

# Generated at 2022-06-24 03:14:20.318314
# Unit test for function tree
def test_tree():
    tree = Tree(initial={
        'a': {
            'x': 1,
            'y': 10
        },
        'b': {
            'z': 3,
            'c': {
                'x': 8
            }
        }
    })

    assert tree.get('a:x') == 1
    assert tree.get('b:c') == {'x': 8}
    assert tree.get('b:z') == 3
    assert tree.get('b:z:c:x') is None

    # Test namespace.
    tree = Tree(namespace='b')
    assert tree.get('c:x') is None
    tree['c:x'] = 2
    assert tree.get('c:x') == 2

# Generated at 2022-06-24 03:14:23.988218
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree()
    t['foo'] = 1
    t['bar:baz'] = 2
    assert t['foo'] == 1
    assert t['bar:baz'] == 2
    try:
        t['baz']
        assert False, 'Should raise KeyError'
    except KeyError:
        pass
    assert t.get('baz', 3) == 3



# Generated at 2022-06-24 03:14:28.139221
# Unit test for function set_tree_node
def test_set_tree_node():
    data = {}
    set_tree_node(data, 'foo', 'bar')
    assert data == {'foo': 'bar'}
    set_tree_node(data, 'foo:bar', 'baz')
    assert data == {'foo': 'bar', 'foo': {'bar': 'baz'}}
    set_tree_node(data, 'foo:bar:biz', 'baz')
    assert data == {'foo': 'bar', 'foo': {'bar': 'baz', 'bar': {'biz': 'baz'}}}



# Generated at 2022-06-24 03:14:32.814634
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    assert __getitem__(Tree(), 'a') == _sentinel
    assert __getitem__(Tree({
        'a': {
            'b': 'c'
        }
    }), 'a:b') == 'c'


# Generated at 2022-06-24 03:14:41.309181
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    # Test tree:
    #
    #   system:
    #     cpu:
    #       idle: 10
    #   memory:
    #     used: 20
    #     free: 80
    tree = {
        'system': {
            'cpu': {
                'idle': 10,
            },
        },
        'memory': {
            'used': 20,
            'free': 80,
        }
    }

    def test_case(key, expected, *args, **kwargs):
        rval = get_tree_node(tree, key, *args, **kwargs)
        assert rval == expected, 'Result of get_tree_node("%s", *%r, **%r) was "%s", expected "%s"' % (key, args, kwargs, str(rval), str(expected))

# Generated at 2022-06-24 03:14:48.909471
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Test function set_tree_node
    """
    # Set up the test
    test_tree = tree()
    test_key = "animals:mammals:cats:breeds:name"
    test_value = "Abyssinian"

    # Execute the function
    node = set_tree_node(test_tree, test_key, test_value)

    # Test the outcome
    assert node["breeds"]["name"] == test_value



# Generated at 2022-06-24 03:14:59.751340
# Unit test for method __getitem__ of class Tree

# Generated at 2022-06-24 03:15:02.128973
# Unit test for function tree
def test_tree():
    assert get_tree_node(tree(), 'foo') is _sentinel


if __name__ == "__main__":
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-24 03:15:12.373883
# Unit test for function get_tree_node
def test_get_tree_node():
    hierarchy = {
        'a': {
            'b': {
                'c': 42
            }
        },
        'a1': {'b': 1, 'c': 'string'},
        'a2': {'b1': 1, 'c1': 'string'},
        'a3': {'b2': 1, 'c2': 'string'},
        'd': 'd_value'
    }

    assert get_tree_node(hierarchy, 'a:b') == {'c': 42}
    assert get_tree_node(hierarchy, 'a1:b') == 1
    assert get_tree_node(hierarchy, 'a:b:c') == 42
    assert get_tree_node(hierarchy, 'a:b:c', default=None) == 42

# Generated at 2022-06-24 03:15:17.597355
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    from unittest import TestCase
    from unittest.mock import Mock

    class TestCase1(TestCase):
        def test_meta(self):
            self.assertIn('tts.utils.tree', self.__module__)

    class TestCase2(TestCase):
        def test_nosetup(self):
            self.assertEqual(self.test, Mock)

    class TestCase3(TestCase):
        def test_setup(self):
            self.assertEqual(self.test, Mock)

    tree = RegistryTree(namespace='tests')
    tree.register(TestCase1)
    tree.register(TestCase2, initial={'test': Mock})
    tree.register(TestCase3, initial={'test': Mock}, namespace='')

    self = tree['tests:TestCase1']


# Generated at 2022-06-24 03:15:27.502919
# Unit test for function set_tree_node
def test_set_tree_node():
    a = tree()
    set_tree_node(a, "foo", "bar")
    set_tree_node(a, "foo:baz", "bar")
    set_tree_node(a, "foo:baz:bar", "bar")
    set_tree_node(a, "hiscores", {u"foo": 20})
    set_tree_node(a, "hiscores:foo", 30)
    set_tree_node(a, "hiscores:bar:foo", 40)
    set_tree_node(a, "hiscores:bar", {u"foo": 40})
    assert a["foo:baz"] == "bar"
    assert a["hiscores:foo"] == 30
    assert a["hiscores:bar:foo"] == 40

# Generated at 2022-06-24 03:15:29.471155
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    t = RegistryTree()
    t.register('myval', 'myval')
    assert t['myval'] == 'myval'

# Generated at 2022-06-24 03:15:37.272663
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    assert (
        Tree({'foo': {'bar': 'baz'}})['foo:bar'] ==
        Tree({'foo': {'bar': 'baz'}}).get('foo:bar') ==
        'baz'
    )
    assert (
        Tree({'foo': {'bar': 'baz'}})['foo:bar:qux'] ==
        Tree({'foo': {'bar': 'baz'}}).get('foo:bar:qux') ==
        {}
    )



# Generated at 2022-06-24 03:15:45.446738
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree()

    t['a:b:c:d'] = 1

    assert t['a:b:c:d'] == 1
    assert t['a']['b']['c']['d'] == 1
    assert t['b']['c']['d'] == 1
    assert t['c']['d'] == 1
    assert t['d'] == 1

    t['a:b:c:d'] = 2

    assert t['a:b:c:d'] == 2
    assert t['a']['b']['c']['d'] == 2
    assert t['b']['c']['d'] == 2
    assert t['c']['d'] == 2
    assert t['d'] == 2



# Generated at 2022-06-24 03:15:51.818159
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    test_tree = RegistryTree()
    # Test for namespace:
    test_tree['something_or_other'] = 'something'
    assert 'something' == test_tree['something_or_other']
    # Test for no namespace:
    test_tree['another_thing'] = 'thing'
    assert 'thing' == test_tree['another_thing']



# Generated at 2022-06-24 03:15:57.359638
# Unit test for function tree
def test_tree():
    from pprint import pprint
    t = tree()
    t['a']['b']['c'] = 'd'
    assert t['a']['b']['c'] == 'd'
    assert t['a']['b']['c'] == 'd'
    assert t['a']['b']['c'] == 'd'
    pprint(dict(t))


if __name__ == '__main__':
    if False:
        TestTree()

    # Test tree()
    test_tree()

# Generated at 2022-06-24 03:16:00.345374
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()
    tree['foo'] = 'bar'
    assert tree['foo'] == 'bar'



# Generated at 2022-06-24 03:16:03.333795
# Unit test for function tree
def test_tree():
    t = tree()
    t['hello']['world']['foo'] = 42
    assert t['hello']['world']['foo'] == 42
    assert t['hello:world:foo'] == 42



# Generated at 2022-06-24 03:16:10.978194
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    import pprint

    reg = RegistryTree(namespace='default')
    reg.register('foo', 'bar')
    reg.register('foo:bar', 'baz')
    assert reg.get('foo') == 'bar'
    assert reg.get('foo:bar') == 'baz'
    assert reg.get('foo:bar:baz') is None
    pprint.pprint(dict(reg))
    assert reg.get('baz') is None
    reg.register('baz:bar', 'baz')
    assert reg.get('baz:bar') == 'baz'



# Generated at 2022-06-24 03:16:20.280923
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    # 1. Test case where there is a match
    tree_instance_1 = Tree(initial={'a':{'b':{'c':'c d'}}})
    assert tree_instance_1['a:b:c'] == 'c d'
    assert tree_instance_1.get('a:b:c') == 'c d'
    assert tree_instance_1.__getitem__('a:b:c') == 'c d'
    # 2. Test case where there is no match
    tree_instance_2 = Tree(initial={'a':{'b':{'c':'c d'}}})
    assert tree_instance_2['a:b:c:d'] == None
    assert tree_instance_2.get('a:b:c:d') == None
    assert tree_instance_2.__get

# Generated at 2022-06-24 03:16:25.311263
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    registry = RegistryTree()

    registry['foo:bar:car:bar'] = 'Hello World'
    registry['foo:car'] = 'baz'
    registry.register('foo:baz:bar', 'car')

    assert registry['foo:bar:car:bar'] == 'Hello World'
    assert registry['foo:car'] == 'baz'
    assert registry['foo:baz:bar'] == 'car'



# Generated at 2022-06-24 03:16:29.701922
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    tree = RegistryTree()
    tree.set('foo', 'bar')
    assert tree.get('foo') == 'bar'

# Generated at 2022-06-24 03:16:34.599215
# Unit test for function set_tree_node
def test_set_tree_node():
    d = {
        'a': {
            'b': 'c',
        },
    }
    set_tree_node(d, 'a:b:c:d', 'e')
    assert d == {'a': {'b': {'c': {'d': 'e'}}}}



# Generated at 2022-06-24 03:16:41.662597
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t1 = Tree()
    t2 = t1[None]
    assert t2 == {}
    t1[None][None][None] = 't1'
    assert t1[None][None][None] == 't1'
    t2[None][None] = 't2'
    assert t1[None][None][None] == 't1'
    assert t2[None][None] == 't2'



# Generated at 2022-06-24 03:16:48.858331
# Unit test for constructor of class Tree
def test_Tree():
    import pprint
    t = Tree()

    t['a'] = 1
    t['b'] = 2
    t['c.a'] = 3
    t['c.b'] = 4
    t['c.c.a'] = 5
    t['c.c.b'] = 6

    assert t == {'a': 1, 'b': 2, 'c': {'a': 3, 'b': 4, 'c': {'a': 5, 'b': 6}}}



# Generated at 2022-06-24 03:16:53.734290
# Unit test for function set_tree_node
def test_set_tree_node():
    m = {}
    set_tree_node(m, 'a', 'A')
    set_tree_node(m, 'b', 'B')
    set_tree_node(m, 'c:d:e:f:g:h', 'test')
    assert m == {
        'a': 'A',
        'b': 'B',
        'c': {
            'd': {
                'e': {
                    'f': {
                        'g': {
                            'h': 'test'
                        }
                    }
                }
            }
        }
    }



# Generated at 2022-06-24 03:17:02.320434
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    import nose.tools as nt
    t = Tree()
    t['a'] = 'a'
    nt.assert_equal(t['a'], 'a')
    t['b:c'] = 'b:c'
    nt.assert_equal(t['b'], {})
    nt.assert_equal(t['b:c'], 'b:c')
    t['b:d'] = 'b:d'
    nt.assert_equal(t['b'], {'c': 'b:c', 'd': 'b:d'})
    t['b'] = {'c': 'b:c'}
    nt.assert_equal(t['b'], {'c': 'b:c'})

# Generated at 2022-06-24 03:17:06.892074
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    from nose.tools import ok_, eq_

    t = Tree()
    t['foo'] = 'bar'
    eq_(t['foo'], 'bar')

    # Check for KeyError
    with ok_(raises(KeyError)):
        t['baz']

    # Check for default value
    ok_(eq_(t.get('baz'), None))



# Generated at 2022-06-24 03:17:14.025568
# Unit test for function get_tree_node
def test_get_tree_node():
    a = {
        'bar': {
            'baz': 3
        }
    }
    assert get_tree_node(a, 'foo') is _sentinel
    assert get_tree_node(a, 'foo', None) is None
    assert get_tree_node(a, 'bar:baz') == 3
    assert get_tree_node(a, 'bar:baz', None) == 3
    # returns parent if requested
    assert get_tree_node(a, 'bar:baz', parent=True) == {'baz': 3}



# Generated at 2022-06-24 03:17:17.459987
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree_ = Tree(initial={'key': 'value'})
    assert tree_['key'] == 'value'



# Generated at 2022-06-24 03:17:21.437762
# Unit test for function set_tree_node
def test_set_tree_node():
    test = {'foo': {'bar': 1492}}
    set_tree_node(test, 'foo:bar', 1234)
    assert test['foo']['bar'] == 1234, test

    set_tree_node(test, 'foo:replaced', 1492)
    assert test['foo']['replaced'] == 1492, test



# Generated at 2022-06-24 03:17:27.715854
# Unit test for function tree
def test_tree():
    _tree = tree()
    _tree['a']['b']['c'] = 'd'
    assert _tree['a']['b']['c'] == 'd'
    assert _tree['a:b:c'] == 'd'
    _tree['a:b:l'] = 'm'
    assert _tree['a']['b']['c'] == 'd'
    assert _tree['a']['b']['l'] == 'm'
    assert _tree['a:b:l'] == 'm'
    assert _tree['a:b:c'] == 'd'



# Generated at 2022-06-24 03:17:36.193838
# Unit test for function get_tree_node
def test_get_tree_node():
    """Test get_tree_node function."""
    tree = {
        'a': {
            'b': 'c'
        }
    }
    assert get_tree_node(tree, 'a') == {'b': 'c'}
    assert get_tree_node(tree, 'a:b') == 'c'
    assert get_tree_node(tree, 'a:b:c', default='missing') == 'missing'
    try:
        get_tree_node(tree, 'a:b:c')
        assert False, "KeyError not raised on invalid key."
    except KeyError:
        pass


if __name__ == '__main__':
    test_get_tree_node()

# Generated at 2022-06-24 03:17:46.363425
# Unit test for function tree
def test_tree():
    t = tree()
    t['a']['b']['c']['d'] = 3
    t['a']['b']['c']['e'] = 4
    assert t['a']['b']['c']['d'] == 3
    assert t['a']['b']['c']['e'] == 4
    t['a']['b']['c']['e'] = 10
    assert t['a']['b']['c']['e'] == 10
    assert t['a']['b']['q'] == {}
    # ensure it's still a tree
    # t['a']['b']['q']['p']['o'] = 7
    # assert t['a']['b']['q']['p'

# Generated at 2022-06-24 03:17:49.884017
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    """
    >>> RegistryTree()
    {}

    >>> RegistryTree([])
    {}

    >>> RegistryTree({'a': 1, 'b': [1, 2, 3]})
    {'a': 1, 'b': [1, 2, 3]}

    """
    pass



# Generated at 2022-06-24 03:17:56.945359
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }

    assert get_tree_node(tree, 'a:b') == {'c': 'd'}
    assert get_tree_node(tree, 'a:b:c') == 'd'
    assert get_tree_node(tree, 'a:b:c:d', 'e') == 'e'



# Generated at 2022-06-24 03:18:07.215867
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    from pprint import pprint

    class A(RegistryTree):
        pass

    A.register(A, 'test')
    pprint(A.registry_tree)


if __name__ == '__main__':
    # Unit test for constructor of class Tree
    def test_Tree():
        from pprint import pprint

        tree = Tree('initial_value')
        assert tree.get('initial') == 'value'
        tree['nested'] = 'value'
        assert tree.get('nested') == 'value'
        assert tree.get('nested:value') == tree['nested']['value']
        assert tree.get('nested:value') == 'value'
        assert tree.get('nested:value', 'default') == 'value'

# Generated at 2022-06-24 03:18:11.884654
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()
    tree['a'] = 1
    assert tree['a'] == 1

    tree['b'] = Tree()
    tree['b']['c'] = 2
    tree.update(Tree(tree['b']))
    assert tree['b:c'] == 2

    assert tree['b:d'] == {}
    assert tree['b']['d'] == {}



# Generated at 2022-06-24 03:18:16.244888
# Unit test for function tree
def test_tree():
    t = tree()
    t['tree']['is']['awesome'] = True  # Much better than nested dicts!

    print(t)



# Generated at 2022-06-24 03:18:23.132306
# Unit test for function tree
def test_tree():
    t = tree()
    t['Am I a Tree?'] = 'Yes. Yes you are.'
    assert t['Am I a Tree?'] == 'Yes. Yes you are.'
    t['I']['Am']['Still']['A']['Tree'] = 'Yes.'
    assert t['I:Am:Still:A:Tree'] == 'Yes.'
    t['I:Am:Not:A:Tree'] = 'No.'
    assert t['I:Am:Not:A:Tree'] == 'No.'
    return t



# Generated at 2022-06-24 03:18:25.775535
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree()
    t['x'] = 0
    t['y'] = 1
    assert t['x'] == 0
    assert t['y'] == 1



# Generated at 2022-06-24 03:18:32.292128
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    # Test ':'.
    a = Tree()
    a['b:c'] = 1
    assert a['b']['c'] == 1

    # Test default.
    a = Tree()
    assert a['b', 0] == 0

    # Test namespace.
    a = Tree(namespace='d')
    a['b'] = 1
    assert a['d:b'] == 1



# Generated at 2022-06-24 03:18:34.830009
# Unit test for function set_tree_node
def test_set_tree_node():
    t = tree()
    assert set_tree_node(t, 'foo', 1) == {'foo': 1}
    assert set_tree_node(t, 'foo:bar', 2) == {'foo': {'bar': 2}}



# Generated at 2022-06-24 03:18:37.083562
# Unit test for function set_tree_node
def test_set_tree_node():
    m = {}
    assert set_tree_node(m, 'foo:bar', 'baz') == {'foo': {'bar': 'baz'}}



# Generated at 2022-06-24 03:18:41.627480
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    tree_ = RegistryTree()
    tree_.register('a:b:c', 1)
    tree_.register('a:b:d', 2)
    tree_.register('a:e', 3)
    assert tree_['a:b:c'] == 1
    assert tree_['a:b:d'] == 2
    assert tree_['a:e'] == 3


if __name__ == '__main__':
    test_RegistryTree()

# Generated at 2022-06-24 03:18:52.075181
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'hello': ['world']}, 'hello:0') == 'world'
    assert get_tree_node({'hello': ['world']}, 'hello:1', default='') == ''
    assert get_tree_node({'hello': ['world']}, 'hello:1', default='') == ''
    assert get_tree_node({'hello': {'world': 'hello'}}, 'hello:world') == 'hello'
    assert get_tree_node({'hello': {'world': 'hello'}}, 'hello:world:hello', default='') == ''
    assert get_tree_node({'hello': {'world': 'hello'}}, 'hello:world:hello', default='') == ''

# Generated at 2022-06-24 03:19:01.285478
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    a = Tree()
    assert a['foo'] == {}
    a['foo']['bar'] = 1
    assert a['foo']['bar'] == 1

    a = Tree()
    a['foo:bar'] = 2
    assert a['foo']['bar'] == 2

    # Test namespace
    a = Tree(namespace='ns')
    a['foo:bar'] = 2
    assert a['foo'] == {}
    assert a['ns:foo:bar'] == 2

    # Test namespace setitem
    a = Tree(namespace='ns')
    a.__setitem__('foo:bar', 2, namespace='other')
    assert 'other:foo:bar' in a.keys()
    assert 'ns:other:foo:bar' not in a.keys()

    # Test namespace getitem

# Generated at 2022-06-24 03:19:05.970907
# Unit test for function tree
def test_tree():
    t = tree()
    t[1:2][3] = 4
    assert t[1:2][3] == 4



# Generated at 2022-06-24 03:19:16.905648
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    a = Tree()
    # Check for empty Tree
    assert a["foo"].data == {}
    # Check for nonexistent key
    assert a["bar"].data == {}
    # Add some keys
    a["foo"]["bar"] = "baz"
    a["foo"]["baz"] = "foo"
    a["bar"]["foo"] = "bar"
    # Assert we have our keys
    assert a["foo"].data == {"bar": "baz", "baz": "foo"}
    assert a["bar"].data == {"foo": "bar"}
    # Remove those keys
    del a["foo"]["bar"]
    del a["foo"]["baz"]
    del a["bar"]["foo"]
    # Assert they were removed
    assert a["foo"].data == {}

# Generated at 2022-06-24 03:19:19.517469
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree = Tree()
    tree.register('foo', 42)
    assert tree.get('foo') == 42, 'Error at __getitem__ of Tree'
    assert tree.get('foo:42') == 42, 'Error at __getitem__ of Tree'

# Generated at 2022-06-24 03:19:29.550427
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = tree()
    set_tree_node(mapping, "a", {'b': 1})
    set_tree_node(mapping, "b", {'c': 2})
    set_tree_node(mapping, "c", {'d': 3})
    assert get_tree_node(mapping, "a") == {'b': 1}
    assert get_tree_node(mapping, "b") == {'c': 2}
    assert get_tree_node(mapping, "c") == {'d': 3}
    assert get_tree_node(mapping, "a:b") == 1
    assert get_tree_node(mapping, "b:c") == 2
    assert get_tree_node(mapping, "c:d") == 3

# Generated at 2022-06-24 03:19:32.658146
# Unit test for constructor of class Tree
def test_Tree():
    my_tree = Tree(initial=dict(x='b'))
    assert my_tree['x'] == 'b'



# Generated at 2022-06-24 03:19:39.796172
# Unit test for function tree
def test_tree():
    boom = tree()
    boom['thing']['thing2']['thing3'] = 'Boom!'

# Generated at 2022-06-24 03:19:44.986949
# Unit test for function set_tree_node
def test_set_tree_node():
    """Test function set_tree_node"""
    data = {}
    set_tree_node(data, 'foo:bar', 'baz')
    assert data == {'foo': {'bar': 'baz'}}
    set_tree_node(data, 'foo', 'baz')
    assert data == {'foo': 'baz'}
    set_tree_node(data, 'bar', 'baz')
    assert data == {'foo': 'baz', 'bar': 'baz'}



# Generated at 2022-06-24 03:19:49.326867
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    class Test(RegistryTree):
        pass

    test = Test(initial={'something': 'else'})
    print(test.get('something'))


if __name__ == '__main__':
    test_RegistryTree()

# Generated at 2022-06-24 03:19:50.729866
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    data = Tree([('1:2:3', 4)])
    assert data['1:2:3'] == 4

# Generated at 2022-06-24 03:19:54.100448
# Unit test for function set_tree_node
def test_set_tree_node():
    from pprint import pprint
    import boto
    cf = boto.connect_cloudformation()
    for stack in cf.list_stacks():
        print(stack.stack_name)
        resources = stack.describe_resources()
        pprint(resources)

# Generated at 2022-06-24 03:19:57.734315
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}
    set_tree_node(tree, 'foo:bar', 'value')
    assert tree['foo']['bar'] == 'value'



# Generated at 2022-06-24 03:20:07.768421
# Unit test for method __getitem__ of class Tree

# Generated at 2022-06-24 03:20:11.362287
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    pass

# Generated at 2022-06-24 03:20:17.107035
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    assert RegistryTree().namespace == ''

    assert RegistryTree(namespace='test').namespace == 'test'

    assert RegistryTree(namespace='test', initial={'a': 1}).get('a') == 1

    assert RegistryTree(initial={'test': {'a': 1}}).get('test:a') == 1

    assert RegistryTree(namespace='test', initial={'a': 1}).get('a') == 1



# Generated at 2022-06-24 03:20:20.138549
# Unit test for function tree
def test_tree():

    t = tree()
    t['a']['b']['c'] = 1
    t['a']['b']['d'] = 2


# Generated at 2022-06-24 03:20:26.681410
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()
    for key in [
        'a',
        'a:b',
        'a:b:c',
        'a:b:d',
        'a:b:c:d',
        'a:b:c:d:e',
    ]:
        tree[key] = key

    assert tree['a']['b']['c']['d']['e'] == 'a:b:c:d:e'



# Generated at 2022-06-24 03:20:37.884682
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Unit test for function `get_tree_node`.
    """
    mapping = tree()

    # Valid ops
    mapping[':']['a'] = 1
    mapping['b'] = 2
    mapping['c'] = 3

    assert mapping == {':': {'a': 1}, 'b': 2, 'c': 3}
    assert get_tree_node(mapping, ':') == {}
    assert get_tree_node(mapping, ':a') == 1
    assert get_tree_node(mapping, ':a:b') is _sentinel
    assert get_tree_node(mapping, ':a:b', default=4) == 4

    # Invalid ops
    with pytest.raises(KeyError):
        get_tree_node(mapping, ':a:b')

# Generated at 2022-06-24 03:20:40.815371
# Unit test for constructor of class Tree
def test_Tree():
    foo = Tree()
    foo['bar'] = 'barvalue!'
    assert foo['bar'] == 'barvalue!'
    assert foo['baz']['boo'] == dict(bar=None)



# Generated at 2022-06-24 03:20:50.389541
# Unit test for function set_tree_node
def test_set_tree_node():
    d = {}
    # set first node
    set_tree_node(d, 'a:b:c', {'value': True})
    # set second node
    set_tree_node(d, 'a:c:d', {'value': True})
    # set third node
    set_tree_node(d, 'a:b:e', {'value': True})

    # check that all three nodes are set
    assert d['a']['b']['c']['value'] is True
    assert d['a']['b']['e']['value'] is True
    assert d['a']['c']['d']['value'] is True



# Generated at 2022-06-24 03:20:56.923789
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()
    tree.update({'foo': 'bar', 'bar': {'baz': 'foo'}})
    tree['foo'] = 'baz'
    assert tree['foo'] == 'baz'

    tree['bar:baz'] = 'baz'
    assert tree['bar:baz'] == 'baz'
    assert tree['bar']['baz'] == 'baz'



# Generated at 2022-06-24 03:21:00.227576
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree = Tree({
        'a': {
            'b': {
                'c': {
                    'd': 'e',
                },
            },
        },
    })
    assert tree['a:b:c:d'] == 'e'

# Generated at 2022-06-24 03:21:08.515865
# Unit test for function set_tree_node
def test_set_tree_node():
    my_tree = tree()
    my_tree['a']['b']['c']['d']['e']['f']['g']['h'] = {'foo': 'bar'}
    assert get_tree_node(my_tree, 'a:b:c:d:e:f:g:h') == {'foo': 'bar'}
    assert get_tree_node(my_tree, 'a:b:c:d:e:f:g:h:foo') == 'bar'



# Generated at 2022-06-24 03:21:10.683927
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()
    tree['foo'] = 'bar'
    assert tree['foo'] == 'bar'



# Generated at 2022-06-24 03:21:13.291566
# Unit test for function get_tree_node
def test_get_tree_node():
    d = {'a': {'b': 'c'}}
    assert get_tree_node(d, 'a:b') == 'c'



# Generated at 2022-06-24 03:21:18.199206
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    data = {
        'foo': {
            'bar': 'baz'
        }
    }
    tree = Tree(data)

    assert tree.__getitem__('foo:bar') == 'baz'
    # With namespacing
    tree = Tree(data, 'namespace')
    assert tree.__getitem__('bar') == 'baz'
    assert tree.__getitem__('bar', namespace='namespace') == 'baz'

# Generated at 2022-06-24 03:21:20.728783
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}
    set_tree_node(tree, 'parent:child', 'value')
    assert tree == {'parent': {'child': 'value'}}



# Generated at 2022-06-24 03:21:25.918309
# Unit test for function tree
def test_tree():
    import nose
    import collections
    test_values = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 'a', 'b', 'c', 'd', 'e', 'f']
    t = tree()
    for idx, val in enumerate(test_values):
        t[0][0][idx] = val
    nose.tools.assert_equals(t[0][0], test_values)



# Generated at 2022-06-24 03:21:32.342192
# Unit test for function tree
def test_tree():
    a = tree()
    a['hello']['world']['foo'] = 1
    a['hello']['world']['bar'] = 2
    assert a['hello']['world']['foo'] == 1
    a['hello']['bar'] = 3
    assert a['hello']['bar'] == 3
    assert a['hello']['world']['bar'] == 2



# Generated at 2022-06-24 03:21:38.063014
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree({'foo': {'bar': {'baz': 'qux'}}})
    assert t['foo']['bar']['baz'] == 'qux'

    assert t.get('fubar', namespace='foo') is None

    t.set('fubar', 'huzzah', namespace='foo')

    assert t['foo']['fubar'] == 'huzzah'



# Generated at 2022-06-24 03:21:42.261879
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    registry = RegistryTree()
    registry.register('a', 'b', {'c': 'd'})
    registry.register('a.b', 'b', {'c': 'd'})
    registry.register('a.b.c', 'd')
    assert 'd' == registry['a.b.c']

# Generated at 2022-06-24 03:21:44.685623
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    instance = RegistryTree()
    assert isinstance(instance, RegistryTree)
    assert isinstance(instance, Tree)
    assert isinstance(instance, collections.defaultdict)



# Generated at 2022-06-24 03:21:53.326480
# Unit test for function tree
def test_tree():
    tree = Tree()
    tree['b']['b'] = 1
    assert tree['b']['b'] == 1
    assert tree['b']['c'] == {}
    assert tree['c']['b'] == {}
    tree = Tree()
    tree['a']['b']['c'] = 1
    assert tree['a']['b']['c'] == 1
    assert tree['a']['c'] == {}
    tree = Tree()
    tree['a:b:c'] = 1
    assert tree['a:b:c'] == 1
    assert tree['a']['b'] == {}
    tree = Tree()
    tree['a:b:c'] = 1
    assert tree['a:b:c'] == 1

# Generated at 2022-06-24 03:22:03.326624
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    from test.test_support import run_unittest as _run_unittest
    from test.test_support import swap_attr as _swap_attr
    from test.test_support import check_py3k_warnings as _check_py3k_warnings


# Generated at 2022-06-24 03:22:05.473108
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()
    tree['a:b:c'] = 5
    assert tree['a']['b']['c'] == 5



# Generated at 2022-06-24 03:22:08.726321
# Unit test for constructor of class RegistryTree
def test_RegistryTree():

    class _RegistryTree(RegistryTree):

        class namespace(RegistryTree):
            pass

    tree = _RegistryTree()
    tree.namespace.register('blah', 'boo')
    assert tree.get('blah') == 'boo'



# Generated at 2022-06-24 03:22:15.065743
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    import pytest
    with pytest.raises(KeyError) as exc_info:
        RegistryTree(
            initial={
                'namespace': {
                    'foo': 'bar',
                },
            },
            initial_is_ref=False,
            namespace='namespace'
        )['foo']

    # Test success
    rt = RegistryTree(
        initial={
            'namespace': {
                'foo': 'bar',
            },
        },
        initial_is_ref=True,
        namespace='namespace'
    )
    assert rt['foo'] == 'bar'

# Generated at 2022-06-24 03:22:17.054137
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    t['hello'] = 'world'
    assert t['hello'] == 'world'



# Generated at 2022-06-24 03:22:26.008299
# Unit test for function get_tree_node
def test_get_tree_node():
    node = Tree({
        'bla': {
            'foo': {
                'bar': 'baz',
                'qux': 4
            }
        },
        'baz': {
            'foo': {
                'bar': 'baz2',
                'qux': 5
            }
        }
    }, initial_is_ref=True)

    assert node['bla:foo:bar'] == 'baz'
    assert node['bla:foo:qux'] == 4
    assert node['baz:foo:bar'] == 'baz2'
    assert node['baz:foo:qux'] == 5

    try:
        node['bla:foo']
        assert False
    except KeyError:
        assert True



# Generated at 2022-06-24 03:22:31.143134
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    rt = RegistryTree()
    rt.register('a', {})
    rt.register('b', {})
    rt.register('a', {})
    rt.register('a', {})

    assert rt['a'] == {}, 'rt["a"] is not an empty dict'
    assert rt['b'] == {}, 'rt["b"] is not an empty dict'


if __name__ == '__main__':
    test_RegistryTree()

# Generated at 2022-06-24 03:22:35.883038
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()
    tree['key'] = 'value'
    assert tree['key'] == 'value'



# Generated at 2022-06-24 03:22:40.453870
# Unit test for function tree
def test_tree():
    """
    Basic unit test for `tree`.
    """
    k = tree()
    k[1][2][3] = 4
    assert k[1][2] == {3: 4}
    assert k[1][2][3] == 4


if __name__ == '__main__':
    test_tree()

# Generated at 2022-06-24 03:22:50.712658
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()\
        .register('animal:mammal:dog', 'bark')\
        .register('animal:mammal:cat', 'meow')\
        .register('animal:fish:goldfish', 'plop')\
        .register('animal:fish:nemo', 'chirp')\
        .register('animal:fish:nemo:bob', 'bark')
    assert tree['animal:mammal:dog'] == 'bark'
    assert tree['animal:mammal:cat'] == 'meow'
    assert tree['animal:fish:goldfish'] == 'plop'
    assert tree['animal:fish:nemo'] == 'chirp'
    assert tree['animal:fish:nemo:bob'] == 'bark'



# Generated at 2022-06-24 03:22:53.529223
# Unit test for function set_tree_node
def test_set_tree_node():
    data = {}
    set_tree_node(data, 'one:two:three', 42)
    assert data == {'one': {'two': {'three': 42}}}



# Generated at 2022-06-24 03:23:02.208509
# Unit test for function get_tree_node
def test_get_tree_node():
    dictionary = {
        'one-level': 'one-level-value',
        'two-levels': {
            'one': 'two-levels-one',
            'two': 'two-levels-two',
        },
        'three-levels': {
            'one': {
                'one': 'three-levels-one-one',
                'two': 'three-levels-one-two',
            },
            'two': {
                'one': 'three-levels-two-one',
                'two': 'three-levels-two-two',
            },
        },
    }

    # Test one-level
    assert get_tree_node(dictionary, 'one-level') == 'one-level-value'

# Generated at 2022-06-24 03:23:09.076242
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {'1': {'2': {'3': 3, '5': 5}}}
    assert get_tree_node(tree, '1:2:3') == 3
    # Should raise KeyError
    try:
        get_tree_node(tree, '1:2:4')
        assert False
    except KeyError:
        assert True



# Generated at 2022-06-24 03:23:13.164612
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    registry = RegistryTree({'test': 'inital'})
    assert registry.test == 'inital'
    assert registry['test'] == 'inital'



# Generated at 2022-06-24 03:23:14.624616
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree(initial={'foo': 'bar'})
    assert t['foo'] == 'bar'



# Generated at 2022-06-24 03:23:17.010449
# Unit test for function set_tree_node
def test_set_tree_node():
    my_tree = tree()
    my_tree[':dim1:dim2:dim3'] = 42
    assert my_tree['dim1']['dim2']['dim3'] == 42



# Generated at 2022-06-24 03:23:26.304056
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    from datetime import datetime
    from sys import version_info
    assert Tree()['_'].get('python_version') == version_info[0]

    assert Tree().get('empty_string') == _sentinel
    assert Tree().get('empty_string', 'def_value') == 'def_value'

    assert Tree({'a': 'b'})['a'] == 'b'

    assert Tree({'a': 'b', 'c': {'d': 'e'}}).get('c:d') == 'e'
    assert Tree({'a': 'b', 'c': {'d': {'e': {'f': 'g'}}}}).get('c:d:e:f') == 'g'

# Generated at 2022-06-24 03:23:37.221820
# Unit test for function set_tree_node
def test_set_tree_node():
    """Test function `set_tree_node`."""

    # Given a tree-like mapping object
    tree_like_mapping = {
        'root': {
            'Foo': {
                'Bar': 'Baz',
                'Bing': [1, 2, 3],
            },
        },
    }

    # When I call set_tree_node on the mapping
    result = set_tree_node(tree_like_mapping, 'root:Foo:Mykey', 'Myvalue')

    # Then the result should be the parent node
    assert result == {'Mykey': 'Myvalue'}

    # And the value should be set.

# Generated at 2022-06-24 03:23:39.683616
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    registry = RegistryTree()
    registry.register('test:something:whatevs', value=5)
    registry.register('test:something', value=5)



# Generated at 2022-06-24 03:23:45.384266
# Unit test for function tree
def test_tree():
    data = tree()
    data['wow']['cool']['amazing'] = 0
    data['wow']['cool']['awesome'] = 1

    from pprint import pprint
    pprint(data)



# Generated at 2022-06-24 03:23:50.753741
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    t['a'] = 1
    t['b'] = 2
    assert t['a'] == 1
    assert t['b'] == 2



# Generated at 2022-06-24 03:23:59.574407
# Unit test for constructor of class Tree
def test_Tree():
    """Testing Tree constructor"""
    import json

    t = Tree({
        'p': {
            'u': {
                'r': {
                    'p': {
                        'o': {
                            's': {
                                'e': {
                                    's': {
                                        ':': {
                                            'p': 'I am an oddly-shaped JSON tree :D'
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }, initial_is_ref=True)
    assert isinstance(t, Tree)

    assert t._namespace_key('a') == 'a'
    assert t._namespace_key('a', namespace='b') == 'b:a'

    t.namespace = 'p:u'
    assert t

# Generated at 2022-06-24 03:24:04.280055
# Unit test for function set_tree_node
def test_set_tree_node():
    test_tree = {}
    set_tree_node(test_tree, 'key:to:node', u'value')
    assert test_tree['key']['to']['node'] == u'value'
    set_tree_node(test_tree, 'key:to:node', u'newvalue')
    assert test_tree['key']['to']['node'] == u'newvalue'



# Generated at 2022-06-24 03:24:07.676877
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    t.__setitem__('a', 1)
    assert t.get('a') == 1
    # TODO Real tests.



# Generated at 2022-06-24 03:24:11.324550
# Unit test for function set_tree_node
def test_set_tree_node():
    d = {}
    set_tree_node(d, 'py:utils:test', 1)
    assert d['py']['utils']['test'] == 1
    assert d['py']['utils']['test'] == 1

