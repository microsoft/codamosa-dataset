

# Generated at 2022-06-24 03:14:20.822053
# Unit test for constructor of class Tree
def test_Tree():
    """Unit test for constructor for `Tree().
    """
    _tree = Tree()
    _tree['a']['b']['c'] = 1
    _tree['a']['b']['d'] = 2
    assert _tree['a']['b']['c'] == 1
    assert _tree['a']['b']['d'] == 2

    _tree = Tree(initial={
        'a': {
            'b': {
                'c': 1
            }
        }
    })
    assert _tree['a']['b']['c'] == 1

    # Test separate namespace
    _tree = Tree(initial={
        'a:b:c': 1
    }, namespace='a')
    assert _tree['b']['c'] == 1


# Generated at 2022-06-24 03:14:32.180884
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    import re
    import nose
    import nose.tools as nt

    t = Tree()
    t.__setitem__('a', 1)
    t.__setitem__('a:b', 2)
    t.__setitem__('a:c:d', 3)
    t.__setitem__('a:c:e', 4)
    t.__setitem__('a:f', 5)

    nose.tools.set_trace()

    # __setitem__ should return `self`, in this case a new instance of class Tree.
    output_line_0 = t.__setitem__('a', 0).__setitem__('a:b', 0).__setitem__(
        'a:c:d', 0).__setitem__('a:c:e', 0)

    output_line_1 = t

# Generated at 2022-06-24 03:14:38.473625
# Unit test for function set_tree_node
def test_set_tree_node():
    reg = {}
    assert set_tree_node(reg, 'foo:bar:baz', {'qux': 'quxx'}) == {'foo': {'bar': {'baz': {'qux': 'quxx'}}}}



# Generated at 2022-06-24 03:14:43.417154
# Unit test for function set_tree_node
def test_set_tree_node():
    assert set_tree_node({}, 'a:b:c', 15) == {'a': {'b': {'c': 15}}}
    assert set_tree_node({'a': {'b': {'c': 15}}}, 'a:b:c', 15) == {'a': {'b': {'c': 15}}}
    assert set_tree_node({}, 'a:b', 15) == {'a': {'b': 15}}
    assert set_tree_node({'a': {'b': {'c': 15}}}, 'a:b', 15) == {'a': {'b': 15}}



# Generated at 2022-06-24 03:14:48.870293
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    ctx = RegistryTree()
    ctx.register('foo:bar:baz', 'Foo Bar Baz')
    assert ctx == {'foo': {'bar': {'baz': 'Foo Bar Baz'}}}
    assert ctx['foo:bar:baz'] == 'Foo Bar Baz'



# Generated at 2022-06-24 03:14:59.752663
# Unit test for function tree
def test_tree():
    data = tree()
    data['a']['b']['c'] = 1
    data['a']['b']['d'] = 2
    data['a']['e'] = 3
    data['f'] = 4

    assert data['a']['b']['c'] == 1
    assert data['a']['b']['d'] == 2
    assert data['a']['e'] == 3
    assert data['f'] == 4
    assert data['a']['b'] == {'c': 1, 'd': 2}
    assert data['a'] == {'b': {'c': 1, 'd': 2}, 'e': 3}
    assert data == {'a': {'b': {'c': 1, 'd': 2}, 'e': 3}, 'f': 4}



# Generated at 2022-06-24 03:15:05.835719
# Unit test for function set_tree_node
def test_set_tree_node():
    d = tree()
    set_tree_node(d, 'hello:world', 'hi')
    assert d['hello']['world'] == 'hi'

    set_tree_node(d, 'hello:world:howdy:doo', 'hello')
    assert d['hello']['world']['howdy']['doo'] == 'hello'



# Generated at 2022-06-24 03:15:09.975962
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():

    # Initialize test model
    t = Tree({
        'a': {
            'b': {
                'c': {
                    'd': 'e',
                },
            },
        },
    }, namespace='a')

    # Test function
    assert t['b:c:d'] == 'e'



# Generated at 2022-06-24 03:15:11.769339
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    registry = RegistryTree()
    registry.register('a.b.c', 123)
    assert registry['a.b.c'] == 123
    assert registry['a.b.c'] == 123
    assert registry['a.b.c'] == 123

# Generated at 2022-06-24 03:15:14.144998
# Unit test for function set_tree_node
def test_set_tree_node():
    a = Tree()
    set_tree_node(a, 'b:c:d:e:f:g', 'h')
    assert a['b']['c']['d']['e']['f']['g'] == 'h'



# Generated at 2022-06-24 03:15:18.596646
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = tree()
    t['a']['b']['x'] = 1
    t['a']['b']['y'] = 2
    t['a']['b']['z'] = 3
    assert t['a']['b']['z'] == 3
    assert t.get('a:b:x') == 1
    assert t['a:b:y'] == 2



# Generated at 2022-06-24 03:15:28.204182
# Unit test for constructor of class Tree
def test_Tree():
    assert tree() == {'a': {'b': {}}}
    assert Tree() == {'a': {'b': {}}}
    assert Tree({'a': {'b': {}}}) == {'a': {'b': {}}}
    assert Tree(namespace='monkey') == {'monkey': {'a': {'b': {}}}}
    assert Tree(namespace='monkey').namespace == 'monkey'
    assert Tree(namespace='monkey')['monkey'] == {'a': {'b': {}}}
    assert Tree(namespace='monkey')['monkey:a:b'] == {}
    assert Tree(namespace='monkey')['monkey:a:b'] == {}
    assert Tree(namespace='monkey')['monkey'] == {'a': {'b': {}}}

# Generated at 2022-06-24 03:15:32.474115
# Unit test for function get_tree_node
def test_get_tree_node():
    thing = tree()
    thing['a'] = tree()
    thing['a']['b'] = 'c'
    thing['d'] = 'e'
    assert 'e' == get_tree_node(thing, 'd')
    assert 'c' == get_tree_node(thing, 'a:b')
    assert get_tree_node(thing, 'a:lol') is _sentinel

# Generated at 2022-06-24 03:15:41.251381
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree()
    assert t['item'] == {}

    t['sub:subsub:subsubsubsub'] = 'subsubsubsub value'
    assert t['sub:subsub:subsubsubsub'] == 'subsubsubsub value'

    # Test namespace
    n = Tree(namespace='x')
    assert n['y'] == {}
    assert n.get('z') == None

    n['y'] = 'y value'
    assert n['y'] == 'y value'
    assert n['x:y'] == 'y value'



# Generated at 2022-06-24 03:15:45.088857
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()
    assert tree['foo']['bar']['baz'] == tree
    assert tree['foo']['bar']['baz'] is not tree
    tree['foo']['bar']['baz']['quux'] = 3
    assert tree['foo']['bar']['baz']['quux'] == 3

# Generated at 2022-06-24 03:15:47.681539
# Unit test for constructor of class Tree
def test_Tree():
    tree = Tree({'foo': {'bar': 'baz'}})
    assert tree['foo:bar'] == 'baz'


if __name__ == '__main__':
    test_Tree()

# Generated at 2022-06-24 03:15:53.719389
# Unit test for constructor of class Tree
def test_Tree():
    tree = Tree(tree(), 'ns')
    tree.register('foo', 'bar')
    assert tree.get('foo') == 'bar'
    assert tree.get('ns:foo') == 'bar'
    assert type(tree) is Tree
    assert type(tree.get('ns')) is Tree

# Generated at 2022-06-24 03:15:59.982215
# Unit test for method __setitem__ of class Tree

# Generated at 2022-06-24 03:16:10.206779
# Unit test for function get_tree_node
def test_get_tree_node():
    print('Testing get_tree_node...')
    my_tree = tree()
    my_tree['bla']['bliep']['bliepsah'] = 'blop'
    assert get_tree_node(my_tree, 'bla:bliep:bliepsah') == 'blop'
    my_tree['bla']['bliep']['boop'] = 5
    assert get_tree_node(my_tree, 'bla:bliep:boop') == 5
    assert get_tree_node(my_tree, 'bla:bliep:boop:oops') is _sentinel
    assert get_tree_node(my_tree, 'bla:bliep:boop:oops', default='nothing here') == 'nothing here'



# Generated at 2022-06-24 03:16:13.547373
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    t['a'] = 1
    assert t.get('a') == 1
    t['a'] = 2
    assert t.get('a') == 2



# Generated at 2022-06-24 03:16:17.206135
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    _exec("""
tree = Tree()
tree['foo'] = 'bar'
assert tree['foo'] == 'bar'
""")
_exec("""
tree = Tree()
tree['foo'] = 'bar'
assert tree['foo'] == 'bar'
tree.namespace = 'baz'
tree['bar'] = 'foo'
assert tree['bar'] == 'foo'
assert tree['baz:bar'] == 'foo'
""")



# Generated at 2022-06-24 03:16:21.032927
# Unit test for function tree
def test_tree():
    d = tree()
    d[1][2][3] = 4
    d[1][2][4] = 5
    assert d[1][2][3] == 4
    assert d[1][2][4] == 5
    d[1][2][4][5] = 6
    assert d[1][2][4][5] == 6



# Generated at 2022-06-24 03:16:23.860574
# Unit test for constructor of class Tree
def test_Tree():
    node = Tree()
    node['key:one'] = 'one'
    node['key:two'] = 'two'
    result = node['key']
    assert result['one'] == 'one'
    assert result['two'] == 'two'



# Generated at 2022-06-24 03:16:26.364495
# Unit test for function set_tree_node
def test_set_tree_node():
    data = tree()
    set_tree_node(data, 'a:b:c', 'VALUE')
    assert data['a']['b']['c'] == 'VALUE'



# Generated at 2022-06-24 03:16:36.070589
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'foo': {
            'bar': {
                'baz': 42,
            },
        },
    }

    assert(get_tree_node(tree, 'foo') == {'bar': {'baz': 42}})
    assert(get_tree_node(tree, '') == tree)
    assert(get_tree_node(tree, 'foo:bar:baz') == 42)
    assert(get_tree_node(tree, 'foo:bar') == {'baz': 42})
    assert(get_tree_node(tree, 'foo:bar:baz:quux', default=None) is None)



# Generated at 2022-06-24 03:16:44.964302
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Test set_tree_node.
    """
    t = tree()
    t['test'] = {}
    t['test']['test'] = 'test'
    assert t['test']['test'] == 'test'

    t = tree()
    set_tree_node(t, 'test:test', 'test')
    assert t['test']['test'] == 'test'

    t = tree()
    set_tree_node(t, 'test:test', 'test')
    assert t['test']['test'] == 'test'

    t = tree()
    set_tree_node(t, 'test:test:test', 'test')
    set_tree_node(t, 'test:test:test:test', 'test')

# Generated at 2022-06-24 03:16:49.976353
# Unit test for constructor of class Tree
def test_Tree():
    tree = Tree({'foo': 'bar'}, namespace='global')
    assert tree.namespace == 'global'
    assert tree.get('foo') == 'bar'
    assert tree.get('global:foo') == 'bar'
    assert tree.get('global:global:foo') is None

# Generated at 2022-06-24 03:16:50.590961
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    pass



# Generated at 2022-06-24 03:16:53.365567
# Unit test for constructor of class Tree
def test_Tree():
    """Unit test for constructor of class Tree"""

    # New instance of Tree
    tree = Tree()

    # Assert default value
    assert isinstance(tree, collections.defaultdict)
    assert tree == collections.defaultdict(Tree)



# Generated at 2022-06-24 03:16:57.587873
# Unit test for constructor of class Tree
def test_Tree():
    test_a = Tree(initial={'foo': 1, 'bar': {'baz': 2}})
    assert test_a['foo'] == 1
    assert test_a['bar:baz'] == 2
    test_b = Tree(initial_is_ref=test_a, namespace='prefix')
    assert test_b['foo'] == 1
    assert test_b['bar:baz'] == 2
    assert test_b['prefix:foo'] == 1
    assert test_b['prefix:bar:baz'] == 2
    test_b['foobar'] = 3
    assert test_b['prefix:foobar'] == 3

# Generated at 2022-06-24 03:17:00.445027
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}
    set_tree_node(tree, 'foo:bar:baz', 'yay')
    assert tree == {
        'foo': {
            'bar': {
                'baz': 'yay'
            }
        }
    }



# Generated at 2022-06-24 03:17:05.632027
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    mytree = RegistryTree(initial={'test': 'example'})

    # Test that RegistryTree picks up initial value
    assert mytree['test'] == 'example'

    # Test that RegistryTree can add to itself
    mytree['test2'] = 'example2'
    assert mytree['test2'] == 'example2'

    # Test that RegistryTree picks up namespace and attempts to bind it to keys
    mytree.namespace = 'test_namespace'
    assert mytree['test'] == 'example'

# Generated at 2022-06-24 03:17:08.341943
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    registry = RegistryTree([('text', 'world')])
    assert registry['text'] == 'world'

    registry.register('foo', 'bar')
    assert registry['foo'] == 'bar'



# Generated at 2022-06-24 03:17:19.097397
# Unit test for function get_tree_node
def test_get_tree_node():
    """Unit test for function get_tree_node."""
    from nose.tools import eq_

    mapping = {
        "a": 1,
        "b": {
            "c": 3,
            "d": 4
        }
    }

    eq_(get_tree_node(mapping, 'a'), 1)
    eq_(get_tree_node(mapping, 'b:c'), 3)
    eq_(get_tree_node(mapping, 'b:d'), 4)

    eq_(get_tree_node(mapping, 'b:c', parent=True), {'c': 3, 'd': 4})
    eq_(get_tree_node(mapping, 'b:d', parent=True), {'c': 3, 'd': 4})


# Generated at 2022-06-24 03:17:21.704370
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree()
    t['foo'] = 'bar'
    assert t['foo'] == 'bar'
    t['foo'] = 'baz'
    assert t['foo'] == 'baz'


if __name__ == '__main__':
    test_Tree___getitem__()

# Generated at 2022-06-24 03:17:22.881865
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    # TODO Write unit test.
    raise NotImplementedError

# Generated at 2022-06-24 03:17:29.988282
# Unit test for function tree
def test_tree():
    assert tree() == {}
    assert tree() == tree()
    assert tree() == {}
    assert tree()['foo']['bar'] == {}

    # Test setting
    root = tree()
    root['foo']['bar'] = 'test'
    assert root == {'foo': {'bar': 'test'}}

    # Test over-writing
    root = tree()
    root['foo']['bar'] = 'test'
    assert root['foo']['bar'] == 'test'
    root['foo']['bar'] = 'test2'
    assert root['foo']['bar'] == 'test2'

    # Test over-writing via key
    root = tree()
    root['foo']['bar'] = 'test'
    assert root['foo:bar'] == 'test'

# Generated at 2022-06-24 03:17:39.242875
# Unit test for function get_tree_node
def test_get_tree_node():

    l = {
        'a': {
            'b': {
                'c': 123
            },
            'd': 456
        }
    }

    assert get_tree_node(l, 'a:b:c') == 123
    assert get_tree_node(l, 'a:b', parent=True) == {'c': 123}
    assert get_tree_node(l, ['a', 'b', 'c']) == 123
    assert get_tree_node(l, ['a', 'b'], parent=True) == {'c': 123}

    with pytest.raises(KeyError):
        get_tree_node(l, 'a:b:c:X')

    with pytest.raises(KeyError):
        get_tree_node(l, 'a:b:X')

   

# Generated at 2022-06-24 03:17:45.439827
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {'foo': {'bar': 'foobar'}}
    assert get_tree_node(tree, 'foo:bar') == 'foobar'
    assert get_tree_node(tree, 'foo:baz') == _sentinel

    with pytest.raises(AttributeError):
        get_tree_node(tree, 'foo:baz', default=_sentinel)



# Generated at 2022-06-24 03:17:48.937461
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}
    set_tree_node(tree, 'foo:bar:baz', 'spam')

# Generated at 2022-06-24 03:17:56.436397
# Unit test for function set_tree_node
def test_set_tree_node():
    import json
    import copy

    # Test case
    data = {
        "user": {
            "name": "Sam Ladd",
            "nickname": "Sam",
            "address": {
                "zip_code": "27615-8212",
                "street": "546 Dogwood Lane",
                "city": "Raleigh",
                "state": "NC",
            }
        }
    }

    # Copy data
    orig = copy.deepcopy(data)

    # Set a key
    set_tree_node(data, 'user:address:city', 'Durham')

    # Ensure the city field was updated
    assert data['user']['address']['city'] == 'Durham'

    # Ensure no other fields were modified
    assert json.dumps(data) == json.dumps(orig)



# Generated at 2022-06-24 03:18:07.164835
# Unit test for function set_tree_node
def test_set_tree_node():

    # Create a new dictnode
    testdict = dict()

    # Set "key" to "value"
    set_tree_node(testdict, 'key', 'value')

    # Check that "key" is "value"
    assert testdict['key'] == 'value'

    # Set "key:subkey" to "subvalue"
    set_tree_node(testdict, 'key:subkey', 'subvalue')

    # Check that "key" is a dict
    assert type(testdict['key']) is dict

    # Check that "key:subkey" is "subvalue"
    assert testdict['key']['subkey'] == 'subvalue'

    # Set "key:subkey" to "subvalue2"
    set_tree_node(testdict, 'key:subkey', 'subvalue2')



# Generated at 2022-06-24 03:18:18.067272
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree()
    print("Tree() =", t)
    t.update({'a':{'b':{'c':1}}})
    print("t.update({'a':{'b':{'c':1}}}) =", t)
    print("t['a:b:c'] =", t['a:b:c'])
    print("t['a:b:e'] =", t['a:b:e'])
    print("t.get('a:b:e') =", t.get('a:b:e'))
    print("t.get('a:b:e',9) =", t.get('a:b:e',9))
    print("t['a:b'] =", t['a:b'])

# Generated at 2022-06-24 03:18:22.636172
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    """Set value at arbitrary node on a tree-like mapping structure, allowing for : notation to signify dimension."""
    t = Tree()
    t['test'] = 'test'
    assert t['test'] == 'test', "'test'!='test'"
    t['test'] = 'test2'
    assert t['test'] == 'test2', "'test2'!='test2'"



# Generated at 2022-06-24 03:18:32.795747
# Unit test for constructor of class Tree

# Generated at 2022-06-24 03:18:42.490447
# Unit test for function tree
def test_tree():
    t = tree()

    t['a']['b']['c']['d']['e']['f']['g'] = "Hello"
    t['a']['b']['c']['d']['e']['f']['h'] = "World"

    assert t['a']['b']['c']['d']['e']['f']['g'] == "Hello"
    assert t['a']['b']['c']['d']['e']['f']['h'] == "World"

    assert t['a']['b']['c']['d']['e']['f']['g'] == "Hello"

# Generated at 2022-06-24 03:18:45.738486
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': 'BAR'
        }
    }
    assert get_tree_node(mapping, 'foo:bar') == 'BAR'



# Generated at 2022-06-24 03:18:50.999891
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()

    # Basic
    assert t == {}
    t['foo'] = 'bar'
    assert t == {'foo': 'bar'}

    # Multiple levels
    assert t == {}
    t['foo:bar:baz'] = 'farkle'
    assert t == {'foo': {'bar': {'baz': 'farkle'}}}
    t['foo:bar:moo'] = 'farkle'
    assert t == {'foo': {'bar': {'baz': 'farkle', 'moo': 'farkle'}}}

    # Invert
    t = Tree()
    t['quox:bar:flam'] = 'farkle'
    assert t == {'quox': {'bar': {'flam': 'farkle'}}}

# Generated at 2022-06-24 03:18:55.600486
# Unit test for function tree
def test_tree():
    # Basic tree construction
    t = tree()
    t['1']['2']['3'] = 4
    assert t['1']['2']['3'] == 4
    assert t['1']['2']['3']['4']['5']['6']['7'] == tree()



# Generated at 2022-06-24 03:18:59.003312
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    a = RegistryTree()
    b = RegistryTree()

    a.register(a)
    b.register(b)

    assert a.get('a') == a
    assert b.get('b') == b
    assert 'a' in a
    assert 'b' in b

# Generated at 2022-06-24 03:19:01.931039
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    rt = RegistryTree()
    rt.register('test', True)
    assert rt.get('test')
    assert not rt.get('test-not-true')


if __name__ == '__main__':
    sys.exit(pytest.main(['-v', __file__]))

# Generated at 2022-06-24 03:19:09.644744
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    rt = RegistryTree(namespace='ns1')
    rt.register('key1', 'value1')
    rt.register('key2', 'value2')
    rt.register('ns2:key2', 'value2')

    assert rt['ns1:key1'] == 'value1'
    assert rt['ns1']['key1'] == 'value1'
    assert rt['key1'] == 'value1'
    assert rt['ns2']['key2'] == 'value2'

# Generated at 2022-06-24 03:19:13.217068
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    registry = RegistryTree()
    registry.register('test_1', 'At test_1')
    assert registry.get('test_1') == 'At test_1'


if __name__ == '__main__':
    test_RegistryTree()

# Generated at 2022-06-24 03:19:17.966923
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()
    tree['a:b:c:d'] = 'e'
    assert tree == {'a': {'b': {'c': {'d': 'e'}}}}



# Generated at 2022-06-24 03:19:20.459089
# Unit test for function tree
def test_tree():
    # TODO Should be using https://github.com/dmnd/treelib instead
    t = tree()
    t['a', 'b', 'c'] = 42
    assert t['a']['b']['c'] == 42



# Generated at 2022-06-24 03:19:29.590465
# Unit test for function set_tree_node
def test_set_tree_node():
    """Test `set_tree_node` function."""
    from itertools import chain

    mapping = {}
    set_tree_node(mapping, 'x', 1)
    set_tree_node(mapping, 'y', 2)
    assert mapping == {'x': 1, 'y': 2}

    mapping = {}
    set_tree_node(mapping, 'x:y', 1)
    set_tree_node(mapping, 'z:y', 2)
    assert mapping == {'x': {'y': 1}, 'z': {'y': 2}}

    mapping = tree()
    set_tree_node(mapping, 'x:y', 1)
    set_tree_node(mapping, 'z:y', 2)

# Generated at 2022-06-24 03:19:31.679534
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    """Tests if RegistryTree() instantiates."""

    rt = RegistryTree()
    return rt

# Generated at 2022-06-24 03:19:35.058550
# Unit test for constructor of class Tree
def test_Tree():
    class Test(Tree):
        pass
    mytree = Test({'foo': 'bar'})
    assert mytree['foo'] == 'bar'


# Generated at 2022-06-24 03:19:38.697998
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'test': {
            'test1':
                'test2'
        }
    }
    assert get_tree_node(mapping, 'test:test1') == 'test2'



# Generated at 2022-06-24 03:19:42.836930
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = {}
    set_tree_node(mapping, 'top1', 'value1')
    assert mapping['top1'] == 'value1'

    set_tree_node(mapping, 'top1:sub1', 'subvalue')
    assert mapping['top1']['sub1'] == 'subvalue'

    set_tree_node(mapping, 'top2:sub2', 'subval2')
    assert mapping['top2']['sub2'] == 'subval2'



# Generated at 2022-06-24 03:19:45.894423
# Unit test for constructor of class Tree
def test_Tree():
    tree = Tree()

    tree['test'] = 'a'
    tree['test2'] = 'b'
    tree['thing']['one'] = 'a'



# Generated at 2022-06-24 03:19:55.452473
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    from pprint import pprint
    t = Tree()
    t.__setitem__('0:1:2:3:4:5', 'foo')
    t.__setitem__('0:1:2:3:4:6', 'bar')
    t.__setitem__('0:1:2:3:4:7', 'baz')
    t.__setitem__('0:1:2:3:4:8', 'qux')

    print(t[0][1][2][3][4])
    print('%s\n' % t[0][1][2][3])
    pprint(t)



# Generated at 2022-06-24 03:20:00.271107
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    # Declare an instance of Tree
    tree_instance = Tree()
    # Initial call to print 0
    print(tree_instance.__setitem__())
    # From here on, calls to print will output the value of N
    N = 1

    # You can start your unit tests here to check if method __setitem__ the class Tree works as expected



# Generated at 2022-06-24 03:20:08.106303
# Unit test for function tree
def test_tree():
    t = tree()
    t['a']['b']['c'] = 3
    t['a']['b']['d'] = 4
    t['x'] = 3
    assert t['a']['b']['c'] == 3
    assert get_tree_node(t, 'a:b:c') == 3
    assert get_tree_node(t, 'a:b:d') == 4
    assert get_tree_node(t, 'z', default=2) == 2
    assert t['x'] == 3
    assert set_tree_node(t, 'a:b:c', 2) == {'c': 2, 'd': 4}

    # Test parent match

# Generated at 2022-06-24 03:20:15.345466
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    import os
    import sys

    def test_generate_dict():
        d = {1: '1', 2: '2', 3: {'a': 'a', 'b': {'c': 'c'}}, 4: '4'}
        return d

    def test_get_simple(tree):
        assert tree[1] == '1'
        assert tree[2] == '2'
        assert tree[4] == '4'

    def test_get_nested(tree):
        assert tree[3:a] == 'a'
        assert tree[3:b:c] == 'c'

    def test_get_exceptions(tree):
        try:
            tree[3:doesnotexist]
        except KeyError as e:
            assert 'doesnotexist' in str(e)


# Generated at 2022-06-24 03:20:21.968821
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    d = RegistryTree()
    assert isinstance(d, dict), 'd must be dict, got %r' % d
    d.register('alpha', '1')
    d.register('beta:gamma', '2')
    assert d.get('alpha') == '1', 'alpha must be "1", got %r' % d.get('alpha')
    assert d.get('beta:gamma') == '2', 'beta:gamma must be "2", got %r' % d.get('beta:gamma')



# Generated at 2022-06-24 03:20:32.433788
# Unit test for function tree
def test_tree():
    t = Tree()
    t['foo:bar:baz'] = 1
    assert t['foo:bar:baz'] == 1
    t['bar:baz'] = 2
    assert t['bar:baz'] == 2
    t['bar:baz'] = 3
    assert t['bar:baz'] == 3
    assert t['foo:bar:baz'] == 1
    assert t.get('foo:bar:baz', None) == 1
    assert t.get('bar:baz', None) == 3
    assert t.get('bar:baz', 2) == 3
    assert t.get('baz', 2) == 2
    t['foo:bar:baz'] = 0
    assert t['foo:bar:baz'] == 0
    assert t['bar:baz'] == 3
    assert t

# Generated at 2022-06-24 03:20:34.893372
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()
    tree['a'] = 'a'
    assert tree['a'] == 'a'
    assert tree['a:a'] == {}



# Generated at 2022-06-24 03:20:43.391286
# Unit test for function get_tree_node
def test_get_tree_node():
    m = {'a': {'b': {'c': 1, 'd': 2}}, 'b': 2}
    assert get_tree_node(m, 'a:b:c') == 1
    assert get_tree_node(m, 'b', default='foo') == 2
    assert get_tree_node(m, 'a:foo', default='bar') == 'bar'
    assert get_tree_node(m, 'a:b:c', parent=True) == {'c': 1, 'd': 2}
    try:
        get_tree_node(m, 'b:a')
    except KeyError:
        pass
    else:
        assert False, 'should have raised KeyError'



# Generated at 2022-06-24 03:20:54.582587
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree({'a': 1, 'b': 2}, 'ns')
    t['d'] = 4
    assert t['a:b'] == 2
    t[':c'] = 45
    assert t['c'] == 45
    assert t['a:b:c'] == 45
    assert t['x'] == Tree()
    assert t.namespace == 'ns'
    t2 = Tree(t)
    assert t2['a:b'] == 2
    t3 = Tree(t, initial_is_ref=True)
    t3['p'] = 4
    assert t3['p'] == 4
    assert t['p'] is None
    assert t2['p'] is None
    t3.register('x', 1)
    assert t3['x'] == 1
    t3.register('x:z', 3)

# Generated at 2022-06-24 03:21:01.101342
# Unit test for function tree
def test_tree():
    """
    Test the `tree` function.
    """
    simple = tree()
    simple['a'] = 1
    simple['b'] = 2
    simple['c']['d'] = 3
    simple['c']['e'] = 4
    assert simple['a'] == 1
    assert simple['b'] == 2
    assert simple['c']['d'] == 3
    assert simple['c']['e'] == 4


if __name__ == '__main__':
    test_tree()

# Generated at 2022-06-24 03:21:09.399033
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'a': {'b': 'foo'}}, 'a:b') == 'foo'
    assert get_tree_node({'a': {'b': 'foo'}}, 'a:b:c', default=0) == 0
    assert get_tree_node({'a': {'b': 'foo'}}, 'a:b:c', default=0) == 0
    assert get_tree_node({'a': {'b': 'foo'}}, 'a:b:c', parent=True) == {'b': 'foo'}



# Generated at 2022-06-24 03:21:19.348741
# Unit test for function tree
def test_tree():
    t = tree()
    t['1']['2']['3'] = 'a'
    t['a']['b']['c']['d'] = 'b'
    assert t['1']['2']['3'] == 'a'
    assert t['a']['b']['c']['d'] == 'b'
    assert t['1:2:3'] == 'a'
    assert t['a:b:c:d'] == 'b'
    assert t['1:2'] == collections.defaultdict(tree, {'3': 'a'})
    assert t['1'] == collections.defaultdict(tree, {'2': collections.defaultdict(tree, {'3': 'a'})})

# Generated at 2022-06-24 03:21:24.473762
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': 'baz'
        }
    }
    value = get_tree_node(mapping, 'foo:bar')
    assert value == 'baz'

    # Test if KeyError is raised correctly
    try:
        get_tree_node(mapping, 'foo:bar:baz')
        raise AssertionError('Did not raise KeyError on bad lookup')
    except KeyError:
        pass

    value = get_tree_node(mapping, 'foo:bar:baz', default='bork')
    assert value == 'bork'



# Generated at 2022-06-24 03:21:30.926222
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    """
    This test will check, that given `key` and `value`, __getitem__ will return value
    """
    from copy import deepcopy

    valid_data = {'foo': {'bar': 'baz'}, 'bar': {'foo': 1},
                  'foobar': {'foo': 1, 'bar': 'baz', 'foobar': {'foo': 'bar'}}}
    for valid_key, valid_value in deepcopy(valid_data).items():
        t = Tree(initial=valid_data)
        assert t.get(valid_key) == valid_data[valid_key]

    invalid_data = {'foo': 'bar'}
    t = Tree(initial=invalid_data)

# Generated at 2022-06-24 03:21:40.321762
# Unit test for function get_tree_node
def test_get_tree_node():
    """Create simple tree-like structure and use get_tree_node to fetch various paths."""
    a = {
        'test': {
            'test2': {
                'test3': 'foo'
            },
            'nope': {
                'test3': 'bar'
            }
        }
    }

    # Should be 'foo'
    assert get_tree_node(a, 'test:test2:test3') == 'foo'

    # Should be 'bar'
    assert get_tree_node(a, 'test:nope:test3') == 'bar'

    # Should not raise an error
    assert get_tree_node(a, 'test:nope:test3', default='wat') == 'bar'

    # Should raise an error because we do not have a default and node does not exist.

# Generated at 2022-06-24 03:21:43.747118
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    t['a'] = 1
    assert t['a'] == 1



# Generated at 2022-06-24 03:21:53.001731
# Unit test for function tree
def test_tree():

    d = tree()
    d["John"]["Doe"]["Age"] = 27
    d["John"]["Doe"]["Job"] = "Programmer"
    d["Jane"]["Doe"]["Age"] = 17
    d["Jane"]["Doe"]["Job"] = "Student"

    assert d["John"]["Doe"]["Age"] == 27
    assert d["John"]["Doe"]["Job"] == "Programmer"
    assert d["Jane"]["Doe"]["Job"] == "Student"

    # Optional namespaces for the lazy
    n = tree(namespace='namespace')
    n["foo"] = "bar"
    assert n["foo"] == "bar"



# Generated at 2022-06-24 03:21:57.259213
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    properties = {'a': {'b': 1}}
    tree = Tree(initial=properties)

    assert tree['a'] == {'b': 1}
    assert tree['a:b'] == 1
    assert tree.get('a:b') == 1



# Generated at 2022-06-24 03:22:03.218824
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    >>> test_set_tree_node()
    """
    test_data = tree()
    set_tree_node(test_data, 'test:value', True)
    assert test_data['test']['value'] is True
    # Note: This behavior is undefined and may change in the future.
    set_tree_node(test_data, 'test:value', 'bar')
    assert test_data['test']['value'] == 'bar'



# Generated at 2022-06-24 03:22:09.365478
# Unit test for function get_tree_node
def test_get_tree_node():
    d = {'a': {1: 2, 2: 4}, 'b': 4}
    assert get_tree_node(d, 'a:1') == 2
    assert get_tree_node(d, 'a:2') == 4
    assert get_tree_node(d, 'b') == 4
    assert get_tree_node(d, 'c') is None
    assert get_tree_node(d, 'c', default=False) is False
    assert get_tree_node(d, 'c', default=Exception) is Exception



# Generated at 2022-06-24 03:22:15.829214
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'b': {
                'c': 10,
            },
        },
    }
    assert get_tree_node(mapping, 'a:b:c') == 10
    assert get_tree_node(mapping, 'a:b', default=20) == {'c': 10}
    assert get_tree_node(mapping, 'a:b:nop', default=20) == 20
    assert get_tree_node(mapping, 'a:b:nop') == get_tree_node(mapping, 'a:b:nop', default=_sentinel)



# Generated at 2022-06-24 03:22:21.331153
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    rt = RegistryTree()
    assert rt._namespace_key('test') == 'test'
    rt = RegistryTree(namespace='foo')
    assert rt._namespace_key('test') == 'foo:test'
    rt = RegistryTree(namespace='foo', initial_is_ref=rt)
    assert rt._namespace_key('test') == 'foo:test'
    rt = RegistryTree(initial={'bar': 'baz'})
    assert rt['bar'] == 'baz'
    data = {}
    rt = RegistryTree(initial_is_ref=data)
    rt['bar'] = 'baz'
    assert 'bar' in data



# Generated at 2022-06-24 03:22:31.854102
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = tree()
    set_tree_node(mapping, 'foo:bar:baz:buz', 'baz')
    mapping = dict(mapping)
    assert get_tree_node(mapping, 'foo:bar:baz:buz') == 'baz'
    assert get_tree_node(mapping, 'foo:bar:baz:buz', default=None) == 'baz'
    assert get_tree_node(mapping, 'foo:bar:baz:buz', default=None, parent=True) == {'buz': 'baz'}
    assert get_tree_node(mapping, 'foo:bar:baz:buz2') is _sentinel


# Generated at 2022-06-24 03:22:38.860988
# Unit test for function tree
def test_tree():
    tree_ = tree()
    tree_['a']['b'] = 1
    tree_['a']['c'] = 2
    tree_['a']['d'] = [1, 2]
    tree_['a']['e'] = {'a': 'b'}
    tree_['a']['e']['c'] = 'd'



# Generated at 2022-06-24 03:22:42.694477
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree(namespace='test')
    t['a'] = 'b'
    assert t['a'] == 'b'
    assert t['a'] == t.get('a')
    assert t['a'] == t.get('test:a')



# Generated at 2022-06-24 03:22:52.615901
# Unit test for constructor of class Tree
def test_Tree():
    from io import StringIO

    # with open('tree_test.json', 'r') as test_file:
    #     test_string = test_file.read()

    test_string = """{
    "leaf": "a leaf",
    "child": {
        "leaf": "something"
    },
    "something:weird": "with a colon"
}"""
    t = Tree(json.loads(test_string))
    assert t['something:weird'] == 'with a colon'

# Generated at 2022-06-24 03:22:55.029709
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    """Test that RegistryTree can be instantiated."""
    tree = RegistryTree()
    assert isinstance(tree, Tree)
    assert isinstance(tree, RegistryTree)

# Generated at 2022-06-24 03:22:58.796627
# Unit test for constructor of class RegistryTree
def test_RegistryTree():  # pragma: no cover
    from pprint import pprint
    tree = RegistryTree()

    tree.register('foo', 'bar')
    tree.register('foo:bar:baz', 'quux')
    tree.register('qux', 'quux')

    pprint(tree)



# Generated at 2022-06-24 03:23:09.632021
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    from unittest import TestCase

    class TestTree___getitem__(TestCase):

        def test_nested(self):
            d = Tree({
                'a': {
                    'b': {
                        'c': {
                            'd': 'test'
                        }
                    }
                }
            })

            self.assertEqual(d['a:b:c:d'], 'test')

        def test_missing(self):
            d = Tree({
                'a': {
                    'b': {
                        'c': {
                            'e': 'test'
                        }
                    }
                }
            })

            with self.assertRaises(KeyError):
                self.assertEqual(d['a:b:c:d'], _sentinel)

        def test_default(self):
            d

# Generated at 2022-06-24 03:23:17.331345
# Unit test for function set_tree_node
def test_set_tree_node():
    simple_dict = {
        'foo': 'bar',
        'baz': {
            'spam': 'eggs',
            'ham': {
                'one': 'two',
            }
        }
    }

    set_tree_node(simple_dict, 'baz:ham:one', 'three')
    assert simple_dict == {
        'foo': 'bar',
        'baz': {
            'spam': 'eggs',
            'ham': {
                'one': 'three',
            }
        }
    }

    set_tree_node(simple_dict, 'baz:ham:two', 'four')

# Generated at 2022-06-24 03:23:19.954288
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()
    tree['test'] = 'value'
    assert tree['test'] == 'value'

# Generated at 2022-06-24 03:23:28.092115
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree(initial={'a': {'b': 2}}, namespace='root')
    t['c'] = ['d']
    assert t == {'a': {'b': 2}, 'c': ['d']}
    assert t['a'] == {'b': 2}
    assert t['a']['b'] == 2
    assert t['c'] == ['d']
    assert t['c'][0] == 'd'
    assert t['root:a'] == {'b': 2}
    assert t['root:a']['b'] == 2
    assert t['root:c'] == ['d']
    assert t['root:c'][0] == 'd'
    assert t.namespace == 'root'



# Generated at 2022-06-24 03:23:35.797894
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree = Tree()
    tree['one']['two']['three']['four']['five'] = 'five'
    assert tree['one:two']['three:four:five'] == 'five'
    tree._namespace = 't'
    assert tree.get('one:two:three:four:five') == None
    assert tree.get('one:two:three:four:five', default='default') == 'default'
    assert tree['t:one:two:three:four:five'] == 'five'

# Generated at 2022-06-24 03:23:39.036268
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    rt = RegistryTree()

    # Make sure the constructor creates an empty dict
    assert len(rt) == 0

    # Make sure we register item on init
    rt = RegistryTree({'foo': 'bar'})
    assert len(rt) == 1

# Generated at 2022-06-24 03:23:42.413526
# Unit test for constructor of class Tree
def test_Tree():
    # Create tree, deep-copy it, then do a double-level deep comparison to ensure it's exactly the same.
    tree = Tree({'a': {'b': {'c': 3}}}).copy()
    assert(tree == {'a': {'b': {'c': 3}}})

# Generated at 2022-06-24 03:23:52.377985
# Unit test for function get_tree_node
def test_get_tree_node():

    tree = {
        'a': {
            'b': {
                'c': {
                    'd': {
                        'e': {
                            'f': 'value'
                        }
                    }
                }
            }
        }
    }
    value = get_tree_node(tree, 'a:b:c:d:e:f')
    assert value == 'value'
    default = get_tree_node(tree, 'a:nothing:here', default="default")
    assert default == "default"
    with pytest.raises(KeyError):
        get_tree_node(tree, 'a:nothing:here')
    parent = get_tree_node(tree, 'a:b:c:d:e:f', parent=True)
    assert parent == {'f': 'value'}

# Generated at 2022-06-24 03:23:59.315895
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}
    set_tree_node(tree, 'a', 'x')
    assert tree == {'a': 'x'}

    tree = {}
    set_tree_node(tree, 'a:b:c', 'x')
    assert tree == {'a': {'b': {'c': 'x'}}}

    tree = {}
    set_tree_node(tree, 'a:b:c:d:e:f', 'x')
    assert tree == {'a': {'b': {'c': {'d': {'e': {'f': 'x'}}}}}}



# Generated at 2022-06-24 03:24:07.232138
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    tree = RegistryTree()
    tree['app'] = 'admin'
    tree['app:site_id'] = '1'
    tree['app:site_id2'] = '2'
    tree['foo'] = 'bar'
    assert tree['app'] == 'admin', 'top level register'
    assert tree['app:site_id'] == '1', 'second level register'
    assert tree['foo'] == 'bar', 'top level normal lookup'
    assert tree['app:site_id2'] == '2', 'second level normal lookup'
    try:
        assert tree['app:site_id:nonexistant'] is KeyError, 'non-existant node lookup'
    except KeyError:
        pass



# Generated at 2022-06-24 03:24:10.768098
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = tree()
    assert set_tree_node(mapping, 'first:second:third:fourth', 'test') == {'fourth': 'test'}
    assert mapping['first']['second']['third'] == {'fourth': 'test'}