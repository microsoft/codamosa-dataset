

# Generated at 2022-06-24 03:14:10.558079
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()
    tree['hue'] = 'huehue'
    assert tree['hue'] == 'huehue'



# Generated at 2022-06-24 03:14:21.892281
# Unit test for constructor of class Tree
def test_Tree():
    import collections
    c = collections.Counter()
    c.update([1, 2, 2, 2, 2, 3, 4, 5, 6, 6, 7, 8, 9, 1, 2, 3, 4, 5, 6, 7, 8])
    c.update([1, 2, 2, 2, 2, 3, 4, 5, 6, 6, 7, 8, 9, 1, 2, 3, 4, 5, 6, 7, 8])
    c.update([1, 2, 2, 2, 2, 3, 4, 5, 6, 6, 7, 8, 9, 1, 2, 3, 4, 5, 6, 7, 8])

# Generated at 2022-06-24 03:14:30.362854
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    t.__setitem__('a','b')
    assert t.__getitem__('a') == 'b'
    t.__setitem__('a:b:c','d')
    assert t.__getitem__('a:b:c') == 'd'
    t.__setitem__('a:c:d','e')
    assert t.__getitem__('a:c:d') == 'e'
    assert t.get('a:c:d') == 'e'
    assert t.get('a:c:d:e') == None

# Generated at 2022-06-24 03:14:40.583867
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree(namespace='arbitrary')
    assert isinstance(t, Tree)
    assert isinstance(t, collections.defaultdict)
    assert isinstance(t, collections.MutableMapping)
    assert t.namespace == 'arbitrary'
    assert t.data == {}
    t = Tree(initial={'foo': 'bar'})
    assert t.data == {'foo': 'bar'}
    assert repr(t) in ('Tree({}, namespace=None)', 'Tree({})')
    assert 'Tree([])' in repr(Tree())  # This is fucked up, but I'm more worried about the other tests for now...
    assert 'Tree({})' in repr(Tree({'a': 'b'}))
    assert t.data == {'a': 'b'}



# Generated at 2022-06-24 03:14:47.177493
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    r = Tree()
    r.update({'a': {'b': 1}})
    assert r['a'] == {'b': 1}
    assert r['a:b'] == 1
    assert r['b'] == {}
    assert r['b:b'] == {}
    r['b'] = 2
    assert r['b'] == 2
    assert r['b:b'] == {}
    r['c:d'] = 3
    assert r['c:d'] == 3
    assert r['c'] == {'d': 3}
    r['c:e'] = {'f': 4}
    assert r['c:e:f'] == 4
    assert r['c:e'] == {'f': 4}
    assert r['c'] == {'d': 3, 'e': {'f': 4}}
    r

# Generated at 2022-06-24 03:14:52.425337
# Unit test for function tree
def test_tree():
    """Test tree function and Tree class"""
    # Simple recursive tree
    t1 = tree()
    t1[1][1][1] = 1
    t1[1][2][2] = 2
    t1[2][2][2] = 2

    # Hierarchy of Tree objects
    t2 = tree()
    t2[1] = Tree()
    t2[1][2] = Tree()
    t2[1][2][3] = 3
    t2[2] = Tree()
    t2[2][4] = Tree()
    t2[2][4][5] = 5

    # Ensure t1 and t2 are the same
    assert t1 == t2

# Generated at 2022-06-24 03:14:53.739304
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree(namespace='root')
    assert t.namespace == 'root'



# Generated at 2022-06-24 03:14:58.963622
# Unit test for function set_tree_node
def test_set_tree_node():
    test_dict = {}
    set_tree_node(test_dict, 'muh:key', 'Fuck!')
    assert test_dict['muh']['key'] == 'Fuck!'



# Generated at 2022-06-24 03:15:02.866686
# Unit test for function tree
def test_tree():
    t = tree()
    t['a']['b']['c']['d'] = 'wut'
    print(t)
    print(t['a']['b']['c']['d'])



# Generated at 2022-06-24 03:15:06.525559
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree = Tree()
    tree.register(('foo:bar', 'yay'))
    assert tree.get('foo:bar') == 'yay'

# Generated at 2022-06-24 03:15:10.728446
# Unit test for function set_tree_node
def test_set_tree_node():
    test_item = tree()
    test_item = set_tree_node(test_item, 'root', 1)
    test_item = set_tree_node(test_item, 'root:a:b:c', 10)
    assert test_item['root']['a']['b']['c'] == 10



# Generated at 2022-06-24 03:15:16.538326
# Unit test for function set_tree_node
def test_set_tree_node():
    from ..types.tests import TreeNode

    base_mapping = TreeNode('root', {})
    base_mapping.aux.a = 'ho'
    base_mapping.aux.b = 'ho'
    base_mapping.aux.c = 'ho'
    base_mapping.aux.d = 'ho'
    base_mapping.aux.f = 'ho'
    base_mapping.aux.g = 'ho'
    base_mapping.aux.h = TreeNode('h', {})
    base_mapping.aux.h.aux.i = 'ho'
    base_mapping.aux.h.aux.j = 'ho'
    base_mapping.aux.h.aux.k = 'ho'
    base_mapping.aux.h.aux.l = 'ho'
   

# Generated at 2022-06-24 03:15:25.145169
# Unit test for constructor of class Tree
def test_Tree():
    test = Tree
    tree = Tree()
    assert tree is not None
    tree['foo'] = 'bar'
    assert tree['foo'] == 'bar'
    tree['bar:baz'] = 'foobar'
    assert tree['bar:baz'] == 'foobar'
    tree['bar:foobaz:baz'] = 'foobar'
    assert tree['bar:foobaz:baz'] == 'foobar'
    test['from:list'] = ['a', 'b', 'c']
    assert test['from:list'] == ['a', 'b', 'c']
    return tree


if __name__ == '__main__':
    print("test_Tree() = ", test_Tree())

# Generated at 2022-06-24 03:15:33.675385
# Unit test for function tree
def test_tree():
    t = tree()
    assert t is t['foo']['bar']['baz']
    assert t['foo']['bar']['baz'] == {}
    assert t['foo']['bar']['qux'] == {}
    assert t['foo']['bar']['qux'] is t['foo']['bar']['qux']
    assert t['foo']['bar']['ban']['boo'] == {}
    assert t['foo']['bar']['ban']['boo'] is t['foo']['bar']['ban']['boo']
    assert t['bla'] == {}
    assert t['bla'] is t['bla']

# Generated at 2022-06-24 03:15:37.356053
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    a = RegistryTree(namespace="a")
    a.register("b", "c")

# Generated at 2022-06-24 03:15:43.542375
# Unit test for function set_tree_node
def test_set_tree_node():
    D = {}
    D['a:b:c'] = 'hello'
    D['a:b:d'] = 'goodbye'
    D['a:e:f'] = 'meh'
    assert D['a:b:c'] == 'hello'
    assert D['a:b:d'] == 'goodbye'
    assert D['a:e:f'] == 'meh'
    assert D.get('a:b') is None
    assert len(D['a:b:c']) == 5



# Generated at 2022-06-24 03:15:45.011216
# Unit test for function tree
def test_tree():
    t = tree()
    t['a']['b']
    return t == {'a': {'b': {}}}



# Generated at 2022-06-24 03:15:55.992808
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree()
    t[1] = 1
    t[2]['2'] = '2'
    t[2]['3']['1'] = '3'
    t['3'] = '3'
    t[3][3] = 3
    t[3][3][3] = 3

# Generated at 2022-06-24 03:16:01.329352
# Unit test for function set_tree_node
def test_set_tree_node():
    """Unit test for function :func:~netpalm.utilities.nplib.registries.set_tree_node."""
    test_dict = {}
    set_tree_node(test_dict, 'one:two:three', 'foobar')
    assert test_dict == {'one': {'two': {'three': 'foobar'}}}



# Generated at 2022-06-24 03:16:06.475264
# Unit test for function set_tree_node
def test_set_tree_node():
    t = tree()
    set_tree_node(t, 'a:b:c', 'test')
    assert t['a']['b']['c'] == 'test'

    t = {}
    set_tree_node(t, 'a:b:c', 'test')
    assert t['a']['b']['c'] == 'test'



# Generated at 2022-06-24 03:16:07.712831
# Unit test for function set_tree_node
def test_set_tree_node():
    store = tree()
    set_tree_node(store, 'one:two:three:four', 5)
    set_tree_node(store, 'foo:bar:baz', 'quux')



# Generated at 2022-06-24 03:16:13.521394
# Unit test for constructor of class Tree
def test_Tree():
    config = {'foo': {'bar': 'baz'}, 'baz': 'foo'}
    t = Tree(config)
    assert t.foo.bar == 'baz'
    assert t['foo:bar'] == 'baz'
    assert t['baz'] == 'foo'
    assert t['baz:bar'] == Tree()
    t.foo.bar = 'boo'
    assert t.foo.bar == 'boo'
    assert t['foo:bar'] == 'boo'



# Generated at 2022-06-24 03:16:18.422487
# Unit test for function tree
def test_tree():
    t = tree()
    assert t == {}
    t['foo']['bar'] = 42
    assert t == {'foo': {'bar': 42}}
    t['foo']['bar'] = 10
    assert t == {'foo': {'bar': 10}}
    t['foo']['baz'] = 20
    assert t == {'foo': {'bar': 10, 'baz': 20}}

# Generated at 2022-06-24 03:16:20.174180
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    a = Tree({'a': {'b': 1}})
    assert a['a:b'] == 1



# Generated at 2022-06-24 03:16:22.491859
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()

    # TODO Not implemented, but must __setitem__ pass?
    raise NotImplementedError('Test not implemented; please do so!')


test_Tree___setitem__.unittest = ['.tree']



# Generated at 2022-06-24 03:16:27.621767
# Unit test for function set_tree_node
def test_set_tree_node():
    d = tree()

    # set_tree_node(d, 'one:two:three', 'FOUR')
    #
    # assert d['one']['two']['three'] == 'FOUR'
    #
    # d = tree()
    # set_tree_node(d, 'one:two:three', 'FOUR')
    #
    # assert d['one:two:three'] == 'FOUR'

    d = tree()
    set_tree_node(d, key='one:two:three:four:five:six:seven', value='FOUR')
    assert 'FOUR' == d['one']['two']['three']['four']['five']['six']['seven']

    d = tree()

# Generated at 2022-06-24 03:16:32.505852
# Unit test for function set_tree_node
def test_set_tree_node():
    """Unit test for function set_tree_node"""
    tree = {}
    set_tree_node(tree, 'a:b:c:d:e:f:g', 'test')
    assert tree['a']['b']['c']['d']['e']['f']['g'] == 'test'



# Generated at 2022-06-24 03:16:40.948148
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = {}
    set_tree_node(mapping, 'first:second:third', 42)
    assert mapping == {'first': {'second': {'third': 42}}}
    set_tree_node(mapping, 'first:second:forth', 22)
    assert mapping == {'first': {'second': {'third': 42, 'forth': 22}}}
    set_tree_node(mapping, 'first:fifth', 17)
    assert mapping == {'first': {'second': {'third': 42, 'forth': 22}, 'fifth': 17}}



# Generated at 2022-06-24 03:16:46.192011
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree()
    expected = 'bar'
    t['foo'] = expected
    assert t['foo'] == expected
    assert t.get('foo') == expected



# Generated at 2022-06-24 03:16:50.950512
# Unit test for constructor of class Tree
def test_Tree():
    d = Tree({'a': 1, 'b': 2})
    assert d['b'] == 2
    assert d['a'] == 1
    d.register('b:c:d:e', 1)

    # TODO Check for namespace?



# Generated at 2022-06-24 03:17:01.312776
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Unit test for function set_tree_node
    """
    sample_dict = {'a': {'x': {'y': 1}}}
    assert set_tree_node(sample_dict, 'a:z', {}) is sample_dict['a']
    assert sample_dict == {'a': {'x': {'y': 1}, 'z': {}}}

    sample_dict = {'a': {'x': {'y': 1}}}
    assert set_tree_node(sample_dict, 'b:x:y', {}) is sample_dict['b']
    assert sample_dict == {'a': {'x': {'y': 1}}, 'b': {'x': {'y': {}}}}

    sample_dict = {'a': {'x': {'y': 1}}}
    assert set_

# Generated at 2022-06-24 03:17:03.331307
# Unit test for function tree
def test_tree():
    tree = tree()
    tree['lol']['wat']['nice'] = {'am': 'I'}
    print(tree)



# Generated at 2022-06-24 03:17:05.780635
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree()

    t[1][2] = "4"
    assert t[1][2] == '4'



# Generated at 2022-06-24 03:17:08.497331
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    import config
    t = Tree(initial=config.test_config)
    print(t.get('test:a'))
    import pdb
    pdb.set_trace()
    pass

# Generated at 2022-06-24 03:17:19.243496
# Unit test for function tree
def test_tree():
    t = Tree()
    t.update({
        'level': 'level',
        'level:one': 'one',
        'level:two': 'two',
        'level:one:foo': 'foo',
        'level:one:bar': 'bar'
    })
    assert t['level']['one']['foo'] == 'foo'
    assert t['level:one:foo'] == 'foo'
    assert t['level:one:baz'] is None
    assert t['level:one:baz'] is None
    assert t['level']['one']['baz'] is None

    # Set
    t['level']['one']['baz'] = 'baz'
    assert t['level:one:baz'] == 'baz'

# Generated at 2022-06-24 03:17:22.321567
# Unit test for function get_tree_node
def test_get_tree_node():
    my_tree = {
        'foo': {
            'bar': 'baz'
        }
    }
    assert get_tree_node(my_tree, 'foo:bar') == 'baz'
    print('test_get_tree_node() passed.')



# Generated at 2022-06-24 03:17:31.359477
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    r = RegistryTree()

    # Test registration of value
    r.register('foo')
    assert r.get() == 'foo'

    # Test registration of dict
    r.register({'hello': 'world'})
    assert r.get('hello') == 'world'

    # Test registration of list
    r.register(['hello', 'world'])
    assert r['0'] == 'hello'
    assert r[0] == 'hello'

    # Test registration of 1-D list (which is also valid)
    r.register(['hello', 'world'])
    assert r['0'] == 'hello'
    assert r[0] == 'hello'

# Generated at 2022-06-24 03:17:38.016266
# Unit test for function tree
def test_tree():
    tree = Tree()

    # Set
    tree['foo']['bar']['baz'] = 'Foobarbaz'
    tree['foo']['bar']['qux'] = 'Quux'

    # Get
    assert tree['foo']['bar']['baz'] == 'Foobarbaz'
    assert tree['foo']['bar']['qux'] == 'Quux'

    # Test overwrite existing key
    tree['foo']['bar']['qux'] = 'Corge'
    assert tree['foo']['bar']['qux'] == 'Corge'

    # Test delving down into dimensions
    tree['foo:bar:qux'] = 'Grault'
    assert tree['foo:bar:qux'] == 'Grault'

    # Test default

# Generated at 2022-06-24 03:17:44.309200
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    """
    Test RegistryTree class as a sanity check, as well as an example.
    """
    test_tree = RegistryTree()
    test_tree.register('foo', 'baz')
    assert test_tree.get('foo') == 'baz'
    assert test_tree.get('bar', default='bam') == 'bam'
    str(test_tree)  # Don't crash.



# Generated at 2022-06-24 03:17:51.085992
# Unit test for function get_tree_node
def test_get_tree_node():
    a = {
        'foo': {
            'bar': 'baz',
        }
    }
    assert get_tree_node(a, 'foo:bar') == 'baz'

    # Test default value
    assert get_tree_node(a, 'funk:bar', default=42) == 42

    # Test parent node correctly returned
    assert get_tree_node(a, 'foo:bar', parent=True) == {'bar': 'baz'}

    # Key should not be found
    with pytest.raises(KeyError):
        get_tree_node(a, 'funk:bar')



# Generated at 2022-06-24 03:17:54.480415
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()
    # test_Tree.__setitem__
    assert(tree['some_key'] == None)



# Generated at 2022-06-24 03:17:56.118368
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    r = RegistryTree(namespace='test')
    assert r.namespace == 'test', "Namespace is not set by constructor"



# Generated at 2022-06-24 03:17:57.372493
# Unit test for function set_tree_node
def test_set_tree_node():
    base = {}
    set_tree_node(base, 'foo', 1)
    assert base['foo'] == 1



# Generated at 2022-06-24 03:18:03.871992
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = {}
    key = 'a:b:c:d'
    result = set_tree_node(mapping, key, 'x')
    assert result == {'c': {'d': 'x'}}
    assert mapping == {'a': {'b': {'c': {'d': 'x'}}}}



# Generated at 2022-06-24 03:18:04.559756
# Unit test for constructor of class Tree
def test_Tree():
    registry = Tree()


# Generated at 2022-06-24 03:18:09.763323
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    import pytest
    t = Tree()
    # Empty namespace
    t['x'] = 'foo'
    assert t['x'] == 'foo'
    # With namespace
    t.namespace = 'root'
    t['y'] = 'bar'
    assert t['y'] == 'bar'
    assert t.data['root']['x'] == 'foo'
    assert t['root:y'] == 'bar'
    t.register('root', 'z', 'baz')
    assert t['root:z'] == 'baz'
    with pytest.raises(Exception):
        t.data['root']['z'] = 'baz'
    with pytest.raises(Exception):
        t.get('root:x')

# Generated at 2022-06-24 03:18:16.105496
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree({'a': 1, 'b:c:d': 2, 'b:e': 3}, 'x')
    assert t['a'] == 1
    assert t['b']['c']['d'] == 2
    assert t['x:b']['e'] == 3


if __name__ == '__main__':
    t = Tree({'a': 1, 'b:c:d': 2, 'b:e': 3}, 'x')

# Generated at 2022-06-24 03:18:18.285839
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    def foo():
        pass

    tree = RegistryTree()
    tree.register('foo', foo)
    assert tree['foo'] == foo



# Generated at 2022-06-24 03:18:22.026021
# Unit test for constructor of class Tree
def test_Tree():
    """Set and fetch keys in Tree with and without key prefix."""
    t = Tree()
    t.register('a', 'A')
    t.register('b', 'B', namespace='bar')
    assert t['a'] == 'A'
    assert t['bar:b'] == 'B'



# Generated at 2022-06-24 03:18:30.030596
# Unit test for function set_tree_node
def test_set_tree_node():
    data = tree()
    set_tree_node(data, 'foo', 'bar')

    set_tree_node(data, 'foo:bar:baz', 1)
    try:
        set_tree_node(data, 'foo:bar:baz', 2)
    except KeyError:
        pass
    assert data['foo']['bar']['baz'] == 1

    set_tree_node(data, 'foo:bar:baz:quux', 2)
    assert data['foo']['bar']['baz']['quux'] == 2



# Generated at 2022-06-24 03:18:35.440446
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree({'foo': {'bar': {'baz': 'quux'}}})
    assert t['foo']['bar']['baz'] == 'quux'
    assert t['quux'] == None
    assert t['foo']['bar']['baz'] == 'quux'
    assert t.get('foo:bar:baz') == 'quux'
    t.namespace = 'fizz'
    assert t.get('bar:baz') == 'quux'

# Generated at 2022-06-24 03:18:44.916420
# Unit test for function get_tree_node
def test_get_tree_node():
    class Object(object):
        pass
    mapping = {
        'foo': {
            'bar': Object(),
        }
    }
    node = get_tree_node(mapping, 'foo:bar')
    assert isinstance(node, Object)
    node = get_tree_node(mapping, 'foo')
    assert isinstance(node, dict)
    node = get_tree_node(mapping, 'nope', default='HAI')
    assert node == 'HAI'
    node = get_tree_node(mapping, 'foo:wut', default='HAI')
    assert node == 'HAI'
    node = get_tree_node(mapping, 'foo:wut', default='HAI')
    assert node == 'HAI'
    mapping = {'foo': [0, 1]}
   

# Generated at 2022-06-24 03:18:54.467910
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    def get_tree_node(mapping, key, default=_sentinel, parent=False):
        key = key.split(':')
        if parent:
            key = key[:-1]
            
        node = mapping
        for node in key:
            try:
                node = node[node]
            except KeyError as exc:
                node = default
                break
                
        if node is _sentinel:
            raise exc
        return node
    
    def set_tree_node(mapping, key, value):
        basename, dirname = key.rsplit(':', 1)
        parent_node = get_tree_node(mapping, dirname)
        parent_node[basename] = value
        return parent_node
    
    def tree():
        return collections.defaultdict(tree)
    


# Generated at 2022-06-24 03:18:59.328296
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    """Basic unit test for RegistryTree class"""
    foo = RegistryTree()
    foo.register('foo', object)
    foo.register('bar:baz', object)

# Generated at 2022-06-24 03:19:00.912805
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    my_tree = Tree()
    my_tree['a'] = 'b'
    assert my_tree['a'] == 'b'



# Generated at 2022-06-24 03:19:08.839588
# Unit test for function get_tree_node
def test_get_tree_node():
    foo = {
        'bar': {
            'baz': {
                'egg': 'spam',
            }
        }
    }
    assert get_tree_node(foo, '', default=False) is False
    assert get_tree_node(foo, 'bar', default=False) is foo['bar']
    assert get_tree_node(foo, 'baz:blah', default='spam') == 'spam'
    assert get_tree_node(foo, 'bar:baz:egg') == 'spam'


# Generated at 2022-06-24 03:19:11.431624
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    tree = RegistryTree(namespace='foo')
    tree.register('bar', 'baz')
    assert tree.get('foo:bar') == 'baz'



# Generated at 2022-06-24 03:19:17.430016
# Unit test for function tree
def test_tree():
    a = tree()
    a['a']['b']['c'] = 1
    a['b']['a']['a'] = 2
    a['b']['a']['b'] = 3
    assert a['a']['b']['c'] == 1
    assert a['b']['a']['a'] == 2
    assert a['b']['a']['b'] == 3



# Generated at 2022-06-24 03:19:24.917702
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Test ``set_tree_node()`` and ``get_tree_node()``,
    along with ``del_tree_node()`` and ``has_tree_node()``
    """
    mapping = tree()
    set_tree_node(mapping, 'test:my:key', 'my_value')
    assert mapping['test']['my']['key'] == 'my_value'

    del_tree_node(mapping, 'test:my')
    assert 'my' not in mapping['test']

    set_tree_node(mapping, 'test:my:key', 'my_value')
    assert has_tree_node(mapping, 'test:my:key')



# Generated at 2022-06-24 03:19:30.762648
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Unit tests for function `get_tree_node`
    """
    import pytest

    fixture = {'key1': 123,
               'key2': {'foo': 'bar',
                        'fizz': 'buzz'},
               'key3': [1, 2, 3]}

    # Test normal functionality
    assert get_tree_node(fixture, 'key1') == 123
    assert get_tree_node(fixture, 'key2:foo') == 'bar'
    assert get_tree_node(fixture, 'key2:fizz') == 'buzz'
    assert get_tree_node(fixture, 'key3:1') == 2
    assert get_tree_node(fixture, 'key3:2') == 3

    # Test default functionality

# Generated at 2022-06-24 03:19:34.740069
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    hello = RegistryTree()
    hello.register(['world', 'hello'], 'world')
    assert hello['world:hello'] == 'world'
    assert hello.get(['world', 'hello']) == 'world'

# Generated at 2022-06-24 03:19:36.213466
# Unit test for constructor of class Tree
def test_Tree():
    assert Tree(initial_is_ref=True) is not None



# Generated at 2022-06-24 03:19:40.317903
# Unit test for function tree
def test_tree():
    data = tree()
    data['a']['b']['c'] = 'b'
    assert data['a']['b']['c'] == 'b'

    data['list'].append('lol')
    assert data['list'] == ['lol']



# Generated at 2022-06-24 03:19:44.622988
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    def hello(name):
        return "Hello, %s!" % name
    t = RegistryTree(initial={
        'say:hello': hello,
    })

    assert t.get('say:hello')('world') == "Hello, world!"

    t['add'] = lambda a, b: a + b
    assert t['add'](3, 5) == 8

# Generated at 2022-06-24 03:19:54.767544
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    >>> mapping = Tree({'user': {'name': 'Steve'}})
    >>> set_tree_node(mapping, 'user:address:city', 'NYC')
    {'city': 'NYC'}
    >>> mapping
    {'user': {'name': 'Steve', 'address': {'city': 'NYC'}}}
    >>> set_tree_node(mapping, 'user:address:state', 'NY')
    {'city': 'NYC', 'state': 'NY'}
    >>> mapping
    {'user': {'name': 'Steve', 'address': {'city': 'NYC', 'state': 'NY'}}}
    """
    pass



# Generated at 2022-06-24 03:19:58.895343
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree()
    t['a'] = 1
    t['b'] = 2
    assert t['a'] == 1
    assert t['b'] == 2



# Generated at 2022-06-24 03:20:07.486128
# Unit test for function tree
def test_tree():
    t = tree()
    t['foo']['bar']['baz'] = 1
    t['foo']['bar']['quux'] = 2
    t['foo']['bar']['quux'] = 3
    t['foo']['bar']['quux'] = 4
    t['foo']['bar']['quux'] = 5

    assert t['foo']['bar']['baz'] == 1
    assert t['foo']['bar']['quux'] == 5
    assert t['bar'] == {}
    assert t['bar']['bar'] == {}
    assert t['bar']['bar']['baz'] == {}



# Generated at 2022-06-24 03:20:14.361901
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    if __name__ == '__main__':
        t = RegistryTree()
        t.register('ciao', 'mondo')
        assert t['ciao'] == 'mondo'
        assert t.get('ciao') == 'mondo'
        assert t.register('ciao:mondo', 'monda') == {'mondo': 'monda'}
        assert t['ciao:mondo'] == 'monda'
        assert t.get('ciao:mondo') == 'monda'
        assert t['ciao'] == {'mondo': 'monda'}
        assert t['ciao:mondo:monda'] == {}


if __name__ == '__main__':
    test_RegistryTree()

# Generated at 2022-06-24 03:20:21.133148
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree_ = Tree({'a': {'b': 1}})
    assert tree_['a']['b'] == 1
    assert tree_['a:b'] == 1

    tree_ = Tree({'a': {'b': 1}}, namespace='foo')
    assert tree_['a']['b'] == 1
    assert tree_['a:b'] == 1
    assert tree_['foo:a']['b'] == 1
    assert tree_['foo:a:b'] == 1
    try:
        tree_['b']
    except KeyError:
        pass
    else:
        assert False, 'Should have raised exception'



# Generated at 2022-06-24 03:20:29.206832
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {'foo': {'bar': 'baz'}, 'qux': 'quux'}

    assert get_tree_node(tree, 'foo:bar') == 'baz'
    assert get_tree_node(tree, 'foo:foobar') is _sentinel  # KeyError
    assert get_tree_node(tree, 'foo:foobar', 'default') == 'default'
    assert get_tree_node(tree, 'qux:quux') is _sentinel  # KeyError
    assert get_tree_node(tree, 'qux:quux', 'default') == 'default'

# Generated at 2022-06-24 03:20:39.104545
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree()
    t['a'] = 1
    assert t.get('a') == 1

    t['b:c'] = 2
    assert t.get('b:c') == 2
    assert t.get('b') == Tree()
    assert t.get('b')['c'] == 2

    # Test namespace
    t = Tree(namespace='d')
    t['e'] = 3
    assert t.get('e') == 3
    assert t.get('d:e') is None

    t = Tree(initial_is_ref=t)
    assert t.get('d:e') == 3

    # Empty namespace
    t = Tree(namespace='')
    assert t.get('a') == 1

    # Test constructor with initial data
    t = Tree(initial={'a': 1})

# Generated at 2022-06-24 03:20:40.233996
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    r = RegistryTree(None)

    assert isinstance(r, RegistryTree)

# Generated at 2022-06-24 03:20:45.456129
# Unit test for function set_tree_node
def test_set_tree_node():
    # NOTE: This is a very poor test
    assert set_tree_node(my_tree, 's:s:s:s:s:s:s:s', 'blah') == my_tree['s']['s']['s']['s']['s']['s']['s']



# Generated at 2022-06-24 03:20:48.192690
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    registry = RegistryTree()
    registry.register('1:2:3:test', 'foo')
    assert registry['1:2:3:test'] == 'foo'

# Generated at 2022-06-24 03:20:49.897173
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    expected = {'key': 'value'}
    tree = Tree(initial=expected)
    assert tree == expected



# Generated at 2022-06-24 03:20:55.187202
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree()
    assert isinstance(t, collections.defaultdict)

    t = Tree({'foo': 'bar'})
    assert t == {'foo': 'bar'}

    t = Tree({'foo': 'bar'}, namespace='test')
    assert t['test:foo'] == 'bar'



# Generated at 2022-06-24 03:21:02.569879
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    """
    Class RegistryTree's constructor
    """
    # Check to make sure the correct exception is thrown
    # when not given exactly one argument
    with pytest.raises(TypeError):
        RegistryTree(1, 2)

    # Check to make sure the correct exception is thrown
    # when given a non-string as the namespace
    with pytest.raises(TypeError):
        RegistryTree(1)

    # Check to make sure no exception is thrown when given
    # the correct number of arguments, and the namespace
    # is in the correct format
    RegistryTree()
    RegistryTree(namespace='a')

# Generated at 2022-06-24 03:21:08.079486
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    t['a:b'] = 1
    t['c'] = 2
    assert sorted(t.keys()) == ['a', 'c']
    assert sorted(t['a'].keys()) == ['b']
    assert t['a']['b'] == 1
    assert t['c'] == 1



# Generated at 2022-06-24 03:21:11.039812
# Unit test for function tree
def test_tree():
    """
    Test function `tree`.
    """
    t = tree()
    t['child']['grandchild'] = 'value'
    assert t['child']['grandchild'] == 'value'



# Generated at 2022-06-24 03:21:21.983456
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}
    set_tree_node(tree, '/foo/bar', 'baz')
    set_tree_node(tree, '/foo/baz', 'baz')
    set_tree_node(tree, '/foo/huz', 'buz')
    set_tree_node(tree, '/foo/huz/foo', 'buz')
    assert tree == {
        '/foo': {
            'bar': 'baz',
            'baz': 'baz',
            'huz': {
                'foo': 'buz'
            }
        }
    }
    set_tree_node(tree, '/foo/huz/foo', 'foo')

# Generated at 2022-06-24 03:21:26.274165
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    registry = RegistryTree(namespace='_:test')
    registry.register('test', True)

    assert registry['_:test:test'] is True



# Generated at 2022-06-24 03:21:33.701296
# Unit test for constructor of class Tree
def test_Tree():
    test_tree = Tree(dict(a=1))
    assert test_tree['a'] == 1
    test_tree[':b:c'] = 3
    assert test_tree['b:c'] == 3
    assert test_tree[':b:c'] == 3
    test_tree.namespace = 'x'
    assert test_tree[':b:c'] == 3
    assert test_tree.namespace == 'x'



# Generated at 2022-06-24 03:21:38.506627
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    registry = RegistryTree({'a': 'b'})
    registry.register('c', {'d': 'e'})
    registry.register('c', {'d': 'f'})
    assert registry['a'] == 'b'
    assert registry['c'] == {'d': 'f'}

# Generated at 2022-06-24 03:21:44.545089
# Unit test for constructor of class Tree
def test_Tree():
    import json
    try:
        import ujson as ujson
    except ImportError:
        ujson = None
    t = Tree()
    t.update({'a': {'b': 'c'}})
    t['d:e'] = {'f': 'g'}
    t['d:h'] = 'i'
    t['d:j:k'] = 'l'
    # print json.dumps(t)
    # print ujson.dumps(t)

# Generated at 2022-06-24 03:21:49.641408
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree(namespace='foo', initial={'bar': {'baz': 'foo:bar:baz'}})
    assert t['baz'] == 'foo:bar:baz'



# Generated at 2022-06-24 03:21:54.537633
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    test_tree = Tree({"foo":"bar"})
    assert test_tree["foo"] == "bar"
    # Tests to ensure that a KeyError is thrown when accessing a key that doesn't exist
    try:
        test_tree["foobar"]
    except KeyError as e:
        assert True
    else:
        assert False



# Generated at 2022-06-24 03:21:59.910283
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    expected_result = "Hello World!"
    t = Tree()
    t['foo'] = 'bar'
    t['foo:baz'] = expected_result
    assert t['foo:baz'] == expected_result
    assert t['foo:baz'] is t['foo']['baz']

# Generated at 2022-06-24 03:22:08.436137
# Unit test for function get_tree_node
def test_get_tree_node():
    test_tree = tree()
    test_tree['one:two:three'] = 'three'
    test_tree['four:five:six'] = 'six'
    assert get_tree_node(test_tree, 'four:five:six') == 'six'
    assert get_tree_node(test_tree, 'one:two:three') == 'three'
    assert get_tree_node(test_tree, 'foo:bar:baz', default='barf') == 'barf'


if __name__ == '__main__':
    test_get_tree_node()
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 03:22:13.230074
# Unit test for function set_tree_node
def test_set_tree_node():
    """Test `set_tree_node` function."""
    t = tree()
    set_tree_node(t, 'x:y:z', 'foo')
    assert t['x']['y']['z'] == 'foo'

    t = tree()
    set_tree_node(t, 'x', 'bar')
    assert t['x'] == 'bar'



# Generated at 2022-06-24 03:22:23.251612
# Unit test for function set_tree_node
def test_set_tree_node():
    import unittest

    class Test(unittest.TestCase):

        def test_simple_set(self):
            from pprint import pprint
            target = tree()
            set_tree_node(target, 'foo:bar:baz', 'A')
            self.assertEqual(
                target,
                {'foo': {'bar': {'baz': 'A'}}}
            )

        def test_simple_set_with_update(self):
            from pprint import pprint
            target = tree()
            set_tree_node(target, 'foo:bar:baz', 'A')
            self.assertEqual(
                target,
                {'foo': {'bar': {'baz': 'A'}}}
            )

# Generated at 2022-06-24 03:22:31.058227
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    """Everything still works."""
    t = RegistryTree()
    t.register('a', 1)
    t['b'] = {'c': 2}
    print(t)
    assert t.get('a:b:c') == 2
    assert t.get('a:b:c:') is None
    assert t.get('a:b:c:', None) is None
    assert t.get('a:b:c:d') is None
    assert t.get('a:b:c:d', None) is None
    assert t.get('a:b:c', 'foo') == 2
    with pytest.raises(KeyError):
        t.get('a:b:c:d')



# Generated at 2022-06-24 03:22:41.727328
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    registry = RegistryTree(namespace='mika')
    registry.register('test', 'testval')
    registry.register('test2', 'testval2')
    assert 'test' in registry.keys()
    assert 'mika:test2' in registry.keys()
    assert 'test2' not in registry.keys()
    assert registry['test'] == 'testval'
    assert registry['test2'] == 'testval2'
    assert registry['mika:test2'] == 'testval2'
    assert registry['mika:test'] == 'testval'

    # Test for "manual" namespace setting
    assert 'test4' not in registry.keys()
    registry.register('test4', 'testval4', namespace='olleh')
    assert 'test4' not in registry.keys()

# Generated at 2022-06-24 03:22:42.328264
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    RegistryTree()

# Generated at 2022-06-24 03:22:51.994130
# Unit test for function get_tree_node
def test_get_tree_node():
    test_dict = tree()
    test_dict['foo']['bar']['baz'] = 1
    test_dict['foo']['bar']['boo'] = 2
    test_dict['foo']['bar']['foo']['bar']['baz'] = 3
    test_dict['foo']['bar']['foo']['bar']['boo'] = 4
    assert get_tree_node(test_dict, 'foo:bar:baz') == 1
    assert get_tree_node(test_dict, 'foo:bar:foo:bar:baz') == 3
    assert get_tree_node(test_dict, 'foo:bar:foo:bar:foo:foo:foo:foo:baz') == 3



# Generated at 2022-06-24 03:22:57.401914
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    def add(x, y):
        return x + y

    r = RegistryTree()
    r.register('test', add)
    assert r['test'](4, 5) == 9


if __name__ == '__main__':
    test_RegistryTree()

# Generated at 2022-06-24 03:23:04.773910
# Unit test for function get_tree_node
def test_get_tree_node():
    #
    # Test cases
    #
    tree = Tree()
    tree['a:b:c'] = 1
    tree['a:b:d'] = 2
    tree['a:b:e'] = 3
    assert tree['a:b:c'] == 1
    assert tree['a:b:d'] == 2
    assert tree['a:b:e'] == 3
    #
    # Test cases (via get)
    #
    tree = Tree()
    tree['a:b:c'] = 1
    tree['a:b:d'] = 2
    tree['a:b:e'] = 3
    assert tree.get('a:b:c') == 1
    assert tree.get('a:b:d') == 2
    assert tree.get('a:b:e') == 3
    #
    #

# Generated at 2022-06-24 03:23:10.868064
# Unit test for function tree
def test_tree():
    my_tree = tree()
    my_tree['lvl1']['lvl11'] = 'foo'
    my_tree['lvl1']['lvl12'] = 'bar'
    assert my_tree['lvl1']['lvl12'] == 'bar'


if __name__ == '__main__':
    test_tree()

# Generated at 2022-06-24 03:23:13.846454
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    """
    Test for method __getitem__ of class Tree
    """
    foo = Tree({'foo': 'bar', 'baz': 'buzz'})
    assert foo['foo'] == 'bar'
    assert foo['baz'] == 'buzz'



# Generated at 2022-06-24 03:23:20.894010
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree()
    t['key:subkey'] = 'value'
    val = t['key:subkey']

# Generated at 2022-06-24 03:23:30.780284
# Unit test for function get_tree_node
def test_get_tree_node():
    from pytest import raises
    test = {
        'test': {
            'test': {
                'test': 'hello world'
            }
        }
    }

    assert get_tree_node(test, 'test:test:test') == 'hello world'
    assert get_tree_node(test, 'test:test:test', default=None) == 'hello world'
    assert get_tree_node(test, 'test:test:nottest') is None
    assert get_tree_node(test, 'test:test:nottest', default='hello world') == 'hello world'
    with raises(KeyError):
        get_tree_node(test, 'test:test:nottest')
        get_tree_node(test, 'test:test:nottest', default=_sentinel)

# Generated at 2022-06-24 03:23:40.818389
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    t = RegistryTree()
    t.register('a', 'A')
    t.register('b:c', 'B')
    t.register('b:e', 'E')
    t.register('b:d', 'D')
    t.register('b:e:f', 'F')
    t.register('h:g:i', 'I')
    t.register('h:g:j', 'J')
    t.register('h:g', 'G')

    assert t._namespace_key('test', namespace='test') == 'test:test'

    assert t.get('a') == 'A'
    assert t.get('b:c') == 'B'
    assert t.get('b') == {'c': 'B', 'd': 'D', 'e': {'f': 'F'}}


# Generated at 2022-06-24 03:23:45.258253
# Unit test for function set_tree_node
def test_set_tree_node():
    assert set_tree_node({}, 'foo:bar:baz', 'TEST') == {'foo': {'bar': {'baz': 'TEST'}}}
    assert set_tree_node({}, 'foo:bar:baz', 'TEST') == {'foo': {'bar': {'baz': 'TEST'}}}



# Generated at 2022-06-24 03:23:55.009213
# Unit test for function get_tree_node
def test_get_tree_node():
    """General test for function get_tree_node"""
    tree = {
        'a': {
            '1': 1,
            '2': 2,
            '3': 3,
        },
        'b': {
            '1': 1,
            '2': 2,
            '3': 3,
        },
        'c': {
            '1': 1,
            '2': 2,
            '3': 3,
        },
    }
    assert get_tree_node(tree, 'a:1') == 1
    assert get_tree_node(tree, 'a:1:2') is _sentinel



# Generated at 2022-06-24 03:24:02.916005
# Unit test for function get_tree_node
def test_get_tree_node():
    import random
    from copy import deepcopy
    from faker import Factory as FakerFactory
    from functools import partial

    faker = FakerFactory.create()
    faker_gen = partial(faker.pystr, max_chars=10)

    tree = Tree()

    for key, value in zip(faker.pyiter(''.join(faker_gen() for _ in range(2)), 6), faker.pyiter(''.join(faker_gen() for _ in range(2)), 6)):
        set_tree_node(tree, key, value)

    assert get_tree_node(tree, key) == value

    # Test default behavior
    try:
        get_tree_node(tree, '%s:%s' % (key, faker_gen()))
    except KeyError:
        pass

# Generated at 2022-06-24 03:24:12.272151
# Unit test for function tree
def test_tree():
    tree = Tree(namespace='test')
    tree['foo:bar:1'] = 'bar'
    assert tree['foo:bar:1'] == 'bar'
    assert tree['foo:bar'] == {}
    assert tree['foo'] == {}
    assert tree['foo:bar:2'] == {}
    assert tree['foo:bar:2']['baz'] == {}
    assert tree['foo:bar:2']['baz'] == {}
    tree['foo:bar:2']['baz'] = 'qux'
    assert tree['foo:bar:2']['baz'] == 'qux'
    assert tree['foo:bar:2'] == {'baz': 'qux'}