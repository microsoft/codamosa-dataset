

# Generated at 2022-06-24 03:14:15.255044
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    test_dict = {'alpha': 5,
                 'bravo': {'omega': 'omega'}}
    test_tree = RegistryTree(test_dict)
    assert test_tree['alpha'] == 5
    assert test_tree['bravo:omega'] == 'omega'

    test_tree.register('charlie', 'charlie')
    assert test_tree['charlie'] == 'charlie'

# Generated at 2022-06-24 03:14:24.101254
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    from nose.tools import assert_equals
    from collections import defaultdict

    t = Tree()
    t[':a:b:c'] = 'test'
    assert_equals(t['a:b:c'], 'test')

# Generated at 2022-06-24 03:14:28.172662
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    tree = RegistryTree()

    def register_something(name):
        def inner(func):
            tree.register(name, func)
            return func
        return inner

    @register_something('foo.bar')
    def baz():
        pass

    assert tree['foo.bar'] is baz



# Generated at 2022-06-24 03:14:34.161503
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree()

    t['x'] = 10
    assert t['x'] == 10

    t['a:b'] = 20
    assert t['a']['b'] == 20

    t['a:b:c:d'] = 30
    assert t['a']['b'] == 20
    assert t['a']['b']['c'] == {'d': 30}

# Generated at 2022-06-24 03:14:39.300329
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    """Test RegistryTree constructor."""
    from six import StringIO
    from sys import stdout
    # Use StringIO to capture stdout for unit testing
    stdout = StringIO()
    # Construct RegistryTree
    registry = RegistryTree()
    registry['echo'] = lambda *inargs: (stdout.write(' '.join(inargs)))
    registry['echo']('Hello', 'World!')
    assert stdout.getvalue() == 'Hello World!'

# Generated at 2022-06-24 03:14:41.177031
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    a = Tree()
    a.__setitem__('a', 1)
    assert a['a'] == 1

# Unit tests for method _namespace_key of class Tree

# Generated at 2022-06-24 03:14:44.986991
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    x = Tree()
    x['ns1:key1'] = 'value1'
    x['ns1:ns2:key2'] = 'value2'

# Generated at 2022-06-24 03:14:48.870203
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'b': 'c'
        }
    }

    assert get_tree_node(mapping, 'a:b') == 'c'



# Generated at 2022-06-24 03:14:55.039882
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    root = Tree(initial={'root': 'root_value'})
    root['child:child'] = 'child_value'
    assert root['root'] == 'root_value'
    assert root['child:child'] == 'child_value'



# Generated at 2022-06-24 03:15:03.074455
# Unit test for function set_tree_node
def test_set_tree_node():
    assert set_tree_node({}, 'foo', 1) == {'foo': 1}
    assert set_tree_node({}, 'foo:bar', 2) == {'foo': {'bar': 2}}
    assert set_tree_node({}, 'foo:bar:baz', 3) == {'foo': {'bar': {'baz': 3}}}
    assert set_tree_node({'foo': {}}, 'foo:bar', 2) == {'foo': {'bar': 2}}
    assert set_tree_node({'foo': {}}, 'foo:bar:baz', 3) == {'foo': {'bar': {'baz': 3}}}

# Generated at 2022-06-24 03:15:09.214273
# Unit test for function set_tree_node
def test_set_tree_node():
    import uuid
    from copy import deepcopy
    d = {'foo': {'bar': {'baz': 'spam'}}}
    d2 = deepcopy(d)
    set_tree_node(d2, 'foo:bar:baz', uuid.uuid4())
    assert d == d2



# Generated at 2022-06-24 03:15:15.523560
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    import random

    # Init tree
    d = Tree({})

    # Set value
    d.__setitem__('foo_bar', 'baz')

    # Check value
    assert d['foo_bar'] == 'baz'

    # Set large, random value
    for i in range(100):
        d.__setitem__('a' * i, random.random())

    # Check large, random value
    for i in range(100):
        assert d['a' * i] == random.random()



# Generated at 2022-06-24 03:15:17.498841
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree()
    t['a']['b']['c'] = 1
    assert t['a:b:c'] == 1



# Generated at 2022-06-24 03:15:24.387968
# Unit test for function get_tree_node
def test_get_tree_node():
    v1 = {'a': {'b': {'c': 'd'}}}
    assert get_tree_node(v1, 'a:b:c') == 'd'
    assert get_tree_node(v1, 'z:z') == _sentinel
    assert get_tree_node(v1, 'z:z', default='NOTHING') == 'NOTHING'

    # Test parent node
    assert get_tree_node(v1, 'a:b', parent=True) == {'c': 'd'}



# Generated at 2022-06-24 03:15:25.981021
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    t = RegistryTree()
    assert isinstance(t, RegistryTree)


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 03:15:26.894432
# Unit test for constructor of class Tree
def test_Tree():
    assert 'Unit test failed' is True

# Generated at 2022-06-24 03:15:28.927469
# Unit test for function tree
def test_tree():
    import json
    t = tree()

    t['a']['b'] = 'c'

# Generated at 2022-06-24 03:15:33.358829
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree({'my': {'test': 'dict'}})
    t.namespace = 'my'
    t.update({'test': {'other': 'dict'}})
    assert t.get('dict') == 'dict'
    assert t.get('test:dict') == 'dict'
    assert t.get('test:other') == 'dict'
    assert t.get('test:other', namespace='test') == 'dict'



# Generated at 2022-06-24 03:15:40.425145
# Unit test for function tree
def test_tree():
    t = tree()
    t['a']['b'] = 'c'
    t['a']['d']['e'] = 'f'
    t['a']['d']['g'] = 'h'

    t2 = tree()
    t2['a']['b'] = 'c'
    t2['a']['d']['e'] = 'f'
    t2['a']['d']['g'] = 'h'

    assert t == t2



# Generated at 2022-06-24 03:15:47.279112
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    r = RegistryTree(initial={'bar': {}}, namespace='foo')
    assert r.namespace == 'foo'
    assert 'foo' not in r
    assert 'bar' not in r
    assert 'foo:bar' in r

    r.update({'baz': {}})
    assert 'foo:baz' in r

    r.__setitem__(key='qux', value={})
    assert 'foo:qux' in r

    r['corge'] = {}
    assert 'foo:corge' in r

    r.register('grault', {})
    assert 'foo:grault' in r

    r = RegistryTree(initial={'bar': {}}, initial_is_ref=True)
    assert 'bar' in r


# Generated at 2022-06-24 03:15:56.529344
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    assert t == {}
    t['foo'] = 'bar'
    assert t == {"foo": "bar"}
    t['foo:bar'] = 'baz'
    assert t == {'foo': {'bar': 'baz'}}
    t['foo:bar:baz'] = 'bip'
    assert t == {'foo': {'bar': {'baz': 'bip'}}}
    t['foo:bar:bip'] = 'baz'
    assert t == {'foo': {'bar': {'baz': 'bip', 'bip': 'baz'}}}



# Generated at 2022-06-24 03:16:07.298678
# Unit test for constructor of class Tree
def test_Tree():
    def check_result(tree_inst, expected):
        for key, value in expected.items():
            assert tree_inst[key] == value

    for initial in [None, {'foo': 'bar', 'dict': {'key': 'value'}}, {'foo': 'bar', 'dict': {'key': 'value'}}]:
        tree_inst = Tree(initial)
        check_result(tree_inst, {'foo': 'bar', 'dict:key': 'value'})

    # # Construct a dict and pass it by reference.
    # initial = {'foo': 'bar', 'dict': {'key': 'value'}}
    # tree_inst = Tree(initial, initial_is_ref=True)
    # check_result(tree_inst, initial)

    # Test with namespace

# Generated at 2022-06-24 03:16:09.825776
# Unit test for function tree
def test_tree():
    data = tree()
    data['testing']['trees'] = 'test tree yield'
    assert data['testing']['trees'] == 'test tree yield'



# Generated at 2022-06-24 03:16:13.656785
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}
    set_tree_node(tree, 'a:b:c:d:e:f', 'foo')
    assert tree['a']['b']['c']['d']['e']['f'] == 'foo'



# Generated at 2022-06-24 03:16:18.276007
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'foo': {
            'bar': {
                'baz': 'foobarbaz'
            }
        }
    }
    assert get_tree_node(tree, 'foo:bar:baz') == 'foobarbaz'
    assert get_tree_node(tree, 'foo:bar:baz:nonexistant', default='default') == 'default'
    tree = {}
    try:
        get_tree_node(tree, 'foo:bar:baz')
    except KeyError:
        pass
    else:
        assert False, "Keys were missing, but no KeyError was thrown!"



# Generated at 2022-06-24 03:16:21.898304
# Unit test for function set_tree_node
def test_set_tree_node():
    """Test case for set_tree_node"""
    tree = Tree()
    set_tree_node(tree, 'key', 'value')
    assert tree['key'] == 'value'
    set_tree_node(tree, 'foo:bar:key', 'value')
    assert tree['foo']['bar']['key'] == 'value'



# Generated at 2022-06-24 03:16:25.694029
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    reg_tree = RegistryTree(initial={
        'key_one': 'value_one',
        'key_two': 'value_two'
    })
    assert reg_tree['key_one'] == 'value_one'
    assert reg_tree['key_two'] == 'value_two'



# Generated at 2022-06-24 03:16:33.482564
# Unit test for constructor of class Tree
def test_Tree():
    _tree = Tree()
    _tree.register(
        'my.namespace.some.weird.key',
        {'moo': {'some': 'depth'}},
        namespace='my.namespace'
    )
    assert _tree.get('my.namespace.some.weird.key').get('moo') == {'some': 'depth'}
    assert _tree['my.namespace.some.weird.key:moo:some'] == 'depth'

# Generated at 2022-06-24 03:16:43.594166
# Unit test for function get_tree_node
def test_get_tree_node():
    doc = tree()
    doc['foo']['bar']['quux'] = 42
    assert get_tree_node(doc, 'foo:bar:quux') == 42
    assert get_tree_node(doc, 'foo:bar:quux', 'fail') == 42
    assert get_tree_node(doc, 'foo:bar:blarg', 'pass') == 'pass'
    assert get_tree_node(doc, 'foo:bar:blarg') == {'quux': 42}
    assert get_tree_node(doc, 'foo:bar:blarg:hopefullynot:here') == {}



# Generated at 2022-06-24 03:16:47.533628
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()
    key = 'group:foo'
    value = {'bar': 'baz'}

    tree.__setitem__(key, value)
    assert tree['group:foo'] == {'bar': 'baz'}



# Generated at 2022-06-24 03:16:49.415997
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    r = RegistryTree()
    assert isinstance(r, RegistryTree)



# Generated at 2022-06-24 03:16:51.251425
# Unit test for function tree
def test_tree():
    t = tree()
    assert t['a']['b']['c'] == {}



# Generated at 2022-06-24 03:16:57.020330
# Unit test for function set_tree_node
def test_set_tree_node():

    # Setup data
    mapping = {
        'name': 'Fauxy', 'species': 'cat',
        'owner': {'name': 'Aaron', 'age': 24},
        'owner:age': ':p',
        'age': 3,
        'children': [{'name': 'Fluffy', 'age': 2}, {'name': 'Bagheera', 'age': 1}],
        'employee': [{'name': 'Aaron', 'age': 24}]
    }

    # Test setting simple node
    result = set_tree_node(mapping, 'color', 'black')
    assert result == {'color': 'black'}

    # Test setting node with multiple levels
    result = set_tree_node(mapping, 'owner:age', 'too old')

# Generated at 2022-06-24 03:17:01.347910
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    registry = RegistryTree()
    registry.register('python', 'structured_data:json:json_store')
    assert registry.data['python']['structured_data']['json']['json_store']


if __name__ == '__main__':
    test_RegistryTree()

# Generated at 2022-06-24 03:17:08.183131
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    """
    Confirm that method `__setitem__` has the desired effect when used on a tree.
    """
    my_tree = Tree()
    my_tree['hi:value1'] = 'hello'
    my_tree['hi:value2'] = 'world'
    my_tree['hi:level2:value3'] = 'world'
    assert my_tree['hi:value1'] == 'hello'
    assert my_tree['hi:value2'] == 'world'
    assert my_tree['hi:level2:value3'] == 'world'
    assert my_tree['hi:value4'] is None



# Generated at 2022-06-24 03:17:18.983044
# Unit test for function get_tree_node
def test_get_tree_node():
    # Define a tree to search
    test_tree = {
        1: {
            2: {
                3: 'baz',
            },
            4: 'foo',
        },
        5: {
            6: 'bar',
        },
    }

    # Do some lookups with get_tree_node
    assert get_tree_node(test_tree, '1:4') == 'foo'
    assert get_tree_node(test_tree, '5') == {6: 'bar'}
    assert get_tree_node(test_tree, '1:2:3') == 'baz'
    assert get_tree_node(test_tree, '1:2:3', parent=True) == {3: 'baz'}

# Generated at 2022-06-24 03:17:22.238633
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()

    t.__setitem__('a', 'a')
    t.__setitem__('a:b', 'b')
    t.__setitem__('a:b:c', 'c')

    assert t['a'] == 'a'
    assert t['a:b'] == 'b'
    assert t['a:b:c'] == 'c'



# Generated at 2022-06-24 03:17:24.953210
# Unit test for function set_tree_node
def test_set_tree_node():
    tree_dict = {}
    set_tree_node(tree_dict, 'parent:child:grandchild', 1337)
    assert tree_dict == {'parent': {'child': {'grandchild': 1337}}}



# Generated at 2022-06-24 03:17:28.530190
# Unit test for constructor of class Tree
def test_Tree():
    assert Tree().data == {}
    assert Tree([('foo', 'bar')]).data == {'foo': 'bar'}
    assert Tree({'foo': 'bar'}).data == {'foo': 'bar'}

# Generated at 2022-06-24 03:17:35.037286
# Unit test for function tree
def test_tree():
    tree = {}
    set_tree_node(tree, 'a:b:c', 'd')
    assert tree['a']['b']['c'] == 'd'
    tree = {}
    set_tree_node(tree, 'a:b:c', 'd')
    assert tree['a']['b']['c'] == 'd'
    assert get_tree_node(tree, 'a:b:c') == 'd'



# Generated at 2022-06-24 03:17:39.322216
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    import pytest

    @RegistryTree.register('test')
    def test_func(foo, bar):
        return foo + bar

    decorated_func = RegistryTree.get('test')

    assert decorated_func.__name__ == 'test_func'
    assert decorated_func(1, 2) == 3

    with pytest.raises(KeyError):
        RegistryTree.get('test_non_existent')

# Generated at 2022-06-24 03:17:49.339578
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    rt = RegistryTree(initial={'foo': 'bar', 'baz': 'quux'})
    assert rt['foo'] == 'bar'
    assert rt['baz'] == 'quux'
    assert 'shaman' not in rt

    # Testing namespace
    rt = RegistryTree(initial={'foo': 'bar', 'baz': 'quux'}, namespace='nebukadnezzar')
    assert rt['foo'] == 'bar'
    assert rt['baz'] == 'quux'
    assert 'nebukadnezzar:foo' in rt
    assert 'nebukadnezzar:baz' in rt

    # Testing registry
    rt = RegistryTree(initial={'foo': 'bar', 'baz': 'quux'})

# Generated at 2022-06-24 03:17:55.798503
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()
    tree.__setitem__('key', 'value')
    assert tree['key'] == 'value'
    tree.__setitem__('namespace:key', 'value')
    assert tree['namespace:key'] == 'value'
    tree.__setitem__('namespace:key:key2', 'value2', namespace='namespace')
    assert tree['namespace:key:key2'] == 'value2'

# Generated at 2022-06-24 03:18:00.870707
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    t['bar'] = 'foo'
    assert t['bar'] == 'foo'
    t['foo:bar'] = 'baz'
    assert t['foo']['bar'] == 'baz'
    t['foo:bar:baz'] = 'foobar'
    assert t['foo']['bar']['baz'] == 'foobar'
    t['foo:bar:qux'] = 'foobaz'
    assert t['foo']['bar']['baz'] == 'foobar'
    assert t['foo']['bar']['qux'] == 'foobaz'

    try:
        t['foo:bar:baz:qux']
        raise AssertionError
    except KeyError:
        pass



# Generated at 2022-06-24 03:18:07.779822
# Unit test for function tree
def test_tree():
    treedict = tree()
    assert isinstance(treedict, collections.defaultdict)
    treedict['a']['b']['c'] = 42
    assert treedict['a:b:c'] == 42
    try:
        treedict['a:b:d']
    except KeyError:
        pass
    else:
        assert False
    assert treedict['a:b:d'] == None
    x = treedict['a:b:c']  # will raise error
    x = treedict['a:b:c', None]  # will not raise error
    assert x == 42
    x = treedict['a:b:d', None]  # will not raise error
    assert x == None



# Generated at 2022-06-24 03:18:14.819844
# Unit test for function set_tree_node
def test_set_tree_node():
    a = tree()
    set_tree_node(a, 'foo:bar:baz', 'quux')
    assert a['foo']['bar']['baz'] == 'quux'
    set_tree_node(a, 'foo:bar:baz:faz', 'quux')
    assert a['foo']['bar']['baz']['faz'] == 'quux'



# Generated at 2022-06-24 03:18:20.395669
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    r = RegistryTree()
    r.register('thesaurus', 'dictionary')
    r.register('thesaurus', 'lexicon')
    assert r['thesaurus'] == 'dictionary'

# Generated at 2022-06-24 03:18:27.643835
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    """
    Tests for self[key] = value
    """
    t = Tree()
    t['a'] = 1
    t['a:b'] = 2
    assert t['a'] == 1
    assert t['a:b'] == 2
    assert t['a']['b'] == 2



# Generated at 2022-06-24 03:18:33.258716
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    tree = RegistryTree()

    assert list(tree.keys()) == []
    assert tree.get('foo', 'bar') == 'bar'

    # Make sure sets are properly registered
    tree.register('foo', None)
    assert list(tree.keys()) == ['foo']

    # Make sure gets work
    assert tree.get('foo', 'bar') == None
    assert tree.get('bar', 'baz') == 'baz'



# Generated at 2022-06-24 03:18:42.909108
# Unit test for function set_tree_node
def test_set_tree_node():
    before = {'a': {'b': {'c': 1}}}
    set_tree_node(before, 'a:b:c', 2)
    assert before == {'a': {'b': {'c': 2}}}

    set_tree_node(before, 'a:b:d', 3)
    assert before == {'a': {'b': {'c': 2, 'd': 3}}}

    set_tree_node(before, 'e:f:g', 4)
    assert before == {'a': {'b': {'c': 2, 'd': 3}}, 'e': {'f': {'g': 4}}}

    set_tree_node(before, 'g', 5)

# Generated at 2022-06-24 03:18:47.454691
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}
    set_tree_node(tree, 'key', 'value')
    assert tree['key'] == 'value'
    set_tree_node(tree, 'key:subkey', 'subvalue')
    assert tree['key'] == {'subkey': 'subvalue'}



# Generated at 2022-06-24 03:18:50.851120
# Unit test for function tree
def test_tree():
    t = tree()
    t['this']['a']['weird']['tree'] = 'Hello World'
    assert t['this']['a']['weird']['tree'] == 'Hello World'



# Generated at 2022-06-24 03:18:53.198399
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    a = Tree()
    a['test'] = 'test'

    assert a['test'] == 'test'



# Generated at 2022-06-24 03:18:58.183449
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree()
    t[:] = {}
    t[:][0] = 1
    t[:][1] = 2
    t[:][2] = 3
    t[:][2][:][:] = 4

    assert t[:][0] == 1
    assert t[:][1] == 2
    assert t[:][2][:][:] == 4



# Generated at 2022-06-24 03:18:59.768170
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    tree = RegistryTree()
    tree.register('foo', 'bar')
    assert tree.get('foo') == 'bar'

# Generated at 2022-06-24 03:19:08.455898
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree(['a', 'b', 'c'], namespace='test')
    assert t['test:a'] == 'b'
    assert t['test:b'] == 'c'
    assert t['test:c'] is None
    assert t['test:d'] is None
    assert t.get('test:d', False) is False
    assert t.get('test:a') == 'b'
    assert t.get('test:b') == 'c'
    assert t.get('test:c') is None
    assert t.get('test:d', False) is False


if __name__ == '__main__':
    test_Tree()

# Generated at 2022-06-24 03:19:18.724184
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    assert tree()['foo'] is tree()
    assert tree()['foo']['bar']['baz'] is tree()

    # Test real values
    test_tree = tree()
    test_tree['foo']['bar']['baz'] = 1
    test_tree['foo']['quux']['qux'] = 2

    assert test_tree == {
        'foo': {
            'bar': {
                'baz': 1
            },
            'quux': {
                'qux': 2
            }
        }
    }

    # Test actual use-case
    tree_opts = tree()
    assert tree_opts['foo']['bar']['baz'] is tree_opts

# Generated at 2022-06-24 03:19:28.123259
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    """
    Simple Tree unit test using pytest
    """
    # tree.__setitem__(key, value, namespace=None)
    tree = Tree()
    tree['x'] = 'x'
    tree[':y'] = 'y'

    assert tree['x'] == 'x'
    assert tree['y'] == 'y'

    tree['x:y'] = 'xy'
    assert tree['y'] == 'y'
    assert tree['x:y'] == 'xy'
    assert tree['x:x:y'] == 'xy'



# Generated at 2022-06-24 03:19:32.076403
# Unit test for function set_tree_node
def test_set_tree_node():
    a = tree()
    set_tree_node(a, '1:2:3', 4)
    assert a['1']['2']['3'] == 4



# Generated at 2022-06-24 03:19:40.951014
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree_ = Tree()

    tree_['key'] = 'value'
    assert tree_.get('key') == 'value'

    tree_['key:1:2'] = 'value'
    assert tree_.get('key:1')['2'] == 'value'

    tree_['key:1:2']['3'] = 'value'
    assert tree_.get('key:1')['2']['3'] == 'value'
    assert tree_.get('key', default={}).get('1', default={}).get('2', default={}).get('3') == 'value'



# Generated at 2022-06-24 03:19:43.036425
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    k = '__getitem__'  # TODO: Replace me!
    tree = Tree()
    assert tree[k] is tree.__getitem__(k)
    return True

# Generated at 2022-06-24 03:19:49.619592
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    # Testing for a tree of level 1
    tree = Tree()
    tree[0] = 1
    assert tree._namespace_key(0) == 0
    assert tree[0] == 1

    # Testing for a tree of level 2
    tree = Tree()
    tree[0] = {}
    tree[0][0] = 1
    assert tree[0][0] == 1



# Generated at 2022-06-24 03:19:57.506206
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()
    root = 'root'
    sub1 = 'sub1'
    sub2 = 'sub2'
    key1 = 'key1'
    key2 = 'key2'
    key3 = 'key3'
    value1 = 'value1'
    value2 = 'value2'
    value3 = 'value3'
    tree[root] = 'root_value'
    tree[root, sub1] = 'sub1_value'
    tree[root, sub1, key1] = 'key1_value'
    tree[root, sub1, key2] = 'key2_value'
    tree[root, sub2, key2] = 'key2_value'
    tree[root, sub2, key3] = 'key3_value'
    print(tree)
    # {'

# Generated at 2022-06-24 03:20:06.485666
# Unit test for function set_tree_node
def test_set_tree_node():
    from pprint import pprint
    t = tree()
    t['a']['b']['c'] = 'foo'
    assert t['a']['b']['c'] == 'foo'
    set_tree_node(t, 'a:b:c', 'bar')
    assert t['a']['b']['c'] == 'bar'
    t['d']['e']['f'] = 'baz'
    assert t['d']['e']['f'] == 'baz'
    set_tree_node(t, 'd:e:f', 'quux')
    assert t['d']['e']['f'] == 'quux'

# Generated at 2022-06-24 03:20:07.647261
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree()
    assert isinstance(t, Tree)



# Generated at 2022-06-24 03:20:09.401817
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree()
    assert t['foo'] == {}
    t['foo'] = 1
    assert t['foo'] == 1

# Generated at 2022-06-24 03:20:14.103591
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}
    set_tree_node(tree, 'foo', 1)
    set_tree_node(tree, 'bar', 2)
    set_tree_node(tree, 'foo:bar', 3)
    assert tree == {'foo': {'bar': 3}, 'bar': 2}



# Generated at 2022-06-24 03:20:21.796028
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    # Setup
    tree = Tree()
    tree['a'] = {'b': {'c': 'd'}}

    # Preconditions
    assert tree['a'] == {'b': {'c': 'd'}}

    # Smoke test
    assert tree['a:b:c'] == 'd'

    # Test default
    try:
        tree['a:b:d']
    except KeyError as exc:
        assert True
    else:
        assert False

    # Test default value

# Generated at 2022-06-24 03:20:24.388802
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    """
    Unit test for method __getitem__ of class Tree.
    """
    pass



# Generated at 2022-06-24 03:20:27.232586
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree()
    t['a:b'] = 1
    result = t.__getitem__('a:b')
    assert result == 1



# Generated at 2022-06-24 03:20:33.843605
# Unit test for function set_tree_node
def test_set_tree_node():
    assert set_tree_node(tree(), 'foo', 'bar') == {'foo': 'bar'}
    assert set_tree_node(tree(), 'foo:bar:baz', 'bat') == {'foo': {'bar': {'baz': 'bat'}}}



# Generated at 2022-06-24 03:20:38.447269
# Unit test for function get_tree_node
def test_get_tree_node():
    """Unit test for function get_tree_node."""
    import nose
    # Basic test
    base_dict = {'foo': {'bar': 'baz'}}
    assert get_tree_node(base_dict, 'foo:bar') == 'baz'
    # Test for detected failure
    with nose.tools.raises(KeyError):
        get_tree_node(base_dict, 'no:such:thing')
    # Test for default value
    assert get_tree_node(base_dict, 'no:such:thing', 'Zork') == 'Zork'



# Generated at 2022-06-24 03:20:48.347308
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    t['client:localhost:mysql:mongo:1'] = { "SOMETHING": 1 }
    t['client:localhost:mysql:mongo:2'] = { "SOMETHING": 2 }
    t['client:localhost:mysql:mongo:3'] = { "SOMETHING": 3 }
    t['client:localhost:mysql:mongo:4'] = { "SOMETHING": 4 }
    t['client:localhost:mysql:mongo:5'] = { "SOMETHING": 5 }
    assert t['client:localhost:mysql:mongo:1'] == {'SOMETHING': 1}
    assert t['client:localhost:mysql:mongo:2'] == {'SOMETHING': 2}

# Generated at 2022-06-24 03:20:52.386001
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    """
    Unit test for method __getitem__ of class Tree
    """
    t = Tree()
    t.__setitem__('one', 1)
    assert t.__getitem__('one') == 1



# Generated at 2022-06-24 03:20:55.957362
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    registry = RegistryTree()
    registry.namespace = 'bar'

    registry.register('foo', lambda: 'bar', namespace='spam:eggs')

    assert registry['spam:eggs:foo']() == 'bar'

# Generated at 2022-06-24 03:20:57.550589
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree({'a': {'b': {'c': 5}, 'd': 7}}, namespace='ns')
    assert t['a:b:c'] == 5
    assert t['a:d'] == 7
    assert t.namespace == 'ns'



# Generated at 2022-06-24 03:20:58.314284
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    pass

# Generated at 2022-06-24 03:21:04.066894
# Unit test for function set_tree_node
def test_set_tree_node():
    import json
    mapping = {}
    key = 'foo:bar:baz'
    value = 'bacon'
    node = set_tree_node(mapping, key, value)
    assert node[key] == value
    assert json.dumps(mapping) == '{"foo": {"bar": {"baz": "bacon"}}}'
    key = 'foo:bar:baz:more'
    set_tree_node(node, key, value)
    assert node[key] == value

# Generated at 2022-06-24 03:21:08.004902
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    t['foo:bar:baz'] = 'fubar'
    assert t['foo:bar:baz'] == 'fubar'



# Generated at 2022-06-24 03:21:14.374263
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    # Prepare
    mytree = {'a': {'b': {'c': 'd'}}}
    t = Tree(mytree)
    # Run & check
    assert t['a:b:c'] == 'd'
    assert t['a:b:c:d:e'] is None

    t['a:b:c'] = ['a', 'b', 'c']
    assert t['a:b:c'] == ['a', 'b', 'c']

# Generated at 2022-06-24 03:21:16.965962
# Unit test for constructor of class Tree
def test_Tree():
    from nose.tools import assert_equal
    tree = Tree()
    assert_equal(tree.get('foo:bar'), tree.get('foo').get('bar'))



# Generated at 2022-06-24 03:21:24.297507
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    >>> d = {}
    >>> set_tree_node(d, 'quux', 1)
    {'quux': 1}

    >>> set_tree_node(d, 'foo:bar', 2)
    {'foo': {'bar': 2}}

    >>> set_tree_node(d, 'foo:baz', 1)
    {'foo': {'baz': 1, 'bar': 2}}

    >>> set_tree_node(d, 'foo', None)
    {'foo': None}

    """



# Generated at 2022-06-24 03:21:35.109923
# Unit test for function set_tree_node
def test_set_tree_node():
    a = {}
    set_tree_node(a, 'a:A:B:C:D', 3)
    assert a == {'a': {'A': {'B': {'C': {'D': 3}}}}}
    set_tree_node(a, 'a:e:f:g', 7)
    assert a == {'a': {'A': {'B': {'C': {'D': 3}}}, 'e': {'f': {'g': 7}}}}


if __name__ == "__main__":
    test_set_tree_node()


# Generated at 2022-06-24 03:21:38.050841
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree()
    t['a']['b']['c']['d'] = 1
    assert t['a']['b']['c']['d'] == 1



# Generated at 2022-06-24 03:21:47.450106
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    # create a registry tree
    registry = RegistryTree()

    registry.register('a', 'b', 'c')
    registry.set('a', 'b', 'd')
    registry.get('a', 'b')
    registry.set('a:b:c', 'd')

    registry.register('a:c', 'b')

    registry.get('a:c')
    registry.get('a:c', 'b')

    registry.register('a:b:c:d', 'b')

    registry.get('a:b:c:d')

    registry.register('a:b:d:c', 'b')

    registry.get('a:b:d:c')

    registry.set('a:b:d:c', 'b', 'd')


# Generated at 2022-06-24 03:21:54.666367
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree_obj = Tree()
    try:
        tree_obj.__setitem__('a')
    except TypeError as exc:
        assert 'method takes exactly 3 arguments (2 given)' == str(exc)
    else:
        assert False, "Did not raise"
    try:
        tree_obj.__setitem__('a', 'b', 1)
    except TypeError as exc:
        assert '\'int\' object is not iterable' == str(exc)
    else:
        assert False, "Did not raise"
    try:
        tree_obj.__setitem__(1, 'a', 'b')
    except TypeError as exc:
        assert '\'int\' object is not iterable' == str(exc)
    else:
        assert False, "Did not raise"

# Generated at 2022-06-24 03:22:01.055711
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    tree = RegistryTree()
    tree.register('model', 'foo', namespace='storage')
    tree.register('model', 'bar', namespace='storage')
    tree.register('model', 'barf', namespace='storage')
    tree.register('controller', 'baz', namespace='storage')
    tree.register('controller', 'bam', namespace='storage')
    tree.register('controller', 'bomb', namespace='storage')

    tree = RegistryTree()
    tree.register('model', 'other:foo', namespace='storage')
    tree.register('model', 'other:bar', namespace='storage')
    tree.register('model', 'other:barf', namespace='storage')
    tree.register('controller', 'other:baz', namespace='storage')
    tree.register('controller', 'other:bam', namespace='storage')
    tree.register

# Generated at 2022-06-24 03:22:03.788221
# Unit test for constructor of class Tree
def test_Tree():
    """Tests for `Tree`."""
    tree = Tree()
    tree['a:b:c'] = 'd'
    assert tree['a']['b']['c'] == 'd'



# Generated at 2022-06-24 03:22:06.732037
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    r = RegistryTree()
    r.register('one:two:three:four:five', 'success')
    assert r.get('one:two:three:four:five') == 'success'



# Generated at 2022-06-24 03:22:07.434636
# Unit test for function set_tree_node
def test_set_tree_node():
    pass

# Generated at 2022-06-24 03:22:10.505082
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    fruits = Tree()
    fruits.__setitem__('yellow:banana', 'banana')

# Generated at 2022-06-24 03:22:14.282913
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    test_Tree = Tree(initial={'a': {'b': 'c'}})
    assert test_Tree.__getitem__('a:b') == test_Tree.__getitem__('a')['b']
    assert test_Tree.__getitem__('a:b') == test_Tree['a']['b']



# Generated at 2022-06-24 03:22:20.312742
# Unit test for function set_tree_node
def test_set_tree_node():
    namespace = 'test'
    data = []

    value = 'foo'
    set_tree_node(data, 'foo', value)
    assert data[0]['foo'] == value

    value = 'bar'
    set_tree_node(data, 'foo:bar', value)
    assert data[0]['foo']['bar'] == value

    value = 'baz'
    set_tree_node(data, ':foo:bar:baz', value)
    assert data[0]['foo']['bar']['baz'] == value

    value = 'foobar'
    set_tree_node(data, ':foo:bar:baz:qux', value)
    assert data[0]['foo']['bar']['baz']['qux'] == value

# Generated at 2022-06-24 03:22:25.290239
# Unit test for constructor of class Tree
def test_Tree():
    """
    Test simple constructor and basic functionality of Tree class
    """
    test_tree = Tree()
    test_tree['a'] = 1
    test_tree['a']['b'] = 2
    test_tree['a']['b']['c'] = 3



# Generated at 2022-06-24 03:22:30.323768
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()
    tree['a'] = 1
    assert tree.get('a') == 1, '__setitem__ failed'



# Generated at 2022-06-24 03:22:33.680841
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    a = RegistryTree()
    a.register('b', 'c')
    assert a['b'] == 'c'
    a.register('b:d:e', 'f')
    assert a['b']['d']['e'] == 'f'
    # _assert(a.tree['b']['d']['e'] == 'f')



# Generated at 2022-06-24 03:22:41.402173
# Unit test for constructor of class Tree
def test_Tree():
    tree = Tree(namespace='foon')
    assert tree.namespace == 'foon'
    tree['test'] = 'test'
    assert tree['test'] == 'test'
    assert tree['test'] == tree.get('test')
    assert tree['test'] == tree.get('foon:test')
    assert tree.get('bar') is None
    try:
        tree['bar']
    except KeyError as exc:
        assert 'bar' == exc.args[0]
    assert tree.get('bar', 'baz') == 'baz'



# Generated at 2022-06-24 03:22:51.527596
# Unit test for function get_tree_node
def test_get_tree_node():
    import json
    import yaml

    # Some helpful test data
    data = {
        'one': {
            'two': {
                'three': 'three-value'
            },
            'three': 'three-value',
            'list': [1, 2, 3],
        },
        'two': {
            'three': 'three-value',
            'list': [1, 2, 3],
        },
        'list': [1, 2, 3],
    }

    # Test for list handling
    data_json = json.dumps(data)
    data_yaml = yaml.dump(data)

    # Read tests
    assert get_tree_node(data, 'one:two:three') == 'three-value'

# Generated at 2022-06-24 03:22:56.481247
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    """Simple unit testing function with doctest."""
    tree = Tree()
    tree.__setitem__("a", "b")
    assert tree == {"a": "b"}



# Generated at 2022-06-24 03:22:57.148468
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    assert isinstance(RegistryTree(), RegistryTree)

# Generated at 2022-06-24 03:23:03.985383
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree(initial=tree(), initial_is_ref=True)

    # We should be able to set data on a tree.
    assert tree.register('hello', 'world') == tree

    # We should be able to set data on a tree with a namespace.
    assert tree.register('hello', 'world', namespace='foo') == tree

    # We should not be able to modify data through the tree view.
    tree['hello'] = 'world'  # But we should be able to modify data in tree directly.

    # We should be able to retrieve data from tree.
    assert tree.get('hello') == 'world'


if __name__ == '__main__':
    from pprint import pprint
    pprint(test_Tree___setitem__())

# Generated at 2022-06-24 03:23:10.422762
# Unit test for function get_tree_node
def test_get_tree_node():
    test_case = Tree({
        'test': {
            'test1': {
                'test2': 'success'
            }
        }
    })

    assert get_tree_node(test_case, 'test:test1:test2') == 'success'
    assert get_tree_node(test_case, 'test3:test4') == _sentinel

# Generated at 2022-06-24 03:23:18.338648
# Unit test for constructor of class Tree
def test_Tree():
    from pprint import pprint
    tree = Tree(initial={
        'a': {
            'b': {
                'c': 'd'
            }
        }
    })

# Generated at 2022-06-24 03:23:27.662057
# Unit test for function set_tree_node
def test_set_tree_node():
    tmp1 = collections.defaultdict(collections.defaultdict)
    tmp2 = collections.defaultdict(collections.defaultdict)
    tmp3 = collections.defaultdict(collections.defaultdict)
    tmp3['test']['test2']['test3']['test4'] = 'tmp'
    set_tree_node(tmp1, 'test:test2:test3:test4', 'tmp')
    set_tree_node(tmp2, 'test:test2', {'test3': {'test4': 'tmp'}})
    assert tmp1 == tmp2, 'setting dict tree nodes does not work'
    assert tmp1 == tmp3

# Generated at 2022-06-24 03:23:31.876615
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = {
        'foo': tree(),
    }
    set_tree_node(mapping, 'foo:bar:baz', 'fizzbuzz')
    assert mapping['foo']['bar']['baz'] == 'fizzbuzz'



# Generated at 2022-06-24 03:23:35.377497
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree = Tree()
    tree.foo.bar.zir = 'test'
    assert tree.foo.bar.zir == 'test'
    assert tree['foo:bar:zir'] == 'test'



# Generated at 2022-06-24 03:23:39.776928
# Unit test for function tree
def test_tree():
    """Test function tree"""
    tree = tree()
    assert tree
    tree.update({'a': {'b': 'c'}})
    assert tree['a']['b'] == 'c'
    tree['a']['b'] = 'd'
    assert tree['a']['b'] == 'd'



# Generated at 2022-06-24 03:23:49.835500
# Unit test for function tree
def test_tree():
    t = tree()
    t['a']['b'] = 'c'
    assert t['a:b'] == 'c'
    assert set_tree_node(t, 'a:b', 'd') == t['a']
    assert t['a:b'] == 'd'
    d = collections.defaultdict(lambda: collections.defaultdict(int))
    d[1][2] = 3
    assert d[1][2] == 3
    d = Tree()
    d[1][2] = 3
    assert d[1][2] == 3
    assert d['1:2'] == 3
    d = Tree()
    d.update(dict(a=dict(b=dict(c=dict(d=dict(e=1))))))
    assert d['a:b:c:d:e'] == 1

# Generated at 2022-06-24 03:23:52.456428
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    rt = RegistryTree(namespace='foo')
    rt.register('bar', 'i_am_shrubbery')
    assert rt['foo:bar'] == 'i_am_shrubbery'

# Generated at 2022-06-24 03:23:59.030254
# Unit test for function tree
def test_tree():
    t = tree()
    t[1][2][3] = True
    assert t[1][2][3]

    t[1][3][3] = True
    t[2][2][3] = True
    t[2][2][3] = False
    assert t[1][3][3] and not t[2][2][3]

    t[1][2][3][4] = True
    assert t[1][2][3][4]

# Generated at 2022-06-24 03:24:04.048583
# Unit test for function tree
def test_tree():
    assert get_tree_node({}, 'a:b:c') == _sentinel
    assert get_tree_node({'a': {}}, 'a:b:c') == _sentinel
    assert get_tree_node({'a': {'b': {}}}, 'a:b:c') == _sentinel
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c:d') == 'd'

# Generated at 2022-06-24 03:24:09.089705
# Unit test for constructor of class Tree
def test_Tree():
    tree = Tree()
    assert tree.namespace is None

    tree = Tree(namespace='foo')
    assert tree.namespace == 'foo'

    tree = Tree(initial={'foo:bar': 'baz'}, namespace='foo')
    assert tree['bar'] is 'baz'

