

# Generated at 2022-06-24 03:14:14.747748
# Unit test for function set_tree_node
def test_set_tree_node():
    import pytest
    registry = tree()
    registry['foo:bar']['baz'] = 'boom'
    assert registry['foo:bar']['baz'] == 'boom'
    with pytest.raises(KeyError):
        _ = registry['foo:b']['baz']



# Generated at 2022-06-24 03:14:17.962214
# Unit test for constructor of class Tree
def test_Tree():
    tree = Tree()
    tree[':a'] = 1
    tree[':b'] = 2
    tree[':a:c'] = 3
    assert tree == {':a': {'c': 3}, ':b': 2}



# Generated at 2022-06-24 03:14:22.258355
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    rt = RegistryTree()
    rt.register('poo:1:2:3:4', 'poopoo')
    assert rt.get('poo:1:2:3:4') == 'poopoo'


if __name__ == '__main__':
    test_RegistryTree()

# Generated at 2022-06-24 03:14:31.604161
# Unit test for function tree
def test_tree():
    # Quick test
    t = tree()
    assert t == {}

    t[1][2] = 3
    t[1][3] = 5

    assert t[1] == {2: 3, 3: 5}
    assert t[1][3] == 5
    assert t[1][2] == 3

    # Multilevel
    t = tree()
    t['a']['b']['c'] = 'd'

    assert t['a'] == {'b': {'c': 'd'}}
    assert t['a']['b'] == {'c': 'd'}
    assert t['a']['b']['c'] == 'd'



# Generated at 2022-06-24 03:14:42.532427
# Unit test for function get_tree_node
def test_get_tree_node():
    # Existing
    assert get_tree_node({'foo': {'bar': 'Baz'}}, 'foo:bar') == 'Baz'
    assert get_tree_node({'foo': {'bar': 'Baz'}}, 'foo:bar', parent=True) == {'bar': 'Baz'}

    # Not existing
    try:
        get_tree_node({'foo': {'bar': 'Baz'}}, 'foo:baz')
    except KeyError:
        pass
    else:
        raise AssertionError('Should raise KeyError')

    # Non existing, with default
    assert get_tree_node({'foo': {'bar': 'Baz'}}, 'foo:baz', default=None) is None


if __name__ == '__main__':
    test_get_

# Generated at 2022-06-24 03:14:43.931104
# Unit test for function set_tree_node
def test_set_tree_node():
    pass



# Generated at 2022-06-24 03:14:48.085992
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    assert RegistryTree() == Tree()
    assert RegistryTree({1: {2: {3: 4}}}) == Tree({1: {2: {3: 4}}})



# Generated at 2022-06-24 03:14:54.898625
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    a = Tree()
    a["1:2:3:4:5:6:7:8:9"] = "testing"
    b = a["1:2:3:4:5:6:7:8:9"]

    assert b == "testing"

# Generated at 2022-06-24 03:14:58.125308
# Unit test for function set_tree_node
def test_set_tree_node():
    mytree = {}
    set_tree_node(mytree, 'fruit:apple:crisp', 'red')
    assert mytree['fruit']['apple']['crisp'] == 'red'
    assert mytree['fruit']['apple'] == {'crisp': 'red'}



# Generated at 2022-06-24 03:15:05.249674
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree()
    t['foo:bar:boo'] = 'abc'
    assert t['foo:bar:boo'] == 'abc'
    assert t == {'foo': {'bar': {'boo': 'abc'}}}

    t2 = Tree({'foo': {'bar': {'boo': 'abc'}}})
    assert t2['foo:bar:boo'] == 'abc'
    assert t2 == {'foo': {'bar': {'boo': 'abc'}}}

    t3 = Tree()
    assert t3 == {}
    t3['foo:bar:boo'] = 'abc'
    assert t3['foo:bar:boo'] == 'abc'
    assert t3 == {'foo': {'bar': {'boo': 'abc'}}}



# Generated at 2022-06-24 03:15:13.911469
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    MAPPING = {
        'foo': 'bar',
        'hello': {
            'world': '1'
        }
    }
    tree = Tree(initial=MAPPING, initial_is_ref=True)
    # "no namespace given"
    tree['hello:world'] = '2'
    assert MAPPING['hello']['world'] == '2'
    # "namespace given"
    tree['hello:world', 'hello'] = '3'
    assert MAPPING['hello']['world'] == '3'
    # "no namespace given, but Tree has own"
    tree.namespace = 'hello'
    tree['world'] = '4'
    assert MAPPING['hello']['world'] == '4'



# Generated at 2022-06-24 03:15:21.224414
# Unit test for function set_tree_node
def test_set_tree_node():

    foo = tree()
    set_tree_node(foo, 'bar:bar2:bar3', 'abc')
    assert foo['bar']['bar2']['bar3'] == 'abc'

    foo = tree()
    set_tree_node(foo, 'bar:bar2:bar4', 'abc')
    assert foo['bar']['bar2']['bar4'] == 'abc'

    foo = tree()
    set_tree_node(foo, 'bar:bar2:bar3', 'abc')
    assert foo['bar']['bar2']['bar3'] == 'abc'



# Generated at 2022-06-24 03:15:27.580217
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'one': {
            'two': {
                'three': {
                    'four': 'FOUR'
                }
            }
        }
    }

    assert get_tree_node(mapping, 'one') == {
        'two': {
            'three': {
                'four': 'FOUR'
            }
        }
    }
    assert get_tree_node(mapping, 'one:two') == {
        'three': {
            'four': 'FOUR'
        }
    }
    assert get_tree_node(mapping, 'one:two:three') == {'four': 'FOUR'}
    assert get_tree_node(mapping, 'one:two:three:four') == 'FOUR'

# Generated at 2022-06-24 03:15:29.047307
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()
    tree.__setitem__('a:b:c:d:e', 12)
    assert tree['a:b:c:d:e'] == 12



# Generated at 2022-06-24 03:15:31.477210
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    mapping = {}
    tree = Tree(mapping)
    tree["fubar"] = "This is a test"
    get_tree_node(mapping, "fubar")
    pass

# Generated at 2022-06-24 03:15:34.942211
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    # Let's populate a tree:
    t = Tree({'foo': {'bar': {'baz': 3}}})

    # Now, let's test the method __getitem__ of the class Tree
    assert t["foo:bar:baz"] == 3
    assert t["foo:bar:baz:qux"] == {}

# Generated at 2022-06-24 03:15:42.120102
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    value = 5

    # Test: default namespace
    t[ 'test' ] = value
    t.register( 'test2', value )
    assert t['test'] == value
    assert t['test2'] == value
    assert t.namespace is None

    # Test: specified namespace
    namespace = 'foo'
    t = Tree( namespace = namespace )
    t[ 'test' ] = value
    t.register( 'test2', value )
    assert t['test'] == value
    assert t['test2'] == value
    assert t.namespace == namespace

    # Test: specified namespace
    namespace = 'foo'
    t = Tree( namespace = namespace )
    t[ 'test' ] = value
    t.register( 'test2', value )
    assert t['test'] == value

# Generated at 2022-06-24 03:15:48.167490
# Unit test for function tree
def test_tree():
    tree = Tree()
    tree['hello:world:abc'] = 'abc'
    tree['hello:world:def'] = 'def'
    tree['hello:world:ghi'] = 'ghi'
    tree['hello:world:jkl'] = 'jkl'
    tree['foo:bar:baz'] = 'baz'
    tree['foo:bar:zog'] = 'zog'
    tree['foo:bar:zog:zog'] = 'zog'
    assert tree['hello:world:abc'] == 'abc'
    assert tree['hello:world:def'] == 'def'
    assert tree['hello:world:ghi'] == 'ghi'
    assert tree['hello:world:jkl'] == 'jkl'
    assert tree['foo:bar:baz'] == 'baz'
   

# Generated at 2022-06-24 03:15:53.544458
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    """Unit test for method __setitem__ of class Tree"""
    tree = Tree()
    tree.__setitem__('test:test:test', 'azerty')
    assert tree['test:test:test'] == 'azerty'



# Generated at 2022-06-24 03:15:55.367142
# Unit test for constructor of class Tree
def test_Tree():
    example = {'a': 1, 'b': 1}
    tree = Tree(initial=example)
    assert dict(tree) == example



# Generated at 2022-06-24 03:15:59.442447
# Unit test for constructor of class Tree
def test_Tree():
    tree = Tree()
    tree['foo']['bar'] = 3
    tree['bar']['foo'] = 5
    assert tree['foo']['bar'] == 3
    assert tree['bar']['foo'] == 5

    # Ops, test failed. So, it returns a new Tree, not 3.
    # That's the reason why we need to traverse the tree with 'get'
    # assert tree['foo'] == 3

    print('Passed test_Tree')



# Generated at 2022-06-24 03:16:07.527540
# Unit test for function tree
def test_tree():
    d = tree()
    d['foo:bar:baz'] = 2
    assert d['foo:bar:baz'] == 2
    assert d['foo']['bar']['baz'] == 2

    d['foo:bar:baz'] = 3
    assert d['foo:bar:baz'] == 3
    assert d['foo']['bar']['baz'] == 3

    d['foo']['bar']['baz'] = 4
    assert d['foo:bar:baz'] == 4
    assert d['foo']['bar']['baz'] == 4



# Generated at 2022-06-24 03:16:13.645306
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree_obj = Tree()
    tree_obj.update({'foo': 'bar'})
    assert tree_obj['foo'] == 'bar'
    tree_obj.update({'foo': {'bar': 'baz'}})
    assert tree_obj['foo:bar'] == 'baz'
    try:
        tree_obj['foo:bar:baz'] == 'qux'
    except KeyError:
        pass


registry = RegistryTree()

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 03:16:17.283148
# Unit test for function tree
def test_tree():
    t = tree()
    t['adj']['quick'] = '1'
    t['adv']['quick'] = '2'
    t['noun']['fox']['quick'] = '3'
    print(t)
    print(t['noun']['fox'])
    print(t['adv']['quick'])
    print(t['adj']['quick'])
    print(t.keys())



# Generated at 2022-06-24 03:16:24.270149
# Unit test for function set_tree_node
def test_set_tree_node():
    import unittest
    import json

    class TestSetTreeNode(unittest.TestCase):

        @classmethod
        def setUpClass(cls):
            cls.test_node = {
                    'foo': {
                        'bar': {}
                        }
                    }

        def test_set(self):
            set_tree_node(self.test_node, 'foo:bar:baz', 'value')
            self.assertEqual(self.test_node['foo']['bar']['baz'], 'value')

        def test_set_overwrite(self):
            set_tree_node(self.test_node, 'foo:bar:baz', 'overwrite')
            self.assertEqual(self.test_node['foo']['bar']['baz'], 'overwrite')



# Generated at 2022-06-24 03:16:34.393976
# Unit test for function set_tree_node
def test_set_tree_node():
    # Initialize tree dict
    tree_dict = collections.defaultdict(collections.OrderedDict)

    tree_dict_expected = collections.defaultdict(collections.OrderedDict, {
        'a': collections.OrderedDict([
            ('b', collections.OrderedDict([
                ('c', collections.OrderedDict([
                    ('d', collections.OrderedDict([
                        ('e', [True, False, True])]))]))]))
        ])
    })

    # Set and get node
    set_tree_node(tree_dict, 'a:b:c:d:e', [True, False, True])
    set_tree_node(tree_dict, 'a:b:c:d:e:f', [True, False, True])

    # Assert operation is successful

# Generated at 2022-06-24 03:16:43.426153
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    t['a', 'b', 'c'] = 1
    assert isinstance(t, collections.defaultdict)
    assert t == {'a': {'b': {'c': 1}}}
    t['a', 'b', 'd'] = 2
    assert t == {'a': {'b': {'c': 1, 'd': 2}}}
    assert t['a', 'd'] == Tree
    assert t['a', 'b'] == {'c': 1, 'd': 2}
    assert t['a', 'b', 'c'] == 1
    return True



# Generated at 2022-06-24 03:16:49.974842
# Unit test for function tree
def test_tree():
    tr = tree()
    tr['a']['b']['c'] = 1
    tr['a']['b']['f'] = 2

    assert tr['a']['b']['c'] == 1
    assert tr['a']['b']['f'] == 2
    assert tr['a']['b'] == {'c': 1, 'f': 2}



# Generated at 2022-06-24 03:17:00.740856
# Unit test for function tree
def test_tree():
    mapping = tree()
    assert mapping is not None
    mapping[0][0] = 42
    assert mapping.data == {0: {0: 42}}
    assert get_tree_node(mapping, 0) == {0: 42}
    assert get_tree_node(mapping, 0, default=False) == {0: 42}
    assert get_tree_node(mapping, '0:0') == 42
    assert get_tree_node(mapping, '0:0', default=False) == 42

    assert get_tree_node(mapping, '0:1', default=False) is False
    get_tree_node(mapping, '0:1')  # KeyError

    set_tree_node(mapping, '4:4', 1)

# Generated at 2022-06-24 03:17:03.540948
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree()
    t['a'] = 1
    t['b']['c'] = 2

# Generated at 2022-06-24 03:17:11.727371
# Unit test for function tree
def test_tree():
    tree = Tree()
    _tree = collections.defaultdict(Tree)
    assert tree == _tree == {}

    tree = Tree({'foo': 'bar'})
    _tree = collections.defaultdict(Tree, {'foo': 'bar'})
    assert tree == _tree

    tree = Tree({'foo': 'bar'})
    tree_node = tree['foo']
    assert tree_node == 'bar'

    tree = Tree({'foo': {'bar': 'baz'}})
    tree_node = tree['foo:bar']
    assert tree_node == 'baz'

    tree = Tree({'foo': {'bar': {'baz': 'quux'}}})
    tree_node = tree['foo:bar:baz']
    assert tree_node == 'quux'

    tree = Tree()
   

# Generated at 2022-06-24 03:17:17.044004
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    """Unit test for :class:Tree."""
    tree = RegistryTree(namespace='registry')
    tree.register('test', 'hello world')
    assert tree.get('registry:test') == 'hello world'

# Generated at 2022-06-24 03:17:19.508423
# Unit test for function tree
def test_tree():
    t = tree()
    t['a']['b']['c'] = '!?'
    assert t['a']['b']['c'] == '!?'


if __name__ == '__main__':
    test_tree()

# Generated at 2022-06-24 03:17:25.444947
# Unit test for function get_tree_node
def test_get_tree_node():
    d = {
        'cool': {
            'beans': 'beans'
        },
        'not': {
            'cool': 'beans'
        }
    }

    assert get_tree_node(d, 'cool') == {'beans': 'beans'}
    assert get_tree_node(d, 'cool:beans') == 'beans'
    assert get_tree_node(d, 'not:cool') == 'beans'
    assert get_tree_node(d, 'not:cool', parent=True) == {'cool': 'beans'}



# Generated at 2022-06-24 03:17:31.109082
# Unit test for constructor of class Tree
def test_Tree():
    # Tree initialization
    tree_dict = Tree()
    assert 'data' in tree_dict

    # Tree like access
    tree_dict[':parent'] = 'value'


if __name__ == '__main__':
    test_Tree()

# Generated at 2022-06-24 03:17:35.458136
# Unit test for function set_tree_node
def test_set_tree_node():
    test = Tree()
    test['blah:blah:blah:blah'] = 'foo'
    assert test['blah:blah']['blah'] == 'foo'
    test['blah:blah:blah'] = 'bar'
    assert test['blah:blah']['blah'] == 'bar'
    assert test['blah'] == {'blah': {'blah': 'bar'}}



# Generated at 2022-06-24 03:17:36.929154
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    """Unit test for constructor of class RegistryTree."""
    tree = RegistryTree(initial={'a': 1, 'b': 2})
    assert tree['a'] == 1
    assert tree['b'] == 2



# Generated at 2022-06-24 03:17:38.465331
# Unit test for constructor of class Tree
def test_Tree():
    obj = Tree(namespace='foo')
    assert obj.namespace == 'foo'
    assert obj == {}



# Generated at 2022-06-24 03:17:44.964831
# Unit test for function tree
def test_tree():
    """Unit test for function tree."""
    t = tree()
    t['foo']['bar'] = 1
    t['foo']['baz'] = 2
    t['foo']['qux']['bar'] = 3
    assert t['foo']['bar'] == 1
    assert t['foo']['baz'] == 2
    assert t['foo']['qux']['bar'] == 3



# Generated at 2022-06-24 03:17:53.211774
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    t['test:test1'] = 1
    t['test:test2'] = 2
    t['test1:test1'] = 1
    t['test2:test2'] = 2
    assert t == {'test': {'test1': 1, 'test2': 2}, 'test1': {'test1': 1}, 'test2': {'test2': 2}}
    assert t['test:test1'] == 1
    assert t['test:test2'] == 2
    assert t['test'] == {'test1': 1, 'test2': 2}
    assert t['test1'] == {'test1': 1}
    assert t['test2'] == {'test2': 2}



# Generated at 2022-06-24 03:17:58.332472
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    class MyClass(RegistryTree):
        pass

    MyClass.register('foo', 'bar')
    assert MyClass['foo'] == 'bar'

    # Test namespace prefix
    MyClass.register('foo', 'BAR', namespace='bar')
    assert MyClass.get('foo', namespace='bar') == 'BAR'

# Generated at 2022-06-24 03:18:00.172054
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree()
    t['parent:child'] = 'foo'
    assert t['parent:child'] == 'foo'
    assert t['parent']['child'] == 'foo'
    assert t['parent']['not:there'] is None



# Generated at 2022-06-24 03:18:08.852279
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    from nose.tools import assert_equals
    mytree = Tree()
    mytree['a'] = 'apple'
    assert_equals(mytree.get('a:b:c:d:e:f', 'ghost'), 'ghost')
    assert_equals(mytree.get('a:b:c:d:e:f', default='ghost'), 'ghost')

    assert_equals(mytree.get('a:b:c:d:e:f'), None)
    assert_equals(mytree.get('a'), 'apple')

# Generated at 2022-06-24 03:18:11.687392
# Unit test for constructor of class Tree
def test_Tree():
    _tree = Tree()
    _tree['a']['b']['c'] = 'd'
    assert _tree['a:b:c'] == 'd'
    assert _tree['A']['B']['C'] == 'd'



# Generated at 2022-06-24 03:18:21.679396
# Unit test for function tree
def test_tree():
    """Unit test for function tree and get_tree_node."""
    t = tree()
    t['a']['b']['c'] = 'test'
    assert t == {'a': {'b': {'c': 'test'}}}
    assert get_tree_node(t, 'a:b:c') == 'test'
    assert get_tree_node(t, 'a:b') == {'c': 'test'}
    assert get_tree_node(t, 'a:b:c', parent=True) == {'c': 'test'}
    assert get_tree_node(t, 'a:b:c:d') == _sentinel



# Generated at 2022-06-24 03:18:28.454413
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    registry = RegistryTree()
    registry.register('app:models:user:name', 'String')
    registry.register('app:models:user:age', 'Integer')
    assert registry.get('app:models:user:name') == 'String'
    assert registry.get('app:models:user:age') == 'Integer'
    assert registry.get('app:models:user:sex') == None
    assert registry.get('app:models:user:sex', 'String') == 'String'



# Generated at 2022-06-24 03:18:32.497663
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Ensure that set_tree_node sets a node correctly.
    """
    test = {}

    set_tree_node(test, 'one:two:three', 'Test')

    assert test['one']['two']['three'] == 'Test'



# Generated at 2022-06-24 03:18:36.609303
# Unit test for function set_tree_node
def test_set_tree_node():
    import sys
    registry_tree = RegistryTree()
    registry_tree.register('a:b:c:d:e', 'test')
    registry_tree.register('a:b:c:d:f', 'test2')
    registry_tree.register('a:b:c:d:g', 'test2')
    sys.stderr.write('Node: %s\n' % registry_tree['a:b:c:d'])
    sys.stderr.write('Node: %s\n' % registry_tree['a:b:c:d:e'])


# Generated at 2022-06-24 03:18:43.860364
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    from ham.test import TestCase
    from ham.test.data import get_std_dummy

    class DummyController(object):
        pass

    dummy = DummyController()

    # Only instantiate a dummy for testing purposes.
    dummy.Registry = RegistryTree(namespace='Registry')
    dummy.Registry['some:key'] = get_std_dummy()
    assert dummy.Registry['some:key'].a == dummy.Registry['some:key'].a
    dummy.Registry['some:namespace:key'] = get_std_dummy()
    dummy.Registry['some:namespace:key'] = get_std_dummy()
    assert dummy.Registry['some:namespace:key'].b == dummy.Registry['some:namespace:key'].b


# Generated at 2022-06-24 03:18:47.358541
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    r = RegistryTree()
    r.register('a.b.c', 'val')
    assert r['a.b.c'] == 'val'
    assert r['b.c'] == r['a.b.c']



# Generated at 2022-06-24 03:18:51.839594
# Unit test for constructor of class Tree
def test_Tree():
    # Initialize tree
    t = Tree()

    # Demonstrate namespace
    t['foo'] = {'bar': 'baz'}
    t.namespace = 'foo'
    t['bar'] = 'asdf'
    assert t['bar'] == 'asdf'
    assert t['foo:bar'] == 'baz'

# Generated at 2022-06-24 03:18:54.189506
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree = Tree()
    set_tree_node(tree, 'x:y', 42)
    assert tree['x:y'] == 42



# Generated at 2022-06-24 03:18:56.624946
# Unit test for function tree
def test_tree():
    root = tree()
    root['key1']['key2'] = 'value'
    assert root['key1']['key2'] == 'value'



# Generated at 2022-06-24 03:19:03.791806
# Unit test for function set_tree_node
def test_set_tree_node():
    d = {'a': 1, 'b': 2, 'c': 3}
    assert set_tree_node(d, 'd', 4) == {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert set_tree_node(d, 'b:d', 4) == {'a': 1, 'b': {'d': 4}, 'c': 3}
    assert set_tree_node(d, 'c:d', 4) == {'a': 1, 'b': 2, 'c': {'d': 4}}



# Generated at 2022-06-24 03:19:08.311748
# Unit test for function set_tree_node
def test_set_tree_node():
    a = {}
    set_tree_node(a, 'foo:bar', 'foobar')
    set_tree_node(a, 'foo:baz', 'foobaz')
    assert a == {'foo': {'bar': 'foobar', 'baz': 'foobaz'}}


# Generated at 2022-06-24 03:19:12.461875
# Unit test for function tree
def test_tree():

    # Setup
    t = tree()
    assert isinstance(t, collections.defaultdict)
    t[('a', 'b')] = 123
    assert t['a']['b'] == 123
    assert get_tree_node(t, 'a:b') == 123



# Generated at 2022-06-24 03:19:18.429526
# Unit test for function set_tree_node
def test_set_tree_node():
    t = {}
    set_tree_node(t, 'x:y:z', 1)
    set_tree_node(t, 'x:y:z', 2)
    assert 2 == t['x']['y']['z']



# Generated at 2022-06-24 03:19:21.137126
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = dict(a=1, b=dict(c=2))

    assert get_tree_node(mapping, 'a', default=None) == 1
    assert get_tree_node(mapping, 'b:c', default=None) == 2



# Generated at 2022-06-24 03:19:26.681294
# Unit test for function set_tree_node
def test_set_tree_node():
    n = set_tree_node({}, 'a:b:c:d', 'hello')
    assert n == {
        'a': {
            'b': {
                'c': {
                    'd': 'hello',
                },
            },
        },
    }



# Generated at 2022-06-24 03:19:33.338786
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    from pprint import pprint
    tree = Tree()

    tree.update({
        'a': {},
        'b': {},
        'c': {},
    })

    tree['a'].update({
        'd': {},
        'e': {},
        'f': {},
    })

    tree['a']['e'].update({
        'g': {},
        'h': {},
    })

    tree['a']['g'] = 'i'

    pprint(tree)

    assert tree['a']['g'] == 'i'



# Generated at 2022-06-24 03:19:42.324960
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree = Tree()
    tree['name'] = 'fanta'
    tree['soda'] = 'awesome!'
    tree['tagline'] = 'orange you glad its fanta?'
    assert tree['name'] == 'fanta'
    assert tree['soda'] == 'awesome!'
    assert tree['tagline'] == 'orange you glad its fanta?'
    assert tree['not:a:real:node'] is None
    assert tree.get('not:a:real:node') is None
    assert tree.get('not:a:real:node', 'default value') == 'default value'
    assert tree.get('not:a:real:node', None) is None

# Generated at 2022-06-24 03:19:54.076690
# Unit test for function tree
def test_tree():
    tree = Tree({
        'a': 1,
        'b': {
            'x': 1,
            'y': 3,
            'z': {
                'hello': 'world',
            }
        }
    })

    assert tree.get('b:z:hello') == 'world'
    assert tree.get('b:z:hello:nonono') is _sentinel
    assert tree.get('b:z:hello:nonono', False) is False
    assert tree.get('b:z:hello', parent=True)['hello'] == 'world'
    assert tree['b:z:hello'] == 'world'
    assert tree['b:z:hello:nonono'] is _sentinel
    assert tree['c:new:x'] == set_tree_node(tree, 'c:new:x', Tree())



# Generated at 2022-06-24 03:19:59.973020
# Unit test for function get_tree_node
def test_get_tree_node():
    # Prepare
    mapping = {
        'a': {
            'b': {
                'c': 'hellyeah'
            }
        }
    }
    expected = 'hellyeah'
    # Execute
    actual = get_tree_node(mapping, 'a:b:c')
    # Assert
    assert expected == actual



# Generated at 2022-06-24 03:20:06.714520
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Test result of set_tree_node function.

    Arguments: None

    Returns: None
    """
    mapping = {}
    set_tree_node(mapping, 'foo:bar:baz', 'qux')
    assert mapping['foo:bar:baz'] == 'qux'
    set_tree_node(mapping, 'foo:bar:qux', 'quux')
    assert mapping['foo:bar']['baz'] == 'qux'
    assert mapping['foo:bar']['qux'] == 'quux'



# Generated at 2022-06-24 03:20:13.792467
# Unit test for function tree
def test_tree():
    t = tree()
    t['level1_node']['level2_node']['level3_node'] = 'this is a value'
    assert t['level1_node']['level2_node']['level3_node'] == 'this is a value'

    t['level1_node']['level2_node']['level3_node'] = 'another value'
    assert t['level1_node']['level2_node']['level3_node'] == 'another value'

    t['level1_node']['level2_node']['level3_node'] = 'yet a third value'
    assert t['level1_node']['level2_node']['level3_node'] == 'yet a third value'
    # print(dict(t))


# Generated at 2022-06-24 03:20:18.730064
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    import logging

    logger = logging.getLogger(__name__)

    logger.info('Testing method __setitem__ of class Tree')
    logger.info('Creating a new RegistryTree')
    a = RegistryTree()
    logger.info('Registering test_key under namespace test_namespace')
    a.__setitem__('test_key', 'test_value', namespace='test_namespace')
    logger.info('Registering test_key under namespace test_namespace2')
    a.__setitem__('test_key', 'test_value2', namespace='test_namespace2')
    logger.info('Searching for test_key in namespace test_namespace2')
    result = a.__getitem__('test_key', namespace='test_namespace2')

# Generated at 2022-06-24 03:20:27.978732
# Unit test for function tree
def test_tree():
    t = tree()

    t['a']['b'] = 'c'
    assert t['a:b'] == 'c'
    assert t['a']['b'] == 'c'
    assert t['a']['b'] == get_tree_node(t, 'a:b')
    assert t['a'] == get_tree_node(t, 'a')
    assert t['a'] == get_tree_node(t, 'a', parent=True)

    t['a']['b']['c'] = 'd'
    assert t['a:b:c'] == 'd'
    print(t)
    assert t['a'] == get_tree_node(t, 'a:b:c', parent=True)

    t['a']['b']['c'] = 'd'


# Generated at 2022-06-24 03:20:34.353700
# Unit test for function tree
def test_tree():
    t = tree()
    assert isinstance(t, collections.Mapping)
    assert isinstance(t, collections.defaultdict)

    t['1'] = 1
    assert t['1'] == 1

    t['a:b:c']['1'] = 2
    assert t['a']['b']['c']['1'] == 2
    assert t.get('a:b:c:2') is None
    assert t.get('a:b:c:2', 123) == 123



# Generated at 2022-06-24 03:20:39.478203
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {1: {2: {3: {4: 5}}}}
    assert get_tree_node(tree, '1') == {2: {3: {4: 5}}}
    assert get_tree_node(tree, '1:2') == {3: {4: 5}}
    assert get_tree_node(tree, '1:2:3') == {4: 5}
    assert get_tree_node(tree, '1:2:3:4') == 5
    assert get_tree_node(tree, '1:2:3:4:5') is _sentinel
    assert get_tree_node(tree, '1:2:3:4:5', default=4) == 4



# Generated at 2022-06-24 03:20:50.246836
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'one': {
            'two': 'three',
        },
    }
    assert get_tree_node(tree, 'one') == {'two': 'three'}
    assert get_tree_node(tree, 'one:two') == 'three'
    assert get_tree_node(tree, 'one:two', default=None) == 'three'
    assert get_tree_node(tree, 'lol:fake:key', default=None) is None
    assert get_tree_node(tree, 'lol') == collections.defaultdict(dict)
    assert get_tree_node(tree, 'lol:fake:key') == collections.defaultdict(dict)
    with pytest.raises(KeyError):
        get_tree_node(tree, 'lol:fake:key', default=_sentinel)

# Generated at 2022-06-24 03:20:56.417661
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    """
    >>> test = RegistryTree()
    >>> test.register = 1
    >>> test.register = 2
    >>> test.register = 3
    >>> set_tree_node(test, 'a:b', 1)
    {'a': {'b': 1}}
    >>> test
    {'a': {'b': 1}, 'register': 3}
    >>> test.register
    3
    """
    pass

# Generated at 2022-06-24 03:21:01.935097
# Unit test for function tree
def test_tree():
    """
    >>> tree = tree()
    >>> tree['foo']['bar']['baz'] = 1
    >>> assert tree == {'foo': {'bar': {'baz': 1}}}
    >>>
    >>> assert tree['foo']['bar']['baz'] == 1
    >>> assert tree['foo']['bar']['qux'] == {}
    >>> assert tree['foo']['quux']['quuz'] == {}
    """



# Generated at 2022-06-24 03:21:05.360034
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    registry_tree = RegistryTree()
    registry_tree.register('tree', 'yay')
    assert registry_tree.get('tree') == 'yay'



# Generated at 2022-06-24 03:21:13.859837
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = Tree()
    tree['foo'] = 'Hello'
    tree['foo:bar'] = 'World'
    tree['foo:baz'] = 'Yip'
    tree['bar:baz'] = 'Yup'
    assert get_tree_node(tree, 'foo') == 'Hello'
    assert get_tree_node(tree, 'foo:bar') == 'World'
    assert get_tree_node(tree, 'bar:baz') == 'Yup'

if __name__ == '__main__':
    test_get_tree_node()

# Generated at 2022-06-24 03:21:19.865803
# Unit test for constructor of class Tree
def test_Tree():
    """Test the Tree class by using it as a dict"""
    t = Tree(foo='bar')
    t['testing:as:a:dict'] = 'baz'
    assert t['testing:as:a:dict'] == 'baz'
    assert t['foo'] == 'bar'
    assert t['testing']['as']['a']['dict'] == 'baz'



# Generated at 2022-06-24 03:21:25.537449
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    t['a'] = 1
    t['a:b'] = 2
    t['a:b:c'] = 3
    t['d'] = 1
    t['d:e:f'] = 2
    t['d:e:g'] = 2
    t['d:e:h'] = 2
    t['d:e:g:h'] = 3
    t['d:j'] = 2
    t['d:j:k'] = 2
    t['d:j:k:l'] = 3
    t['d:j:k:m'] = 4


# Generated at 2022-06-24 03:21:33.787593
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    rt = RegistryTree()
    assert isinstance(rt, dict)
    rt = RegistryTree(namespace='blarg')
    assert isinstance(rt, dict)
    rt = RegistryTree(initial_is_ref=dict())
    assert isinstance(rt, dict)
    rt = RegistryTree(initial_is_ref=dict(), namespace='blarg')
    assert isinstance(rt, dict)
    rt = RegistryTree(initial=dict(), namespace='blarg')
    assert isinstance(rt, dict)



# Generated at 2022-06-24 03:21:35.978661
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    result = RegistryTree(namespace='a.b')
    assert result.namespace == 'a.b'



# Generated at 2022-06-24 03:21:40.313187
# Unit test for constructor of class Tree
def test_Tree():

    tree = Tree({
        'foo': {
            'bar': 'baz',
        },
        'spam': 'ham',
    })

    assert set(tree.keys()) == {'foo', 'spam'}

    assert Tree(initial_is_ref=tree) == tree



# Generated at 2022-06-24 03:21:42.537084
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree = Tree()
    tree['one:two'] = [1, 2, 3]
    assert tree['one:two'] == [1, 2, 3]



# Generated at 2022-06-24 03:21:51.041089
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    def assert_dict_equal(d1, d2):
        assert sorted(set(d1.__dict__.keys()) & set(['data', '__weakref__'])) == sorted(set(d2.__dict__.keys()) & set(['data', '__weakref__']))
        assert sorted(set(d1.keys()) & set(['_namespace', '__weakref__'])) == sorted(set(d2.keys()) & set(['_namespace', '__weakref__']))
        assert d1._namespace == d2._namespace
        assert d1.data == d2.data


# Generated at 2022-06-24 03:21:59.390596
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'a': {
            'b': {
                'c': 2
            }
        }
    }

    assert get_tree_node(tree, 'a:b:c') == 2
    tree['a']['b']['d'] = 3

    assert get_tree_node(tree, 'a:b:d') == 3
    assert get_tree_node(tree, 'a:b:c:d') == None

    with pytest.raises(KeyError):
        get_tree_node(tree, 'a:b:e')

# Generated at 2022-06-24 03:22:01.380005
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    test_instance = Tree()
    test_instance.__setitem__(key=None, value=None)
    assert True



# Generated at 2022-06-24 03:22:04.890911
# Unit test for function set_tree_node
def test_set_tree_node():
    # Fixture
    data = {}

    # Test
    set_tree_node(data, 'a:b:c', 'd')

    # Assert it worked
    assert data['a']['b']['c'] == 'd'



# Generated at 2022-06-24 03:22:13.938206
# Unit test for constructor of class Tree
def test_Tree():
    from collections import defaultdict
    from types import GeneratorType
    test = Tree({'foo': 'bar'})
    assert test['foo'] == 'bar'
    assert isinstance(test['foo'], str)
    assert isinstance(test['spam'], Tree)
    test['foo:bar'] = 'baz'
    assert test['foo:bar'] == 'baz'
    assert isinstance(test['foo'], dict)
    assert isinstance(test['foo']['bar'], str)
    assert isinstance(test.get('foo', default='ham'), dict)
    assert test.get('foo', default='ham') == test['foo']
    assert test.get('eggs', default='ham') == 'ham'
    test = Tree({'foo': 'bar'}, namespace='foo')

# Generated at 2022-06-24 03:22:20.059522
# Unit test for constructor of class Tree
def test_Tree():
    import unittest
    import json

    class TestTree(unittest.TestCase):
        def test_tree(self):
            tre = Tree()
            data = {
                'a': {
                    'b': {
                        'c': {
                            'd': 'e',
                            'f': 'g'
                        },
                        'h': {
                            'i': 'j'
                        }
                    }
                }
            }
            tre.update(data)
            self.assertEqual(tre.get('a:b:c:d'), 'e')
            self.assertEqual(tre.get('a:b:c:f'), 'g')
            self.assertEqual(tre.get('a:b:h:i'), 'j')

# Generated at 2022-06-24 03:22:26.451807
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree()
    t['a'] = 1
    t['b']['b2'] = 2
    t['b']['d'] = 4
    t['c'] = 3
    print(t)
    assert t['a'] == 1
    assert t['b']['b2'] == 2
    assert t['b']['d'] == 4
    assert t['c'] == 3



# Generated at 2022-06-24 03:22:32.820511
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Tests basic function set_tree_node
    """
    tree = {}
    set_tree_node(tree, 'hello', 'world')
    assert tree == {'hello': 'world'}
    set_tree_node(tree, 'test:test:test', 'blah')
    assert tree == {
        'hello': 'world',
        'test': {
            'test': {
                'test': 'blah'
            }
        }
    }


if __name__ == '__main__':
    test_set_tree_node()

# Generated at 2022-06-24 03:22:41.816744
# Unit test for function tree
def test_tree():
    # TESTS
    t = tree()
    t[u'a'][u'b'][u'c'] = 1
    t[u'a'][u'b'][u'd'] = 2
    t[u'a'][u'x'] = 3
    t[u'e'] = 4
    assert len(t) == 3
    assert t[u'a'][u'b'][u'c'] == 1
    assert t[u'a'][u'x'] == 3
    assert t[u'e'] == 4
    assert t[u'a:b:c'] == 1
    assert t[u'a:x'] == 3
    assert t[u'e'] == 4
    assert len(t[u'a']) == 2

# Generated at 2022-06-24 03:22:44.063966
# Unit test for function set_tree_node
def test_set_tree_node():
    # Test tree with 3 layers.
    tree = {}
    set_tree_node(tree, 'layer1:layer2:layer3', 'value')
    assert tree['layer1']['layer2']['layer3'] == 'value'



# Generated at 2022-06-24 03:22:51.492770
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    r = RegistryTree()
    r.register(r.namespace, 'foo', 'bar')
    assert r.get('foo') == 'bar'
    r.register('nope', 'foo', 'bar')
    assert r.get('nope:foo') == 'bar'
    assert r.get('foo') == 'bar'
    r.namespace = 'bar'
    assert r.get('foo') == 'bar'
    assert r.get('bar:foo') == 'bar'

# Generated at 2022-06-24 03:22:53.306040
# Unit test for constructor of class Tree
def test_Tree():
    test = Tree()
    assert test is test['a']['b']['c']



# Generated at 2022-06-24 03:22:57.911231
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    rt = RegistryTree({'a': {'b': {'c': 'd'}}})
    assert rt['a:b:c'] == 'd'
    assert rt['a:b'] == {'c': 'd'}
    assert rt['a'] == {'b': {'c': 'd'}}
    assert len(rt) == 1



# Generated at 2022-06-24 03:23:03.651084
# Unit test for function set_tree_node
def test_set_tree_node():
    d = {}
    set_tree_node(d, 'a', 1)
    assert d == {'a': 1}
    set_tree_node(d, 'a:b', 2)
    assert d == {'a': {'b': 2}}
    set_tree_node(d, 'a:b:c', 3)
    assert d == {'a': {'b': {'c': 3}}}

    d = {}
    set_tree_node(d, 'a:b:c', 3)
    assert d == {'a': {'b': {'c': 3}}}



# Generated at 2022-06-24 03:23:14.377690
# Unit test for function get_tree_node
def test_get_tree_node():
    from nose.tools import assert_equal, assert_raises

    mapping = {
        'a': {'b': {'c': 1}},
        'd': 2,
    }

    # Valid paths
    assert_equal(get_tree_node(mapping, 'a:b:c'), 1)
    assert_equal(get_tree_node(mapping, 'd'), 2)
    assert_equal(get_tree_node(mapping, 'd', default=0), 2)
    assert_equal(get_tree_node(mapping, 'd', default=0, parent=True), mapping)
    assert_equal(get_tree_node(mapping, 'd', parent=True)['a'], mapping['a'])

    # Invalid paths

# Generated at 2022-06-24 03:23:18.929819
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()
    tree['a', 'b', 'c'] = 1
    assert tree['a', 'b', 'c'] == 1



# Generated at 2022-06-24 03:23:25.122327
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    tree = RegistryTree(namespace='test_namespace')
    tree.register('object', 'value')
    assert tree.get('object') == 'value'
    assert tree.get('test_namespace:object') == 'value'



# Generated at 2022-06-24 03:23:28.208452
# Unit test for function set_tree_node
def test_set_tree_node():
    a = {}
    set_tree_node(a, 'a:b:c', True)
    print(a)
    assert a == {'a': {'b': {'c': True}}}

# Generated at 2022-06-24 03:23:37.616229
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': 'baz',
        }
    }

    assert get_tree_node(mapping, 'foo:bar') == 'baz'
    assert get_tree_node(mapping, 'foo:bar:baz') is _sentinel

    mapping = {
        'foo': {
            'bar': [
                'baz',
                'boo',
            ],
        },
        'yookoo': 'hi'
    }

    assert get_tree_node(mapping, 'foo:bar:1') == 'boo'
    assert get_tree_node(mapping, 'yookoo') == 'hi'

    mapping = tree()
    mapping['foo']['bar'] = 'baz'


# Generated at 2022-06-24 03:23:41.663032
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree_ = Tree()
    tree_.update({
        'a': 1,
        'b': 2,
        'c': 3,
    })
    assert tree_ == {'a': 1, 'b': 2, 'c': 3}

    tree_['a'] = 10
    assert tree_ == {'a': 10, 'b': 2, 'c': 3}
    assert tree_.a == 10

    tree_['b'] = 20
    assert tree_ == {'a': 10, 'b': 20, 'c': 3}
    assert tree_.b == 20

    tree_['c'] = 30
    assert tree_ == {'a': 10, 'b': 20, 'c': 30}
    assert tree_.c == 30

    tree_['d'] = 4

# Generated at 2022-06-24 03:23:48.241117
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    """
    This tests the method `Tree.__setitem__`.
    """
    tree = Tree()
    tree['a'] = 1
    tree['b'] = 2
    tree['a:b'] = 3
    tree['a:b:c'] = 4

    assert tree['a'] == 1
    assert tree['b'] == 2
    assert tree['a:b'] == 3
    assert tree['a:b:c'] == 4

# Generated at 2022-06-24 03:23:57.909615
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    ca_tree = Tree({
        'ca': {
            'ab': {
                'calgary': '403',
                'edmonton': '780',
            },
            'bc': {
                'vancouver': '604',
            },
        },
    })

    assert ca_tree['ca:bc:vancouver'] == '604'
    assert ca_tree['ca:bc:vancouver', '604'] == '604'
    assert ca_tree['ca:bc:vancouver', '604'] == '604'
    assert ca_tree['ca:bc:vancouver', '604'] == '604'

    try:
        ca_tree['ca:bc:vancouve']
    except KeyError:
        pass
    else:
        assert False, 'Failed to raise KeyError for invalid key value.'



# Generated at 2022-06-24 03:24:02.278552
# Unit test for constructor of class Tree
def test_Tree():
    test_tree = Tree({'foo': {'bar': 'baz'}})
    assert test_tree.get('foo:bar') == 'baz'
    test_tree['foo:bar'] = 'baz2'
    assert test_tree.get('foo:bar') == 'baz2'
    assert test_tree.get('foo:barx') == Tree()



# Generated at 2022-06-24 03:24:09.041069
# Unit test for function set_tree_node
def test_set_tree_node():
    """ Unit test for Tree.register """

    # Create a tree
    t = tree()

    # Set value at the root
    set_tree_node(t, 'key', 'value')
    assert t['key'] == 'value'

    # Set value at dimension 2
    set_tree_node(t, 'dim1:dim2', 'value')
    assert t['dim1']['dim2'] == 'value'

    # Set value at dimension 3
    set_tree_node(t, 'dim1:dim2:dim3', 'value')
    assert t['dim1']['dim2']['dim3'] == 'value'

