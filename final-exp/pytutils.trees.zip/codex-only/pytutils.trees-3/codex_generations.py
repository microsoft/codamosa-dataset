

# Generated at 2022-06-24 03:14:15.092224
# Unit test for function set_tree_node
def test_set_tree_node():
    t = tree()
    set_tree_node(t, 'a:b', 1)
    assert t['a']['b'] == 1
    set_tree_node(t, 'a:c:d', 2)
    assert t['a']['c']['d'] == 2
    assert t['a']['c']['d'] == 2



# Generated at 2022-06-24 03:14:16.537447
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree()
    t['a'] = '1'
    t['b'] = '2'
    assert t['a'] == '1'
    assert t['b'] == '2'



# Generated at 2022-06-24 03:14:21.380143
# Unit test for function set_tree_node
def test_set_tree_node():
    tree_ = tree()
    set_tree_node(tree_, "one:two:three", "3")
    assert tree_["one"]["two"]["three"] == "3"



# Generated at 2022-06-24 03:14:30.297723
# Unit test for function get_tree_node
def test_get_tree_node():
    t = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    assert get_tree_node(t, 'a:b:c') == 'd'
    assert get_tree_node(t, 'a:b') == {'c': 'd'}

    with pytest.raises(KeyError):
        get_tree_node(t, 'z:z:z')

    assert get_tree_node(t, 'z:z:z', default='q') == 'q'



# Generated at 2022-06-24 03:14:33.826420
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree(namespace='foo')
    tree['bar:spam'] = True
    assert tree['bar:spam'] is True



# Generated at 2022-06-24 03:14:39.616604
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree = Tree({'a': {'b': 3}})
    assert tree.get('a:b') == 3
    assert tree['a:b'] == 3
    # TODO Fails on 2.6 because 2.6's dict raises KeyError even though
    # 2.6's defaultdict doesn't.
    #with pytest.raises(KeyError):
    #    tree.get('a:c')
    with pytest.raises(KeyError):
        tree['a:c']



# Generated at 2022-06-24 03:14:45.536084
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    t.__setitem__('a', 'b')
    t.__setitem__('a:b', 'c')
    assert t['a'] == 'b'
    assert t['a:b'] == 'c'



# Generated at 2022-06-24 03:14:47.519342
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree()
    assert t == {}



# Generated at 2022-06-24 03:14:50.498598
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    registry = RegistryTree({'a': {'b': {'c': 'c'}}}, namespace='root')
    value = registry['a:b:c'] == 'c'
    assert value



# Generated at 2022-06-24 03:14:54.861037
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    """
    Unit test for method __getitem__ of class Tree
    """
    test_tree = Tree()
    test_tree['abc'] = 'abc'
    result = test_tree['abc']
    assert result == 'abc'


# Generated at 2022-06-24 03:15:01.893602
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree(namespace='ns')

    # Normal
    tree['record', 'deviceId'] = 123
    assert tree.get('ns:record:deviceId') == 123

    # Namespace specified.

# Generated at 2022-06-24 03:15:11.059917
# Unit test for function get_tree_node
def test_get_tree_node():
    # Set up
    mapping = {'a': {'b': {'c': {'d': {'e': {'f': 'value'}}}}}}

    # Run tests
    assert get_tree_node(mapping, 'a:b:c') == {'d': {'e': {'f': 'value'}}}
    assert get_tree_node(mapping, 'a:b:c:d:e:f') == 'value'
    assert get_tree_node(mapping, 'a:b:c:d:e:f:g') is _sentinel
    assert get_tree_node(mapping, 'b') is _sentinel



# Generated at 2022-06-24 03:15:15.633526
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Test the set_tree_node function
    """
    tree = Tree()
    tree.set_tree_node('test', 'value')
    tree.set_tree_node('one:two:three', 'value')
    tree.set_tree_node('one:two:three', 'value2')
    assert tree.get_tree_node('one:two:three') == 'value2'
    assert tree.get_tree_node('one:two:three:four') == 'value'
    assert tree.get_tree_node('one:two:three:four') == 'value'

# Generated at 2022-06-24 03:15:17.962928
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    a = Tree()
    a.__setitem__('b', 'c')

# Generated at 2022-06-24 03:15:22.066180
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree = Tree({'a': {'b': 1, 'c': '2'}})
    assert tree['a:b'] == 1
    assert tree['a:c'] == '2'
    assert tree['a'] == {'b': 1, 'c': '2'}

# Generated at 2022-06-24 03:15:31.076976
# Unit test for function set_tree_node
def test_set_tree_node():
    dct = {}
    set_tree_node(dct, 'a:b:c:d', 1)
    assert dct == {
        'a': {
            'b': {
                'c': {
                    'd': 1,
                },
            },
        },
    }

    set_tree_node(dct, 'a:b:e:f:g:h', 2)
    assert dct == {
        'a': {
            'b': {
                'c': {
                    'd': 1,
                },
                'e': {
                    'f': {
                        'g': {
                            'h': 2,
                        },
                    },
                },
            },
        },
    }

    dct = {}

# Generated at 2022-06-24 03:15:35.039562
# Unit test for constructor of class Tree
def test_Tree():
    """Unit test for `Tree` constructor."""
    t = Tree()
    print(t)


if __name__ == '__main__':
    test_Tree()

# Generated at 2022-06-24 03:15:42.120022
# Unit test for function set_tree_node
def test_set_tree_node():
    t1 = tree()
    set_tree_node(t1, 'a:b:c', 'd')
    assert t1['a']['b']['c'] == 'd', (
        "Function set_tree_node failed. Expected t1['a']['b']['c'] == 'd'; got %s" % t1['a']['b']['c']
    )

    class T2(Tree):
        pass

    t2 = T2()
    t2.set_tree_node('a:b:c', 'd')

# Generated at 2022-06-24 03:15:45.837703
# Unit test for function tree
def test_tree():
    expected = {
        'a': {
            'b': {
                'c': 'foo',
            },
        },
    }
    t = tree()
    t['a']['b']['c'] = 'foo'
    assert t == expected, repr(t)


if __name__ == '__main__':
    test_tree()

# Generated at 2022-06-24 03:15:56.819732
# Unit test for function tree
def test_tree():
    data = tree()
    data['a']['b']['c'] = 2
    data['a']['b']['d'] = 2
    data['a']['b']['e'] = 2
    data['a']['b']['f'] = 2

    data['b']['c'] = 2

    data['a']['b']['c'] = 2
    data['a']['c']['b'] = 2
    data['a']['c']['b']['c'] = 2
    data['a']['c']['b']['c']['d'] = 2
    data['a']['c']['b']['c']['d']['e'] = 2

# Generated at 2022-06-24 03:16:01.976782
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    # Setup
    tree = Tree()
    tree['parents:id:1:kids:id:2'] = 2
    tree['parents:id:2:kids:id:3'] = 3

    # Exercise
    actual = tree['parents:id:1:kids:id:2']

    # Verify
    assert actual == 2



# Generated at 2022-06-24 03:16:05.594263
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    registry = RegistryTree(initial={}, namespace='test')
    registry.register('test:test', 'test')
    assert registry['test:test'] == 'test'
    assert registry['test:test', 'test'] == 'test'



# Generated at 2022-06-24 03:16:07.259586
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    registry = RegistryTree()
    registry.register('foo', 'bar')
    registry.register('foobar.blah', 'hooga')
    assert registry['foo'] == 'bar'
    assert registry['foobar']['blah'] == 'hooga'



# Generated at 2022-06-24 03:16:10.135003
# Unit test for function set_tree_node
def test_set_tree_node():
    d = {}
    d = set_tree_node(d, 'a:b:c', 'd')
    assert d == {'a': {'b': {'c': 'd'}}}



# Generated at 2022-06-24 03:16:19.390494
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree()
    t.register('a:b', 'c')
    t.register('a:b:c', 'd')
    assert t.get('a:b') == 'c'
    assert t.get('a:b:c') == 'd'
    assert t.get('a:b:c:d') == {}
    assert t['a:b:c:d:e:f:g:h'] is None
    assert t.get('a:b:c:d:e:f:g:h', namespace='foo') is None
    t.register('a', 'b', namespace='foo')
    assert t.get('a', namespace='foo') == 'b'


if __name__ == "__main__":
    test_Tree___getitem__()

# Generated at 2022-06-24 03:16:23.621879
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    import pytest
    t = Tree()
    t['test'] = 'test'  # Quickly set a node as we know that works
    pytest.raises(KeyError, t.__getitem__, 'foo')

    assert t.__getitem__('test') == 'test'
    assert t.__getitem__('foo', default='foo') == 'foo'

# Generated at 2022-06-24 03:16:33.403431
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Test `set_tree_node` functionality.
    """
    # Testing TreeNode
    node_test = tree()
    node_test.update(
        {'a': {'b': 2}, 'c': {'d': 3}}
    )
    assert node_test == {'a': {'b': 2}, 'c': {'d': 3}}
    assert set_tree_node(node_test, 'a:b', 5) == {'b': 5}
    assert node_test == {'a': {'b': 5}, 'c': {'d': 3}}

    # Testing RegistryTreeNode
    registry_node_test = RegistryTree()
    registry_node_test.register('a:b', 2)
    assert registry_node_test == {'a': {'b': 2}}


# Unit

# Generated at 2022-06-24 03:16:39.862589
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    t['a'] = 'b'
    assert t['a'] == 'b'
    t['a:b'] = 'c'
    assert t['a']['b'] == 'c'



# Generated at 2022-06-24 03:16:45.762743
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = tree()
    set_tree_node(mapping, 'key:sub:sub2', 'value')

    assert mapping.get('key') is not None
    assert mapping['key'].get('sub') is not None
    assert mapping['key']['sub']['sub2'] == 'value'

# Generated at 2022-06-24 03:16:49.025184
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree()
    t[':foo:bar'] = 'baz'

    assert t[':foo:bar'] == 'baz'



# Generated at 2022-06-24 03:17:00.161680
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    from pytest import raises
    from pprint import pprint
    from pprint import pformat
    from collections import OrderedDict
    from itertools import permutations

    # TODO Pre-register for caching.

# Generated at 2022-06-24 03:17:02.492903
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    import pytest

    tree = Tree()
    tree['a'] = 'one'

    assert tree['a'] == 'one'


if __name__ == '__main__':
    test_Tree___setitem__()

# Generated at 2022-06-24 03:17:09.644442
# Unit test for constructor of class Tree
def test_Tree():
    """Test simple tree defaultdict."""
    test_dict = {'a': {'b': {'c': 'd'}}, 'f': 'g'}
    t = Tree(test_dict)
    assert t == test_dict, ("{0} != {1}".format(test_dict, t))
    test_dict2 = {'a': {'b': {'e': 'f'}}, 'h': 'i'}
    t = Tree(test_dict2)
    assert t == test_dict2, ("{0} != {1}".format(test_dict2, t))
    t = Tree()
    assert t == {}, ("{0} != {}".format(t))



# Generated at 2022-06-24 03:17:12.885136
# Unit test for constructor of class Tree
def test_Tree():
    tree = Tree({'a': {'b': 1}})
    assert tree.data['a']['b'] == 1

    tree = Tree(initial_is_ref=True)
    assert tree.data == {}


#
#------------------------------------------------------------------------------
#

# Generated at 2022-06-24 03:17:15.808028
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    t.__setitem__('foo:bar:baz', 'value')
    assert t['foo:bar:baz'] == 'value'



# Generated at 2022-06-24 03:17:19.703913
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree_ = Tree()
    for i in (1, 2, 3, 4, 5, 6, 7, 8, 9, 10):
        tree_['d1:d2:d3:d4'] = i

    for i in range(8, 0, -1):
        assert tree_['d1:d2:d3:d4'] == i
        assert tree_['d1:d2:d3:d4'] == i


# Generated at 2022-06-24 03:17:23.050589
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    # Arrange
    key = 'foo'
    value = 'bar'
    m = Tree()
    m[key] = value

    # Act
    result = m[key]
    print(result)

    # Assert
    assert result == value



# Generated at 2022-06-24 03:17:25.324934
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree()
    assert t.namespace == ''
    assert str(t.__class__) == "<class '__main__.Tree'>"
    assert t[':'] == t
    assert t['foo'] == t



# Generated at 2022-06-24 03:17:26.896911
# Unit test for constructor of class Tree
def test_Tree():
    RegistryTree()

# Generated at 2022-06-24 03:17:32.973862
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    registry = RegistryTree()
    registry.register("database", "mysql")
    registry.register("database:user", "root")
    registry.register("database:password", "secr3t")

    assert registry['database'] == 'mysql'
    assert registry['database:user'] == 'root'
    assert registry['database:password'] == 'secr3t'



# Generated at 2022-06-24 03:17:40.420592
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'foo': {
            'bar': {
                'baz': True,
                'buzz': False
            }
        }
    }

    # Test: direct key retrieval
    assert get_tree_node(tree, 'foo:bar:baz') is True

    # Test: access to non-existing key (default value)
    assert get_tree_node(tree, 'foo:bar:foo', default=False) is False

    # Test: access to non-existing key (KeyError)
    try:
        get_tree_node(tree, 'foo:bar:foo')
    except KeyError:
        pass
    else:
        raise AssertionError('KeyError not raised on invalid key')

    # Test: access to non-existing key (KeyError)

# Generated at 2022-06-24 03:17:44.737821
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    registry = RegistryTree()
    registry.register('foo', 'bar')
    registry.register('foo', 'baz', namespace='a')
    assert registry['foo'] == 'bar'

# Generated at 2022-06-24 03:17:49.842109
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    """Unit test for method __setitem__ of class `Tree`"""

    tree = Tree()
    tree['foo'] = 'bar'
    assert tree['foo'] == 'bar'
    tree['foo:bar'] = 'baz'
    assert tree['foo']['bar'] == 'baz'
    tree['foo:bar:baz'] = 'xoo'
    assert tree['foo']['bar']['baz'] == 'xoo'



# Generated at 2022-06-24 03:17:55.641029
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    r = Tree()
    r['a:b:c'] = 7
    assert r['a']['b']['c'] == 7
    r['a:b:c'] = 8
    assert r['a']['b']['c'] == 8



# Generated at 2022-06-24 03:17:57.135732
# Unit test for function tree
def test_tree():
    t = tree()
    t['a']['b'] = 1
    t['a:b'] = 2
    assert t['a']['b'] == 2



# Generated at 2022-06-24 03:18:01.508431
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    tree = RegistryTree(namespace='users')
    tree.register('foo')
    assert tree['users:foo'] is not None

# Generated at 2022-06-24 03:18:09.629976
# Unit test for function get_tree_node
def test_get_tree_node():
    d = Tree()
    d['a']['b']['c']['d'] = 'e'
    assert d['a:b:c:d'] == 'e'
    assert d['a:b:c:d'] == d['a']['b']['c']['d']

    # Test default value
    assert d.get_tree_node('a:b:c:g', default=1) == 1
    # Test KeyError
    try:
        d.get_tree_node('a:b:c:g')
    except KeyError:
        pass


# Generated at 2022-06-24 03:18:18.189325
# Unit test for function get_tree_node
def test_get_tree_node():
    d = {'a': {'b': 10}, 'b': 2}
    assert (get_tree_node(d, 'a:b') == 10)
    assert (get_tree_node(d, 'a:c', default=1) == 1)
    assert (get_tree_node(d, 'a') == {'b': 10})
    assert (get_tree_node(d, 'b') == 2)

    try:
        get_tree_node(d, 'a:c')
    except KeyError:
        pass
    else:
        raise AssertionError()



# Generated at 2022-06-24 03:18:28.405355
# Unit test for function get_tree_node
def test_get_tree_node():
    test_cases = (
        (
            {'A': {'B': {'C': {'D': 'E'}}}},
            'A:B:C:D',
            'E',
        ),
        (
            {'A': {'B': {'C': {'D': 'E'}}}},
            'A:B:C:D',
            'F',
            'F',
        ),
        (
            {'A': {'B': {'C': {'D': 'E'}}}},
            'A:B:C:DD',
            'F',
            'F',
        ),
        (
            {'A': {'B': {'C': {'D': 'E'}}}},
            'A:B:C:DD',
        ),
    )


# Generated at 2022-06-24 03:18:35.033714
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    a = Tree()
    a.foo = 'bar'
    assert a['foo'] == 'bar'
    assert a['foo:bar'] is None
    assert a.get('foo:bar') == []
    a['foo:bar'] = 'baz'
    assert a['foo:bar'] == 'baz'
    a['foo:bar:baz'] = 'foo'
    assert a['foo:bar:baz'] == 'foo'
    assert a['foo:bar:baz:foo'] is None



# Generated at 2022-06-24 03:18:44.583487
# Unit test for function tree
def test_tree():
    tree = tree()
    tree['a']['b']['c'] = 1
    tree['a']['b']['d'] = 2
    tree['a']['e'] = 3
    tree['d']['e']['f'] = 4
    assert tree['a']['b']['c'] == 1
    assert tree['a']['e'] == 3
    assert tree['d']['e']['f'] == 4
    assert tree['z'] == {}
    assert 'z' in tree

    # Test allowing same key to be used for different dimensions
    tree = tree()
    tree['a:b:c:d:e:f']['g'] = 1
    tree['a']['b']['c'] = 2

# Generated at 2022-06-24 03:18:47.884055
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    """Unit test for constructor of class RegistryTree"""
    tree = RegistryTree()
    tree.register(('foo', 'bar', 'baz'), 'quux')
    assert tree.get(('foo', 'bar', 'baz')) == 'quux'
    assert tree.get(('foo', 'bar', 'baz', 'quux')) is None
    assert tree.get(('foo', 'bar', 'baz', 'quux'), default='norf') == 'norf'
    assert tree.get('foo:bar') is None

# Generated at 2022-06-24 03:18:55.012874
# Unit test for function tree
def test_tree():
    root = tree()
    root['foo']['bar']['baz'] = 'quux'
    assert root['foo']['bar']['baz'] == 'quux'

    root['foo']['bar']['baz'] = 'baz'
    assert root['foo']['bar']['baz'] == 'baz'

    root['foo']['bar']['level'] == 'second'
    assert root['foo']['bar']['level'] == 'second'

    root['foo']['baz']['level'] == 'third'
    assert root['foo']['baz']['level'] == 'third'

    root['bar']['baz']['level'] == 'third'

# Generated at 2022-06-24 03:19:03.453309
# Unit test for function tree
def test_tree():
    t = tree()
    t['foo']['bar'] = 1
    assert t['foo']['bar'] == 1
    t['foo']['bar'] = 2
    assert t['foo']['bar'] == 2

    try:
        t['foo']['baz']
    except KeyError:
        pass
    else:
        raise Exception("Tree didn't fail")

    assert t['foo'].get('baz') is None

    t['bar'] = 3
    assert t['bar'] == 3

    t['foo']['baz'] = 4
    assert t['foo']['baz'] == 4

    assert t['foo'] == {'baz': 4, 'bar': 2}

    assert t == {'bar': 3, 'foo': {'baz': 4, 'bar': 2}}



# Generated at 2022-06-24 03:19:04.535775
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    reg = RegistryTree()
    assert reg
    assert isinstance(reg, RegistryTree)



# Generated at 2022-06-24 03:19:07.831412
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = RegistryTree(initial={'tester': '2'})
    assert t['tester'] == '2'
    assert t.get('tester') == '2'



# Generated at 2022-06-24 03:19:18.137984
# Unit test for function tree
def test_tree():
    t = tree()
    t['a']['1'] = 'A1'
    assert t['a']['1'] == 'A1'
    t['a:b']['1'] = 'AB1'
    assert t['a']['b']['1'] == 'AB1'
    assert t['a:b']['1'] == 'AB1'
    t['a']['c']['d'] = 'ACD'
    assert t['a:c:d'] == 'ACD'
    assert t['a:c:d:e'] == {}

# Generated at 2022-06-24 03:19:21.348725
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree(namespace='foo')
    t['bar'] = 'baz'
    assert t.get('bar') == 'baz'
    assert t.get('foo:bar') == 'baz'


if __name__ == '__main__':
    import pytest
    pytest.main([__file__, '-v'])

# Generated at 2022-06-24 03:19:25.661338
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}
    set_tree_node(tree, 'first:second:third', 'foo')
    assert tree == {'first': {'second': {'third': 'foo'}}}



# Generated at 2022-06-24 03:19:32.029194
# Unit test for function set_tree_node
def test_set_tree_node():
    foo = {}
    assert set_tree_node(foo, 'foo', 'blah') == foo
    assert foo['foo'] == 'blah'

    foo = {}
    assert set_tree_node(foo, 'foo:bar', 'blah') == foo['foo']
    assert foo['foo']['bar'] == 'blah'

    foo = {}
    assert set_tree_node(foo, 'foo:bar:baz', 'blah') == foo['foo']['bar']
    assert foo['foo']['bar']['baz'] == 'blah'



# Generated at 2022-06-24 03:19:37.460383
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = tree()
    set_tree_node(mapping, 'foo:bar:baz', 'test')

    # Sanity check
    assert mapping['foo']['bar']['baz'] == 'test'

    # This is a blackbox test, as there is no good way to assert
    # the state of the tree.



# Generated at 2022-06-24 03:19:45.489079
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    t[':foo'] = 'bar'
    assert t[':foo'] == 'bar'

    t['foo'] = 'bar'
    assert t['foo'] == 'bar'

    t['bar:foo'] = 'baz'
    assert t['bar:foo'] == 'baz'

    t['bar'] = 'baz'
    assert t['bar'] == 'baz'
    assert t['bar:foo'] == 'baz'
    assert t['foo'] == 'bar'
    assert t[''] == t
    assert t[':'] == t


if __name__ == '__main__':
    test_Tree___setitem__()

# Generated at 2022-06-24 03:19:50.370134
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    t['foo'] = 'bar'
    assert t['foo'] == 'bar'
    t['foo:bar'] = 'bar'
    assert t['foo:bar'] == 'bar'
    assert t['foo']['bar'] == 'bar'



# Generated at 2022-06-24 03:19:53.927137
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree({'a': {'a-a': {'a-a-a': {'a-a-a-a': 'foo'}}}})
    assert t.get('a:a-a:a-a-a:a-a-a-a') == 'foo'



# Generated at 2022-06-24 03:20:00.596381
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = tree()
    set_tree_node(mapping, 'foo:bar:baz', 'hello')
    assert mapping == {'foo': {'bar': {'baz': 'hello'}}}

    mapping = tree()
    set_tree_node(mapping, 'foo:bar', 'baz')
    assert mapping == {'foo': {'bar': 'baz'}}



# Generated at 2022-06-24 03:20:10.318207
# Unit test for function get_tree_node
def test_get_tree_node():
    a = {'b': {'c': {'d': 'e'}}}
    assert get_tree_node(a, 'b:c:d') == 'e'
    assert get_tree_node(a, 'b:c', default='f') == {'d': 'e'}
    assert get_tree_node(a, 'b:c', default=_sentinel) == {'d': 'e'}

    # Test parent
    assert get_tree_node(a, 'b:c', parent=True) == {'d': 'e'}
    assert get_tree_node(a, 'b:c:d', parent=True) == {'d': 'e'}
    assert get_tree_node(a, 'b:c:d:e', parent=True) == {'d': 'e'}

# Generated at 2022-06-24 03:20:17.203004
# Unit test for function tree
def test_tree():
    """
    Test tree, set_tree_node, and get_tree_node.
    """
    tree = {}

    set_tree_node(tree, 'foo', 'bar')
    assert get_tree_node(tree, 'foo') == 'bar'

    set_tree_node(tree, 'foo:bar', 'baz')
    assert get_tree_node(tree, 'foo:bar') == 'baz'

    assert get_tree_node(tree, 'foo:baz') is _sentinel

    # Unit test parent
    assert get_tree_node(tree, 'foo:baz', parent=True) == tree['foo']

    # Test default
    assert get_tree_node(tree, 'foo:baz', default='spam') == 'spam'

# Generated at 2022-06-24 03:20:19.814552
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree()
    t['a'] = 1
    t['b'] = 2
    assert t['a'] == 1
    assert t['b'] == 2

# Generated at 2022-06-24 03:20:22.898966
# Unit test for function set_tree_node
def test_set_tree_node():
    root = tree()
    set_tree_node(root, 'foo:bar:baz', 'cats')
    assert root.get('foo:bar:baz') == 'cats'



# Generated at 2022-06-24 03:20:31.681871
# Unit test for function get_tree_node
def test_get_tree_node():

    simple = {
        'a': {
            'a': 1,
            'b': 2
        },
        'b': {
            'a': 3,
            'b': 4
        }
    }

    assert get_tree_node(simple, 'a:a') == 1
    assert get_tree_node(simple, 'b:b') == 4

    assert get_tree_node(simple, 'c:c', default=99) == 99

    try:
        get_tree_node(simple, 'c:c')
    except KeyError:
        pass
    else:
        raise AssertionError('get_tree_node did not raise KeyError')



# Generated at 2022-06-24 03:20:35.241349
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    from pudb.remote import set_trace; set_trace()
    value = 'whatever'
    # test with missing key
    pass
    # test with exists key
    pass


if __name__ == '__main__':
    # test_Tree___getitem__()
    pass

# Generated at 2022-06-24 03:20:37.361416
# Unit test for constructor of class Tree
def test_Tree():
    tree = Tree()
    tree['one']['two']['three'] = "ABC"
    assert tree['one']['two']['three'] == "ABC"



# Generated at 2022-06-24 03:20:41.203138
# Unit test for constructor of class RegistryTree

# Generated at 2022-06-24 03:20:49.135065
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    t['a'] = 1
    t['b:c'] = 2
    t['d'] = 3
    t['e:f:g'] = 4
    t['e:h:i'] = 5

    assert t['a'] == 1
    assert t['b']['c'] == 2
    assert t['d'] == 3
    assert t['e']['f']['g'] == 4
    assert t['e']['h']['i'] == 5


if __name__ == '__main__':
    test_Tree___setitem__()

# Generated at 2022-06-24 03:20:53.193057
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = tree()
    set_tree_node(mapping, 'test:test2:test3', 'test4')
    assert mapping['test']['test2']['test3'] == 'test4'



# Generated at 2022-06-24 03:21:02.965879
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    from collections import defaultdict
    from collections import Mapping
    from types import MethodType
    from types import FunctionType
    from types import BuiltinFunctionType
    from types import NoneType
    from collections import Sequence
    from collections import Set
    from collections import Mapping
    from collections import MutableSet
    from collections import MutableMapping
    from collections import MutableSequence
    from operator import lt
    from operator import le
    from operator import eq
    from operator import ne
    from operator import gt
    from operator import ge
    from operator import length_hint
    from types import MethodType
    from operator import neg
    from operator import pos
    from operator import abs
    from operator import invert
    from operator import complex
    from operator import int
    from operator import float
    from operator import index
    from operator import truediv

# Generated at 2022-06-24 03:21:11.078024
# Unit test for constructor of class RegistryTree

# Generated at 2022-06-24 03:21:16.308254
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'first': 1,
        'second': {
            0: {
                'third': 2,
                'fourth': 4
            },
            1: {
                'third': 3,
                'fourth': 4
            }
        }
    }
    assert get_tree_node(mapping, 'second:1:third') == 3



# Generated at 2022-06-24 03:21:19.537139
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    registry = RegistryTree()
    registry.register('example', lambda: "Hello World!")
    assert registry.get('example')() == "Hello World!"


# Generated at 2022-06-24 03:21:23.204580
# Unit test for constructor of class Tree
def test_Tree():
    a = Tree()
    a['this'] = 'that'
    a.update({'tree': {'is': 'awesome'}})
    assert a['this'] == 'that'
    assert a['tree']['is'] == 'awesome'



# Generated at 2022-06-24 03:21:25.839944
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree(initial={'hello': 'world'})
    assert t['hello'] == 'world'



# Generated at 2022-06-24 03:21:28.748086
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    t['test1'] = 1
    assert t['test1'] == 1



# Generated at 2022-06-24 03:21:31.386310
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    import unittest as ut
    item = Tree(None)

    class TestTree___getitem__(ut.TestCase):
        pass

    raise ut.SkipTest

# Generated at 2022-06-24 03:21:36.169872
# Unit test for function set_tree_node
def test_set_tree_node():
    # Create mock tree
    mapping = collections.defaultdict(collections.defaultdict)

    # Inject some example data
    set_tree_node(mapping, 'a:b:c:d:e', 'hello')

    # Verify inserted
    assert mapping['a']['b']['c']['d']['e'] == 'hello'



# Generated at 2022-06-24 03:21:40.226477
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    t['a'] = 1
    t['b:a'] = 2
    t['b:c'] = 3
    # KeyError: 'a'
    # ValueError: too many values to unpack
    # t['a'] = value, namespace
    # t['a'] = value, namespace='b'



# Generated at 2022-06-24 03:21:49.384006
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    a = Tree()
    # This works
    a['foo'] = 'bar'
    assert a['foo'] == 'bar'
    # (this works)
    a['bar'] = {'baz': 'bas'}
    assert a['bar'] == {'baz': 'bas'}
    # This works
    a['bar:baz'] = 'baz'
    assert a['bar:baz'] == 'baz'
    assert a['bar'] == {'baz': 'baz'}
    # This DOES NOT work
    a['bar:baz:baz'] = 'baz'
    assert a['bar:baz:baz'] == 'baz'
    assert a['bar'] == {'baz': 'baz'}
    print(a)



# Generated at 2022-06-24 03:21:54.913200
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    expected = {
        'd': {
            'b': {
                'g': {
                    'f': {
                        'a': 1
                    }
                }
            },
            'a': 2
        }
    }
    t = Tree()
    t.update(expected)
    for key, value in t.items():
        assert(t[key] == value)



# Generated at 2022-06-24 03:21:57.529002
# Unit test for function tree
def test_tree():
    my_tree = tree()
    my_tree['foo']['bar']['baz'] = "Hello World"

# Generated at 2022-06-24 03:22:03.102932
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    t['foo'] = 'bar'
    assert t['foo'] == 'bar'
    t['foo'] = 'baz'
    assert t['foo'] == 'baz'
    t['foo'] = True
    assert t['foo'] is True
    assert t['foo:bar'] == {}
    t['foo:bar:baz'] = 'foo'
    assert t['foo:bar:baz'] == 'foo'



# Generated at 2022-06-24 03:22:11.568248
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree()
    t['a']['b']['c'] = 3

    assert t['a']['b']['c'] == 3
    assert t.get('a:b:c') == 3
    assert t.get('a:b:d') is _sentinel

    assert t['a']['b'].get('c') == 3
    assert t.get('a:b').get('c') == 3
    assert t['a'].get('b:c') == 3
    assert t.get('a').get('b:c') == 3

    assert t.get('a:b') is t['a'].get('b')
    assert t['a'].get('b') is t.get('a').get('b')

# Generated at 2022-06-24 03:22:21.291291
# Unit test for function set_tree_node
def test_set_tree_node():
    test_map = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }
    set_tree_node(test_map, 'a:b:c', 'e')
    # No change
    assert test_map == {
        'a': {
            'b': {
                'c': 'e'
            }
        }
    }

    set_tree_node(test_map, 'a:b:c', 'f')
    # No change
    assert test_map == {
        'a': {
            'b': {
                'c': 'f'
            }
        }
    }



# Generated at 2022-06-24 03:22:26.950715
# Unit test for constructor of class Tree
def test_Tree():
    tree = Tree()
    tree.register('mean', {'attr': 'mean'})
    tree.register('std', {'attr': 'std'})
    assert tree.get('mean') == {'attr': 'mean'}
    assert tree.get('std') == {'attr': 'std'}


test_Tree()

# Generated at 2022-06-24 03:22:31.114978
# Unit test for function set_tree_node
def test_set_tree_node():
    m = {}
    set_tree_node(m, 'a', 'b')
    assert m == {'a': 'b'}
    set_tree_node(m, 'c:d', 'e')
    assert m == {'a': 'b', 'c': {'d': 'e'}}



# Generated at 2022-06-24 03:22:38.795450
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    tree = RegistryTree({
        'foo': {
            'bar': 'foobar',
            'baz': 'foobaz'
        }
    })
    assert tree.get('foo') == {
        'bar': 'foobar',
        'baz': 'foobaz'
    }
    assert tree.get('foo:bar') == 'foobar'



# Generated at 2022-06-24 03:22:48.543987
# Unit test for function tree
def test_tree():
    tree = {
        'a': {
            'a': '1',
            'b': {
                'a': '2',
                'b': '3',
            }
        },
        'b': '4',
        'c': {
            'a': '5',
            'b': '6',
            'c': '7',
        },
    }
    assert get_tree_node(tree, 'a:a') == '1'
    assert get_tree_node(tree, 'a:b') == {'a': '2', 'b': '3'}
    assert get_tree_node(tree, 'a:c') is _sentinel
    assert get_tree_node(tree, 'a:c', 'X') == 'X'

# Generated at 2022-06-24 03:22:59.268501
# Unit test for function get_tree_node
def test_get_tree_node():
    treenode = {'bob': {'dylan': {'the': 1, 'times': 2}}}
    assert get_tree_node(treenode, 'bob:dylan:the') == 1
    assert get_tree_node(treenode, 'bob:dylan:the', default=_sentinel) == 1
    assert get_tree_node(treenode, 'bob:dylan:the', default=None) == 1
    assert get_tree_node(treenode, 'bob:dylan:foo') is None
    assert get_tree_node(treenode, 'bob:dylan:foo', default=None) is None
    assert get_tree_node(treenode, 'bob:dylan:foo', default=_sentinel) is None



# Generated at 2022-06-24 03:23:00.985775
# Unit test for constructor of class Tree
def test_Tree():
    Tree({'one': 1}, 'tree')
    Tree({'one': 1}, initial_is_ref=True)



# Generated at 2022-06-24 03:23:03.877907
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()
    assert tree is not None
    item = 'tree[foo]'
    value = 'bar'
    assert tree._namespace_key(item) == item
    tree.__setitem__(item, value)
    assert tree[item] == value



# Generated at 2022-06-24 03:23:11.025376
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    t['foo'] = 'bar'
    t['baz'] = 1
    t[':'] = 'bam'
    assert t['foo'] == 'bar'
    assert t['baz'] == 1
    assert t[':'] == 'bam'
    assert t[':foo'] == 'bar'
    assert t[':baz'] == 1
    assert t[':bam'] is None



# Generated at 2022-06-24 03:23:14.308065
# Unit test for constructor of class Tree
def test_Tree():
    # Create
    t = Tree({'apples': 'oranges'})

    # See
    assert t['apples'] == 'oranges'

    # Change
    t['apples'] = 'peaches'

    # See
    assert t['apples'] == 'peaches'



# Generated at 2022-06-24 03:23:17.609601
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    tree = RegistryTree(namespace='ns')
    tree.register('a', 'b')

    assert tree['a'] == 'b'
    assert tree.namespace == 'ns'
    assert tree._namespace_key('a') == 'ns:a'
    assert tree['ns:a'] == 'b'

# Generated at 2022-06-24 03:23:24.799898
# Unit test for function get_tree_node
def test_get_tree_node():
    testing_map = {
        'a': 1,
        'b:c': 2,
        'b:d': 3,
        'b:e:f': 4,
        'g': [],
    }

    assert get_tree_node(testing_map, 'a') == 1
    assert get_tree_node(testing_map, 'b:c') == 2
    assert get_tree_node(testing_map, 'b:d') == 3
    assert get_tree_node(testing_map, 'b:e:f') == 4

    assert get_tree_node(testing_map, 'a:non-existant', default=None) is None
    with pytest.raises(KeyError):
        get_tree_node(testing_map, 'a:non-existant')

    assert get_tree_node

# Generated at 2022-06-24 03:23:26.458566
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    assert RegistryTree.register is Tree.__setitem__



# Generated at 2022-06-24 03:23:30.289989
# Unit test for function tree
def test_tree():
    test = Tree({'a': {'b': 1, 'c': 2}})
    assert test['a:b'] == 1


if __name__ == '__main__':
    print (test_tree())

# Generated at 2022-06-24 03:23:33.876806
# Unit test for function tree
def test_tree():

    t = tree()
    t['level1']['level2']['level3'] = 'WOAH'

    assert t['level1']['level2']['level3'] == 'WOAH'



# Generated at 2022-06-24 03:23:38.669614
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree()
    t.update(dict(
        a='a',
        a_b='a_b',
        a_b_c='a_b_c',
    ))
    assert t.a == 'a'
    assert t.a_b == 'a_b'
    assert t.a_b_c == 'a_b_c'



# Generated at 2022-06-24 03:23:42.694275
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    """Basic test for Tree.__getitem__"""
    t = Tree(namespace='test1')
    t['a'] = {'b': 'c'}
    assert t.get('a:b') == 'c'
    assert t.get('a:d') is None
    t.update({'a': {'e': 'f'}})
    assert t.get('a:b') == 'c'
    assert t.get('a:e') == 'f'
    assert t.get('a', {}, namespace='test1') == {'b': 'c', 'e': 'f'}
    assert t.get('a', {}, namespace='test2') == {}
    assert t.get('a:b', {}, namespace='test2') is None

# Generated at 2022-06-24 03:23:52.615195
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    example_list = Tree()
    example_list.__setitem__('key', 'value', namespace='')
    # Initialization of class 'Tree' with argument(s) (None, '', False)
    example_list_2 = Tree()
    # Call to method __setitem__ of class 'Tree' with argument(s) (key, 'value', namespace='')
    example_list_2.__setitem__('key', 'value', namespace='')
    # Initialization of class 'Tree' with argument(s) (None, '', False)
    example_list_3 = Tree()
    # Call to method __setitem__ of class 'Tree' with argument(s) ('key', 'value', namespace=None)
    example_list_3.__setitem__('key', 'value', namespace=None)


# Unit

# Generated at 2022-06-24 03:23:55.088214
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    tree = RegistryTree()
    tree.register('foo:1:2:3', 'bar')
    assert tree['foo:1:2:3'] == 'bar'

# Generated at 2022-06-24 03:24:03.681276
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t1 = Tree(namespace='a')
    assert t1 == {}
    t1[2] = 3
    assert t1 == {'a': {2: 3}}
    t1[1] = 2
    assert t1 == {'a': {2: 3, 1: 2}}
    t1['a:1'] = 3
    assert t1 == {'a': {2: 3, 1: 2, 'a:1': 3}}
    t1['a:b:1'] = 5
    assert t1 == {'a': {2: 3, 1: 2, 'a:1': 3, 'b': {1: 5}}}
    t1['c:b:1'] = 5

# Generated at 2022-06-24 03:24:08.504869
# Unit test for function tree
def test_tree():
    """Test tree function."""
    from pprint import pprint
    t = tree()
    t['0:0:c']['0:1:b'] = '1:2:a'
    pprint(t)


if __name__ == '__main__':
    test_tree()