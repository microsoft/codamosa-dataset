

# Generated at 2022-06-24 03:14:18.250797
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    up = RegistryTree(namespace='up')
    up['down'] = RegistryTree(namespace='down')
    up['down']['left'] = 'left'
    up['down']['right'] = 'right'
    up['down']['inside'] = RegistryTree(namespace='inside')
    up['down']['inside']['back'] = 'back'

    assert up['down']['back'] == 'back'
    assert up['down']['inside:back'] == 'back'

# Generated at 2022-06-24 03:14:22.023531
# Unit test for function tree
def test_tree():
    t = tree()
    t['foo']['bar'] = 1
    t['foo']['baz']['quux'] = 2
    t['reggie']['root'] = 3
    t['reggie']['root']['man'] = 4
    assert t['foo']['bar'] == 1
    assert t['foo']['baz']['quux'] == 2
    assert t['reggie']['root']['man'] == 4



# Generated at 2022-06-24 03:14:24.048082
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}
    set_tree_node(tree, 'a:b:c', 'foo')
    assert tree == {'a': {'b': {'c': 'foo'}}}



# Generated at 2022-06-24 03:14:26.313976
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree(initial={
        'a': {
            'b': {
                'c': 'd',
            }
        }
    })
    assert t['a:b:c'] == 'd'



# Generated at 2022-06-24 03:14:33.096786
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()
    tree['a:b:c'] = 3
    tree['a:d'] = 4
    tree['a:e:f'] = 5
    tree['a:b:c2'] = 6
    tree['g'] = 7
    tree['a:e:f2'] = 8
    tree['a:e:f3'] = 9
    tree['a:e:f4'] = 10
    tree['a:e:f5'] = 11
    assert tree['a:e:f'] == 5
    assert tree['a:b:c'] == 3
    assert tree['a:e:f4'] == 10
    assert tree['a:e:f3'] == 9
    assert tree['g'] == 7
    assert tree['a:e:f2'] == 8



# Generated at 2022-06-24 03:14:35.824345
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    t['a'] = 'b'
    assert t['a'] == 'b'
    assert t.get('a') == 'b'



# Generated at 2022-06-24 03:14:44.182743
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'a': {
            'b': {
                'c': 'd'
            },
            'b1': {
                'c1': 'd1'
            }
        }
    }
    assert tree == {'a': {'b': {'c': 'd'}, 'b1': {'c1': 'd1'}}}
    assert tree.get('a:b') == {'c': 'd'}
    assert get_tree_node(tree, 'a:b') == {'c': 'd'}
    assert tree == {'a': {'b': {'c': 'd'}, 'b1': {'c1': 'd1'}}}

    assert tree.get('a:b:c') == 'd'

# Generated at 2022-06-24 03:14:54.736890
# Unit test for constructor of class Tree
def test_Tree():
    # Constructor test
    assert Tree().__class__ is Tree
    assert Tree({}).__class__ is Tree

    # Sanity test
    assert Tree({'foo': 'bar'}).get('foo') == 'bar'

    # Test update after first use
    t = Tree({'foo': 'bar'})
    t.update({'biz': 'baz'})
    assert t.get('biz') == 'baz'

    # Test namespace
    t = Tree(namespace='baz')
    assert t.namespace == 'baz'
    t['foo'] = 'bar'
    assert t['foo'] == 'bar'
    assert t['baz:foo'] == 'bar'

    # Test sub-namespace
    t = Tree(namespace='baz')

# Generated at 2022-06-24 03:14:57.392696
# Unit test for function get_tree_node
def test_get_tree_node():
    """Test [Tree][] lookup mechanism"""
    tree = {"data": "D", "dimensions": {"level2a": {"data": "in_a"}, "level2b": {"data": "in_b"}}}
    assert get_tree_node(tree, 'data') == 'D'
    assert get_tree_node(tree, 'dimensions:level2a:data') == 'in_a'
    assert get_tree_node(tree, 'dimensions:level2b:data') == 'in_b'
    assert get_tree_node(tree, 'dimensions:level2c:data') is _sentinel

# Generated at 2022-06-24 03:15:00.426673
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    """
    >>> tree = Tree()
    >>> tree['a'] = 'A'
    >>> print tree
    {'a': 'A'}
    >>> print tree['a']
    A
    >>> tree['b']['c'] = 'C'
    >>> print tree['b']['c']
    C
    """



# Generated at 2022-06-24 03:15:06.355258
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    t.register(key='foo', value='bar')
    t.register(key='foo:bar', value='sushi')

    try:
        t.register(key='baz', value='sushi')
    except TypeError:
        pass

    assert t.get('foo') == 'bar'
    assert t.get('foo:bar') == 'sushi'



# Generated at 2022-06-24 03:15:08.580230
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    r = RegistryTree()
    r.register('my:registry', {})
    assert r['my:registry'] == {}



# Generated at 2022-06-24 03:15:16.722475
# Unit test for function get_tree_node
def test_get_tree_node():
    test_dict = {
        'key1': 'value1',
        'key2': {
            'key3': 'value3'
        }
    }

    assert get_tree_node(test_dict, 'key1') == 'value1'
    assert get_tree_node(test_dict, 'key2:key3') == 'value3'

    try:
        get_tree_node(test_dict, 'key3:key3')
    except KeyError:
        pass
    else:
        assert False, 'get_tree_node did not raise a KeyError as it should have'
    assert get_tree_node(test_dict, 'key3:key3', default=_sentinel) is _sentinel



# Generated at 2022-06-24 03:15:21.218275
# Unit test for constructor of class Tree
def test_Tree():
    """Ensure Tree behaves properly, as it's an important base class elsewhere."""
    tree = Tree(initial={'a': 1}, initial_is_ref=True)
    assert(tree['a'] == tree.get('a') == tree.get('a:b') and tree['a'] == 1)



# Generated at 2022-06-24 03:15:24.838418
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree({'a': 1, 'b': 2})
    assert t.get('a') == 1
    assert t.get('b', 2) == 2
    assert t.get('c', 3) == 3

    assert t.get('a:b:c:d', 3) == 3



# Generated at 2022-06-24 03:15:27.785955
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c') == 'd'


# Unit tests for function set_tree_node

# Generated at 2022-06-24 03:15:30.692265
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    class TestTree(Tree):
        def __init__(self):
            pass
    tree = TestTree()
    tree['tree:value:key'] = 'value'
    assert tree['value:key'] == 'value'



# Generated at 2022-06-24 03:15:36.034434
# Unit test for function set_tree_node
def test_set_tree_node():
    mydict = {}
    set_tree_node(mydict, 'foo:bar:baz', 'alpha')
    assert mydict == {'foo': {'bar': {'baz': 'alpha'}}}
    set_tree_node(mydict, 'foo:bar:bee', 'alpha')
    assert mydict == {'foo': {'bar': {'baz': 'alpha', 'bee': 'alpha'}}}



# Generated at 2022-06-24 03:15:44.926019
# Unit test for function tree
def test_tree():
    test_tree = tree()

    test_tree['a'] = 'bar'
    test_tree['b:c'] = 'baz'
    test_tree['foo']['bar'] = 'baz'
    test_tree['foo']['bar']['baz'] = 'foobar'

    test_tree['c'] = {'a': 1, 'b': 2}
    test_tree['c']['foo']['bar']['baz'] = 'foobar'

    assert test_tree['a'] == 'bar'
    assert test_tree['b']['c'] == 'baz'
    assert test_tree['foo']['bar']['baz'] == 'foobar'

# Generated at 2022-06-24 03:15:55.871155
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree()
    assert get_tree_node(t, 'foo') is None

    # Non-existing key
    t['foo:bar'] = 'spam'
    assert get_tree_node(t, 'foo:bar') == 'spam'
    assert get_tree_node(t, 'foo:baz') is None
    assert get_tree_node(t, 'foo:baz:eggs') is None

    # Key with . notation
    assert get_tree_node(t, 'foo') == {'bar': 'spam'}
    assert get_tree_node(t, 'foo:bar') == 'spam'

    # Key with : notation
    assert get_tree_node(t, 'foo:bar') == 'spam'

    # Return parent

# Generated at 2022-06-24 03:15:57.488595
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    tree = RegistryTree()
    tree.__class__.register('foo', 'bar')
    assert tree['foo'] == 'bar'


# Generated at 2022-06-24 03:16:04.232298
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    registry = RegistryTree()
    registry.namespace = 'my_namespace'
    registry.register('test', 'test')

    assert registry['test'] == 'test', 'class RegistryTree.register() as expected'
    assert registry.namespace == 'my_namespace', 'class RegistryTree.namespace is as expected'



# Generated at 2022-06-24 03:16:11.529261
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    t['a'] = 'b'
    assert t['a'] == 'b'
    assert t == {'a': 'b'}
    t['a:b'] = 'c'
    assert t == {'a': {'b': 'c'}}
    t['a:b:c'] = 'd'
    assert t == {'a': {'b': {'c': 'd'}}}
    t['a:b:c:d'] = 'e'
    assert t == {'a': {'b': {'c': {'d': 'e'}}}}



# Generated at 2022-06-24 03:16:20.523962
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree()
    t['a'] = 'b'
    t['a']['b'] = 'c'
    t['a']['c'] = 'd'
    assert(t['a']['b'] == 'c')
    assert(t['a']['c'] == 'd')

    t = Tree({'a': {'b': 'c'}})
    assert(t['a']['b'] == 'c')


if __name__ == '__main__':
    import sys

    if len(sys.argv) < 2:
        print('Usage: %s <test_to_run>' % sys.argv[0])
        sys.exit(1)

    sys.argv.pop(0)

# Generated at 2022-06-24 03:16:28.388659
# Unit test for constructor of class Tree
def test_Tree():
    print('Testing Tree class')
    print('Testing against Tree system')
    test_t = Tree({'a': 1, 'b': {'c': 2, 'd': [3, 4, 5]}})
    assert test_t['a'] == 1
    assert test_t['b:c'] == 2
    assert test_t['b:d:2'] == 5
    print('Success')
    print('Testing against defaultdict system')
    test_t = Tree()
    test_t['a'] = 1
    test_t['b']['c'] = 2
    test_t['b']['d'][0] = 3
    test_t['b']['d'][1] = 4
    test_t['b']['d'][2] = 5
    assert test_t['a'] == 1

# Generated at 2022-06-24 03:16:32.090638
# Unit test for function tree
def test_tree():
    # Test tree function
    # Set root
    treedict = tree()
    treedict['path']['to']['value'] = 'foo'
    assert treedict['path']['to']['value'] == 'foo'



# Generated at 2022-06-24 03:16:42.431214
# Unit test for function get_tree_node
def test_get_tree_node():
    # Check for exception for non-existent key
    data = {
        'foo': {
            'bar': {
                'baz': 'fubar',
            }
        }
    }

    try:
        get_tree_node(data, 'foo:bar:meh')
    except KeyError:
        pass
    else:
        assert False

    # Check that default value is set
    data = {
        'foo': {
            'bar': {
                'baz': 'fubar',
            }
        }
    }

    assert get_tree_node(data, 'foo:bar:foo', default='lol') == 'lol'

    # Check for parent value

# Generated at 2022-06-24 03:16:47.029214
# Unit test for constructor of class Tree
def test_Tree():
    m = Tree({'a': {'b': {'c': {'d': 1}}}})
    print(m['a:b:c']['d'])


if __name__ == '__main__':
    test_Tree()

# Generated at 2022-06-24 03:16:49.710598
# Unit test for constructor of class Tree
def test_Tree():
    assert Tree().namespace == ''
    assert Tree('pyramid').namespace == 'pyramid'



# Generated at 2022-06-24 03:16:54.097552
# Unit test for function tree
def test_tree():
    test_tree = tree()
    test_tree['a'] = 1
    test_tree['b:a'] = 2
    test_tree['b:b'] = 3
    assert test_tree['a'] == 1
    assert test_tree['b']['a'] == 2
    assert test_tree['b']['b'] == 3



# Generated at 2022-06-24 03:16:58.040442
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    # Given
    obj = Tree({'foo': 'bar', 'biz': {'baz': 1}})

    # When/Then
    assert obj['biz:baz'] == 1



# Generated at 2022-06-24 03:17:01.045793
# Unit test for function tree
def test_tree():
    tree = Tree()
    tree['a'] = 1
    tree['a:b'] = 2
    tree['a:b:c'] = 3
    assert tree['a'] == 1
    assert tree['a:b'] == 2
    assert tree['a:b:c'] == 3


# Generated at 2022-06-24 03:17:02.432934
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree()
    t['foo'] = 42
    assert t['foo'] == 42



# Generated at 2022-06-24 03:17:05.149904
# Unit test for function get_tree_node
def test_get_tree_node():
    foo = {'a': {'b': {'c': 42}}}
    assert get_tree_node(foo, 'a:b:c') == 42



# Generated at 2022-06-24 03:17:07.584396
# Unit test for function set_tree_node
def test_set_tree_node():
    registry = Tree()
    registry['x:y:z'] = 'correct'
    assert registry['x:y:z'] == 'correct'



# Generated at 2022-06-24 03:17:18.478501
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'parent': {
            'a': 'value_a',
            'b': {
                'c': 'value_c',
                'd': 'value_d',
            },
            'e': 'value_e',
        },
    }

    assert get_tree_node(mapping, 'parent:b:c') == 'value_c'
    assert get_tree_node(mapping, 'parent:b:c', parent=True)['c'] == 'value_c'
    assert get_tree_node(mapping, 'parent:b:c', default='default') == 'value_c'
    assert get_tree_node(mapping, 'parent:b:f', default='default') == 'default'

# Generated at 2022-06-24 03:17:21.282878
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    # Setup
    t = Tree()

    # Testing
    assert t['a'] == {}
    t['a'] = {'b': {'c': 'd'}}
    assert t['a']['b']['c'] == 'd'

    # Teardown
    pass



# Generated at 2022-06-24 03:17:28.912552
# Unit test for constructor of class Tree
def test_Tree():
    assert isinstance(Tree(), collections.Mapping)
    assert isinstance(Tree(), collections.defaultdict)
    assert isinstance(Tree(), Tree)
    assert isinstance(Tree(Tree({'foo': 1}, namespace='a.b')), Tree)
    assert not isinstance(Tree(list()), Tree)
    assert not isinstance(Tree(dict()), Tree)
    assert set(Tree().keys()) == set(Tree(Tree({'foo': 1}, namespace='a.b.c')).keys()) == set(Tree(dict()).keys())  # Empty
    assert Tree().get('foo') is None
    assert Tree(dict(foo='bar')).get('foo') == 'bar'
    assert Tree(dict(foo='bar')).get('bar', 'baz') == 'baz'

# Generated at 2022-06-24 03:17:34.456840
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree = Tree()
    tree['some:key'] = (1, 2)
    assert tree['some:key'] == (1, 2)
    assert tree['some:key'] is tree['some:key']
    assert tree['some:key'] is not tree['some:key:']



# Generated at 2022-06-24 03:17:40.358485
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    """
    Test to see if we can get back 'root'
    """
    my_tree_instance = Tree(namespace='a')
    my_tree_instance.__setitem__('root', 123)
    my_tree_instance.__setitem__('root:foo', 321)
    my_tree_instance.__setitem__('root:bar', 321)
    my_tree_instance.__setitem__('root:baz', 321)
    result = my_tree_instance.__getitem__('root', namespace='a')
    expected = 123
    assert result == expected, 'Expected %s, got %s' % (expected, result)

# Generated at 2022-06-24 03:17:42.971874
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    rt = RegistryTree(namespace='namespace 1')
    assert rt.namespace == 'namespace 1'



# Generated at 2022-06-24 03:17:46.596349
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree()
    t[1][2][3]['four'] = {'five': 5, 'six': 6}
    assert t[1][2][3]['four']['five'] == 5
    assert t[1][2][3]['four']['six'] == 6

# Generated at 2022-06-24 03:17:54.398557
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    import unittest
    import json
    datastring = '''{
        "examples": {
            "list1": [1, 2, 3],
            "list2": [4, 5, 6]
        }
    }'''
    class TestTree_NamespaceSpecification(unittest.TestCase):
        def setUp(self):
            self.tree = Tree()
            self.tree.update(json.loads(datastring))

        def test_Tree___setitem___with_namespace(self):
            self.tree['examples:list1'].append(4)
            self.assertEqual(self.tree['examples:list1'], [1, 2, 3, 4])


# Generated at 2022-06-24 03:18:00.090973
# Unit test for function tree
def test_tree():
    t = tree()
    t['animal']['canine']['dog'] = 'bark'
    t['animal']['canine']['fox'] = 'mute'
    t['animal']['feline']['cat'] = 'meow'
    t['mineral']['rock']['granite'] = 'hard'
    t['mineral']['rock']['sand'] = 'ground'
    t['mineral']['metal']['copper'] = 'red'
    t['mineral']['metal']['gold'] = 'yellow'

    assert t['animal']['canine']['dog'] == 'bark'
    assert t['animal']['feline']['cat'] == 'meow'

# Generated at 2022-06-24 03:18:10.491318
# Unit test for function get_tree_node
def test_get_tree_node():
    import unittest

    TEST_MAPPING = {
        'foo': {
            'bar': 'baz',
            'egg': {
                'spam': 'ham',
                'cheese': {
                    'burger': 'fries'
                },
                'burger': 'fries'
            }
        }
    }

    class TestGetTreeNode(unittest.TestCase):

        def setUp(self):
            self.mapping = TEST_MAPPING

        def test_primary(self):
            """
            Test base lookup
            """
            self.assertEqual(get_tree_node(self.mapping, 'foo:bar'), 'baz')

        def test_parent(self):
            """
            Test parent lookup
            """

# Generated at 2022-06-24 03:18:21.456321
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree()
    t['a']['b']['c'] = 'value'
    assert t['a']['b']['c'] == 'value'

    t = Tree()
    t.namespace = 'namespace'
    t['a']['b']['c'] = 'value'
    assert t['a']['b']['c'] == 'value'
    assert t['namespace:a']['namespace:b']['namespace:c'] == 'value'

    t = Tree(namespace='namespace')
    t['a']['b']['c'] = 'value'
    assert t['a']['b']['c'] == 'value'

# Generated at 2022-06-24 03:18:31.737406
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    t['a'] = 1
    assert t['a'] == 1
    t['a:b'] = 2
    assert t['a:b'] == 2
    t['a:c'] = 3
    assert t['a:c'] == 3
    t['a:c:d'] = 4
    assert t['a:c:d'] == 4
    t['a:c'] = 5
    assert t['a:c'] == 5
    del t['a:c']
    assert 'a:c' not in t
    with pytest.raises(KeyError):
        t['a:c']
    t.update({'a:c': 6, 'a:d': 7})
    assert t['a:c'] == 6
    assert t['a:d'] == 7

# Generated at 2022-06-24 03:18:39.931049
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree({'a': 1, 'b': 2, 'c': {'d': 3, 'e': {'f': 4, 'g': 5}, 'h': 6, 'i': 7}, 'j': 8})

# Generated at 2022-06-24 03:18:44.061222
# Unit test for constructor of class Tree
def test_Tree():
    tree = Tree()
    tree['a']['b']['c'] = 1
    assert tree.get('a:b:c') == 1
    assert tree['a']['b']['c'] == 1



# Generated at 2022-06-24 03:18:52.811207
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'one': {
            'two': {
                'three': 'foo'
            }
        }
    }
    assert tree['one:two:three'] == 'foo'
    # Should return parent node
    assert tree['one:two', True] == {'three': 'foo'}
    # Should raise KeyError
    try:
        tree['one:two:four']
    except KeyError:
        pass
    else:
        raise AssertionError('KeyError not raised')
    # Should return None
    assert tree['one:two:four', None] is None


if __name__ == '__main__':
    test_get_tree_node()

# Generated at 2022-06-24 03:18:56.586548
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()
    tree['foo'] = 'Foo'
    assert tree['foo'] == 'Foo'

    tree['bar'] = {'baz': 'Baz'}
    assert tree['bar']['baz'] == 'Baz'



# Generated at 2022-06-24 03:18:59.099050
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree = Tree({'a': {'b': {'c': 42}}})
    assert tree['a:b:c'] is 42
    assert tree['a:b'] == {'c': 42}



# Generated at 2022-06-24 03:19:05.755935
# Unit test for function tree
def test_tree():
    t = tree()
    t['item']['subitem']['subsubitem'] = 'val1'
    t['item']['subitem2'] = 'val2'
    t['item']['subitem']['subsubitem2'] = 'val3'

    assert t['item']['subitem']['subsubitem'] == 'val1'
    assert t['item']['subitem2'] == 'val2'
    assert t['item']['subitem']['subsubitem2'] == 'val3'

    for node in ['item', 'subitem', 'subsubitem']:
        t[node] = 'val1'

    assert t['item'] == 'val1'
    assert t['subitem'] == 'val1'

# Generated at 2022-06-24 03:19:12.220256
# Unit test for function set_tree_node
def test_set_tree_node():
    assert_equal(set_tree_node(tree(), 'foo', 'bar')['foo'], 'bar')
    assert_equal(set_tree_node(tree(), 'foo:bar', 'baz')['foo']['bar'], 'baz')
    assert_equal(set_tree_node(tree(), 'foo:bar:baz:bax', 'bux')['foo']['bar']['baz']['bax'], 'bux')



# Generated at 2022-06-24 03:19:21.630747
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    t['a'] = 'A'
    t['b:c'] = 'B'
    t['d'] = 'D'
    t['d:e'] = 'E'
    t['f:g'] = 'G'
    assert t['a'] == 'A'
    assert t['b:c'] == 'B'
    assert t['d'] == 'D'
    assert t['d:e'] == 'E'
    assert t['f:g'] == 'G'
    try:
        assert t['f:g:h'] == 'H'
    except KeyError:
        pass
    else:
        raise Exception("Expected KeyError exception")

# Generated at 2022-06-24 03:19:22.640257
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    return



# Generated at 2022-06-24 03:19:27.796683
# Unit test for function set_tree_node
def test_set_tree_node():
    t = tree()
    set_tree_node(t, 'a:b:c', 42)
    set_tree_node(t, 'a:d', [])
    assert t == tree({'a': {'b': {'c': 42}, 'd': []}})



# Generated at 2022-06-24 03:19:31.805375
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    value = 'bar'
    tree = Tree()
    tree['foo'] = value
    assert tree['foo'] == value



# Generated at 2022-06-24 03:19:38.537738
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}
    set_tree_node(tree, 'foo:bar', 42)
    assert tree['foo']['bar'] == 42
    set_tree_node(tree, 'foo:bar:baz', 23)
    assert tree['foo']['bar']['baz'] == 23
    set_tree_node(tree, 'foo:bar', 1)
    assert tree['foo']['bar'] == 1



# Generated at 2022-06-24 03:19:41.288020
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree()
    t["foo"]["bar"] = "baz"
    assert t["foo"]["bar"] == "baz"



# Generated at 2022-06-24 03:19:44.965390
# Unit test for constructor of class Tree
def test_Tree():
    tree = Tree(initial={'foo': 'bar'}, namespace='test', initial_is_ref=False)
    assert 'bar' == tree.get('test:foo')
    assert isinstance(tree['test:foo'], basestring)



# Generated at 2022-06-24 03:19:48.172126
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    t['abcde'] = 'hahaha'
    assert t['other'] == {}



# Generated at 2022-06-24 03:19:54.042052
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    registry = RegistryTree(namespace='unittest')
    registry.register('1', 'hi')
    registry.register('2', 'foo')
    registry.register('3', 'bar')

    assert registry.get('1') == 'hi'
    assert registry.get('2') == 'foo'
    assert registry.get('3') == 'bar'

    import pprint
    pprint.pprint(registry)

# Generated at 2022-06-24 03:20:05.014543
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    from pprint import pprint

    # Example 1
    t = Tree()
    t['a']['b']['c'] = 'foo'
    assert t['a:b:c'] == 'foo'

    # Example 2
    assert get_tree_node(t, 'a:b:c', default=_sentinel) == 'foo'

    # Example 3
    t = Tree()
    t['a']['b']['c'] = 'foo'
    assert t['a:b:c'] == 'foo'
    assert t['a']['b']['c'] == 'foo'
    assert t['a']['b']['d'] == {}
    assert t['a']['b']['d'] == {}

    # Example 4

# Generated at 2022-06-24 03:20:12.996095
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    test_t = Tree({'foo': 'bar'}, initial_is_ref=True)
    assert test_t.get('foo') == 'bar'
    assert test_t.get('foo', 'default') == 'bar'
    assert test_t.get('bar', '') == ''
    assert test_t.get('bar') == {}
    assert test_t.get('bar', 'default') == 'default'

    test_t = Tree({'foo': 'bar'}, initial_is_ref=True)
    assert test_t.get('foo') == 'bar'
    test_t.update({'foo': 'baz'})
    assert test_t.get('foo') == 'baz'

    test_t = Tree({'foo': 'bar'}, initial_is_ref=True)
    test_t

# Generated at 2022-06-24 03:20:21.271907
# Unit test for constructor of class RegistryTree
def test_RegistryTree():

    from collections import Mapping

    # Constructors
    tree = RegistryTree()
    assert isinstance(tree, Mapping)
    tree = RegistryTree('foo')
    assert isinstance(tree, Mapping)
    tree = RegistryTree(namespace='foo')
    assert isinstance(tree, Mapping)
    tree = RegistryTree(('bar', 'foo'))
    assert isinstance(tree, Mapping)

    # Check registration:
    tree.register('bar', 'baz')
    tree.register('bar:baz', 'bim')

    # Check get:
    tree.get('bar') == 'baz'
    tree.get('bar:baz') == 'bim'
    tree.get('baz') == None

    # Check __repr__ :
    assert repr(tree) == '{}'




# Generated at 2022-06-24 03:20:24.813961
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    from . import http

    rt = RegistryTree()
    rt.register('test', http.HTTPResponse)
    if not isinstance(rt['test'], type):
        raise Exception('RegistryTree constructor failed.')



# Generated at 2022-06-24 03:20:27.622432
# Unit test for constructor of class Tree
def test_Tree():
    o = Tree()
    o['a']['b']['c'] = 5
    assert o['a']['b']['c'] == 5



# Generated at 2022-06-24 03:20:30.536059
# Unit test for function get_tree_node
def test_get_tree_node():
    pass



# Generated at 2022-06-24 03:20:40.505034
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    test_tree_obj = Tree()
    test_key0 = 'TEST_KEY0'
    test_value0 = 'TEST_VALUE0'
    test_namespace0 = 'TEST_NAMESPACE0'
    test_tree_obj[test_key0] = test_value0
    test_namespaced_tree_obj = Tree(initial_is_ref=test_tree_obj, namespace=test_namespace0)
    test_key1 = 'TEST_KEY1'
    test_value1 = 'TEST_VALUE1'
    test_namespace1 = 'TEST_NAMESPACE1'
    test_namespaced_tree_obj[test_key1] = test_value1
    test_namespaced_tree_obj[test_key1] = test_value1, test_namespace

# Generated at 2022-06-24 03:20:42.635252
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    t['data'] = "Hello World"
    print(t)



# Generated at 2022-06-24 03:20:44.058875
# Unit test for function tree
def test_tree():
    assert get_tree_node(tree(), 'root')



# Generated at 2022-06-24 03:20:50.541317
# Unit test for function get_tree_node
def test_get_tree_node():
    d = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }

    assert get_tree_node(d, 'a:b:c') == 'd'
    assert get_tree_node(d, 'a:f:c') is _sentinel
    try:
        assert get_tree_node(d, 'a:f:c')
    except KeyError as exc:
        assert True



# Generated at 2022-06-24 03:21:01.278552
# Unit test for constructor of class Tree
def test_Tree():
    tree = Tree()
    tree['foo'] = 'bar'
    assert tree == {'foo': 'bar'}
    tree['lol']['wtf'] = 'bbq'
    assert tree == {'foo': 'bar', 'lol': {'wtf': 'bbq'}}
    tree['lol']['rofl'] = 'copter'
    assert tree == {'foo': 'bar', 'lol': {'wtf': 'bbq', 'rofl': 'copter'}}
    tree['lol']['rofl']['omg'] = 'wtf'
    assert (tree == {'foo': 'bar',
                     'lol': {'wtf': 'bbq', 'rofl': {'omg': 'wtf'}}})

    # Test namespace
    tree = Tree(namespace='test')
   

# Generated at 2022-06-24 03:21:10.443835
# Unit test for function get_tree_node
def test_get_tree_node():
    # Test empty key
    mapping = {'hello': 'world'}
    assert get_tree_node(mapping, '') == mapping

    # Test parent
    mapping = {
        'hello': {
            'world': 'yay'
        }
    }
    assert get_tree_node(mapping, 'hello', parent=True) == mapping['hello']
    assert get_tree_node(mapping, 'hello:world', parent=True) == mapping['hello']

    # Test with trailing delimiter
    mapping = {
        'hello': {
            'world': 'yay'
        }
    }
    assert get_tree_node(mapping, 'hello:world') == 'yay'
    assert get_tree_node(mapping, 'hello:world:') == 'yay'

    # Test without trailing

# Generated at 2022-06-24 03:21:13.497157
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree(namespace='foo')
    t['bar:baz'] = 1
    assert t['bar:baz'] == 1
    assert t['foo:bar:baz'] == 1

# Generated at 2022-06-24 03:21:19.937389
# Unit test for constructor of class Tree
def test_Tree():
    assert Tree().namespace == ''
    assert Tree({'a': 1}).namespace == ''
    assert Tree(namespace='foo')['foo:a'] == {}
    assert Tree({'a': 1}, namespace='foo')['foo:a'] == 1



# Generated at 2022-06-24 03:21:27.137107
# Unit test for function set_tree_node
def test_set_tree_node():
    a = {}
    set_tree_node(a, 'a:b:c', 1)
    assert a == {'a': {'b': {'c': 1}}}
    set_tree_node(a, 'd:e', 2)
    assert a == {'a': {'b': {'c': 1}}, 'd': {'e': 2}}


# Unit test: function get_tree_node

# Generated at 2022-06-24 03:21:37.630472
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    a = Tree()
    a['a'] = 1
    assert a['a'] == 1
    assert Tree()['a'] is _sentinel

    a['b:c'] = 'd'
    assert a['b:c'] == 'd'

    assert a['b']['c'] == 'd'
    assert a['b']['c'] == 'd'
    assert a['b:c'] == 'd'

    with pytest.raises(KeyError):
        a['d']

    assert a.get('d') is None
    assert a.get('d', 'e') == 'e'
    assert a.get('b:c') == 'd'
    assert a.get('b:d') is None
    assert a.get('b:d', 'e') == 'e'

    a.namespace

# Generated at 2022-06-24 03:21:42.002002
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = Tree()
    set_tree_node(tree, 'a:b:c', 'foobar')
    assert tree.get('a') == {'b': {'c': 'foobar'}}


if __name__ == '__main__':
    test_set_tree_node()

# Generated at 2022-06-24 03:21:44.030359
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    t = RegistryTree()
    t.register('foo', 'bar')
    assert t.get('foo') == 'bar'



# Generated at 2022-06-24 03:21:46.713669
# Unit test for function set_tree_node
def test_set_tree_node():
    data = {}
    set_tree_node(data, 'foobar', 'bar')
    assert data == {'foobar': 'bar'}
    set_tree_node(data, 'foobar:baz:fizz', 123)
    assert data == {'foobar': {'baz': {'fizz': 123}}}



# Generated at 2022-06-24 03:21:48.760978
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    """This method is tested as part of test_Tree"""
    pass



# Generated at 2022-06-24 03:21:52.314031
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()
    tree['a:b'] = 1
    assert tree['a:b'] == 1



# Generated at 2022-06-24 03:21:58.653702
# Unit test for function set_tree_node
def test_set_tree_node():
    input = {}
    result = set_tree_node(input, 'k1:k2:k3', 'v3')
    expected_result = {}
    expected_result['k1'] = {}
    expected_result['k1']['k2'] = {}
    expected_result['k1']['k2']['k3'] = 'v3'
    assert expected_result == result

# Generated at 2022-06-24 03:22:07.849943
# Unit test for function set_tree_node
def test_set_tree_node():
    import unittest
    from collections import OrderedDict

    class TestSetTreeNode(unittest.TestCase):
        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test_set_node_works(self):
            d = OrderedDict()
            d = set_tree_node(d, 'foo:bar:baz', 42)
            self.assertEqual(d['foo']['bar']['baz'], 42)
            self.assertEqual(d['foo']['bar'], {'baz': 42})
            self.assertEqual(d['foo'], {'bar': {'baz': 42}})
            self.assertEqual(d, {'foo': {'bar': {'baz': 42}}})

    unittest

# Generated at 2022-06-24 03:22:15.689919
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    # Create an instance of Tree and store it in the variable test_Tree_instance
    test_Tree_instance = Tree()

    # Call the __getitem__ method of the instance with the arguments '', False
    # The return value of the method is stored in the variable return_value
    return_value = test_Tree_instance.__getitem__('', False)

    # Check the value returned by __getitem__
    # assert return_value == ...
    # assert return_value != ...

    # Check the type of the return value
    assert isinstance(return_value, type(None))



# Generated at 2022-06-24 03:22:18.542694
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()
    assert tree == {}
    tree.__setitem__(1, 'uno')
    assert tree == {1: 'uno'}
    tree.__setitem__(2, 'dos', namespace='spanish')
    assert tree == {1: 'uno', 'spanish': {2: 'dos'}}



# Generated at 2022-06-24 03:22:21.903982
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    rt = RegistryTree()

    assert isinstance(rt, RegistryTree)

    rt.register('a', 'b')
    assert rt['a'] == 'b'


# Generated at 2022-06-24 03:22:26.450836
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    h = RegistryTree()
    h.register(key='test', value=1)
    RegistryTree(initial=[('test', 1)])



# Generated at 2022-06-24 03:22:33.234721
# Unit test for constructor of class Tree
def test_Tree():

    item_tree = Tree()
    item_tree['a'] = 1
    print('Constructor with defaultdict: %s' %
          dict(item_tree))  # prints {'a': 1}

    item_tree = Tree({'a': 1,
                      'b': 2})
    print('Constructor with dict: %s' % dict(item_tree))

    item_tree = Tree([('a', 1), ('b', 2)])
    print('Constructor with list: %s' % dict(item_tree))

    item_tree = Tree(item_tree)
    print('Constructor with Tree: %s' % dict(item_tree))



# Generated at 2022-06-24 03:22:40.945054
# Unit test for function set_tree_node
def test_set_tree_node():
    assert set_tree_node({}, 'foo:bar:x', 'y') == {'foo': {'bar': {'x': 'y'}}}
    assert set_tree_node({}, 'x', 'y') == {'x': 'y'}
    assert set_tree_node({'foo': {'bar': {}}}, 'foo:bar:x', 'z') == {'foo': {'bar': {'x': 'z'}}}
    assert set_tree_node({'foo': {'bar': {}}}, 'foo:bar:x', 'z') == {'foo': {'bar': {'x': 'z'}}}



# Generated at 2022-06-24 03:22:45.878541
# Unit test for function tree
def test_tree():
    t = tree()
    assert t == {}
    assert t['foo'] == {}
    assert t['foo']['bar'] == {}
    assert t['foo']['bar']['baz'] == {}



# Generated at 2022-06-24 03:22:55.450376
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    """Randomized testing of RegistryTree.register()"""
    # TODO: Fix this.
    # return

    class BasicTree(RegistryTree):
        pass

    tree = BasicTree(namespace='math')
    namespace = 'math'

    assert len(tree[namespace]) == 0
    tree.register(key='pi', value=3.141592653589793)
    assert len(tree[namespace]) == 1
    tree.register(key='pi', value=3.141592653589793)
    assert len(tree[namespace]) == 1
    tree.register(key='e', value=2.71828)
    tree.register(key='i', value=10)
    tree.register(key='pi', value=10)
    assert len(tree[namespace]) == 3

# Generated at 2022-06-24 03:23:03.550881
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Verify that get_tree_node works as advertised.

    """

# Generated at 2022-06-24 03:23:08.747872
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    r = RegistryTree()
    assert r.namespace is None
    r = RegistryTree(namespace='a')
    assert r.namespace == 'a'
    r = RegistryTree([('a', ['a'])])
    assert r['a'] == ['a']

# Generated at 2022-06-24 03:23:11.512711
# Unit test for function tree
def test_tree():
    foo = tree()
    foo['bar']['baz'] = 1
    assert foo == {'bar': {'baz': 1}}



# Generated at 2022-06-24 03:23:18.730838
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()
    tree['food']['apple']['quality'] = '5'
    tree['food']['banana']['quality'] = '3'
    assert tree['food:banana:quality'] == '3'
    assert tree['food:apple:quality'] == '5'

    # Test overriding
    tree['food:banana:quality'] = '10'
    assert tree['food:banana:quality'] == '10'

    # Test namespace
    ns_tree = Tree('foods', 'ns')
    ns_tree['apple']['quality'] = '5'
    assert ns_tree['ns:apple:quality'] == '5'
    assert tree['foods:apple:quality'] == '5'



# Generated at 2022-06-24 03:23:26.164757
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree()
    assert t == {}

    t = Tree({'foo': 'woohoo'})
    assert t == {'foo': 'woohoo'}

    t = Tree({'foo': {'bar': 'woohoo'}})
    assert t == {'foo': {'bar': 'woohoo'}}

    t = Tree(namespace='lol')
    assert t == {}

# Generated at 2022-06-24 03:23:30.532629
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    """
    Unit test for Tree.__setitem__
    """
    import pytest
    from pprint import pprint as pp
    from pprint import pformat as pf

    # Init
    t = Tree()

    # Test
    t['a'] = {'b':'c'}
    assert t['a']['b'] == 'c'

    # Teardown
    return t



# Generated at 2022-06-24 03:23:33.350939
# Unit test for function get_tree_node
def test_get_tree_node():
    x = {'a': {'b': {'c': 'd'}}}
    assert get_tree_node(x, 'a:b:c') == 'd'



# Generated at 2022-06-24 03:23:40.725138
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'value'
            }
        }
    }
    assert get_tree_node(mapping, 'foo:bar:baz') == 'value'

    assert get_tree_node(mapping, 'foo:bar') == {'baz': 'value'}
    assert get_tree_node(mapping, 'foo:bar', parent=True) == mapping['foo']
    assert get_tree_node(mapping, 'foo:bar:quux', default='spam') == 'spam'



# Generated at 2022-06-24 03:23:49.518976
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    class Root(RegistryTree):

        def __init__(self, *args, **kwargs):
            self.apples = {}
            self.oranges = {}
            super(Root, self).__init__(*args, **kwargs)

    root = Root(namespace='root')
    assert root.namespace == 'root'

    assert root.apples is root['apples']
    assert root.oranges is root['oranges']

    root.register('banana', ['mango'])
    root['banana'].append('pineapple')
    assert root.items()[0] == ('banana', ['mango', 'pineapple'])
    assert root['banana'] == ['mango', 'pineapple']

    root['coconut:maki'] = 'wasabi'

# Generated at 2022-06-24 03:23:55.209862
# Unit test for function get_tree_node
def test_get_tree_node():
    res = get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c')
    assert res == 'd'
    res = get_tree_node({'a': {'b': {'c': 'd'}}}, 'notfound', default='fallback')
    assert res == 'fallback'
    with pytest.raises(KeyError):
        res = get_tree_node({'a': {'b': {'c': 'd'}}}, 'notfound')



# Generated at 2022-06-24 03:23:57.447947
# Unit test for constructor of class Tree
def test_Tree():
    tree = Tree(tree())
    tree['role:test']['test'] = 'test'
    assert tree['role:test']['test'] == 'test'

# Generated at 2022-06-24 03:24:04.715956
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {"a": {"b": {"c": {"d": 1}}}}
    assert get_tree_node(mapping, "a:b:c:d") == 1
    assert get_tree_node(mapping, "a:b:c:d:e") == (_sentinel, ValueError)
    assert get_tree_node(mapping, "a:b:c:d:e", default="noch nix") == "noch nix"
    assert get_tree_node(mapping, "a:b:c:d", parent=True) == {"c": {"d": 1}}
    assert get_tree_node(mapping, "a", parent=True) == _sentinel



# Generated at 2022-06-24 03:24:07.728580
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree({'foo': 'bar'})

    assert t['foo'] == 'bar'



# Generated at 2022-06-24 03:24:18.322492
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = {
        '1': {
            '2': {
                '3': {
                    '4': 4,
                }
            },
            '5': 5,
        },
    }

    set_tree_node(mapping, '1:2:3:4', '4')
    assert mapping['1']['2']['3']['4'] == '4'

    set_tree_node(mapping, '1:2:3:6', 6)
    assert mapping['1']['2']['3']['6'] == 6

    set_tree_node(mapping, '1:2:3:7:8:9', 9)
    assert mapping['1']['2']['3']['7']['8']['9'] == 9

