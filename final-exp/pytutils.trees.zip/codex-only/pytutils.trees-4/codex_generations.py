

# Generated at 2022-06-24 03:14:14.553230
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    # Tests without namespace
    tree = Tree()
    tree['a'] = {'b': {'c': {'d': 'e'}}}
    tree['l'] = 'm'
    tree['p'] = {'q': 'r'}
    assert tree['a:b:c:d'] == 'e'
    assert tree['l'] == 'm'
    assert tree['p:q'] == 'r'
    # Overrides
    assert tree['p'] == {'q': 'r'}
    tree['p'] = 'q'
    assert tree['p'] == 'q'
    # Enforced types
    try:
        tree['a:b:c:d'] = 'e'
    except TypeError:
        pass
    tree['p']['q'] = 'r'

# Generated at 2022-06-24 03:14:16.849473
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree(namespace='foo')
    t.register(3)
    assert t['foo:3'] == t[3]

# Generated at 2022-06-24 03:14:25.432094
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'one': {
            'two': {
                'three': 3
            }
        }
    }
    assert get_tree_node(mapping, 'one:two:three') == 3
    assert get_tree_node(mapping, 'one:two:three', default=0) == 3
    assert get_tree_node(mapping, 'one:two:four', default=0) == 0
    assert get_tree_node(mapping, 'one:two:three', parent=True) == {'three': 3}
    assert get_tree_node(mapping, 'one:two:three', parent=True, default=0) == {'three': 3}


# Generated at 2022-06-24 03:14:28.613322
# Unit test for function tree
def test_tree():
    t = tree()
    t['a']['b']['c']['d'] = 1
    assert t['a']['b']['c']['d'] == 1
    assert t['a:b:c:d'] == 1



# Generated at 2022-06-24 03:14:34.614172
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()
    tree['a'] = 1
    tree['b'] = 2
    tree['a:b'] = 3
    tree['a']['b'] = 4
    assert tree['a']['b'] == 4
    assert tree['a:b'] == 4
    assert tree['b'] == 2
    assert tree['c'] == tree.__class__()



# Generated at 2022-06-24 03:14:42.637973
# Unit test for function tree
def test_tree():
    """
    Unit test for function tree.
    """
    import pytest

    mytree = tree()
    mytree['a']['b']['c'] = 'd'
    mytree['a']['b']['x'] = 'y'
    mytree['a']['f']['g'] = 'h'
    mytree['a']['f']['i'] = 'j'

    assert get_tree_node(mytree, 'a') == {
        'b': {'c': 'd', 'x': 'y'},
        'f': {'g': 'h', 'i': 'j'}
    }

    assert get_tree_node(mytree, 'a:b') == {'c': 'd', 'x': 'y'}
    assert get_tree_node

# Generated at 2022-06-24 03:14:49.843122
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = {}

    set_tree_node(mapping, 'foo:bar:baz', 'OK!')
    assert mapping['foo']['bar']['baz'] == 'OK!'

    set_tree_node(mapping, 'foo:bar:qux', 'derp')
    assert mapping['foo']['bar']['qux'] == 'derp'



# Generated at 2022-06-24 03:14:55.755629
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    tree = RegistryTree(initial=dict(
        foo=dict(
            bar=dict(
                baz=dict(
                    qux='quux'
                )
            )
        )
    ))
    tree.register('qux', 'quux')
    assert tree.get('foo:bar:baz:quux') == 'quux'

# Generated at 2022-06-24 03:15:03.090075
# Unit test for function tree
def test_tree():
    """
    Unit test.
    """
    t = tree()
    r = t['aa']
    r = t['aa']
    t['aa'] = 'abc'
    t['aa']['bb'] = 'abc'
    t['aa']['bb']['cc'] = 'abc'
    t['aa']['bb']['cc']['dd'] = 'abc'
    t['aa']['bb']['cc']['dd']['ee'] = 'abc'
    t['aa']['bb']['cc']['dd']['ee']['ff'] = 'abc'
    t['aa']['bb']['cc']['dd']['ee']['ff']['gg'] = 'abc'

# Generated at 2022-06-24 03:15:14.006920
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    print('Testing __getitem__')
    t = Tree()
    t['a:b:c'] = 'd'
    t['a:b:e'] = 'f'
    t['a:g'] = 'h'
    t['i'] = 'j'
    assert t['a:b:c'] == 'd'
    assert t['a:b:e'] == 'f'
    assert t['a:g'] == 'h'
    assert t['i'] == 'j'
    assert t['a:b'] == {'c': 'd', 'e': 'f'}
    assert t['a'] == {'b': {'c': 'd', 'e': 'f'}, 'g': 'h'}

# Generated at 2022-06-24 03:15:16.153732
# Unit test for constructor of class Tree
def test_Tree():
    a = Tree()
    assert a == {}
    a['blah'] = 1
    assert a == {'blah': 1}



# Generated at 2022-06-24 03:15:26.097955
# Unit test for function tree
def test_tree():
    """
    Unit test for function `tree`
    """
    root = tree()
    root['a'] = 1
    root['b']['b1'] = 2
    root['b']['b2']['b2b'] = 3
    assert str(root) == 'defaultdict(<function tree at 0x10998b950>, {\'a\': 1, \'b\': defaultdict(<function tree at 0x10998b950>, {\'b1\': 2, \'b2\': defaultdict(<function tree at 0x10998b950>, {\'b2b\': 3})})})'
    print(root)
    print(root['b']['b2'])
    print(root['b'])

    root = Tree()
    root['a'] = 1

# Generated at 2022-06-24 03:15:29.266431
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    registry = RegistryTree(namespace='root')
    registry.register(namespace='a', key='b', value='c')
    registry.get('a:b')


registry = RegistryTree(namespace='root')
register = RegistryTree.register

# Generated at 2022-06-24 03:15:32.792440
# Unit test for function set_tree_node
def test_set_tree_node():
    t = tree()
    t = set_tree_node(t, 'a:b:c', 42)
    t = set_tree_node(t, 'a:d:e', 43)
    assert t == {'a': {'b': {'c': 42}, 'd': {'e': 43}}}
    return t



# Generated at 2022-06-24 03:15:41.501266
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    logger = logging.getLogger(__name__ + '.test_Tree___setitem__')
    tree = Tree()
    tree['test'] = {'nested': 'item'}
    logger.debug('example1: %s', tree)
    tree['test:nested'] = {'more': 'item'}
    logger.debug('example2: %s', tree)
    tree['test:nested:more'] = {'more': 'item'}
    logger.debug('example3: %s', tree)
    tree['test:nested2'] = {'more': 'item'}
    logger.debug('example4: %s', tree)



# Generated at 2022-06-24 03:15:49.658396
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({}, 'foo') == _sentinel

    assert get_tree_node({}, 'foo', _sentinel) == _sentinel
    assert get_tree_node({}, 'foo', default=_sentinel) == _sentinel
    assert get_tree_node({}, 'foo', default=_sentinel) == _sentinel

    assert get_tree_node({'foo': 'bar'}, 'foo') == 'bar'
    assert get_tree_node({'foo': 'bar'}, 'foo', default=_sentinel) == 'bar'
    assert get_tree_node({'foo': 'bar'}, 'foo', default=_sentinel) == 'bar'

    assert get_tree_node({'foo': {'bar': 'baz'}}, 'foo:bar') == 'baz'

# Generated at 2022-06-24 03:15:55.715418
# Unit test for function tree
def test_tree():
    t = tree()
    t['a']['b']['c'] = 'd'
    t['a']['e']['f'] = 'g'

    assert t['a']['b']['c'] == 'd'
    assert t['a']['e']['f'] == 'g'



# Generated at 2022-06-24 03:15:58.597229
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'foo': 'bar'}, 'foo') == 'bar'
    assert 'test2' in {'test': 'test2'}
    assert 'test' in {'test': 'test2'}
    assert 'bar' in {'foo': 'bar'}



# Generated at 2022-06-24 03:16:01.736022
# Unit test for function set_tree_node
def test_set_tree_node():
    # Given
    bean = {}

    # When
    set_tree_node(bean, 'k1', 5)

    # Then
    assert bean['k1'] == 5



# Generated at 2022-06-24 03:16:04.484215
# Unit test for constructor of class Tree
def test_Tree():
    x = Tree()
    x['foo']['bar'] = 'baz'
    assert x['foo']['bar'] == 'baz'



# Generated at 2022-06-24 03:16:11.098573
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree(namespace='foo')
    t.__getitem__('abc')
    t.__setitem__('abc', 123, namespace='foo')

# Generated at 2022-06-24 03:16:16.354102
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    # Create new instance of RegistryTree with test specifying namespace
    test = RegistryTree(namespace='test')

    # Add test key and value
    test.register('my_key', 'my_value')

    # Assert test key is set
    assert test['test:my_key'] == 'my_value'
    assert test.get('test:my_key') == 'my_value'

# Generated at 2022-06-24 03:16:19.695393
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    """Unit test for method __getitem__ of class Tree"""
    my_tree = Tree({'foo': {'bar': {'baz': 'BLAMMO'}}})


# Generated at 2022-06-24 03:16:21.515454
# Unit test for function tree
def test_tree():
    tree = Tree()
    tree['a']['b']['c'] = 'd'
    assert tree['a:b:c'] == 'd'



# Generated at 2022-06-24 03:16:23.201763
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c') == 'd'



# Generated at 2022-06-24 03:16:28.186545
# Unit test for function get_tree_node
def test_get_tree_node():
    import unittest

    class TestGetTreeNode(unittest.TestCase):
        def setUp(self):
            self.data = {
                'top': {
                    'middle': {
                        'bottom': 42
                    }
                }
            }

        def test_basic(self):
            self.assertEqual(get_tree_node(self.data, 'top:middle:bottom'), 42)

        def test_default(self):
            self.assertEqual(get_tree_node(self.data, 'top:middle:top'), None)
            self.assertEqual(get_tree_node(self.data, 'top:middle:top', default=None), None)
            self.assertEqual(get_tree_node(self.data, 'top:middle:top', default=42), 42)


# Generated at 2022-06-24 03:16:38.061848
# Unit test for function tree
def test_tree():
    t = tree()
    t[1][0] = 1
    t[1][1][0] = 1
    t[1][2][0] = 1
    t[1][2][1] = 1
    t[1][3][0] = 1
    t[1][3][1] = 1
    t[1][3][2] = 1
    assert get_tree_node(t, '1:0') == 1
    assert get_tree_node(t, '1:1:0') == 1
    assert get_tree_node(t, '1:2:0') == 1
    assert get_tree_node(t, '1:2:1') == 1
    assert get_tree_node(t, '1:3:0') == 1

# Generated at 2022-06-24 03:16:45.698083
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    tree = RegistryTree()
    tree.register('first', '1')
    tree.register('second:a:b:c', '2')
    tree.register('third:a:b:c', '3')
    tree.register('third:a:b:c', '4')
    tree.register('third:a:b:d', '5')

    assert tree.get('first') == '1'
    assert tree.get('second:a:b:c') == '2'
    assert tree.get('third:a:b:d') == '5'
    assert tree.get('third:a:b:e') is None
    assert tree.get('third:a:b:e', '6') == '6'

    tree.register('third:a:b:e', '6')

# Generated at 2022-06-24 03:16:52.492841
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    # Initialization
    tree = Tree()
    god = 'God'
    name = 'name'
    adam = 'Adam'
    # Action
    res = tree.__setitem__(god, name, adam)
    # Verification
    assert res is not None, 'Tree.__setitem__ should return something'
    assert tree.get(god, name) == adam, 'Tree.__setitem__ should add a new key'



# Generated at 2022-06-24 03:16:57.883484
# Unit test for function set_tree_node
def test_set_tree_node():
    data = {}

    set_tree_node(data, 'a:b:c', 'c')
    assert data.get('a')['b']['c'] == 'c'



# Generated at 2022-06-24 03:17:04.493445
# Unit test for constructor of class Tree
def test_Tree():
    tree = Tree({
        'foo': 'bar',
        'bar': {
            'baz': 'quux'
        }
    }, initial_is_ref=True)
    old_ref = tree.data
    assert tree['foo'] == 'bar'
    assert tree['bar:baz'] == 'quux'
    tree['foo'] = 'baz'
    assert tree['foo'] == 'baz'
    assert old_ref['foo'] == 'bar'
    tree = Tree()
    tree['foo'] = 'baz'
    assert tree['foo'] == 'baz'

# Generated at 2022-06-24 03:17:12.714543
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    rtree = RegistryTree()
    # rtree.register('a', 'b', 'c')
    rtree['a:b:c'] = 'd'
    assert rtree['a:b:c'] == 'd'
    rtree.register('a:b', 'd', 'e')
    assert rtree['a:b:d:e']
    assert rtree['a:b:c'] == 'd'
    rtree.register('a:b:d', 'e', 'f')
    assert rtree['a:b:d:e:f']


if __name__ == "__main__":
    test_RegistryTree()

# Generated at 2022-06-24 03:17:14.921796
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    rt = RegistryTree()
    rt.register('foo:bar:baz', 'boo')
    assert 'boo' == rt['foo:bar:baz']

# Generated at 2022-06-24 03:17:19.527046
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()
    tree['a:b:c'] = 1
    assert tree['a:b:c'] == 1
    assert tree['a']['b']['c'] == 1


if __name__ == '__main__':
    test_Tree___setitem__()

# Generated at 2022-06-24 03:17:24.690251
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()
    # Testing Tuple
    tree['BC', 'AAAB'] = 'ABB'
    assert tree['BC', 'AAAB'] == 'ABB'
    # Testing single
    tree['BC:AB'] = 'AB'
    assert tree['BC:AB'] == 'AB'
    # Testing multiple
    tree['BC:AB:CD'] = 'CD'
    assert tree['BC:AB:CD'] == 'CD'



# Generated at 2022-06-24 03:17:35.364198
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree = Tree()
    # Tree indexing (with str)
    tree['a'] = 1
    assert tree['a'] == 1
    # Tree indexing (with unicode)
    tree['b:c'] = 2
    assert tree['b:c'] == 2
    # Tree indexing (with unicode, unicode)
    tree['b'] = {'c': 3}
    assert tree['b:c'] == 3
    # Tree indexing (with tree)
    tree['b'] = Tree()
    tree['b']['c'] = 4
    assert tree['b:c'] == 4
    # Tree indexing (with list)
    tree['b'] = []
    tree['b'].append({'c': 5})
    assert tree['b:c'] == 5
    # Tree indexing (with dict)
   

# Generated at 2022-06-24 03:17:39.969316
# Unit test for function tree
def test_tree():
    t = tree()
    assert t == {}
    t[1][2][3]['four'] = 5
    assert t[1][2][3]['four'] == 5
    assert t[1]['two']['three']['four'] == 5
    t[1]['two'][4] = 5
    assert t[1]['two'][4] == 5
    assert t[1]['two']['three']['four'] == 5

    assert get_tree_node(t, '1:two:four') == 5
    assert get_tree_node(t, '1:two:five', default=100) == 100
    assert get_tree_node(t, '1:three:four') is None

    set_tree_node(t, '1:two:four', 'new!')

# Generated at 2022-06-24 03:17:43.492575
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    m = Tree()
    m['foo']['bar'] = 'baz'
    assert m['foo']['bar'] == 'baz'



# Generated at 2022-06-24 03:17:52.005949
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Test set_tree_node.
    """
    mapping = {}
    set_tree_node(mapping, 'key', 'value')
    assert mapping['key'] == 'value'
    set_tree_node(mapping, 'key2', 'value2')
    assert mapping['key2'] == 'value2'
    set_tree_node(mapping, 'key1:key2', 'value2')
    assert mapping['key1']['key2'] == 'value2'
    set_tree_node(mapping, 'key1:key3', 'value3')
    assert mapping['key1']['key3'] == 'value3'
    stn = get_tree_node(mapping, 'key1:key3')
    assert stn == 'value3'
    return True


# Unit test

# Generated at 2022-06-24 03:18:00.555117
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    list_data = [{'key_a': {'key_b': 'value'}}]
    assert Tree(list_data)[':key_a:key_b'] == 'value'

    dict_data = {'key_a': {'key_b': 'value'}}
    assert Tree(dict_data)[':key_a:key_b'] == 'value'

    tree_data = Tree({'key_a': {'key_b': 'value'}})
    assert Tree(tree_data)[':key_a:key_b'] == 'value'

# Generated at 2022-06-24 03:18:09.339531
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {}
    mapping['foo'] = tree()
    mapping['foo']['bar'] = tree()
    mapping['foo']['bar']['baz'] = 150

    assert get_tree_node(mapping, 'foo:bar:baz') == 150
    try:
        get_tree_node(mapping, 'foo:bar:boz')
    except KeyError:
        pass
    else:
        assert False, "KeyError not raised when it should."

    assert get_tree_node(mapping, 'foo:bar:boz', default=None) is None



# Generated at 2022-06-24 03:18:14.177508
# Unit test for function set_tree_node
def test_set_tree_node():
    test_tree = tree()
    test_tree['one:two:three'] = 4
    assert test_tree['one']['two']['three'] == 4
    assert test_tree['one']['two']['three'] == 4
    assert test_tree['one']['two']['three'] == 4



# Generated at 2022-06-24 03:18:21.000892
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    a = Tree()
    a['a'] = 1
    a['b'] = {'a': 1, 'b': 2}
    assert a['a'] == 1
    assert a['b'] == {'a': 1, 'b': 2}
    try:
        a['c']
    except KeyError:
        pass
    else:
        assert False, 'a[c] should throw a KeyError'
    assert a.get('c') == None



# Generated at 2022-06-24 03:18:24.848333
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree(initial_is_ref='test')
    return [t.data, t.namespace]

# Generated at 2022-06-24 03:18:30.318771
# Unit test for function tree
def test_tree():
    tree_ = tree()
    tree_['a:s:s:ding'] = True
    assert tree_['a:s:s:ding'] is True
    assert tree_.get('a:s:r:r:r', None) is None
    tree_['a:s:r:r:r'] = False
    assert tree_['a:s:r:r:r'] is False



# Generated at 2022-06-24 03:18:36.706764
# Unit test for constructor of class Tree
def test_Tree():
    #Test with namespace
    a = Tree(namespace='a')
    a.namespace = 'a'
    #Test with initial namespace
    b = Tree(namespace='b')
    b.namespace = 'b'
    #Test with initial value and namespace
    c = Tree({'c': 'c'}, 'c')
    c.namespace = 'c'
    assert (a.namespace == 'a')
    assert (b.namespace == 'b')
    assert (c.namespace == 'c')



# Generated at 2022-06-24 03:18:41.454222
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    thing = Tree({'a': {'b': {'c': 'd'}}}, initial_is_ref=True)
    assert thing['a:b:c'] == 'd'
    assert thing['a:b'] == {'c': 'd'}
    assert thing.get('a:b:c', 'wut') == 'd'
    assert thing.get('a:b', 'wut') == {'c': 'd'}



# Generated at 2022-06-24 03:18:47.648749
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    test_data = tree()
    test_data['a']['b']['c'] = 'foo'
    assert test_data['a']['b']['c'] == 'foo'


if __name__ == "__main__":
    test_data = tree()
    test_data['a']['b']['c'] = 'foo'
    assert test_data['a']['b']['c'] == 'foo'

# Generated at 2022-06-24 03:18:51.038222
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    t['foo'] = 1
    assert t['foo'] == 1
    t['bar:baz'] = 1
    assert t['bar:baz'] == 1
    # __setitem__ of Tree



# Generated at 2022-06-24 03:18:53.764182
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    tree = RegistryTree(initial={'foo': 1})
    assert tree.register('bar', value=2) == {'foo': 1, 'bar': 2}



# Generated at 2022-06-24 03:18:57.012978
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree({'a': b'a'})
    assert t['a'] == b'a'
    t = Tree()
    t['b'] = 'b'
    assert t['b'] == 'b'



# Generated at 2022-06-24 03:19:05.553755
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = {'foo': {'bar': 'BAR'}}
    set_tree_node(mapping, 'foo:bar', 'BAR')
    assert mapping['foo']['bar'] == 'BAR'

    set_tree_node(mapping, 'foo:bar:baz', 'BAZ')
    assert mapping['foo']['bar']['baz'] == 'BAZ'

    set_tree_node(mapping, 'foo:bar:baz:bink', 'BINK')
    assert mapping['foo']['bar']['baz']['bink'] == 'BINK'

    try:
        get_tree_node(mapping, 'foo:bar:biep')
    except KeyError:
        assert True
    else:
        assert False



# Generated at 2022-06-24 03:19:08.120067
# Unit test for constructor of class Tree
def test_Tree():
    tre = Tree(namespace='test:v1')
    assert tre['test:v1:mykey'] == tre['mykey']



# Generated at 2022-06-24 03:19:16.910359
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    o = Tree()
    o['a'] = 'b'
    assert o['a'] == 'b'
    o['b'] = {'c': 'd'}
    assert o['b:c'] == 'd'
    assert o['b'] == {'c': 'd'}
    assert o['b:d'] is None
    assert o['b:d', 'e'] == 'e'
    assert o['b:d', 'e', 'f'] == 'f'
    assert o['b:d', 'e', 'f', 'g'] == 'g'


if __name__ == "__main__":
    test_Tree___getitem__()

# Generated at 2022-06-24 03:19:21.438422
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    reg_tree = RegistryTree()
    reg_tree.register('foo.bar', 1)
    reg_tree.register('foo.baz', 2)
    reg_tree.register('foo.bar.baz', 3)
    assert reg_tree.get('foo.bar') is 1
    assert reg_tree.get('foo.bar.baz') is 3
    assert reg_tree.get('foo.foobar') is None
    assert reg_tree.get('foo.foobar', 4) is 4

# Generated at 2022-06-24 03:19:29.721634
# Unit test for constructor of class Tree
def test_Tree():
    """Test correct behaviour of Tree constructor"""
    initial_data = {
        'name': 'John Do',
        'age': 16,
        'school': {
            'name': 'High School',
            'grade': 9,
        }
    }
    my_tree = Tree(initial=initial_data, namespace='test')
    assert my_tree['name'] == 'John Do'
    assert my_tree['age'] == 16
    assert my_tree['school'] is not None
    assert my_tree['school:name'] == 'High School'
    assert my_tree['school:grade'] == 9



# Generated at 2022-06-24 03:19:32.881782
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    registry = RegistryTree(initial={'a': {'b': {}}}, initial_is_ref=True)

# Generated at 2022-06-24 03:19:40.365824
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = tree()
    mapping['foo'] = 'bar'
    mapping['spam'] = 'eggs'
    mapping['bar']['baz'] = 'qux'

    assert get_tree_node(mapping, 'foo') == 'bar'
    assert get_tree_node(mapping, 'spam') == 'eggs'
    assert get_tree_node(mapping, 'bar:baz') == 'qux'
    assert get_tree_node(mapping, 'bar:foo') == 'bar'



# Generated at 2022-06-24 03:19:49.289574
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    # Initiate a Tree() object with namespace 'xxx'
    instance = Tree(namespace='xxx')
    # Index the object's __setitem__ method with key 'bar', and value '1'
    instance.__setitem__('bar', '1')
    # Assert that the previosly set value equals '1'
    assert instance.get('xxx:bar') == '1'
    # Append an item to the instance's namespace
    instance.__setitem__('bar2', '2')
    # Assert that the namespace has been appended
    assert instance.get('xxx:bar2') == '2'
    # Append an item to the instance's namespace
    instance.__setitem__('bar3', '3')
    # Assert that the namespace has been appended

# Generated at 2022-06-24 03:19:57.018331
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    """
    Unit test for method `__getitem__` of class `Tree`
    """

    def _mock_getitem(key, default=_sentinel, namespace=None):
        key = self._namespace_key(key, namespace=namespace)
        return get_tree_node(self, key, default=default)

    Tree.__getitem__ = _mock_getitem

    node = Tree()
    node['root:child1'] = 'child1'
    node['root:child2:child3'] = 'child3'
    assert node.get('root:child2:child3') == 'child3'

    Tree.__getitem__ = Tree.__getitem__.__func__



# Generated at 2022-06-24 03:20:03.990815
# Unit test for constructor of class Tree
def test_Tree():
    test_tree = Tree({
        'a': 'b',
        'a:b': 'c',
        'a:b:c': 'd',
        'a:b:c:d': 'e'
    })
    assert test_tree.namespace == ''
    assert test_tree['a'] == 'b'
    assert test_tree['a:b'] == 'c'
    assert test_tree['a:b:c'] == 'd'
    assert test_tree['a:b:c:d'] == 'e'



# Generated at 2022-06-24 03:20:07.645558
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    r1 = RegistryTree()
    assert r1.namespace is None
    assert isinstance(r1, RegistryTree)

    r2 = RegistryTree(namespace='foo')
    assert r2.namespace == 'foo'

    r3 = RegistryTree(namespace=None, initial_is_ref=r2)
    assert r3 is r2

# Generated at 2022-06-24 03:20:15.013026
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    # Simple tree-like object
    tree = RegistryTree()
    tree['a.b.c'] = 'abc'
    assert tree['a.b.c'] == 'abc'
    assert tree.get('a.b.c') == 'abc'

    # Tree using custom namespace, and `alias` for __setitem__
    tree = RegistryTree(namespace='test')
    tree.register('a.b.c', 'abc')
    assert tree['test:a.b.c'] == 'abc'

    # Tree refering to an already existing tree, preserving previous values
    tree = RegistryTree()
    tree['a.b.c'] = 'abc'
    tree = RegistryTree(initial_is_ref=tree)
    assert tree['a.b.c'] == 'abc'

    # Tree refering to an already existing tree,

# Generated at 2022-06-24 03:20:19.850551
# Unit test for function get_tree_node
def test_get_tree_node():
    a = {'b': {'c': {'d': 'blarg'}}},

# Generated at 2022-06-24 03:20:30.758378
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree()
    t['newparent'] = Tree()
    if not isinstance(t['newparent'], Tree):
        raise Exception('Not instance of Tree')

    t['newparent']['newchild'] = 'Foobar'
    if t['newparent']['newchild'] != 'Foobar':
        raise Exception('Failed to return correct value')

    t['newparent:newchild'] = 'Foobar2'
    if t['newparent']['newchild'] != 'Foobar2':
        raise Exception('Failed to return correct value')

    t['newparent']['newchild2'] = 'Foobar3'
    if t['newparent:newchild2'] != 'Foobar3':
        raise Exception('Failed to return correct value')



# Generated at 2022-06-24 03:20:32.891691
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    test_tree = RegistryTree.register(RegistryTree(), 'test', 'one')
    assert test_tree['test'] == 'one'



# Generated at 2022-06-24 03:20:37.719434
# Unit test for function set_tree_node
def test_set_tree_node():
    test_dict = {
        'foo': {
            'bar': 'baz',
        },
    }

    assert set_tree_node(test_dict, 'foo:bar', 'baz') == {'foo': {'bar': 'baz'}}
    assert set_tree_node(test_dict, 'foo:bar:baz', 'bingo') == {'foo': {'bar': 'bingo'}}



# Generated at 2022-06-24 03:20:43.606241
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}
    set_tree_node(tree, 'user:fritz:a', 'some-value')
    assert tree['user']['fritz']['a'] == 'some-value'

    tree = {}
    set_tree_node(tree, 'user:fritz:a:b', 'some-value')
    assert tree['user']['fritz']['a']['b'] == 'some-value'



# Generated at 2022-06-24 03:20:47.321704
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = {}
    set_tree_node(mapping, 'p:q:r:s:key', 'value')
    assert mapping['p']['q']['r']['s']['key'] == 'value'



# Generated at 2022-06-24 03:20:51.954883
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()
    tree['1']
    tree['1.1'] = 1
    tree['1:1:1:1:1:1'] = 2
    tree['1:1:1:1:1']['1'] = 3
    tree['2']['2']['2']['2']['2']['2'] = 4


# Generated at 2022-06-24 03:21:02.201496
# Unit test for function get_tree_node
def test_get_tree_node():
    """Unit test for function `get_tree_node`"""
    from nose.tools import assert_raises

    tree = {'1': {'2': {'3': 3}}}
    assert get_tree_node(tree, '1:2:3') == 3

    assert_raises(KeyError, get_tree_node, tree, '1:2:3:4')
    assert get_tree_node(tree, '1:2:3:4', default=4) == 4

    tree = {'a': {'b': {'c': {'d': 'd'}}}}
    assert tree['a'] == {'b': {'c': {'d': 'd'}}}
    assert get_tree_node(tree, 'a') == {'b': {'c': {'d': 'd'}}}

# Generated at 2022-06-24 03:21:04.374293
# Unit test for function set_tree_node
def test_set_tree_node():
    data = {}
    set_tree_node(data, 'hello.world', 'test-data')
    assert get_tree_node(data, 'hello.world') == 'test-data'



# Generated at 2022-06-24 03:21:09.560782
# Unit test for function set_tree_node
def test_set_tree_node():
    """Test set_tree_node"""
    mapping = tree()
    key = 'd:e:f'
    value = 'g'
    set_tree_node(mapping, key, value)
    assert mapping['d']['e']['f'] == 'g'

# Generated at 2022-06-24 03:21:19.348799
# Unit test for function get_tree_node
def test_get_tree_node():
    class Tree(dict):
        __getattr__ = dict.__getitem__

    # Simple tree:
    #  - tree
    #      - 'person'
    #          - 'name' = 'John Doe'
    #          - 'age' = 42
    tree = Tree()
    tree.person = Tree()
    tree.person.name = 'John Doe'
    tree.person.age = 42

    # Test valid values
    assert get_tree_node(tree, 'person:name') == 'John Doe'
    assert get_tree_node(tree, 'person:age') == 42

    # Test invalid values
    with pytest.raises(KeyError):
        get_tree_node(tree, 'person:gender')

# Generated at 2022-06-24 03:21:24.260106
# Unit test for function tree
def test_tree():
    t1 = tree()
    t1['a']['b']['c'] = 'd'
    assert t1['a']['b']['c'] == 'd'
    assert t1['a:b:c'] == 'd'

    t1['a']['b'] = 'e'
    assert t1['a:b'] == 'e'
    assert t1['a']['b'] == 'e'

    t2 = tree()
    t2['a']['b']['c'] = [1, 2, 3]
    t2['a']['b']['d'] = [4, 5, 6]
    t2['a']['b:c'] = [7, 8, 9]

# Generated at 2022-06-24 03:21:35.087832
# Unit test for function get_tree_node
def test_get_tree_node():
    # Test
    my_dict = {'a': 3, 'b': {'c': {'d': 4, 'e': 5}, 'f': 6}, 'g': 7}

    # Check output
    assert get_tree_node(my_dict, 'b:c') == {'d': 4, 'e': 5}

    # Check output
    assert get_tree_node(my_dict, 'b:c:e') == 5

    # Check output
    assert get_tree_node(my_dict, 'b:c:e', default=3) == 5

    # Check output
    assert get_tree_node(my_dict, 'j', default=6) == 6

    # Check output
    assert get_tree_node(my_dict, 'j', default=8) == 8


# Generated at 2022-06-24 03:21:44.048492
# Unit test for function get_tree_node
def test_get_tree_node():
    from nose.tools import assert_equals, assert_raises

    # Create a test tree
    test_data = {
        'one': {
            'two': 2
        },
        'none': {
            'nope': None,
            'no': False
        }
    }

    # Test returning a value
    assert_equals(get_tree_node(test_data, 'one:two'), 2)
    assert_equals(get_tree_node(test_data, 'none:no'), False)
    assert_equals(get_tree_node(test_data, 'none:nope'), None)

    # Test returning a parent node
    assert_equals(get_tree_node(test_data, 'one:two', default=None, parent=True), {
        'two': 2
    })


# Generated at 2022-06-24 03:21:46.553074
# Unit test for constructor of class Tree
def test_Tree():
    h = {
        'h': 'Hello'
    }
    t = Tree(h)
    assert t['h'] == 'Hello'

    t = Tree(h, namespace='a')
    assert t['h'] == 'Hello'

    t['a:h'] == 'Hello'



# Generated at 2022-06-24 03:21:55.741759
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    t['a'] = 'a'
    t['b:a'] = 'ba'
    t['b:b'] = 'bb'
    t['b:c'] = 'bc'
    t['b:d'] = 'bd'
    t['c'] = 'c'
    t['d'] = 'd'

    t.update({
        'e': 'e',
        'b:f': 'bf',
    })

# Generated at 2022-06-24 03:22:00.535376
# Unit test for function tree
def test_tree():
    d = tree()
    d['a']['b'] = 'c'
    d['a']['d'] = 'e'
    assert d['a']['b'] == 'c'
    assert d['a']['d'] == 'e'
    assert d['a']['f'] == {}



# Generated at 2022-06-24 03:22:09.100275
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    from nose.tools import assert_raises
    tree = Tree(initial={'a': {'b': {'c': 'test'}}})
    assert tree['a:b:c'] == 'test'
    assert tree.get('a:b:d') is None
    assert_raises(KeyError, tree.get, 'a:b:d', KeyError)
    assert tree.get('a:b:d', 'default') == 'default'
    assert tree.get('a:b:d', default='default') == 'default'


if __name__ == '__main__':
    exit(__import__('nose2').main())

# Generated at 2022-06-24 03:22:16.958389
# Unit test for function set_tree_node

# Generated at 2022-06-24 03:22:24.914663
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    r = RegistryTree()
    # Alias
    r.register('test', 'foo')
    assert r['test'] == 'foo'
    r['test'] = 'bar'
    assert r['test'] == 'bar'
    r.register('test:sub:subsub', 'biz')
    assert r['test'] == 'bar'
    assert r['test:sub'] == {'subsub': 'biz'}
    assert r['test:sub:subsub'] == 'biz'
    assert r.get('test:sub:subsub:not:here') is None

# Generated at 2022-06-24 03:22:30.899843
# Unit test for function set_tree_node
def test_set_tree_node():
    d = tree()
    set_tree_node(d, 'red:matte', 0)
    set_tree_node(d, 'red:glossy', 100)
    set_tree_node(d, 'red:metallic', 200)
    set_tree_node(d, 'blue:matte', 300)
    set_tree_node(d, 'blue:glossy', 400)
    set_tree_node(d, 'blue:metallic', 500)
    print(d)



# Generated at 2022-06-24 03:22:38.795471
# Unit test for function get_tree_node
def test_get_tree_node():
    """Unit test for function `get_tree_node`."""
    assert get_tree_node(tree, '', default=False) is False
    assert get_tree_node(tree, 'a:b:c:d') == {}
    assert get_tree_node(tree, 'a:b:c:d', parent=True) == {
        'c': {}
    }



# Generated at 2022-06-24 03:22:42.971884
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}
    set_tree_node(tree, u'foo:bar:baz', u'qux')
    assert tree == {'foo': {'bar': {'baz': u'qux'}}}


if __name__ == '__main__':
    test_set_tree_node()

# Generated at 2022-06-24 03:22:46.670879
# Unit test for function set_tree_node
def test_set_tree_node():
    key = 'foo:bar:baz'
    d = {}
    assert set_tree_node(d, key, 'bat')[key] == 'bat'
    d = tree()
    assert set_tree_node(d, key, 'bat')[key] == 'bat'



# Generated at 2022-06-24 03:22:51.352986
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    instance = Tree()
    assert(instance['foo'] == {})
    assert(instance['foo:bar'].get('baz') == None)
    assert(instance['foo:bar:baz'] == {})



# Generated at 2022-06-24 03:22:57.193097
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    e = RegistryTree()
    assert isinstance(e, collections.defaultdict)
    # Check for existence of namespace
    assert e.namespace is None
    # Check for the namespace to be set correctly
    test = RegistryTree('foo')
    assert test.namespace == 'foo'
    # Check for defaultdict functionality
    test = RegistryTree()
    test['foo']['bar'] = 'hello'
    assert test['foo']['bar'] == 'hello'



# Generated at 2022-06-24 03:22:59.691050
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree(initial={'hi': 1}, initial_is_ref=False)
    t2 = Tree(initial=t, initial_is_ref=True)
    assert t2 == t



# Generated at 2022-06-24 03:23:01.097383
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree({'a': {'b': 1}}, namespace='test')
    assert t['a:b'] == 1

# Generated at 2022-06-24 03:23:07.142044
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree = Tree()
    tree['a'] = '1'
    tree['b'] = '2'
    tree['c'] = '3'

    assert tree['a'] == '1'
    assert tree['b'] == '2'
    assert tree['c'] == '3'



# Generated at 2022-06-24 03:23:10.885415
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    pass


if __name__ == '__main__':
    test_Tree___getitem__()

# Generated at 2022-06-24 03:23:14.192722
# Unit test for constructor of class Tree
def test_Tree():
    import pytest
    t = Tree(initial={'a': 1})
    assert t['a'] == 1
    with pytest.raises(KeyError):
        t['b']
    assert t.get('b', default=2) == 2
    assert t.setdefault('b', 2) == 2



# Generated at 2022-06-24 03:23:21.642366
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    from pprint import pprint
    tree = Tree()
    tree.register('a:b:c', 'Hello')
    assert tree['a']['b']['c'] == 'Hello'
    assert tree['a:b']['c'] == 'Hello'
    assert tree['a:b:c'] == 'Hello'

    tree.register('a:b', 'World')
    assert tree['a']['b']['c'] == 'Hello'
    assert tree['a']['b'] == 'World'
    assert tree['a:b:c'] == 'Hello'

    # pprint(dict(tree))
    tree = Tree()
    tree.register('namespace:a:b:c', 'Hello')
    assert tree['a:b']['c'] == 'Hello'

    # pprint(dict

# Generated at 2022-06-24 03:23:25.461197
# Unit test for function tree
def test_tree():
    from pprint import pprint
    t = tree()
    t['a']['b']['c'] = 'd'
    pprint(t)



# Generated at 2022-06-24 03:23:29.677133
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {'a': {'b': 4}, 'c': {'d': {'e': 5}}}
    assert get_tree_node(mapping, 'a:b') == 4
    assert get_tree_node(mapping, 'c:d:e') == 5
    assert get_tree_node(mapping, 'a:b:c') == _sentinel



# Generated at 2022-06-24 03:23:37.398997
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree()
    t['a']['b']['c'] = 1
    t['a']['b']['d'] = 2
    t['a']['b']['e'] = 3
    t['a']['f'] = 4
    t['g'] = 5
    assert t['a']['b:c'] == 1
    assert t['a']['b']['d'] == 2
    assert t['a']['b']['e'] == 3
    assert t['a']['f'] == 4
    assert t['g'] == 5



# Generated at 2022-06-24 03:23:45.960441
# Unit test for function tree
def test_tree():
    t = tree()
    t['foo']['bar'] = 'baz'
    assert t['foo'] == {'bar': 'baz'}
    assert t['foo']['bar'] == 'baz'

    # Unit test for function get_tree_node
    assert get_tree_node(t, 'foo') == {'bar': 'baz'}

    # Unit test for function get_tree_node
    assert get_tree_node(t, 'foo:bar') == 'baz'

    # Unit test for function set_tree_node
    set_tree_node(t, 'foo:bar2', 'baz2')
    assert 'bar2' in t['foo']
    assert t['foo']['bar2'] == 'baz2'

    # Unit test for function get_tree_node
   

# Generated at 2022-06-24 03:23:49.260726
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    registry_tree = RegistryTree()



# Generated at 2022-06-24 03:23:57.040252
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree = Tree()

    tree.update(
        {'a': {'b': {'c': 1}}},
    )

    assert tree == {'a': {'b': {'c': 1}}}
    assert tree['a:b:c'] == 1
    assert tree['a:d', None] is None
    assert tree.namespace is None

    tree_namespaced = Tree(tree, 'foo')

    assert tree_namespaced == {'foo': {'a': {'b': {'c': 1}}}}
    assert tree_namespaced['a:b:c'] == 1
    assert tree_namespaced['a:d', None] is None
    assert tree_namespaced.namespace == 'foo'

    try:
        tree['a:d']
    except KeyError:
        pass

# Generated at 2022-06-24 03:24:01.979846
# Unit test for function set_tree_node
def test_set_tree_node():
    d = {}
    o = set_tree_node(d, 'extensions:mimetypes', [])
    assert o == d['extensions']['mimetypes']
    set_tree_node(d, 'extensions:mimetypes:pink', 'floyd')
    assert d['extensions']['mimetypes']['pink'] == 'floyd'


# Generated at 2022-06-24 03:24:05.585207
# Unit test for function tree
def test_tree():
    from test_tree import _test_tree as test_tree_func
    test_tree_func(tree)


if __name__ == '__main__':
    test_tree()

# Generated at 2022-06-24 03:24:14.000386
# Unit test for function tree
def test_tree():
    tree = {
        'apples': {
            'wax': 'red',
            'royal': 'green',
        },
        'bananas': {
            'yellow',
        },
        'pears': {
            'purple',
        },
    }

    assert get_tree_node(tree, 'apples:wax') == 'red'
    assert get_tree_node(tree, 'apples:royal') == 'green'

    assert set_tree_node(tree, 'apples:wax', 'blue') == {
        'wax': 'blue',
        'royal': 'green',
    }