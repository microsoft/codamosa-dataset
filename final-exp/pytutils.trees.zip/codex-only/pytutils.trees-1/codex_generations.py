

# Generated at 2022-06-24 03:14:14.618162
# Unit test for function set_tree_node
def test_set_tree_node():
    t = tree()
    set_tree_node(t, 'foo:bar:baz', 'bamf')
    assert get_tree_node(t, 'foo:bar:baz') == 'bamf'
    assert get_tree_node(t, 'foo:bar')['baz'] == 'bamf'
    assert get_tree_node(t, 'foo')['bar']['baz'] == 'bamf'



# Generated at 2022-06-24 03:14:16.924672
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()
    value = 'foo'
    tree["bar"] = value
    assert tree.get("bar") == value



# Generated at 2022-06-24 03:14:23.521764
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree()
    t['a'] = "Hello"
    t['a:b'] = "World"
    t['a:c'] = "Ponies"
    t['a:b:c'] = "Ponies"
    t['a:b:d'] = "Ponies"
    assert t['a'] == "Hello"
    assert t['a:b'] == "World"
    assert t['a:b:d'] == "Ponies"



# Generated at 2022-06-24 03:14:31.229549
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree = Tree()
    tree['foo:bar'] = 'baz'
    assert tree['foo']['bar'] == 'baz'
    assert tree['foo:bar'] == 'baz'
    assert tree['foo']['bar'] == tree['foo:bar']

    tree = Tree()
    tree['foo'] = tree()
    tree['foo']['bar'] = 'baz'
    assert tree['foo']['bar'] == 'baz'
    assert tree['foo:bar'] == 'baz'
    assert tree['foo']['bar'] == tree['foo:bar']

    tree = Tree()
    tree['foo'] = {}
    tree['foo']['bar'] = 'baz'
    assert tree['foo']['bar'] == 'baz'

# Generated at 2022-06-24 03:14:35.822394
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    """Test case for Tree.__getitem__

    Arguments:
        <str>: <str>"""

    # Test Tree().__getitem__(), expected <str>
    # Test Tree.__getitem__(<str>), expected <str>
    pass

# Generated at 2022-06-24 03:14:41.405686
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'a': {'b': {'c': 2}}}, 'a:b:c') == 2
    assert get_tree_node({'a': {'b': {'c': 2}}}, 'a:b:c', default=3) == 2
    assert get_tree_node({'a': {'b': {'c': 2}}}, 'f:b:c', default=3) == 3
    assert get_tree_node({'a': {'b': {'c': 2}}}, 'f:b:c') == KeyError


# Generated at 2022-06-24 03:14:52.656022
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    t['foo'] = 'bar'
    assert t == {'foo': 'bar'}
    t['bar'] = 'baz'
    assert t == {'foo': 'bar', 'bar': 'baz'}
    t['baz:foo'] = 'bar'
    assert t == {'foo': 'bar', 'bar': 'baz', 'baz': {'foo': 'bar'}}
    t['baz:bar'] = 'foo'
    assert t == {'foo': 'bar', 'bar': 'baz', 'baz': {'foo': 'bar', 'bar': 'foo'}}
    t['baz:bar:foo'] = 'bar'

# Generated at 2022-06-24 03:14:54.636296
# Unit test for constructor of class Tree
def test_Tree():
    test = Tree()
    test.test = Tree()
    assert isinstance(test.test, Tree)


if __name__ == '__main__':
    test_Tree()

# Generated at 2022-06-24 03:15:00.415472
# Unit test for function set_tree_node
def test_set_tree_node():
    test_dict = {}
    test_key = "test_1:test_2"
    test_value = "test_3"
    set_tree_node(test_dict, test_key, test_value)
    assert get_tree_node(test_dict, test_key) == test_value

# Generated at 2022-06-24 03:15:05.061951
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()
    tree['foo'] = 'bar'
    assert tree == {'foo': 'bar'}
    tree['foo:bar'] = 'baz'
    assert tree == {'foo': {'bar': 'baz'}}



# Generated at 2022-06-24 03:15:06.702003
# Unit test for constructor of class Tree
def test_Tree():
    assert Tree(initial={'a': 3}).get('a') == 3



# Generated at 2022-06-24 03:15:09.854114
# Unit test for function tree
def test_tree():
    assert tree()
    my_tree = tree()
    my_tree[1] = 2
    my_tree[2][3] = 4
    assert my_tree == {1: 2, 2: {3: 4}}



# Generated at 2022-06-24 03:15:13.296115
# Unit test for constructor of class Tree
def test_Tree():
    assert Tree(initial_is_ref=True)
    assert Tree(initial={'a': {'b': {'c': {'d': {'e': ''}}}}})
    assert Tree(initial={'a': {'b': {'c': {'d': {'e': ''}}}}}, initial_is_ref=True)
    assert Tree(initial_is_ref=True, namespace='a')

# Generated at 2022-06-24 03:15:16.117044
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()
    tree['a:b:c:d'] = 'test'
    assert tree == {'a': {'b': {'c': {'d': 'test'}}}}



# Generated at 2022-06-24 03:15:19.574668
# Unit test for constructor of class Tree
def test_Tree():
    initial = {'a': 'A'}
    Tree(initial)
    Tree(initial, 'initial')  # should not be initial_is_ref
    Tree(initial_is_ref=True)  # should raise an exception

    pass



# Generated at 2022-06-24 03:15:24.085102
# Unit test for function tree
def test_tree():
    map_ = tree()
    map_['a']['b']['c'] = 'value'
    assert map_['a']['b']['c'] == 'value'

    map_['a:b:c'] = 'value'
    assert map_['a']['b']['c'] == 'value'



# Generated at 2022-06-24 03:15:26.808331
# Unit test for function set_tree_node
def test_set_tree_node():
    d = {}
    set_tree_node(d, 'a:b:c', 'test')
    assert d == {'a': {'b': {'c': 'test'}}}


# Generated at 2022-06-24 03:15:36.034885
# Unit test for function tree
def test_tree():
    t = tree()
    t['a:b:c:d:e:f'] = 1
    assert t['a']['b']['c']['d']['e']['f'] == 1
    t['a:b:c'] = 2
    assert t['a']['b']['c'] == 2
    assert get_tree_node(t, 'a') is t['a']
    assert get_tree_node(t, 'a:b') is t['a']['b']
    assert get_tree_node(t, 'a:b:c:d:e:f') == 1
    assert get_tree_node(t, 'a:b:c') == 2

# Generated at 2022-06-24 03:15:40.562265
# Unit test for function tree
def test_tree():
    """
    >>> test_tree()
    {'a': {'b': {'c': 'd'}}}
    >>> test_tree()['a']['b']['c']
    'd'
    """
    t = tree()
    t['a']['b']['c'] = 'd'
    return t



# Generated at 2022-06-24 03:15:47.370209
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():

    def assert_tree_keys(tree, ks, k_s):
        for k, v in ks:
            assert tree[k] == v
        for ks_ in k_s:
            assert tree[ks_] == 1

    T = Tree()
    T['a'] = 1
    assert_tree_keys(T, [('a', 1)], [['a']])
    T['a:b'] = 1
    assert_tree_keys(T, [('a', 1), ('a:b', 1)], [['a'], ['a:b']])
    T['a:b:c'] = 1

# Generated at 2022-06-24 03:15:55.992468
# Unit test for function set_tree_node
def test_set_tree_node():
    import copy

    test_data = {
        'a': {
            'b': {
                'c': 'test'
            }
        }
    }
    modified = copy.deepcopy(test_data)
    set_tree_node(modified, 'd:e:f', 'test2')
    assert modified == {
        'a': {
            'b': {
                'c': 'test'
            }
        },
        'd': {
            'e': {
                'f': 'test2',
            }
        }
    }



# Generated at 2022-06-24 03:16:00.082601
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    value = 42
    key = 'foo:bar:baz'
    result = t.__setitem__(key, value)
    expected = {'foo': {'bar': {'baz': value}}}
    assert result == expected



# Generated at 2022-06-24 03:16:07.631944
# Unit test for constructor of class Tree
def test_Tree():
    """
    >>> test = Tree(initial={'a':'b'}, namespace='test')
    >>> 'a' in test
    False
    >>> 'test:a' in test
    True
    """

    # Unit test for classmethod update
    def test_update(self):
        pass

    # Unit test for classmethod register
    def test_register(self):
        pass


if __name__ == '__main__':
    import doctest
    doctest.testmod(optionflags=doctest.REPORT_ONLY_FIRST_FAILURE)

# Generated at 2022-06-24 03:16:12.629982
# Unit test for function set_tree_node
def test_set_tree_node():
    test_dict = {}

    # Test top-level addition
    set_tree_node(test_dict, 'foo', 3)
    assert test_dict == {'foo': 3}, test_dict

    # Test second-level addition
    set_tree_node(test_dict, 'bar:baz', 5)
    assert test_dict == {'foo': 3, 'bar': {'baz': 5}}, test_dict



# Generated at 2022-06-24 03:16:15.617592
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree()
    t['a'] = 1
    t['b'] = 2
    assert t['a'] == 1
    assert t['b'] == 2
    assert t['c'] is None



# Generated at 2022-06-24 03:16:21.328761
# Unit test for function get_tree_node
def test_get_tree_node():
    """Unit test for function get_tree_node."""
    mapping = tree()
    mapping['a']['b']['c'] = 'd'
    return mapping, get_tree_node(mapping, 'a:b:c', default=_sentinel), get_tree_node(mapping, 'a:x:c', default=-1)



# Generated at 2022-06-24 03:16:24.477223
# Unit test for function set_tree_node
def test_set_tree_node():
    d = {}
    assert set_tree_node(d, 'a:b:c:d:e:f:g', 1) == {'a': {'b': {'c': {'d': {'e': {'f': {'g': 1}}}}}}}



# Generated at 2022-06-24 03:16:32.959607
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = Tree()
    assert tree.set_tree_node({'foo': {'bar': 42}}, 'foo:bar', 17) == {'foo': {'bar': 42}}
    assert tree == {'foo': {'bar': 42}}

    assert tree.set_tree_node({'foo': 17}, 'foo', 42) == {'foo': 17}
    assert tree == {'foo': 42}



# Generated at 2022-06-24 03:16:43.134788
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    """
    Unit test for method __setitem__ of class Tree
    """
    import types

    tree = Tree()

    tree.__setitem__('a', 1)
    assert tree['a'] == 1

    tree.__setitem__('a:b:c:d:e', 2)
    assert tree['a:b:c:d:e'] == 2

    tree.__setitem__('f', 3)
    assert tree['f'] == 3

    ref = tree['a']
    assert ref['b']['c']['d']['e'] == 2

    # very basic sanity checks below
    assert isinstance(tree['a'], Tree)
    assert isinstance(tree['a']['b'], Tree)
    assert isinstance(tree['a:b'], Tree)

# Generated at 2022-06-24 03:16:45.584742
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    # TODO: Readd this test
    return
    t = Tree()
    assert t['a']['b'] == {}



# Generated at 2022-06-24 03:16:53.467871
# Unit test for function get_tree_node
def test_get_tree_node():
    data = {
        'a': 'b',
        'c': {
            'd': {
                'e': 'f',
            },
        },
    }
    assert get_tree_node(data, 'a') == 'b'
    assert get_tree_node(data, 'c') == {'d': {'e': 'f'}}
    assert get_tree_node(data, 'c:d') == {'e': 'f'}
    assert get_tree_node(data, 'c:d:e') == 'f'



# Generated at 2022-06-24 03:16:58.403176
# Unit test for constructor of class Tree
def test_Tree():
    # Create test data structures
    # a = {'a': {'b': {'c': {'d': 'e'}}}}
    b = {'a': {'b': {'c': {'d': 'e', 'f': 'g'}}}}
    # c = {'a': {'b': {'c': {'d': 'e', 'f': 'g'}, 'h': 'i'}}}
    # d = {'a': {'b': {'j': {'d': 'e', 'f': 'g'}, 'h': 'i', 'c': 'k'}}}

    # Test tree instance
    # Should return 'e'
    tree = Tree(b)
    assert tree['a:b:c:d'] == 'e'

    # Test namespace
    # Should return 'g'
   

# Generated at 2022-06-24 03:17:00.605885
# Unit test for function tree
def test_tree():

    tree = tree()
    tree['one']['two']['three'] = 'testing'
    assert tree['one']['two']['three'] == 'testing'



# Generated at 2022-06-24 03:17:07.205347
# Unit test for function tree
def test_tree():
    # TODO Test with different kinds of underlying tree
    tree = Tree()
    tree['foo:bar:baz'] = 'some value'
    tree.update({
        'some:numbers': '1, 2, 3',
        'some:other:numbers': '4, 5, 6',
    })

    test_tree = Tree()
    test_tree['foo']['bar']['baz'] = 'some value'
    test_tree['some']['numbers'] = '1, 2, 3'
    test_tree['some']['other']['numbers'] = '4, 5, 6'
    assert tree == test_tree

# Generated at 2022-06-24 03:17:10.264131
# Unit test for function set_tree_node
def test_set_tree_node():
    t_obj = tree()
    set_tree_node(t_obj, 'x.y.z', 0)
    assert t_obj['x']['y']['z'] == 0



# Generated at 2022-06-24 03:17:20.175620
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree()
    t["a"]["b"]["c"] = "d"
    assert t['a:b:c'] == "d", "Tree cannot set tree but can get tree"

    t = Tree(initial={"a": "b"})
    assert t["a"] == "b", "Tree cannot set and get initial values"

    t = Tree(initial={"a": "b"}, namespace=None)
    assert t["a"] == "b", "Tree cannot set and get initial values when namespace is None"

    t = Tree(initial={"a": "b"}, namespace='')
    assert t["a"] == "b", "Tree cannot set and get initial values when namespace is ''"

    t = Tree(initial={"a": "b"}, namespace='n')

# Generated at 2022-06-24 03:17:22.321852
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    r = RegistryTree()
    assert isinstance(r, RegistryTree)
    assert isinstance(r, Tree)
    assert isinstance(r, collections.defaultdict)

# Generated at 2022-06-24 03:17:24.412304
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    t['a:b:c:d'] = 3
    assert t['a:b:c:d'] == 3



# Generated at 2022-06-24 03:17:30.773964
# Unit test for function get_tree_node
def test_get_tree_node():
    data = {
        'a': {
            'b': {
                'c': {
                    'd': 1
                }
            }
        }
    }

    assert get_tree_node(data, 'a') == data['a']
    assert get_tree_node(data, 'a:b') == data['a']['b']
    assert get_tree_node(data, 'a:b:c:d', default='DEADBEEF') == 1
    with pytest.raises(KeyError):
        get_tree_node(data, 'a:b:c:e')
    with pytest.raises(KeyError):
        get_tree_node(data, 'a:b:c:e', default='DEADBEEF')



# Generated at 2022-06-24 03:17:37.047159
# Unit test for constructor of class Tree
def test_Tree():
    """Tests setting and getting of arbitrary tree nodes"""

    my_tree = Tree()
    my_tree.register('first', 1)
    my_tree.register('second', 2)
    my_tree.register('first:second', 1.2)
    my_tree.register('first:third:second', 12)

    print(my_tree, my_tree.get('first'))
    print(my_tree, my_tree.get('second'))
    print(my_tree, my_tree.get('first:second'))
    print(my_tree, my_tree.get('first:third:second'))


if __name__ == '__main__':
    test_Tree()

# Generated at 2022-06-24 03:17:39.657033
# Unit test for function set_tree_node
def test_set_tree_node():
    obj = {}
    set_tree_node(obj, 'foo', 'bar')
    assert obj == {'foo': 'bar'}



# Generated at 2022-06-24 03:17:45.097751
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    tree = RegistryTree({'data': 'present', 'interesting:data': 'present'})
    assert(isinstance(tree, RegistryTree))
    assert(tree['data'] == 'present')
    assert(tree['interesting:data'] == 'present')
    print('\033[92mPASSED\033[0m test_RegistryTree')

# Generated at 2022-06-24 03:17:47.253788
# Unit test for function tree
def test_tree():
    root = tree()
    root['a']['b'] = 'c'
    assert root['a']['b'] == 'c'



# Generated at 2022-06-24 03:17:54.969075
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    d = Tree()
    d['foo'] = 'Foo'
    assert d.get('foo') == 'Foo'
    assert d.get('foo:bar') is None
    assert d.get('bar') is None
    assert d.get('bar', namespace='foo') is None
    d['foo:bar'] = 'Foo:Bar'
    assert d.get('foo:bar') == 'Foo:Bar'
    assert d.get('foo') == 'Foo'
    assert d.get('bar') is None
    assert d.get('bar', namespace='foo') is None
    assert d['foo:bar'] == 'Foo:Bar'
    assert d['foo'] == 'Foo'
    d['foo:baz'] = 'Foo:Baz'
    assert d['foo'] == 'Foo'

# Generated at 2022-06-24 03:18:00.408260
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    # Construct tree
    tree = RegistryTree(namespace='foo')
    # Register item
    tree.register('bar', 'test')
    # Get item
    tree.get('bar') == 'test'


if __name__ == '__main__':
    # Unit test for function get_tree_node
    def test_get_tree_node():
        # Create dict
        dict = {
            'a': {
                'b': {
                    'c': 'test',
                }
            }
        }
        # Get nested value
        get_tree_node(dict, 'a:b:c') == 'test'
        # Get nested value with default
        get_tree_node(dict, 'a:b:c:d', default='test') == 'test'
        # Get nested value with parent
        get_tree_

# Generated at 2022-06-24 03:18:07.609276
# Unit test for function set_tree_node
def test_set_tree_node():
    t = tree()
    set_tree_node(t, 'a:b:c', 'foo')
    assert t['a']['b']['c'] == 'foo'
    set_tree_node(t, 'a:b:c', 'bar')
    assert t['a']['b']['c'] == 'bar'



# Generated at 2022-06-24 03:18:17.111855
# Unit test for function get_tree_node
def test_get_tree_node():

    # Arrange
    tree = {
        'config': {
            'gametypes': {
                'nad_ctf': {
                    'scorelimits': {
                        'default': {
                            'fraglimit': 100,
                            'capturelimit': 3,
                        }
                    }
                },
                'nad_dm': {
                    'scorelimits': {
                        'default': {
                            'fraglimit': 500,
                            'capturelimit': 2,
                        }
                    }
                }
            }
        }
    }

    # Act + Assert
    assert get_tree_node(tree, 'config') == tree['config']
    assert get_tree_node(tree, 'config:gametypes') == tree['config']['gametypes']

# Generated at 2022-06-24 03:18:18.973216
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree()
    t['foo'] = 'bar'
    assert t['foo'] == 'bar'



# Generated at 2022-06-24 03:18:21.752920
# Unit test for function tree
def test_tree():
    node = tree()
    node['a']['b']['c'] = 'd'
    assert node['a:b:c'] == 'd', 'tree() traversal failed'



# Generated at 2022-06-24 03:18:30.176243
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    class PluginRegistry(RegistryTree):
        pass

    plugin = PluginRegistry()

    # Register some stuff
    plugin.register('network', 'http', 'https://example.com/json')
    plugin.register('network', 'irc', 'irc://irc.example.com/channel')

    assert plugin['network:http'] == 'https://example.com/json'
    assert plugin['network:irc'] == 'irc://irc.example.com/channel'

    # Retrieve reference to one of the plugins
    some_plugin = plugin['network']

    assert some_plugin['http'] == 'https://example.com/json'



# Generated at 2022-06-24 03:18:34.072792
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = RegistryTree(namespace='global')
    tree.register('foo', 'bar')
    tree.register('foom:bar:baz', 'foobar')
    assert tree['global:foo'] == 'bar'
    assert tree['global:foom:bar:baz'] == 'foobar'



# Generated at 2022-06-24 03:18:39.951823
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    # This should be fine
    obj = {'key': 'value'}
    reg_tree = RegistryTree(obj)  # This should be fine
    obj = {}
    # reg_tree = RegistryTree(obj, initial_is_ref=True)

    # This should raise an exception cause obj is empty
    # reg_tree = RegistryTree(obj)

    try:
        # This should raise an exception cause obj is empty
        reg_tree = RegistryTree(obj)
    except BaseException:
        # FIXME: BaseException is too broad:
        #        it should be KeyError
        pass

# Generated at 2022-06-24 03:18:44.468266
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    """Unit test for constructor of class RegistryTree"""
    initial = {
        'a': {
            'b': {},
        },
    }
    registry = RegistryTree(initial=initial)
    assert registry['a']['b'] == {}



# Generated at 2022-06-24 03:18:51.841017
# Unit test for function get_tree_node
def test_get_tree_node():
    test_tree = {
        'blah': {
            'lorem': 'ipsum'
        }
    }

    assert get_tree_node(test_tree, 'blah:lorem') == 'ipsum'
    assert get_tree_node(test_tree, 'blah:lorem', default='dolor') == 'ipsum'
    assert get_tree_node(test_tree, 'blah:dolor', default='dolor') == 'dolor'
    assert get_tree_node(test_tree, 'blah:dolor') == KeyError



# Generated at 2022-06-24 03:18:58.544513
# Unit test for function set_tree_node
def test_set_tree_node():
    m = {}
    set_tree_node(m, 'a:b:c', 'd')
    assert m.get('a') and m.get('a').get('b') and m.get('a').get('b').get('c') == 'd'

    set_tree_node(m, 'e:f:g', 'h')
    assert m.get('e') and m.get('e').get('f') and m.get('e').get('f').get('g') == 'h'



# Generated at 2022-06-24 03:19:05.417666
# Unit test for constructor of class Tree
def test_Tree():
    import pytest
    t = Tree(initial_is_ref=True)
    t._namespace = 'foo'
    t['a'] = 'b'
    assert t['a'] == 'b'
    assert t['a'] == 'b'  # Make sure we can get twice.
    assert t['foo:a'] == 'b'
    assert t.get('foo:a') == 'b'
    with pytest.raises(KeyError):
        t['a2']
    t2 = Tree(initial_is_ref=t)
    assert t2['foo:a'] == 'b'
    assert t2['a'] == 'b'
    t2['a'] = 'b2'
    assert t2['a'] == 'b2'
    assert t2['foo:a'] == 'b2'
   

# Generated at 2022-06-24 03:19:09.503937
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()
    tree['a'] = 1
    assert 1 == tree['a'], 'Failed to lookup [a] with tree[a].'
    assert _sentinel is tree['b'], 'Failed to detect missing key [b].'



# Generated at 2022-06-24 03:19:10.940039
# Unit test for constructor of class Tree
def test_Tree():
    assert Tree() == Tree(initial_is_ref=True)



# Generated at 2022-06-24 03:19:20.806632
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree = Tree()
    tree['a'] = 'b'
    assert tree['a'] == 'b'
    assert tree.get('a') == 'b'

    # Test with namespace
    tree = Tree(namespace='foo')
    tree['a'] = 'b'
    assert tree['a'] == 'b'
    assert tree.get('a') == 'b'
    assert tree['foo:a'] == 'b'
    assert tree.get('foo:a') == 'b'

    # Test with namespace override
    tree = Tree(namespace='foo')
    tree['a'] = 'b'
    assert tree['a'] == 'b'
    assert tree['foo:a'] == 'b'
    assert tree['bar:a'] is _sentinel

    # Test with namespace override

# Generated at 2022-06-24 03:19:31.520203
# Unit test for function tree
def test_tree():
    assert get_tree_node(tree, 'a:b:c:d:e:f', default='novalue') == 'novalue'
    assert get_tree_node(tree, 'a:b:c:d:e:f') is None
    assert get_tree_node(tree, 'a:b:c:d:e:f') == get_tree_node(tree, 'a:b:c:d:e:f', default=None)

    t = tree()
    set_tree_node(t, 'a:b:c:d:e:f', 'value')
    assert get_tree_node(t, 'a:b:c:d:e:f') == 'value'
    # print(t)  # {'a': {'b': {'c': {'d': {'e': {

# Generated at 2022-06-24 03:19:41.386969
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()
    tree.register('foo', 'bar')
    assert tree['foo'] == 'bar'
    tree.register('foo:bar', 'baz')
    assert tree['foo:bar'] == 'baz'
    tree.register('foo:bar:baz', 'lol')
    assert tree['foo:bar:baz'] == 'lol'
    tree.register('foo:bar:lol', 'baz')
    assert tree['foo:bar:lol'] == 'baz'
    tree.register('foo:bar:lol:baz', 'nested')
    assert tree['foo:bar:lol:baz'] == 'nested'



# Generated at 2022-06-24 03:19:53.059899
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    rt = RegistryTree(initial={'a': {'b': {'c': 1}}})
    assert rt.get('a:b:c') == 1
    assert callable(rt)
    rt = rt({'a': {'b': {'c': 2}}}, initial_is_ref=True)
    assert id(rt) == id(rt())
    rt({'a': {'b': {'c': 3}}}, initial_is_ref=False)
    assert rt.get('a:b:c', default=None) == 2
    rt.register('a:b:c', 4)
    assert rt.get('a:b:c') == 4
    assert 'a:b:c:d:e' in rt
    assert 'a:b:c' in rt
   

# Generated at 2022-06-24 03:19:56.180561
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    test_tree = Tree()
    test_tree.__setitem__('key', 'value')
    assert test_tree['key'] == 'value'



# Generated at 2022-06-24 03:19:59.531920
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree()

# Generated at 2022-06-24 03:20:07.315418
# Unit test for function get_tree_node
def test_get_tree_node():
    # Test with a tree-like mapping
    collection = {
        'group_1': {
            'key_2': 'value_2',
        },
        'group_2': {
            'key_2': 'value_3',
        },
        'group_3': {
            'key_3': 'value_3',
        },
    }
    assert get_tree_node(collection, 'group_2:key_2') == 'value_3'

    # Verify KeyError raised properly
    try:
        get_tree_node(collection, 'fake:key')
    except KeyError:
        pass
    else:
        raise AssertionError('KeyError not raised')

# Generated at 2022-06-24 03:20:16.340329
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'chicken': {
            'wings': {
                'flavors': [{'hot': 'hot'}, {'teriyaki': 'teriyaki'}]
            }
        },
        'hot': 'yes'
    }
    result = get_tree_node(mapping, 'chicken:wings:flavors:0:hot', default=_sentinel)
    assert result == 'hot'
    result = get_tree_node(mapping, 'chicken:wings:flavors:0:salty', default=_sentinel)
    assert result is _sentinel
    result = get_tree_node(mapping, 'salty', default=_sentinel)
    assert result is _sentinel



# Generated at 2022-06-24 03:20:25.164366
# Unit test for function get_tree_node
def test_get_tree_node():
    """Unit test for function get_tree_node"""
    assert get_tree_node({}, 'a') is _sentinel
    assert get_tree_node({'a': {}}, 'a') == {}
    assert get_tree_node({'a': {}}, 'a:b') is _sentinel
    assert get_tree_node({'a': {}}, 'a:b', default=None) is None
    assert get_tree_node({'a': {'b': 0}}, 'a:b') == 0
    assert get_tree_node({'a': {'b': 0}}, 'a:b', parent=True) == {'a': {'b': 0}}



# Generated at 2022-06-24 03:20:34.887627
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    instance = Tree()
    instance['a'] = 1
    instance['b.c'] = 2
    instance['b.d.e'] = 3
    instance['b.d.f'] = 4

    assert instance['a'] == 1
    assert instance['b.c'] == 2
    assert instance['b.d.e'] == 3
    assert instance['b.d.f'] == 4

    instance = Tree()
    instance['a'] = 1
    instance['b:c'] = 2
    instance['b:d:e'] = 3
    instance['b:d:f'] = 4

    assert instance['a'] == 1
    assert instance['b:c'] == 2
    assert instance['b:d:e'] == 3
    assert instance['b:d:f'] == 4

# Generated at 2022-06-24 03:20:37.925486
# Unit test for function tree
def test_tree():
    t = tree()
    t['hello']['world']['monkey']['socks'] = True

    assert t['hello']['world']['monkey']['socks'] is True



# Generated at 2022-06-24 03:20:48.542966
# Unit test for constructor of class Tree
def test_Tree():
    import json
    # Example use case.
    config = Tree({'foo': 1,
                   'bar': 2,
                   'foobar': {'foo': 2, 'bar': 1}})
    assert config['foobar:foo'] == 2
    assert config['foobar:bar'] == 1

    config['foobar:foo'] = 3
    assert config['foobar:foo'] == 3
    assert 'foo' in config

    config['foobar'].update({'foo': 4, 'bar': 5})
    assert config['foobar:foo'] == 4
    assert config['foobar:bar'] == 5


# Generated at 2022-06-24 03:20:56.470887
# Unit test for function get_tree_node
def test_get_tree_node():
    """get_tree_node() - Test finding single node within a tree-like dictionary.
    
    Arguments:
        mapping collections.Mapping: Mapping to fetch from
        key str|unicode: Key to lookup, allowing for : notation
        default object: Default value. If set to `:module:_sentinel`, raise KeyError if not found.
        parent bool: If True, return parent node. Defaults to False.
    
    
    Returns:
        object: Value at specified key
    """
    test_mapping = {
        'test': {
            'test': {
                'test': 'test',
            },
        }
    }

    test_get_tree_node.assert_equal(get_tree_node(test_mapping, 'test:test:test'), 'test')



# Generated at 2022-06-24 03:20:58.893465
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree()
    t['a']['b']['c'] = 3
    assert t['a:b:c'] == 3
    assert t['a:b']['c'] == 3



# Generated at 2022-06-24 03:21:04.829188
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'a': {'b': {'c': 1}}}, 'a:b:c') == 1
    assert get_tree_node({'a': {'b': {'c': 1}}}, 'a:b:d') is None
    try:
        assert get_tree_node({'a': {'b': {'c': 1}}}, 'a:b:d', default=_sentinel)
    except KeyError:
        pass
    else:
        assert False, 'Expected KeyError not raised'



# Generated at 2022-06-24 03:21:09.469001
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree(namespace='com.example')
    t['something'] = 'value'
    assert t['something'] == 'value'
    assert t.get('something') == 'value'
    assert t['com.example:something'] == 'value'

    new_t = t['new']
    assert t['new'] == new_t
    assert t['com.example:new'] == new_t



# Generated at 2022-06-24 03:21:19.348756
# Unit test for function get_tree_node
def test_get_tree_node():
    # Test if raise KeyError when `_sentinel` is passed as the `default` parameter and key doesn't exist
    test_dict = {
        'key_a': {'key_aa': {'key_aaa': 'value_aaa'}, 'key_ab': 'value_ab'},
        'key_b': 'value_b',
    }

    assert get_tree_node(test_dict, 'key_a:key_aa:key_aaa') == 'value_aaa'
    assert get_tree_node(test_dict, 'key_a:key_ab') == 'value_ab'
    assert get_tree_node(test_dict, 'key_b') == 'value_b'
    assert get_tree_node(test_dict, 'not_here') == _sentinel  # this is what get_tree_

# Generated at 2022-06-24 03:21:21.392813
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {
        'one': {
            'two': {
                'three': 'four'
            }
        }
    }
    set_tree_node(tree, 'one:two:three:four', 'five')
    assert tree['one']['two']['three']['four'] == 'five'



# Generated at 2022-06-24 03:21:28.189125
# Unit test for function tree
def test_tree():
    """Test :py:func:`get_tree_node`."""

    # Unit test for function `get_tree_node`
    assert get_tree_node({'foo': {'bar': 'buzz'}}, 'foo:bar') == 'buzz'
    assert get_tree_node({}, 'foo:bar') is _sentinel



# Generated at 2022-06-24 03:21:37.715610
# Unit test for constructor of class Tree
def test_Tree():
    """Constructor of class Tree, namespace, set and get."""
    a = Tree(namespace='foo')
    assert a.namespace == 'foo'
    a['bar'] = 'baz'
    a['test'] = 'test'
    assert a['bar'] == 'baz'
    assert a['foo:bar'] == 'baz'
    assert a['foo:test'] == 'test'
    assert a['test'] == 'test'
    assert a['bar'] == 'baz'
    assert a['foo:bar'] == 'baz'
    assert a['foo:test'] == 'test'
    a['bar'] = 'baz'
    assert a['foo:bar'] == 'baz'
    a['bar'] = 'baz'
    assert a['foo:bar'] == 'baz'
   

# Generated at 2022-06-24 03:21:42.980119
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    from pytest import raises
    from .helpers import is_tree

    instance = Tree()
    instance.__setitem__('test')
    assert is_tree(instance)
    with raises(TypeError):
        instance.__setitem__()



# Generated at 2022-06-24 03:21:46.705494
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    """
    Test Tree.__getitem__.
    """
    registry_tree = RegistryTree()
    registry_tree['foo'] = 1
    registry_tree['bar:baz'] = 2
    assert registry_tree['foo'] == 1
    assert registry_tree['bar:baz'] == 2



# Generated at 2022-06-24 03:21:48.874166
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()
    tree['key1'] = 'value1'
    assert tree['key1'] == 'value1', 'Tree.__setitem__() failed.'



# Generated at 2022-06-24 03:21:50.295020
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    import doctest
    doctest.testmod(Tree['__setitem__'])



# Generated at 2022-06-24 03:21:53.105972
# Unit test for function set_tree_node
def test_set_tree_node():
    """Test set_tree_node"""
    a = Tree()
    a['a']['b'] = 'c'
    assert a['a']['b'] == 'c'



# Generated at 2022-06-24 03:22:02.026944
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    d = Tree({'bla': 'blub', 'foo': {'bar': 'baz'}})

    assert d['bla'] == 'blub'


# Generated at 2022-06-24 03:22:04.459186
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree({'a': {'b': {'c': 'd'}}})
    assert t['a:b:c'] == 'd'



# Generated at 2022-06-24 03:22:07.745234
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    tree = RegistryTree(namespace='test')
    tree.register('foo:bar:baz', 'qux')
    assert tree['foo:bar:baz'] == 'qux'
    assert tree.get('foo:bar:baz') == 'qux'
    assert tree.get('bar:bar:baz', 'foo') == 'foo'

# Generated at 2022-06-24 03:22:16.456498
# Unit test for function get_tree_node
def test_get_tree_node():
    test_mapping = {
        'foo': {
            'bar': 'baz'
        }
    }
    assert get_tree_node(test_mapping, 'foo') == {'bar': 'baz'}
    assert get_tree_node(test_mapping, 'foo:bar') == 'baz'

    assert get_tree_node(test_mapping, 'foo', default='fizz') == {'bar': 'baz'}
    assert get_tree_node(test_mapping, 'xyzzy', default='fizz') == 'fizz'
    with pytest.raises(KeyError):
        get_tree_node(test_mapping, 'fakey')



# Generated at 2022-06-24 03:22:21.692158
# Unit test for constructor of class Tree
def test_Tree():
    from django.utils.encoding import python_2_unicode_compatible

    @python_2_unicode_compatible
    class Foo(object):
        def __init__(self, app_label, name):
            self.app_label = app_label
            self.name = name

        def __str__(self):
            return self.name

    foo = Foo('foobar', 'Fubar')
    t = Tree()
    t['foo'] = foo
    t['bar:baz'] = 'Hello World'
    assert t['foo'].app_label == 'foobar', t['foo'].app_label
    assert t['bar:baz'] == 'Hello World', t['bar:baz']
    assert t['bar']['baz'] == 'Hello World', t['bar']['baz']


# Generated at 2022-06-24 03:22:32.155273
# Unit test for function tree
def test_tree():
    from pprint import pprint

    t = tree()
    t['fuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuu']['fuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuu']['fuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuu'] = 'fuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuu'
    pprint(t)

    t = tree()
    t['a']['b']['c'] = 'd'

# Generated at 2022-06-24 03:22:38.382199
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    """Create a RegistryTree instance, add and retrieve data"""
    rt = RegistryTree()
    rt.register('a', 'b')
    rt.register('c', 'd')
    assert rt['a'] == 'b'
    assert rt['c'] == 'd'



# Generated at 2022-06-24 03:22:40.712099
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    RT = RegistryTree()
    RT.register('tput time', ['0'])
    assert RT.get('tput time') == ['0']

# Generated at 2022-06-24 03:22:48.202462
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    # Test Tree with {}
    test = Tree()
    # Check that the result of __setitem__ of Tree with ('key', 'value')
    assert test.__setitem__('key', 'value') == get_tree_node(test, 'key', default=_sentinel)
    # Check that the result of __setitem__ of Tree with ('key:key', 'value')
    assert test.__setitem__('key:key', 'value') == get_tree_node(test, 'key:key', default=_sentinel)
    # Check that the result of __setitem__ of Tree with ('key:key:key', 'value')
    assert test.__setitem__('key:key:key', 'value') == get_tree_node(test, 'key:key:key', default=_sentinel)
    # Check that the result

# Generated at 2022-06-24 03:22:51.738977
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    test_tree = Tree()
    test_tree['foo'] = 'bar'
    assert test_tree['foo'] == 'bar'



# Generated at 2022-06-24 03:22:57.529384
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {'a': {'b': 0}}
    assert get_tree_node(mapping, 'a:b') == 0
    assert get_tree_node(mapping, 'b:c', default=None) is None
    assert get_tree_node(mapping, 'c:b', default=None, parent=True) is None
    assert get_tree_node(mapping, 'a:b', default=None, parent=True) == mapping['a']


# Generated at 2022-06-24 03:23:04.900409
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node(Tree({'test': {'test': {'test': 'a'},'test2': 123}}, namespace='a'), 'test:test:test', namespace='a') == 'a'
    assert get_tree_node(Tree({'test': {'test': 'a'},'test2': 123}), 'test:test') == 'a'
    assert get_tree_node(Tree({'test': {'test': 'a'},'test2': 123}), 'test2') == 123
    try:
        get_tree_node(Tree({'test': {'test': {'test': 'a'},'test2': 123}}, namespace='a'), 'test2', default='fail')
    except:
        pass
    else:
        assert False

# Generated at 2022-06-24 03:23:11.224160
# Unit test for function tree
def test_tree():
    a = tree()
    assert a.keys() == []
    assert a['a'].keys() == []
    assert a['a']['b'] == {}
    b = a['a']['b']
    assert b['c'].keys() == []
    b['c']['d'] = True
    assert b['c']['d'] is True



# Generated at 2022-06-24 03:23:14.818676
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree({'a': {'b':'c'}})
    assert t['a:b'] == 'c'
    t['a:b'] = 'd'
    assert t['a:b'] == 'd'
    t['a:c'] = 'e'
    assert t['a:c'] == 'e'



# Generated at 2022-06-24 03:23:22.182844
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree = Tree()
    tree[':foo'] = 1
    tree['foo:bar'] = 2
    tree['bar:foo:bar'] = 3

    # Regression test for #3 (https://github.com/jasonamyers/python-tree/issues/3)
    tree['foo:bar:baz'] = 4
    assert tree['foo:bar:baz'] == 4

    assert tree[':foo'] == 1
    assert tree['foo:bar'] == 2
    assert tree['bar:foo:bar'] == 3

    # Respecting default when key doesn't exist
    assert tree['baz:bam', 3] == 3

    # Respecting default when key doesn't exist when traversing down levels
    assert tree['baz:bam:foo', 3] == 3


# Generated at 2022-06-24 03:23:29.446994
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    from unittest import TestCase
    from ..__main__ import main

    class TestTree___getitem__(TestCase):
        def test___getitem__(self):
            t = Tree({'a': {'b': {'c': 3}}})
            assert t['a'] == {'b': {'c': 3}}
            assert t['a:b'] == {'c': 3}
            assert t['a:b:c'] == 3

    main(TestTree___getitem__())

# Generated at 2022-06-24 03:23:33.020306
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    t.register('s', 'test_value')
    assert t['s'] == 'test_value', 'test_Tree___setitem__ returned %s instead of test_value' % t['s']



# Generated at 2022-06-24 03:23:41.162536
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree = Tree()
    tree['a'] = {'b': 1, 'c': 2}
    assert tree['a:b'] == 1
    assert tree['a:c'] == 2

    # Test default

# Generated at 2022-06-24 03:23:49.163677
# Unit test for function get_tree_node
def test_get_tree_node():
    """Test for function get_tree_node"""
    test_mapping = {
        'foo': {
            'bar': {
                'spam': 'eggs',
                'ham': 'eggs',
            },
        },
    }
    assert get_tree_node(test_mapping, 'foo:bar:spam') == 'eggs'
    assert get_tree_node(test_mapping, 'foo:bar:ham') == 'eggs'
    assert get_tree_node(test_mapping, 'foo:baz') is _sentinel

# Generated at 2022-06-24 03:23:51.840595
# Unit test for constructor of class Tree
def test_Tree():
    tree = Tree()
    tree['a']['b'] = 'c'
    assert tree['a']['b'] == 'c'



# Generated at 2022-06-24 03:24:01.112315
# Unit test for function get_tree_node
def test_get_tree_node():
    test_dict = {
        'key_a': 'value_a',
        'key_b': {
            'key_c': {
                'key_d': 'value_d'
            },
            'key_e': 'value_e'
        }
    }
    assert get_tree_node(test_dict, 'key_a') == 'value_a'
    assert get_tree_node(test_dict, 'key_b:key_c:key_d') == 'value_d'
    assert get_tree_node(test_dict, 'key_b:key_c:key_e', default=None) is None
    assert get_tree_node(test_dict, 'key_b:key_c:key_e', default=None) is None

# Generated at 2022-06-24 03:24:10.074366
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    rt = RegistryTree(initial={'root': ['a', 'b', 'c']})
    assert len(rt) == 1
    assert rt['root'] == ['a', 'b', 'c']
    assert len(rt['root']) == 3

    rt = RegistryTree(initial={'root': ['a', 'b', 'c']}, initial_is_ref=True)
    assert len(rt) == 1
    assert rt['root'] == ['a', 'b', 'c']
    assert len(rt['root']) == 3

