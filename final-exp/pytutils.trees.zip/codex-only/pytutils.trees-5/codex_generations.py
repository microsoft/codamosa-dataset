

# Generated at 2022-06-24 03:14:17.144959
# Unit test for constructor of class Tree
def test_Tree():
    tree = Tree({'sample': {'key': 'value'}})
    assert tree.get('sample:key') == 'value'
    assert tree.get('sample:key2') is _sentinel
    tree['sample:key2'] = 'value2'
    assert tree.get('sample:key2') == 'value2'



# Generated at 2022-06-24 03:14:20.730048
# Unit test for constructor of class Tree
def test_Tree():
    data = {'foo': 'bar'}
    namespace = 'test'
    t = Tree(data, namespace=namespace)
    t2 = Tree(t, initial_is_ref=True)
    assert t == t2
    assert 'bar' == t.get('test:foo')


if __name__ == '__main__':
    test_Tree()

# Generated at 2022-06-24 03:14:25.277085
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    a = Tree()
    a.__setitem__('foo', 'bar')
    a.__setitem__('a:b:c', 'foo')
    assert a['foo'] == 'bar'
    assert a['a']['b']['c'] == 'foo'

    # Test that class extensibility works.
    class TestTree(Tree):
        pass

    a = TestTree()
    a.__setitem__('foo', 'bar')
    assert a['foo'] == 'bar'



# Generated at 2022-06-24 03:14:29.390150
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    a = RegistryTree()
    assert type(a) == RegistryTree
    assert 'RegistryTree' == a.__class__.__name__
    assert 'dict' == type(a).__name__
    a.register('foo', 'bar')
    assert a['foo'] == 'bar'


if __name__ == '__main__':
    test_RegistryTree()

# Generated at 2022-06-24 03:14:39.714169
# Unit test for function tree
def test_tree():
    """
    Test tree function.

    Returns:
        None
    """
    tree = collections.defaultdict(tree)
    assert tree == tree()
    assert tree() == tree()()
    tree["a"]["b"]["c"] = 1
    assert tree["a"]["b"]["c"] == 1
    tree["a"]["b"]["d"] = 1
    assert tree["a"]["b"]["d"] == 1
    tree["a"]["b"]["d"] = 2
    assert tree["a"]["b"]["d"] == 2
    tree["a"]["b"]["d"] += 1
    assert tree["a"]["b"]["d"] == 3
    tree["a"]["b"]["c"] += 1

# Generated at 2022-06-24 03:14:41.531328
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    tree = RegistryTree()
    tree.register('foo', 'bar')
    assert tree['foo'] is 'bar'
    assert tree['foo', ''] is 'bar'

# Generated at 2022-06-24 03:14:43.898999
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    tree = RegistryTree()
    tree.register('user', 'abcd')
    assert tree.get('user') is 'abcd'



# Generated at 2022-06-24 03:14:54.560172
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'a': 'b'}, 'a') == 'b'
    assert get_tree_node({'a': {'b': 'c'}}, 'a:b') == 'c'
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c') == 'd'
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c:d') is _sentinel
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:d') is _sentinel
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'b:c') is _sentinel

# Generated at 2022-06-24 03:15:01.166545
# Unit test for function tree
def test_tree():
    test = {'tree': {'foo': {'bar': 'baz'}}}
    assert tree()['foo']['bar'] is tree()['foo']['bar']
    assert tree()['foo']['bar'] is not tree()['foo']['bar']
    test = tree()
    test['foo']['bar'] = 'baz'
    assert test == {'foo': {'bar': 'baz'}}



# Generated at 2022-06-24 03:15:05.373745
# Unit test for function get_tree_node
def test_get_tree_node():
    t = tree()
    t['foo']['bar']['baz'] = 1
    assert get_tree_node(t, 'foo:bar:baz') == 1



# Generated at 2022-06-24 03:15:12.291127
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree()
    t['foo:bar:zed:yolo'] = 'swag'
    assert t['foo:bar:zed:yolo'] == 'swag'
    t['foo:bar:zed:yolo'] = 'swaaaaaaaaaag'
    assert t['foo:bar:zed'] == {'yolo': 'swaaaaaaaaaag'}
    t['foo:bar:veedub:yolo'] = 'swaaaaaaaaaag'
    assert t['foo:bar'] == {'veedub': {'yolo': 'swaaaaaaaaaag'}, 'zed': {'yolo': 'swaaaaaaaaaag'}}

# Generated at 2022-06-24 03:15:14.787158
# Unit test for constructor of class Tree
def test_Tree():
    tree = Tree()
    assert isinstance(tree, dict)
    assert isinstance(tree, collections.defaultdict)



# Generated at 2022-06-24 03:15:16.756923
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    instance = RegistryTree()

    # Add an entry
    instance.register('key', 'value')
    # and retrieve it
    assert instance.get('key') == 'value'

# Generated at 2022-06-24 03:15:18.699662
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()
    tree['foo'] = 'bar'
    assert tree['foo'] == 'bar'
    return True

# Generated at 2022-06-24 03:15:28.339086
# Unit test for function get_tree_node
def test_get_tree_node():
    """Usage:
    >>> test_get_tree_node()
    """
    # Setup
    test_paths = [
        ':a:b:c',
        ':a:b:d',
        ':a:b:e',
        ':a:b:f',
        ':a:b:g',
    ]
    mapping = tree()
    for path in test_paths:
        set_tree_node(mapping, path, None)

    # Test
    for path in test_paths:
        node = get_tree_node(mapping, path)
        assert node is None, 'Did not parse %s' % path
        node = get_tree_node(mapping, path, parent=True)

# Generated at 2022-06-24 03:15:32.802761
# Unit test for function get_tree_node
def test_get_tree_node():
    """Unit test for get_tree_node"""
    # Generate test object
    test_obj = tree()
    test_obj['key1'] = tree()
    test_obj['key2'] = tree()
    test_obj['key1']['subkey1'] = tree()
    test_obj['key1']['subkey2'] = tree()
    test_obj['key1']['subkey2']['subkey2_1'] = 'testvalue1'

    target = get_tree_node(test_obj, 'key1:subkey1')
    assert target == test_obj['key1']['subkey1']

    target = get_tree_node(test_obj, 'key1:subkey2:subkey2_1')
    assert target == 'testvalue1'


# Generated at 2022-06-24 03:15:42.771462
# Unit test for function set_tree_node
def test_set_tree_node():
    test_data = dict()
    assert set_tree_node(test_data, 'test:test1', 'test') == test_data['test']
    assert set_tree_node(test_data, 'test:test1', 'test') == test_data['test']['test1']
    assert set_tree_node(test_data, 'test:test2', 'test') == test_data['test']
    assert set_tree_node(test_data, 'test:test2', 'test') == test_data['test']['test2']
    assert set_tree_node(test_data, 'test:test2', 'test') == test_data['test']['test2']

# Generated at 2022-06-24 03:15:49.090102
# Unit test for function tree
def test_tree():
    t = tree()
    t['level1']['level2'] = 1
    t['level1']['level2'] = 2
    t['level1']['level2'] = 3
    t['level1']['level2']['level3'] = 3
    assert t['level1']['level2']['level3'] == 3
    assert t['level1']['level2'] == 3
    assert t['level1'] == {'level2': 3}



# Generated at 2022-06-24 03:15:57.876274
# Unit test for function tree
def test_tree():
    tree_ = {
        'hello': {
            'world': 'wat'
        }
    }
    tree_ = tree()
    result = get_tree_node(tree_, 'hello:world')
    assert result == {}
    result = get_tree_node(tree_, 'hello:world', default='wat')
    assert result == 'wat'
    result = get_tree_node(tree_, 'hello:world', default='wat', parent=True)
    assert result == {}
    set_tree_node(tree_, 'hello:world', 'wat')
    assert tree_['hello']['world'] == 'wat'



# Generated at 2022-06-24 03:16:09.077299
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    # By default, we want to use the latest version
    from . import _registered_api_versions
    _registered_api_versions.setdefault(None, max(_registered_api_versions.keys()))

    # Test for constructor
    t = RegistryTree()
    assert isinstance(t, RegistryTree)
    assert isinstance(t, Tree)
    assert isinstance(t, collections.defaultdict)
    assert isinstance(t, collections.MutableMapping)
    assert id(t['foo/bar']) == id(t['foo']['bar'])
    assert id(t['foo']['bar']) == id(t['foo']['bar'].data)
    assert t['foo']['bar'] is t['foo/bar'] is t['foo'].data['bar']

    # Test for namespace

# Generated at 2022-06-24 03:16:16.311143
# Unit test for constructor of class Tree
def test_Tree():
    import unittest
    d = {'level1': {'level2': "Should be possible"}}

    class TestTree1(Tree):
        pass

    class TestTree2(Tree):
        pass

    class TestTree3(Tree):
        pass

    class TestTree4(Tree):
        data = d

    class TestTree5(Tree):
        data = d

    t1 = TestTree1()
    t2 = TestTree2(initial=d)
    t3 = TestTree3(initial_is_ref=d)
    t4 = TestTree4()
    t5 = TestTree5(initial_is_ref=d)

    # Checking if initialized in a correct way
    assert t1['level1']['level2'] == ''

# Generated at 2022-06-24 03:16:23.635439
# Unit test for function get_tree_node

# Generated at 2022-06-24 03:16:33.441865
# Unit test for function get_tree_node
def test_get_tree_node():

    # Invalid mappings
    assert_raises(TypeError, get_tree_node, 'yolo', 'yolo')
    assert_raises(TypeError, get_tree_node, ['yolo'], 'yolo')

    # Single level, valid
    assert_equal(
        get_tree_node({'yolo': 'yolo'}, 'yolo'),
        'yolo'
    )
    # Multi level, valid
    assert_equal(
        get_tree_node({'yolo': {'yolo': 'yolo'}}, 'yolo:yolo'),
        'yolo'
    )
    # Multi level, missing

# Generated at 2022-06-24 03:16:42.454979
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree(initial={'foo': {'bar': 'baz'}})
    assert t['foo:bar'] == 'baz'
    assert t.get('foo:bar') == 'baz'
    assert t.get('foo:bar:quux', 'quux') == 'quux'

    with pytest.raises(KeyError):
        t['foo:quux']
    with pytest.raises(KeyError):
        t['foo:bar:baz']



# Generated at 2022-06-24 03:16:44.089356
# Unit test for function set_tree_node
def test_set_tree_node():
    a = {}
    assert set_tree_node(a, 'b:c', 'd')['c'] == 'd'



# Generated at 2022-06-24 03:16:46.312512
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()
    assert not tree['test']
    tree['test'] = 1
    assert tree['test'] == 1



# Generated at 2022-06-24 03:16:51.039999
# Unit test for function tree
def test_tree():
    try:
        tree()[0]['a']['b']['c']['d']['e']['f']['g']
        assert False
    except KeyError:
        pass



# Generated at 2022-06-24 03:16:55.992584
# Unit test for function set_tree_node
def test_set_tree_node():
    node = {}
    set_tree_node(node, 'a', 'b')
    assert node['a'] == 'b'
    set_tree_node(node, 'c:d', 'e')
    assert node['c']['d'] == 'e'
    set_tree_node(node, 'f:g:h', 'i')
    assert node['f']['g']['h'] == 'i'



# Generated at 2022-06-24 03:16:58.193415
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree_ = Tree()
    _ = tree_['thing']


# Generated at 2022-06-24 03:17:04.114519
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    import nose
    from nose.tools import assert_equal

    tree = Tree()
    tree['A'] = 'A'
    tree['A:A'] = 'AA'
    tree['A:A:A'] = 'AAA'

    assert_equal(tree['A'], 'A')
    assert_equal(tree['A:A'], 'AA')
    assert_equal(tree['A:A:A'], 'AAA')

    try:
        tree['B']
    except KeyError:
        pass
    else:
        assert False

    assert_equal(tree['B', 'B'], 'B')

    try:
        tree['A:B']
    except KeyError:
        pass
    else:
        assert False

    assert_equal(tree['A:B', 'B'], 'B')


# Generated at 2022-06-24 03:17:07.342822
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test function get_tree_node
    """
    mapping = Tree()
    mapping['a']['b']['c'] = 1
    assert get_tree_node(mapping, 'a:b:c') == 1



# Generated at 2022-06-24 03:17:18.256829
# Unit test for function tree
def test_tree():
    # Single item set
    t = tree()
    t['foo']['bar']['baz'] = 'a'
    assert t['foo']['bar']['baz'] == 'a'

    # Scan down multiple levels at once
    t['foo'][':']['baz'] = 'b'
    assert t['foo']['bar']['baz'] == 'b'

    # Set at root
    t[':'] = 'c'
    assert t['bar']['baz'] == 'c'

    # Set root to dict
    t = tree()
    t['foo']['bar']['baz'] = 'a'
    t[':'] = tree()
    assert t['bar']['baz'] == {}

# Generated at 2022-06-24 03:17:24.006595
# Unit test for constructor of class Tree
def test_Tree():
    from collections import OrderedDict
    from pprint import pprint


# Generated at 2022-06-24 03:17:25.420331
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    t['foo'] = 'bar'
    assert t['foo'] == 'bar'
    t['foo'] = 'bar2'
    assert t['foo'] == 'bar2'



# Generated at 2022-06-24 03:17:31.587243
# Unit test for function get_tree_node
def test_get_tree_node():
    # Assert valid and invalid keys
    assert get_tree_node({'a': 1}, 'a') == 1
    assert get_tree_node({'a': {'b': 1}}, 'a:b') == 1
    assert get_tree_node({'a': {'b': 1}}, 'a:c') == _sentinel
    assert get_tree_node({'a': {'b': 1}}, 'a:b', default=2) == 1
    assert get_tree_node({'a': {'b': 1}}, 'a:c', default=2) == 2

    # Assert with default set to :py:obj:`:module:_sentinel`
    with pytest.raises(KeyError):
        get_tree_node({'a': {'b': 1}}, 'a:c')



# Generated at 2022-06-24 03:17:38.135692
# Unit test for function get_tree_node
def test_get_tree_node():
    from nose.tools import assert_equal

    data = {
        'a': 'a',
        'b': {
            'c': 'c',
        },
        'f': {
            'g': 'g',
            'h': {
                'i': 'i',
            },
        },
        'd': {
            'e': 'e',
            'f': {
                'g': 'g',
                'h': {
                    'i': 'i',
                },
            },
        },
    }

    assert_equal(get_tree_node(data, 'a'), 'a')
    assert_equal(get_tree_node(data, 'b'), {'c': 'c'})
    assert_equal(get_tree_node(data, 'b:c'), 'c')
    assert_equal

# Generated at 2022-06-24 03:17:39.241613
# Unit test for function tree
def test_tree():
    pass


# Unit test class Tree

# Generated at 2022-06-24 03:17:47.368516
# Unit test for function get_tree_node
def test_get_tree_node():
    myt = RegistryTree({
        'a': 'b',
        'a:b': {
            'c': 'd',
            'c:d': {
                'e': 'f',
            }
        }
    })
    assert myt.get('a:b:c:d:e') == 'f'
    assert myt.get('a:b:c') == 'd'
    assert myt.get('a:b:not:existing', default=None) is None
    assert myt.get('a:b:not:existing') == myt['a:b:not:existing']

# Generated at 2022-06-24 03:17:55.229101
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    import contextlib
    @contextlib.contextmanager
    def _dict_like(tree, key, expect_value=None):
        try:
            yield
        except AttributeError:
            pass
        else:
            value = tree[key, '']
            if expect_value is not None and value is not expect_value:
                raise AssertionError('%s != %s' % (value, expect_value))

    # Test initial value of Tree
    tree = RegistryTree()
    assert tree == {}

    # Test initial value of RegistryTree
    tree = RegistryTree()
    with _dict_like(tree, 'foo:bar', expect_value=None):
        tree['foo:bar'] = 'spam:eggs'

    tree = RegistryTree()

# Generated at 2022-06-24 03:17:56.726721
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree()
    t[':foo:1'] = 'bar'
    t[':baz:0:0'] = 'qux'
    print(t)



# Generated at 2022-06-24 03:18:01.489880
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = collections.OrderedDict([
        ('a', 'value for key "a"'),
        ('b', 'value for key "b"'),
        ('c', collections.OrderedDict([
            ('1', 'value for key "c:1"'),
            ('2', 'value for key "c:2"')
        ])),
    ])
    assert get_tree_node(mapping, 'a') == 'value for key "a"'
    assert get_tree_node(mapping, 'c', default='no such key') == 'no such key'
    assert get_tree_node(mapping, 'c:1') == 'value for key "c:1"'
    assert get_tree_node(mapping, 'c:2') == 'value for key "c:2"'



# Generated at 2022-06-24 03:18:10.802427
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Unit test for function set_tree_node
    """
    result = {}
    set_tree_node(result, 'a:b:c', 'd')
    del result['a']['b']['c']
    result = {}
    set_tree_node(result, 'a:b:c', 'd')
    del result['a']['b']['c']
    result = {}
    set_tree_node(result, 'a:b:c', 'd')
    del result['a']['b']['c']
    result = {}
    set_tree_node(result, 'a:b:c', 'd')
    del result['a']['b']['c']
    result = {}

# Generated at 2022-06-24 03:18:14.729339
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    tree = RegistryTree()
    tree.register('a.b', 'c')


# Generated at 2022-06-24 03:18:20.392996
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree(
        {
            'foo': 'bar',
            'level2': {
                'nested': 'value'
            }
        }
    )
    assert t.get('foo') == 'bar'
    assert t.get('level2:nested') == 'value'
    assert t.get('level2:nested:not_here', default='default') == 'default'



# Generated at 2022-06-24 03:18:30.704178
# Unit test for function get_tree_node
def test_get_tree_node():
    t = {
        'a': {
            'b': {
                'c': 'd'
            },
            'e': 'f'
        },
        'g': {
            'h': 'i',
            'j': 'k'
        }
    }
    assert get_tree_node(t, 'a:b:c') == 'd'
    assert get_tree_node(t, 'a:b') == {'c': 'd'}
    assert get_tree_node(t, 'a:b', default=None, parent=True) == {'c': 'd'}
    assert get_tree_node(t, 'a:b', default=None, parent=False) == {'c': 'd'}
    assert get_tree_node(t, 'a:b', parent=False)

# Generated at 2022-06-24 03:18:32.056108
# Unit test for function set_tree_node
def test_set_tree_node():
    t = tree()
    set_tree_node(t, 'bag:of:holding', 'stuff')
    assert t['bag']['of']['holding'] == 'stuff'



# Generated at 2022-06-24 03:18:36.841743
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    object1 = Tree({'foo': 'bar'})
    object2 = Tree({'foo': {'bar': 'baz'}})
    object3 = Tree({'foo': {'bar': 'baz'}, 'baz': {'bam': 'bim'}})

    assert object1['foo'] == 'bar'
    assert object2['foo:bar'] == 'baz'
    assert object3['baz:bam'] == 'bim'



# Generated at 2022-06-24 03:18:41.489209
# Unit test for constructor of class Tree
def test_Tree():
    expected = {'a': 1,
                'b': {
                    'x': 1,
                    'y': 2,
                    'z': {
                        'm': 1,
                        'n': 2,
                    }
                }
                }
    t = Tree()
    for key, value in expected.iteritems():
        t[key] = value
    for key, value in expected.iteritems():
        assert t[key] == value

# Generated at 2022-06-24 03:18:45.589738
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    # Define test cases with expected output
    test_cases = [
        ('foo', Tree({'foo': 'foo'}), 'foo'),
    ]

    # Run tests
    run_test_cases(test_cases, Tree.get)



# Generated at 2022-06-24 03:18:49.451937
# Unit test for constructor of class RegistryTree
def test_RegistryTree():

    reg = RegistryTree({
        'things': {
            'oranges': 'orange',
            'apples': 'red',
        },
    })

    assert reg['things:oranges'] == 'orange'
    assert reg['things:apples'] == 'red'



# Generated at 2022-06-24 03:18:51.345716
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    registry = RegistryTree(namespace='my_super')
    registry['this:that'] = 'x'
    assert registry['this:that'] == 'x'
    registry.register('that:there', 'y')
    assert registry.get('this:that:there') == 'y'

# Generated at 2022-06-24 03:19:00.705336
# Unit test for function get_tree_node
def test_get_tree_node():
    class MyMapping(collections.Mapping):
        def __getitem__(self, item):
            return self.store[item]

        def __iter__(self):
            return iter(self.store)

        def __len__(self):
            return len(self.store)

        def __init__(self, initial_data={}):
            self.store = initial_data

    foo = MyMapping({'foo': {'bar': 'baz'}})
    assert get_tree_node(foo, 'foo') == {'bar': 'baz'}
    assert get_tree_node(foo, 'foo:bar') == 'baz'
    assert get_tree_node(foo, 'foo:bar:quux') == _sentinel

# Generated at 2022-06-24 03:19:06.749118
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree_ = Tree({'a': {'b': 3}}, 'foo')
    response_1 = tree_['a:b', 'far']
    assert response_1 == 3

    response_2 = tree_['a:bar']
    assert response_2 == 'far'



# Generated at 2022-06-24 03:19:12.269941
# Unit test for function set_tree_node
def test_set_tree_node():
    # Arrange
    d = {}
    key = 'a:b:c:d:e:f:g:h:i:j:k:l'
    value = 'value'

    # Act
    set_tree_node(d, key, value)

    # Assert
    assert value == get_tree_node(d, key), 'Assertion for value failed'



# Generated at 2022-06-24 03:19:19.690816
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    _old_value = t.get('nope:nope', _sentinel)

    value = t.__setitem__('nope:nope', 'm8', namespace='foo')

    assert value == t['nope:nope', 'foo']
    assert _old_value is _sentinel or _old_value == t['nope:nope', 'foo']



# Generated at 2022-06-24 03:19:26.490937
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    rt = RegistryTree()

    rt.register('foo', 'bar')
    rt.register('foo:baz', 'bam')
    assert rt.get('foo') == 'bar'
    assert rt.get('foo:baz') == 'bam'


if __name__ == '__main__':
    test_RegistryTree()

# Generated at 2022-06-24 03:19:34.648440
# Unit test for function get_tree_node
def test_get_tree_node():
    test = {
        'foo': {
            'bar': 1,
            'baz': {
                'one': 1,
                'two': 2,
                'three': 3,
            },
        },
    }

    assert get_tree_node(test, 'foo:bar') == 1
    assert get_tree_node(test, 'foo:baz:one') == 1
    assert get_tree_node(test, 'foo:baz:two') == 2
    assert get_tree_node(test, 'foo:baz:three') == 3

    assert get_tree_node(test, 'foo:baz:one:two:three') is None
    assert get_tree_node(test, 'foo:baz:one:two:three', default=None) is None

# Generated at 2022-06-24 03:19:40.063630
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    """Unit testing for method `Tree.__setitem__`."""
    from hikari import Tree

    t = Tree()
    t['foo:bar:baz'] = 1
    assert t[':foo:bar:baz'] == 1
    assert t['foo:bar:baz'] == 1
    assert t[':foo::bar::baz'] == 1



# Generated at 2022-06-24 03:19:43.159613
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    reg = RegistryTree(initial_is_ref=True, initial={'foo': {'bar': 'baz'}}, namespace='test')
    assert reg.namespace == 'test'
    assert reg.tree == {'foo': {'bar': 'baz'}}



# Generated at 2022-06-24 03:19:46.374442
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree_instance = Tree()
    key = 'abc'
    result = tree_instance.__getitem__(key)
    assert result is None



# Generated at 2022-06-24 03:19:49.280393
# Unit test for constructor of class Tree
def test_Tree():
    class MyTree(Tree):
        pass

    m = MyTree()
    assert isinstance(m, MyTree)



# Generated at 2022-06-24 03:19:56.918071
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    """Test the constructor of RegistryTree."""
    class TestClass(RegistryTree):
        namespace = 'foo'

    test_tree = TestClass()
    assert test_tree.namespace == 'foo'
    assert test_tree._namespace_key('bar') == 'foo:bar'
    assert test_tree['bar'] == {}
    assert test_tree == {'foo': {'bar': {}}}
    # Test updating
    test_tree.update({'baz': {}})
    assert test_tree == {'foo': {'bar': {}, 'baz': {}}}



# Generated at 2022-06-24 03:20:01.899914
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    """
    Test for method __setitem__ of class Tree
    """
    # Testing for performance of Tree.__setitem__
    # Create an object Tree()
    obj = Tree()
    # Assert that method __setitem__ is efficient
    assert timeit.timeit(lambda: obj.__setitem__(1, 1), number=100000) < 0.1



# Generated at 2022-06-24 03:20:06.910218
# Unit test for constructor of class Tree
def test_Tree():
    data = [{'a': 1}, {'b': 2, 'c': 3}]
    tree = Tree(initial=data)
    for index, item in enumerate(data):
        for k, v in item.iteritems():
            assert tree[k] == v
            assert tree[index][k] == v
    assert tree[1]['c'] == 3



# Generated at 2022-06-24 03:20:14.296357
# Unit test for method __getitem__ of class Tree

# Generated at 2022-06-24 03:20:18.725390
# Unit test for function set_tree_node
def test_set_tree_node():
    foo = tree()
    set_tree_node(foo, 'bar:baz', 'foobarbaz')
    set_tree_node(foo, 'bar:bar', 'foobar')

    assert foo['bar']['baz'] == 'foobarbaz'
    assert foo['bar']['bar'] == 'foobar'



# Generated at 2022-06-24 03:20:26.946462
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree_obj = Tree()
    tree_obj['a:a:a:a'] = 1
    assert tree_obj['a:a:a:a'] == 1

    tree_obj = Tree()
    tree_obj['a:a:a:a'] = 1
    assert tree_obj['a:a:a:a:b:b:b:b'] is None

    tree_obj = Tree()
    tree_obj['a:a:a:a'] = 1
    assert tree_obj['a:a:a:a:b:b:b:b', 2] == 2



# Generated at 2022-06-24 03:20:35.492989
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree = Tree(initial={'a': {'b': {'c': 0}}})
    assert tree['a:b:c'] == 0
    assert not tree['a:b:d']
    assert tree.get('a:b:d') is _sentinel
    assert tree.get('a:b:d', None) is None
    assert tree.get('a:b:d', {}) == {}
    assert tree.get('a:b:d', []) == []



# Generated at 2022-06-24 03:20:42.907290
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'some': {
            'deep': {
                'level': 'Hello'
            }
        },
        'foo': {
            'bar': 'Baz',
            'baz': {
                'bar': 'Quux'
            }
        },
        'list': [
            'Foo',
            'Bar',
            'Baz'
        ]
    }
    assert get_tree_node(mapping, 'foo:bar') == 'Baz'
    assert get_tree_node(mapping, 'foo:baz:bar') == 'Quux'
    assert get_tree_node(mapping, 'list:1') == 'Bar'
    assert get_tree_node(mapping, 'foo:quux') == _sentinel

# Generated at 2022-06-24 03:20:46.491897
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    data = Tree()
    data['foo'] = 'bar'
    assert data['foo'] == 'bar'
    data['foo']['foo'] = 'bar'
    assert data['foo']['foo'] == 'bar'



# Generated at 2022-06-24 03:20:55.297614
# Unit test for constructor of class Tree
def test_Tree():
    test_tree = Tree({'foo': {'bar': 'fizz'}})
    assert isinstance(test_tree, Tree)
    assert test_tree.namespace == ''
    assert test_tree['foo'] == {'bar': 'fizz'}
    assert test_tree['foo:bar'] == 'fizz'
    test_tree.namespace = 'scope'
    assert test_tree['foo'] == {'bar': 'fizz'}
    assert test_tree['foo:bar'] == 'fizz'
    assert test_tree['scope:foo'] == {'bar': 'fizz'}
    assert test_tree['scope:foo:bar'] == 'fizz'
    assert test_tree.get('missing', 'default') == 'default'

# Generated at 2022-06-24 03:21:03.719509
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 123,
                'quux': 789,
            },
        },
    }
    # Fetch a node
    assert get_tree_node(mapping, 'foo:bar:baz') == 123
    # Fetch a missing node with default
    assert get_tree_node(mapping, 'foo:bar:quux:qux', 'qux') == 'qux'
    # Fetch a missing node without default
    with pytest.raises(KeyError):
        get_tree_node(mapping, 'foo:bar:quux:qux')
    # Fetch a node with parent

# Generated at 2022-06-24 03:21:05.520885
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    t['a'] = 1
    assert t['a'] == 1



# Generated at 2022-06-24 03:21:13.168069
# Unit test for function tree
def test_tree():
    t = tree()
    t['child']['subchild'] = 5
    t['child']['subchild2'] = 10
    t['child2']['subchild2'] = 15
    t['child2']['subchild3'] = 20
    assert t['child']['subchild'] == 5
    assert t['child']['subchild'] == 5
    assert t['child:subchild'] == 5
    assert t['child2:subchild3'] == 20
    assert 'subchild4' not in t['child:subchild']


if __name__ == '__main__':
    test_tree()

# Generated at 2022-06-24 03:21:14.830459
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    rt = RegistryTree()
    assert isinstance(rt, Tree)



# Generated at 2022-06-24 03:21:25.148647
# Unit test for function get_tree_node
def test_get_tree_node():
    test_mapping = {
        'a': 1,
        'b': {
            'c': 2,
            'd': {
                'e': 3,
                'f': 4,
                'g': {
                    'h': 5
                }
            }
        }
    }
    assert get_tree_node(test_mapping, 'a') == 1
    assert get_tree_node(test_mapping, 'a:') == 1
    assert get_tree_node(test_mapping, 'a:b:') == 1
    assert get_tree_node(test_mapping, 'b:c') == 2
    assert get_tree_node(test_mapping, 'b:d:e') == 3
    assert get_tree_node(test_mapping, 'b:d:g:h')

# Generated at 2022-06-24 03:21:31.449056
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    # This test provides coverage for __setitem__
    # when provided with valid args,
    # and by extension to __init__ because they both use __setitem__
    test_tree = Tree(initial={'foo': {'bar': {'baz': 'quux'}}})

    # This test provides coverage for __setitem__
    # when provided with valid args,
    # and by extension to __init__ because they both use __setitem__
    test_tree = Tree(initial={'foo': {'bar': {'baz': 'quux'}}})

    # This test provides coverage for __setitem__
    # when provided with valid args,
    # and by extension to __init__ because they both use __setitem__

# Generated at 2022-06-24 03:21:35.793318
# Unit test for function set_tree_node
def test_set_tree_node():
    my_dict = {}
    set_tree_node(my_dict, 'a:b:c:d', 123)
    assert my_dict['a']['b']['c']['d'] == 123



# Generated at 2022-06-24 03:21:38.043756
# Unit test for constructor of class Tree
def test_Tree():
    """Basic unit testing for `Tree` class."""
    tree = Tree(initial={'test': 1})
    assert tree['test'] == 1



# Generated at 2022-06-24 03:21:47.450284
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree()
    t['a:b:c'] = 3
    assert t['a:b:c'] == 3
    t['a:b:d'] = 4
    assert t['a:b:c'] == 3
    assert t['a:b:d'] == 4
    assert t['a:x:y'] == {}
    assert t['a']['b']['c'] == 3
    assert t['a']['b']['d'] == 4
    assert t['a']['x']['y'] == {}
    t['a'] = 5
    assert t['a'] == 5
    assert t['a:b'] == {}
    t['namespace'] = 'ns1'
    t['x:y:z'] = 1

# Generated at 2022-06-24 03:21:49.270154
# Unit test for function set_tree_node
def test_set_tree_node():
    assert set_tree_node({}, 'key:subkey', 'value') == {'key': {'subkey': 'value'}}



# Generated at 2022-06-24 03:21:56.268216
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    # This tests the tree class
    tt = Tree()
    tt['a']['b']['c'] = 3
    assert tt['a:b:c'] == 3  # Simple ':' delving
    assert tt['a:b:c:d'] == {}  # Ignores and returns empty dict
    assert tt['a:b:c']['d'] == {}  # Ignores and returns empty dict

    tt = Tree({'a': {'b': {'c': 3}}})
    assert tt['a:b:c'] == 3  # Simple ':' delving
    assert tt['a:b:c:d'] == {}  # Ignores and returns empty dict
    assert tt['a:b:c']['d'] == {}  # Ignores and returns empty dict


# Unit test

# Generated at 2022-06-24 03:22:05.961437
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'top1': {
            'mid1': {
                'bot1': 'hello',
                'bot2': 'world',
            },
        },
        'top2': {
            'mid2': {
                'bot1': 'hello',
                'bot2': 'world',
            },
        },
    }

    # Normal
    assert get_tree_node(mapping, 'top1:mid1:bot1') == 'hello'

    # Default
    assert get_tree_node(mapping, 'not_top3', default='default') == 'default'

    # Not found
    with pytest.raises(KeyError):
        get_tree_node(mapping, 'not_top3')

    # Parent retrieval

# Generated at 2022-06-24 03:22:14.660867
# Unit test for constructor of class Tree
def test_Tree():
    a = Tree()
    a.namespace = 'a.ns'
    b = Tree()
    b.namespace = 'b.ns'
    c = Tree()
    c.namespace = 'c.ns'
    d = Tree()
    d.namespace = 'd.ns'
    a.update({'a': b})
    b.update({'b': c})
    c.update({'c': d})
    d.update({'d': 'DDD'})

    assert(a.namespace == 'a.ns')
    assert(a['a'].namespace == 'b.ns')
    assert(a['a']['b'].namespace == 'c.ns')
    assert(a['a']['b']['c'].namespace == 'd.ns')

# Generated at 2022-06-24 03:22:18.359159
# Unit test for function set_tree_node
def test_set_tree_node():
    d = tree()
    assert not set_tree_node(d, "hello:world", "hi")
    assert d["hello"]["world"] == "hi"

    d = {
        "hello": {
            "world": "hi"
        }
    }
    assert not set_tree_node(d, "hello:world", "hi")
    assert d["hello"]["world"] == "hi"



# Generated at 2022-06-24 03:22:26.771714
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Unit test for function set_tree_node

    Returns:
        bool: True if test passes, False if test fails
    """
    nested_dict = {}
    set_tree_node(nested_dict, 'x:y:z', 'foo')
    assert 'x' in nested_dict
    assert 'y' in nested_dict['x']
    assert 'z' in nested_dict['x']['y']
    assert nested_dict['x']['y']['z'] == 'foo'
    return True



# Generated at 2022-06-24 03:22:30.255253
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree({'a': 2})
    assert t['a'] == 2
    assert t['a'] == 2
    t = Tree({'a': 2}, initial_is_ref=True)
    assert t['a'] == 2
    assert t['a'] == 2



# Generated at 2022-06-24 03:22:34.090197
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    """Tests for RegistryTree initial state and registration."""
    assert isinstance(RegistryTree(), RegistryTree)
    assert RegistryTree().namespace == ''
    assert isinstance(RegistryTree(namespace='test'), RegistryTree)
    assert RegistryTree().namespace == 'test'
    assert RegistryTree()['test'].namespace == 'test'



# Generated at 2022-06-24 03:22:44.477119
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'hi': {
            'yo': 'yo',
        },
        'lol': {
            'wat': {
                'no': 'no',
            },
            'why': 'no',
        },
    }

    # Simple:
    assert get_tree_node(tree, 'lol', default=None)['wat']['no'] == 'no'
    # Recursive:
    assert get_tree_node(tree, 'lol:wat:no') == 'no'
    # With parent:
    assert get_tree_node(tree, 'lol:wat:no', parent=True)['no'] == 'no'
    assert get_tree_node(tree, 'lol:wat:no', parent=True)['no'] == 'no'

    # Doesn't exist:

# Generated at 2022-06-24 03:22:46.754942
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    t['foo'] = 'bar'
    assert t['foo'] == 'bar', t['foo']



# Generated at 2022-06-24 03:22:51.445992
# Unit test for function set_tree_node
def test_set_tree_node():
    t = tree()
    set_tree_node(t, 'posix:linux:dumb', 'totally')
    assert t['posix']['linux']['dumb'] == 'totally'



# Generated at 2022-06-24 03:22:57.315983
# Unit test for constructor of class Tree
def test_Tree():
    import unittest

    class TestTree(unittest.TestCase):
        @staticmethod
        def test_ctor():
            t = Tree(namespace='ns')
            t['a'] = 1
            self.assertEqual(t['a'], 1)
            self.assertEqual(t['ns:a'], 1)

# Generated at 2022-06-24 03:23:04.677464
# Unit test for constructor of class Tree
def test_Tree():
    tree = Tree('http://example.com/one')
    assert tree.namespace == 'http://example.com/one'
    assert tree[''] == tree
    assert tree['one'] == tree['one']

    try:
        tree['one:1']
    except KeyError:
        pass
    else:
        assert False, 'One:1 should not be in dict'

    tree['one:1'] = 1
    assert tree['one:1'] == 1
    assert tree['one:1:2:3:4'] == tree['one']['1']['2']['3']['4']
    assert tree['one']['1']['2']['3']['4'] == tree['one:1:2:3:4']

    # Regression test
    tree = Tree('')


# Generated at 2022-06-24 03:23:08.879102
# Unit test for function set_tree_node
def test_set_tree_node():
    t = tree()
    set_tree_node(t, 'foo', 'bar')
    assert isinstance(t['foo'], str)



# Generated at 2022-06-24 03:23:17.758955
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    import re
    import logging

    # Create an instance of Tree
    obj = Tree()

    # Try calling __getitem__ with correct arguments
    ret_val = obj.__getitem__('some', default=_sentinel, namespace=None)

    # Check that __getitem__ calls Tree.__init__ (which calls
    # collections.defaultdict.__init__)
    # arg_pattern = "self, initial=None, namespace=''"
    # assert_pattern = re.compile(arg_pattern)
    # args, _, _, _ = inspect.getargvalues(inspect.currentframe())
    # all_args = inspect.getargspec(Tree.__init__)
    # for arg in all_args.args:
    #     if arg not in args:
    #         continue
    #     val = args[

# Generated at 2022-06-24 03:23:24.455775
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    registry = RegistryTree()

    # Register key 'a' in the registry
    registry.register('a', 1)

    # Overwrite the value of key 'a'
    registry.register('a', 2)

    # Register a dict under key 'a'
    registry.register('a', {'foo': 3, 'bar': -1})

    # Register an int under key 'a:foo'
    registry.register('a:foo', 4)

    # Fetch value of key 'a'
    assert registry['a'] == {'foo': 3, 'bar': -1}

    # Fetch value of key 'a:foo'
    assert registry['a:foo'] == 4

    # Fetch value of key 'a:bar'
    assert registry['a:bar'] == -1

    # Fetch value of key 'b' (should not

# Generated at 2022-06-24 03:23:27.121540
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()

    tree['foo'] = 'bar'
    assert tree['foo'] == 'bar'



# Generated at 2022-06-24 03:23:30.783709
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    """
    Run doctests for method __getitem__ of class Tree
    """
    import doctest
    doctest.run_docstring_examples(Tree.__getitem__, {}, Tree)


# Generated at 2022-06-24 03:23:33.639056
# Unit test for function tree
def test_tree():
    test = tree()
    test['a']['b']['c'] = 1
    print(test['a']['b']['c'])



# Generated at 2022-06-24 03:23:39.172737
# Unit test for function set_tree_node
def test_set_tree_node():
    # Create test tree
    t = tree()
    assert t and t == dict()
    # Try setting top node
    t = set_tree_node(t, 'a', 'a')
    assert t == {'a': 'a'}
    # Try setting sub node
    t = set_tree_node(t, 'a:b', 'b')
    assert t == {'a': {'b': 'b'}}



# Generated at 2022-06-24 03:23:44.670435
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree([{'foo': {'bar': 'BAR'}}])
    assert t['foo:bar'] == 'BAR'

# Generated at 2022-06-24 03:23:53.990466
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    import nose.tools
    tree = Tree()
    tree[':foo:bar'][':baz'] = 'qux'
    
    nose.tools.assert_equals(tree['foo:bar:baz'], 'qux')
    nose.tools.assert_equals(tree.get('foo:bar:baz'), 'qux')
    
    nose.tools.assert_raises(KeyError, tree.__getitem__, 'foo')
    nose.tools.assert_equals(tree.get('foo'), None)
    nose.tools.assert_equals(tree.get('foo', 'orz'), 'orz')
    nose.tools.assert_equals(tree.get('foo:bar:baz', 'orz'), 'qux')

# Generated at 2022-06-24 03:23:59.897499
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}
    set_tree_node(tree, 'a', {'b': 'c'})
    assert tree == {'a': {'b': 'c'}}
    set_tree_node(tree, 'a:b', 'd')
    assert tree == {'a': {'b': 'd'}}
    set_tree_node(tree, 'a:c', 'e')
    assert tree == {'a': {'b': 'd', 'c': 'e'}}



# Generated at 2022-06-24 03:24:06.521649
# Unit test for function tree
def test_tree():
    t = tree()
    t['foo']['bar'] = 1
    assert t['foo']['bar'] == 1

    t = tree()
    t[0, 0][0, 1][0, 2] = 1
    assert t[0, 0][0, 1][0, 2] == 1

# Generated at 2022-06-24 03:24:10.479137
# Unit test for function set_tree_node
def test_set_tree_node():
    """tree.set_tree_node should work by setting an item deep in a mapping"""
    d = {}
    set_tree_node(d, 'a:b:c:d', 1)
    assert d['a']['b']['c']['d'] == 1

