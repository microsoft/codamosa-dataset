

# Generated at 2022-06-24 03:14:21.531668
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    rt = RegistryTree()
    assert isinstance(rt, Tree)
    assert rt.namespace == ''

    _initial = {'a': {'b': {'c': 'd'}}}
    rt = RegistryTree(_initial, 'foo', True)
    assert rt.namespace == 'foo'
    assert rt.get('a:b:c') == 'd'

    rt.register('a:b:c', 'd:d:d')
    assert rt.get('a:b:c') == 'd:d:d'

    rt.register('d:e:f', 'g:g:g', namespace='foo')
    assert rt.get('d:e:f') == 'g:g:g'



# Generated at 2022-06-24 03:14:31.788587
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    # Test docstring example
    tree = Tree()
    tree.__setitem__('a', 1)
    tree.__setitem__('b:c', 2)
    tree.__setitem__('b:d', 3)

    assert tree.__getitem__('a') == 1
    assert tree.__getitem__('b:c') == 2
    assert tree.__getitem__('b:d') == 3

    # Default value
    assert tree.__getitem__('x', default=None) is None

    # Key not found
    try:
        tree.__getitem__('a:x')
    except KeyError:
        pass
    else:
        raise Exception('KeyError not raised')



# Generated at 2022-06-24 03:14:42.532908
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({}, '') == {}
    assert get_tree_node({'foo': 'bar'}, 'foo') == 'bar'
    assert get_tree_node({'foo': {'bar': {'baz': 'barbaz'}}}, 'foo:bar:baz') == 'barbaz'
    assert get_tree_node({'foo': {'bar': {'baz': 'barbaz'}}}, 'foo:bar', parent=True) == {'bar': {'baz': 'barbaz'}}
    assert get_tree_node({'foo': {'bar': {'baz': 'barbaz'}}}, 'foo:bar:baz', parent=True) == {'baz': 'barbaz'}

# Generated at 2022-06-24 03:14:53.737583
# Unit test for function get_tree_node
def test_get_tree_node():
    # Setup
    tree = {
        'a': {
            'b': {
                'c': 'd'
            },
            'e': [
                'f',
                'g',
                {
                    'h': 'i'
                }
            ],
            'j': {
                'k': {
                    'l': {
                        'm': 'n'
                    }
                }
            }
        },
        'o': {
            'p': [
                {'q': 'r'},
                {'s': 't'},
                {'u': 'v'}
            ]
        }
    }

    # Tests
    assert get_tree_node(tree, 'a:b:c') == 'd'
    assert get_tree_node(tree, 'a:e:2:h')

# Generated at 2022-06-24 03:15:01.258942
# Unit test for constructor of class Tree
def test_Tree():
    """Create a tree and check if the namespace works."""
    from pytest import raises
    from shakedown.utils.dicts import tree
    t = Tree()
    t.namespace = 'abc'
    t['x'] = 'X'
    with raises(KeyError):
        tree['abc:x']  # Fails
    tree['abc:x'] = 'X'
    tree.data is t.data  # Should be the same object in memory



# Generated at 2022-06-24 03:15:02.902878
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    a = RegistryTree()
    a.register('a', 'b')
    assert a['a'] == 'b'

# Generated at 2022-06-24 03:15:13.993919
# Unit test for function tree
def test_tree():
    non_tree = {
        'a': {
            'b': {
                'c': {
                    'd': 'e',
                    'a': 'b',
                },
                'd': 'e',
            },
            'c': 'd',
        },
        'b': 'c',
    }

    a = tree()
    a['a']['b'] = 'c'
    a['a']['c']['d']['e'] = 'f'
    a['a']['c']['d']['d']['e']['f']['g']['h']['i']['j'] = 'k'

    assert a['a']['b'] == 'c'

# Generated at 2022-06-24 03:15:20.848069
# Unit test for function get_tree_node
def test_get_tree_node():

    example_map = {
        'a': {
            'b': {
                'c': {
                    'd': 'last-true',
                },
                'd': 'second-true',
                'e': 'third-true',
                'f': 'fourth-true',
            },
            'c': {
                'd': 'last-false',
                'e': {
                    'f': 'last-true',
                },
            },
        },
        'b': {
            'c': {
                'd': 'false-branch',
            },
        },
    }


# Generated at 2022-06-24 03:15:25.354199
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': 'bar',
        'baz': {
            'bazinga': 'Bazinga!'
        }
    }
    expected = mapping['foo']
    result = get_tree_node(mapping, 'foo')
    assert expected == result

    expected = mapping['baz']['bazinga']
    result = get_tree_node(mapping, 'baz:bazinga')
    assert expected == result



# Generated at 2022-06-24 03:15:31.258963
# Unit test for function tree
def test_tree():
    d = tree()
    d['a']['b']['c'] = 1
    d['a']['b']['d'] = 2
    d['a']['b']['e'] = 3
    assert d['a:b:c'] == 1
    assert d['a:b:d'] == 2
    assert d['a:b:e'] == 3
    assert d['a:b'] == {'c': 1, 'd': 2, 'e': 3}



# Generated at 2022-06-24 03:15:38.971264
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    test_dict = {'a': 0, 'b': 1, 'c': {'a': 0, 'b': 1}}
    test = Tree(test_dict)
    assert test.get('a') == 0
    assert test.get('c') == {'a': 0, 'b': 1}
    assert test.get('c:a') == 0
    try:
        test.get('d')
        assert False
    except KeyError:
        assert True
    try:
        test.get('d:e')
        assert False
    except KeyError:
        assert True
    assert test.get('d:e', default=None) is None



# Generated at 2022-06-24 03:15:46.674038
# Unit test for function tree
def test_tree():
    t = tree()
    t['a']['b']['c'] = 1
    t['a']['b']['d'] = 2
    t['a']['e'] = 3
    assert t['a']['b']['c'] == 1
    assert t['a']['b']['d'] == 2
    assert t['a']['e'] == 3
    t['a']['b']['c'] = 5
    assert t['a']['b']['c'] == 5
    t['a']['b']['c'] = 1
    assert t['a']['b']['c'] == 1

    t = tree()
    t['a']['b']['c'] = 1

# Generated at 2022-06-24 03:15:48.966182
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    t['foo'] = 'bar'
    assert t['foo'] == 'bar'
    return t



# Generated at 2022-06-24 03:15:58.965882
# Unit test for function get_tree_node
def test_get_tree_node():
    import json

    def check(expected, mapping, key, default=_sentinel, parent=False):
        actual = get_tree_node(mapping, key, default=default, parent=parent)
        assert expected == actual

    mapping = json.loads('{"a": {"b": ["c"]}}')
    check(mapping, mapping, 'a')
    check(mapping, mapping, 'a:b')
    check(mapping['a']['b'], mapping, 'a:b:0')
    check(mapping['a'], mapping, 'a:b:0', parent=True)
    check(None, mapping, 'z')
    check(None, mapping, 'a:z')
    check(None, mapping, 'a:b:1')
    check(None, mapping, 'a:b:c')


# Generated at 2022-06-24 03:16:02.318957
# Unit test for constructor of class Tree
def test_Tree():
    f = Tree({'foo': 'bar', 'baz': 'boo'})
    assert 'bar' == f['foo']
    assert 'boo' == f['baz']

# Generated at 2022-06-24 03:16:12.031858
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    t['foo'] = 'bar'
    assert t['foo'] == 'bar'
    t['foo:bar'] = 'baz'
    assert t['foo:bar'] == 'baz'
    assert hasattr(t, 'foo')
    assert hasattr(t['foo'], 'bar')
    assert t['foo']['bar'] == 'baz'
    assert t['foo:bar'] == 'baz'

    t['foo:bar:baz'] = 'goo'
    assert hasattr(t['foo']['bar'], 'baz')
    assert t['foo:bar:baz'] == 'goo'

    t['foo'] = 'foo'
    assert t['foo'] == 'foo'
    assert t['foo:bar:baz'] == 'goo'


# Generated at 2022-06-24 03:16:20.900477
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    # Instantiate class RegistryTree with initial structure
    init = {
        '1': {
            '2': {
                '3': 4
            }
        }
    }

    rt = RegistryTree(initial=init, namespace='ns:ns2')
    assert rt['1:2:3'] == 4

    # Register an item with namespace
    rt.register('4:4', 8, namespace='ns:ns2')
    assert rt['4:4'] == 8

    # Instantiate class RegistryTree without initial structure
    rt = RegistryTree(namespace='ns:ns2')
    # Register an item without namespace
    rt.register('4:4', 16)
    assert rt['4:4'] == 16

    # Register an item with namespace

# Generated at 2022-06-24 03:16:26.535304
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree({'a': 'b'})
    assert t['a'] == 'b'

    t = Tree(initial_is_ref=False, initial={'a': 'b'})
    assert t['a'] == 'b'

    t = Tree(initial_is_ref=True, initial={'a': 'c'})
    assert t['a'] == 'c'



# Generated at 2022-06-24 03:16:37.358265
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    """
    Unit tests for Tree.__getitem__.
    """

    import unittest

    class TestcaseTree___getitem__(unittest.TestCase):

        def test_getitem_with_default(self):
            tree = Tree({
                "a": 0,
                "b": {
                    "c": 0,
                    "d": {
                        "e": 0,
                        "f": 0,
                        "g": {
                            "h": 0
                        }
                    }
                }
            }, namespace="a")
            self.assertEqual(
                tree["a:b:d:e"],
                0,
                "Retrieve the value of the key"
            )

# Generated at 2022-06-24 03:16:45.496218
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    import unittest
    import mock

    test_data = {
        'foo': 'bar',
        'key': 'value',
        'nested': {
            'key': 'value',
            'foo': 'bar',
        },
    }

    class TreeTest(unittest.TestCase):
        def setUp(self):
            self.registry = RegistryTree()

        @mock.patch.object(RegistryTree, '_namespace_key')
        def test_nested_key_with_namespace(self, namespace_key):
            namespace_key.return_value = 'foo:bar:baz'
            self.registry.register('foo:bar:baz', 'value')
            self.assertEqual(self.registry['foo']['bar']['baz'], 'value')

# Generated at 2022-06-24 03:16:50.762383
# Unit test for constructor of class Tree
def test_Tree():
    initial = {'foo': 'bar'}
    tree = Tree(initial=initial)
    assert tree['foo'] == initial['foo'] == 'bar'

    initial['foo'] = 'bar2'
    assert tree['foo'] == 'bar'



# Generated at 2022-06-24 03:16:52.012607
# Unit test for constructor of class Tree
def test_Tree():
    assert Tree({'a': 1})['a'] == 1



# Generated at 2022-06-24 03:16:58.741694
# Unit test for function set_tree_node
def test_set_tree_node():
    d = {
        'a': {
            'b': {
                'c': 42
            }
        }
    }

    set_tree_node(d, 'a:b:c', 24)

    assert d['a']['b']['c'] == 24



# Generated at 2022-06-24 03:17:04.371736
# Unit test for constructor of class Tree
def test_Tree():
    # Test for empty tree
    assert Tree() == {}

    # Test for tree of dicts
    assert Tree({'a': '1', 'b': '2'}) == {'a': '1', 'b': '2'}

    # Test for tree of custom objects
    t = Tree([(1, 2), (3, 4)])
    assert t == {1: 2, 3: 4}

    # Test for tree of dicts with default namespace
    t = Tree({'a': '1', 'b': '2'}, 'test_namespace')
    assert t == {'test_namespace': {'a': '1', 'b': '2'}}
    assert t.get('test_namespace:a') == '1'

    # Test for tree of custom objects with default namespace

# Generated at 2022-06-24 03:17:09.395333
# Unit test for function tree
def test_tree():
    tree_ = tree()
    tree_['a']['b'] = 'c'
    tree_['a']['d']['e'] = 'f'

    assert tree_['a']['b'] == 'c'
    assert tree_['a']['d']['e'] == 'f'
    assert tree_['a']['d']['f'] == {}
    assert tree_['a']['d']['f']['b'] == {}



# Generated at 2022-06-24 03:17:15.002737
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    # Setup
    tree = Tree()
    key = 'foo:bar:baz'
    value = 'quux'
    ref = tree

    # Exercise
    tree[key] = value

    # Verify
    assert tree[key] == value
    assert tree['foo']['bar']['baz'] == value
    # Directly using the root reference should allow accessing the value
    assert ref[key] == value
    assert ref['foo']['bar']['baz'] == value

# Generated at 2022-06-24 03:17:20.789197
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    tree = RegistryTree(initial={'test': 'passed', 'test2': 'passed'})
    assert tree['test'] == 'passed'
    assert tree['test2'] == 'passed'

    # Lookup of non-existent key should raise KeyError
    with pytest.raises(KeyError):
        tree['test3']

    assert tree.get('test3', 'passed') == 'passed'
    assert tree.get('test', 'passed') == 'passed'

    # Test the namespace feature
    tree = RegistryTree(namespace='namespace')
    tree['test'] = 'passed'
    assert tree['test'] == 'passed'
    assert tree['namespace:test'] == 'passed'



# Generated at 2022-06-24 03:17:27.585978
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {'foo': {'bar': {'baz': 'qux'}}}
    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'

    try:
        get_tree_node(mapping, 'foo:bar:baz:quux')
    except KeyError:
        pass
    else:
        raise AssertionError('get_tree_node should raise KeyError')

    mapping = {'foo': {'bar': {'baz': 'qux'}}}
    assert get_tree_node(mapping, 'foo:bar:baz:quux', default='quux') == 'quux'



# Generated at 2022-06-24 03:17:32.255138
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Set an arbitrary node in the tree.

    Returns:
        object: Value at specified key

    """
    tree = Tree()
    tree['foo:bar'] = 'baz'

# Generated at 2022-06-24 03:17:35.948142
# Unit test for constructor of class Tree
def test_Tree():
    tree = Tree()
    tree['path:to:node'] = 'value'
    assert tree['path:to:node'] == 'value'

    tree = Tree(initial={'path': {'to': 'value'}})
    assert tree['path:to'] == 'value'



# Generated at 2022-06-24 03:17:40.568527
# Unit test for function set_tree_node
def test_set_tree_node():
    test_data = tree()
    set_tree_node(test_data, 'foo:bar:baz', 'qux')
    # Test that the key was set
    assert test_data['foo']['bar']['baz'] == 'qux'
    # Test that the key was not nested further
    assert test_data['foo']['bar'] == {'baz': 'qux'}
    assert test_data['foo'] == {'bar': {'baz': 'quz'}}
    # Test that keys were not overwritten
    try:
        test_data['foo']['bar']['baz'] = 'qux'
    except Exception:
        assert False
    else:
        assert True



# Generated at 2022-06-24 03:17:47.172747
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree()
    t['a']

    t = Tree(namespace='a')
    t['b']

    t = Tree(namespace='a', initial={'x': 'y'})
    assert t['x'] == 'y'

    t = Tree(namespace='a', initial_is_ref=True)
    t['b']

    t = Tree(initial_is_ref=True)
    t['b']
    t.update({'b': 'c'})



# Generated at 2022-06-24 03:17:49.592319
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {'bar': {'baz': 5}}
    }
    assert 5 == get_tree_node(mapping, 'foo:bar:baz')



# Generated at 2022-06-24 03:17:54.813950
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    x = Tree()
    x['y'] = 2
    x['y'] = 7
    assert x['y'] == 7
    assert 'y' in x
    assert 'y' in x.data



# Generated at 2022-06-24 03:18:01.021982
# Unit test for function get_tree_node
def test_get_tree_node():
    """Test simple cases of `get_tree_node`."""
    assert get_tree_node({'a': 'b'}, 'a') == 'b'
    assert get_tree_node({'a': {'b': 'c'}}, 'a:b') == 'c'
    assert get_tree_node({'a': {'b': {'c': 'd'}}}, 'a:b:c') == 'd'



# Generated at 2022-06-24 03:18:08.073512
# Unit test for function set_tree_node
def test_set_tree_node():
    """Unit test for function set_tree_node"""
    M = tree()
    set_tree_node(M, 'a:b:c:d:e:f', 1000)
    set_tree_node(M, 'a:b', 100)
    set_tree_node(M, 'a:b:g', 101)
    set_tree_node(M, 'a:b:g:h', 102)
    set_tree_node(M, 'a:b:c:d:e', 1001)
    set_tree_node(M, 'a:b:c:d:e:f', 1002)
    assert M['a']['b']['g']['h'] == 102

# Generated at 2022-06-24 03:18:11.728172
# Unit test for function get_tree_node
def test_get_tree_node():
    pass

if __name__ == '__main__':
    import doctest
    doctestmod()

# Generated at 2022-06-24 03:18:22.505372
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    import sys
    if sys.version_info.major == 2:
        import mock
    else:
        from unittest import mock


# Generated at 2022-06-24 03:18:25.982600
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {'a': {'b': 'c'}}
    assert get_tree_node(tree, 'a:b') == 'c'
    assert get_tree_node(tree, 'a:b:c') == _sentinel



# Generated at 2022-06-24 03:18:29.008256
# Unit test for function set_tree_node
def test_set_tree_node():
    testing = tree()
    set_tree_node(testing, 'peter:piper:picked', 'a')
    assert testing['peter']['piper']['picked'] == 'a'



# Generated at 2022-06-24 03:18:38.164231
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree()
    t['foo']['bar']['baz'] = 'quux'
    t['spam']['ham']['eggs'] = 'kraftwerk'

    assert t['foo:bar:baz'] == 'quux'

    # Also test namespaceing
    t.namespace = 'waldo'
    assert t['foo:bar:baz'] == 'quux'
    assert t['waldo:foo:bar:baz'] == 'quux'
    assert t['waldo:spam:ham:eggs'] == 'kraftwerk'

    t['waldo:foo:bar:baz'] = 'quux'
    assert t['foo:bar:baz'] == 'quux'
    assert t['waldo:foo:bar:baz'] == 'quux'

# Generated at 2022-06-24 03:18:42.962585
# Unit test for function tree
def test_tree():
    t = tree()
    t['a']['b']['c']['d'] = 'value'
    assert t == {'a': {'b': {'c': {'d': 'value'}}}}
    assert t['a']['b']['c']['d'] == 'value'
    assert t['a']['b']['c']['d'] == t['a']['b']['c']['d']
    assert t['a']['b']['c']['d'] == t['a:b:c:d']



# Generated at 2022-06-24 03:18:53.529468
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    from copy import copy
    from operator import itemgetter

    test_obj = dict(a=1, b=2, c=3)

    # Test dict input
    t = RegistryTree(test_obj)
    assert t.get('a') == 1

    # Test copy.copy() input
    t = RegistryTree(copy(test_obj), initial_is_ref=True)
    t['a'] = 100
    assert test_obj['a'] == 100

    # Test copy.deepcopy() input
    t = RegistryTree(copy(test_obj), '')
    t['a'] = 200
    assert test_obj['a'] == 100

    # Test empty namespace
    t = RegistryTree({}, '')
    t['a'] = 5
    assert t.get('a') == 5

# Generated at 2022-06-24 03:19:02.295598
# Unit test for function tree
def test_tree():
    from pprint import pprint

    tree = RegistryTree()

    tree.register(':a:b:c:d', 1)
    tree.register(':a:b:c:e', 2)
    tree.register(':a:b:f:g', 3)
    tree.register(':a:h:[]:i', 4)
    tree.register(':a:h:foo:bar', 5)

# Generated at 2022-06-24 03:19:09.890291
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree()
    t[u'foo'] = 1
    assert t[u'foo'] == 1
    assert t[u'foo:bar'] == OrderedDict()
    assert t[u'foo:bar:baz'] is None
    t[u'foo:bar:baz'] = 2
    assert t[u'foo:bar:baz'] == 2
    assert t[u'foo'] == OrderedDict([
        (u'bar', OrderedDict([
            (u'baz', 2)
        ]))
    ])



# Generated at 2022-06-24 03:19:18.671613
# Unit test for function tree
def test_tree():
    a = tree()
    a['foo']['bar'] = 'value'
    assert a == {'foo': {'bar': 'value'}}
    assert a['foo']['bar'] == 'value'

    a['baz']['foo']['bar'] = 'value 2'
    a['baz']['bar'] = 'value 3'
    assert a['baz'] == {'foo': {'bar': 'value 2'}, 'bar': 'value 3'}
    assert a['baz']['foo']['bar'] == 'value 2'
    assert a['baz']['bar'] == 'value 3'



# Generated at 2022-06-24 03:19:23.619499
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree = Tree()
    ret = tree.__getitem__('test')
    assert ret is None
    ret = tree.__getitem__('test', 42)
    assert ret == 42



# Generated at 2022-06-24 03:19:28.646006
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Example tree_like mapping
    {
        'foo': {
            'bar': {
                'baz': 'baz'
            }
        }
    }
    """

    tree_like = {
        'foo': {
            'bar': {
                'baz': 'baz'
            }
        }
    }

    assert tree_like['foo']['bar']['baz'] == 'baz'
    assert get_tree_node(tree_like, 'foo:bar') == {'baz': 'baz'}
    assert get_tree_node(
        tree_like, 'foo:bar', parent=True) == {'baz': 'baz'}
    assert get_tree_node(tree_like, 'foo:bar:baz') == 'baz'
   

# Generated at 2022-06-24 03:19:40.729036
# Unit test for function get_tree_node
def test_get_tree_node():

    # Initialize our data structure
    mapping = {
        'one': {
            'spam': 'eggs',
            },
        'two': {
            'foo': 'bar',
            },
    }

    # Test traversal into a dictionary
    assert get_tree_node(mapping, 'one:spam') == 'eggs'
    assert get_tree_node(mapping, 'two:foo') == 'bar'

    # Try to fail without a default
    with pytest.raises(KeyError):
        get_tree_node(mapping, 'nope')

    # Test default
    assert get_tree_node(mapping, 'nope', default='bar') == 'bar'

    # Test parent

# Generated at 2022-06-24 03:19:44.886317
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    # Setup
    tree = Tree()
    tree['foo'] = tree
    tree['bar'] = 7

    # Exercise
    tree['foo']

    # Verify
    assert tree['foo'] == tree
    assert tree['bar'] == 7
    assert tree['baz'] is None
    assert tree.get('baz') is None
    assert tree.get('bar') == 7



# Generated at 2022-06-24 03:19:53.388864
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():

    tree = Tree(namespace='ns')
    tree.__setitem__('key', 'value')
    assert tree.get('key') is 'value'

    tree = Tree(namespace='ns')
    tree.__setitem__('key2', 'value2')
    assert tree.get('key') is not 'value'
    assert tree.get('key2') is 'value2'

    tree = Tree(namespace='ns')
    tree.__setitem__('key2', 'value2')
    tree.__setitem__('key2', 'value2new')
    assert tree.get('key') is not 'value'
    assert tree.get('key2') is 'value2new'

    tree = Tree(namespace='ns')
    tree.__setitem__('key:key:key', 'value')

# Generated at 2022-06-24 03:19:59.697352
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()
    tree.update({
        'traffic_stats': {
            'primary': {'rxtx_bytes': 0, 'rxtx_pkts': 0},
            'alternate': {'rxtx_bytes': 0, 'rxtx_pkts': 0}
        }
    })
    tree.register('traffic_stats:primary:rxtx_bytes', 0)
    tree.register('traffic_stats:primary:rxtx_pkts', 0)
    tree.register('traffic_stats:alternate:rxtx_bytes', 0)
    tree.register('traffic_stats:alternate:rxtx_pkts', 0)

# Generated at 2022-06-24 03:20:08.121922
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree = Tree()
    tree['a']['b']['c'] = 'd'

    # One level
    assert tree['a']['b']['c'] == 'd'

    # Two levels
    assert tree['a:b']['c'] == 'd'

    # Three levels
    assert tree['a:b:c'] == 'd'

    # Default key

# Generated at 2022-06-24 03:20:10.403412
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}
    set_tree_node(tree, 'a:b:c', True)
    tree == {'a': {'b': {'c': True}}}



# Generated at 2022-06-24 03:20:13.194833
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    expected = ['a', 'b']
    tree = RegistryTree({'a': {'b': {}}})
    got = RegistryTree(initial_is_ref=tree)
    assert got['a']['b'] == expected[:], 'Constructor with reference failed'



# Generated at 2022-06-24 03:20:16.148215
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    import doctest
    doctest.testmod(optionflags=doctest.NORMALIZE_WHITESPACE)



# Generated at 2022-06-24 03:20:24.114238
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    """
    Unit test for method `__setitem__` of `Tree` class.
    """
    tree = Tree()
    tree.register('foo', 'bar')
    assert tree[':foo'] == 'bar'

    # Test namespace
    tree.namespace = 'baz'
    tree.register('foo', 'bar')
    assert tree[':foo'] == 'bar'
    assert tree.get('baz:foo') == 'bar'

    # Test explicit namespace
    tree.register('foo', 'bar', namespace='foobar')
    assert tree.get('foobar:foo') == 'bar'

# Generated at 2022-06-24 03:20:30.079797
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    >>> mapping = tree()
    >>> set_tree_node(mapping, 'foo:bar:baz', 'quux')
    {'foo': {'bar': {'baz': 'quux'}}}
    >>> mapping
    defaultdict(<function tree at 0x7f3d08a926e0>, {'foo': {'bar': {'baz': 'quux'}}})
    """



# Generated at 2022-06-24 03:20:32.989840
# Unit test for constructor of class Tree
def test_Tree():
    tree = Tree()
    tree.update({'a': 1})
    tree.register('b', 2)
    assert tree['a'] == 1
    assert tree['b'] == 2



# Generated at 2022-06-24 03:20:34.794544
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    t = RegistryTree()
    t.register('foo:bar:baz', 'stuff')
    assert t['foo:bar:baz'] == 'stuff'

# Generated at 2022-06-24 03:20:36.142746
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    t = RegistryTree()
    assert isinstance(t, RegistryTree)



# Generated at 2022-06-24 03:20:40.021110
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    h = Tree()
    k = "maths:1:2:3:4:5:6:7:8:9:0"
    v = "ten"
    h.__setitem__(k, v)
    assert h.get(k) == v



# Generated at 2022-06-24 03:20:43.907815
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = collections.Mapping()
    set_tree_node(mapping, 'foo:bar:baz', 'set')
    assert get_tree_node(mapping, 'foo:bar:baz') == 'set'



# Generated at 2022-06-24 03:20:48.739855
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree = Tree()

    tree.register('foo', 'bar')
    assert tree['foo'] == 'bar'

    tree.register('foo:bar', 'baz')
    assert tree['foo:bar'] == 'baz'

    # Test default value

# Generated at 2022-06-24 03:20:49.732019
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    pass



# Generated at 2022-06-24 03:20:55.085172
# Unit test for function set_tree_node
def test_set_tree_node():
    data = {
        'foo': {
            'bar': {
                'baz': True,
                'baq': False
            }
        }
    }

    set_tree_node(data, 'foo:bar:BAZ', 123)
    assert data['foo']['bar']['BAZ'] == 123



# Generated at 2022-06-24 03:20:58.116085
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    a = RegistryTree()
    a.register('z:x:y', 'foo')
    assert a['z:x:y'] == 'foo'
    assert a['x:y'] == 'foo'



# Generated at 2022-06-24 03:21:00.227267
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    rt = RegistryTree()
    rt.register('foo', 'bar')
    assert rt['foo'] == 'bar'

# Generated at 2022-06-24 03:21:08.232222
# Unit test for function tree
def test_tree():
    import itertools
    import random
    t = tree()
    for x, y, z in itertools.product(range(2), range(2), range(2)):
        t[x][y][z] = x + y + z
    r = random.choice(range(8))
    x, y, z = divmod(r, 4)
    assert t[x][y][z] == r
    assert t[x][y][z] == (x + y + z)



# Generated at 2022-06-24 03:21:14.627600
# Unit test for function get_tree_node
def test_get_tree_node():
    test_mapping = {
        'some_mapping': {
            'other_mapping': 'value',
        },
        'foo': 'bar',
    }

    assert get_tree_node(test_mapping, 'some_mapping:other_mapping') == 'value'
    assert get_tree_node(test_mapping, 'foo') == 'bar'
    assert get_tree_node(test_mapping, 'baz') == _sentinel

# Generated at 2022-06-24 03:21:16.401305
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    r = RegistryTree()
    assert r is not None



# Generated at 2022-06-24 03:21:26.430175
# Unit test for function set_tree_node
def test_set_tree_node():
    """Unit test for function set_tree_node"""
    data = {}

    # Set top level
    set_tree_node(data, 'key', 'a')
    assert data == {'key': 'a'}

    # Set on existing level
    set_tree_node(data, 'key:again', 'b')
    assert data == {'key': 'a', 'key': {'again': 'b'}}

    # Set on existing level, with dashes
    set_tree_node(data, 'key:again-child', 'c')
    assert data['key'] == {'again': 'b', 'again-child': 'c'}

    # Set on new level
    set_tree_node(data, 'key:yet:again', 'd')

# Generated at 2022-06-24 03:21:37.600325
# Unit test for function set_tree_node
def test_set_tree_node():
    import pytest

    m = {}
    set_tree_node(m, 'a:b:c:d:e:f:g:h', 'foo')
    assert m['a']['b']['c']['d']['e']['f']['g']['h'] == 'foo'

    # The one condition I'd like to consider an error is duplicate keys.
    with pytest.raises(KeyError):
        set_tree_node(m, 'a:b:c:d:e:f:g:h', 'bar')

    set_tree_node(m, 'a:b:c:d:e:f:g:i', 'hello world')

# Generated at 2022-06-24 03:21:43.555126
# Unit test for function get_tree_node
def test_get_tree_node():
    # Test tree structure
    tree = {
        'root': {
            'child': {
                'node': 'node'
            },
            'child2': 'node2'
        },
        'root2': {
            'child': 'root2'
        }
    }

    assert get_tree_node(tree, 'root:child:node') == 'node'
    assert get_tree_node(tree, 'root2:child') == 'root2'
    assert get_tree_node(tree, 'root3:child') == _sentinel

# Generated at 2022-06-24 03:21:47.590225
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()

    t['a'] = 'A'
    assert t.data['a'] == 'A'
    assert t.data['a']['b']['c'] == Tree
    t['a']['b']['c'] = 'ABC'
    assert t.data['a']['b']['c'] == 'ABC'



# Generated at 2022-06-24 03:21:56.539493
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    # Create an instance of `Tree`
    tree = Tree()
    # Based on the spec, try to set the first key
    tree['first'] = 'first_value'
    # Check that the key is set
    assert tree['first'] == 'first_value'
    # Set the second key
    tree['second'] = 'second_value'
    # Check that the second key is set
    assert tree['second'] == 'second_value'
    # Go one level deeper
    tree['third:fourth'] = 'third_fourth_value'
    # Check that the key is set
    assert tree['third:fourth'] == 'third_fourth_value'
    # Check that the parent is still available
    assert tree['third'] == {}
    # Go yet another level deeper

# Generated at 2022-06-24 03:22:06.340681
# Unit test for constructor of class RegistryTree
def test_RegistryTree():

    # Create empty RegistryTree
    rt = RegistryTree()

    # Insert 2 elements
    rt.register('foo', 'bar')
    rt.register('foo:bar', 'buz')

    # Create an empty tree and fill it with elements
    rt2 = RegistryTree({'foo': {'bar': 'buz'}})

    # Assert contents equality
    assert(rt['foo'] == rt2['foo'])
    assert(rt['foo:bar'] == rt2['foo:bar'])

    # Assert namespaces are equal
    assert(rt.namespace == '')
    assert(rt.namespace == rt2.namespace)

    # Assert elements are stored on the same tree
    assert(hash(rt['foo']) == hash(rt2['foo']))

# Generated at 2022-06-24 03:22:10.572666
# Unit test for function tree
def test_tree():
    d = tree()
    d['foo']['bar'] = 1
    d['foo']['baz'] = 2
    assert d['foo']['bar'] == 1
    assert d['foo']['baz'] == 2

    d = tree()
    d['foo:bar:baz'] = '1'
    assert d['foo:bar:baz'] == '1'



# Generated at 2022-06-24 03:22:18.720153
# Unit test for function get_tree_node
def test_get_tree_node():
    """Test get_tree_node with a custom tree."""
    tree_test = {}
    tree_test['a'] = {'b': {'c': {'d': {'e': 'f', 'g': 'h'}}}, 'i': [{'j': 'k'}]}

    assert get_tree_node(tree_test, 'a') == {'b': {'c': {'d': {'e': 'f', 'g': 'h'}}}, 'i': [{'j': 'k'}]}
    assert get_tree_node(tree_test, 'a:b') == {'c': {'d': {'e': 'f', 'g': 'h'}}}
    assert get_tree_node(tree_test, 'a:b:c:d:e') == 'f'

# Generated at 2022-06-24 03:22:24.959596
# Unit test for function set_tree_node
def test_set_tree_node():
    test_mapping = {}
    set_tree_node(test_mapping, 'foo', 'bar')
    assert test_mapping['foo'] == 'bar'

    set_tree_node(test_mapping, 'foo:bar', 'baz')
    assert test_mapping['foo']['bar'] == 'baz'



# Generated at 2022-06-24 03:22:35.292673
# Unit test for function get_tree_node
def test_get_tree_node():
    node = {
        'path1': {
            'path2': {
                'path3': 'leaf'
            }
        }
    }
    assert get_tree_node(node, 'path1') == node['path1']
    assert get_tree_node(node, 'path1:path2') == node['path1']['path2']
    assert get_tree_node(node, 'path1:path2:path3') == 'leaf'
    assert get_tree_node(node, 'path1:path2:path3', parent=True) == node['path1']['path2']
    assert get_tree_node(node, 'inexistent', default='fallback') == 'fallback'
    assert get_tree_node(node, 'inexistent', default='fallback') == 'fallback'

# Generated at 2022-06-24 03:22:39.000650
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    t__setitem__ = t.__setitem__;t__setitem__('a', 'A')
    assert t['a'] == 'A'
    assert t['a'] != 'B'
    return



# Generated at 2022-06-24 03:22:46.190140
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree(initial=None, namespace='ns1')
    _ = t['a']
    assert t.namespace == 'ns1'
    assert t['ns1:a'] == {}
    _ = t['a']
    assert t['ns1:a'] == {}



# Generated at 2022-06-24 03:22:57.201736
# Unit test for function get_tree_node
def test_get_tree_node():  # flake8: noqa
    # Test only one branch
    mapping = {'a': {'b': {'c': 'test1'}}}
    assert(get_tree_node(mapping, 'a:b:c') == 'test1')

    # Test multiple
    mapping = {'a': {'b': {'c': 'test1'}, 'b1': {'c': 'test2'}}}
    assert(get_tree_node(mapping, 'a:b1:c') == 'test2')

    # Test shortcut notation
    mapping = {'a': {'b': {'c': 'test1'}, 'b1': {'c': 'test2'}}}

# Generated at 2022-06-24 03:23:04.579205
# Unit test for function set_tree_node
def test_set_tree_node():
    # Initialize testing data
    data = tree()

    # Default namespace
    set_tree_node(data, 'test', 'value')
    assert get_tree_node(data, 'test') == 'value'
    assert data['test'] == 'value'

    # Set on branch
    set_tree_node(data, 'test:nest:branch', 'value2')
    assert get_tree_node(data, 'test:nest:branch') == 'value2'

    # Update parent
    set_tree_node(data, 'test:nest', 'value3')
    assert get_tree_node(data, 'test:nest') == 'value3'
    assert get_tree_node(data, 'test:nest:branch') == 'value3'



# Generated at 2022-06-24 03:23:10.054616
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree = Tree()
    tree['one'] = 'un'
    tree['two'] = 'deux'
    assert tree.get('one') == 'un'
    assert tree.get('two') == 'deux'
    assert tree.get('three') is None



# Generated at 2022-06-24 03:23:13.878276
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    x = Tree()
    x.__setitem__('a', 1)
    assert x['a'] == 1
    x.__setitem__('b', 2)
    assert x['b'] == 2
    x.__setitem__('a:b', 3)
    assert x['a'] == {'b': 3}



# Generated at 2022-06-24 03:23:23.520701
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree()
    t['a']['b']['c'] = 'foo'
    assert t['a:b:c'] == 'foo'
    t = Tree(initial={'a': {'b': {'c': 'foo'}}})
    assert t['a:b:c'] == 'foo'
    assert t['a:b'] == {'c': 'foo'}
    assert t['noop'] is _sentinel
    assert t['noop', None] is None
    assert t['a:b:c', None] == 'foo'
    assert t['a', None] == {'b': {'c': 'foo'}}



# Generated at 2022-06-24 03:23:28.902910
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree()
    t['foo']['bar']['baz'] = 1
    assert t['foo']['bar']['baz'] == 1
    t['foo']['bar']['baz.bax'] = 2
    assert t['foo']['bar']['baz.bax'] == 2



# Generated at 2022-06-24 03:23:36.223825
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'b': {
                'c': 'd'
            },
            'd': {
                'e': 'f'
            }
        }
    }
    assert get_tree_node(mapping, 'a:b:c') == 'd'
    try:
        get_tree_node(mapping, 'a:e')
    except KeyError:
        pass
    assert get_tree_node(mapping, 'a:e', default='f') == 'f'



# Generated at 2022-06-24 03:23:42.884824
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    """
    Test for method `__getitem__` of class `Tree`

    Case:
    - Create Tree instance `a`
    - Set `a`[:foo:bar:baz] = 'quux'
    - `a`[:foo:bar:baz] == 'quux'
    """
    a = Tree()

# Generated at 2022-06-24 03:23:52.817200
# Unit test for function tree
def test_tree():
    t = tree()
    t.update({
        'a': {
            'b': 'c',
        }
    })
    assert t == {
        'a': {
            'b': 'c',
        }
    }
    assert t['a']['b'] == 'c'

    t['a']['b'] = 'd'
    assert t == {
        'a': {
            'b': 'd',
        }
    }
    assert t['a']['b'] == 'd'

    t['a']['d'] = 'e'
    assert t == {
        'a': {
            'b': 'd',
            'd': 'e'
        }
    }
    assert t['a']['b'] == 'd'

# Generated at 2022-06-24 03:23:59.382841
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'foo': {'bar': 'baz'}}, 'foo:bar') == 'baz'
    assert get_tree_node({'foo': {'bar': 'baz'}}, 'foo:baz') is None
    assert get_tree_node({'foo': {'bar': 'baz'}}, 'foo:baz', default=1) == 1
    assert get_tree_node({'foo': {'bar': 'baz'}}, 'foo:bar', parent=True) == {'bar': 'baz'}



# Generated at 2022-06-24 03:24:01.263462
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree()
    t['a.b.c'] = 42
    assert t['a.b.c'] == 42



# Generated at 2022-06-24 03:24:12.832860
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'ice': {
            'cream': {
                'chocolate': 'yum',
                'vanilla': 'yum',
            },
            'milk': 'yuck',
        },
        'liquor': 'yum',
    }

    assert get_tree_node(mapping, 'ice:cream:chocolate') == 'yum'
    assert get_tree_node(mapping, 'ice:cream:vanilla') == 'yum'
    assert get_tree_node(mapping, 'ice:milk') == 'yuck'
    assert get_tree_node(mapping, 'liquor') == 'yum'

    assert get_tree_node(mapping, 'ice:cream:chocolate', parent=True) == mapping['ice']['cream']
    assert get_