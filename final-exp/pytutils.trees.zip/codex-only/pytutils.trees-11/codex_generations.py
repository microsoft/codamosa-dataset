

# Generated at 2022-06-24 03:14:20.415119
# Unit test for function tree
def test_tree():

    def assert_tree(tree, expected):
        assert tree['foo']['bar']['baz'] == 'biz'
        assert tree['alpha']['beta']['gamma'] == expected

    # Test basic tree
    tree = Tree()
    tree['foo:bar:baz'] = 'biz'
    assert_tree(tree, 'gamma')
    tree['foo:bar:baz'] = 'biz'
    assert_tree(tree, 'gamma')

    # Test tree with namespace
    tree = Tree(namespace='alpha')
    tree['bar:baz'] = 'biz'
    assert_tree(tree, 'gamma')
    tree['bar:baz'] = 'biz'
    assert_tree(tree, 'gamma')

    # Test tree with initial values

# Generated at 2022-06-24 03:14:26.902136
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree(initial={
        'foo': 'bar',
        'baz': {'boo': 'foo'},
    }, namespace='test')

    assert t['foo'] == 'bar'
    assert t['baz:boo'] == 'foo'

    # Test __setitem__ with namespace
    t['foo'] = 'bar'
    assert t['foo'] == 'bar'
    assert t['test:foo'] == 'bar'

    # Test __setitem__ without namespace
    t.namespace = 'test2'
    t['foo'] = 'bar'
    assert t['test2:foo'] == 'bar'

    # Test setitem with namespace
    t.set('foo', 'bar')
    t['foo'] = 'baz'
    assert t['foo'] == 'baz'



# Generated at 2022-06-24 03:14:29.219629
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    assert type(RegistryTree()) is RegistryTree

# Generated at 2022-06-24 03:14:37.703605
# Unit test for function tree
def test_tree():
    t = tree()
    t['a'] = 42
    t['hello']['world'] = 1
    t['hello']['people'] = 2
    assert t['a'] == 42
    assert t['hello']['world'] == 1
    assert t['hello']['people'] == 2
    assert 'b' not in t
    assert 'b' not in t['hello']
    assert t['hello'].get('b') is None
    try:
        t['b']
    except KeyError:
        pass
    else:
        raise Exception('KeyError expected')



# Generated at 2022-06-24 03:14:46.951423
# Unit test for function get_tree_node
def test_get_tree_node():
    t = tree()
    t = set_tree_node(t, 'foo', 'bar')
    t = set_tree_node(t, 'foo:bar', 'baz')
    t = set_tree_node(t, 'bar:baz:quux', 'blah')

    assert get_tree_node(t, 'foo', default=None) == 'bar'
    assert get_tree_node(t, 'foo:bar', default=None) == 'baz'
    assert get_tree_node(t, 'bar:baz:quux', default=None) == 'blah'

    assert get_tree_node(t, 'foooo') is None
    assert get_tree_node(t, 'foo:baar') is None

# Generated at 2022-06-24 03:14:52.345443
# Unit test for constructor of class RegistryTree
def test_RegistryTree():

    r = RegistryTree()

    # Register
    r.register('foo', 'bar')
    assert r['foo'] == 'bar'

    r.register({'bar': 'baz'})
    assert r['bar'] == 'baz'

    # Unregister
    r.unregister(r['bar'])
    with pytest.raises(KeyError):
        r['bar']

    # Register with namespace
    r.register('baz:qux', 'foobar', namespace='foo')
    assert r.get('baz:qux', namespace='foo') == 'foobar'

    # Unregister with namespace
    r.unregister('baz:qux', namespace='foo')

# Generated at 2022-06-24 03:14:54.949982
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()
    assert tree.set('key', 'value') == set_tree_node(tree, 'key', 'value')
    assert tree.get('key') == get_tree_node(tree, 'key')



# Generated at 2022-06-24 03:14:59.877047
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()
    tree['a']['b'] = 1
    assert tree['a:b'] == 1

    tree2 = Tree({'a': {'b': 1}})
    assert tree2['a:b'] == 1

    # No difference between setitem and setattr whatsoever
    tree3 = Tree()
    tree3.a.b = 1
    assert tree3['a:b'] == 1


if __name__ == '__main__':
    test_Tree___setitem__()

# Generated at 2022-06-24 03:15:02.128678
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    registry = RegistryTree()
    registry.register('name', {'bob': {'age': 34}})
    assert registry.get('name:bob:age') == 34



# Generated at 2022-06-24 03:15:12.085897
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree({'a': {'b': 'c'}})
    t['a']['b'] = 'd'
    assert t['a']['b'] == 'd'
    assert t['a']['b'] is not 'd'
    t = Tree({'a': {'b': 'c'}}, initial_is_ref=True)
    t['a']['b'] = 'd'
    assert t['a']['b'] == 'c'
    t2 = Tree({'a': {'b': 'd'}}, initial_is_ref=True)
    t = Tree({'a': {'b': 'c'}}, t2)
    assert t['a']['b'] == 'd'

# Generated at 2022-06-24 03:15:14.908893
# Unit test for function get_tree_node
def test_get_tree_node():
    foo = {
        'k1': {
            'k2': {
                'k3': 'v1',
            }
        },
    }

    assert get_tree_node(foo, 'k1:k2:k3') == 'v1'



# Generated at 2022-06-24 03:15:18.886457
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    test_tree = Tree()
    test_tree['a'] = 1
    test_tree['b:c'] = 2
    test_tree['d:e:f'] = 3
    assert test_tree == {
        'a': 1,
        'b': {
            'c': 2
        },
        'd': {
            'e': {
                'f': 3
            }
        }
    }



# Generated at 2022-06-24 03:15:27.068170
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    # Test without namespace
    t = Tree()
    t['a:a'] = 'A'
    t['b:b'] = 'B'
    assert t['a:a'] == 'A'
    assert t['b:b'] == 'B'
    assert t._namespace_key('a:a') == 'a:a'

    t = Tree(namespace='t')
    t['a'] = 'A'
    t['t:b'] = 'B'
    assert t['a'] == 'A'
    assert t['b'] == 'B'
    assert t._namespace_key('a') == 't:a'



# Generated at 2022-06-24 03:15:30.730200
# Unit test for function set_tree_node
def test_set_tree_node():
    test_dict = dict()
    test_key = "test:test2"
    test_value = "test_value"
    set_tree_node(test_dict, test_key, test_value)
    assert test_dict["test"]["test2"] == test_value



# Generated at 2022-06-24 03:15:38.894858
# Unit test for function tree
def test_tree():
    """Regression test suite for `tree` function."""
    passed = False

# Generated at 2022-06-24 03:15:40.949242
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    from pprint import pprint as pp
    pp(Tree()['foo']['bar']['baz']('quux'))



# Generated at 2022-06-24 03:15:43.685805
# Unit test for function get_tree_node
def test_get_tree_node():
    m = tree()
    m['foo']['bar']['baz'] = 'baz'
    assert len(m) == 1
    assert len(m['foo']) == 1
    assert len(m['foo']['bar']) == 1
    res = get_tree_node(m, 'foo:bar:baz')
    assert res == 'baz'


if __name__ == '__main__':
    import nose
    r = nose.run()
    sys.exit(0 if r else 1)

# Generated at 2022-06-24 03:15:45.727167
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    registry_tree = RegistryTree(namespace='speech')
    registry_tree.register('hello', 'world')
    assert registry_tree['hello'] == 'world'
    assert registry_tree['speech:hello'] == 'world'

# Generated at 2022-06-24 03:15:56.712942
# Unit test for function tree
def test_tree():
    tree = tree()
    assert tree['a'] == tree
    assert tree['a']['b'] == tree
    assert tree['a']['b']['c'] == tree

    tree['a']['b']['c']['test'] = True
    assert tree['a']['b']['c'] == {'test': True}

    tree = tree()
    tree['a']['b']['c'] = 'test'
    tree['a']['b']['c2'] = 'test2'

    assert tree == {'a': {'b': {'c': 'test', 'c2': 'test2'}}}

    tree = tree()
    tree['a']['b']['c']['test'] = True

# Generated at 2022-06-24 03:16:00.243084
# Unit test for function set_tree_node
def test_set_tree_node():
    x = {}
    set_tree_node(x, 'a:b:c', 1)
    assert x == {'a': {'b': {'c': 1}}}



# Generated at 2022-06-24 03:16:10.369386
# Unit test for function get_tree_node
def test_get_tree_node():
    # Testing tree
    tree = {
        'a': {
            'b': 'c',
            'd': {
                'e': 'f'
            }
        }
    }

    # Check if function gets the correct values
    assert get_tree_node(tree, 'a:b') == 'c'
    assert get_tree_node(tree, 'a:d:e') == 'f'
    assert get_tree_node(tree, 'a:d:f') is _sentinel

    # Check if function gets parent nodes
    assert get_tree_node(tree, 'a:d:e', parent=True) == {'e': 'f'}

    # Check if function raises exceptions
    try:
        get_tree_node(tree, 'a:d:f')
    except KeyError:
        pass


# Generated at 2022-06-24 03:16:15.928340
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    t = RegistryTree()
    t['obj'].register('a', object())
    t['obj'].register('b', object())
    t['other'].register('c', object())

    # If this pops, we're ok.
    assert t['obj:b'] is t['obj']['b']
    assert t['other:c'] is t['other']['c']

# Generated at 2022-06-24 03:16:18.062553
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    mapping = Tree()
    mapping["foo:bar:baz"] = "abc"
    assert mapping["foo"]["bar"]["baz"] == "abc"



# Generated at 2022-06-24 03:16:27.595502
# Unit test for constructor of class Tree
def test_Tree():
    import unittest

    class TestTree(unittest.TestCase):
        def setUp(self):
            self.test_mapping = {
                'foo': 'bar',
                'baz': 'qux',
                'spam': {
                    'eggs': 'ham',
                    'foo': 'baz'
                }
            }
            self.tree = Tree(initial=self.test_mapping)

        def test_init(self):
            # Extremely basic
            self.assertEqual(sorted(self.tree.keys()), ['baz', 'foo', 'spam'])
            # Depth
            self.assertEqual(sorted(self.tree['spam'].keys()), ['eggs', 'foo'])


# Generated at 2022-06-24 03:16:37.584401
# Unit test for function tree
def test_tree():
    """Test tree function."""
    my_tree = tree()
    my_tree['John']['surname'] = 'Smith'
    my_tree['John']['age'] = 42
    assert my_tree['John']['surname'] == 'Smith'
    assert my_tree['John']['age'] == 42
    my_tree['John']['siblings']['Matthew']['age'] = 39
    assert my_tree['John']['siblings']['Matthew']['age'] == 39
    assert my_tree['John']['siblings']['Steven']['age'] == {}
    assert my_tree['John']['siblings']['Steven']['age'] == {}


# Generated at 2022-06-24 03:16:45.599122
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    a = Tree()
    a["foo"] = "bar"
    assert "bar" == a["foo"]
    assert a["bar"] == a

    a = Tree()
    a["foo:bar"] = "baz"
    assert "baz" == a["foo:bar"]
    assert a["foo"]["bar"] == "baz"
    assert a._namespace_key("baz:dip") == "baz:dip"
    assert a._namespace_key("baz:dip", namespace="namespace_key") == "namespace_key:baz:dip"

    try:
        a["bar"]
    except KeyError:
        pass
    else:
        assert False

    try:
        a["bar:baz"]
    except KeyError:
        pass

# Generated at 2022-06-24 03:16:56.081252
# Unit test for function get_tree_node
def test_get_tree_node():
    """Test TreeNode"""
    import pytest

    class Unindexable(object):

        def __getitem__(self, key):
            raise KeyError(key)

    simple_tree = {'1': {'2': {'3': '4'}}}
    simple_tree2 = collections.defaultdict(dict, {'1': {'2': {'3': '4'}}})

    deep_tree = {
        '1': {
            '2': {
                '3': {
                    '4': {
                        '5': {
                            '6': {
                                '7': {
                                    '8': {
                                        '9': '10',
                                    },
                                },
                            },
                        },
                    },
                },
            },
        },
    }


# Generated at 2022-06-24 03:16:59.515463
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    mapping = Tree()
    mapping['foo'] = 'bar'
    mapping['foo:bar:baz'] = 'bin'
    mapping['foo:bar:bin'] = 'baz'

    print(mapping)

# Generated at 2022-06-24 03:17:02.871120
# Unit test for function tree
def test_tree():
    test = tree()
    assert test is not None

    test['a']['b']['c'] = 'd'
    assert test['a']['b']['c'] == 'd'

    assert dict(test) == dict(a=dict(b=dict(c='d')))



# Generated at 2022-06-24 03:17:06.237239
# Unit test for function set_tree_node
def test_set_tree_node():
    """Testcase for set_tree_node."""
    d = tree()
    set_tree_node(d, 'a:b:c', 1)
    assert d['a']['b']['c'] == 1



# Generated at 2022-06-24 03:17:11.915755
# Unit test for function tree
def test_tree():
    t = tree()
    assert t == {}
    t['a']['b'] = 'c'

    assert t['a'] == {'b': 'c'}
    assert t['a']['b'] == 'c'
    assert t['a']['b'] == t['a']['b']

    import pytest
    with pytest.raises(KeyError):
        t['a']['c']



# Generated at 2022-06-24 03:17:19.584747
# Unit test for function get_tree_node
def test_get_tree_node():
    t = Tree(namespace='ns')
    t.update({
        'a': {
            'b': {
                'c': 'value',
                'd': 'value'}}})
    assert t['a:b:c'] == t.get('ns:a:b:c')

    t['ns:ns2:test'] = 'test'
    assert t['ns:ns2:test'] == 'test'

    # bad path
    with pytest.raises(KeyError):
        t['ns:a:b:c:d']



# Generated at 2022-06-24 03:17:29.214661
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    rtree = RegistryTree()
    rtree.register('a:b:c:d', 'test')
    r = rtree.get('a:b:c:d')
    assert r == 'test'
    try:
        rtree.get('a:b:c:d:e')
    except KeyError:
        pass
    else:
        raise AssertionError

    rtree.register('a:b:c', 123)
    r = rtree.get('a:b:c')
    assert r == 123

    rtree.register('a:b:c:d:e:f:g:h', 'test2')
    r = rtree.get('a:b:c:d:e:f:g:h')
    assert r == 'test2'


# Generated at 2022-06-24 03:17:39.215302
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    import pytest

    def get(t, key, default=_sentinel):
        return t.__getitem__(key, default=default)

    # Make sure it works for a simple tree
    t = Tree()
    t[('a', 'b')] = 'c'
    assert get(t, ('a', 'b')) == 'c'

    # Make sure it works for a subtree
    t = Tree()
    t[('a', 'b')] = 'c'
    assert get(t, ('a', ))['b'] == 'c'

    # Make sure it works with a namespace
    t = Tree()
    t.namespace = 'foo'
    t[('a', 'b')] = 'c'
    t[('d', )] = 'e'

# Generated at 2022-06-24 03:17:47.018378
# Unit test for constructor of class Tree
def test_Tree():
    """
    Check whether ':' notation works properly.
    """
    tree = Tree({
        'foo': {
            'bar': 1,
            'baz': 2,
        }
    })

    assert 1 == tree.get('foo:bar')
    assert 2 == tree.get('foo:baz')
    assert {} == tree.get('not_a_key')
    with pytest.raises(KeyError):
        tree.get('not_a_key', _sentinel)
    assert {} == tree.get('not_a_key', _sentinel)

# Generated at 2022-06-24 03:17:51.045956
# Unit test for function set_tree_node
def test_set_tree_node():
    t = {}
    set_tree_node(t, 'a:b:c', 1)
    set_tree_node(t, 'a:b:d', 2)
    set_tree_node(t, 'b', 3)
    assert t == {'a': {'b': {'c': 1, 'd': 2}}, 'b': 3}



# Generated at 2022-06-24 03:17:54.084459
# Unit test for function tree
def test_tree():
    assert get_tree_node(tree(), 'foo') == tree()



# Generated at 2022-06-24 03:17:59.824577
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    test_tree = Tree()
    test_tree['foo:bar'] = 1
    assert test_tree['foo']['bar'] == 1
    test_tree['foo:baz'] = 2
    assert test_tree['foo']['baz'] == 2
    assert test_tree['foo'] == dict(bar=1, baz=2)
    assert test_tree['foo:bar'] == 1
    assert test_tree['foo:baz'] == 2

    # Test _namespace_key
    test_tree = Tree(initial=dict(bar=1, baz=2))
    test_tree.namespace = 'foo'
    assert test_tree['bar'] == 1
    assert test_tree['baz'] == 2
    assert test_tree.get('not-here', default=666) == 666

# Generated at 2022-06-24 03:18:04.605991
# Unit test for function get_tree_node
def test_get_tree_node():
    test = tree()
    test['']['namespace']['key'] = 'value'

# Generated at 2022-06-24 03:18:09.797527
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    from test_base import TestCase
    from datetime import datetime

    # Setup
    tree = Tree()
    tree['foo:bar'] = 'BAR!'
    tree['foo:bar:baz'] = 'BAZ!'
    tree['foo:bar:baz:qux'] = 'QUX!'
    tree['foo:bar:quux'] = 'QUUX!'
    tree['foo:norf'] = 'NORF!'

    # Assertions
    assert tree['foo:bar:baz'] == 'BAZ!'
    assert tree['foo:bar:baz:qux'] == 'QUX!'
    assert tree['foo:bar:baz:qux'][0] == 'QUX!'
    assert tree['foo:bar:quux'] == 'QUUX!'

# Generated at 2022-06-24 03:18:19.704137
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'a': {'b': {'c': True}}}, 'a:b:c') is True
    assert get_tree_node({'a': {'b': {'c': True}}}, 'a:b:C') is _sentinel
    assert get_tree_node({'a': {'b': {'c': True}}}, 'a:b:c', default=None) is True
    assert get_tree_node({'a': {'b': {'c': True}}}, 'a:B:C', default=None) is None
    assert get_tree_node({'a': {'b': {'c': True}}}, 'A:B:C') is _sentinel



# Generated at 2022-06-24 03:18:23.849552
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    import unittest
    class TestRegistryTree(unittest.TestCase):
        def test_basic(self):
            tree = RegistryTree()
            tree.register('one:two:three', 'value')
            self.assertEqual(tree['one:two:three'], 'value')

    unittest.main()

if __name__ == '__main__':
    test_RegistryTree()

# Generated at 2022-06-24 03:18:33.890200
# Unit test for function get_tree_node
def test_get_tree_node():
    # Compile test data
    data = {
        'a': 'A',
        'b': {
            'ba': 'BA',
            'bb': {
                'bba': 'BBA',
                'bbb': {
                    'bbba': 'BBBA',
                }
            }
        }
    }
    # Test expected
    assert get_tree_node(data, 'a') == 'A'
    assert get_tree_node(data, 'b:ba') == 'BA'
    assert get_tree_node(data, 'b:bb:bba') == 'BBA'
    assert get_tree_node(data, 'b:bb:bbb:bbba') == 'BBBA'
    # Test non-existing key
    with pytest.raises(KeyError):
        get_tree_node

# Generated at 2022-06-24 03:18:40.367606
# Unit test for function set_tree_node
def test_set_tree_node():
    d = {'a': {'b': {'c': 2}}}
    n = set_tree_node(d, 'x:y:z', 1)
    assert n == {'x': {'y': {'z': 1}}}
    assert d == {'a': {'b': {'c': 2}}, 'x': {'y': {'z': 1}}}



# Generated at 2022-06-24 03:18:50.614724
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():

    # Setup test
    test_data = {'a': {'b': {'c': 10}}}
    tree = Tree(initial=test_data)

    # Expected behavior:
    #  - Valid keys should return the associated value.
    #  - Invalid keys should raise KeyError.
    assert tree['a'] == {'b': {'c': 10}}
    assert tree['a:b'] == {'c': 10}
    assert tree['a:b:c'] == 10

    with pytest.raises(KeyError):
        tree['d']

    with pytest.raises(KeyError):
        tree['a:d']

    with pytest.raises(KeyError):
        tree['a:b:d']


# Generated at 2022-06-24 03:18:55.600337
# Unit test for function tree
def test_tree():
    # Create a tree
    tree_ = tree()
    # Set a value
    tree_['foo'] = 'bar'
    # Get the value
    assert tree_['foo'] == 'bar'
    # Set a multidemensional value
    tree_['foo:bar'] = 'baz'
    # Get the value
    assert tree_['foo:bar'] == 'baz'



# Generated at 2022-06-24 03:19:03.046720
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree()
    t['a'] = 'foo'
    t['a:b'] = 'baz'
    t['a:c:d:e:f'] = 'fizz'

    # Test traversal
    t.get('a:b') == 'baz'
    t.get('a:c:d:e:f') == 'fizz'

    assert t.get('a:c:d:e:f:g') is None
    assert t.get('a:c:d:e:f:g', 'missing') == 'missing'

    return True



# Generated at 2022-06-24 03:19:05.630079
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    """Test for RegistryTree."""
    registry = RegistryTree()
    registry.register('foo', 'bar')
    assert registry['foo'] == 'bar'



# Generated at 2022-06-24 03:19:16.385461
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = collections.OrderedDict(
        [('host', 'localhost'),
         ('user', 'admin'),
         ('password', 'admin'),
         ('port', 9900),
         ('db', 'mydb'),
         ('config', collections.OrderedDict([
             ('rows', 100),
             ('page', 1),
             ('timezone', 'UTC'),
         ]))]
    )
    assert get_tree_node(mapping, 'host') == 'localhost'
    assert get_tree_node(mapping, 'page', parent=True) == mapping['config']
    assert get_tree_node(mapping, 'page') == 1
    with pytest.raises(KeyError):
        get_tree_node(mapping, 'p')

# Generated at 2022-06-24 03:19:21.458171
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    from pprint import pprint
    r = RegistryTree()
    r.register('foo:a', 'bar')
    pprint(r)
    assert r['foo:a'] == 'bar'
    assert r.get('foo:a') == 'bar'
    assert r['foo:xxx'] is None
    try:
        assert r['foo:a:b']  # should fail
        assert False
    except KeyError:
        pass

# Generated at 2022-06-24 03:19:23.600715
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    a = RegistryTree(namespace='foo')
    a.register('bar', "baz")
    assert a['foo:bar'] == "baz"

# Generated at 2022-06-24 03:19:26.947750
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    t.__setitem__('tree', 'value')
    assert t['tree'] == 'value'



# Generated at 2022-06-24 03:19:30.112934
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    # Arrange
    t = Tree()
    t['a:b:d'] = 'z'

    # Act
    actual = t['a:b:d']

    # Assert
    assert actual == 'z'


test_Tree___getitem__()

# Generated at 2022-06-24 03:19:41.681059
# Unit test for constructor of class Tree
def test_Tree():
    a = Tree()
    for i in range(0, 10):
        a[i] = i
        assert a[i] == i

    assert a.get(10, _sentinel) is _sentinel

    a = Tree(namespace='seven')
    a.set(10, 'foo')
    assert a.get('seven:10') == 'foo'

    # Testing the initial ref option.
    a = Tree(initial={'a': 10}, initial_is_ref=True)
    a['a'] = 20
    a['b'] = 30
    assert a['a'] == 20
    assert a['b'] == 30

    a['c'] = Tree({'d': 20}, initial_is_ref=True)
    assert a['c:d'] == 20


if __name__ == '__main__':
    test

# Generated at 2022-06-24 03:19:43.521695
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    dct = Tree()
    dct['key'] = 'value'
    assert dct['key'] == 'value'



# Generated at 2022-06-24 03:19:54.992887
# Unit test for constructor of class Tree
def test_Tree():
    # Empty tree (namespace)
    tree = Tree()
    assert not tree
    assert not tree.namespace
    tree.namespace = 'test'
    assert tree.namespace == 'test'

    # Tree from dict
    tree = Tree({'1': '1', '2': '2', '3': '3'})
    assert tree['1'] == tree.get('1') == '1'

    # Tree from dict with namespace
    tree = Tree({'1': '1', '2': '2', '3': '3'}, namespace='test')
    assert tree['1'] == tree.get('1') == '1'
    assert tree['test:1'] == tree.get('test:1') == '1'
    with pytest.raises(KeyError):
        tree['1']

# Generated at 2022-06-24 03:20:03.387071
# Unit test for function tree
def test_tree():
    tree = Tree()
    tree['a']['b']['c'] = 'd'
    tree['1']['2']['3']['4'] = '5'

# Generated at 2022-06-24 03:20:06.392230
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    tree = RegistryTree()
    try:
        tree['foo']
    except KeyError:
        pass
    else:
        raise AssertionError('Getter should have raised key error!')



# Generated at 2022-06-24 03:20:08.077245
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree()
    t2 = Tree(t)
    assert t == t2



# Generated at 2022-06-24 03:20:17.093301
# Unit test for function tree
def test_tree():
    _tree = tree()
    _tree['a-ac']['a-ac-ac'] = 'a-ac-ac-ac'
    _tree['a-ac']['a-ac-ad'] = 'a-ac-ad-ad'
    _tree['a-ac']['a-ac-ae'] = 'a-ac-ae-ae'
    _tree['a-ac']['a-ac-af'] = 'a-ac-af-af'
    _tree['a-ac']['a-ac-ag'] = 'a-ac-ag-ag'
    _tree['a-ac']['a-ac-aa'] = 'a-ac-aa-aa'
    _tree['a-ac']['a-ac-ab'] = 'a-ac-ab-ab'
    _tree

# Generated at 2022-06-24 03:20:27.622496
# Unit test for constructor of class Tree
def test_Tree():
    import unittest

    class TestTree(unittest.TestCase):
        def test_single(self):
            test_tree = Tree()
            test_tree['foo'] = 'baz'
            self.assertEqual(test_tree['foo'], 'baz')

        def test_double_dimension(self):
            test_tree = Tree()
            test_tree['foo:bar'] = 'baz'
            self.assertEqual(test_tree['foo:bar'], 'baz')

        def test_namespace(self):
            test_tree = Tree(namespace='test')
            test_tree['foo:bar'] = 'baz'
            self.assertEqual(test_tree['foo:bar'], 'baz')
            self.assertEqual(test_tree.namespace, 'test')

# Generated at 2022-06-24 03:20:32.891365
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    """Unit test for method __setitem__ of class Tree"""
    # TODO Verify all asserts
    foo = Tree()
    parent = foo['namespace1:namespace2:namespace3:key'] = 'value'
    # assert parent == foo['namespace1']
    assert isinstance(parent, Tree)
    assert foo['namespace1:namespace2:namespace3:key'] == 'value'



# Generated at 2022-06-24 03:20:42.493060
# Unit test for function set_tree_node
def test_set_tree_node():
    from mock import MagicMock
    from random import shuffle

    mock = MagicMock()

    mapping = {}

    list_ = list(range(99))
    shuffle(list_)
    for i in list_:
        set_tree_node(mapping, str(i), i)
    assert set_tree_node(mapping, ':3:3:3:3:3', 3)
    for i in list_:
        assert get_tree_node(mapping, str(i)) == i
    assert get_tree_node(mapping, ':3:3:3:3:3') == 3
    assert get_tree_node(mapping, ':3:3:3:3', parent=True) == {'3': 3}

# Generated at 2022-06-24 03:20:45.665293
# Unit test for constructor of class RegistryTree

# Generated at 2022-06-24 03:20:55.222865
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    """
    Test method __setitem__ of class Tree.
    """
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO

    import sys
    import unittest
    from treelib import Tree

    # Define the required methods for unittest
    def read(self, text=None, filename=None):
        if text is None and filename is None:
            return ''
        if text is not None:
            self.write(text)
        elif filename is not None:
            with open(filename) as f:
                data = f.read()
            self.write(data)

    class Input(StringIO):
        read = read

    class Output(StringIO):
        pass

    def setUp(self):
        self.inp = Input()
        self.out

# Generated at 2022-06-24 03:20:57.071309
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    test_instance = Tree()
    test_instance.__setitem__('a', 'b')



# Generated at 2022-06-24 03:21:04.639618
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {'a': {'b': {'c': {'d': 'e'}}}}
    set_tree_node(tree, 'a:b:c:d', 'f')
    assert tree['a']['b']['c']['d'] == 'f'
    set_tree_node(tree, 'a:b:c:d', 'g')
    assert tree['a']['b']['c']['d'] == 'g'
    set_tree_node(tree, 'a:b:c:d:e', 'f')
    assert tree['a']['b']['c']['d']['e'] == 'f'

# Generated at 2022-06-24 03:21:12.401698
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = Tree()
    node = set_tree_node(mapping, 'me:myself', 1)
    assert node is mapping['me']
    assert mapping['me:myself'] == 1
    assert mapping['me']['myself'] == 1
    node = set_tree_node(mapping, 'me:myself:and_i', 2)
    assert node is mapping['me']['myself']
    assert mapping['me:myself:and_i'] == 2
    assert mapping['me']['myself']['and_i'] == 2


# Generated at 2022-06-24 03:21:14.474105
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    """Unit test for method __setitem__ of class Tree"""
    # TODO Implement this
    pass


# Generated at 2022-06-24 03:21:21.598874
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()
    tree['foo'] = 'bar'
    tree['bar'] = 'foo'
    tree['baz:qux'] = 'qux:baz'

    assert tree['foo'] == 'bar'
    assert tree['bar'] == 'foo'
    assert tree['baz:qux'] == 'qux:baz'

    tree['foo:bar:baz'] = 'qux'

    assert tree['foo:bar:baz'] == 'qux'



# Generated at 2022-06-24 03:21:27.606007
# Unit test for function get_tree_node
def test_get_tree_node():
    t = tree()
    t['a']['b'] = {'c': [1, 2, 3]}
    assert get_tree_node(t, 'a:b') == {'c': [1, 2, 3]}
    assert get_tree_node(t, 'a:b:c') == [1, 2, 3]
    assert get_tree_node(t, 'a:b:c:2') == 3
    try:
        get_tree_node(t, 'a:b:c:4')
    except KeyError:
        pass
    else:
        assert False



# Generated at 2022-06-24 03:21:33.740841
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'name': 'Graham',
        'city': 'Seattle',
        'state': {
            'name': 'Washington',
            'abbrev': 'WA',
        }
    }
    assert get_tree_node(mapping, 'name') == 'Graham'
    assert get_tree_node(mapping, 'state:name') == 'Washington'
    assert get_tree_node(mapping, 'state:abbrev') == 'WA'



# Generated at 2022-06-24 03:21:39.648383
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    """
    A method that tests functionality of __setitem__
    """
    # Creating a Tree
    tree = Tree()
    # Adding a key-value pair to the Tree
    tree.__setitem__('a','b')
    assert tree == {'a': 'b'}
    # Deleting a key-value pair from the Tree
    tree.__delitem__('a')
    assert tree == {}



# Generated at 2022-06-24 03:21:44.790517
# Unit test for function tree
def test_tree():
    t = tree()
    t['foo']['bar'] = 'baz'
    assert t['foo:bar'] == 'baz'
    assert t['foo'] == tree()
    assert t['bar'] == tree()



# Generated at 2022-06-24 03:21:53.008839
# Unit test for function set_tree_node
def test_set_tree_node():
    """Unit test for set_tree_node"""
    test_map = tree()
    test_map['foo']['bar']['baz'] = 'foo'
    assert test_map['foo:bar:baz'] == 'foo'
    assert set_tree_node(test_map, 'foo:bar:baz', 'foobar') == {'baz': 'foobar'}
    assert test_map['foo:bar:baz'] == 'foobar'
    assert set_tree_node(test_map, 'test:test2:test3', 'foobar') == {'test3': 'foobar'}
    assert test_map['test:test2:test3'] == 'foobar'



# Generated at 2022-06-24 03:22:03.068566
# Unit test for function get_tree_node
def test_get_tree_node():
    test_mapping = {
        'a': {
            'aa': {
                'aaa': 'IamAAA!',
                'aab': 'IamAAB!'
            }
        },
        'b': {
            'ba': 'IamBA!',
            'bb': {
                'ba': 'IamBBA!'
            }
        },
        'c': 'IamC!',
        'd': {
            'da': {
                'daa': 'IamDAA!'
            }
        }
    }

    assert get_tree_node(test_mapping, 'd') == {'da': {'daa': 'IamDAA!'}}
    assert get_tree_node(test_mapping, 'a:aa:aaa') == 'IamAAA!'
    assert get_tree

# Generated at 2022-06-24 03:22:06.342624
# Unit test for function tree
def test_tree():
    tree = tree()
    assert tree['a']['b']['c'] == {}
    assert tree == {'a': {'b': {'c': {}}}}


if __name__ == '__main__':
    test_tree()

# Generated at 2022-06-24 03:22:15.746624
# Unit test for function tree
def test_tree():
    import json
    data = tree()
    data['foo']['bar']['baz']['foo'] = 'baz'

    assert json.dumps(data) == json.dumps({
        'foo': {
            'bar': {
                'baz': {
                    'foo': 'baz'
                }
            }
        }
    })

    # Test get_tree_node
    assert get_tree_node(data, 'foo:bar:baz:foo') == 'baz'
    assert get_tree_node(data, 'foo:bar:baz:foo:bar') is None
    assert get_tree_node(data, 'foo:bar:baz:foo:bar', default='spam') == 'spam'

    # Test set_tree_node

# Generated at 2022-06-24 03:22:20.009157
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()
    tree['foo'] = 'bar'
    assert tree['foo'] == 'bar'

    # Test with default namespace
    tree._namespace = 'blah'
    tree['fizz'] = 'buzz'
    assert tree['fizz'] == 'buzz'
    assert tree['blah:fizz'] == 'buzz'

    # Test with namespace override
    tree['blarg:fizz'] = 'buzz'
    assert tree['blarg:fizz'] == 'buzz'
    assert tree['fizz'] != 'buzz'



# Generated at 2022-06-24 03:22:28.210130
# Unit test for function tree
def test_tree():
    tree = Tree()
    tree['foo:bar:baz'] = 'test'
    assert tree['foo']['bar']['baz'] == 'test'
    assert tree['foo:bar:baz'] == 'test'
    tree['foo']['bar']['baz'] = 'test_overwritten'
    assert tree['foo:bar:baz'] == 'test_overwritten'
    tree['foo:bar:baz'] = 'test_again'
    assert tree['foo']['bar']['baz'] == 'test_again'



# Generated at 2022-06-24 03:22:35.569922
# Unit test for function set_tree_node
def test_set_tree_node():
    import pytest
    from itertools import product

    test_data = dict(product(map(str, xrange(10)), repeat=2))

# Generated at 2022-06-24 03:22:45.813008
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    '''
    Unit test for method __getitem__ of class Tree
    '''
    # Initialize a tree
    test_tree = Tree()
    # Check that it works for a single entry
    test_tree['one'] = 'two'
    assert test_tree['one'] == 'two'
    # Check that it works for a multidimensional entry
    test_tree['three:four:five'] = 'six'
    assert test_tree['three:four:five'] == 'six'
    assert test_tree['three']['four']['five'] == 'six'
    # Check that it raises an error if the value doesn't exist

# Generated at 2022-06-24 03:22:48.635325
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree = Tree()
    tree['foo'] = {'bar': {'baz': 'quux'}}
    assert tree['foo', 'bar', 'baz'] == 'quux'



# Generated at 2022-06-24 03:22:54.073884
# Unit test for function tree
def test_tree():
    expected_result = collections.OrderedDict([
        ('a', collections.OrderedDict([
            ('b', 'c')
        ]))
    ])
    tree_ = tree()
    tree_['a:b'] = 'c'
    assert tree_ == expected_result



# Generated at 2022-06-24 03:22:56.173227
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    pass

if __name__ == '__main__':
    test_RegistryTree()

# Generated at 2022-06-24 03:22:59.618356
# Unit test for function get_tree_node
def test_get_tree_node():
    foo = Tree()
    foo['bar'] = 'baz'
    assert get_tree_node(foo, 'bar') == 'baz'
    assert get_tree_node(foo, 'zed') == _sentinel
    foo['bar:zed'] = 'karl'
    assert get_tree_node(foo, 'bar:zed') == 'karl'



# Generated at 2022-06-24 03:23:10.294907
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()

    test_list = [('a', None),
                 ('a:b', {'b': None}),
                 ('a:b:c', {'b': {'c': None}}),
                 ('d:e:f:g:h:i:j:k:l:m',
                  {
                      'd': {
                          'e': {
                              'f': {
                                  'g': {
                                      'h': {
                                          'i': {
                                              'j': {
                                                  'k': {
                                                      'l': {
                                                          'm': None
                                                      }
                                                  }
                                              }
                                          }
                                      }
                                  }
                              }
                          }
                      }
                  })
                 ]
   

# Generated at 2022-06-24 03:23:17.368308
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'hello':
        {'world':
            {'my':
                'name',
             },
         },
        'goodbye':
            'girl',
    }

    # This is expected to raise a KeyError, since None is a default value
    assert get_tree_node(mapping, 'hello:world:my:name') is 'name'
    assert get_tree_node(mapping, 'hello:world:my:name') == 'name'
    assert get_tree_node(mapping, 'hello:world:my:not_a_name', default=None) is None
    assert get_tree_node(mapping, 'hello:world:my:not_a_name', default=None) is None

# Generated at 2022-06-24 03:23:22.464480
# Unit test for function set_tree_node
def test_set_tree_node():
    """Unit test for function set_tree_node."""
    tree = {}
    value = {'hello': 'world'}
    assert not set_tree_node(tree, 'a:b:c:d:e', value)

# Generated at 2022-06-24 03:23:29.753176
# Unit test for function get_tree_node
def test_get_tree_node():
    tree_node = Tree({
        'one': {
            'two': 2
        }
    })
    assert tree_node.get('one:two') == 2
    assert tree_node.get('two') is None
    assert tree_node.get('two', default='two') == 'two'
    assert tree_node.get('two', default=tree_node) is tree_node

    with pytest.raises(KeyError):
        tree_node.get('three')



# Generated at 2022-06-24 03:23:32.924347
# Unit test for function tree
def test_tree():
    t = tree()
    t['a'] = 1
    t['a']['b'] = 2
    t['a']['c']['d'] = 3
    print(t)


# Generated at 2022-06-24 03:23:36.234523
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()
    tree['foo'] = 'bar'
    assert tree['foo'] == 'bar'
    tree['foo:bar'] = 'baz'
    assert tree['foo:bar'] == 'baz'


# Generated at 2022-06-24 03:23:41.158245
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'a': {
            'a': 'IT WORKED',
        }
    }

    assert get_tree_node(mapping, 'a:a') == 'IT WORKED'
    assert get_tree_node(mapping, 'a:a', default=False) == 'IT WORKED'
    assert get_tree_node(mapping, 'a:b', default=False) is False
    try:
        get_tree_node(mapping, 'a:b')
    except KeyError:
        assert True
    else:
        assert False



# Generated at 2022-06-24 03:23:51.566086
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    import copy

    expected = 'world'
    tree = Tree({'hello': expected})
    assert tree['hello'] == expected
    assert tree.get('hello') == expected
    assert tree.get('foo') is None
    assert tree.get('foo', 'bar') == "bar"
    assert tree.get(':hello') is None
    assert tree.get('hello', 'bar') is not "bar"  # because it never called for `default`

    # Make sure it doesn't modify the original object
    tree = Tree({'hello': expected})
    tree = tree['hello']
    assert tree['hello'] == expected

    tree = Tree({'hello': {'world': {'foo': 'bar'}}})
    assert tree['hello:world:foo'] == 'bar'
    assert tree['foo'] is None

# Generated at 2022-06-24 03:23:56.640869
# Unit test for function tree
def test_tree():
    _tree = tree()
    _tree['one'] = 'two'
    _tree['one']['three'] = 'four'
    _tree['two']['five']['six'] = 'seven'
    assert _tree['one'] == 'two'
    assert _tree['one:three'] == 'four'
    assert _tree['two:five:six'] == 'seven'
    return _tree



# Generated at 2022-06-24 03:24:04.884342
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree(namespace='foo')
    for _ in t:
        raise AssertionError('Non-empty tree when created.')

    # Set top-level items
    t['bar'] = 'baz'
    t['bar2'] = 'baz2'
    t['bar3'] = 'baz3'

    # Set one level deep
    t['bar:baz'] = 'baz'

    # Set two levels deep
    t['bar:baz:baz'] = 'baz'

    # Check expected values
    assert t['bar'] == 'baz'
    assert t['bar2'] == 'baz2'
    assert t['bar3'] == 'baz3'
    assert t['bar:baz'] == 'baz'

# Generated at 2022-06-24 03:24:06.966711
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    assert Tree().__setitem__('a', 'b') == {'a': 'b'}



# Generated at 2022-06-24 03:24:12.203629
# Unit test for function tree
def test_tree():
    root = tree()

    root['values']['a'] = 'Hello'
    root['values']['b'] = 'World'
    root['values']['c'] = '!'

    assert root['values']['a'] ==  'Hello'
    assert root['values']['b'] ==  'World'
    assert root['values']['c'] ==  '!'