

# Generated at 2022-06-24 03:14:14.236329
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    """
    Test RegistryTree constructor and set/get behavior.
    """
    prefix = 'registrytree'
    key = 'test'
    value = 'testvalue'
    rt = RegistryTree()
    assert rt.get(key) is None

    rt = RegistryTree(namespace=prefix)
    rt[key] = value
    assert rt.get(key) == value and rt.get(key, namespace=prefix) == value
    assert rt.get(key, namespace='blah') is None

    rt = RegistryTree(initial={key: value}, namespace=prefix)
    assert rt.get(key) == value
    assert rt.get(key, namespace='blah') is None



# Generated at 2022-06-24 03:14:15.750570
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree = Tree()
    tree["foo"] = "bar"
    assert tree["foo"] is "bar"

# Generated at 2022-06-24 03:14:21.572072
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    """
    Unit test for method __setitem__ of class Tree
    """
    t = Tree()
    t['test_Tree__setitem__'] = 'hello'
    assert t['test_Tree__setitem__'] == 'hello'



# Generated at 2022-06-24 03:14:26.248844
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree()
    t[':a:b'] = 'c'
    assert t[':a:b'] == 'c'



# Generated at 2022-06-24 03:14:31.696360
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree()
    t['a']['b'] = 3
    assert t['a']['b'] == 3

    # Test namespace
    t = Tree(namespace='foo')
    t['b'] = 3
    assert t['b'] == 3
    assert t['foo:b'] == 3

    # Test __eq__ on tree
    t = Tree()
    t['foo']['bar'] = 3
    t2 = Tree()
    t2['foo']['bar'] = 3
    assert t == t2



# Generated at 2022-06-24 03:14:42.532674
# Unit test for constructor of class Tree
def test_Tree():
    def prop(obj):
        return Tree(obj)

    def prop_is_ref(obj):
        return Tree(obj, initial_is_ref=True)

    for prop in [prop, prop_is_ref]:
        obj = {
            'foo': 'bar',
            'baz': {
                'foo': 'bar'
            },
            'qux': {
                'fooz': 'baaz'
            },
        }
        t = prop(obj)
        assert t.data is obj
        assert t['foo'] == obj['foo']
        assert t['baz']['foo'] == obj['baz']['foo']
        assert t['qux']['fooz'] == obj['qux']['fooz']

# Generated at 2022-06-24 03:14:50.757186
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Unit test for function set_tree_node
    """
    test_mapping = tree()
    set_tree_node(test_mapping, 'key1:key2', 'value')
    assert test_mapping['key1']['key2'] == 'value'

    set_tree_node(test_mapping, 'key3:key4', 'value2')
    assert test_mapping['key3']['key4'] == 'value2'



# Generated at 2022-06-24 03:14:58.477153
# Unit test for constructor of class Tree
def test_Tree():
    mapping = Tree()
    mapping['foo:bar:baz'] = 'spam'
    assert 'foo' in mapping
    assert 'bar' in mapping['foo']
    assert 'baz' in mapping['foo:bar']
    assert mapping['foo:bar:baz'] == 'spam'
    mapping['foo:eggs'] = 'ham'
    assert 'foo' in mapping
    assert 'eggs' in mapping['foo']
    assert mapping['foo:eggs'] == 'ham'
    assert 'baz' in mapping['foo:bar']
    assert mapping['foo:bar:baz'] == 'spam'



# Generated at 2022-06-24 03:15:00.797442
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = collections.defaultdict(dict)
    assert set_tree_node(mapping, 'a:b:c', 'd')
    assert mapping == {'a': {'b': {'c': 'd'}}}



# Generated at 2022-06-24 03:15:05.593579
# Unit test for constructor of class Tree
def test_Tree():
    data = {'foo': 'bar', 'bar': {'baz': 'quux'}}
    t = Tree(data)
    assert t.get('foo') == 'bar'
    assert t.get('bar:baz') == 'quux'



# Generated at 2022-06-24 03:15:12.799055
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'one': {
            'two': {
                'three': 3
            }
        }
    }

    assert 3 == get_tree_node(mapping, 'one:two:three')
    assert mapping == get_tree_node(mapping, 'one:two:three', parent=True)

    try:
        get_tree_node(mapping, 'one:two:four')
    except KeyError:
        pass
    else:
        raise AssertionError('KeyError not raised when expected.')

    assert None is get_tree_node(mapping, 'one:two:four', None)



# Generated at 2022-06-24 03:15:20.173118
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    """Unit test for method Tree.__setitem__"""
    from pprint import pprint as print_
    from collections import defaultdict
    from copy import copy

    tree = Tree()
    tree['one']['two']['three'] = 'Four'

    _assert_equal(tree, {'one': {'two': {'three': 'Four'}}})

    tree2 = Tree()
    tree2['one']['two']['three']['Four'] = 'Five'

    _assert_equal(tree2, {'one': {'two': {'three': {'Four': 'Five'}}}})

    tree3 = Tree()
    tree3['one']['two']['three']['Four']['Five']['Six'] = 'Seven'


# Generated at 2022-06-24 03:15:29.559080
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():

    # Test `:static:` method `:method:__setitem__` of class  `:class:Tree` with `:arg:namespace` set to `:attr:None`
    def test_with_namespace_set_to_None():

        # Set `:var:_2359` to `:class:Tree`
        _2359 = Tree
        # Call `:method:__setitem__` of `:var:_2359` with arguments `:args:(:kwarg:key, :kwarg:value, :kwarg:namespace)`
        _2359.__setitem__(key=None, value=None, namespace=None)
        # Assert that `:ref:None` is `:ref:None`
        assert None is None

    # Test `:static:` method `:method:__setitem__

# Generated at 2022-06-24 03:15:39.309715
# Unit test for function set_tree_node
def test_set_tree_node():
    from collections import defaultdict
    from copy import deepcopy
    from pprint import pformat

    mapping = defaultdict(dict)

    fixture = {
        'foo': {
            'bar': {
                'baz': 'moo',
                'bam': 'bam',
            }
        }
    }

    fixture_copy = deepcopy(fixture)
    fixture_copy['foo']['bar']['boo'] = 'moo'

    assert set_tree_node(mapping, 'foo:bar:boo', 'moo') == fixture_copy['foo']['bar']
    assert mapping == fixture_copy

    assert set_tree_node(mapping, 'foo:bar:boo', 'moo') == fixture_copy['foo']['bar']
    assert mapping == fixture_copy


# Generated at 2022-06-24 03:15:41.955687
# Unit test for constructor of class Tree
def test_Tree():
    tree = Tree({'foo': 'bar'}, namespace='test')
    assert tree['foo'] == 'bar'
    assert tree['test', 'foo'] == 'bar'

# Generated at 2022-06-24 03:15:48.103271
# Unit test for function tree
def test_tree():
    tree = RegistryTree({
        'a': 1,
        'b': {
            'x': 3,
            'y': {
                'key': ['I', 'am', 'LEET'],
                'key2': ['I', 'am', 'so', 'LEET'],
            },
            'z': 5
        },
        'c': 7,
    })
    assert tree.get('a') is 1
    assert tree.get('b:x') is 3
    assert tree.get('b:y:key2') == ['I', 'am', 'so', 'LEET']
    assert tree.get('b:y:key') == ['I', 'am', 'LEET']
    assert tree.get('b:y:key2:2') == 'so'

# Generated at 2022-06-24 03:15:49.548634
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree = Tree()
    assert tree['hello'] == {}



# Generated at 2022-06-24 03:15:59.262234
# Unit test for function get_tree_node
def test_get_tree_node():
    d = {'foo': {'bar': {'baz': 'hi'}}}
    result = get_tree_node(d, 'foo:bar:baz')
    assert result == 'hi', 'Result was %s, not "hi"' % result
    result = get_tree_node(d, 'foo:missing:key', default='hi')
    assert result == 'hi', "Result was %s, not 'hi'" % result
    try:
        result = get_tree_node(d, 'foo:missing:key')
    except KeyError:
        assert True, 'get_tree_node raised KeyError'
    else:
        assert False, 'get_tree_node did not raise KeyError'
    result = get_tree_node(d, 'foo')

# Generated at 2022-06-24 03:16:02.617243
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = tree()
    set_tree_node(mapping, 'x:y:z', 'a')
    assert mapping['x']['y']['z'] == 'a'



# Generated at 2022-06-24 03:16:04.990343
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    tree = RegistryTree()
    tree.register('foo', 'bar')
    assert tree['foo'] == 'bar'



# Generated at 2022-06-24 03:16:13.794203
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()

    # Setting arbitrary keys should work
    t['baz:quux'] = 'bar'
    assert t['baz:quux'] == 'bar'

    # Setting a key that references a subkey should work
    t['foo'] = 'bar'
    assert t['foo'] == 'bar'

    # Setting a key that references a subkey should work
    t['foo:bar:baz'] = 'quux'
    assert t['foo:bar:baz'] == 'quux'

    # Setting a key that references a subkey that references a subkey should work
    t['foo:bar'] = 'baz'
    assert t['foo:bar'] == 'baz'

    # Setting a key that references a subkey that references a subkey should work
    t['foo:bar'] = 'baz'


# Generated at 2022-06-24 03:16:19.257667
# Unit test for constructor of class Tree
def test_Tree():
    """
    Demonstration of tree-like mapping interface on class Tree.
    """
    # Confirm that tree works as a callable
    assert isinstance(tree(), collections.Mapping)
    assert isinstance(tree(), dict)

    # Confirm that tree works as a class
    t = Tree()
    assert isinstance(t, collections.Mapping)
    assert isinstance(t, dict)

    t2 = Tree(t, initial_is_ref=True)
    t['a'] = 'alpha'
    assert t2['a'] == 'alpha'

    # Confirm that we can update
    t.update({'a': 'alpha', 'b': 'beta'})
    assert t['a'] == 'alpha'
    assert t['b'] == 'beta'
    assert t['c'] == {}

    # Confirm that we

# Generated at 2022-06-24 03:16:21.700941
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    registry = RegistryTree()
    registry.register('a', 10)
    registry.register('a:b', 20)

    assert registry['a'] == 10
    assert registry['a:b'] == 20



# Generated at 2022-06-24 03:16:23.288893
# Unit test for function tree
def test_tree():
    t = tree()
    t[1][2][3][4] = 5



# Generated at 2022-06-24 03:16:25.729518
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    from . import Tree
    from . import RegistryTree

    tree = Tree()
    tree.register('test', 1)
    assert tree.get('test') == 1



# Generated at 2022-06-24 03:16:37.281928
# Unit test for function get_tree_node

# Generated at 2022-06-24 03:16:40.597780
# Unit test for function set_tree_node
def test_set_tree_node():
    registry_tree = Tree()
    registry_tree.set('a:b:c:d:e', 'foo')
    assert registry_tree.get('a:b:c:d:e') == 'foo'



# Generated at 2022-06-24 03:16:41.329608
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    assert Tree()['test:test'] == {}



# Generated at 2022-06-24 03:16:50.771635
# Unit test for constructor of class Tree
def test_Tree():
    import unittest
    class TreeTestCase(unittest.TestCase):
        def test_initial(self):
            expected = {'a': {'b': 5}}
            tree = Tree(initial=expected)
            self.assertEqual(tree, expected)

        def test_initial_ref(self):
            initial = {'a': {'b': 5}}
            tree = Tree(initial=initial, initial_is_ref=True)
            tree['a']['b'] = 6
            self.assertEqual(initial, {'a': {'b': 6}})
            self.assertEqual(tree, {'a': {'b': 6}})

        def test_namespace(self):
            tree = Tree(namespace='ns1')
            tree['a']['b'] = 5

# Generated at 2022-06-24 03:16:53.552262
# Unit test for function tree
def test_tree():

    test_tree = tree()
    test_tree['a']['b'] = 'c'
    test_tree['a']['d'] = 'e'
    assert test_tree['a']['b'] == 'c'
    assert test_tree['a']['d'] == 'e'



# Generated at 2022-06-24 03:16:54.789981
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    rt = RegistryTree()
    rt.register('a:b:c', 5)
    rt.register(5)



# Generated at 2022-06-24 03:16:59.960941
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    from pprint import pprint
    tree = Tree()
    tree['foo:bar:baz'] = 'x'
    pprint(dict(tree))
    assert tree['foo:bar:baz'] == 'x'



# Generated at 2022-06-24 03:17:03.155704
# Unit test for constructor of class Tree
def test_Tree():
    tree = Tree({
        'foo': {
            'bar': 'baz'
        }
    })

    assert tree['foo:bar'] == 'baz'
    tree['foo:bar'] = 'baz2'
    assert tree['foo:bar'] == 'baz2'



# Generated at 2022-06-24 03:17:11.451405
# Unit test for function tree
def test_tree():
    import random

    for i in range(100):
        t = tree()
        for x in range(random.randint(10, 100)):
            key = ":".join("%s" % random.randint(0, 300) for x in range(random.randint(1, 5)))
            t[key] = random.randint(0, 300)

        for x in range(random.randint(10, 50)):
            key = ":".join("%s" % random.randint(0, 300) for x in range(random.randint(1, 5)))
            value = random.randint(0, 300)

            retrieved = get_tree_node(t, key)
            set_tree_node(t, key, value)
            new_retrieved = get_tree_node(t, key)



# Generated at 2022-06-24 03:17:18.022954
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = Tree({
        'a': {
            'b': {
                'c': 'd'
            }
        }
    })

    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:b:d', default='e') == 'e'



# Generated at 2022-06-24 03:17:22.263624
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    data = {'a': {'b': {'c': {'d': {'e': 'f'}}}}}
    tree = Tree(data)
    assert tree['a:b:c:d:e'] == 'f'
    assert tree['a:b:c:d:e', 'x'] == 'f'
    assert tree['A:B:C:D:E'] == {}
    assert tree['A:B:C:D:E', 'x'] == 'x'



# Generated at 2022-06-24 03:17:29.583330
# Unit test for function set_tree_node
def test_set_tree_node():
    from pprint import pprint
    from random import randint
    from json import dumps, loads
    from .common import flatten

    # Set up some random data
    depth = randint(2, 5)
    width = randint(2, 5)

    data = [dumps(tree()) for __ in range(depth)]
    data_str = ':'.join(data)
    data = loads(data_str)

    # Throw in some data
    for __ in range(width):
        key = ':'.join(data_str.split(':')[:randint(1, depth)])
        value = randint(1, 99)
        data = set_tree_node(data, key, value)

    # Test the results

# Generated at 2022-06-24 03:17:33.854205
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}
    set_tree_node(tree, 'root:sibling1:sibling2', 'value')
    assert tree == {'root': {'sibling1': {'sibling2': 'value'}}}



# Generated at 2022-06-24 03:17:35.612258
# Unit test for constructor of class Tree
def test_Tree():
    a = Tree()
    a['x']['y'] = 1
    assert a['x:y'] == 1

# Generated at 2022-06-24 03:17:41.481194
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    t = RegistryTree(initial={'foo': 'bar'}, namespace='bob')  # this setting of namespace is key
    assert t['foo'] == 'bar'
    assert 'foo' not in t  # Namespace is key

    # But we can remove the namespace
    assert t['bob:foo'] == 'bar'
    assert 'bob:foo' in t

    # Now we can remove it
    del t['bob:foo']
    assert 'foo' not in t
    assert 'bob:foo' not in t

    # Set it again, using the alias
    t.register('bob:foo', 'bar')
    assert 'foo' not in T
    assert t['bob:foo'] == 'bar'

    # And finally, reset the namespace
    t.namespace = 'bob'

# Generated at 2022-06-24 03:17:50.530955
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    def test_rp(rp):
        assert 'first:person' in rp
        assert 'second:person' in rp
        assert 'first' in rp
        assert 'second' in rp
        assert 'third' in rp

    # Testing if setting an item to a dict-like object works
    rp = RegistryTree()
    rp.register('person', {'name': 'John', 'age': 26}, namespace='first')
    rp.register('person', {'name': 'Jane', 'age': 24}, namespace='second')
    rp.register('person', {'name': 'Barry', 'age': 84}, namespace='third')
    test_rp(rp)

    # Testing if setting an item to a RegistryTree works
    rp = RegistryTree()

# Generated at 2022-06-24 03:17:55.884115
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():

    # Testing method __setitem__ of class Tree
    # Declare variables
    
    t = Tree()
    
    # Tested function
    t['foo'] = 'bar'
    
    # Checkpoint
    assert t['foo'] == 'bar'
test_Tree___setitem__()



# Generated at 2022-06-24 03:18:01.971529
# Unit test for function tree
def test_tree():
    u = tree()
    u['a']['b']['c']['d'] = 1
    u['a']['c'] = 3

    assert u['a']['b']['c']['d'] == 1
    assert u['a']['c'] == 3
    assert u['d']['e']['f']
    assert u['a']['b']['c']['g']
    assert not u['a']['b']['c']['d'] == 2



# Generated at 2022-06-24 03:18:11.026449
# Unit test for constructor of class RegistryTree
def test_RegistryTree():

    registry = RegistryTree()

    registry.register('asdf', 'fdsa')
    registry.register('asdf:qwer', 'qwer')
    registry.register('asdf:qwer', 'zxcv')
    registry.register('asdf:qwer:tyui', 'yuio')
    registry.register('asdf:qwer:tyui', 'rtyu', namespace='ghjk')
    registry.register('asdf:qwer:tyui', 'iop[')
    registry.register('asdf:qwer:tyui:asdf', 'asdf', namespace='ghjk')

    assert registry['asdf:qwer'] == 'zxcv'
    assert registry['asdf:qwer:tyui'] == 'iop['

# Generated at 2022-06-24 03:18:14.902881
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree(tree)
    assert isinstance(t, Tree)
    assert isinstance(t, collections.defaultdict)
    assert t is not tree



# Generated at 2022-06-24 03:18:20.888055
# Unit test for function set_tree_node
def test_set_tree_node():
    assert set_tree_node(tree(), 'key', 'value') == {'key': 'value'}
    assert set_tree_node(tree(), 'a:b:c', 'value') == {'a': {'b': {'c': 'value'}}}
    assert set_tree_node(tree(), 'a:b:c:d', 'value') == {'a': {'b': {'c': {'d': 'value'}}}}



# Generated at 2022-06-24 03:18:25.407511
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    values = {
        'foo': {
            'bar': 'baz'
        }
    }

    t = Tree(values)

    assert t['foo:bar'] == 'baz'

# Generated at 2022-06-24 03:18:35.659228
# Unit test for constructor of class Tree
def test_Tree():
    import unittest
    import json
    import os.path

    class TestConfigCase(unittest.TestCase):
        sample_config = '{'\
                        '"database": {'\
                        '    "dbname": "appdb",' \
                        '    "host": "db.example.com",' \
                        '    "port": "5432"'\
                        '},'\
                        '"application": {'\
                        '    "log": "/var/log/appname.log"'\
                        '}'\
                        '}'

        def setUp(self):
            self.config = Tree(json.loads(self.sample_config))

        def test_json_load(self):
            self.assertTrue(isinstance(self.config, collections.Mapping))


# Generated at 2022-06-24 03:18:43.048492
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    r = RegistryTree()

    # Test 1: Setting and getting an item
    r.register('foo', 'bar')
    assert r.get('foo') == 'bar'

    # Test 2: Setting and getting an item in another namespace
    r.register('foo', 'bar2', namespace='bar')
    assert r.get('foo', namespace='bar') == 'bar2'
    assert r.get('bar:foo') == 'bar2'

    # Test 3: Updating an item
    r.register('foo', 'bar3', namespace='baz')
    assert r.get('foo', namespace='baz') == 'bar3'
    r.register('foo', 'baz')
    assert r['foo'] == 'baz'

# Generated at 2022-06-24 03:18:53.620256
# Unit test for function get_tree_node
def test_get_tree_node():
    at_root = {
        'a': 'root_a',
        'b': 'root_b',
        'c': {
            'd': 'level1_d',
            'e': 'level1_e',
            'f': 'level1_f',
            'g': {
                'h': 'level2_h',
                'i': 'level2_i',
                'j': {
                    'k': 'level3_k',
                    'l': 'level3_l',
                    'm': {
                        'n': 'level4_n',
                        'o': 'level4_o'
                    }
                }
            }
        }
    }
    # Get single node by key
    assert get_tree_node(at_root, 'a') == 'root_a'
    # Get node

# Generated at 2022-06-24 03:18:58.588207
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree()
    assert t['a:b:c'] == {}
    t['a:b:c'] = 5
    assert t['a:b:c'] == 5
    assert t.get('a:b:c') == 5
    assert t['a:b:c'] is t.get('a:b:c')
    assert 'a:b:c' in t



# Generated at 2022-06-24 03:19:01.662288
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = {'a': {'b': {'c': 4}}}
    set_tree_node(mapping, 'a:b:d')
    assert mapping == {'a': {'b': {'c': 4, 'd': None}}}



# Generated at 2022-06-24 03:19:07.508594
# Unit test for function set_tree_node
def test_set_tree_node():
    node = tree()
    # set_tree_node()
    assert set_tree_node(node, 'foo:bar:baz', 123) == node['foo']['bar']
    assert node['foo']['bar']['baz'] == 123



# Generated at 2022-06-24 03:19:10.979808
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    instance = RegistryTree()



# Generated at 2022-06-24 03:19:17.943694
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree = Tree()

    assert tree.get('foo:bar') is None
    assert tree.set('foo:bar', 'baz') == tree['foo']
    assert tree.get('foo:bar') == 'baz'

    tree.set('foo:bar:baz', 'baz')
    assert tree.get('foo:bar:baz') == 'baz'
    assert tree.get('foo:bar:baz:baz', 'baz') == 'baz'



# Generated at 2022-06-24 03:19:26.214110
# Unit test for function tree
def test_tree():
    t = tree()
    t['foo:bar']['baz'] = 1
    t['foo:bar']['boo'] = 2
    t['foo:bar']['quz'] = 3
    assert t == {'foo': {'bar': {'baz': 1, 'boo': 2, 'quz': 3}}}
    t['foo:bar']['quz'] = 4
    assert t == {'foo': {'bar': {'baz': 1, 'boo': 2, 'quz': 4}}}
    assert t['foo'] == {'bar': {'baz': 1, 'boo': 2, 'quz': 4}}
    assert t['foo:bar'] == {'baz': 1, 'boo': 2, 'quz': 4}

# Generated at 2022-06-24 03:19:33.247283
# Unit test for function get_tree_node
def test_get_tree_node():
    treedict = {
        'mysite': {
            'static': {
                'js': {
                    'plugins': ['plugin']
                }
            }
        }
    }
    # Gets the plugins tree
    assert get_tree_node(treedict, 'mysite:static:js:plugins') == ['plugin']
    assert get_tree_node(treedict, 'mysite:static:js:plugins', parent=True) == {'plugins': ['plugin']}
    with pytest.raises(KeyError):
        get_tree_node(treedict, 'mysite:static:js:no_plugins')



# Generated at 2022-06-24 03:19:34.313035
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    pass



# Generated at 2022-06-24 03:19:41.336836
# Unit test for constructor of class Tree
def test_Tree():
    """
    >>> tree = Tree({'key1': 'val1', 'key2': 'val2', 'key3': {'key4': 'val4'}})
    >>> tree.get('key1')
    'val1'
    >>> tree.get('key3:key4')
    'val4'
    >>> tree['key3:key5'] = 'val5'
    >>> tree.get('key3:key5')
    'val5'
    """
    pass  # Prevent doctest from complain

# Generated at 2022-06-24 03:19:49.907193
# Unit test for function tree
def test_tree():
    t = tree()
    assert t['test'] == {}
    t['test']['foo'] = 'bar'
    assert t['test']['foo'] == 'bar'
    assert t['test'] == {'foo': 'bar'}
    assert t['test']['bar'] == {}
    t['test']['bar']['foo'] = 1
    assert t['test']['bar']['foo'] == 1
    assert t['test'] == {'foo': 'bar', 'bar': {'foo': 1}}
    assert t['foo'] == {}



# Generated at 2022-06-24 03:19:57.680965
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    assert get_tree_node(set_tree_node({}, 'a', 1), 'a') == 1
    assert get_tree_node(set_tree_node({}, 'a:b:c', 1), 'a:b:c') == 1
    assert get_tree_node(set_tree_node({}, 'a:b:c', 1), 'a:b:c:d', parent=True) == {'c': 1}



# Generated at 2022-06-24 03:20:07.723659
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({}, 'foo') == _sentinel
    assert get_tree_node({'foo': 'bar'}, 'foo') == 'bar'
    assert get_tree_node({'foo': {'bar': 'baz'}}, 'foo:bar') == 'baz'
    assert get_tree_node({'foo': {'bar': {'baz': 'gazonks'}}}, 'foo:bar:baz') == 'gazonks'
    assert get_tree_node({'foo': {'bar': {'baz': 'gazonks'}}}, 'foo:bar') == {'baz': 'gazonks'}

# Generated at 2022-06-24 03:20:12.638161
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    registry = RegistryTree()
    registry.register('A', value='a')
    registry.register('B:C', value='b')
    registry.register('B:D:E', value='c')
    registry.register('B:D:F', value='d')

    assert registry['A'] == 'a'
    assert registry['B:C'] == 'b'
    assert registry['B:D:E'] == 'c'
    assert registry['B:D:F'] == 'd'



# Generated at 2022-06-24 03:20:21.037629
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = tree()
    t['a']['b']['c'] = 1
    eq_(t['a']['b']['c'], 1)

    # Check for update()
    t['a']['b']['c'] = 2
    eq_(t['a']['b']['c'], 2)

    # Check for namespace use
    t.namespace = 'test'
    t['a']['b'] = 1
    eq_(t['test:a']['test:b'], 1)

    # Test dict-like notation
    t['a:b:c'] = 2
    eq_(t['test:a:b:c'], 2)

    # Test recursive use
    t['a:b']['c:d'] = 3

# Generated at 2022-06-24 03:20:25.537685
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()
    tree['a'] = 1
    assert tree['a'] == 1

    tree['b:c'] = 2
    assert tree['b']['c'] == 2

    tree.register('d:e', 4)
    assert tree['d:e'] == 4



# Generated at 2022-06-24 03:20:31.435237
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()

    t['foo'] = 'bar'

    assert t['foo'] == 'bar'

    t['foo:bar'] = 'baz'

    assert t['foo:bar'] == 'baz'

    t['foo:bar:baz'] = 'quux'

    assert t['foo:bar:baz'] == 'quux'

    assert t['foo'] == {'bar': {'baz': 'quux'}}

# Generated at 2022-06-24 03:20:34.709688
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    tree = RegistryTree(initial=tree())
    tree.register('plugin', tree())


if __name__ == '__main__':
    test_RegistryTree()

# Generated at 2022-06-24 03:20:36.532720
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    tree = RegistryTree()
    assert tree.__class__ is RegistryTree

if __name__ == '__main__':
    test_RegistryTree()

# Generated at 2022-06-24 03:20:42.379707
# Unit test for function tree
def test_tree():
    """Unit test for function tree"""
    t = tree()
    t['a'] = 5
    t['b'] = 6

# Generated at 2022-06-24 03:20:44.207841
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree(initial={'foo': 'bar'})
    assert t['foo'] == 'bar'



# Generated at 2022-06-24 03:20:53.785799
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    from pprint import pprint
    t = Tree()

    # Test normal setting
    t['foo:bar:bat:baz'] = 1

    # Test setting namespaced key
    t['ding:dang:dong'] = 2

    # Test setting as normal key
    t['foo'] = 3

    # Test setting as parent node
    t['foo'] = 4

    # Test setting with namespace
    t['dong', 'foo'] = 5

    #print (t)
    print ("\n")
    print ("printing t")
    pprint(t)
    print ("\n")
    # Test getting normal key
    assert t['foo:bar:bat:baz'] == 1

    # Test getting normal key2
    assert t['foo'] == 4

    # Test getting parent node

# Generated at 2022-06-24 03:20:56.059991
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    regr = RegistryTree()
    regr.register('a', 'apple')
    assert regr['a'] == "apple"



# Generated at 2022-06-24 03:21:01.325621
# Unit test for function tree
def test_tree():
    t = tree()
    t['a']['b']['c'] = {'d': 'e'}
    assert get_tree_node(t, 'a:b:c') is not None
    assert get_tree_node(t, 'a:b:c:d') is None
    assert get_tree_node(t, 'a:b:c') == {'d': 'e'}



# Generated at 2022-06-24 03:21:02.586158
# Unit test for constructor of class Tree
def test_Tree():
    """Test constructor of class `Tree`."""
    t = Tree()
    assert isinstance(t, Tree)
    assert len(t.data) == 0



# Generated at 2022-06-24 03:21:11.696220
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree(initial='foo')
    assert t == {None: 'foo'}

    t = Tree(initial_is_ref=True)
    assert t is initial_is_ref

    # Test namespace
    initial = {'foo': 'baz'}
    t = Tree(initial=initial, namespace='bar')
    assert t == {'bar': {'foo': 'baz'}}
    assert t['foo'] == 'baz'
    assert t.get('foo.bar') is None  # Check if non-existing key returns `None`

    # Test `setitem`
    t['foo.bar'] = 'baz'
    assert t['foo.bar'] == 'baz'

# Generated at 2022-06-24 03:21:16.964134
# Unit test for function get_tree_node
def test_get_tree_node():
    # m = {'a': {'b': {'c': 'd'}}}
    m = tree()
    m['a']['b']['c'] = 'd'
    assert m['a']['b']['c'] == 'd'
    assert get_tree_node(m, 'a:b:c') == 'd'



# Generated at 2022-06-24 03:21:26.852826
# Unit test for function set_tree_node
def test_set_tree_node():

    @pytest.fixture
    def assert_tree():
        def assert_tree(tree, assert_dict):
            for key, value in assert_dict.items():
                if isinstance(value, dict):
                    assert_tree(tree[key], value)
                else:
                    assert tree[key] == value
        return assert_tree

    def test_set_tree_node(assert_tree):
        mapping = tree()

        set_tree_node(mapping, 'a:b:c', 'd')
        assert_tree(mapping, {'a': {'b': {'c': 'd'}}})

    def test_set_tree_node_bad_key(assert_tree):
        mapping = tree()


# Generated at 2022-06-24 03:21:34.503827
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test get_tree_node function.
    """
    t = {
        'b': {
            'c': {
                'd': 'D'
            }
        }
    }

    assert get_tree_node(t, 'b:c:d') == 'D'
    assert get_tree_node(t, 'b:c') == {'d': 'D'}
    assert get_tree_node(t, 'b') == {'c': {'d': 'D'}}



# Generated at 2022-06-24 03:21:36.678624
# Unit test for constructor of class Tree
def test_Tree():
    tree = Tree({'a': 1})
    tree['b'] = 2
    assert tree['a'] == 1
    assert tree['b'] == 2

# Generated at 2022-06-24 03:21:40.665551
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree = Tree()
    tree.register('A', {'B': {'C': 'D'}})
    assert tree['A:B:C'] == 'D'
    assert tree.get('A:B:C') == 'D'



# Generated at 2022-06-24 03:21:46.541444
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    registry = RegistryTree()
    assert registry['a']['b'] == {}
    registry['a']['b']['c'] = 3
    assert registry['a']['b']['c'] == 3
    registry['a']['b']['d'] = None
    assert registry['a']['b']['d'] is None

    # Test tree derivation
    assert isinstance(registry['a']['b'], Tree)



# Generated at 2022-06-24 03:21:52.594627
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}
    set_tree_node(tree, 'client:192.168.0.1:ifaces:1:name', 'eth0')
    assert tree['client']['192.168.0.1']['ifaces']['1']['name'] == 'eth0'
    set_tree_node(tree, 'client:192.168.0.1:ifaces:1:name', 'eth1')
    assert tree['client']['192.168.0.1']['ifaces']['1']['name'] == 'eth1'



# Generated at 2022-06-24 03:21:56.109045
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = {}
    set_tree_node(mapping, 'foo:bar:baz', 'qux')
    assert mapping['foo']['bar']['baz'] == 'qux'



# Generated at 2022-06-24 03:22:02.437467
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    """
    >>> r = RegistryTree()
    >>> r.register('a', 1)
    >>> r.register('b', 2)
    >>> r.register('b.subb', 3)
    >>> print r['b.subb']
    3
    >>> r.register('c', {'key': 'value'})
    >>> print r['c.key']
    value
    """

    pass


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 03:22:04.441448
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree({'a': {'b': 'c'}})
    assert t['a']['b'] == 'c'



# Generated at 2022-06-24 03:22:12.558467
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    from inspect import isclass
    from .exceptions import NotFoundError
    from .exceptions import FoundMultipleError
    from . import factories
    reg = RegistryTree()
    assert reg.namespace is None
    assert isinstance(reg, collections.defaultdict)
    assert isclass(reg.default_factory)
    assert reg.default_factory is RegistryTree
    assert len(reg) == 0
    reg.register('test_one', factories.TestFactory)
    reg.register('test_two', factories.TestFactory)
    assert len(reg) == 2
    assert reg['test_one'] is not None
    assert reg['test_two'] is not None
    assert isinstance(reg['test_one'], factories.TestFactory)
    assert isinstance(reg['test_two'], factories.TestFactory)

# Generated at 2022-06-24 03:22:19.292526
# Unit test for function set_tree_node
def test_set_tree_node():
    t = tree()
    set_tree_node(t, 'one', 2)
    set_tree_node(t, 'one:two', 3)
    assert t['one']['two'] == 3
    set_tree_node(t, 'one:two', 4)
    assert t['one']['two'] == 4


if __name__ == '__main__':
    test_set_tree_node()

# Generated at 2022-06-24 03:22:30.526012
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    data = {
        'people': {
            'fred': {
                'user_id': 12,
                'name': 'Fred',
            },
        },
    }
    t = Tree(data)
    assert t['people:fred:user_id'] == 12
    assert 'asdf' in t.data
    assert not t.get('asdf')
    assert t.get('asdf', 123) == 123

    # Verify that specifying a namespace works.
    t = Tree(initial=None, namespace='foo')
    assert t['bar'] == {}
    assert t.data['foo:bar'] is t['bar']

    # Set a value.
    t['bar:baz'] = 'schmo'
    assert t['bar:baz'] == 'schmo'

# Generated at 2022-06-24 03:22:32.339981
# Unit test for constructor of class Tree
def test_Tree():
    d = Tree()
    d['a']['b'] = 1
    assert d['a']['b'] == 1



# Generated at 2022-06-24 03:22:40.652093
# Unit test for function tree
def test_tree():
    # Verify getter
    assert get_tree_node(tree(), 'a:b:c:d:e') == tree
    assert get_tree_node(tree(), 'a:b:c:d:e', default=None) is None
    assert get_tree_node(Tree(initial={'a': 1}), 'a') == 1

    # Verify setter
    t = tree()
    set_tree_node(t, 'a:b:c:d:e', 100)
    assert t['a']['b']['c']['d']['e'] == 100



# Generated at 2022-06-24 03:22:47.574334
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    t['aaa'] = {'bbb': 'ccc'}
    assert t.get('aaa:bbb') == 'ccc'
    t['aaa:bbb'] = 'ddd'
    assert t.get('aaa') == {'bbb': 'ddd'}
    t['aaa:ccc'] = 'eee'
    assert t.get('aaa') == {'bbb': 'ddd', 'ccc': 'eee'}


if __name__ == '__main__':
    import nose
    nose.main()

# Generated at 2022-06-24 03:22:51.446007
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    d = RegistryTree()
    d.register('foo:bar:baz', '10')
    assert d.get('foo:bar:baz') == '10'



# Generated at 2022-06-24 03:22:57.995088
# Unit test for constructor of class Tree
def test_Tree():
    class TestTree(Tree):
        namespace = 'test'
    t = TestTree()
    t['foo'] = 'Foo'
    t['bar'] = 'Bar'
    assert t['foo'] == 'Foo'
    assert t['bar'] == 'Bar'
    assert t['test:foo'] == 'Foo'
    assert t['test:bar'] == 'Bar'


if __name__ == '__main__':
    import nose
    nose.run_exit(argv=['nosetests', __file__])

# Generated at 2022-06-24 03:23:00.469840
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    t['a'] = 'x'
    t['a:b'] = 'y'
    assert t == {
        'a': {
            'b': 'y'
        }
    }



# Generated at 2022-06-24 03:23:06.194006
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = {}
    key = 'foo:bar:baz'
    value = 'test_value'
    result = set_tree_node(mapping, key, value)
    assert result == {'bar': {'baz': 'test_value'}}



# Generated at 2022-06-24 03:23:07.571130
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    rt = RegistryTree()
    rt.register('foo', 'bar')



# Generated at 2022-06-24 03:23:10.874327
# Unit test for function tree
def test_tree():
    mapping = tree()
    mapping['smeb']['smeb'] = 'smeb'
    mapping['smeb']['smeb']['smeb'] = 'smeb'
    assert mapping['smeb']['smeb']['smeb'] == 'smeb'

# Generated at 2022-06-24 03:23:17.589118
# Unit test for function tree
def test_tree():
    import unittest

    class TreeTest(unittest.TestCase):
        def setUp(self):
            self.tree = tree()
            self.tree[1][2][3] = 'foo'
            self.tree[1][2][4] = 'bar'

        def test_str_dels(self):
            self.assertEqual(get_tree_node(self.tree, '1:2:4'), 'bar')

        def test_list_dels(self):
            self.assertEqual(get_tree_node(self.tree, [1, 2, 4]), 'bar')

    unittest.main()


# Generated at 2022-06-24 03:23:20.138732
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    from nose.tools import ok_
    tree = RegistryTree()
    ok_(tree['foo'].data)

# Generated at 2022-06-24 03:23:29.407294
# Unit test for function set_tree_node
def test_set_tree_node():
    """Unit test for function set_tree_node"""
    test_data = {}
    assert not set_tree_node(test_data, 'a:b:c', 1)
    assert len(test_data) == 1
    assert test_data['a']['b']['c'] == 1

    assert not set_tree_node(test_data, 'a:b', 2)
    assert len(test_data) == 1
    assert test_data['a']['b'] == 2

    assert not set_tree_node(test_data, 'a:b:c', 3)
    assert len(test_data) == 1
    assert test_data['a']['b']['c'] == 3



# Generated at 2022-06-24 03:23:34.468751
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    # Define a custom tree class
    class MyTree(RegistryTree):
        pass

    # Instantiate a new RegistryTree
    m = MyTree()
    # Register a new key
    m.register('foo.bar', 'baz')
    # Test that key has been correctly set
    assert m['foo.bar'] == 'baz'



# Generated at 2022-06-24 03:23:42.687515
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()
    tree.update({
        'world': {
            'hello': 1,
            'world': {
                'hello': 2,
                'world': {
                    'hello': 3,
                    'world': {
                        'hello': 4,
                        'world': {
                            'hello': 5,
                        }
                    }
                }
            }
        }
    })

    assert tree['world:hello'] == 1
    assert tree['world:world:hello'] == 2
    assert tree['world:world:world:hello'] == 3
    assert tree['world:world:world:world:hello'] == 4
    assert tree['world:world:world:world:world:hello'] == 5



# Generated at 2022-06-24 03:23:47.845600
# Unit test for function set_tree_node
def test_set_tree_node():
    d = {'a': {'b': {'c': 0}}}
    set_tree_node(d, 'ee:ff:gg', 'end')
    assert d['ee']['ff']['gg'] == 'end'
    assert d['ee']['ff'] != {'gg': 'end'}



# Generated at 2022-06-24 03:23:52.817223
# Unit test for function tree
def test_tree():
    t = tree()
    t['a']['b']['c'] = 'r'
    assert t['a']['b']['c'] == 'r', "Unable to write"
    assert t['a:b:c'] == 'r', "Unable to read"
    try:
        t['a:b:d']
        assert False, "Should have raised a KeyError"
    except KeyError:
        pass



# Generated at 2022-06-24 03:23:58.415594
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'some': 'dict',
        'foo': {
            'bar': {
                'baz': {
                    'spam': 'eggs'
                }
            }
        }
    }
    node = get_tree_node(mapping, 'foo:bar:baz:spam')
    assert node == 'eggs'
    node = get_tree_node(mapping, 'spam')
    assert node == _sentinel



# Generated at 2022-06-24 03:24:00.528827
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    class Foo(object):
        pass

    tree = RegistryTree(namespace='foo')
    tree.register('bar', Foo)
    assert tree[':bar'] is Foo

# Generated at 2022-06-24 03:24:06.528049
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = collections.defaultdict(dict)

    set_tree_node(mapping, 'foo', 'bar')
    set_tree_node(mapping, 'foo:bar', 'baz')
    set_tree_node(mapping, 'foo:bar:baz', 'quux')

    assert mapping == {
        'foo': {
            'bar': {
                'baz': 'quux'
            }
        }
    }


if __name__ == '__main__':
    test_set_tree_node()

# Generated at 2022-06-24 03:24:10.137168
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = tree()
    set_tree_node(tree, 'a:b:c:d.e', 'f')
    assert tree['a']['b']['c']['d.e'] == 'f'

