

# Generated at 2022-06-24 03:14:21.793917
# Unit test for function get_tree_node
def test_get_tree_node():
    test_tree = {
        'test': {
            'test2': 'test2',
        },
        'test3': 'test3',
    }

    assert get_tree_node(test_tree, 'test:test2') == 'test2'
    assert get_tree_node(test_tree, 'test3') == 'test3'
    assert get_tree_node(test_tree, 'test4', default='test4') == 'test4'
    assert get_tree_node(test_tree, 'test4:test5', default='test4') == 'test4'
    assert get_tree_node(test_tree, 'test:test2:test6', default='test4') == 'test4'


# Generated at 2022-06-24 03:14:31.289547
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    """
    Unit test for method __setitem__ of class Tree
    """
    t = Tree()
    t['a']['b']['c'] = 'value'
    assert t['a']['b']['c'] == 'value'

    # Test overriding value
    t['a']['b']['c'] = 'value2'
    assert t['a']['b']['c'] == 'value2'

    # Test setting parent node
    t['a']['b'] = 'value3'
    assert t['a']['b'] == 'value3'
    assert t['a']['b']['c'] is None



# Generated at 2022-06-24 03:14:39.117584
# Unit test for function set_tree_node
def test_set_tree_node():
    m = tree()
    set_tree_node(m, 'a:b:c', 'foo')
    set_tree_node(m, 'a:b:d', 'bar')

    assert m['a']['b']['c'] == 'foo'
    assert m['a']['b']['d'] == 'bar'



# Generated at 2022-06-24 03:14:43.571397
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    from hypothesis import given, assume, settings
    from hypothesis.strategies import composite, text, lists

    @composite
    def fq_key_strategy(draw):
        return ':'.join(draw(lists(text(), min_size=1)))

    @setting.set_setting(setting.Setting)
    @given(fq_key_strategy(), fq_key_strategy())
    def test_get(key, default):
        assert Tree([])[key] == default

    settings.load_profile('ci')
    test_get()



# Generated at 2022-06-24 03:14:52.319746
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        "a": {
            "b": {
                "c": "d",
                "e": "f",
            },
            "g": "h",
        },
        "i": [{
            "j": "k",
            "l": "m",
        }],
    }
    assert get_tree_node(mapping, 'a:b:c') == 'd'
    assert get_tree_node(mapping, 'a:g') == 'h'
    assert get_tree_node(mapping, 'i:0:j') == 'k'



# Generated at 2022-06-24 03:15:02.387065
# Unit test for function tree
def test_tree():
    for (initial, key, default), expect in [
            (({}, 'foo', 1), 1),
            (({}, 'foo', 1, False), 1),
            (({}, 'foo:bar', 1), 1),
            (({}, 'foo:bar', 1, False), 1),
            (({'foo': {'bar': 1}}, 'foo:bar', 3), 1),
            (({'foo': {'bar': 1}}, 'foo:bar', 3, False), {'bar': 1}),
            (({'foo': {'bar': 1}}, 'foo:bar:baz', 3), 3),
            (({'foo': {'bar': 1}}, 'foo:bar:baz', 3, False), {'bar': 1}),
            ]:
        result = get_tree_node(*initial)

# Generated at 2022-06-24 03:15:06.158733
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree = Tree(namespace='namespace')
    assert tree['foo:bar'] == tree['namespace:foo:bar']



# Generated at 2022-06-24 03:15:15.487218
# Unit test for function tree
def test_tree():
    tree = Tree()
    tree[':one']['two']['three'] = 4
    tree[':one']['two']['four'] = 5
    tree['one']['two']['five'] = 6
    assert tree[':one:two:three'] == 4
    assert tree[':one:two:four'] == 5
    assert tree['one:two:five'] == 6
    assert get_tree_node(tree, 'one:two:five') == 6

    # Test setting values deep inside
    tree[':one']['two']['seven'] = 7
    assert tree[':one:two:seven'] == 7

    # Test setting values near end
    tree['nine'] = 9
    assert tree['nine'] == 9

    # Test setting values at root
    tree[':eleven'] = 11


# Generated at 2022-06-24 03:15:18.871736
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree()
    t['a'] = 'b'
    t['c:d'] = 'e'
    assert t['c:d'] == 'e'
    assert t['a'] == 'b'



# Generated at 2022-06-24 03:15:24.386151
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    t['foo'] = 'bar'
    assert t['foo'] == 'bar'

    t['a:b:c'] = 'd'
    assert t['a']['b']['c'] == 'd'

    t['a:b:c:d'] = 'e'
    assert t['a']['b']['c']['d'] == 'e'


# Generated at 2022-06-24 03:15:27.239000
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    global a
    a = RegistryTree()
    a['test'] = 42

# Generated at 2022-06-24 03:15:29.266912
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()
    tree['foo'] = 'bar'
    assert tree['foo'] == 'bar'



# Generated at 2022-06-24 03:15:31.913590
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree()
    t[':app:1:a'] = 2
    assert t['app:1:a'] == 2
    try:
        t['app:2:a']
    except KeyError:
        pass
    else:
        assert False
    assert t.get('app:2:a', 'x') == 'x'
    assert t.get('app:1:a', 'x') == 2



# Generated at 2022-06-24 03:15:33.845378
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()
    tree.__setitem__({}, 'foo', 'bar')
    assert 'foo' in tree
    assert tree['foo'] == 'bar'



# Generated at 2022-06-24 03:15:41.289882
# Unit test for constructor of class Tree
def test_Tree():
    data = {
        'foo': {
            'bar': 'bar',
            'baz': {
                'buzz': 'buzz'
            }
        }
    }

    tree_ = Tree(data)

    assert tree_['foo:bar'] == 'bar'
    assert tree_['foo:baz:buzz'] == 'buzz'

    tree_ = Tree(tree_)

    assert tree_['foo:bar'] == 'bar'
    assert tree_['foo:baz:buzz'] == 'buzz'



# Generated at 2022-06-24 03:15:42.913470
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()
    tree['A:B:C'] = 'D'
    assert tree == {'A': {'B': 'C'}}
    return True



# Generated at 2022-06-24 03:15:53.593571
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    from os.path import abspath, join, dirname, exists

    TEST_ROOT = 'tests/fixtures'
    TEST_FILENAME = 'test_data.yml'

    test_fixtures = Tree()

    for path in [TEST_ROOT, TEST_FILENAME]:
        test_fixtures.register(path, abspath(join(dirname(__file__), path)))

    # Fetch
    assert test_fixtures['tests/fixtures/test_data.yaml']['key1'] == 'value1'
    assert test_fixtures['test_data.yaml']['key1'] == 'value1'
    assert test_fixtures['test_data.yaml'].get('key2') == None

    # Set

# Generated at 2022-06-24 03:15:57.323538
# Unit test for constructor of class Tree
def test_Tree():
    treetest = Tree(dict(a=1, b=dict(c=3, d=4)))
    assert treetest['a'] == 1
    assert treetest['b']['c'] == 3
    assert treetest['b']['d'] == 4


# Unit test tree()

# Generated at 2022-06-24 03:16:08.405437
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree()
    t['a'] = 'b'
    assert t['a'] == 'b'
    assert t.get('a') == 'b'
    t['fancy']['pants'] = 'trousers'
    assert t['fancy']['pants'] == 'trousers'
    assert t.get('fancy:pants') == 'trousers'
    assert t.get('fancy').get('pants') == 'trousers'
    assert t.get('fancy:pants') == t.get('fancy').get('pants')
    assert t.get('fancy:pants:not:a:key') is None
    assert t.get('fancy:pants:not:a:key', 'value') == 'value'

# Generated at 2022-06-24 03:16:12.924869
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    d = dict(a=dict(b=5), b=5)
    r = RegistryTree(d)
    assert r['a:b'] == 5
    assert r['b'] == 5
    assert r.get('c') is None
    assert r.get('c', 1) == 1
    try:
        r['c']
    except KeyError:
        pass
    else:
        raise AssertionError()

# Generated at 2022-06-24 03:16:19.955593
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    _t = Tree()
    _key = 'foo'
    _value = 'bar'
    _key_namespace = 'namespace'
    _namespace = 'namespace1'
    _key_namespace_namespace = 'namespace2'
    _namespace_namespace = 'namespace3'
    _t[(_key, _namespace)] = _value
    _t[((_key_namespace, _namespace_namespace), _namespace_namespace)] = _value
    assert(_t[_key] == _value)
    assert(_t[_key_namespace, _namespace_namespace] == _value)



# Generated at 2022-06-24 03:16:27.659634
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    from pprint import pprint

    t = Tree({'foo': {'bar': {'baz': {}}}})
    assert t['foo:bar'] == t['foo']['bar']
    assert t['foo'] == {'bar': {'baz': {}}}

    assert t['foo:bar:baz'] == {}
    assert t['foo:bar'] == {'baz': {}}

    assert t['bar'] == {}
    assert t['bar'] == t['bar']  # Bug fix

    assert t['not-there'] is None
    assert t['not-there'] == t['not-there']  # Bug fix

    # TODO: Test non-dict dunder methods.
    # print(t.items())
    # assert t.items() == [('foo', {'bar': {'baz': {

# Generated at 2022-06-24 03:16:33.036980
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = collections.defaultdict(lambda: collections.defaultdict(lambda: collections.defaultdict(dict)))
    assert set_tree_node(tree, 'foo:bar:baz:buzz', 'whiz') == {'buzz': 'whiz'}



# Generated at 2022-06-24 03:16:43.195385
# Unit test for function tree
def test_tree():
    t = tree()
    assert t['key_1']['key_2']['key_3'] == {}
    assert t['key_1']['key_2']['key_3']['key_4'] == {}
    assert t['key_1']['key_2']['key_3']['key_4'] is t['key_1']['key_2']['key_3']['key_4']
    assert t['key_1']['key_2']['key_3'] == {'key_4': {}}
    assert t['key_1']['key_2'] == {'key_3': {'key_4': {}}}

# Generated at 2022-06-24 03:16:51.003636
# Unit test for function tree
def test_tree():
    expected_tree = {
        'foo': {
            'bar': 'baz',
            'qux': 'quux',
        },
        'corge': 'grault',
    }

    # Mimic the behaviour of `set_tree_node`
    tree = {}
    set_tree_node(tree, 'foo:bar', 'baz')
    set_tree_node(tree, 'foo:qux', 'quux')
    set_tree_node(tree, 'corge', 'grault')

    assert tree == expected_tree
    assert tree['foo:bar'] == 'baz'
    assert tree['foo:qux'] == 'quux'
    assert tree['corge'] == 'grault'

    with pytest.raises(KeyError):
        tree['missing']


# Generated at 2022-06-24 03:16:54.089122
# Unit test for function set_tree_node
def test_set_tree_node():
    tree = {}
    node = 'almond.types.test'
    value = 'This is a test'
    set_tree_node(tree, node, value)
    assert tree['almond']['types']['test'] == value



# Generated at 2022-06-24 03:17:02.784130
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'foo': {
            'bar': {
                'baz': 'baz',
                'bah': {
                    'asdf': 'asdf',
                },
            },
        },
    }

    assert get_tree_node(tree, 'foo:bar') == {
        'baz': 'baz',
        'bah': {
            'asdf': 'asdf',
        },
    }

    assert get_tree_node(tree, 'foo:bar:baz') == 'baz'

    assert get_tree_node(tree, 'foo:bar:bah') == {'asdf': 'asdf'}

    assert get_tree_node(tree, 'foo:bar:bah:asdf') == 'asdf'


# Generated at 2022-06-24 03:17:12.129108
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    test_data = {'foo': 'bar', 'bar': {'baz': 'bam'}}
    my_tree = Tree(initial=test_data)

    assert my_tree['foo'] == 'bar'
    assert my_tree['bar:baz'] == 'bam'
    assert my_tree.get('bar:baz') == 'bam'
    assert my_tree.get('bar:baz:bam', 'wtf') == 'wtf'
    try:
        my_tree['bar:baz:bam']
        assert False, 'wtf'
    except KeyError:
        pass

    test_data = {'foo': 'bar', 'bar': {'baz': 'bam'}}
    my_tree = Tree(initial={}, initial_is_ref=test_data)
   

# Generated at 2022-06-24 03:17:22.087751
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': True
            }
        },
        'bar': {
            'foo': {
                'baz': True
            }
        }
    }

    assert get_tree_node(mapping, 'bar') == {'foo': {'baz': True}}
    assert get_tree_node(mapping, 'foo:bar:baz') is True
    assert get_tree_node(mapping, 'foo:baz', default='test') == 'test'
    assert get_tree_node(mapping, 'baz') is _sentinel
    assert get_tree_node(mapping, 'baz:foo:bar') is _sentinel

# Generated at 2022-06-24 03:17:24.488702
# Unit test for function set_tree_node
def test_set_tree_node():
    a = tree()
    set_tree_node(a, 'x:y:z', 'test')
    assert a['x']['y']['z'] == 'test'



# Generated at 2022-06-24 03:17:35.106585
# Unit test for function set_tree_node
def test_set_tree_node():
    original_tree = {'a': {'b': {'c': 'd'}}}
    tree = Tree(initial=original_tree, initial_is_ref=True)
    v = tree['a:b:c']
    assert v == 'd'

    # Test dict insert
    tree['f:g:h'] = 'i'
    assert tree['f:g:h'] == 'i'

    # Test dict change
    tree['f:g:h'] = 'j'
    assert tree['f:g:h'] == 'j'

    # Test dict change to list
    tree['f:g'] = ['h']
    assert len(tree['f:g']) == 1
    assert tree['f:g:0'] == 'h'

    # Test dict delete
    del tree['f']
    assert 'f'

# Generated at 2022-06-24 03:17:41.284438
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Unit tests for function set_tree_node
    """
    from nose.tools import assert_equal

    # Test 1
    data = {}
    set_tree_node(data, 'foo', 'bar')
    assert_equal(data, {'foo': 'bar'})

    # Test 2
    data = {}
    set_tree_node(data, 'foo:bar', 'foobar')
    assert_equal(data, {'foo': {'bar': 'foobar'}})

    # Test 3
    data = {}
    set_tree_node(data, 'foo:bar:foobar', 'fooblob')
    assert_equal(data, {'foo': {'bar': {'foobar': 'fooblob'}}})



# Generated at 2022-06-24 03:17:43.294658
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    """Test if Tree__setitem__ recursively create items as needed"""
    t = Tree()
    t['a'] = 1
    t['a'] = 2
    assert t['a'] == 2
    t['b:c'] = 3
    assert t['b:c'] == 3



# Generated at 2022-06-24 03:17:45.746842
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    tree = RegistryTree()
    tree.register(u'foo:bar', 'some value')
    assert tree.get(u'foo:bar') == 'some value'

# Generated at 2022-06-24 03:17:53.741878
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = Tree({
        'key': 'value',

        'one': {
            'two': {
                'three': 'four',
                'five': 'six',
            },
        },
    })
    assert get_tree_node(mapping, 'key') == 'value'
    assert get_tree_node(mapping, 'one') == {'two': {'three': 'four', 'five': 'six'}}
    assert get_tree_node(mapping, 'one:two') == {'three': 'four', 'five': 'six'}
    assert get_tree_node(mapping, 'one:two:three') == 'four'
    assert get_tree_node(mapping, 'one:two:four', default='not found') == 'not found'

# Generated at 2022-06-24 03:18:02.623200
# Unit test for constructor of class Tree
def test_Tree():
    # setup
    import json

    mock_data = {
        'a': {
            'b': 10,
            'c': {
                'd': 20,
                'e': {
                    'f': {
                        'bar': 'baz'
                    }
                }
            }
        }
    }

    # test
    t = Tree(mock_data)

    # assert
    assert json.dumps(t) == json.dumps({
        'a': {
            'b': 10,
            'c': {
                'd': 20,
                'e': {
                    'f': {
                        'bar': 'baz'
                    }
                }
            }
        }
    })



# Generated at 2022-06-24 03:18:11.158714
# Unit test for function get_tree_node
def test_get_tree_node():
    test_mapping = {
        'sub': {
            'subsub': 'value',
            'subsubsub': {
                'subsubsubsubsubsubsubsubsubsubsubsubsubsubsub': 'subsubsubsubsubsubsubsubsubsubsubsubsubsubsub'
            }
        }
    }
    assert get_tree_node(test_mapping, 'sub:subsub') == 'value'
    assert get_tree_node(test_mapping, 'sub:subsubsub:subsubsubsubsubsubsubsubsubsubsubsubsubsubsub') == \
        'subsubsubsubsubsubsubsubsubsubsubsubsubsubsub'

# Generated at 2022-06-24 03:18:16.887811
# Unit test for function get_tree_node
def test_get_tree_node():
    """Unit test for function `get_tree_node`"""
    tree_dict = {
        'one': {
            'two': {
                'three': 'value'
            }
        }
    }

    assert get_tree_node(tree_dict, 'one:two:three') == 'value'

# Generated at 2022-06-24 03:18:27.027417
# Unit test for function get_tree_node
def test_get_tree_node():
    # Get "leaf node"
    tree = {
        'root': {
            'level1': {
                'level2': 'leaf node'
            }
        }
    }
    assert get_tree_node(tree, 'root:level1:level2') == 'leaf node'

    # Get "leaf node", specify default
    tree = {
        'root': {
            'level1': {
                'level2': 'leaf node'
            }
        }
    }
    assert get_tree_node(tree, 'root:level1:missing', default='duck') == 'duck'

    # Get parent node, specify default
    tree = {
        'root': {
            'level1': {
                'level2': 'leaf node'
            }
        }
    }
    parent = get_tree_

# Generated at 2022-06-24 03:18:30.921086
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    tree = RegistryTree()
    tree.register(1, 'one')
    tree.register(1, 1)
    tree.register(2, 2)
    tree.register(3, 3)
    assert tree[1] == 1
    assert tree.get(2) == 2
    assert tree.get(3) == 3
    assert tree.get(2, default='nope') == 2
    tree.register('foo:bar', 'baz')
    assert tree.get('foo:bar') == 'baz'



# Generated at 2022-06-24 03:18:36.609907
# Unit test for function tree
def test_tree():
    # Fetch this node
    tree = {'key1': {'key2': 'value'}}
    assert get_tree_node(tree, 'key1:key2') == 'value'

    # Fetch this node
    tree = {'key1': {'key2': {'key3': {'key4': 'value'}}}}
    assert get_tree_node(tree, 'key1:key2:key3:key4') == 'value'

    # Fetch this node
    tree = {'key1': {'key2': {'key3': {'key4': 'value'}}}}
    assert get_tree_node(tree, 'key1:key2:key3') == {'key4': 'value'}

    # Fetches nothing, but returns default

# Generated at 2022-06-24 03:18:40.849505
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    a = RegistryTree(
        initial={
            'foo': 'bar',
            'baz': 'narf',
        },
        initial_is_ref=True,
    )
    assert a['foo'] == 'bar'
    assert a['baz'] == 'narf'
    a['bat'] = 'zarb'
    assert a['bat'] == 'zarb'

# Generated at 2022-06-24 03:18:51.412722
# Unit test for constructor of class Tree
def test_Tree():
    m = Tree({'a': {'b': {'c': 'd'}}})
    assert m['a:b:c'] == 'd'
    assert m['a:b']['c'] == 'd'
    assert m['a']['b']['c'] == 'd'

    m.update({'a': {'b': {'e': 'f'}}})
    assert m['a:b:e'] == 'f'

    m.update({'a': 'c'})
    assert m['a'] == 'c'

    m = Tree({}, 'a')
    m['b'] = 'c'
    assert m['b'] == 'c'
    assert m['a:b'] == 'c'


# Generated at 2022-06-24 03:18:58.138214
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree_ = Tree()
    data = {'foo': {'bar': 'baz'}}
    tree_.update(data)
    assert tree_['foo:bar'] == 'baz'

    assert tree_.get('foo:bar:baz') is None
    assert tree_.get('foo:bar:baz', default=None) is None

    # Double-check the update worked
    assert tree_['foo']['bar'] == 'baz'
    assert tree_['foo']['bar'] == 'baz'



# Generated at 2022-06-24 03:19:04.922359
# Unit test for constructor of class Tree
def test_Tree():
    # Test some stuff.
    t = Tree(namespace='foo')
    t.register('bar', 'foo:bar')
    assert t.get('bar') == 'foo:bar'
    assert 'bar' not in t

    t.register('bar', 'bar', namespace='')
    assert t.get('bar') == 'bar'
    assert t.get('foo:bar') == 'foo:bar'

    assert t.get('foo:baz', 'default') == 'default'

    t['foo:baz'] = 'baz'
    assert t.get('foo:baz', 'default') == 'baz'


if __name__ == '__main__':
    import sys
    import logging
    logging.basicConfig(stream=sys.stdout, level=logging.DEBUG)

# Generated at 2022-06-24 03:19:11.330477
# Unit test for function tree
def test_tree():
    """Unit test for function tree. Leaves test here rather than in test_utils, since I want to test the function."""
    t = tree()

    t['a:b'] = 'b'
    t['c:d'] = 'd'

    assert t == {
        'a': {
            'b': 'b',
        },
        'c': {
            'd': 'd',
        },
    }
    assert t['a:b'] == 'b'



# Generated at 2022-06-24 03:19:15.605006
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree(initial={'d': 34, 'c': {'e': {'f': 123}}, 'b': {'g': 444}})
    assert t['b:g'] == 444
    assert t['c:e:f'] == 123
    assert t['d'] == 34



# Generated at 2022-06-24 03:19:24.567291
# Unit test for function tree
def test_tree():
    tree = Tree()

    tree['foo'] = 'bar'
    tree['foo:bar'] = 'baz'

    assert tree == {
        'foo': {
            'bar': 'baz'
        }
    }
    assert tree.get('foo', '') == {'bar': 'baz'}
    assert tree.get('foo:bar', '') == 'baz'

    tree['foo:bar:baz'] = 'baz'

    assert tree == {
        'foo': {
            'bar': {
                'baz': 'baz'
            }
        }
    }
    assert tree.get('foo', '') == {
        'bar': {
            'baz': 'baz'
        }
    }

# Generated at 2022-06-24 03:19:30.666469
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    from pprint import pprint

    t = Tree()
    t['a:b:c:d'] = 4
    t['a:b:c:e'] = 5
    t['a:b:f'] = 6
    t['a:b:c:d:e'] = ['everything', 'is', 'awesome']
    t['a:b:c:d:f'] = {1: 'Foo!', 2: 'Bar!', 3: 'Baz!'}
    assert t['a:b:c:d:f'][2] == t['a:b:c:d:f']['2'] == t['a:b:c:d:f'].get('2') == 'Bar!'
    pprint(t)

# Generated at 2022-06-24 03:19:33.043606
# Unit test for constructor of class Tree
def test_Tree():
    assert Tree('test') == {'test': {}}



# Generated at 2022-06-24 03:19:33.681481
# Unit test for function tree
def test_tree():
    pass

# Generated at 2022-06-24 03:19:43.855671
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree()
    assert t
    t[':lol']
    t.update({
        'foo': 'bar',
        'baz': {1: 2}
    })
    assert t['foo'] == 'bar'
    assert t['baz'] == {1: 2}
    assert t[':baz'] == {1: 2}
    t['baz:1'] = 3
    assert t['baz:1'] == 3
    assert t['baz'] == {1: 3}
    t['baz:2'] = 4
    assert t['baz'] == {1: 3, 2: 4}
    t['baz:2:3:4'] = 5
    assert t['baz:2'] == {3: {4: 5}}
    t2 = Tree()

# Generated at 2022-06-24 03:19:48.792604
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    ref_tree = tree()
    ref_tree['foo']['bar']['baz'] = 1

    reg_tree = RegistryTree()
    reg_tree.register({'foo': {'bar': {'baz': 1}}})

    assert ref_tree == reg_tree.data

# Generated at 2022-06-24 03:19:53.936913
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    from functools import partial
    from pprint import pformat
    _tree = {'name': 'test'}
    tree = Tree()
    set_tree_node = partial(tree.set_tree_node, tree)

    print (set_tree_node('foo', 'foo_value'))
    print (pformat(tree))



# Generated at 2022-06-24 03:19:56.135907
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    rt = RegistryTree()
    rt.register('test.test', 'value')
    assert rt['test.test'] == 'value'

# Generated at 2022-06-24 03:19:58.698445
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()
    tree['a:b:c:d'] = 1
    assert tree == {'a': {'b': {'c': {'d': 1}}}}, tree

# Generated at 2022-06-24 03:20:04.891922
# Unit test for constructor of class Tree
def test_Tree():
    l = [{'spam': 'eggs'}, {'foo': {'bar': {'baz': 'quux'}}}]
    tree = Tree(l, namespace='a')
    assert tree.get('a:spam', default=None) == 'eggs'
    assert tree.get('a:foo:bar:baz', default=None) == 'quux'



# Generated at 2022-06-24 03:20:09.657744
# Unit test for function set_tree_node
def test_set_tree_node():

    import pytest

    node = {}
    set_tree_node(node, 'key:subkey', 'value')
    assert node['key']['subkey'] == 'value'

    set_tree_node(node, 'key:subkey', 'changed')
    assert node['key']['subkey'] == 'changed'



# Generated at 2022-06-24 03:20:13.899089
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'foobarbaz'
            }
        }
    }

    assert get_tree_node(mapping, 'foo:bar:baz') == 'foobarbaz'



# Generated at 2022-06-24 03:20:21.614965
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'node': {
            'subnode': {
                'subsubnode': 1
            }
        }
    }
    assert get_tree_node(mapping, 'node') == {'subnode': {'subsubnode': 1}}
    assert get_tree_node(mapping, 'node:subnode') == {'subsubnode': 1}
    assert get_tree_node(mapping, 'node:subnode:subsubnode') == 1
    assert get_tree_node(mapping, 'node:subnode:subsubnode:nonexistent') is _sentinel
    try:
        get_tree_node(mapping, 'node:subnode:subsubnode:nonexistent')
    except KeyError:
        pass



# Generated at 2022-06-24 03:20:26.982963
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    x = Tree()
    x[':a'] = 1
    assert x[':a'] == 1
    assert x[':b'] == Tree()
    assert x[':a'] == 1
    x[':c:d'] = 3
    assert x[':c:d'] == 3
    assert x[':c'] == Tree({'d': 3})



# Generated at 2022-06-24 03:20:36.490135
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    foo = Tree()

    # Initialize tree with preset data
    data = {
        'a': 1,
        'b': {
            'c': 3,
        },
    }
    foo.update(data)

    assert foo['a'] == 1
    assert foo['b:c'] == 3
    assert foo.get('b:c') == 3

    # Test defaults
    assert foo.get('x', 'no key') == 'no key'
    assert foo.get('x') == {}
    with pytest.raises(KeyError):
        foo['x']



# Generated at 2022-06-24 03:20:44.364744
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {'a': {'b': {'c': 'd'}}}
    assert mapping == {'a': {'b': {'c': 'd'}}}
    assert mapping == get_tree_node(mapping, 'a')
    assert mapping['a'] == get_tree_node(mapping, 'a', parent=True)
    assert {'b': {'c': 'd'}} == get_tree_node(mapping, 'a:b')
    assert {'c': 'd'} == get_tree_node(mapping, 'a:b:c')
    assert 'd' == get_tree_node(mapping, 'a:b:c:d')


# Generated at 2022-06-24 03:20:50.439686
# Unit test for constructor of class Tree
def test_Tree():
    root = Tree()
    root['a:b:c:d'] = 'pass'
    assert root['a:b:c:d'] == 'pass'

    root = Tree(namespace='root')
    root['a:b:c:d'] = 'pass'
    assert root['a:b:c:d'] == 'pass'
    assert root['root:a:b:c:d'] == 'pass'



# Generated at 2022-06-24 03:21:01.195094
# Unit test for function get_tree_node
def test_get_tree_node():
    test_dict = {
        "foo": {
            "bar": {
                "baz": 1,
                "quux": 2
            }
        },
        "alpha": {
            "beta": 3,
            "gamma": 4
        }
    }

    assert get_tree_node(test_dict, 'alpha:beta') == 3

    test_dict = {
        'foo': {
            'bar': 1
        }
    }

    assert get_tree_node(test_dict, 'nope', default=False) is False
    assert get_tree_node(test_dict, 'foo:bar') == 1
    with pytest.raises(KeyError):
        get_tree_node(test_dict, 'foo:nope')
    with pytest.raises(KeyError):
        get_

# Generated at 2022-06-24 03:21:10.931035
# Unit test for function tree
def test_tree():
    assert (tree()['a']['b']['c']) == {}
    assert (tree()['a']['b']['c']) != (tree()['a']['b']['d'])
    assert (tree()['a']['b']['c']) == (tree()['a']['b'])['c']
    assert (tree()['a']['b']['c']) != (tree()['a']['b'])['d']
    assert (tree()['a']['b']['c']) == (tree()['a'])['b']['c']
    assert (tree()['a']['b']['c']) != (tree()['a'])['b']['d']

# Generated at 2022-06-24 03:21:15.031868
# Unit test for function tree
def test_tree():
    t = tree()
    t['a']['b']['c']['d'] = 'e'
    assert t['a']['b']['c']['d'] == 'e'
    assert t['a:b:c:d'] == 'e'

# Generated at 2022-06-24 03:21:25.313190
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'foo': {'bar': 1}}, 'foo:bar') == 1
    assert get_tree_node({'foo': {'bar': {'boo': 1}}}, 'foo:bar') == {'boo': 1}
    assert get_tree_node({'foo': {'bar': {'boo': 1}}}, 'foo:bar:boo') == 1
    assert get_tree_node({'foo': {'bar': {'boo': 1}}}, 'foo:bar:boo', parent=True) == {'boo': 1}
    assert get_tree_node({'foo': {'bar': {'boo': 1}}}, 'foo') == {'bar': {'boo': 1}}

# Generated at 2022-06-24 03:21:36.678622
# Unit test for function get_tree_node
def test_get_tree_node():
    assert get_tree_node({'a': {'a': 1}}, 'a:a') == 1  # Fetch first level node
    assert get_tree_node({'a': {'a': 1}}, 'a:a:a') == _sentinel  # Fails because the node at 'a:a' is not a mapping
    assert get_tree_node({'a': [1, 2, 3]}, 'a:b') == _sentinel  # Fails because the intermediate node 'a' is not a mapping
    assert get_tree_node({'a': {'a': {'a': 1}}}, 'a:a:a') == 1  # Fetch nested node

# Generated at 2022-06-24 03:21:41.736732
# Unit test for function tree
def test_tree():
    _t = tree()
    _t['a']['b']['c'] = 'Z'
    assert _t['a']['b']['c'] == 'Z'
    assert _t['a:b']['c'] == 'Z'
    assert _t['a:b:c'] == 'Z'

# Generated at 2022-06-24 03:21:45.207935
# Unit test for function get_tree_node
def test_get_tree_node():
    """Unit test for :func:`get_tree_node`"""
    mapping = {'foo': {'bar': {'baz': 'qux'}}}
    assert get_tree_node(mapping, 'foo:bar:baz') == 'qux'



# Generated at 2022-06-24 03:21:52.107906
# Unit test for constructor of class Tree
def test_Tree():

    d = {'foo': {'bar': True}}
    t = Tree(d, namespace='foo')
    assert t.get('bar', default=False)
    assert t.get('foobar', default=False) is False
    assert t.get('bar', default=False, namespace='foo')
    assert t.get('foobar', default=False, namespace='foo') is False

    t = Tree(d, namespace='')
    assert t.get('bar', default=False, namespace='foo')
    assert t.get('foobar', default=False) is False

# Generated at 2022-06-24 03:22:00.848726
# Unit test for function tree
def test_tree():
    t = tree()
    t['a']['b']['c']['d'] = 1
    t['a']['b']['e'] = 2
    t['a']['f'] = 5
    assert t['a']['b']['c']['d'] == 1
    assert t['a']['b']['e'] == 2
    assert t['a']['f'] == 5
    assert t['a'] == {
        'b': {
            'c': {
                'd': 1
            },
            'e': 2
        },
        'f': 5
    }



# Generated at 2022-06-24 03:22:08.783075
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Unit-test for :func:`get_tree_node`.

    Raises:
        AssertionError on failure.
    """
    tree = {
        'first': {
            'second': {
                'third': 'value'
            }
        }
    }

    assert 'value' == get_tree_node(tree, 'first:second:third')
    assert _sentinel != get_tree_node(tree, 'no_exist')
    assert 'default' == get_tree_node(tree, 'no_exist', 'default')

# Generated at 2022-06-24 03:22:14.820851
# Unit test for function tree
def test_tree():
    """
    Extremely silly unit test for function `:func:tree`.
    """
    m = tree()
    m['a']['b']['c'] = 'd'

    assert m['a']['b']['c'] == 'd'

    m['a:b:c'] = 'd'

    assert m['a']['b']['c'] == 'd'

    # Check default key
    assert m['a']['b']['c']['abracadabra'] == tree()


test_tree()



# Generated at 2022-06-24 03:22:18.639948
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree()
    t['foo'] = {'bar': 'baz'}
    assert t['foo']['bar'] == 'baz'
    assert t.get('foo:bar') == 'baz'
    assert t['foo:bar'] == 'baz'



# Generated at 2022-06-24 03:22:28.482736
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': {
                'baz': 'foobarbaz',
            },
            'foo': 'barfoo',
        },
    }
    assert get_tree_node(mapping, 'foo:bar:baz') == 'foobarbaz'
    assert get_tree_node(mapping, 'foo:baz', default='foobarbaz') == 'foobarbaz'
    try:
        assert get_tree_node(mapping, 'foo:baz')
    except KeyError:
        pass


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 03:22:30.163127
# Unit test for constructor of class Tree
def test_Tree():
    x = Tree({'hello': 'world!'})
    assert x['hello'] == "world!"



# Generated at 2022-06-24 03:22:33.454106
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'foo': {
            'bar': 'foobar',
        },
    }
    assert get_tree_node(mapping, 'foo:bar') == 'foobar'
    assert get_tree_node(mapping, 'foo:bar:baz') == _sentinel



# Generated at 2022-06-24 03:22:38.732384
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree(initial=None, initial_is_ref=False, namespace='')
    assert t['a']['b']['c'] == {}
    t['a']['b']['c'] = 'd'
    assert t['a']['b']['c'] == {'d'}



# Generated at 2022-06-24 03:22:39.911966
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    assert 0, 'Not implemented'



# Generated at 2022-06-24 03:22:48.527313
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    registry = RegistryTree()
    registry.register('hoi', 'hoi')
    registry.register('hoi.doei', 'doei')
    registry.register('hoi.doei.lekker', 'lekker')
    assert registry.get('hoi') == 'hoi'
    assert registry.get('hoi:doei') == 'doei'
    assert registry.get('hoi.doei.lekker') == 'lekker'
    assert registry.get('hoi:doei:lekker') == 'lekker'
    assert registry.get('hoi:doei:lekker.leuk.lol') is None



# Generated at 2022-06-24 03:22:56.919173
# Unit test for function tree
def test_tree():
    """Test `tree` with a simple example."""
    _tree = tree()
    _tree[0][0][0][0] = 'Hello'
    _tree[0][1][0][0] = 'World'
    _tree[1][0][0][0] = '!'

    assert _tree[0][0][0][0] == 'Hello'
    assert _tree[0][1][0][0] == 'World'
    assert _tree[1][0][0][0] == '!'


if __name__ == '__main__':
    test_tree()

# Generated at 2022-06-24 03:23:03.508386
# Unit test for function set_tree_node
def test_set_tree_node():
    test_tree = tree()

    # Test list setting
    set_tree_node(test_tree, 'list:list_list', ['list', 'of', 'lists'])
    assert test_tree['list']['list_list'] == ['list', 'of', 'lists']

    # Test dict setting
    set_tree_node(test_tree, 'dict:dict_dict', {'dict': 'of', 'dicts': 'foo'})
    assert test_tree['dict']['dict_dict'] == {'dict': 'of', 'dicts': 'foo'}

    # Test replacive setting
    set_tree_node(test_tree, 'list:list_list', {'list': 'of', 'dicts': 'foo'})

# Generated at 2022-06-24 03:23:10.628332
# Unit test for function set_tree_node
def test_set_tree_node():
    from pprint import pprint
    tree = {}
    pprint(set_tree_node(tree, 'a', {'b': 1, 'c': 2}))
    pprint(set_tree_node(tree, 'a:b', {'z': 3}))
    pprint(set_tree_node(tree, 'a:b:z', {'z': 3}))
    pprint(tree)



# Generated at 2022-06-24 03:23:18.517466
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree({
        'a': {
            'a1': '1',
            'a2': {'a21': '21'}
        },
        'b': '2',
        'c': {
            'c1': {
                'c11': '11',
                'c12': '12'
            },
            'c2': {
                'c21': '21',
                'c22': '22'
            }
        },
        'd': '4'
    })

    assert t['a'] == {
        'a1': '1',
        'a2': {'a21': '21'}
    }
    assert t['a:a1'] == '1'
    assert t['a:a2'] == {'a21': '21'}

# Generated at 2022-06-24 03:23:28.362488
# Unit test for function tree
def test_tree():
    t = tree()
    t['a']['b']['c'] = 'd'
    assert t['a']['b']['c'] == 'd'
    assert t == {'a': {'b': {'c': 'd'}}}

    assert get_tree_node(t, 'a:b') == {'c': 'd'}
    assert get_tree_node(t, 'a:b:c') == 'd'

    t = tree()
    t['a']['b']['c'] = 'd'
    t = set_tree_node(t, 'a:b:c', 'e')
    assert t == {'a': {'b': {'c': 'e'}}}

    # List
    t = tree()

# Generated at 2022-06-24 03:23:30.961247
# Unit test for constructor of class Tree
def test_Tree():
    assert Tree.namespace == None



# Generated at 2022-06-24 03:23:40.909955
# Unit test for constructor of class Tree
def test_Tree():

    assert Tree() == {}

    t = Tree(initial={'a': 1, 'b': 2})
    assert t == {'a': 1, 'b': 2}
    assert t.namespace == ''

    from copy import copy
    base = {'a': 1, 'b': 2}
    t = Tree(initial=base, initial_is_ref=True)
    base['c'] = 3
    assert t == {'a': 1, 'b': 2, 'c': 3}
    base['d'] = 4
    assert t == {'a': 1, 'b': 2, 'c': 3, 'd': 4}

    t = Tree(initial={'a': 1, 'b': 2}, namespace='foo')
    assert t == {'a': 1, 'b': 2}
    t.namespace = ''
   

# Generated at 2022-06-24 03:23:51.319756
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree = Tree()
    tree['foo'] = 'bar'
    assert tree['foo'] == 'bar'

    tree['foo']['foo2'] = 'bar2'
    assert tree['foo:foo2'] == 'bar2'

    tree['foo']['foo3'] = 'bar3'
    assert tree['foo:foo3'] == 'bar3'

    tree['foo']['foo2']['foo3']['foo4'] = 'bar4'
    assert tree['foo:foo2:foo3:foo4'] == 'bar4'

    # Test default

# Generated at 2022-06-24 03:24:00.590984
# Unit test for function get_tree_node
def test_get_tree_node():
    """Unit test for function `get_tree_node`"""
    tree = {
        'a': {
            'b': {
                'c': [1, 2, 3],
                'd': [4, 5, 6]
            }
        }
    }
    assert get_tree_node(tree, 'a:b:c') == [1, 2, 3]
    assert get_tree_node(tree, 'a:b:c', default=None) == [1, 2, 3]
    assert get_tree_node(tree, 'a:b:f', default=None) is None

    # Test no-op
    tree_copy = tree.copy()
    assert get_tree_node(tree, 'a:b:c') == [1, 2, 3]

    # Test mutable

# Generated at 2022-06-24 03:24:07.728753
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    from pprint import pprint
    import unittest

    class TestClass(unittest.TestCase):
        def test_tree_registry_set_item(self):
            tree = RegistryTree()
            tree['a'] = {'b': {'c': 'x'}}
            tree['a']['b'] = {'c': 'y'}
            tree.register('a:b', 'c', 'z')
            expected = {
                'a': {
                    'b': {
                        'c': 'z'
                    }
                }
            }
            self.assertEqual(tree, expected)

    unittest.main()



# Generated at 2022-06-24 03:24:18.317570
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    """
    Method `__getitem__` is tested with positive and negative scenarios.
    The default behavior :func:`collections.defaultdict` behavior is tested as well.
    Also tests the `get` method.
    """
    # Test basic Tree[key] behavior.
    dt = Tree()
    dt['key'] = 'value'
    assert dt['key'] == 'value'

    # Test Tree[key] with invalid key
    invalid_key = 'foo'
    assert dt[invalid_key] == Tree()

    # Test Tree[key] with invalid key and default value
    assert dt.get(invalid_key) == Tree()

    # Test Tree[key] with default value
    default_value = 'foo'
    assert dt[invalid_key, default_value] == Tree()

    #