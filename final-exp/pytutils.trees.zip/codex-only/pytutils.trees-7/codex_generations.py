

# Generated at 2022-06-24 03:14:18.672362
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree()
    t['a']['b']['c']['d'] = 4
    assert t['a']['b']['c']['d'] == 4
    #  No KeyError because it is a defaultdict
    assert t['q']['b']['v'] == {}
    assert t['q']['w'] == {}

    #  No KeyError because we have a default value
    assert t['a']['b']['c']['f'] == {}
    # KeyError because we have no default value
    try:
        t['a']['b']['c']['f']
    except KeyError:
        pass
    else:
        raise AssertionError("Did not raise KeyError")



# Generated at 2022-06-24 03:14:23.701574
# Unit test for function tree
def test_tree():
    t = tree()
    for i in xrange(16):
        t[i] = {
            'data': i * 10,
            'sub': {
                'intk': 1,
                'outk': 2,
            }
        }

# Generated at 2022-06-24 03:14:30.904756
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {'foo': {'bar': {'baz': {'qux': 'quux'}, 'buzz': 'fizz'}}}
    assert get_tree_node(tree, 'foo:bar:baz:qux') == 'quux'
    assert get_tree_node(tree, 'foo:bar:buzz') == 'fizz'
    assert get_tree_node(tree, 'foo:bar:buzz:blim') is _sentinel
    assert get_tree_node(tree, 'foo:bar:buzz:blim', default='blam') == 'blam'
    assert get_tree_node(tree, 'foo:bar:buzz:blim', parent=True) == {'buzz': 'fizz'}

# Generated at 2022-06-24 03:14:34.243111
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    matrix = Tree(namespace='foo')
    matrix[':bar'] = 1
    assert matrix['foo:bar'] == 1



# Generated at 2022-06-24 03:14:38.122891
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    rt = RegistryTree(namespace='foo')
    assert rt.namespace is 'foo'

    rt = RegistryTree(initial={1: 2})
    assert rt[1] == 2

    rt = RegistryTree(initial_is_ref=rt)
    assert rt[1] == 2



# Generated at 2022-06-24 03:14:44.857261
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():

    data = {
        'foo': {
            'bar': {
                'baz': 'buz',
            }
        },
        'bar': {
            'foo': 'buz:bar:foo'
        }
    }

    n1 = Tree(data)

    assert n1['foo:bar:baz'] == 'buz'
    assert n1['bar:foo'] == 'buz:bar:foo'
    assert 'foo:bar:buz' not in n1

    assert n1.get('foo:bar:baz') == 'buz'
    assert n1.get('foo:bar:buz', 'default') == 'default'

    # Expected KeyError
    with pytest.raises(KeyError):
        n1.get('foo:bar:buz')



# Generated at 2022-06-24 03:14:52.135284
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree()
    t['home']['folder']['file1'] = 'banana'
    t['home']['folder']['file2'] = 'apple'
    t['home']['folder']['file_new'] = 'peach'

    assert t['home:folder:file1'] == 'banana'
    assert t['home:folder:file2'] == 'apple'
    assert t['home:folder:file_new'] == 'peach'



# Generated at 2022-06-24 03:15:02.256116
# Unit test for function get_tree_node
def test_get_tree_node():
    plain_dict = {
        'foo': 'bar',
        'egg': 'spam',
    }

    nested_dict = {
        'foo': {
            'egg': 'spam',
            'test': 'ing',
        }
    }

    plain_tree = {
        'foo': 'bar',
        'egg': 'spam',
    }

    nested_tree = {
        'foo': {
            'egg': 'spam',
            'test': 'ing',
        }
    }

    assert get_tree_node(plain_dict, 'foo', default=None) == 'bar'
    assert get_tree_node(nested_dict, 'foo:egg', default=None) == 'spam'
    assert get_tree_node(plain_dict, 'not_there', default=None)

# Generated at 2022-06-24 03:15:06.182550
# Unit test for function set_tree_node
def test_set_tree_node():
    m = {}
    set_tree_node(m, 'foo.bar', 'baz')
    assert m['foo']['bar'] == 'baz'



# Generated at 2022-06-24 03:15:15.486963
# Unit test for function tree
def test_tree():
    t = tree()
    t['a']['b'] = 'c'
    t['a']['b']['d'] = 'e'
    t['a']['b']['f']['g'] = 'h'
    assert t['a']['b']['f']['g'] == 'h'
    assert list(t['a']['b']) == ['d', 'f']
    assert t['a']['b']['f'] == {'g': 'h'}
    t['a']['b']['f']['g'] = 'i'
    assert t['a']['b']['f']['g'] == 'i'

# Generated at 2022-06-24 03:15:25.146781
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree()
    t['a:b:c'] = 1
    # print(t)
    # print(t.get('a:b'))
    # print(t['a:b:c'])

    # print(t['x:y:z'])
    # print(t.get('a:b:c'))
    # print(t.get('x:y:z'))

    # print(t.pretty())

    # -------------------------------------------------------------------------

    t = Tree()
    t['a:b'] = {'c': 1}
    # print(t)
    # print(t['a:b'])
    # print(t['a:b']['c'])

    # print(t.pretty())

    # -------------------------------------------------------------------------

    t = Tree()

# Generated at 2022-06-24 03:15:30.236275
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree({'tree': {'branch': 'leaf', 'trunk': 'sinew'}})
    assert 'sinew' == t['tree:trunk']
    assert {'branch': 'leaf', 'trunk': 'sinew'} == t['tree']
    assert {'branch': 'leaf', 'trunk': 'sinew'} == t[':tree']



# Generated at 2022-06-24 03:15:39.745415
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    test_registry = RegistryTree(namespace='foo')

    # Assert that we use a namespace
    assert test_registry.namespace == 'foo'

    test_registry.register('test', 'bar')
    assert test_registry['foo:test'] == 'bar'

    # Namespacing should be optional
    test_registry['test2'] = 'bar'
    assert test_registry['test2'] == 'bar'
    assert test_registry['foo:test2'] == 'bar'

    # Test that we can build a tree
    test_registry['foo:child:child'] = 'child'

    # Assert nested namepaces
    assert test_registry['foo:child']['foo:child'] == 'child'

    # Assert nested namespace with defaultdict

# Generated at 2022-06-24 03:15:42.368187
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    r = RegistryTree(namespace='foo')
    r.register('bar:baz', 'bingo')
    assert r.get('bar:baz') == 'bingo'



# Generated at 2022-06-24 03:15:45.229250
# Unit test for constructor of class Tree
def test_Tree():
    # TODO `assert Tree('test') == {'test': {}}` is broken.
    assert Tree() == Tree({})
    assert Tree({}) == {}
    assert Tree({'test': 'value'}) == {'test': {'value': {}}}



# Generated at 2022-06-24 03:15:48.179783
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    """Unit test for constructor of class RegistryTree."""
    registry_tree = RegistryTree(namespace='os')
    registry_tree.register('os:path', os.path)


if __name__ == '__main__':
    test_RegistryTree()

# Generated at 2022-06-24 03:15:53.590589
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    # TODO: Test case.
    # Setup Environment
    tree = {'foo': {'bar': 'baz'}}
    tree = Tree(tree)

    # Test 1
    tree['foo'] == {'bar': 'baz'}



# Generated at 2022-06-24 03:16:04.077160
# Unit test for function set_tree_node
def test_set_tree_node():
    """
    Test behaviour of `set_tree_node`
    """
    # Test 1, simple key
    test_dict = tree()
    test_dict['key'] = 'value'
    assert test_dict['key'] == 'value'
    assert test_dict['key2']['key3'] == {}

    # Test 2, simple nested key
    test_dict['key2:key3'] = 'value'
    assert test_dict['key2']['key3'] == 'value'

    # Test 3, setting initial
    test_dict = tree(initial={'key': 'value'})
    assert test_dict['key'] == 'value'
    test_dict['key2'] = 'value2'
    assert test_dict['key2'] == 'value2'
    # Test nested default dict
    assert test_dict

# Generated at 2022-06-24 03:16:13.214092
# Unit test for function get_tree_node
def test_get_tree_node():
    x = tree()
    x['a']['b']['c']['d']['e'] = 'foo'
    assert get_tree_node(x, 'a:b:c:d:e', 'bar') == 'foo'
    assert get_tree_node(x, 'a:b:c:d:f', 'bar') == 'bar'


if __name__ == "__main__":
    x = tree()
    x['a']['b']['c']['d']['e'] = 'foo'
    assert get_tree_node(x, 'a:b:c:d:e') == 'foo'
    assert get_tree_node(x, 'a:b:c:d:f', 'bar') == 'bar'
    test_get_tree_node()

# Generated at 2022-06-24 03:16:19.917934
# Unit test for function set_tree_node
def test_set_tree_node():
    """Unit test for set_tree_node"""

    tree = {}
    set_tree_node(tree, 'tree', {})
    set_tree_node(tree, 'tree:subdirA', 'subdirA_value')
    set_tree_node(tree, 'tree:subdirB', {})
    set_tree_node(tree, 'tree:subdirB:subsubdirA', 'subsubdirA_value')
    set_tree_node(tree, 'tree:subdirB:subsubdirB', 'subsubdirB_value')
    return tree



# Generated at 2022-06-24 03:16:24.380902
# Unit test for function get_tree_node
def test_get_tree_node():
    mapping = {
        'one': 1,
        'two': {
            'five': 5,
            'six': 6
        }
    }

    assert get_tree_node(mapping, 'one') == 1
    assert get_tree_node(mapping, 'two:five') == 5
    assert get_tree_node(mapping, 'two:seven', default=-1) == -1
    try:
        get_tree_node(mapping, 'two:seven')
        assert False
    except KeyError:
        assert True



# Generated at 2022-06-24 03:16:32.611531
# Unit test for function get_tree_node
def test_get_tree_node():
    tree = {
        'foo': {
            'bar': {
                'baz': 'bat',
            }
        }
    }

    assert get_tree_node(tree, 'foo:bar') == {'baz': 'bat'}
    assert get_tree_node(tree, 'foo:bar:baz') == 'bat'
    assert get_tree_node(tree, 'lol:nope') is _sentinel
    assert get_tree_node(tree, 'lol:nope', default='yolo') == 'yolo'



# Generated at 2022-06-24 03:16:36.059129
# Unit test for function set_tree_node
def test_set_tree_node():
    test_dict = {}
    set_tree_node(test_dict, 'a:b:c', 'd')
    assert test_dict.get('a') == {'b': {'c': 'd'}}



# Generated at 2022-06-24 03:16:44.964530
# Unit test for function set_tree_node
def test_set_tree_node():

    class Mapping(collections.Mapping):

        def __init__(self, *args, **kwargs):
            self.__dict = {}
            self.update(*args, **kwargs)

        def __getitem__(self, key):
            return self.__dict[key]

        def __iter__(self):
            return iter(self.__dict)

        def __len__(self):
            return len(self.__dict)

        def update(self, *args, **kwargs):
            self.__dict.update(*args, **kwargs)

    src = {'a': 1, 'b': {'c': 3, 'd': 4}}
    mapping = Mapping(src)
    set_tree_node(mapping, 'b:c', 'New value!')

# Generated at 2022-06-24 03:16:52.858547
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree()
    t['a']['b']['c'] = 'd'
    assert t.get('a') == {'b': {'c': 'd'}}
    assert t.get('b') is None
    assert t.get('a:b') is None
    assert t.get('a:b:c') == 'd'
    assert t.get('a:x:c') is None
    assert t.get('a:x:c', default='Missing') == 'Missing'



# Generated at 2022-06-24 03:17:02.713419
# Unit test for function tree
def test_tree():
    """Unit test for tree function using unittest.TestCase"""
    import unittest

    class TestTree(unittest.TestCase):
        data = [{'key1': 'value1', 'key2': {'key3': 'value3'}, 'key4': 'value4'},
                {'key1': 'value5', 'key2': {'key3': 'value6'}, 'key4': 'value7'},
                {'key1': 'value8', 'key2': {'key3': 'value9'}, 'key4': 'value0'}]


# Generated at 2022-06-24 03:17:11.354478
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    tree = Tree()

    # Assert is KeyError
    try:
        tree['stuff']
    except KeyError:
        pass
    else:
        assert False, 'Expected KeyError, got None'

    tree['stuff'] = 'value'
    assert tree['stuff'] == 'value'
    tree['stuff:deeper'] = 'value'
    assert tree['stuff:deeper'] == 'value'
    tree['stuff:deeper:deeper'] = 'value'
    assert tree['stuff:deeper:deeper'] == 'value'
    tree['stuff:deeper:deeper:deeper'] = 'value'
    assert tree['stuff:deeper:deeper:deeper'] == 'value'



# Generated at 2022-06-24 03:17:17.867096
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = {}
    set_tree_node(mapping, 'A:B:C:D:E:F:G:H:I:J:K', 'value')
    assert mapping == {'A': {'B': {'C': {'D': {'E': {'F': {'G': {'H': {'I': {'J': {'K': 'value'}}}}}}}}}}}



# Generated at 2022-06-24 03:17:23.745746
# Unit test for function get_tree_node
def test_get_tree_node():
    test_dict = {
        'a': {
            'b': {
                'c': {
                    'd': 'hi'
                }
            }
        }
    }

    assert 'hi' == get_tree_node(test_dict, 'a:b:c:d')
    assert get_tree_node(test_dict, 'a:b:c:d:e') is _sentinel
    with pytest.raises(KeyError):
        get_tree_node(test_dict, 'a:b:c:d:e')



# Generated at 2022-06-24 03:17:30.551026
# Unit test for constructor of class Tree
def test_Tree():
    from pprint import pprint
    t = Tree()
    t['foo']['bar'] = 'baz'
    assert t['foo']['bar'] == 'baz'
    pprint(t)
    print(t.get('neither', 5.0))
    t['foo']['bar:spam'] = 'eggs'
    assert t['foo']['bar']['spam'] == 'eggs'
    t['foo:spam'] = 'eggs'
    assert t['foo']['spam'] == 'eggs'
    pprint(t)
    pprint(t.namespace)
    t.namespace = 'foo'
    assert t['bar'] == 'baz'
    assert t.get('bar:spam') == 'eggs'

# Generated at 2022-06-24 03:17:33.421872
# Unit test for function set_tree_node
def test_set_tree_node():
    import json
    import pprint

    tree = collections.defaultdict(tree)
    set_tree_node(tree, 'one:two:three', '3.14')
    pprint.pprint(dict(tree))
    return 0


# Generated at 2022-06-24 03:17:38.783604
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    """
    Assert that a registry tree is created and that its namespace behaves as expected.
    """
    registry = RegistryTree('test_register', 'test')
    assert registry.namespace == 'test'
    assert registry.register(':foo', 'bar') == {':foo': 'bar'}
    assert registry[':foo'] == 'bar', registry
    registry.set_namespace('test2')
    assert registry.namespace == 'test2'
    assert registry[':foo'] == 'bar', registry



# Generated at 2022-06-24 03:17:41.657017
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    tree = RegistryTree(initial_is_ref=dict(foo='bar'))
    assert tree.foo == 'bar'



# Generated at 2022-06-24 03:17:44.784217
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    d = RegistryTree()
    d['foo'] = 'bar'
    result = d['foo']
    assert result == 'bar'
    # Should raise KeyError
    # result = d['baz']



# Generated at 2022-06-24 03:17:50.207468
# Unit test for constructor of class Tree
def test_Tree():
    from pprint import pprint
    test = Tree()
    test['foo'] = 'bar'
    test['foo:bar'] = 'baz'
    test['foo:bar:baz'] = 'foo'
    assert test['foo'] == 'bar'
    assert test['foo:bar'] == 'baz'
    assert test['foo:bar:baz'] == 'foo'
    assert test['foo:bar:buz'] == {}
    assert test['baz'] == {}



# Generated at 2022-06-24 03:17:56.176345
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    data = Tree(namespace='test')
    data.__setitem__(
        'test',
        {'test': 'test'},
    )
    data.__setitem__(
        'foo',
        {'bar': 'test'}
    )
    data.__setitem__(
        'foo:bar',
        {'fizz': 'buzz'}
    )
    assert data['test'] == {'test': 'test'}
    assert data['foo:bar'] == {'fizz': 'buzz'}
    assert data['foo:bar:fizz'] == 'buzz'



# Generated at 2022-06-24 03:18:05.217531
# Unit test for function get_tree_node
def test_get_tree_node():
    """
    Test get_tree_node on a nested array
    """
    test_array = {
        'a': {
            'b': {
                'c': 'd'
            }
        },
        'e': {
            'f': 'g'
        }
    }

    # Test 1
    assert get_tree_node(test_array, 'e:f') == 'g'

    # Test 2
    assert get_tree_node(test_array, 'a:b:c') == 'd'



# Generated at 2022-06-24 03:18:10.709458
# Unit test for function tree
def test_tree():
    t = tree()
    t['a']['b']['c'] = 1
    assert t['a']['b']['c'] == 1
    assert t['a']['b']['d'] == collections.defaultdict(tree, {})

    t = tree()
    t['a'].update({'b': tree(), 'c': 1})
    assert t['a']['b'] == collections.defaultdict(tree, {})
    assert t['a']['c'] == 1


# Generated at 2022-06-24 03:18:21.679456
# Unit test for constructor of class Tree
def test_Tree():
    from pprint import pformat

    t = Tree({'one': {'two': {'three': 3}}}, initial_is_ref=False)
    t.register('four')
    t.register('five', namespace='foo')
    t.register('six', namespace='foo')
    t.register('seven:eight:nine:ten:eleven')
    assert t == {'foo': {'five': {}, 'six': {}}, 'one': {'two': {'three': 3}}, 'seven': {'eight': {'nine': {'ten': {'eleven': {}}}}}, 'four': {}}

# Generated at 2022-06-24 03:18:31.958530
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    import sys
    import inspect
    import six

    class A(object):
        def __init__(self, i):
            self.i = i

        def __str__(self):
            return str(self.i)

    class B(A):
        def __init__(self, i, j):
            super(B, self).__init__(i)
            self.j = j

        def __str__(self):
            return str(self.j)

    r = RegistryTree(namespace='awesome')

    # Concrete instance
    r.register('a', A(5))
    assert r.get('a').i == 5
    assert r.get('a') == 5

    # Concrete class with parameter
    r.register('b', B, (5, 6))

# Generated at 2022-06-24 03:18:34.247448
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    class MyRegistryTree(RegistryTree):
        namespace = 'test'

    rt = MyRegistryTree()
    rt.register('foo', 'bar')
    assert rt['test:foo'] == 'bar'

# Generated at 2022-06-24 03:18:42.567484
# Unit test for function tree
def test_tree():
    mapping = {'a': {'b': {'c': 'd'}, 'e': 'f'}, 'g': {'h': 'i', 'j': 'k'}}
    node = get_tree_node(mapping, 'a:b:c')
    assert node == 'd'

    node = get_tree_node(mapping, 'g:j')
    assert node == 'k'

    node = get_tree_node(mapping, 'a:b')
    assert node == {'c': 'd'}

    node = get_tree_node(mapping, 'a:b', parent=True)
    assert node == {'b': {'c': 'd'}, 'e': 'f'}



# Generated at 2022-06-24 03:18:53.150244
# Unit test for function set_tree_node
def test_set_tree_node():

    # Test a simple flat mapping
    mapping = {}
    set_tree_node(mapping, 'name', 'Bob')
    assert mapping['name'] == 'Bob'

    # Test nested names
    mapping = {}
    set_tree_node(mapping, 'name:first', 'Bob')
    set_tree_node(mapping, 'name:last', 'Owen')
    assert mapping['name']['first'] == 'Bob'
    assert mapping['name']['last'] == 'Owen'

    # Test failure
    with pytest.raises(KeyError):
        set_tree_node(mapping, 'name:middle', 'of somewhere')

    # Test nested names
    mapping = {}
    set_tree_node(mapping, 'name:first', 'Bob')

# Generated at 2022-06-24 03:19:02.000566
# Unit test for function get_tree_node
def test_get_tree_node():
    data = tree()
    data['a']['b']['c']['e'] = 'd'
    assert get_tree_node(data, 'a:b:c:e') == 'd'
    assert get_tree_node(data, 'a:b:c:e', default='nada') == 'd'
    assert get_tree_node(data, 'a:b:c:nada') is _sentinel
    with pytest.raises(KeyError):
        get_tree_node(data, 'a:b:c:nada')
    assert get_tree_node(data, 'a:b:c:nada', default='nada') == 'nada'
    assert dict(data) == {'a': {'b': {'c': {'e': 'd'}}}}

   

# Generated at 2022-06-24 03:19:04.068959
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = tree()
    set_tree_node(mapping, 'dicta:dictb:key', 'value')
    assert mapping['dicta']['dictb']['key'] == 'value'



# Generated at 2022-06-24 03:19:08.686614
# Unit test for function get_tree_node
def test_get_tree_node():
    """Test get_tree_node"""
    t = tree()
    t['a']['b']['c'] = 1
    assert get_tree_node(t, 'a:b:c') == 1
    assert get_tree_node(t, 'd:b:c') is _sentinel



# Generated at 2022-06-24 03:19:11.289962
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    """Construct registry tree"""
    registry = RegistryTree(namespace='core')
    registry.register('test', lambda: 'hi')
    assert registry.get('test')() == 'hi'

# Generated at 2022-06-24 03:19:21.117995
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree()
    assert not t
    assert len(t) is 0

    t = Tree({'foo': 'bar'})
    assert t['foo'] == 'bar'
    assert t['foo'] is not None

    with pytest.raises(KeyError):
        t['bar']

    t = Tree({}, 'foo')
    assert not t
    assert len(t) is 0

    t = Tree({'bar': 'baz'}, 'foo')
    assert t['bar'] == 'baz'
    assert t['bar'] is not None
    assert t['foo:bar'] == 'baz'
    assert t['foo:bar'] is not None

    with pytest.raises(KeyError):
        t['foo']

    with pytest.raises(KeyError):
        t['bar']


# Generated at 2022-06-24 03:19:27.036942
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():

    tree1 = Tree(initial={'key1': 'val1', 'key2': {'subkey1': 'subval1'}})
    assert tree1['key2:subkey1'] == 'subval1'
    assert tree1['key1'] == 'val1'
    assert tree1['key0'] is None



# Generated at 2022-06-24 03:19:32.241232
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    a = RegistryTree()
    a.register('test', 42)
    assert a['test'] == 42
    b = RegistryTree(initial={'test': 42})
    assert b['test'] == 42

# Generated at 2022-06-24 03:19:41.778904
# Unit test for function get_tree_node
def test_get_tree_node():
    data = {
        'key1': 'value1',
        'key2': {'key3': 'value3'},
        'key4': {'key5': {'key6': 'value6'}},
        'key7': 'value7'
    }
    assert get_tree_node(data, 'key1') == 'value1'
    assert get_tree_node(data, 'key2:key3') == 'value3'
    assert get_tree_node(data, 'key4:key5:key6') == 'value6'
    assert get_tree_node(data, 'key7') == 'value7'



# Generated at 2022-06-24 03:19:53.573923
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree()
    t['a'] = 1
    t['b'] = 'spam'
    t['c:d'] = 3.14
    t['c:e:f'] = 'egg'
    t['c:e:g:h'] = 'ham'

# Generated at 2022-06-24 03:19:56.821456
# Unit test for function tree
def test_tree():
    t = tree()
    t['first']['second']['third']['fourth'] = 'hello'
    assert t['first:second:third:fourth'] == 'hello'
    assert get_tree_no

# Generated at 2022-06-24 03:20:06.199035
# Unit test for function tree
def test_tree():
    tree = Tree()
    tree['1'] = 1
    tree['2'] = 2
    assert tree['1'] == 1
    assert tree['2'] == 2
    tree['a:b:c:d'] = 4
    assert tree['a:b:c:d'] == 4
    tree['a:b:c:f'] = 5
    assert tree['a:b:c:f'] == 5
    assert tree['a:b:c']['d'] == 4
    assert tree['a']['b']['c']['d'] == 4
    assert tree['a:b:c']['f'] == 5
    assert tree['a']['b']['c']['f'] == 5



# Generated at 2022-06-24 03:20:12.179172
# Unit test for function set_tree_node
def test_set_tree_node():
    d = {}
    set_tree_node(d, 'a:b:c', 1)
    set_tree_node(d, 'a:b:d', 2)

    assert d['a']['b']['c'] == 1
    assert d['a']['b']['d'] == 2
    assert d['a']['b'] == {'c': 1, 'd': 2}

    # Overwrite
    set_tree_node(d, 'a:b', 2)
    assert d['a']['b'] == 2



# Generated at 2022-06-24 03:20:17.595186
# Unit test for function tree
def test_tree():
    t = tree()
    t['a']['b'] = '123'
    assert t['a']['b'] == '123'
    assert set_tree_node(t, 'a:b', '789') == {'b': '789'}
    assert t['a']['b'] == '789'
    assert get_tree_node(t, 'a:b') == '789'



# Generated at 2022-06-24 03:20:18.612183
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    reg = RegistryTree()



# Generated at 2022-06-24 03:20:29.152924
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    # Empty Tree
    t = Tree()
    # No Keys
    assert len(t) == 0
    # One Key
    t.__setitem__('foo', 'bar')
    assert len(t) == 1
    # Two keys, one namespace
    t.namespace = 'baz'
    t.__setitem__('foo', 'bar')
    assert t['baz:foo'] == 'bar'
    assert t['foo'] == 'bar'
    # Two keys, two namespaces
    t.namespace = 'baz'
    t.__setitem__('baz:foo', 'bar')
    assert t['baz:foo'] == 'bar'
    assert t['baz:baz:foo'] == 'bar'
    assert t['foo'] == 'bar'
    # Three keys, two namespaces


# Generated at 2022-06-24 03:20:31.729865
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    registry = RegistryTree()

    registry.register(1, 2)
    assert registry[1] == 2

    # Ensure that objects are actually equal
    assert registry == registry



# Generated at 2022-06-24 03:20:39.822895
# Unit test for constructor of class Tree
def test_Tree():
    import pprint

    # Initialize tree with a dictionary
    tree = Tree({'a': {'a1': {'a1a': 'a1a_value'},
                       'a2': 'a2_value'},
                 'b': {'b1': 'b1_value'}})

    # Test get via __getitem__
    assert tree['a:a1:a1a'] == 'a1a_value'
    assert tree['a:a2'] == 'a2_value'
    assert tree['b:b1'] == 'b1_value'

    # Test get via get
    assert tree.get('a:a1:a1a') == 'a1a_value'
    assert tree.get('a:a2') == 'a2_value'

# Generated at 2022-06-24 03:20:46.644755
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    tree = Tree(initial=tree(), namespace='dimm0')
    tree['dimm0:dimm1:node'] = 'node'
    assert tree['dimm0:dimm1:node'] == 'node'

    # Testing namespace overriding
    tree = Tree(initial=tree(), namespace='dimm0')
    tree['dimm0:dimm1:node'] = 'node'

# Generated at 2022-06-24 03:20:52.705530
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree({'a': {'b': {'c': 'd'}}})
    assert t['a:b:c'] == 'd'
    assert t['a:b'] == {'c': 'd'}
    assert t['a'] == {'b': {'c': 'd'}}
    with pytest.raises(KeyError):
        t['foo']



# Generated at 2022-06-24 03:20:55.034893
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    obj = Tree()
    obj.__setitem__('key', 'value')
    return obj['key'] == 'value'


# Generated at 2022-06-24 03:21:04.344647
# Unit test for function set_tree_node
def test_set_tree_node():
    # TODO Use unittest.mock.patch
    test_dict = dict()
    test_dict2 = dict()
    test_dict3 = dict()
    test_dict4 = dict()
    test_dict['test_dict'] = {
        'test_dict2': {
            'test_dict3': {
                'test_dict4': {
                    'test_dict': test_dict,
                    'test_dict2': test_dict2,
                    'test_dict3': test_dict3,
                    'test_dict4': test_dict4,
                },
            },
        },
    }

    set_tree_node(test_dict, 'test_dict:test_dict2:test_dict3:test_dict4:test_dict5', test_dict)

# Generated at 2022-06-24 03:21:07.702815
# Unit test for constructor of class Tree
def test_Tree():
    assert Tree().__class__.__bases__[0] is collections.defaultdict



# Generated at 2022-06-24 03:21:18.667686
# Unit test for constructor of class Tree
def test_Tree():
    from pprint import pprint
    test = Tree({'pylib': {'proc': {'cpu': 'cpu10', 'mem': 'mem20'}, 'ver': '0.1.2'}})
    pprint(test)
    test.register('pylib:proc:cpu', 'cpu1000', namespace='temp')
    pprint(test)
    assert Tree({'temp': {'pylib': {'proc': {'cpu': 'cpu10', 'mem': 'mem20'}, 'ver': '0.1.2'}}}) == test
    pprint(test.get('pylib:proc:mem', namespace='temp'))
    assert test.get('pylib:proc:mem', namespace='temp') == 'mem20'

# Generated at 2022-06-24 03:21:24.838534
# Unit test for function set_tree_node
def test_set_tree_node():
    data = tree()
    data = set_tree_node(data, "foo:bar:baz", 123)
    assert data["foo"]["bar"]["baz"] == 123

    data = set_tree_node(data, "foo:bar:baz", 456)
    assert data["foo"]["bar"]["baz"] == 456

    data = set_tree_node(data, "lorem:ipsum", "dolor")
    assert data["lorem"]["ipsum"] == "dolor"

    data = set_tree_node(data, "lorem:ipsum", "sit")
    assert data["lorem"]["ipsum"] == "sit"



# Generated at 2022-06-24 03:21:28.162228
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    registry = RegistryTree({'foo': 'bar'}, namespace='baz')
    assert registry['baz:foo'] == 'bar'

    # Test namespace
    assert registry['foo'] == 'bar'
    assert 'baz' in registry.namespace
    assert 'foo' in registry.namespace



# Generated at 2022-06-24 03:21:29.588482
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    assert t == {'a': {'b': {'c': 3}}}



# Generated at 2022-06-24 03:21:32.982071
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    from pprint import pprint

    tree = Tree()
    tree['foo:bar:baz'] = 'fubar'
    pprint(dict(tree))
    assert tree['foo:bar:baz'] == 'fubar'



# Generated at 2022-06-24 03:21:37.154667
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    """Unit test for RegistryTree's constructor handling of initial parameter."""
    t = RegistryTree(initial={'foo': 'bar'})
    assert t == {'foo': 'bar'}
    t = RegistryTree(initial_is_ref={'foo': 'bar'})
    assert t == {'foo': 'bar'}

# Generated at 2022-06-24 03:21:42.825554
# Unit test for function tree
def test_tree():
    t = tree()
    t['cat']['dog']['mouse'] = 'mouse:' + repr(id(t))
    t['cat2']['dog2']['mouse2'] = 'mouse2:' + repr(id(t))
    print(t)
    assert t['cat']['dog']['mouse'] == 'mouse:' + repr(id(t))
    assert t['cat']['dog']['mouse'] == 'mouse:' + repr(id(t))



# Generated at 2022-06-24 03:21:46.255016
# Unit test for function tree
def test_tree():
    root = tree()
    root['a']['b'] = 'c'
    assert root['a']['b'] == 'c'

    root = tree()
    root['a:b'] = 'c'
    assert root['a:b'] == 'c'



# Generated at 2022-06-24 03:21:53.401050
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree()

    t.update({'a': {'b': {'c': {'d': 'dee'}}}})
    assert t['a'] == {'b': {'c': {'d': 'dee'}}}
    assert t['a:b'] == {'c': {'d': 'dee'}}
    assert t['a:b:c'] == {'d': 'dee'}
    assert t['a:b:c:d'] == 'dee'

# Generated at 2022-06-24 03:21:59.773075
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree([('foo', {'bar': {'baz': 'qux'}})])
    assert t['foo:bar:baz'] == 'qux'
    t['foo:bar:baz'] = 'qazz'
    assert t['foo:bar:baz'] == 'qazz'

# Generated at 2022-06-24 03:22:08.841000
# Unit test for function set_tree_node
def test_set_tree_node():
    inp = {
        'one': 1,
        'three': {
            'four': 4,
        },
    }

    set_tree_node(inp, 'two', 2)
    assert inp == {
        'one': 1,
        'two': 2,
        'three': {
            'four': 4,
        },
    }

    set_tree_node(inp, 'two:three', 3)
    assert inp == {
        'one': 1,
        'two': {
            'three': 3,
        },
        'three': {
            'four': 4,
        },
    }

    set_tree_node(inp, 'two:three:four', 4)

# Generated at 2022-06-24 03:22:16.751088
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    import random
    # Test method __setitem__ of class Tree
    test_value = random.randint(0, 100)
    test_arr = ['test_one', 'test_two', 'test_three', 'test_four']
    for i in range(100):
        test_key = random.choice(test_arr)
        test_tree = Tree()
        for j in range(4):
            test_tree[test_key] = test_value
        test_tree_expected = dict({'test_one': test_value, 'test_two': test_value,
                                   'test_three': test_value, 'test_four': test_value})
        assert test_tree == test_tree_expected

    # Test method __setitem__ of class Tree with namespace

# Generated at 2022-06-24 03:22:23.350968
# Unit test for function tree
def test_tree():
    tree_ = tree()
    tree_['hello']['world'] = 'foo'
    tree_['there']['you'] = 'bar'
    assert tree_['hello']['world'] == 'foo'
    assert tree_['there']['you'] == 'bar'



# Generated at 2022-06-24 03:22:25.954046
# Unit test for function set_tree_node
def test_set_tree_node():
    result = tree()
    set_tree_node(result, 'foo:bar:baz', 'BAZ')
    assert result['foo']['bar']['baz'] == 'BAZ'



# Generated at 2022-06-24 03:22:32.009485
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    import collections
    import hypothesis
    import hypothesis.strategies as st

    @hypothesis.given(st.lists(elements=st.lists(min_size=2, max_size=2, elements=st.text())))
    def test_Tree___getitem__(lijst):
        mapping = collections.defaultdict(Tree)
        for key, value in lijst:
            mapping[key] = value
        for key, value in lijst:
            assert mapping[key] == value
        return mapping

    test_Tree___getitem__()

# Generated at 2022-06-24 03:22:41.785033
# Unit test for function get_tree_node
def test_get_tree_node():
    from pytest import raises

    mapping = tree()
    mapping['a:a:a']['b:b:b'] = 'c:c:c'
    mapping['a:a:a']['b:b'] = 'c:c'
    mapping['a:a']['b:b'] = 'c:c'
    mapping['a:a']['b'] = 'c'
    mapping['a']['b'] = 'c'
    mapping['a'] = 'c'
    mapping['a']['b']['c']['d']['e']['f']['g']['h']['i']['j']['k']['l']['m']['n'] = 'o'


# Generated at 2022-06-24 03:22:45.975405
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    instance = Tree()
    _key = 'somekey'
    _value = 'somevalue'
    _namespace = 'somenamespace'
    instance.__setitem__(_key, _value, namespace=_namespace)
    _key = '%s:%s' % (_namespace, _key)
    result = instance[_key]
    assert result == _value



# Generated at 2022-06-24 03:22:47.667045
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    rt = RegistryTree()
    rt.register('x', 50)
    assert rt['x'] == 50

# Generated at 2022-06-24 03:22:52.324987
# Unit test for function set_tree_node
def test_set_tree_node():
    data = {}

    node = set_tree_node(data, 'one:two:three:four', 'FOUR')
    assert dict(node) == dict(one=dict(two=dict(three=dict(four='FOUR'))))



# Generated at 2022-06-24 03:22:59.344906
# Unit test for function set_tree_node
def test_set_tree_node():
    mapping = {'foo': {}, 'bar': {}, }
    set_tree_node(mapping, 'foo:bar', {'junk': 'junk'})
    assert mapping['foo']['bar'] == {'junk': 'junk'}

    mapping = {'foo': {'bar': 'junk', }, }
    assert mapping['foo']['bar'] == 'junk'
    set_tree_node(mapping, 'foo:bar', {'ham': 'spam'})
    assert mapping['foo']['bar'] == {'ham': 'spam'}



# Generated at 2022-06-24 03:23:10.026596
# Unit test for function tree
def test_tree():
    tree = tree()
    tree['a'] = {'b': 0, 'c': 1}
    tree['b'] = {'c': 2, 'd': 3}
    assert tree['a:b'] == 0
    assert tree['a:c'] == 1
    assert tree['b:c'] == 2
    assert tree['b:d'] == 3
    assert tree['a:b:c:d'] == {}


# Test for class Tree
if __name__ == '__main__':
    test_tree()

    tree = Tree()
    tree['a'] = {'b': 0, 'c': 1}
    tree['b'] = {'c': 2, 'd': 3}
    assert tree['a:b'] == 0
    assert tree['a:c'] == 1
    assert tree['b:c'] == 2

# Generated at 2022-06-24 03:23:14.082897
# Unit test for function get_tree_node
def test_get_tree_node():
    """Test function get_tree_node"""
    assert get_tree_node({'a': {'b': {'c': 42}}}, 'a:b:c') == 42
    with pytest.raises(KeyError):
        get_tree_node({'a': {'b': {'c': 42}}}, 'a:b:c:d')



# Generated at 2022-06-24 03:23:21.578471
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    import unittest

    class RegistryTreeTestCase(unittest.TestCase):

        def setUp(self):
            self.tree = RegistryTree({'foo': {'bar': {'baz': 1}}})

        def test_basic_registration(self):
            expected = {'foo': {'bar': {'baz': 1, 'bat': 2}}}
            self.tree.register('foo:bar:bat', 2)
            self.assertEqual(self.tree, expected)

        def test_basic_registration_empty_namespace(self):
            expected = {'foo': {'bar': {'baz': 1, 'bat': 2}}}
            self.tree.register('bar:bat', 2, namespace='')
            self.assertEqual(self.tree, expected)

    unittest.main()

# Generated at 2022-06-24 03:23:26.107370
# Unit test for function set_tree_node
def test_set_tree_node():
    # Arrange
    t = tree()
    # Act
    set_tree_node(t, 'level1:level2', True)
    # Assert
    assert t['level1']['level2'] is True



# Generated at 2022-06-24 03:23:32.745869
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    item = t['hello country 0'] = 'hello country 0 value'
    assert t['hello country 0'] == item
    assert t['hello county 0'] == item
    assert t['hello country 0'] == 'hello country 0 value'
    assert t['hello county 0'] == 'hello country 0 value'
    return True


if __name__ == '__main__':

    assert test_Tree___setitem__()

# Generated at 2022-06-24 03:23:34.859517
# Unit test for constructor of class Tree
def test_Tree():
    t = Tree()
    assert t == {}
    t['a'] = 1
    assert t == {'a': 1}


# Generated at 2022-06-24 03:23:38.144268
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    t = Tree()
    t['a:b:c'] = 'hello'
    assert t['a:b:c'] == 'hello'
    assert t.get('a:b:c') == 'hello'



# Generated at 2022-06-24 03:23:41.329176
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    t['a:b:c'] = 'd'
    assert t['a']['b']['c'] == 'd'
    assert t['a:b']['c'] == 'd'



# Generated at 2022-06-24 03:23:47.633958
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    from unittest import TestCase

    t = Tree()
    t['a'] = 'b'
    t['a:b'] = 'c'
    TestCase().assertEqual(t['a'], 'b')
    TestCase().assertEqual(t['a']['b'], 'c')
    TestCase().assertEqual(t['a:b'], 'c')



# Generated at 2022-06-24 03:23:51.325487
# Unit test for constructor of class Tree
def test_Tree():
    """Ensure that constructor argument 'initial_is_ref' works correctly"""
    data = {'a': 'b'}
    t = Tree(data, initial_is_ref=True)
    data['a'] = 'c'
    assert t['a'] == 'c', 'data object was not used as reference'



# Generated at 2022-06-24 03:23:56.710637
# Unit test for constructor of class RegistryTree
def test_RegistryTree():
    r = RegistryTree()
    r.register('fruit:apples', 'crisp')
    r.register('fruit:oranges', 'juicy')
    r.register('vegetables:potatoes', 'starchy')
    r.register('vegetables:tomatoes', 'red')

    # Unit test for class RegistryTree:
    assert r['fruit:apples'] == 'crisp'
    assert r['fruit:oranges'] == 'juicy'
    assert r['vegetables:potatoes'] == 'starchy'
    assert r['vegetables:tomatoes'] == 'red'

# Generated at 2022-06-24 03:24:01.690247
# Unit test for method __setitem__ of class Tree
def test_Tree___setitem__():
    t = Tree()
    t['a'] = 1
    t['a:b'] = 2
    t['a:b:c'] = 3
    t['a:b:d'] = 4
    t['a:e'] = 5

    print(t)
    # {'a': {'b': {'d': 4, 'c': 3}, 'e': 5}}



# Generated at 2022-06-24 03:24:07.256712
# Unit test for method __getitem__ of class Tree
def test_Tree___getitem__():
    instance = Tree()
    instance.__setitem__('a', '1', namespace='ns')
    assert_equal(instance.__getitem__('a', namespace='ns'), '1')
    assert_equal(instance.get('a', namespace='ns'), '1')
    assert_equal(instance['a'], '1')
    #instance.get('b')

