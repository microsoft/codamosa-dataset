

# Generated at 2022-06-25 05:44:56.372553
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition_0 = RoleDefinition()
    dict_0 = dict()
    dict_0['role'] = 'nginx'
    dict_0['sudo'] = True
    dict_0['connection'] = 'local'
    dict_0['extra_var'] = 'extra_var'
    dict_0['var1'] = 'var1'
    dict_0['var2'] = 'var2'
    dict_0['var3'] = 'var3'
    dict_0['tags'] = 'tags'
    dict_0['when'] = 'when'
    dict_0['address'] = 'address'
    dict_0['port'] = 'port'
    role_definition_0.post_validate(dict_0, dict())
    dict_1 = dict()
    dict_1['role'] = 'nginx'

# Generated at 2022-06-25 05:45:06.494329
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition_0 = RoleDefinition()
    # Call method preprocess_data of role_definition_0 with param ds = "{'role': 'foobar'}"
    # result = role_definition_0.preprocess_data(ds = "{'role': 'foobar'}")
    print('Testing unit test for method preprocess_data of class RoleDefinition')
    print("role_definition_0")
    print("Test 1/1:")
    # print("result:")
    # print("Test 1/1:")
    # print("result:")
    # print("None")
    # role_definition_0.preprocess_data(ds = "{'role': 'foobar'}")
    print("None")
    print("result:")
    print("None")
    print("Expected result:")
    print("None")

# Generated at 2022-06-25 05:45:07.984991
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    role_definition_0 = RoleDefinition()
    var_0 = role_definition_0.get_name()
    assert var_0 == None


# Generated at 2022-06-25 05:45:10.607269
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    role_definition_0 = RoleDefinition()
    var_0 = role_definition_0.get_name()
    # var_0 == None
    assert var_0 is not None, "var_0 == None"

# Generated at 2022-06-25 05:45:12.534683
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    st = AnsibleMapping()
    t1 = st.preprocess_data(st)
    assert True


# Generated at 2022-06-25 05:45:21.656370
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition = RoleDefinition()
    role_definition._variable_manager = object
    # FIXME: what should be used for templar?
    role_definition.templar = object
    role_definition.loader = object
    role_definition.loader.path_exists = object
    role_definition.loader.path_exists.return_value = True
    role_definition._loader = object
    role_definition._loader.get_basedir = object
    role_definition._loader.get_basedir.return_value = 'return_value'
    role_definition._role_basedir = '_role_basedir'
    role_definition._valid_attrs = dict()

    ds_1 = dict()
    ds_1['name'] = 'value'

# Generated at 2022-06-25 05:45:24.322791
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition_0 = RoleDefinition()
    ds = dict()
    role_definition_0.preprocess_data(ds)
    return role_definition_0


# Generated at 2022-06-25 05:45:33.929442
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition_0 = RoleDefinition()
    role_definition_1 = RoleDefinition()
    role_definition_2 = RoleDefinition()
    role_definition_3 = RoleDefinition()
    role_definition_4 = RoleDefinition()
    role_definition_5 = RoleDefinition()
    role_definition_6 = RoleDefinition()
    role_definition_7 = RoleDefinition()
    role_definition_8 = RoleDefinition()
    role_definition_9 = RoleDefinition()
    role_definition_10 = RoleDefinition()
    role_definition_11 = RoleDefinition()
    role_definition_12 = RoleDefinition()
    role_definition_13 = RoleDefinition()
    role_definition_14 = RoleDefinition()
    role_definition_15 = RoleDefinition()
    role_definition_16 = RoleDefinition()
    role_definition_17 = RoleDefinition()
   

# Generated at 2022-06-25 05:45:39.824762
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    # Test for a case with a file name for the role
    role_definition_1 = RoleDefinition()
    var_1 = role_definition_1.preprocess_data('my_role')
    assert var_1['role'] == 'my_role'

    # Test for a case with a file name for the role
    role_definition_2 = RoleDefinition()
    var_2 = role_definition_2.preprocess_data(42)
    assert var_2['role'] == 42

# Generated at 2022-06-25 05:45:46.611232
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    role_definition0 = RoleDefinition()
    str_val0 = role_definition0.get_name()
    role_definition1 = RoleDefinition()
    str_val1 = role_definition1.get_name(bool_val0=True)
    str_val2 = role_definition1.get_name(include_role_fqcn=True)
    str_val3 = role_definition1.get_name(include_role_fqcn=True)
    str_val4 = role_definition1.get_name(bool_val1=True)
    str_val5 = role_definition1.get_name(bool_val2=True)
    str_val6 = role_definition1.get_name(include_role_fqcn=bool_val0)
    str_val7 = role_definition1.get_

# Generated at 2022-06-25 05:46:04.459392
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    ansible_mapping_0 = module_0.AnsibleMapping()
    ansible_mapping_0.ansible_pos = '10:2:2'
    variable_manager_0 = None
    loader_0 = None
    collection_list_0 = None
    role_definition_0 = RoleDefinition(role_basedir=None, variable_manager=variable_manager_0, loader=loader_0, collection_list=collection_list_0)
    assert role_definition_0.preprocess_data(ansible_mapping_0) == ansible_mapping_0

# Generated at 2022-06-25 05:46:13.995677
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    # Preprocessed data is not available for this test case
    # Note: AnsibleMapping is a subclass of AnsibleBaseYAMLObject, so either can be used
    ansible_mapping_0 = module_0.AnsibleMapping()
    ansible_mapping_0.ansible_pos = (0, 0, 0)
    ansible_mapping_0.ansible_line_number = 1
    ansible_mapping_0['role'] = 'test_role'
    ansible_mapping_0['when'] = 'test_when'
    ansible_mapping_0['something_else'] = 'test_something_else'
    variable_manager = None
    loader = None
    collection_list = ['test_collection']

# Generated at 2022-06-25 05:46:18.672665
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    ansible_mapping_0 = module_0.AnsibleMapping()
    ansible_mapping_0._ds = ansible_mapping_0
    role_definition_0 = RoleDefinition(role_basedir=ansible_mapping_0)
    role_definition_0._variable_manager = ansible_mapping_0
    role_definition_0._role_basedir = ansible_mapping_0
    role_definition_0._ds = ansible_mapping_0
    ansible_mapping_0.preprocess_data(ansible_mapping_0)


# Generated at 2022-06-25 05:46:20.865444
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    ansible_mapping_0 = module_0.AnsibleMapping()
    print(ansible_mapping_0)
    role_definition_1 = RoleDefinition(None, None, None, None, None)
    print(role_definition_1)
    role_definition_1.preprocess_data(ansible_mapping_0)


# Generated at 2022-06-25 05:46:25.475984
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_basedir = os.path.dirname(__file__)
    role_definition_0 = RoleDefinition(role_basedir=role_basedir)
    module_0.AnsibleMapping
    ds = ansible_mapping_0
    role_definition_0.preprocess_data(ds)


# Generated at 2022-06-25 05:46:34.907064
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    ansible_mapping_0 = module_0.AnsibleMapping()
    assert type(ansible_mapping_0) == module_0.AnsibleMapping
    ansible_mapping_0.foo = "foo"
    assert ansible_mapping_0.foo == "foo"
    ansible_mapping_0.role = "role"
    assert ansible_mapping_0.role == "role"
    ansible_mapping_0.name = "name"
    assert ansible_mapping_0.name == "name"
    ansible_mapping_0.bar = 1
    assert ansible_mapping_0.bar == 1
    assert isinstance(ansible_mapping_0, dict) == True

# Generated at 2022-06-25 05:46:41.896769
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    test_case_0()
    test_obj = RoleDefinition()
    # AttributeName(value:None,missing:False,default:None,fallback:None,nullable:False,required:False,is_value:False,is_collection:False,is_sequence:False,is_scalar:False,is_boolean:False,is_numeric:False,is_string:False,choices:None,has_choices:False,allow_duplicates:False,is_hash:False,is_path:False,is_file:False,is_directory:False,is_object:False,is_datetime:False,is_unix_socket:False,is_alias:False,is_ipv4:False,is_ipv6:False,is_port:False,help:None,label:None,is_

# Generated at 2022-06-25 05:46:47.857019
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():

    # Create a mock object representing a role definition
    role = RoleDefinition(role_basedir = 'ROLEDIR', variable_manager = None, loader = None, collection_list = None)

    # Test the method with a valid role definition
    try:
        role.get_name(include_role_fqcn = True)
    except:
        pass


# Generated at 2022-06-25 05:46:53.208634
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    obj = RoleDefinition(display, role_basedir, variable_manager, loader)
    assert obj.get_name(include_role_fqcn=True) == '.'
    assert obj.get_name(include_role_fqcn=False) == ''

# Generated at 2022-06-25 05:47:00.379675
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    ansible_mapping_0 = module_0.AnsibleMapping()
    role_definition_0 = RoleDefinition(ds=ansible_mapping_0)
    include_role_fqcn_0 = unittest.mock.Mock()
    expected_result_0 = "expected_result_0"
    unittest.mock.patch.object(role_definition_0, 'get_name', return_value=expected_result_0).start()
    actual_result_0 = role_definition_0.get_name(include_role_fqcn=include_role_fqcn_0)
    assert actual_result_0 == expected_result_0

# Generated at 2022-06-25 05:47:14.456207
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():

    # Calls to AnsibleError during the yaml parsing would have raised
    # if a problem was found.  We don't expect this to be a problem
    # here, but we will catch and report the exception, just in case

    try:
        # First, with a default role (no changes)
        defaults = RoleDefinition.load("test_role_name")
    except AnsibleError as e:
        display.error("An exception was raised: %s" % str(e))
        raise

    assert defaults._role == "test_role_name"
    assert defaults._role_path == "test_role_name (not a real path)"
    assert defaults._ds == "test_role_name"
    assert defaults._role_params == dict()


# Generated at 2022-06-25 05:47:18.148354
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    modifier = 'preprocess_data'
    cls_bases_0 = (object,)
    cls_dict_0 = {
        '__module__': module_0.__name__,
        'preprocess_data': module_0.preprocess_data,
    }
    class_definition_0 = type('AnsibleMapping', cls_bases_0, cls_dict_0)
    param_0 = None
    obj_0 = class_definition_0.__new__(class_definition_0, param_0)
    obj_0.preprocess_data(modifier)


# Generated at 2022-06-25 05:47:22.677192
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    ansible_errors_1 = AnsibleError()
    ansible_errors_2 = AnsibleError()
    ansible_errors_3 = AnsibleError()
    role_definition_0 = RoleDefinition()
    test_ds = dict()
    test_ds = ansible_mapping_0
    test_ds = ansible_errors_1
    test_ds = ansible_errors_2
    test_ds = ansible_errors_3
    try:
        role_definition_0.preprocess_data(test_ds)
    except TypeError:
        pass
    else:
        assert False


# Generated at 2022-06-25 05:47:31.948387
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    ansible_mapping_0 = module_0.AnsibleMapping()
    ansible_mapping_0.ansible_pos = "test string"
    role_name_0 = "test string"
    role_name_1 = "test string"
    role_path_0 = "test string"
    role_search_paths_0 = ["test string", ]
    role_params_0 = {'a': 1, }
    role_def_0 = {"role": role_name_1, }
    ansible_mapping_1 = module_0.AnsibleMapping()
    ansible_mapping_1.ansible_pos = "test string"
    role_name_2 = "test string"
    role_path_1 = "test string"

# Generated at 2022-06-25 05:47:36.612103
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    ansible_mapping_0 = AnsibleMapping()


if __name__ == '__main__':
    ansible_mapping_0 = AnsibleMapping()
    test_case_0()

# Generated at 2022-06-25 05:47:40.191794
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    # Create a new instance of class RoleDefinition
    x = RoleDefinition()

    # Check if the method preprocess_data raises a AnsibleError exception
    # when called with argument ds = ansible_mapping_0.
    # (The exception is expected because the role name is missing)
    with pytest.raises(AnsibleError):
        assert x.preprocess_data(ansible_mapping_0)


# Generated at 2022-06-25 05:47:41.764682
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    ansible_mapping_1 = module_0.AnsibleMapping()
    role_definition_0 = RoleDefinition.load(ansible_mapping_1)
    role_definition_0.get_name()

# Generated at 2022-06-25 05:47:43.292710
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition = RoleDefinition()
    role_definition._loader = 'test-loader'
    role_definition.preprocess_data(ds)

# Generated at 2022-06-25 05:47:44.328898
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    obj = RoleDefinition()
    obj.preprocess_data('')

# Generated at 2022-06-25 05:47:53.881479
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    # Setup
    ansible_mapping_0 = module_0.AnsibleMapping()
    ansible_mapping_1 = module_0.AnsibleMapping()
    ansible_mapping_2 = module_0.AnsibleMapping()
    ansible_mapping_2.ansible_pos = None
    ansible_mapping_3 = module_0.AnsibleMapping()
    ansible_mapping_3.ansible_pos = None
    ansible_mapping_4 = module_0.AnsibleMapping()
    ansible_mapping_4.ansible_pos = None
    ansible_mapping_5 = module_0.AnsibleMapping()
    ansible_mapping_5.ansible_pos = None
    # TODO: Update the reference values for Ans

# Generated at 2022-06-25 05:48:06.125007
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    ansible_mapping_0 = module_0.AnsibleMapping()
    ansible_mapping_1 = module_0.AnsibleMapping()
    ansible_mapping_2 = module_0.AnsibleMapping()
    ansible_mapping_3 = module_0.AnsibleMapping()
    ansible_mapping_4 = module_0.AnsibleMapping()

    role_definition_0 = RoleDefinition()
    role_definition_0._role_params = ansible_mapping_4

    role_definition_0.preprocess_data(ansible_mapping_0)

    assert(role_definition_0._role_params == ansible_mapping_4)

# Generated at 2022-06-25 05:48:14.458576
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    ansible_mapping_2 = module_0.AnsibleMapping()
    ansible_mapping_1 = module_0.AnsibleMapping()
    role_definition_1 = RoleDefinition()
    ansible_mapping_1.update(ansible_mapping_2)
    # Make sure the preprocess_data function is not implemented
    assert not hasattr(role_definition_1, 'preprocess_data'), "The `preprocess_data` function should not be implemented."

import ansible.utils.collection_loader as module_1


# Generated at 2022-06-25 05:48:25.550010
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    ansible_mapping_0 = module_0.AnsibleMapping()
    ansible_mapping_0.ansible_pos = None

    # Testing when parameter 'ds' is of the type <class 'str'>
    role_def_0 = RoleDefinition(play=None, role_basedir=None, variable_manager=None, loader=None, collection_list=None)
    ansible_mapping_0['role'] = 'role_name_0'
    assert ansible_mapping_0['role'] == role_def_0._load_role_name(ds='role_name_0')
    assert (role_def_0.preprocess_data(ds='role_name_0') == ansible_mapping_0)

    # Testing when parameter 'ds' is of the type <class 'ansible.parsing

# Generated at 2022-06-25 05:48:34.272154
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    print("CREATE_TEST_CASE ( role_definition_0.py :: 'RoleDefinition_get_name' )")
    ansible_mapping_0 = module_0.AnsibleMapping()
    variable_manager_0 = {
    }
    test_instance_0 = RoleDefinition(
        ds=ansible_mapping_0,
        variable_manager=variable_manager_0
    )
    print("  ASSERTION PASSED ( role_definition_0.py :: 'RoleDefinition_get_name' )")


# Generated at 2022-06-25 05:48:43.171427
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    definition_0 = RoleDefinition()
    definition_0.role = 'string'
    ds_0 = definition_0.role
    new_ds_0 = definition_0.preprocess_data(ds_0)
    assert new_ds_0 == 0
    role_name_0 = definition_0.role
    definition_0.role = 'string'
    role_name_0 = definition_0.role
    definition_0._role_params = {}
    all_vars_0 = definition_0._variable_manager.get_vars()
    templar_0 = Templar(loader=definition_0._loader, variables=all_vars_0)
    role_name_0 = templar_0.template(role_name_0)
    definition_0.role = role_name_0
    ds_

# Generated at 2022-06-25 05:48:48.452364
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    ansible_mapping_0 = module_0.AnsibleMapping()
    roledef = RoleDefinition(ds=ansible_mapping_0)
    roledef.role = 'foo'
    roledef._role_collection = None
    result = roledef.get_name()
    assert result == 'foo'


# Generated at 2022-06-25 05:48:52.549817
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    ansible_mapping_0 = module_0.AnsibleMapping()
    role_definition_0 = RoleDefinition(ansible_mapping_0)
    name_0 = role_definition_0.get_name()


# Generated at 2022-06-25 05:48:53.985742
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    preprocess_data_0 = test_case_0
    assert preprocess_data_0 == None, 'preprocess_data_0 is None'


# Generated at 2022-06-25 05:48:56.505649
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    ansible_mapping_0 = module_0.AnsibleMapping()
    ansible_mapping_0.role = "ansible.legacy"
    role_definition_0 = RoleDefinition(ansible_mapping_0, None, None, None)
    if False:
        raise Exception('AssertionError')

# Generated at 2022-06-25 05:49:07.478045
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    '''
    Unit test for method preprocess_data of class RoleDefinition
    '''

# Generated at 2022-06-25 05:49:13.785684
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    role_definition_0 = RoleDefinition()
    role_definition_0.get_name()


# Generated at 2022-06-25 05:49:18.128599
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    ansible_mapping_0 = module_0.AnsibleMapping()
    game_0 = RoleDefinition()
    dict_0 = dict()
    game_0.preprocess_data(dict_0)

if __name__ == '__main__':
    test_case_0()
    test_RoleDefinition_preprocess_data()

# Generated at 2022-06-25 05:49:23.679319
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    ##############################
    # RoleDefinition.preprocess_data

    # FIXME: Not a complete test

    # FIXME: Valid calls to RoleDefinition.preprocess_data with correct parameters
    # FIXME: Invalid calls to RoleDefinition.preprocess_data with correct parameters

    raise AnsibleAssertionError()

# Generated at 2022-06-25 05:49:32.057147
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    ansible_mapping_0 = module_0.AnsibleMapping()
    ansible_mapping_1 = module_0.AnsibleMapping()
    ansible_mapping_2 = module_0.AnsibleMapping()
    ansible_mapping_3 = module_0.AnsibleMapping()
    ansible_mapping_4 = module_0.AnsibleMapping()
    ansible_mapping_5 = module_0.AnsibleMapping()
    ansible_mapping_6 = module_0.AnsibleMapping()
    ansible_mapping_7 = module_0.AnsibleMapping()
    ansible_mapping_8 = module_0.AnsibleMapping()
    ansible_mapping_9 = module_0.AnsibleMapping()

# Generated at 2022-06-25 05:49:36.813751
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    print('Testing RoleDefinition.preprocess_data')
    RoleDefinition_instance = RoleDefinition()
    try:
        ansible_mapping_0 = module_0.AnsibleMapping()
        RoleDefinition_instance.preprocess_data(ansible_mapping_0)
    except AnsibleAssertionError as e:
        print('AnsibleAssertionError: ' + str(e))
        # Exception Caught
    try:
        ansible_mapping_0 = module_0.AnsibleMapping()
        RoleDefinition_instance.preprocess_data(ansible_mapping_0)
    except AnsibleAssertionError as e:
        print('AnsibleAssertionError: ' + str(e))
        # Exception Caught

# Generated at 2022-06-25 05:49:40.163125
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    background_0 = RoleDefinition()
    ds_0 = None
    background_0.preprocess_data(ds_0)

if __name__ == '__main__':
    test_case_0()
    test_RoleDefinition_preprocess_data()

# Generated at 2022-06-25 05:49:47.540392
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    ansible_mapping_0_0 = module_0.AnsibleMapping()
    ansible_mapping_0_1 = module_0.AnsibleMapping()

    my_role_definition = RoleDefinition()
    result = my_role_definition.preprocess_data(ansible_mapping_0_0)
    assert result == ansible_mapping_0_1

# Generated at 2022-06-25 05:49:52.170844
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    ansible_mapping_0 = module_0.AnsibleMapping()
    role_definition_0 = RoleDefinition(collection_list=ansible_mapping_0)
    string_0 = role_definition_0.get_name(False)


# Generated at 2022-06-25 05:49:57.613770
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    ansible_mapping_0 = module_0.AnsibleMapping()
    role_definition_0 = RoleDefinition()
    role_definition_0.preprocess_data(ansible_mapping_0)


# Generated at 2022-06-25 05:50:00.167113
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    # Has no attribute _variable_manager
    with pytest.raises(AttributeError):
        role_definition_0 = RoleDefinition()
        res = role_definition_0.preprocess_data(test_case_0())


# Generated at 2022-06-25 05:50:15.752129
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    ansible_mapping_0 = module_0.AnsibleMapping()
    ansible_mapping_0 = module_0.AnsibleMapping()
    ansible_mapping_0 = module_0.AnsibleMapping()
    ansible_mapping_0 = module_0.AnsibleMapping()
    ansible_mapping_0 = module_0.AnsibleMapping()
    ansible_mapping_0 = module_0.AnsibleMapping()
    ansible_mapping_0 = module_0.AnsibleMapping()
    ansible_mapping_0 = module_0.AnsibleMapping()
    ansible_mapping_0 = module_0.AnsibleMapping()
    ansible_mapping_0 = module_0.AnsibleMapping()

# Generated at 2022-06-25 05:50:23.564948
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    ansible_mapping_1 = module_0.AnsibleMapping()
    ansible_mapping_2 = module_0.AnsibleMapping()
    ansible_mapping_2.update({'role': 'role_4'})
    ansible_mapping_1.ansible_pos = [1,2]
    role_definition_0 = RoleDefinition()
    role_definition_0._ds = ansible_mapping_1
    role_definition_0._loader = 'loader_0'
    role_definition_0._role_basedir = 'role_basedir_0'
    role_definition_0._play = 'play_0'
    role_definition_0._variable_manager = 'variable_manager_0'


# Generated at 2022-06-25 05:50:29.556099
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    ansible_mapping_0 = module_0.AnsibleMapping()

    # 1
    role_definition_0 = RoleDefinition()
    with pytest.raises(AnsibleAssertionError) as exception_0:
        role_definition_0.preprocess_data(ansible_mapping_0)
    assert exception_0.match('isinstance')


# Generated at 2022-06-25 05:50:41.188192
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    ansible_mapping_0 = module_0.AnsibleMapping()
    loader_1 = None
    variable_manager_1 = None
    role_basedir_1 = None
    collection_list_1 = None

    role_definition_0 = RoleDefinition(play=None, role_basedir=role_basedir_1, variable_manager=variable_manager_1, loader=loader_1, collection_list=collection_list_1)
    ds_1 = ansible_mapping_0

    try:
        role_definition_0.preprocess_data(ds=ds_1)

    except AttributeError as ex_0:
        assert ex_0.args[0] == 'The preprocess_data() method is not available on this class. You must define it yourself.'

# Generated at 2022-06-25 05:50:46.902379
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    ansible_mapping_0 = module_0.AnsibleMapping()
    role_definition_0 = RoleDefinition()
    ansible_mapping_1 = role_definition_0.preprocess_data(ansible_mapping_0)


if __name__ == "__main__":
    import sys
    import traceback

    try:
        main_ret = main()
    except (EOFError, KeyboardInterrupt):
        main_ret = 1
    except SystemExit as se:
        main_ret = se.code
    except Exception as e:
        traceback.print_exc(file=sys.stdout)
        main_ret = 1

    sys.exit(main_ret)

# Generated at 2022-06-25 05:50:56.139715
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    ansible_mapping_0 = module_0.AnsibleMapping()
    ansible_mapping_0.ansible_pos = "This is for testing"
    ansible_mapping_1 = module_0.AnsibleMapping()
    ansible_mapping_1.ansible_pos = "This is for testing"
    ansible_mapping_1['role'] = "nfs"

    role_definition_0 = RoleDefinition(play = None, role_basedir = None, variable_manager = None, loader = None, collection_list = None)

    assert role_definition_0._load_role_path('nfs') == ('nfs', '/etc/ansible/roles/nfs')


# Generated at 2022-06-25 05:50:57.124356
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    obj = RoleDefinition()
    obj.preprocess_data(int)



# Generated at 2022-06-25 05:51:06.159787
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    ansible_mapping_0 = module_0.AnsibleMapping()
    role_definition_0 = RoleDefinition()
    role_definition_0.role = 'test_role'
    role_definition_0._role_collection = 'test_collection'
    assert role_definition_0.get_name(True) == 'test_collection.test_role'
    assert role_definition_0.get_name(False) == 'test_role'

# Local Variables:
# # tab-width:4
# # indent-tabs-mode:nil
# # End:
# vim: set syntax=python expandtab tabstop=4 shiftwidth=4:

# Generated at 2022-06-25 05:51:14.602115
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    # Initialize the class
    role_definition_0 = RoleDefinition()
    # Expecting no exception here
    role_definition_0.preprocess_data(0)
    # Check for exception
    try:
        role_definition_0.preprocess_data(ansible_mapping_0)
    except Exception:
        pass
    # Initialize the class
    role_definition_1 = RoleDefinition()
    # Expecting no exception here
    role_definition_1.preprocess_data('vars')
    # Check for exception
    try:
        role_definition_1.preprocess_data(ansible_mapping_0)
    except Exception:
        pass



# Generated at 2022-06-25 05:51:20.533172
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    ansible_mapping_1 = module_0.AnsibleMapping()
    ansible_mapping_1.ansible_pos = tuple()
    ansible_mapping_1['role'] = 'role'



if __name__ == '__main__':
    #import ansible.parsing.yaml.objects as module_0
    #ansible_mapping_0 = module_0.AnsibleMapping()
    ansible_role_definition_0 = RoleDefinition()

    test_case_0()
    #test_RoleDefinition_preprocess_data()

# Generated at 2022-06-25 05:51:33.101902
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    ansible_mapping_0 = module_0.AnsibleMapping()
    ansible_mapping_0.ansible_pos = None
    ansible_mapping_0.ansible_line = None
    ansible_mapping_0.ansible_column = None
    ansible_mapping_0.ansible_key = None
    ansible_mapping_0.ansible_value = None
    ansible_mapping_0.ansible_comment = None
    ansible_mapping_0.ansible_empty = None
    ansible_mapping_0.ansible_unskipped = None


# Generated at 2022-06-25 05:51:34.297741
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    pass


# Generated at 2022-06-25 05:51:41.645358
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    rd = RoleDefinition()
    ds = dict()
    assert rd._load_role_name(ds) == None
    assert rd._load_role_path("") == ('', None)
    assert rd._split_role_params(ds) == (dict(), dict())
    assert rd.get_role_params() == dict()
    assert rd.get_role_path() == None
    assert rd.get_name(True) == ''

# Generated at 2022-06-25 05:51:45.218167
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    argument = {}
    argument['variable_manager'] = None
    argument['role_basedir'] = None
    argument['loader'] = None
    argument['collection_list'] = None
    argument['play'] = None
    assert False


# Generated at 2022-06-25 05:51:49.035203
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    ansible_mapping_0 = test_case_0()

    role_definition_0 = RoleDefinition(ansible_mapping_0)
    role_definition_1 = RoleDefinition(ansible_mapping_0)

    assert role_definition_0.get_name() == role_definition_1.get_name()


# Generated at 2022-06-25 05:51:50.739805
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():

    # FIXME: test case is blocked by unresolved dependencies
    pass


# Generated at 2022-06-25 05:51:53.041341
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    role = RoleDefinition(variable_manager=None, loader=None, play=None)
    assert role.get_name() == '<no name set>'


# Generated at 2022-06-25 05:51:57.848993
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    ansible_mapping_0 = module_0.AnsibleMapping()
    ansible_mapping_0.ansible_pos = 'test'
    obj_RoleDefinition_0 = RoleDefinition(collection_list='test', loader='test', play='test', role_basedir='test', variable_manager='test')
    a = obj_RoleDefinition_0.preprocess_data(ansible_mapping_0)
    assert a == ansible_mapping_0

# Generated at 2022-06-25 05:52:04.610883
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    class_0 = RoleDefinition()

    ansible_mapping_0 = module_0.AnsibleMapping()
    ansible_mapping_0.ansible_pos = module_0.AnsibleBaseYAMLObject(0, 1, 2)
    str_0 = 'str'
    role_definition_0 = class_0.preprocess_data(str_0)
    assert isinstance(class_0, class_0.__class__)
    assert isinstance(role_definition_0, ansible_mapping_0.__class__)
    assert isinstance(role_definition_0, role_definition_0.__class__)
    assert isinstance(role_definition_0, role_definition_0.__class__)

# Generated at 2022-06-25 05:52:05.412152
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    test_case_0()

# Generated at 2022-06-25 05:52:17.413841
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition = RoleDefinition()
    role_definition.preprocess_data("test")
    role_definition.preprocess_data("test", "var")
    role_definition.preprocess_data("test", "var", "value")
    role_definition.preprocess_data("test", "var", "value", "template")
    role_definition.preprocess_data("test", "var", "value", "template", "var1")
    role_definition.preprocess_data({"test": "test"})
    role_definition.preprocess_data({"test": "test"}, "var")
    role_definition.preprocess_data({"test": "test"}, "var", "value")
    role_definition.preprocess_data({"test": "test"}, "var", "value", "template")
    role_definition.preprocess

# Generated at 2022-06-25 05:52:19.308913
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    x = RoleDefinition()
    ds = AnsibleMapping()
    ds['role'] = 'test'
    actual_result = x.preprocess_data(ds=ds)
    expected_result = AnsibleMapping()
    expected_result['role'] = 'test'
    assert actual_result == expected_result

# Generated at 2022-06-25 05:52:24.862517
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition_1 = RoleDefinition()
    ds1 = dict()
    ds1['role'] = 'some.collection.role'

    role_definition_2 = RoleDefinition()
    ds2 = dict()
    ds2['role'] = 'some.collection.role'
    ds2['my'] = 'a'
    ds2['parameters'] = 'for the role'

    role_definition_3 = RoleDefinition()
    ds3 = dict()
    ds3['some.collection.role'] = dict()
    ds3['some.collection.role']['my'] = 'parameters'
    ds3['some.collection.role']['are'] = 'here'

    role_definition_4 = RoleDefinition()
    ds4 = dict()

# Generated at 2022-06-25 05:52:28.104799
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    role_definition_0 = RoleDefinition()
    role_definition_0.role = 'test_value'
    print("test: %s" % role_definition_0.get_name())

test_RoleDefinition_get_name()

# Generated at 2022-06-25 05:52:32.080851
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    """RoleDefinition: unit test for preprocess_data method"""

    # describe what we are testing as a comment
    display.display(u'test_RoleDefinition_preprocess_data: role_definition_0')

    # construct object to test
    role_definition_0 = RoleDefinition()



# Generated at 2022-06-25 05:52:39.648120
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    # Test case with all the params specified
    # Create a temp obj of class 'RoleDefinition'
    role_definition_1 = RoleDefinition()
    # Call the method under test
    ds_1 = role_definition_1.preprocess_data({'role': 'test_role_name', 'tasks': '/path/to/tasks'})
    assert ds_1 == {'role': 'test_role_name'}

    # Test case with only the mandatory params specified
    # Create a temp obj of class 'RoleDefinition'
    role_definition_2 = RoleDefinition()
    # Call the method under test
    ds_2 = role_definition_2.preprocess_data('test_role_name')
    assert ds_2 == 'test_role_name'

    # Test case with no params specified
    # Create a temp

# Generated at 2022-06-25 05:52:47.202891
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition_1 = RoleDefinition()
    role_defs_data_samples = [
        dict(
            role="role1",
            params1=1,
            params2=2,
            params3=3,
        ),
        dict(
            role="role1",
            hosts="some_hosts",
        ),
        dict(
            name="role1",
            params1=1,
            params2=2,
            params3=3,
        ),
        dict(
            name="role1",
            hosts="some_hosts",
        ),
        "role1_with_name_only",
        "role1_with_name_only",
    ]
    role_def_data = role_defs_data_samples[0]

# Generated at 2022-06-25 05:52:56.676576
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data(): 
    # Test 1

    # inputs
    role_definition_0 = RoleDefinition()
    ds = {
        'role': 'foo',
    }
    # perform test
    new_ds = role_definition_0.preprocess_data(ds)

    # validate results
    assert new_ds == ds
    assert role_definition_0._ds == ds
    assert role_definition_0._role_path == 'foo'
    assert role_definition_0._role_params == dict()
    # cleanup
    role_definition_0 = None
    ds = None
    new_ds = None


    # Test 2

    # inputs
    role_definition_0 = RoleDefinition()
    ds = {
        'role': 'foo',
        'a': 1,
        'b': 2,
    }
   

# Generated at 2022-06-25 05:52:59.343342
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    role_definition_0 = RoleDefinition()
    assert role_definition_0.get_name(True) == None

# Generated at 2022-06-25 05:53:04.297795
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():

    # Create an object of class RoleDefinition with empty arguments
    role_definition_0 = RoleDefinition()

    # Create a dictionary and use it as a argument for method preprocess_data of object role_definition_0
    # dictionary_0 is created using the following code - dictionary_0 = {'role': 'grafana'}
    dictionary_0 = dict()
    dictionary_0['role'] = 'grafana'
    role_definition_0.preprocess_data(dictionary_0)

# Generated at 2022-06-25 05:53:12.905394
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition_0 = RoleDefinition()

    assert role_definition_0.preprocess_data('test_value_4') == {'role': 'test_value_4'}



# Generated at 2022-06-25 05:53:21.579204
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():

    # Test with dict as argument
    ds = dict()
    ds['role'] = 'test_role'
    ds['role_basedir'] = 'test/role/basedir'
    ds['variable_manager'] = 'test_variable_manager'
    ds['loader'] = 'test_loader'
    ds['collection_list'] = 'test_collection_list'
    role_definition = RoleDefinition()

    role_definition.preprocess_data(dict)

    assert role_definition._ds == ds

    # Test with string as argument
    ds = 'test_role'
    ds = 'test_role'
    ds = 'test_role'
    ds = 'test_role'
    ds = 'test_role'
    role_definition = RoleDefinition()


# Generated at 2022-06-25 05:53:23.990041
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    role_definition_0 = RoleDefinition()
    assert role_definition_0.get_name() == None

# Generated at 2022-06-25 05:53:29.415658
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    role_definition = RoleDefinition()
    role_definition.role = 'role_name_0'
    assert 'role_name_0' == role_definition.get_name(False)
    assert 'role_name_0' == role_definition.get_name(True)
    role_definition.role = '0role_name_0'
    assert '0role_name_0' == role_definition.get_name(False)
    assert '0role_name_0' == role_definition.get_name(True)

# Generated at 2022-06-25 05:53:39.200669
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    # Test RoleDefinition class with just the role name
    # No attributes, only a role name
    role_definition_1 = RoleDefinition()
    role_definition_1.preprocess_data({'role': 'test_role'})
    assert role_definition_1.role == 'test_role'
    assert not role_definition_1.get_role_params()

    # Test RoleDefinition class with role name and attributes
    # No attrbutes, only a role name
    role_definition_2 = RoleDefinition()
    role_definition_2.preprocess_data({
        'role': 'test_role',
        'loop': '3',
    })
    assert role_definition_2.role == 'test_role'
    assert role_definition_2.loop == '3'
    assert not role_definition_2.get_role_

# Generated at 2022-06-25 05:53:41.896241
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    role_definition_0 = RoleDefinition()
    role_definition_0.name = 'name_0'
    assert role_definition_0.get_name() == 'name_0'
    role_definition_0.name = 'name_1'
    assert role_definition_0.get_name() == 'name_1'

# Generated at 2022-06-25 05:53:52.546165
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition_0 = RoleDefinition()
    role_def_mapping_0 = AnsibleMapping()
    role_definition_0_preprocess_data_result = role_definition_0.preprocess_data(role_def_mapping_0)
    assert role_definition_0_preprocess_data_result == role_def_mapping_0
    attribute_instance_0 = Attribute()
    str_0 = 'somestring'
    test_path = os.path.join('/', 'home', 'rv', 'FND', 'dev', 'ansible')
    role_definition_1 = RoleDefinition(role_basedir=test_path)
    role_def_mapping_1 = AnsibleMapping()
    role_def_mapping_1['role'] = str_0
    role_def_

# Generated at 2022-06-25 05:53:59.333867
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    role_definition_0 = RoleDefinition()
    role_definition_0._role_collection = 'test.collection0'
    role_definition_0._attributes['role'] = 'test.role0'
    actual = role_definition_0.get_name()
    assert actual == 'test.collection0.test.role0'
    actual = role_definition_0.get_name(include_role_fqcn=False)
    assert actual == 'test.role0'

# Generated at 2022-06-25 05:54:02.526440
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():

    role_definition_0 = RoleDefinition()
    role_definition_0.role = u'role'
    result = role_definition_0.get_name()
    assert isinstance(result, string_types) and len(result) > 0

# Generated at 2022-06-25 05:54:08.767484
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():

    testVars = dict(
        test_role_def = dict(
            role = 'rolename',
            test_role_param = True
            ),
        test_role_array = [
            dict(role = 'rolename'),
            dict(role = 'rolename')
            ]
        )

    role_definition_0 = RoleDefinition()
    role_definition_0.preprocess_data(testVars['test_role_def'])
    role_definition_0.preprocess_data(testVars['test_role_array'])


# Generated at 2022-06-25 05:54:16.223150
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    # Basic test
    role_definition_0 = RoleDefinition()
    assert role_definition_0.get_name() == None


# Generated at 2022-06-25 05:54:24.974972
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    role_definition_1 = RoleDefinition()

    name_value_0 = role_definition_1.get_name()
    assert name_value_0 is None, "name_value_0 should be None"

    role_definition_1.role = "foobar"
    name_value_0 = role_definition_1.get_name()
    assert name_value_0 == "foobar", "name_value_0 should be equal to foobar"

    name_value_0 = role_definition_1.get_name(True)
    assert name_value_0 == "foobar", "name_value_0 should be equal to foobar"

    role_definition_1._role_collection = "my.collection"
    name_value_1 = role_definition_1.get_name()

# Generated at 2022-06-25 05:54:35.019478
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    """Unit test for method get_name of class RoleDefinition"""
    from ansible.playbook.role import RoleDefinition

    rd = RoleDefinition(role_basedir="./t/roles", collection_list=None)

    # Test1: collection based role
    role = 'foo'
    rd._role = role
    assert rd.get_name() == role

    # Test2: role inside role directory
    role = 'role_in_roles'
    rd._role = role
    assert rd.get_name() == role

    # Test3: use role name and relative path of role
    role = './t/roles/role_in_roles'
    rd._role = role
    assert rd.get_name() == role

    # Test4: use relative path to role

# Generated at 2022-06-25 05:54:37.281860
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    role_definition_0 = RoleDefinition()
    role_definition_0.role = 'foo'
    expected = 'foo'
    actual = role_definition_0.get_name()
    assert actual == expected

# Generated at 2022-06-25 05:54:45.668907
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    role_definition = RoleDefinition()
    role_definition.role = 'name'
    assert(role_definition.get_name(include_role_fqcn=False) == 'name')
    assert(role_definition.get_name(include_role_fqcn=True) == 'name')
    role_definition._role_collection = 'collection'
    assert(role_definition.get_name(include_role_fqcn=False) == 'name')
    assert(role_definition.get_name(include_role_fqcn=True) == 'collection.name')