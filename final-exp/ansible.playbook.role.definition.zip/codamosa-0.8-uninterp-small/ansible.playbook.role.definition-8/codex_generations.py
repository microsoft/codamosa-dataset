

# Generated at 2022-06-25 05:44:52.983587
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition_0 = RoleDefinition()

    data = {u'role': u'rmdir', u'name': u'rmdir_role'}

    role_definition_0.preprocess_data(data)

# Generated at 2022-06-25 05:44:54.606717
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    test_case_0()
    # TODO: Add code to test get_name here.


# Generated at 2022-06-25 05:45:00.161871
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition_0 = RoleDefinition(str)
    role_definition_1 = RoleDefinition(list)
    role_definition_2 = RoleDefinition(dict)

    role_definition_0.preprocess_data(None)

    role_definition_0.preprocess_data(int)

    role_definition_0.preprocess_data(int)

# Generated at 2022-06-25 05:45:06.318004
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    str_0 = 'YjfQ`:!5'
    role_definition_0 = RoleDefinition(str_0)
    str_1 = 'j!y8-%7V9>}'
    dict_0 = {"ZbU6*": str_1}
    map_0 = AnsibleMapping()
    map_0.ansible_pos = 1
    role_definition_0.preprocess_data(map_0)
    role_definition_0._split_role_params(dict_0)


# Generated at 2022-06-25 05:45:10.687374
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    str_0 = 'YjfQ`:!5'
    role_definition_0 = RoleDefinition(str_0)
    role_definition_0.preprocess_data(2 * 3 * str_0)
    # print(role_definition_0.__repr__())
    print(role_definition_0.__dict__)


# Generated at 2022-06-25 05:45:12.462755
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    pass

if __name__ == '__main__':
    test_case_0()
    #test_RoleDefinition_get_name()

# Generated at 2022-06-25 05:45:17.617165
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    role_definition_0 = RoleDefinition()
    role_definition_0.role = 'YjfQ`:!5'
    str_0 = role_definition_0.get_name()
    assert str_0 == 'YjfQ`:!5'


# Generated at 2022-06-25 05:45:27.421310
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.objects import AnsibleMapping
    role_definition_1 = RoleDefinition()
    try:
        role_definition_1.preprocess_data(1)
    except AnsibleError as e:
        print('exception message: {0}'.format(e.message))
    except AnsibleAssertionError as e:
        print('exception message: {0}'.format(e.message))

# Generated at 2022-06-25 05:45:38.741246
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():

    role_basedir_0 = './roles'
    role_definition_0 = RoleDefinition(role_basedir=role_basedir_0)
    role_definition_0._role_basedir = r'C:\Users\Alaina\Documents\ansible-roles'

    data_0 = 'S1h'
    templar_0 = Templar(loader=role_definition_0._loader, variables=role_definition_0._variable_manager)
    templar_0.template(data_0)

    role_definition_0._role_path = 'C:\\Users\\Alaina\\Documents\\ansible-roles\\w08m1f28\\m01o9'
    role_definition_0.get_role_path()

    # Input parameters

# Generated at 2022-06-25 05:45:42.818677
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    str_0 = 'YjfQ`:!5'
    role_definition_0 = RoleDefinition(str_0)
    str_1 = 'YjfQ`:!5'
    assert role_definition_0.get_name(str_1) == '.'.join(x for x in (role_definition_0._role_collection, role_definition_0.role) if x)


# Generated at 2022-06-25 05:45:51.535024
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    # default test case
    str_0 = 'YjfQ`:!5'
    role_definition_0 = RoleDefinition(str_0)
    bool_0 = role_definition_0.get_name()


# Generated at 2022-06-25 05:45:57.863258
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    str_0 = '2S`1'
    role_definition_0 = RoleDefinition(str_0)
    ds_0 = {}
    role_name_0 = role_definition_0._load_role_name(ds_0)
    role_name_1 = role_definition_0._load_role_name(ds_0)
    role_path_0 = role_definition_0._load_role_path(role_name_1)
    role_def_0, role_params_0 = role_definition_0._split_role_params(ds_0)
    role_name_2 = role_definition_0._load_role_name(ds_0)
    new_ds_0 = {}
    role_name_3 = role_definition_0._load_role_name(ds_0)
    role_

# Generated at 2022-06-25 05:46:08.296810
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    str_0 = 'LwO~)5_'
    role_definition_0 = RoleDefinition(str_0)
    str_1 = 'WZ{iNdK'
    role_definition_1 = RoleDefinition(str_1)
    str_2 = 'zIW}m8x'
    role_definition_2 = RoleDefinition(str_2)
    str_3 = 'B)R()|P'
    role_definition_3 = RoleDefinition(str_3)
    str_4 = '2uam(V'
    role_definition_4 = RoleDefinition(str_4)
    str_5 = '6U=Q;^u'
    role_definition_5 = RoleDefinition(str_5)
    str_6 = 'Tm%+'

# Generated at 2022-06-25 05:46:09.759505
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    str_0 = '5<_#Z]^U'
    role_definition_0 = RoleDefinition(str_0)
    role_definition_0.preprocess_data(str_0)



# Generated at 2022-06-25 05:46:15.034396
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    str_0 = 'yf#_KKp?wI'
    str_1 = 'YjfQ`:!5'
    role_definition_0 = RoleDefinition(str_1)
    role_definition_0.preprocess_data(str_0)

# Generated at 2022-06-25 05:46:18.337244
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    role_definition_0 = RoleDefinition()
    role_definition_0.role = 'cSk-i@<'
    str_0 = role_definition_0.get_name()
    assert str_0 == 'cSk-i@<', str_0


# Generated at 2022-06-25 05:46:20.545288
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    str_0 = 'YjfQ`:!5'
    role_definition_0 = RoleDefinition(str_0)
    data_0 = {'role': 'kH1U6(8lndW%aG'}
    role_definition_0.preprocess_data(data_0)

# Generated at 2022-06-25 05:46:30.806133
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    str_0 = 'YjfQ`:!5'
    role_definition_0 = RoleDefinition(str_0)
    str_0 = 'J7V#+2Eg'
    role_definition_1 = RoleDefinition(str_0)
    str_0 = 'U5G6f;/z'
    role_definition_2 = RoleDefinition(str_0)
    str_0 = 'l\" ( uc'
    role_definition_3 = RoleDefinition(str_0)
    str_0 = 'b&0aYtR.'
    role_definition_4 = RoleDefinition(str_0)
    str_0 = '%gvZ2/&`'
    role_definition_5 = RoleDefinition(str_0)
    str_0 = 'KjXk*1tC'
   

# Generated at 2022-06-25 05:46:40.147154
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    str_0 = 'YjfQ`:!5'
    role_definition_0 = RoleDefinition(str_0)
    dict_0 = dict()
    dict_0['role'] = 'YjfQ`:!5'
    dict_1 = dict()

    # Case for when isinstance(ds, dict) is True
    result = role_definition_0.preprocess_data(dict_0)
    assert result == dict_1

    # Case when isinstance(ds, dict) is False and isinstance(ds, string_types) is True
    result = role_definition_0.preprocess_data(str_0)
    assert result == dict_1

    # Case when isinstance(ds, dict) is False and isinstance(ds, string_types) is True
    result = role_definition_0.preprocess_

# Generated at 2022-06-25 05:46:43.469403
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    str_0 = '_?Q'
    str_1 = '3M|'
    role_definition_0 = RoleDefinition(str_0)
    role_definition_0.role = str_1
    boolean_0 = role_definition_0.get_name()
    assert boolean_0 == '3M|'

# Generated at 2022-06-25 05:47:00.460455
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():

    dict_0 = dict()
    dict_0['__ansible_no_log'] = False
    dict_0['__ansible_ignore_errors'] = False
    dict_0['__ansible_become'] = True
    dict_0['__ansible_become_user'] = u'deploy'
    dict_0['__ansible_become_method'] = u'sudo'
    dict_0['__ansible_verbosity'] = 3
    dict_0['__ansible_version'] = 2.5
    dict_0['__ansible_module_name'] = u'ping'
    dict_0['__ansible_all_vars'] = dict()
    dict_0['__ansible_module_args'] = dict()

# Generated at 2022-06-25 05:47:07.387625
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    data_0 = 'YjfQ`:!5'
    variable_manager_0 = VariableManager()
    loader_0 = NULL
    # The following call to preprocess_data is expected to fail with an error
    try:
        RoleDefinition.preprocess_data(data_0, variable_manager_0, loader_0)
    except AnsibleError as e:
        assert e.message == ''
        assert e.obj == ''


# Generated at 2022-06-25 05:47:09.628426
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    str_0 = 'eg.ng'
    role_definition_0 = RoleDefinition()
    role_definition_0.preprocess_data(str_0)


# Generated at 2022-06-25 05:47:16.994953
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    # Input data for test case
    str_0 = 'zLp:)S'
    str_1 = '!5.5)9.'
    str_2 = '$8#vZ'
    str_3 = 'wWRA%'
    str_4 = 'hLbxA'

    # Expected results
    expected_0 = AnsibleMapping()
    expected_0.ansible_pos = 8
    expected_0['role_path'] = 'A/B/C'
    expected_0['role'] = 'C'

    # Actual results
    actual_0 = RoleDefinition(str_0).preprocess_data(dict(A=str_1, B=str_2, C=str_3, D=str_4))

    # Assertions
    assert expected_0 == actual_0

# Generated at 2022-06-25 05:47:17.643948
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    test_case_0()


# Generated at 2022-06-25 05:47:19.457089
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    try:
        test_case_0()
    except Exception as exception_0:
        has_exception = True
    else:
        has_exception = False

    assert has_exception == False

# Generated at 2022-06-25 05:47:24.522104
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    str_1 = 'm1'
    role_definition_1 = RoleDefinition(str_1)
    assert role_definition_1.get_name() == str_1
    str_2 = 'tO[Q'
    role_definition_2 = RoleDefinition(str_2)
    assert role_definition_2.get_name() == str_2
    str_3 = 'F7V5'
    role_definition_3 = RoleDefinition(str_3)
    assert role_definition_3.get_name() == str_3
    str_4 = 'gJUn!Oa'
    role_definition_4 = RoleDefinition(str_4)
    assert role_definition_4.get_name() == str_4


# Generated at 2022-06-25 05:47:26.957567
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    # Create an instance of RoleDefinition for testing
    role_definition_2 = RoleDefinition()

    # Test return value
    role_definition_2.get_name(True)



# Generated at 2022-06-25 05:47:35.525871
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    str_0 = 'RoleDefinition'
    str_1 = 'RoleDefinition'
    str_2 = 'RoleDefinition'
    str_3 = 'RoleDefinition'
    str_4 = 'RoleDefinition'
    str_5 = 'RoleDefinition'
    str_6 = 'RoleDefinition'
    str_7 = 'RoleDefinition'
    str_8 = 'RoleDefinition'
    str_9 = 'RoleDefinition'
    str_10 = 'RoleDefinition'
    role_definition_0 = RoleDefinition(str_0)

    role_definition_0.preprocess_data(str_1)
    role_definition_0.preprocess_data(str_2)
    role_definition_0.preprocess_data(str_3)
    role_definition_0.preprocess_data(str_4)
    role_definition_0

# Generated at 2022-06-25 05:47:39.355440
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    str_0 = 'x;'
    role_definition_0 = RoleDefinition(str_0)
    role_definition_1 = role_definition_0.get_name()
    if not isinstance(role_definition_1, string_types):
        raise AssertionError()


# Generated at 2022-06-25 05:47:48.742624
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():

    #
    # Test creation of a RoleDefinition object
    #
    role_def = RoleDefinition()

    # Test basic creation of an object
    assert role_def is not None

# Run the tests
if __name__ == '__main__':
    test_case_0()
    test_RoleDefinition_preprocess_data()

# Generated at 2022-06-25 05:47:56.841556
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    template_basedir = '/usr/local/lib/python2.7/dist-packages/ansible/templates'
    loader = None
    variable_manager = None
    collection_list = []
    collection_search_paths = []
    ds = 'role'
    ansible_pos = None

    role_definition_0 = RoleDefinition(collection_search_paths, loader, template_basedir, variable_manager, collection_list)

    role_definition_0.preprocess_data(ds)

# Generated at 2022-06-25 05:48:02.251715
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    # set up objects needed to test
    str_0 = 'YjfQ`:!5'
    role_definition_0 = RoleDefinition(str_0)
    # perform the test
    ds_0 = '@U$X`"p3}r>'
    role_definition_0.preprocess_data(ds_0)


# Generated at 2022-06-25 05:48:07.204966
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    str_0 = './roles/nginx'
    role_definition_0 = RoleDefinition(str_0)
    role_definition_0.preprocess_data('nginx')
    role_definition_0.preprocess_data(None)


# Generated at 2022-06-25 05:48:16.487053
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    str_0 = 'YjfQ`:!5'
    role_definition_0 = RoleDefinition(str_0)
    dict_0 = {'CfdU`': "c6W8"}

    role_definition_0._load_role_path = lambda ds: (ds.get('role', ds.get('name')), 'role_path_0')
    role_definition_0._load_role_name = lambda ds: ds
    role_definition_0._split_role_params = lambda ds: ({'role': 'role_name_0'}, dict())

    role_definition_0.preprocess_data(dict_0)


# Generated at 2022-06-25 05:48:20.762824
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    str_0 = 'YjfQ`:!5'
    role_definition_0 = RoleDefinition(str_0)
    role_definition_0.preprocess_data(None)


# Generated at 2022-06-25 05:48:26.053761
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    data = {'role': 'test_name'}
    role_definition_0 = RoleDefinition(data)
    role_definition_0.preprocess_data(data)
    disk_0 = getattr(role_definition_0, '_role_path')
    assert disk_0 == '~/roles/test_name'

# Generated at 2022-06-25 05:48:34.010445
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    str_0 = '*oDA;'
    role_definition_0 = RoleDefinition(str_0)
    ds = {'not_a_real_key': -1, 'but_should_be_real_key': 4}
    new_ds = role_definition_0.preprocess_data(ds)
    assert(isinstance(new_ds, AnsibleMapping))
    assert(isinstance(new_ds['role'], string_types))
    assert(new_ds['role'] == str_0)


# Generated at 2022-06-25 05:48:40.798721
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    # TODO: ...
    str_0 = 'YjfQ`:!5'
    str_1 = '6U^G6+M<'
    for param_0 in str_0:
        for param_1 in str_1:
            role_definition_0 = RoleDefinition(param_0) # FIXME: invalid parameter value(s)


# Generated at 2022-06-25 05:48:47.143898
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    str_0 = 'M;\x06\x1c\r\r\t\x0b'
    int_0 = -2
    float_0 = 1.4344595929361281
    role_definition_0 = RoleDefinition(str_0)
    role_definition_1 = RoleDefinition(int_0)
    role_definition_2 = RoleDefinition(float_0)
    str_1 = '\x1d\n\x1b\r\r\r\x0b'
    str_2 = '\x0c!'
    str_3 = '\x17S'
    str_4 = '\x1d\x1a\x1c\x0b\x0c\x0b'

# Generated at 2022-06-25 05:48:57.696523
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    test_0 = dict()

    test_1 = dict()
    test_1['ansible_pos'] = dict()
    test_1['key_0'] = test_0
    test_1['key_1'] = (test_0, test_0)

    assert RoleDefinition.preprocess_data(test_1) is not None


# Generated at 2022-06-25 05:49:00.278108
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    role_definition_0 = RoleDefinition()
    assert role_definition_0.get_name() == '.'

# Generated at 2022-06-25 05:49:09.186810
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    str_0 = 'YjfQ`:!5'
    role_definition_0 = RoleDefinition(str_0)
    role_definition_0.name = 'YjfQ`:!5'
    role_definition_0.role = 'YjfQ`:!5'
    role_definition_0.all = 'YjfQ`:!5'
    role_definition_0._play = 'YjfQ`:!5'
    role_definition_0._variable_manager = 'YjfQ`:!5'
    role_definition_0._loader = 'YjfQ`:!5'
    role_definition_0._ds = 'YjfQ`:!5'
    role_definition_0._role_path = 'YjfQ`:!5'
    role_definition

# Generated at 2022-06-25 05:49:19.539538
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    str_0 = 'YjfQ`:!5'
    role_definition_0 = RoleDefinition(str_0)
    assert isinstance(role_definition_0, RoleDefinition)
    int_0 = 1
    ds = int_0
    expected_AnsibleError_0 = AnsibleError
    actual_AnsibleError_0 = None
    try:
        role_definition_0.preprocess_data(ds)
    except Exception as actual_AnsibleError_0:
        pass
    assert type(actual_AnsibleError_0) == type(expected_AnsibleError_0)
    str_1 = 'jKmpC}fA'
    ds = str_1
    expected_AnsibleError_1 = AnsibleError
    actual_AnsibleError_1 = None
   

# Generated at 2022-06-25 05:49:20.082781
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    pass

# Generated at 2022-06-25 05:49:22.166548
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition_0 = RoleDefinition()
    str_0 = '1d`xT`&'
    role_definition_0.preprocess_data(str_0)


# Generated at 2022-06-25 05:49:28.530345
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    test_case_0()
    str_0 = 'YjfQ`:!5'
    role_definition_0 = RoleDefinition(str_0)
    ds_0 = 'ul+7hEq'
    x_0 = role_definition_0.preprocess_data(ds_0)
    str_1 = 'YjfQ`:!5'
    role_definition_1 = RoleDefinition(str_1)
    ds_1 = 'ul+7hEq'
    x_1 = role_definition_1.preprocess_data(ds_1)
    assert x_0 == x_1


# Generated at 2022-06-25 05:49:34.806476
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    str_0 = 'YjfQ`:!5'
    role_definition_0 = RoleDefinition(str_0)
    assert role_definition_0.role == 'YjfQ`:!5'
    assert role_definition_0.get_name() == 'YjfQ`:!5'


# Generated at 2022-06-25 05:49:45.903632
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    # String arguments
    str_0 = 'YjfQ`:!5'
    # Instance creation
    role_definition_0 = RoleDefinition(str_0)
    int_0 = 9
    ansible_mapping_0 = AnsibleMapping()
    # Call the method
    role_definition_0.preprocess_data(int_0)
    # Call the method with arguments
    role_definition_0.preprocess_data(ansible_mapping_0)
    # Call the method with default arguments
    role_definition_0.preprocess_data()
    # Call the method with positional arguments
    role_definition_0.preprocess_data(ansible_mapping_0)
    # Call the method with keyword arguments
    role_definition_0.preprocess_data(obj=ansible_mapping_0)

# Generated at 2022-06-25 05:49:48.077057
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    str_0 = '- role: {{ role_name }}'
    role_definition_0 = RoleDefinition(str_0)
    role_definition_0.preprocess_data(role_definition_0)


# Generated at 2022-06-25 05:49:55.367272
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    str_0 = 'YjfQ`:!5'
    role_definition_0 = RoleDefinition()
    role_definition_0 = role_definition_0.preprocess_data(str_0)

# Generated at 2022-06-25 05:50:00.924204
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    str_0 = 'YjfQ`:!5'
    role_definition_0 = RoleDefinition(str_0)
    role_definition_0.attribute_to_compare = 'name'
    role_definition_0.name = 'name'



# Generated at 2022-06-25 05:50:03.000400
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    pass


# Generated at 2022-06-25 05:50:07.172591
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    str_0 = 'YjfQ`:!5'
    role_definition_0 = RoleDefinition(str_0)
    role_definition_0.preprocess_data(str_0)

# Generated at 2022-06-25 05:50:18.799879
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_path_0 = 'YjfQ`:!5'
    role_name_0 = 'YjfQ`:!5'
    role_name_1 = 'YjfQ`:!5'
    role_name_2 = 'YjfQ`:!5'
    role_name_3 = 'YjfQ`:!5'
    role_name_4 = 'YjfQ`:!5'
    role_name_5 = 'YjfQ`:!5'
    role_definition_0 = RoleDefinition(role_name_0)
    role_definition_1 = RoleDefinition(role_name_1)
    role_definition_2 = RoleDefinition(role_name_2)
    role_definition_3 = RoleDefinition(role_name_3)
    role_definition_

# Generated at 2022-06-25 05:50:23.604986
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    str_0 = ''
    variable_manager_0 = []
    loader_0 = []
    collection_list_0 = []
    role_definition_0 = RoleDefinition(str_0, variable_manager_0, loader_0, collection_list_0)
    dict_0 = dict()
    role_definition_0.preprocess_data(dict_0)
    param_0 = ds = None
    role_definition_0.preprocess_data(param_0)


# Generated at 2022-06-25 05:50:31.479224
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    '''
    role names that are simply numbers can be parsed by PyYAML
        as integers even when quoted, so turn it into a string type
    '''
    str_0 = 'YjfQ`:!5'
    role_definition_0 = RoleDefinition(str_0)
    ds_0 = '+'
    result = role_definition_0.preprocess_data(ds_0)
    assert result is None, "Preprocess data: %s" % result


# Generated at 2022-06-25 05:50:42.427472
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    str_0 = 'YjfQ`:!5'
    role_definition_0 = RoleDefinition(str_0)
    role_definition_0.preprocess_data(str_0)
    dict_0 = {}
    dict_0['fta_vBWJ:'] = '@t$1.`[p'
    dict_0['rGxr~,e2P'] = 'c%}|>nK3'
    dict_0[''] = '?'
    dict_0['o\'-#C,+R'] = '6U;?_%c9'
    dict_0['|}A3iH-w'] = '@,Mu<dr`'
    dict_0['YjfQ`:!5'] = 'T}A&w-^_'

# Generated at 2022-06-25 05:50:52.433430
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    # Test case 1
    case_1_data = {
        'role': 'role-name',
        'name': 'role-name',
        'something': {
            'foo': 'bar',
        },
    }
    role_definition_1 = RoleDefinition(case_1_data)
    role_definition_1.preprocess_data(case_1_data)
    raise NotImplementedError()

    # Test case 2
    case_2_data = {
        'role': 'role-name',
        'name': 'role-name',
        'something': {
            'foo': 'bar',
        },
    }
    role_definition_2 = RoleDefinition(case_2_data)
    role_definition_2.preprocess_data(case_2_data)
    raise NotImplementedError()

# Generated at 2022-06-25 05:50:57.066359
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    host = 'localhost'
    ds = {'role': 'YjfQ`:!5', 'name': host}
    variable_manager = 'variable_manager'
    loader = 'loader'
    role_definition_0 = RoleDefinition(ds, variable_manager, loader)
    passed = False
    try:
        role_definition_0.preprocess_data(ds)
        passed = False
    except Exception as exception:
        passed = True



# Generated at 2022-06-25 05:51:04.202946
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    assert True


# Generated at 2022-06-25 05:51:10.197584
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    str_0 = 'YjfQ`:!5'
    role_definition_0 = RoleDefinition(str_0)
    str_1 = 'role'
    str_2 = 'testcase'
    dict_0 = {str_1: str_2}
    # Test fails because of TypeError
    with pytest.raises(TypeError):
        role_definition_0.preprocess_data(dict_0)


# Generated at 2022-06-25 05:51:18.521272
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    def test_case_0():
        str_0 = """
        - name: deploy the user's application
          hosts: localhost
          tasks:
            - name: make sure a virtualenv exists
              pip:
                name={{ item }}
                virtualenv={{ venv }}/{{ item }}
                state=present
              with_items:
                - Flask
                - Flask-SQLAlchemy
          roles:
            - { role: common, when: ansible_distribution == 'RedHat' }
            - common
            - { role: 'geerlingguy.java' }
            - geerlingguy.java
            - { role: 'geerlingguy.java', when: ansible_distribution != 'RedHat' }
            - 'geerlingguy.java'
        """

# Generated at 2022-06-25 05:51:26.703667
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    # Parameters to set
    # play_0 = Play()
    # variable_manager_0 = VariableManager()
    # loader_0 = DataLoader()
    # collection_list_0 = ['load', 'from', 'collections']
    # role_definition_0 = RoleDefinition(play_0, role_basedir_0, variable_manager_0, loader_0, collection_list_0)
    # ds_0 = {}
    print('Executing test for method preprocess_data of class RoleDefinition')


# Generated at 2022-06-25 05:51:28.604059
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    ds = {}
    role_definition_0 = RoleDefinition()
    role_definition_0.preprocess_data(ds)


# Generated at 2022-06-25 05:51:34.921382
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    try:
        str_0 = 'this is a string'
        role_definition_0 = RoleDefinition(str_0)
        role_definition_0.preprocess_data(dict_0)
    except Exception as e:
        print(e)


# Generated at 2022-06-25 05:51:38.303048
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    assert 1 == 1


# Generated at 2022-06-25 05:51:39.711333
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    str_0 = 'YjfQ`:!5'
    role_definition_0 = RoleDefinition(str_0)


# Generated at 2022-06-25 05:51:43.064629
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
  str_0 = '3N}/&^'
  role_definition_0 = RoleDefinition()
  role_definition_0.preprocess_data(str_0)


# Generated at 2022-06-25 05:51:45.779730
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    print('\n**************************************************************')
    print('\nTest #1: test_RoleDefinition_get_name')
    print('\n**************************************************************')
    test_case_0()

# Generated at 2022-06-25 05:51:55.539256
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    class_0 = RoleDefinition()
    class_0.role = 'fU[#6)_'
    str_0 = 'h{wTj?Q'

    assert class_0.get_name(str_0) == ('h{wTj?Q', 'fU[#6)_')


# Generated at 2022-06-25 05:51:56.725337
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition_0 = RoleDefinition()
    role_definition_0.preprocess_data()


# Generated at 2022-06-25 05:52:03.873953
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    print("== START test_RoleDefinition_preprocess_data ==")
    # Test config 1
    dict_0 = dict()
    dict_1 = dict()
    dict_1['name'] = 'Q'
    dict_0['role'] = dict_1
    role_definition_0 = RoleDefinition(dict_0)
    role_definition_0.preprocess_data(dict_0)

    # Test config 2
    dict_0 = dict()
    dict_1 = dict()
    dict_1['name'] = 'Q'
    dict_0['role'] = dict_1
    role_definition_0 = RoleDefinition(dict_0)
    role_definition_0.preprocess_data(dict_0)

    # Test config 3
    dict_0 = dict()
    dict_1 = dict()
    dict_

# Generated at 2022-06-25 05:52:05.417540
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    mapper_0 = {}
    role_definition_0 = RoleDefinition(mapper_0)
    mapper_0 = {"hello": "world"}
    role_definition_0.preprocess_data(mapper_0)

# Generated at 2022-06-25 05:52:13.350096
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    # (role_name: str) -> dict
    def normalize(role_name):
        # dict -> dict
        def preprocess_data(data):
            return RoleDefinition(role_name).preprocess_data(data)

        return preprocess_data

    data_0 = normalize('role1')({'name': 'rolestring'})
    data_1 = normalize('role1')({'role': 'rolestring'})
    data_2 = normalize('role1')({'role': 'rolestring', 'become': True})
    data_3 = normalize('role1')({'role': 'rolestring', 'unknown': 'value'})
    data_4 = normalize('role1')({'role': 'rolestring', 'name': 'unused'})
    data_5

# Generated at 2022-06-25 05:52:15.864218
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    str_0 = 'l0~/X|'
    role_definition_0 = RoleDefinition(str_0)
    str_1 = role_definition_0.get_name(bool_0)
    int_0 = str_1


# Generated at 2022-06-25 05:52:23.492620
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    str_0 = 'YjfQ`:!5'
    dict_0 = dict()
    dict_1 = dict()
    attribute_0 = Attribute(dict_0, dict_1)
    role_definition_0 = RoleDefinition(str_0)
    data_0 = 'd; n(!M@'

    role_definition_0.preprocess_data(data_0)

    dict_2 = dict()
    dict_3 = dict()


# Generated at 2022-06-25 05:52:27.212674
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    str_0 = 'Q0g.=H:@'
    role_definition_0 = RoleDefinition(str_0)
    dict_0 = dict()
    str_1 = role_definition_0.preprocess_data(dict_0)
    print(str_1)


# Generated at 2022-06-25 05:52:31.847560
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    name_0 = '&'
    role_definition_0 = RoleDefinition(name_0)
    name_1 = role_definition_0.get_name()
    # AssertionError: '&' != 'None.&'
    assert name_1 == ("%s.%s" % (None, name_0))


# Generated at 2022-06-25 05:52:35.363800
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition_0 = RoleDefinition(str_0)
    role_definition_0.preprocess_data(str_0)


# Generated at 2022-06-25 05:52:47.540246
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    
    # Setup data for testing
    str_0 = 'YjfQ`:!5'
    role_definition_0 = RoleDefinition(str_0)
    
    # Testing
    role_definition_0.preprocess_data(str_0)


# Generated at 2022-06-25 05:52:50.552423
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    # TODO: Mock data and arguments
    str_0 = 'NlveI'
    role_definition_0 = RoleDefinition(str_0)
    dict_0 = dict()
    role_definition_0.preprocess_data(dict_0)
    # TODO: Add assertions


# Generated at 2022-06-25 05:53:00.717713
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    s = r'role: "{{test_invalid_name}}"\n  allow_duplicates: True'
    role_definition = RoleDefinition(s)
    role_definition_preprocess_data = role_definition.preprocess_data(role_definition._ds)
    assert isinstance(role_definition_preprocess_data, dict)
    assert role_definition_preprocess_data.get('role', False), "The role_definition_preprocess_data dictionary doesn't have the key role"
    assert role_definition_preprocess_data['role'] == "{{test_invalid_name}}", "The role is not what is expected"
    assert 'test_invalid_name' in role_definition_preprocess_data.get('role'), "The value of the key role doesn't have the 'test_invalid_name' string"


# Generated at 2022-06-25 05:53:01.365369
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    assert True


# Generated at 2022-06-25 05:53:10.628769
# Unit test for method preprocess_data of class RoleDefinition

# Generated at 2022-06-25 05:53:13.244039
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    int_0 = 7
    test_case_0(int_0)


# Unit test execution
if __name__ == '__main__':
    test_RoleDefinition_preprocess_data()

# Generated at 2022-06-25 05:53:22.019691
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    # Save original value of C.DEFAULT_ROLES_PATH in order to re-set after testing
    orig_default_path = C.DEFAULT_ROLES_PATH

# Generated at 2022-06-25 05:53:27.510254
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    str_0 = 'YjfQ`:!5'
    role_definition_0 = RoleDefinition(str_0)
    dict_0 = dict()
    dict_0['role'] = 'tCkK8Wp]_'
    role_definition_1 = role_definition_0.preprocess_data(dict_0)
    assert(role_definition_1.__class__.__name__ == 'RoleDefinition')


# Generated at 2022-06-25 05:53:34.902330
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    # Create instance of class with params
    role_definition_1 = RoleDefinition()

    role_name_0 = 'wcp@*yi!3c1g'
    ds_0 = role_name_0

    role_definition_1._load_role_name(ds_0)

    role_name_1 = 't4*h4%8!t=0'
    ds_1 = role_name_1

    role_definition_1._load_role_name(ds_1)

    # Call method
    assert True # TODO: implement your test here


# Generated at 2022-06-25 05:53:43.255757
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    # # FIXME: move this to tests/unit/playbook/test_role.py?
    # FIXME: load() classmethod is not implemented
    # FIXME: this test does not do the actual check

    rd0 = RoleDefinition('name')
    rd0.preprocess_data('name')

    rd1 = RoleDefinition(role_basedir='basedir')
    rd1.preprocess_data({'role': 'name'})

    rd2 = RoleDefinition(role_basedir='basedir')
    rd2.preprocess_data({'role': 'name', 'var': 'val'})

    rd3 = RoleDefinition(role_basedir='basedir')
    rd3.preprocess_data(path='some/path/')

# Generated at 2022-06-25 05:53:50.248702
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():

    # Test code...
    raise Exception(test_RoleDefinition_preprocess_data.__doc__)


# Generated at 2022-06-25 05:53:55.149101
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    str_0 = 'YjfQ`:!5'
    role_definition_0 = RoleDefinition(str_0)
    boolean_0 = role_definition_0.get_name()
    print(boolean_0)


# Generated at 2022-06-25 05:53:59.450374
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    with pytest.raises(ValueError) as err:
        ds_0 = 'YjfQ`:!5'
        role_definition_0 = RoleDefinition(ds_0)
        pd_0 = role_definition_0.preprocess_data(ds_0)
    assert err.type == AssertionError


# Generated at 2022-06-25 05:54:00.793188
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    str_0 = '_Jg$[a'
    role_definition_0 = RoleDefinition()
    assert role_definition_0.preprocess_data(str_0) is not None


# Generated at 2022-06-25 05:54:09.153979
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    str_0 = 'YjfQ`:!5'
    role_definition_0 = RoleDefinition(str_0)
    role_definition_0.r = None
    role_definition_0.r_0 = None
    role_definition_0._role = '_AZ!O'
    role_definition_0._role_collection = '@Y=!R'
    role_definition_0._role_path = 'Pm'
    role_definition_0._role_params = {'4n)t': 5, 'HG`n': 5}
    role_definition_0._variable_manager = 'e'
    role_definition_0.a = '@Y=!R.S$'
    role_definition_0.b = 'S$._AZ!O'
    role_definition_0.c = ''


# Generated at 2022-06-25 05:54:12.080137
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition = RoleDefinition()
    data = dict()
    role_definition.preprocess_data(data)


# Generated at 2022-06-25 05:54:16.227063
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    str_0 = 'h*xLPw!VY'
    role_definition_0 = RoleDefinition(str_0)


# Generated at 2022-06-25 05:54:24.449456
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition_0 = RoleDefinition('YjfQ`:!5')
    args_0 = {'role': 'foobar', 'asdf': 'fdsa'}
    result_0 = role_definition_0.preprocess_data(args_0)
    assert result_0
    assert isinstance(result_0, dict)
    assert result_0.keys() == ['asdf', 'role']


# Generated at 2022-06-25 05:54:34.994729
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    # Test 1, with argument str_0
    str_0 = 'YjfQ`:!5'
    role_definition_0 = RoleDefinition(str_0)
    role_definition_0.preprocess_data()
    # Test 2, with argument list_0
    list_0 = ['>', 'o', 'L|]m*7vcP']
    role_definition_1 = RoleDefinition(list_0)
    role_definition_1.preprocess_data()
    # Test 3, with argument dict_0
    dict_0 = {'>': '!', 'o': '&', 'L|]m*7vcP': 'W', 'm': 'e'}
    role_definition_2 = RoleDefinition(dict_0)
    role_definition_2.preprocess_data()


# Generated at 2022-06-25 05:54:37.224905
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    ds = None
    variable_manager = None
    loader = None
    data = dict()
    data['role'] = 'test'
    role_definition = RoleDefinition()
    role_definition.preprocess_data(data)
