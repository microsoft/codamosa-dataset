

# Generated at 2022-06-25 05:44:49.815460
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    ds= {'role': 'test_role'}
    role_definition_1 = RoleDefinition(ds)
    role_definition_1.preprocess_data(ds)
    


# Generated at 2022-06-25 05:44:51.673472
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    print("test_RoleDefinition_get_name")


# Generated at 2022-06-25 05:45:02.190030
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    complex_0 = None
    role_definition_0 = RoleDefinition(complex_0)

    # Test 1: get_name() with no parameter passed
    role_definition_0.role = 'test-role'
    name = role_definition_0.get_name()
    try:
        assert name == "test-role"
    except AssertionError:
        print("Expected %s, but got %s." % ("test-role", name))
    else:
        print("Test 1 of get_name() passed.")

    # Test 2: get_name(False)
    role_definition_0.role = 'test-role'
    name = role_definition_0.get_name(include_role_fqcn=False)

# Generated at 2022-06-25 05:45:13.200546
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    complex_0 = dict()
    complex_0["role_name"] = "c89d7f1c367f908e10e6f8f8dfa5a7a5"
    complex_0["role"] = "c89d7f1c367f908e10e6f8f8dfa5a7a5"
    complex_0["role_path"] = "9f6c824a8f05c7bcd6d968c1f8490902"
    result_0 = RoleDefinition.preprocess_data(complex_0)
    assert result_0 != None
    result_1 = RoleDefinition.preprocess_data(complex_0)
    result_2 = RoleDefinition.preprocess_data(complex_0)
    assert result_1 == result_2
    complex_1 = dict

# Generated at 2022-06-25 05:45:19.575075
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    complex_0 = None
    role_definition_0 = RoleDefinition(complex_0)
    print("Unit test for Preprocess roles with role_name as a simple string")
    ds = "roles_in_play"
    print("Role name is : " + "\""+ ds + "\"");
    new_ds = role_definition_0.preprocess_data(ds)
    print ("Role name and path are : ", end='');
    print (new_ds)


# Generated at 2022-06-25 05:45:21.948879
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():

    complex_0 = None
    role_definition_0 = RoleDefinition(complex_0)
    print(role_definition_0)
    assert(False)  # TODO: implement your test here


# Generated at 2022-06-25 05:45:31.049250
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():

    '''
    Unit test for method preprocess_data of class RoleDefinition
    '''

    # Default args
    complex_0 = None
    variable_manager_0 = None
    loader_0 = None
    collection_list_0 = None
    role_definition_0 = RoleDefinition(complex_0)

    # Template vars
    name_1 = 'test_name'

    # Template vars
    name_2 = 'test_name'

    # Template vars
    name_3 = 'test_name'

    # Template vars
    name_4 = 'test_name'

    # Template vars
    name_5 = 'test_name'

    # Template vars
    name_6 = 'test_name'

    # Template vars
    name_7 = 'test_name'

    # Template vars


# Generated at 2022-06-25 05:45:34.182561
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    complex_1 = None
    role_definition_1 = RoleDefinition(complex_1)
    assert True  # TODO: implement your test here



# Generated at 2022-06-25 05:45:38.933223
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    complex_role = {
        "role": "some.collection.role",
        "tags": ["some_tag"]
    }
    role_definition = RoleDefinition(complex_role)
    assert role_definition.get_name() == "some.collection.role"
    assert role_definition.get_name(include_role_fqcn=False) == "role"


# Generated at 2022-06-25 05:45:40.901542
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    complex_1 = None
    role_definition_1 = RoleDefinition(complex_1)
    result = role_definition_1.get_name()
    assert isinstance(result, str)
    assert result == '.'

# Generated at 2022-06-25 05:45:55.003809
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    var_1 = dict()

    role_definition = RoleDefinition(var_0, var_1)
    var_1 = dict()
    var_1['role'] = 'test'

    var_2 = role_definition.preprocess_data(var_1)
    var_3 = type(var_2)
    assert var_3 == dict
    var_3 = var_2.get('role')
    var_4 = type(var_3)
    assert var_4 == str
    var_4 = var_3 == 'test'
    assert var_4 == True
    var_5 = var_2.get('other')
    var_6 = type(var_5)
    assert var_6 == Attribute
    var_6 = str(var_5)
    var_7 = type(var_6)
   

# Generated at 2022-06-25 05:45:57.943632
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    rd = RoleDefinition()
    ds = {'role': 'common', 'meta': {'foo': 'bar'}}
    rd.preprocess_data(ds)

# Generated at 2022-06-25 05:46:01.163864
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    var_0 = RoleDefinition(**dict())
    var_1 = dict()

    var_1 = var_0.preprocess_data(var_1)
    assert(var_1 == dict())


# Generated at 2022-06-25 05:46:11.431237
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():

    # Setup
    # Initialization of objects for test
    role_collection = 'ansible.builtin'
    role_name = 'apt'
    role_path = '/home/fcoelho/.ansible/collections/ansible_collections/ansible/builtin/roles/apt'
    variable_manager = dict()
    role_def = RoleDefinition(variable_manager=variable_manager)

    # Mocking the variable_manager
    variable_manager.get_vars = lambda play=None: dict()
    variable_manager.set_nonpersistent_facts = lambda x: None
    variable_manager.set_facts = lambda x: None

    # Mocking _load_role_name
    role_def._load_role_name = lambda x: role_name

    # Mocking _load_role_path
    role_

# Generated at 2022-06-25 05:46:18.330256
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():

    import ansible.parsing.yaml.objects

    ds = dict()
    role_basedir = ''
    variable_manager = None

    # set up the following attributes on the object
    #
    #
    # _ds = ds
    # _role_path = role_path
    # _role_basedir = role_basedir
    # _role_params = role_params
    # _variable_manager = variable_manager
    #
    # inputs:
    #   ds
    #   role_basedir
    #   variable_manager
    #
    # outputs:
    #   self._ds = ds
    #   self._role_path
    #   self._role_basedir
    #   self._role_params
    #   self._variable_manager
    #

# Generated at 2022-06-25 05:46:21.321569
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    ds = None
    variable_manager = None
    loader = None
    role_def = RoleDefinition()
    role_def.preprocess_data(ds)
    role_def_2 = RoleDefinition(play=None, variable_manager=variable_manager, loader=loader)
    role_def_2.preprocess_data(ds)
    role_def_3 = RoleDefinition(play=None, variable_manager=variable_manager, loader=loader)
    role_def_3.preprocess_data(ds)


# Generated at 2022-06-25 05:46:31.240687
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():

    var_0 = dict()
    var_1 = dict()
    var_0 = Attribute()
    var_0.name = 'hostvars'
    var_0.static = True
    var_1['hostvars'] = var_0
    var_0 = Attribute()
    var_0.name = 'group_names'
    var_0.static = True
    var_1['group_names'] = var_0
    var_0 = Attribute()
    var_0.name = 'groups'
    var_0.static = True
    var_1['groups'] = var_0
    var_0 = Attribute()
    var_0.name = 'ansible_ssh_host'
    var_0.default = False
    var_0.required = False

# Generated at 2022-06-25 05:46:37.036314
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    var_0 = RoleDefinition.load(dict())
    var_0 = RoleDefinition.load('name')
    var_0 = RoleDefinition.load(dict(role='name'))
    var_0 = RoleDefinition.load(dict(role=dict()))
    var_0 = RoleDefinition.load(dict(role=dict(), a='b'))


# Generated at 2022-06-25 05:46:39.764754
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    var_1 = RoleDefinition()
    var_2 = dict()
    var_1.preprocess_data(var_2)


# Generated at 2022-06-25 05:46:49.213011
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    var_0 = {"name": "test_role", "role": "test_role"}
    var_1 = var_0
    var_1.pop("role")
    var_2 = var_0
    var_2.pop("name")
    var_3 = {"foo": "bar"}
    var_4 = "test_role"
    var_5 = 123
    var_6 = {"role": 1}
    var_7 = {"role": "test_role", "bad_key": "bad_value"}
    var_8 = {"name": "test_role", "bad_key": "bad_value"}
    var_9 = {"role": "test_role", "a": "b", "c": "d"}

# Generated at 2022-06-25 05:46:54.972242
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    print("Test: preprocess_data")

    # FIXME



# Generated at 2022-06-25 05:46:58.618942
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    var_0 = RoleDefinition(role_basedir=None, variable_manager=None, loader=None, play=None, collection_list=None)
    var_1 = None

    res = var_0.preprocess_data(var_1)

    assert res is not None


# Generated at 2022-06-25 05:47:09.823666
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    var_0 = 'role_name'
    var_1 = dict(
        role = 'role_name',
        enabled = 'yes',
        other = 'other_value',
    )
    var_1 = dict()
    var_1 = dict(
        role = 'role_name',
        enabled = 'yes',
        other = 'other_value',
    )

    # setup test env
    var_0 = 'role_name'
    var_1 = dict(
        role = 'role_name',
        enabled = 'yes',
        other = 'other_value',
    )
    test_instance = RoleDefinition.load(var_1)
    assert test_instance._attributes['role'] == var_0

    # test
    test_instance.preprocess_data(var_1)
    assert test_instance

# Generated at 2022-06-25 05:47:11.977863
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    var_0 = dict()
    obj_0 = RoleDefinition()
    obj_1 = obj_0.preprocess_data(var_0)


# Generated at 2022-06-25 05:47:17.759208
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_def = RoleDefinition(role_basedir="/tmp/ansible_n9nNzM/tmpfjKqgP",
                              variable_manager=var_0, loader=var_0)
    # call function
    result = role_def.preprocess_data(var_0)



# Generated at 2022-06-25 05:47:19.366012
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    var_0 = RoleDefinition()
    var_1 = dict()

    obj = var_0.preprocess_data(var_1)
    

# Generated at 2022-06-25 05:47:20.761452
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    var_0 = dict()
    var_1 = RoleDefinition._RoleDefinition__split_role_params(var_0)


# Generated at 2022-06-25 05:47:31.048485
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():

    # Testing the first of the two branches
    if True:
        var_0 = dict()
        var_0['role_basedir'] = 'some_dir'
        var_0['loader'] = {'get_basedir': lambda : 'some_dir/roles'}
        var_0['variable_manager'] = {'get_vars': lambda x: {}}
        var_0['collection_list'] = []

        # Testing the first of the three branches
        if True:
            var_0['ds'] = dict()
            var_0['ds'] = dict()
            var_0['ds']['role'] = {'template': lambda : 'some_dir/test'}

            # Testing the first of the three branches
            if True:
                var_0['result'] = dict()

                # Testing the first of the

# Generated at 2022-06-25 05:47:42.027827
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():

    assert 1 == 1
    assert 'Gur Chefhvg bs Uncv-arff' == 'Gur Chefhvg bs Uncv-arff'
    assert 'Gur Chefhvg bs Uncv-arff'.encode('UTF-8') == 'Gur Chefhvg bs Uncv-arff'.encode('UTF-8')
    assert 'Gur Chefhvg bs Uncv-arff'.encode('UTF-8') == 'Gur Chefhvg bs Uncv-arff'.encode('UTF-8')
    assert 'Gur Chefhvg bs Uncv-arff'.encode('UTF-8') == 'Gur Chefhvg bs Uncv-arff'.encode('UTF-8')
    assert 'Gur Chefhvg bs Uncv-arff'.encode('UTF-8')

# Generated at 2022-06-25 05:47:46.698714
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():

    # Check for "include" keyword in input data
    # and compare to expected result.
    assert test_case_0 == AnsibleMapping()

#
# Run unit tests
#
# FIXME: Will these be picked up by nosetests?
#

test_RoleDefinition_preprocess_data()

# Generated at 2022-06-25 05:47:58.147193
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    test_case = 0
    var_0 = RoleDefinition()
    var_0.preprocess_data()
    test_case += 1

    var_1 = RoleDefinition()
    var_1.preprocess_data()
    test_case += 1

    var_2 = RoleDefinition()
    var_2.preprocess_data()
    test_case += 1

    var_3 = RoleDefinition()
    var_3.preprocess_data()
    test_case += 1

    var_4 = RoleDefinition()
    var_4.preprocess_data()
    test_case += 1

    var_5 = RoleDefinition()
    var_5.preprocess_data()
    test_case += 1

    var_6 = RoleDefinition()
    var_6.preprocess_data()
    test_case += 1

    var_

# Generated at 2022-06-25 05:48:03.258260
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    obj = RoleDefinition()

    # Test with arguments: ds
    test_0 = "test string"
    var_0 = test_0
    obj.preprocess_data(var_0)

    # Test with arguments: ds
    test_1 = int
    var_1 = test_1
    obj.preprocess_data(var_1)

    # Test with arguments: ds
    test_2 = dict
    var_2 = test_2
    obj.preprocess_data(var_2)

    # Test with arguments: ds
    test_3 = AnsibleMapping
    var_3 = test_3
    obj.preprocess_data(var_3)

    # Test with arguments: ds
    test_4 = AnsibleBaseYAMLObject
    var_4 = test_4

# Generated at 2022-06-25 05:48:07.513584
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_name = "collection_name.role_name"
    data = dict(role_name)
    role_def = RoleDefinition(ds=data, variable_manager=var_0)
    role_def.preprocess_data(ds=data)
    role_path = role_def.get_role_path()
    assert role_path == '/home/ansible/collection_name/roles/name'

## Unit test for method get_name of class RoleDefinition
#def test_RoleDefinition_get_name():
#    role_name = "collection_name.role_name"
#    data = dict(role_name)
#    role_def = RoleDefinition(ds=data, variable_manager=var_0)
#    role_def.preprocess_data(ds=data)
#    fqcr = role_def

# Generated at 2022-06-25 05:48:12.548649
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    var_0 = RoleDefinition()
    var_0.role = 'foo'
    var_1 = var_0.get_name()
    var_2 = 'foo'
    assert var_1 == var_2


# Generated at 2022-06-25 05:48:14.010352
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    test_case_0()


# Generated at 2022-06-25 05:48:16.166291
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    var_1 = test_case_0()
    var_2 = u'foo.bar'
    var_3 = RoleDefinition(var_1, var_2, var_1, var_1)
    var_4 = var_3.get_name()
    assert var_4 == var_2

# Generated at 2022-06-25 05:48:26.216456
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():

    # This is a test case for the preprocess_data function for the class RoleDefinition
    # This test case does not make use of the inventory or other ansible components
    # and it is a simulation of the preprocessing of a data structure into the
    # class fields prior to use in the playbook

    data = dict(
        role="test_role",
        role_params=dict(
            test_param_1="value1",
            test_param_2="value2",
        )
    )

    # Setup the initial RoleDefition object
    role_def = RoleDefinition()
    # Setup the attribute fields for the Role Definition
    role_def.add_field(Attribute.from_spec("role", attr_type=str, default="test_role"))
    # Perform the preprocessing of the data structure into the RoleDefintion Object
    role_

# Generated at 2022-06-25 05:48:34.702561
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    var_0 = dict()
    var_0['role'] = 'test'
    var_1 = dict()
    var_1['name'] = 'test'
    var_2 = dict()
    var_2['var'] = 'test'
    yaml_obj = list()
    yaml_obj.append(var_0)
    yaml_obj.append(var_1)
    yaml_obj.append(var_2)
    for item in yaml_obj:
        role_def = RoleDefinition.load(item)
        role_def.preprocess_data(item)

# Generated at 2022-06-25 05:48:45.560097
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    simple_test_0 = ''
    simple_test_1 = ''
    simple_test_2 = ''
    simple_test_3 = ''
    test_0 = dict(socket)
    test_1 = dict(socket)
    test_2 = dict(socket)
    test_3 = dict(socket)

    # Run test case 0 on a simple string
    try:
        RoleDefinition.preprocess_data(simple_test_0)
    except AnsibleError:
        pass

    # Run test case 1 on a simple string
    try:
        RoleDefinition.preprocess_data(simple_test_1)
    except AnsibleError:
        pass

    # Run test case 2 on a simple string
    try:
        RoleDefinition.preprocess_data(simple_test_2)
    except AnsibleError:
        pass



# Generated at 2022-06-25 05:48:48.820311
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    var_0 = RoleDefinition()
    var_1 = var_0.get_name()
    if var_1:
        if True:
            raise test_case_0()
    else:
        if True:
            raise test_case_0()

# Generated at 2022-06-25 05:48:57.354904
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():

    # Assert definition
    var_0 = [ 'role' ]
    assert var_0 == var_0

# Generated at 2022-06-25 05:48:58.383875
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    test_case_0()

# Generated at 2022-06-25 05:48:59.574448
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    result = test_case_0()
    assert result

# Generated at 2022-06-25 05:49:09.062160
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    var_0 = dict()
    var_1 = dict()
    var_2 = dict()
    var_3 = dict()
    var_4 = dict()
    var_5 = dict()
    var_6 = dict()
    var_7 = dict()
    var_8 = dict()
    var_9 = dict()
    var_10 = dict()
    var_11 = dict()
    var_12 = dict()
    var_13 = dict()
    var_14 = dict()
    var_15 = dict()
    var_16 = dict()
    var_17 = dict()
    var_18 = dict()
    var_19 = dict()
    var_20 = dict()
    var_21 = dict()
    var_22 = dict()
    var_23 = dict()
    var_24 = dict()

# Generated at 2022-06-25 05:49:11.846852
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    var = RoleDefinition()
    var_ds = dict()
    assert var.preprocess_data(var_ds) == None

# Generated at 2022-06-25 05:49:14.835427
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    var_test = {'message': 'bar'}
    var_test = RoleDefinition._serialize_value(var_test)
    assert var_test == {'message': 'bar'}


# Generated at 2022-06-25 05:49:22.824969
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    var_0 = ";e&1S[vX8Wn,n:>|@V$4Kk]`#Z`I#;,1pr%-Qq|/d{Y>Q&<+sPOh,tPuwvk)C7Nu@t!z]N3qgIVYX2{H&<+sPOh,tPuwvk)C7Nu@t!z]N3qgIVYX2{H'&#cu$|]4GCKY::Z$4Kk]`#Z`I#"
    var_1 = Attribute()
    var_2 = Conditional()
    var_3 = None
    var_4 = Conditional()
    var_5 = Conditional()
    var_6 = ""

# Generated at 2022-06-25 05:49:32.011560
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    var_0 = dict()
    var_0 = {'role': 'role0'}
    var_1 = RoleDefinition.load(var_0)
    assert var_1.get_name() == 'role0'

    var_0 = {'role': 'role1', 'nested': {'opts': {'l': 'a'}}}
    var_1 = RoleDefinition.load(var_0)
    assert var_1.get_name() == 'role1'

    var_0 = {'role': 'role2', 'nested': {'opts': {'l': 'a'}}, 'b': 'c'}
    var_1 = RoleDefinition.load(var_0)
    assert var_1.get_name() == 'role2'


# Generated at 2022-06-25 05:49:36.798425
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    var_0 = RoleDefinition()

# Generated at 2022-06-25 05:49:48.079529
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    var_0 = RoleDefinition(variable_manager=var_0)
    var_0.role = 'foobar'
    var_0.RoleDefinition_get_role_params()
    var_0.RoleDefinition_get_role_path()
    result = var_0.get_name()
    assert result is not None
    assert isinstance(result, string_types)
    assert result == ''
    assert result == 'foobar'

    var_0 = RoleDefinition(variable_manager=var_0)
    var_0.role = 'foobar'
    var_0.RoleDefinition_get_role_params()
    var_0.RoleDefinition_get_role_path()
    result = var_0.get_name()
    assert result is not None
    assert isinstance(result, string_types)

# Generated at 2022-06-25 05:49:57.034549
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_def = RoleDefinition()
    # TODO: Fill in the test case with actual parameters
    print(role_def.preprocess_data(var_0))
    assert False


# Generated at 2022-06-25 05:49:59.427881
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    loader = None
    variable_manager = None
    data = dict()
    role_basedir = None
    collection_list = None
    obj = RoleDefinition(play=None, role_basedir=role_basedir, variable_manager=variable_manager, loader=loader, collection_list=collection_list)
    result = obj.preprocess_data(data)
    assert result is var_0

# Generated at 2022-06-25 05:50:10.807512
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_data_0 = dict()
    role_data_0['role'] = 'test'
    role_data_0['tasks'] = [ { 'meta': 'test', 'block': 'test' } ]
    role_data_0['handlers'] = [ { 'meta': 'test', 'block': 'test' } ]
    role_data_0['defaults'] = [ { 'meta': 'test', 'block': 'test' } ]
    role_data_0['vars'] = [ { 'meta': 'test', 'block': 'test' } ]
    role_data_0['meta'] = [ { 'meta': 'test', 'block': 'test' } ]
    role_data_0['pre_tasks'] = [ { 'meta': 'test', 'block': 'test' } ]
    role_data_0

# Generated at 2022-06-25 05:50:20.717048
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    for x in range(2):
        if x == 0:
            var_0 = RoleDefinition()
            var_0.preprocess_data('test_val_5')
        elif x == 1:
            var_0 = RoleDefinition()
            var_0.preprocess_data(dict())
    return True


if __name__ == '__main__':
    import sys
    import json

    vars_dict = dict()
    vars_dict['test_case_0'] = test_case_0()

    for k, v in vars_dict.items():
        print("{} = {}".format(k, json.dumps(v)))
    if not vars_dict['test_case_0']:
        sys.exit(1)
        #sys.exit(not test_all_cases())

# Generated at 2022-06-25 05:50:23.996560
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    try:
        var_0 = RoleDefinition()
        var_1 = var_0.preprocess_data(var_0.__dict__)
        assert var_1 is None
    except AssertionError:
        raise AssertionError(AssertionError())
    except:
        assert False


# Generated at 2022-06-25 05:50:28.107412
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    var_0 = RoleDefinition.load(data=None, variable_manager=None, loader=None)
    # None
    var_0.preprocess_data(ds=None)


# Generated at 2022-06-25 05:50:40.006806
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    from ansible.parsing.yaml.objects import AnsibleMapping


# Generated at 2022-06-25 05:50:50.007394
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():

    # Simple test case, with just a role name
    print("test_case_0")
    display.display("test_case_0", color='green', screen_only=True)
    result = True
    try:
        role = RoleDefinition()
        role.preprocess_data("role_name_00")
    except Exception as e:
        display.display("Error: %s" % e, color='red', screen_only=True)
        result = False
    assert result == True

    # Test case with a complex role def, using all the supported fields except 'collections'
    print("test_case_1")
    display.display("test_case_1", color='green', screen_only=True)
    result = True

# Generated at 2022-06-25 05:50:58.832067
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    var_0 = dict()

    var_0['roles'] = [ "some.collection.here" ]

    loader = None
    variable_manager = None

    r = RoleDefinition(None, None, variable_manager, loader, var_0)

    ds = dict()

    r._load_role_name = test_case_0
    r._load_role_path = test_case_0
    r._split_role_params = test_case_0

    r.preprocess_data(ds)

if __name__ == '__main__':
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-25 05:51:00.687859
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    var_0 = dict()
    assert(var_0 == test_case_0())

# Generated at 2022-06-25 05:51:15.044594
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    role_definition = RoleDefinition()
    # 'role_definition' is an instance of class RoleDefinition
    # 'get_name' is a public method of class RoleDefinition
    assert isinstance(role_definition.get_name(), string_types)

    # 'role_definition' is an instance of class RoleDefinition
    # 'get_name' is a public method of class RoleDefinition
    # 'include_role_fqcn' is a parameter of get_name
    assert isinstance(role_definition.get_name(include_role_fqcn=False), string_types)


# Generated at 2022-06-25 05:51:17.114380
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    rd = RoleDefinition()
    assert rd.get_name() == "RoleDefinition"

test_case_0()
test_RoleDefinition_get_name()

# Generated at 2022-06-25 05:51:24.091053
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    # Describe test case input
    ansible_playbook_basedir = "./"
    ansible_playbook_role_basedir = "./roles"

    # Describe test case output
    role_definition_preprocess_data_role_name = "test_role"
    role_definition_preprocess_data_role_params = {}
    role_definition_preprocess_data_role_path = "./roles/test_role"
    role_definition_preprocess_data_returned_ds = {'role': 'test_role'}

    # Describe test data
    role_definition_preprocess_data_test_data_0 = {}
    role_definition_preprocess_data_test_data_1 = "test_role"

# Generated at 2022-06-25 05:51:34.326791
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():

    role_definition = RoleDefinition()
    role_definition._loader = None
    role_definition._variable_manager = None

    # Valid Input

    # Name Only
    ds = dict()
    ds['role'] = 'git'
    ds_expected = dict()
    ds_expected['role'] = 'git'
    ret = role_definition.preprocess_data(ds)
    assert ret == ds_expected

    # Name And Params
    ds = dict()
    ds['role'] = 'git'
    ds['some_param'] = 'some_value'
    ds_expected = dict()
    ds_expected['role'] = 'git'
    ret = role_definition.preprocess_data(ds)
    assert ret == ds_expected

    # Path
    ds = dict()

# Generated at 2022-06-25 05:51:42.191281
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition_0 = RoleDefinition()

    ds = {"role": "role1"}

    role_definition_0.preprocess_data(ds)
    assert role_definition_0.role == "role1"
    assert role_definition_0._role_path == None
    assert role_definition_0._variable_manager == None
    assert role_definition_0._loader == None
    assert role_definition_0._collection_list == None
    assert role_definition_0._ds == {"role": "role1"}

# Generated at 2022-06-25 05:51:44.056585
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition_obj=RoleDefinition()
    role_definition_obj.preprocess_data(())

# Generated at 2022-06-25 05:51:53.276992
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    # Simple case:
    role_definition = RoleDefinition()
    ds = {'name': 'simple-case'}
    ds2 = role_definition.preprocess_data(ds)
    assert ds2['role'] == "simple-case"
    assert ds2['name'] is None

    # Simple string case:
    role_definition = RoleDefinition()
    ds = "simple-string"
    ds2 = role_definition.preprocess_data(ds)
    assert ds2['role'] == "simple-string"
    assert ds2['name'] is None

    # Simple string case with whitespace:
    role_definition = RoleDefinition()
    ds = "simple-string-with-whitespace"
    ds2 = role_definition.preprocess_data(ds)
    assert ds2

# Generated at 2022-06-25 05:51:54.794649
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition_0 = RoleDefinition()
    role_definition_0.preprocess_data(100)

# Generated at 2022-06-25 05:52:02.495955
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    # Check that an error is raised if ds is a dict with no key "role"
    # (or "name")
    ds = {"no": "role"}
    role_definition_0 = RoleDefinition()
    try:
        role_definition_0.preprocess_data(ds)
    except Exception as e:
        assert isinstance(e, AnsibleError)
        assert "role definitions must contain a role name" in str(e)
    
    # Check that an AnsibleAssertionError is raised if ds is neither a
    # dict, string_types, nor an AnsibleBaseYAMLObject
    ds = 23
    role_definition_0 = RoleDefinition()

# Generated at 2022-06-25 05:52:12.764201
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition_0 = RoleDefinition()

    # Invalid type for argument data
    with pytest.raises(AnsibleAssertionError):
        role_definition_0.preprocess_data([0])

    # Invalid value for role:
    role_definition_1 = RoleDefinition()
    data_1 = dict(role=None)
    with pytest.raises(AnsibleError):
        role_definition_1.preprocess_data(data_1)

    # Simple string value
    role_definition_2 = RoleDefinition()
    data_2 = 'simple-string'
    result_2 = role_definition_2.preprocess_data(data_2)
    assert result_2['role'] == 'simple-string'

    # Minimal role definition with role: key
    role_definition_3 = RoleDefinition()


# Generated at 2022-06-25 05:52:23.961743
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    rd = RoleDefinition()

    # We have to test all these cases because of preprocess_data's complex
    # behavior.
    ds_tests = [
        # Test hash:
        dict(role="foo_role", some_hash_key="some_hash_value"),
        dict(name="foo_role", some_hash_key="some_hash_value"),
        dict(role="foo_role"),
        dict(name="foo_role"),
        # Test string only:
        "foo_role",
        # Test None:
        None,
    ]
    for ds in ds_tests:

        # If we pass ds in to preprocess_data, we should get back a dictionary.
        ds_copy = ds.copy() if isinstance(ds, dict) else ds
        new_ds = rd

# Generated at 2022-06-25 05:52:31.849505
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():

    # TODO:  have test check that name is set when only a path exists (and path is set to the name)
    # TODO:  have test check that name is set when both name and path are provided and they are identical
    # TODO:  have test check that name is set when both name and path are provided and they are different
    # TODO:  have test check that role_path is set when only a name exists
    # TODO:  have test check that role_path is set when both name and path are provided and they are identical
    # TODO:  have test check that role_path is set when both name and path are provided and they are different

    raise AnsibleError("not implemented")

# Generated at 2022-06-25 05:52:34.787035
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    role_definition_1 = RoleDefinition()
    assert role_definition_1.get_name() == None


# Generated at 2022-06-25 05:52:41.279280
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition_0 = RoleDefinition()
    # Testing possible values for argument ds
    role_definition_0.preprocess_data("SimpleString")
    role_definition_0.preprocess_data({"AKey": "AValue"})

if __name__ == '__main__':
    test_case_0()
    test_RoleDefinition_preprocess_data()

# Generated at 2022-06-25 05:52:50.764512
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.utils.display import Display

    display = Display()
    play = "test_play"
    role_basedir = "test_dir"
    collection_list = "test_list"
    attribute_manager = {}
    loader = "test_loader"
    loader_obj = AnsibleMapping()
    loader_obj['__ansible_module__'] = type('test_loader', (object,), {'default_vars': attribute_manager})
    role_definition_0 = RoleDefinition(play=play, role_basedir=role_basedir, loader=loader_obj,
                                       collection_list=collection_list)
    # test when ds is of type int
    # Expecting assertRaise here as in this case ds is integer

# Generated at 2022-06-25 05:52:52.863986
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    role_definition = RoleDefinition()
    role_definition._role_collection = ""
    role_definition._role = "test_role"
    assert(role_definition.get_name() == "test_role")


# Generated at 2022-06-25 05:52:59.260848
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    print("")
    print("***** RoleDefinition.preprocess_data unit test *****")
    test_playbook = os.path.join("test/test_data", "test_playbook.yml")
    loader = DataLoader()
    role_definition = RoleDefinition()
    role_definition.data_from_file(loader, test_playbook)
    test_result = role_definition.preprocess_data(role_definition._ds)
    if test_result["role"] == "test_role":
        print("preprocess_data test passed")
    else:
        print("preprocess_data test failed")
    print("")


# Generated at 2022-06-25 05:53:07.662756
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    # 1. Create a RoleDefinition object
    # 2. Call preprocess_data with a simple string
    # 3. Verify that the returned data structure has the given string as its role_name
    # 4. Call preprocess_data with a data structure that contains a 'role' field, but no name field
    # 5. Verify that the returned data structure has the name from the role field
    # 6. Call preprocess_data with a data structure that contains a 'name' field, but no role field
    # 7. Verify that the returned data structure has the name from the name field
    # 8. Call preprocess_data with a data structure that contains both a 'name' and 'role' field
    # 9. Verify that the returned data structure has the name from the name field
       
    # 1. Create a RoleDefinition object
    role_definition_0 = RoleDefinition()



# Generated at 2022-06-25 05:53:14.980701
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    rd = RoleDefinition()
    role_name = "test_role"
    role_file_path = "./test_role/roles" + role_name
    role_params = dict(
        param1=1,
        param2=2,
        param3=3
    )
    test_data = dict(
        role=role_file_path,
        param1=1,
        param2=2,
        param3=3
    )
    expected_result = dict(
        role=role_name,
    )
    rd.preprocess_data(test_data)
    assert rd._role_path is not None
    assert rd._role_path == role_file_path
    assert rd._role_params is not None
    assert rd._role_params == role_params

# Generated at 2022-06-25 05:53:23.376020
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    # Test case when a bare string is passed
    role_definition_1 = RoleDefinition()
    ret = role_definition_1.preprocess_data('kvm')
    assert isinstance(ret, dict)
    assert ret['role'] == 'kvm'

    # Test case when a dictionary is passed with role attribute
    role_definition_2 = RoleDefinition()
    d = dict(
        role="test_role"
    )
    ret = role_definition_2.preprocess_data(d)
    assert isinstance(ret, dict)
    assert ret['role'] == 'test_role'

    # Test case when a dictionary is passed with name attribute
    role_definition_3 = RoleDefinition()
    d = dict(
        name="test_role"
    )

# Generated at 2022-06-25 05:53:34.361754
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():

    def get_name_side_effect(include_role_fqcn):
        if (include_role_fqcn):
            return self.role_name_called_0
        return self.role_name_called_1


    role_definition_0 = RoleDefinition()
    role_definition_0.role = 'foobar'

    assert role_definition_0.get_name() == 'foobar'
    assert role_definition_0.get_name(False) == 'barfoo'

# Generated at 2022-06-25 05:53:43.047179
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition = RoleDefinition()
    
    # Test 1#: When the data structure is not a dictionary, raise an assert exception
    ds = 1
    try:
        role_definition.preprocess_data(ds)
    except (AssertionError):
        pass
    else:
        assert False
    
    # Test 2#: When the data structure is a dictionary, and it has a role name, and it has role params,
    # then preprocess that data structure, and return a new data structure with the role name and the
    # role params
    ds = {"role": "test_role_name", "role_param_key": "test_role_param_value"}
    new_ds = role_definition.preprocess_data(ds)
    assert new_ds == {'role': 'test_role_name'}
   

# Generated at 2022-06-25 05:53:52.940982
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition_0 = RoleDefinition()
    role_definition_1 = RoleDefinition()
    role_definition_2 = RoleDefinition()

    ds_0 = dict({'role': 'test_role'})
    new_ds_0 = role_definition_0.preprocess_data(ds_0)
    assert ds_0 == new_ds_0

    ds_1 = dict({'role': 'test_role', 'name': 'test_name'})
    new_ds_1 = role_definition_1.preprocess_data(ds_1)
    assert ds_1 == new_ds_1

    ds_2 = dict({'role': 'test_role', 'name': 'test_role'})
    new_ds_2 = role_definition_2.preprocess_data(ds_2)
   

# Generated at 2022-06-25 05:54:03.042954
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition_0 = RoleDefinition()
    assert(role_definition_0.preprocess_data('my-role') == { 'role': 'my-role' })
    assert(role_definition_0.preprocess_data({'role': 'my-role'}) == { 'role': 'my-role' })
    try:
        role_definition_0.preprocess_data({})
    except:
        assert True
    else:
        assert False
    assert(role_definition_0.preprocess_data({'name': 'my-role'}) == { 'role': 'my-role' })
    assert(role_definition_0.preprocess_data({'role': 'my-role', 'name': 'my-role'}) == { 'role': 'my-role' })

# Generated at 2022-06-25 05:54:06.600902
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    """Test a full role definition.
    """

    role_definition = RoleDefinition()
    role_definition.preprocess_data(  # noqa: F841
        {'role': 'foo'}
    )



# Generated at 2022-06-25 05:54:18.324475
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    output_dict = dict()

    input_string = "my_role"
    role_definition_object = RoleDefinition()

    def side_effect_loader_path_exists_1(arg, ignore_provider):
        return True

    class Side_effect_Loader(object):

        def get_basedir(self):
            return

        def path_exists(self, arg, ignore_provider=True):
            return side_effect_loader_path_exists_1(arg, ignore_provider)

    my_loader = Side_effect_Loader()
    role_definition_object._loader = my_loader

    def side_effect_variable_manager_get_vars_1(arg):
        return dict()

    class Side_effect_VariableManager(object):

        def get_vars(self, arg):
            return

# Generated at 2022-06-25 05:54:24.621511
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition_0 = RoleDefinition()
    role_definition_0.preprocess_data({'role': {'role': {'role': 'test'}, 'test': 'test'}})
    role_definition_0.preprocess_data({'role': {'role': 'test'}})
    role_definition_0.preprocess_data({'role': 'test'})
    role_definition_0.preprocess_data('test')

# Generated at 2022-06-25 05:54:29.858451
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition_1 = test_RoleDefinition_generate()

    # We should get error when "role_definition_1.preprocess_data(ds)" is called with "ds" having type other than
    # "AnsibleMapping"
    ds_list = ["my_role", 1, None, [], object()]

    for ds in ds_list:
        try:
            role_definition_1.preprocess_data(ds)
        except AnsibleAssertionError:
            continue
        except Exception as e:
            raise AssertionError("Some unexpected error occurred: %s" % str(e))
        raise AssertionError("AnsibleAssertionError is not raised when preprocess_data(ds) is called with "
                             "ds having incorrect type: %s" % str(type(ds)))



# Generated at 2022-06-25 05:54:38.035850
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    # Test case when data structure is not a dictionary
    # Expected exception: AssertionError
    try:
        role_definition_0 = RoleDefinition()
        role_definition_0.preprocess_data(1)
        assert False
    except Exception as exception:
        # Test case when data structure is not a dictionary
        # Expected exception: AnsibleAssertionError
        assert type(exception) == AnsibleAssertionError
    except AssertionError:
        pass

    # Test case when valid data structure is provided
    # Expected result: the passed in data structure
    role_definition_1 = RoleDefinition()
    assert role_definition_1.preprocess_data({'role': 'some_role'}) == {'role': 'some_role'}

    # Test case when a role name is provided instead of a data structure


# Generated at 2022-06-25 05:54:47.126402
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():

    role_definition_0 = RoleDefinition()

    
    data_0 = {'role': 'common', 'tasks': [], 'handlers': [], 'vars': {}, 'defaults': {}, 'meta': {}}

    # Expected value of data_0
    data_parsed_0 = {'role': 'common', 'tasks': [], 'handlers': [], 'vars': {}, 'defaults': {}, 'meta': {}}

    role_definition_0.preprocess_data(data_0)
    assert data_0 == data_parsed_0

    # Test for exception: AttributeError
    # test of method preprocess_data of class RoleDefinition
    # with the following statement:
    #     raise AttributeError(name)
    # Expected value of data_0
    #data_