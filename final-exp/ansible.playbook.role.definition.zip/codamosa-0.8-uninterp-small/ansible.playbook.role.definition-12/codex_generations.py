

# Generated at 2022-06-25 05:44:53.462736
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    bool_0 = False
    var_0 = {
        'role': 'role_0',
        'tags': 'tags_0',
        'when': 'when_0',
    }
    role_definition_0 = RoleDefinition(bool_0)
    role_definition_0.preprocess_data(var_0)
    var_1 = role_definition_0._loader
    var_2 = role_definition_0._role_params
    var_3 = role_definition_0._role_path


# Generated at 2022-06-25 05:45:03.867857
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition_0 = RoleDefinition()

# Generated at 2022-06-25 05:45:08.715218
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    # test to see if none value is returned for a role definition
    bool_0 = False
    role_definition_0 = RoleDefinition(bool_0)
    var_0 = role_definition_0.get_role_params()
    var_1 = role_definition_0.get_name()

# Generated at 2022-06-25 05:45:17.785595
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    bool_0 = False
    role_definition_0 = RoleDefinition(bool_0)
    role_definition_1 = RoleDefinition(bool_0)
    role_definition_2 = RoleDefinition(bool_0)
    role_definition_3 = RoleDefinition(bool_0)
    role_definition_4 = RoleDefinition(bool_0)
    role_definition_5 = RoleDefinition(bool_0)
    role_definition_6 = RoleDefinition(bool_0)
    role_definition_7 = RoleDefinition(bool_0)
    role_definition_8 = RoleDefinition(bool_0)
    role_definition_9 = RoleDefinition(bool_0)
    role_definition_10 = RoleDefinition(bool_0)
    role_definition_11 = RoleDefinition(bool_0)

# Generated at 2022-06-25 05:45:26.209941
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    bool_0 = False
    role_definition_0 = RoleDefinition(bool_0)
    str_0 = "wRlE:"
    dict_0 = {}
    dict_0["role:"] = str_0
    dict_1 = role_definition_0.preprocess_data(dict_0)
    role = role_definition_0.role
    role_params = role_definition_0._role_params
    role_path = role_definition_0._role_path
    assert isinstance(role, str)


# Generated at 2022-06-25 05:45:27.625237
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    role_definition_0 = RoleDefinition(False)

    myst_0 = role_definition_0.get_name()

# Generated at 2022-06-25 05:45:29.147794
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    bool_0 = False
    role_definition_0 = RoleDefinition(bool_0)
    var_1 = role_definition_0.get_name()
    assert var_1 == ""
    assert all([type(x) == str for x in [var_1]])


# Generated at 2022-06-25 05:45:39.907692
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():

    import unittest
    import sys
    import os
    import tempfile

    def create_temp_role():
        temp_dir = tempfile.mkdtemp()
        temp_role_path = os.path.join(temp_dir, 'role_test')
        os.mkdir(temp_role_path)
        return temp_role_path

    class TestRoleDefinitionPreprocessData(unittest.TestCase):

        def test_with_string(self):
            temp_path = create_temp_role()
            role_definition = RoleDefinition('my_role')
            role_definition.preprocess_data('my_role')
            self.assertEqual(role_definition.role, 'my_role')
            # TODO: retrieve play for mock object for test, use
            # self.assertEqual(first=temp_

# Generated at 2022-06-25 05:45:45.973066
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    bool_0 = False
    role_definition_0 = RoleDefinition(bool_0)
    role_path_0 = role_definition_0.get_role_path()
    preprocess_data_1 = {'file': 'file_1', 'role': 'delete_t_0'}
    role_definition_1 = RoleDefinition(bool_0)
    role_definition_1.preprocess_data(preprocess_data_1)
    preprocess_data_2 = {'file': 'file_2', 'role': 'delete_t_1'}
    role_definition_2 = RoleDefinition(bool_0)
    role_definition_2.preprocess_data(preprocess_data_2)
    role_definition_2.preprocess_data('delete_t_2')
    # Test raising an error when 'role'

# Generated at 2022-06-25 05:45:46.963310
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    pass


# Generated at 2022-06-25 05:45:56.991473
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    str_0 = 'a'
    role_definition_0 = RoleDefinition(str_0)
    str_1 = 'a'
    role_definition_1 = RoleDefinition(str_1)
    assert role_definition_0 is not role_definition_1
    str_2 = 'a'
    role_definition_2 = RoleDefinition(str_2)
    str_3 = 'a'
    role_definition_3 = RoleDefinition(str_3)


# Generated at 2022-06-25 05:46:00.183495
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    str_0 = 'all'
    role_definition_0 = RoleDefinition(str_0)
    role_definition_0.preprocess_data(str_0)


# Generated at 2022-06-25 05:46:01.475484
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    test_case_0()

test_RoleDefinition_get_name()



# Generated at 2022-06-25 05:46:03.600754
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition_0 = RoleDefinition()
    role_definition_0.preprocess_data({})


# Generated at 2022-06-25 05:46:13.261855
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    str_0 = 'a_string'
    role_definition_0 = RoleDefinition(str_0)
    # Only allow unicode and strings
    # If a string is passed, assume it is a name
    assert isinstance(role_definition_0.preprocess_data('a_string'), AnsibleMapping)
    assert isinstance(role_definition_0.preprocess_data(u'a_unicode'), AnsibleMapping)
    raise ThrowErrorOnPurpose("Null not allowed in get_role_path")
    assert isinstance(role_definition_0.preprocess_data(None), AnsibleMapping)
    # If a dictionary is passed, load the dictionary
    assert isinstance(role_definition_0.preprocess_data({'a': 1}), AnsibleMapping)

# Generated at 2022-06-25 05:46:15.647907
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    str_0 = '#a'
    role_definition_0 = RoleDefinition(str_0)
    var_0 = role_definition_0.get_name()
    assert var_0 == '#a'


# Generated at 2022-06-25 05:46:23.071889
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    try:
        str_0 = '#a'
        role_definition_0 = RoleDefinition(str_0)
        rv = role_definition_0.preprocess_data(str_0)
    except AnsibleError:
        pass
    else:
        print('FAIL')
    try:
        str_0 = '\x81'
        role_definition_0 = RoleDefinition(str_0)
        rv = role_definition_0.preprocess_data(str_0)
    except AnsibleError:
        pass
    else:
        print('FAIL')


if __name__ == "__main__":
    test_case_0()
    # test_RoleDefinition_preprocess_data()

# Generated at 2022-06-25 05:46:33.009017
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    print("test preprocess_data")
    param_0 = ""
    param_1 = "test_role"
    param_2 = "a/b/c"
    param_3 = "/a/b/c"
    param_4 = "./a/b/c"
    param_5 = "../a/b/c"
    param_6 = "../a/b/c/test_role"
    param_7 = "../role"
    param_8 = "./role"
    param_9 = "role"
    param_10 = "/a/b/c/role"
    param_11 = "../a/b/c/../role"
    param_12 = "./../a/b/c/../role"

# Generated at 2022-06-25 05:46:38.092497
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    str_0 = '#a'
    role_definition_0 = RoleDefinition(str_0)
    var_0 = role_definition_0.get_name()

# Direct call to method preprocess_data of class RoleDefinition

# Generated at 2022-06-25 05:46:42.780332
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    str_0 = '#a'
    role_definition_0 = RoleDefinition(str_0)
    var_0 = role_definition_0.get_name()
    str_1 = '#'
    role_definition_1 = RoleDefinition(str_1, collection_list=list(var_0))
    var_1 = role_definition_1.get_name()

# Generated at 2022-06-25 05:46:50.152172
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    str_0 = '#a'
    role_definition_0 = RoleDefinition(str_0)
    var_0 = role_definition_0.preprocess_data()



# Generated at 2022-06-25 05:46:59.276809
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    str_0 = '#a'
    role_definition_0 = RoleDefinition(str_0)
    role_definition_1 = role_definition_0.preprocess_data(role_definition_0)
    assert role_definition_1 == role_definition_0
    role_definition_0 = RoleDefinition(str_0)
    var_0 = role_definition_0.get_name()
    assert var_0 == '#a'
    role_definition_0 = RoleDefinition('#a')
    var_0 = role_definition_0.get_role_path()
    assert var_0 == None
    role_definition_0 = RoleDefinition('#a')
    var_0 = role_definition_0.get_role_params()
    assert var_0 == dict()


# Generated at 2022-06-25 05:47:02.171877
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role = 'role01'
    role_definition_1 = RoleDefinition(name=role)
    var_1 = role_definition_1._role_path


# Generated at 2022-06-25 05:47:06.877431
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():

    # HERE: test case #0

    str_0 = '#a'
    role_definition_0 = RoleDefinition(str_0)
    var_0 = role_definition_0.get_name()
    print(var_0)

# Generated at 2022-06-25 05:47:15.051217
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    tmp = RoleDefinition()
    # role
    role_0 = {}
    role_0['role'] = 'role'
    role_0['name'] = 'role'
    role_0['tags'] = ['role']
    role_0['when'] = 'role'
    role_0['loop'] = 'role'
    role_0['loop_control'] = 'role'
    role_0['vars'] = {}
    role_0['hosts'] = 'role'
    role_0['any_errors_fatal'] = False
    role_0['handlers'] = []

    # role_params
    role_params_0 = {}
    role_params_0['role'] = 'role'
    role_params_0['param_1'] = 'param_1'

# Generated at 2022-06-25 05:47:15.589250
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    test_case_0()


# Generated at 2022-06-25 05:47:19.376812
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    # Create a new instance of a RoleDefinition
    role_definition = RoleDefinition("#a")
    role_definition.role = "a"
    role_definition.role_basedir = "/path/to/role_basedir"
    role_definition.preprocess_data("#a")



# Generated at 2022-06-25 05:47:23.306359
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    role_definition = RoleDefinition("foo")
    assert role_definition.get_name() == "foo"
    assert role_definition.get_name(include_role_fqcn=False) == "foo"

    role_definition = RoleDefinition("#a")
    assert role_definition.get_name() == "#a"
    assert role_definition.get_name(include_role_fqcn=False) == "#a"

    role_definition = RoleDefinition({"role": "foo"})
    assert role_definition.get_name() == "foo"
    assert role_definition.get_name(include_role_fqcn=False) == "foo"

    role_definition = RoleDefinition({"role": "#a"})
    assert role_definition.get_name() == "#a"
    assert role_definition.get_name

# Generated at 2022-06-25 05:47:24.309359
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    test_case_0()


# Generated at 2022-06-25 05:47:33.566322
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    str_0 = '*'
    role_definition_0 = RoleDefinition(str_0)
    ds_0 = {'role': 'bar'}
    # Failure: TypeError with message: 'Expected '<type 'dict'>', got '<type 'str'>' instead"
    # TODO: Verify the exact error message
    # try:
    #     role_definition_0.preprocess_data(ds_0=ds_0)
    # except TypeError as e:
    #     print('type error caught: {0}'.format(e))
    #     raise

    ds_1 = 'foo'
    role_definition_1 = RoleDefinition(data=ds_1)
    # Failure: TypeError with message: 'Expected '<type 'unicode'>', got '<type 'dict'>' instead"
   

# Generated at 2022-06-25 05:47:39.861999
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    str_0 = '#a'
    role_definition_0 = RoleDefinition(str_0)
    assert isinstance(role_definition_0.get_name(), str)



# Generated at 2022-06-25 05:47:43.911597
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    str_0 = RoleDefinition.preprocess_data({})


# Generated at 2022-06-25 05:47:50.271151
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    str_0 = '#a'
    ds_0 = '#a'
    variable_manager_0 = '#a'
    loader_0 = '#a'
    collection_list_0 = '#a'
    role_definition_0 = RoleDefinition(str_0, variable_manager_0, loader_0, collection_list_0)
    role_definition_0.preprocess_data(ds_0)


# Generated at 2022-06-25 05:47:55.857032
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    str_0 = '#a'     #Case#0: correct input, correct output
    role_definition_0 = RoleDefinition(str_0)
    var_0 = role_definition_0.preprocess_data(str_0)

    str_1 = ''       #Case#1: None input, exception
    role_definition_1 = RoleDefinition(str_1)
    var_1 = role_definition_1.preprocess_data(str_1)

    str_2 = None     #Case#2: None input, exception
    role_definition_2 = RoleDefinition(str_2)
    var_2 = role_definition_2.preprocess_data(str_2)


# Generated at 2022-06-25 05:48:06.203123
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    str_0 = '#a'
    role_definition_0 = RoleDefinition(str_0)
    dict_0 = {}
    dict_0['role'] = '#a'
    dict_1 = role_definition_0.preprocess_data(dict_0)
    var_0 = dict_1['role']

    dict_2 = {}
    dict_2['role'] = '#a'
    dict_3 = role_definition_0.preprocess_data(dict_2)
    assert var_0 == dict_3['role']

    dict_4 = {}
    dict_4['role'] = '#a'
    dict_5 = role_definition_0.preprocess_data(dict_4)
    assert var_0 == dict_5['role']

# Generated at 2022-06-25 05:48:10.716325
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    # Instance of class RoleDefinition
    role_definition_0 = RoleDefinition()

    # Test attributes of class RoleDefinition
    # Test method preprocess_data of class RoleDefinition
    test_case_0()



# Generated at 2022-06-25 05:48:15.620802
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    str_1 = '#a'
    role_definition_1 = RoleDefinition(str_1)
    ds = {'role': '#a'}
    role_definition_2 = RoleDefinition(ds, role_basedir=None)
    role_definition_2.preprocess_data(ds)
    var_1 = role_definition_2.get_name()

# Generated at 2022-06-25 05:48:21.633457
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    str_1 = '#a'
    role_definition_1 = RoleDefinition(str_1)
    str_2 = 'role: a'
    role_definition_2 = RoleDefinition(str_2)
    str_3 = 'role: a\nbecome: yes'
    role_definition_3 = RoleDefinition(str_3)


# Generated at 2022-06-25 05:48:25.651043
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    str_0 = '#a'
    role_definition_0 = RoleDefinition(str_0)
    variable_manager = C.VariableManager()
    loader = C.DataLoader()
    string_0 = '#a'
    role_definition_0.preprocess_data(string_0)
    role_definition_0.get_name()


# Generated at 2022-06-25 05:48:27.347400
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    str_0 = '#a'
    role_definition_0 = RoleDefinition(str_0)
    var_0 = role_definition_0.get_name()

# Generated at 2022-06-25 05:48:36.727468
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition_0 = RoleDefinition()
    role_definition_0.preprocess_data("role/name")
    # If there is something wrong with the return value
    # assert condition should be false (i.e., condition is true)
    assert(not role_definition_0._role_params)
    assert(role_definition_0._role_path == 'role/name')


# Generated at 2022-06-25 05:48:37.942518
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    test_case_0()

# Generated at 2022-06-25 05:48:41.490545
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition_0 = RoleDefinition()
    data_0 = {}
    role_definition_0.preprocess_data(data_0)
    var_0 = role_definition_0.get_name()


# Generated at 2022-06-25 05:48:44.517807
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    assert True # call your test code here


# Generated at 2022-06-25 05:48:47.527258
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    # Arguments
    role_definition = RoleDefinition()
    data = {}
    # No-op test
    assert(role_definition.preprocess_data(data) == data)


# Generated at 2022-06-25 05:48:50.031731
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition_0 = RoleDefinition()
    ds_arg_0 = None
    result_0 = role_definition_0.preprocess_data(ds_arg_0)



# Generated at 2022-06-25 05:48:56.907299
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition_1 = RoleDefinition()
    role_definition_2 = RoleDefinition()
    role_definition_3 = RoleDefinition()
    role_definition_4 = RoleDefinition()

    # test0 - AssertionError when ds is not a dict and not a string_types
    with pytest.raises(AssertionError):
        role_definition_1.preprocess_data(42)

    # test1 - AssertionError when ds is not a dict and not a string_types
    with pytest.raises(AssertionError):
        role_definition_2.preprocess_data(None)

    # test2 - AnsibleError when ds is a dict and does not contain 'role' or 'name'
    with pytest.raises(AnsibleError):
        role_definition_3.preprocess_data

# Generated at 2022-06-25 05:48:58.285823
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
	assert False, "Test case not implemented"


# Generated at 2022-06-25 05:48:59.028442
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    assert True == True

# Generated at 2022-06-25 05:49:02.660614
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    role_definition_0 = RoleDefinition()
    var_0 = role_definition_0.get_name()


# Generated at 2022-06-25 05:49:17.554375
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition_0 = RoleDefinition()
    try:
        role_definition_0.preprocess_data(2)
    except AnsibleAssertionError:
        pass
    try:
        role_definition_0.preprocess_data(0)
    except AnsibleAssertionError:
        pass
    try:
        role_definition_0.preprocess_data('0')
    except AnsibleAssertionError:
        pass
    try:
        role_definition_0.preprocess_data(2)
    except AnsibleAssertionError:
        pass
    try:
        role_definition_0.preprocess_data(0)
    except AnsibleAssertionError:
        pass

# Generated at 2022-06-25 05:49:22.082610
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():

    role_definition_0 = RoleDefinition()
    var_0 = role_definition_0.preprocess_data('test')

# Generated at 2022-06-25 05:49:24.547052
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition_1 = RoleDefinition()
    role_def_dict_0 = dict()
    role_definition_1.preprocess_data(role_def_dict_0)

if __name__ == '__main__':
    test_case_0()
    test_RoleDefinition_preprocess_data()

# Generated at 2022-06-25 05:49:27.106311
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition_0 = RoleDefinition()
    var_0 = role_definition_0.preprocess_data('roles/my_role')



# Generated at 2022-06-25 05:49:29.816357
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    try:
        ds = 'ansible/test_role'
        var_1 = RoleDefinition.load(ds)
    except Exception as exception:
        print(str(exception))


if __name__ == '__main__':
    test_case_0()
    test_RoleDefinition_preprocess_data()

# Generated at 2022-06-25 05:49:33.639902
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    data = dict()
    role_definition = RoleDefinition()

    role_definition.preprocess_data(data)


# Generated at 2022-06-25 05:49:36.676688
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition_0 = RoleDefinition()
    role_name = role_definition_0.preprocess_data(role_definition_0._ds)
    print(role_name)


# Generated at 2022-06-25 05:49:37.868747
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    # Nothing to assert for the moment
    test_case_0()


# Generated at 2022-06-25 05:49:49.342782
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():

    # class from which instance is created
    class_name = RoleDefinition

    # Initializing role_definition
    role_definition = RoleDefinition()

    # Data structure used for testing preprocess_data
    ansible_pos = "ansible_pos"
    ds = AnsibleMapping()
    ds["role"] = "role_name"
    ds["name"] = "name"
    ds["ansible_pos"] = ansible_pos

    # Expected result
    expected_result = AnsibleMapping()
    expected_result["role"] = "role_name"
    expected_result["ansible_pos"] = ansible_pos

    # Calling preprocess_data
    role_definition.preprocess_data(ds)

    # Asserting expected result with actual result
    assert role_definition._ds == ds
   

# Generated at 2022-06-25 05:49:50.633411
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition = RoleDefinition()
    ds = {}
    role_definition.preprocess_data(ds)

# Generated at 2022-06-25 05:49:57.887133
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
  role_definition = RoleDefinition()
  result = role_definition.get_name(include_role_fqcn=None)
  assert result is None


# Generated at 2022-06-25 05:49:59.323034
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition = RoleDefinition()
    role_definition.preprocess_data('role_0')

# Generated at 2022-06-25 05:50:10.147757
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition_0 = RoleDefinition(role_basedir='roles')
    with pytest.raises(AnsibleError) as exec_info:
        role_definition_0.preprocess_data(dict())
    assert "role definitions must contain a role name" in str(exec_info.value)
    role_definition_1 = RoleDefinition(role_basedir='roles')
    with pytest.raises(AnsibleAssertionError):
        role_definition_1.preprocess_data(['1', '2'])
    role_definition_2 = RoleDefinition(role_basedir='roles')
    role_definition_2.preprocess_data(dict(role='test_value'))

# Generated at 2022-06-25 05:50:15.188317
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition_0 = RoleDefinition()
    data_0 = "some-role"
    var_0 = role_definition_0.preprocess_data(data_0)
    print('var_0 = ', var_0)
    assert(var_0 == {u'role': u'some-role'})


# Generated at 2022-06-25 05:50:23.223234
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    role_definition_1 = RoleDefinition()                                           # Instantiate a object of class RoleDefinition
    role_definition_2 = RoleDefinition()                                           # Instantiate a object of class RoleDefinition
    role_definition_3 = RoleDefinition()                                           # Instantiate a object of class RoleDefinition
    role_definition_4 = RoleDefinition()                                           # Instantiate a object of class RoleDefinition
    role_definition_5 = RoleDefinition()                                           # Instantiate a object of class RoleDefinition
    role_definition_6 = RoleDefinition()                                           # Instantiate a object of class RoleDefinition
    role_definition_7 = RoleDefinition()                                           # Instantiate a object of class RoleDefinition
    role_definition_8 = RoleDefinition()                                           # Instantiate a object of class RoleDefinition

    var_1 = role_definition_1.get_name()

# Generated at 2022-06-25 05:50:26.101600
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    role_definition_0 = RoleDefinition()
    var_1 = role_definition_0.get_name()


# Generated at 2022-06-25 05:50:29.238858
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    ds = 'string'
    variable_manager = None
    loader = None
    role_definition_0 = RoleDefinition()
    role_definition_0.preprocess_data(ds)


# Generated at 2022-06-25 05:50:34.378257
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition = RoleDefinition()
    role_definition._loader = None
    role_definition._variable_manager = None
    role_definition._play = None
    role_definition._role_basedir = None
    role_definition._collection_list = None

    ds = dict()
    result = role_definition.preprocess_data(ds)


# Generated at 2022-06-25 05:50:44.184709
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    role_definition_0 = RoleDefinition()
    role_definition_0._valid_attrs = {'name': Attribute(), 'become': Attribute()}
    role_definition_0._loader = None
    role_definition_0._variable_manager = None
    role_definition_0._play = None
    role_definition_0._ds = AnsibleMapping()
    role_definition_0._ds.ansible_pos = None
    role_definition_0._role_basedir = None
    ds_0 = AnsibleMapping()
    ds_0.ansible_pos = None
    role_definition_0._ds = ds_0
    role_

# Generated at 2022-06-25 05:50:48.180506
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    # Test set up
    data_in = 'roles/jdoe.role_0'
    expected_out = {'role': 'jdoe.role_0'}

    # Test execution
    actual_data = RoleDefinition.preprocess_data(data_in)

    # Test verification
    assert isinstance(actual_data, AnsibleMapping)
    assert actual_data == expected_out


# Generated at 2022-06-25 05:50:55.201295
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    role_definition_0 = RoleDefinition()
    var_0 = role_definition_0.get_name()
    assert var_0 == ''



# Generated at 2022-06-25 05:50:57.514555
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    role_definition_0 = RoleDefinition()
    var_0 = role_definition_0.get_name()
    assert var_0 is None


# Generated at 2022-06-25 05:51:04.536598
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.playbook.play import Play

    play_data = dict(
        name = "Ansible Play"
    )

    loader_0 = None
    play_0 = Play.load(play_data, loader=loader_0)
    role_basedir_0 = u"roles"
    role_definition_0 = RoleDefinition(play_0, role_basedir_0)
    role_definition_0.preprocess_data(role_basedir_0)
    assert role_definition_0.get_name() == u'roles'

# Generated at 2022-06-25 05:51:08.496231
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition_0 = RoleDefinition()
    ds_0 = {'role': 'new-role-name'}
    role_definition_0.preprocess_data(ds_0)
    assert role_definition_0._role == 'new-role-name'

# Generated at 2022-06-25 05:51:13.080272
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition_0 = RoleDefinition()
    var_0 = role_definition_0.preprocess_data(8)
    assert not var_0, "Unit test for method preprocess_data of class RoleDefinition failed."


# Generated at 2022-06-25 05:51:17.649078
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition_0 = RoleDefinition()
    ds_0 = int()
    try:
        role_definition_0.preprocess_data(ds_0)
    except TypeError:
        var_0 = True
        raise RuntimeError('Test error')
    except AnsibleAssertionError:
        var_0 = True
    except Exception:
        var_0 = False
    finally:
        assert var_0


# Generated at 2022-06-25 05:51:24.335898
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition_0 = RoleDefinition()
    role_definition_0.__setattr__('_role_path', None)
    role_definition_0.__setattr__('_role_params', None)
    var_0 = role_definition_0.get_role_params()
    assert var_0 == None, "role_definition_0._role_params not initialized to None"
    var_0 = role_definition_0.get_role_path()
    assert var_0 == None, "role_definition_0._role_path not initialized to None"
    role_definition_0.__setattr__('_ds', None)
    role_definition_0.__setattr__('_role_collection', None)
    role_definition_0.__setattr__('_role_basedir', None)
    role_definition_

# Generated at 2022-06-25 05:51:31.017395
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    x = {
        "get_name": {
            "1": {"role_name": "test.role", "expected_result": "test.role"},
            "2": {"role_name": None, "expected_result": None}
        }
    }
    for k, v in iteritems(x["get_name"]):
        assert v["expected_result"] == test_RoleDefinition_get_name_work(v)



# Generated at 2022-06-25 05:51:31.993167
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    try:
        role_definition_0 = RoleDefinition()
        pass
    except Exception:
        pass


# Generated at 2022-06-25 05:51:37.880020
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition_0 = RoleDefinition()
    str_0 = '0'
    str_1 = '0'
    dict_0 = {'a': '1', 'b': '2'}
    dict_1 = {'c': '3', 'd': '4'}
    dict_2 = dict_1.copy()
    dict_2.update(dict_0)
    dict_3 = {'a': '1', 'b': '2', 'c': '3', 'd': '4'}
    dict_4 = dict_0.copy()
    dict_4.update({'args': dict_1})
    dict_5 = {'role': str_0, 'a': '1', 'b': '2', 'args': dict_1}

# Generated at 2022-06-25 05:51:51.353157
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():

    role_definition_0 = RoleDefinition()
    role_def_data_0 = dict()
    role_def_data_0['role'] = 'geerlingguy.apache'
    role_def_data_0['tags'] = ['geerling']
    role_def_data_0['vars'] = dict()
    role_def_data_0['vars']['apache_listen_port'] = 80
    role_def_data_0['vars']['apache_version'] = '2.4'
    role_def_data_0['vars']['apache_run_group'] = 'apache'
    role_def_data_0['vars']['apache_run_user'] = 'apache'

# Generated at 2022-06-25 05:51:54.916301
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    # Create the target object
    role_definition = RoleDefinition()

    # Create test variables
    ds = 'test_ds'

    # Call method
    result = role_definition.preprocess_data(ds)

    # Check result
    assert result == 'test_ds'


# Generated at 2022-06-25 05:52:01.459686
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition_0 = RoleDefinition()
    ds_0 = dict([('role', 'webapp'), ('become', True), ('tasks', [dict([('action', dict([('module', 'shell'), ('args', 'pwd')]))])])])
    role_definition_0.preprocess_data(ds_0)
    display.display("test: %s" % repr(ds_0))
    assert ds_0 == dict([('role', u'webapp'), ('become', True), ('tasks', [dict([('action', dict([('module', 'shell'), ('args', 'pwd')]))])])])


# Generated at 2022-06-25 05:52:12.631001
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    # Preparing test
    role_definition_0 = RoleDefinition()

    # Testing method with `role` key
    ds = {'role': 'common'}
    result = role_definition_0.preprocess_data(ds)
    assert result == {'role': 'common'}

    # Testing method with `role` key and role_basedir
    role_definition_0._role_basedir = '/path/to/roles'
    ds = {'role': 'common'}
    result = role_definition_0.preprocess_data(ds)
    assert result == {'role': 'common'}

    # Testing method with `role` key and role_basedir and role
    role_definition_0._role_basedir = '/path/to/roles'

# Generated at 2022-06-25 05:52:16.737248
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition_0 = RoleDefinition()
    ds_0 = dict()
    ds_0['role'] = 'role-name-1'
    role_definition_0.preprocess_data(ds_0)

## Unit test for method get_name of class RoleDefinition
#def test_RoleDefinition_get_name():
#    role_definition_0 = RoleDefinition()
#    var_0 = role_definition_0.get_name()

# Generated at 2022-06-25 05:52:18.882340
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    role_definition_0 = RoleDefinition()

    # Unit test for get_name (0)
    var_0 = role_definition_0.get_name()



# Generated at 2022-06-25 05:52:20.934606
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    test_var = ""
    local_role_definition = RoleDefinition()
    role_definition_0 = { 'role' : test_var }
    local_role_definition.preprocess_data(role_definition_0)


# Generated at 2022-06-25 05:52:21.914269
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    test_case_0()

# Generated at 2022-06-25 05:52:32.542662
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    # Test instantiation of class RoleDefinition from a string.
    # Create three strings, each of which will be used to instantiate a class.
    string0 = 'foo'
    string1 = 'bar'
    string2 = 'baz'

    # Create new object of class RoleDefinition by instantiating the class directly.
    role_definition_0 = RoleDefinition()

    # Set the attribute '_ds' to be string0 (cast the string to an AnsibleMapping).
    role_definition_0._ds = AnsibleMapping(string0)

    # Set the attribute 'test_string' to be string1 (will be used as the return value of the preprocess_data method).
    role_definition_0.test_string = string1

    # Set the attribute '_ds' to be string2 (cast the string to an AnsibleMapping).


# Generated at 2022-06-25 05:52:39.875848
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition = RoleDefinition()
    role_definition.preprocess_data(ds={'role':'role_name', 'key1':'value1'})
    assert role_definition.role == 'role_name'

    role_definition.preprocess_data(ds={'name':'role_name', 'key1':'value1'})
    assert role_definition.role == 'role_name'

    role_definition.preprocess_data(ds='role_name')
    assert role_definition.role == 'role_name'

    try:
        role_definition.preprocess_data(ds={'key1':'value1'})
    except AnsibleError:
        pass

    try:
        role_definition.preprocess_data(ds=2)
    except AnsibleAssertionError:
        pass

# Generated at 2022-06-25 05:52:45.740882
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    role_definition_0 = RoleDefinition()
    var_0 = role_definition_0.get_name()

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 05:52:47.853394
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition_0 = RoleDefinition()
    ds = dict()
    result = role_definition_0.preprocess_data(ds)

    # assert result
    assert result is not None


# Generated at 2022-06-25 05:52:52.520957
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    obj = RoleDefinition()
    str_0 = obj.get_name()
    print(str_0)

# Generated at 2022-06-25 05:52:55.007048
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition_4 = RoleDefinition()
    var_4 = role_definition_4.preprocess_data()


# Generated at 2022-06-25 05:53:00.717047
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    try:
        role_definition_1 = RoleDefinition()
        ds_0 = ""
        role_definition_1.preprocess_data(ds_0)
        is_correct = True
    except Exception as err:
        is_correct = False
        print("Exception thrown while testing [RoleDefinition_preprocess_data] : " + str(err))
    assert is_correct


# Generated at 2022-06-25 05:53:01.515323
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    # FIXME: Need to determine more about this class.
    pass

# Generated at 2022-06-25 05:53:04.367318
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    role_definition_0 = RoleDefinition()
    var_0 = role_definition_0.get_name()
    assert var_0 == None

if __name__ == '__main__':
    test_RoleDefinition_get_name()
    test_case_0()

# Generated at 2022-06-25 05:53:08.732603
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition_0 = RoleDefinition()
    var_0 = role_definition_0.preprocess_data(ds=0)
    assert var_0 is None

# Generated at 2022-06-25 05:53:10.122591
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    role_definition_0 = RoleDefinition()
    var_0 = role_definition_0.get_name()


# Generated at 2022-06-25 05:53:18.824746
# Unit test for method preprocess_data of class RoleDefinition

# Generated at 2022-06-25 05:53:25.243483
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    role_definition_0 = RoleDefinition()
    var_0 = role_definition_0.get_name()


# Generated at 2022-06-25 05:53:35.292423
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    '''
    Unit test for RoleDefinition::preprocess_data
    '''

    role_definition_0 = RoleDefinition()
    role_definition_0._load_role_name = role_definition_0.__init__
    role_definition_0._load_role_path = role_definition_0.get_name
    role_definition_0._split_role_params = role_definition_0.get_name
    role_definition_0._role_basedir = None
    role_definition_0._role_params = {}
    role_definition_0._variable_manager = None
    print ('begin unit test for method preprocess_data of class RoleDefinition')

# Generated at 2022-06-25 05:53:39.051495
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    test_cases = {
        0: {'_role': None},
    }
    for t in test_cases:
        test_case_0()


# Generated at 2022-06-25 05:53:45.470572
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    # Initialize RoleDefinition object
    role_definition_0 = RoleDefinition()
    # Load yaml data structure
    role_definition_1 = role_definition_0.load('- role: my_role')
    # Check if assertion error was raised
    try:
        role_definition_0.preprocess_data({'role': 'test'})
    except AssertionError:
        pass
    else:
        raise AssertionError("expected AssertionError")
    # Check if assertion error was raised
    try:
        role_definition_0.preprocess_data(['arg1', 'arg2'])
    except AssertionError:
        pass
    else:
        raise AssertionError("expected AssertionError")
    # Execute preprocess_data

# Generated at 2022-06-25 05:53:49.778755
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    role_definition_1 = RoleDefinition()
    var_1 = role_definition_1.get_name()


if __name__ == "__main__":
    test_RoleDefinition_get_name()
    test_case_0()

# Generated at 2022-06-25 05:53:55.960533
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    # Unit test for method preprocess_data of class RoleDefinition

    # Input Parameters:
    # ===============================================================

    role_definition_0 = RoleDefinition()
    role_definition_0._load_role_path('nginx')
    role_definition_0._split_role_params({'role': 'nginx', 'become': True, 'become_user': 'root', 'connection': 'local'})
    var_0 = role_definition_0.preprocess_data({'role': 'nginx', 'become': True, 'become_user': 'root', 'connection': 'local'})

# Generated at 2022-06-25 05:53:58.965595
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    role_definition_1 = RoleDefinition()
    var_1 = role_definition_1.get_name()
    print(var_1)

if __name__ == "__main__":
    test_RoleDefinition_get_name()

# Generated at 2022-06-25 05:54:01.226930
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition_0 = RoleDefinition()
    data_0 = {}
    var_0 = role_definition_0.preprocess_data(data_0)

# Generated at 2022-06-25 05:54:03.442084
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition_0 = RoleDefinition()
    ds = dict()
    result = role_definition_0.preprocess_data(ds)
    assert result is None


# Generated at 2022-06-25 05:54:06.987668
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    var_1 = RoleDefinition()
    var_1.role = 'role'
    var_2 = var_1.get_name()
    print(var_2, 'should be', 'role')

test_RoleDefinition_get_name()

# Generated at 2022-06-25 05:54:25.415686
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition_0 = RoleDefinition()
    ds = 'test'
    role_definition_0._variable_manager = MockAnsibleVars()
    role_definition_0.preprocess_data(ds)
    try:
        assert False
    except AssertionError:
        print("Assertion Error")


# Generated at 2022-06-25 05:54:29.845455
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    role_definition_0 = RoleDefinition()
    var_0 = role_definition_0.get_name()

    # test calling method twice to test cache behavior
    var_1 = role_definition_0.get_name()

    assert var_0 == var_1


# Generated at 2022-06-25 05:54:38.945429
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    rolepath = '/tmp/rolename'
    role_definition_1 = RoleDefinition()
    role_definition_1.preprocess_data(rolepath)
    role_definition_2 = RoleDefinition()
    role_definition_2.preprocess_data({'role': rolepath})
    var_2 = role_definition_2.get_role_path()
    assert var_2 == rolepath
    var_1 = role_definition_1.get_role_path()
    assert var_1 == rolepath
    role_definition_3 = RoleDefinition()
    role_definition_3.preprocess_data('rolename')
    var_4 = role_definition_3.get_name(False)
    assert var_4 == 'rolename'
    role_definition_4 = RoleDefinition()
    role_definition_4.preprocess_

# Generated at 2022-06-25 05:54:42.931016
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    with pytest.raises(AnsibleError):
        role_definition = RoleDefinition()
        ds = 'test_value'
        role_definition.preprocess_data(ds)
