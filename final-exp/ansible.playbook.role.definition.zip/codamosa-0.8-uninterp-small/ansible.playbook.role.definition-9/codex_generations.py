

# Generated at 2022-06-25 05:44:59.658482
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    # test object attributes
    role = "_%-h>iip)R&.vn"
    role_basedir = "`?$]Uv-+6U[f6T:Tj"
    variable_manager = ";2X>J_6*]U6OvU6p+"
    loader = "Kz-G50f,a|QP8X3f"
    collection_list = "6[,W8G c1L-0K&Rv+"
    role_definition_1 = RoleDefinition(role, role_basedir, variable_manager, loader, collection_list)
    role_definition_1.role = "A=^I+LUv[fj2Dl(#"

# Generated at 2022-06-25 05:45:08.930529
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    role_definition_0 = RoleDefinition()

    # Test with integer argument
    assert role_definition_0.get_name(1) is None

    role_definition_1 = RoleDefinition()
    str_0 = 'Wy"%;m1`Vw\\ny'
    role_definition_1.name = str_0

    # Test with string argument
    assert role_definition_1.get_name('s') == 'Wy"%;m1`Vw\\ny'

    role_definition_2 = RoleDefinition()
    str_0 = '!'
    role_definition_2.name = str_0
    role_definition_2.role = str_0

    # Test with float argument
    assert role_definition_2.get_name(1.2) is None

    role_definition_3 = RoleDefinition()
    
   

# Generated at 2022-06-25 05:45:11.325975
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    # FIXME: implement a test for this method
    pass

# Generated at 2022-06-25 05:45:17.337456
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():

    role_definition_0 = RoleDefinition()
    role_definition_0.role = 'myrole'

    assert 'myrole' == role_definition_0.get_name()

    role_definition_1 = RoleDefinition()
    role_definition_1.role = 'myrole'
    collections = [
        AnsibleCollectionRef('ansible.builtin','1.0.0','namespace'),
        AnsibleCollectionRef('community.general','1.0.0','namespace')
    ]

    role_definition_1._role_collection = collections[1]

    assert 'community.general.myrole' == role_definition_1.get_name()

# Generated at 2022-06-25 05:45:21.084299
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_name = 'RoleDefinition'
    role_basedir = 'RoleDefinition'
    role_params = {'role_name': 'RoleDefinition'}
    role_definition_0 = RoleDefinition(role_name, role_basedir, role_params)
    role_definition_0.preprocess_data(role_name)


# Generated at 2022-06-25 05:45:21.955217
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    test_case_0()


# Generated at 2022-06-25 05:45:24.665002
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    args = dict()
    role_definition = RoleDefinition(**args)

    # Set up test values
    ds = 3

    # Invoke method
    result = role_definition.preprocess_data(ds)
    assert result is None



# Generated at 2022-06-25 05:45:31.009783
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    str_0 = 'Wy"%;m1`Vw\\ny'
    role_definition_0 = RoleDefinition(str_0)
    role_definition_0._ds = AnsibleMapping()
    role_definition_0._loader = C.DEFAULT_LOADER_NAME
    role_definition_0._role_params = dict()
    role_definition_0._role_path = str_0
    role_definition_0._valid_attrs = dict()
    role_definition_1 = role_definition_0.preprocess_data(str_0)


# Generated at 2022-06-25 05:45:35.151682
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    # Instances of the class
    role_definition_0 = RoleDefinition()
    role_definition_1 = RoleDefinition('role')
    role_definition_2 = RoleDefinition('test')

    # Outputs
    role_definition_2.get_name()

# Generated at 2022-06-25 05:45:43.582559
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    #test AnsibleMapping object with role key
    str_0 = 'Wy"%;m1`Vw\\ny'
    role_definition_0 = RoleDefinition(str_0)
    test_ds_0 = {u'role': u'xyz.myrole'}
    assert role_definition_0.preprocess_data(test_ds_0) == {'role': 'xyz.myrole'}, "Incorrect name returned"

    # test AnsibleMapping object with name key
    str_1 = 'Wy"%;m1`Vw\\ny'
    role_definition_1 = RoleDefinition(str_1)
    test_ds_1 = {u'name': u'xyz.myrole'}

# Generated at 2022-06-25 05:45:55.278748
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    vm = VariableManager()
    all_vars = {u'foo': u'bar'}
    all_vars[u'hostvars'] = {}
    vm._vars_cache = all_vars
    pc = PlayContext()

    role_definition_2 = RoleDefinition(VariableManager=vm, PlayContext=pc)
    str_3 = 'Wy"%;m1`Vw\\ny'
    str_2 = 'Wy"%;m1`Vw\\ny'
    role_definition_2._RoleDefinition__role = str_2
    role_definition_2._RoleDefinition__collection_list = None
    role_definition_2._RoleDefinition__role_basedir = None
    role_definition_2

# Generated at 2022-06-25 05:45:58.266775
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    str_0 = 'Wy"%;m1`Vw\\ny'
    role_definition_0 = RoleDefinition(str_0)
    # Call method get_name of class RoleDefinition with parameter include_role_fqcn = True
    role_definition_0.get_name(True)
    # Call method get_name of class RoleDefinition with parameter include_role_fqcn = False
    role_definition_0.get_name(False)


# Generated at 2022-06-25 05:46:01.473155
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    str_0 = 'Wy"%;m1`Vw\\ny'
    role_definition_0 = RoleDefinition(str_0)
    display.warning(role_definition_0.get_name())


# Generated at 2022-06-25 05:46:11.732417
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    str_0 = 'Wy"%;m1`Vw\\ny'
    role_definition_0 = RoleDefinition(str_0)

    dict_0 = dict()
    dict_0['ansible_user'] = 'Wy"%;m1`Vw\\ny'
    dict_0['become'] = 'Wy"%;m1`Vw\\ny'
    dict_0['become_method'] = 'Wy"%;m1`Vw\\ny'
    dict_0['become_user'] = 'Wy"%;m1`Vw\\ny'
    dict_0['delegate_to'] = 'Wy"%;m1`Vw\\ny'
    dict_0['deprecated'] = 'Wy"%;m1`Vw\\ny'

# Generated at 2022-06-25 05:46:17.623076
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    str_0 = 'm~hC{`P>_y?'
    role_definition_0 = RoleDefinition(str_0)
    str_1 = '6fLEU6S%<'
    assert role_definition_0.get_name(str_1) == '6fLEU6S%<'
    str_2 = 'x]'
    role_definition_1 = RoleDefinition(str_2)
    assert role_definition_1.get_name() == 'x]'

# Generated at 2022-06-25 05:46:25.984784
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    ds = {"role": "PJc%=?szs@o8Q2`C"}
    variable_manager = None
    loader = None
    role_definition_0 = RoleDefinition(variable_manager = variable_manager, loader = loader)
    role_definition_1 = RoleDefinition(ds, variable_manager = variable_manager, loader = loader)
    role_definition_1.preprocess_data(ds)
    role_definition_1.preprocess_data("mg+7|o\"g#}VSR{D")
    try:
        role_definition_1.preprocess_data(1.0)
    except AnsibleError:
        pass
    try:
        role_definition_1.preprocess_data(ds)
    except AnsibleError:
        pass

# Generated at 2022-06-25 05:46:31.594868
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    root_path = 'AccountService.py'
    str_0 = 'Wy"%;m1`Vw\\ny'
    role_definition_0 = RoleDefinition(str_0)
    ds = 'ab_def'
    role_definition_0._loader = ds
    # Call the method
    try:
        role_definition_0.preprocess_data(ds)
    except:
        pass


# Generated at 2022-06-25 05:46:40.576327
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    str_0 = 'Wy"%;m1`Vw\\ny'
    role_definition_0 = RoleDefinition(str_0)
    str_1 = '_o2j\\'
    role_definition_1 = RoleDefinition(str_0)
    yaml_object_0 = AnsibleMapping()
    yaml_object_0['file'] = 'lYk}'
    yaml_object_0['role'] = 'g?wQe'
    role_definition_0.preprocess_data(yaml_object_0)



# Generated at 2022-06-25 05:46:42.884530
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    str_0 = 'Wy"%;m1`Vw\\ny'
    role_definition_0 = RoleDefinition(str_0)
    role_definition_0.preprocess_data()


# Generated at 2022-06-25 05:46:45.469315
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    assert 1 == 1


# Generated at 2022-06-25 05:46:59.200859
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    str_0 = 'Wy"%;m1`Vw\\ny'
    role_definition_0 = RoleDefinition(str_0)

    dict_0 = {"role": "Awesome Role", "name": "michael"}
    dict_1 = role_definition_0.preprocess_data(dict_0)

    assert dict_0 is not dict_1
    assert dict_1['role'] == 'Awesome Role'
    assert dict_1['name'] is None
    assert dict_0['name'] == 'michael'

# vim: set expandtab:shiftwidth=4:softtabstop=4:tabstop=4

# Generated at 2022-06-25 05:47:05.515378
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    """
    Tests get_name of RoleDefinition
    """

    role_definition = RoleDefinition()
    if role_definition.get_name() is not None:
        raise RuntimeError("Unable to test RoleDefinition.get_name()")

# Generated at 2022-06-25 05:47:07.944637
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    str_0 = 'Wy"%;m1`Vw\\ny'
    role_definition_0 = RoleDefinition(str_0)
    ds = str_0
    role_definition_0.preprocess_data(ds)

# Generated at 2022-06-25 05:47:11.429625
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    str_0 = 'Wy"%;m1`Vw\\ny'
    role_definition_0 = RoleDefinition(str_0)
    res_0 = role_definition_0.get_name(True)
    res_1 = role_definition_0.get_name(False)


# Generated at 2022-06-25 05:47:16.507271
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition = RoleDefinition()
    role_definition.preprocess_data(None)

if __name__ == "__main__":
    test_case_0()
    test_RoleDefinition_preprocess_data()

# Generated at 2022-06-25 05:47:21.387322
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    my_role_definition = RoleDefinition()
    my_ds = AnsibleMapping()
    my_ds['role'] = 'some-role'
    assert my_role_definition.preprocess_data(my_ds) == my_ds, "Failed preprocess_data with valid input"

    my_ds2 = AnsibleMapping()
    my_ds2['name'] = 'some-role'
    assert my_role_definition.preprocess_data(my_ds2) == my_ds, "Failed preprocess_data with valid input"



# Generated at 2022-06-25 05:47:23.768173
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    role_definition_0 = RoleDefinition()
    role_definition_0.get_name()


# Generated at 2022-06-25 05:47:33.061595
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    src_dir = 'test/data/ansible_collections/jctanner_ant/my_collection/roles/test-role/'
    loader = DictDataLoader({'roles': {'jctanner.ant.test-role': {'tasks': {'main': {'test-task.yml': '---\n'}}}}})
    role_definition_0 = RoleDefinition(loader=loader)
    role_definition_0._ds = src_dir
    role_definition_0._collection_list = [('/home/swaroop/my_collection', 'jctanner_ant', AnsibleCollectionRef('jctanner_ant', '/home/swaroop/my_collection'))]
    role_definition_0._role_basedir = './'
    role_definition_0.preprocess

# Generated at 2022-06-25 05:47:40.050711
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    str_0 = 'Wy"%;m1`Vw\\ny'
    role_definition_0 = RoleDefinition(str_0)
    str_1 = "Wy\"%;m1`Vw\\ny"
    str_2 = 'Wy"%;m1`Vw\\ny'
    str_3 = 'Wy"%;m1`Vw\\ny'
    str_4 = 'Wy"%;m1`Vw\\ny'
    str_5 = 'Wy"%;m1`Vw\\ny'
    str_6 = "Wy\"%;m1`Vw\\ny"
    str_7 = 'Wy"%;m1`Vw\\ny'
    str_8 = 'Wy"%;m1`Vw\\ny'

# Generated at 2022-06-25 05:47:46.927591
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    # FIXME: add a real test of the preprocess_data function itself
    str_0 = 'Wy"%;m1`Vw\\ny'
    role_definition_0 = RoleDefinition(str_0)
    role_definition_0._load_role_path(str_0)
    role_definition_0._load_role_name(str_0)
    role_definition_0._split_role_params(str_0)


# Generated at 2022-06-25 05:47:55.259033
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    str_0 = 'TpB[c#m0M7'
    role_definition_0 = RoleDefinition(str_0)
    role_definition_0.preprocess_data(str_0)



# Generated at 2022-06-25 05:48:04.083301
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():

    # Construct an instance of class RoleDefinition with its attributes
    # initialized to the test values above.

    assert isinstance(role_definition_0, RoleDefinition)

    # Now load the expected results for the test into a dictionary
    expected = {
        # Put the expected results for the test here.
    }

    # Now run the test.
    # AnsibleFilter is a static class, so just execute its static method.
    results = role_definition_0.preprocess_data()

    assert results == expected, "Expected {0} but got {1}".format(expected, results)

# Generated at 2022-06-25 05:48:07.800628
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    str_0 = 'Wy"%;m1`Vw\\ny'
    role_definition_0 = RoleDefinition(str_0)
    role_definition_1 = role_definition_0.preprocess_data(str_0)
    assert role_definition_1 == str_0

# Generated at 2022-06-25 05:48:12.554819
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    str_0 = 'k5o=!}a@P*3q'
    role_definition_0 = RoleDefinition(str_0)
    role_definition_0.get_name(True)


# Generated at 2022-06-25 05:48:19.568581
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    str_0 = 'Wy"%;m1`Vw\\ny'
    role_definition_1 = RoleDefinition(str_0)
    result_0 = role_definition_1.get_name()
    assert(len(result_0) > 0)


# Generated at 2022-06-25 05:48:27.468486
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    str_0 = 'Wy"%;m1`Vw\\ny'
    role_definition_0 = RoleDefinition(str_0)
    str_1 = 'Wy"%;m1`Vw\\ny'
    str_2 = 'Wy"%;m1`Vw\\ny'
    str_3 = 'Wy"%;m1`Vw\\ny'
    str_4 = 'Wy"%;m1`Vw\\ny'
    str_5 = 'Wy"%;m1`Vw\\ny'
    str_6 = 'Wy"%;m1`Vw\\ny'
    str_7 = 'Wy"%;m1`Vw\\ny'
    str_8 = 'Wy"%;m1`Vw\\ny'

# Generated at 2022-06-25 05:48:28.150624
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    RoleDefinition()


# Generated at 2022-06-25 05:48:34.184341
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    VALID_ROLE_NAMES = (
        'testrole',
        'test1',
        '/a/b/testrole',
        '/a/b/testrole/',
        './test1',
        './testrole.tar.gz'
    )

    for role in VALID_ROLE_NAMES:
        role_def = RoleDefinition(role)
        assert role == role_def.role



# Generated at 2022-06-25 05:48:40.609671
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    str_0 = 'Wy"%;m1`Vw\\ny'
    role_definition_0 = RoleDefinition(str_0)
    try:
        result = role_definition_0.get_name()
        assert isinstance(result, str)
    except Exception:
        result = False
    assert result


# Generated at 2022-06-25 05:48:51.285568
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    display.display("Test: method preprocess_data of class RoleDefinition start")
    # Valid case
    display.display("Valid case")
    # role_definition_0 = RoleDefinition("role:")
    # role_definition_0.preprocess_data("role:")
    role_definition_0 = RoleDefinition("role:")
    role_definition_0.preprocess_data("role:")
    # Invalid case
    display.display("Invalid case")
    # role_definition_1 = RoleDefinition("role:")
    # role_definition_1.preprocess_data(True)
    role_definition_1 = RoleDefinition("role:")
    with pytest.raises(AnsibleAssertionError):
        role_definition_1 = RoleDefinition("role:")
        role_definition_1.preprocess_data(True)

# Generated at 2022-06-25 05:49:01.107360
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    str_0 = 'Wy"%;m1`Vw\\ny'
    role_definition_0 = RoleDefinition(str_0)
    str_1 = 'p}1|:()WXFv>4y'
    bool_0 = role_definition_0.get_name(str_1)
    assert str_1 == str_0



# Generated at 2022-06-25 05:49:01.775483
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    assert 1 == 1

# Generated at 2022-06-25 05:49:08.100702
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    # mock up an object
    a_role_definition = RoleDefinition()
    # mock up an arguments
    args_0 = True
    # mock up result
    expected_0 = 'Wy"%;m1`Vw\ny'
    # do the method call
    result_0 = a_role_definition.get_name(args_0)
    # assert result is expected
    assert result_0 == expected_0, 'Expected result: %s, but got result: %s.' % (expected_0, result_0)


# Generated at 2022-06-25 05:49:18.843412
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition_0 = RoleDefinition()
    str_0 = 'Name'
    assert role_definition_0.preprocess_data(str_0) == role_definition_0._ds
    str_0 = 'Name'
    map_0 = {'role': str_0}
    assert role_definition_0.preprocess_data(map_0) == map_0
    str_0 = 'Name'
    map_0 = {'role': str_0}
    role_definition_0._ds = str_0
    role_definition_0._role_path = str_0
    role_definition_0._role_params = map_0
    assert role_definition_0.preprocess_data(map_0) == map_0


# Generated at 2022-06-25 05:49:22.996519
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    str_in_0 = '!NqDh\o*\x0f8'
    result = RoleDefinition.preprocess_data(str_in_0)
    assert type(result) == dict


# Generated at 2022-06-25 05:49:27.605108
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    # Test case data
    role_definition_1 = RoleDefinition()
    role_definition_1.preprocess_data('')



# Generated at 2022-06-25 05:49:37.796589
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    # Test with a string data structure
    str_0 = 'Wy"%;m1`Vw\\ny'
    role_definition_0 = RoleDefinition(str_0)
    # Check that the fields have been properly initialized
    data_structure_0 = role_definition_0._ds
    assert data_structure_0 == str_0

    # Test with a dictionary data structure
    dict_0 = OrderedDict()
    dict_0['role'] = 'my_role'
    dict_0['another_param'] = 'some_param'
    role_definition_1 = RoleDefinition(dict_0)
    # Check that the fields have been properly initialized
    data_structure_1 = role_definition_1._ds
    assert data_structure_1 == dict_0

    # Test that fields are properly set when calling pre

# Generated at 2022-06-25 05:49:43.282096
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    str_0 = 'Wy"%;m1`Vw\\ny'
    role_definition_0 = RoleDefinition(str_0)
    actual = role_definition_0.get_name(include_role_fqcn=True)
    assert actual == '.'.join(x for x in (role_definition_0._role_collection, role_definition_0.role) if x)

# Generated at 2022-06-25 05:49:49.243678
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    fixture_data = {}
    fixture_data['include_role_fqcn'] = True
    fixture_data['expected_result'] = '.'
    # Assumption: '.' is the value for role for this test
    role_definition_0 = RoleDefinition(fixture_data['.'])

    result = role_definition_0.get_name(fixture_data['include_role_fqcn'])
    assert result == fixture_data['expected_result']

RoleDefinition.test_case_0 = test_case_0

# Generated at 2022-06-25 05:49:53.154085
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    # Test with required parameter
    str_0 = 'Wy"%;m1`Vw\\ny'
    role_definition_0 = RoleDefinition(str_0)
    str_1 = 'Wy"%;m1`Vw\\ny'
    role_definition_0.preprocess_data(str_1)


# Generated at 2022-06-25 05:50:00.750643
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    import sys
    import os
    try:
        from unittest import mock
    except ImportError:
        import mock
    role_definition_0 = RoleDefinition('Wy"%;m1`Vw\\ny')
    expected_1 = '0T:Jc%0k6'
    assert role_definition_0.get_name() == expected_1


# Generated at 2022-06-25 05:50:08.324560
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    # create a role_definition using a simple role name
    role_definition_1 = RoleDefinition('name')
    # run the preprocess_data method to ensure it does not raise an exception
    if hasattr(role_definition_1, 'preprocess_data'):
        try:
            role_definition_1.preprocess_data(dict_1)
        except Exception as e:
            print('An unexpected exception occurred {}'.format(e))


# Generated at 2022-06-25 05:50:12.364196
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():

    try:
        role_definition_0 = RoleDefinition()
        role_definition_0.preprocess_data(0)
    except Exception as e:
        print("Exception: " + str(e))


# Generated at 2022-06-25 05:50:15.965524
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    # test 1
    str_0 = 'Wy"%;m1`Vw\\ny'
    role_definition_0 = RoleDefinition(str_0)
    role_definition_0.preprocess_data(str_0)



# Generated at 2022-06-25 05:50:17.190775
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    test_case_0()


# Generated at 2022-06-25 05:50:20.065405
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    str_0 = 'Wy"%;m1`Vw\\ny'
    role_definition_0 = RoleDefinition(str_0)
    role_definition_0.preprocess_data(str_0)


# Generated at 2022-06-25 05:50:22.685631
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    str_0 = 'Wy"%;m1`Vw\\ny'
    role_definition_0 = RoleDefinition(str_0)
    bool_0 = role_definition_0.get_name()


# Generated at 2022-06-25 05:50:34.074089
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    str_0 = '5G_B*|Ghfjkgb~&u:'
    role_definition_0 = RoleDefinition(str_0)
    str_1 = 'c\\OX'
    str_2 = '0Xt3ZlF'
    dynamic_types.str_0 = str_2
    role_definition_0.update(dynamic_types.str_0)
    float_0 = float(str_0)
    float_1 = float(str_2)
    float_2 = float(str_1)
    str_3 = '\\'
    str_4 = "\\"
    str_5 = '\\'
    str_6 = '\\'
    str_7 = "\\"
    str_8 = '\\'
    str_9 = '\\'

# Generated at 2022-06-25 05:50:39.452194
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    from ansible.playbook.role import Role
    role_1_0 = Role(name='test_role')

    role_definition_0 = RoleDefinition(role_1_0)
    str_0 = role_definition_0.get_name()

    assert str_0 == 'test_role'

# Generated at 2022-06-25 05:50:43.065360
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    str_0 = 'Wy"%;m1`Vw\\ny'
    role_definition_0 = RoleDefinition(str_0)
    dict_0 = {'role': 'name'}
    assert role_definition_0.preprocess_data(dict_0) == {'role': 'name'}


# Generated at 2022-06-25 05:50:51.461087
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    role_name_0 = '-;]8j7V'
    role_definition_0 = RoleDefinition(role_name_0)
    assert(role_definition_0.get_name()) == '-;]8j7V'


# Generated at 2022-06-25 05:50:53.801643
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    test_case_0()



# Generated at 2022-06-25 05:50:55.374522
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition_0 = RoleDefinition()
    role_definition_0.preprocess_data(str_0)

# Generated at 2022-06-25 05:51:00.041630
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition_0 = RoleDefinition()
    str_0 = 'Wy"%;m1`Vw\\ny'
    ds_0 = AnsibleMapping(str_0)
    role_definition_1 = role_definition_0.preprocess_data(ds_0)



# Generated at 2022-06-25 05:51:02.837248
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    str_0 = 'Wy"%;m1`Vw\\ny'
    role_definition_0 = RoleDefinition(str_0)
    role_definition_0.preprocess_data(str_0)

# Generated at 2022-06-25 05:51:09.235516
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_name_0 = 'iHeag'
    role_collection_0 = 'i[ %#*~?6'
    variable_manager_0 = 'r1T*'
    role_definition_0 = RoleDefinition(role_collection_0, variable_manager_0, role_name_0)
    ds_0 = {'role': '%n/!I'}
    role_definition_0.preprocess_data(ds_0)
    assert role_definition_0._role_path == 'C5:B^'
    assert role_definition_0._role == '%n/!I'
    assert role_definition_0._role_collection == 'i[ %#*~?6'


# Generated at 2022-06-25 05:51:14.430289
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    str_0 = 'Wy"%;m1`Vw\\ny'
    role_definition_0 = RoleDefinition(str_0)
    assert role_definition_0.get_name() == b'Wy"%;m1`Vw\\ny', 'Unexpected value returned by method get_name'

#
# Test that role_path returns the correct value from a role defined in a collection
#

# Generated at 2022-06-25 05:51:22.556322
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition_0 = RoleDefinition('RoleDefinition_0')
    role_definition_0.preprocess_data(None)
    role_definition_1 = RoleDefinition('RoleDefinition_1')
    role_definition_1._variable_manager = 'VariableManager_0'
    role_definition_1._loader = 'Loader_0'
    role_definition_1._split_role_params(None)
    role_definition_1._load_role_path(None)
    role_definition_1._load_role_name(None)
    role_definition_1.preprocess_data(None)
    role_definition_2 = RoleDefinition('RoleDefinition_2')
    role_definition_2.preprocess_data(None)
    role_definition_3 = RoleDefinition('RoleDefinition_3')
    role_definition_3.preprocess

# Generated at 2022-06-25 05:51:27.373128
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    my_play = {}
    my_role_basedir = ''
    my_variable_manager = ''
    my_loader = []
    my_collection_list = []
    test_case_1 = 'j*f`'
    test_case_2 = {'oJGZh': 'QdLw1n@m'}
    role_definition_1 = RoleDefinition(my_play, my_role_basedir, my_variable_manager, my_loader, my_collection_list)
    role_definition_1.preprocess_data(test_case_1)
    role_definition_1.preprocess_data(test_case_2)


# Generated at 2022-06-25 05:51:35.048992
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    str_0 = 'Wy"%;m1`Vw\\ny'
    role_definition_0 = RoleDefinition(str_0)
    str_1 = 'role name'
    str_2 = '/etc/ansible/roles/role/tasks/main.yml'
    role_definition_0._load_role_name = MagicMock(return_value=str_1)
    role_definition_0._load_role_path = MagicMock(return_value=(str_1, str_2))
    dict_1 = {'role': str_1}
    role_definition_0._split_role_params = MagicMock(return_value=(dict_1, dict_1))
    dict_2 = {'tc': dict_1}
    dict_3 = dict_2

# Generated at 2022-06-25 05:51:39.527268
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    assert callable(RoleDefinition.get_name)


# Generated at 2022-06-25 05:51:42.220899
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():

    # Test the function with a simple string
    obj_0 = 'Wy"%;m1`Vw\\ny'
    c = RoleDefinition('Wy"%;m1`Vw\\ny')
    # TODO: check the results
    assert c



# Generated at 2022-06-25 05:51:51.768202
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    field_debug = False
    # all setup for test is done in the setup function
    setup()

    # set up object that can call the preprocess_data method
    role_definition_0 = RoleDefinition()
    role_definition_0_role = 'test_role'
    role_definition_0_role_path = '/path/to/roles/test_role'
    role_definition_0_role_params = {'test_role_param0': 'test role param0 value',
                                     'test_role_param1': 'test role param1 value',
                                     'test_role_param2': 'test role param2 value'}

    # create data structure that tests the preprocess_data method
    #
    # key           value                             description
    # -----------   -------------------------------   --------------------------------
    # role          test_role                         value

# Generated at 2022-06-25 05:51:55.192262
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    str_0 = 'Wy"%;m1`Vw\\ny'
    role_definition_0 = RoleDefinition(str_0)
    role_definition_0.get_role_path()
    display.display(role_definition_0.get_name())


test_case_0()

# Generated at 2022-06-25 05:51:57.453361
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    str_0 = 'Wy"%;m1`Vw\\ny'
    role_definition_0 = RoleDefinition(str_0)

    result = role_definition_0.get_name()


# Generated at 2022-06-25 05:52:01.121678
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    str_0 = 'Wy"%;m1`Vw\\ny'
    role_definition_0 = RoleDefinition(str_0)
    str_1 = 'aXU0p/O*GVm&0p'
    role_definition_0.preprocess_data(str_1)


# Generated at 2022-06-25 05:52:04.953329
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    test_case_0()


# Generated at 2022-06-25 05:52:07.413203
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition_class = RoleDefinition()
    role_definition_instance = role_definition_class.load(role_definition_0)
    role_definition_instance.preprocess_data(data_0)


# Generated at 2022-06-25 05:52:10.694456
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    str_0 = 'Wy"%;m1`Vw\\ny'
    role_definition_0 = RoleDefinition(str_0)
    test_case_0()


# Generated at 2022-06-25 05:52:13.197899
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    str_1 = 'D"YJ5=5$x3>2%'
    # Test with assert
    assert AnsibleAssertionError == RoleDefinition().preprocess_data(str_1)

test_RoleDefinition_preprocess_data()

# Generated at 2022-06-25 05:52:22.098781
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    str_0 = 'Wy"%;m1`Vw\\ny'
    role_definition_0 = RoleDefinition(str_0)
    ds = {'role': 'role'}
    # Run method
    result = role_definition_0.preprocess_data(ds)


# Generated at 2022-06-25 05:52:24.630468
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    str_0 = 'T`T/T`T/T`T/T'
    role_definition_0 = RoleDefinition(str_0)
    assert role_definition_0.get_name() == str_0


# Generated at 2022-06-25 05:52:31.382037
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    str_0 = 'Wy"%;m1`Vw\\ny'
    role_definition_0 = RoleDefinition(str_0)
    role_definition_0.name = "ro1e"
    role_definition_0._role_collection = "role_collection"
    str_1 = role_definition_0.get_name()
    assert str_1 == "role_collection.ro1e"
    str_2 = role_definition_0.get_name(False)
    assert str_2 == "ro1e"


# Generated at 2022-06-25 05:52:35.898207
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    data = dict(
        role = 'moon',
        name = 'george'
    )
    variable_manager = dict()
    loader = dict()
    role_definition = RoleDefinition()
    role_definition.preprocess_data(data=data, variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-25 05:52:42.513375
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    str_0 = 'Wy"%;m1`Vw\\ny'
    role_definition_0 = RoleDefinition(str_0)
    str_0_0 = 'Wy"%;m1`Vw\\ny'
    bool_0_0 = True
    str_0_1 = role_definition_0.get_name(bool_0_0)
    assert str_0_0 == str_0_1

# Generated at 2022-06-25 05:52:43.926228
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    test_case_0()


# Generated at 2022-06-25 05:52:46.499175
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    str_0 = 'Wy"%;m1`Vw\\ny'
    role_definition_0 = RoleDefinition(str_0)
    try:
        role_definition_0.preprocess_data(str_0)
    except:
        pass

# Generated at 2022-06-25 05:52:53.223244
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():

    import sys
    import os
    import unittest

    from ansible.module_utils.six import PY3, b

    import ansible.utils.module_docs as module_docs
    import ansible.playbook.role.definition as role_definition
    import ansible.playbook.role.requiremen
    import ansible.playbook.role.meta
    import ansible.playbook

    import ansible.errors

    # Find the set of collections in the current working directory
    collection_list = []
    # collection_list = ['test_collections']

    # Find the set of collections in the current working directory
    collection_list = []
    # collection_list = ['test_collections']


# Generated at 2022-06-25 05:53:00.393430
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    str = 'Wy"%;m1`Vw\\ny'
    role_definition = RoleDefinition(str)
    ret_val = role_definition.preprocess_data(1)
    assert ret_val is not None
    assert ret_val is not False
    assert isinstance(ret_val, int)
    assert ret_val == 1


# Generated at 2022-06-25 05:53:06.959085
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    str_0 = 'Wy"%;m1`Vw\\ny'
    role_definition_0 = RoleDefinition(str_0)
    role_definition_0.role = 'p?FO\xa8\x1b\x03'
    role_definition_0.role.name = '67,xO'
    role_definition_0.preprocess_data(str_0)
    role_definition_0.name = 'x"6\x14\x1c\x1f<n'
    role_definition_0.name.role = '"P#\x7f'
    role_definition_0.get_name()
    role_definition_0.role.role = 'Z0C2`^t'

# Generated at 2022-06-25 05:53:20.693968
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    # Ensure that we first use the role: name
    role_definition_0 = RoleDefinition()
    dict_0 = dict()
    dict_0['role'] = 'a'
    dict_0['name'] = 'b'
    result = role_definition_0.preprocess_data(dict_0)
    assert role_definition_0._role == 'a'

    # Ensure that we next use the name: field
    dict_1 = dict()
    dict_1['name'] = 'a'
    result = role_definition_0.preprocess_data(dict_1)
    assert role_definition_0._role == 'a'

    # Verify that you can pass in a simple string, which does not need to be preprocessed
    dict_2 = dict()
    dict_2['name'] = 'a'
    result = role

# Generated at 2022-06-25 05:53:26.885884
# Unit test for method preprocess_data of class RoleDefinition

# Generated at 2022-06-25 05:53:33.726486
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    yaml_obj_0 = AnsibleMapping()
    yaml_obj_0.yaml_add_eol_comment('#comment', '#comment')
    yaml_obj_0.yaml_key = "role"
    role_definition_0 = RoleDefinition(yaml_obj_0)
    assert role_definition_0.preprocess_data(yaml_obj_0) is None


# Generated at 2022-06-25 05:53:42.274081
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    str_0 = 'Wy"%;m1`Vw\\ny'
    role_definition_0 = RoleDefinition(str_0)
    str_1 = '%K`?X~1,/Nzs'
    dict_2 = dict()
    dict_2['role'] = str_1
    dict_2['name'] = str_1
    role_definition_0.preprocess_data(dict_2)
    str_3 = 'XrQaLl1,y[+Hd'
    dict_4 = dict()
    dict_4['role'] = str_3
    dict_4['name'] = str_3
    role_definition_0.preprocess_data(dict_4)


# Generated at 2022-06-25 05:53:45.393789
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    str_0 = 'Wy"%;m1`Vw\\ny'
    role_definition_0 = RoleDefinition(str_0)
    assert role_definition_0.get_name() == 'Wy"%'

# Generated at 2022-06-25 05:53:49.954379
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    str_0 = 'Wy"%;m1`Vw\\ny'
    role_definition_0 = RoleDefinition(str_0)
    assert role_definition_0.get_name() == 'Wy"%;m1`Vw\\ny'

test_case_0()

# Generated at 2022-06-25 05:53:52.789244
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    int_0 = 90
    role_definition_0 = RoleDefinition(int_0)
    assert role_definition_0._load_role_name(int_0) == '90'


# Generated at 2022-06-25 05:53:59.941957
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition_0 = RoleDefinition()
    role_definition_0.preprocess_data(ds = {u'name': u'ABC', u'role': u'ABC'})
    assert role_definition_0.role == u'ABC'

    role_definition_1 = RoleDefinition()
    role_definition_1.preprocess_data(ds = {u'name': u'ABC', u'role': u'ABC'})
    assert role_definition_1.role == u'ABC'


# Generated at 2022-06-25 05:54:07.132867
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    display.debug('test_RoleDefinition_preprocess_data')

    # FIXME: will set these up at some point
    role_definition_0 = RoleDefinition()
    ds_0 = dict()
    role_definition_0.preprocess_data(ds_0)

    role_definition_1 = RoleDefinition()
    ds_1 = list()
    role_definition_1.preprocess_data(ds_1)

    role_definition_2 = RoleDefinition()
    ds_2 = dict()
    role_definition_2.preprocess_data(ds_2)


# Generated at 2022-06-25 05:54:12.521937
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition_1 = RoleDefinition()
    role_definition_1.preprocess_data(0)
    assert type(role_definition_1) is RoleDefinition


# Generated at 2022-06-25 05:54:23.993392
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    str_0 = 'Wy"%;m1`Vw\\ny'
    role_definition_0 = RoleDefinition(str_0)
    role_definition_0.get_name()


# Generated at 2022-06-25 05:54:33.190984
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    str_0 = 'Wy"%;m1`Vw\\ny'
    role_definition_0 = RoleDefinition(str_0)
    role_definition_0.role = "CQIwLTm8%H^Gz-XsU6:KU{f!%/Q1@^N1"
    role_definition_0.become = "9c7V0*h[Y;7Vu>=O\\y7e_,*wB%]7l&#=b"
    result = role_definition_0.get_name()
    assert isinstance(result, str)


# Generated at 2022-06-25 05:54:41.850014
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    str_0 = 'Wy"%;m1`Vw\\ny'
    role_definition_0 = RoleDefinition(str_0)
    role_definition_0.role = 'G0~X9'
    role_definition_1 = RoleDefinition(str_0)
    role_definition_1.role = '2c$Xh'
    role_definition_2 = RoleDefinition(str_0)
    role_definition_2.role = 'm=1]C'
    role_definition_3 = RoleDefinition(str_0)
    role_definition_3.role = 'S5(A}'
    role_definition_4 = RoleDefinition(str_0)
    role_definition_4.role = ')J2*r'
    role_definition_5 = RoleDefinition(str_0)
    role_definition_

# Generated at 2022-06-25 05:54:51.251720
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    str_0 = 'Wy"%;m1`Vw\\ny'
    role_definition_1 = RoleDefinition(str_0)
    str_1 = 'Y'
    role_definition_2 = RoleDefinition(str_1)
    str_2 = 'Wy&r'
    role_definition_3 = RoleDefinition(str_2)
    str_3 = 'Wy&r'
    role_definition_4 = RoleDefinition(str_3)
    role_definition_4.preprocess_data(str_0)
    str_4 = 'Y'
    role_definition_5 = RoleDefinition(str_4)
    role_definition_5.preprocess_data(str_2)
    str_5 = 'Wy"%;m1`Vw\\ny'