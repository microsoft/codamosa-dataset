

# Generated at 2022-06-25 05:44:51.360057
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    test_case_0()

if __name__ == "__main__":
    test_RoleDefinition_get_name()

# Generated at 2022-06-25 05:44:53.764050
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    str_0 = '\\>1|54'
    role_definition_0 = RoleDefinition(str_0)
    print(role_definition_0.get_name)

# Generated at 2022-06-25 05:44:59.658040
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    str_0 = '\\>1|54'
    role_definition_0 = RoleDefinition(str_0)
    str_1 = '\\>1|54'
    try:
        role_definition_0.preprocess_data(str_1)
    except AnsibleAssertionError as error:
        assert type(error) == AnsibleAssertionError


# Generated at 2022-06-25 05:45:04.295520
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    str_0 = '\\>1|54'
    # Calling RoleDefinition constructor with argument str_0
    role_definition_0 = RoleDefinition(str_0)
    # Calling preprocess_data method of role_definition_0 object with argument ds_0
    ds_0 = '\\>1|54'
    role_definition_0.preprocess_data(ds_0)


# Generated at 2022-06-25 05:45:09.104887
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition_0 = RoleDefinition(role='test_value_1')
    role_definition_0.preprocess_data(role_definition_0)
if __name__ == '__main__':
    test_case_0()
    test_RoleDefinition_preprocess_data()

# Generated at 2022-06-25 05:45:13.221508
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition_0 = RoleDefinition()
    role_definition_0.preprocess_data({'role': '\\>1|54'})


if __name__ == "__main__":
    test_RoleDefinition_preprocess_data()

# Generated at 2022-06-25 05:45:21.730679
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    str_0 = '\\>1|54'
    role_definition_0 = RoleDefinition(str_0)
    assert role_definition_0.get_name() == '\\>1|54'
    assert role_definition_0._role_basedir is None
    assert role_definition_0._role_path is None
    assert role_definition_0._loader is None
    assert role_definition_0._variable_manager is None
    assert role_definition_0._ds == '\\>1|54'
    assert role_definition_0._role_params == {}
    assert role_definition_0._role_collection is None

# End of test cases

# test_case_0()
test_RoleDefinition_get_name()

# Generated at 2022-06-25 05:45:30.844339
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    # Test for int type of role name
    role_definition_0 = RoleDefinition()
    role_definition_0.preprocess_data(1)

    # Test for dict type of role name
    role_definition_1 = RoleDefinition()
    role_definition_1.preprocess_data({u"name": u"test1"})

    # Test for dict type of role name with the name field
    role_definition_2 = RoleDefinition()
    role_definition_2.preprocess_data({u"role": u"test2"})

    # Test for dict type of role name with the name field in lowercase
    role_definition_3 = RoleDefinition()
    role_definition_3.preprocess_data({u"Role": u"test3"})

    # Test for dict type of role name with the name field in uppercase
    role

# Generated at 2022-06-25 05:45:39.609384
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_def = dict(
        role='test_role',
        become='true',
        become_user='bob',
        these='params',
        are='extra',
    )
    rd = RoleDefinition()
    result = rd.preprocess_data(role_def)
    assert result == {
        'role': 'test_role',
        'become': 'true',
        'become_user': 'bob',
    }
    assert rd._role_params == {
        'these': 'params',
        'are': 'extra',
    }
    assert rd._role_path is None

# Generated at 2022-06-25 05:45:41.316415
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    str_0 = '\\>1|54'

    # Test case 0:
    test_case_0()



# Generated at 2022-06-25 05:45:50.515297
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_basedir = 'C:\\Users\\Kazim\\PycharmProjects\\ansible_project\\roles'
    ds = None
    obj = RoleDefinition(role_basedir=role_basedir)
    out = obj.preprocess_data(ds)


# Generated at 2022-06-25 05:45:52.196515
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    str_1 = '!RoleDefinition'
    print('\n\n')
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 05:45:53.563806
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    rd = RoleDefinition()
    rd.preprocess_data(dict())


# Generated at 2022-06-25 05:45:56.021319
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    try:
        # test if exception is raised and catch it
        test_case_0()
        # if no exception is raised, the test case has failed
        assert False
    except:
        # if no exception is raised, the test case has passed
        pass


# Generated at 2022-06-25 05:46:00.651761
# Unit test for method preprocess_data of class RoleDefinition

# Generated at 2022-06-25 05:46:03.511923
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    role_definition_0 = RoleDefinition()

    role_definition_0.get_name()
    role_definition_0.get_name(False)

    return

# Generated at 2022-06-25 05:46:07.544973
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    assert test_RoleDefinition_get_name.__name__ == RoleDefinition.get_name.__name__
    assert RoleDefinition.get_name.__doc__ == "Returns the name of the role, optionally including the FQCN prefix from the collections keyword."
    assert RoleDefinition.get_name.__doc__


# Generated at 2022-06-25 05:46:16.223213
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    str_0 = '\\>1|54'
    str_1 = '\\>1|54'
    str_2 = '  \\>1|54'
    str_3 = '  \\>1|54'
    str_4 = 'a'
    str_5 = '\\>1|54'
    str_6 = '\\>1|54'
    str_7 = '  \\>1|54'
    str_8 = '  \\>1|54'
    str_9 = 'a'

    dict_arg = dict()
    dict_arg['a'] = str_0
    dict_arg['b'] = str_1
    dict_arg['c'] = str_2
    dict_arg['d'] = str_3
    dict_arg['e'] = str_4

# Generated at 2022-06-25 05:46:16.988889
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    obj_0 = RoleDefinition()
    test_case_0()
    return

# Generated at 2022-06-25 05:46:20.585339
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    str_0 = '/home/yuchen/python/ansible/test/test_role_definition.py'
    print(unfrackpath(str_0))
    return


if __name__ == '__main__':
    # test_case_0()
    test_RoleDefinition_preprocess_data()

# Generated at 2022-06-25 05:46:38.220603
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    print("Calling preprocess_data on a dict")
    role_definition_1 = RoleDefinition()
    ds_1 = {"role": "test1"}
    role_definition_1.preprocess_data(ds_1)
    assert role_definition_1._role_path == "test1"
    assert role_definition_1._role_params == {}

    print("Calling preprocess_data on a string")
    role_definition_1 = RoleDefinition()
    ds_2 = "test2"
    role_definition_1.preprocess_data(ds_2)
    assert role_definition_1._role_path == "test2"
    assert role_definition_1._role_params == {}

    print("Calling preprocess_data on an AnsibleBaseYAMLObject")
    role_definition_1 = RoleDefinition()


# Generated at 2022-06-25 05:46:41.925462
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    rd = RoleDefinition()
    a = rd.preprocess_data(dict(name="test_role_name", connection="test_connection", foo="test_foo"))
    assert(a["role"] == "test_role_name")
    assert(a["connection"] == "test_connection")
    assert(rd.get_role_params()["foo"] == "test_foo")


# Generated at 2022-06-25 05:46:48.663688
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition_0 = RoleDefinition()
    role_definition_0.preprocess_data("""127.0.0.1""")

    role_definition_0 = RoleDefinition()
    role_definition_0.preprocess_data("""{"name": "test_role"}""")

    role_definition_0 = RoleDefinition()
    role_definition_0.preprocess_data("""{"role": "test_role"}""")

    # fails with AnsibleError: role definitions must contain a role name
    #role_definition_0 = RoleDefinition()
    #role_definition_0.preprocess_data("""{"role": ""}""")

    # fails with AnsibleError: role definitions must contain a role name
    #role_definition_0 = RoleDefinition()
    #role_definition_0.preprocess_data("""{}""

# Generated at 2022-06-25 05:46:58.998495
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition = RoleDefinition()
    role_definition.preprocess_data("role_0")
    assert role_definition._ds == "role_0"
    assert role_definition._role == "role_0"
    assert role_definition._role_path == None
    assert role_definition._role_params == {}

# Generated at 2022-06-25 05:47:02.845108
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    assert True

# Generated at 2022-06-25 05:47:10.372357
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition_0 = RoleDefinition()

    role_definition_0.role = 'foobar'
    role_definition_0.name = 'foobar2'

    ds = {
            'role': 'foobar',
            'name': 'foobar2'
         }

    ds_1 = {
            'role': 'foobar',
            'name': 'foobar2',
            'x': '1',
            'y': '2'
         }

    ds_2 = {
            'role': 'foobar',
            'name': 'foobar2',
            'a': 'b',
            'c': 'd'
         }

    role_definition_0._load_role_name(ds)

    role_definition_0._load_role_path('foobar')

    role_definition_0

# Generated at 2022-06-25 05:47:12.433756
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition_0 = RoleDefinition()
    role_definition_0.preprocess_data('./../library/')



# Generated at 2022-06-25 05:47:19.051160
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    # test 1 (simple)
    role_definition_1 = RoleDefinition()
    role_definition_1.preprocess_data('some_role')
    assert role_definition_1._role == 'some_role'
    assert role_definition_1._role_path is None

    # test 2 (complex)
    role_definition_2 = RoleDefinition(loader=MockLoader())
    role_definition_2.preprocess_data({'role': 'some_role', 'a': 'b'})
    assert role_definition_2._role == 'some_role'
    assert role_definition_2._role_path is None
    assert role_definition_2._role_params == dict(a='b')

    # test 3 (complex, alternate 'name' attribute)
    role_definition_3 = RoleDefinition(loader=MockLoader())


# Generated at 2022-06-25 05:47:21.350290
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    role_definition_0 = RoleDefinition()
    role_definition_0.preprocess_data("/home/username/myansible/roles/role_name")
    assert role_definition_0.get_name() == "role_name", "Test failed"


# Generated at 2022-06-25 05:47:29.426968
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():

    my_role_definition = RoleDefinition()
    my_role_definition._play = Base()
    my_role_definition._role_path = '/this/is/my/role/path'

    # testing when include_role_fqcn is True
    assert my_role_definition.get_name(True) == '.'.join(x for x in (my_role_definition._role_collection, my_role_definition.role) if x)

    # testing when include_role_fqcn is False
    assert my_role_definition.get_name(False) == my_role_definition.role

# Generated at 2022-06-25 05:47:40.110386
# Unit test for method preprocess_data of class RoleDefinition

# Generated at 2022-06-25 05:47:43.946213
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition_1 = RoleDefinition()


# Generated at 2022-06-25 05:47:49.394101
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition_1 = RoleDefinition()
    role_definition_1.preprocess_data({"role": "common", "connection": "local", "vars": {"var1": "value of var1"}})
    assert role_definition_1.get_role_path() == '/home/discover/project/roles/common'

# Generated at 2022-06-25 05:47:50.825104
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    role_definition = RoleDefinition()
    assert role_definition.role is None
    assert role_definition.get_name() == ""

# Generated at 2022-06-25 05:47:53.012618
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition_0 = RoleDefinition()
    role_definition_0.preprocess_data("role_definition")

if __name__ == '__main__':
    test_case_0()
    test_RoleDefinition_preprocess_data()

# Generated at 2022-06-25 05:48:00.072682
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    # Test with ds as an int
    ds = 1
    role_definition = RoleDefinition()
    new_ds = role_definition.preprocess_data(ds)
    assert isinstance(new_ds, string_types)
    assert new_ds == '1'
    # Test with ds as a simple string
    ds = 'sample'
    new_ds = role_definition.preprocess_data(ds)
    assert isinstance(new_ds, string_types)
    assert new_ds == 'sample'
    # Test with ds as a dictionary with role field specified
    ds = {'role': 'sample'}
    new_ds = role_definition.preprocess_data(ds)
    assert isinstance(new_ds, AnsibleMapping)
    assert new_ds['role'] == 'sample'
   

# Generated at 2022-06-25 05:48:10.487259
# Unit test for method preprocess_data of class RoleDefinition

# Generated at 2022-06-25 05:48:12.747926
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition_0 = RoleDefinition()
    role_definition_0.preprocess_data("")

# Generated at 2022-06-25 05:48:19.568614
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition_0 = RoleDefinition()
    role_definition_0._loader = None
    role_definition_0._variable_manager = None
    role_definition_0._collection_list = None
    role_definition_0.preprocess_data(ds=None)

# Generated at 2022-06-25 05:48:22.666403
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_data = {"role": "nginx"}
    test_role = RoleDefinition()
    result = test_role.preprocess_data(role_data)
    assert isinstance(result, dict)

# Generated at 2022-06-25 05:48:38.031729
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    '''
    Test the behavior of preprocess_data in class RoleDefinition
    '''

    # Case 0: Test role with name, tags and become
    role_definition_0 = RoleDefinition()
    new_ds = role_definition_0.preprocess_data({'name': 'test_role', 'tags': ['test_tag'], 'become': True})
    assert isinstance(new_ds, dict)
    assert new_ds == {'become': True, 'name': 'test_role', 'tags': ['test_tag'], 'role': 'test_role'}
    assert role_definition_0.tags == {'test_tag'}

    # Test role with name, action and args that are not dict
    role_definition_1 = RoleDefinition()

# Generated at 2022-06-25 05:48:45.907234
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    # Tests that the method preprocess_data with a string
    # as input returns a dictionary with a key role:'input parameter'
    role_definition_0 = RoleDefinition()
    text_parameter = "test_with_string"
    dictionary = role_definition_0.preprocess_data(text_parameter)
    assert dictionary['role'] == "test_with_string"
    # Tests that the method preprocess_data with a dictionary as
    # input returns a dictionary with a key role:'role name'
    input_dict = {"role": "test_with_dict"}
    dictionary = role_definition_0.preprocess_data(input_dict)
    assert dictionary['role'] == "test_with_dict"
    # Tests that the method preprocess_data with a dictionary as
    # input returns a dictionary with a key role:'role name'

# Generated at 2022-06-25 05:48:53.393103
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    mock_loader = loader_mock()
    mock_variable_manager = variable_manager_mock()
    role_definition = RoleDefinition(loader=mock_loader, variable_manager=mock_variable_manager)

    # Testing for case when ds is int
    ds=123
    value = role_definition.preprocess_data(ds)
    assert value == '123'

    #Testing for case when ds is a dict
    ds = {
    'role': {
        'role1: ': 'foo'
    },
    'name': {
        'name1': 'foo'
    }}
    value = role_definition.preprocess_data(ds)
    assert value == { 'role': 'foo' }



# Generated at 2022-06-25 05:49:05.249670
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    # Create an object of class RoleDefinition
    role_definition = RoleDefinition()
    # Create a dictionary object to hold parameter values to be parsed
    ds = dict()
    # Construct a string value to assign to key 'role' in the parameter dictionary
    ds['role'] = 'the_role'
    # Pass the parameter value to the preprocess_data method of role_definition object
    result = role_definition.preprocess_data(ds)
    # Verify the expected result against the value returned by preprocess_data
    assert(str(result) == "{'role': 'the_role'}")
    # Construct an int value to assign to key 'role' in the parameter dictionary
    ds['role'] = 123
    # Pass the parameter value to the preprocess_data method of role_definition object

# Generated at 2022-06-25 05:49:12.389020
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    role_definition_0 = RoleDefinition()
    assert (role_definition_0.get_name()) == None
    r = RoleDefinition()
    r._role_collection = 'my.collection'
    r.role = 'myrole'
    assert r.get_name() == 'my.collection.myrole'
    assert r.get_name(include_role_fqcn=False) == 'myrole'


# Generated at 2022-06-25 05:49:20.718804
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition_1 = RoleDefinition()
    assert role_definition_1.preprocess_data({'role': u'dep1'})['role'] == u'dep1'
    
    role_definition_2 = RoleDefinition()
    assert role_definition_2.preprocess_data({'name': u'dep2'})['role'] == u'dep2'
    
    role_definition_3 = RoleDefinition()
    assert role_definition_3.preprocess_data({'role': '{{ test_var }}'})['role'] == '{{ test_var }}'
    
    role_definition_4 = RoleDefinition()
    assert role_definition_4.preprocess_data(u'dep4')['role'] == u'dep4'


# Generated at 2022-06-25 05:49:26.287115
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    input_data = {'role': 'git', 'scm': 'git', 'version': 'master'}
    role_definition_obj_0 = RoleDefinition()
    role_definition_obj_0.preprocess_data(input_data)


# Generated at 2022-06-25 05:49:32.656227
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    # Input to test case: ds with string type as argument
    role_definition_string = RoleDefinition()
    role_definition_string_role_name = role_definition_string._load_role_name('test')
    assert role_definition_string_role_name == 'test'

    # Input to test case: dict type as argument
    role_definition_dict = RoleDefinition()

    # Returned result from preprocess_data should contain role attribute
    preprocess_data_result = role_definition_dict.preprocess_data({
        'role': 'test',
        'other': 'test'
    })
    assert 'role' in preprocess_data_result

    # Returned result from preprocess_data should contain role attribute with 'role' as key

# Generated at 2022-06-25 05:49:43.471084
# Unit test for method preprocess_data of class RoleDefinition

# Generated at 2022-06-25 05:49:50.727490
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    
    # TODO: mock loader.path_exists and _get_collection_role_path to return a defined value for the test
    # TODO: run test with loader.path_exists return both a defined value and mocking _get_collection_role_path to return True
    data_structure = {'role': 'roleg',
                      'tasks': [
                          {'name': 'task1', 'task1_param1': 'value1'},
                          {'name': 'task2', 'task2_param1': 'value1'}],
                      'tasks_param1': 'value1'}
    role_definition = RoleDefinition()
    role_definition.preprocess_data(data_structure)

# Generated at 2022-06-25 05:50:10.957007
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    # unit test of ansible.playbook.role_definition.RoleDefinition.preprocess_data
    # test with int
    data = 'test-role'
    data = 1024
    rd = RoleDefinition()
    rd.preprocess_data(data)
    assert len(rd._ds) == 1
    assert 'role' in rd._ds
    assert rd._ds['role'] == '1024'

    # test with dict
    data = 'test-role'
    data = dict(role='test-role')
    rd = RoleDefinition()
    rd.preprocess_data(data)
    assert len(rd._ds) == 1
    assert 'role' in rd._ds
    assert rd._ds['role'] == 'test-role'

    # test with str
    data = 'test-role'


# Generated at 2022-06-25 05:50:15.138923
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    pass

# merge of test_case_0, test_case_1, test_case_2, test_case_3, test_case_4, test_case_5, test_case_6, test_case_7
# into test_case_0

# Generated at 2022-06-25 05:50:21.524242
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():

    # Test Case 0: test preprocess_data
    role_definition_0 = RoleDefinition()
    role_definition_0.preprocess_data('role: testing_role_name')
    role_definition_0.preprocess_data('role: testing_role_name with_params')
    role_definition_0.preprocess_data({'role': 'testing_role_name with_params', 'become': 'foo'})
    role_definition_0.preprocess_data({'name': 'testing_role_name with_params', 'become': 'foo'})

# Generated at 2022-06-25 05:50:29.606299
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    role_definition_1 = RoleDefinition()
    role_definition_1.role = "test_role"
    assert role_definition_1.get_name() == "test_role"

    role_definition_2 = RoleDefinition()
    role_definition_2.role = "test_role_2"
    role_definition_2._role_name = "test_role_2"
    role_definition_2._role_collection = "test_ansible_namespace"
    assert role_definition_2.get_name() == "test_ansible_namespace.test_role_2"



# Generated at 2022-06-25 05:50:41.185387
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    rd = RoleDefinition()
    data1 = {'role': 'superuser'}
    data2 = {'role': '../my.role/'}
    data3 = {'role': '../my.role/', 'sudo': 'true'}
    data4 = {'role': 'my.role', 'sudo': 'true'}
    data5 = {'foo': 'bar'}
    data6 = {'role': 'foo', 'bar': 'baz'}
    data7 = 'foo'

    assert rd._load_role_name(data1) == 'superuser'
    assert rd._load_role_name(data2) == '../my.role/'
    assert rd._load_role_name(data3) == '../my.role/'
    assert rd._load_role_

# Generated at 2022-06-25 05:50:50.090997
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    # unit test with a role name that has a colon in it
    role_def_1 = RoleDefinition().preprocess_data('some_collection.some_namespace.some_role')
    assert isinstance(role_def_1, dict)
    assert role_def_1 == {'role': 'some_collection.some_namespace.some_role'}

    # unit test with a role name that's just a string
    role_def_2 = RoleDefinition().preprocess_data('some_role')
    assert isinstance(role_def_1, dict)
    assert role_def_2 == {'role': 'some_role'}

    # unit test with a dict that has a role: but no name:
    role_def_3 = RoleDefinition().preprocess_data({'role': 'some_role'})
    assert isinstance

# Generated at 2022-06-25 05:50:51.710972
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition_0 = RoleDefinition()
    if role_definition_0.preprocess_data('role_name'):
        return 'success'
    else:
        return 'fail'


# Generated at 2022-06-25 05:50:56.863066
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible import __version__
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    role_definition_0 = RoleDefinition()
    assert role_definition_0 is not None
    ds_0 = 'foo'
    new_ds_0 = role_definition_0.preprocess_data(ds_0)
    assert new_ds_0._attributes['role'] == 'foo'
    assert new_ds_0._data is None
    ds_1 = 'bar'
    new_ds_1 = role_definition_0.preprocess_data(ds_1)
    assert new_ds_1._attributes['role'] == 'bar'
    assert new_ds_1._data is None
    ds_2 = 'baz'
    new_ds_2 = role_

# Generated at 2022-06-25 05:51:07.075850
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    # Initialize object
    role_definition_1 = RoleDefinition()

    # load bare string
    test_ds_0 = "simple_name"
    result_ds_0 = role_definition_1.preprocess_data(test_ds_0)
    expected_result_ds_0 = {'role': 'simple_name'}
    assert result_ds_0 == expected_result_ds_0, result_ds_0

    # load string template
    test_ds_1 = "{% raw %}{{role_name}}{% endraw %}"
    result_ds_1 = role_definition_1.preprocess_data(test_ds_1)
    expected_result_ds_1 = {'role': '{{role_name}}'}
    assert result_ds_1 == expected_result_ds_1, result_ds

# Generated at 2022-06-25 05:51:16.349915
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition_1 = RoleDefinition()
    role_definition_1._loader = {}
    role_definition_1._variable_manager = {}

    ds_1 = {'role': 'name_1', 'bad_key': 'value_1'}
    role_definition_1.data = ds_1
    role_definition_1.preprocess_data(ds_1)
    assert role_definition_1._role_params == {'bad_key': 'value_1'}

    ds_2 = 'name_2'
    role_definition_1.data = ds_2
    role_definition_1.preprocess_data(ds_2)
    assert role_definition_1._role_params == {}

    ds_3 = 1
    role_definition_1.data = ds_3

# Generated at 2022-06-25 05:51:42.033721
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    test_role_name = "some_role"
    test_role_path = "/home/user/some_role"

    # test_ds1 = string_types(test_role_name)
    test_ds1 = "some_role"
    role_definition_1 = RoleDefinition()
    role_definition_1.preprocess_data(test_ds1)
    print(role_definition_1._role_path)

    # test_ds2 = {'role': test_role_name}
    test_ds2 = {'role': 'some_role'}
    role_definition_2 = RoleDefinition()
    role_definition_2.preprocess_data(test_ds2)
    print(role_definition_2._role_path)

    # test_ds3 = {'role': test_role_path}


# Generated at 2022-06-25 05:51:50.387597
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition_1 = RoleDefinition()
    role_definition_1._loader = None
    role_definition_1._variable_manager = None
    role_definition_1._play = None
    role_definition_1._ds = None
    role_definition_1._role = None
    role_definition_1._role_basedir = None
    role_definition_1._role_path = None
    role_definition_1._role_params = None
    role_definition_1._collection_list = None
    ds_1 = None

    # Test code for preprocess_data of class RoleDefinition
    result = role_definition_1.preprocess_data(ds_1)
    assert result is None


# Generated at 2022-06-25 05:52:00.946008
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    role_definition_0 = RoleDefinition()
    role_definition_0.role = "the_role_name"
    role_definition_0._role_collection = "the_role_collection_name"
    # Method get_name of class RoleDefinition returns the exact value 'the_role_name' as a string
    assert role_definition_0.get_name() == "the_role_name"
    # Method get_name of class RoleDefinition returns the exact value 'the_role_collection_name.the_role_name' as a string
    assert role_definition_0.get_name(True) == "the_role_collection_name.the_role_name"
    role_definition_0._role_collection = None
    # Method get_name of class RoleDefinition returns the exact value 'the_role_name' as a string

# Generated at 2022-06-25 05:52:05.410678
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    role_definition_0 = RoleDefinition()
    assert(role_definition_0.get_name() == None)


# Generated at 2022-06-25 05:52:11.750007
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    # create empty objects
    role_definition_1 = RoleDefinition()

    # populate with input
    role_definition_1.role = 'test_role'
    role_definition_1._role_collection = 'test_collection'

    # call method to be tested
    result = role_definition_1.get_name()

    # check result
    assert result == 'test_collection.test_role'


# Generated at 2022-06-25 05:52:19.168129
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    # Test the following case:
    # 1. A bare string
    # 2. A dict with both 'role' and 'name', with the latter overriding the former
    # 3. A dict with 'role' and/or 'name' and some role params
    # 4. A dict with no 'role' or 'name' and some role params (should fail)

    # Test case #1
    role_definition_0 = RoleDefinition()
    preprocessed_data = role_definition_0.preprocess_data('test_role')
    assert preprocessed_data['role'] == 'test_role'

    # Test case #2
    role_definition_1 = RoleDefinition()
    preprocessed_data = role_definition_1.preprocess_data({'role': 'test_role', 'name': 'test_name'})
    assert preprocess

# Generated at 2022-06-25 05:52:20.745739
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition_1 = RoleDefinition()
    role_definition_1.preprocess_data("role_name")
    # TODO: add more asserts


# Generated at 2022-06-25 05:52:31.060708
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition_test_0 = RoleDefinition()
    role_definition_test_0._ds = dict()
    role_definition_test_0._ds['role'] = 'test_role'
    role_definition_test_0._ds['tasks'] = list()
    role_definition_test_0._ds['tasks'].append('test_task')
    role_definition_test_0._ds['tasks'].append('test_task')
    role_definition_test_0._ds['vars'] = dict()
    role_definition_test_0._ds['vars']['test_key'] = 'test_val'

# Generated at 2022-06-25 05:52:40.987216
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    test_data = 'role_name'
    test_variable_manager = None
    test_loader = None
    test_collection_list = ['ansible.builtin', 'ansible.juniper']
    role_definition = RoleDefinition(variable_manager=test_variable_manager,
                                     loader=test_loader,
                                     collection_list=test_collection_list)
    test_ds = role_definition.preprocess_data(test_data)
    assert test_ds['role'] == 'role_name'
    test_data = {'role': 'role_name', 'some_key': 'some_value'}
    role_definition = RoleDefinition(variable_manager=test_variable_manager,
                                     loader=test_loader,
                                     collection_list=test_collection_list)
    test_ds = role_definition

# Generated at 2022-06-25 05:52:47.688248
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    data = """
- role: ansible.apt

- role: ansible.base
  name: ansible.base_without_role
"""
    yaml_data = AnsibleMapping.load(data)
    assert yaml_data
    assert isinstance(yaml_data, list)
    assert len(yaml_data) == 2
    assert isinstance(yaml_data[0], RoleDefinition)

    role_definition_1 = RoleDefinition()
    role_definition_1.name = "ansible.base_without_role"

    assert yaml_data[0].get_name() == "ansible.apt"
    assert yaml_data[1].get_name() == "ansible.base"

    assert role_definition_1.get_name() == "ansible.base_without_role"

# Generated at 2022-06-25 05:53:09.863531
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition = RoleDefinition()
    data = {}
    role_definition.preprocess_data(data)

# Generated at 2022-06-25 05:53:18.411406
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition_0 = RoleDefinition()
    role_definition_0._init_attributes()
    role_definition_0._variable_manager = None
    role_definition_0._loader = None
    role_definition_0._role_basedir = None
    role_definition_0._collection_list = None
    ansible_mapping_0 = AnsibleMapping()
    ansible_mapping_0.ansible_pos = None
    role_definition_0._ds = ansible_mapping_0
    role_definition_0._role_params = dict()
    role_definition_0._role_path = None
    role_definition_0._role_collection = None
    ansible_mapping_1 = AnsibleMapping()
    ansible_mapping_1['role'] = ''
    ansible_mapping_

# Generated at 2022-06-25 05:53:25.884051
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition_1 = RoleDefinition()
    role_definition_1.preprocess_data({"role": "test_role_name", "roles_path": "/tmp/roles"})
    assert role_definition_1._role == "test_role_name"
    assert role_definition_1._role_path == "/tmp/roles/test_role_name"

    role_definition_2 = RoleDefinition()
    role_definition_2.preprocess_data({"role": "test_role_name", "roles_path": "/tmp/roles", "extra_var": "extra"})
    assert role_definition_2._role == "test_role_name"
    assert role_definition_2._role_path == "/tmp/roles/test_role_name"
    assert role_definition_2.extra_var

# Generated at 2022-06-25 05:53:29.867342
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():

    #
    # Test case #1: regular dict
    #
    role_definition_1 = RoleDefinition()
    ds = dict(
        role='test_role_name'
    )
    ds = role_definition_1.preprocess_data(ds)
    assert 'role' in ds
    assert ds['role'] == 'test_role_name'

    #
    # Test case #2: dict with extra params
    #
    role_definition_2 = RoleDefinition()
    ds = dict(
        role='test_role_name',
        param1=True,
        param2=1,
        param3='test_param_3',
    )
    ds = role_definition_2.preprocess_data(ds)
    assert 'role' in ds

# Generated at 2022-06-25 05:53:33.915216
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    rd = RoleDefinition()
    assert rd.get_name(include_role_fqcn=False) is None
    rd.role = 'role_name'
    assert rd.get_name() == 'role_name'
    rd._role_collection = 'collection'
    assert rd.get_name() == 'collection.role_name'

# Generated at 2022-06-25 05:53:42.774644
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition_1 = RoleDefinition()
    input_1 = 'ansible.satellite.satellite_capsule_install'
    expected_result_1 = {'role': 'ansible.satellite.satellite_capsule_install'}
    actual_result_1 = role_definition_1.preprocess_data(input_1)
    assert expected_result_1 == actual_result_1, "Unexpected result: %s" % actual_result_1

    role_definition_2 = RoleDefinition()
    input_2 = 'katello.client.foreman_register'
    expected_result_2 = {'role': 'katello.client.foreman_register'}
    actual_result_2 = role_definition_2.preprocess_data(input_2)
    assert expected_result_2 == actual_

# Generated at 2022-06-25 05:53:50.093001
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition_0 = RoleDefinition()
    role_definition_0.preprocess_data(
        {'role': 'test', 'other': 'test1'})
    print('test_RoleDefinition_preprocess_data...')
    print('role_definition_0._role_path: %s' % role_definition_0._role_path)
    print('role_definition_0._role: %s' % role_definition_0._role)
    print('role_definition_0._role_params: %s' % role_definition_0._role_params)

# test_RoleDefinition_preprocess_data()


# Generated at 2022-06-25 05:53:52.911749
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition_1 = RoleDefinition()
    role_definition_1.preprocess_data(dict([('role',dict([('role', 'test_role_0')]))]))


# Generated at 2022-06-25 05:53:56.183544
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    role_definition_0 = RoleDefinition()
    assert isinstance(role_definition_0.get_name(), str), \
        "RoleDefinition.get_name is not string"


# Generated at 2022-06-25 05:53:59.298421
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    test_role = {"role": "TestRole", "x": "y"}
    role_definition_obj = RoleDefinition()
    assert role_definition_obj.preprocess_data(test_role) == {"role": "TestRole", "x": "y"}

# Generated at 2022-06-25 05:54:28.309414
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():

    # Case 0: Valid role definition with string type name
    role_definition_0 = RoleDefinition()
    role_name_0 = 'TestRole'
    processed_role_name_0 = role_definition_0.preprocess_data(role_name_0)
    assert(role_name_0 == processed_role_name_0)

    # Case 1: Valid role definition with role name
    role_definition_1 = RoleDefinition()
    role_name_1 = 'TestRole'
    ds = {'role': role_name_1}
    processed_role_name_1 = role_definition_1.preprocess_data(ds)
    assert(role_name_1 == processed_role_name_1)

    # Case 2: Role definition with role name and params
    role_definition_2 = RoleDefinition()
    role_

# Generated at 2022-06-25 05:54:29.833223
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    # Test case 0
    role_definition_0 = RoleDefinition()
    role_name = role_definition_0.get_name()
    assert role_name == None

# Generated at 2022-06-25 05:54:35.165649
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    role_definition_0 = RoleDefinition()
    # Testing if method get_name of class RoleDefinition, called with
    # argument include_role_fqcn=True raises exception AnsibleError
    try:
        role_definition_0.get_name(True)
    except AnsibleError:
        pass
    except Exception as err:
        raise AssertionError(err)
    else:
        raise AssertionError('AnsibleError exception was not raised')


# Generated at 2022-06-25 05:54:36.483253
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    print("test_RoleDefinition_get_name")
    test_case_0()

# Generated at 2022-06-25 05:54:43.021219
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():

    RoleDefinition.registered_attrs = {'role': Attribute(isa='string')}

    role_definition = RoleDefinition()

    # Case 0:
    # Simple string as a role name
    # Expected Result: role name shouldn't be changed
    role_name = 'role1'
    role_name_2 = role_definition.preprocess_data(role_name)
    if not role_name_2 == 'role1':
        raise AssertionError()

    # Case 1:
    # Role definition as a dict with a name
    # Expected Result: role name should be extracted from the dict
    role_name = {'name': 'role2', 'something': 'else'}
    role_name_2 = role_definition.preprocess_data(role_name)