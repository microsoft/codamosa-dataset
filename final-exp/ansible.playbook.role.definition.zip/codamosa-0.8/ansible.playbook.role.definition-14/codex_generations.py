

# Generated at 2022-06-11 10:28:52.720563
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    rd = RoleDefinition()
    rd._role_collection = None
    rd.role = "test"
    assert rd.get_name() == "test"

    rd._role_collection = None
    rd.role = AnsibleVaultEncryptedUnicode("test")
    assert rd.get_name() == "test"

    rd._role_collection = "ns.collection"
    rd.role = "test"
    assert rd.get_name() == "ns.collection.test"

    rd._role_collection = "ns.collection"

# Generated at 2022-06-11 10:28:57.057085
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    def test_name(role, expected_name):
        rd = RoleDefinition()
        rd._role = role
        if expected_name:
            assert rd.get_name() == expected_name
        else:
            assert rd.get_name() == role
    test_name('my_role', 'my_role')
    test_name('my_collection.some_role', 'my_collection.some_role')
    test_name('my_collection.some.nested.role', 'my_collection.some.nested.role')


# Generated at 2022-06-11 10:28:57.711000
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    pass

# Generated at 2022-06-11 10:29:09.985579
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    # test case 1: when ds is string type
    rd = RoleDefinition()
    new_ds = rd.preprocess_data("test_role")
    assert new_ds['role'] == "test_role"
    # test case 2: when ds is dict type, and have name field
    rd = RoleDefinition()
    new_ds = rd.preprocess_data({"name": "test_role"})
    assert new_ds['role'] == "test_role"
    # test case 3: when ds is dict type, and have role field
    rd = RoleDefinition()
    new_ds = rd.preprocess_data({"role": "test_role"})
    assert new_ds['role'] == "test_role"
    # test case 4: when ds is dict type, and have name field

# Generated at 2022-06-11 10:29:22.087803
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    class TestRoleDefinition(RoleDefinition):
        _valid_attrs = dict(
            a1=Attribute(isa='string', default=None, always_post_validate=True),
            a2=Attribute(isa='string', default=None, always_post_validate=True),
        )

    # Test a dict containing a dict
    ds = dict()
    ds['a1'] = 10
    ds['a2'] = '20'
    ds['a3'] = dict()
    ds['a3']['b1'] = 'foo'
    ds['a3']['b2'] = dict()
    ds['a3']['b2']['c1'] = 'bar'
    ds['a3']['b2']['c2'] = 10

    g = Test

# Generated at 2022-06-11 10:29:34.501934
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition = RoleDefinition()
    role_definition._valid_attrs["one"] = Attribute(name='one')
    role_definition._valid_attrs["two"] = Attribute(name='two')
    role_definition._valid_attrs["three"] = Attribute(name='three')
    role_definition._valid_attrs["four"] = Attribute(name='four')
    role_definition._valid_attrs["five"] = Attribute(name='five')
    role_definition._valid_attrs["six"] = Attribute(name='six')
    role_definition._valid_attrs["seven"] = Attribute(name='seven')
    role_definition._valid_attrs["eight"] = Attribute(name='eight')

    # test different variations of dictionary

# Generated at 2022-06-11 10:29:37.666371
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    role_name = 'test.role.name'
    role = RoleDefinition({'role': role_name})
    assert role.get_name() == role_name
    assert role.get_name(include_role_fqcn=False) == 'name'

# Generated at 2022-06-11 10:29:42.944253
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    import ansible.parsing.yaml.loader as yaml_loader
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    '''
    Test module preprocess_data and each if, elif and else block in
    the method with and without vault encrypted data.
    '''
    loader = DataLoader()
    variable_manager = VariableManager()
    play = None
    role_basedir = None
    collection_list = None

    # simple test for string type
    ds = u'role1'
    role_def_obj = RoleDefinition(play, role_basedir, variable_manager, loader, collection_list)
    result = role_def_

# Generated at 2022-06-11 10:29:55.890077
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.parsing.yaml.objects import AnsibleMapping

    # test role definition with simple string
    r = RoleDefinition()
    ds = 'foo'
    result = r.preprocess_data(ds)
    assert isinstance(result, AnsibleMapping)
    assert 'role' in result
    assert result['role'] == 'foo'

    # test role definition with role field using YAML object
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    r = RoleDefinition()

# Generated at 2022-06-11 10:30:00.405008
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    rd = RoleDefinition()
    rd.preprocess_data({'role': 'file://../test_role3', 'test1': 1, 'test2': 2})
    assert rd._role == 'test_role3'
    assert rd._role_params == {'test1': 1, 'test2': 2}

# Generated at 2022-06-11 10:30:13.541644
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():

    class DataStruct:
        def __init__(self, ds):
            self.ds = ds

    data = DataStruct({'role': 'geerlingguy.java', 'tasks': [{'debug': {'msg': 'ansible'}}]})

    role_definition = RoleDefinition(play=None, role_basedir=None, variable_manager=None, loader=None, collection_list=None)
    role_definition.preprocess_data(data)

    assert role_definition.get_name() == 'geerlingguy.java'
    assert role_definition.get_role_params() == {'tasks': [{'debug': {'msg': 'ansible'}}]}

# Generated at 2022-06-11 10:30:24.469162
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    d = {}
    d['role'] = 'nginx'
    r = RoleDefinition(role_basedir='ansible.legacy.role',
                       variable_manager=None,
                       loader=None,
                       collection_list=['nginx'])
    r._ds = d
    r._role = d['role']
    # role found in collection but not in paths
    r._role_path = None
    r._role_collection = 'nginx'
    assert r.get_name() == 'nginx.nginx'
    # role found in paths but not in collections
    d['role'] = 'test_role'
    r._ds = d
    r._role = d['role']
    r._role_path = '/path/to/roles/test_role'
    r._role_collection = None
    assert r

# Generated at 2022-06-11 10:30:34.325670
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.playbook.play import Play
    from ansible.parsing.yaml.loader import AnsibleLoader

    play_context = dict(
        port=2222
    )
    loader = AnsibleLoader(None, play_context)
    play = Play()
    play._variable_manager = VariableManager()
    play._loader = loader

    # Load the YAML data.
    data = '''
        - hosts: localhost
          tasks:
            - debug:
                msg: "hello"
                var1: "foo"
    '''
    ds = AnsibleLoader(data, play_context)
    role_definition = RoleDefinition(play, 'dummy_role_basedir', play._variable_manager, play._loader)
    new_ds = role_definition.preprocess_data(ds)

   

# Generated at 2022-06-11 10:30:44.672764
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    from ansible.playbook.play import Play
    from ansible.playbook.role_include import RoleInclude

    class DummyPlay(Play):

        def __init__(self, role_basedir):
            super(DummyPlay, self).__init__()
            self.role_basedir = role_basedir

    ri = RoleInclude()
    # create a single collection
    collection_1 = AnsibleCollectionRef.from_short_name('name_space.collection_1')
    # create multiple collections
    collection_2 = AnsibleCollectionRef.from_short_name('name_space.collection_2')
    collection_3 = AnsibleCollectionRef.from_short_name('name_space.collection_2.collection_3')
    # create a list of multiple collections

# Generated at 2022-06-11 10:30:54.317128
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    variables = {'ansible_connection': 'docker', 'ansible_user': 'root'}
    role_name = 'foo'
    role_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '../', '../', '..', 'lib', 'ansible', 'roles', role_name))
    rd = RoleDefinition()
    rd._role = role_name
    rd._role_path = role_path
    result = rd.get_name()
    assert result == 'foo'
    result = rd.get_name(include_role_fqcn=False)
    assert result == 'foo'

# Generated at 2022-06-11 10:31:04.064578
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    import sys
    import yaml

    def _get_RoleDefinition_preprocess_data_mock_loader(data):
        class FakeLoader:
            def __init__(self, basedir):
                self.basedir = basedir

            def list_directory(self, path):
                return [r'\name']

            def path_exists(self, path):
                return path == r'\path'

            def get_basedir(self):
                return self.basedir

        basedir = r'\playbook'
        ret = _preprocess_data(data, FakeLoader(basedir))

        return ret

    class MockLoader:
        def __init__(self, basedir):
            self.basedir = basedir

        def list_directory(self, path):
            return [r'\name']


# Generated at 2022-06-11 10:31:16.432712
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    ################################################################################
    # Test the RoleDefinition class without collection usage
    ################################################################################

    class MockLoader:
        def __init__(self, basedir='/foo/bar'):
            self._basedir = basedir

        def path_exists(self, name):
            return name.startswith(self._basedir)

        def get_basedir(self):
            return self._basedir

    class MockVariableManager:
        def __init__(self, vars):
            self._vars = vars

        def get_vars(self, play=None):
            return self._vars.copy()

    loader = MockLoader()
    variable_manager = MockVariableManager({})


# Generated at 2022-06-11 10:31:27.098783
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    '''
    Test for method preprocess_data of class RoleDefinition
    '''
    from ansible.template import Templar

    templar = Templar(loader=None, variables=dict())
    role_def = RoleDefinition(play=object(), role_basedir='/tmp', variable_manager=None, loader=None)
    role_def.preprocess_data('sample')
    assert role_def._role_params == dict()
    assert role_def._role_path == 'sample'
    role_def.preprocess_data({'role': 'sample', 'some_key': 'some_value'})
    assert role_def._role_params == {'some_key': 'some_value'}
    assert role_def._role_path == 'sample'

# Generated at 2022-06-11 10:31:36.369627
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    roles_path = ['.']
    play = dict()
    role_basedir = '.'
    variable_manager = dict()
    loader = dict()
    collection_list = dict()

    test_role_path = './test_role'
    test_role_name = 'test_role'

    test_obj = RoleDefinition(play, role_basedir, variable_manager, loader, collection_list)
    test_obj._role_path = test_role_path
    test_obj.role = test_role_name
    assert test_obj.get_name(True) == 'test_role'
    assert test_obj.get_name(False) == 'test_role'

# Generated at 2022-06-11 10:31:47.987290
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():

    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.utils.color import stringc


# Generated at 2022-06-11 10:32:04.163554
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.collection_loader._collection_finder import _get_collection_role_path

    # test with a dict
    ds = dict(
        role="a.b.c.d",
        become_user="root",
        become="no",
        my_param="some_value",
        other_param=dict(
            foo="bar",
            baz="bab"
        )
    )

    # test with a string
    ds2 = 'a.b.c.d'

    loader = DataLoader()
    role_def = RoleDefinition()
    role_def.preprocess_data(ds)
    role_def.preprocess_data(ds2)

    # test role name with role_path dict
    role_def

# Generated at 2022-06-11 10:32:14.716626
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    display = Display()

    variable_manager = VariableManager()
    loader = DataLoader()

    hosts = InventoryManager(loader=loader, sources='localhost,')
    variable_manager.set_inventory(hosts)

    # this is what the playbooks should contain:
    # roles:
    #   - role: myrole
    #     become: true
    #     become_method: sudo
    #     become_user: root
    #     when: hostvar
    #     tags: this, that
    #     params:
    #       rolevar1: value1
    #
    # we'll test different role defs with this playbook

    ds = dict()

    # test 0: role with name,

# Generated at 2022-06-11 10:32:23.679608
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_name = '../test_role'
    role_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '../../test/test_role'))
    module_utils_path = os.path.join(role_path, 'module_utils')

    with AnsibleCollectionRef.temporary_collections_path([module_utils_path]):
        role = RoleDefinition.load(dict(name=role_name))

    assert role._role_path == role_path
    assert role.get_name() == 'test_role'
    assert role._role_collection is None

    # test preprocess_data with an invalid data structure
    try:
        RoleDefinition.load(42)
    except AnsibleAssertionError:
        pass
    else:
        raise Ass

# Generated at 2022-06-11 10:32:35.940332
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    import os

    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.set_inventory(loader.load_inventory(loader.load_from_file(os.path.join(os.path.dirname(__file__), 'hosts'))))
    variable_manager.set_extra_vars({'role_name': 'common'})
    variable_manager.add_nonpersistent_facts(variable_manager.get_vars())

    ds = AnsibleBaseYAMLObject()
    d

# Generated at 2022-06-11 10:32:44.463405
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    class FakeRoleDef(RoleDefinition):
        # A method to ensure attribute_name is filled with the right value
        def _load_role_name(self, ds):
            assert ds['attribute_name'] == 'attribute_value'
            return 'fake_role_name'

        # A method to ensure attribute_name is filled with the right value
        def _split_role_params(self, ds):
            assert ds['attribute_name'] == 'attribute_value'
            return (dict(role='fake_role_name'), dict())

    # Test a dict
    ds = dict(attribute_name='attribute_value')
    role_definition = FakeRoleDef()
    role_definition.preprocess_data(ds)

    # Test a string
    ds = 'fake_role_name'
    role_definition = FakeRole

# Generated at 2022-06-11 10:32:55.882271
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_definition1 = RoleDefinition(role_basedir='/path/to/dir/roles')
    role_definition2 = RoleDefinition(role_basedir='/path/to/dir/roles')

    role1 = role_definition1.preprocess_data('name')
    print('role: ', role1)
    assert 'role' in role1
    assert role1['role'] == 'name'

    role2 = role_definition2.preprocess_data(dict(role='name'))
    print('role: ', role2)
    assert 'role' in role2
    assert role2['role'] == 'name'

    role3 = role_definition1.preprocess_data(dict(name='name'))
    print('role: ', role3)
    assert 'role' in role3
    assert role3['role']

# Generated at 2022-06-11 10:33:07.040683
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    display.verbosity = 3
    # example 1: collection-based role
    rd = RoleDefinition()
    rd._role = "good"
    rd._role_collection = "netapp.awesome_collection"
    assert rd.get_name() == "netapp.awesome_collection.good"
    # example 2: legacy role
    rd = RoleDefinition()
    rd._role = "good"
    rd._role_collection = None
    assert rd.get_name() == "good"
    # example 3: no role, no collection
    rd = RoleDefinition()
    rd._role = None
    assert rd.get_name() is None
    # example 4: no name, collection
    rd = RoleDefinition()
    rd._role = None

# Generated at 2022-06-11 10:33:07.527076
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    pass

# Generated at 2022-06-11 10:33:12.440973
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():

    test_role = RoleDefinition()
    assert test_role.get_name() == '.'

    test_role.role = 'test_role'
    assert test_role.get_name() == 'test_role'

    test_role._role_collection = 'test_collection'
    assert test_role.get_name() == 'test_collection.test_role'

# Generated at 2022-06-11 10:33:23.663015
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():

    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    templar = Templar(loader=None, variables={})
    play_context = PlayContext()
    play_context._role_params = dict()
    play_context._variable_manager = dict()
    loader = 'loader'

    # test: role name is a string
    role_definition = RoleDefinition(play_context, loader=loader)
    role_name = 'testrole'
    result = role_definition.preprocess_data(role_name)
    assert result == role_name

    # test: role name is a dict
    role_definition = RoleDefinition(play_context, loader=loader)
    role_name = dict()
    result = role_definition.preprocess_data(role_name)
    assert not result

   

# Generated at 2022-06-11 10:33:37.812766
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():

    from units.mock.loader import DictDataLoader
    from ansible.vars.manager import VariableManager

    data = { 'role': 'foobar' }
    variable_manager = VariableManager()
    loader = DictDataLoader({})

    rd = RoleDefinition(play=None, role_basedir=None,
                        variable_manager=variable_manager,
                        loader=loader)

    ds = rd.preprocess_data(data)

    if 'role' in ds:
        assert ds['role'] == 'foobar'
    else:
        assert False

    data = 'foobar'
    rd = RoleDefinition(play=None, role_basedir=None,
                        variable_manager=variable_manager,
                        loader=loader)

    ds = rd.preprocess_data(data)

   

# Generated at 2022-06-11 10:33:49.950243
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.playbook.role import Role
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    # we need to fake some of the data the object uses
    play = {
        'connection': 'local',
        'hosts': 'all',
        'name': 'Test Play',
        'roles': [
            RoleDefinition.load(
                dict(
                    name='test_role',
                    role='/path/to/test/roles/test_role'
                ),
                variable_manager=VariableManager(),
                loader=AnsibleLoader
            ),
        ],
    }

    play_context = PlayContext()

    # create the objects using the fake data
    role_definition

# Generated at 2022-06-11 10:34:00.393660
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():

    # test function is good (multiple keys: 1 valid, 1 extra)
    test_data_dict = dict(role='test1', testkey='testval')
    test_role_basedir = 'testbasedir'
    test_variable_manager = None
    test_loader = None
    test_collection_list = []

    role_definition = RoleDefinition(None, test_role_basedir, test_variable_manager, test_loader, test_collection_list)
    assert isinstance(role_definition, RoleDefinition)

    r = role_definition.preprocess_data(test_data_dict)
    assert r.get('role') == 'test1'
    assert r.get('testkey') == 'testval'
    assert isinstance(r, AnsibleMapping)

# Generated at 2022-06-11 10:34:11.102541
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    """
    Test preprocess_data with various inputs.
    """
    from ansible.parsing.yaml.objects import AnsibleMapping

    def check_preprocess_data(role_name, expected_role_path, expected_role_name, expected_role_params):
        rd = RoleDefinition()
        ds = AnsibleMapping()
        ds['role'] = role_name
        result = rd.preprocess_data(ds)
        assert result.get('role') == expected_role_name
        assert rd._role_path == expected_role_path
        assert rd._role_params == expected_role_params

    check_preprocess_data('name_only_role', 'name_only_role', 'name_only_role', {})

# Generated at 2022-06-11 10:34:22.830954
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    play = dict(
        name='test play',
        hosts='localhost',
        gather_facts='no',
        roles=[
            dict(
                name='testrole',
                tags=['testrole', 'testrole1', 'testrole2']
            )
        ]
    )

    play_ds = RoleDefinition.load(play, variable_manager=VariableManager(), loader=None)

    host_list = [dict(name='localhost')]
    inventory = dict(
        hosts=host_list,
        host_list=host_list,
        groups=[dict(name='localhost', hosts=host_list)]
    )

    play_context = PlayContext(play=play_ds)

    var_manager = Variable

# Generated at 2022-06-11 10:34:31.866299
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.errors import AnsibleError

    rd = RoleDefinition()
    try:
        rd.preprocess_data(AnsibleSequence())
        assert(False)
    except AnsibleError:
        pass
    role_name, role_path = rd.preprocess_data('the-name')
    assert role_name == 'the-name'
    assert role_path is None
    role_name, role_path = rd.preprocess_data(AnsibleUnsafeText('the-name'))
    assert role_name == 'the-name'
    assert role_path is None


# Generated at 2022-06-11 10:34:43.615935
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():

    from ansible.plugins.loader import shared_loader_obj
    from ansible.utils.collection_loader._collection_finder import _get_collection_path


    # when loading from a collection, only the role name is supported (without release)
    # and that name must match the name of directory in the collection that contains the role
    ds1 = 'my-role'
    ds1_expected_name = 'my-role'
    ds1_expected_path = '/etc/ansible/collections/ansible_collections/test/test_collection/roles/my-role'
    collection = 'test.test_collection'

    # when loading from a collection, the role name can also be specified as an FQCN
    ds2 = 'test.test_collection.my-role'

# Generated at 2022-06-11 10:34:54.453749
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    from ansible.module_utils.six import PY2
    from ansible.loaders import DataLoader
    from ansible.vars import VariableManager

    role_definition = RoleDefinition(loader=DataLoader(),
                                     variable_manager=VariableManager())
    role_definition._role = 'role-name'
    role_definition._role_collection = 'namespace.collection.foo'

    # When python 2.7 and include_role_fqcn, we expect FQCN
    assert role_definition.get_name(include_role_fqcn=True) == 'namespace.collection.foo.role-name'

    # When python 2.7 and include_role_fqcn=False, we expect role name
    assert role_definition.get_name(include_role_fqcn=False) == 'role-name'

   

# Generated at 2022-06-11 10:35:04.814585
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    parameters = {
        'role': 'test_role',
        'collection': 'test_col',
    }
    rd = RoleDefinition(None, None, None, None, None)
    rd._role_collection = parameters.get('collection')
    for param in parameters:
        setattr(rd, str(param), parameters[param])
    assert rd.get_name(False) == 'test_role'
    assert rd.get_name(True) == 'test_col.test_role'
    parameters = {
        'role': 'test_role',
        'collection': '',
    }
    rd = RoleDefinition(None, None, None, None, None)
    rd._role_collection = parameters.get('collection')

# Generated at 2022-06-11 10:35:16.917270
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    '''
    RoleDefinition: get_name() should return the name of the role.
    '''

    # Setup
    class _FakeVariableManager():
        def get_vars(self, play=None):
            return dict()

    class _FakeLoader():
        def get_basedir(self):
            return u'.'
        def path_exists(self, role_path):
            return True

    variables = _FakeVariableManager()
    loader = _FakeLoader()
    fake_collection_list = ['collections.ns1.ns2.my_collection']
    my_role = RoleDefinition(variable_manager=variables, loader=loader, collection_list=fake_collection_list)
    my_role._role = u'name_of_role'

    # When

# Generated at 2022-06-11 10:35:36.108319
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():

    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.utils.display import Display
    from ansible.playbook.play import Play

    di = AnsibleMapping()
    di = {"name": "test_role", "meta": "meta_task"}

    display = Display()
    play = Play().load(di, variable_manager=None, loader=None)
    role = RoleDefinition(play=play, role_basedir=None, variable_manager=None, loader=None, collection_list=[])
    result = role.preprocess_data(di)

    assert result == {"role": "test_role", "meta": "meta_task"}

# Generated at 2022-06-11 10:35:45.587128
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    # Setup
    play = None
    role_basedir = None
    variable_manager = None
    loader = None
    collection_list = None
    role_definition = RoleDefinition(play, role_basedir, variable_manager, loader, collection_list)

    role_definition._role_collection = "no_collection"

    # Test
    actual = role_definition.get_name()
    expected = 'no_collection.role'

    # Verify
    assert actual == expected, \
        "Actual: " + actual + "\nExpected: " + expected

    # Test
    actual = role_definition.get_name(include_role_fqcn=False)
    expected = 'role'

    # Verify
    assert actual == expected, \
        "Actual: " + actual + "\nExpected: " + expected

# Generated at 2022-06-11 10:35:57.856962
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.plugins.action import ActionBase
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVars

    action = ActionBase()
    variable_manager = VariableManager(loader=action._loader)
    variable_manager.set_inventory(action.get_loader().inventory)

    role_name = 'test_role_name'
    role_name_dict = dict(role=role_name)
    role_no_name = dict(nope=role_name)


# Generated at 2022-06-11 10:35:58.722494
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    pass

# Generated at 2022-06-11 10:36:07.099614
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    # role_basedir is not used, so it may be None
    role_basedir = None
    # variable_manager is not used either
    variable_manager = None
    # loader is not used either
    loader = None
    # collection_list is not used either
    collection_list = None
    # create a role definition
    role = RoleDefinition(role_basedir=role_basedir, variable_manager=variable_manager, loader=loader, collection_list=collection_list)
    role.preprocess_data("my-role-name")
    assert role._role == 'my-role-name'

# Generated at 2022-06-11 10:36:12.087777
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_path = '/test/roles/'
    role_name = 'nginx'
    role_name_with_path = os.path.join(role_path, role_name)
    role_name_with_variable = '{{ role_name }}'
    role_name_with_variable_expected = "nginx"

    # Test case with no params
    ds = dict(
        name = role_name
    )
    rd = RoleDefinition(role_basedir=role_path)
    assert ds == rd.preprocess_data(ds)

    # Test case with role name as a string
    ds = role_name
    rd = RoleDefinition(role_basedir=role_path)
    assert {'role': role_name} == rd.preprocess_data(ds)

    # Test

# Generated at 2022-06-11 10:36:24.518853
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.playbook.role_includes import IncludeRole
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager

    from ansible.utils.vars import combine_vars

    loader = None
    variable_manager = VariableManager()

    ds = AnsibleMapping()
    ds['role'] = 'simple_role'
    ds['format'] = '{{ format }}'
    ds['role_parameter'] = '{{ role_parameter }}'

    play_context = PlayContext()

# Generated at 2022-06-11 10:36:34.904921
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    '''
    There are five groups of tests:
    1. Test for the cases for role name given as quoted string
    2. Test for the cases for role name given as unquoted string
    3. Test for the cases for role name given as string using variables
    4. Test for the cases for role name given as string with params
    5. Test for the cases for role name given as dict
    '''
    # tests 1
    role_def = RoleDefinition()
    role_def._load_role_path = lambda x: (x, 'roles/{}'.format(x))
    role_def._split_role_params = lambda x: (x, dict())

    # case 1-1: given quoted string should return unquoted value
    result = role_def.preprocess_data('"webserver"')

# Generated at 2022-06-11 10:36:42.423410
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.yaml.objects import AnsibleSequence

    display = Display()

    from ansible.parsing.yaml import objects
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.errors import AnsibleParserError
    from ansible.parsing.utils.addresses import parse_address
    from ansible.inventory import Inventory, Host, Group
    from ansible.vars.manager import VariableManager

    inventory = Inventory("")

    variable_manager = VariableManager()
    variable_manager.set_inventory(inventory)

    loader = AnsibleLoader

# Generated at 2022-06-11 10:36:52.168637
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    '''
    This function performs unit test for method preprocess_data of class RoleDefinition
    '''
    role_data = {
        'role': 'juniper.junos',
        'hosts': 'all',
        'connection': 'local',
        'gather_facts': False,
        'vars': {
            'ansible_network_os': 'junos',
        },
        'when': "'juniper' in inventory_hostname",
        'tasks': [
            {
                'import_tasks': 'show_version.yml',
                'when': "'junos' in ansible_network_os",
            }
        ],
    }
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook

# Generated at 2022-06-11 10:37:19.712772
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    # Test the get_name method of class RoleDefinition
    # Create a fake role name to be used by the test
    fake_role = 'fake_role'
    # Create a fake role collection fqcn to be used by the test
    fake_role_collection = 'fake_role_collection'
    # Create an instance of RoleDefinition with fake_role, no collection and
    # no variable manager
    fake_role_definition = RoleDefinition(role_basedir=None, variable_manager=None,
                                          loader=None, collection_list=None)
    # Set the fake role for the fake_role_definition
    fake_role_definition._role = fake_role
    # Execute the get_name method with a valid value for the include_role_fqcn

# Generated at 2022-06-11 10:37:29.156398
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.errors import AnsibleError
    from ansible.playbook import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.utils.collection_loader import AnsibleCollectionRef
    from ansible.utils.collection_loader._collection_finder import _get_collection_role_path
    from ansible.utils.vars import combine_vars

    class TestRoleDefinition(RoleDefinition):
        def __init__(self, *args, **kwargs):
            super(TestRoleDefinition, self).__init__(*args, **kwargs)

        def _split_role_params(self, ds):
            return (ds, {})

        def _load_role_path(self, role_name):
            return (role_name, role_name)


# Generated at 2022-06-11 10:37:39.545465
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager.set_inventory(inventory)

    play_source = dict(
        name="Ansible Play",
        hosts="localhost",
        gather_facts="no",
        tasks=[
            dict(name="Test role inclusion", include_role=dict(name='testrole', tasks_from='main'))
        ]
    )


# Generated at 2022-06-11 10:37:52.648875
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play

    play_source_file = './test_playbook.yml'

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager)
    variable_manager.set_inventory(inventory)
    play = Play.load(play_source_file, variable_manager=variable_manager, loader=loader)

    role_def = next(iter(play.roles))
    # we need to temporarily remove the role name, play, and variable_manager
    # attributes when calling preprocess_data so that it can be used
    # normally from within

# Generated at 2022-06-11 10:37:59.232348
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    variable_manager = VariableManager()
    loader = DataLoader()
    rd = RoleDefinition(variable_manager=variable_manager, loader=loader)
    rd.role = 'test'
    assert rd.get_name() == 'test'
    rd._role_collection = 'test_collection'
    assert rd.get_name() == 'test_collection.test'
    assert rd.get_name(include_role_fqcn=False) == 'test'

# Generated at 2022-06-11 10:38:09.825290
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role = RoleDefinition()

    # Defining role with role and when parameters
    assert role.preprocess_data({'role': 'foo', 'when': 'bar'}) == {'role': 'foo', 'when': 'bar'}

    # Defining role with name and when parameters
    assert role.preprocess_data({'name': 'foo', 'when': 'bar'}) == {'role': 'foo', 'when': 'bar'}

    # Defining role with name and when parameters, name wins
    assert role.preprocess_data({'name': 'foo', 'role': 'baz', 'when': 'bar'}) == {'role': 'foo', 'when': 'bar'}

    # Defining role with name and when parameters, role wins

# Generated at 2022-06-11 10:38:21.722769
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager

    # create a data structure
    ds = {
        'role': 'test_role_1',
        'role_name': 'test_role_2',
        'not_role_param': 'test_role_1',
        'roles': [ 'test_role_3' ],
        'foo': { 'bar': 'test_role_4' },
    }

    # create a play
    play = Play.load({
        'name': 'test_play',
        'hosts': 'all',
        'roles': [ ds ],
    }, variable_manager=VariableManager())

    # pre-process the data structure
    role = RoleDefinition.load(ds, play=play)
    role.preprocess_data

# Generated at 2022-06-11 10:38:31.831854
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    # Setup
    p = None
    rd = RoleDefinition(play=p)
    test_ds = dict()
    test_ds['role'] = 'myrole1'
    test_ds['tags'] = ['tag1','tag2']
    test_ds['when'] = 'ansible_os_family == "RedHat"'
    test_ds['become'] = False
    test_ds['become_method'] = 'su'
    test_ds['variable'] = 'test_value'

    # Test
    actual = rd.preprocess_data(test_ds)

    # Verify
    assert actual['role'] == 'myrole1'
    assert actual['tags'] == ['tag1','tag2']
    assert actual['when'] == 'ansible_os_family == "RedHat"'
    assert actual['become']

# Generated at 2022-06-11 10:38:36.274812
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():

    # Init data & variables
    ds = 123
    variable_manager = None
    loader = None
    collection_list = None
    rd = RoleDefinition(None, None, variable_manager, loader)

    # test all cases
    # wrong type of ds
    try:
        rd.preprocess_data(ds)
        raise AssertionError("preprocess_data() accept wrong type of ds.")
    except AnsibleAssertionError:
        pass

    ds = 'test_role'
    # correct type of ds
    result = rd.preprocess_data(ds)
    assert(isinstance(result, AnsibleMapping))
    assert(isinstance(result, AnsibleMapping))
    assert(result['role'] == 'test_role')
    # correct type of ds