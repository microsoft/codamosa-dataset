

# Generated at 2022-06-17 07:46:30.410510
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play = Play().load({}, variable_manager=variable_manager, loader=loader)

    role_definition = RoleDefinition(play=play, variable_manager=variable_manager, loader=loader)

    # Test with a string
    ds = 'test'
    result = role_definition.preprocess_data(ds)
    assert result == ds

    # Test with a dict
    ds = {'role': 'test'}
    result = role_definition.preprocess_data(ds)
    assert result == ds

    # Test with a dict and a variable

# Generated at 2022-06-17 07:46:37.423069
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-17 07:46:42.497633
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    role_definition = RoleDefinition()
    role_definition._role_collection = 'namespace.collection'
    role_definition._role = 'role'
    assert role_definition.get_name() == 'namespace.collection.role'
    assert role_definition.get_name(include_role_fqcn=False) == 'role'

# Generated at 2022-06-17 07:46:50.432735
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import UnsafeProxy

    # Create a mock PlayContext
    play_context = PlayContext()
    play_context._set_connection_info('local', 'local', 'local')

    # Create a mock HostVars
    host_vars = HostVars(play_context, 'localhost')

    # Create a mock VariableManager
    variable_manager = VariableManager()
    variable_manager._fact_cache = dict()
    variable_manager._vars_cache = dict()
    variable_manager

# Generated at 2022-06-17 07:46:55.937895
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = dict(
        foo='bar',
        baz='qux',
        ansible_connection='local',
        ansible_ssh_user='test',
        ansible_ssh_pass='test',
        ansible_sudo_pass='test',
    )
    play_context = PlayContext()
    play_context.network_os = 'default'
    variable_manager.set_play_context(play_context)

    # Test with a simple string
    role_def = RoleDefinition(variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-17 07:46:58.489211
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    role_definition = RoleDefinition()
    role_definition._role_collection = 'namespace.collection'
    role_definition._attributes['role'] = 'role_name'
    assert role_definition.get_name() == 'namespace.collection.role_name'
    assert role_definition.get_name(include_role_fqcn=False) == 'role_name'

# Generated at 2022-06-17 07:47:08.166170
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.template import Templar

    # Test 1: role definition as a string
    role_def = 'test_role'
    role_def_obj = RoleDefinition()
    role_def_obj.preprocess_data(role_def)
    assert role_def_obj.role == 'test_role'
    assert role_def_obj._role_path == 'test_role'
    assert role_def_obj._role_params == {}

    # Test 2: role definition as a dict with role name
    role_def = AnsibleMapping(ansible_pos=('test_role', 1, 1))
   

# Generated at 2022-06-17 07:47:20.371063
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.utils.path import unfrackpath
    from ansible.utils.collection_loader import AnsibleCollectionRef

    # Create a role definition
    role_def = RoleDefinition()

    # Create a variable manager


# Generated at 2022-06-17 07:47:28.928116
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.utils.collection_loader import AnsibleCollectionRef

    # Test case 1: role name is a string
    role_name = 'test_role'
    role_def = AnsibleMapping(role_name)
    role_def.ansible_pos = 'test_role_def'
    role_def_obj = RoleDefinition()
    role_def_obj.preprocess_data(role_def)
    assert role_def_obj._role_path == 'test_role'
    assert role_def_obj._role_params == {}

    # Test case 2: role name is a dict
    role_name = 'test_role'
    role_def = Ansible

# Generated at 2022-06-17 07:47:38.997448
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-17 07:47:55.326087
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task

    loader = AnsibleLoader(None, None)
    variable_manager = VariableManager()
    play = Play().load(dict(
        name="Ansible Play",
        hosts=['all'],
        gather_facts='no',
        tasks=[
            dict(action=dict(module='shell', args='ls'), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
        ]
    ), variable_manager=variable_manager, loader=loader)


# Generated at 2022-06-17 07:48:00.655578
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    role_name = 'test_role'
    role_path = 'test_role_path'
    role_params = dict(a=1, b=2)
    role_def = dict(role=role_name, **role_params)
    role_def_yaml = AnsibleMapping(role_def)

    # Create a loader to load the role definition
    loader = AnsibleLoader(role_def_yaml, '<string>')

    # Create a variable manager to template the role name
    variable_manager = VariableManager()

# Generated at 2022-06-17 07:48:13.015050
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    play_context._variable_manager = variable_manager

    role_definition = RoleDefinition(play=play_context, variable_manager=variable_manager, loader=loader)

    # Test case 1: role name is a string
    role_name = 'test_role'
    role_definition.preprocess_data(role_name)

# Generated at 2022-06-17 07:48:25.991283
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager.set_inventory(inventory)

    play_context = PlayContext()
    play_context.network_os = 'ios'
    play_context.become = True
    play_context.become_method = 'enable'
    play_context.become_user = 'test'
    play_context.remote_

# Generated at 2022-06-17 07:48:38.317511
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_source = dict(
        name="Ansible Play",
        hosts='localhost',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='debug', args=dict(msg='{{ role_name }}')))
        ]
    )

# Generated at 2022-06-17 07:48:50.236740
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.utils.vars import combine_vars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.become import Become
    from ansible.playbook.connection import Connection

# Generated at 2022-06-17 07:48:56.676453
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    role_definition = RoleDefinition()
    role_definition._role_collection = 'test_collection'
    role_definition._attributes['role'] = 'test_role'
    assert role_definition.get_name() == 'test_collection.test_role'
    assert role_definition.get_name(include_role_fqcn=False) == 'test_role'

# Generated at 2022-06-17 07:49:01.290453
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    role_definition = RoleDefinition()
    role_definition.role = 'test_role'
    assert role_definition.get_name() == 'test_role'
    role_definition._role_collection = 'test_collection'
    assert role_definition.get_name() == 'test_collection.test_role'
    assert role_definition.get_name(include_role_fqcn=False) == 'test_role'

# Generated at 2022-06-17 07:49:11.616865
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars.manager import VariableManager


# Generated at 2022-06-17 07:49:21.816652
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager


# Generated at 2022-06-17 07:49:37.282026
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import shell_loader
    from ansible.plugins.loader import strategy_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import test_loader

# Generated at 2022-06-17 07:49:45.909822
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.utils.vars import combine_vars
    from ansible.vars.manager import VariableManager

    # create a role definition with a role name
    role_def = AnsibleMapping()
    role_def['role'] = 'test_role'

    # create a variable manager
    variable_manager = VariableManager()
    variable_manager.extra_vars = combine_vars(loader=None, variables=dict(test_var='test_value'))

    # create a role definition object
    role_def_obj = RoleDefinition(variable_manager=variable_manager)

    # preprocess the role definition

# Generated at 2022-06-17 07:50:00.952113
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader, lookup_loader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_

# Generated at 2022-06-17 07:50:14.724586
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.taggable import Taggable
    from ansible.playbook.attribute import Attribute

# Generated at 2022-06-17 07:50:29.509109
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import strategy_loader
    from ansible.plugins.loader import test_loader
    from ansible.plugins.loader import vars_loader

# Generated at 2022-06-17 07:50:35.257759
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    role_definition = RoleDefinition()
    role_definition._role_collection = 'test_collection'
    role_definition.role = 'test_role'
    assert role_definition.get_name() == 'test_collection.test_role'
    assert role_definition.get_name(include_role_fqcn=False) == 'test_role'

# Generated at 2022-06-17 07:50:43.314463
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    # Create a play
    play = Play()

    # Create a role
    role = Role()

    # Create a role include
    role_include = RoleInclude()

    # Create a variable manager
    variable_manager = VariableManager()

    # Create a loader
    loader = DataLoader()



# Generated at 2022-06-17 07:50:52.574144
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-17 07:50:59.150559
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    # Test with a simple string
    rd = RoleDefinition()
    ds = rd.preprocess_data('test_role')
    assert ds['role'] == 'test_role'

    # Test with a dict
    rd = RoleDefinition()
    ds = rd.preprocess_data({'role': 'test_role'})
    assert ds['role'] == 'test_role'

    # Test with a dict containing a role param
    rd = RoleDefinition()
    ds = rd.preprocess_data({'role': 'test_role', 'role_param': 'test_value'})
    assert ds['role'] == 'test_role'
    assert rd._role_params['role_param'] == 'test_value'

    # Test with a dict containing a field attribute
    rd = Role

# Generated at 2022-06-17 07:51:08.248052
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    # Test with a simple string
    rd = RoleDefinition()
    ds = rd.preprocess_data('test')
    assert ds == {'role': 'test'}

    # Test with a dict
    rd = RoleDefinition()
    ds = rd.preprocess_data({'role': 'test'})
    assert ds == {'role': 'test'}

    # Test with a dict with extra params
    rd = RoleDefinition()
    ds = rd.preprocess_data({'role': 'test', 'param1': 'value1'})
    assert ds == {'role': 'test'}
    assert rd._role_params == {'param1': 'value1'}

    # Test with a dict with extra params and a name
    rd = RoleDefinition()

# Generated at 2022-06-17 07:51:27.562395
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.hostvars import HostVarsVarsVars
    from ansible.vars.hostvars import HostVarsVarsVarsVars
    from ansible.vars.hostvars import HostVarsVarsVarsVarsVars
    from ansible.vars.hostvars import HostVarsVarsVarsVarsVarsVars


# Generated at 2022-06-17 07:51:38.489872
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.requiremenets import RoleRequirement
    from ansible.playbook.become import Become
    from ansible.playbook.connection import Connection
    from ansible.playbook.vars.hostvars import HostVars
    from ansible.playbook.vars.taskvars import TaskVars
    from ansible.playbook.vars.filevars import FileVars
    from ansible.playbook.vars.groupvars import GroupVars

# Generated at 2022-06-17 07:51:45.655830
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import cache_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import strategy_loader

# Generated at 2022-06-17 07:51:55.065540
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.utils.collection_loader import AnsibleCollectionRef

    # Test with a role name
    role_def = RoleDefinition()
    role_def.preprocess_data('role_name')
    assert role_def._ds == 'role_name'
    assert role_def._role_path == 'role_name'
    assert role_def._role_params == {}
    assert role_def.role == 'role_name'

    # Test with a role name and a role path
    role_def = RoleDefinition()

# Generated at 2022-06-17 07:52:00.512367
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    role_definition = RoleDefinition()
    role_definition._role_collection = 'collection'
    role_definition._attributes['role'] = 'role'
    assert role_definition.get_name() == 'collection.role'
    assert role_definition.get_name(include_role_fqcn=False) == 'role'
    role_definition._role_collection = None
    assert role_definition.get_name() == 'role'
    assert role_definition.get_name(include_role_fqcn=False) == 'role'

# Generated at 2022-06-17 07:52:10.978383
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    # Test with include_role_fqcn=True
    role_definition = RoleDefinition()
    role_definition._role_collection = 'namespace.collection'
    role_definition._attributes['role'] = 'role_name'
    assert role_definition.get_name(include_role_fqcn=True) == 'namespace.collection.role_name'

    # Test with include_role_fqcn=False
    role_definition = RoleDefinition()
    role_definition._role_collection = 'namespace.collection'
    role_definition._attributes['role'] = 'role_name'
    assert role_definition.get_name(include_role_fqcn=False) == 'role_name'

# Generated at 2022-06-17 07:52:22.753634
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    role_def = RoleDefinition()
    role_def._role_collection = 'test_collection'
    role_def._attributes['role'] = 'test_role'
    assert role_def.get_name() == 'test_collection.test_role'
    assert role_def.get_name(include_role_fqcn=False) == 'test_role'
    role_def._role_collection = None
    assert role_def.get_name() == 'test_role'
    role_def._role_collection = 'test_collection'
    role_def._attributes['role'] = None
    assert role_def.get_name() == 'test_collection'
    role_def._role_collection = None
    assert role_def.get_name() == ''

# Generated at 2022-06-17 07:52:32.828063
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.hostvars import HostVarsVarsVars
    from ansible.vars.hostvars import HostVarsVarsVarsVars
    from ansible.vars.hostvars import HostVarsVarsVarsVarsVars
    from ansible.vars.hostvars import HostVarsVarsVarsVarsVarsVars


# Generated at 2022-06-17 07:52:38.196260
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    role_definition = RoleDefinition()
    role_definition._role_collection = 'my_collection'
    role_definition._role = 'my_role'
    assert role_definition.get_name() == 'my_collection.my_role'
    assert role_definition.get_name(include_role_fqcn=False) == 'my_role'

# Generated at 2022-06-17 07:52:48.087198
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    role_definition = RoleDefinition()
    role_definition._role_collection = 'namespace.collection'
    role_definition._role = 'role'
    assert role_definition.get_name() == 'namespace.collection.role'
    assert role_definition.get_name(include_role_fqcn=False) == 'role'
    role_definition._role_collection = None
    assert role_definition.get_name() == 'role'
    assert role_definition.get_name(include_role_fqcn=False) == 'role'
    role_definition._role_collection = 'namespace.collection'
    role_definition._role = None
    assert role_definition.get_name() == 'namespace.collection'
    assert role_definition.get_name(include_role_fqcn=False) == ''
   

# Generated at 2022-06-17 07:53:02.098527
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader, connection_loader, lookup_loader, callback_loader
    from ansible.plugins.callback import CallbackBase
    from ansible.utils.path import unfrackpath
    import os
    import sys
    import yaml
    import json

    # Create a dummy callback plugin

# Generated at 2022-06-17 07:53:12.670150
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-17 07:53:24.571972
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

# Generated at 2022-06-17 07:53:36.009540
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()
    play_context.network_os = 'ios'
    play = Play().load({}, variable_manager=variable_manager, loader=loader, play_context=play_context)

    role_definition = RoleDefinition(play=play, variable_manager=variable_manager, loader=loader)

    # test with a simple string
    ds = 'test'
    new_ds = role_definition.preprocess_data(ds)
    assert new_ds == {'role': 'test'}

    #

# Generated at 2022-06-17 07:53:43.483983
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    play_context.network_os = 'ios'
    play_context.become = True
    play_context.become_method = 'enable'
    play_context.become_user = 'test_user'
    variable_manager.set_play_context(play_context)

    role_def = RoleDefinition(variable_manager=variable_manager, loader=loader)
    role

# Generated at 2022-06-17 07:53:50.991280
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    variable_manager.set_play_context(play_context)

    role_definition = RoleDefinition(variable_manager=variable_manager, loader=loader)

    # Test with a string
    ds = 'role_name'
    new_ds = role_definition.preprocess_data(ds)
    assert new_ds == {'role': 'role_name'}



# Generated at 2022-06-17 07:54:02.997181
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader, lookup_loader
    from ansible.plugins.callback import CallbackBase
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement

# Generated at 2022-06-17 07:54:12.362469
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars

    loader = AnsibleLoader(None, None)
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=[])
    play_context = PlayContext()
    variable_manager.set_inventory(inventory)

    # test role definition with role name
    role_def = RoleDefinition(variable_manager=variable_manager, loader=loader)
    role_def.preprocess_data({'role': 'test_role'})
    assert role_def._role_path == 'test_role'
    assert role_

# Generated at 2022-06-17 07:54:16.738229
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    role_definition = RoleDefinition()
    role_definition._role_collection = 'namespace.collection'
    role_definition.role = 'role'
    assert role_definition.get_name() == 'namespace.collection.role'
    assert role_definition.get_name(include_role_fqcn=False) == 'role'

# Generated at 2022-06-17 07:54:24.684954
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

# Generated at 2022-06-17 07:54:42.657188
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.playbook.role.definition import RoleDefinition

    # Test with a dict
    ds = AnsibleMapping()
    ds['role'] = 'test_role'
    ds['tags'] = ['tag1', 'tag2']
    ds['when'] = 'when_condition'
    ds['become'] = True
    ds['become_user'] = 'root'
    ds['become_method'] = 'sudo'
    ds['become_flags'] = '-H'
    ds['become_ask_pass'] = True

# Generated at 2022-06-17 07:54:55.873508
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Create a role definition
    role_def = RoleDefinition()

    # Create a variable manager
    variable_manager = VariableManager()
    variable_manager.set_nonpersistent_facts(dict(foo='bar'))

    # Create a templar
    templar = Templar(loader=None, variables=variable_manager.get_vars(play=None))

    # Create a play context
    play_context = PlayContext()

    # Create a role definition data structure
    ds = AnsibleMapping()
    ds.ansible_pos = (1, 1, 1)
    ds

# Generated at 2022-06-17 07:55:07.855633
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory'])
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-17 07:55:19.042630
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.plugins.loader import action_loader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    play_context.network_os = 'ios'
    play_context.remote_addr = '127.0.0.1'
    play_context.port = 22
    play_context.remote_user = 'vagrant'

# Generated at 2022-06-17 07:55:29.295250
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    play_source = dict(
        name="Ansible Play",
        hosts='localhost',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='setup', args=dict()))
        ]
    )


# Generated at 2022-06-17 07:55:39.062872
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()
    variable_manager.set_play_context(play_context)

    role_def = RoleDefinition(variable_manager=variable_manager, loader=loader)

    # test role name
    ds = dict(role='test_role')
    new_ds = role_def.preprocess_data(ds)
    assert new_ds['role'] == 'test_role'

    # test role name with path
    ds = dict(role='/path/to/test_role')

# Generated at 2022-06-17 07:55:50.469566
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.unsafe_proxy import wrap_var

    # Create a role definition
    role_def = RoleDefinition()

    # Create a variable manager
    variable_manager = VariableManager()
    variable_manager.set_inventory(HostVars(dict(), wrap_var))

    # Create a play context
    play_context = PlayContext()

    # Create a templar
   

# Generated at 2022-06-17 07:56:00.284848
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.utils.collection_loader import AnsibleCollectionRef

    # Test case 1: role_name is a string
    role_name = 'test_role'
    role_def = AnsibleMapping(role_name)
    role_def.ansible_pos = (1, 1, 1)
    role_def = RoleDefinition(role_basedir='/tmp/roles', collection_list=['ansible.builtin'])
    role_def.preprocess_data(role_def)
    assert role_def._role_path == '/tmp/roles/test_role'
    assert role_def._role_collection is None
    assert role_def._role_params

# Generated at 2022-06-17 07:56:13.663905
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()
    play_context.network_os = 'ios'
    variable_manager.set_play_context(play_context)

    # Test with a simple string
    role_definition = RoleDefinition(variable_manager=variable_manager, loader=loader)
    role_definition.preprocess_data('test_role')
    assert role_definition._role_path == 'test_role'
    assert role_definition.role == 'test_role'

    # Test with a dict