

# Generated at 2022-06-17 07:46:28.763809
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    role_def = RoleDefinition()
    role_def._role_collection = 'namespace.collection'
    role_def.role = 'role_name'
    assert role_def.get_name() == 'namespace.collection.role_name'
    assert role_def.get_name(include_role_fqcn=False) == 'role_name'
    role_def._role_collection = None
    assert role_def.get_name() == 'role_name'
    assert role_def.get_name(include_role_fqcn=False) == 'role_name'
    role_def._role_collection = 'namespace.collection'
    role_def.role = None
    assert role_def.get_name() == 'namespace.collection'

# Generated at 2022-06-17 07:46:34.433487
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    # Create a role definition
    role_def = AnsibleMapping()
    role_def['role'] = 'test_role'
    role_def['tags'] = ['tag1', 'tag2']
    role_def['when'] = 'ansible_os_family == "RedHat"'
    role_def['become'] = True
    role_def['become_user'] = 'root'
    role_def['become_method'] = 'sudo'

# Generated at 2022-06-17 07:46:45.697972
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition

    loader = AnsibleLoader(None, None)
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    play_context.network_os = 'ios'

# Generated at 2022-06-17 07:47:00.855570
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition

    # Create a loader
    loader = AnsibleLoader(None, None)

    # Create a variable manager
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'foo': 'bar'}

    # Create an inventory manager
    inventory_manager = InventoryManager(loader=loader, sources='localhost,')

    # Create a play
    play

# Generated at 2022-06-17 07:47:10.750500
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    # Test with a simple string
    role_def = RoleDefinition()
    role_def.preprocess_data('test_role')
    assert role_def._role_path == 'test_role'
    assert role_def._role_params == {}

    # Test with a dict
    role_def = RoleDefinition()
    role_def.preprocess_data({'role': 'test_role'})
    assert role_def._role_path == 'test_role'
    assert role_def._role_params == {}

    # Test with a dict with extra params
    role_def = RoleDefinition()
    role_def.preprocess_data({'role': 'test_role', 'param1': 'value1', 'param2': 'value2'})
    assert role_def._role_path == 'test_role'
    assert role_

# Generated at 2022-06-17 07:47:17.013916
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase

    class ResultCallback(CallbackBase):
        """A sample callback plugin used for performing an action as results come in

        If you want to collect all results into a single object for processing at
        the end of the execution, look into utilizing the ``json`` callback plugin
        or writing your own custom callback plugin
        """

# Generated at 2022-06-17 07:47:25.499377
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar

    # Create a role definition
    role_def = RoleDefinition()

    # Create a variable manager
    variable_manager = Variable

# Generated at 2022-06-17 07:47:34.200398
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    # Test case 1:
    #   - role_collection is None
    #   - role is 'test_role'
    #   - include_role_fqcn is True
    # Expected result:
    #   - 'test_role'
    role_collection = None
    role = 'test_role'
    include_role_fqcn = True
    role_definition = RoleDefinition()
    role_definition._role_collection = role_collection
    role_definition.role = role
    assert role_definition.get_name(include_role_fqcn) == 'test_role'

    # Test case 2:
    #   - role_collection is 'test_collection'
    #   - role is 'test_role'
    #   - include_role_fqcn is True
    # Expected result:
    #

# Generated at 2022-06-17 07:47:41.784565
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader

    # Test for role definition with role name
    role_name = 'test_role'
    role_def = AnsibleMapping()
    role_def['role'] = role_name
    role_def['test_key'] = 'test_value'
    role_def['test_key2'] = 'test_value2'
    role_def['test_key3'] = 'test_value3'
    role_def['test_key4'] = 'test_value4'
    role_def['test_key5'] = 'test_value5'
    role_def['test_key6'] = 'test_value6'

# Generated at 2022-06-17 07:47:52.585106
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars_files
    from ansible.utils.vars import load_

# Generated at 2022-06-17 07:48:11.999926
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-17 07:48:25.261145
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import strategy_loader
    from ansible.plugins.loader import test_loader
    from ansible.plugins.loader import vars_loader

# Generated at 2022-06-17 07:48:32.192037
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play = Play().load({}, variable_manager=variable_manager, loader=loader)
    task = Task()
    task._role = RoleDefinition(play=play, variable_manager=variable_manager, loader=loader)
    task._role.preprocess_data({'role': 'test_role'})
    assert task._role.role == 'test_role'
    assert task._role._role_path == 'test_role'
    assert task._role._role_params == {}


# Generated at 2022-06-17 07:48:42.241719
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    # Test with a simple string
    role_def = RoleDefinition()
    ds = 'role_name'
    new_ds = role_def.preprocess_data(ds)
    assert new_ds['role'] == 'role_name'
    assert role_def._role_path == 'role_name'

    # Test with a dict
    role_def = RoleDefinition()
    ds = {'role': 'role_name'}
    new_ds = role_def.preprocess_data(ds)
    assert new_ds['role'] == 'role_name'
    assert role_def._role_path == 'role_name'

    # Test with a dict and params
    role_def = RoleDefinition()
    ds = {'role': 'role_name', 'param1': 'value1'}
    new_ds

# Generated at 2022-06-17 07:48:50.742036
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    role_definition = RoleDefinition()
    role_definition._role_collection = 'namespace.collection'
    role_definition._role = 'role'
    assert role_definition.get_name() == 'namespace.collection.role'
    assert role_definition.get_name(include_role_fqcn=False) == 'role'
    role_definition._role_collection = None
    assert role_definition.get_name() == 'role'
    assert role_definition.get_name(include_role_fqcn=False) == 'role'

# Generated at 2022-06-17 07:48:57.482628
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    # Test with a simple string
    role_def = RoleDefinition()
    role_name = 'test_role'
    role_path = '/path/to/test_role'
    role_def._load_role_path = lambda x: (x, role_path)
    role_def._split_role_params = lambda x: (x, dict())
    role_def._ds = role_name
    role_def.preprocess_data(role_name)
    assert role_def._role_path == role_path
    assert role_def._role_params == dict()
    assert role_def._ds == role_name

    # Test with a dict
    role_def = RoleDefinition()
    role_name = 'test_role'
    role_path = '/path/to/test_role'
    role_def._load_

# Generated at 2022-06-17 07:49:04.798483
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role_include import RoleInclude

    # Create a loader for loading data from a string
    loader = AnsibleLoader(None, None)

    # Create a dumper for dumping data to a string
    dumper = AnsibleDumper()

    # Create a variable manager

# Generated at 2022-06-17 07:49:13.822118
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    def test_get_name(role_name, collection_name, include_role_fqcn, expected_result):
        role_definition = RoleDefinition()
        role_definition._role_collection = collection_name
        role_definition._attributes['role'] = role_name
        assert role_definition.get_name(include_role_fqcn) == expected_result

    test_get_name('role_name', 'collection_name', True, 'collection_name.role_name')
    test_get_name('role_name', 'collection_name', False, 'role_name')
    test_get_name('role_name', None, True, 'role_name')
    test_get_name('role_name', None, False, 'role_name')

# Generated at 2022-06-17 07:49:23.109094
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    rd = RoleDefinition()
    rd._role_collection = 'my_collection'
    rd._attributes['role'] = 'my_role'
    assert rd.get_name() == 'my_collection.my_role'
    assert rd.get_name(include_role_fqcn=False) == 'my_role'
    rd._role_collection = None
    assert rd.get_name() == 'my_role'
    assert rd.get_name(include_role_fqcn=False) == 'my_role'
    rd._role_collection = 'my_collection'
    rd._attributes['role'] = None
    assert rd.get_name() == 'my_collection'
    assert rd.get_name(include_role_fqcn=False) == ''

# Generated at 2022-06-17 07:49:34.584492
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role.definition import RoleDefinition

    loader = AnsibleLoader(None, None)
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])

# Generated at 2022-06-17 07:49:52.022150
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition

    loader = AnsibleLoader(None, None)
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])

# Generated at 2022-06-17 07:50:03.356343
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    role_def = RoleDefinition()
    role_def._role_collection = 'test_collection'
    role_def.role = 'test_role'
    assert role_def.get_name() == 'test_collection.test_role'
    assert role_def.get_name(include_role_fqcn=False) == 'test_role'
    role_def._role_collection = None
    assert role_def.get_name() == 'test_role'
    assert role_def.get_name(include_role_fqcn=False) == 'test_role'
    role_def._role_collection = 'test_collection'
    role_def.role = None
    assert role_def.get_name() == 'test_collection'

# Generated at 2022-06-17 07:50:15.483397
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()
    play_context.network_os = 'ios'
    variable_manager.set_play_context(play_context)

    # test role definition with role name
    role_def = RoleDefinition()
    role_def.preprocess_data({'role': 'test_role'})
    assert role_def.role == 'test_role'

    # test role definition with role name and role params
    role_def = RoleDefinition()

# Generated at 2022-06-17 07:50:29.956480
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-17 07:50:38.918856
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    role_definition = RoleDefinition()
    role_definition.role = 'test_role'
    assert role_definition.get_name() == 'test_role'
    role_definition._role_collection = 'test_collection'
    assert role_definition.get_name() == 'test_collection.test_role'
    assert role_definition.get_name(include_role_fqcn=False) == 'test_role'

# Generated at 2022-06-17 07:50:52.031940
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-17 07:51:01.824123
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    # Test with include_role_fqcn=True
    role_definition = RoleDefinition()
    role_definition._role_collection = 'namespace.collection'
    role_definition._attributes['role'] = 'role'
    assert role_definition.get_name(include_role_fqcn=True) == 'namespace.collection.role'

    # Test with include_role_fqcn=False
    role_definition = RoleDefinition()
    role_definition._role_collection = 'namespace.collection'
    role_definition._attributes['role'] = 'role'
    assert role_definition.get_name(include_role_fqcn=False) == 'role'

# Generated at 2022-06-17 07:51:13.029783
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    role_definition = RoleDefinition()
    role_definition._role_collection = 'namespace.collection'
    role_definition._attributes['role'] = 'role_name'
    assert role_definition.get_name() == 'namespace.collection.role_name'
    assert role_definition.get_name(include_role_fqcn=False) == 'role_name'
    role_definition._role_collection = None
    assert role_definition.get_name() == 'role_name'
    role_definition._role_collection = 'namespace.collection'
    role_definition._attributes['role'] = None
    assert role_definition.get_name() == 'namespace.collection'
    role_definition._role_collection = None
    assert role_definition.get_name() == ''

# Generated at 2022-06-17 07:51:24.391273
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-17 07:51:30.564511
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    role_definition = RoleDefinition()
    role_definition.role = 'test_role'
    assert role_definition.get_name() == 'test_role'

    role_definition._role_collection = 'test_collection'
    assert role_definition.get_name() == 'test_collection.test_role'

# Generated at 2022-06-17 07:51:55.171263
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy

    # Create a role definition
    role_def = RoleDefinition()

    # Create a variable manager
    variable_manager = VariableManager()
    variable_manager.set_nonpersistent_facts(dict(foo='bar'))

    # Create a templar
    templar = Templar(loader=None, variables=variable_manager.get_vars(loader=None, play=None))

    # Create a role definition with a role name
    ds = AnsibleMapping()
    ds['role'] = 'test'
    role

# Generated at 2022-06-17 07:52:03.025836
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Test case 1: role definition is a string
    role_def = 'test_role'
    role_def_obj = RoleDefinition()
    role_def_obj.preprocess_data(role_def)
    assert role_def_obj._role_path == 'test_role'
    assert role_def_obj._role_params == {}

    # Test case 2: role definition is a dict
    role_def = Ans

# Generated at 2022-06-17 07:52:08.544852
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    role_definition = RoleDefinition()
    role_definition._role_collection = 'namespace.collection'
    role_definition._attributes['role'] = 'role_name'
    assert role_definition.get_name() == 'namespace.collection.role_name'
    assert role_definition.get_name(include_role_fqcn=False) == 'role_name'

# Generated at 2022-06-17 07:52:17.307187
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.utils.collection_loader import AnsibleCollectionRef
    from ansible.utils.collection_loader._collection_finder import _get_collection_role_path

    # Test with a simple role name
    role_name = 'test_role'
    role_def = AnsibleMapping()
    role_def['role'] = role_name
    role_def = RoleDefinition.preprocess_data(role_def)
    assert role_def['role'] == role_name

    # Test with a role name that contains a variable
    role_name = '{{ test_var }}'
    role_

# Generated at 2022-06-17 07:52:29.970222
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    play_source = dict(
        name="Ansible Play",
        hosts='localhost',
        gather_facts='no',
        roles=[
            dict(
                role='test_role',
                role_params=dict(
                    param1='value1',
                    param2='value2',
                )
            )
        ]
    )

    play = Play().load

# Generated at 2022-06-17 07:52:36.249182
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-17 07:52:46.373869
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play = Play.load(dict(
        name="Ansible Play",
        hosts=['all'],
        gather_facts='no',
        roles=[
            dict(
                role='common',
                some_parameter='some_value',
                some_other_parameter='some_other_value',
            ),
        ],
    ), loader=loader, variable_manager=variable_manager)

    role_def = RoleDefinition(play=play, role_basedir=None, variable_manager=variable_manager, loader=loader)
   

# Generated at 2022-06-17 07:52:52.841851
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()
    play_context.network_os = 'ios'
    variable_manager.set_play_context(play_context)

    rd = RoleDefinition(play=None, role_basedir=None, variable_manager=variable_manager, loader=loader)

    # Test with a simple string
    ds = 'test'
    new_ds = rd.preprocess_data(ds)
    assert new_ds == ds

    # Test with a dict
    ds = {'role': 'test'}

# Generated at 2022-06-17 07:53:02.166044
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    role_def = RoleDefinition()

# Generated at 2022-06-17 07:53:08.277127
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    role_def = RoleDefinition()
    role_def._role_collection = 'namespace.collection'
    role_def._role = 'role'
    assert role_def.get_name() == 'namespace.collection.role'
    assert role_def.get_name(include_role_fqcn=False) == 'role'
    role_def._role_collection = None
    assert role_def.get_name() == 'role'
    assert role_def.get_name(include_role_fqcn=False) == 'role'

# Generated at 2022-06-17 07:53:35.513634
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    rd = RoleDefinition()
    rd._role_collection = 'namespace.collection'
    rd.role = 'role'
    assert rd.get_name() == 'namespace.collection.role'
    assert rd.get_name(include_role_fqcn=False) == 'role'

    rd = RoleDefinition()
    rd._role_collection = 'namespace.collection'
    rd.role = None
    assert rd.get_name() == 'namespace.collection'
    assert rd.get_name(include_role_fqcn=False) == ''

    rd = RoleDefinition()
    rd._role_collection = None
    rd.role = 'role'
    assert rd.get_name() == 'role'

# Generated at 2022-06-17 07:53:42.868691
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    role_def = RoleDefinition()
    role_def._role_collection = 'namespace.collection'
    role_def._attributes['role'] = 'role_name'
    assert role_def.get_name() == 'namespace.collection.role_name'
    assert role_def.get_name(include_role_fqcn=False) == 'role_name'
    role_def._role_collection = None
    assert role_def.get_name() == 'role_name'
    assert role_def.get_name(include_role_fqcn=False) == 'role_name'

# Generated at 2022-06-17 07:53:49.827345
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    role_definition = RoleDefinition()
    role_definition.role = 'test_role'
    assert role_definition.get_name() == 'test_role'
    role_definition._role_collection = 'test_collection'
    assert role_definition.get_name() == 'test_collection.test_role'
    assert role_definition.get_name(include_role_fqcn=False) == 'test_role'

# Generated at 2022-06-17 07:53:59.207246
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.play_context import PlayContext

    loader = AnsibleLoader(None, None)
    variable_manager = VariableManager()

# Generated at 2022-06-17 07:54:07.812940
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    # Test with a simple string
    role_def = RoleDefinition()
    ds = 'test_role'
    new_ds = role_def.preprocess_data(ds)
    assert new_ds == {'role': 'test_role'}

    # Test with a dict
    role_def = RoleDefinition()
    ds = {'role': 'test_role'}
    new_ds = role_def.preprocess_data(ds)
    assert new_ds == {'role': 'test_role'}

    # Test with a dict and extra params
    role_def = RoleDefinition()
    ds = {'role': 'test_role', 'extra_param': 'extra_value'}
    new_ds = role_def.preprocess_data(ds)

# Generated at 2022-06-17 07:54:18.509086
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import strategy_loader
    from ansible.plugins.loader import test_loader

# Generated at 2022-06-17 07:54:30.177960
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    play_source =  dict(
            name = "Ansible Play",
            hosts = 'localhost',
            gather_facts = 'no',
            tasks = [
                dict(action=dict(module='setup', args='')),
            ]
        )

# Generated at 2022-06-17 07:54:38.006120
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy

    # Create a role definition with a role name
    role_def = RoleDefinition()
    role_def._loader = None
    role_def._play = None
    role_def._variable_manager = VariableManager()
    role_def._role_basedir = None
    role_def._collection_list = None

    # Create a role definition with a role name
    ds = AnsibleMapping()
    ds['role'] = 'test_role'
    ds['tags'] = ['test_tag']

# Generated at 2022-06-17 07:54:45.136182
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    role_definition = RoleDefinition()
    role_definition._role_collection = 'namespace.collection'
    role_definition._attributes['role'] = 'role_name'
    assert role_definition.get_name() == 'namespace.collection.role_name'
    assert role_definition.get_name(include_role_fqcn=False) == 'role_name'
    role_definition._role_collection = None
    assert role_definition.get_name() == 'role_name'
    assert role_definition.get_name(include_role_fqcn=False) == 'role_name'
    role_definition._role_collection = 'namespace.collection'
    role_definition._attributes['role'] = None
    assert role_definition.get_name() == 'namespace.collection'

# Generated at 2022-06-17 07:54:54.308500
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    role_definition = RoleDefinition()
    role_definition._role_collection = 'namespace.collection'
    role_definition._role = 'role'
    assert role_definition.get_name() == 'namespace.collection.role'
    assert role_definition.get_name(include_role_fqcn=False) == 'role'
    role_definition._role_collection = None
    assert role_definition.get_name() == 'role'
    assert role_definition.get_name(include_role_fqcn=False) == 'role'

# Generated at 2022-06-17 07:55:35.791206
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

    # test role name as a string
    role_def = RoleDefinition(variable_manager=variable_manager, loader=loader)
    role_def.preprocess_data('test_role')
    assert role_def._role_path == 'test_role'

    # test role name as a dict
    role_def = RoleDefinition(variable_manager=variable_manager, loader=loader)
   

# Generated at 2022-06-17 07:55:46.589335
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars
    from ansible.utils.collection_loader import AnsibleCollectionRef

    # Create a role definition with a role name
    role_def = RoleDefinition()
    role_def.role = 'test_role'
    role_def.post_validate(templar=None)

    # Create a role definition with a role name and a role path
    role_def = RoleDefinition()
    role_def.role = 'test_role'
    role_def.role_

# Generated at 2022-06-17 07:55:57.619277
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.playbook.vars_include import VarsInclude
    from ansible.playbook.role_definition import RoleDefinition
    from ansible.playbook.attribute import Att

# Generated at 2022-06-17 07:56:03.912837
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition

    loader = AnsibleLoader(None, None)
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=None)
    play = Play().load(dict(
        name="Ansible Play",
        hosts=['all'],
        gather_facts='no',
        tasks=[dict(action=dict(module='setup'))]
    ), variable_manager=variable_manager, loader=loader)
