

# Generated at 2022-06-21 01:03:51.377710
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    from .playbook_include import PlaybookInclude
    from .vars import Vars
    from .hosts import Hosts
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars

    display = Display()

    role_def = data = """
- name: test user creation
  hosts: all
  become: true
  roles:
      role_collection.role:
          test_role: 1
          test_role_2: 2
    """

    yaml_data = yaml.safe_load(data)
    variable_manager = VariableManager()
    loader = DataLoader()
    variable

# Generated at 2022-06-21 01:04:05.801836
# Unit test for method get_role_path of class RoleDefinition
def test_RoleDefinition_get_role_path():

    from ansible.utils.collection_loader import AnsibleCollectionRef
    from ansible.utils.collection_loader._collection_finder import _get_collection_role_path

    class Mock_CollectionSearch(CollectionSearch):
        def get_collection_name(self):
            return None

    class Mock_loader(object):
        def path_exists(self, path):
            return True

        def get_basedir(self):
            return 'TestCollection/roles'

    class Mock_RoleDefinition(RoleDefinition, Mock_CollectionSearch):
        def __init__(self, plays, role_basedir, variable_manager, loader, collection_list):
            super(Mock_RoleDefinition, self).__init__(plays, role_basedir, variable_manager, loader, collection_list)

    # test case1: role is not a path
   

# Generated at 2022-06-21 01:04:17.034942
# Unit test for method get_role_params of class RoleDefinition
def test_RoleDefinition_get_role_params():
    # Expected results for different role definitions
    result = {'param': 123, 'complex_param': {'subparam1': 'val1', 'subparam2': 'val2'}}

# Generated at 2022-06-21 01:04:25.189911
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.parsing.yaml import objects
    from ansible.module_utils._text import to_bytes
    from ansible.playbook.play_context import PlayContext

    # Create a play that does not have the required attributes
    play = AnsibleBaseYAMLObject()
    play._attributes = dict()
    play._ds = dict()
    play.vars = dict()
    play.ROLE_CACHE = dict()
    play.ROLE_CACHE_MAX_SIZE = 1000
    play.ROLE_WARNINGS = dict()
    play.ROLE_WARNINGS_MAX_SIZE = 1000

    # Create an attribute without the required attribute 'name' or 'private'
    attr = Attribute()
    attr._attributes = dict()
    attr._ds = dict()

# Generated at 2022-06-21 01:04:38.190310
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    variable_manager = VariableManager()
    play_context = PlayContext()

    basedir = '.'
    role_name = 'test'
    role_basedir = os.path.join(basedir, 'roles')
    role_path = os.path.join(role_basedir, role_name)
    role_definition = RoleDefinition(variable_manager=variable_manager, play=None, role_basedir=role_basedir)
    # create a new data structure here, using the same object used internally by the YAML parsing code so we can preserve file:line:column information if it exists
    role_definition._ds = role_definition.preprocess_data(role_path)

# Generated at 2022-06-21 01:04:47.026281
# Unit test for method get_role_path of class RoleDefinition
def test_RoleDefinition_get_role_path():
    # Define mock object of loader class
    class loader(object):
        def get_basedir(self):
            return '/home/user1/ansible-workspace/'
        def path_exists(self, path):
            if path == '/home/user1/ansible-workspace/roles/role-name':
                return True
            else:
                return False

    # Define mock object of variable_manager class
    class variable_manager(object):
        def get_vars(self, play=None):
            return dict(user='user1')

    # Create object of 'variable_manager' class
    v_mgr = variable_manager()
    # Create object of 'loader' class
    loader_obj = loader()
    # Create object of 'VariableManager' class with 'loader' and 'variable_manager' objects as

# Generated at 2022-06-21 01:04:59.151149
# Unit test for method get_role_params of class RoleDefinition
def test_RoleDefinition_get_role_params():
    play = '''
- hosts: localhost
  vars:
    var1: "var1_value"
    var2: "var2_value"
  roles:
    - role1
    - role2
    - role3
    - role4:
        role_params: role4_params
    - role5:
      - role_params: role5_params
  tasks:
    - debug:
        msg: "tasks_debug"

'''
    ds = yaml.safe_load(play)
    expected = {'role_params': 'role4_params'}
    assert RoleDefinition.load(data=ds['roles'][3], variable_manager=None, loader=None).get_role_params() == expected
    expected = {'role_params': 'role5_params'}
   

# Generated at 2022-06-21 01:05:09.786719
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    import ansible.plugins.loader
    rd = RoleDefinition()

    rd.role = 'role1'
    assert rd.get_name() == 'role1'

    rd.role = 'namespace.collection1/role1'
    assert rd.get_name() == 'namespace.collection1.role1'

    rd.role = 'role1'
    rd.role_basedir = '/namespace.collection1/roles'
    assert rd.get_name() == 'namespace.collection1.role1'

    rd.role = 'role1'
    rd.role_basedir = '/roles'
    assert rd.get_name() == 'role1'

    rd.role = 'role1'

# Generated at 2022-06-21 01:05:20.129028
# Unit test for method get_role_path of class RoleDefinition
def test_RoleDefinition_get_role_path():
    rd = RoleDefinition()
    # Load a bare role name as a string
    ds = 'foobar'
    rd.preprocess_data(ds)
    # Check if a valid path is returned
    if rd.get_role_path() == None:
       raise AssertionError("foobar could not be found")
    # Load a role name as a dict and set the default_roles_path
    # so that it can be found
    ds = {'role': 'foobar'}

# Generated at 2022-06-21 01:05:23.630998
# Unit test for method load of class RoleDefinition
def test_RoleDefinition_load():
    """
    Unit test for method load of class RoleDefinition
    """

    # Create a test object

    # No longer needed
    pass

# Generated at 2022-06-21 01:05:36.311727
# Unit test for constructor of class RoleDefinition
def test_RoleDefinition():
    import json
    import yaml
    ds = dict(
        role='test_role',
        role_path='/some/test/path'
    )
    rd = RoleDefinition.load(ds, None, None)
    assert rd.role == 'test_role'
    assert rd._role_path == '/some/test/path'

    ds = dict(
        role='test_role',
        role_path='/some/test/path',
        var_test='test'
    )
    rd = RoleDefinition.load(ds, None, None)
    assert rd.role == 'test_role'
    assert rd._role_path == '/some/test/path'
    assert rd._role_params['var_test'] == 'test'


# Generated at 2022-06-21 01:05:43.032358
# Unit test for method get_role_params of class RoleDefinition
def test_RoleDefinition_get_role_params():
    from ansible.parsing.yaml.objects import AnsibleMapping

    role_def = RoleDefinition()
    role_def.role = "foo"
    role_def._ds = AnsibleMapping()
    role_def._split_role_params(AnsibleMapping(dict(a=42, b=43, c=44)))

    assert role_def.get_role_params() == dict(a=42, b=43, c=44)

    role_def.a = 42
    role_def.b = 42
    role_def.c = 42

    assert role_def.get_role_params() == dict(a=42, b=43, c=44)

# Generated at 2022-06-21 01:05:45.116461
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    # FIXME: unit test?
    pass


# Generated at 2022-06-21 01:05:46.939408
# Unit test for constructor of class RoleDefinition
def test_RoleDefinition():
    role_definition = RoleDefinition()
    assert role_definition is not None

# Generated at 2022-06-21 01:05:59.875965
# Unit test for method get_role_path of class RoleDefinition
def test_RoleDefinition_get_role_path():
    role_basedir = '/data/projects/ansible-devel/test/integration/targets/galaxy_roles/'
    role_def1 = RoleDefinition(role_basedir=role_basedir)
    role_def1.role = 'test_role1'
    role_path1 = role_def1.get_role_path()
    assert role_path1 == '/data/projects/ansible-devel/test/integration/targets/galaxy_roles/test_role1'

    role_def2 = RoleDefinition(role_basedir=role_basedir)
    role_def2.role = '/data/projects/ansible-devel/test/integration/targets/galaxy_roles/test_role1'
    role_path2 = role_def2.get_

# Generated at 2022-06-21 01:06:09.999717
# Unit test for method get_role_path of class RoleDefinition
def test_RoleDefinition_get_role_path():
    import os
    import sys
    import stat
    import shutil
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.module_utils.six import iteritems
    from collections import namedtuple
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.collection_loader import AnsibleCollectionRef

    # create and remove temporary roles directory
    temp_dir = os.path.dirname(os.path.dirname(__file__))
    roles_dir = os.path.join(temp_dir, "roles")
    if os.path.exists(roles_dir):
        shutil.r

# Generated at 2022-06-21 01:06:10.885729
# Unit test for constructor of class RoleDefinition
def test_RoleDefinition():
    raise AnsibleError("not implemented")


# Generated at 2022-06-21 01:06:19.420160
# Unit test for method get_role_params of class RoleDefinition
def test_RoleDefinition_get_role_params():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext

    variable_manager = VariableManager()
    loader = DataLoader()
    playcontext = PlayContext()
    role_name = 'common'
    role_path = '/etc/ansible/roles/common'
    role_params = {
        'role': role_name,
        'blah': 'foo',
        'thing': 'bar',
        'foo': 'bar'
    }
    role_def = RoleDefinition(variable_manager=variable_manager, loader=loader, play=None)
    role_def.preprocess_data(role_params)
    # Update the role path with the role path that we know will result from the role name


# Generated at 2022-06-21 01:06:30.790000
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    def test_one(obj, expected_name):
        name = obj.get_name()
        assert name == expected_name, 'Expected name: {}, Actual name: {}'.format(expected_name, name)

    role_def_dict = dict(role='test.role')
    role_def = RoleDefinition(variable_manager=None, loader=None, collection_list=[])
    role_def.preprocess_data(role_def_dict)
    test_one(role_def, 'test.role')

    role_def_dict = dict(name='test.role')
    role_def = RoleDefinition(variable_manager=None, loader=None, collection_list=[])
    role_def.preprocess_data(role_def_dict)
    test_one(role_def, 'test.role')

    role_

# Generated at 2022-06-21 01:06:41.082241
# Unit test for method get_role_params of class RoleDefinition
def test_RoleDefinition_get_role_params():
    import tempfile
    import shutil

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    role_name = 'test_role'
    play_data = {u'name': u'test',
                 u'roles': [u'%s' % role_name]}

    # Create a temp dir in which we create the test_role
    tmp_dir = tempfile.mkdtemp()
    role_path = os.path.join(tmp_dir, 'roles', role_name)
    shutil.copytree(os.path.join(os.path.dirname(__file__), '../../../../test/integration/roles/test_role'),
                    role_path)

    loader = DataLoader

# Generated at 2022-06-21 01:06:48.625332
# Unit test for constructor of class RoleDefinition
def test_RoleDefinition():
    roledefinition = RoleDefinition()
    assert roledefinition is not None

# Generated at 2022-06-21 01:06:59.773876
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=["inventory"])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()

    role_definition = RoleDefinition(loader=loader, variable_manager=variable_manager, play=play_context, role_basedir='/var/tmp/ansible')

    # Test 1
    source = "# this is a comment\nname: cron"
    result = role_definition.preprocess_data(source)

# Generated at 2022-06-21 01:07:10.802384
# Unit test for constructor of class RoleDefinition
def test_RoleDefinition():
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    role_definition = RoleDefinition(variable_manager=variable_manager, loader=loader)
    assert isinstance(role_definition, RoleMetadata)

    role_definition = RoleDefinition(play=None, role_basedir=None, variable_manager=variable_manager, loader=loader)
    assert isinstance(role_definition, RoleMetadata)

    role_definition = RoleDefinition(play=None, role_basedir=None, variable_manager=None, loader=loader)
    assert isinstance(role_definition, RoleMetadata)


# Generated at 2022-06-21 01:07:21.846995
# Unit test for method load of class RoleDefinition

# Generated at 2022-06-21 01:07:27.439712
# Unit test for method get_role_params of class RoleDefinition
def test_RoleDefinition_get_role_params():

    from ansible.vars.manager import VariableManager
    vm = VariableManager()
    role = RoleDefinition(None, None, vm, None)
    vm.set_variable('name', 'foobar')

    # name is defined as a field attribute
    assert 'name' not in role.get_role_params()

    # extra parameters are stored as role params
    assert 'include' in role.get_role_params()
    assert role.get_role_params()['include'] == '{{ name }}'

# Generated at 2022-06-21 01:07:38.779668
# Unit test for method get_role_params of class RoleDefinition
def test_RoleDefinition_get_role_params():
    role_def = RoleDefinition(role_basedir=None, variable_manager=None, loader=None)
    role_def.role = 'test'
    role_def._ds = '''test:
    this_is_role_param1: value1
    this_is_role_param2: value2
    '''
    role_def.preprocess_data(role_def._ds)
    assert role_def.get_role_params() == {'this_is_role_param1': 'value1', 'this_is_role_param2': 'value2'}, \
        "test_RoleDefinition_get_role_params: 'test' failed!"

    role_def = RoleDefinition(role_basedir=None, variable_manager=None, loader=None)
    role_def.role = 'test'
    role

# Generated at 2022-06-21 01:07:45.704787
# Unit test for method get_role_params of class RoleDefinition
def test_RoleDefinition_get_role_params():

    class TestRoleDefinition(RoleDefinition):
        _valid_attrs = dict(
            frozenset(
                a.name for a in vars(RoleDefinition).values()
                if isinstance(a, Attribute)
            ).union(
                'application', 'instance'
            )
        )

    ds = dict(
        role='test_role',
        application='myapp',
        instance='staging',
    )
    role_def = TestRoleDefinition()
    role_def.load_data(data=ds)
    assert type(role_def.get_role_params()) == dict



# Generated at 2022-06-21 01:07:56.751639
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    test_rd = RoleDefinition()
    #
    # Originally, this test used mocking to generate a scenario where
    # self._role_collection was None and self.role was not
    #
    # That would have meant that if the code had regressed and changed
    # from '.'.join() to '+', an exception would have been thrown.
    #
    # It did not seem worth the effort to set up a mock and assert
    # on it for such a small amount of code that could be tested
    # by inspection.
    #
    assert test_rd.get_name(False) == ''
    assert test_rd.get_name(True) == ''
    test_rd._role_collection = 'my-collection'
    assert test_rd.get_name(False) == 'my-collection.None'
    assert test_rd.get

# Generated at 2022-06-21 01:08:07.451478
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    d = {}
    d['role'] = 'myrole'
    assert RoleDefinition(loader=None, collection_list=None).get_name(include_role_fqcn=True) == 'myrole'
    assert RoleDefinition(loader=None, collection_list=None).get_name(include_role_fqcn=False) == 'myrole'
    assert RoleDefinition(loader=None, collection_list=[]).get_name(include_role_fqcn=True) == 'myrole'
    assert RoleDefinition(loader=None, collection_list=[]).get_name(include_role_fqcn=False) == 'myrole'
    assert RoleDefinition(loader=None, collection_list=['mycollection']).get_name(include_role_fqcn=True) == 'mycollection.myrole'

# Generated at 2022-06-21 01:08:10.734073
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    # Given
    role_definition = RoleDefinition()
    role_definition._role = 'common'

    # When
    role_name = role_definition.get_name()

    # Then
    assert role_name == 'common'


# Generated at 2022-06-21 01:08:29.931027
# Unit test for constructor of class RoleDefinition
def test_RoleDefinition():
    class Playbook:
        def __init__(self):
            self.roles_path = []

    try:
        RoleDefinition.load([], [])
    except AnsibleError as e:
        assert 'not implemented' in str(e)

    try:
        RoleDefinition.load({}, [])
    except AnsibleAssertionError as e:
        assert True
    else:
        assert False

    try:
        RoleDefinition.load(123, [])
    except AnsibleAssertionError as e:
        assert True
    else:
        assert False

    try:
        RoleDefinition.load('role_name', [])
    except AnsibleAssertionError as e:
        assert True
    else:
        assert False


# Generated at 2022-06-21 01:08:36.390566
# Unit test for method load of class RoleDefinition
def test_RoleDefinition_load():

    obj = RoleDefinition()

    # 'role_name' must be a string
    # ds = None
    # RoleDefinition.load(ds)
    #
    # 'ds' must be a dict or a string
    # ds = object()
    # obj.load(ds)
    #
    # 'ds' must be a dict or a string
    # ds = 1234
    # obj.load(ds)

# Generated at 2022-06-21 01:08:47.817933
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from units.mock.loader import DictDataLoader

    class MockAttribute(Attribute):
        def __init__(self, name):
            self._name = name
            self._value = None
            self._value_type = None
            self._static = False
            self._required = False

        def post_validate(self, attr, name):
            pass

        def _get_value(self):
            return self._value

        def _set_value(self, value):
            self._value = value

        def serialize(self):
            return self._value

        def deserialize(self, value):
            self._value = value

    role_definition = RoleDefinition()

    # Test Name
    role_name = MockAttribute("name")
    role_definition._valid_attrs["name"] = role_name

    #

# Generated at 2022-06-21 01:08:56.284485
# Unit test for method get_role_params of class RoleDefinition
def test_RoleDefinition_get_role_params():
    from ansible.plugins.loader import find_plugin, PluginLoader
    from ansible.playbook.play_context import PlayContext

    # Simple data structure
    test_data = """
    - role: role1
      role: role2
      any_key: any_value
    """

    # Parse test data
    role_definition_objects = yaml.load(test_data)
    if not isinstance(role_definition_objects, list):
        raise AssertionError()

    # Take first object
    role_definition_object = role_definition_objects[0]
    if not isinstance(role_definition_object, RoleDefinition):
        raise AssertionError()

    # Get expected result
    expected_result = {'any_key': 'any_value'}

    # Get actual result
    actual_result = role_

# Generated at 2022-06-21 01:09:05.711298
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    # Return role name
    role = RoleDefinition()
    role._role = 'foo'
    role._role_collection = 'bar.baz'
    assert role.get_name() == 'bar.baz.foo'
    assert role.get_name(include_role_fqcn=False) == 'foo'
    role._role_collection = None
    assert role.get_name() == 'foo'
    assert role.get_name(include_role_fqcn=False) == 'foo'
    role._role = None
    assert role.get_name() == ''
    assert role.get_name(include_role_fqcn=False) == ''

# Generated at 2022-06-21 01:09:12.553617
# Unit test for method load of class RoleDefinition
def test_RoleDefinition_load():
    role_def = RoleDefinition.load({'role': 'test_role'})
    assert role_def.role == 'test_role'

    # Test handling of 'name' field instead of 'role'
    role_def = RoleDefinition.load({'name': 'test_role'})
    assert role_def.role == 'test_role'

    # Test handling of bare strings
    role_def = RoleDefinition.load('test_role')
    assert role_def.role == 'test_role'

# Generated at 2022-06-21 01:09:19.071241
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    rd = RoleDefinition()
    rd._role_collection = 'namespace.collection'
    rd._attributes = {'role': 'role_name'}
    rd_without_fqcn = RoleDefinition()
    rd_without_fqcn._role_collection = 'namespace.collection'
    rd_without_fqcn._attributes = {'role': 'role_name'}
    assert rd.get_name(include_role_fqcn=True) == 'namespace.collection.role_name'
    assert rd_without_fqcn.get_name(include_role_fqcn=False) == 'role_name'

# Generated at 2022-06-21 01:09:30.834715
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    # Simple role name
    ds = 'my-role'
    role = RoleDefinition()
    role._loader = DataLoader()
    role.preprocess_data(ds)
    assert role._role_path == '/path/to/roles/my-role'

    # Role name as dict with a single element
    ds = { 'role': 'my-role' }
    role = RoleDefinition()
    role._loader = DataLoader()
    role._loader.path_exists = lambda x: x == '/path/to/roles/my-role'

# Generated at 2022-06-21 01:09:43.484127
# Unit test for method load of class RoleDefinition
def test_RoleDefinition_load():
    from ansible.playbook.play_context import PlayContext

    # Test 1. Check for error when ds is not a string
    context = PlayContext(play=None, options=dict(), passwords=dict())
    variable_manager = None
    loader = None
    collection_list = None

    c = RoleDefinition(play=None, variable_manager=variable_manager, loader=loader, collection_list=collection_list)

    error_exception = None
    try:
        c.load(data=dict(), variable_manager=variable_manager, loader=loader)
    except Exception as ex:
        error_exception = ex

    assert 'not implemented' in str(error_exception)

    # Test 2. Check for valid input
    variable_manager = 'variable_manager'
    loader = 'loader'


# Generated at 2022-06-21 01:09:46.656499
# Unit test for method get_role_params of class RoleDefinition
def test_RoleDefinition_get_role_params():
    role_def = RoleDefinition()
    role_def.preprocess_data({'role': 'test'})

    assert not role_def.get_role_params()

    role_def.preprocess_data({'role': 'test', 'something': 'else'})

    assert role_def.get_role_params() == {'something': 'else'}

# Generated at 2022-06-21 01:10:12.071875
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    # Test for the case when the role is already defined
    role_definition = RoleDefinition()
    role_definition._role_collection = None
    role_definition._attributes = {'role': 'role_name'}
    assert role_definition.get_name() == 'role_name'

    # Test for the case when the role is a collection
    role_definition = RoleDefinition()
    role_definition._role_collection = 'ansible_namespace'
    role_definition._attributes = {'role': 'role_name'}
    assert role_definition.get_name() == 'ansible_namespace.role_name'


# Generated at 2022-06-21 01:10:21.680750
# Unit test for constructor of class RoleDefinition
def test_RoleDefinition():
    variable_manager = VariableManager()
    display = Display()
    loader = DataLoader()
    variable_manager.extra_vars = {'foobar': 'bar'}
    variable_manager = VariableManager()
    variables = variable_manager.get_vars(play=play)
    play = Play().load({
                        'name': 'test_play',
                        'hosts': 'all',
                        'roles': [
                            {'name': 'foobar'},
                        ],
                        'vars': {
                            'var1': 'val1',
                            'var2': 'val2'
                            }
                    },
                    variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-21 01:10:31.981592
# Unit test for method get_role_path of class RoleDefinition
def test_RoleDefinition_get_role_path():
    # pylint: disable=protected-access
    def get_role_path(roles_path, collection_list, role_basedir, loader_basedir, dep_name):
        variable_manager = None
        loader = DictDataLoader({})
        role_def = RoleDefinition(play=None, role_basedir=role_basedir, variable_manager=variable_manager,
                                  loader=loader, collection_list=collection_list)
        role_def._loader.set_basedir(loader_basedir)
        if roles_path is not None:
            role_def._loader.set_roles_path(roles_path)
        role_def.preprocess_data(dep_name)
        return role_def.get_role_path()


# Generated at 2022-06-21 01:10:37.973552
# Unit test for method get_role_params of class RoleDefinition
def test_RoleDefinition_get_role_params():
    class MockSimpleRoleDefinition(RoleDefinition):
        _valid_attrs = dict(
            attr1=Attribute(isa='dict')
        )

    test_params = dict(
        test_param1='param1',
        attr1=dict(test='attr1')
    )

    test_role = MockSimpleRoleDefinition.load(test_params)
    assert test_role.get_role_params() == test_params

    test_role = MockSimpleRoleDefinition.load('test_role')
    assert test_role.get_role_params() == dict()

# Generated at 2022-06-21 01:10:48.216029
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.utils.collection_loader._collection_finder import _get_collection_role_path

    # Create a loader
    # FUTURE: this is something that can be moved out to a common routine
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()

    # Create a variable manager
    variable_manager = VariableManager()

    # (1) Role is a dict with a single key:value where the key is not role or name
    #
    # Here the key is going to be added as a role parameter and the
    # value will be preserved as the parameter value.
    data = dict()
    data["my_key"] = "my_value"


# Generated at 2022-06-21 01:10:53.378045
# Unit test for method load of class RoleDefinition
def test_RoleDefinition_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    rd = RoleDefinition()
    assert rd is not None

    try:
        rd.load(
            data=None,
            variable_manager=VariableManager(),
            loader=None
        )
    except AnsibleError:
        pass


# Generated at 2022-06-21 01:10:59.454951
# Unit test for method load of class RoleDefinition
def test_RoleDefinition_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    play = Play()

    test_string = """
            ---
            - import_role:
                name: test_role
                foo: bar
                quux:
                - 1
                - 2
                - 3
        """

    test_object = RoleDefinition.load(loader.load(test_string), variable_manager, loader)

    assert test_object._valid_attrs['name'] == 'role'
    assert test_object._valid_attrs['foo'] == Attribute()
    assert test_object._valid_attrs

# Generated at 2022-06-21 01:11:03.159731
# Unit test for method get_role_params of class RoleDefinition
def test_RoleDefinition_get_role_params():
    role_definition = RoleDefinition()
    role_definition.role = 'common'
    role_definition._role_params = dict(a=1, b=2)
    assert role_definition.get_role_params() == dict(a=1, b=2)


# Generated at 2022-06-21 01:11:04.495822
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    assert RoleDefinition().get_name() == '<no name set>'

# Generated at 2022-06-21 01:11:08.485965
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    role = RoleDefinition()
    role.role = Exception('test_role')
    assert(role.get_name() == 'test_role')
    role._role_collection = Exception('test_collection')
    assert(role.get_name() == 'test_collection.test_role')
    assert(role.get_name(include_role_fqcn=False) == 'test_role')

# Generated at 2022-06-21 01:11:42.543070
# Unit test for constructor of class RoleDefinition
def test_RoleDefinition():
    from collections import namedtuple
    from ansible.playbook.play import Play
    play_ds = namedtuple('play_ds', ['basedir'])
    play_ds.basedir = os.path.dirname(__file__)
    play = Play().load(play_ds, variable_manager=None, loader=None)
    rd1 = RoleDefinition(play=play).load(dict(role='myrole'), variable_manager=None, loader=None, collection_list=None)
    assert rd1._role_path == "./roles/myrole"
    assert rd1.role == "myrole"
    rd2 = RoleDefinition(play=play).load(dict(role='../roles/myrole'), variable_manager=None, loader=None, collection_list=None)
    assert rd2._

# Generated at 2022-06-21 01:11:53.485534
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():

    test_role = RoleDefinition()

    # test role with role_collection
    test_role._role = "test_role"
    test_role._role_collection = "test_collection"
    assert test_role.get_name() == "test_collection.test_role"

    # test role without role_collection
    test_role._role = "test_role"
    test_role._role_collection = None
    assert test_role.get_name() == "test_role"

    # test role with invalid role_collection
    test_role._role = "test_role"
    test_role._role_collection = 123
    assert test_role.get_name() == "test_role"

    # test role without role
    test_role._role = None
    test_role._role_collection = "test_collection"


# Generated at 2022-06-21 01:12:01.711695
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    fake_loader = 'Fake mock loader'
    fake_variable_manager = 'Fake mock variable manager'

    role_def_string = 'role_name_string'
    role_def_dict = {'role': 'role_name_dict'}
    role_def_dict_include_name = {'role': 'role_name_dict', 'name': 'name_in_role_dict'}
    role_def_dict_include_extra_params = {'role': 'role_name_dict_include_extra_params', 'name': 'name_in_role_dict_extra_params', 'extra_params': 'extra_params_in_role_dict'}

    fake_host_basedir = '/path/to/host/basedir'

    fake_role_basedir = '/path/to/role/basedir'

   

# Generated at 2022-06-21 01:12:12.788560
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    role_basedir = 'roles'
    role_name = 'apache'
    role_path = 'roles/apache'

    # 1. Input, not dict or string
    data = [role_name]
    rd = RoleDefinition(role_basedir=role_basedir)
    try:
        rd.preprocess_data(data)
        assert False
    except AnsibleAssertionError:
        assert True

    # 2. Input dict, where role name is role name, role path is in search paths, 
    #    and role parameters are empty.
    data = {
        'role': role_name
    }
    rd = RoleDefinition(role_basedir=role_basedir)
    rd.preprocess_data(data)
    assert rd._role_path == role_path 

# Generated at 2022-06-21 01:12:15.578671
# Unit test for method get_role_path of class RoleDefinition
def test_RoleDefinition_get_role_path():
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    path = '/etc/ansible/roles/role1'
    role = RoleDefinition()
    role._loader = loader
    role._role_basedir = '/etc/ansible/roles/'
    role._role_collection = 'collection1'
    role._role_name = 'role1'
    role._role_path = '/etc/ansible/roles/role1'
    assert role.get_role_path() == path

# Generated at 2022-06-21 01:12:23.038726
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    role_def = RoleDefinition()
    role_def._role_collection = 'test'
    role_def._attributes = {'role': 'test'}
    assert role_def.get_name() == 'test.test'
    assert role_def.get_name(include_role_fqcn=False) == 'test'
    role_def._role_collection = None
    role_def._attributes = {'role': 'test'}
    assert role_def.get_name() == 'test'
    assert role_def.get_name(include_role_fqcn=False) == 'test'
    role_def._role_collection = 'test'
    role_def._attributes = {'role': None}
    assert role_def.get_name() == 'test'
    assert role_def.get

# Generated at 2022-06-21 01:12:33.409320
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    # test with include_role_fqcn=True
    role = RoleDefinition()
    role.role = 'test'
    role._role_collection = 'collection_name'
    assert role.get_name() == 'collection_name.test'
    role._role_collection = 'collection_name1.collection_name2'
    assert role.get_name() == 'collection_name1.collection_name2.test'

    # test with include_role_fqcn=False
    role = RoleDefinition()
    role.role = 'test'
    role._role_collection = 'collection_name'
    assert role.get_name(include_role_fqcn=False) == 'test'
    role._role_collection = 'collection_name1.collection_name2'

# Generated at 2022-06-21 01:12:42.163797
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():

    def _test(role_name, expected_ds=None, expected_role_params=None, expected_role_path=None):
        role_def = RoleDefinition()
        role_path = '../some_collection/some_path'
        role_collection = 'invalid'

        # Setup mocks
        role_def._load_role_path = mock.MagicMock(return_value=(role_name, role_path))
        role_def._role_collection = role_collection

        ds = {'role': role_name, 'some_attr': 'some_val'}
        # Call method
        actual_ds = role_def.preprocess_data(ds)

        # Assertions
        role_def._load_role_path.assert_called_once_with(role_name)
        assert actual_ds == expected

# Generated at 2022-06-21 01:12:51.100914
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test case 1
    # Test case: role: [webservers]
    # Expected outcome: {'role': webservers}
    ds = {'role': ['webservers']}
    rd = RoleDefinition(play=None, role_basedir=None, variable_manager=variable_manager, loader=loader,
                        collection_list=None)
    assert rd.preprocess

# Generated at 2022-06-21 01:12:54.201642
# Unit test for method get_role_path of class RoleDefinition
def test_RoleDefinition_get_role_path():
    RoleDefinition._role_path = './roles/example'

    assert RoleDefinition.get_role_path() == './roles/example'