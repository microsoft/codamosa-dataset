

# Generated at 2022-06-21 01:03:47.421285
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.collection_loader import AnsibleCollectionFinder

    variable_manager = VariableManager()
    loader = DataLoader()
    collection_finder = AnsibleCollectionFinder(loader=loader, variable_manager=variable_manager)
    play = Play().load({}, variable_manager=variable_manager, loader=loader)
    role1 = RoleDefinition(play, role_basedir="test_role/", variable_manager=variable_manager, loader=loader, collection_list=collection_finder.get_collections())
    role2 = RoleDefinition(play, role_basedir="test_role/", variable_manager=variable_manager, loader=loader, collection_list=[])

# Generated at 2022-06-21 01:03:55.325666
# Unit test for method get_role_path of class RoleDefinition
def test_RoleDefinition_get_role_path():
    # RoleDefinition.get_role_path
    #
    # Test a role defined in ansible/ansible:
    role_def = RoleDefinition(role_basedir='../../../lib/ansible/modules/cloud/amazon', loader='loader', collection_list=['ansible.ansible'])
    role_def._ds = role_def.preprocess_data('ec2')
    assert role_def.get_role_path() == '../../../lib/ansible/modules/cloud/amazon/ec2'
    assert role_def.get_name() == 'ansible.ansible.ec2'

    #
    # Test a role defined in ansible/ansible_collections/namespace/name:

# Generated at 2022-06-21 01:04:07.034554
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.playbook.base import Base
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    loader_mock = Base()
    play_context_mock = PlayContext()
    variable_manager = VariableManager()

    role_definition = RoleDefinition(loader=loader_mock, play=None, role_basedir=None,
                                     collection_list=[], variable_manager=variable_manager)

    # tes a simple role name, i.e. not a dict
    data = 'test-role'
    new_role_def = role_definition.preprocess_data(data)
    assert new_role_def['role'] == 'test-role'
    assert role_definition.role == 'test-role'

# Generated at 2022-06-21 01:04:14.238221
# Unit test for method get_role_path of class RoleDefinition
def test_RoleDefinition_get_role_path():
    test_role_name = 'myrole'
    test_role_basedir = './roles'
    test_role_path = './roles/myrole'

    rd = RoleDefinition(play=None, role_basedir=test_role_basedir)
    rd._ds = test_role_name
    rd._role_path = test_role_path
    assert rd.get_role_path() == test_role_path

# Generated at 2022-06-21 01:04:24.534389
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    role_def = RoleDefinition(role_basedir='/a')
    role_def._role_collection = None
    role_def._role = 'role1'
    assert role_def.get_name() == 'role1'
    assert role_def.get_name(include_role_fqcn=False) == 'role1'
    role_def._role_collection = 'namespace1'
    assert role_def.get_name() == 'namespace1.role1'
    assert role_def.get_name(include_role_fqcn=False) == 'role1'

# Generated at 2022-06-21 01:04:31.938926
# Unit test for constructor of class RoleDefinition
def test_RoleDefinition():
    role_def = RoleDefinition()
    assert isinstance(role_def, RoleDefinition)
    assert isinstance(role_def, Base)
    assert isinstance(role_def, Conditional)
    assert isinstance(role_def, Taggable)
    assert isinstance(role_def, CollectionSearch)
    assert isinstance(role_def, Attribute)

# Generated at 2022-06-21 01:04:40.873995
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    # setup
    class MockRoleDefinition(RoleDefinition):
        _valid_attrs = dict(
            one=Attribute(default=1, priority=1),
            two=Attribute(default=2, priority=2),
            three=Attribute(default=3, priority=3),
            four=Attribute(default=4, priority=4),
            role=Attribute(default='test', priority=1),
        )
    rd = MockRoleDefinition()
    # test
    assert rd.get_name() == 'test'
    rd._role_collection = 'test_collection'
    assert rd.get_name() == 'test_collection.test'
    assert rd.get_name(include_role_fqcn=False) == 'test'

# Generated at 2022-06-21 01:04:47.903583
# Unit test for method get_role_params of class RoleDefinition
def test_RoleDefinition_get_role_params():
    rd = RoleDefinition()

    rd._ds = """
- role: common
  foo: bar
  baz: baz
"""
    rd.preprocess_data(rd._ds)
    assert rd.role == "common"
    role_params = rd.get_role_params()
    assert role_params['foo'] == 'bar' and role_params['baz'] == 'baz'



# Generated at 2022-06-21 01:04:59.421993
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    from .host import Host
    from .task import Task
    from .playbook import Playbook
    from .playbook_include import PlaybookInclude
    from .block import Block
    from .async_task import AsyncTask
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    import ansible.constants as C

    # create a task with a valid role
    loader = DataLoader()
    play_context = PlayContext(loader=loader)
    variable_manager = VariableManager(loader=loader, play_context=play_context)
    task = Task()
    task.role = 'ansible.builtin.ping'

# Generated at 2022-06-21 01:05:09.882811
# Unit test for method get_role_params of class RoleDefinition
def test_RoleDefinition_get_role_params():
    "Tests the method RoleDefinition.get_role_params"

    from ansible.playbook.task import Task


# Generated at 2022-06-21 01:05:28.909192
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    ds = dict(role='test')
    # Fake objects to prevent code from breaking
    play = Play()
    tqm = TaskQueueManager(inventory=InventoryManager(loader=DataLoader()), variable_manager=VariableManager(), loader=DataLoader())
    rd = RoleDefinition(play=play, variable_manager=VariableManager(), loader=DataLoader())

    # Base case
    assert isinstance(rd.preprocess_data(ds), AnsibleMapping)

    # Input is a string

# Generated at 2022-06-21 01:05:41.001257
# Unit test for method get_role_path of class RoleDefinition
def test_RoleDefinition_get_role_path():

    # TODO: this code should be moved to a unit test module
    #       because it adds a dependency on unit test module
    #       to library module.

    import sys
    try:
        from unittest import mock
    except ImportError:
        import mock
        mock = mock

    # Build mocks and patch `RoleDefinition._load_role_path` method
    # so that it returns mocked data.
    ds1 = {}
    ds1['role'] = 'role_name1'
    role_name1 = ds1['role']
    role_path1 = '/path/to/roles/' + role_name1
    role_name1_tuples = (role_name1, role_path1, None)

    ds2 = {}

# Generated at 2022-06-21 01:05:51.868622
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    loader = None
    variable_manager = None
    def __init__(self, play=None, role_basedir=None, variable_manager=None, loader=None, collection_list=None):
        self._role_basedir = role_basedir
        self._role_params = dict()
        self._role_path = None
        self._collection_list = collection_list
        self.role = 'test_role'
        return
    RoleDefinition.__init__ = __init__
    role_def = RoleDefinition()
    #no collection, include_role_fqcn=True
    assert role_def.get_name(True) == 'test_role'
    #collection, include_role_fqcn=True
    role_def._role_collection = 'test_collection'

# Generated at 2022-06-21 01:05:57.464104
# Unit test for constructor of class RoleDefinition
def test_RoleDefinition():
    try:
        rd = RoleDefinition(play=None, role_basedir=None, variable_manager=None, loader=None, collection_list=None)
    except:
        rd = None
    assert rd is not None, "Failed to construct RoleDefinition object"


# Generated at 2022-06-21 01:06:10.626125
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    # collection-based roles (no colons)
    def preprocess_data(data, collection_list=None, strict=False):
        rd = RoleDefinition(collection_list=collection_list)
        new_data = rd.preprocess_data(data)
        return new_data.data

    # simple role name (no role/name key)
    data = 'rolename'
    new_data = preprocess_data(data)
    assert new_data == {'role': 'rolename'}

    # role name with a relative path specified, but without the roles/ directory
    data = {'name': './relative-dir-roles/rolename'}
    new_data = preprocess_data(data)
    assert new_data == {'role': 'rolename'}

    # role name with a relative path specified,

# Generated at 2022-06-21 01:06:18.888584
# Unit test for constructor of class RoleDefinition
def test_RoleDefinition():

    ds = dict(
        role='foo'
    )
    role_def = RoleDefinition(ds)

    assert isinstance(role_def, RoleDefinition)
    assert role_def.role == 'foo'

    ds = dict(
        role='foo',
        bar='baz'
    )
    cond = dict(
        when='some_condition'
    )
    ds['conditions'] = cond
    role_def = RoleDefinition(ds)

    assert hasattr(role_def, '_conditional_block')
    assert isinstance(role_def._conditional_block, dict)
    assert role_def.conditions == cond
    assert role_def.role == 'foo'
    assert role_def.bar == 'baz'


# Generated at 2022-06-21 01:06:29.931115
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader
    # We need to create a role definition with a role_name and a role_path
    # to test the preprocess_data method. This can be easily done by instantiating
    # the RoleDefinition class the right way.
    # To do this, we need following objects
    # 1. play object
    # 2. variable manager object
    # 3. loader object
    # 4. collection object
    #
    # To test it, we need one more thing, assertion library.

    role_def = 'test_role_definition'

    play_name = 'test_play'
    play_path = '/tmp'
    loader = DataLoader()
    variable_manager = None
    collection = []

    my_play = Play().load

# Generated at 2022-06-21 01:06:34.430883
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    fqcn = 'demo.apache'
    role = RoleDefinition(role_basedir=None, role=fqcn)
    assert role.get_name() == fqcn
    assert role.get_name(include_role_fqcn=False) == 'apache'

# Generated at 2022-06-21 01:06:43.258254
# Unit test for method get_role_path of class RoleDefinition
def test_RoleDefinition_get_role_path():
    '''
    Unit test for method get_role_path of class RoleDefinition
    '''

    # TestCase1
    test_role_path = '/path/to/roles'
    test_role_path_dict = {'role':'test_role_name'}
    role_def = RoleDefinition(role_basedir=test_role_path)
    role_def.preprocess_data(test_role_path_dict)
    assert role_def.get_role_path() == os.path.join(test_role_path, 'test_role_name')

    # TestCase2
    test_role_path = '/path/to/roles'
    test_role_path_dict = {'role':'/path/to/roles/test_role_name'}

# Generated at 2022-06-21 01:06:43.832616
# Unit test for method load of class RoleDefinition
def test_RoleDefinition_load():
    pass

# Generated at 2022-06-21 01:06:59.127024
# Unit test for method get_role_path of class RoleDefinition
def test_RoleDefinition_get_role_path():
    class MockLoader(object):
        def path_exists(self, path):
            if path == '/some/collection/some/role/tasks/main.yml' or path == '/some/collection/some/role/meta/main.yml' or path == '/some/collection/some/role/vars/main.yml':
                return True
            return False

    loader = MockLoader()
    variable_manager = None
    play = object()

    # Test with a valid 'roles' collection name
    role = RoleDefinition(play=play, loader=loader, variable_manager=variable_manager, collection_list=['roles'])

    try:
        role._load_role_name('some.role')
    except:
        assert False


# Generated at 2022-06-21 01:06:59.721855
# Unit test for method get_role_path of class RoleDefinition
def test_RoleDefinition_get_role_path():
    pass

# Generated at 2022-06-21 01:07:02.982319
# Unit test for method get_role_path of class RoleDefinition
def test_RoleDefinition_get_role_path():
    rd = RoleDefinition()
    rd._role_path = '/path/to/role'

    assert rd.get_role_path() == '/path/to/role'

# Generated at 2022-06-21 01:07:04.805049
# Unit test for method load of class RoleDefinition
def test_RoleDefinition_load():

    # FIXME(retr0h): Load fixture
    assert False

# Generated at 2022-06-21 01:07:07.987478
# Unit test for constructor of class RoleDefinition
def test_RoleDefinition():
    role_def = RoleDefinition(role_basedir="test")
    assert role_def is not None
    assert role_def._role_basedir == "test"

# Generated at 2022-06-21 01:07:18.945308
# Unit test for method get_role_path of class RoleDefinition
def test_RoleDefinition_get_role_path():
    from ansible.plugins.loader import module_loader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inv = InventoryManager(loader=loader, sources='localhost')
    variable_manager = VariableManager(loader=loader, inventory=inv)
    templar = Templar(loader=loader, variables=variable_manager.get_vars())

    current_dir = os.path.dirname(os.path.realpath(__file__))
    test_dir = os.path.join(current_dir, 'roles_test_r')


# Generated at 2022-06-21 01:07:28.148047
# Unit test for constructor of class RoleDefinition
def test_RoleDefinition():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars import VariableManager

    data = '''
---
- hosts: all
  roles:
    - role: test
      foo: bar
    - role: baz
      bar: bing
'''
    loader = AnsibleLoader(data, None, variable_manager=VariableManager())
    results = list(loader.get_single_data())
    assert(len(results) == 1)
    assert(isinstance(results[0], dict))
    assert(len(results[0]) == 2)
    assert(results[0]['hosts'] == 'all')
    assert(isinstance(results[0]['roles'], list))
    assert(len(results[0]['roles']) == 2)

# Generated at 2022-06-21 01:07:38.006478
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    role_definition = RoleDefinition()
    role_definition._role_collection = 'test_collection'
    role_definition.role = 'test_role'
    msg = "test_name_of_role_definition"

    # get_name with param include_role_fqcn
    fqcn = role_definition.get_name(True)
    assert fqcn == 'test_collection.test_role', "Role should be test_collection.test_role"

    # get_name without param include_role_fqcn
    name = role_definition.get_name()
    assert name == 'test_role', "Role should be test_role"

# Generated at 2022-06-21 01:07:38.977514
# Unit test for constructor of class RoleDefinition
def test_RoleDefinition():
    rd = RoleDefinition()
    rd.role = 'testname'

# Generated at 2022-06-21 01:07:39.891447
# Unit test for method load of class RoleDefinition
def test_RoleDefinition_load():
    RoleDefinition.load(None, None, None)

# Generated at 2022-06-21 01:07:58.170273
# Unit test for method preprocess_data of class RoleDefinition

# Generated at 2022-06-21 01:08:08.605511
# Unit test for method get_role_path of class RoleDefinition
def test_RoleDefinition_get_role_path():
    fname = os.path.split(__file__)[-1]

    # Test case 1: role_name = absolute path
    role_name = '/tmp/test_role_path/test_role_1'
    role_path = RoleDefinition._load_role_path(role_name, None)

    assert role_name == role_path[0]
    assert os.path.dirname(role_name) == role_path[1]
    dirs_to_clean=[]
    dirs_to_clean.append(os.path.dirname(role_name))
    for path in dirs_to_clean:
        shutil.rmtree(path)

    # Test case 2: role_name = relative path
    role_name = 'test_role_path/test_role_2/roles'
    role

# Generated at 2022-06-21 01:08:20.405151
# Unit test for method get_role_path of class RoleDefinition
def test_RoleDefinition_get_role_path():

    import os
    import ansible.parsing.yaml.objects

    ds = ansible.parsing.yaml.objects.AnsibleMapping()
    ds.update({
        'role': 'foobar'
    })

    test_role_path = os.path.join(os.getcwd(), 'test_role_definitions', 'test_roles', 'foobar')
    role_definition = RoleDefinition(role_basedir=os.path.join(os.getcwd(), 'test_role_definitions', 'test_roles'))
    role_definition.preprocess_data(ds)
    actual_role_path = role_definition.get_role_path()

    assert actual_role_path == test_role_path


# Generated at 2022-06-21 01:08:29.937148
# Unit test for method get_role_params of class RoleDefinition
def test_RoleDefinition_get_role_params():
    role = 'role'
    role_params = dict()
    role_params['a'] = 'b'
    role_params['c'] = 'd'
    role_params['e'] = 'f'
    role_def = dict()
    role_def['role'] = role
    role_def['a'] = 'b'
    role_def['c'] = 'd'
    role_def['e'] = 'f'
    role_def_obj = RoleDefinition()
    role_def_obj._split_role_params(role_def)
    (roledef, roleparams) = role_def_obj._split_role_params(role_def)
    assert (role_def['role'] == roledef['role'])
    assert C.DEFAULT_ROLES_PATH

# Generated at 2022-06-21 01:08:42.017081
# Unit test for method get_role_path of class RoleDefinition
def test_RoleDefinition_get_role_path():
    # Success
    role_def = RoleDefinition()
    role_def._role_path = "/path/to/ansible/roles/an_existing_role"
    assert role_def.get_role_path() == "/path/to/ansible/roles/an_existing_role"

    # Failure
    role_def = RoleDefinition()
    role_def._role_path = False
    try:
        role_def.get_role_path()
        assert False, 'AnsibleAssertionError not raised'
    except AnsibleAssertionError:
        pass

    role_def = RoleDefinition()
    role_def._role_path = None

# Generated at 2022-06-21 01:08:51.393125
# Unit test for method get_role_params of class RoleDefinition
def test_RoleDefinition_get_role_params():
    role_definition = RoleDefinition(role_basedir="test/test_roles")
    role_definition._ds = {'role': 'test', 'tasks': 'main.yml', 'vars': {'test_var': 'myvar'}}
    role_definition._variable_manager = 'test'
    role_definition._loader = 'test'
    role_definition._collection_list = ['ansible_collections.test.test_collection']

    role_definition.preprocess_data(role_definition._ds)
    role_params = role_definition.get_role_params()

    # Ensure role params are correct
    assert role_params == {'vars': {'test_var': 'myvar'}}


# Generated at 2022-06-21 01:08:52.676671
# Unit test for constructor of class RoleDefinition
def test_RoleDefinition():
    '''
    Unit test for constructor of class RoleDefinition
    '''
    pass

# Generated at 2022-06-21 01:08:58.875585
# Unit test for method load of class RoleDefinition
def test_RoleDefinition_load():
    # Test the data structure of a dictionary
    try:
        RoleDefinition.load({'role':'common',"sudo":"true",'tasks':[{'name':'task1','action':{'module':'debug','msg':'test'}}]})
    except AnsibleError:
        assert False
    except:
        assert True
    else:
        assert True
    # Test the data structure of a string
    try:
        RoleDefinition.load('common')
    except AnsibleError:
        assert False
    except:
        assert True
    else:
        assert True
    # Test the data structure of an AnsibleBaseYAMLObject
    try:
        RoleDefinition.load(AnsibleBaseYAMLObject('common'))
    except AnsibleError:
        assert False
    except:
        assert True

# Generated at 2022-06-21 01:09:01.851754
# Unit test for method get_role_params of class RoleDefinition
def test_RoleDefinition_get_role_params():
    x = RoleDefinition()
    x.preprocess_data({"role": "common", "var": "foo"})
    assert x.get_role_params() == {"var": "foo"}

# Generated at 2022-06-21 01:09:12.131541
# Unit test for method get_role_path of class RoleDefinition
def test_RoleDefinition_get_role_path():
    variable_manager = None
    loader = None
    role_basedir = None
    collection_list = None
    role_name = 'my_role'
    role_path = '/my/role/path'
    ansible_pos = None
    ds = 'my_role'
    role_def = RoleDefinition(play=None, role_basedir=role_basedir, variable_manager=variable_manager, loader=loader, collection_list=collection_list)
    assert role_def._load_role_path(role_name) == (role_name, role_path)
    assert role_def._load_role_name(ds) == role_name
    assert role_def._split_role_params(ds) == (None, None)


# Generated at 2022-06-21 01:09:46.571248
# Unit test for method get_role_path of class RoleDefinition
def test_RoleDefinition_get_role_path():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.role_include import RoleInclude
    from ansible.module_utils.six import PY2

    try:
        __import__('yaml')
    except ImportError:
        print("Error: yaml is required for this unit test")
        sys.exit(1)

    result = {}

    def _add_result(key, value):
        if key not in result:
            result[key] = value

    def _assert_equal(key, expected, value):
        if expected != value:
            raise AssertionError("%s: expected %s, got %s" % (key, expected, value))



# Generated at 2022-06-21 01:09:47.662517
# Unit test for method load of class RoleDefinition
def test_RoleDefinition_load():
    raise AnsibleError("not implemented")

# Generated at 2022-06-21 01:09:48.287395
# Unit test for method load of class RoleDefinition
def test_RoleDefinition_load():
    pass

# Generated at 2022-06-21 01:09:59.268703
# Unit test for method get_role_path of class RoleDefinition
def test_RoleDefinition_get_role_path():
    # Create fake play
    play1 = dict(name = "TestPlay")
    # Set fake variables_manager
    variable_manager = dict()
    # Set fake loader
    loader = dict(path = "/root/ansible/test_role/test_playbook.yml", basedir = "/root/ansible/test_role/")
    # Create fake collection list
    collection_list = dict()
    # Create fake role definition
    role_definition1 = RoleDefinition(play1, "/root/ansible/test_role/", variable_manager, loader, collection_list)

    # Create fake play
    play2 = dict(name = "RoleTestPlay")
    # Create fake role definition
    role_definition2 = RoleDefinition(play2, "/root/ansible/test_role/", variable_manager, loader, collection_list)

   

# Generated at 2022-06-21 01:10:09.537103
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    module = False
    attribute_map = False
    loader = None
    templar = None
    roles = [
        {
            'name': "test_role",
            'role': "role_def1",
            'attributes': Attribute(attribute_map)
        },
        {
            'name': "test_role",
            'role': "role_def2",
            'attributes': Attribute(attribute_map)
        },
        {
            'name': "test_role",
            'role': "role_def3",
            'attributes': Attribute(attribute_map)
        },
        {
            'name': "test_role",
            'role': "role_def4",
            'attributes': Attribute(attribute_map)
        },
    ]


# Generated at 2022-06-21 01:10:17.090230
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    # test cases with include_role_fqcn = True
    # -----------------------------------------
    # 1. collection_name != None, role != None
    display.display("")
    display.display("[test_RoleDefinition_get_name] test case 1: collection_name != None, role != None")
    rd = RoleDefinition(role_basedir=None, variable_manager=None, loader=None, collection_list=None)
    rd._role_collection = "my_collection_name"
    rd._role = "my_role"
    assert rd.get_name() == "my_collection_name.my_role"
    display.display(str(rd.get_name()))

    # 2. collection_name != None, role == None
    display.display("")

# Generated at 2022-06-21 01:10:21.981235
# Unit test for method get_role_params of class RoleDefinition
def test_RoleDefinition_get_role_params():
    role_def = RoleDefinition()
    role_def._role_params = {'param1': 'value', 'param2': 'value2'}
    assert role_def.get_role_params() == {'param1': 'value', 'param2': 'value2'}


# Generated at 2022-06-21 01:10:32.220099
# Unit test for constructor of class RoleDefinition
def test_RoleDefinition():
    """
    Unit test for class RoleDefinition
    """
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    rd = RoleDefinition()
    # include_role is a task of type include_role
    include_role = Task.load(dict(
        include_role="role_name",
        ignore_errors=True
    ), play=Play().load(dict(
        name="test_play",
        hosts="localhost",
        gather_facts="no"
    )), variable_manager=dict(), loader=None)
    # block is a block which contains include_role

# Generated at 2022-06-21 01:10:42.732454
# Unit test for method get_role_path of class RoleDefinition
def test_RoleDefinition_get_role_path():
    rd = RoleDefinition()
    # role role_param
    assert os.path.basename(rd._load_role_path('role_param')[1]) == 'role_param'
    # role role_param/tasks
    assert os.path.basename(rd._load_role_path('role_param/tasks')[1]) == 'role_param'
    # file path
    assert os.path.basename(rd._load_role_path('/etc/passwd')[1]) == 'passwd'
    # file path with extra /
    assert os.path.basename(rd._load_role_path('/etc/passwd/')[1]) == 'passwd'
    # role role: role_param

# Generated at 2022-06-21 01:10:44.639253
# Unit test for method get_role_params of class RoleDefinition
def test_RoleDefinition_get_role_params():
    assert RoleDefinition(role_basedir='/var/foo', loader=None,play=None,variable_manager=None,collection_list=None)

# Generated at 2022-06-21 01:11:27.405089
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    import pytest
    
    role_name = 'name'
    role_fqcn = 'namespace.name'
    collection_name = 'namespace.collection'
    role_basedir = '.'

    # # test with no collection
    rd = RoleDefinition()
    rd._collection_list = None
    rd._role_collection = None
    rd.role = role_name
    assert rd.get_name() == role_name
    assert rd.get_name(include_role_fqcn=False) == role_name

    # # test without a collection and a role that doesn't have a collection
    rd = RoleDefinition()
    rd._collection_list = [collection_name]
    rd._role_collection = None
    rd.role = role_name

# Generated at 2022-06-21 01:11:28.267294
# Unit test for constructor of class RoleDefinition
def test_RoleDefinition():
    rd = RoleDefinition()
    assert rd

# Generated at 2022-06-21 01:11:36.359497
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    res = RoleDefinition()

    # include fqcn
    assert res.get_name(True) == None
    res._role_collection = 'namespace.collection'
    res.role = 'role'
    assert res.get_name(True) == 'namespace.collection.role'

    # exclude fqcn
    assert res.get_name(False) == 'role'
    res._role_collection = None
    assert res.get_name(False) == 'role'
    res._role_collection = 'namespace.collection'
    assert res.get_name(False) == 'role'
    res.role = None
    assert res.get_name(False) == None

# Generated at 2022-06-21 01:11:42.562904
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    collection_list = [
        AnsibleCollectionRef.from_str('my.collection1')
    ]
    ds = {'role': 'my.collection1.role1'}
    # When collection_list is not empty
    def test_get_name(self):
        self._role_collection = 'my.collection1'
        self.role = 'role1'
        self._collection_list = collection_list
        self.name = self.get_name()
        assert self.name == 'my.collection1.role1'

        self.name = self.get_name(include_role_fqcn=False)
        assert self.name == 'role1'

    # When collection_list is empty
    def test_get_name(self):
        self._role_collection = 'my.collection'
        self.role

# Generated at 2022-06-21 01:11:49.002447
# Unit test for constructor of class RoleDefinition
def test_RoleDefinition():
    host = "127.0.0.1"
    var_mgr = VariableManager()
    loader = DataLoader()
    role_def = RoleDefinition.load(dict(role=dict(name="test")), var_mgr, loader)
    assert role_def.get_name(include_role_fqcn=True) == "test"
    assert role_def.get_name(include_role_fqcn=False) == "test"

# Generated at 2022-06-21 01:11:49.932343
# Unit test for method load of class RoleDefinition
def test_RoleDefinition_load():
    raise NotImplementedError

# Generated at 2022-06-21 01:11:59.257091
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    r = RoleDefinition(role_basedir=None, variable_manager=None, loader=None, collection_list=None)
    r._role = 'test_role'
    assert r.get_name() == 'test_role'

    r = RoleDefinition(role_basedir=None, variable_manager=None, loader=None, collection_list='collection')
    r._role = 'test_role'
    assert r.get_name() == 'collection.test_role'

    r = RoleDefinition(role_basedir=None, variable_manager=None, loader=None, collection_list=None)
    r._role = 'test_role'
    assert r.get_name(include_role_fqcn=False) == 'test_role'


# Generated at 2022-06-21 01:12:04.502417
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.inventory import Inventory
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.utils.display import Display
    import pytest
    #
    # setup
    #

    # setup test variables
    play_context = PlayContext(new_stdin=False)
    play_context._target_host = 'localhost'
    play_context._play = play_context
    play_context._play_ds = {}
    play_context.variable

# Generated at 2022-06-21 01:12:10.286933
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    import __main__
    __main__.display = Display()

    r = RoleDefinition()
    assert r.get_name() == None
    r.role = 'foobar'
    assert r.get_name() == 'foobar'
    r._role_collection = 'foo.bar'
    assert r.get_name() == 'foo.bar.foobar'

# Generated at 2022-06-21 01:12:19.643410
# Unit test for method get_role_path of class RoleDefinition
def test_RoleDefinition_get_role_path():
    import ansible.plugins
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible import context
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector

    # setup

# Generated at 2022-06-21 01:13:02.394694
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    here = os.path.dirname(os.path.realpath(__file__))
    role_path = os.path.abspath(os.path.join(here, '..', '..', 'test', 'roles', 'foo'))
    block_name = 'block_name'
    block = Block.load({'name': block_name, 'roles': [{'role': 'foo'}]}, play=Play(), variable_manager=VariableManager(), loader=DataLoader())

    assert block.parent._role_basedir == role_path
    assert block.parent.role == 'foo'


# Generated at 2022-06-21 01:13:12.442539
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():

    # CASE1: role definition is not a string or dict
    # Expect: AnsibleAssertionError
    ds = 42
    role_definition = RoleDefinition()
    try:
        role_definition.preprocess_data(ds)
        assert False
    except AnsibleAssertionError:
        pass

    # CASE2: role definition is a string
    # Expect: as-is
    ds = 'role_name'
    role_definition = RoleDefinition()
    assert role_definition.preprocess_data(ds) == 'role_name'

    # CASE3: role definition is a dict, but has no role and no name
    # Expect: AnsibleError
    ds = {}
    role_definition = RoleDefinition()

# Generated at 2022-06-21 01:13:22.064971
# Unit test for constructor of class RoleDefinition
def test_RoleDefinition():
    from ansible.parsing.yaml.data import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from six import StringIO
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.vault import VaultLib
    from ansible.parsing.yaml.dumper import AnsibleDumper

    datastr = """
    - hosts:
       - localhost
      roles:
      - base
      tasks:
      - name: Print out
        debug:
          msg: Hello
    """

    data = DataLoader().load(datastr)[0]
    play = Play.load

# Generated at 2022-06-21 01:13:24.924631
# Unit test for constructor of class RoleDefinition
def test_RoleDefinition():
    # RoleDefinition() is no longer instantiated directly
    # Constructor takes the following arguments
    # play=None, role_basedir=None, variable_manager=None, loader=None, collection_list=None
    assert 1 == 1

# Generated at 2022-06-21 01:13:30.492828
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():

    from ansible.playbook.role_loaders import RoleLoader

    # Try to get the name of a role definition from a collection
    role = RoleDefinition()
    role._role_path = 'ansible_collections.community.graphite.roles.graphite'
    role._role_collection = 'ansible_collections.community.graphite'
    role.role = 'graphite'

    role_loader = RoleLoader()

    assert role.get_name() == 'ansible_collections.community.graphite.graphite', \
        "The name of a role definition should be a concatenation of the collection name, a dot and the role name"