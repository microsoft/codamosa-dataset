

# Generated at 2022-06-21 01:03:46.832984
# Unit test for method get_role_params of class RoleDefinition
def test_RoleDefinition_get_role_params():
    from ansible.vars.manager import VariableManager
    from units.mock.loader import DictDataLoader

    data = dict(
        name='myrolename',
        role='myrolename'
    )

    variable_manager = VariableManager()
    variable_manager.set_inventory(None)

    loader = DictDataLoader([])

    #Create a test roleDefinition object
    rd = RoleDefinition(variable_manager=variable_manager, loader=loader)

    #Set the role params of the roleDefinition object
    rd._role_params = data

    assert data == rd.get_role_params()


# Generated at 2022-06-21 01:03:52.246001
# Unit test for method get_role_params of class RoleDefinition
def test_RoleDefinition_get_role_params():
    assert RoleDefinition(role_basedir='/')._ds == {'role': '.'}
    assert RoleDefinition(role_basedir='/',
                          _ds={"role": "test"}).get_role_params() == {}
    assert RoleDefinition(role_basedir='/',
                          _ds={"role": "test", "k1": "v1"}).get_role_params() == {"k1": "v1"}

# Generated at 2022-06-21 01:04:05.995376
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():

    class TestRoleDefinition(RoleDefinition):
        def __init__(self):
            super(TestRoleDefinition, self).__init__()

    # Test when include_role_fqcn is True
    test_role_definition = TestRoleDefinition()

    # Test when role is not set
    assert test_role_definition.get_name() == ''

    # Test when role is set to an empty string
    test_role_definition.role = ''
    assert test_role_definition.get_name() == ''

    # Test when role is set to a string
    test_role_definition.role = 'role'
    assert test_role_definition.get_name() == 'role'

    # Test when role is set to None
    test_role_definition.role = None
    assert test_role_definition.get_name() == ''

   

# Generated at 2022-06-21 01:04:17.125084
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    result = RoleDefinition(role_basedir='./', collection_list=['ansible.builtin']).get_name()
    assert result == '.role'

    result = RoleDefinition(role_basedir='./', collection_list=['ansible.builtin']).get_name(include_role_fqcn=False)
    assert result == '.role'

    result = RoleDefinition(role_basedir='./', collection_list=['collection']).get_name()
    assert result == 'collection.role'

    result = RoleDefinition(role_basedir='./', collection_list=['collection']).get_name(include_role_fqcn=False)
    assert result == 'role'

    result = RoleDefinition(role_basedir='./', collection_list=['ansible.builtin']).get_name

# Generated at 2022-06-21 01:04:25.310864
# Unit test for method get_role_path of class RoleDefinition
def test_RoleDefinition_get_role_path():
    # Test with a mocked _loader
    from ansible.errors import AnsibleError
    from ansible.parsing.dataloader import DataLoader
    class MockLoader:
        def path_exists(self, role_path):
            if role_path == "mock_role_path":
                return True
            return False
        def get_path_by_role(self, role_name):
            if role_name == "mock_role_name":
                return "mock_role_path"
            return None
        def get_basedir(self):
            return "mock_basedir"
    mock_loader = MockLoader()

    # Test with _role_basedir: None
    role_definition = RoleDefinition(role_basedir=None, loader=mock_loader)

# Generated at 2022-06-21 01:04:37.892156
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.playbook.play import Play

    class TestVariableManager:
        def __init__(self):
            self.vars_cache = {
                'play': {
                    'local_action': True
                }
            }

        def get_vars(self, play=None):
            if play is None or play == 'play':
                return self.vars_cache['play']
            raise KeyError("No vars available for '%s'" % play)

    class TestLoader:
        def __init__(self):
            self.base_dir = '/etc/ansible/'

        def path_exists(self, path):
            return True

        def get_basedir(self):
            return self.base_dir

    # First case:
    # role_name is a string
    # role_path is

# Generated at 2022-06-21 01:04:46.451394
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():

    from ansible.playbook.play_context import PlayContext
    from ansible.utils.vars import merge_hash

    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler

    block1 = Block()
    task1 = Task()
    task2 = Task()
    handler1 = Handler()

    pc = PlayContext()

    block1._play = pc
    task1._play = pc
    task2._play = pc
    handler1._play = pc

    block1._parent = task1
    task1._parent = block1
    task2._parent = block1
    handler1._parent = block1

    test_role_def1 = RoleDefinition()
    test_role_def2 = RoleDefinition()
    test_role_def3

# Generated at 2022-06-21 01:04:58.569301
# Unit test for method load of class RoleDefinition
def test_RoleDefinition_load():
    import ansible.parsing.yaml.objects

    data = """
        name: foo
        become: yes
        become_user: root
        pre_tasks:
          - debug: msg="hello"
        tasks:
        - debug: msg="hello"
        """

    loader = DictDataLoader({})

    data = ansible.parsing.yaml.objects.AnsibleBaseYAMLObject(data, file_name='test.yaml')

    role_def = RoleDefinition.load(data, loader=loader)
    assert role_def.get_name() == 'foo'
    assert role_def.become is True
    assert role_def.become_user == 'root'
    assert len(role_def.get_role_params()) == 0

# Generated at 2022-06-21 01:05:06.359792
# Unit test for method get_role_params of class RoleDefinition
def test_RoleDefinition_get_role_params():
    def _mock():
        class Mock(object):
            def __init__(self):
                self._ds = {"var1": "val1", "var2": "val2"}

        mock = Mock()
        return mock

    role_def = RoleDefinition()
    role_def.preprocess_data = _mock
    assert role_def.get_role_params() == {'var1': 'val1', 'var2': 'val2'}

# Generated at 2022-06-21 01:05:09.681691
# Unit test for method get_role_params of class RoleDefinition
def test_RoleDefinition_get_role_params():
    role_definition = RoleDefinition()
    role_definition._role_params = {'k1': 'v1', 'k2': 'v2', 'k3': 'v3'}
    assert role_definition.get_role_params() == {'k1': 'v1', 'k2': 'v2', 'k3': 'v3'}

# Generated at 2022-06-21 01:05:28.790390
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    r = RoleDefinition(role='foo')
    assert r.role == 'foo'
    assert r.get_name() == 'foo'

    r = RoleDefinition(role='foo.bar')
    assert r.role == 'foo.bar'
    assert r.get_name() == 'foo.bar'

    r = RoleDefinition(role='foo.bar', collection_list=[AnsibleCollectionRef('somenamespace', 'somecollection')])
    assert r.role == 'foo.bar'
    assert r.get_name() == 'somecollection.foo.bar'
    assert r.get_role_collection().namespace == 'somenamespace'
    assert r.get_role_collection().collection == 'somecollection'

# Generated at 2022-06-21 01:05:31.997646
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    # Test attribute include_role_fqcn
    # FIXME: implement test when special attribute is implemented
    pass

# Generated at 2022-06-21 01:05:33.764107
# Unit test for method load of class RoleDefinition
def test_RoleDefinition_load():
    assert True


# Generated at 2022-06-21 01:05:42.923264
# Unit test for constructor of class RoleDefinition
def test_RoleDefinition():
    from ansible.playbook.play import Play

    import ansible.constants as C
    C.DEFAULT_ROLES_PATH = [ '../test/ansible/roles', '../test/ansible/roles/test' ]

    yaml_data = """
---
- hosts: localhost
  roles:
    - { role: 'test', a: 1, b: 2 }
"""
    pb = Play().load(yaml_data, variable_manager=None, loader=None)
    assert len(pb.roles) is 1
    assert pb.roles[0].role == 'test'
    assert pb.roles[0].get_role_path().endswith('test/roles/test')
    assert pb.roles[0].a == 1
    assert pb.roles

# Generated at 2022-06-21 01:05:53.365861
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.parsing.yaml import objects
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Create a dummy loader for the role definition
    class FakeLoader(object):

        def get_basedir(self):
            # Some path that does not exist
            return '/my-playbook'

        def path_exists(self, role_path):
            # If the role path is valid, path_exists returns True
            return role_path == '/my-playbook/roles/role-name'

    loader = FakeLoader()

    # Create a dummy variable manager for the role definition
    class FakeVariableManager(object):

        def __init__(self):
            self.vars = dict()

        def get_vars(self, play=None):
            return self.vars

   

# Generated at 2022-06-21 01:06:00.027821
# Unit test for method get_role_path of class RoleDefinition
def test_RoleDefinition_get_role_path():
    # define the method get_path_exists
    def get_path_exists(self, path):
        if path == u'/path/to/basedir/roles/myrole':
            return True
        elif path == u'/path/to/basedir/roles/anotherrole':
            return True
        elif path == u'/path/to/basedir/roles/yetanotherrole':
            return True
        elif path == u'/path/to/basedir/myrole':
            return True
        elif path == u'/path/to/basedir/anotherrole':
            return True
        elif path == u'/path/to/basedir/yetanotherrole':
            return True
        elif path == u'/path/to/basedir/description':
            return True

# Generated at 2022-06-21 01:06:01.791925
# Unit test for method load of class RoleDefinition
def test_RoleDefinition_load():
    raise AnsibleError("not implemented")

# Generated at 2022-06-21 01:06:12.136522
# Unit test for constructor of class RoleDefinition
def test_RoleDefinition():
    # Note: we need valid play context to have this unit test pass
    role_basedir=os.path.join(os.getcwd(),'tests','data','playbooks','roles')
    role_definition = RoleDefinition(role_basedir=role_basedir)
    role_definition.preprocess_data(os.path.join(role_basedir,'test'))
    assert role_definition.get_name() == "test"
    assert role_definition.get_role_params() == dict()
    assert role_definition.get_role_path() == os.path.join(role_basedir,'test')
    role_definition.preprocess_data(dict(role=os.path.join(role_basedir,'test')))
    assert role_definition.get_name() == "test"
    assert role_definition.get

# Generated at 2022-06-21 01:06:20.168299
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():

    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.template import Templar

    from ansible.module_utils.six import b
    from tempfile import NamedTemporaryFile
    from collections import namedtuple

    BlockArgs = namedtuple('BlockArgs', [
        'filename',
        'data',
        'vars',
        'collection_list',
        'play',
        'variable_manager',
    ])

    def _create_encrypted_file(data, vault_id='default'):
        '''
        Create a temporary file that contains the encrypted contents passed in data.
        '''

        with NamedTemporaryFile(delete=False, prefix='ansible_test_') as f:
            vault_pass = 'ansible'
            vault = AnsibleVaultEncrypted

# Generated at 2022-06-21 01:06:21.216912
# Unit test for method load of class RoleDefinition
def test_RoleDefinition_load():
    raise AnsibleError("not implemented")



# Generated at 2022-06-21 01:06:38.316625
# Unit test for method load of class RoleDefinition
def test_RoleDefinition_load():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    # Required to stop the templar's template loading, which does not work in the test env.
    for param in PlayContext.__init__.__code__.co_varnames:
        if param not in ('self', 'play_context'):
            PlayContext.__init__.__defaults__ += (None,)
    # Required to stop the templar's template loading, which does not work in the test env.
    for param in VariableManager.__init__.__code__.co_varnames:
        if param not in ('self', 'loader', 'inventory', 'variable_manager'):
            VariableManager.__init__.__defaults__ += (None,)

    # Load a role def w/o a variable

# Generated at 2022-06-21 01:06:42.565888
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    display.verbosity = 4

    role_def = RoleDefinition()
    role_def.role = 'test_role'
    new_ds = role_def.preprocess_data(ds)

    assert new_ds == ds

ds = {'role': 'test_role', 'tasks': [{'include': 'var.yml'}]}
test_RoleDefinition_preprocess_data()

# Generated at 2022-06-21 01:06:43.531504
# Unit test for method load of class RoleDefinition
def test_RoleDefinition_load():
    pass


# Generated at 2022-06-21 01:06:53.793375
# Unit test for method get_role_params of class RoleDefinition
def test_RoleDefinition_get_role_params():
    rd = RoleDefinition()
    rd.preprocess_data({'role': 'test_role', 'not_a_role_param': 'test_value'})
    assert rd.get_role_params() == {'not_a_role_param': 'test_value'}

    rd = RoleDefinition()
    rd.preprocess_data({'role': 'test_role', 'not_a_role_param': 'test_value', 'sub_role': {'another_role': {'another_role_param': 'another_value'}}})
    assert rd.get_role_params() == {'not_a_role_param': 'test_value'}

# Generated at 2022-06-21 01:07:02.171100
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.plugins.loader import find_plugin
    from ansible.playbook.play import Play
    from ansible.playbook.task.include import TaskInclude
    from ansible.template import Templar
    from ansible.vars import VariableManager

    variables = VariableManager()
    templar = Templar(loader=None, variables=variables)

    tasks = [{
        'block': None,
        'always': None,
        'any_errors_fatal': None,
        'attributes': {'name': 'test_role',
                       'collections': 'test.collection'},
        'block': None,
        'tags': [],
        'when': [],
        'consistency_type': 'metadata',
        'dunno': None,
        'defaults': []
    }]

    play

# Generated at 2022-06-21 01:07:13.146624
# Unit test for method load of class RoleDefinition
def test_RoleDefinition_load():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    ds = dict(
        role=dict(
            name="test_role",
            tags=['test_tag'],
            other_parameter=dict(key='value')
        ),
    )
    loader = DataLoader()
    variable_manager = VariableManager()

    rd = RoleDefinition.load(ds, loader=loader, variable_manager=variable_manager)

    assert rd.role == 'test_role'
    assert rd.get_name() == 'test_role'
    assert rd.tags == ['test_tag']
    assert rd.get_role_params() == dict(other_parameter=dict(key='value'))

# Generated at 2022-06-21 01:07:23.979932
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    from ansible.playbook.play import Play
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.utils.collection_loader import AnsibleCollectionRef

    # Use a context manager to substitute collection_finder.find_collections_for_path
    with AnsibleCollectionRef.find_collections_for_path.swap_registry():

        # a collection containing a role named 'skippy' would be found here
        fqcr = 'skippy'
        collection_list = [
            ('ana', '/tmp/ana', 'skippy'),
            ('bob', '/tmp/bob', 'skippy'),
        ]
        base_path = '/tmp/skippy'
        playbook = {}

        # Create a playbook include
        playbook_include = PlaybookInclude()

# Generated at 2022-06-21 01:07:24.544594
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    pass

# Generated at 2022-06-21 01:07:30.851232
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader, None, variable_manager)

    # test with a simple string
    rd = RoleDefinition(role_basedir="tests/test_data",
                        loader=loader,
                        variable_manager=variable_manager)
    rd.preprocess_data("test_role_1")
    assert isinstance(rd.get_name(), str)
    assert rd.get_name() == "test_role_1"

    # test role definition with role using collection name

# Generated at 2022-06-21 01:07:41.463478
# Unit test for method get_role_path of class RoleDefinition
def test_RoleDefinition_get_role_path():
    # FIXME:
    # This test should be moved to test/unit/plugins/lookup/
    # Also, the test should test all the possible cases
    # (role with collection name and without, role with
    # collection name that is not found on disk, etc.)
    rd = RoleDefinition()

    role_with_collection = "foo.bar"
    role_without_collection = "foo"

    # Test we get attribute role when no role has been set yet
    try:
        rd.role
    except AttributeError:
        failed = True

    assert not failed

    loader = DictDataLoader({
        'roles/foo/tasks/main.yml': '',
        'roles/foo.bar/tasks/main.yml': '',
    })

    rd._loader = loader
    rd

# Generated at 2022-06-21 01:07:57.998106
# Unit test for method get_role_params of class RoleDefinition
def test_RoleDefinition_get_role_params():
    test_loader = MockDataLoader()

    test_variable_manager = MockVariableManager()

    test_role_base = RoleDefinition(play=None, role_basedir=None, variable_manager=test_variable_manager, loader=test_loader)
    test_mapping = {"role": "mock_role", "name": "mock_name", "mock_param": "mock_value"}
    test_role_base.preprocess_data(test_mapping)

    params = test_role_base.get_role_params()

    assert params["mock_param"] == "mock_value", "Params contains a wrong value"


# Generated at 2022-06-21 01:08:08.446370
# Unit test for method get_role_params of class RoleDefinition
def test_RoleDefinition_get_role_params():
    from units.mock.loader import DictDataLoader

    # use the DictDataLoader to load the data, and create the playbook executor
    loader = DictDataLoader({
        "test_role.yml": """
        - hosts: all
          roles:
            - name: test_role
              aParam: True
              anotherParam: "foo"
        """,
    })

    play = dict(
        name="TEST PLAY",
        hosts='all',
        gather_facts='no',
        tasks=[],
        vars={},
        role_params={},
        roles=[],
    )

    # create a role definition object
    rdef = RoleDefinition()

    # set the property values
    rdef._variable_manager = None
    rdef._loader = loader
    rdef._play = play
    rdef

# Generated at 2022-06-21 01:08:14.776327
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from __main__ import display

    display.verbosity = True

    role_def = RoleDefinition()

    data = {
        'role': 'test_role'
    }

    # testing the case when the data structure is of type dict
    role_def.preprocess_data(data)

    # testing the case when the data structure is of type string
    role_def.preprocess_data('test_role')

# Generated at 2022-06-21 01:08:20.359576
# Unit test for method get_role_params of class RoleDefinition
def test_RoleDefinition_get_role_params():
    role_definition = RoleDefinition(play=None, role_basedir=None, variable_manager=None, loader=None, collection_list=None)
    role_definition.preprocess_data(dict(role_name=dict(role='test_role_name', x=1, y=2)))
    assert role_definition.get_role_params() == dict(x=1, y=2)

# Generated at 2022-06-21 01:08:26.760820
# Unit test for method get_role_params of class RoleDefinition
def test_RoleDefinition_get_role_params():
    rd = RoleDefinition()
    ds = {
        'name': 'all',
        'free1': 'param1',
        'free2': 'param2',
        'free3': 'param3',
    }
    rd.preprocess_data(ds)
    assert rd.get_role_params() == {'free1': 'param1', 'free2': 'param2', 'free3': 'param3'}

# Generated at 2022-06-21 01:08:38.958502
# Unit test for method load of class RoleDefinition
def test_RoleDefinition_load():

    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.utils.collection_loader import AnsibleCollectionRef

    # Fake play context
    context = PlayContext()
    context.connection = 'smart'
    context.remote_addr = '127.0.0.1'
    context.remote_user = 'username'
    context.password = 'secret'
    context.port = 2222

    # Fake loader
    loader = DictDataLoader({})

    # Fake variable manager
    variable_manager = DictDataManager()

    # Fake collection list

# Generated at 2022-06-21 01:08:49.821363
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    from ansible.playbook import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    display.verbosity = 3

    # unused, but required
    # FIXME: we should probably create a null inventory object for use in tests
    inventory = InventoryManager(loader=DataLoader(), sources=[])
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    play = Play.load({}, variable_manager, DataLoader())

    # the datastructure we want to test
    ds = dict(
        role="test",
        r=dict(a=1, b=2, c=3)
    )


# Generated at 2022-06-21 01:08:57.586802
# Unit test for method get_role_params of class RoleDefinition
def test_RoleDefinition_get_role_params():

    from units.mock.loader import DictDataLoader
    from ansible.vars import VariableManager

    loader = DictDataLoader({
        "role_definition_get_role_params.yml": """
        ---
        - hosts: localhost
          roles:
            - role: test_role
              some_param: 123
              another_param: "abc"
              should_be_skipped: "{{ not_real_var }}"
        """,
    })

    variable_manager = VariableManager()

    pb = Base.load(loader.load("role_definition_get_role_params.yml"), variable_manager=variable_manager, loader=loader)

    assert len(pb.get_plays()) == 1
    play = pb.get_plays()[0]
    assert play.hosts == ['localhost']


# Generated at 2022-06-21 01:09:01.673306
# Unit test for method get_role_params of class RoleDefinition
def test_RoleDefinition_get_role_params():
    rd = RoleDefinition()
    rd._role_params = {'b': 'b'}

    assert rd.get_role_params() == {'b': 'b'}
    assert rd.get_role_params() is not rd._role_params

# Generated at 2022-06-21 01:09:02.710267
# Unit test for method load of class RoleDefinition
def test_RoleDefinition_load():
    #TODO
    pass

# Generated at 2022-06-21 01:09:14.756121
# Unit test for method load of class RoleDefinition
def test_RoleDefinition_load():
    from ansible.playbook.play import Play

    # Arguments:
    #    data: dict
    #    variable_manager: VariableManager
    #    loader: DataLoader

    # Return:
    #    RoleDefinition

    # Setup
    variable_manager = None
    loader = None
    play = Play()

    ds = dict()
    rd = RoleDefinition(play, variable_manager=variable_manager, loader=loader)
    RoleDefinition.load(ds, variable_manager=variable_manager, loader=loader)


# Generated at 2022-06-21 01:09:20.987561
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    # get_name() should return a string
    role_definition = RoleDefinition()
    role_definition._role_collection = 'test_role_collection'
    role_definition.role = 'test_role'
    assert isinstance(role_definition.get_name(include_role_fqcn=True), str)
    assert isinstance(role_definition.get_name(include_role_fqcn=False), str)
    # get_name(include_role_fqcn=True) should return both values separated by '.'
    assert role_definition.get_name(include_role_fqcn=True) == 'test_role_collection.test_role'
    # get_name(include_role_fqcn=False) should return only the role attribute

# Generated at 2022-06-21 01:09:32.022319
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    def _role_definition(args, include_role_fqcn=True):
        r = RoleDefinition()
        r._role_collection = args.get('role_collection')
        r._ds = args.get('ds')
        r.role = args.get('role')
        return r.get_name(include_role_fqcn)

    assert _role_definition({'role_collection': None, 'ds': None, 'role': 'test'}) == 'test'
    assert _role_definition({'role_collection': None, 'ds': None, 'role': 'test'}, include_role_fqcn=False) == 'test'
    assert _role_definition({'role_collection': 'foo', 'ds': None, 'role': 'test'}) == 'foo.test'

# Generated at 2022-06-21 01:09:38.328247
# Unit test for constructor of class RoleDefinition
def test_RoleDefinition():
    playbook = "''"
    variable_manager = None
    loader = None
    collection_list = None
    role_definition = RoleDefinition(playbook, variable_manager, loader, collection_list)
    assert role_definition is not None
    print("passed test_RoleDefinition")

# Run unit tests
if __name__ == "__main__":
    test_RoleDefinition()

# Generated at 2022-06-21 01:09:48.456838
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():

    from ansible.parsing.yaml import objects
    from ansible.parsing.yaml.constructor import AnsibleConstructor


# Generated at 2022-06-21 01:09:59.270085
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    # unit test for preprocess_data
    # load data from file
    path = os.path.dirname(os.path.realpath(__file__))
    data = open(path + '/../../test/units/data/role_definitions.yaml', 'r').read()
    ds = AnsibleBaseYAMLObject.construct_yaml_object(data, deepcopy=True)

    # create model instance
    model = RoleDefinition(play=None, role_basedir=None, variable_manager=None, loader=None, collection_list=None)

    # compare
    expected = AnsibleMapping()
    # set the role name in the new ds
    expected['role'] = 'role_name'
    result = model.preprocess_data(ds[0])
    assert result == expected
    #

# Generated at 2022-06-21 01:10:00.376839
# Unit test for method load of class RoleDefinition
def test_RoleDefinition_load():
    raise AnsibleError("not implemented")



# Generated at 2022-06-21 01:10:10.665933
# Unit test for method get_role_params of class RoleDefinition
def test_RoleDefinition_get_role_params():
    print("Test RoleDefinition.get_role_params()")
    from ansible.playbook.play import Play
    play_obj = Play()
    role_obj = RoleDefinition()
    role_obj.set_play(play_obj)
    play_obj.vars = dict()
    variable_manager = play_obj.variable_manager
    loader = play_obj.loader
    # Test only with PLAY_DS_AS_LOADED = True
    ansible = {
        'PLAY_DS_AS_LOADED': True,
        'ROLE_DS_AS_LOADED': False
    }
    if loader:
        loader.set_basedir(C.DEFAULT_PLAYBOOK_BASEDIR)

    # Test with a simple string instead of a dict
    print("Test with simple string instead of dict")

# Generated at 2022-06-21 01:10:12.828614
# Unit test for method get_role_params of class RoleDefinition
def test_RoleDefinition_get_role_params():
    role_def = RoleDefinition()
    role_def._role_params = 'test'
    assert role_def.get_role_params() == 'test'



# Generated at 2022-06-21 01:10:18.809850
# Unit test for method get_role_params of class RoleDefinition
def test_RoleDefinition_get_role_params():

    from ansible.playbook.play import Play

    import os
    import sys
    import shutil
    libdir = os.path.join(os.path.dirname(__file__), '..', '..', 'config', 'data')
    sys.path.append(libdir)
    from data.playbooks.playbook import test_playbook_data as test_playbook_data
    from data.playbooks.role import test_role_data as test_role_data

    tmpdir = '/tmp/ansible_test_role_definition'
    role_list = list()

    # Create temporary directory with role
    shutil.rmtree(tmpdir)
    os.makedirs(tmpdir)
    os.chdir(tmpdir)
    os.makedirs('roles')

# Generated at 2022-06-21 01:10:36.696626
# Unit test for method get_role_path of class RoleDefinition
def test_RoleDefinition_get_role_path():
    loader = DictDataLoader({})
    variable_manager = VariableManager()

    role_name = 'foo'
    role_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'lib', 'ansible', 'playbooks', 'roles', 'bar')

    # this is so we can test the case where 'foo' is a name and not a path
    # (if 'foo' is a path, we have to change the role_path variable to 'foo')
    loader.set_basedir(os.path.dirname(role_path))

    role_definition = RoleDefinition(role_basedir=None, variable_manager=variable_manager, loader=loader)
    role_definition.role = role_name
    role_definition.post_validate(templar=None)



# Generated at 2022-06-21 01:10:46.237901
# Unit test for method get_role_params of class RoleDefinition
def test_RoleDefinition_get_role_params():
    playobj = "play_obj"
    loader = "loader_obj"
    role_param_key = "access_key"
    role_param_value = "role_param_value"
    role_name = "role_name"
    role_path = "role_path"
    data = {'role': role_name, role_param_key: role_param_value}
    role_def = RoleDefinition(play=playobj, loader=loader)
    role_def.preprocess_data(data)
    role_params = role_def.get_role_params()
    assert (role_params.get(role_param_key) == role_param_value)
    assert (role_params.get(role_param_key) != data.get(role_param_key))


# Generated at 2022-06-21 01:10:53.470657
# Unit test for method get_role_params of class RoleDefinition
def test_RoleDefinition_get_role_params():
   #from ansible.playbook.role_definition import RoleDefinition
   ds = dict(
        role='test_role',
        var1='value1',
        var2='value2'
    )
   rd = RoleDefinition()
   assert(rd.preprocess_data(ds) == dict(role='test_role'))
   assert(rd.get_role_params() == {'var1': 'value1', 'var2': 'value2'})

# Generated at 2022-06-21 01:10:55.922238
# Unit test for method get_role_params of class RoleDefinition
def test_RoleDefinition_get_role_params():

    role_params = dict(some_key='some_value')

    role_definition = RoleDefinition()
    role_definition._role_params = role_params

    assert role_definition.get_role_params() == role_params


# Generated at 2022-06-21 01:11:06.540591
# Unit test for method get_role_path of class RoleDefinition
def test_RoleDefinition_get_role_path():
    from ansible.playbook.play_context import PlayContext

    rd = RoleDefinition(play=None, role_basedir='/tmp/some_dir/some_subdir', variable_manager=None, loader=None, collection_list=None)
    rd.preprocess_data('some_role')
    assert rd.get_role_path() == '/tmp/some_dir/some_subdir/some_role'
    rd.preprocess_data({'role': 'some_role', 'some_param': 'some_value'})
    assert rd.get_role_path() == '/tmp/some_dir/some_subdir/some_role'
    rd.preprocess_data({'role': '/tmp/some_other_dir/some_role', 'some_param': 'some_value'})
   

# Generated at 2022-06-21 01:11:07.215059
# Unit test for method load of class RoleDefinition
def test_RoleDefinition_load():
    raise AnsibleError("not implemented")

# Generated at 2022-06-21 01:11:14.004296
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    role_def = RoleDefinition()
    role_def.role = 'httpd'
    role_def._role_collection = 'foo.bar'
    assert role_def.get_name() == 'foo.bar.httpd'
    assert role_def.get_name(include_role_fqcn=False) == 'httpd'

    role_def = RoleDefinition()
    role_def.role = 'httpd'
    role_def._role_collection = None
    assert role_def.get_name() == 'httpd'
    assert role_def.get_name(include_role_fqcn=False) == 'httpd'

# Generated at 2022-06-21 01:11:25.331081
# Unit test for method get_role_path of class RoleDefinition
def test_RoleDefinition_get_role_path():
    from ansible.parsing.yaml.objects import AnsibleMapping

    # Test case 1
    ds = AnsibleMapping({"role": "common"})
    rd = RoleDefinition()
    rd.preprocess_data(ds)
    assert rd.get_role_path() == "common"

    # Test case 2
    ds = "common"
    rd = RoleDefinition()
    rd.preprocess_data(ds)
    assert rd.get_role_path() == "common"

    # Test case 3
    ds = AnsibleMapping({"role": "geerlingguy.apache"})
    rd = RoleDefinition()
    rd.preprocess_data(ds)
    assert rd.get_role_path() == "geerlingguy.apache"

    #

# Generated at 2022-06-21 01:11:34.606532
# Unit test for method preprocess_data of class RoleDefinition
def test_RoleDefinition_preprocess_data():
    # simple name
    # yaml=role_name
    yaml = 'test_role'
    ds = RoleDefinition.preprocess_data(yaml)
    assert ds == {'role': 'test_role'}

    # with parameters
    # yaml=role_name ansible_options=role_params
    yaml = {'test_role': {'foo': 'bar'}}
    ds = RoleDefinition.preprocess_data(yaml)
    assert ds == {'role': 'test_role'}
    assert ds.get_role_params() == {'foo': 'bar'}

    # with name
    # yaml=name: role_name
    yaml = {'name': 'test_role'}
    ds = RoleDefinition.preprocess_data(yaml)

# Generated at 2022-06-21 01:11:37.656620
# Unit test for method get_role_params of class RoleDefinition
def test_RoleDefinition_get_role_params():
    role_definition = RoleDefinition()
    assert {} == role_definition.get_role_params()
    role_definition._role_params = {'a': 1}
    assert {'a': 1} == role_definition.get_role_params()

# Generated at 2022-06-21 01:11:51.462102
# Unit test for method get_role_path of class RoleDefinition
def test_RoleDefinition_get_role_path():
    test_obj = RoleDefinition()
    assert not test_obj.get_role_path()
    test_obj._role_path = "role_path"
    assert test_obj.get_role_path() == "role_path"


# Generated at 2022-06-21 01:12:00.496010
# Unit test for method load of class RoleDefinition
def test_RoleDefinition_load():

    collection_namespace = 'jctanner.test_collection'
    collection_name = 'test_collection'

    playbook_path = os.path.join(os.path.dirname(__file__), 'data/collection_role_def.yml')

    play_context = dict(
        basedir=os.path.dirname(playbook_path),
        playbook_path=playbook_path,
        collection_namespace=collection_namespace,
        collection_name=collection_name,
    )

    display.verbosity = 3

    collection_finder = lambda p: {'plugins/collections/jctanner/test_collection/':
                                  [play_context['playbook_path']]}

    loader = DataLoader()
    variable_manager = VariableManager()

# Generated at 2022-06-21 01:12:04.059012
# Unit test for constructor of class RoleDefinition
def test_RoleDefinition():
    rd = RoleDefinition()
    assert rd
    assert rd.role == ''

    rd = RoleDefinition(role_basedir='./')
    assert rd
    assert rd.role == ''
    assert rd._role_basedir == './'

# Generated at 2022-06-21 01:12:14.892821
# Unit test for method get_role_params of class RoleDefinition
def test_RoleDefinition_get_role_params():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext

    mock_loader = DataLoader()
    mock_variable_manager = VariableManager()

    # 1. role_params should be empty for all roles without params
    for role_name in ['role_name_without_params', 'role_name_with_params', 'role_with_params']:
        role_definition = RoleDefinition(play=None, role_basedir=None, variable_manager=mock_variable_manager, loader=mock_loader, collection_list=None)
        role_definition.preprocess_data(role_name)
        assert role_definition.get_role_params() == {"_role_name": role_name}

    #

# Generated at 2022-06-21 01:12:20.794576
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    role = RoleDefinition()
    role._role_collection = "alph"
    role._valid_attrs['role'] = 'alph'
    assert role.get_name(include_role_fqcn=True) == 'alph.alph'
    assert role.get_name(include_role_fqcn=False) == 'alph'
    role._role_collection = None
    assert role.get_name(include_role_fqcn=True) == 'alph'
    assert role.get_name(include_role_fqcn=False) == 'alph'

# Generated at 2022-06-21 01:12:32.316288
# Unit test for method load of class RoleDefinition
def test_RoleDefinition_load():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    playbook = Play()
    ds = dict(
        name='test_role',
        become=True,
        become_user='root',
        become_method='sudo'
    )
    role_definition = RoleDefinition.load(ds, variable_manager=VariableManager(), loader=DataLoader())

    assert isinstance(role_definition, RoleDefinition)
    assert isinstance(role_definition._play, Play)
    assert role_definition._role == 'test_role'
    assert role_definition._role_params['become'] is True
    assert role_definition

# Generated at 2022-06-21 01:12:33.949893
# Unit test for constructor of class RoleDefinition
def test_RoleDefinition():
    role_definition = RoleDefinition()

    display.display("The role definition is %s" % role_definition)

# Generated at 2022-06-21 01:12:38.981366
# Unit test for method load of class RoleDefinition
def test_RoleDefinition_load():
    # Data for testing
    data = {'role': 'test_role',
            'when': 'test_when'}

    # This method is not implemented
    try:
        RoleDefinition.load(data)
    except AnsibleError as e:
        assert 'not implemented' in e.message
        assert e.obj == data
    else:
        assert False



# Generated at 2022-06-21 01:12:39.944739
# Unit test for method load of class RoleDefinition
def test_RoleDefinition_load():
    raise AnsibleError("not implemented")

# Generated at 2022-06-21 01:12:45.749413
# Unit test for method get_role_path of class RoleDefinition
def test_RoleDefinition_get_role_path():
    from ansible.parsing.use_vault import VaultLib
    from ansible.parsing.vault import VaultEditor
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook import Play
    from ansible.playbook.role.definition import RoleDefinition
    # set up variables
    inventory = InventoryManager(loader=DataLoader(), sources='localhost,')
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    loader = DataLoader()

    results = []

    # setup all required internal objects
    vault_pass = None

# Generated at 2022-06-21 01:13:11.754708
# Unit test for method get_role_path of class RoleDefinition
def test_RoleDefinition_get_role_path():
    roledefinition = RoleDefinition()

    roledefinition._role_path = "/tmp/ansible_test/test1"
    assert roledefinition.get_role_path() == "/tmp/ansible_test/test1"

    roledefinition._role_path = "/tmp/ansible_test/test2"
    assert roledefinition.get_role_path() == "/tmp/ansible_test/test2"

# Generated at 2022-06-21 01:13:17.514754
# Unit test for method get_role_params of class RoleDefinition
def test_RoleDefinition_get_role_params():

    ds_in  = {'role': 'some_name', 'tags': ['tag2'], 'vars': {'var1': 'val1'}}
    pat_out = {'tags': ['tag2'], 'vars': {'var1': 'val1'}}
    stored = RoleDefinition.load(ds_in).get_role_params()
    assert stored == pat_out


# Generated at 2022-06-21 01:13:23.372411
# Unit test for constructor of class RoleDefinition
def test_RoleDefinition():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager.set_inventory(inventory)
    role_definition = RoleDefinition(variable_manager=variable_manager, loader=loader)
    assert role_definition is not None

# Generated at 2022-06-21 01:13:25.987221
# Unit test for method get_role_params of class RoleDefinition
def test_RoleDefinition_get_role_params():
    role_def = RoleDefinition()
    role_def._ds = "test role"
    role_def._role_params = {"a":1, "b":2}

    assert role_def.get_role_params() == {"a":1, "b":2}


# Generated at 2022-06-21 01:13:30.378961
# Unit test for method get_name of class RoleDefinition
def test_RoleDefinition_get_name():
    rd = RoleDefinition()
    rd._role_collection = None
    rd._role = "dummy"
    assert rd.get_name() == "dummy"
    rd._role_collection = "mazer.dummy"
    assert rd.get_name() == "mazer.dummy.dummy"
    assert rd.get_name(include_role_fqcn=False) == "dummy"


# backwards compat