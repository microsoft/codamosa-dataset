

# Generated at 2022-06-20 20:37:55.432419
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Create an instance of NetBSDVirtual
    netbsd_virtual_facts = NetBSDVirtual({})

    # Get virtual facts
    virtual_facts = netbsd_virtual_facts.get_virtual_facts()

    # Test for hypervisor value in virtual_facts
    assert isinstance(virtual_facts['virtualization_type'], str)

    # Test for role value in virtual_facts
    assert isinstance(virtual_facts['virtualization_role'], str)

    # Test for hypervisor_vendor value in virtual_facts
    assert isinstance(virtual_facts['virtualization_product_name'], str)

    # Test for hypervisor_version value in virtual_facts
    assert isinstance(virtual_facts['virtualization_product_version'], str)

# Generated at 2022-06-20 20:37:59.682004
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_host = NetBSDVirtual()
    result = virtual_host.get_virtual_facts()
    assert result['virtualization_type'] == 'xen'
    assert result['virtualization_role'] == 'guest'

# Generated at 2022-06-20 20:38:00.771523
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    NetBSDVirtualCollector()

# Generated at 2022-06-20 20:38:11.809570
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    def seg_fault_with_xend():
        return False

    netbsd_virtual = NetBSDVirtual({}, {}, True, seg_fault_with_xend=seg_fault_with_xend)
    netbsd_virtual_get_virtual_facts = netbsd_virtual.get_virtual_facts()

    assert 'virtualization_type' in netbsd_virtual_get_virtual_facts
    assert netbsd_virtual_get_virtual_facts['virtualization_type'] == ''

    assert 'virtualization_role' in netbsd_virtual_get_virtual_facts
    assert netbsd_virtual_get_virtual_facts['virtualization_role'] == ''

# Generated at 2022-06-20 20:38:18.631346
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    vf = NetBSDVirtual()
    dmi_sys_vendor = 'HVM domU'
    dmi_sys_product = 'Xen'
    vf.get_sysctl_outputs = lambda x: {
        'machdep.dmi.system-product': dmi_sys_product,
        'machdep.dmi.system-vendor': dmi_sys_vendor}
    virtual_facts = vf.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_product'] == dmi_sys_product
    assert virtual_facts['virtualization_vendor'] == dmi_sys_vendor

# Generated at 2022-06-20 20:38:28.334989
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    # Test with a full sysctl-mib output
    vm_guest = NetBSDVirtual({})
    assert vm_guest.get_virtual_facts() == {}

    # Test with a restricted sysctl-mib output
    vm_guest = NetBSDVirtual({
        'machdep.dmi.system-product': 'System Product'
    })
    assert vm_guest.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_type_role': '',
        'virtualization_tech': set()
    }

    # Test with a full sysctl-mib output

# Generated at 2022-06-20 20:38:31.927521
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virtual_collector = NetBSDVirtualCollector(None)
    assert isinstance(virtual_collector._fact_class, NetBSDVirtual)
    assert virtual_collector._platform == 'NetBSD'

# Generated at 2022-06-20 20:38:33.177202
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert issubclass(NetBSDVirtualCollector, VirtualCollector)

# Generated at 2022-06-20 20:38:34.416038
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virt = NetBSDVirtual()

    assert virt.platform == 'NetBSD'

# Generated at 2022-06-20 20:38:39.528873
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():

    class TestClass(object):
        def __init__(self):
            self.ansible_facts = {}

    test_obj = TestClass()
    netbsd_virtual_obj = NetBSDVirtual(test_obj)
    assert isinstance(netbsd_virtual_obj, NetBSDVirtual)

# Generated at 2022-06-20 20:38:44.711260
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual(None)
    assert netbsd_virtual


# Generated at 2022-06-20 20:38:46.384348
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virtual_collector = NetBSDVirtualCollector()
    assert virtual_collector._fact_class._platform == 'NetBSD'

# Generated at 2022-06-20 20:38:49.026755
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual()
    virtual_facts.get_virtual_facts()
    assert virtual_facts.virtual_facts


# Generated at 2022-06-20 20:38:50.108210
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector

# Generated at 2022-06-20 20:38:53.007515
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    nv = NetBSDVirtualCollector()
    assert nv

# Generated at 2022-06-20 20:38:59.628093
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Create NetBSDVirtual instance
    netbsd_virtual = NetBSDVirtual()

    # Get virtual facts
    virtual_facts = netbsd_virtual.get_virtual_facts()

    # Verify virtual_facts
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert len(virtual_facts['virtualization_tech_guest']) == 0
    assert len(virtual_facts['virtualization_tech_host']) == 0

# Generated at 2022-06-20 20:39:02.435522
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual()
    assert virtual.platform == 'NetBSD'

# Generated at 2022-06-20 20:39:05.008649
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.platform == 'NetBSD'


# Generated at 2022-06-20 20:39:09.178663
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert netbsd_virtual_collector._fact_class == NetBSDVirtual
    assert netbsd_virtual_collector._platform == 'NetBSD'

# Generated at 2022-06-20 20:39:13.232001
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual({})
    assert virtual._platform == 'NetBSD'
    assert virtual.platform == 'NetBSD'
    assert virtual.get_virtual_facts() == {
        'virtualization_role': '',
        'virtualization_type': '',
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': set()
    }

# Generated at 2022-06-20 20:39:18.399379
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virt = NetBSDVirtual()
    assert virt.platform == 'NetBSD'

# Generated at 2022-06-20 20:39:24.790280
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual = NetBSDVirtual()
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_guest'] == set(['xen'])
    assert virtual_facts['virtualization_tech_host'] == set([])


# Generated at 2022-06-20 20:39:32.483749
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    """
    See:
    https://stackoverflow.com/questions/453465/class-factory-in-python
    """
    #  get the module in question
    temp = __import__('ansible.module_utils.facts.virtual.netbsd')
    #  pull out the class we need
    vm = temp.module_utils.facts.virtual.netbsd.NetBSDVirtual()
    #  test the constructor
    assert vm is not None

# Generated at 2022-06-20 20:39:35.917516
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual = NetBSDVirtual({})
    facts = virtual.get_virtual_facts()

    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts
    assert 'virtualization_tech_guest' in facts
    assert 'virtualization_tech_host' in facts

# Generated at 2022-06-20 20:39:38.691852
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    """Test class constructor for class NetBSDVirtualCollector"""
    obj = NetBSDVirtualCollector()
    assert True is True


# Generated at 2022-06-20 20:39:48.349062
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    facter = NetBSDVirtual()
    facter._read_file = create_facter_read_file_mock("""
machdep.hypervisor=QEMU
machdep.dmi.system-product=KVM
machdep.dmi.system-vendor=KVM
""")

    # Test with QEMU
    virtual_facts = facter.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == 'kvm'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_host'] == set(['kvm'])
    assert virtual_facts['virtualization_tech_guest'] == set(['kvm'])

# Generated at 2022-06-20 20:39:50.552487
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector._platform == 'NetBSD'
    assert NetBSDVirtualCollector._fact_class == NetBSDVirtual


# Generated at 2022-06-20 20:39:53.267226
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    ne = NetBSDVirtual({})
    assert ne.platform == 'NetBSD'


# Generated at 2022-06-20 20:39:55.241130
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    nv = NetBSDVirtualCollector()
    assert nv is not None

# Generated at 2022-06-20 20:39:57.238567
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual(None)
    assert netbsd_virtual.platform == 'NetBSD'

# Generated at 2022-06-20 20:40:06.695474
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virtual_facts_collector = NetBSDVirtualCollector()
    assert virtual_facts_collector._platform == 'NetBSD'
    assert virtual_facts_collector._fact_class == NetBSDVirtual

# Generated at 2022-06-20 20:40:15.915066
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    import json
    x =  NetBSDVirtualCollector().collect()
    assert isinstance(x, dict)
    assert 'ansible_facts' in x
    assert 'virtualization_type' in x['ansible_facts']
    assert x['ansible_facts']['virtualization_type'] in ['', 'virtualbox', 'xen']
    assert 'virtualization_role' in x['ansible_facts']
    assert x['ansible_facts']['virtualization_role'] in ['', 'guest', 'host']
    assert 'virtualization_tech_guest' in x['ansible_facts']
    assert isinstance(x['ansible_facts']['virtualization_tech_guest'], set)
    assert 'virtualization_tech_host' in x['ansible_facts']

# Generated at 2022-06-20 20:40:17.678730
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual(None, None)
    assert virtual.platform == 'NetBSD'


# Generated at 2022-06-20 20:40:24.296134
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    v = NetBSDVirtual()
    vs = v.get_virtual_facts()
    assert 'virtualization_type' in vs
    assert 'virtualization_role' in vs
    assert 'virtualization_tech_guest' in vs
    assert 'virtualization_tech_host' in vs
    assert vs['virtualization_type'] != ''
    assert vs['virtualization_role'] != ''

# Generated at 2022-06-20 20:40:25.802642
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual_facts = NetBSDVirtual()
    assert netbsd_virtual_facts._platform == 'NetBSD'

# Generated at 2022-06-20 20:40:38.123311
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    os.environ['PATH'] = '/usr/sbin:/sbin:' + os.environ['PATH']

    # Test values for output from sysctl
    sysctl_output = {
        'machdep.dmi.system-product': 'KVM',
        'machdep.dmi.system-vendor': 'KVM',
        'machdep.hypervisor': 'KVM',
    }

    # Test values for os.path.exists
    os_path_exists = {
        '/dev/xencons': False,
    }

    # Test values for return data

# Generated at 2022-06-20 20:40:41.259370
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():

    netbsdvirtual_obj = NetBSDVirtual()
    assert netbsdvirtual_obj
    assert netbsdvirtual_obj.platform == 'NetBSD'

# Generated at 2022-06-20 20:40:48.020814
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert netbsd_virtual_collector._platform == 'NetBSD', (
        'The class NetBSDVirtualCollector should be having platform as NetBSD instead of {}'.format(
            netbsd_virtual_collector._platform)
    )
    assert netbsd_virtual_collector._fact_class.platform == 'NetBSD', (
        'The class NetBSDVirtualCollector should be having fact_class.platform as NetBSD instead of {}'.format(
            netbsd_virtual_collector._fact_class.platform)
    )

# Generated at 2022-06-20 20:40:48.546832
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    assert NetBSDVirtual()

# Generated at 2022-06-20 20:40:59.240893
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    def mocked_get_file_content(path):
        content = {
            '/kern/bootfile': 'netbsd',
            '/usr/sbin/sysctl': 'netbsd',
            '/kern/ostype': 'netbsd',
            '/kern/osrelease': 'netbsd',
            '/var/db/virtinfo.db': 'netbsd',
            '/kern/hv_support.xen': '1',
            '/kern/hv_support.vmm': '1'
        }
        return content[path]


# Generated at 2022-06-20 20:41:15.616413
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual = NetBSDVirtualCollector()
    assert netbsd_virtual._platform == 'NetBSD'

# Generated at 2022-06-20 20:41:18.750067
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    """Test NetBSDVirtualCollector"""

    obj = NetBSDVirtualCollector()
    assert obj.default_collectors == ['NetBSDVirtual', 'SysctlVirtual']

# Generated at 2022-06-20 20:41:28.167122
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Test with empty facts
    fake_platform_sysctl_cmd = []
    setattr(NetBSDVirtualCollector, '_platform_sysctl_cmd', fake_platform_sysctl_cmd)
    virtual_facts = NetBSDVirtualCollector().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()

    # Test with valid facts
    fake_platform_sysctl_cmd = ['machdep.dmi.system-product=Bochs', 'machdep.dmi.system-vendor=Bochs', 'machdep.hypervisor=VT-x']

# Generated at 2022-06-20 20:41:31.312073
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    nvirt = NetBSDVirtual()
    assert nvirt.platform == 'NetBSD'
    assert nvirt.get_virtual_facts()['virtualization_type'] == ''

# Generated at 2022-06-20 20:41:35.614653
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    NoNetBSDVirtualCollector = NetBSDVirtualCollector(None)
    assert NoNetBSDVirtualCollector.get_all_facts()['virtualization_type'].startswith('(')

# Generated at 2022-06-20 20:41:43.146258
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # test for virt_product
    def test_virt_product(f, expected_virt_type, expected_virt_role):
        virt_facts = f.get_virtual_facts()
        assert virt_facts['virtualization_type'] == expected_virt_type
        assert virt_facts['virtualization_role'] == expected_virt_role
        assert isinstance(virt_facts['virtualization_tech_guest'], set)
        assert isinstance(virt_facts['virtualization_tech_host'], set)

    # test for virt_vendor
    def test_virt_vendor(f, expected_virt_type, expected_virt_role):
        virt_facts = f.get_virtual_facts()
        assert virt_facts['virtualization_type'] == expected_virt_type

# Generated at 2022-06-20 20:41:46.719145
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
     collector = NetBSDVirtualCollector()
     assert collector.platform == NetBSDVirtualCollector._platform
     assert collector._fact_class.platform == NetBSDVirtualCollector._platform

# Generated at 2022-06-20 20:41:56.234168
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    sysctl = {'machdep.dmi.system-product': "QEMU Standard PC (i440FX + PIIX, 1996)",
              'machdep.dmi.system-vendor': "No Enclosure",
              'machdep.hypervisor': "QEMU"}

    netbsd_virtual_collector = NetBSDVirtualCollector(sysctl)
    virtual_facts_output = netbsd_virtual_collector.collect()['ansible_facts']['ansible_virtualization_facts']

    assert virtual_facts_output['virtualization_type'] == 'hvm'
    assert virtual_facts_output['virtualization_role'] == 'guest'
    assert virtual_facts_output['virtualization_tech_guest'] == {'hvm'}

# Generated at 2022-06-20 20:41:59.116465
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    nv = NetBSDVirtualCollector()
    assert nv.platform == "NetBSD"
    assert nv.fact_class == NetBSDVirtual


# Generated at 2022-06-20 20:42:03.466127
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert(netbsd_virtual_collector._fact_class == NetBSDVirtual)
    assert(netbsd_virtual_collector._platform == 'NetBSD')

# Generated at 2022-06-20 20:42:35.668553
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual({})
    assert netbsd_virtual.platform == 'NetBSD'

# Generated at 2022-06-20 20:42:38.783036
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    obj = NetBSDVirtualCollector()
    assert hasattr(obj, '_platform')
    assert hasattr(obj, '_fact_class')
    assert obj._platform == 'NetBSD'
    assert obj._fact_class == NetBSDVirtual

# Generated at 2022-06-20 20:42:46.201187
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Set information values, which is used in the testing process
    sysctl_openvz_values = {
        'machdep.dmi.system-vendor': 'OpenVZ',
        'machdep.dmi.system-product': '',
        'machdep.hypervisor': '',
        'machdep.dmi.system-product': '',
        'machdep.dmi.system-vendor': '',
    }


# Generated at 2022-06-20 20:42:57.219369
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    module_name = 'ansible_netbsd_virtual_facts'
    module_path = 'ansible.module_utils.facts.virtual.netbsd'
    module_args = ''

    m = VirtualCollector._create_module_from(module_name, module_path, module_args)
    vm = NetBSDVirtual(m)
    vm.collect()

    # Test that the dictionary is not empty
    assert bool(vm.data.get('virtualization_type')) == True

    # Test that the dictionary has the items we expect
    keys = ['virtualization_type', 'virtualization_role', 'virtualization_tech_guest', 'virtualization_tech_host']
    for key in keys:
        assert bool(vm.data.get(key)) == True

# Generated at 2022-06-20 20:43:00.590865
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual()
    assert virtual.platform == 'NetBSD'

# Generated at 2022-06-20 20:43:10.350873
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    raw_facts = dict()
    virtual_facts = dict()

    import sys
    if sys.version_info[0] > 2:
        basestring = str
    elif sys.version_info[0] < 2:
        basestring = basestring

    virtual_facts['virtualization_type'] = ''
    virtual_facts['virtualization_role'] = ''
    virtual_facts['virtualization_tech_guest'] = set()
    virtual_facts['virtualization_tech_host'] = set()

    # Test for unimplemented features
    # virtual_facts['virtualization_system'] = 'unknown'
    # virtual_facts['virtualization_systems'] = 'unknown'

    # NetBSDVirtual subclasses VirtualSysctlDetectionMixin
    # Test that NetBSDVirtual._sysctl_virtual_sysctl_technologies

# Generated at 2022-06-20 20:43:12.513644
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    module = NetBSDVirtual()
    assert module.platform == 'NetBSD'

# Generated at 2022-06-20 20:43:23.445724
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual = NetBSDVirtual()

    # Create dict to pass as sysctl_commands.
    sysctl_commands = {}
    sysctl_commands['machdep.dmi.system-product'] = 'VirtualBox'
    sysctl_commands['machdep.dmi.system-vendor'] = 'Oracle Corporation'
    sysctl_commands['machdep.dmi.system-version'] = '1.2-3'
    sysctl_commands['machdep.hypervisor'] = 'vbox'
    virtual.sysctl_commands = sysctl_commands

    # Call the method to test and check result.
    facts = virtual.get_virtual_facts()
    assert facts['virtualization_type'] == 'VirtualBox'
    assert facts['virtualization_role'] == 'guest'
    assert facts

# Generated at 2022-06-20 20:43:31.903975
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    facts_dict = {
        'machdep.dmi.system-product': 'VirtualBox',
        'machdep.dmi.system-vendor': 'Oracle Corporation',
        'machdep.hypervisor': 'Unknown',
    }

    klass = NetBSDVirtual({'ansible_facts': facts_dict})
    virtual_facts = klass.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == 'virtualbox'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert 'virtualbox' in virtual_facts['virtualization_tech_guest']
    assert 'virtualbox' in virtual_facts['virtualization_tech_host']
    assert len(virtual_facts['virtualization_tech_guest']) == 1

# Generated at 2022-06-20 20:43:41.053669
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():

    from ansible.module_utils.facts.virtual.netbsd import NetBSDVirtual
    netbsd_virtual = NetBSDVirtual()

    # Test for NetBSD host with Xen hypervisor
    netbsdvirtualfakefacts = {
        'machdep.dmi.system-product': '',
        'machdep.dmi.system-vendor': '',
        'machdep.hypervisor': 'Xen'
    }
    facts = netbsd_virtual.get_virtual_facts(netbsdvirtualfakefacts)

    assert facts['virtualization_type'] == 'xen'
    assert facts['virtualization_role'] == 'guest'
    assert 'xen' in facts['virtualization_tech_guest']

    # Test for NetBSD host with no hypervisor

# Generated at 2022-06-20 20:44:57.869453
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector._platform == 'NetBSD'
    assert NetBSDVirtualCollector._fact_class == NetBSDVirtual


# Generated at 2022-06-20 20:44:58.386305
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    NetBSDVirtual()

# Generated at 2022-06-20 20:45:00.625654
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    vc = NetBSDVirtualCollector()
    assert vc._platform == 'NetBSD'
    assert vc._fact_class == NetBSDVirtual
    assert vc._fact_class.platform == 'NetBSD'
    assert isinstance(vc._fact_class(), NetBSDVirtual)
    assert vc._first_available == [NetBSDVirtual]

# Generated at 2022-06-20 20:45:03.630518
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert issubclass(NetBSDVirtualCollector, VirtualCollector)

# Generated at 2022-06-20 20:45:05.399330
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.platform == 'NetBSD'

# Generated at 2022-06-20 20:45:06.598924
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert issubclass(NetBSDVirtualCollector, VirtualCollector)


# Generated at 2022-06-20 20:45:10.471029
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():

    netbsd_virtual_facts = NetBSDVirtual()
    virtual_facts = netbsd_virtual_facts.get_virtual_facts()
    print("Virtual facts: " + str(virtual_facts))

# Generated at 2022-06-20 20:45:15.217947
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual = NetBSDVirtual()
    sysctl = {'machdep.dmi.system-product': '',
        'machdep.dmi.system-vendor': ''}
    expected_facts = {'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }
    virtual_facts = virtual.get_virtual_facts(sysctl)
    assert expected_facts == virtual_facts

# Generated at 2022-06-20 20:45:26.148935
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Test with fully populated sysctl data
    sysctl_output = {
        'machdep.dmi.system-product': 'VirtualBox',
        'machdep.dmi.system-vendor': 'innotek GmbH',
        'machdep.hypervisor': 'VirtualBox'
    }
    expected_output = {
        'virtualization_type': 'VirtualBox',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['VirtualBox']),
        'virtualization_tech_host': set(['VirtualBox'])
    }
    actual_output = NetBSDVirtual(sysctl_output).get_virtual_facts()
    assert actual_output == expected_output

    # Test with no Xen console

# Generated at 2022-06-20 20:45:37.344186
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():

    # Init the class
    virtual_facts = NetBSDVirtual()

    # Define the output of the virtual_facts.get_virtual_facts method
    # when machdep.hypervisor == 'Xen HVM'
    output = {
        'virtualization_type': 'xen',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': {
            'xen'
        },
        'virtualization_tech_host': {
            'xen'
        }
    }

    # Set the output of the machdep.hypervisor sysctl
    virtual_facts.set_sysctl_output({'machdep.hypervisor': 'Xen HVM'})

    # Set the output of the machdep.dmi.system-product sysctl