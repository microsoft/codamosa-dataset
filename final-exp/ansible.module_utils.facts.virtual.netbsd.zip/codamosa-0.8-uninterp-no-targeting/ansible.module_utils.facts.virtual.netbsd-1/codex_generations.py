

# Generated at 2022-06-20 20:37:48.134684
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    instance = NetBSDVirtualCollector()
    assert(instance._platform == 'NetBSD')
    assert(instance._fact_class == NetBSDVirtual)


# Generated at 2022-06-20 20:37:49.892579
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    obj = NetBSDVirtualCollector()
    assert isinstance(obj, NetBSDVirtualCollector)


# Generated at 2022-06-20 20:37:51.663776
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    obj = NetBSDVirtualCollector()
    assert obj.platform == "NetBSD"


# Generated at 2022-06-20 20:37:57.832291
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():

    virtual = NetBSDVirtual({})
    virtual.platform = 'NetBSD'

    assert virtual.get_virtual_facts() == {
            'virtualization_type': '',
            'virtualization_role': '',
            'virtualization_technologies': set(['virt_product', 'virt_vendor'])
            }

    assert virtual.get_virtual_facts()['virtualization_type'] == ''

    assert virtual.get_virtual_facts()['virtualization_role'] == ''

    assert virtual.get_virtual_facts()['virtualization_technologies'] == set(['virt_product', 'virt_vendor'])



# Generated at 2022-06-20 20:38:00.156720
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virtual_data = NetBSDVirtualCollector()
    assert virtual_data.platform == 'NetBSD'

# Generated at 2022-06-20 20:38:12.400709
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    facts = {'kernel': 'NetBSD'}
    fake_sysctl = [
        ('machdep.dmi.system-product', 'KVM'),
        ('machdep.dmi.system-vendor', 'QEMU'),
        ('machdep.hypervisor', 'KVM'),
        ('machdep.cpu.features', '1,7-10,14-17,20,22,25-27,30,32,37-39,42-44,46,48,52,54-58,63')
    ]

    virtual = NetBSDVirtual(collector=None, facts=facts, sysctl_data=fake_sysctl)
    virtual_facts = virtual.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == 'kvm'
    assert virtual_facts['virtualization_role']

# Generated at 2022-06-20 20:38:24.569270
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    # Test sysctl module with correct sysctl command
    netbsd_virtual.sysctl_cmd = "/sbin/sysctl machdep.dmi.system-product"
    # Test sysctl module with faulty sysctl command
    netbsd_virtual.sysctl_cmd = "/sbin/sysctl machdep.dmi.system-produc"
    # Test sysctl module with faulty sysctl command
    netbsd_virtual.sysctl_cmd = "/sbin/sysctl machdep.dmi.system-product"
    # Test sysctl module with faulty sysctl command
    netbsd_virtual.sysctl_cmd = "/sbin/sysctl machdep.dmi.system-produc"
    # Test sysctl module with correct sysctl command
    netbsd_virtual.sysctl

# Generated at 2022-06-20 20:38:28.357197
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsdvirtual = NetBSDVirtual()
    assert netbsdvirtual.get_virtual_facts()['virtualization_type'] == ''
    assert netbsdvirtual.get_virtual_facts()['virtualization_role'] == ''

# Generated at 2022-06-20 20:38:31.055538
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.platform == 'NetBSD'


# Generated at 2022-06-20 20:38:32.533856
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    result = NetBSDVirtualCollector.collect()
    assert type(result) == dict

# Generated at 2022-06-20 20:38:37.048005
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert netbsd_virtual_collector.fact_class is not None

# Generated at 2022-06-20 20:38:38.893892
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    v = NetBSDVirtual()
    assert v.platform == 'NetBSD'

# Generated at 2022-06-20 20:38:42.818759
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual = NetBSDVirtualCollector()
    assert netbsd_virtual._platform == 'NetBSD'
    assert isinstance(netbsd_virtual._fact_class, NetBSDVirtual)

# Generated at 2022-06-20 20:38:50.096617
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual_get_virtual_facts_return_value = NetBSDVirtual().get_virtual_facts()
    assert 'virtualization_type' in netbsd_virtual_get_virtual_facts_return_value
    assert 'virtualization_role' in netbsd_virtual_get_virtual_facts_return_value
    assert 'virtualization_tech_guest' in netbsd_virtual_get_virtual_facts_return_value
    assert 'virtualization_tech_host' in netbsd_virtual_get_virtual_facts_return_value

# Generated at 2022-06-20 20:38:53.628450
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virtual_collector = NetBSDVirtualCollector()
    assert virtual_collector.get_platform() == 'NetBSD'

# Generated at 2022-06-20 20:38:55.753347
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    collector = NetBSDVirtualCollector()
    assert collector.platform == 'NetBSD'
    assert collector.fact_class == NetBSDVirtual

# Generated at 2022-06-20 20:39:05.789294
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    test_data_dir = os.path.join(os.path.dirname(__file__), 'unit/data/')

    # Test NetBSD 6.1
    sysctl_file_611 = 'sysctl_netbsd_611'
    sysctl_input_611 = open(test_data_dir + sysctl_file_611).read()
    sysctl_reader = open(test_data_dir + sysctl_file_611, 'r')
    sysctl_reader.seek(0)
    v = NetBSDVirtual(sysctl_reader)

# Generated at 2022-06-20 20:39:07.220322
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    NetBSDVirtualCollector()

# Generated at 2022-06-20 20:39:12.319592
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual = NetBSDVirtualCollector({}, {}).collect()[0]
    virtual_facts = virtual.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'

    assert virtual_facts['virtualization_tech_guest'] == {'xen'}
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-20 20:39:18.535203
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virtual_collector = NetBSDVirtualCollector()
    virtual_collector.collect()
    virtual_facts = virtual_collector.get_facts()['ansible_facts']

    # Test "virtual" facts as keys
    assert set(virtual_facts.keys()) == set(['virtual'])

    # Test "virtualization_type"
    assert virtual_facts['virtual']['virtualization_type'].__class__ == str

    # Test "virtualization_role"
    assert virtual_facts['virtual']['virtualization_role'].__class__ == str

    # Test "virtualization_system"
    assert virtual_facts['virtual']['virtualization_system'].__class__ == str

    # Test "virtualization_host_type"
    assert virtual_facts['virtual']['virtualization_host_type'].__class

# Generated at 2022-06-20 20:39:26.115212
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd = NetBSDVirtual(None)
    assert netbsd.platform == 'NetBSD'

# Generated at 2022-06-20 20:39:28.764765
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virt = NetBSDVirtual()


# Generated at 2022-06-20 20:39:37.789981
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual = NetBSDVirtual(module=None)
    netbsd_virtual_facts = netbsd_virtual.get_virtual_facts()
    assert netbsd_virtual_facts == {
        'virtualization_type': '', 'virtualization_role': '',
        'virtualization_system': '', 'virtualization_product': '',
        'virtualization_product_version': '',
        'virtualization_product_auto': '',
        'virtualization_product_vendor': '',
        'virtualization_product_auto_vendor': '',
        'virtualization_tech_guest': set(), 'virtualization_tech_host': set()
    }

# Generated at 2022-06-20 20:39:41.294691
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    obj = NetBSDVirtualCollector()
    assert obj._platform == 'NetBSD'
    assert obj._fact_class == NetBSDVirtual

# Generated at 2022-06-20 20:39:43.207015
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virtual_collector = NetBSDVirtualCollector()
    assert virtual_collector._fact_class.platform == 'NetBSD'

# Generated at 2022-06-20 20:39:44.560158
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert(NetBSDVirtualCollector._platform == 'NetBSD')

# Generated at 2022-06-20 20:39:53.267199
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():

    from ansible.module_utils.facts.virtual.netbsd import NetBSDVirtual
    from ansible.module_utils.facts.virtual.sysctl import VirtualSysctlDetectionMixin

    NetBSDVirtual.detect_virt_vendor = lambda self, path: {'virtualization_type': 'vendor',
                                                           'virtualization_role': 'guest',
                                                           'virtualization_tech_guest': {},
                                                           'virtualization_tech_host': {'virt_vendor'}}


# Generated at 2022-06-20 20:40:05.314482
# Unit test for method get_virtual_facts of class NetBSDVirtual

# Generated at 2022-06-20 20:40:06.650433
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector._platform == 'NetBSD'

# Generated at 2022-06-20 20:40:08.278144
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual({})
    assert virtual is not None


# Generated at 2022-06-20 20:40:16.682465
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    vc = NetBSDVirtualCollector()
    assert vc._platform == 'NetBSD'


# Generated at 2022-06-20 20:40:18.946451
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert isinstance(NetBSDVirtualCollector('/usr/bin/uname'), NetBSDVirtualCollector)

# Generated at 2022-06-20 20:40:30.318478
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():

    v = NetBSDVirtual()

    # If no virtualization is detected, all values should be returned as empty
    assert v.get_virtual_facts() == {
        'virtualization_role': '',
        'virtualization_type': '',
        'virtualization_system': '',
        'virtualization_technologies': [],
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }

    v.sysctl_sysvendor = 'Xen'
    v.sysctl_hypervisor = 'Xen'
    v.sysctl_product = 'HVM domU'
    v.sysctl_xen_major = '3'
    v.sysctl_xen_minor = '0'
    v.sysctl_xen_extra = ''

    # Test Xen

# Generated at 2022-06-20 20:40:41.987543
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual()
    facts_platform = virtual_facts.get_virtual_facts()['platform']
    facts_virtualization_type = virtual_facts.get_virtual_facts()['virtualization_type']
    facts_virtualization_role = virtual_facts.get_virtual_facts()['virtualization_role']
    facts_virtualization_tech_host = virtual_facts.get_virtual_facts()['virtualization_tech_host']
    facts_virtualization_tech_guest = virtual_facts.get_virtual_facts()['virtualization_tech_guest']

    assert facts_platform == 'NetBSD'
    assert facts_virtualization_type == ''
    assert facts_virtualization_role == ''
    assert facts_virtualization_tech_host == 'hyperv'
    assert facts_virtualization_tech_guest

# Generated at 2022-06-20 20:40:43.955331
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    obj = NetBSDVirtualCollector()
    assert obj._platform == 'NetBSD'
    assert obj._fact_class == NetBSDVirtual


# Generated at 2022-06-20 20:40:53.821550
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    import sys
    sys.modules['ansible_netbsd_virtual_facts'] = __import__('ansible.module_utils.facts.virtual.netbsd')
    NetBSD = __import__('ansible.module_utils.facts.virtual.netbsd').ansible_netbsd_virtual_facts.NetBSDVirtual()

    # setting up possible outputs from sysctl
    os_release_output = (
        'NetBSD 8.0_BETA (GENERIC)',
        'NetBSD 8.1 (GENERIC)')

# Generated at 2022-06-20 20:40:54.653718
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    NetBSDVirtualCollector()

# Generated at 2022-06-20 20:41:01.672835
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virt_facts = NetBSDVirtual()

    # Test get_virtual_facts() with valid sysctl_values and valid dmi values
    sysctl_values = {'machdep.dmi.system-product': 'VirtualBox',
                     'machdep.dmi.system-vendor': 'innotek GmbH',
                     'machdep.hypervisor': ''}
    dmi_values = {'vendor': 'innotek GmbH', 'product': 'VirtualBox'}
    virtual_facts = virt_facts.get_virtual_facts(sysctl_values, dmi_values)

# Generated at 2022-06-20 20:41:04.265046
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    bsd = NetBSDVirtual()
    virtual_facts = bsd.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == 'xen'

# Generated at 2022-06-20 20:41:12.886396
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    fake_pipe = FakePipe([
        # machdep.dmi.system-vendor
        "QEMU",
        # machdep.hypervisor
        "Xen",
        # machdep.dmi.system-product
        "Standard PC (Q35 + ICH9, 2009)"
    ])

    expected_data = {
        'virtualization_type': 'xen',
        'virtualization_role': 'guest',
        'virtualization_product': 'Standard PC (Q35 + ICH9, 2009)',
        'virtualization_vendor': 'QEMU',
        'virtualization_tech_guest': {'xen'}
    }

    virtual = NetBSDVirtualCollector(fake_pipe, 'linux')
    assert virtual.get_virtual_facts() == expected_data

# Generated at 2022-06-20 20:41:31.064000
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtualCollector({})
    assert virtual_facts.platform == 'NetBSD'
    assert virtual_facts.facts['virtualization_type'] == ''
    assert virtual_facts.facts['virtualization_role'] == ''

# Generated at 2022-06-20 20:41:34.151585
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual({})
    assert virtual.platform == 'NetBSD'

# Generated at 2022-06-20 20:41:36.667725
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd = NetBSDVirtual()
    assert netbsd.platform == 'NetBSD'
    assert netbsd.get_virtual_facts() == {}


# Generated at 2022-06-20 20:41:39.459055
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual = NetBSDVirtual()
    virtual_facts = virtual.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''

# Generated at 2022-06-20 20:41:42.257417
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert netbsd_virtual_collector._fact_class == NetBSDVirtual

# Generated at 2022-06-20 20:41:47.308795
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    facts = netbsd_virtual_collector.collect()
    assert facts['virtualization_type'] == 'NetBSD'
    assert facts['virtualization_type_full'] == 'NetBSD full'

# Generated at 2022-06-20 20:41:55.416083
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    # Assert initialization of virtualization keys
    assert netbsd_virtual.virtual_subsystem == 'kern.sysctl.system_subsystem'
    assert netbsd_virtual.product_subsystem == 'machdep.dmi.system-product'
    assert netbsd_virtual.product_subsystem_legacy == 'machdep.hypervisor'
    assert netbsd_virtual.vendor_subsystem == 'machdep.dmi.system-vendor'
    assert netbsd_virtual.vendor_subsystem_legacy == 'machdep.hypervisor'

# Generated at 2022-06-20 20:41:59.587603
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    collector = NetBSDVirtualCollector()
    assert collector.platform == "NetBSD"
    assert collector._fact_class.platform == "NetBSD"
    assert collector._fact_class.get_virtual_facts()['virtualization_type'] != ""


# Generated at 2022-06-20 20:42:06.693863
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual_facts = NetBSDVirtual()
    netbsd_virtual_facts.get_virtual_facts()
    assert netbsd_virtual_facts.facts['virtualization_type'] == 'xen'
    assert netbsd_virtual_facts.facts['virtualization_role'] == 'guest'
    assert netbsd_virtual_facts.facts['virtualization_tech_guest'] == {'xen'}

# Generated at 2022-06-20 20:42:17.486972
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Set up a test object
    test_obj = NetBSDVirtual()

    # Populate a dictionary with test values
    kern_vals = {
        'machdep.dmi.system-product': 'VMware Virtual Platform',
        'machdep.dmi.system-vendor': 'VMware, Inc.',
        'machdep.dmi.system-version': 'None',
        'machdep.hypervisor': 'None'
    }

    # Set up a test environment which extends a real environment
    # Modelled after the code in facts/__init__.py: get_platform_facts()
    env_path = os.path.realpath(os.path.dirname(__file__))  # Route to current file

# Generated at 2022-06-20 20:42:51.588790
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd = NetBSDVirtualCollector()
    assert netbsd.platform == 'NetBSD'
    assert isinstance(netbsd._fact_class, NetBSDVirtual)


# Generated at 2022-06-20 20:42:57.335851
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    mock_module = MockModule()
    mock_module.params = {}
    netbsd_virtual = NetBSDVirtual(module=mock_module)
    facts_dict = netbsd_virtual.get_virtual_facts()
    assert facts_dict['virtualization_type'] == 'VMware Virtual Platform'
    assert facts_dict['virtualization_role'] == 'guest'


# Generated at 2022-06-20 20:43:05.608563
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    del os.environ['PYTHONPATH']  # causes module to fail
    netbsd_virtual = NetBSDVirtual()
    virtual_facts = netbsd_virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert 'xen' in virtual_facts['virtualization_tech_guest']

# Generated at 2022-06-20 20:43:06.327088
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    instance = NetBSDVirtualCollector()
    assert isinstance(instance.collect(), dict)

# Generated at 2022-06-20 20:43:06.808784
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # TODO
    pass

# Generated at 2022-06-20 20:43:14.290025
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual(module=None)
    # Test whether the 'machdep.dmi.system-product' key is present in facts_from_cmd string.
    assert isinstance(virtual_facts.FACTS_FROM_CMD, str)
    assert 'machdep.dmi.system-product' in virtual_facts.FACTS_FROM_CMD
    # Test whether the 'machdep.dmi.system-vendor' key is present in facts_from_cmd string.
    assert isinstance(virtual_facts.FACTS_FROM_CMD, str)
    assert 'machdep.dmi.system-vendor' in virtual_facts.FACTS_FROM_CMD
    # Test whether the 'machdep.hypervisor' key is present in facts_from_cmd string

# Generated at 2022-06-20 20:43:24.698264
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():

    # Set up mocks
    class NetBSDVirtual_Mock(NetBSDVirtual):
        def detect_virt_product(self, sysctl):
            return {'virtualization_type': '', 'virtualization_tech_guest': [], 'virtualization_tech_host': []}
        def detect_virt_vendor(self, sysctl):
            return {'virtualization_type': '', 'virtualization_tech_guest': [], 'virtualization_tech_host': []}

    # Test case: empty
    mock = NetBSDVirtual_Mock()
    virtual_facts = mock.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts

# Generated at 2022-06-20 20:43:27.553254
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual().get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts

# Generated at 2022-06-20 20:43:33.841121
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    test_object = NetBSDVirtual(module=None)

    test_object.sysctl = {
        'machdep.dmi.system-product': 'KVM',
        'machdep.dmi.system-vendor': 'Red Hat',
        'machdep.hypervisor': 'KVM'
    }

    virtual_facts = test_object.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == 'kvm', \
        "Virtualization type is not kvm, virtualization_type: " + \
        virtual_facts['virtualization_type']

    assert virtual_facts['virtualization_role'] == 'guest', \
        "Virtualization role is not guest, virtualization_role: " + \
        virtual_facts['virtualization_role']

# Generated at 2022-06-20 20:43:35.769069
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts_obj = NetBSDVirtual(None)

    assert virtual_facts_obj.platform == 'NetBSD'



# Generated at 2022-06-20 20:44:54.017156
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    nbv = NetBSDVirtual()
    assert nbv.platform.startswith('NetBSD')
    assert nbv.virtualization_type == ''
    assert nbv.virtualization_role == ''

# Generated at 2022-06-20 20:44:56.218772
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_obj = NetBSDVirtual()
    assert virtual_obj.virtualization_type == ''
    assert virtual_obj.virtualization_role == ''


# Generated at 2022-06-20 20:44:57.078399
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    v = NetBSDVirtual({}, {})
    assert v.platform == 'NetBSD'

# Generated at 2022-06-20 20:44:59.558135
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virt = NetBSDVirtualCollector().collect()

    assert(virt['virtualization_type'] != 'None')
    assert(virt['virtualization_role'] != 'None')
    assert(virt['virtualization_type'] != '')
    assert(virt['virtualization_role'] != '')

# Generated at 2022-06-20 20:45:00.649376
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    obj = NetBSDVirtualCollector()
    assert (obj._platform == 'NetBSD')

# Generated at 2022-06-20 20:45:03.620294
# Unit test for method get_virtual_facts of class NetBSDVirtual

# Generated at 2022-06-20 20:45:05.644415
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
   virtual_collector = NetBSDVirtualCollector
   assert virtual_collector(None)._fact_class.platform == 'NetBSD'

# Generated at 2022-06-20 20:45:08.845633
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    nvc = NetBSDVirtualCollector()
    assert nvc._fact_class == NetBSDVirtual
    assert nvc._platform == 'NetBSD'



# Generated at 2022-06-20 20:45:11.962338
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    # NetBSD's virtualization_type should be empty
    assert netbsd_virtual.data['virtualization_type'] == ''
    assert netbsd_virtual.data['virtualization_role'] == ''

# Generated at 2022-06-20 20:45:14.022712
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual = NetBSDVirtualCollector()
    assert netbsd_virtual.platform == 'NetBSD'
    assert netbsd_virtual._fact_class == NetBSDVirtual