

# Generated at 2022-06-20 20:37:48.182726
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()

    assert netbsd_virtual.platform == 'NetBSD', 'Test platform field'


# Generated at 2022-06-20 20:37:53.289979
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():

    # Test NetBSDVirtual()
    virtual_obj = NetBSDVirtual()

    assert virtual_obj.platform == "NetBSD"
    assert virtual_obj.virtualization_role == ""
    assert virtual_obj.virtualization_type == ""
    assert virtual_obj.virt_what == ""
    assert virtual_obj.virtualization_tech_host == set()
    assert virtual_obj.virtualization_tech_guest == set()

# Generated at 2022-06-20 20:37:54.742445
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual_test = NetBSDVirtual(None)
    assert netbsd_virtual_test


# Generated at 2022-06-20 20:38:00.206396
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts_result = NetBSDVirtual().get_virtual_facts()
    assert virtual_facts_result['virtualization_type'] in ['', 'xen', 'kvm', 'vmware', 'parallels', 'hyperv', 'bhyve', 'qemu', 'docker', None]

# Generated at 2022-06-20 20:38:02.058742
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virt_module = NetBSDVirtualCollector()
    assert virt_module._platform == "NetBSD"

# Generated at 2022-06-20 20:38:05.293778
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    # Create collector object
    collector = NetBSDVirtualCollector()
    assert collector._platform == 'NetBSD'
    assert collector._fact_class.platform == 'NetBSD'

# Generated at 2022-06-20 20:38:15.998446
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    def fake_file(path):
        if path == '/etc/release':
            content = '''
NetBSD 7.1 (GENERIC) #0: Fri May 19 11:15:48 UTC 2017
    mkrepro@mkrepro.NetBSD.org:/usr/src/sys/arch/amd64/compile/GENERIC
'''
        elif path == '/proc/cpuinfo':
            content = '''
cpu0: Intel Xeon E3110 (Penryn) (686-class), 3090.16 MHz, id 0x10676
'''
        elif path == '/dev/xen/evtchn':
            return None
        elif path == '/dev/xen/privcmd':
            return None
        elif path == '/dev/xen/xenbus':
            return None

# Generated at 2022-06-20 20:38:21.335594
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual_facts = NetBSDVirtual('ansible.module__utils.facts.virtual.netbsd')
    assert netbsd_virtual_facts.platform == 'NetBSD'
    assert netbsd_virtual_facts.get_virtual_facts.__name__ == 'get_virtual_facts'

# Generated at 2022-06-20 20:38:25.945238
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual = NetBSDVirtual()

    virtual_facts = virtual.get_virtual_facts()

    assert virtual_facts['virtualization_type'] != ''
    assert virtual_facts['virtualization_role'] != ''
    assert type(virtual_facts['virtualization_type']) is str
    assert type(virtual_facts['virtualization_role']) is str

# Generated at 2022-06-20 20:38:28.770247
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    obj = NetBSDVirtualCollector()
    assert obj.platform == 'NetBSD'
    assert obj._fact_class == NetBSDVirtual

# Generated at 2022-06-20 20:38:34.071284
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsdvirtual = NetBSDVirtual({})
    assert (netbsdvirtual.platform == 'NetBSD')

# Generated at 2022-06-20 20:38:38.173786
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    assert NetBSDVirtual(None, None)._platform == 'NetBSD'
    assert NetBSDVirtual(None, None)._fact_class == NetBSDVirtual


# Generated at 2022-06-20 20:38:41.946236
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd = NetBSDVirtualCollector()
    assert isinstance(netbsd, NetBSDVirtualCollector)
    assert netbsd._platform == "NetBSD"

# Generated at 2022-06-20 20:38:43.301436
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
     assert NetBSDVirtualCollector._platform == 'NetBSD'


# Generated at 2022-06-20 20:38:48.557894
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    nv = NetBSDVirtualCollector().collect()
    if nv['virtualization_type'] != '':
        assert nv.get_virtual_facts()['virtualization_type'] == nv['virtualization_type']
    if nv['virtualization_role'] != '':
        assert nv.get_virtual_facts()['virtualization_role'] == nv['virtualization_role']

# Generated at 2022-06-20 20:38:50.314000
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    x = NetBSDVirtualCollector()
    assert x.platform == 'NetBSD'



# Generated at 2022-06-20 20:39:02.745527
# Unit test for method get_virtual_facts of class NetBSDVirtual

# Generated at 2022-06-20 20:39:03.806001
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()


# Generated at 2022-06-20 20:39:07.818748
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert netbsd_virtual_collector._fact_class is not None
    assert netbsd_virtual_collector._platform == 'NetBSD'

# Generated at 2022-06-20 20:39:12.230486
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual()
    f_facts = dict()
    f_facts['virtualization_type'] = 'xen'
    f_facts['virtualization_role'] = 'guest'
    f_facts['virtualization_tech_guest'] = {'xen'}
    f_facts['virtualization_tech_host'] = {'xen'}

    v_facts = virtual_facts.get_virtual_facts()

    assert v_facts == f_facts

# Generated at 2022-06-20 20:39:28.554042
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Test with empty values
    virtual_facts = NetBSDVirtual({}).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts
    assert not virtual_facts['virtualization_tech_guest']
    assert not virtual_facts['virtualization_tech_host']

    # Test with expected values
    virtual_facts = NetBSDVirtual({'machdep.dmi.system-product': 'VirtualBox'}).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'virtualbox'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert 'virtualbox' in virtual_

# Generated at 2022-06-20 20:39:29.560953
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    NetBSDVirtualCollector()


# Generated at 2022-06-20 20:39:32.107128
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.platform == 'NetBSD'

# Generated at 2022-06-20 20:39:33.768523
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virt = NetBSDVirtual()
    assert virt.platform == 'NetBSD'


# Generated at 2022-06-20 20:39:35.792938
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    collector = NetBSDVirtualCollector()
    assert collector._platform == 'NetBSD'
    assert collector._fact_class == NetBSDVirtual

# Generated at 2022-06-20 20:39:37.046394
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    NetBSDVirtual()

# Generated at 2022-06-20 20:39:41.938415
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual = NetBSDVirtual()
    virtual_facts = netbsd_virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''

# Generated at 2022-06-20 20:39:44.737042
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    assert NetBSDVirtual(None, 'linux') == VirtualCollector._virtuals['linux']
    assert NetBSDVirtual(None, 'netbsd') == VirtualCollector._virtuals['netbsd']

# Generated at 2022-06-20 20:39:47.527623
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual({}, None).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'

# Generated at 2022-06-20 20:39:59.331581
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.netbsd import NetBSDVirtual
    from ansible.module_utils.facts.virtual import VirtualFactCollector
    import json
    import os

    virtual_facts_data = {}
    file_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'facts.d', 'virtual', 'netbsd.json')
    with open(file_path, 'r') as f:
        virtual_facts_data = json.load(f)

    virtual_obj = NetBSDVirtual()
    virtual_result = virtual_obj.get_virtual_facts()

    assert virtual_result['virtualization_type'] == virtual_facts_data['virtualization_type']

# Generated at 2022-06-20 20:40:14.854712
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    objNetBSDVirtual = NetBSDVirtual()
    assert objNetBSDVirtual.platform == 'NetBSD'


# Generated at 2022-06-20 20:40:19.550664
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    from ansible.module_utils.facts.virtual import NetBSDVirtualCollector
    from ansible.module_utils.facts.virtual.netbsd import NetBSDVirtual
    facts = NetBSDVirtualCollector(None).collect()
    assert facts['virtualization_type'] == NetBSDVirtual().get_virtual_facts()['virtualization_type']

# Generated at 2022-06-20 20:40:25.139686
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert netbsd_virtual_collector._fact_class == NetBSDVirtual
    assert netbsd_virtual_collector._platform == 'NetBSD'


# Generated at 2022-06-20 20:40:36.613319
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    class fake_sysctl(object):
        machdep_dmi_system_product = 'MacBookPro11,3'
        machdep_dmi_system_vendor = 'Apple Inc.'
        machdep_hypervisor = 'Apple Inc. Mac-E43C1C25D4880AD6'

        def get(self, name):
            return getattr(self, name)

    facts = NetBSDVirtual(fake_sysctl()).get_virtual_facts()
    assert facts['virtualization_type'] == 'parallels'
    assert facts['virtualization_role'] == 'guest'

    # The is_virtual value is set in VirtualCollector.__init__
    assert facts['virtualization_type'] != ''

    # Set the virtualization detection to fail.
    class fake_sysctl(object):
        machdep_dmi

# Generated at 2022-06-20 20:40:37.499725
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    network_virtual = NetBSDVirtual()
    assert network_virtual.platform == 'NetBSD'

# Generated at 2022-06-20 20:40:43.488623
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virt = NetBSDVirtual({'ansible_facts': {'kernel': 'NetBSD'}})
    facts = virt.get_virtual_facts()
    assert facts['virtualization_type'] == ''
    assert facts['virtualization_role'] == ''
    assert facts['virtualization_tech_guest'] == set()
    assert facts['virtualization_tech_host'] == set()



# Generated at 2022-06-20 20:40:45.229880
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    facts_obj = NetBSDVirtualCollector()
    assert facts_obj._fact_class.platform == 'NetBSD'


# Generated at 2022-06-20 20:40:47.085000
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    bsd_virtual = NetBSDVirtual()
    assert bsd_virtual._platform == 'NetBSD'
    assert bsd_virtual.get_virtual_facts == bsd_virtual._get_virtual_facts

# Generated at 2022-06-20 20:40:54.882066
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert netbsd_virtual_collector.platform == 'NetBSD'
    assert netbsd_virtual_collector.fact_class.platform == 'NetBSD'
    assert netbsd_virtual_collector._fact_class == NetBSDVirtual
    assert netbsd_virtual_collector._platform == 'NetBSD'


# Generated at 2022-06-20 20:40:59.523431
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_facts = NetBSDVirtualCollector().get_virtual_facts()
    assert netbsd_facts['virtualization_type'] == 'xen'
    assert netbsd_facts['virtualization_role'] == 'guest'
    assert netbsd_facts['virtualization_tech_guest'] == set(['xen'])
    assert netbsd_facts['virtualization_tech_host'] == set(['xen'])

# Generated at 2022-06-20 20:41:31.655804
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
  x = NetBSDVirtualCollector()
  assert x.platform == 'NetBSD'
  assert x.fact_class == NetBSDVirtual
  assert NetBSDVirtual.platform == 'NetBSD'



# Generated at 2022-06-20 20:41:42.107636
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    '''Unit test for method get_virtual_facts of class NetBSDVirtual'''
    netbsdvirtual = NetBSDVirtual()
    virtual_facts = {}
    host_tech = set()
    guest_tech = set()

    # Test for case when machdep.dmi.system-product exists
    sysctl_product_name_value = 'ThinkPad T420'
    virtual_facts['virtualization_type'], virtual_facts['virtualization_role'], guest_tech, host_tech = netbsdvirtual.detect_virt_product('machdep.dmi.system-product', sysctl_product_name_value)
    assert virtual_facts['virtualization_type'] == 'KVM' and virtual_facts['virtualization_role'] == 'guest' and host_tech == set(['KVM'])
    sysctl_product

# Generated at 2022-06-20 20:41:53.890916
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Initialize the NetBSDVirtual object
    nbsd_virtual = NetBSDVirtual()

    # Set the product name
    nbsd_virtual.sysctl_product_name = ''
    # Set the vendor name
    nbsd_virtual.sysctl_vendor_name = ''
    # Set the hypervisor name
    nbsd_virtual.sysctl_hypervisor_name = ''

    # Verify that virtualization_type, virtualization_role and
    # virtualization_tech_guest are set to empty values
    assert nbsd_virtual.get_virtual_facts()['virtualization_type'] == ''
    assert nbsd_virtual.get_virtual_facts()['virtualization_role'] == ''
    assert nbsd_virtual.get_virtual_facts()['virtualization_tech_guest'] == set()

    #

# Generated at 2022-06-20 20:41:55.487255
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    x = NetBSDVirtual()
    assert x


# Generated at 2022-06-20 20:42:07.272823
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Test get_virtual_facts method of class NetBSDVirtual with empty sysctl
    # tree
    virtual_facts = NetBSDVirtual(content={}).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()

    # Test get_virtual_facts method of class NetBSDVirtual with sysctl tree
    # containing VMware Hypervisor vendor

# Generated at 2022-06-20 20:42:17.317909
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Create the object
    virtual_system = NetBSDVirtual()
    # Create some fake values
    virtual_system.sysctl_values = {
        'machdep.dmi.system-product': 'VirtualBox',
        'machdep.dmi.system-vendor': 'innotek GmbH',
        'machdep.hypervisor': '',
    }
    result = virtual_system.get_virtual_facts()
    assert result['virtualization_type'] == 'VirtualBox', \
        "Expected virtualization_type 'VirtualBox'"
    assert result['virtualization_type'] == result['virtualization_role'] == \
        "VirtualBox", "Expected virtualization_type and virtualization_role to both be 'VirtualBox'"

# Generated at 2022-06-20 20:42:18.177488
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    v = NetBSDVirtual({})


# Generated at 2022-06-20 20:42:19.995839
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    results = NetBSDVirtualCollector().collect()

    assert type(results) is dict
    assert results['virtualization_type'] != ''

# Generated at 2022-06-20 20:42:24.850516
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtualCollector().collect()

    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-20 20:42:28.694212
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    fact = NetBSDVirtual()

    fact_dict = fact.get_virtual_facts()

    assert fact_dict.get('virtualization_type') == 'xen'
    assert fact_dict.get('virtualization_role') == 'guest'

# Generated at 2022-06-20 20:43:38.512461
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    ret_value = NetBSDVirtualCollector()
    assert isinstance(ret_value, NetBSDVirtualCollector)

# Generated at 2022-06-20 20:43:43.654718
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_vd = NetBSDVirtual()
    assert netbsd_vd.platform == 'NetBSD'

# Generated at 2022-06-20 20:43:50.018412
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Create object
    virtual_facts = NetBSDVirtual()

    # Call method
    virtual_facts.get_virtual_facts()

    # Validate
    assert virtual_facts.get_virtual_facts() == dict(virtualization_type='', virtualization_role='', virtualization_system='', virtualization_type_role='', virtualization_product='', virtualization_technology='', virtualization_virt_who='')

# Generated at 2022-06-20 20:43:56.077014
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    fake_module = type('module', (object,), {})
    fake_module.exit_json = lambda x: None
    fake_module.fail_json = lambda x, msg: msg
    fake_module.params = {}

    assert NetBSDVirtual(fake_module).get_virtual_facts() == {
        'virtualization_role': 'guest',
        'virtualization_type': 'xen',
        'virtualization_tech_guest': {'xen'},
        'virtualization_tech_host': set()
    }

# Generated at 2022-06-20 20:44:05.254657
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.netbsd import NetBSDVirtual

    virt_facts = NetBSDVirtual()
    assert virt_facts.get_virtual_facts()
    assert virt_facts.get_virtual_facts().get('virtualization_type') == ''
    assert virt_facts.get_virtual_facts().get('virtualization_role') == ''
    assert not virt_facts.get_virtual_facts().get('virtualization_tech_guest')
    assert not virt_facts.get_virtual_facts().get('virtualization_tech_host')

# Generated at 2022-06-20 20:44:10.490604
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual().get_virtual_facts()
    guests = ['kvm', 'openvz', 'kvm', 'kvm', 'xen']
    assert virtual_facts['virtualization_tech_guest'] == set(guests)
    hosts = ['openvz', 'kvm', 'xen']
    assert virtual_facts['virtualization_tech_host'] == set(hosts)

# Generated at 2022-06-20 20:44:14.761130
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_fact = NetBSDVirtual()
    assert virtual_fact._platform == 'NetBSD'
    assert virtual_fact._fact_class == NetBSDVirtual
    assert virtual_fact._collector_class == NetBSDVirtualCollector
    assert virtual_fact.virtual_facts == {}

# Generated at 2022-06-20 20:44:20.201588
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    # Create a new instance
    test_ins = NetBSDVirtual()
    # Check the platform
    assert 'NetBSD' == test_ins.platform
    # Check the keys
    keys = set(test_ins.data.keys())
    assert keys == set(['virtualization_type', 'virtualization_role', 'virtualization_tech_guest', 'virtualization_tech_host'])

# Unit tests for detect_virt_vendor

# Generated at 2022-06-20 20:44:25.495438
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virt_collector = NetBSDVirtualCollector()
    # Try to detect host and guest with openvz
    openvz_probe = {'machdep.dmi.system-vendor': 'OpenVZ',
                    'machdep.dmi.system-product': 'virtualization-host'}
    netbsd_virtual = virt_collector.collect(openvz_probe, None)
    netbsd_virtual_facts = netbsd_virtual.get_virtual_facts()
    assert 'openvz' in netbsd_virtual_facts['virtualization_tech_guest']
    assert 'openvz' in netbsd_virtual_facts["virtualization_tech_host"]
    assert 'openvz' == netbsd_virtual_facts["virtualization_type"]

# Generated at 2022-06-20 20:44:26.603057
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert issubclass(NetBSDVirtualCollector, VirtualCollector)



# Generated at 2022-06-20 20:47:29.104658
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virtual_collector = NetBSDVirtualCollector()

    expected_fact_class = NetBSDVirtual
    assert virtual_collector._fact_class == expected_fact_class

    expected_platform = 'NetBSD'
    assert virtual_collector._platform == expected_platform

# Generated at 2022-06-20 20:47:30.608196
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    nets = NetBSDVirtual()
    assert nets._platform == 'NetBSD'
    assert nets._fact_class == NetBSDVirtual


# Generated at 2022-06-20 20:47:41.460765
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # pylint: disable=protected-access, unused-argument
    def fake_ansible_module(ansible_module):
        facts = NetBSDVirtualCollector().collect(ansible_module, ansible_module.params)

        assert 'virtualization_type' in facts
        assert 'virtualization_role' in facts
        assert 'virtualization_tech_guest' in facts
        assert 'virtualization_tech_host' in facts

        if os.path.exists('/dev/xencons'):
            assert facts['virtualization_type'] == 'xen'
            assert facts['virtualization_role'] == 'guest'

    module = FakeAnsibleModule()
    setattr(module, 'run_command', fake_run_command)
    NetBSDVirtualCollector()._detect_virt_vendor = fake_det