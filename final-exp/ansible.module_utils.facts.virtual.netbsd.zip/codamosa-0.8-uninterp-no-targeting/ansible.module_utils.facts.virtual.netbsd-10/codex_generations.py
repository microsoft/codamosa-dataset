

# Generated at 2022-06-20 20:37:46.371918
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsdv = NetBSDVirtual()
    assert netbsdv is not None


# Generated at 2022-06-20 20:37:48.672409
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual('libvirt')
    assert netbsd_virtual.platform == 'NetBSD'

# Generated at 2022-06-20 20:37:52.344224
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual_facts = NetBSDVirtual()
    assert netbsd_virtual_facts.get_virtual_facts()['virtualization_type'] == ''
    assert netbsd_virtual_facts.get_virtual_facts()['virtualization_role'] == ''

# Generated at 2022-06-20 20:37:53.247985
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector._platform == 'NetBSD'

# Generated at 2022-06-20 20:37:54.826441
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual is not None


# Generated at 2022-06-20 20:37:57.756262
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd = NetBSDVirtual(None)
    assert netbsd.platform == 'NetBSD'

# Generated at 2022-06-20 20:38:00.050479
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    class_ = NetBSDVirtualCollector()
    assert class_._platform == 'NetBSD'


# Generated at 2022-06-20 20:38:06.146907
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    physical_facts = {'kernel': 'NetBSD'}
    test_obj = NetBSDVirtual(physical_facts=physical_facts, log_callback=None)
    test_obj.populate()
    assert test_obj.virtual_facts == {'virtualization_type': '', 'virtualization_role': '', 'virtualization_tech_guest': set([]), 'virtualization_tech_host': set([])}

# Generated at 2022-06-20 20:38:10.028664
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual({})

    # Assert the result is an instance of Virtual
    assert isinstance(virtual, Virtual)

    # Assert the result is instance of NetBSDVirtual
    assert isinstance(virtual, NetBSDVirtual)

# Generated at 2022-06-20 20:38:13.333080
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    test_object = NetBSDVirtual({})
    test_object.facts['kernel'] = 'NetBSD'
    facts = test_object.get_virtual_facts()
    assert facts is not None

# Generated at 2022-06-20 20:38:19.342266
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virtual_collector = NetBSDVirtualCollector()
    assert virtual_collector._platform == 'NetBSD'

# Generated at 2022-06-20 20:38:22.217488
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual = NetBSDVirtualCollector()
    assert netbsd_virtual._fact_class is NetBSDVirtual
    assert netbsd_virtual.platform == "NetBSD"

# Generated at 2022-06-20 20:38:24.255790
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual_constructor = NetBSDVirtual()
    assert netbsd_virtual_constructor.platform == "NetBSD"


# Generated at 2022-06-20 20:38:31.047770
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virt = NetBSDVirtual()
    mock_virtual = {
        'os_sysctl': {
            'machdep.dmi.system-product': 'VMware Virtual Platform',
            'machdep.dmi.system-vendor': 'VMware',
            'machdep.hypervisor': 'KVM',
        },
        'os_file': {
            '/dev/xencons': '',
        }
    }

# Generated at 2022-06-20 20:38:32.174222
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd = NetBSDVirtual()


# Generated at 2022-06-20 20:38:35.124582
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert netbsd_virtual_collector._platform == "NetBSD"
    assert netbsd_virtual_collector._fact_class.platform == "NetBSD"


# Generated at 2022-06-20 20:38:43.681886
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    """
    A basic construction test of class NetBSDVirtualCollector
    """
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert netbsd_virtual_collector._platform == 'NetBSD', \
        "NetBSDVirtualCollector() object should have _platform == 'NetBSD'"
    assert netbsd_virtual_collector._fact_class == NetBSDVirtual, \
        "NetBSDVirtualCollector() object should have _fact_class == NetBSDVirtual"


# Generated at 2022-06-20 20:38:46.571017
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    facts = {}
    NetBSDVirtual(facts).get_virtual_facts()
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts

# Generated at 2022-06-20 20:38:51.643295
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    vnetbsd = NetBSDVirtualCollector()
    assert vnetbsd is not None, 'NetBSDVirtualCollector constructor returns None'
    assert 'NetBSD' in vnetbsd._platform, 'NetBSDVirtualCollector._platform not set correctly'
    assert vnetbsd._fact_class is not None, 'NetBSDVirtualCollector._fact_class not set correctly'

# Generated at 2022-06-20 20:38:55.178746
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # As the method get_virtual_facts of class NetBSDVirtual needs to call the
    # method get_file_content of class File, we cannot use unittest here.
    assert True

# Generated at 2022-06-20 20:39:06.594039
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    """Test that the NetBSDVirtualCollector constructor performs as expected"""
    netbsd_virtual = NetBSDVirtualCollector()
    assert netbsd_virtual._fact_class == NetBSDVirtual
    assert netbsd_virtual._platform == 'NetBSD'

# Generated at 2022-06-20 20:39:08.262274
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector._platform == 'NetBSD'
    assert NetBSDVirtualCollector._fact_class == NetBSDVirtual

# Generated at 2022-06-20 20:39:09.184992
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    NetBSDVirtual().get_virtual_facts()

# Generated at 2022-06-20 20:39:15.242916
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    # Fake sysctl output
    sysctl_output = {
        'machdep.dmi.system-product': 'VirtualBox',
        'machdep.hypervisor': 'none',
        'hw.model': 'amd64',
        'hw.machine_arch': 'amd64'
    }
    # Play with the constructor
    v = NetBSDVirtual(sysctl_output)
    # Assert some of the results from the constructor
    assert v.platform == 'NetBSD'
    assert v.virtualization_type == 'virtualbox'
    assert v.virtualization_role == 'guest'
    assert v.virtualization_tech_guest == {'virtualbox'}


# Generated at 2022-06-20 20:39:21.950239
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virtual_facts = NetBSDVirtualCollector()
    assert virtual_facts.__class__.__name__ == 'NetBSDVirtualCollector'
    assert virtual_facts._fact_class == NetBSDVirtual
    assert virtual_facts._platform == 'NetBSD'
    assert virtual_facts._fact_class._platform == 'NetBSD'


# Generated at 2022-06-20 20:39:24.220683
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual()
    assert virtual.platform == 'NetBSD'
    assert virtual.virtualization_type == ''
    assert virtual.virtualization_role == ''

# Generated at 2022-06-20 20:39:27.395507
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual()
    # Verify existing attributes of instance of class NetBSDVirtual
    assert hasattr(virtual, 'sysctl')
    assert hasattr(virtual, 'sysctl_path')
    assert virtual.sysctl_path == '/sbin/sysctl'


# Generated at 2022-06-20 20:39:28.914452
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert issubclass(NetBSDVirtualCollector, VirtualCollector)

# Generated at 2022-06-20 20:39:32.580948
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert netbsd_virtual_collector._platform == 'NetBSD'
    assert netbsd_virtual_collector._fact_class is NetBSDVirtual

# Generated at 2022-06-20 20:39:34.996666
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virt = NetBSDVirtualCollector()
    assert virt._platform == 'NetBSD'
    assert virt._fact_class is NetBSDVirtual
    assert isinstance(virt._fact_class, Virtual)

# Generated at 2022-06-20 20:39:50.973795
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():

    x = NetBSDVirtualCollector()

    assert x._fact_class == NetBSDVirtual
    assert x._platform == 'NetBSD'

# Generated at 2022-06-20 20:39:53.266986
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual()
    assert virtual._platform == 'NetBSD'

# Generated at 2022-06-20 20:39:56.255745
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    collector_inst = NetBSDVirtualCollector()
    assert collector_inst._fact_class == NetBSDVirtual
    assert collector_inst._platform == 'NetBSD'

# Generated at 2022-06-20 20:39:59.340762
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'

# Generated at 2022-06-20 20:40:03.578571
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert issubclass(NetBSDVirtualCollector, VirtualCollector)
    assert NetBSDVirtualCollector._fact_class is NetBSDVirtual
    assert NetBSDVirtualCollector._platform == 'NetBSD'


# Generated at 2022-06-20 20:40:10.375715
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    # Create instance of class NetBSDVirtual
    netbsd_virtual_inst = NetBSDVirtual()
    # Create empty dict for virtualization facts
    netbsd_virtual_vars = {}

    # Set empty values as default
    netbsd_virtual_vars['virtualization_type'] = ''
    netbsd_virtual_vars['virtualization_role'] = ''

    # Assert method 'get_virtual_facts' returns expected results
    assert netbsd_virtual_inst.get_virtual_facts() == netbsd_virtual_vars

# Generated at 2022-06-20 20:40:12.455090
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    obj = NetBSDVirtualCollector()
    assert obj._platform == 'NetBSD'
    assert obj._fact_class == NetBSDVirtual

# Generated at 2022-06-20 20:40:13.949968
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual({})

    assert netbsd_virtual.platform == 'NetBSD'

# Generated at 2022-06-20 20:40:15.900100
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.platform == 'NetBSD'
    assert netbsd_virtual.get_virtual_facts() == {}

# Generated at 2022-06-20 20:40:27.182886
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Set all the possible facts to None
    NetBSDVirtFacts = NetBSDVirtual(None)
    virtual_facts = NetBSDVirtFacts.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_host'] == set()
    assert virtual_facts['virtualization_tech_guest'] == set()

    # Set all the possible facts to None
    NetBSDVirtFacts.sysctl = {'machdep.dmi.system-vendor': '', 'machdep.hypervisor': '', 'machdep.dmi.system-product': ''}
    virtual_facts = NetBSDVirtFacts.get_virtual_facts()
    assert virtual_facts['virtualization_type']

# Generated at 2022-06-20 20:40:54.691972
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    NetBSDVirtualCollector()

# Generated at 2022-06-20 20:41:05.228848
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # List of filters to use in order to find the required sysctl
    filters = ['machdep.dmi.system-product', 'machdep.dmi.system-vendor']

    # sysctl_values dict to create an instance of class NetBSDVirtual
    sysctl_values = {'machdep.dmi.system-product': 'VirtualBox',
                     'machdep.dmi.system-vendor': 'innotek GmbH'}

    # Expected output from get_virtual_facts

# Generated at 2022-06-20 20:41:06.475474
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    x = NetBSDVirtualCollector()
    assert x.platform == 'NetBSD'

# Generated at 2022-06-20 20:41:10.579250
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    """Checking NetBSDVirtualCollector initialization
    """
    assert issubclass(NetBSDVirtualCollector, dict)
    assert NetBSDVirtualCollector._fact_class is NetBSDVirtual
    assert NetBSDVirtualCollector._platform is 'NetBSD'
    assert NetBSDVirtualCollector().get_virtual_facts() == {}


# Generated at 2022-06-20 20:41:14.370660
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    # Test the constructor of NetBSDVirtualCollector
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert netbsd_virtual_collector._fact_class._platform == 'NetBSD'

# Generated at 2022-06-20 20:41:17.432274
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    collector = NetBSDVirtualCollector()
    assert isinstance(collector.platform, str)
    assert isinstance(collector.fact_class, object)

# Generated at 2022-06-20 20:41:27.250023
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    fc = NetBSDVirtual()
    facts = {}

    # machdep.dmi.system-product.product=OpenStack Nova
    # machdep.dmi.system-vendor.vendor=Apple Inc.
    facts['dmi'] = {'system-product': {'product': 'OpenStack Nova'},
                    'system-vendor': {'vendor': 'Apple Inc.'}}
    virtual_facts = fc.get_virtual_facts(facts)
    assert virtual_facts['virtualization_type'] == 'openstack'
    assert virtual_facts['virtualization_role'] == 'guest'

    # machdep.dmi.system-product.product=VMware Virtual Platform
    facts['dmi'] = {'system-product': {'product': 'VMware Virtual Platform'}}
    virtual_facts = fc.get_

# Generated at 2022-06-20 20:41:35.341018
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    # Create new NetBSDVirtual object
    netbsd_virtual_info = NetBSDVirtual()

    # Check the type of the object
    assert isinstance(netbsd_virtual_info, (NetBSDVirtual, Virtual))

    # Check if the platform is set correctly
    if netbsd_virtual_info.get_platform() != 'NetBSD':
        raise AssertionError("Platform should be 'NetBSD'")

# Generated at 2022-06-20 20:41:39.543178
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    module_name = 'ansible_netbsd_virtual_facts'
    kwargs = {'ansible_facts': {'ansible_sysctl': {}}}
    obj = NetBSDVirtual(module_name, **kwargs)
    assert obj.module_name == module_name
    assert kwargs['ansible_facts'] == obj.facts

# Generated at 2022-06-20 20:41:42.780660
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    module = AnsibleModuleMock()
    p = NetBSDVirtual(module)
    assert p.platform == 'NetBSD'
    assert p.module == module


# Generated at 2022-06-20 20:42:45.087812
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # FIXME: Write real unit tests
    # There is no way currently to set the values for sysctl
    # For example, we can set machdep.dmi.system-vendor=VMWare, Inc.
    # And it will return correctly VMware, Inc
    #
    # But we can not set machdep.dmi.system-product to VMware Virtual Platform
    # So the detected virtualization type will be VMware ESXi, not VMware
    # Virtual Platform
    virtual = NetBSDVirtual({})
    print(virtual.get_virtual_facts())



# Generated at 2022-06-20 20:42:54.552598
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
  netbsd_virtual_facts = NetBSDVirtual()
  netbsd_virtual_facts.sysctl = {'machdep.dmi.system-vendor': '',
                                 'machdep.dmi.system-product': '',
                                 'machdep.hypervisor': ''}
  result = netbsd_virtual_facts.get_virtual_facts()
  assert result == {'virtualization_type': '',
                    'virtualization_role': '',
                    'virtualization_tech_guest': set(),
                    'virtualization_tech_host': set()}

# Generated at 2022-06-20 20:42:56.823459
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual_fact_class = NetBSDVirtual()
    assert netbsd_virtual_fact_class.platform == 'NetBSD'

# Generated at 2022-06-20 20:43:00.919216
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_obj = NetBSDVirtual()
    assert virtual_obj.platform == 'NetBSD'


# Generated at 2022-06-20 20:43:05.448220
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    from ansible.module_utils.facts.virtual.netbsd import NetBSDVirtualCollector
    nvn = NetBSDVirtualCollector()
    assert nvn.platform == 'NetBSD'
    assert isinstance(nvn._fact_class, NetBSDVirtual)

# Generated at 2022-06-20 20:43:07.490246
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    # Unit test for constructor of class NetBSDVirtual
    vm = NetBSDVirtual()
    assert vm.platform == 'NetBSD'


# Generated at 2022-06-20 20:43:08.902165
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    obj = NetBSDVirtualCollector()
    assert isinstance(obj, NetBSDVirtualCollector)

# Generated at 2022-06-20 20:43:09.960860
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    x = NetBSDVirtualCollector()
    assert x.platform == 'NetBSD'

# Generated at 2022-06-20 20:43:11.009965
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual()
    assert virtual.platform == 'NetBSD'

# Generated at 2022-06-20 20:43:12.660508
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert isinstance(netbsd_virtual_collector, VirtualCollector)


# Generated at 2022-06-20 20:45:47.639851
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virtual_collector = NetBSDVirtualCollector()
    assert virtual_collector

# Generated at 2022-06-20 20:45:56.712957
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    testobj = NetBSDVirtual()
    testobj._get_sysctl = lambda x: 'OpenBSD'
    assert testobj.get_virtual_facts() == {
        'virtualization_type': 'xen',
        'virtualization_role': 'guest',
        'virtualization_product': 'OpenBSD',
        'virtualization_tech_guest': set(['xen']),
        'virtualization_tech_host': set([])
    }


# Generated at 2022-06-20 20:46:01.258335
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Set up the class and facts to test
    facts = dict()
    virtual_facts_class = NetBSDVirtual(facts=facts, module=None)
    # Test when no sysctl facts are provided
    virtual_facts_class.get_sysctl = dict()
    virtual_facts = virtual_facts_class.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert not virtual_facts['virtualization_tech_guest']
    assert not virtual_facts['virtualization_tech_host']

# Generated at 2022-06-20 20:46:05.774007
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():

    # Get platform of this host
    platform = 'NetBSD'

    # Create object of class NetBSDVirtualCollector
    obj = NetBSDVirtualCollector()

    # Check the platform of class NetBSDVirtualCollector is same as platform of this host
    assert obj._platform == platform

# Generated at 2022-06-20 20:46:16.312309
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    """
    When /dev/xencons exists, it should correctly get the virtual facts for NetBSD guests
    """
    # if the system is indeed NetBSD and /dev/xencons exists
    # the virtual info should be set correctly
    from ansible.module_utils.facts import Virtual, VirtualCollector
    import mock
    import os
    if os.path.exists('/dev/xencons'):
        with mock.patch('os.path.exists', return_value=True):
            virtual_info = VirtualCollector().collect(None, None)
            assert set(virtual_info.keys()) == {'virtualization_type',
                                                'virtualization_role',
                                                'virtualization_technologies'}
            assert virtual_info['virtualization_type'] == 'xen'

# Generated at 2022-06-20 20:46:27.941382
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():

    # Return value of function facter_parse_sysctl
    facter_parse_sysctl = {
        'machdep.dmi.system-product': 'VAIO',
        'machdep.dmi.system-vendor': 'Sony',
        'machdep.hypervisor': 'None'
    }

    # Return value of function detect_virt_product
    detect_virt_product = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }

    # Return value of function detect_virt_vendor

# Generated at 2022-06-20 20:46:32.561195
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual = NetBSDVirtual()
    facts_dict = netbsd_virtual.get_virtual_facts()
    assert 'virtualization_type' in facts_dict
    assert 'virtualization_role' in facts_dict
    assert 'virtualization_tech' in facts_dict

# Generated at 2022-06-20 20:46:34.902835
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector()._platform == 'NetBSD'

# Generated at 2022-06-20 20:46:41.298669
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    facts = dict(
        machdep=dict(
            dmi=dict(
                system_product='KVM',
                system_vendor='Generic',
            ),
            hypervisor='kvm',
        )
    )
    virtual_gather = NetBSDVirtual(facts=facts)
    virtual_facts = virtual_gather.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'kvm'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert 'kvm' in virtual_facts['virtualization_tech_guest']
    assert 'kvm' in virtual_facts['virtualization_tech_host']

# Generated at 2022-06-20 20:46:42.930717
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virt = NetBSDVirtual()
    virt_facts = virt.get_virtual_facts()
    assert 'virtualization_type' in virt_facts