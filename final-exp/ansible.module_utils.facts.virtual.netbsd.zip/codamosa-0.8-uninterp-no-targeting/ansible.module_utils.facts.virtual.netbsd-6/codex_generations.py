

# Generated at 2022-06-20 20:37:45.585746
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert netbsd_virtual_collector._fact_class.platform == 'NetBSD'

# Generated at 2022-06-20 20:37:48.328741
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virtual_collector = NetBSDVirtualCollector()

    assert virtual_collector.platform == 'NetBSD'
    assert virtual_collector.fact_class == NetBSDVirtual


# Generated at 2022-06-20 20:37:53.391777
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():

    # Test machdep.dmi.system-product detection with a hypervisor
    sysctl_dict_1 = {'machdep.dmi.system-product': 'VMware Virtual Platform',
                     'machdep.dmi.system-vendor': 'VMware, Inc.'}

    netbsd_virtual_1 = NetBSDVirtual(sysctl_dict=sysctl_dict_1)
    virtual_facts_1 = netbsd_virtual_1.get_virtual_facts()
    assert(virtual_facts_1['virtualization_type'] == 'VMware')
    assert(virtual_facts_1['virtualization_role'] == 'guest')
    assert('vmware' in virtual_facts_1['virtualization_tech_host'])

# Generated at 2022-06-20 20:37:59.373421
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    import pytest
    from ansible.module_utils.facts.virtual.netbsd import NetBSDVirtual
    from ansible.module_utils import basic

    from ansible_collections.ansible.community.tests.unit.module_utils.virtual.facts.virtual.netbsd import NetBSDVirtual_sysctl_dmi_system_vendor_RESULT_dict
    from ansible_collections.ansible.community.tests.unit.module_utils.virtual.facts.virtual.netbsd import NetBSDVirtual_sysctl_dmi_system_product_RESULT_dict
    from ansible_collections.ansible.community.tests.unit.module_utils.virtual.facts.virtual.netbsd import NetBSDVirtual_sysctl_hypervisor_RESULT_dict

    # Mock

# Generated at 2022-06-20 20:38:01.311227
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual_facts = NetBSDVirtual()
    assert netbsd_virtual_facts is not None

# Generated at 2022-06-20 20:38:02.881912
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector()._platform == 'NetBSD'


# Generated at 2022-06-20 20:38:05.584355
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virt_fact_collector = NetBSDVirtualCollector()
    assert virt_fact_collector.virtual == NetBSDVirtual

# Generated at 2022-06-20 20:38:16.159505
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual = NetBSDVirtual()

    # Set empty values as default
    sysctl_mib = {}
    sysctl_mib['machdep.dmi.system-vendor'] = 'No Virtualization'
    sysctl_mib['machdep.dmi.system-product'] = 'n/a'

    # Set values for Xen
    sysctl_mib['machdep.dmi.system-vendor'] = 'Xen'
    sysctl_mib['machdep.dmi.system-product'] = 'HVM domU'
    sysctl_mib['machdep.hypervisor'] = 'Xen'

    netbsd_virtual.set_sysctl_mib(sysctl_mib)
    virtual_facts = netbsd_virtual.get_virtual_facts()

   

# Generated at 2022-06-20 20:38:18.909710
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.platform == 'NetBSD'



# Generated at 2022-06-20 20:38:21.535554
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    obj = NetBSDVirtualCollector()
    assert obj.platform == 'NetBSD'
    assert obj._fact_class == NetBSDVirtual

# Generated at 2022-06-20 20:38:27.772573
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    facts_collector = NetBSDVirtualCollector()
    assert facts_collector._platform == "NetBSD"

# Generated at 2022-06-20 20:38:29.572561
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    v = NetBSDVirtual({})
    assert v._platform == 'NetBSD'

# Generated at 2022-06-20 20:38:33.983437
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    facts = NetBSDVirtual().get_virtual_facts()
    assert facts['virtualization_type'] == 'xen'
    assert facts['virtualization_role'] == 'guest'

    assert 'virtualization_type' not in NetBSDVirtual().get_virtual_facts()
    assert 'virtualization_role' not in NetBSDVirtual().get_virtual_facts()

# Generated at 2022-06-20 20:38:35.955577
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virtual_facts = NetBSDVirtualCollector()
    assert virtual_facts._fact_class == NetBSDVirtual
    assert virtual_facts._platform == 'NetBSD'

# Generated at 2022-06-20 20:38:39.523116
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virt = NetBSDVirtual()
    assert virt.platform == 'NetBSD', 'test_NetBSDVirtual - Failed to set platform'


# Generated at 2022-06-20 20:38:41.891018
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    cl = NetBSDVirtualCollector()
    assert cl != None

# Generated at 2022-06-20 20:38:45.194622
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    test_virtual = NetBSDVirtual({})
    assert NetBSDVirtual == test_virtual.__class__
    assert Virtual == test_virtual.__class__.__base__
    assert 'NetBSD' == test_virtual.platform


# Generated at 2022-06-20 20:38:48.883977
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virtual_collector = NetBSDVirtualCollector()
    assert virtual_collector._fact_class is not None
    assert virtual_collector._platform is not None
    assert virtual_collector._fact_class.platform == virtual_collector._platform

# Generated at 2022-06-20 20:38:53.284990
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual import NetBSDVirtual
    # Create a NetBSDVirtual instance
    netbsd_virtual = NetBSDVirtual()
    # test get_virtual_facts method
    netbsd_virtual_facts = netbsd_virtual.get_virtual_facts()
    assert isinstance(netbsd_virtual_facts, dict)
    assert netbsd_virtual_facts['virtualization_type'].startswith('virtualbox')

# Generated at 2022-06-20 20:38:55.415629
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtualCollector()
    assert virtual_facts._platform == 'NetBSD'
    assert virtual_facts._fact_class == NetBSDVirtual

# Generated at 2022-06-20 20:39:03.839689
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():

    # Create object of 'NetBSDVirtual' class
    netbsd_virtual_instance = NetBSDVirtual()

    # Create object of 'Virtual' class
    virtual_instance = Virtual()

    # Compare the type of both the objects
    assert type(netbsd_virtual_instance) == type(virtual_instance)

# Generated at 2022-06-20 20:39:07.819298
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual_instance = NetBSDVirtual()
    assert netbsd_virtual_instance.platform == 'NetBSD'


# Generated at 2022-06-20 20:39:10.369893
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    """
    Test method get_virtual_facts of NetBSDVirtual class

    """
    netbsd_virtual_facts = NetBSDVirtual()
    virtual_facts = netbsd_virtual_facts.get_virtual_facts()
    assert virtual_facts['virtualization_type'] in ['', 'xen']

# Generated at 2022-06-20 20:39:13.894405
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual = NetBSDVirtual()
    virtual_facts = netbsd_virtual.get_virtual_facts()

    assert set(virtual_facts.keys()) == {'virtualization_role', 'virtualization_type', 'virtualization_tech_guest', 'virtualization_tech_host'}

# Generated at 2022-06-20 20:39:18.222576
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd = NetBSDVirtualCollector()
    assert(netbsd.platform == 'NetBSD')
    assert(netbsd._fact_class == NetBSDVirtual)


# Generated at 2022-06-20 20:39:24.789750
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    # Test construction of the object with no parameters
    obj = NetBSDVirtual()
    assert obj

    # Test that we get a dictionary back from the get_virtual_facts() method
    x = obj.get_virtual_facts()
    assert isinstance(x, dict)

# Generated at 2022-06-20 20:39:33.511245
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual()
    virtual_facts_result = virtual_facts.get_virtual_facts()

    assert isinstance(virtual_facts_result, dict)

    # assert list of virtualization technology
    assert virtual_facts_result['virtualization_tech_guest'] == set()
    assert virtual_facts_result['virtualization_tech_host'] == set()

    # assert virtualization type
    assert virtual_facts_result['virtualization_type'] == ''

    # assert virtualization role
    assert virtual_facts_result['virtualization_role'] == ''

# Generated at 2022-06-20 20:39:36.493044
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()

    assert netbsd_virtual is not None
    assert netbsd_virtual._platform == 'NetBSD'
    assert netbsd_virtual._fact_class == 'NetBSDVirtual'

# Generated at 2022-06-20 20:39:39.026173
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector._platform == 'NetBSD'
    assert NetBSDVirtualCollector._fact_class is NetBSDVirtual


# Generated at 2022-06-20 20:39:43.390324
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual = NetBSDVirtual()
    virtual_facts = virtual.get_virtual_facts()

    interfaces = ('virtualization_type', 'virtualization_role')
    for key in interfaces:
        assert key in virtual_facts



# Generated at 2022-06-20 20:40:07.784592
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Create an instance of class NetBSDVirtual
    NetBSDVirtual_ins = NetBSDVirtual()

    # Cache the output of sysctl -n
    sysctl_dict_return = {'hw.model': '',
                          'machdep.hypervisor': '',
                          'machdep.dmi.system-product': '',
                          'machdep.dmi.system-vendor': ''}
    # Set return value for sysctl_dict()
    NetBSDVirtual_ins.sysctl_dict = lambda *args, **kwargs: sysctl_dict_return

    # Cache the output of os.path.exists('/dev/xencons')
    os_path_exists_return = False
    # Set return value for os.path.exists()

# Generated at 2022-06-20 20:40:10.242454
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.platform == 'NetBSD'


# Generated at 2022-06-20 20:40:12.664770
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual()
    assert virtual_facts.facts['virtualization_type'] == ''
    assert virtual_facts.facts['virtualization_role'] == ''

# Generated at 2022-06-20 20:40:18.932370
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_collector_mock = NetBSDVirtualCollector({'ansible_facts': {}})

    # Test for empty result set
    netbsd_collector_mock.collector = {'machdep.dmi.system-vendor': '',
                                       'machdep.hypervisor': '',
                                       'machdep.dmi.system-product': '',
                                       'machdep.dmi.system-version': '',
                                       'machdep.dmi.baseboard-product': '',
                                       'machdep.dmi.baseboard-version': '',
                                       'machdep.dmi.chassis-type': ''}
    assert not netbsd_collector_mock._fact_class.get_virtual_facts()

    netbsd_collector_

# Generated at 2022-06-20 20:40:20.576809
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsdvirtual = NetBSDVirtual()
    assert netbsdvirtual.platform == 'NetBSD'

# Generated at 2022-06-20 20:40:22.174447
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual


# Generated at 2022-06-20 20:40:24.424217
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    NetBSDVirtualCollector()

# Generated at 2022-06-20 20:40:26.389033
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual_fact = NetBSDVirtual()
    assert netbsd_virtual_fact.get_virtual_facts() == {}

# Generated at 2022-06-20 20:40:27.653201
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual()
    assert virtual != None


# Generated at 2022-06-20 20:40:30.414180
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual_obj = NetBSDVirtual('')
    assert netbsd_virtual_obj.platform == 'NetBSD'


# Generated at 2022-06-20 20:41:04.878036
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual({'ansible_facts': {'sysctl': {}}})
    assert netbsd_virtual.sysctl_all == {}
    assert netbsd_virtual.dmi_command == 'dmidecode'
    assert netbsd_virtual.get_sysctl_fact('foo') is None
    assert netbsd_virtual.get_sysctl_fact('foo', False) is None


# Generated at 2022-06-20 20:41:07.579306
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    """Unit test for the NetBSDVirtualCollector constructor."""
    c = NetBSDVirtualCollector()
    assert c.platform == 'NetBSD'
    assert c._fact_class == NetBSDVirtual

# Generated at 2022-06-20 20:41:10.291603
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    # Call the constructor
    netbsd_virtual = NetBSDVirtual()
    # We do not check for virtualization_role here.
    assert netbsd_virtual.virtual == ("", set(), set())

# Generated at 2022-06-20 20:41:16.232108
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    mock_virtual_facts_result = {
        'virtualization_type': 'xen',
        'virtualization_role': 'guest',
        'virtualization_product': '',
        'virtualization_vendor': '',
        'virtualization_tech_guest': ['xen'],
        'virtualization_tech_host': ['xen']
    }

    mock_virtual_facts_data = {
        'machdep.dmi.system-product': [
            'NULL'
        ],
        'machdep.dmi.system-vendor': [
            'NULL'
        ],
        'machdep.hypervisor': [
            'NULL'
        ]
    }

    virtual_facts_obj = NetBSDVirtual(mock_virtual_facts_data)
    virtual_facts = virtual_facts_

# Generated at 2022-06-20 20:41:18.386481
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    nc = NetBSDVirtualCollector()
    assert nc._platform == "NetBSD"
    assert nc._fact_class == NetBSDVirtual

# Generated at 2022-06-20 20:41:27.915342
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    facts = {
        'machdep.dmi.system-product': 'VirtualBox',
        'machdep.dmi.system-vendor': 'innotek GmbH',
        'machdep.hypervisor': 'VMWare',
        'machdep.vmm': 'VMWare',
        'machdep.vmm.version': '7.0',
        'machdep.vmm.product': 'ESXi',
        'machdep.vmm.vm-generation-id': 'not-supported',
    }


# Generated at 2022-06-20 20:41:30.440204
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    collector = NetBSDVirtualCollector()
    assert collector.fact_class == NetBSDVirtual
    assert collector.platform == 'NetBSD'


# Generated at 2022-06-20 20:41:41.441678
# Unit test for method get_virtual_facts of class NetBSDVirtual

# Generated at 2022-06-20 20:41:44.008866
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual()
    assert virtual.platform == "NetBSD"


# Generated at 2022-06-20 20:41:46.074957
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    myTest = NetBSDVirtual()
    assert(myTest.platform == 'NetBSD')


# Generated at 2022-06-20 20:42:52.244097
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert netbsd_virtual_collector.platform == 'NetBSD'
    assert netbsd_virtual_collector._fact_class.platform == 'NetBSD'

# Generated at 2022-06-20 20:42:54.552312
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    # Test for NetBSDVirtualCollector instantiation
    assert NetBSDVirtualCollector() is not None

# Generated at 2022-06-20 20:42:56.822776
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    nvfact = NetBSDVirtualCollector()
    assert nvfact._platform == 'NetBSD'
    assert nvfact._fact_class == NetBSDVirtual

# Generated at 2022-06-20 20:43:01.903457
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    # unit test for constructor of class NetBSDVirtual
    netbsdvirtual_class = NetBSDVirtual()
    assert netbsdvirtual_class.platform == 'NetBSD'


# Generated at 2022-06-20 20:43:11.129991
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    sysctl = {'machdep.dmi.system-product': 'KVM',
              'machdep.dmi.system-vendor': 'Proxmox Virtual Environment',
              'machdep.hypervisor': 'Proxmox Virtual Environment'
             }
    vs = NetBSDVirtual(sysctl=sysctl)
    facts = vs.get_virtual_facts()
    assert facts['virtualization_type'] == 'kvm'
    assert facts['virtualization_role'] == 'guest'
    assert facts['virtualization_product'] == 'Proxmox Virtual Environment'
    assert facts['virtualization_system'] == 'Proxmox'
    assert 'proxmox' in facts['virtualization_tech_guest']
    assert 'proxmox' in facts['virtualization_tech_host']

# Generated at 2022-06-20 20:43:12.548912
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert netbsd_virtual_collector is not None


# Generated at 2022-06-20 20:43:20.042288
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    expected_facts = {
        'virtualization_type': 'xen',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['xen']),
        'virtualization_tech_host': set([])
    }

    netbsd_virtual = NetBSDVirtual()
    virtual_facts = netbsd_virtual.get_virtual_facts()
    assert virtual_facts == expected_facts

# Generated at 2022-06-20 20:43:22.187058
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    nbv = NetBSDVirtual()

    assert nbv.platform == 'NetBSD'

# Generated at 2022-06-20 20:43:28.105687
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'virtualbox'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert 'virtualbox' in virtual_facts['virtualization_tech_guest']
    assert 'virtualbox' in virtual_facts['virtualization_tech_host']

# Generated at 2022-06-20 20:43:31.939278
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    x = NetBSDVirtualCollector()
    assert x._platform == 'NetBSD'
    assert x._fact_class.platform == 'NetBSD'



# Generated at 2022-06-20 20:46:19.500832
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    collector = NetBSDVirtualCollector()

    # Test the case when a host is virtualized with a product
    class TestVirtualSysctlProduct:
        @staticmethod
        def get(name, default=None):
            if 'machdep.dmi.system-product' in name:
                return 'VMware Virtual Platform'
            return default
    collector._sysctl = TestVirtualSysctlProduct()
    virtual_facts = collector.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'VMware Virtual Platform'
    assert virtual_facts['virtualization_role'] == 'host'
    assert 'vmware' in virtual_facts['virtualization_tech_host']
    assert 'virtualbox' not in virtual_facts['virtualization_tech_host']

# Generated at 2022-06-20 20:46:21.088611
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    v = NetBSDVirtual()
    assert v
    assert v.platform == 'NetBSD'


# Generated at 2022-06-20 20:46:31.481785
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    test_virtual_facts = dict(
        virtualization_type='xen',
        virtualization_role='guest',
        virtualization_tech_host=['xen'],
        virtualization_tech_guest=['xen'],
    )

    def fake_virtual_product(product_name, value):
        return dict(virtualization_type='',
                    virtualization_role='',
                    virtualization_tech_guest=set(),
                    virtualization_tech_host=set())

    def fake_virtual_vendor(vendor_name, value):
        return dict(virtualization_type='',
                    virtualization_role='',
                    virtualization_tech_guest=set(),
                    virtualization_tech_host=set())


# Generated at 2022-06-20 20:46:34.615931
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    # VirtualCollector is abstract class, test constructor of
    # NetBSDVirtualCollector class
    NetBSDVirtualCollector()

# Generated at 2022-06-20 20:46:36.449275
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector._platform == 'NetBSD'
    assert NetBSDVirtualCollector._fact_class == NetBSDVirtual


# Generated at 2022-06-20 20:46:38.847580
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    x = NetBSDVirtual()
    assert isinstance(x, NetBSDVirtual)
    assert x.platform == 'NetBSD'
    assert x.get_virtual_facts() == {}


# Generated at 2022-06-20 20:46:41.077309
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    # Test creating a NetBSDVirtual object
    facts = NetBSDVirtual()

    # Test the value of facts.platform
    actual = facts.platform
    expected = 'NetBSD'
    assert actual == expected



# Generated at 2022-06-20 20:46:46.294238
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    testobj = NetBSDVirtual(None, None)

    testobj.sysctl = FakeSysctl(
        {
            'machdep.dmi.system-product': FakeSysctlValue(
                'Dell', 'System Product Name\t: Dell System XPS L502X'),
            'machdep.dmi.system-vendor': FakeSysctlValue(
                'Dell Inc.', 'System Manufacturer\t: Dell Inc.'),
            'machdep.hypervisor': FakeSysctlValue(
                'QEMU', 'Hypervisor\t: QEMU'),
        }
    )

    facts = testobj.get_virtual_facts()
    assert facts['virtualization_type'] == 'xen'
    assert facts['virtualization_role'] == 'guest'

# Generated at 2022-06-20 20:46:51.980746
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    facts = NetBSDVirtualCollector().get_virtual_facts()

    assert facts['virtualization_type'] in ['', 'xen']
    assert facts['virtualization_role'] in ['', 'guest']
    assert facts['virtualization_tech_guest'] in [set(['xen']), set()]
    assert facts['virtualization_tech_host'] in [set(), set(['xen'])]

# Generated at 2022-06-20 20:46:52.868383
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector()