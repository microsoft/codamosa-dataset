

# Generated at 2022-06-20 20:37:46.975319
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    platform_facts = {'kernel': 'NetBSD'}
    assert NetBSDVirtualCollector(platform_facts)._platform == 'NetBSD'

# Generated at 2022-06-20 20:37:50.078542
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    nvcollector = NetBSDVirtualCollector()
    assert nvcollector.get_fact_class() == NetBSDVirtual
    assert nvcollector.get_platform() == 'NetBSD'

# Generated at 2022-06-20 20:37:55.587196
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd = NetBSDVirtual()

    assert netbsd._platform == 'NetBSD'
    assert netbsd.get_virtual_facts()['virtualization_type'] == ''
    assert netbsd.get_virtual_facts()['virtualization_role'] == ''
    assert netbsd.get_virtual_facts()['virtualization_tech_guest'] == set()
    assert netbsd.get_virtual_facts()['virtualization_tech_host'] == set()

# Generated at 2022-06-20 20:37:57.681387
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    nv = NetBSDVirtual()
    assert nv.platform == 'NetBSD'

# Generated at 2022-06-20 20:37:59.521988
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector is not None


# Generated at 2022-06-20 20:38:00.619499
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    NetBSDVirtualCollector()

# Generated at 2022-06-20 20:38:03.854843
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert netbsd_virtual_collector._fact_class == NetBSDVirtual
    assert netbsd_virtual_collector._platform == 'NetBSD'

# Generated at 2022-06-20 20:38:07.732549
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsdvirtualcollector = NetBSDVirtualCollector()
    assert netbsdvirtualcollector.platform == 'NetBSD'
    assert netbsdvirtualcollector._fact_class == NetBSDVirtual

# Should return empty dict

# Generated at 2022-06-20 20:38:16.987978
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    sysctl_result = dict()
    sysctl_result['machdep.dmi.system-product'] = 'VMware Virtual Platform'
    sysctl_result['machdep.hypervisor'] = 'VMware Virtual Platform'
    sysctl_result['machdep.dmi.system-vendor'] = 'Dell Inc.'
    virtual = NetBSDVirtual(sysctl_result)
    assert virtual.collect() == {
        'virtualization_role': 'guest',
        'virtualization_type': 'VMware',
        'virtualization_tech_guest': set(['kvm', 'xen', 'VMware']),
        'virtualization_tech_host': set(['kvm', 'xen', 'VMware'])
    }

# Generated at 2022-06-20 20:38:19.395046
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    test_class = NetBSDVirtual({}, None)
    assert test_class.platform == 'NetBSD'

# Generated at 2022-06-20 20:38:24.211956
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual()
    assert virtual.platform == 'NetBSD'

# Generated at 2022-06-20 20:38:26.229582
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    nv = NetBSDVirtual()
    assert nv.name == 'NetBSD'

# Generated at 2022-06-20 20:38:30.939362
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():

    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert netbsd_virtual_collector.platform == 'NetBSD'
    assert netbsd_virtual_collector._fact_class == NetBSDVirtual


# Generated at 2022-06-20 20:38:32.407756
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    test_class = NetBSDVirtual(None)
    assert test_class



# Generated at 2022-06-20 20:38:34.325425
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert (netbsd_virtual.platform == 'NetBSD')


# Generated at 2022-06-20 20:38:37.064991
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.platform == 'NetBSD'


# Generated at 2022-06-20 20:38:43.397601
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual().get_virtual_facts()
    assert 'virtualization_role' in virtual_facts.keys()
    assert 'virtualization_type' in virtual_facts.keys()
    assert 'virtualization_tech_host' in virtual_facts.keys()
    assert 'virtualization_tech_guest' in virtual_facts.keys()

# Generated at 2022-06-20 20:38:52.831851
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    NetBSDVirt_test_object = NetBSDVirtual({})
    NetBSDVirt_test_object.module = {'run_command': lambda x: \
        ("machdep.dmi.system-product='VirtualBox' machdep.dmi.system-vendor='innotek GmbH' machdep.hypervisor=''", '', 0)}
    assert NetBSDVirt_test_object.get_virtual_facts() == {'virtualization_type': 'xen', 'virtualization_role': 'guest', 'virtualization_tech_host': set([]), 'virtualization_tech_guest': set(['xen'])}

# Generated at 2022-06-20 20:38:54.475803
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    facts_dict = NetBSDVirtualCollector().collect()
    assert facts_dict is not None

# Generated at 2022-06-20 20:39:00.531896
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    # NetBSDVirtualCollector is supposed to only be used on NetBSD
    # For the plattforms it is not suitable for an empty dict is expected
    hypervisors = ['Linux', 'FreeBSD', 'OpenBSD']
    for hypervisor in hypervisors:
        virtual_collector = NetBSDVirtualCollector(hypervisor)
        assert virtual_collector.get_facts() == {}
    assert NetBSDVirtualCollector('NetBSD').get_facts() != {}

# Generated at 2022-06-20 20:39:14.668134
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd = NetBSDVirtual()
    # Make sure we are on the correct platform.
    assert netbsd._platform == 'NetBSD'
    # Make sure the correct fact class is set.
    assert netbsd.__class__.__name__ == 'NetBSDVirtual'
    # Make sure the correct fact_subclass is set.
    assert netbsd._fact_class.__name__ == 'NetBSDVirtual'
    # Assert that virtualization_type is empty.
    assert netbsd.get_virtual_facts()['virtualization_type'] in ('', 'guest')
    # Make sure the correct keys are set.
    assert netbsd.get_virtual_facts().keys() == netbsd.get_virtual_facts().keys()


# Generated at 2022-06-20 20:39:19.211248
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virtual_collector = NetBSDVirtualCollector()
    assert virtual_collector._fact_class == NetBSDVirtual
    assert virtual_collector._platform == 'NetBSD'

# Generated at 2022-06-20 20:39:27.879813
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Create a dummy class for testing.
    class DummyNetBSDVirtual(object):
        def __init__(self):
            setattr(self, 'machdep.dmi.system-product', 'VMware Virtual Platform')
            setattr(self, 'machdep.dmi.system-vendor', 'VMware, Inc.')
            setattr(self, 'machdep.hypervisor', 'VMware')

    # Instantiate the class and run facts.
    netbsd_virtual = DummyNetBSDVirtual()
    facts = NetBSDVirtual().get_virtual_facts(netbsd_virtual)

    assert facts['virtualization_type'] == 'VMware'
    assert facts['virtualization_role'] == 'guest'


# Generated at 2022-06-20 20:39:31.709735
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    # Test that NetBSDVirtualCollector correctly initializes VirtualCollector
    c = NetBSDVirtualCollector()
    assert c.platform == 'NetBSD'
    assert c._fact_class.platform == 'NetBSD'


# Generated at 2022-06-20 20:39:39.363435
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    test_data_path = os.path.join(os.path.dirname(__file__), '../testing_data/virtual/NetBSD')
    NetBSDVirtual.sysctl_values = VirtualCollector._get_sysctl_values(os.path.join(test_data_path, 'sysctl_values.txt'))
    NetBSDVirtual.lspci_values = VirtualCollector._get_lspci_values(os.path.join(test_data_path, 'lspci_values.txt'))
    virtual_facts = NetBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'oracle'
    assert virtual_facts['virtualization_role'] == 'guest'

# Generated at 2022-06-20 20:39:41.827941
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    x = NetBSDVirtualCollector()
    assert x.platform == 'NetBSD'

# Generated at 2022-06-20 20:39:43.934153
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    res = VirtualCollector._get_facts(NetBSDVirtualCollector, NetBSDVirtual)
    assert 'virtualization_type' in res

# Generated at 2022-06-20 20:39:45.256072
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virt_obj = NetBSDVirtual()
    assert virt_obj.is_virtual == 0

# Generated at 2022-06-20 20:39:46.712253
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual(None)
    assert virtual.platform == 'NetBSD'

# Generated at 2022-06-20 20:39:49.805042
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd = NetBSDVirtualCollector()
    assert netbsd.platform == 'NetBSD'


# Generated at 2022-06-20 20:40:04.427594
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert isinstance(NetBSDVirtualCollector(), NetBSDVirtualCollector)

# Generated at 2022-06-20 20:40:06.043110
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector
    assert netbsd_virtual_collector()

# Generated at 2022-06-20 20:40:08.380884
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virt = NetBSDVirtual()
    assert virtualization_type == ''
    assert virtualization_role == ''
    assert virtualization_system == ''

# Generated at 2022-06-20 20:40:11.505837
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    """
    Constructor of NetBSDVirtualCollector generates an instance of NetBSDVirtual
    """
    my_obj = NetBSDVirtualCollector()
    assert isinstance(my_obj._fact_class, NetBSDVirtual)

# Generated at 2022-06-20 20:40:15.996256
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual().get_virtual_facts()
    # At this time, these are the expected test results
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_guest'] == {'xen'}
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-20 20:40:19.158988
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    x = NetBSDVirtualCollector()
    assert x.platform == 'NetBSD'
    assert x._platform == 'NetBSD'
    assert x._fact_class == NetBSDVirtual

# Generated at 2022-06-20 20:40:20.818761
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virtual_detect = NetBSDVirtualCollector()
    assert virtual_detect



# Generated at 2022-06-20 20:40:32.052176
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    mocked_facts = {
        'machdep.dmi.system-product': 'VirtualBox',
        'machdep.dmi.system-vendor': 'innotek GmbH',
        'machdep.hypervisor': 'none'
    }
    netbsd_virtual = NetBSDVirtual(mocked_facts, None)
    netbsd_virtual_facts = netbsd_virtual.get_virtual_facts()
    assert netbsd_virtual_facts['virtualization_type'] == 'virtualbox'
    assert netbsd_virtual_facts['virtualization_role'] == ''
    assert 'virtualbox' in netbsd_virtual_facts['virtualization_tech_host']
    assert 'virtualbox' not in netbsd_virtual_facts['virtualization_tech_guest']


# Generated at 2022-06-20 20:40:40.914753
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtualFactCollector()
    virtual_facts.collect()
    virtual_facts.populate()
    data = virtual_facts.data()
    assert 'virtualization_type' in data
    assert 'virtualization_role' in data
    assert 'virtualization_sysctl_args' in data
    assert 'virtualization_product_facts' in data
    assert 'virtualization_vendor_facts' in data
    assert 'virtualization_tech_host' in data
    assert 'virtualization_tech_guest' in data

# Generated at 2022-06-20 20:40:47.742247
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    f = NetBSDVirtual()
    f._module = {}
    f._module['command'] = lambda cmd: "machdep.dmi.system-product=VirtualBox\n" \
        "machdep.dmi.system-vendor=innotek GmbH"

    f.collect()

    assert f.get_virtual_facts() == {
        'virtualization_role': 'guest',
        'virtualization_type': 'virtualbox',
        'virtualization_tech_host': {'virtualbox'},
        'virtualization_tech_guest': {'virtualbox'},
    }


# Generated at 2022-06-20 20:41:23.227169
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual_facts = dict()
    netbsd_virtual_facts['virtualization_type'] = 'kvm'
    netbsd_virtual_facts['virtualization_role'] = 'guest'
    netbsd_virtual_facts['virtualization_tech_guest'] = {'kvm'}
    netbsd_virtual_facts['virtualization_tech_host'] = {'kvm'}
    netbsd_virtual = NetBSDVirtual()
    # Test for virtualization_type and virtualization_role
    assert netbsd_virtual_facts == netbsd_virtual.get_virtual_facts()


# Generated at 2022-06-20 20:41:25.338183
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual({})
    assert netbsd_virtual.platform == 'NetBSD'


# Generated at 2022-06-20 20:41:27.691221
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    sysctl_data = 'hw.model=amd64'
    virtual_obj = NetBSDVirtual(sysctl_data)
    assert virtual_obj.platform == 'NetBSD'


# Generated at 2022-06-20 20:41:30.742626
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virtual_collector = NetBSDVirtualCollector()
    assert virtual_collector._fact_class == NetBSDVirtual
    assert virtual_collector._platform == 'NetBSD'

# Generated at 2022-06-20 20:41:33.894531
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_instance = NetBSDVirtual()
    assert 'NetBSD' == virtual_instance.platform

# Generated at 2022-06-20 20:41:39.665611
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netBSDVirtual = NetBSDVirtual()
    assert netBSDVirtual.platform == 'NetBSD'
    assert netBSDVirtual.get_virtual_facts() == {}
    assert netBSDVirtual.get_virtual_facts() == {'virtualization_role': '', 'virtualization_type': '',
                                                'virtualization_technology': '', 'virtualization_tech_host': set(),
                                                'virtualization_tech_guest': set(), 'virtualization_product': ''}


# Generated at 2022-06-20 20:41:52.005679
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    from ansible_collections.ansible.community.tests.unit.module_utils.facts.virtual.test_virtual import FakeSysctl
    from ansible_collections.ansible.community.tests.unit.module_utils.facts.virtual.test_virtual import FakeStat
    from ansible_collections.ansible.community.tests.unit.module_utils.facts.virtual.test_virtual import FakeProcess

    # NOTE: The 'fake' calls are directly within the module.
    facts = NetBSDVirtual({'sysctl': FakeSysctl(),
                           'stat': FakeStat(),
                           'process': FakeProcess()},
                          {})
    # Create expected result

# Generated at 2022-06-20 20:41:59.588302
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual = NetBSDVirtual()

    # Load a single fact, see if it matches expected output.
    # sysctl_exists() can't be easily mocked so this is skipped for now.
    sysctl_virtual_facts = virtual.get_virtual_facts()
    assert sysctl_virtual_facts['virtualization_role'] == ''
    assert sysctl_virtual_facts['virtualization_type'] == ''
    assert sysctl_virtual_facts['virtualization_tech_guest'] == set()
    assert sysctl_virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-20 20:42:02.735174
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    collector = NetBSDVirtualCollector()
    assert collector._platform == "NetBSD"
    assert collector._fact_class == NetBSDVirtual

# Generated at 2022-06-20 20:42:08.761280
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual(None, None).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'N/A'
    assert virtual_facts['virtualization_role'] == 'N/A'
    assert list(virtual_facts['virtualization_tech_host']) == []
    assert list(virtual_facts['virtualization_tech_guest']) == []

# Generated at 2022-06-20 20:43:16.466873
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Description: Test method get_virtual_facts of class NetBSDVirtual

    # Setup Test
    class_params = dict(module_name='ansible.module_utils.facts.virtual.netbsd',
                        class_name='NetBSDVirtual',
                        method_name='get_virtual_facts')
    test_params = dict()
    test_obj = VirtualTest(class_params, test_params)

    # Test execution
    test_obj.run_test()


if __name__ == "__main__":
    test_NetBSDVirtual_get_virtual_facts()

# Generated at 2022-06-20 20:43:17.950765
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    n = NetBSDVirtualCollector()
    assert n.platform == 'NetBSD'
    assert n.fact_class == NetBSDVirtual


# Generated at 2022-06-20 20:43:19.887060
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert(netbsd_virtual_collector._fact_class is NetBSDVirtual)

# Generated at 2022-06-20 20:43:21.947020
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsdvirtual = NetBSDVirtual()
    assert type(netbsdvirtual) == NetBSDVirtual

# Generated at 2022-06-20 20:43:24.263142
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Unit test for the get_virtual_facts method of class NetBSDVirtual
    return

# Generated at 2022-06-20 20:43:28.768659
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    facts = {}
    set_module_args(dict(gather_subset='!all', filter='virtual'))
    virtual_facts = NetBSDVirtual(module=None)
    facts.update(virtual_facts.get_virtual_facts())
    assert facts['virtualization_type'] == ''
    assert facts['virtualization_role'] == ''

# Generated at 2022-06-20 20:43:32.441609
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virt_facts = NetBSDVirtualCollector()
    assert virt_facts._platform == 'NetBSD'
    assert virt_facts._fact_class == NetBSDVirtual


# Generated at 2022-06-20 20:43:36.518944
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    # instantiating class NetBSDVirtualCollector
    virtual_collector = NetBSDVirtualCollector()

    # assert the class instance
    assert virtual_collector._fact_class == NetBSDVirtual
    assert virtual_collector._platform == 'NetBSD'

# Generated at 2022-06-20 20:43:39.048657
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual_facts = NetBSDVirtual()
    assert netbsd_virtual_facts.platform == 'NetBSD'

if __name__ == '__main__':
    test_NetBSDVirtual()

# Generated at 2022-06-20 20:43:42.601076
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # create instance of NetBSDVirtual
    netbsd_virtual = NetBSDVirtual()
    # get virtual facts
    virtual_facts = netbsd_virtual.get_virtual_facts()
    # validate virtual_facts
    assert virtual_facts['virtualization_type'] == 'Linux'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_type_role'] == 'guest/Linux'

# Generated at 2022-06-20 20:46:21.240113
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    fc = NetBSDVirtualCollector()
    assert fc.platform == "NetBSD"
    assert fc._fact_class == NetBSDVirtual
    assert fc.collect()

# Generated at 2022-06-20 20:46:22.857686
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    obj = NetBSDVirtual()
    assert obj


# Generated at 2022-06-20 20:46:34.013557
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    input_value = {}

# Generated at 2022-06-20 20:46:42.141507
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # When no virtualization technology is detected
    assert NetBSDVirtual({}).get_virtual_facts() == {'virtualization_type': '',
                                                     'virtualization_role': '',
                                                     'virtualization_tech_guest': set(),
                                                     'virtualization_tech_host': set()}

    # When a virtualization technology is detected
    assert NetBSDVirtual({'ansible_sysctl': {'machdep.hypervisor': 'XenVMM'}}).get_virtual_facts() == {'virtualization_type': 'Xen',
                                                                                                       'virtualization_role': 'guest',
                                                                                                       'virtualization_tech_guest': {'xen'},
                                                                                                       'virtualization_tech_host': {'xen'}}

    # When

# Generated at 2022-06-20 20:46:45.502372
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    v = NetBSDVirtualCollector()
    assert v.platform == 'NetBSD'
    assert v._fact_class == NetBSDVirtual

# Generated at 2022-06-20 20:46:46.983755
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    v = NetBSDVirtual()
    assert v.platform == 'NetBSD'
    assert not v.flags

# Generated at 2022-06-20 20:46:57.930716
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual_fact = NetBSDVirtual()
    netbsd_virtual_fact._module = dict()

    # Set empty values as default
    netbsd_virtual_fact._module['virtualization_type'] = ''
    netbsd_virtual_fact._module['virtualization_role'] = ''

    # test for machdep.dmi.system-product
    netbsd_virtual_fact.get_sysctl_virtual_facts = lambda x: 'VMWare Virtual Platform'
    netbsd_virtual_fact._module['virtualization_type'] = ''
    netbsd_virtual_fact._module['virtualization_role'] = ''
    virtual_facts = netbsd_virtual_fact.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'vmware'

# Generated at 2022-06-20 20:47:00.294633
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual()

    # Keeping these for backwards compatibility.
    for fact in ['virtualization_type', 'virtualization_role']:
        assert fact in virtual_facts.data
        assert virtual_facts.data[fact] is None

# Generated at 2022-06-20 20:47:11.597031
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.netbsd import NetBSDVirtual
    from ansible.module_utils.facts.virtual.generic import VirtualGenericDetectionMixin
    from ansible.module_utils.facts.virtual.sysctl import VirtualSysctlDetectionMixin

    class DerivedNetBSDVirtual(
            NetBSDVirtual,
            VirtualGenericDetectionMixin,
            VirtualSysctlDetectionMixin):
        pass

    netbsd_virtual = DerivedNetBSDVirtual()

    def detect_virt_product(self, sysctl_name):
        return {'virtualization_type': '',
                'virtualization_role': '',
                'virtualization_tech_guest': set(),
                'virtualization_tech_host': set()}


# Generated at 2022-06-20 20:47:17.896047
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual()
    assert virtual.get_virtual_facts()['virtualization_type'] == ''
    assert virtual.get_virtual_facts()['virtualization_role'] == ''
    assert len(virtual.get_virtual_facts()['virtualization_tech_guest']) == 0
    assert len(virtual.get_virtual_facts()['virtualization_tech_host']) == 0

    # Unit test for method NetBSDVirtual.detect_virt_vendor
    def test_NetBSDVirtual_detect_virt_vendor():
        virtual = NetBSDVirtual()

        # Test for empty sysctl output
        def test_empty():
            virtual.sysctl_output = ''
            assert not virtual.detect_virt_vendor('machdep.hypervisor')['virtualization_type']

        # Test for host