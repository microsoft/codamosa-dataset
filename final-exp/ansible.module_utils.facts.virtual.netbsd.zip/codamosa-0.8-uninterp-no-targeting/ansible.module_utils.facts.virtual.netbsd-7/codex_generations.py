

# Generated at 2022-06-20 20:37:45.839659
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual({}, {})
    assert virtual.virtualization_type == ''
    assert virtual.virtualization_role == ''

# Generated at 2022-06-20 20:37:49.300886
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert netbsd_virtual_collector._fact_class._platform == 'NetBSD'
    assert netbsd_virtual_collector.platform == 'NetBSD'



# Generated at 2022-06-20 20:37:53.290965
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virtual = NetBSDVirtualCollector()

    assert virtual.platform == 'NetBSD'
    assert virtual._fact_class == NetBSDVirtual
    assert virtual._platform == 'NetBSD'



# Generated at 2022-06-20 20:37:55.098957
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual({}, {})
    assert netbsd_virtual
    assert netbsd_virtual.platform == 'NetBSD'

# Generated at 2022-06-20 20:38:04.336361
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual = NetBSDVirtual()
    facts_dict = netbsd_virtual.get_virtual_facts()

    assert facts_dict['virtualization_type'] == 'physical'
    assert facts_dict['virtualization_role'] == 'host'
    assert facts_dict['virtualization_tech_guest'] == set()
    assert facts_dict['virtualization_tech_host'] == set(['hostdev', 'physical'])
    assert facts_dict['virtualization_product_name'] == 'Physical'
    assert facts_dict['virtualization_product_version'] == 'Physical'

# Generated at 2022-06-20 20:38:07.768396
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert netbsd_virtual_collector._platform == 'NetBSD'
    assert netbsd_virtual_collector._fact_class == NetBSDVirtual

# Generated at 2022-06-20 20:38:10.154350
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsdv = NetBSDVirtual()
    assert netbsdv.platform == 'NetBSD'


# Generated at 2022-06-20 20:38:15.062492
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    # Create a object of NetBSDVirtualCollector class
    test_obj = NetBSDVirtualCollector()
    # Check the platform property of object test_obj
    assert test_obj._platform == 'NetBSD'
    # Check the fact_class property of object test_obj
    assert test_obj._fact_class.platform == 'NetBSD'

# Generated at 2022-06-20 20:38:26.824982
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    fixture_path = os.path.join(os.path.dirname(__file__), 'fixtures')

    def sysctl_mock(*args, **kwargs):
        if args == ('machdep.dmi.system-vendor',):
            return 'QEMU'
        elif args == ('machdep.dmi.system-product',):
            return 'Standard PC (Q35 + ICH9, 2009)'

    # Test a QEMU virtual machine
    virtual = NetBSDVirtual(Facts({'sysctl': sysctl_mock}))
    facts = virtual.get_virtual_facts()
    assert facts['virtualization_type'] == 'kvm'
    assert facts['virtualization_role'] == 'guest'

# Generated at 2022-06-20 20:38:32.578088
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual({}, {})
    actual_result = virtual.get_virtual_facts()
    expected_result = dict(
        virtualization_role='host',
        virtualization_type='',
        virtualization_tech_host=set(),
        virtualization_tech_guest=set()
    )
    assert actual_result == expected_result


# Generated at 2022-06-20 20:38:37.003944
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual({}, {})
    assert virtual.platform == 'NetBSD'


# Generated at 2022-06-20 20:38:39.623939
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual()
    assert virtual._platform == 'NetBSD'
    assert virtual._fact_class == 'NetBSDVirtual'

# Generated at 2022-06-20 20:38:50.845536
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    facts_instance = NetBSDVirtual()
    sysctl_value = 'NetBSD'
    expected_virtual_facts = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }
    # 'machdep.dmi.system-product' and 'machdep.dmi.system-vendor' are checked
    # before 'machdep.hypervisor'.
    sysctl_value = 'NetBSD'
    expected_virtual_facts['virtualization_type'] = ''
    expected_virtual_facts['virtualization_role'] = ''
    expected_virtual_facts['virtualization_tech_guest'] = set()
    expected_virtual_facts['virtualization_tech_host'] = set()


# Generated at 2022-06-20 20:38:58.586117
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual._platform == 'NetBSD'
    assert netbsd_virtual.platform == 'NetBSD'
    assert netbsd_virtual.virtualization_type == ''
    assert netbsd_virtual.virtualization_role == ''
    assert netbsd_virtual.virtualization_tech_guest == set()
    assert netbsd_virtual.virtualization_tech_host == set()



# Generated at 2022-06-20 20:39:01.755827
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    assert NetBSDVirtual()


# Generated at 2022-06-20 20:39:11.706162
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    sysctl_values = {
        'machdep.dmi.system-product': 'LENOVO',
        'machdep.dmi.system-vendor': 'LENOVO',
        'machdep.hypervisor.name': 'VMWARE',
    }

    test_virtual = NetBSDVirtual(sysctl_values)
    ret_val = test_virtual.get_virtual_facts()

    assert ret_val['virtualization_type'] == 'xen'
    assert ret_val['virtualization_role'] == 'guest'
    assert 'xen' in ret_val['virtualization_tech_guest']
    assert 'xen' not in ret_val['virtualization_tech_host']


# Generated at 2022-06-20 20:39:18.148238
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():

    # Test detection for virtualization tech of product
    test_sysctl_values = {
        'machdep.dmi.system-product': 'VMware Virtual Platform',
    }

    test_virtual = NetBSDVirtual(fact_class=None, sysctl_values=test_sysctl_values)
    virtual_facts = test_virtual.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == 'VMware'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert {'vmware', 'hypervisor'} == virtual_facts['virtualization_tech_guest']
    assert {'vmware'} == virtual_facts['virtualization_tech_host']

    # Test detection for virtualization tech of vendor

# Generated at 2022-06-20 20:39:23.706302
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    facts_dict = dict()
    virtual_facts = NetBSDVirtual(facts_dict).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == '' and virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_guest'] == set() and virtual_facts['virtualization_tech_host'] == set()


# Generated at 2022-06-20 20:39:26.408457
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert netbsd_virtual_collector._platform == 'NetBSD'
    assert netbsd_virtual_collector._fact_class == NetBSDVirtual

# Generated at 2022-06-20 20:39:32.243626
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    x = NetBSDVirtual()
    assert x.platform == 'NetBSD'
    assert x.get_virtual_facts() == {'virtualization_type': '',
                                     'virtualization_role': '',
                                     'virtualization_tech_guest': set(),
                                     'virtualization_tech_host': set()}

# Generated at 2022-06-20 20:39:41.926990
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector._platform == 'NetBSD'
    assert NetBSDVirtualCollector._fact_class == NetBSDVirtual

# Generated at 2022-06-20 20:39:42.890049
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    NetBSDVirtualCollector()


# Generated at 2022-06-20 20:39:51.377676
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    sysctl_output = {'machdep.dmi.system-product': 'iMac11,3',
                     'machdep.hypervisor.vmm': 'KVM',
                     'machdep.hypervisor.vmm.vendor': 'KVM',
                     'machdep.hypervisor.version': '2.6',
                     'machdep.hypervisor.version.major': '2',
                     'machdep.hypervisor.version.minor': '6',
                     'machdep.hypervisor.vmm.product': 'VMware Virtual Platform',
                     'machdep.dmi.system-vendor': 'Apple Inc.'}
    virtual_machine = NetBSDVirtual(sysctl_output)
    virtual_facts = virtual_machine.get_virtual_facts()
    assert virtual_facts['virtualization_type']

# Generated at 2022-06-20 20:39:52.822743
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():

    v_obj = NetBSDVirtual()
    assert v_obj

# Generated at 2022-06-20 20:39:58.222736
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual()
    virt_facts = virtual_facts.get_virtual_facts()
    assert 'virtualization_type' in virt_facts
    assert 'virtualization_role' in virt_facts
    assert 'virtualization_tech_guest' in virt_facts
    assert 'virtualization_tech_host' in virt_facts

# Generated at 2022-06-20 20:40:09.533874
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Mock result returned by detect_virt_vendor
    class MockVirtualVendor(object):
        virtualization_type = ''
        virtualization_tech_guest = set()
        virtualization_tech_host = set()

    # Mock result returned by detect_virt_product
    class MockVirtualProduct(object):
        virtualization_type = 'xen'
        virtualization_tech_guest = {'xen'}
        virtualization_tech_host = set()

    virtual_facts = NetBSDVirtual()
    virtual_facts.detect_virt_product = Mock(name='detect_virt_product', return_value=MockVirtualProduct())
    virtual_facts.detect_virt_vendor = Mock(name='detect_virt_vendor', return_value=MockVirtualVendor())

    virtual_facts.is_

# Generated at 2022-06-20 20:40:11.714629
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    collector = NetBSDVirtualCollector()
    assert collector.platform == 'NetBSD'
    assert len(collector.collect()) > 0

# Generated at 2022-06-20 20:40:18.448315
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual = NetBSDVirtual()
    virtual.device_facts = {'machdep.hypervisor': 'VirtualBox', 'machdep.dmi.product-version': 'VirtualBox',
                            'machdep.dmi.system-product': 'VirtualBox', 'machdep.dmi.system-vendor': 'innotek GmbH'}
    virtual_facts = virtual.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == 'virtualbox'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_product'] == 'VirtualBox'
    assert virtual_facts['virtualization_product_version'] == 'VirtualBox'
    assert virtual_facts['virtualization_product_version'] == virtual_facts['virtualization_product']

# Generated at 2022-06-20 20:40:29.800378
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual = NetBSDVirtual()
    netbsd_isfile_paths = [('/proc/cpuinfo', False),
                           ('/dev/xencons', False),
                           ('/dev/kvm', False),
                           ('/proc/xen/capabilities', False),
                           ('/sys/hypervisor/type', False),
                           ('/sys/devices/virtual/dmi/id/product_name', False),
                           ('/sys/devices/virtual/dmi/id/sys_vendor', False)]
    netbsd_isdir_paths = []
    netbsd_readfile_data = {}

# Generated at 2022-06-20 20:40:33.078208
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    """
    Unit test for constructor of class NetBSDVirtualCollector
    """
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert isinstance(netbsd_virtual_collector, NetBSDVirtualCollector)

# Generated at 2022-06-20 20:40:41.611282
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virtual_collector = NetBSDVirtualCollector()
    assert virtual_collector.fact_class == NetBSDVirtual

# Generated at 2022-06-20 20:40:44.259184
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert netbsd_virtual_collector.platform  == 'NetBSD'
    assert netbsd_virtual_collector._fact_class == NetBSDVirtual

# Generated at 2022-06-20 20:40:50.722103
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    fake_collector = NetBSDVirtualCollector()
    fake_collector.sysctl_mixed_content = {
        'machdep.dmi.system-product': 'VMWare Virtual Platform',
        'machdep.hypervisor': 'VMware Virtual Platform',
    }

    # test for vmware virtual platform
    assert fake_collector.get_virtual_facts() == {
        'virtualization_type': 'VMware Virtual Platform',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['VMware Virtual Platform']),
        'virtualization_tech_host': set(['VMware Virtual Platform']),
    }

# Generated at 2022-06-20 20:40:53.236951
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    vc = NetBSDVirtualCollector(None)
    assert vc is not None

# Generated at 2022-06-20 20:40:55.697301
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    h = NetBSDVirtual()
    assert(h.platform == 'NetBSD')
    assert(h.get_virtual_facts() == {})

# Generated at 2022-06-20 20:40:59.348038
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts
    assert 'virtualization_product_version' in virtual_facts

# Generated at 2022-06-20 20:41:01.307188
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector().platform == 'NetBSD'

# Generated at 2022-06-20 20:41:08.206556
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual = NetBSDVirtual()
    netbsd_virtual._read_sysctl = lambda x: 'foo'
    netbsd_virtual_facts = netbsd_virtual.get_virtual_facts()
    expected_netbsd_virtual_facts = {'virtualization_type': 'xen', 'virtualization_role': 'guest', 'virtualization_tech_guest': {'xen'}, 'virtualization_tech_host': set()}
    assert netbsd_virtual_facts == expected_netbsd_virtual_facts


# Generated at 2022-06-20 20:41:10.250847
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual(None, {})
    assert virtual.platform == 'NetBSD'
    assert virtual._virtual_facts == {}


# Generated at 2022-06-20 20:41:21.886529
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual()

    def mock_sysctl_exists(sysctl_name):
        if sysctl_name == 'machdep.dmi.system-product':
            return False
        if sysctl_name == 'machdep.dmi.system-vendor':
            return True
        if sysctl_name == 'machdep.hypervisor':
            return True
        return False

    def mock_sysctl_get(sysctl_name):
        if sysctl_name == 'machdep.dmi.system-vendor':
            # Return a vendor that won't match in the virtual_vendor_facts
            # detection logic
            return 'ACME Inc.'

# Generated at 2022-06-20 20:41:36.323910
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():

    # Test default properties
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert netbsd_virtual_collector._fact_class == NetBSDVirtual
    assert netbsd_virtual_collector._platform == NetBSDVirtual._platform

# Generated at 2022-06-20 20:41:45.175906
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Create an instance of NetBSDVirtual
    nv = NetBSDVirtual({})

    # Create a dictionary with values to be returned by sysctl_all method
    # when called with 'machdep.hypervisor' key
    vdict = {}
    vdict['machdep.hypervisor'] = 'bochs'
    vdict_none = {}
    vdict_none['machdep.hypervisor'] = 'none'

    # Create a dictionary with values to be returned by sysctl_all method
    # when called with 'machdep.dmi.system-product' key
    pdict = {}
    pdict['machdep.dmi.system-product'] = 'VMWare Virtual Platform'

    # Create a dictionary with values to be returned by sysctl_all method
    # when called with 'machdep.dmi.system

# Generated at 2022-06-20 20:41:47.210779
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual()
    assert virtual is not None


# Generated at 2022-06-20 20:41:56.510441
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virt_facts = NetBSDVirtual()
    if os.path.exists('/proc/self/status'):
        virt_facts.sysctl_values['machdep.hypervisor'] = 'BHYVE'
        virt_facts.sysctl_values['machdep.dmi.system-vendor'] = 'BHYVE'
        virt_facts.sysctl_values['machdep.dmi.system-product'] = 'BHYVE'

        virt_test_facts = virt_facts.get_virtual_facts()

        assert virt_test_facts['virtualization_type'] == 'BHYVE'
        assert virt_test_facts['virtualization_role'] == 'guest'
        assert 'vmware' not in virt_test_facts['virtualization_tech_guest']
        assert 'Hypervisor' not in virt_

# Generated at 2022-06-20 20:41:59.436504
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    """
    Constructor of class NetBSDVirtualCollector is no-op,
    don't test it's correctness.
    """
    assert NetBSDVirtualCollector() is None

# Generated at 2022-06-20 20:42:02.581943
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector._platform == 'NetBSD'
    assert NetBSDVirtualCollector._fact_class.platform == 'NetBSD'


# Generated at 2022-06-20 20:42:08.566008
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_technologies'] == set()
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-20 20:42:10.053570
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual({})
    assert virtual.virtualization_tech_guest == set()
    assert virtual.virtualization_tech_host == set()

    # Note: This is the default value provided by AnsibleModule.
    assert virtual.data == {}

# Generated at 2022-06-20 20:42:12.355678
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual('')
    assert isinstance(netbsd_virtual, NetBSDVirtual)

# Generated at 2022-06-20 20:42:14.426682
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector._platform == 'NetBSD'
    assert NetBSDVirtualCollector._fact_class == NetBSDVirtual


# Generated at 2022-06-20 20:42:50.376948
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert netbsd_virtual_collector._fact_class == NetBSDVirtual
    assert netbsd_virtual_collector._platform == 'NetBSD'


# Generated at 2022-06-20 20:42:53.452772
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virtual_collector = NetBSDVirtualCollector()
    assert virtual_collector.platform == 'NetBSD'
    assert virtual_collector.fact_class == NetBSDVirtual

# Generated at 2022-06-20 20:43:01.072010
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sysctl import VirtualSysctlDetectionMixin

    class MockSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self, *args, **kwargs):
            pass

        @staticmethod
        def sysctl(*keys):
            # For testing, we just return the key.
            return keys

    class MockNetBSDVirtual(MockSysctlDetectionMixin, NetBSDVirtual):
        def __init__(self, *args, **kwargs):
            pass

    virtual = MockNetBSDVirtual()
    facts = virtual.get_virtual_facts()
    assert facts['virtualization_type'] == 'hypervisor'
    assert facts['virtualization_role'] == 'host'
    assert facts['virtualization_product'] == 'kvm'
    assert facts

# Generated at 2022-06-20 20:43:01.903966
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    myvirt = NetBSDVirtual()
    assert myvirt



# Generated at 2022-06-20 20:43:05.105528
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    nvcol = NetBSDVirtualCollector()
    assert nvcol._platform == 'NetBSD'
    assert nvcol._fact_class.platform == 'NetBSD'

# Generated at 2022-06-20 20:43:12.748840
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual = NetBSDVirtual(module=None)

    # Test system is a bare metal
    virtual._module.get_bin_path.return_value = '/sbin/sysctl'
    virtual._module.run_command.return_value = (0, 'hw.model: Intel Core i5 CPU M 520 2.40GHz', '')
    virtual._module.run_command.return_value = ('', '', 1)
    virtual_facts = virtual.get_virtual_facts()
    expected_result = {}
    expected_result['virtualization_type'] = ''
    expected_result['virtualization_role'] = ''
    expected_result['virtualization_tech_host'] = set()
    expected_result['virtualization_tech_guest'] = set()
    assert virtual_facts == expected_result

    virtual._module.get_bin_

# Generated at 2022-06-20 20:43:14.659576
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    NetBSDVirtual()

# Generated at 2022-06-20 20:43:16.891749
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector(None)._platform == 'NetBSD'

# Generated at 2022-06-20 20:43:17.914728
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Nothing to test with this platform
    pass

# Generated at 2022-06-20 20:43:18.849312
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    NetBSDVirtualCollector()

# Generated at 2022-06-20 20:44:31.548066
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    NetBSDVirtualCollector()

# Generated at 2022-06-20 20:44:38.645475
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():

    netbsd_virtual_get_virtual_facts_obj = NetBSDVirtual()
    netbsd_virtual_get_virtual_facts_result = {
        'virtualization_technology': set(),
        'virtualization_role': '',
        'virtualization_type': '',
        'virtualization_technology_guest': set()
    }

    # No machdep.hypervisor. (machdep.dmi.system-vendor=QEMU)
    netbsd_virtual_get_virtual_facts_obj.sysctl_get = lambda x: {'machdep.hypervisor': ''}
    netbsd_virtual_get_virtual_facts_result.update({'virtualization_type': 'QEMU'})
    assert netbsd_virtual_get_virtual_facts_obj.get_virtual_facts() == net

# Generated at 2022-06-20 20:44:42.829082
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    obj = NetBSDVirtualCollector()
    assert obj.platform == 'NetBSD'
    assert obj.fact_class == NetBSDVirtual
    assert obj.fact_class().platform == 'NetBSD'


# Generated at 2022-06-20 20:44:49.261084
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():

    class FakeFile(object):
        def readline(self):
            return 'simba\n'

    # Set up a class for testing

    class NetBSDVirtualForTest(NetBSDVirtual):
        def __init__(self):
            self.facts_type = 'virtual'

        def _load_files(self):
            return {
                'machdep.hypervisor': FakeFile(),
                'machdep.dmi.system-vendor': FakeFile(),
                'machdep.dmi.system-product': FakeFile()
            }

        def _load_excluded_facts_files(self):
            return []

    virtual_facts = NetBSDVirtualForTest().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'xen'

# Generated at 2022-06-20 20:44:51.590027
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    """Unit test for constructor of class NetBSDVirtualCollector."""
    NetBSDVirtualCollector()

# Generated at 2022-06-20 20:44:52.391286
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    NetBSDVirtualCollector()

# Generated at 2022-06-20 20:44:59.848955
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    fake_sysctl_values = {b'machdep.dmi.system-product': 'VirtualBox',
                          b'machdep.dmi.system-vendor': 'innotek GmbH',
                          b'machdep.hypervisor': 'VMM'}
    fake_sysctl_file = '/tmp/ansible_test_fake_sysctl_file'
    write_fake_sysctl_file(fake_sysctl_file, fake_sysctl_values)
    fake_facts = {'kernel': 'NetBSD', 'module_setup': True}

# Generated at 2022-06-20 20:45:02.929900
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    collector = NetBSDVirtualCollector()
    assert collector.platform == 'NetBSD'


# Generated at 2022-06-20 20:45:09.178441
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    facts_dict = {}

    netbsd_virtual_instance = NetBSDVirtualCollector(facts_dict, {})
    assert netbsd_virtual_instance._platform == 'NetBSD'

    netbsd_virtual_instance._get_virtual_facts()
    assert netbsd_virtual_instance._facts_dict['virtualization_type'].strip() != ''

# Generated at 2022-06-20 20:45:10.941108
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    facts = NetBSDVirtual().get_virtual_facts()
    assert isinstance(facts, dict)