

# Generated at 2022-06-20 20:37:45.481410
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_obj = NetBSDVirtual()
    assert virtual_obj.platform == 'NetBSD'

# Generated at 2022-06-20 20:37:47.266180
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtualCollector.collect(None, None)
    assert virtual.platform == 'NetBSD'

# Generated at 2022-06-20 20:37:49.156744
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert netbsd_virtual_collector

# Generated at 2022-06-20 20:37:57.526842
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    module_utils = 'ansible.module_utils.facts.virtual.netbsd.NetBSDVirtual'
    sysctl_command = ['/sbin/sysctl', '-n']
    sysctl_key = 'machdep.dmi.system-product'
    fake_values = [
        'VirtualBox',
        'Oracle VirtualBox',
        'VMware Virtual Platform',
        'Amazon EC2 AMI',
        'KVM',
        'Bochs',
        'Parallels',
        'VMWare',
        'Microsoft Virtual Server',
        'bochs',
        'virt-manager',
        'VMware',
        'kvm',
        'OpenVZ',
        'ovzkernel',
        'Parallels'
    ]

    # Test 1: Test the "virtualization_type" and

# Generated at 2022-06-20 20:37:59.329325
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector is not None

# Unit Test for class NetBSDVirtual

# Generated at 2022-06-20 20:38:01.717235
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    collector = NetBSDVirtualCollector()
    assert collector
    assert collector._platform == 'NetBSD'
    assert collector._fact_class == NetBSDVirtual

# Generated at 2022-06-20 20:38:13.737540
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    data = {'sysctl': {}}
    # VirtualBox
    data['sysctl'].update({'machdep.dmi.system-product': 'VirtualBox',
                           'machdep.dmi.system-vendor': 'innotek GmbH',
                           'machdep.hypervisor': 'none'})
    result = NetBSDVirtual().get_virtual_facts(data)
    assert result['virtualization_type'] == 'virtualbox'
    assert result['virtualization_role'] == 'guest'
    assert result['virtualization_tech_guest'] == set(['virtualbox'])
    assert result['virtualization_tech_host'] == set(['virtualbox'])

    # VMware

# Generated at 2022-06-20 20:38:17.930522
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert issubclass(NetBSDVirtualCollector, VirtualCollector)
    assert NetBSDVirtualCollector._fact_class == NetBSDVirtual
    assert NetBSDVirtualCollector._platform == 'NetBSD'

# Generated at 2022-06-20 20:38:28.030095
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():

    mock_module_facts_dict = {
        'machdep.hypervisor': 'none',
        'machdep.dmi.system-product': 'VirtualBox',
        'machdep.dmi.system-vendor': 'Oracle Corporation',
    }

    mock_module_exit_json = {
        'changed': False,
        'ansible_facts': {
            'virtualization_type': 'virtualbox',
            'virtualization_role': 'guest',
            'virtualization_technologies_guest': ['virtualbox'],
            'virtualization_technologies_host': ['virtualbox']}
    }

    mock_module_instance = mock.MagicMock()
    mock_module_instance.params = mock_module_params


# Generated at 2022-06-20 20:38:28.889531
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector()

# Generated at 2022-06-20 20:38:36.806748
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert netbsd_virtual_collector.collect()
    assert netbsd_virtual_collector._platform == 'NetBSD'
    assert netbsd_virtual_collector.sysctl_path == '/sbin/sysctl'

# Generated at 2022-06-20 20:38:39.814464
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual().get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts

# Generated at 2022-06-20 20:38:42.096317
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual()

# Generated at 2022-06-20 20:38:50.441554
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virt = NetBSDVirtual()
    facts = virt.get_virtual_facts()
    assert facts['virtualization_type'] in ['xen', '', 'kvm', 'proxmoxve', 'hyperv'], \
        "Virtualization type " + facts['virtualization_type'] + " from NetBSD sysctls is unknown"
    assert facts['virtualization_role'] in ['host', 'guest', ''], \
        "Virtualization role " + facts['virtualization_role'] + " from NetBSD sysctls is unknown"
    assert facts['virtualization_type'] != '', \
        "Virtualization type from NetBSD sysctls is empty"

# Generated at 2022-06-20 20:38:54.130916
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    vf = NetBSDVirtual()
    assert vf.__class__.__name__ == 'NetBSDVirtual'


# Generated at 2022-06-20 20:38:56.216858
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    collector = NetBSDVirtualCollector()
    assert collector._platform == 'NetBSD'
    assert collector._fact_class == NetBSDVirtual

# Generated at 2022-06-20 20:39:04.498722
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual_obj = NetBSDVirtual({}, {})

    # Populate the machdep field of sysctl_all
    netbsd_virtual_obj.sysctl_all = {'machdep': {'dmi': {'system-vendor': 'VMWare, Inc.',
                                                            'system-product': 'VMware Virtual Platform'},
                                                    'hypervisor': 'QEMU'}}
    virtual_facts = netbsd_virtual_obj.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'vmware'
    assert virtual_facts['virtualization_type_role'] == 'guest'

# Generated at 2022-06-20 20:39:07.818624
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    c = NetBSDVirtualCollector()
    assert isinstance(c._fact_class, NetBSDVirtual)
    assert c._platform == 'NetBSD'

# Generated at 2022-06-20 20:39:10.218624
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    from ansible.module_utils.facts.virtual.netbsd import NetBSDVirtualCollector
    assert NetBSDVirtualCollector._platform == 'NetBSD'


# Generated at 2022-06-20 20:39:17.483581
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Build the subject to test
    ns_subject = NetBSDVirtual()

    # Build the test data
    vr_test_data = {
        'machdep.hypervisor': '',
        'machdep.dmi.system-vendor': '',
        'machdep.dmi.system-product': ''
    }

    # Run the get_virtual_facts() method
    vr_result = ns_subject.get_virtual_facts(vr_test_data)

    # Check the results
    assert vr_result['virtualization_type'] == ''
    assert vr_result['virtualization_role'] == ''
    assert vr_result['virtualization_product_name'] == ''
    assert vr_result['virtualization_product_version'] == ''

# Generated at 2022-06-20 20:39:26.413762
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    facter_virtual = NetBSDVirtual()
    assert facter_virtual.platform == 'NetBSD'
    assert facter_virtual.__class__.__name__ == 'NetBSDVirtual'


# Generated at 2022-06-20 20:39:37.320778
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()

    results = netbsd_virtual.get_all_facts()
    assert results['ansible_virtualization_type'] == 'VirtualBox' or results['ansible_virtualization_type'] == 'VMware' or results['ansible_virtualization_type'] == ''
    assert results['ansible_virtualization_role'] == 'guest' or results['ansible_virtualization_role'] == ''

    assert results['ansible_virtualization_type'] == results['ansible_machine_virtualization_type']
    assert results['ansible_virtualization_role'] == results['ansible_machine_virtualization_role']

    assert results['ansible_virtualization_type'] == results['ansible_system_virtualization_type']

# Generated at 2022-06-20 20:39:41.827867
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    x = NetBSDVirtualCollector()
    assert isinstance(x, NetBSDVirtualCollector)
    assert isinstance(x._fact_class, NetBSDVirtual)
    assert x._platform == "NetBSD"

# Generated at 2022-06-20 20:39:46.960876
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.platform == "NetBSD"
    assert netbsd_virtual.virtualization_type == ''
    assert netbsd_virtual.virtualization_role == ''
    assert netbsd_virtual.virtualization_tech_guest == set()
    assert netbsd_virtual.virtualization_tech_host == set()


# Generated at 2022-06-20 20:39:51.253087
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsdvirtual = NetBSDVirtual()
    assert netbsdvirtual.platform == "NetBSD", "Platform should be 'NetBSD' instead of: %s" % netbsdvirtual.platform

# Generated at 2022-06-20 20:39:53.058216
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsdvirtual = NetBSDVirtual(None)
    assert netbsdvirtual is not None


# Generated at 2022-06-20 20:39:58.400490
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual()
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_technologies_host'] == set()
    assert virtual_facts['virtualization_technologies_guest'] == set()

# Generated at 2022-06-20 20:40:03.894561
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.platform == 'NetBSD'
    assert netbsd_virtual.sysctl_exists("vm.kvm.vmcount") is False
    assert netbsd_virtual.sysctl_exists("machdep.hypervisor") is True

# Generated at 2022-06-20 20:40:10.326523
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual = NetBSDVirtual(collector=None)
    netbsd_virtual.sysctl_get.side_effect = netbsd_mock_sysctl_get

    assert netbsd_virtual.get_virtual_facts() == {
        'virtualization_type': 'xen',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['xen']),
        'virtualization_tech_host': set()
    }


# Generated at 2022-06-20 20:40:13.392937
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual_ins = NetBSDVirtual({})
    netbsd_virtual_facts = netbsd_virtual_ins.get_virtual_facts()
    assert netbsd_virtual_facts['virtualization_type'] == ''

# Generated at 2022-06-20 20:40:30.360122
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    """Test NetBSDVirtual class"""

    # This testcase is not supposed to fail as class NetBSDVirtual
    # is supposed to return a dict of virtualization facts
    virtual_facts = NetBSDVirtual()
    assert virtual_facts.get_virtual_facts() is not None

# Generated at 2022-06-20 20:40:31.898314
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virt = NetBSDVirtual()
    assert virt.platform == 'NetBSD'


# Generated at 2022-06-20 20:40:43.654226
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    test_os_data = {
        'os_data': {
            'sysctl': {
                'machdep.dmi.system-product': 'ThinkPad X1 Carbon',
                'machdep.dmi.system-vendor': 'LENOVO',
                'machdep.hypervisor': 'vbox',
            },
            'system': 'NetBSD',
            'distribution': 'NetBSD',
            'distribution_version': '8.1',
            'distribution_major_version': '8',
        }}

    result = NetBSDVirtual(fake_manager, test_os_data).get_virtual_facts()

    assert result.get('virtualization_type') == 'xen'
    assert result.get('virtualization_role') == 'guest'
    assert 'xen' in result.get

# Generated at 2022-06-20 20:40:45.673932
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virtual_collector = None
    virtual_collector = NetBSDVirtualCollector()
    assert isinstance(virtual_collector._fact_class, NetBSDVirtual)

# Generated at 2022-06-20 20:40:47.820568
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    facts_collector = NetBSDVirtualCollector()
    assert facts_collector.platform == 'NetBSD'
    assert facts_collector.fact_class == NetBSDVirtual


# Generated at 2022-06-20 20:40:52.673696
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_vc = NetBSDVirtualCollector()
    assert netbsd_vc.platform == 'NetBSD'
    assert netbsd_vc._fact_class == NetBSDVirtual


# Generated at 2022-06-20 20:40:55.138227
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():

    # instantiate the class
    myvirt = NetBSDVirtual()

    # check the properties
    assert myvirt.platform == "NetBSD"

# Generated at 2022-06-20 20:40:56.728339
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual()
    assert virtual.platform == 'NetBSD'



# Generated at 2022-06-20 20:40:58.055291
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
	s = NetBSDVirtualCollector()
	assert s.platform == 'NetBSD'

# Generated at 2022-06-20 20:41:09.075825
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.virtual import NetBSDVirtual
    nbsd_virtual = NetBSDVirtual()
    nbsd_virtual._module = FakeModule()

    # Test case: _sysctl_vendor contains 'QEMU'
    nbsd_virtual._sysctl_vendor = 'QEMU'
    virtual_facts = nbsd_virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'kvm'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_guest'] == {'kvm'}
    assert virtual_facts['virtualization_tech_host'] == {'kvm'}

# Generated at 2022-06-20 20:41:43.044323
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual = NetBSDVirtualCollector(None, None, None, None)
    facts = netbsd_virtual.get_virtual_facts()

    if facts['virtualization_type'] == 'xen':
        assert facts['virtualization_role'] == 'guest'
        assert 'xen' in facts['virtualization_tech_guest']
    elif facts['virtualization_type'] == 'openvz':
        assert facts['virtualization_role'] == 'guest'
        assert 'openvz' in facts['virtualization_tech_guest']
    else:
        assert facts['virtualization_type'] == ''
        assert facts['virtualization_role'] == ''
        assert facts['virtualization_tech_guest'] == set()
    assert facts['virtualization_tech_host'] == set()

# Generated at 2022-06-20 20:41:45.653049
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.platform == 'NetBSD'


# Generated at 2022-06-20 20:41:50.587151
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():

    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert netbsd_virtual_collector
    assert netbsd_virtual_collector.platform == 'NetBSD'
    assert netbsd_virtual_collector._fact_class is NetBSDVirtual

# Generated at 2022-06-20 20:41:56.936262
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    fake_sysctl_facts = {
        'machdep.dmi.system-vendor': 'Amazon EC2',
        'machdep.hypervisor': 'bhyve',
    }
    expected_virtual_facts = {
        "virtualization_type": "xen",
        "virtualization_role": "guest",
        "virtualization_tech_guest": {
            "xen"
        },
        "virtualization_tech_host": {
            "ec2"
        }
    }
    subject = NetBSDVirtual(fake_sysctl_facts)
    assert expected_virtual_facts == subject.get_virtual_facts()

# Generated at 2022-06-20 20:42:09.261932
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net = NetBSDVirtual()

    net.sysctl_output = b''
    net.dmi_output = b''
    facts = net.get_virtual_facts()

    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts
    assert 'virtualization_tech_guest' in facts
    assert 'virtualization_tech_host' in facts

    assert not facts['virtualization_type']
    assert not facts['virtualization_role']
    assert not facts['virtualization_tech_guest']
    assert not facts['virtualization_tech_host']

    net.sysctl_output = b'machdep.dmi.system-vendor: OpenBSD'
    net.dmi_output = b'machdep.dmi.system-product: NAME'
    facts = net.get_virtual_facts()

# Generated at 2022-06-20 20:42:19.278515
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    NetBSDVirtual_test = NetBSDVirtual()
    NetBSDVirtual_test.sysctl_output = dict()

    # Set empty as default
    NetBSDVirtual_test.sysctl_output['machdep.dmi.system-product'] = ''
    NetBSDVirtual_test.sysctl_output['machdep.dmi.system-vendor'] = ''
    assert NetBSDVirtual_test.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }

    # machdep.dmi.system-product
    NetBSDVirtual_test.sysctl_output['machdep.dmi.system-product'] = 'VMware Virtual Platform'
    NetBSDVirtual

# Generated at 2022-06-20 20:42:26.889203
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    netbsd_virtual = netbsd_virtual_collector.fetch_virtual_facts()
    assert netbsd_virtual['virtualization_type'] != ''
    assert netbsd_virtual['virtualization_role'] != ''
    assert netbsd_virtual['virtualization_type'] != 'xen' or netbsd_virtual['virtualization_role'] == 'guest'

# Generated at 2022-06-20 20:42:31.023474
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] in ('', 'virtualbox', 'kvm', 'xen')
    assert virtual_facts['virtualization_role'] in ('guest', 'host', '')

# Generated at 2022-06-20 20:42:35.782646
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual()
    virtual_facts = virtual.collect()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_system' in virtual_facts
    assert 'virtualization_hypervisor' in virtual_facts
    assert 'virtualization_products' in virtual_facts

# Generated at 2022-06-20 20:42:40.780704
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    '''
    When sysctl is not available or detects no virtualization,
    no values should be set.
    '''
    virtual = NetBSDVirtual(None)

    # Test for virtualization_type
    assert virtual.virtualization_type == ''

    # Test for virtualization_role
    assert virtual.virtualization_role == ''

    # Test for virtualization_system
    assert virtual.virtualization_system == ''


# Generated at 2022-06-20 20:43:39.500826
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.platform == 'NetBSD'


# Generated at 2022-06-20 20:43:42.558195
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual = NetBSDVirtual()
    expected = {
        'virtualization_type': 'xen',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['xen']),
        'virtualization_tech_host': set([]),
    }
    result = virtual.get_virtual_facts()
    assert result == expected


# Generated at 2022-06-20 20:43:44.683460
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()

    assert netbsd_virtual._platform == 'NetBSD'
    assert netbsd_virtual.platform == 'NetBSD'

    assert netbsd_virtual._fact_class == NetBSDVirtual
    assert netbsd_virtual.fact_class == NetBSDVirtual


# Generated at 2022-06-20 20:43:48.101353
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual().get_virtual_facts()
    assert isinstance(virtual_facts, dict)

# Generated at 2022-06-20 20:43:49.452037
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virt = NetBSDVirtual()
    assert virt.platform == 'NetBSD'

# Generated at 2022-06-20 20:43:56.774142
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Arrange
    netbsd_virtual = NetBSDVirtual()
    netbsd_virtual.sysctl = {
        'machdep.hypervisor': '',
        'machdep.dmi.system-product': '',
        'machdep.dmi.system-vendor': '',
    }
    expected_facts = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }

    # Act
    facts = netbsd_virtual.get_virtual_facts()

    # Assert
    assert facts == expected_facts


# Generated at 2022-06-20 20:43:59.175351
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
  nv=NetBSDVirtualCollector()
  assert(nv._platform == 'NetBSD')

# Generated at 2022-06-20 20:44:02.056320
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    nbsd = NetBSDVirtualCollector()
    assert nbsd._platform == 'NetBSD'
    assert nbsd._fact_class == NetBSDVirtual


# Generated at 2022-06-20 20:44:10.811554
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    """Unit test for method get_virtual_facts of class NetBSDVirtual"""
    # pylint: disable=import-error
    from ansible.module_utils.facts.virtual.netbsd import NetBSDVirtual
    # pylint: enable=import-error
    netbsd_virtual = NetBSDVirtual()
    virt_facts = netbsd_virtual.get_virtual_facts()
    # assumes no others have been run before
    assert virt_facts['virtualization_type'] == ''
    assert virt_facts['virtualization_role'] == ''
    assert virt_facts['virtualization_tech_guest'] == set()
    assert virt_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-20 20:44:16.688345
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    sysctl_virtual_facts = {
        'machdep.dmi.system-vendor': 'Xen',
        'machdep.dmi.system-product': 'HVM domU',
        'machdep.hypervisor': 'Xen',
    }
    nbv = NetBSDVirtual(sysctl_virtual_facts)
    assert nbv.sysctl_virtual_facts == sysctl_virtual_facts


# Generated at 2022-06-20 20:46:56.413109
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual()
    assert virtual_facts._platform == 'NetBSD'

# Generated at 2022-06-20 20:47:00.535718
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    '''
    Unit test for method get_virtual_facts of class NetBSDVirtual
    '''
    virtual_facts = NetBSDVirtual().get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-20 20:47:11.599462
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    '''Unit test'''
    # Prepare test object
    netbsd_virtual = NetBSDVirtual()

    #
    # Virtual facts
    #
    virtual_facts = netbsd_virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_technologies'] == {'guest': set(['']), 'host': set([''])}

    #
    # Virtual KVM product
    #
    netbsd_virtual._get_sysctl_info = lambda x: 'HVM domU'
    virtual_facts = netbsd_virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''

# Generated at 2022-06-20 20:47:14.070422
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    facts = dict()
    collector = NetBSDVirtualCollector(facts)
    assert collector._facts == facts
    assert collector._platform == 'NetBSD'
    assert collector._fact_class.platform == 'NetBSD'

# Generated at 2022-06-20 20:47:18.423530
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.platform == 'NetBSD'


# Generated at 2022-06-20 20:47:20.136899
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd = NetBSDVirtual()
    assert netbsd is not None

# Generated at 2022-06-20 20:47:20.901117
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    NetBSDVirtualCollector()

# Generated at 2022-06-20 20:47:25.526269
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    test_facts = dict(
        ansible_system='NetBSD',
        machdep=dict(
            hypervisor=""
        )
    )
    virtual_facts = NetBSDVirtual(module=None, facts=test_facts).get_virtual_facts()
    compare_virtual_facts = dict(
        virtualization_type='xen',
        virtualization_role='host',
        virtualization_tech_host=set(['xen']),
        virtualization_tech_guest=set(['xen'])
    )
    assert virtual_facts == compare_virtual_facts

# Generated at 2022-06-20 20:47:26.256297
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    # Constructor of class NetBSDVirtual can be called without any argument
    NetBSDVirtual()

# Generated at 2022-06-20 20:47:32.723283
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Method definition for unit test
    def makemock(filename, content):
        def side_effect(filename, *args, **kwargs):
            if filename == filename:
                return content
        return side_effect

    # Set up
    module_mock = {}
    facts_module_mock = {}
    read_mock = {}
    facts_module_mock['file_exists'] = lambda filename: filename in read_mock
    facts_module_mock['read_file'] = makemock('/dev/xencons', '')

    # Test
    virtual_facts = NetBSDVirtual(module_mock, facts_module_mock).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts