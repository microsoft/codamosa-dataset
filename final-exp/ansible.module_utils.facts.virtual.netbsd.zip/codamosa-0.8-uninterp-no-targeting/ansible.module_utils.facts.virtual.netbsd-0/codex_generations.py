

# Generated at 2022-06-20 20:37:49.255364
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # instantiate the NetBSDVirtual class
    virtual_facts = NetBSDVirtual({})
    assert virtual_facts.get_virtual_facts() == {'virtualization_type': '',
                                                 'virtualization_role': '',
                                                 'virtualization_tech_guest': set(),
                                                 'virtualization_tech_host': set()}

# Generated at 2022-06-20 20:37:51.474898
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    collector = NetBSDVirtualCollector()
    assert collector.platform == 'NetBSD'
    assert collector.fact_class == NetBSDVirtual


# Generated at 2022-06-20 20:37:53.415142
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    collector = NetBSDVirtualCollector()
    assert collector.platform == 'NetBSD'
    assert collector._fact_class == NetBSDVirtual

# Generated at 2022-06-20 20:37:54.326733
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector is not None

# Generated at 2022-06-20 20:37:58.065389
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Create instance of NetBSDVirtual.
    virtual = NetBSDVirtual()
    # Test get_virtual_facts method.
    assert isinstance(virtual.get_virtual_facts(), dict)

# Generated at 2022-06-20 20:38:09.793789
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():

    from types import ModuleType
    from ansible.module_utils.facts.virtual import NetBSDVirtual
    from ansible.module_utils.facts.virtual import VirtualCollector

    # Create a mock module
    fake_module = ModuleType('ansible.module_utils.facts.virtual.NetBSDVirtual')
    dummy_collector = VirtualCollector()
    fake_module.collector = dummy_collector

    # Create the object
    obj = NetBSDVirtual(fake_module)

    # Test the detect_virt_product method
    # Test 1
    # In case of XEN PV
    fake_module.collector.get_file_lines = lambda x: ['XEN']
    obj.facts['virtualization_type'] = ''
    obj.facts['virtualization_role'] = ''

# Generated at 2022-06-20 20:38:12.495332
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_collector = NetBSDVirtualCollector()
    assert netbsd_collector is not None

# Generated at 2022-06-20 20:38:14.430218
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual()
    assert isinstance(virtual, Virtual)
    assert isinstance(virtual, VirtualSysctlDetectionMixin)
    assert virtual.platform == 'NetBSD'

# Generated at 2022-06-20 20:38:26.549039
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virt_facts = NetBSDVirtual({}).get_virtual_facts()
    # The returned data is a dict.
    assert(isinstance(virt_facts, dict))

    # The BasePlatform virtualization_type and virtualization_role are
    # the same and are normal strings.
    assert('virtualization_type' in virt_facts)
    assert(isinstance(virt_facts['virtualization_type'], str))
    assert('virtualization_role' in virt_facts)
    assert(isinstance(virt_facts['virtualization_role'], str))

    # The BasePlatform virtualization_technology is a list and it is empty
    # by default.
    assert('virtualization_tech_guest' in virt_facts)
    assert(isinstance(virt_facts['virtualization_tech_guest'], set))

# Generated at 2022-06-20 20:38:27.730011
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    assert NetBSDVirtual()

# Generated at 2022-06-20 20:38:34.830521
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual({})
    assert virtual_facts.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }

# Generated at 2022-06-20 20:38:37.612365
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    collector = NetBSDVirtualCollector()
    assert collector.__class__.__name__ == "_NetBSDVirtualCollector"


# Generated at 2022-06-20 20:38:49.394209
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual({})
    sysctl_output = {
        'machdep.dmi.system-product': 'Virtual Box',
        'machdep.dmi.system-vendor': 'Oracle Corporation',
        'machdep.hypervisor': '',
    }
    expected_virtual_facts = {
        'virtualization_type': 'virtualbox',
        'virtualization_role': 'guest',
        'virtualization_type_role': 'guest:virtualbox',
        'virtualization_tech_guest': set(['virtualbox']),
        'virtualization_tech_host': set(['virtualbox']),
    }

    virtual_facts.sysctl = lambda x: sysctl_output[x]
    virtual_facts.is_file = lambda x: x == '/dev/xencons'

# Generated at 2022-06-20 20:38:50.054774
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    NetBSDVirtual()

# Generated at 2022-06-20 20:38:53.627931
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual(None)
    assert netbsd_virtual.platform == 'NetBSD'

# Generated at 2022-06-20 20:38:55.007019
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    provider = NetBSDVirtual()
    assert provider.platform == 'NetBSD'

# Generated at 2022-06-20 20:38:57.181310
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_facts = NetBSDVirtual()
    assert netbsd_facts.platform == 'NetBSD'


# Generated at 2022-06-20 20:39:00.487459
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual({})
    assert isinstance(netbsd_virtual.platform, str)
    assert netbsd_virtual.platform == 'NetBSD'


# Generated at 2022-06-20 20:39:03.114666
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd = NetBSDVirtual()
    assert isinstance(netbsd, NetBSDVirtual)


# Generated at 2022-06-20 20:39:11.255349
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    test_virtual_facts = [{'virtualization_type': '',
                           'virtualization_role': ''},
                          {'virtualization_type': 'xen',
                           'virtualization_role': 'guest',
                           'virtualization_tech_guest': set(['xen']),
                           'virtualization_tech_host': set([])}]
    nb_virtual_collector = NetBSDVirtualCollector()
    nb_virtual_collector.sysctl_facts_dict = {}
    nb_virtual_collector.sysctl_facts_dict['machdep.dmi.system-product'] = ''
    nb_virtual_collector.sysctl_facts_dict['machdep.dmi.system-vendor'] = ''

# Generated at 2022-06-20 20:39:19.062992
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual()
    assert virtual_facts.platform == 'NetBSD'

# Generated at 2022-06-20 20:39:19.646179
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    assert NetBSDVirtual()

# Generated at 2022-06-20 20:39:26.257026
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual().get_virtual_facts()

    # Set expected values (tested on a NetBSD 8.0 system)
    expected_facts = {
        'virtualization_role': 'guest',
        'virtualization_type': 'vmware',
        'virtualization_tech_guest': {'vmware'},
        'virtualization_tech_host': set()
    }

    assert virtual_facts == expected_facts, 'Virtual facts are not as expected'


# Generated at 2022-06-20 20:39:28.765097
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virtual_collector = NetBSDVirtualCollector()
    assert virtual_collector is not None

# Generated at 2022-06-20 20:39:37.436574
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():

    virtual_netbsd = NetBSDVirtual()
    virtual_netbsd.collect()
    assert virtual_netbsd.data.get('virtualization_type') == ''
    assert virtual_netbsd.data.get('virtualization_role') == ''
    assert virtual_netbsd.data.get('virtualization_tech_guest') == set()
    assert virtual_netbsd.data.get('virtualization_tech_host') == set()
    assert virtual_netbsd.data.get('virtualization_system') == ''
    assert virtual_netbsd.data.get('virtualization_product_name') == ''
    assert virtual_netbsd.data.get('virtualization_product_version') == ''

# Generated at 2022-06-20 20:39:39.362772
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert isinstance(NetBSDVirtualCollector(), VirtualCollector)

# Generated at 2022-06-20 20:39:43.753078
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virt = NetBSDVirtual(None)

    # Ensure that required attributes were properly set
    assert virt._platform == 'NetBSD'
    assert virt.sysctl_default_search_paths == ['/sbin/sysctl', '/usr/sbin/sysctl']

# Generated at 2022-06-20 20:39:46.334469
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd = NetBSDVirtualCollector()
    assert netbsd._platform == 'NetBSD'
    assert netbsd._fact_class == NetBSDVirtual


# Generated at 2022-06-20 20:39:48.353218
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():

    v_facts = NetBSDVirtual().get_virtual_facts()

    assert 'virtualization_type' in v_facts
    assert 'virtualization_role' in v_facts



# Generated at 2022-06-20 20:40:00.132716
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    test_facts = {
        'machdep.hypervisor': '',
        'machdep.dmi.system-product': '',
        'machdep.dmi.system-vendor': '',
    }

    def sysctl(module):
        if module in test_facts:
            return test_facts[module]
        else:
            return None

    def exists(module):
        if module in test_facts:
            return True
        else:
            return False

    virtual = NetBSDVirtual(sysctl, exists)
    assert virtual.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }


# Generated at 2022-06-20 20:40:12.457693
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    assert NetBSDVirtual

# Generated at 2022-06-20 20:40:24.001944
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.netbsd import NetBSDVirtual

    # Definition of the kern.dmi.system-vendor and kern.dmi.system-product sysctl mib
    sysctl_virtual_mibs = {
        'machdep.hypervisor': '',
        'machdep.dmi.system-vendor': '',
        'machdep.dmi.system-product': '',
    }

    # NetBSD running as a guest on Xen
    netbsd_virtual = NetBSDVirtual({'sysctl': sysctl_virtual_mibs})
    virtual_facts = netbsd_virtual.get_virtual_facts()
    assert 'virtualization_type' in virtual_facts.keys(), 'The "virtualization_type" key should be present'

# Generated at 2022-06-20 20:40:35.194230
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    """Test method get_virtual_facts of class NetBSDVirtual"""

    # Arrange
    # Create a mock class with the same name of the target one
    class_name = 'NetBSDVirtual'

# Generated at 2022-06-20 20:40:36.174433
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virt = NetBSDVirtual()
    assert virt is not None

# Generated at 2022-06-20 20:40:38.141564
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virtual = NetBSDVirtualCollector()
    assert virtual._fact_class == NetBSDVirtual
    assert virtual._platform == 'NetBSD'

# Generated at 2022-06-20 20:40:42.089520
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    collector = NetBSDVirtualCollector()
    assert collector.platform == 'NetBSD'
    assert collector._fact_class == NetBSDVirtual
    assert collector._fact_class.platform == 'NetBSD'

# Generated at 2022-06-20 20:40:46.159878
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    result = {'ansible_facts': {'virtualization_type': 'qemu', 'virtualization_role': 'guest', 'virtualization_tech_guest': {'kvm'}, 'virtualization_tech_host': {'kvm'} }}
    assert NetBSDVirtual({}).get_virtual_facts() == result

# Generated at 2022-06-20 20:40:50.859202
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual(None, None)
    assert virtual
    assert virtual.platform == 'NetBSD'
    assert virtual.get_virtual_facts()
    assert virtual.get_virtual_facts()['virtualization_type'] == ''
    assert virtual.get_virtual_facts()['virtualization_role'] == ''
    assert virtual.get_virtual_facts()['virtualization_tech_guest'] == set()
    assert virtual.get_virtual_facts()['virtualization_tech_host'] == set()

# Generated at 2022-06-20 20:40:54.558209
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    nvc = NetBSDVirtualCollector()
    assert nvc.platform == 'NetBSD'
    assert nvc._platform == 'NetBSD'
    assert nvc._fact_class.platform == 'NetBSD'

# Generated at 2022-06-20 20:40:57.453737
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    my_NetBSDVirtualCollector = NetBSDVirtualCollector()
    '''
    Test for the constructor of class NetBSDVirtualCollector
    '''
    assert isinstance(my_NetBSDVirtualCollector, NetBSDVirtualCollector)


# Generated at 2022-06-20 20:41:23.724759
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    NetBSDVirtualCollector()


# Generated at 2022-06-20 20:41:27.105963
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    '''
    Test NetBSDVirtualCollector constructor
    '''
    obj = NetBSDVirtualCollector()
    assert isinstance(obj, VirtualCollector)
    assert isinstance(obj._fact_class, NetBSDVirtual)
    assert isinstance(obj._platform, str)

# Generated at 2022-06-20 20:41:31.165732
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert netbsd_virtual_collector._platform == 'NetBSD'
    assert netbsd_virtual_collector._fact_class == NetBSDVirtual

# Generated at 2022-06-20 20:41:34.251712
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    x = NetBSDVirtual()
    assert x.platform == 'NetBSD'

# Generated at 2022-06-20 20:41:35.661867
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virt = NetBSDVirtual()
    assert virt.platform == 'NetBSD'

# Generated at 2022-06-20 20:41:36.539613
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector is not None

# Generated at 2022-06-20 20:41:38.320976
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''

# Generated at 2022-06-20 20:41:40.548513
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector._platform == 'NetBSD'

# Generated at 2022-06-20 20:41:46.717892
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual = NetBSDVirtual(module=None)
    facts = virtual.get_virtual_facts()
    virtualization_type = facts.get('virtualization_type')
    virtualization_role = facts.get('virtualization_role')
    assert virtualization_type == 'xen'
    assert virtualization_role == 'guest'


# Generated at 2022-06-20 20:41:49.956461
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert isinstance(netbsd_virtual_collector, NetBSDVirtualCollector)


# Generated at 2022-06-20 20:42:46.065875
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virtual = NetBSDVirtualCollector()
    assert virtual._fact_class == NetBSDVirtual
    assert virtual._platform == 'NetBSD'

# Generated at 2022-06-20 20:42:54.551816
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual_obj = NetBSDVirtual()
    results = netbsd_virtual_obj.get_virtual_facts()
    #assertion check
    assert results['virtualization_role'] == 'guest'
    assert results['virtualization_type'] == 'xen'
    assert results['virtualization_tech_guest'] == set(['xen'])
    assert results['virtualization_tech_host'] == set([])

# Generated at 2022-06-20 20:42:56.097568
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert netbsd_virtual_collector.platform == "NetBSD"
    assert netbsd_virtual_collector.fact_class == NetBSDVirtual

# Generated at 2022-06-20 20:43:02.386045
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():

    netbsd_virtual_facts = {
        "virtualization_role": "guest",
        "virtualization_type": "xen",
        "virtualization_tech_guest": ["xen"],
        "virtualization_tech_host": ["xen"],
    }

    # Create a mock version of the sysctl command, so we can test this
    # method without actually calling sysctl
    def my_sysctl_method(command):
        return """
machdep.dmi.system-product: Grub2
machdep.dmi.system-vendor: Xen
machdep.hypervisor: Xen
"""

    # Override the method with ours.
    module = type('Module', (object,), {'run_command': my_sysctl_method})
    # Create a NetBSDVirtual object
    netbsd_

# Generated at 2022-06-20 20:43:06.573558
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()

    if not isinstance(netbsd_virtual_collector, NetBSDVirtualCollector):
        raise AssertionError('Instantiation of NetBSDVirtualCollector did not yield an object of correct type')


# Generated at 2022-06-20 20:43:16.466300
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    def create_os_mock(sysctl_result_dict):
        class OSMock(object):
            def __init__(self, sysctl_result_dict):
                self.sysctl_result_dict = sysctl_result_dict

            def sysctl(self, sysctl_arg):
                return self.sysctl_result_dict[sysctl_arg]

        return OSMock(sysctl_result_dict)

    test_virtual_facts_simple = {
        'virtualization_type':  '',
        'virtualization_role':  '',
        'virtualization_tech_host':  set([]),
        'virtualization_tech_guest':  set([]),
        }

    # empty result
    os_mock = create_os_mock({})

# Generated at 2022-06-20 20:43:17.995830
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    collector = NetBSDVirtualCollector()
    assert collector._platform == 'NetBSD'
    assert collector._fact_class == NetBSDVirtual

# Generated at 2022-06-20 20:43:20.530180
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsdVirtualCollector = NetBSDVirtualCollector()
    assert netbsdVirtualCollector.platform == 'NetBSD'
    assert netbsdVirtualCollector._fact_class == NetBSDVirtual


# Generated at 2022-06-20 20:43:30.733662
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    fake_sysctl_raw_output = [
        "machdep.dmi.system-uuid: FDFA9B9C-D1F4-11E4-A3EB-10FEEDAB4B4B",
        "machdep.dmi.system-product: KVM",
        "machdep.dmi.system-serial: 01",
        "machdep.dmi.system-version: Linux KVM Server",
        "machdep.dmi.system-vendor: ABACUS",
        "machdep.hypervisor: bhyve",
        ]


# Generated at 2022-06-20 20:43:34.193018
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virtual_collector = NetBSDVirtualCollector()
    assert virtual_collector._platform == 'NetBSD'
    assert isinstance(virtual_collector._fact_class, NetBSDVirtual)

# Generated at 2022-06-20 20:46:02.101804
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    assert NetBSDVirtual(dict())

# Generated at 2022-06-20 20:46:11.749173
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual = NetBSDVirtual()
    detect_virt_product = netbsd_virtual.detect_virt_product
    detect_virt_vendor = netbsd_virtual.detect_virt_vendor

    # Set up the stubs
    class Stub_NetBSDVirtual(object):
        machdep_dmi_system_vendor = ''
        machdep_dmi_system_product = ''
        machdep_hypervisor = ''
        sysctl_dev_xencons = False

        def detect_virt_product(self, fact):
            return detect_virt_product(fact)

        def detect_virt_vendor(self, fact):
            return detect_virt_vendor(fact)

    netbsd_virtual = Stub_NetBSDVirtual()

# Generated at 2022-06-20 20:46:14.810955
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.platform == 'NetBSD'

# Generated at 2022-06-20 20:46:16.815144
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual({})
    assert netbsd_virtual.platform == 'NetBSD'

# Generated at 2022-06-20 20:46:24.651946
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual_facts = NetBSDVirtual()
    test_facts = {
        'virtualization_type': '',
        'virtualization_role': ''
    }
    test_facts.update(netbsd_virtual_facts.get_virtual_facts())

    assert test_facts['virtualization_type'] == ''
    assert test_facts['virtualization_role'] == ''

# Generated at 2022-06-20 20:46:25.953318
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
   assert NetBSDVirtualCollector.__name__ == "NetBSDVirtualCollector"

# Generated at 2022-06-20 20:46:27.362605
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd = NetBSDVirtual()
    print(netbsd.get_virtual_facts())


# Generated at 2022-06-20 20:46:28.935588
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    temp = NetBSDVirtualCollector()
    assert (temp._platform == 'NetBSD')
    assert (temp._fact_class == NetBSDVirtual)
    del temp


# Generated at 2022-06-20 20:46:35.624223
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    import unittest
    class TestNetBSDVirtualConstructor(unittest.TestCase):
        def test_constructor(self):
            import mock
            self.assertIsInstance(
                NetBSDVirtualCollector(),
                NetBSDVirtualCollector,
            )
    test_suite = unittest.TestLoader().loadTestsFromTestCase(TestNetBSDVirtualConstructor)
    unittest.TextTestRunner().run(test_suite)

# Generated at 2022-06-20 20:46:37.087373
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector.get_platform() == 'NetBSD'
    assert NetBSDVirtualCollector().fact_class == NetBSDVirtual