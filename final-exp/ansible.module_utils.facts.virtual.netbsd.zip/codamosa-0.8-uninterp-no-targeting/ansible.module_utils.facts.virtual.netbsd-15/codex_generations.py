

# Generated at 2022-06-20 20:37:55.157777
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Define a sample sysctl emulator for NetBSDVirtual.detect_virt_product
    def sample_sysctl(key):
        """
        Return sysctl value for the given key.
        """
        d = {
            "machdep.dmi.system-product": "iSeries Virtual Machine",
        }
        return d[key]

    # Create an instance of NetBSDVirtual
    netbsd_virtual = NetBSDVirtual(sysctl=sample_sysctl)

    # Call the method get_virtual_facts
    # of class NetBSDVirtua
    facts = netbsd_virtual.get_virtual_facts()

    # Check the result
    assert facts['virtualization_type'] == 'ibm_powervm'
    assert facts['virtualization_role'] == 'guest'

# Generated at 2022-06-20 20:38:01.768961
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual('/usr/sbin/sysctl').get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-20 20:38:09.749184
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():

    # Set attributes
    fact_class = NetBSDVirtual

    # Create a NetBSDVirtual object
    netbsd_fact_class = fact_class()

    # Unit test for method get_virtual_facts
    virtual_facts = netbsd_fact_class.get_virtual_facts()
    for key in virtual_facts.keys():
        assert key in ['virtualization_type',
                       'virtualization_role',
                       'virtualization_system',
                       'virtualization_tech_guest',
                       'virtualization_tech_host']

# Generated at 2022-06-20 20:38:11.705440
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    NetBSDVirtualCollector()

# Generated at 2022-06-20 20:38:18.590340
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # happy path
    from ansible.module_utils.facts.virtual.netbsd import NetBSDVirtual
    nv = NetBSDVirtual()
    nv.sysctl_mock_values = {
        'machdep.dmi.system-vendor': 'SuperMicro',
        'machdep.dmi.system-product': 'SYS-5019S-M',
        'machdep.hypervisor': 'vbox',
    }
    nv.os_path_exists_mock_file_list = ['/dev/xencons']

    virtual_facts = nv.get_virtual_facts()

# Generated at 2022-06-20 20:38:23.544039
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    # Test default values
    nv = NetBSDVirtual()
    assert nv.platform == 'NetBSD'
    assert nv.virtualization_tech_guest == set()
    assert nv.virtualization_tech_host == set()
    assert nv.virtualization_type == ''
    assert nv.virtualization_role == ''



# Generated at 2022-06-20 20:38:28.041341
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    facts = NetBSDVirtual({})
    assert facts.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': set(),
        'virtualization_product': '',
        'virtualization_vendor': ''
    }

# Generated at 2022-06-20 20:38:34.026584
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    facts = NetBSDVirtualCollector.collect()
    assert facts.pop('_fact_class') == 'NetBSDVirtual'
    assert facts.pop('_platform') == 'NetBSD'
    # Test value of the fact 'virtualization_type'
    if facts.get('virtualization_type') != 'xen':
        assert facts.pop('virtualization_type') == 'physical'
    # No other facts returned.
    assert len(facts) == 0

# Generated at 2022-06-20 20:38:37.106877
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert netbsd_virtual_collector._platform == 'NetBSD'


# Generated at 2022-06-20 20:38:39.341357
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual_obj = NetBSDVirtual()
    assert netbsd_virtual_obj.platform == 'NetBSD'

# Generated at 2022-06-20 20:38:51.747027
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtual
    from ansible.module_utils.facts.virtual.linux import LinuxVirtual
    from ansible.module_utils.facts.virtual.netbsd import NetBSDVirtual
    from ansible.module_utils.facts.virtual.openbsd import OpenBSDVirtual

    vc = NetBSDVirtualCollector()
    assert vc.get_fact_class(vendor="OpenBSD") == OpenBSDVirtual
    assert vc.get_fact_class(vendor="FreeBSD") == FreeBSDVirtual
    assert vc.get_fact_class(vendor="Linux") == LinuxVirtual
    assert vc.get_fact_class(vendor="NetBSD") == NetBSDVirtual

# Generated at 2022-06-20 20:38:54.233768
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    collector = NetBSDVirtualCollector()
    assert collector.name == 'NetBSDVirtualCollector'

# Generated at 2022-06-20 20:38:57.181623
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual()
    assert virtual_facts.platform == 'NetBSD'

# Test get_virtual_facts function. This function is responsible for
# extracting virtualization details related to NetBSD system.

# Generated at 2022-06-20 20:39:01.189498
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual_obj = NetBSDVirtual()
    virtual_facts = netbsd_virtual_obj.get_virtual_facts()
    assert virtual_facts["virtualization_type"] is not None
    assert virtual_facts["virtualization_role"] is not None

# Generated at 2022-06-20 20:39:11.668507
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    facts_dictionary = {
        'machdep.dmi.system-product': 'VMware Virtual Platform',
        'machdep.dmi.system-vendor': 'VMware, Inc.',
        'machdep.hypervisor': 'VMware Virtual Platform',
    }

    netbsd_virtual_collector = NetBSDVirtualCollector(module=None, facts=facts_dictionary)
    assert netbsd_virtual_collector.get_virtual_facts() == {
        'virtualization_type': 'VMware',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['vmware']),
        'virtualization_tech_host': set(['vmware']),
    }


# Generated at 2022-06-20 20:39:18.124620
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():

    with open('/proc/cpuinfo', 'r') as f:
        cpuinfo_file = f.read()

    # Populate module with sysctl-related data
    setattr(module, 'sysctl_get_lines', lambda _: cpuinfo_file.splitlines())

    # Check that if no virtualization facts can be found, empty values are used
    virtual_facts = NetBSDVirtual(module=module).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_product_name'] == ''
    assert virtual_facts['virtualization_product_version'] == ''
    assert virtual_facts['virtualization_product_serial'] == ''
    assert virtual_facts['virtualization_host_vendor'] == ''

# Generated at 2022-06-20 20:39:27.878142
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():

    netbsd_virtual = NetBSDVirtual()

    # Let's set some facts manually
    netbsd_virtual.facts = {
        'machdep.dmi.system-product': 'Not Applicable',
        'machdep.dmi.system-version': '',
        'machdep.hypervisor': 'VMWare Virtual Platform',
        'machdep.dmi.system-vendor': 'VMware, Inc.',
    }

    # Since we have set facts manually, we no longer have access to
    # sysctl. Instead, let's test seeing if we can access it
    assert hasattr(netbsd_virtual, '_sysctl')

    virtual_facts = netbsd_virtual.get_virtual_facts()

    # Did we get any virtualization technologies?
    assert 'virtualization_tech_guest'

# Generated at 2022-06-20 20:39:30.071186
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virtual = NetBSDVirtualCollector().collect()['ansible_facts']['ansible_virtualization_type']
    assert type(virtual) == str

# Generated at 2022-06-20 20:39:33.024403
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd = NetBSDVirtualCollector()
    assert netbsd.platform == "NetBSD"
    assert netbsd._fact_class == NetBSDVirtual

# Generated at 2022-06-20 20:39:35.081636
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual()
    assert virtual_facts.platform == 'NetBSD'
    assert virtual_facts.get_virtual_facts() == {}

# Generated at 2022-06-20 20:39:48.704072
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Test NetBSDVirtual().get_virtual_facts() with empty facts
    test_facts = dict()
    test_netbsdvirtual = NetBSDVirtual(test_facts, None)
    test_virtual_facts = test_netbsdvirtual.get_virtual_facts()
    assert test_virtual_facts == dict()

    # Test NetBSDVirtual().get_virtual_facts() with empty machdep.dmi
    test_facts = dict(machdep=dict(dmi={}))
    test_netbsdvirtual = NetBSDVirtual(test_facts, None)
    test_virtual_facts = test_netbsdvirtual.get_virtual_facts()
    assert test_virtual_facts == dict()

    # Test NetBSDVirtual().get_virtual_facts() with virtualization_type = xen
    # and virtualization_role = guest
   

# Generated at 2022-06-20 20:39:50.502803
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    v = NetBSDVirtual()
    assert v.platform == 'NetBSD'


# Generated at 2022-06-20 20:39:51.739711
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    NetBSDVirtualCollector()

# Generated at 2022-06-20 20:39:58.271301
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual()

    fake_virtual_facts = {
        'virtualization_type': '',
        'virtualization_role': '',
        'pci_devs': [{'driver': 'virtio-pci', 'number': '0x1000'}]
    }

    virtual_facts.get_virtual_facts(fake_virtual_facts)
    assert fake_virtual_facts['virtualization_type'] == 'kvm'

# Generated at 2022-06-20 20:40:01.344809
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector._platform == 'NetBSD'
    assert NetBSDVirtualCollector._fact_class == NetBSDVirtual


# Generated at 2022-06-20 20:40:03.938900
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual()
    assert virtual.platform == 'NetBSD'
    assert virtual.get_virtual_facts() == {}


# Generated at 2022-06-20 20:40:05.226206
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual()
    assert virtual.platform == 'NetBSD'

# Generated at 2022-06-20 20:40:06.774849
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual()
    assert virtual.platform == 'NetBSD'


# Generated at 2022-06-20 20:40:14.582668
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    expected_facts = {'virtualization_type': 'xen', 'virtualization_role': 'guest', 'virtualization_tech_guest': {'xen'}}
    mock_module = type('module', (object,), {'params': {'gather_subset': []}, 'get_bin_path': lambda *_: None})()
    mock_module.run_command = lambda *_, **__: None
    virtual_facts = NetBSDVirtual(mock_module, 'test').get_virtual_facts()
    for key, value in expected_facts.items():
        assert virtual_facts[key] == value

# Generated at 2022-06-20 20:40:25.483532
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual = NetBSDVirtual({})
    virtual_facts = virtual.get_virtual_facts()
    assert type(virtual_facts) is dict
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech'] == set()
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()

    virtual = NetBSDVirtual(dict(machdep={
        'dmi': {
            'system-product': 'VirtualBox',
            'system-vendor': 'InnoTek Systemberatung GmbH',
        }
    },
        machdep={
            'hypervisor': 'somehype'
        }))
    virtual_facts = virtual.get

# Generated at 2022-06-20 20:40:30.485576
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd = NetBSDVirtual({},{})
    assert netbsd.platform == 'NetBSD'

# Generated at 2022-06-20 20:40:35.584225
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-20 20:40:37.632881
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.platform == 'NetBSD'


# Generated at 2022-06-20 20:40:41.124216
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():

    os_facts = dict(distribution='NetBSD')

    test_obj = NetBSDVirtual(os_facts)

    assert 'NetBSD' == test_obj.platform

# Generated at 2022-06-20 20:40:43.486197
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    """
    Create an object of NetBSDVirtualCollector
    """

    netbsd_virtual_collector_obj = NetBSDVirtualCollector()


# Generated at 2022-06-20 20:40:51.116351
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Define a dict to be returned by sysctl(3)
    sysctl = {
        'machdep.dmi.system-vendor': 'FUJITSU',
        'machdep.dmi.system-product': 'S26361-D2900-A26-13',
        'machdep.hypervisor': 'QEMU',
    }
    # Create instance of NetBSDVirtual
    netbsd_virtual = NetBSDVirtual(sysctl)

    # Test with return_values of sysctl method
    assert netbsd_virtual.get_virtual_facts() == {'virtualization_type': 'xen', 'virtualization_role': 'guest',
                                                  'virtualization_tech_guest': {'xen'},
                                                  'virtualization_tech_host': set()}
    assert net

# Generated at 2022-06-20 20:41:00.346234
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    "Unit test"
    # Initialize a NetBSDVirtual object
    test_virtual_facts = NetBSDVirtual()

    # Create a "fake" sysctl utility
    def fake_sysctl(sysctl_args):
        "Fake function to support fake_sysctl_utility"
        if sysctl_args == ['machdep.hypervisor']:
            return "machdep.hypervisor = Xen 3.3\n"
        elif sysctl_args == ['machdep.dmi.system-product']:
            return "machdep.dmi.system-product = VMware Virtual Platform\n"
        elif sysctl_args == ['machdep.dmi.system-vendor']:
            return "machdep.dmi.system-vendor = Intel Corporation\n"
        return ''
    # Create a "fake

# Generated at 2022-06-20 20:41:02.918531
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virtual_collector = NetBSDVirtualCollector()
    assert isinstance(virtual_collector, NetBSDVirtualCollector)


# Generated at 2022-06-20 20:41:05.426902
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virtual_collector = NetBSDVirtualCollector()
    assert virtual_collector._platform == 'NetBSD'
    assert virtual_collector._fact_class == NetBSDVirtual


# Generated at 2022-06-20 20:41:07.825747
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsdvirtual = NetBSDVirtual()
    assert netbsdvirtual.platform == 'NetBSD'


# Generated at 2022-06-20 20:41:18.608950
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert netbsd_virtual_collector._fact_class is not None
    assert netbsd_virtual_collector._platform == 'NetBSD'


# Generated at 2022-06-20 20:41:28.068276
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # We need to mock the sysctl calls and return arbitrary values
    from six.moves import builtins
    from ansible.module_utils.facts import virtual

    with open('unittests/fake_sysctl_output/fake_sysctl_output_NetBSD.txt') as sysctl_output:
        with open('unittests/fake_sysctl_output/fake_sysctl_output_NetBSD_machdep-hypervisor.txt') as sysctl_hypervisor_output:
            builtins.open = lambda path, *args, **kwargs: {'/sbin/sysctl': sysctl_output, '/sbin/sysctl -n machdep.hypervisor': sysctl_hypervisor_output}[path]

# Generated at 2022-06-20 20:41:34.102611
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    n_b_v_c = NetBSDVirtualCollector()
    assert n_b_v_c._fact_class == NetBSDVirtual
    assert n_b_v_c._platform == 'NetBSD'
    assert n_b_v_c._collectors == []

# Generated at 2022-06-20 20:41:37.431325
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert netbsd_virtual_collector._platform == 'NetBSD'
    assert netbsd_virtual_collector._fact_class == NetBSDVirtual


# Generated at 2022-06-20 20:41:41.392230
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual(None)
    assert virtual_facts.platform == 'NetBSD'



# Generated at 2022-06-20 20:41:43.961365
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    nbsd = NetBSDVirtual()

    assert nbsd.platform == 'NetBSD'


# Generated at 2022-06-20 20:41:50.856445
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    # Test creating VirtualCollector object
    netbsd_virtual_collector_obj = NetBSDVirtualCollector()
    assert netbsd_virtual_collector_obj
    # Test that _fact_class attribute is set to Virtual class
    assert netbsd_virtual_collector_obj._fact_class == NetBSDVirtual
    # Test that _platform attribute is set to NetBSD
    assert netbsd_virtual_collector_obj._platform == 'NetBSD'

# Generated at 2022-06-20 20:41:52.722483
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netBSDVirtualCollectorObj = NetBSDVirtualCollector()
    assert netBSDVirtualCollectorObj.platform == "NetBSD"

# Generated at 2022-06-20 20:41:54.288882
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual is not None

# Generated at 2022-06-20 20:41:56.717917
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert 'NetBSDVirtual' in netbsd_virtual_collector.data.keys()

# Generated at 2022-06-20 20:42:12.314366
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    # No sysctl on NetBSD is available, so testing this should cause an exception
    NetBSDVirtual().get_virtual_facts()

# Generated at 2022-06-20 20:42:21.145514
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():

    class FakeModule(object):

        def __init__(self, sysctl_output):
            self.sysctl_output = sysctl_output

        def run_command(self, args, check_rc=False):
            if args[0] == '/sbin/sysctl':
                return 0, self.sysctl_output, ''
            else:
                return 1, '', ''

        def fail_json(self, **kwargs):
            for k in kwargs:
                print(k, kwargs[k])
            exit(1)

    # Test virtual machine

# Generated at 2022-06-20 20:42:25.508199
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    f = NetBSDVirtual()
    assert isinstance(f, NetBSDVirtual)
    assert isinstance(f, Virtual)
    assert f._platform == 'NetBSD'
    assert f._fact_class == NetBSDVirtual


# Generated at 2022-06-20 20:42:29.633900
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert isinstance(netbsd_virtual, NetBSDVirtual)
    assert netbsd_virtual.platform == 'NetBSD'

# Test that determining the vendor from machdep.dmi.system-vendor works

# Generated at 2022-06-20 20:42:32.822379
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual({}).get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-20 20:42:35.782798
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsdVirtualCollectorInstance = NetBSDVirtualCollector()
    assert isinstance(netbsdVirtualCollectorInstance, NetBSDVirtualCollector)

# Generated at 2022-06-20 20:42:37.204907
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    v = NetBSDVirtual(None)

    assert v.platform == 'NetBSD'


# Generated at 2022-06-20 20:42:45.324429
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    vd = NetBSDVirtual()
    vd.set_sysctl_info('machdep.dmi.system-product', '')
    vd.set_sysctl_info('machdep.dmi.system-vendor', '')
    vd.set_sysctl_info('machdep.hypervisor', '')

    vd.get_virtual_facts()

    vd.set_sysctl_info('machdep.hypervisor', 'A "Foo"')
    vd.get_virtual_facts()
    assert vd.facts['virtualization_type'] == 'foo'

    vd.set_sysctl_info('machdep.hypervisor', 'A "Foo"')
    vd.get_virtual_facts()
    assert vd.facts['virtualization_type'] == 'foo'

# Generated at 2022-06-20 20:42:46.856819
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    obj = NetBSDVirtual({'ansible_facts':{}}, {})
    assert obj


# Generated at 2022-06-20 20:42:54.552141
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    my_obj = NetBSDVirtualCollector()
    assert my_obj._platform == 'NetBSD'
    assert my_obj._fact_class == NetBSDVirtual
    assert my_obj.platforms == ('NetBSD',)
    assert my_obj.legacy_collect == False
    assert my_obj.collectable_facts == ()

# Generated at 2022-06-20 20:43:28.144214
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd = NetBSDVirtual()
    virtual_facts = netbsd.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''

# Generated at 2022-06-20 20:43:31.642184
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector._platform == 'NetBSD'
    assert NetBSDVirtualCollector._fact_class == NetBSDVirtual

# Generated at 2022-06-20 20:43:36.012830
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    print("Testing constructor of NetBSDVirtualCollector")
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert netbsd_virtual_collector._platform == 'NetBSD'
    assert netbsd_virtual_collector._fact_class == NetBSDVirtual

# Generated at 2022-06-20 20:43:37.512987
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():

    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.platform == 'NetBSD'

# Generated at 2022-06-20 20:43:38.500139
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    NetBSDVirtualCollector()

# Generated at 2022-06-20 20:43:45.714717
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    facts = {'kernel': 'NetBSD'}
    virt = NetBSDVirtual(facts, None)

    # exclude vnode
    virtual_facts = {'virtualization_type': 'vnode', 'virtualization_role': '', 'virtualization_system': 'vnode'}
    # vnode is not supported
    assert virt.get_virtual_facts() == virtual_facts

# Generated at 2022-06-20 20:43:48.514780
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()


# Generated at 2022-06-20 20:43:50.962999
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    test_object = NetBSDVirtualCollector()
    assert test_object.platform == 'NetBSD'
    assert test_object._fact_class == NetBSDVirtual
    assert test_object._platform == 'NetBSD'

# Generated at 2022-06-20 20:43:58.100598
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # pylint: disable=protected-access
    netbsd_virtual = NetBSDVirtual()

    # Default return values
    assert netbsd_virtual._get_sysctl_mib_value('') is None

    netbsd_virtual.sysctl_output[''] = 'nonsense'
    assert netbsd_virtual._get_sysctl_mib_value('') is None

    netbsd_virtual.sysctl_output[''] = 'nonsense\n'
    assert netbsd_virtual._get_sysctl_mib_value('') is None

    netbsd_virtual.sysctl_output[''] = 'foo: bar\n'
    assert netbsd_virtual._get_sysctl_mib_value('') is None


# Generated at 2022-06-20 20:44:09.217200
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    data = { 'machdep.dmi.system-vendor': 'MSI',
             'machdep.dmi.sys_vendor': 'MSI',
             'machdep.dmi.system-product': 'X99A Gaming 7',
             'machdep.dmi.sys_vendor': 'X99A Gaming 7',
             'machdep.hypervisor': 'QEMU',
             'hw.machine': 'amd64'}

    facts = NetBSDVirtual(data, None)

# Generated at 2022-06-20 20:45:40.397786
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    v_object = NetBSDVirtual()
    open('/proc/xen/capabilities', 'w').close()
    open('/proc/xen/privcmd', 'w').close()
    os.mkdir('/sys/bus/xen')
    open('/sys/bus/xen/devices/vbd/51712/512/add', 'w').close()
    open('/sys/bus/xen/devices/vbd/51712/512/51712', 'w').close()
    open('/sys/bus/xen/devices/vbd/51712/512/dev', 'w').close()
    open('/sys/bus/xen/devices/vbd/51712/512/hotplug_status', 'w').close()

# Generated at 2022-06-20 20:45:45.066732
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtualCollector.fetch_virtual_facts()
    assert virtual['virtualization_type'] == ''
    assert virtual['virtualization_role'] == ''
    assert virtual['virtualization_technologies'] == set()
    assert virtual['virtualization_tech_guest'] == set()
    assert virtual['virtualization_tech_host'] == set()
    assert virtual['virtualization_hypervisor'] == 'unknown'

# Generated at 2022-06-20 20:45:48.926686
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    test_test = NetBSDVirtual({'ansible_facts': {'kernel': 'NetBSD'}})
    assert test_test.platform == 'NetBSD'


# Generated at 2022-06-20 20:45:53.456952
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert netbsd_virtual_collector
    assert isinstance(netbsd_virtual_collector, VirtualCollector)

# Generated at 2022-06-20 20:45:57.241132
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd = NetBSDVirtual()
    assert 'sysctl' in netbsd._virtual_detect_methods
    assert netbsd.platform == 'NetBSD'

# Generated at 2022-06-20 20:45:58.912629
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()

    assert 'NetBSD' == netbsd_virtual.platform


# Generated at 2022-06-20 20:46:02.908725
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virt_facts = NetBSDVirtual()
    assert virt_facts.__class__.__name__ == 'NetBSDVirtual'


# Generated at 2022-06-20 20:46:04.959819
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector_obj = NetBSDVirtualCollector()
    assert netbsd_virtual_collector_obj._platform == 'NetBSD'

# Generated at 2022-06-20 20:46:06.788403
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual({})
    assert netbsd_virtual.collect()

# Generated at 2022-06-20 20:46:09.646420
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virt_obj = NetBSDVirtualCollector()
    assert virt_obj._platform == 'NetBSD'
    assert virt_obj._fact_class == NetBSDVirtual
