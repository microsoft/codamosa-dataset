

# Generated at 2022-06-20 20:37:54.581972
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    class Virtsysctl:
        def __init__(self, sysctl_values):
            self.sysctl_values = sysctl_values

        def get(self, name):
            return self.sysctl_values[name]

    class Virtfile:
        def __init__(self, virtfile_values):
            self.virtfile_values = virtfile_values

        @staticmethod
        def exists(path):
            return path in virtfile_values

    # Expected results for all tests
    expected_general = {
        'virtualization_type': '',
        'virtualization_role': '',
    }


# Generated at 2022-06-20 20:38:07.091829
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # First, define some methods that will be used as mock return values.

    def fake_is_sysctl_available(self):
        return True

    def fake_sysctl_get(self, key):
        if key == 'machdep.dmi.system-vendor':
            return 'VMware, Inc.'
        elif key == 'machdep.dmi.system-product':
            return 'VMware Virtual Platform'
        elif key == 'machdep.hypervisor':
            return 'VMware, Inc.'
        elif key == 'machdep.dmi.bios-vendor':
            return 'Apple Inc.'
        elif key == 'machdep.dmi.bios-version':
            return 'VMware Virtual Platform'

# Generated at 2022-06-20 20:38:10.624250
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert netbsd_virtual_collector._fact_class is NetBSDVirtual
    assert netbsd_virtual_collector._platform is 'NetBSD'

# Generated at 2022-06-20 20:38:17.711984
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual_fact_collector = NetBSDVirtualCollector()
    sysctl_file = netbsd_virtual_fact_collector.get_file_content('/proc/sysctl')
    netbsd_virtual = NetBSDVirtual(sysctl_file)
    virtual_facts = netbsd_virtual.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()
    assert virtual_facts['virtualization_sysctl'] == {}

# Generated at 2022-06-20 20:38:20.808169
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    nv = NetBSDVirtual()
    assert nv.platform == 'NetBSD'
    assert nv.get_virtual_facts()['virtualization_role'] == ''


# Generated at 2022-06-20 20:38:21.876656
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    NetBSDVirtualCollector()

# Generated at 2022-06-20 20:38:24.568778
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virtual_collector = NetBSDVirtualCollector()
    assert virtual_collector._platform == 'NetBSD'
    assert virtual_collector._fact_class.platform == 'NetBSD'

# Generated at 2022-06-20 20:38:26.373002
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    # Just test if the class is able to create a new instance.
    NetBSDVirtualCollector()

# Generated at 2022-06-20 20:38:28.769884
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    collector = NetBSDVirtualCollector()
    assert collector.__class__ == NetBSDVirtualCollector


# Generated at 2022-06-20 20:38:32.050459
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual({})
    assert netbsd_virtual is not None
    assert netbsd_virtual._name is 'NetBSD'


# Generated at 2022-06-20 20:38:39.484746
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd = NetBSDVirtual({})
    assert netbsd is not None
    assert isinstance(netbsd, NetBSDVirtual)
    assert netbsd.get_virtual_facts() == {}



# Generated at 2022-06-20 20:38:42.291802
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual()
    assert virtual_facts.get_virtual_facts()['virtualization_type'] == ''

# Generated at 2022-06-20 20:38:45.194067
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    # Assert that netbsd_virtual is NetBSDVirtual instance
    assert isinstance(netbsd_virtual, NetBSDVirtual)



# Generated at 2022-06-20 20:38:46.524051
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    c = NetBSDVirtualCollector()

# Generated at 2022-06-20 20:38:54.565284
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    NetBSDVirtualCollector._update_virtual_facts()

    class ModuleHelper(object):
        def __init__(self, params=None):
            self.params = {}
            if params:
                for param in params:
                    self.params[param] = params[param]

    # Test default facts
    def mock_read_file_lines(filename):
        if filename == '/dev/xencons':
            return

        if filename == '/dev/hypervisor':
            return None


# Generated at 2022-06-20 20:39:04.933465
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    collected_facts = {
        'virtualization_type': '',
        'virtualization_role': ''
    }

    virtual_facts = {
        'virtualization_type': 'kvm',
        'virtualization_role': 'guest'
    }

    # Test for sysctl_virtual_facts
    sysctl_virtual_facts = {
        'machdep.dmi.system-product':
            b'VMware Virtual Platform',
        'machdep.dmi.system-vendor':
            b'VMware, Inc.',
        'machdep.hypervisor':
            b'xen',
    }

    virtual = NetBSDVirtual(collected_facts, sysctl_virtual_facts)
    virtual_facts = virtual.get_virtual_facts()
    assert 'virtualization_tech_guest' in virtual

# Generated at 2022-06-20 20:39:09.415336
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual(module=None)
    netbsd_virtual.collect()
    # Make sure we get a dict
    assert isinstance(netbsd_virtual.data, dict)
    # Make sure we get a non-empty dict
    assert netbsd_virtual.data

# Generated at 2022-06-20 20:39:12.856271
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    # Instantiate NetBSDVirtualCollector so that it can be used in tests
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert netbsd_virtual_collector._platform == 'NetBSD'
    assert netbsd_virtual_collector._fact_class == NetBSDVirtual


# Generated at 2022-06-20 20:39:13.928834
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    thisObj = NetBSDVirtualCollector()
    assert thisObj is not None

# Generated at 2022-06-20 20:39:22.242967
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    facts_dict = {'kernel': 'NetBSD', 'system': 'NetBSD'}
    facts = NetBSDVirtual(module=None, facts=facts_dict)

    expected_virtual_facts = {'virtualization_type': '', 'virtualization_role': '', 'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}
    assert facts.get_virtual_facts() == expected_virtual_facts

# Generated at 2022-06-20 20:39:30.387855
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    """Just instantiating a NetBSDVirtualCollector gets the detection logic initialized."""
    NetBSDVirtualCollector()

# Generated at 2022-06-20 20:39:34.836483
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector._platform == 'NetBSD'
    assert issubclass(NetBSDVirtualCollector._fact_class, Virtual)
    assert issubclass(NetBSDVirtualCollector._fact_class, VirtualSysctlDetectionMixin)


# Generated at 2022-06-20 20:39:36.038796
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    v = NetBSDVirtual()
    assert v.platform == 'NetBSD'

# Generated at 2022-06-20 20:39:37.789505
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    inst = NetBSDVirtualCollector()
    assert isinstance(inst, NetBSDVirtualCollector)


# Generated at 2022-06-20 20:39:48.585559
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    '''
    Test get_virtual_facts method
    '''
    from ansible.module_utils.facts import collector

    def _get_sysctl_value(key):
        """
        Mock get_sysctl_value method
        """
        if key == 'machdep.dmi.system-product':
            return 'Virtual Machine'
        if key == 'machdep.dmi.system-vendor':
            return 'Google'
        if key == 'machdep.hypervisor':
            return 'Xen'

    collector._get_sysctl_value = _get_sysctl_value

    fake_facts = {
        'ansible_virtualization_type': '',
        'ansible_virtualization_role': '',
    }

# Generated at 2022-06-20 20:40:00.571887
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():

    from ansible.module_utils.facts.virtual.sysctl import VirtualSysctlDetectionMixin

    # Create a mock object for the mixin methods
    class DummySysctl(VirtualSysctlDetectionMixin):
        pass

    # Create a NetBSDVirtual object from the DummySysctl object
    class DummyVirt(NetBSDVirtual, DummySysctl):
        pass

    # Create a NetBSDVirtual object
    nbvirt = NetBSDVirtual()

    # Verify the result of the method get_virtual_facts
    assert nbvirt.get_virtual_facts() == {'virtualization_type': ''}

    # Create a DummyVirt object
    dummyvirt = DummyVirt()

    # Add property virtualization_type and virtualization_role to the object
    dummyvirt.virtualization_type = ''

# Generated at 2022-06-20 20:40:08.116418
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    """
    Test method get_virtual_facts of class NetBSDVirtual
    """
    fake_virtual_facts = {
        'virtualization_type': 'citrix',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['hvm']),
        'virtualization_tech_host': set(['citrix'])
    }

    netbsd_virtual_ins = NetBSDVirtual()
    virtual_facts = netbsd_virtual_ins.get_virtual_facts()
    assert virtual_facts == fake_virtual_facts

# Generated at 2022-06-20 20:40:10.699707
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector is not None
    assert NetBSDVirtualCollector._fact_class is NetBSDVirtual
    assert NetBSDVirtualCollector._platform == 'NetBSD'

# Generated at 2022-06-20 20:40:11.767087
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector._platform == 'NetBSD'

# Generated at 2022-06-20 20:40:12.622465
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector is not None

# Generated at 2022-06-20 20:40:35.781790
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual = NetBSDVirtual({}, None)
    virtual_facts = virtual.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_type_role'] == ''
    assert virtual_facts['virtualization_system'] == ''
    assert virtual_facts['virtualization_environ'] == ''
    assert virtual_facts['virtualization_uid_domain'] == ''
    assert virtual_facts['virtualization_product_name'] == ''
    assert virtual_facts['virtualization_product_version'] == ''
    assert virtual_facts['virtualization_product_host'] == ''
    assert virtual_facts['virtualization_product_uuid'] == ''

# Generated at 2022-06-20 20:40:46.042746
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    # Initialize NetBSDVirtual class
    virt = NetBSDVirtual(None)
    # virt.get_virtual_facts()
    # Check "virtualization_type"
    assert(virt.get_virtual_facts()['virtualization_type'] == '')
    # Check "virtualization_role"
    assert(virt.get_virtual_facts()['virtualization_role'] == '')
    # Check "virtualization_product"
    assert(virt.get_virtual_facts()['virtualization_product'] == '')
    # Check "virtualization_subsystem"
    assert('virtualization_subsystem' in virt.get_virtual_facts().keys())
    # Check "virtualization_systems"
    assert(virt.get_virtual_facts()['virtualization_systems'] == set())
    # Check "virtualization_environments"


# Generated at 2022-06-20 20:40:52.429736
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    test_virtual = NetBSDVirtual()

    '''
    Virtual parameters for VirtualBox
    '''
    test_virtual_sysctl_vendor_string = 'innotek GmbH'
    test_virtual_sysctl_product_string = 'VirtualBox'
    test_virtual_sysctl_machine_string = 'amd64'
    test_virtual_sysctl_hypervisor_string = 'GenuineIntel-6.92-000'

    '''
    Virtual parameters for Xen
    '''
    test_virtual_xen_vendor_string = 'Xen'
    test_virtual_xen_hypervisor_string = 'XenVMMXenVMM'

    '''
    Virtual parameters for Parallels
    '''
    test_virtual_parallels_vendor_string = 'Parallels Software International Inc.'

# Generated at 2022-06-20 20:41:00.812185
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = {}
    virtual_facts['virtualization_type'] = 'xen'
    virtual_facts['virtualization_role'] = 'guest'
    virtual_facts['virtualization_tech_guest'] = set(['xen'])
    virtual_facts['virtualization_tech_host'] = set(['xen'])
    virtual_facts['virtualization_product_name'] = 'Xen'
    virtual_facts['virtualization_product_version'] = '4.1'

    assert_result = virtual_facts
    assert_result['virtualization_type'] = 'xen'
    assert_result['virtualization_role'] = 'guest'
    assert_result['virtualization_tech_guest'] = set(['xen'])

# Generated at 2022-06-20 20:41:02.735723
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_detector = NetBSDVirtual()
    assert(virtual_detector.platform == 'NetBSD')



# Generated at 2022-06-20 20:41:04.167031
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd = NetBSDVirtual()
    assert netbsd.platform == 'NetBSD'

# Generated at 2022-06-20 20:41:12.518762
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.netbsd import NetBSDVirtual
    virtual_facts = NetBSDVirtual().get_virtual_facts()
    # Test if virtual_facts is a dictionary
    assert isinstance(virtual_facts, dict)
    # Test if it contains a key 'virtualization_role'
    assert 'virtualization_role' in virtual_facts
    # Test if it contains a key 'virtualization_type'
    assert 'virtualization_type' in virtual_facts
    # Test if it contains a key 'virtualization_technologies_guest'
    assert 'virtualization_technologies_guest' in virtual_facts
    # Test if it contains a key 'virtualization_technologies_host'
    assert 'virtualization_technologies_host' in virtual_facts

# Generated at 2022-06-20 20:41:24.030910
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    my_obj = NetBSDVirtual()

    #
    # Test with blank file
    #
    my_open_mock = mocker.mock_open(read_data='')
    with mocker.patch('%s.open' % builtin_name, my_open_mock, create=True):
        virtual_facts = my_obj.get_virtual_facts()
        assert virtual_facts == {}

    #
    # Test with machdep.dmi.system-product
    #
    my_open_mock = mocker.mock_open(read_data='vbox')
    with mocker.patch('%s.open' % builtin_name, my_open_mock, create=True):
        virtual_facts = my_obj.get_virtual_facts()

# Generated at 2022-06-20 20:41:28.359629
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual()
    assert virtual_facts.platform == 'NetBSD'
    assert virtual_facts.virtualization_type == ''
    assert virtual_facts.virtualization_role == ''
    assert virtual_facts.virtualization_tech_guest == set()
    assert virtual_facts.virtualization_tech_guest == set()

# Test for virtualization_type and virtualization_role

# Generated at 2022-06-20 20:41:29.969430
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual({})
    assert(virtual.data == {})

# Generated at 2022-06-20 20:41:56.816753
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd = NetBSDVirtualCollector()
    assert netbsd.get_virtual_facts()['virtualization_type'].startswith('NetBSD')

# Generated at 2022-06-20 20:42:09.224535
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    '''Unit test for method get_virtual_facts of class NetBSDVirtual'''
    class MockReadFile(object):

        def __init__(self, file_dict):
            self.file_dict = file_dict

        @staticmethod
        def read_file(filename):
            return

        @staticmethod
        def read_file_contents(filename):
            if filename == '/proc/cpuinfo':
                return self.file_dict['/proc/cpuinfo']
            return

    # Case 1: host is virtual machine
    # Expected result:
    #       virtualization_type='virtualbox'
    #       virtualization_role='guest'
    #       virtualization_product='VirtualBox'
    #       virtualization_technology={'hvm', 'vbox'}
    #       virtualization_system='virtualbox'


# Generated at 2022-06-20 20:42:19.241559
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virt = NetBSDVirtual()
    virtual_facts = netbsd_virt.get_virtual_facts()

    expected_expected_type = ['virtualbox', '', '', 'xen']
    expected_actual_type = ['', '', '', 'xen']

    expected_expected_role = ['guest', 'guest', 'guest', 'guest']
    expected_actual_role = ['guest', 'guest', '', 'guest']

    # iterate through the sets of dictionaries, comparing the expected and
    # actual values

# Generated at 2022-06-20 20:42:25.907965
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    obj = NetBSDVirtualCollector()
    assert hasattr(obj, '_platforms')
    assert hasattr(obj, 'data')
    assert hasattr(obj, 'collect')
    assert hasattr(obj, '_fact_class')
    assert NetBSDVirtualCollector._platform == 'NetBSD'
    assert NetBSDVirtualCollector._fact_class == NetBSDVirtual


# Generated at 2022-06-20 20:42:36.121098
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    class MockModule(object):
        def __init__(self):
            self.params = {'gather_subset': ['virtual']}

        def fail_json(self, msg):
            raise AssertionError(msg)

        def get_bin_path(self, arg, required=False, opt_dirs=[]):
            if arg == 'sysctl':
                return '/sbin/sysctl'
            else:
                if required:
                    self.fail_json("test_NetBSDVirtual_get_virtual_facts(): get_bin_path() called for non-sysctl arg '%s'" % arg)
                return None


# Generated at 2022-06-20 20:42:44.334957
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    with open('tests/unit/data/facts/virtual/NetBSD_virtual.out') as f:
        lines = f.readlines()
    sysctl_return = "\n".join(lines)
    virtual_facts = NetBSDVirtual(None, 'NetBSD', sysctl_return).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_guest'] == set(['xen'])
    assert virtual_facts['virtualization_tech_host'] == set([])
    assert virtual_facts['virtualization_product_version'] == ''
    assert virtual_facts['virtualization_product_name'] == ''
    assert virtual_facts['virtualization_product_vendor'] == ''

# Generated at 2022-06-20 20:42:46.198162
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual_facts = NetBSDVirtual()
    assert netbsd_virtual_facts.platform == 'NetBSD'


# Generated at 2022-06-20 20:42:49.402380
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    collector = NetBSDVirtualCollector(None)
    assert collector._fact_class == NetBSDVirtual
    assert collector._platform == 'NetBSD'

# Generated at 2022-06-20 20:42:58.986637
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():

    from ansible.module_utils.facts.virtual.netbsd import NetBSDVirtual

    class TestArgs():
        def __init__(self, sysctl_output):
            self.sysctl = sysctl_output

    testargs = TestArgs("machdep.hypervisor=VirtualBox")
    virtual_facts = NetBSDVirtual(testargs=testargs).get_virtual_facts()

    assert virtual_facts['virtualization_type'] == 'virtualbox'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_guest'] == set(['virtualbox'])
    assert virtual_facts['virtualization_tech_host'] == set()

    # verify that later facts override previous facts

# Generated at 2022-06-20 20:43:02.107734
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert netbsd_virtual_collector._fact_class is NetBSDVirtual


# Generated at 2022-06-20 20:44:05.814683
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virt = NetBSDVirtual()
    virt_facts = netbsd_virt.get_virtual_facts()

    assert 'virtualization_role' in virt_facts
    assert 'virtualization_type' in virt_facts
    assert 'virtualization_tech_guest' in virt_facts
    assert 'virtualization_tech_host' in virt_facts

# Generated at 2022-06-20 20:44:07.948452
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector()._platform == 'NetBSD'

# Generated at 2022-06-20 20:44:09.980265
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual_obj = NetBSDVirtual()
    assert netbsd_virtual_obj.get_virtual_facts()['virtualization_type'] == ''


# Generated at 2022-06-20 20:44:16.535672
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual().get_virtual_facts()
    assert 'virtualization_type' in virtual_facts, \
        "Virtualization type is not set"
    assert 'virtualization_role' in virtual_facts, \
        "Virtualization role is not set"
    assert 'virtualization_tech_guest' in virtual_facts, \
        "Virtualization technology for guest is not set"
    assert 'virtualization_tech_host' in virtual_facts, \
        "Virtualization technology for host is not set"

# Generated at 2022-06-20 20:44:17.961916
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    n_v_c = NetBSDVirtualCollector()
    assert n_v_c._fact_class == NetBSDVirtual

# Generated at 2022-06-20 20:44:19.864545
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual()
    assert virtual.platform == 'NetBSD'

# Generated at 2022-06-20 20:44:21.750015
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    facts_dict = {}
    netbsd_facts = NetBSDVirtual(facts_dict, None)

    assert(netbsd_facts.platform == 'NetBSD')


# Generated at 2022-06-20 20:44:22.610445
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual()
    assert virtual.platform == 'NetBSD'

# Generated at 2022-06-20 20:44:25.053162
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd = NetBSDVirtual({}, {})
    assert netbsd.platform == 'NetBSD'


# Generated at 2022-06-20 20:44:31.211608
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = {
        'virtualization_role': 'guest',
        'virtualization_type': 'xen',
        'virtualization_tech_host': '',
        'virtualization_tech_guest': set(['xen']),
    }
    fact_class = NetBSDVirtual()
    result = fact_class.get_virtual_facts()

    assert result == virtual_facts, 'Unexpected virtual facts returned'

# Generated at 2022-06-20 20:47:07.178174
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    NetBSDVirtualCollector()

# Generated at 2022-06-20 20:47:08.214587
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    NetBSDVirtualCollector(None, None)

# Generated at 2022-06-20 20:47:09.459856
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_vc = NetBSDVirtualCollector()

# Generated at 2022-06-20 20:47:16.801829
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual = NetBSDVirtual()
    netbsd_virtual.facts['machdep.dmi.system-product'] = 'Amazon EC2'
    netbsd_virtual.facts['machdep.dmi.system-vendor'] = 'innotek GmbH'
    netbsd_virtual.facts['machdep.hypervisor'] = 'xen'

    result_facts = netbsd_virtual.get_virtual_facts()
    assert result_facts.get('virtualization_type') == 'xen'
    assert result_facts.get('virtualization_role') == 'guest'
    assert result_facts.get('virtualization_guest_id') == ''
    assert result_facts.get('virtualization_product') == ''
    assert result_facts.get('virtualization_tech_guest')

# Generated at 2022-06-20 20:47:22.368704
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    virtual_facts = netbsd_virtual.get_virtual_facts()

    if os.path.exists('/dev/xencons'):
        assert (virtual_facts['virtualization_type'] == 'xen')
        assert (virtual_facts['virtualization_role'] == 'guest')

# Generated at 2022-06-20 20:47:27.568760
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector()._platform == 'NetBSD'
    assert NetBSDVirtualCollector()._fact_class == NetBSDVirtual
    assert NetBSDVirtualCollector()._fact_class() is not None


# Generated at 2022-06-20 20:47:29.317437
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert hasattr(NetBSDVirtualCollector, '_platform')
    assert NetBSDVirtualCollector._platform == 'NetBSD'


# Generated at 2022-06-20 20:47:31.161059
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert netbsd_virtual_collector._fact_class == NetBSDVirtual
    assert netbsd_virtual_collector._platform == 'NetBSD'

# Generated at 2022-06-20 20:47:33.506057
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virt = NetBSDVirtualCollector()
    assert virt.platform == 'NetBSD'

# Generated at 2022-06-20 20:47:34.881661
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    obj = NetBSDVirtualCollector()
    assert obj.platform == 'NetBSD'