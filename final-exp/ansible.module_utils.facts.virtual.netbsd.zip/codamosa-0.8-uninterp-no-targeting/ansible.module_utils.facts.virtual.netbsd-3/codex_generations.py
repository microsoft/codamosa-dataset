

# Generated at 2022-06-20 20:37:49.799484
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert not virtual_facts['virtualization_tech_guest']
    assert not virtual_facts['virtualization_tech_host']

# Generated at 2022-06-20 20:37:53.290126
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():

    netbsd_virtual = NetBSDVirtual()

    results = netbsd_virtual.get_virtual_facts()
    assert results['virtualization_type'] == 'xen'
    assert results['virtualization_role'] == 'guest'

# Generated at 2022-06-20 20:37:57.414425
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    data = NetBSDVirtual()
    assert data['virtualization_type'] == ''
    assert data['virtualization_role'] == ''
    assert data['virtualization_system'] == ''
    assert data['virtualization_uuid'] == ''

# Generated at 2022-06-20 20:38:00.155002
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual._platform == 'NetBSD'


# Generated at 2022-06-20 20:38:12.398475
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    def sysctl_mock(kernel, key):
        if kernel == 'machdep.dmi.system-product':
            return 'KVM'
        elif kernel == 'machdep.dmi.system-vendor':
            return 'Red Hat'
        return ''

    def path_exists_mock(path):
        if path == '/dev/xencons':
            return True
        return False


# Generated at 2022-06-20 20:38:16.584559
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virt = NetBSDVirtual({})
    assert virt.collect() == {'virtualization_type': 'unknown',
                              'virtualization_role': 'unknown',
                              'virtualization_tech_guest': set(),
                              'virtualization_tech_host': set()}

# Generated at 2022-06-20 20:38:19.394733
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    n = NetBSDVirtualCollector()
    assert n._platform == 'NetBSD'
    assert n._fact_class == NetBSDVirtual


# Generated at 2022-06-20 20:38:20.197803
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    collector = NetBSDVirtualCollector()
    assert isinstance(collector, NetBSDVirtualCollector)


# Generated at 2022-06-20 20:38:23.147946
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual(module=None)
    assert netbsd_virtual.platform == 'NetBSD'

# Generated at 2022-06-20 20:38:34.277557
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Override Virtual.get_file_content() to return test data
    def get_file_content(file):
        if file.endswith('/machdep.dmi.system-vendor'):
            return 'Google'
        elif file.endswith('/machdep.dmi.system-product'):
            return 'Google Compute Engine'
        elif file.endswith('/machdep.hypervisor'):
            return 'KVM'
        else:
            return ''
    import __builtin__
    __builtin__._get_file_content = NetBSDVirtual.get_file_content
    NetBSDVirtual.get_file_content = get_file_content

    # Override Virtual._detect_container() to return empty set of types
    import __builtin__
    __builtin__

# Generated at 2022-06-20 20:38:44.855286
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual({}).get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_system' in virtual_facts
    assert 'virtualization_host' in virtual_facts
    assert 'virtualization_guest' in virtual_facts
    assert 'virtualization_hypervisor' in virtual_facts
    assert 'virtualization_products' in virtual_facts

# Generated at 2022-06-20 20:38:46.164738
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual()
    assert virtual_facts.virtualization_type == ''

# Generated at 2022-06-20 20:38:54.370264
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    VF = NetBSDVirtual()
    datastore = {}
    datastore['sysctl_args'] = ['machdep.dmi.system-vendor', 'machdep.dmi.system-product', 'machdep.hypervisor']
    datastore['sysctl_extended'] = {}
    datastore['sysctl_extended']['machdep.dmi.system-vendor'] = {'value': 'KVM'}
    datastore['sysctl_extended']['machdep.hypervisor'] = {'value': 'KVM'}
    datastore['sysctl_extended']['machdep.dmi.system-product'] = {'value': 'KVM'}

# Generated at 2022-06-20 20:38:57.769495
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual_fact = NetBSDVirtual(None)
    assert netbsd_virtual_fact.__class__.__name__ == 'NetBSDVirtual'
    assert netbsd_virtual_fact.platform == 'NetBSD'


# Generated at 2022-06-20 20:39:03.206464
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    result = NetBSDVirtual({}, {})
    assert result.sysctl_name == 'sysctl -n'
    assert result.platform == 'NetBSD'
    result = NetBSDVirtual({'sysctl_path': '/usr/local/bin/sysctl'}, {})
    assert result.sysctl_name == '/usr/local/bin/sysctl -n'


# Generated at 2022-06-20 20:39:07.356245
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert isinstance(netbsd_virtual_collector._fact_class, NetBSDVirtual)
    assert netbsd_virtual_collector._platform == 'NetBSD'


# Generated at 2022-06-20 20:39:09.179071
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual({})
    assert virtual
    assert virtual.platform == 'NetBSD'

# Generated at 2022-06-20 20:39:16.572859
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = {}
    virtual_facts['virtualization_type'] = ''
    virtual_facts['virtualization_role'] = ''
    virtual_facts['virtualization_tech_guest'] = set()
    virtual_facts['virtualization_tech_host'] = set()

    guest_tech = set()
    host_tech = set()

    # Return product name none
    virtual_product_facts = NetBSDVirtual().detect_virt_product('none')
    guest_tech.update(virtual_product_facts['virtualization_tech_guest'])
    host_tech.update(virtual_product_facts['virtualization_tech_host'])
    assert virtual_facts['virtualization_type'] == virtual_product_facts['virtualization_type']

# Generated at 2022-06-20 20:39:20.111094
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert netbsd_virtual_collector._fact_class is NetBSDVirtual
    assert netbsd_virtual_collector._platform == 'NetBSD'

# Generated at 2022-06-20 20:39:22.096798
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virt = NetBSDVirtual()
    assert virt.platform == 'NetBSD'

# Generated at 2022-06-20 20:39:33.554707
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_collector = NetBSDVirtual()
    virtual_facts = virtual_collector.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_full_info'] == []

# Generated at 2022-06-20 20:39:39.613475
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Create a NetBSDVirtual class object
    virtual_facts = NetBSDVirtual()

    # Get the virtualization facts
    virtual_facts_dict = virtual_facts.get_virtual_facts()

    # Check for facts
    assert type(virtual_facts_dict) == dict
    assert virtual_facts_dict['virtualization_type'] == ''
    assert virtual_facts_dict['virtualization_role'] == ''
    assert virtual_facts_dict['virtualization_system'] == ''
    assert virtual_facts_dict['virtualization_role'] == ''
    assert type(virtual_facts_dict['virtualization_tech_guest']) == set
    assert type(virtual_facts_dict['virtualization_tech_host']) == set

# Generated at 2022-06-20 20:39:42.512274
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    v = NetBSDVirtual()
    assert v.platform == 'NetBSD', v.platform


# Generated at 2022-06-20 20:39:44.560856
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsdvirtual = NetBSDVirtual('/sys/')
    assert netbsdvirtual.platform == 'NetBSD'


# Generated at 2022-06-20 20:39:48.245050
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    # The os.getpid() method is used as it is a real method that is used to
    # retrieve the process id of the current process.
    drv = NetBSDVirtual({'module_setup': {'filter': 'ansible_local'}},
        os.getpid)
    assert drv

# Generated at 2022-06-20 20:39:57.397625
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    module = FakeModule()
    virtual = NetBSDVirtual({}, module=module)
    virtual.detect_virt_product = FakeVirtProductMethod()
    virtual.detect_virt_vendor = FakeVirtVendorMethod()
    facts = virtual.get_virtual_facts()

    assert facts == {
        'virtualization_type': 'kvm',
        'virtualization_role': 'host',
        'virtualization_tech_host': set([
            'kvm'
        ]),
        'virtualization_tech_guest': set([])
    }


# Test fixtures for method get_virtual_facts of class NetBSDVirtual

# Generated at 2022-06-20 20:39:58.940086
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert isinstance(NetBSDVirtualCollector().get_virtual_facts(), dict)

# Generated at 2022-06-20 20:40:03.175535
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    bsd_virtual_collector = NetBSDVirtualCollector()
    assert bsd_virtual_collector._platform == 'NetBSD'
    assert bsd_virtual_collector._fact_class == NetBSDVirtual

# Generated at 2022-06-20 20:40:06.204900
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert netbsd_virtual_collector.platform == 'NetBSD'
    assert netbsd_virtual_collector.fact_class == NetBSDVirtual


# Generated at 2022-06-20 20:40:08.095546
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert(netbsd_virtual.platform == "NetBSD")

# Generated at 2022-06-20 20:40:24.663456
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    x = NetBSDVirtualCollector()
    assert x._fact_class == NetBSDVirtual
    assert x._platform == 'NetBSD'

# Generated at 2022-06-20 20:40:26.283437
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual()
    assert virtual.platform == 'NetBSD'


# Generated at 2022-06-20 20:40:29.121510
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts_instance = NetBSDVirtual()
    assert virtual_facts_instance.platform == 'NetBSD'


# Generated at 2022-06-20 20:40:31.037612
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual()
    assert virtual_facts.platform == 'NetBSD'
    assert virtual_facts.get_virtual_facts() == {}

# Generated at 2022-06-20 20:40:36.970673
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual().get_virtual_facts()

    # Expected return value
    virtual_facts_expected = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }

    assert virtual_facts == virtual_facts_expected

# Generated at 2022-06-20 20:40:47.116540
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual()
    virtual.sysctl_exe = lambda x: ''

    virtual.sysctl = {
        'machdep.dmi.system-vendor': '',
        'machdep.hypervisor': '',
    }

    virtual.file_exists = lambda x: True

    assert virtual.is_guest() == False
    assert virtual.is_host() == True
    assert virtual.get_virtual_facts()['virtualization_type'] == ''
    assert virtual.get_virtual_facts()['virtualization_role'] == ''
    assert virtual.get_virtual_facts()['virtualization_tech_host'].issubset(set(['xen']))
    assert virtual.get_virtual_facts()['virtualization_tech_guest'].issubset(set(['xen']))

   

# Generated at 2022-06-20 20:40:53.344377
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virt = NetBSDVirtual()

    assert virt.get_virtual_facts() == {
        'virtualization_role': 'guest',
        'virtualization_type': 'hvm',
        'virtualization_tech_guest': {},
        'virtualization_tech_host': {}
    }


# Generated at 2022-06-20 20:40:58.105524
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual().get_virtual_facts()
    assert isinstance(virtual_facts, dict)
    assert virtual_facts['virtualization_type'] in ('', 'kvm', 'xen', 'vserver', 'virtualbox', 'parallels', 'vmware', 'hyperv', 'virtualpc')
    assert virtual_facts['virtualization_role'] in ('guest', 'host')

# Generated at 2022-06-20 20:41:00.884543
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_msg = NetBSDVirtual()
    assert virtual_msg.platform == 'NetBSD'

# Generated at 2022-06-20 20:41:10.412715
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Return values.
    # Each return value must be a dict and have virtualization_type and virtualization_role keys.
    # These keys are feeded for each entry of get_virtual_facts return value.
    # The keys of the dict returned by get_virtual_facts method will be the union of all virtualization_type and virtualization_role keys.
    # The value of these keys will be the list of all virtualization_type and virtualization_role values of all dicts returned by get_virtual_facts.

    # Set mocked facts
    facts = dict()

    # Set sysctl values
    sysctl = dict()
    sysctl['machdep.dmi.system-vendor'] = 'Google'
    sysctl['machdep.dmi.system-product'] = 'Google Compute Engine'
    sysctl['machdep.hypervisor']

# Generated at 2022-06-20 20:41:44.510181
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual_fact = NetBSDVirtual({'ansible_facts': {'ansible_system_vendor': '', 'ansible_product_name': ''}})
    assert isinstance(netbsd_virtual_fact, Virtual)
    assert netbsd_virtual_fact.platform == 'NetBSD'

# Generated at 2022-06-20 20:41:55.230751
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # pylint: disable=import-error,no-name-in-module
    from ansible.module_utils.facts.virtual.netbsd import NetBSDVirtual
    from ansible.module_utils.facts.virtual.sysctl import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.base import Virtual

    class MockSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        # mock sysctl results
        machdep_dmi = {'machdep.dmi.system-product': 'VMware Virtual Platform',
                       'machdep.dmi.system-vendor' : 'VMware, Inc.',
                       'machdep.hypervisor': 'VMware, Inc.'}


# Generated at 2022-06-20 20:41:57.630900
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert netbsd_virtual_collector.platform == 'NetBSD'

# Generated at 2022-06-20 20:42:01.698121
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsdvirtualcollector = NetBSDVirtualCollector()
    assert netbsdvirtualcollector.platform == 'NetBSD'
    assert netbsdvirtualcollector._fact_class == NetBSDVirtual


# Generated at 2022-06-20 20:42:04.070396
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_role'] == 'guest'

# Generated at 2022-06-20 20:42:06.187833
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    obj = NetBSDVirtualCollector()
    assert obj._platform == 'NetBSD'


# Generated at 2022-06-20 20:42:17.028735
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_tech_set_empty = set()
    virtual_tech_set_guest = set(['guest'])
    virtual_tech_set_host = set(['host'])

    virtual_dict_host = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': virtual_tech_set_empty,
        'virtualization_tech_host': virtual_tech_set_host
    }

    virtual_dict_guest = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': virtual_tech_set_guest,
        'virtualization_tech_host': virtual_tech_set_empty
    }


# Generated at 2022-06-20 20:42:23.388200
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Test virtualizations detected by machdep.dmi.system-vendor and
    # machdep.dmi.system-product
    with open('/proc/sysctl/machdep.dmi.system-vendor', 'wb') as f:
        f.write('Microsoft Corporation\n'.encode())
    with open('/proc/sysctl/machdep.dmi.system-product', 'wb') as f:
        f.write('Virtual Machine\n'.encode())
    virtual = NetBSDVirtual()
    virtual_facts = virtual.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == 'vmware'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_guest'] == set(['vmware'])
    assert virtual_

# Generated at 2022-06-20 20:42:31.884987
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # All values are expected to be empty
    expected = {'virtualization_type': '',
                'virtualization_role': '',
                'virtualization_system': '',
                'virtualization_product_name': '',
                'virtualization_product_version': '',
                'virtualization_numvcpus': 1,
                'virtualization_tech_guest': set(),
                'virtualization_tech_host': set()}
    # Create an instance of NetBSDVirtual class
    netbsd_virtual = NetBSDVirtual()
    # Assert method get_virtual_facts returns the expected dictionary
    assert netbsd_virtual.get_virtual_facts() == expected

# Generated at 2022-06-20 20:42:41.530068
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual().get_virtual_facts()
    assert isinstance(virtual_facts, dict)
    assert isinstance(virtual_facts.get('virtualization_type'), str)
    assert isinstance(virtual_facts.get('virtualization_role'), str)
    assert isinstance(virtual_facts.get('virtualization_type'), str)
    assert isinstance(virtual_facts.get('virtualization_type_full'), str)
    assert isinstance(virtual_facts.get('virtualization_tech_guest'), set)
    assert isinstance(virtual_facts.get('virtualization_tech_host'), set)
    assert isinstance(virtual_facts.get('virtualization_tech_guest'), set)
    assert isinstance(virtual_facts.get('virtualization_tech_host'), set)

# Generated at 2022-06-20 20:43:43.187452
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    obj = NetBSDVirtual()
    assert isinstance(obj.get_virtual_facts(), dict)

# Generated at 2022-06-20 20:43:43.988656
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    NetBSDVirtualCollector()

# Generated at 2022-06-20 20:43:45.092416
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virtual = NetBSDVirtual()
    assert virtual.platform == 'NetBSD'

# Generated at 2022-06-20 20:43:51.224967
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsdvirtual = NetBSDVirtual()
    facts = netbsdvirtual.get_virtual_facts()

    assert facts['virtualization_type'] == 'kvm'
    assert facts['virtualization_role'] == 'guest'
    assert 'kvm' in facts['virtualization_tech_guest']
    assert 'kvm' in facts['virtualization_tech_host']

# Generated at 2022-06-20 20:43:54.530802
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # this makes sure that get_virtual_facts returns a dict
    netbsd_virtual = NetBSDVirtual()
    assert isinstance(netbsd_virtual.get_virtual_facts(), dict)



# Generated at 2022-06-20 20:43:59.669959
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virt_facts = NetBSDVirtualCollector().get_virtual_facts()
    assert 'virtualization_type' in virt_facts
    assert 'virtualization_role' in virt_facts
    assert 'virtualization_tech_guest' in virt_facts
    assert 'virtualization_tech_host' in virt_facts

# Generated at 2022-06-20 20:44:03.137582
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd = NetBSDVirtualCollector()
    assert netbsd._platform == 'NetBSD'
    assert netbsd._fact_class == NetBSDVirtual

# Generated at 2022-06-20 20:44:05.391939
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virtual_collector = NetBSDVirtualCollector()
    assert virtual_collector._platform == 'NetBSD'
    assert virtual_collector._fact_class == NetBSDVirtual


# Generated at 2022-06-20 20:44:06.729821
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    assert NetBSDVirtual(None).platform == 'NetBSD'


# Generated at 2022-06-20 20:44:16.770320
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }
    netbsd_virtual = NetBSDVirtual()
    virtual_facts = netbsd_virtual.get_virtual_facts()

    assert_equals(virtual_facts['virtualization_type'], '', 'virtualization_type should be empty string')
    assert_equals(virtual_facts['virtualization_role'], '', 'virtualization_role should be empty string')
    assert_equals(virtual_facts['virtualization_tech_guest'], set(), 'virtualization_tech_guest should be empty set')

# Generated at 2022-06-20 20:47:02.007613
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    facts = {}
    # Test get_virtual_facts with an existing data file
    test_file = os.path.dirname(__file__) + '/../../sample/sysctl/machdep.dmi.system-product'
    with open(test_file, 'r') as f:
        content = f.read()
    data = NetBSDVirtualCollector.parse_output(content)
    virtual = NetBSDVirtual(facts, None, data, None)
    virtual_facts = virtual.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == 'vmware'
    assert virtual_facts['virtualization_role'] == 'host'

    # Test get_virtual_facts with a non existant file

# Generated at 2022-06-20 20:47:07.816550
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    detector = NetBSDVirtual({})
    # virtual_facts = detector.get_virtual_facts()
    # assert virtual_facts['virtualization_type'] == 'xen'
    # assert virtual_facts['virtualization_role'] == 'guest'
    assert True

# Generated at 2022-06-20 20:47:09.729717
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual({})
    assert netbsd_virtual.platform == 'NetBSD'


# Generated at 2022-06-20 20:47:11.512210
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    facts = NetBSDVirtual()
    assert facts._platform == 'NetBSD'

# Generated at 2022-06-20 20:47:14.002032
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_platform = NetBSDVirtualCollector()
    assert netbsd_platform
    assert netbsd_platform._platform == 'NetBSD'
    assert netbsd_platform._fact_class == NetBSDVirtual

# Generated at 2022-06-20 20:47:24.973492
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    NetBSDVirtual_obj = NetBSDVirtual()
    NetBSDVirtual_obj.sysctl_all_output = {'machdep.dmi.system-product': 'PRODUCT',
                                           'machdep.dmi.system-vendor': 'VENDOR',
                                           'machdep.hypervisor': 'HYPERVISOR',
                                           'machdep.dmi.baseboard-vendor': 'VENDOR'}

# Generated at 2022-06-20 20:47:28.869010
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual(None).get_virtual_facts()
    assert ('virtualization_type' in virtual_facts and
            'virtualization_role' in virtual_facts and
            'virtualization_tech_guest' in virtual_facts and
            'virtualization_tech_host' in virtual_facts)

# Generated at 2022-06-20 20:47:30.184888
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    collector = NetBSDVirtualCollector()
    fact_class = collector.detect()
    assert fact_class == NetBSDVirtual

# Generated at 2022-06-20 20:47:33.505186
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual()
    facts = virtual.get_virtual_facts()
    # print(json.dumps(facts, indent=4, sort_keys=True))
    assert isinstance(facts, dict)

# Generated at 2022-06-20 20:47:43.216814
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    import mock
    from ansible.module_utils.facts.virtual.netbsd import NetBSDVirtual
    facts = NetBSDVirtual()
    mock_exec_file = mock.Mock(return_value=('foo', 'bar'))
    guest = fact = set()
    host = fact = set()

    # Virtualization type is not detected, but the role is.
    with mock.patch.object(facts, '_exec_file', mock_exec_file):
        with mock.patch.dict(facts.virtualization_fact_keys,
                             {'machdep.dmi.system-product': 'Prod'}):
            facts.virtualization_fact_keys = {'machdep.dmi.system-product': 'Prod'}
            virtual_facts = facts.get_virtual_facts()
            assert virtual_facts