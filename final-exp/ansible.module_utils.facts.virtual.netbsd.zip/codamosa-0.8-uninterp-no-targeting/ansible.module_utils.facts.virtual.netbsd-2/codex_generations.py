

# Generated at 2022-06-20 20:37:45.886319
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    x = NetBSDVirtualCollector()
    assert x.platform == "NetBSD"


# Generated at 2022-06-20 20:37:48.571628
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual({})
    # Test that object is of class NetBSDVirtual
    assert isinstance(netbsd_virtual, NetBSDVirtual)

# Generated at 2022-06-20 20:37:51.566808
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    module = {}
    virtual_obj = NetBSDVirtualCollector(module=module)
    assert isinstance(virtual_obj, NetBSDVirtualCollector)
    assert virtual_obj.platform == 'NetBSD'

# Generated at 2022-06-20 20:37:52.527157
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    x = NetBSDVirtualCollector()
    assert x._platform == 'NetBSD'


# Generated at 2022-06-20 20:37:54.453215
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virtual_collector = NetBSDVirtualCollector()
    assert virtual_collector.platform == 'NetBSD'


# Generated at 2022-06-20 20:38:06.533161
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    vf = NetBSDVirtual()
    vf._get_sysctl = mock_get_sysctl()
    expected = {'virtualization_role': 'guest', 'virtualization_type': 'xen',
                'virtualization_tech_host': set(['xen']),
                'virtualization_tech_guest': set(['xen'])}
    actual = vf.get_virtual_facts()
    assert expected['virtualization_type'] == actual['virtualization_type']
    assert expected['virtualization_role'] == actual['virtualization_role']
    assert expected['virtualization_tech_host'] == actual['virtualization_tech_host']
    assert expected['virtualization_tech_guest'] == actual['virtualization_tech_guest']



# Generated at 2022-06-20 20:38:08.652113
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.get_virtual_facts()['virtualization_type'] == ''

# Generated at 2022-06-20 20:38:10.345469
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    NetBSDVirtualCollector()

# Generated at 2022-06-20 20:38:17.809106
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # create a klass object
    klass = NetBSDVirtual()

    # create a empty dictionary as return value
    ret = {}

    # create a dictionary as sysctl values
    sysctl_dict = {'machdep.dmi.system-product': '', 'machdep.dmi.system-vendor': '', 'machdep.hypervisor': ''}
    klass.read_sysctl_values = lambda x: sysctl_dict[x]

    # call get_virtual_facts function
    result = klass.get_virtual_facts()

    # check if result is not empty and with the correct keys
    assert bool(result)
    assert sorted(result.keys()) == sorted(ret.keys())



# Generated at 2022-06-20 20:38:20.486731
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual({})
    assert virtual_facts.platform == 'NetBSD'
    assert virtual_facts.get_virtual_facts() == {}

# Generated at 2022-06-20 20:38:29.849444
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual(module=None)
    assert virtual_facts._platform == 'NetBSD'


# Generated at 2022-06-20 20:38:32.885979
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    a = NetBSDVirtual({'ansible_facts': {}})
    assert a.platform == 'NetBSD'
    assert a.sysctl_path == '/sbin/sysctl'


# Generated at 2022-06-20 20:38:38.605364
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.netbsd import NetBSDVirtual
    nv = NetBSDVirtual()
    facts = nv.get_virtual_facts()
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts
    assert 'virtualization_tech_guest' in facts
    assert 'virtualization_tech_host' in facts

# Generated at 2022-06-20 20:38:49.958597
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    """Test get_virtual_facts implementation"""
    # Initialize a NetBSDVirtual object
    netbsd_virtual = NetBSDVirtual()

    # Do nothing if there is no machdep.dmi.system-product in sysctl
    netbsd_virtual.sysctl_all_exists = lambda x: False
    assert 'virtualization_type' not in netbsd_virtual.get_virtual_facts()

    # Do nothing if there is no machdep.dmi.system-vendor in sysctl
    netbsd_virtual.sysctl_all_exists = lambda x: True
    assert 'virtualization_type' not in netbsd_virtual.get_virtual_facts()

    # Do nothing if there is no machdep.hypervisor in sysctl
    netbsd_virtual.sysctl_all_exists = lambda x: False


# Generated at 2022-06-20 20:39:02.584451
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    import os
    import json
    assert os.path.exists("/usr/sbin/sysctl")
    assert os.path.exists("/dev/xencons")

    test_virtual_facts_json = """
        {
            "virtualization_type": "xen",
            "virtualization_role": "guest",
            "virtualization_tech_guest": ["xen"],
            "virtualization_tech_host": ["xen"]
        }
    """

    virtual_facts = {}
    virtual_facts['virtualization_type'] = ''
    virtual_facts['virtualization_role'] = ''
    virtual_facts['virtualization_tech_guest'] = set()
    virtual_facts['virtualization_tech_host'] = set()

    virtual_product_facts = {}

# Generated at 2022-06-20 20:39:10.082564
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts_test = {'virtualization_type': 'hvm',
                          'virtualization_role': 'guest',
                          'virtualization_tech_guest': set(['hvm']),
                          'virtualization_tech_host': set(['xen'])}
    test_virtual = NetBSDVirtual()
    test_virtual.sysctl = lambda x: 'Xen' if x == 'machdep.dmi.system-product' else 'Xen'
    assert virtual_facts_test == test_virtual.get_virtual_facts()

# Generated at 2022-06-20 20:39:13.128696
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    '''Test NetBSDVirtualCollector constructor'''
    virtual_collector = NetBSDVirtualCollector()
    assert virtual_collector is not None
    assert virtual_collector._platform == 'NetBSD'
    assert virtual_collector._fact_class == NetBSDVirtual


# Generated at 2022-06-20 20:39:16.750994
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual_instance = NetBSDVirtual()
    assert netbsd_virtual_instance.platform == 'NetBSD'



# Generated at 2022-06-20 20:39:19.113937
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    test_NetBSDVirtual = NetBSDVirtual()

    assert test_NetBSDVirtual is not None


# Generated at 2022-06-20 20:39:28.286470
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    with open('unit/ansible_collections/ansible/community/plugins/module_utils/facts/virtual/test/unit_test_data/sysctl_machdep.dmi.system-vendor.txt', 'r') as f:
        system_vendor_txt = f.read()
    with open('unit/ansible_collections/ansible/community/plugins/module_utils/facts/virtual/test/unit_test_data/sysctl_machdep.dmi.system-product.txt', 'r') as f:
        system_product_txt = f.read()
    with open('unit/ansible_collections/ansible/community/plugins/module_utils/facts/virtual/test/unit_test_data/sysctl_machdep.hypervisor.txt', 'r') as f:
        hypervisor

# Generated at 2022-06-20 20:39:36.949286
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    # Make sure we can create an instance of NetBSDVirtualCollector
    nv_collector = NetBSDVirtualCollector()
    assert isinstance(nv_collector, NetBSDVirtualCollector)

# Generated at 2022-06-20 20:39:42.608453
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():  # pylint: disable=missing-function-docstring,invalid-name
    module = {}  # pylint: disable=missing-docstring

    virtual = NetBSDVirtual(module)

    if not isinstance(virtual, NetBSDVirtual):
        print("ERROR: Could not create NetBSDVirtual object")

# Generated at 2022-06-20 20:39:43.937223
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    guest = NetBSDVirtualCollector()
    assert guest.platform == 'NetBSD'

# Generated at 2022-06-20 20:39:53.247744
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual(module=None)
    facts = virtual_facts.get_virtual_facts()

    # Check virtualization_type
    assert facts['virtualization_type'] in ['', 'kvm', 'qemu', 'virtualbox']
    # Check virtualization_role
    assert facts['virtualization_role'] in ['guest', 'host', '']
    # Check virtualization_product
    assert facts['virtualization_product'] in ['', 'kvm', 'qemu', 'VMware']
    # Check virtualization_product_version
    assert facts['virtualization_product_version'] in ['', '1', '', '']

# Generated at 2022-06-20 20:40:02.680212
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    testobj = NetBSDVirtual(module=None)
    testobj.sysctl_sysctlbyname = lambda x: 'Intel Inc.'
    testobj.sysctl_sysctlbyname = lambda x: 'VirtualBox'
    facts = testobj.get_virtual_facts()
    assert facts.get('virtualization_type') == 'virtualbox'
    assert facts.get('virtualization_role') == 'guest'
    assert 'virtualbox' in facts.get('virtualization_tech_guest')
    assert 'virtualbox' not in facts.get('virtualization_tech_host')

# Generated at 2022-06-20 20:40:05.791659
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    facts = NetBSDVirtual(module=None).collect()

    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts
    assert 'virtualization_tech_guest' in facts
    assert 'virtualization_tech_host' in facts

# Generated at 2022-06-20 20:40:06.651767
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector._platform == 'NetBSD'

# Generated at 2022-06-20 20:40:15.874319
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    mock_gather_subset = dict(
        all=dict(
            machdep=dict(
                dmi=dict(
                    system_vendor='Google',
                    system_product='Google Compute Engine',
                ),
                hypervisor='mocked_Hypervisor'
            )
        )
    )

    # Unit test for the case where no virtualization hypervisor is found
    def mock_gather_subset_no_virtualization(subset=None):
        mock_subset = dict(all=dict())
        return mock_subset


# Generated at 2022-06-20 20:40:20.088695
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    # constructor
    virtual_facts_collector = NetBSDVirtualCollector()
    # platform
    assert virtual_facts_collector._platform == 'NetBSD'

# Execute unit test
if __name__ == '__main__':
    test_NetBSDVirtualCollector()

# Generated at 2022-06-20 20:40:23.253328
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual({})
    assert virtual.sysctl_file == '/dev/sysmon'
    assert virtual.platform == 'NetBSD'
    assert virtual.sysctrl_virtual_subsystem == 'machdep.hypervisor'
    assert virtual.sysctrl_virtual_vendor == 'machdep.dmi.system-vendor'
    assert virtual.sysctrl_virtual_product == 'machdep.dmi.system-product'

# Generated at 2022-06-20 20:40:41.860225
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    test_virtual = NetBSDVirtual()

    # The definition of sysctl_outputs dictionary is as follows:
    # {
    #     '/path/of/sysctls/file': {
    #         'machdep.dmi.system-product': {
    #             'default': 'KVM',
    #             'sysctl_output': 'KVM'
    #         }
    #     }
    # }

# Generated at 2022-06-20 20:40:43.194567
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual(None)
    assert virtual.platform == 'NetBSD'

# Generated at 2022-06-20 20:40:45.230530
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    facts = NetBSDVirtual().get_virtual_facts()
    assert facts['virtualization_type'] == ''
    assert facts['virtualization_role'] == ''

# Generated at 2022-06-20 20:40:46.325417
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual()
    assert isinstance(virtual_facts, dict)


# Generated at 2022-06-20 20:40:50.684996
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd = NetBSDVirtualCollector()
    assert netbsd._platform == 'NetBSD'
    assert netbsd._fact_class == NetBSDVirtual
    assert netbsd._order == 40

# Generated at 2022-06-20 20:40:54.727790
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virtual_facts = VirtualCollector()
    assert isinstance(virtual_facts, VirtualCollector)


# Generated at 2022-06-20 20:40:56.305839
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual({}).get_virtual_facts()
    assert virtual_facts

# Generated at 2022-06-20 20:41:04.433930
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual(None, {})
    assert virtual_facts

    expected_virtual_facts = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_technologies_guest': '',
        'virtualization_technologies_host': ''
    }
    for key in expected_virtual_facts:
        assert key in virtual_facts.facts
        assert virtual_facts.facts[key] == expected_virtual_facts[key]



# Generated at 2022-06-20 20:41:09.213162
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    v_netbsd = NetBSDVirtual()
    facts = v_netbsd.get_virtual_facts()
    assert facts['virtualization_type'] == 'xen'
    assert facts['virtualization_role'] == 'guest'
    assert facts['virtualization_tech_guest'] == set(['xen'])
    assert facts['virtualization_tech_host'] == set(['xen'])

# Generated at 2022-06-20 20:41:11.176627
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert netbsd_virtual_collector.platform == 'NetBSD'

# Generated at 2022-06-20 20:41:26.737330
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.platform == 'NetBSD'

# Generated at 2022-06-20 20:41:28.853381
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    nv = NetBSDVirtualCollector()

# Generated at 2022-06-20 20:41:40.397538
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    test_virtual_facts = dict(
        virtualization_type='',
        virtualization_role='',
        virtualization_sysctl_host={},
        virtualization_sysctl_guest={},
        virtualization_sysctl_product={},
        virtualization_sysctl_vendor={},
        virtualization_sysctl_sys_vendor={},
        virtualization_sysctl_sys_product={},
        virtualization_sysctl_sys_version={},
        virtualization_sysctl_sys_serial={},
        virtualization_sysctl_sys_uuid={},
        virtualization_sysctl_sys_sku={},
        virtualization_sysctl_sys_family={}
    )

    # Sample output from 'machdep.dmi.system-product' sysctl
    test_sysctl_machdep_

# Generated at 2022-06-20 20:41:42.626308
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_facts_test = NetBSDVirtual()
    assert netbsd_facts_test.platform == 'NetBSD'

# Generated at 2022-06-20 20:41:44.592658
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    m = NetBSDVirtual()
    assert m._platform == 'NetBSD'

# Generated at 2022-06-20 20:41:55.304059
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual()

    # Create a dict of expected keys and empty values
    expected_results = {}
    for key in ['virtualization_type', 'virtualization_role', 'virtualization_system', 'virtualization_hypervisor', 'virtualization_host', 'virtualization_guest']:
        expected_results[key] = ''

    # The sysctl command outputs keys as a line of text
    # each seperated with a colon (:)
    sysctl_keys = 'machdep.dmi.system-product:machdep.dmi.system-vendor:machdep.hypervisor'

    # Set sysctl_commands to return a list of keys; each key is a line with a colon (:)
    # and a newline character (\n).
    virtual_facts.sysctl_commands = mock

# Generated at 2022-06-20 20:41:57.736663
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virt_facts_obj = NetBSDVirtual()
    assert virt_facts_obj.platform == "NetBSD"


# Generated at 2022-06-20 20:42:03.036025
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    """ Test the constructor of class NetBSDVirtualCollector.

    This is a very minor test, added just to ensure the test infrastructure
    is working properly.
    """
    collector = NetBSDVirtualCollector()
    assert collector is not None
    assert isinstance(collector, VirtualCollector)


# Generated at 2022-06-20 20:42:06.484519
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual(None, None)
    assert netbsd_virtual
    assert netbsd_virtual.platform == 'NetBSD'
    assert netbsd_virtual._platform == 'NetBSD'

# Generated at 2022-06-20 20:42:08.897101
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual()
    assert virtual.platform == 'NetBSD'



# Generated at 2022-06-20 20:42:42.479795
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # This is just a stub for now, this needs further work.
    f = NetBSDVirtual()
    facts = f.get_virtual_facts()
    assert facts['virtualization_type'] == ''

# Generated at 2022-06-20 20:42:43.249865
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    NetBSDVirtualCollector()

# Generated at 2022-06-20 20:42:44.019454
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    NetBSDVirtualCollector()

# Generated at 2022-06-20 20:42:54.212993
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    # test initialization
    netbsdvirtual = NetBSDVirtual()

    facts = {'machdep.dmi.system-product': 'vbox', 'machdep.dmi.system-vendor': 'innotek GmbH', 'machdep.hypervisor': 'vbox'}
    expected_virtual_facts = {'virtualization_type': 'VirtualBox', 'virtualization_role': 'guest',
                              'virtualization_tech_guest': set(), 'virtualization_tech_host': {'virtualbox'},
                              'virtualization_guest_type': 'VirtualBox'}

    virtual_facts = netbsdvirtual.get_virtual_facts(facts)

    assert virtual_facts == expected_virtual_facts

# Generated at 2022-06-20 20:42:56.134169
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    facts = NetBSDVirtual().get_virtual_facts()
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts
    assert 'virtualization_tech_guest' in facts
    assert 'virtualization_tech_host' in facts

# Generated at 2022-06-20 20:42:57.336126
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual()
    assert virtual_facts.platform == 'NetBSD'

# Generated at 2022-06-20 20:43:00.959495
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual({},{},{},{})
    assert virtual.platform == 'NetBSD'


# Generated at 2022-06-20 20:43:03.309787
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector._platform == "NetBSD"
    assert NetBSDVirtualCollector._fact_class == NetBSDVirtual


# Generated at 2022-06-20 20:43:05.730845
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual({})
    assert netbsd_virtual is not None

# Generated at 2022-06-20 20:43:06.614075
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    NetBSDVirtualCollector()

# Generated at 2022-06-20 20:44:15.344677
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual_obj = NetBSDVirtual()
    assert netbsd_virtual_obj.platform == 'NetBSD'

# Test for virtual facts of NetBSDVirtual

# Generated at 2022-06-20 20:44:17.444467
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_facts = NetBSDVirtualCollector()
    assert netbsd_facts._fact_class == NetBSDVirtual
    assert netbsd_facts._platform == 'NetBSD'

# Generated at 2022-06-20 20:44:18.352449
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    NetBSDVirtualCollector()

# Generated at 2022-06-20 20:44:19.902710
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    NetBSDVirtualCollector()

# Generated at 2022-06-20 20:44:23.067028
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    test = NetBSDVirtual({})
    host_tech = set()
    guest_tech = set()
    virtual_facts = {}

    virtual_facts = test.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''

    assert virtual_facts['virtualization_tech_guest'] == guest_tech
    assert virtual_facts['virtualization_tech_host'] == host_tech

# Generated at 2022-06-20 20:44:25.909185
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert netbsd_virtual_collector._fact_class == NetBSDVirtual

# Generated at 2022-06-20 20:44:36.612900
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # We need to create a subclass because VirtualSysctlDetectionMixin methods
    # must be classmethods.
    class TestVirtual(VirtualSysctlDetectionMixin, NetBSDVirtual):
        pass

    facts = TestVirtual().get_virtual_facts()
    assert facts['virtualization_type'] == ''
    assert facts['virtualization_role'] == ''

    machdep = {
        'machdep.dmi.system-product': 'VirtualBox',
        'machdep.dmi.system-vendor': 'innotek GmbH',
        'machdep.hypervisor': 'innotek GmbH',
        'machdep.hypervisor.version': '1.2.3',
    }

# Generated at 2022-06-20 20:44:39.918608
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    NetBSDVirtual.collect()
    assert NetBSDVirtual.get_virtual_facts()['virtualization_tech_guest'] == set()



# Generated at 2022-06-20 20:44:44.940349
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    """Check if NetBSDVirtualCollector class has been defined with given parameters."""
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert netbsd_virtual_collector._fact_class is NetBSDVirtual
    assert netbsd_virtual_collector._platform is 'NetBSD'

# Generated at 2022-06-20 20:44:45.709992
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    # Test with valid class
    NetBSDVirtualCollector()

# Generated at 2022-06-20 20:47:30.334704
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    thisNetBSDVirtual = NetBSDVirtual('Sysctl')
    assert thisNetBSDVirtual.platform == 'NetBSD'

# Generated at 2022-06-20 20:47:40.867201
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Declare a NetBSDVirtual object
    netbsd_virtual_obj = NetBSDVirtual()

    # Mock dmi_data() method