

# Generated at 2022-06-23 02:24:10.245732
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    NetBSDVirtualCollector()

# Generated at 2022-06-23 02:24:12.810410
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    """ Returns NetBSDVirtualCollector object with given parameters.
    """
    collector_obj = NetBSDVirtualCollector()
    return collector_obj


# Generated at 2022-06-23 02:24:17.072928
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    '''Answer the question:
    Is the constructor of the NetBSDVirtualCollector class really the
    NetBSDVirtualCollector class?
    '''
    assert NetBSDVirtualCollector.__name__ == 'NetBSDVirtualCollector'


# Generated at 2022-06-23 02:24:23.976419
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual()
    # Asserting the virtualization_type
    assert 'virtualization_type' in virtual_facts.data
    # Asserting the virtualization_role
    assert 'virtualization_role' in virtual_facts.data
    # Asserting the virtualization_tech_guest
    assert 'virtualization_tech_guest' in virtual_facts.data
    # Asserting the virtualization_tech_host
    assert 'virtualization_tech_host' in virtual_facts.data

# Generated at 2022-06-23 02:24:33.773900
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.netbsd import NetBSDVirtual
    from ansible.module_utils.facts.virtual.sysctl import Sysctl
    from ansible.module_utils.facts.virtual.sysctl import SysctlParser

    sysctl = Sysctl()
    sysctl.add_sysctl(SysctlParser('machdep.dmi.system-product', 'KVM'))
    sysctl.add_sysctl(SysctlParser('machdep.dmi.system-vendor', '0x1af4'))

    netbsd_virtual = NetBSDVirtual(sysctl)
    virtual_facts = netbsd_virtual.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == 'kvm'

# Generated at 2022-06-23 02:24:35.937592
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    facts = NetBSDVirtualCollector()
    assert facts.platform == 'NetBSD'
    assert isinstance(facts._fact_class, NetBSDVirtual)

# Generated at 2022-06-23 02:24:38.972236
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual("/proc")
    assert netbsd_virtual.platform == 'NetBSD'
    assert netbsd_virtual.subplatform is None
    assert netbsd_virtual.facts == {}


# Generated at 2022-06-23 02:24:46.887075
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd = NetBSDVirtual()
    facts = dict()

    netbsd.set_mock_facts(facts)

    netbsd.get_virtual_facts()

    assert facts['virtualization_type'] == ''
    assert facts['virtualization_role'] == ''
    assert facts['virtualization_tech_guest'] == set()
    assert facts['virtualization_tech_host'] == set()

# Test method get_virtual_facts if machdep.hypervisor is set on NetBSD
# guest

# Generated at 2022-06-23 02:24:49.508958
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
   c = NetBSDVirtualCollector()
   assert c.platform == 'NetBSD'
   assert c._fact_class == NetBSDVirtual


# Generated at 2022-06-23 02:24:56.030685
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Create instance of NetBSDVirtual
    netbsd_virtual = NetBSDVirtual()
    # Run get_virtual_facts
    netbsd_virtual.collect()
    # Verify there is a key 'virtual_facts' in ansible_facts
    assert('virtual_facts' in netbsd_virtual.facts)
    # Verify the key 'virtual_facts' has the class attributes
    assert(netbsd_virtual.facts['virtual_facts'] == netbsd_virtual.get_virtual_facts())

# Generated at 2022-06-23 02:25:01.890120
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual = NetBSDVirtual()
    ret = virtual.get_virtual_facts()
    assert 'virtualization_tech_guest' in ret
    assert 'virtualization_tech_host' in ret
    assert 'virtualization_role' in ret
    assert 'virtualization_type' in ret
    assert ret['virtualization_role'] in ['guest', 'host', 'guest:host']
    assert ret['virtualization_type'] in ['xen', 'kvm', 'virtualbox', 'vmware', '']

# Generated at 2022-06-23 02:25:04.637360
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
     nb_collector = NetBSDVirtualCollector()
     assert nb_collector._platform == 'NetBSD'


# Generated at 2022-06-23 02:25:06.826498
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virtual_collector = NetBSDVirtualCollector()
    assert virtual_collector.platform == 'NetBSD'
    assert virtual_collector._fact_class == NetBSDVirtual

# Generated at 2022-06-23 02:25:10.520284
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    nvsys = NetBSDVirtualCollector()
    nvsys.collect()
    nvsys.populate()
    assert nvsys.data["ansible_virtual"] == True

# Generated at 2022-06-23 02:25:20.179580
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    def fake_file_read(path):
        assert(path == "/proc/sysctl/machdep.dmi.system-product")
        return "VMWare Virtual Platform"

    def fake_hg_read(path):
        assert(path == "/dev/xencons")
        return "open file failed"

    class FakeModule():
        def fail_json(self, *args, **kwargs):
            pass

    fake_module = FakeModule()
    files = dict()
    file_read_orig = NetBSDVirtualCollector._file_read
    hg_read_orig = NetBSDVirtualCollector._hg_read
    files_orig = NetBSDVirtualCollector.files

    NetBSDVirtualCollector.files = files
    NetBSDVirtualCollector._file_read = fake_file_read
    NetBSDVirtualCollect

# Generated at 2022-06-23 02:25:21.745527
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_facts = NetBSDVirtual()
    assert type(netbsd_facts.get_virtual_facts()) is dict

# Generated at 2022-06-23 02:25:28.879289
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():

    # Test OpenVZ
    (out, err) = module.run_command("sysctl -n machdep.dmi.system-vendor && sysctl -n machdep.hypervisor", use_unsafe_shell=True)
    module.sysctl['machdep.dmi.system-vendor'] = out.strip()
    module.sysctl['machdep.hypervisor'] = out.strip()
    assert NetBSDVirtual(module).get_virtual_facts() == {
        'virtualization_role': 'guest',
        'virtualization_type': 'OpenVZ',
        'virtualization_tech_guest': {'OpenVZ'},
        'virtualization_tech': 'OpenVZ',
        'virtualization_tech_host': {'OpenVZ'}
    }

    # Test KVM

# Generated at 2022-06-23 02:25:30.852450
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector(None)._platform == 'NetBSD'


# Generated at 2022-06-23 02:25:41.273880
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd = NetBSDVirtual()

    assert netbsd.platform == "NetBSD"
    assert netbsd.is_linux() == True
    assert netbsd.is_netbsd() == True
    assert netbsd.is_nxos() == False
    assert netbsd.is_openbsd() == False
    assert netbsd.is_openwrt() == False
    assert netbsd.is_freebsd() == False
    assert netbsd.get_distribution() is None
    assert netbsd.get_system() is None

    # Test when no 'sysctl' command is present
    netbsd._find_cmd = lambda x: None
    assert netbsd.is_linux() == True
    assert netbsd.is_netbsd() == True

# Generated at 2022-06-23 02:25:48.567691
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():

    # Create an object of class NetBSDVirtual
    netbsdvirtual = NetBSDVirtual()

    # Mock the following method of class NetBSDVirtual
    netbsdvirtual.get_sysctl_virtual_facts = fake_get_sysctl_virtual_facts

    # Execute method get_virtual_facts of class NetBSDVirtual
    virtual_facts = netbsdvirtual.get_virtual_facts()

    # Assert the result of method get_virtual_facts of class NetBSDVirtual
    assert virtual_facts['virtualization_type'] == 'vbox'
    assert virtual_facts['virtualization_role'] == 'guest'



# Generated at 2022-06-23 02:25:50.781301
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd = NetBSDVirtual()
    assert netbsd.platform == 'NetBSD'


# Generated at 2022-06-23 02:25:52.985926
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    n=NetBSDVirtualCollector()
    assert n._platform == 'NetBSD'
    assert n._fact_class == NetBSDVirtual

# Generated at 2022-06-23 02:25:54.750577
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert (NetBSDVirtualCollector.platform == 'NetBSD')
    c = NetBSDVirtualCollector()


# Generated at 2022-06-23 02:26:00.586832
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts_helper = NetBSDVirtual()
    virtual_facts = virtual_facts_helper.get_virtual_facts()

    assert isinstance(virtual_facts, dict)
    assert virtual_facts['virtualization_type'] == 'virtualbox-ose'
    assert virtual_facts['virtualization_role'] == 'guest'

# Generated at 2022-06-23 02:26:01.635108
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    NetBSDVirtualCollector()

# Generated at 2022-06-23 02:26:03.336997
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.get_virtual_facts() == {}

# Generated at 2022-06-23 02:26:03.922176
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    NetBSDVirtual()

# Generated at 2022-06-23 02:26:06.580457
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual({}, {'ansible_system': 'NetBSD'})
    assert netbsd_virtual.platform == 'NetBSD'

# Generated at 2022-06-23 02:26:13.492745
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd = NetBSDVirtual({}, {})
    assert netbsd.platform == 'NetBSD'
    assert netbsd.guest_detect_filename == 'machdep.dmi.system-product'
    assert netbsd.hypervisor_detect_filename == 'machdep.dmi.system-vendor'
    assert netbsd.guest_detect_exists == False
    assert netbsd.hypervisor_detect_exists == False


# Generated at 2022-06-23 02:26:24.008369
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Create an instance of the object
    netbsd_virtual = NetBSDVirtual()
    # Return None if the file with the virtualization information doesn't exist
    if not os.path.exists('/dev/xencons'):
        assert netbsd_virtual.get_virtual_facts() == {
            'virtualization_type': '', 'virtualization_role': '',
            'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}
    # Return the values of the virtualization_type and virtualization_role
    # attributes

# Generated at 2022-06-23 02:26:27.207912
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virtual_collector = NetBSDVirtualCollector()
    assert virtual_collector.platform == 'NetBSD'
    assert virtual_collector._fact_class == NetBSDVirtual

# Unit test methods of class NetBSDVirtual

# Generated at 2022-06-23 02:26:30.368432
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual = NetBSDVirtualCollector()
    assert netbsd_virtual.platform == 'NetBSD'
    assert netbsd_virtual._fact_class == NetBSDVirtual

# Generated at 2022-06-23 02:26:39.816238
# Unit test for method get_virtual_facts of class NetBSDVirtual

# Generated at 2022-06-23 02:26:43.601066
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # instantiate class
    netbsd_virtual = NetBSDVirtual()
    # get_virtual_facts method returns dict
    assert isinstance(netbsd_virtual.get_virtual_facts(), dict)


# Generated at 2022-06-23 02:26:46.092767
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    v = NetBSDVirtual()
    assert v.get_virtual_facts()['virtualization_type'] == ''
    assert v.get_virtual_facts()['virtualization_role'] == ''

# Generated at 2022-06-23 02:26:48.236827
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virt = NetBSDVirtual()
    assert netbsd_virt._platform == "NetBSD"


# Generated at 2022-06-23 02:26:58.414620
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    detectobj = NetBSDVirtual(None)

    # Test virtualization_type is correctly detected
    if os.environ.get('ANSIBLE_NETBSD_VIRTUALIZATION_TYPE'):
        detectobj.facts['machdep.dmi.system-product'] = os.environ.get('ANSIBLE_NETBSD_VIRTUALIZATION_TYPE')
        detectobj.facts['machdep.dmi.system-vendor'] = os.environ.get('ANSIBLE_NETBSD_VIRTUALIZATION_TYPE')
        detectobj.facts['machdep.hypervisor'] = os.environ.get('ANSIBLE_NETBSD_VIRTUALIZATION_TYPE')
    else:
        detectobj.facts['machdep.dmi.system-product'] = ''

# Generated at 2022-06-23 02:26:59.947162
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd = NetBSDVirtual({'module_setup': True})
    assert netbsd is not None


# Generated at 2022-06-23 02:27:04.287857
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual = NetBSDVirtual()
    facts = netbsd_virtual.get_virtual_facts()
    assert facts['virtualization_type'] == ''
    assert facts['virtualization_role'] == ''
    assert facts['virtualization_technologies_guest'] == set()
    assert facts['virtualization_technologies_host'] == set()

if __name__ == '__main__':
    test_NetBSDVirtual_get_virtual_facts()

# Generated at 2022-06-23 02:27:07.336672
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts_dict = NetBSDVirtual().get_virtual_facts()
    assert virtual_facts_dict['virtualization_type'] == ''

# Generated at 2022-06-23 02:27:11.023532
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd = NetBSDVirtual(module=None, facts={}, params={})
    assert netbsd.platform == 'NetBSD'
    assert not netbsd.is_linux()
    assert netbsd.get_virtual_facts()


# Generated at 2022-06-23 02:27:13.246301
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    fact = NetBSDVirtualCollector()

    assert fact._platform == 'NetBSD'
    assert fact._fact_class == NetBSDVirtual


# Generated at 2022-06-23 02:27:15.797636
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    # Constructor of NetBSDVirtualCollector should assign _platform as 'NetBSD'
    obj = NetBSDVirtualCollector()
    assert obj._platform == 'NetBSD'


# Generated at 2022-06-23 02:27:19.191324
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    # Arrange
    # Act
    virtual_collector = NetBSDVirtualCollector()
    # Assert
    assert virtual_collector._fact_class == NetBSDVirtual
    assert virtual_collector._platform == 'NetBSD'

# Generated at 2022-06-23 02:27:23.906752
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virt = NetBSDVirtual()
    facts = virt.get_virtual_facts()
    assert facts['virtualization_type'] == 'xen'
    assert facts['virtualization_role'] == 'guest'
    assert facts['virtualization_tech_guest'] == set(['xen'])
    assert facts['virtualization_tech_host'] == set(['xen'])

# Generated at 2022-06-23 02:27:33.599290
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    mock_open = mock_open(read_data='Some data')
    fake_path = '/sys/devices/virtual/dmi/id/'
    fake_file = 'machdep.dmi.system-product'
    fake_open_name = 'ansible.module_utils.facts.virtual.netbsd.open'

    mock_os_exists = mock.MagicMock(return_value=True)
    mock_os_path_exists_name = 'ansible.module_utils.facts.virtual.netbsd.os.path.exists'

    with mock.patch(mock_open_name, mock_open, create=True):
        with mock.patch(mock_os_path_exists_name, mock_os_exists):
            test_obj = NetBSDVirtual()
            output = test

# Generated at 2022-06-23 02:27:36.408847
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual({}, {}, {}).get_virtual_facts()
    assert isinstance(virtual_facts, dict)

# Generated at 2022-06-23 02:27:47.214473
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():

    class TestSysctlResult(object):
        def __init__(self, k, v):
            self.k = k
            self.v = v

        def get(self, k):
            return self.v

        def __repr__(self):
            return '{0} = {1}'.format(self.k, self.v)


# Generated at 2022-06-23 02:27:49.343042
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual = NetBSDVirtualCollector()
    assert netbsd_virtual.platform == 'NetBSD'

# Generated at 2022-06-23 02:27:51.817011
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual()
    assert virtual_facts._platform == "NetBSD"


# Generated at 2022-06-23 02:28:01.344895
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Initializing test objects
    testobj = NetBSDVirtual()

    hypervisor = testobj.get_sysctl('machdep.hypervisor')

    machdep_dmi_system_vendor = testobj.get_sysctl('machdep.dmi.system-vendor')
    machdep_dmi_system_product = testobj.get_sysctl('machdep.dmi.system-product')

    # Test cases
    # Case 1: with machdep.hypervisor as 'none'
    testobj.set_sysctl('machdep.hypervisor', 'none')
    testobj.set_sysctl('machdep.dmi.system-vendor', 'none')
    testobj.set_sysctl('machdep.dmi.system-product', 'none')

    result = testobj.get_virtual

# Generated at 2022-06-23 02:28:03.322204
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual().get_virtual_facts()
    assert 'virtualization_type' in virtual_facts

# Generated at 2022-06-23 02:28:14.702573
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    # Pass empty argument
    netbsd_virtual = NetBSDVirtual(set())

    # Set argument with sysctl data under the key 'machdep.dmi.system-product',
    # which is the key used when calling get_virtual_facts method.
    netbsd_virtual_fact = NetBSDVirtualCollector()
    netbsd_virtual_fact._sysctl_info = dict()
    netbsd_virtual_fact._sysctl_info['machdep.dmi.system-product'] = 'To Be Defined'
    netbsd_virtual_fact._sysctl_info['machdep.dmi.system-vendor'] = 'Microsoft Corporation'
    netbsd_virtual_fact._sysctl_info['machdep.hypervisor'] = 'Hyper-V'

    # Call get_virtual_facts method to test if

# Generated at 2022-06-23 02:28:15.717292
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector._platform == 'NetBSD'


# Generated at 2022-06-23 02:28:21.613471
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    vc = NetBSDVirtualCollector()

    assert vc._platform == 'NetBSD'
    assert vc._fact_class.__name__ == 'NetBSDVirtual'
    assert vc._fact_class.platform == 'NetBSD'
    assert issubclass(vc._fact_class, Virtual)


# Generated at 2022-06-23 02:28:24.778007
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virtual_collector_ref = NetBSDVirtualCollector()
    assert virtual_collector_ref._fact_class is not None
    assert virtual_collector_ref._platform is not None
    assert virtual_collector_ref.platform == 'NetBSD'


# Generated at 2022-06-23 02:28:26.189516
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual()
    assert virtual.platform == 'NetBSD'

# Generated at 2022-06-23 02:28:29.205962
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    try:
        netbsd = NetBSDVirtualCollector()
        assert netbsd is not None
    except Exception:
        assert 1

# Generated at 2022-06-23 02:28:31.976601
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual(file_exists=lambda x: True)
    assert virtual_facts.get_virtual_facts()['virtualization_type'] == 'kvm'

# Generated at 2022-06-23 02:28:34.376614
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    facts = NetBSDVirtual()
    assert facts._platform == 'NetBSD'
    assert facts._fact_class == NetBSDVirtual


# Generated at 2022-06-23 02:28:36.145824
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.platform == 'NetBSD'

# Generated at 2022-06-23 02:28:38.124021
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    obj = NetBSDVirtual("/usr/bin/sysctl")
    assert obj.platform == "NetBSD"


# Generated at 2022-06-23 02:28:39.639158
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd = NetBSDVirtual()
    assert netbsd.platform == 'NetBSD'


# Generated at 2022-06-23 02:28:50.438764
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Set expected output
    expected = {
        'virtualization_type': 'kvm',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': {'kvm', 'hypervisor'},
        'virtualization_tech_host': {'kvm'},
        'virtualization_system': 'kvm'
    }
    # Create a NetBSDVirtual object
    netbsd_virtual = NetBSDVirtual()

    # Overwrite the sysctl function from netbsd_virtual to return a dict with
    # kvm as the hypervisor value.
    def sysctl(self, *args):
        if args[0] == 'machdep.hypervisor':
            return {'machdep': {'hypervisor': 'kvm'}}
        else:
            return {}
    netbsd_virtual

# Generated at 2022-06-23 02:29:02.441675
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Test case when machdep.dmi.system-vendor is set to 'QEMU' and
    # machdep.dmi.system-product is set to 'Standard PC (Q35 + ICH9, 2009)'
    def test_qemu_q35_ich9():
        netbsd_virtual = NetBSDVirtual()
        netbsd_virtual.sysctl = {'machdep.dmi.system-vendor': 'QEMU',
                                 'machdep.dmi.system-product': 'Standard PC (Q35 + ICH9, 2009)'}
        virtual_facts = netbsd_virtual.get_virtual_facts()
        assert virtual_facts['virtualization_type'] == 'kvm'
        assert virtual_facts['virtualization_role'] == 'guest'
        assert 'kvm' in virtual

# Generated at 2022-06-23 02:29:04.238396
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()

    assert netbsd_virtual_collector is not None

# Generated at 2022-06-23 02:29:08.643061
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    with open(os.devnull, 'w') as fp:
        virtual_facts = NetBSDVirtualCollector(fp=fp).collect()
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert 'xen' in virtual_facts['virtualization_tech_guest']

# Generated at 2022-06-23 02:29:10.633792
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual()
    assert virtual.platform == 'NetBSD'

# Generated at 2022-06-23 02:29:12.638199
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virtual = NetBSDVirtualCollector()
    assert virtual._platform == 'NetBSD'


# Generated at 2022-06-23 02:29:16.048191
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual = NetBSDVirtual(module=None)
    virtual_facts = virtual.get_virtual_facts()
    asserttype(virtual_facts) == {dict: 'virtualization_tech_guest', dict: 'virtualization_tech_host', str: 'virtualization_type', str: 'virtualization_role'}

# Generated at 2022-06-23 02:29:17.523069
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.platform == 'NetBSD'


# Generated at 2022-06-23 02:29:19.709946
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    vc = NetBSDVirtualCollector()
    assert isinstance(vc._fact_class, NetBSDVirtual)
    assert vc._platform == 'NetBSD'

# Generated at 2022-06-23 02:29:22.433005
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual({}, {}, '')
    assert virtual
    assert virtual.get_virtual_facts() is not None

# Generated at 2022-06-23 02:29:29.425402
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()

    assert netbsd_virtual._platform == 'NetBSD'
    assert netbsd_virtual.platform == 'NetBSD'

    assert netbsd_virtual._fact_class == NetBSDVirtual
    assert netbsd_virtual.get_virtual_facts() == netbsd_virtual.virtual_facts


# Generated at 2022-06-23 02:29:30.638930
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector.__dict__['_platform'] == 'NetBSD'

# Generated at 2022-06-23 02:29:34.053694
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    vc = NetBSDVirtualCollector()
    assert vc._platform == 'NetBSD'
    assert vc._fact_class.platform == 'NetBSD'


# Generated at 2022-06-23 02:29:35.541418
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    x = NetBSDVirtualCollector()
    assert isinstance(x, NetBSDVirtualCollector)


# Generated at 2022-06-23 02:29:42.788793
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():

    # Instantiate NetBSDVirtual object and set the values expected by the
    # test.
    virtual_obj = NetBSDVirtual()

    # Set class attributes using the values expected by the test.
    virtual_obj.sysctl = {
        'machdep.dmi.system-product': 'foo-product',
        'machdep.dmi.system-vendor': 'foo-vendor',
        'machdep.hypervisor': 'foo-hypervisor'
    }

    # Call get_virtual_facts of class NetBSDVirtual.
    virtual_facts = virtual_obj.get_virtual_facts()

    # set the expected output for calling get_virtual_facts of class
    # NetBSDVirtual.

# Generated at 2022-06-23 02:29:45.261867
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual()
    assert virtual_facts.platform == 'NetBSD'


# Generated at 2022-06-23 02:29:47.730591
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector._platform == 'NetBSD'
    assert NetBSDVirtualCollector._fact_class == NetBSDVirtual


# Generated at 2022-06-23 02:29:52.086774
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virt = NetBSDVirtual()
    assert virt.platform == 'NetBSD'


# Generated at 2022-06-23 02:29:55.513328
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    instance = NetBSDVirtual()
    assert isinstance(instance, NetBSDVirtual)
    assert isinstance(instance, Virtual)
    assert isinstance(instance, VirtualCollector)

# Generated at 2022-06-23 02:30:00.138045
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd = NetBSDVirtual()
    assert repr(netbsd) == '<NetBSDVirtual object at ' + hex(id(netbsd)) + '>'


# Generated at 2022-06-23 02:30:03.959715
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    from ansible.module_utils.facts.virtual.sysctl import SubKeyDict
    netbsd_virtual = NetBSDVirtual(SubKeyDict())

    assert netbsd_virtual.platform == 'NetBSD'

# Generated at 2022-06-23 02:30:07.225813
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    """Unit test: constructor of NetBSDVirtualCollector"""
    netbsd = NetBSDVirtual()
    assert netbsd.platform == 'NetBSD'

# Generated at 2022-06-23 02:30:10.685078
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual(module=None)
    assert netbsd_virtual.platform == 'NetBSD'
    assert netbsd_virtual.sysctl_cmd == 'sysctl -b'


# Generated at 2022-06-23 02:30:17.445518
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual = NetBSDVirtualCollector()
    # Check if machdep.hypervisor.vendor was added to sysctl_virtualization_facts
    assert 'machdep.hypervisor.vendor' in netbsd_virtual.sysctl_virtualization_facts

# Generated at 2022-06-23 02:30:22.158208
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual().get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-23 02:30:23.791895
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    facts = NetBSDVirtualCollector()
    assert facts._platform == 'NetBSD'
    assert facts._fact_class == NetBSDVirtual

# Generated at 2022-06-23 02:30:27.693202
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virtual_collector = NetBSDVirtualCollector()
    assert virtual_collector._fact_class == NetBSDVirtual
    assert virtual_collector._platform == 'NetBSD'


# Generated at 2022-06-23 02:30:33.615793
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    expected_results = dict()
    expected_results['virtualization_type'] = ''
    expected_results['virtualization_role'] = ''
    expected_results['virtualization_tech_guest'] = set()
    expected_results['virtualization_tech_host'] = set()
    actual_results = dict()
    NetBSDVirtualCollector_obj = NetBSDVirtualCollector()
    actual_results = NetBSDVirtualCollector_obj.collect()
    assert actual_results == expected_results

# Generated at 2022-06-23 02:30:34.571473
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    NetBSDVirtualCollector()

# Generated at 2022-06-23 02:30:42.648238
# Unit test for method get_virtual_facts of class NetBSDVirtual

# Generated at 2022-06-23 02:30:45.980888
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    if netbsd_virtual_collector._platform != 'NetBSD':
        print("Expected platform NetBSD, but got %s" % (netbsd_virtual_collector._platform))
        return False
    return True


# Generated at 2022-06-23 02:30:58.072808
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsdvirtual = NetBSDVirtual()

    # Fact 'virtualization_type' should be initialized with empty string
    assert netbsdvirtual.data['virtualization_type'] == ''

    # Fact 'virtualization_role' should be initialized with empty string
    assert netbsdvirtual.data['virtualization_role'] == ''

    # Fact 'virtualization_sysctl_facts' should be initialized with empty list
    assert netbsdvirtual.data['virtualization_sysctl_facts'] == []

    # Fact 'virtualization_tech_guest' should be initialized with empty set
    assert netbsdvirtual.data['virtualization_tech_guest'] == set()

    # Fact 'virtualization_tech_host' should be initialized with empty set
    assert netbsdvirtual.data['virtualization_tech_host'] == set()

# Generated at 2022-06-23 02:30:59.499293
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    assert NetBSDVirtual({}) is not None


# Generated at 2022-06-23 02:31:02.684639
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    v = NetBSDVirtual()
    assert isinstance(v, Virtual)
    assert v.platform == 'NetBSD'
    assert v.get_virtual_facts() == {}

# Generated at 2022-06-23 02:31:05.136731
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    obj = NetBSDVirtualCollector()
    assert obj.platform == 'NetBSD'
    assert obj.fact == NetBSDVirtual


# Generated at 2022-06-23 02:31:08.973735
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual(module=None)
    assert isinstance(netbsd_virtual, NetBSDVirtual)
    assert isinstance(netbsd_virtual, VirtualSysctlDetectionMixin)
    assert isinstance(netbsd_virtual, Virtual)


# Generated at 2022-06-23 02:31:10.848402
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual()
    assert virtual.platform == 'NetBSD'

# Generated at 2022-06-23 02:31:15.129952
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    # The below values are chosen to represent the minimum
    # values for the platform. Tests may need to be updated
    # if/when minimum values are lowered
    assert NetBSDVirtualCollector.platform_minimum_version('3.0')
    assert NetBSDVirtualCollector.platform_minimum_version('3.2')

# Generated at 2022-06-23 02:31:16.383745
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd = NetBSDVirtual()
    assert netbsd.platform == 'NetBSD'

# Generated at 2022-06-23 02:31:23.591377
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    facts = {}
    with open('/usr/src/sys/arch/amd64/conf/GENERIC', 'r') as fp:
        for line in fp:
            if line.startswith('include'):
                path = line.split()[-1]
                with open(path, 'r') as fp2:
                    for line in fp2:
                        if line.startswith('#define'):
                            name, value = line.split()[1:3]
                            facts['machdep.' + name] = value
    v = NetBSDVirtual(module=None, facts=facts)
    result = v.get_virtual_facts()
    assert result['virtualization_type'] == 'kvm'

# Generated at 2022-06-23 02:31:26.113235
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual()
    assert virtual_facts._platform == "NetBSD"


# Generated at 2022-06-23 02:31:28.858289
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    collector = NetBSDVirtualCollector()
    assert hasattr(collector, '_fact_class')
    assert hasattr(collector, '_platform')

# Generated at 2022-06-23 02:31:31.058116
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    """Stub for Testcase in VirtualCollector class."""
    obj = NetBSDVirtual()
    assert obj.platform == 'NetBSD'


# Generated at 2022-06-23 02:31:34.369865
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual._platform == 'NetBSD'

# Generated at 2022-06-23 02:31:41.906118
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    facts = NetBSDVirtual({})
    assert ('virtualization_type' in facts.data)
    assert ('virtualization_role' in facts.data)
    assert ('virtualization_tech_guest' in facts.data)
    assert ('virtualization_tech_host' in facts.data)
    assert (facts.data['virtualization_type'] in
            ['virtualbox', 'hyperv', 'kvm', 'vmware', 'xen', ''])
    assert (facts.data['virtualization_role'] in ['guest', 'host', ''])
    assert (type(facts.data['virtualization_tech_guest']) == set)
    assert (type(facts.data['virtualization_tech_host']) == set)


# Generated at 2022-06-23 02:31:46.585851
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert netbsd_virtual_collector.platform == 'NetBSD'
    assert netbsd_virtual_collector._fact_class._platform == 'NetBSD'
    assert netbsd_virtual_collector._fact_class._fact_class.platform == 'NetBSD'


# Generated at 2022-06-23 02:31:48.471793
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.platform == 'NetBSD'

# Generated at 2022-06-23 02:31:55.032957
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual_obj = NetBSDVirtual()
    facts = netbsd_virtual_obj.get_virtual_facts()

    assert facts is not None
    assert 'virtualization_type' in facts.keys()
    assert 'virtualization_role' in facts.keys()
    assert 'virtualization_tech_guest' in facts.keys()
    assert 'virtualization_tech_host' in facts.keys()

# Generated at 2022-06-23 02:32:00.819090
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    collector = NetBSDVirtualCollector()
    assert collector.platform == 'NetBSD'
    assert collector.fact_class == NetBSDVirtual
    assert collector.definitions == [
        'machdep.dmi.system-product',
        'machdep.dmi.system-vendor',
        'machdep.hypervisor',
    ]

# Generated at 2022-06-23 02:32:09.946082
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Create a test instance of NetBSDVirtual class
    test_instance = NetBSDVirtual()

    # Test: Define test data
    test_data = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': set(),
        'virtualization_product_name': '',
        'virtualization_product_version': '',
        'virtualization_product_vendor': ''
    }

    test_result = test_instance.get_virtual_facts()

    assert test_data == test_result


# Generated at 2022-06-23 02:32:15.391242
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = {}
    virtual_facts['virtualization_type'] = 'xen'
    virtual_facts['virtualization_role'] = 'guest'
    virtual_facts['virtualization_technologies_guest'] = set(['xen'])
    virtual_facts['virtualization_technologies_host'] = set(['xen'])

    virtual = NetBSDVirtual()
    assert virtual.get_virtual_facts() == virtual_facts

# Generated at 2022-06-23 02:32:18.530992
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_collector = NetBSDVirtualCollector()
    assert netbsd_collector._fact_class is not None
    assert netbsd_collector._platform == 'NetBSD'

# Generated at 2022-06-23 02:32:23.731384
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert netbsd_virtual_collector is not None
    assert netbsd_virtual_collector._platform == 'NetBSD'
    assert netbsd_virtual_collector._fact_class == NetBSDVirtual

# Generated at 2022-06-23 02:32:25.562796
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_netbsd = NetBSDVirtual()
    assert virtual_netbsd.platform == 'NetBSD'

# Generated at 2022-06-23 02:32:31.125138
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual = NetBSDVirtual()
    netbsd_virtual_facts = netbsd_virtual.get_virtual_facts()

    assert netbsd_virtual_facts['virtualization_type'] in ['', 'xen', 'kvm', 'vmware', 'virtualbox', 'parallel', 'qemu', 'hyperv', 'kvm', 'oracle', 'photon_controller']
    assert netbsd_virtual_facts['virtualization_role'] in ['guest', 'host']

# Generated at 2022-06-23 02:32:37.883848
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert netbsd_virtual_collector._platform == 'NetBSD'
    assert netbsd_virtual_collector._fact_class == NetBSDVirtual

# Generated at 2022-06-23 02:32:41.802936
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    f_module = NetBSDVirtualCollector(module=None)
    virtual_facts = f_module._get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'

# Generated at 2022-06-23 02:32:44.244733
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    x = NetBSDVirtual()
    assert not x.guest

# Generated at 2022-06-23 02:32:49.662144
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    # Create expected output
    expected_output = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_technologies': set([])
    }

    # Create instance
    netbsd_virtual = NetBSDVirtual({}, {}, False, False)

    # Assert expected output
    assert netbsd_virtual.data == expected_output


# Generated at 2022-06-23 02:32:51.122796
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    nv = NetBSDVirtualCollector()
    assert nv is not None


# Generated at 2022-06-23 02:32:52.528788
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    a = NetBSDVirtual()
    assert a.platform == 'NetBSD'


# Generated at 2022-06-23 02:32:57.567058
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():

    class TestModule:
        def __init__(self):
            self.params = None

    netbsd_virtual_collector = NetBSDVirtualCollector(TestModule())

    assert netbsd_virtual_collector._platform == 'NetBSD'

# Generated at 2022-06-23 02:33:01.995593
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    # Instantiate NetBSDVirtual class
    virtual_obj = NetBSDVirtual()

    # Assert that get_virtual_facts() method of class NetBSDVirtual returns a dictionary
    assert isinstance(virtual_obj.get_virtual_facts(), dict)

# Generated at 2022-06-23 02:33:04.962078
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.platform == 'NetBSD'


# Generated at 2022-06-23 02:33:06.876381
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    vm = NetBSDVirtual()
    assert vm.platform == 'NetBSD'


# Generated at 2022-06-23 02:33:09.180442
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual()
    assert virtual.platform == 'NetBSD'


# Generated at 2022-06-23 02:33:12.244321
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.platform == 'NetBSD'


# Generated at 2022-06-23 02:33:13.998382
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert hasattr(NetBSDVirtualCollector._fact_class, '_platform')

# Generated at 2022-06-23 02:33:17.205549
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert issubclass(NetBSDVirtualCollector, VirtualCollector)
    assert NetBSDVirtualCollector._platform == 'NetBSD'
    assert NetBSDVirtualCollector._fact_class == NetBSDVirtual

# Generated at 2022-06-23 02:33:25.564139
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    m_open = __builtins__.open
    def test_open(*args, **kwargs):
        raise IOError()
    __builtins__.open = test_open

    netbsd_facts = NetBSDVirtual()
    __builtins__.open = m_open

    assert netbsd_facts.platform == 'NetBSD'
    assert netbsd_facts.get_virtual_facts() == {'virtualization_type': '', 'virtualization_role': '',
                                                'virtualization_tech_host': set(), 'virtualization_tech_guest': set()}

# Generated at 2022-06-23 02:33:27.084563
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert issubclass(NetBSDVirtualCollector,VirtualCollector)

# Generated at 2022-06-23 02:33:33.214862
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual = NetBSDVirtual({}, {})

    # 'virtualization_type' and 'virtualization_role' should default to ''.
    assert netbsd_virtual.get_virtual_facts()['virtualization_type'] == ''
    assert netbsd_virtual.get_virtual_facts()['virtualization_role'] == ''



# Generated at 2022-06-23 02:33:35.359411
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    result = NetBSDVirtualCollector()
    assert result.platform == 'NetBSD'
    assert result._fact_class is NetBSDVirtual
    assert not hasattr(result, '_platform')

# Generated at 2022-06-23 02:33:37.243358
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    x = NetBSDVirtualCollector()
    assert x._fact_class == NetBSDVirtual
    assert x._platform == 'NetBSD'

# Generated at 2022-06-23 02:33:38.657866
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector._platform == 'NetBSD'
    assert NetBSDVirtualCollector._fact_class == NetBSDVirtual

# Generated at 2022-06-23 02:33:43.573732
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    for fact_class in [NetBSDVirtual, NetBSDVirtualCollector]:
        assert fact_class._platform == 'NetBSD'
        assert fact_class.get_virtual_facts() is not None
        assert fact_class.get_all_virtual_facts() is not None

# Generated at 2022-06-23 02:33:49.092418
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual = NetBSDVirtual({})
    expected_virtual_facts = {'virtualization_role': 'guest',
                              'virtualization_type': '',
                              'virtualization_tech_guest': set(['xen']),
                              'virtualization_tech_host': set(['xen'])}
    virtual_facts = netbsd_virtual.get_virtual_facts()
    assert virtual_facts == expected_virtual_facts

# Generated at 2022-06-23 02:33:53.584206
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsdvirtual = NetBSDVirtual()
    assert netbsdvirtual.virtual.platform == 'NetBSD'


# Generated at 2022-06-23 02:33:55.959555
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    vcollect = NetBSDVirtualCollector()
    vobj = vcollect._fact_class(vcollect)
    vm_facts = {'virtualization_type': 'xen'}
    assert vm_facts == vobj.get_virtual_facts()

# Generated at 2022-06-23 02:34:01.092450
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_collect = NetBSDVirtualCollector()
    netbsd_facts = netbsd_collect.get_all_facts()
    assert netbsd_facts['virtualization_type'] == 'xen'
    assert netbsd_facts['virtualization_role'] == 'guest'
    assert 'xen' in netbsd_facts['virtualization_tech_guest']

# Generated at 2022-06-23 02:34:10.186908
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Setup mock facts
    facts = {
        'kernel_name': 'NetBSD',
        'virtual_subsystems': ['netbsd'],
    }

    # Setup expected results
    expected = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_subtype': '',
        'virtualization_systems': ['netbsd:netbsd'],
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }

    # Run test
    result = NetBSDVirtual(facts).get_virtual_facts()
    assert result == expected
