

# Generated at 2022-06-23 02:24:15.165254
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual = NetBSDVirtualCollector()
    assert netbsd_virtual._platform == "NetBSD"
    assert netbsd_virtual._fact_class.platform == "NetBSD"


# Generated at 2022-06-23 02:24:25.725878
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.netbsd import NetBSDVirtual
    from ansible.module_utils.facts import collect_facts
    sysctl_output = '''
sysctl: machdep.dmi.system-product: VMware Virtual Platform
sysctl: machdep.dmi.system-vendor: VMware, Inc.
'''
    test = NetBSDVirtual({'sysctl_raw': sysctl_output})
    assert test.get_virtual_facts()['virtualization_type'] == 'VMware'
    assert test.get_virtual_facts()['virtualization_role'] == 'guest'
    assert test.get_virtual_facts()['virtualization_tech_host'] == set(['VMware'])

# Generated at 2022-06-23 02:24:30.914106
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual_info = {'virtualization_type': '',
                           'virtualization_role': ''}

    netbsd_virtual = NetBSDVirtual(netbsd_virtual_info)
    assert netbsd_virtual
    assert netbsd_virtual.platform == 'NetBSD'
    assert netbsd_virtual.virtual == ''
    assert netbsd_virtual.role == ''

# Generated at 2022-06-23 02:24:39.921762
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    facts = {
        'platform': 'NetBSD'
    }
    virtual = NetBSDVirtual(facts)
    virtual_facts = virtual.get_virtual_facts()
    for k in ['virtualization_type', 'virtualization_role',
            'virtualization_tech_guest', 'virtualization_tech_host']:
        assert k in virtual_facts
    assert virtual_facts['virtualization_type'] in [
            '', 'xen', 'bochs', 'vmware', 'hyper-v', 'virtualbox']
    assert virtual_facts['virtualization_role'] in [
            '', 'guest', 'host']
    assert isinstance(virtual_facts['virtualization_tech_guest'], set)
    assert isinstance(virtual_facts['virtualization_tech_host'], set)

# Generated at 2022-06-23 02:24:41.648908
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual()
    assert virtual.platform == 'NetBSD'

# Generated at 2022-06-23 02:24:46.389968
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual({'sysctl': {'machdep.dmi.system-vendor': 'VirtualBox',
                                        'machdep.dmi.system-product': 'VirtualBox',
                                        'machdep.dmi.system-version': '1.2-3'}})
    assert virtual.data['virtualization_type'] == 'virtualbox'
    assert virtual.data['virtualization_role'] == ''
    assert not virtual.data['virtualization_tech_guest']
    assert not virtual.data['virtualization_tech_host']


# Generated at 2022-06-23 02:24:50.019693
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    # test constructor
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.platform == 'NetBSD'
    assert netbsd_virtual.get_virtual_facts() == {}

# Generated at 2022-06-23 02:24:51.181371
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    NetBSDVirtualCollector(None)

# Generated at 2022-06-23 02:24:53.594855
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    obj = NetBSDVirtualCollector()
    assert obj._fact_class == NetBSDVirtual
    assert obj._platform == 'NetBSD'

# Generated at 2022-06-23 02:24:58.562219
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.netbsd import NetBSDVirtual
    virtual = NetBSDVirtual()

    facts = virtual.get_virtual_facts(virtual.platform)
    assert 'virtualization_role' in facts
    assert 'virtualization_type' in facts
    assert 'virtualization_tech_host' in facts
    assert 'virtualization_tech_guest' in facts
    assert 'virtualization_vendor_facts' in facts

# Generated at 2022-06-23 02:25:09.706745
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Create the instance of NetBSDVirtual
    netbsd_virtual = NetBSDVirtual()

    # Construct the input for method get_virtual_facts
    virtual_facts = {'virtualization_type': '', 'virtualization_role': ''}

    # Mock the method detect_virt_product
    def mock_detect_virt_product(key):
        ret_val = {'virtualization_type': 'kvm', 'virtualization_role': 'host'}
        return ret_val

    netbsd_virtual.detect_virt_product = mock_detect_virt_product

    # Mock the method detect_virt_vendor
    def mock_detect_virt_vendor(key):
        ret_val = {'virtualization_type': 'kvm', 'virtualization_role': 'host'}
        return ret_val



# Generated at 2022-06-23 02:25:15.461233
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virt = NetBSDVirtual(module=None)
    output = virt.get_virtual_facts()
    assert output['virtualization_type'] == 'virtualbox'
    assert output['virtualization_role'] == 'guest'

    # Disable sysctl
    virt.disable_sysctl = True
    output = virt.get_virtual_facts()
    assert output['virtualization_type'] == ''
    assert output['virtualization_role'] == ''

# Generated at 2022-06-23 02:25:24.267927
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Prepare input variables
    inject = {
        'platform': 'NetBSD',
        'sysctl_path': ['machdep.dmi.system-product',
                        'machdep.dmi.system-vendor',
                        'machdep.hypervisor'],
        'sysctl_lines': {'machdep.dmi.system-product':
                             u'VMware Virtual Platform'
                             u'',
                         'machdep.dmi.system-vendor':
                             u'VMware, Inc.'
                             u'',
                         'machdep.hypervisor':
                             u'vmware'
                         }
    }

    # Set expected results

# Generated at 2022-06-23 02:25:33.280460
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.netbsd import NetBSDVirtual

    # build a faked mockable sysctl output
    vm_type = None
    vm_role = None
    sysctl_output = [('paravirt', 'foo'),
                     ('hypervisor', 'bar'),
                     ('xen0.pcpu.cpu.cpu', '42')]
    virt_facts = NetBSDVirtual.get_virtual_facts(sysctl_output)

    # test vm_type
    assert 'virtualization_type' in virt_facts
    if virt_facts['virtualization_type'] == 'foo':
        vm_type = 'paravirt'
    elif virt_facts['virtualization_type'] == 'bar':
        vm_type = 'hypervisor'

# Generated at 2022-06-23 02:25:43.161488
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    import sys, os
    test_vars = {}
    module = AnsibleModule(
        argument_spec = dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )

    if not module.params['gather_subset']:
        module.params['gather_subset'] = ['!all']

    # get all available facts
    inst = NetBSDVirtual(module)
    facts_dict = inst.get_all_facts()

    for key in [
        'virtualization_role',
        'virtualization_type',
    ]:
        if key in facts_dict:
            test_vars[key] = facts_dict[key]


# Generated at 2022-06-23 02:25:46.491330
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    # Get instance of NetBSDVirtualCollector
    netbsd_virtual = NetBSDVirtualCollector()

    # Check if the instance is correct
    assert netbsd_virtual._fact_class is NetBSDVirtual
    assert netbsd_virtual._platform is 'NetBSD'

# Generated at 2022-06-23 02:25:49.768653
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual = NetBSDVirtualCollector()
    assert netbsd_virtual._fact_class == NetBSDVirtual
    assert netbsd_virtual._platform == 'NetBSD'

# Generated at 2022-06-23 02:25:52.378736
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virtual_facts = NetBSDVirtualCollector()

    assert virtual_facts._platform == 'NetBSD'
    assert virtual_facts._fact_class == NetBSDVirtual


# Generated at 2022-06-23 02:25:56.485330
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_systems': set(),
        'virtualization_environments': set()
    }

# Generated at 2022-06-23 02:25:58.439923
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    # test creating object
    NetBSDVm = NetBSDVirtualCollector()
    assert NetBSDVm


# Generated at 2022-06-23 02:26:02.268826
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():

    from ansible.module_utils.facts import virtual

    virtual_facts = virtual._VirtualInfo(module=None).get_facts()
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_type'] == 'xen'

# Generated at 2022-06-23 02:26:04.539377
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    nvt = NetBSDVirtual({'ansible_facts': {}})
    assert nvt.platform == 'NetBSD'


# Generated at 2022-06-23 02:26:10.880720
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    """
    Test get_virtual_facts of class NetBSDVirtual
    """
    # Create an instance of class NetBSDVirtual
    netbsd_virtual = NetBSDVirtual()

    # Define the expected result of method get_virtual_facts
    expected_result = {'virtualization_role': 'guest', 'virtualization_type': 'xen',
                       'virtualization_tech_guest': {'xen'}, 'virtualization_tech_host': {}}

    # Call method get_virtual_facts
    result = netbsd_virtual.get_virtual_facts()

    assert result == expected_result

# Generated at 2022-06-23 02:26:19.674487
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    expected_facts = {
        'virtualization_type': 'kvm',
        'virtualization_role': 'host',
        'virtualization_tech_host': set(['kvm'])
    }

    # Sample sysctl output with virtualization facts
    sysctl_output = """machdep.dmi.system-product = VMware Virtual Platform
machdep.hypervisor = kvm"""

    # Create an instance of NetBSDVirtual class
    v = NetBSDVirtual()

    # Return value of get_virtual_facts should match expected_facts
    assert v.get_virtual_facts(sysctl_output) == expected_facts

# Generated at 2022-06-23 02:26:22.050691
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    # Constructor test
    virtual_facts_collector = NetBSDVirtualCollector()
    assert virtual_facts_collector


# Generated at 2022-06-23 02:26:23.545018
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual({})
    assert virtual.platform == 'NetBSD'

# Generated at 2022-06-23 02:26:30.593027
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    facts = NetBSDVirtual()
    assert facts.virtualization_type == ''
    assert facts.virtualization_role == ''
    assert facts.virtualization_system == ''
    assert facts.virtualization_hypervisor is None
    assert facts.virtualization_system == ''
    assert facts.virtualization_hypervisor_version is None
    assert facts.virtualization_system_version == ''
    assert facts.virtualization_product_name is None
    assert facts.virtualization_product_version is None


# Generated at 2022-06-23 02:26:32.444429
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.platform == 'NetBSD'

# Generated at 2022-06-23 02:26:34.783787
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert netbsd_virtual_collector._fact_class == NetBSDVirtual
    assert netbsd_virtual_collector._platform == 'NetBSD'

# Generated at 2022-06-23 02:26:39.300290
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert isinstance(netbsd_virtual, NetBSDVirtual)
    assert isinstance(netbsd_virtual, Virtual)
    assert isinstance(netbsd_virtual, VirtualSysctlDetectionMixin)


# Generated at 2022-06-23 02:26:41.117935
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    nv_fact = NetBSDVirtualCollector()
    assert nv_fact.collect()['virtualization_type'] == 'xen'

# Generated at 2022-06-23 02:26:46.045778
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virtual_collector = NetBSDVirtualCollector()
    assert virtual_collector.platform == 'NetBSD'
    assert virtual_collector.fact_class.platform == 'NetBSD'
    assert virtual_collector._platform == 'NetBSD'
    assert virtual_collector._fact_class == NetBSDVirtual


# Generated at 2022-06-23 02:26:48.189840
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual(None)
    virtual.collect()
    assert virtual.platform == "NetBSD"


# Generated at 2022-06-23 02:26:52.646266
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual().get_virtual_facts()
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts

# Generated at 2022-06-23 02:26:57.430803
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    # Negative test
    # Testing instantiation of class NetBSDVirtualCollector with invalid platform
    try:
        virtual = NetBSDVirtualCollector('XYZ')
        assert False
    except:
        assert True

    # Positive test
    # Testing instatiation of class NetBSDVirtualCollector with valid platform
    virtual = NetBSDVirtualCollector('NetBSD')
    assert True


# Generated at 2022-06-23 02:27:01.729869
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual()
    assert virtual_facts.virtualizations
    assert virtual_facts.virtualization_type
    assert virtual_facts.virtualization_role
    assert virtual_facts.virtualization_embedded
    assert virtual_facts.virtualization_systems
    assert virtual_facts.virtualization_tech_guest
    assert virtual_facts.virtualization_tech_host

# Generated at 2022-06-23 02:27:09.588025
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Test without any virtualization
    virtual_facts = {'virtualization_type': '', 'virtualization_role': '',
                     'virtualization_tech_host': set(), 'virtualization_tech_guest': set()}
    assert NetBSDVirtual().get_virtual_facts() == virtual_facts

    # Test with VMWare product name
    virtual_facts = {'virtualization_type': 'vmware', 'virtualization_role': 'guest',
                     'virtualization_tech_host': set(), 'virtualization_tech_guest': set(['vmware'])}
    assert NetBSDVirtual('machdep.dmi.system-product', 'VMware Virtual Platform').get_virtual_facts() == virtual_facts

    # Test with VirtualBox product name

# Generated at 2022-06-23 02:27:15.403119
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Run get_virtual_facts()
    facts = NetBSDVirtual().get_virtual_facts()

    # Test virtualization_type value
    assert 'virtualization_type' in facts.keys()
    assert facts['virtualization_type'] in ('xen', '')
    # Test virtualization_role value
    assert 'virtualization_role' in facts.keys()
    assert facts['virtualization_role'] in ('guest', '')

# Generated at 2022-06-23 02:27:18.037450
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    facts = NetBSDVirtualCollector()
    assert isinstance(facts, VirtualCollector)
    assert isinstance(facts, NetBSDVirtualCollector)


# Generated at 2022-06-23 02:27:23.558071
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual import NetBSDVirtual as NetBSDVirtual_test
    '''
    This test verifies if the detected virtual machine
    is actually running inside a virtual machine.
    '''

    virtual_facts = NetBSDVirtual_test().get_virtual_facts()
    assert 'virtualization_role' in virtual_facts
    assert virtual_facts['virtualization_role'] == 'guest'


# Generated at 2022-06-23 02:27:25.428387
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virtual_facts = NetBSDVirtualCollector(None, None, None)
    assert virtual_facts._platform == 'NetBSD'

# Generated at 2022-06-23 02:27:28.550743
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virtual_collector = NetBSDVirtualCollector()
    assert virtual_collector.platform == 'NetBSD'
    assert virtual_collector._fact_class == NetBSDVirtual

# Generated at 2022-06-23 02:27:36.561818
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    '''Unit test for method get_virtual_facts of class NetBSDVirtual.'''

    # Create a NetBSDVirtual object
    netbsd_virtual = NetBSDVirtual()

    # Mock function sysctl to return dict[string, string]
    netbsd_virtual._sysctl = lambda x: {'machdep.hypervisor': 'bochs',
                                        'machdep.dmi.system-vendor': 'Bochs',
                                        'machdep.dmi.system-product': 'Bochs'}

    # Call method get_virtual_facts
    output = netbsd_virtual.get_virtual_facts()

    # Check output
    assert 'virtualization_role' in output
    assert output['virtualization_role'] == 'guest'
    assert 'virtualization_type' in output

# Generated at 2022-06-23 02:27:38.747910
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert netbsd_virtual_collector._fact_class is NetBSDVirtual

# Generated at 2022-06-23 02:27:45.518004
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': set(),
    }

    netbsd_virtual = NetBSDVirtual(module=None)
    netbsd_virtual_facts = netbsd_virtual.get_virtual_facts()

    for key in virtual_facts.keys():
        assert virtual_facts[key] == netbsd_virtual_facts[key]

# Generated at 2022-06-23 02:27:46.969389
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    n = NetBSDVirtualCollector()
    assert n.platform == 'NetBSD'

# Generated at 2022-06-23 02:27:48.888352
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    collector = NetBSDVirtualCollector()
    assert isinstance(collector._fact_class, NetBSDVirtual)

# Generated at 2022-06-23 02:27:50.480132
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virt = NetBSDVirtual()

    assert virt.get_virtual_facts() is not None


# Generated at 2022-06-23 02:27:56.905142
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'xen'
    assert 'xen' in virtual_facts['virtualization_tech_guest']
    assert 'xen' not in virtual_facts['virtualization_tech_host']
    assert virtual_facts['virtualization_role'] == 'guest'

# Generated at 2022-06-23 02:28:02.929658
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    os_facts = dict(
        system='NetBSD',
        kernel='NetBSD',
        machine='amd64',
        os='NetBSD'
    )
    collector = NetBSDVirtualCollector(os_facts)
    assert collector.platform == 'NetBSD'
    assert collector.os_facts['system'] == 'NetBSD'
    assert collector.os_facts['kernel'] == 'NetBSD'
    assert collector.os_facts['machine'] == 'amd64'
    assert collector.os_facts['os'] == 'NetBSD'

# Generated at 2022-06-23 02:28:04.033497
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    NetBSDVirtualCollector()

# Generated at 2022-06-23 02:28:10.842294
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virt = NetBSDVirtual()

    # Set empty values as default
    results = {'virtualization_type': '',
               'virtualization_role': '',
               'virtualization_tech_guest': set(),
               'virtualization_tech_host': set()}

    # Execute the method get_virtual_facts
    results_test = virt.get_virtual_facts()

    # Assertion with the good results
    assert results == results_test


# Generated at 2022-06-23 02:28:14.237437
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual = NetBSDVirtualCollector()
    assert netbsd_virtual.platform == 'NetBSD'
    assert netbsd_virtual._fact_class == NetBSDVirtual

# Generated at 2022-06-23 02:28:23.534454
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():

    # Mock data
    sysctl_run = {
        'machdep.dmi.system-vendor': 'Google',
        'machdep.dmi.system-product': 'Google Compute Engine',
        'machdep.hypervisor': 'KVM',
    }

    # Invoke the method
    fact_class = NetBSDVirtual()
    virtual_facts = fact_class._get_virtual_facts(sysctl_run)

    # Assertion 2: Verify the virtualization_type
    assert virtual_facts['virtualization_type'] == 'kvm'

    # Assertion 3: Verify the virtualization_role
    assert virtual_facts['virtualization_role'] == 'guest'

    # Assertion 4: Verify the virtualization_tech_guest
    assert virtual_facts['virtualization_tech_guest']

# Generated at 2022-06-23 02:28:26.793655
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Init
    netBSD = NetBSDVirtual({})
    netBSD_virtual_facts = netBSD.get_virtual_facts()

    # Assert type
    assert type(netBSD_virtual_facts).__name__ == 'dict'

    # Assert key names
    keys = ['virtualization_type',
            'virtualization_role',
            'virtualization_tech_guest',
            'virtualization_tech_host']

    for i in range(0, len(keys)):
        assert keys[i] in netBSD_virtual_facts

# Generated at 2022-06-23 02:28:30.862615
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual_facts = NetBSDVirtual()
    assert netbsd_virtual_facts._platform == 'NetBSD'
    assert netbsd_virtual_facts._fact_class == NetBSDVirtual
    assert netbsd_virtual_facts._collector_class == NetBSDVirtualCollector



# Generated at 2022-06-23 02:28:40.852540
# Unit test for method get_virtual_facts of class NetBSDVirtual

# Generated at 2022-06-23 02:28:42.570362
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    print(NetBSDVirtualCollector().collect())

# Generated at 2022-06-23 02:28:54.258737
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Patching the sysctl method
    def mock_sysctl(sysctl_parameter):
        proc_sysctl = {
            'machdep.dmi.system-vendor': 'Microsoft Corporation',
            'machdep.dmi.system-product': 'Virtual Machine',
            'machdep.hypervisor.version': 'Hyper-V UEFI',
            'machdep.hypervisor.product': 'Microsoft Corporation',
            'machdep.hypervisor.vendor': 'Microsoft',
        }
        return proc_sysctl.get(sysctl_parameter, None)

    # Patching the exists method
    class mock_os(object):
        @staticmethod
        def exists(path):
            return True if path == '/dev/xencons' else False

    fake_ansible_module = FakeAnsibleModule()

# Generated at 2022-06-23 02:28:56.325703
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual()
    assert virtual_facts.platform == 'NetBSD'


# Generated at 2022-06-23 02:29:07.092148
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual = NetBSDVirtual()
    sysctl_dict = {'machdep.dmi.system-product': 'VMware VMware Virtual Platform',
                   'machdep.dmi.system-vendor': 'VMware, Inc.',
                   'machdep.hypervisor': 'VirtualBox'}
    virtual_facts = netbsd_virtual.get_virtual_facts(sysctl_dict)
    assert virtual_facts['virtualization_type'] == 'virtualbox'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert 'vmware' in virtual_facts['virtualization_tech_guest']
    assert 'virtualbox' in virtual_facts['virtualization_tech_guest']
    assert 'vmware' in virtual_facts['virtualization_tech_host']

# Generated at 2022-06-23 02:29:10.491944
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    v = NetBSDVirtualCollector()
    assert isinstance(v, VirtualCollector)
    assert isinstance(v, NetBSDVirtualCollector)
    assert isinstance(v._fact_class, NetBSDVirtual)
    assert v._platform == 'NetBSD'

# Generated at 2022-06-23 02:29:11.458604
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():

    NetBSDVirtual()


# Generated at 2022-06-23 02:29:19.062096
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()

    assert netbsd_virtual.platform == 'NetBSD'
    assert isinstance(netbsd_virtual.virtual, dict)
    assert 'virtualization_type' not in netbsd_virtual.virtual.keys()
    assert 'virtualization_role' not in netbsd_virtual.virtual.keys()
    assert 'virtualization_sysctl_name' in dir(netbsd_virtual)
    assert 'virtualization_product_sysctl_name' in dir(netbsd_virtual)
    assert netbsd_virtual._platform == 'NetBSD'

    assert netbsd_virtual.virtualization_type == ''
    assert netbsd_virtual.virtualization_role == ''

# Generated at 2022-06-23 02:29:20.397895
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual()
    assert virtual_facts.get_virtual_facts() == {}

# Generated at 2022-06-23 02:29:29.095898
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    import pytest

    # Test with only machdep.dmi.system-product set and matching
    sysctl_data = {
        'machdep.dmi.system-product': 'VMware Virtual Platform',
        'machdep.dmi.system-vendor': 'VMware, Inc.',
    }

    # Test with only machdep.dmi.system-product set and matching
    sysctl_data = {
        'machdep.dmi.system-product': 'VMware Virtual Platform',
        'machdep.dmi.system-vendor': 'VMware, Inc.',
    }
    virtual_facts = NetBSDVirtual(sysctl_data).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'VMware Virtual Platform'

# Generated at 2022-06-23 02:29:40.779912
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virt_facts = NetBSDVirtual()
    virt_facts.collect()
    vm_facts = virt_facts.get_virtual_facts()

    assert vm_facts['virtualization_type'] == 'xen'
    assert vm_facts['virtualization_role'] == 'guest'
    assert vm_facts['virtualization_technology'] == ['xen']
    assert vm_facts['virtualization_technologies'] == ['xen']
    assert vm_facts['virtualization_product_name'] == 'HVM domU'
    assert vm_facts['virtualization_product_version'] == ''
    assert vm_facts['virtualization_product'] == 'HVM domU'
    assert vm_facts['virtualization_system_vendor'] == 'Xen'

# Generated at 2022-06-23 02:29:45.877960
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    virtual_facts = netbsd_virtual.get_virtual_facts()

    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-23 02:29:52.529447
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    from ansible.module_utils.facts.virtual.netbsd import NetBSDVirtualCollector
    from ansible.module_utils.facts.virtual.sysctl import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual import VirtualCollector

    assert issubclass(NetBSDVirtualCollector, VirtualCollector)
    assert issubclass(NetBSDVirtualCollector, VirtualSysctlDetectionMixin)

    assert NetBSDVirtualCollector._fact_class == NetBSDVirtual
    assert NetBSDVirtualCollector._platform == 'NetBSD'

# Generated at 2022-06-23 02:29:54.885523
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual()
    assert virtual_facts.platform == 'NetBSD'


# Generated at 2022-06-23 02:29:56.896304
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual_object = NetBSDVirtual()
    assert netbsd_virtual_object.platform == 'NetBSD'

# Generated at 2022-06-23 02:29:58.401728
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    f = NetBSDVirtualCollector()
    assert f is not None

# Generated at 2022-06-23 02:30:03.526584
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert 'xen' in virtual_facts['virtualization_tech_host']
    assert 'xen' in virtual_facts['virtualization_tech_guest']

# Generated at 2022-06-23 02:30:10.591891
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()

    assert netbsd_virtual._platform == 'NetBSD'
    assert netbsd_virtual.platform == 'NetBSD'
    assert netbsd_virtual.sysctl_base == 'mib'
    assert netbsd_virtual._virtual_fact_class == NetBSDVirtual
    assert netbsd_virtual._virtual_fact_subclass == NetBSDVirtual
    assert netbsd_virtual.virtualization_type == ''
    assert netbsd_virtual.virtualization_role == ''


# Generated at 2022-06-23 02:30:18.196787
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd = NetBSDVirtual(None)
    assert netbsd._sysctl_key_to_search == 'machdep.dmi.system-product'
    assert set(netbsd._guest_virtual_facts) == set([])
    assert set(netbsd._host_virtual_facts) == set([])


# Generated at 2022-06-23 02:30:29.114743
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    try:
        import machdep
    except ImportError:
        from ansible.module_utils import basic
        machdep = basic.AnsibleModule(argument_spec={})._load_params()
        machdep['machdep']['dmi']['system-product'] = 'VirtualBox'
    virtual_facts = NetBSDVirtual(machdep).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'virtualbox'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert 'virtualbox' in virtual_facts['virtualization_tech_guest']
    assert 'virtualbox' in virtual_facts['virtualization_tech_host']
    assert 'vbox' in virtual_facts['virtualization_tech_guest']

# Generated at 2022-06-23 02:30:30.869544
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual({}, {})
    assert isinstance(netbsd_virtual, NetBSDVirtual)

# Generated at 2022-06-23 02:30:38.374002
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    class MockModule(object):
        def __init__(self):
            self.run_command_environ = os.environ.copy()

    module = MockModule()

    # empty values
    sysctl = dict()
    sysctl['machdep.dmi.system-product'] = ''
    sysctl['machdep.dmi.system-vendor'] = ''
    virtual = NetBSDVirtual(module=module, sysctl=sysctl)
    result = virtual.get_virtual_facts()
    assert result['virtualization_type'] == ''
    assert result['virtualization_role'] == ''

    # vmware
    sysctl = dict()
    sysctl['machdep.dmi.system-product'] = ''
    sysctl['machdep.dmi.system-vendor'] = 'VMware, Inc.'


# Generated at 2022-06-23 02:30:39.935278
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert isinstance(NetBSDVirtualCollector(), VirtualCollector)


# Generated at 2022-06-23 02:30:47.855572
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual()
    assert virtual_facts._platform == 'NetBSD'
    assert virtual_facts.platform == 'NetBSD'
    assert virtual_facts.is_linux() == True
    assert virtual_facts.is_linux_systemd() == False
    assert virtual_facts.is_solaris() == False
    assert virtual_facts.is_freebsd() == False
    assert virtual_facts.is_netbsd() == True
    assert virtual_facts.is_openbsd() == False
    assert virtual_facts.is_aix() == False
    assert virtual_facts.is_sunos() == False
    assert virtual_facts.is_hpux() == False
    assert virtual_facts.is_devuan() == False


# Generated at 2022-06-23 02:30:48.937079
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual()
    assert virtual is not None

# Generated at 2022-06-23 02:30:50.443771
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virt = NetBSDVirtual()
    assert netbsd_virt.platform == 'NetBSD'

# Generated at 2022-06-23 02:31:00.450402
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    import json
    import platform

    def json_load_byteified(file_handle):
        return _byteify(json.load(file_handle, object_hook=_byteify), ignore_dicts=True)

    def _byteify(data, ignore_dicts=False):
        # if this is a unicode string, return its string representation
        if isinstance(data, unicode):
            return data.encode('utf-8')
        # if this is a list of values, return list of byteified values
        if isinstance(data, list):
            return [_byteify(item, ignore_dicts=True) for item in data]
        # if this is a dictionary, return dictionary of byteified keys and values
        # but only if we haven't already byteified it

# Generated at 2022-06-23 02:31:05.920334
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    v = NetBSDVirtualCollector()
    assert v.platform == 'NetBSD'
    assert v.fact_class == NetBSDVirtual
    assert repr(v) == "<NetBSDVirtualCollector(platform='NetBSD', fact_class=<class 'ansible.module_utils.facts.virtual.netbsd.NetBSDVirtual'>)>"

# Generated at 2022-06-23 02:31:09.881055
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virtual_collector = NetBSDVirtualCollector()
    assert virtual_collector._fact_class == NetBSDVirtual

# Generated at 2022-06-23 02:31:15.385295
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Create a NetBSDVirtual object
    netbsd_virtual = NetBSDVirtual()

    # Test get_virtual_facts with no arguments
    netbsd_virtual_facts = netbsd_virtual.get_virtual_facts()
    assert netbsd_virtual_facts['virtualization_type'] == ''
    assert netbsd_virtual_facts['virtualization_role'] == ''
    assert not netbsd_virtual_facts['virtualization_tech_guest']
    assert not netbsd_virtual_facts['virtualization_tech_host']

# Generated at 2022-06-23 02:31:23.698150
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    bsdv = NetBSDVirtual()

    # emtpy machdep.dmi.system-vendor, machdep.dmi.system-product, machdep.hypervisor
    sysctl_values = {
        'machdep.dmi.system-vendor': '',
        'machdep.dmi.system-product': '',
        'machdep.hypervisor': '',
    }
    virtual_facts = bsdv.get_virtual_facts(sysctl_values)
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert not virtual_facts['virtualization_tech_guest']
    assert not virtual_facts['virtualization_tech_host']

    # machdep.dmi.system-vendor is OpenBSD Foundation
    sysctl_

# Generated at 2022-06-23 02:31:26.112757
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual(None, None)
    assert netbsd_virtual.platform == 'NetBSD'

# Generated at 2022-06-23 02:31:30.867691
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virt = NetBSDVirtual(None, None)

    assert virt.platform == 'NetBSD'
    assert virt.virtualization_type == ''
    assert virt.virtualization_role == ''
    assert virt._sysctl_vm_guest is not None
    assert virt._sysctl_hypervisor is not None



# Generated at 2022-06-23 02:31:34.772796
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert netbsd_virtual_collector.fact_class._platform == 'NetBSD'

# Generated at 2022-06-23 02:31:47.609432
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Define virtual version of sysctl and empty sysctl.
    class MySysctlMock(object):
        def __init__(self):
            self.sysctl = {}

        def read(self, sysctl_name):
            return self.sysctl.get(sysctl_name)

    # Virtual part of dmidecode.
    virtual_dmidecode = {
        "machdep.dmi.system-product": "VirtualBox\n",
        "machdep.dmi.system-vendor": "innotek GmbH\n",
        "machdep.hypervisor": "none"
    }

    virtual_sysctl = MySysctlMock()
    empty_sysctl = MySysctlMock()

    # Set virtual dmidecode information.
    virtual_sysctl.sysctl = virtual_

# Generated at 2022-06-23 02:31:48.736854
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual()
    virtual_facts.get_virtual_facts()

# Generated at 2022-06-23 02:31:50.309691
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector is not None



# Generated at 2022-06-23 02:31:52.946111
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    n_col = NetBSDVirtualCollector()
    assert n_col._platform == 'NetBSD'

# Generated at 2022-06-23 02:31:54.872213
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual(module=None)
    assert virtual.platform == 'NetBSD'


# Generated at 2022-06-23 02:32:05.534933
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    test = NetBSDVirtual()
    test.sysctl_values['machdep.dmi.system-product'] = 'VirtualBox'
    test.sysctl_values['machdep.dmi.system-vendor'] = 'Oracle Corporation'
    test.sysctl_values['machdep.hypervisor'] = 'VirtualBox'
    test.file_exists_values['/dev/xencons'] = False
    virtual_facts = test.get_virtual_facts()
    assert virtual_facts == {
        'virtualization_type': 'virtualbox',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': {'virtualbox'},
        'virtualization_tech_host': {'virtualbox'}}

# Generated at 2022-06-23 02:32:07.908842
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual()
    assert virtual
    assert virtual._platform == 'NetBSD'
    assert virtual._fact_class == NetBSDVirtual


# Generated at 2022-06-23 02:32:12.557986
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Create a new instance of the NetBSDVirtual class
    virtual = NetBSDVirtual(module=None)

    # Return a dictionary containing the virtualization facts
    virtual_facts_dict = virtual.get_virtual_facts()

    # Assert that the dictionary is not empty
    assert bool(virtual_facts_dict)

    assert virtual_facts_dict['virtualization_type'] == ''
    assert virtual_facts_dict['virtualization_role'] == ''

# Generated at 2022-06-23 02:32:15.965724
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert netbsd_virtual_collector._platform == 'NetBSD'
    assert netbsd_virtual_collector._fact_class == NetBSDVirtual

# Generated at 2022-06-23 02:32:17.957920
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_module = NetBSDVirtual()
    assert netbsd_module.platform == 'NetBSD'


# Generated at 2022-06-23 02:32:21.108772
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    import sys
    collector = NetBSDVirtualCollector(sys.modules[__name__])
    assert collector is not None

# Generated at 2022-06-23 02:32:23.584870
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virtual_collector = NetBSDVirtualCollector()
    assert virtual_collector._platform == 'NetBSD'
    assert virtual_collector._fact_class == NetBSDVirtual

# Generated at 2022-06-23 02:32:25.565231
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    x = NetBSDVirtualCollector()
    assert x._platform == 'NetBSD'
    assert x._fact_class == NetBSDVirtual

# Generated at 2022-06-23 02:32:28.897599
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    facts = NetBSDVirtual().get_virtual_facts()

    assert isinstance(facts, dict)
    assert facts['virtualization_type'] != ''
    assert facts['virtualization_role'] != ''
    assert facts['virtualization_type'] == 'virtualbox'
    assert facts['virtualization_role'] == 'guest'

# Generated at 2022-06-23 02:32:31.580193
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    x = NetBSDVirtualCollector()
    assert x._platform == 'NetBSD'
    assert x._fact_class._platform == 'NetBSD'

# Generated at 2022-06-23 02:32:41.189486
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual = NetBSDVirtual()
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'xen'
    assert 'xen' in virtual_facts['virtualization_tech_guest']
    assert 'xen' in virtual_facts['virtualization_tech_host']
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_product_name'] == 'HVM domU'

# Generated at 2022-06-23 02:32:41.761585
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    pass

# Generated at 2022-06-23 02:32:44.540130
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    x = NetBSDVirtualCollector()
    assert x.platform == 'NetBSD'


# Generated at 2022-06-23 02:32:47.341197
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    vp = NetBSDVirtualCollector(None, None, None)
    assert vp.__class__.__name__ == 'NetBSDVirtualCollector'

# Generated at 2022-06-23 02:32:50.023564
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virtual_collector = NetBSDVirtualCollector()
    assert isinstance(virtual_collector, VirtualCollector)
    assert virtual_collector._platform == 'NetBSD'
    assert virtual_collector._fact_class == NetBSDVirtual


# Generated at 2022-06-23 02:32:51.923344
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert isinstance(netbsd_virtual_collector, NetBSDVirtualCollector)

# Generated at 2022-06-23 02:32:56.636286
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual_facts = NetBSDVirtual()
    assert netbsd_virtual_facts._platform == 'NetBSD'
    assert netbsd_virtual_facts._fact_class == NetBSDVirtual


# Generated at 2022-06-23 02:33:05.145210
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():

    # set up
    netbsd_virtual_collector = NetBSDVirtualCollector()
    netbsd_virtual = netbsd_virtual_collector._fact_class('module')
    netbsd_virtual.sysctl = {
                                'machdep.dmi.system-vendor': 'Super Micro',
                                'machdep.dmi.system-product': 'X9DRi-F',
                                'machdep.hypervisor': 'Xen'
                            }

    # make virtual_facts
    virtual_facts = netbsd_virtual.get_virtual_facts()

    # assert statements
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'



# Generated at 2022-06-23 02:33:14.290924
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    """Test method get_virtual_facts of class NetBSDVirtual"""
    # Create empty virtual data dict
    virtual_data_dict = dict()

    # Create empty virtual data dict
    virtual_facts_dict = dict()

    # Create instance of class NetBSDVirtual
    netbsd_virtual_obj = NetBSDVirtual(module=None)

    # Create class instance and call get_virtual_facts method
    netbsd_virtual_obj.get_virtual_facts()
    netbsd_virtual_obj.get_virtual_facts(virtual_data_dict)
    virtual_facts_dict = netbsd_virtual_obj.get_virtual_facts(virtual_data_dict=virtual_facts_dict)

    # Test if returned dict is correct
    assert isinstance(virtual_facts_dict, dict)

# Generated at 2022-06-23 02:33:16.277511
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():

    a = NetBSDVirtual()
    assert a.platform == 'NetBSD'


# Generated at 2022-06-23 02:33:17.426228
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual(None)

    assert virtual is not None

# Generated at 2022-06-23 02:33:28.185852
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual = NetBSDVirtual(module=None)
    sysctl_output = [
        'machdep.hypervisor = qemu',
        'machdep.dmi.system-vendor = Apple Inc.',
        'machdep.dmi.system-product = MacBookPro11,3',
    ]
    virtual.module.run_command = MagicMock(side_effect=[
        (0, '\n'.join(sysctl_output), '')
    ])
    x = virtual.get_virtual_facts()
    assert 'virtualization_type' in x
    assert x['virtualization_type'] == 'qemu'
    assert 'virtualization_role' in x
    assert x['virtualization_role'] == 'guest'
    assert 'virtualization_tech_guest' in x

# Generated at 2022-06-23 02:33:39.913407
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    nvc = NetBSDVirtualCollector()
    try:
        # Can't use assertIsInstance as instanceof is not available in Python's
        # unittest and isinstance() doesn't give us an error message when the
        # type is wrong so we are trying a try/except instead.
        nvc._fact_class
    except:
        raise AssertionError("Class NetBSDVirtualCollector did not initialize _fact_class properly")
    try:
        # Can't use assertIsInstance as instanceof is not available in Python's
        # unittest and isinstance() doesn't give us an error message when the
        # type is wrong so we are trying a try/except instead.
        nvc._platform
    except:
        raise AssertionError("Class NetBSDVirtualCollector did not initialize _platform properly")


# Generated at 2022-06-23 02:33:43.028814
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    facts_data = NetBSDVirtualCollector().collect()
    keys = ['virtualization_type', 'virtualization_role', 'virtualization_technologies']
    for key in keys:
        assert key in facts_data

# Generated at 2022-06-23 02:33:45.236457
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual()
    assert virtual_facts._platform == "NetBSD"
    assert virtual_facts.platform == "NetBSD"



# Generated at 2022-06-23 02:33:46.753159
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    v = NetBSDVirtual()
    assert v.platform == 'NetBSD'

# Generated at 2022-06-23 02:33:48.218022
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    instance = NetBSDVirtualCollector()
    assert isinstance(instance, VirtualCollector)

# Generated at 2022-06-23 02:33:51.807813
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd = NetBSDVirtualCollector()
    assert netbsd._platform == 'NetBSD'
    assert netbsd._fact_class == NetBSDVirtual

# Generated at 2022-06-23 02:33:54.636271
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = VirtualCollector.fetch_virtual_facts(NetBSDVirtual)

    assert virtual_facts.get('virtualization_type') == 'kvm'
    assert 'virtualization_role' not in virtual_facts

# Generated at 2022-06-23 02:33:56.653849
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    facts = {'kernel': 'NetBSD'}
    NetBSDVirtualCollector(facts).collect()

# Generated at 2022-06-23 02:34:06.277665
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    hypervisor_facts = NetBSDVirtual().get_virtual_facts()
    assert hypervisor_facts and isinstance(hypervisor_facts, dict), \
        'get_virtual_facts should return a dict of facts, or an empty dict.'
    assert 'virtualization_type' in hypervisor_facts.keys(), \
        'get_virtual_facts should include virtualization_type.'
    assert 'virtualization_role' in hypervisor_facts.keys(), \
        'get_virtual_facts should include virtualization_role.'
    assert 'virtualization_tech_guest' in hypervisor_facts.keys(), \
        'get_virtual_facts should include virtualization_tech_guest.'
    assert 'virtualization_tech_host' in hypervisor_facts.keys(), \
        'get_virtual_facts should include virtualization_tech_host.'
   

# Generated at 2022-06-23 02:34:09.519062
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual(None)
    assert isinstance(virtual_facts, NetBSDVirtual)
    assert isinstance(virtual_facts, Virtual)
    assert isinstance(virtual_facts, VirtualSysctlDetectionMixin)


# Generated at 2022-06-23 02:34:11.121820
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    detector = NetBSDVirtual()
    assert(isinstance(detector, NetBSDVirtual))


# Generated at 2022-06-23 02:34:13.728515
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virtual_collector = NetBSDVirtualCollector()

    assert virtual_collector.platform == 'NetBSD'
    assert virtual_collector._fact_class == NetBSDVirtual
