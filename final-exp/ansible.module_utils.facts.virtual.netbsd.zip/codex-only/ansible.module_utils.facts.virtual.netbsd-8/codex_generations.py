

# Generated at 2022-06-23 02:24:18.139858
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    sysctl_mock = {
        'machdep.dmi.system-product': 'VirtualBox',
        'machdep.dmi.system-vendor': 'Oracle Corporation',
        'machdep.hypervisor': 'None'
    }

    v = NetBSDVirtual(sysctl_facts = sysctl_mock)

    # Assert values when machdep.hypervisor is 'None'
    virtual_facts = v.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'virtualbox'
    assert virtual_facts['virtualization_role'] == 'guest'

    # Assert values when machdep.hypervisor isn't 'None'
    sysctl_mock['machdep.hypervisor'] = 'BHYVE'
    virtual_facts = v.get_virtual_facts()

# Generated at 2022-06-23 02:24:19.602424
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd = NetBSDVirtual()
    assert netbsd.platform == 'NetBSD'

# Generated at 2022-06-23 02:24:28.406978
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.netbsd import NetBSDVirtual

    # Create a new instance of NetBSDVirtual class
    v = NetBSDVirtual()

    # If ls is found, set it in path
    if v.module.get_bin_path("ls"):
        path = os.environ['PATH']
        os.environ['PATH'] = "{0}:/sbin".format(path)

    m = v.module
    # Get the output of 'sysctl -a' as dictionary

# Generated at 2022-06-23 02:24:31.280054
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    nv = NetBSDVirtualCollector()
    assert nv._fact_class == NetBSDVirtual
    assert nv._platform == 'NetBSD'


# Generated at 2022-06-23 02:24:32.801139
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual._platform == 'NetBSD'

# Generated at 2022-06-23 02:24:38.042926
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virt_facts = NetBSDVirtual()
    facts = {'machdep.dmi.system-product': 'Some_Product', 'machdep.dmi.system-vendor': 'Some_Vendor', 'ansible_product_name': '', 'ansible_system': ''}
    virtual_facts = virt_facts.get_virtual_facts(facts)
    assert virtual_facts is not None
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'

# Generated at 2022-06-23 02:24:42.156516
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual = NetBSDVirtualCollector()
    assert netbsd_virtual._platform == 'NetBSD'
    assert netbsd_virtual._fact_class.platform == 'NetBSD'
    assert repr(netbsd_virtual)

# Generated at 2022-06-23 02:24:44.848801
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    results = NetBSDVirtual({}).get_virtual_facts()
    assert results


if __name__ == '__main__':
    test_NetBSDVirtual_get_virtual_facts()

# Generated at 2022-06-23 02:24:51.068070
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    # Check re-loading of NetBSDVirtualCollector class
    unload_module(mod_name='ansible.module_utils.facts.virtual.netbsd')
    NetBSDVirtualCollector()
    # Check re-loading of NetBSDVirtualCollector class again
    unload_module(mod_name='ansible.module_utils.facts.virtual.netbsd')
    NetBSDVirtualCollector()

# Generated at 2022-06-23 02:24:53.874950
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    result = NetBSDVirtualCollector()
    assert result.platform == 'NetBSD'
    assert isinstance(result.virts, NetBSDVirtual)


# Generated at 2022-06-23 02:25:02.076335
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    test_fixture = {
        'machdep.hypervisor': 'QEMU',
        'machdep.dmi.system-product': 'VirtualBox',
        'machdep.dmi.system-vendor': 'innotek GmbH',
    }
    module = AnsibleModule(argument_spec={})
    module.exit_json = lambda **kwargs: kwargs
    module.run_command = lambda command: (0, test_fixture.get(command, ''), None)

    nbsd_virtual = NetBSDVirtual(module)
    virtual_facts = nbsd_virtual.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == 'virtualbox'
    assert virtual_facts['virtualization_role'] == 'guest'

# Generated at 2022-06-23 02:25:10.047871
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.netbsd import NetBSDVirtual
    nv = NetBSDVirtual(module=None)
    host_tech = set()
    guest_tech = set()
    virtual_facts = {}
    virtual_product_facts = nv.detect_virt_product('machdep.dmi.system-product')
    guest_tech.update(virtual_product_facts['virtualization_tech_guest'])
    host_tech.update(virtual_product_facts['virtualization_tech_host'])
    virtual_facts.update(virtual_product_facts)

    virtual_vendor_facts = nv.detect_virt_vendor('machdep.dmi.system-vendor')

# Generated at 2022-06-23 02:25:21.195666
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    fixture_path = os.path.join(os.path.dirname(__file__), 'fixtures', 'NetBSD')
    data = {}

    for filename in os.listdir(fixture_path):
        if filename.endswith('.fact'):
            with open(os.path.join(fixture_path, filename), 'r') as f:
                data['netbsd_' + filename.split('.')[0]] = eval(f.read())

    nbsd = NetBSDVirtual(data)
    virtual_facts = nbsd.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == data['netbsd_virtualization_type']
    assert virtual_facts['virtualization_role'] == data['netbsd_virtualization_role']

# Generated at 2022-06-23 02:25:22.575136
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    NetBSDVirtualCollector()

# Generated at 2022-06-23 02:25:27.767964
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    obj = NetBSDVirtual()
    assert obj.platform == 'NetBSD'
    assert obj.virtualization_type == ''
    assert obj.virtualization_role == ''
    assert obj.virtualization_tech_guest == set()
    assert obj.virtualization_tech_host == set()

    # Unit test for method get_virtual_facts
    obj._get_virtual_facts = lambda: {'virtualization_type': 'KVM'}
    assert obj._get_virtual_facts() == {'virtualization_type': 'KVM'}

# Generated at 2022-06-23 02:25:29.454550
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    x = NetBSDVirtualCollector()
    assert x.platform == x._platform

# Generated at 2022-06-23 02:25:31.957500
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector._platform == 'NetBSD'
    assert NetBSDVirtualCollector._fact_class == NetBSDVirtual

# Generated at 2022-06-23 02:25:41.358419
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    test_data_dir = os.path.dirname(os.path.realpath(__file__))
    test_data_path = os.path.join(test_data_dir, 'ipvs.yaml')
    mock_module = get_mock_module(test_data_path)
    # Create a NetBSDVirtualCollector instance
    inst = NetBSDVirtualCollector(mock_module)
    # Call method get_virtual_facts
    facts = inst._fact_class.get_virtual_facts(inst)
    # Assert 'virtualization_type' is not ''
    assert facts['virtualization_type'] != ''
    # Assert 'virtualization_role' is 'guest'
    assert facts['virtualization_role'] == 'guest'

# Generated at 2022-06-23 02:25:46.670103
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual_facts = NetBSDVirtual().get_virtual_facts()
    assert netbsd_virtual_facts['virtualization_type'] == ''
    assert netbsd_virtual_facts['virtualization_role'] == ''
    assert netbsd_virtual_facts['virtualization_tech_guest'] == set()
    assert netbsd_virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-23 02:25:48.368291
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert isinstance(NetBSDVirtualCollector(), NetBSDVirtualCollector)

# Generated at 2022-06-23 02:25:58.811212
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    srcdata = {}
    srcdata['machdep.dmi.system-product'] = 'VirtualBox'
    srcdata['machdep.dmi.system-vendor'] = 'Oracle Corporation'
    srcdata['machdep.hypervisor'] = 'VirtualBox'
    srcdata['machdep.xen.guest'] = 'NetBSD 7.2'
    srcdata['machdep.xen.guest_major'] = '7'
    srcdata['machdep.xen.guest_minor'] = '2'
    srcdata['machdep.xen.guest_version'] = '7.2'
    srcdata['machdep.xen.guest_vendor'] = 'The NetBSD Foundation, Inc.'

    virtual = NetBSDVirtual()

# Generated at 2022-06-23 02:26:00.231176
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    v = NetBSDVirtual({})
    assert v.platform == 'NetBSD'

# Generated at 2022-06-23 02:26:02.032376
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtualFactCollector = NetBSDVirtualCollector()
    assert virtualFactCollector._fact_class is NetBSDVirtual

# Generated at 2022-06-23 02:26:11.221356
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual()
    virtual_facts._LSB_RELEASE_CONTENT = """
    NetBSD 3.2 (INSTALL) #5: Wed May 25 10:12:01 PDT 2005
        user@:~$
    """
    virtual_facts._SYSCTL_MACHDEP_CONTENT = """
    machdep.dmi.system-manufacturer: VMware, Inc.
    machdep.dmi.system-product: VMware Virtual Platform
    machdep.dmi.system-version: None
    machdep.hypervisor: unknown
    """
    virtual_facts._SYSCTL_MACHDEP_HYPERVISOR_CONTENT = """
    machdep.hypervisor: BHYVE
    """

# Generated at 2022-06-23 02:26:22.395094
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual = NetBSDVirtual(platform='NetBSD')
    sysctl_get = {
        'machdep.dmi.system-product': 'VirtualBox',
        'machdep.dmi.system-vendor': 'innotek GmbH',
        'machdep.hypervisor': 'innotek GmbH',
        'machdep.cpu.brand_string': 'Intel(R) Xeon(R) CPU           E5450  @ 3.00GHz',
    }

    def _file_exists(path):
        if path == '/dev/xencons':
            return True
        if path == '/proc/xen':
            return False
        if path == '/proc/cpuinfo':
            return True
        # If a different file path is asked, return False
        return False


# Generated at 2022-06-23 02:26:24.702311
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual_facts = NetBSDVirtual(None, None)
    assert netbsd_virtual_facts.platform == 'NetBSD'

# Generated at 2022-06-23 02:26:35.206139
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    '''Unit test for method get_virtual_facts of class NetBSDVirtual'''
    virtual_facts = NetBSDVirtual().get_virtual_facts()
    assert isinstance(virtual_facts, dict)
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert isinstance(virtual_facts['virtualization_tech_host'], set)
    assert virtual_facts['virtualization_tech_host'].issubset(set(['xen', 'kvm', 'vmware',
                                                                   'microsoft', 'oracle', 'parallels',
                                                                   'hyperv']))

# Generated at 2022-06-23 02:26:43.320957
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual = NetBSDVirtual()
    virtual_facts = virtual.get_virtual_facts()
    if virtual_facts:
        assert isinstance(virtual_facts['virtualization_type'], str)
        assert isinstance(virtual_facts['virtualization_role'], str)
        assert isinstance(virtual_facts['virtualization_system'], str)
        assert isinstance(virtual_facts['virtualization_uuid'], str)
        assert isinstance(virtual_facts['virtualization_tech_guest'], set)
        assert isinstance(virtual_facts['virtualization_tech_host'], set)

# Generated at 2022-06-23 02:26:45.073327
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual(None)

    assert virtual.platform == 'NetBSD'


# Generated at 2022-06-23 02:26:55.275666
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():

    sysctl_ret = {
            'machdep.dmi.system-product': '',
            'machdep.dmi.system-vendor': '',
            'machdep.hypervisor': '',
            }

    virtual_facts = {
            'virtualization_type': '',
            'virtualization_role': '',
            'virtualization_tech_guest': {},
            'virtualization_tech_host': {},
            }

    # For 'machdep.dmi.system-vendor'
    test_obj = NetBSDVirtual()
    test_obj.sysctl = lambda param: ''
    test_obj.detect_virt_vendor = lambda arg: ''

    # For 'machdep.dmi.system-product'

# Generated at 2022-06-23 02:27:00.250551
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts_output = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': set(),
    }

    netbsdvirtual = NetBSDVirtual()
    virtual_facts = netbsdvirtual.get_virtual_facts()

    assert virtual_facts == virtual_facts_output


# Generated at 2022-06-23 02:27:04.881746
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    # test the type of object returned
    collector = NetBSDVirtualCollector()
    assert isinstance(collector, NetBSDVirtualCollector)
    # test the type of NetBSDVirtualCollector._platform attr
    assert isinstance(collector._platform, str)
    # test the type of NetBSDVirtualCollector._fact_class attr
    assert isinstance(collector._fact_class, type)

# Generated at 2022-06-23 02:27:08.008142
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual(None, {})
    assert virtual_facts.platform == 'NetBSD'
    assert virtual_facts.get_virtual_facts() == {}

# Generated at 2022-06-23 02:27:10.015411
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    new_NetBSDVirtual = NetBSDVirtual()
    assert new_NetBSDVirtual is not None


# Generated at 2022-06-23 02:27:11.430191
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual()
    assert virtual is not None


# Generated at 2022-06-23 02:27:14.426586
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    # Ensure constructor sets correct values
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.platform == 'NetBSD'
    assert netbsd_virtual.virtual_tech is not None


# Generated at 2022-06-23 02:27:24.203853
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Create the instance of NetBSDVirtual
    netbsd_virtual = NetBSDVirtual({})

    # Test virtualization_type and virtualization_role is 'guest'
    setattr(netbsd_virtual, '_get_sysctl_value', lambda *args: 'Xen')
    assert(netbsd_virtual.get_virtual_facts()['virtualization_type'] == 'xen')
    assert(netbsd_virtual.get_virtual_facts()['virtualization_role'] == 'guest')

    # Test virtualization_type is 'kvm' and virtualization_role is 'guest'
    setattr(netbsd_virtual, '_get_sysctl_value', lambda *args: 'innotek GmbH')

# Generated at 2022-06-23 02:27:26.130942
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    x = NetBSDVirtualCollector()
    assert x._fact_class == NetBSDVirtual
    assert x._platform == 'NetBSD'

# Generated at 2022-06-23 02:27:28.308358
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual()
    assert virtual_facts.platform == 'NetBSD'

# Generated at 2022-06-23 02:27:36.414004
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():

    # Get a dict of facts with 'virtualization_type' and 'virtualization_role'
    # as key and its corresponding empty value as value.
    expected = {
        'virtualization_type': 'xen',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['xen']),
        'virtualization_tech_host': set(['xen']),
    }

    # Create a instance of NetBSDVirtual class and assign a list of tuples
    # containing the key and corresponding value of sysctl variable to
    # 'sysctl' variable of instance of NetBSDVirtual class.
    netbsd_virtual = NetBSDVirtual()

# Generated at 2022-06-23 02:27:38.742015
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.platform == 'NetBSD'


# Generated at 2022-06-23 02:27:40.999045
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    c = NetBSDVirtualCollector()
    assert c._fact_class is NetBSDVirtual
    assert c._platform == 'NetBSD'

# Generated at 2022-06-23 02:27:43.731206
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual_obj = NetBSDVirtual(None)
    netbsd_virtual_obj.collect()
    assert netbsd_virtual_obj.platform == 'NetBSD'

# Generated at 2022-06-23 02:27:45.973148
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    vc = NetBSDVirtualCollector()
    assert vc is not None

# Generated at 2022-06-23 02:27:47.412548
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    nv = NetBSDVirtual()
    assert nv is not None

# Generated at 2022-06-23 02:27:48.378057
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    vm = NetBSDVirtual()
    assert vm is not None

# Generated at 2022-06-23 02:27:50.120175
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    instance = NetBSDVirtualCollector()
    assert instance._platform == 'NetBSD'


# Generated at 2022-06-23 02:27:53.034833
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Instance a NetBSDVirtual object to test get_virtual_facts method
    facts_instance = NetBSDVirtual()

    # The object facts should be a dictionary
    assert isinstance(facts_instance.get_virtual_facts(), dict)


# Generated at 2022-06-23 02:27:55.700149
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd = NetBSDVirtualCollector()
    assert isinstance(netbsd, NetBSDVirtualCollector)


# Generated at 2022-06-23 02:28:00.082468
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_guest'] == set([u'xen'])
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-23 02:28:01.569282
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual(None)
    assert virtual._platform == 'NetBSD'

# Generated at 2022-06-23 02:28:03.537879
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    v = NetBSDVirtual(dict())
    assert isinstance(v, NetBSDVirtual)

# Generated at 2022-06-23 02:28:08.553021
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert isinstance(netbsd_virtual_collector, NetBSDVirtualCollector)
    assert netbsd_virtual_collector._platform == 'NetBSD'
    assert netbsd_virtual_collector._fact_class == NetBSDVirtual


# Generated at 2022-06-23 02:28:10.465352
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    """Test constructor of class `NetBSDVirtualCollector`."""
    NetBSDVirtualCollector()

# Generated at 2022-06-23 02:28:11.957523
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual_fact_instance = NetBSDVirtual()
    netbsd_virtual_fact_instance.get_virtual_facts()

# Generated at 2022-06-23 02:28:13.935629
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual()

    assert virtual.platform == 'NetBSD'


# Generated at 2022-06-23 02:28:15.382339
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector(None, None, None).collect()

# Generated at 2022-06-23 02:28:16.373437
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    assert NetBSDVirtual()


# Generated at 2022-06-23 02:28:17.128037
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    NetBSDVirtualCollector()

# Generated at 2022-06-23 02:28:20.566928
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_NetBSDVirtual = NetBSDVirtual()
    assert virtual_NetBSDVirtual.platform == 'NetBSD'

# Generated at 2022-06-23 02:28:31.224494
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    fake_sysctl_result = '''machdep.dmi.system-product: VMware Virtual Platform
machdep.dmi.system-version: None
machdep.dmi.system-serial-number: VMware-42 19 73 d8 b8 5c 34 6c-6e 77 d6 10 51 b4 b8 9f
machdep.dmi.system-uuid: 421973D8-B85C-3464-6E77-D610518B89F1
machdep.dmi.system-vendor: VMware, Inc.
machdep.hypervisor: NetBSD/x86 64-bit Xen 4.2.0'''


# Generated at 2022-06-23 02:28:33.152955
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector._platform == 'NetBSD'
    assert NetBSDVirtualCollector._fact_class == NetBSDVirtual

# Generated at 2022-06-23 02:28:35.903352
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert netbsd_virtual_collector.__class__.__name__ == 'NetBSDVirtualCollector'

# Generated at 2022-06-23 02:28:44.337153
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual = NetBSDVirtual(module=None)

    netbsd_virtual.sysctl_all_data = {
        'machdep.dmi.system-product': 'test_product',
        'machdep.dmi.system-vendor': 'test_vendor',
        'machdep.hypervisor': 'test_hypervisor',
    }
    assert netbsd_virtual.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_product': 'test_product',
        'virtualization_vendor': 'test_vendor',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }


# Generated at 2022-06-23 02:28:46.724874
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual_instance = NetBSDVirtual()
    assert netbsd_virtual_instance.platform == 'NetBSD'

# Generated at 2022-06-23 02:28:51.558564
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual import NetBSDVirtual
    NetBSDVirtualObject = NetBSDVirtual()
    assert NetBSDVirtualObject.get_virtual_facts() == {'virtualization_type': 'kvm', 'virtualization_role': 'guest'}

# Generated at 2022-06-23 02:28:56.684580
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    collector = NetBSDVirtualCollector()
    fact_class = collector._fact_class
    assert fact_class._platform == 'NetBSD'
    assert issubclass(fact_class, Virtual)
    assert issubclass(fact_class, VirtualSysctlDetectionMixin)

# Generated at 2022-06-23 02:29:01.187531
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    assert issubclass(NetBSDVirtual, Virtual)
    assert issubclass(NetBSDVirtual, VirtualSysctlDetectionMixin)
    assert isinstance(NetBSDVirtual(module=None), Virtual)
    assert isinstance(NetBSDVirtual(module=None), VirtualSysctlDetectionMixin)

# Generated at 2022-06-23 02:29:06.243717
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual(module=None)
    assert netbsd_virtual.platform == 'NetBSD'
    assert netbsd_virtual.virtualization_type is None
    assert netbsd_virtual.virtualization_role is None
    assert netbsd_virtual.virtualization_system is None
    assert netbsd_virtual.virtualization_hypervisor is None

# Generated at 2022-06-23 02:29:15.964387
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    fixture_dir = os.path.dirname(__file__) + '/fixtures/'
    fixture_file = 'sysctl_mib_netbsd.txt'
    netbsd_virtual = NetBSDVirtual(module=None, collector=None)
    netbsd_virtual._module.params['gather_subset'] = ['!all', 'virtual']
    netbsd_virtual.sysctl_all = netbsd_virtual.read_file(fixture_dir + fixture_file)

    # Test for VirtualBox
    output = netbsd_virtual.get_virtual_facts()
    assert output['virtualization_type'] == 'virtualbox'
    assert output['virtualization_role'] == 'guest'
    assert 'virtualbox' in output['virtualization_tech']

# Generated at 2022-06-23 02:29:17.218692
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual = NetBSDVirtual()
    assert virtual.get_virtual_facts()

# Generated at 2022-06-23 02:29:19.365166
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    """Unit test for constructor of class NetBSDVirtualCollector."""
    assert isinstance(NetBSDVirtualCollector(), NetBSDVirtualCollector)


# Generated at 2022-06-23 02:29:20.338966
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    NetBSDVirtualCollector()

# Generated at 2022-06-23 02:29:21.996974
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    x = NetBSDVirtual()
    assert x.platform == 'NetBSD'


# Generated at 2022-06-23 02:29:23.481344
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_netbsd = NetBSDVirtual()
    assert virtual_netbsd

# Generated at 2022-06-23 02:29:25.854827
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virtual_collector = NetBSDVirtualCollector()

    assert virtual_collector._fact_class == NetBSDVirtual
    assert virtual_collector._platform == 'NetBSD'

# Generated at 2022-06-23 02:29:32.727088
# Unit test for method get_virtual_facts of class NetBSDVirtual

# Generated at 2022-06-23 02:29:34.466765
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
   assert NetBSDVirtualCollector._platform in NetBSDVirtualCollector.collectors

# Generated at 2022-06-23 02:29:36.229915
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    nv_collector = NetBSDVirtualCollector()
    assert nv_collector.platform == 'NetBSD'

# Generated at 2022-06-23 02:29:38.911597
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virt = NetBSDVirtual()

    assert 'virtualization_type' in virt.get_virtual_facts()
    assert 'virtualization_role' in virt.get_virtual_facts()
    assert 'virtualization_tech_guest' in virt.get_virtual_facts()
    assert 'virtualization_tech_host' in virt.get_virtual_facts()

# Generated at 2022-06-23 02:29:44.687553
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virt_facts = NetBSDVirtualCollector().collect()

    assert isinstance(virt_facts, dict)

    for required_key in ('virtualization_role', 'virtualization_type', 'virtualization_technologies'):
        assert required_key in virt_facts, "retrieved virtual facts should contain {0}".format(required_key)


# Generated at 2022-06-23 02:29:47.199370
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd = NetBSDVirtual(None, None)
    assert netbsd.platform == 'NetBSD'



# Generated at 2022-06-23 02:29:55.518031
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virt_facts = NetBSDVirtual().get_virtual_facts()

    # Test NetBSDVirtual().get_virtual_facts() method of NetBSDVirtual class
    # when machdep.dmi.system-vendor sysctl is empty
    assert isinstance(virt_facts, dict)
    assert 'virtualization_type' in virt_facts
    assert 'virtualization_role' in virt_facts
    assert 'virtualization_tech_guest' in virt_facts
    assert 'virtualization_tech_host' in virt_facts

    # Test NetBSDVirtual().get_virtual_facts() method of NetBSDVirtual class
    # when machdep.dmi.system-vendor sysctl is not empty
    assert isinstance(virt_facts, dict)
    assert 'virtualization_type' in virt_facts
    assert 'virtualization_role' in virt_facts

# Generated at 2022-06-23 02:29:59.392463
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual()
    assert virtual_facts.collect()['virtualization_type'] == ''

# Generated at 2022-06-23 02:30:01.601282
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts_class = NetBSDVirtual()
    assert virtual_facts_class.platform == 'NetBSD'

# Generated at 2022-06-23 02:30:05.322322
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector.__name__ == "NetBSDVirtualCollector"
    assert NetBSDVirtualCollector._platform == "NetBSD"
    assert NetBSDVirtualCollector._fact_class == NetBSDVirtual


# Generated at 2022-06-23 02:30:06.708126
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    obj = NetBSDVirtual()
    assert obj.platform == 'NetBSD'

# Generated at 2022-06-23 02:30:09.585936
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    """Check for the instantiation of NetBSD Virtual class.
    """
    nb_virtual = NetBSDVirtual(None)
    assert nb_virtual.platform == 'NetBSD'



# Generated at 2022-06-23 02:30:13.457153
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd = NetBSDVirtual({})
    assert netbsd.platform == 'NetBSD'
    assert netbsd.sysctl_base_path == '/netbsd'
    assert netbsd.virtualization_type == ''
    assert netbsd.virtualization_role == ''


# Generated at 2022-06-23 02:30:16.161615
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd = NetBSDVirtual()
    assert netbsd.platform == 'NetBSD'

# Generated at 2022-06-23 02:30:19.094726
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.platform == 'NetBSD'
    assert netbsd_virtual.collector_class == NetBSDVirtualCollector

# Generated at 2022-06-23 02:30:29.948311
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virt = NetBSDVirtual()
    virt.sysctl = {'machdep.dmi.system-product': 'VirtualBox',
                   'machdep.dmi.system-vendor': 'innotek GmbH',
                   'machdep.hypervisor': 'vbox',
                   'machdep.cpu.arch': 'x86'}

# Generated at 2022-06-23 02:30:33.931133
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    collector = NetBSDVirtualCollector()
    assert collector._fact_class == NetBSDVirtual
    assert collector._platform == 'NetBSD'

# Generated at 2022-06-23 02:30:36.464912
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    facts = NetBSDVirtual()
    assert facts._platform == 'NetBSD'
    assert facts._fact_class == NetBSDVirtual
    assert isinstance(facts, Virtual)
    assert len(facts.get_virtual_facts()) == 6

# Generated at 2022-06-23 02:30:40.929454
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual()
    assert virtual_facts.platform == 'NetBSD'
    assert virtual_facts.virtualization_type == ''
    assert virtual_facts.virtualization_role == ''

# Generated at 2022-06-23 02:30:42.513878
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    collector = NetBSDVirtualCollector()
    assert collector._platform == 'NetBSD'

# Generated at 2022-06-23 02:30:44.788401
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual_obj = NetBSDVirtual()
    assert netbsd_virtual_obj.platform == 'NetBSD'

# Generated at 2022-06-23 02:30:46.297485
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd = NetBSDVirtual()
    assert netbsd.platform == 'NetBSD'


# Generated at 2022-06-23 02:30:58.467591
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual = NetBSDVirtual({})
    # make sysctl executable.
    os.chmod = lambda x, y: 0
    # Capture sysctl output as an array of lines.
    os.popen = lambda x: open("test/units/modules/virtual/NetBSDVirtual_data.txt",
                              'r')

    netbsd_virtual_facts = netbsd_virtual.get_virtual_facts()
    # First test if the results of above method has matched with the expected
    # output.
    assert netbsd_virtual_facts['virtualization_role'] == 'guest'
    assert netbsd_virtual_facts['virtualization_type'] == 'xen'
    # Test if the virtualization_tech_guest has the expected set of technologies.

# Generated at 2022-06-23 02:31:00.962491
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    facts = NetBSDVirtual({})
    result = facts.get_virtual_facts()
    assert result['virtualization_role'] == ''
    assert 'virtualization_type' not in result

# Generated at 2022-06-23 02:31:04.541137
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    import json

    # Build input parameters
    raw_result = {}

    # Build expected results

# Generated at 2022-06-23 02:31:07.264782
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    nv = NetBSDVirtualCollector()
    assert nv.platform == 'NetBSD'
    assert nv.fact_class == NetBSDVirtual


# Generated at 2022-06-23 02:31:18.873560
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.netbsd import NetBSDVirtual
    fact_class = NetBSDVirtual()
    #  call the method with unsupported parameter
    with pytest.raises(AttributeError):
        fact_class.get_virtual_facts('something unexpected')
    # call the method with None parameter
    virtual_facts = fact_class.get_virtual_facts(None)
    # check the result
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_system'] == ''
    assert virtual_facts['virtualization_product'] == ''
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-23 02:31:21.139712
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.__class__.__name__ == 'NetBSDVirtual'

# Generated at 2022-06-23 02:31:24.719044
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert netbsd_virtual_collector.platform == 'NetBSD'

# Generated at 2022-06-23 02:31:35.790524
# Unit test for method get_virtual_facts of class NetBSDVirtual

# Generated at 2022-06-23 02:31:40.116899
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert issubclass(NetBSDVirtualCollector, VirtualCollector)


# Generated at 2022-06-23 02:31:49.272551
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.netbsd import NetBSDVirtual
    from ansible.module_utils.facts.virtual.sysctl import VirtualSysctlDetectionMixin
    NetBSDVirtual._detect_virt_product = lambda self, sysctl: {'virtualization_type': 'product',
                                                               'virtualization_role': 'guest'}
    NetBSDVirtual._detect_virt_vendor = lambda self, sysctl: {'virtualization_type': 'vendor',
                                                              'virtualization_role': 'host'}

    virtual_facts = NetBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'product'
    assert virtual_facts['virtualization_role'] == 'guest'

# Generated at 2022-06-23 02:31:50.496882
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    NetBSDVirtualCollector()

# Generated at 2022-06-23 02:31:53.410283
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    bsdVirtual = NetBSDVirtual()
    assert bsdVirtual.platform == 'NetBSD'


# Generated at 2022-06-23 02:31:54.728672
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual()
    assert virtual.platform == 'NetBSD'

# Generated at 2022-06-23 02:31:59.594854
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert netbsd_virtual_collector._platform == 'NetBSD'
    assert isinstance(netbsd_virtual_collector._fact_class, NetBSDVirtual)

# Generated at 2022-06-23 02:32:06.658836
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    # Test when not on NetBSD
    virtual_collector = NetBSDVirtualCollector(None, 'foo', {})
    assert virtual_collector._fact_class is None
    assert virtual_collector._platform == 'foo'
    assert virtual_collector._variables == {}

    # Test when on NetBSD
    virtual_collector = NetBSDVirtualCollector(None, 'NetBSD', {})
    assert virtual_collector._fact_class is not None
    assert virtual_collector._platform == 'NetBSD'
    assert virtual_collector._variables == {}

# Generated at 2022-06-23 02:32:07.952175
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    assert NetBSDVirtual(None).platform == 'NetBSD'


# Generated at 2022-06-23 02:32:14.114852
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual({}).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert len(virtual_facts['virtualization_tech_host']) == 0
    assert len(virtual_facts['virtualization_tech_guest']) == 0

# Generated at 2022-06-23 02:32:19.558492
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual().get_virtual_facts()
    assert type(virtual_facts['virtualization_tech_guest']) == set
    assert type(virtual_facts['virtualization_tech_host']) == set
    assert virtual_facts['virtualization_type'] in ('', 'xen')
    assert virtual_facts['virtualization_role'] in ('', 'guest')

# Generated at 2022-06-23 02:32:24.246985
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.platform == 'NetBSD'
    assert netbsd_virtual.virtualization_type == ''
    assert netbsd_virtual.virtualization_role == ''
    assert not netbsd_virtual.virtualization_tech_host
    assert not netbsd_virtual.virtualization_tech_guest

# Generated at 2022-06-23 02:32:26.466619
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual().get_virtual_facts()
    # There is nothing to test right now
    assert virtual_facts is not None


# Generated at 2022-06-23 02:32:34.476308
# Unit test for method get_virtual_facts of class NetBSDVirtual

# Generated at 2022-06-23 02:32:37.212093
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual(None)
    assert virtual._platform == 'NetBSD'


# Generated at 2022-06-23 02:32:40.753482
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    facts = NetBSDVirtual().get_virtual_facts()

    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts
    assert 'virtualization_tech_host' in facts
    assert 'virtualization_tech_guest' in facts

# Generated at 2022-06-23 02:32:45.840550
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    # Create a NetBSDVirtualCollector instance
    virtual_collector = NetBSDVirtualCollector()

    # Ensure the created instance is of the correct class
    assert isinstance(virtual_collector, NetBSDVirtualCollector)

if __name__ == "__main__":
    test_NetBSDVirtualCollector()

# Generated at 2022-06-23 02:32:47.430230
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virt = NetBSDVirtualCollector()
    assert virt.platform == 'NetBSD'


# Generated at 2022-06-23 02:32:52.384997
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual = NetBSDVirtual()
    netbsd_virtual.sysctl_read_sysctl_all = lambda: (
        {'hw.product': 'Google Compute Engine', 'machdep.hypervisor': 'Google'},
    )

    virtual_facts = netbsd_virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'gce'
    assert virtual_facts['virtualization_role'] == 'guest'

# Generated at 2022-06-23 02:33:03.610934
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():

    # Create a dummy class to hold the results - this is passed by reference
    # in the test
    class FakeModule(object):
        pass

    module = FakeModule()
    module.sysctl = {}

    # Create a dummy NetBSDVirtual collector
    v = NetBSDVirtual(module)

    # Create the output that sysctl would return - this is a dictionary
    # containing key/value pairs from sysctl
    sysctl_output = {'machdep.dmi.system-vendor': 'QEMU',
                     'machdep.dmi.system-product': 'Standard PC (i440FX + PIIX, 1996)',
                     'machdep.hypervisor': 'Foo'}
    v.get_machine_info(sysctl_output)

    # Call the module
    v.get_virtual_facts()

    #

# Generated at 2022-06-23 02:33:13.853026
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    import json
    import tempfile
    from collections import namedtuple

    # Create namedtuple object, so it behaves like a class
    # pylint: disable=invalid-name
    FixtureClass = namedtuple("FixtureClass", "content_type, content")

    # Create fixtures
    fixture_sysctl_machdep_dmi_system_product = FixtureClass('text/x-shellscript', '''
# $NetBSD: syscons.c,v 1.15 2005/02/26 22:26:48 perry Exp $
echo "VirtualBox"
''')

# Generated at 2022-06-23 02:33:18.873026
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual = NetBSDVirtual()
    result = netbsd_virtual.get_virtual_facts()
    assert result['virtualization_type'] == ''
    assert result['virtualization_role'] == ''
    assert bool(result['virtualization_tech_guest']) is False
    assert bool(result['virtualization_tech_host']) is False

# Generated at 2022-06-23 02:33:28.677145
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Create virtual product facts
    virtual_product_facts = {'virtualization_type': 'parallel', 'virtualization_role': 'guest'}

    # Create virtual vendor facts
    virtual_vendor_facts = {'virtualization_type': 'oracle', 'virtualization_role': 'host'}

    # Create virtual facts
    virtual_facts = {'virtualization_type': '', 'virtualization_role': '', 'virtualization_tech_guest': set(),
                     'virtualization_tech_host': set()}

    get_mock = lambda x: (x == 'machdep.dmi.system-product') and virtual_product_facts or virtual_vendor_facts
    # Create instance of NetBSDVirtual class
    virtual_netbsd = NetBSDVirtual()
    virtual_netbsd.detect_virt_

# Generated at 2022-06-23 02:33:39.965938
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    facts = {'ansible_distribution': 'NetBSD'}
    data = {'machdep.dmi.system-product': 'VirtualBox', 'machdep.dmi.system-vendor': 'Oracle Corporation', 'machdep.hypervisor': 'VirtualBox'}
    sysctl = {'sysctl.ordered_facts': False, 'sysctl.facts': data}
    expected_facts = {'virtualization_type': '', 'virtualization_role': ''}
    expected_facts['virtualization_tech_guest'] = set()
    expected_facts['virtualization_tech_host'] = set()
    expected_facts['virtualization_product_facts'] = {'product_name': '', 'product_version': ''}

    collector = NetBSDVirtualCollector(facts, sysctl)

# Generated at 2022-06-23 02:33:44.024739
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual()
    assert virtual_facts.platform == 'NetBSD'
    assert sorted(virtual_facts.get_virtual_facts().keys()) == sorted([
        'virtualization_role', 'virtualization_type',
        'virtualization_tech_guest', 'virtualization_tech_host'
    ])

# Generated at 2022-06-23 02:33:49.556105
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    """
    Return virtual fact information for NetBSD system
    """

    # Create an instance of NetBSDVirtual
    virtual_facts = NetBSDVirtual()

    # Invoke get_virtual_facts method
    virtual_fact_data = virtual_facts.get_virtual_facts()

    # Assertion
    assert virtual_fact_data['virtualization_type'] == ''
    assert virtual_fact_data['virtualization_role'] == ''



# Generated at 2022-06-23 02:33:53.581239
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virtual_collector = NetBSDVirtualCollector()
    assert virtual_collector is not None


# Generated at 2022-06-23 02:33:57.472663
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Check that facts are returned when sysctl is not broken

    # Arrange
    testing = NetBSDVirtual()

    # Act
    facts = testing.get_virtual_facts()

    # Assert
    assert facts is not None


# Generated at 2022-06-23 02:34:06.847796
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():

    # Test for virtualization type
    def test_virtualization_type(data):
        test_facts = {
            'ansible_virtualization_type': data[0],
            'ansible_virtualization_role': data[1],
            'ansible_virtualization_technology_guest': set(data[2]),
            'ansible_virtualization_technology_host': set(data[3])
        }
        collector = NetBSDVirtualCollector(module=None)
        facts = collector.collect(module=None, collected_facts=None)
        if facts != test_facts:
            raise AssertionError("Virtual facts mismatch! Expected: {}, Actual: {}".format(test_facts, facts))

    # type: xen, role: guest

# Generated at 2022-06-23 02:34:09.575993
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Make sure get_virtual_facts returns a dict
    assert isinstance(NetBSDVirtual(None).get_virtual_facts(), dict)


# Generated at 2022-06-23 02:34:11.888071
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsdvirtualcollector = NetBSDVirtualCollector()
    assert netbsdvirtualcollector._fact_class is not None
    assert netbsdvirtualcollector._platform is not None