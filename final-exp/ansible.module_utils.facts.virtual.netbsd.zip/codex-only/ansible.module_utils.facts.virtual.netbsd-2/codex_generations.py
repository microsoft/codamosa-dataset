

# Generated at 2022-06-23 02:24:12.716071
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual({},{})
    assert netbsd_virtual.platform == 'NetBSD'


# Generated at 2022-06-23 02:24:15.409166
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    vm = NetBSDVirtual()
    assert vm.platform == 'NetBSD'



# Generated at 2022-06-23 02:24:23.566174
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual = NetBSDVirtual({})
    fake_platform_virtual_fact = {'virtualization_role': u'guest',
                                  'virtualization_type': 'VMWare',
                                  'virtualization_tech_host': 'kvm',
                                  'virtualization_tech_guest': 'openvz'}
    # First test if get_virtual_facts from NetBSDVirtual return virtual_facts
    assert netbsd_virtual.get_virtual_facts()
    # Second test if the values inside the dictionary are correct
    assert fake_platform_virtual_fact == netbsd_virtual.get_virtual_facts()

# Generated at 2022-06-23 02:24:30.255119
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual(module=None).get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_system' in virtual_facts
    assert 'virtualization_hypervisor' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-23 02:24:36.378479
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():

    class TestFacts:
        def __init__(self, data={}):
            self.data = data

    data = {
        'virtualization_type': "kvm",
        'virtualization_role': "guest",
        'virtualization_tech_guest': set(['kvm']),
        'virtualization_tech_host': set(['kvm'])
    }
    facts = TestFacts(data)
    collector = NetBSDVirtualCollector(facts, {})
    assert collector._platform == 'NetBSD'
    assert collector._fact_class.__name__ == 'NetBSDVirtual'

# Generated at 2022-06-23 02:24:38.361437
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    # Given, When
    virt_facts = NetBSDVirtual()

    # Then
    assert virt_facts.platform == 'NetBSD'

# Generated at 2022-06-23 02:24:50.492205
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    def machdep_get_sysctl_mock(path):
        path = path.lower()
        if path == 'machdep.hypervisor':
            return 'amd rvi'
        if path == 'machdep.dmi.system-vendor':
            return 'VirtualBox'
        if path == 'machdep.dmi.system-product':
            return 'VirtualBox'
        return ''

    def os_path_exists_mock(path):
        path = path.lower()
        if path == '/dev/xencons':
            return True
        return False

    facts_dict = NetBSDVirtual(machdep_get_sysctl=machdep_get_sysctl_mock,
                               os_path_exists=os_path_exists_mock).get_virtual_facts()

   

# Generated at 2022-06-23 02:24:53.282625
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    # Check the class is correctly instantiated
    nbsd_virtual = NetBSDVirtualCollector()
    assert(nbsd_virtual.fact_class.platform == 'NetBSD')

# Generated at 2022-06-23 02:24:59.649793
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec=dict()
    )
    result = NetBSDVirtual(module).get_virtual_facts()
    assert result['virtualization_type'] == 'kvm'
    assert result['virtualization_role'] == 'guest'

test_doc = '''
---
module: test_get_virtual_facts
short_description: test module
version_added: None
description:
  - test module
author:
    - Petr Michalec
'''

from ansible.module_utils.basic import *  # noqa



# Generated at 2022-06-23 02:25:05.603542
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    result = dict(ansible_facts={}, changed=False, skipped=False, msg='')
    obj = NetBSDVirtualCollector(result)
    assert obj._platform is 'NetBSD'
    assert obj._fact_class is NetBSDVirtual
    assert obj._result == result

# Generated at 2022-06-23 02:25:11.197847
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    # Make sure that both platform and fact_class are set.
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert netbsd_virtual_collector._platform == 'NetBSD'
    assert netbsd_virtual_collector._fact_class is NetBSDVirtual


# Generated at 2022-06-23 02:25:15.240960
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_fact = NetBSDVirtualCollector()
    assert netbsd_virtual_fact._platform == 'NetBSD'
    assert netbsd_virtual_fact._fact_class.platform == 'NetBSD'


# Generated at 2022-06-23 02:25:16.588753
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert issubclass(NetBSDVirtualCollector, VirtualCollector)


# Generated at 2022-06-23 02:25:25.274864
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # fake sysctl values for unit test
    fake_sysctl_machdep_dmi_system_vendor = """
machdep.dmi.system-vendor: VMware, Inc.
"""
    fake_sysctl_machdep_dmi_system_product = """
machdep.dmi.system-product: VMware Virtual Platform
"""

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )

    netbsd_virtual = NetBSDVirtual(module)

    # initial values
    virtual_facts = netbsd_virtual.get_virtual_facts()
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_type'] == ''

# Generated at 2022-06-23 02:25:27.602806
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    collector = NetBSDVirtualCollector()
    assert collector.fact_class._platform == 'NetBSD'


# Generated at 2022-06-23 02:25:32.065302
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual = NetBSDVirtual()
    result = netbsd_virtual.get_virtual_facts()
    assert result['virtualization_type'] == 'xen'
    assert result['virtualization_role'] == 'guest'

# Generated at 2022-06-23 02:25:40.747319
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual = NetBSDVirtual()

    with open("unit/ansible/module_utils/facts/virtual/test_netbsd_virtual.txt") as netbsd_virtual_txt:
        netbsd_virtual_output = netbsd_virtual_txt.read()
        netbsd_virtual_data = {
            'virtualization_type': '',
            'virtualization_role': '',
            'virtualization_tech_guest': set([]),
            'virtualization_tech_host': set([])}
        assert netbsd_virtual.get_virtual_facts(netbsd_virtual_output) == netbsd_virtual_data

# Generated at 2022-06-23 02:25:46.858003
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Given
    facts = {}
    virtual = NetBSDVirtual(module=None, facts=facts)

    # When
    virtual_facts = virtual.get_virtual_facts()

    # Then
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_guest'] == ['xen']
    assert virtual_facts['virtualization_tech_host'] == []

# Generated at 2022-06-23 02:25:49.172994
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virtual_collector = NetBSDVirtualCollector()
    assert virtual_collector.platform == 'NetBSD'

# Generated at 2022-06-23 02:25:52.887602
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual()
    assert virtual.platform == 'NetBSD'

# Generated at 2022-06-23 02:25:54.275415
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual({})
    assert virtual.platform == 'NetBSD'

# Generated at 2022-06-23 02:25:56.077700
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.platform == 'NetBSD'

# Generated at 2022-06-23 02:26:03.430479
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual(None).get_virtual_facts()
    assert 'virtualization_type' in virtual_facts.keys()
    assert 'virtualization_role' in virtual_facts.keys()
    assert 'virtualization_tech_guest' in virtual_facts.keys()
    assert 'virtualization_tech_host' in virtual_facts.keys()
    assert virtual_facts['virtualization_type'] in ['host', 'guest', '']
    assert virtual_facts['virtualization_role'] in ['host', 'guest', '']

# Generated at 2022-06-23 02:26:12.426653
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts(): # pylint: disable=too-many-locals
    from unittest import TestCase
    from ansible.module_utils.facts.virtual.netbsd import NetBSDVirtual

    class NetBSDVirtualFactsTestCase(TestCase):

        def setUp(self):
            self.netbsd = NetBSDVirtual()

        def tearDown(self):
            pass

        def test_get_virtual_facts_none(self):
            self.netbsd.sysctl_values = {}
            self.netbsd.sysctl_values['machdep.dmi.system-vendor'] = ''
            self.netbsd.sysctl_values['machdep.dmi.system-product'] = ''
            self.netbsd.sysctl_values['machdep.hypervisor'] = ''


# Generated at 2022-06-23 02:26:14.535865
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_obj = NetBSDVirtual()
    assert virtual_obj.platform == 'NetBSD'

# Generated at 2022-06-23 02:26:16.359062
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd = NetBSDVirtual()
    assert isinstance(netbsd, NetBSDVirtual)

# Generated at 2022-06-23 02:26:19.387475
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert issubclass(NetBSDVirtualCollector, VirtualCollector)
    assert NetBSDVirtualCollector._platform == 'NetBSD'
    assert NetBSDVirtualCollector._fact_class is NetBSDVirtual


# Generated at 2022-06-23 02:26:28.938133
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd = NetBSDVirtual()
    assert isinstance(netbsd, NetBSDVirtual)
    assert isinstance(netbsd.platform, str)
    assert netbsd.platform == 'NetBSD'
    assert isinstance(netbsd.get_virtual_facts(), dict)
    assert netbsd.get_virtual_facts().get('virtualization_type') == ''
    assert netbsd.get_virtual_facts().get('virtualization_role') == ''
    assert isinstance(netbsd.get_virtual_facts().get('virtualization_tech_guest'), set)
    assert isinstance(netbsd.get_virtual_facts().get('virtualization_tech_host'), set)


# Generated at 2022-06-23 02:26:30.893279
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virt = NetBSDVirtual(None)
    assert virt.platform == 'NetBSD'

# Generated at 2022-06-23 02:26:33.931405
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    nbsd = NetBSDVirtual(None)
    assert isinstance(nbsd, NetBSDVirtual)
    assert not nbsd.subtype
    assert dict == type(nbsd.facts)



# Generated at 2022-06-23 02:26:34.979183
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():

    assert NetBSDVirtual().platform == 'NetBSD'

# Generated at 2022-06-23 02:26:45.356413
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    def get_mock_sysctl_data(path):
        sysctl_files = {
            'machdep.dmi.system-product': 'Mock Product',
            'machdep.dmi.system-vendor': 'Mock Vendor',
            'machdep.hypervisor': 'Mock Hypervisor',
        }

        if path in sysctl_files:
            return sysctl_files[path]
        else:
            return None

    module_original = NetBSDVirtualCollector._module
    NetBSDVirtualCollector._module = lambda self: None

    def set_module_original():
        NetBSDVirtualCollector._module = module_original


# Generated at 2022-06-23 02:26:48.996189
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd = NetBSDVirtual()
    facts = netbsd.get_virtual_facts()

    # Check that the facts collection return is not empty
    assert facts is not None
    assert facts['virtualization_type'] == None
    assert facts['virtualization_role'] == None

# Generated at 2022-06-23 02:26:50.482156
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    c = NetBSDVirtualCollector()
    assert c.platform == 'NetBSD'

# Generated at 2022-06-23 02:26:53.089522
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    facts = NetBSDVirtualCollector()
    assert facts._platform == 'NetBSD'
    assert facts._fact_class == NetBSDVirtual


# Generated at 2022-06-23 02:26:57.150698
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.platform == 'NetBSD'
    assert netbsd_virtual.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_technologies': [],
    }

# Generated at 2022-06-23 02:26:59.548459
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsdvirtual = NetBSDVirtual()

    assert netbsdvirtual._platform == 'NetBSD'
    assert netbsdvirtual._fact_class == NetBSDVirtual

# Generated at 2022-06-23 02:27:00.855287
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    data = {}
    obj = NetBSDVirtualCollector(data)
    assert isinstance(obj, object)

# Generated at 2022-06-23 02:27:02.331378
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert isinstance(NetBSDVirtualCollector(), VirtualCollector)


# Generated at 2022-06-23 02:27:06.656350
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    '''Unit test for constructor of NetBSDVirtual'''

    netbsd_virtual_object = NetBSDVirtual()
    assert netbsd_virtual_object.get_virtual_facts() == {
        'virtualization_role': 'guest',
        'virtualization_type': 'xen',
        'virtualization_tech_guest': set(['xen']),
        'virtualization_tech_host': set([])
    }


# Generated at 2022-06-23 02:27:10.623356
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():

    # Create an instance of NetBSDVirtual to use for this test
    obj = NetBSDVirtual()

    # Run the method get_virtual_facts and capture the result
    result = obj.get_virtual_facts()

    # Check the result
    assert bool(result)


# Generated at 2022-06-23 02:27:12.890288
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector._platform == 'NetBSD'
    assert NetBSDVirtualCollector._fact_class == NetBSDVirtual


# Generated at 2022-06-23 02:27:15.450577
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    # We're not testing anything here as this function is
    # empty. This is a temporary workaround.
    obj = NetBSDVirtualCollector()
    assert obj is not None

# Generated at 2022-06-23 02:27:25.053287
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    fact = NetBSDVirtual({'ansible_facts': {'kernel': 'NetBSD'}})

    # Mock the sysctl call
    # See: man sysctl
    fact.get_file_lines.return_value = [
        'machdep.dmi.system-product = "VirtualBox"',
        'machdep.dmi.system-vendor = "innotek GmbH"',
        'machdep.hypervisor = "VirtualBox"',
        'machdep.hv_vendor = "Oracle"',
        'machdep.hv_version = "0x00010000"',
        'machdep.hv_tsc_freq = "0"',
    ]

    # Call get_virtual_facts method
    ret = fact.get_virtual_facts()

    # Check if the

# Generated at 2022-06-23 02:27:25.604845
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    NetBSDVirtual()

# Generated at 2022-06-23 02:27:28.431278
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.platform == 'NetBSD'


# Generated at 2022-06-23 02:27:30.991216
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    """Test the constructor of NetBSDVirtual"""
    virtual = NetBSDVirtual({})
    assert virtual._facts['virtualization_type'] == ''



# Generated at 2022-06-23 02:27:34.184152
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector._platform == 'NetBSD'
    assert NetBSDVirtualCollector._fact_class == NetBSDVirtual

# Generated at 2022-06-23 02:27:39.835019
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual().get_virtual_facts()

    if virtual_facts['virtualization_type'] == 'xen':
        assert 'xen' in virtual_facts['virtualization_tech_guest']
    else:
        assert not virtual_facts['virtualization_tech_guest']

    assert virtual_facts['virtualization_role'] in ['guest', 'host']

# Generated at 2022-06-23 02:27:50.386012
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    facts = {}
    facts['virtualization_type'] = ''
    facts['virtualization_role'] = ''
    facts['virtualization_technologies'] = set()
    facts['virtualization_technologies_guest'] = set()
    facts['virtualization_technologies_host'] = set()
    facts['virtualization_product_name'] = ''

    virtual = NetBSDVirtual(module=None)
    sysctl_output = {'machdep.hypervisor': 'KVM', 'machdep.dmi.system-product': 'VMware Virtual Platform',
                     'machdep.dmi.system-vendor': 'VMware, Inc.'}
    virtual.sysctl = sysctl_output
    virtual_facts = virtual.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == 'kvm'
   

# Generated at 2022-06-23 02:27:54.939559
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsdVirtualCollector = NetBSDVirtualCollector()
    assert netbsdVirtualCollector._fact_class == NetBSDVirtual
    assert netbsdVirtualCollector._platform == 'NetBSD'


# Generated at 2022-06-23 02:27:56.653090
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual(None)
    assert isinstance(netbsd_virtual, NetBSDVirtual)

# Generated at 2022-06-23 02:27:58.618923
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    vc = NetBSDVirtualCollector()
    assert vc._platform == 'NetBSD'
    assert vc._fact_class.platform == 'NetBSD'

# Generated at 2022-06-23 02:28:00.261481
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    v_collector = NetBSDVirtualCollector()
    assert v_collector._platform == 'NetBSD'

# Generated at 2022-06-23 02:28:07.050670
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    module = AnsibleModule(argument_spec={})
    fixture = NetBSDVirtual({'module': module})

    virtual_facts = fixture.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert {'xen'} == virtual_facts['virtualization_tech_guest']
    assert {'xen'} == virtual_facts['virtualization_tech_host']

# Generated at 2022-06-23 02:28:10.678516
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert netbsd_virtual_collector._platform == 'NetBSD'
    assert netbsd_virtual_collector._fact_class == NetBSDVirtual


# Generated at 2022-06-23 02:28:14.190929
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    my_obj = NetBSDVirtual()
    assert my_obj.platform == 'NetBSD'
    assert my_obj.virtualization_type == ''
    assert my_obj.virtualization_role == ''


# Generated at 2022-06-23 02:28:15.957874
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector._platform == 'NetBSD'
    assert NetBSDVirtualCollector._fact_class == NetBSDVirtual

# Generated at 2022-06-23 02:28:18.491455
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual({}).get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts

# Generated at 2022-06-23 02:28:20.732785
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.platform == 'NetBSD'

# Generated at 2022-06-23 02:28:28.296988
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():  # pylint: disable=invalid-name
    def fake_sysctl(predicate, *args, **kwargs):  # pylint: disable=unused-argument
        return "VirtualBox"
    virtual = NetBSDVirtual()
    virtual.sysctl = fake_sysctl
    result = virtual.get_virtual_facts()
    assert result['virtualization_type'] == 'VirtualBox'
    assert result['virtualization_role'] == 'guest'
    assert 'virtualbox' in result['virtualization_tech_guest']


# Generated at 2022-06-23 02:28:34.135364
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual = NetBSDVirtual()
    virtual_facts = netbsd_virtual.get_virtual_facts()

    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-23 02:28:35.551077
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    NetBSDVirtual(None, None, None).collect()

# Generated at 2022-06-23 02:28:43.459977
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual().get_virtual_facts()

    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert isinstance(virtual_facts['virtualization_tech_guest'], set)
    assert isinstance(virtual_facts['virtualization_tech_host'], set)
    assert 'xen' in virtual_facts['virtualization_tech_guest']
    assert 'xen' not in virtual_facts['virtualization_tech_host']

# Generated at 2022-06-23 02:28:46.171345
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    # No exception is error
    assert NetBSDVirtualCollector()


# Unit tests for functions in class NetBSDVirtual

# Generated at 2022-06-23 02:28:56.596745
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    from ansible.utils.shlex import shlex_split
    from ansible.module_utils.facts.virtual.sysctl import VirtualSysctlDetectionMixin
    process = os.popen('sysctl machdep.hypervisor', 'r')
    output = process.read()
    assert process.close() is None
    hypervisor = output.split('=', 1)[1].strip()


# Generated at 2022-06-23 02:28:59.507579
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual = NetBSDVirtual()
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'xen'

# Generated at 2022-06-23 02:29:06.545918
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    netbsd_virtual_facts = netbsd_virtual_collector.get_virtual_facts()
    assert isinstance(netbsd_virtual_facts, dict)
    assert 'virtualization_type' in netbsd_virtual_facts
    assert 'virtualization_role' in netbsd_virtual_facts
    assert 'virtualization_tech_host' in netbsd_virtual_facts
    assert 'virtualization_tech_guest' in netbsd_virtual_facts

# Generated at 2022-06-23 02:29:08.356099
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virt = NetBSDVirtual({})
    assert virt.platform == 'NetBSD'


# Generated at 2022-06-23 02:29:11.707390
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    detector = NetBSDVirtual(module=dict())
    facts = detector.get_virtual_facts()
    assert facts['virtualization_type'] == ''
    assert facts['virtualization_role'] == ''
    assert facts['virtualization_interfaces'] == ''

# Generated at 2022-06-23 02:29:19.525055
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    class FakeOsModule(object):
        class FakePath(object):
            def exists(self, arg):
                return False

    module = FakeOsModule()
    module.path = FakeOsModule.FakePath()
    virtual_facts = NetBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()
    assert virtual_facts['virtualization_product_name'] == ''
    assert virtual_facts['virtualization_product_version'] == ''

# Generated at 2022-06-23 02:29:22.311464
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual({})
    assert netbsd_virtual is not None


# Generated at 2022-06-23 02:29:23.718483
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual()
    assert virtual.platform == 'NetBSD'

# Generated at 2022-06-23 02:29:26.756271
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netBSDVirtualCollector = NetBSDVirtualCollector()
    assert netBSDVirtualCollector is not None
    assert netBSDVirtualCollector._fact_class is NetBSDVirtual
    assert netBSDVirtualCollector._platform is 'NetBSD'


# Generated at 2022-06-23 02:29:28.182740
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    NetBSDVirtualCollector()

# Generated at 2022-06-23 02:29:31.460635
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector._platform == 'NetBSD'
    assert NetBSDVirtualCollector._fact_class == NetBSDVirtual
    assert NetBSDVirtualCollector.collect() == NetBSDVirtual().get_virtual_facts()



# Generated at 2022-06-23 02:29:34.199030
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtu

# Generated at 2022-06-23 02:29:40.734258
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virtual_facts = NetBSDVirtualCollector().collect()
    assert 'ansible_virtualization_type' in virtual_facts
    assert 'ansible_virtualization_role' in virtual_facts
    assert 'ansible_virtualization_technologies_guest' in virtual_facts
    assert 'ansible_virtualization_technologies_host' in virtual_facts
    assert 'ansible_virtualization_role_guest' in virtual_facts
    assert 'ansible_virtualization_role_host' in virtual_facts

# Generated at 2022-06-23 02:29:44.053026
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert netbsd_virtual_collector.platform == "NetBSD"
    assert netbsd_virtual_collector.fact_class == NetBSDVirtual

# Generated at 2022-06-23 02:29:53.675770
# Unit test for method get_virtual_facts of class NetBSDVirtual

# Generated at 2022-06-23 02:30:04.756080
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Test for virtualization type/role of Xen
    # Returned value should be "xen" and "guest"
    class CollectedFacts:
        def __init__(self, sysctl_dict):
            self.sysctl = sysctl_dict

    virtual_facts = NetBSDVirtual()
    sysctl_dict = {'machdep.dmi.system-product': 'Xen', 'machdep.hypervisor': ''}
    collected_facts = CollectedFacts(sysctl_dict)

    virtual_facts.get_virtual_facts(collected_facts)
    assert virtual_facts.virtualization_type == 'xen'
    assert virtual_facts.virtualization_role == 'guest'

    # Test for virtualization type/role of VMWare
    # Returned value should be "vmware" and "gu

# Generated at 2022-06-23 02:30:07.551539
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert(netbsd_virtual_collector.__class__.__name__ == 'NetBSDVirtualCollector')
    assert(netbsd_virtual_collector._fact_class.__name__ == 'NetBSDVirtual')

# Generated at 2022-06-23 02:30:10.966527
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    """Test NetBSDVirtualCollector constructor"""
    nv_collector = NetBSDVirtualCollector()
    assert nv_collector._fact_class == NetBSDVirtual
    assert nv_collector._platform == 'NetBSD'

# Generated at 2022-06-23 02:30:17.860630
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    from ansible_collections.community.general.tests.unit.compat.mock import patch
    module = patch('ansible.module_utils.facts.virtual.netbsd.NetBSDVirtual.get_sysctl_value').start()
    module.return_value = ''
    netbsd_virtual = NetBSDVirtual(module)
    expected_result = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': set()
    }
    result = netbsd_virtual.get_virtual_facts()
    assert result == expected_result
    module.assert_not_called()

# Generated at 2022-06-23 02:30:20.306544
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    v = NetBSDVirtual()
    assert v.platform == 'NetBSD'
    assert v.get_virtual_facts() == {}

# Generated at 2022-06-23 02:30:21.353380
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    NetBSDVirtualCollector()

# Generated at 2022-06-23 02:30:22.161823
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    assert NetBSDVirtual()

# Generated at 2022-06-23 02:30:25.767593
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    x = NetBSDVirtualCollector()
    assert x.platform == "NetBSD"
    assert x._platform == "NetBSD"
    assert x.fact_class == NetBSDVirtual
    assert x._fact_class == NetBSDVirtual

# Generated at 2022-06-23 02:30:29.187943
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    x = NetBSDVirtualCollector()
    assert x.platform == 'NetBSD'
    assert x._fact_class.platform == 'NetBSD'

# Generated at 2022-06-23 02:30:31.374108
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virt = NetBSDVirtual()
    assert isinstance(netbsd_virt, NetBSDVirtual)


# Generated at 2022-06-23 02:30:33.234223
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    import doctest
    failed, tests = doctest.testmod(NetBSDVirtualCollector)
    assert failed == 0


# Generated at 2022-06-23 02:30:35.321647
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual = NetBSDVirtualCollector()
    assert netbsd_virtual._platform == 'NetBSD'
    assert netbsd_virtual._fact_class == NetBSDVirtual

# Generated at 2022-06-23 02:30:38.758622
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net = NetBSDVirtual()
    assert net.platform == net.get_virtual_facts()['ansible_virtualization_type']

# Generated at 2022-06-23 02:30:40.995794
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virt = NetBSDVirtual()
    assert virt.platform == 'NetBSD'


# Generated at 2022-06-23 02:30:46.983032
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # We do not need to test specifics here, only the general flow and that keys
    # are present, as NetBSDVirtual is just a wrapper around multiple other
    # classes.
    nv = NetBSDVirtual()
    assert nv.get_virtual_facts()
    assert nv.get_virtual_facts() == {
        'virtualization_role': 'guest',
        'virtualization_type': 'kvm',
        'virtualization_tech_guest': set(['kvm']),
        'virtualization_tech_host': set(['kvm']),
    }

# Generated at 2022-06-23 02:30:58.855085
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    sysctl1 = {'machdep.dmi.system-product': 'VMware Virtual Platform',
               'machdep.dmi.system-vendor': 'VMware, Inc.',
               'machdep.hypervisor': '',
               }
    sysctl2 = {'machdep.dmi.system-product': 'innotek GmbH VirtualBox',
               'machdep.dmi.system-vendor': 'innotek GmbH',
               'machdep.hypervisor': '',
               }
    sysctl3 = {'machdep.dmi.system-product': 'Microsoft Virtual Machine',
               'machdep.dmi.system-vendor': 'Microsoft Corporation',
               'machdep.hypervisor': '',
               }

# Generated at 2022-06-23 02:31:06.763957
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():

    # Initialize class
    netbsd_virtual = NetBSDVirtual()
    netbsd_virtual.get_virtual_facts()

    # Check if virtualization_type is set to 'xen'
    assert virtual_facts['virtualization_type'] == 'xen'

    # Check if virtualization_role is set to 'guest'
    assert virtual_facts['virtualization_role'] == 'guest'

    # Test if virtualization_tech_guest contains 'xen'
    assert 'xen' in virtual_facts['virtualization_tech_guest']

# Generated at 2022-06-23 02:31:15.226007
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():

    # Build an instance of NetBSDVirtual, call
    # method get_virtual_facts and check the result.
    # For now we just add a stub for this method
    # to test it and make sure it doesn't throw an error.
    #
    # This unit test needs to be extended to check
    # if the virtual facts returned by the method
    # get_virtual_facts are valid.

    # Expect: call to get_virtual_facts does not throw an error.
    NetBSDVirtual().get_virtual_facts()

# Generated at 2022-06-23 02:31:16.537681
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual(None, None)
    assert virtual.platform == "NetBSD"

# Generated at 2022-06-23 02:31:24.209307
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    '''
        Unit test for method get_virtual_facts of class NetBSDVirtual
        Ansible Fact platform has to be one of ['Linux', 'OpenBSD', 'NetBSD', 'FreeBSD', 'Darwin', 'SunOS', 'AIX']
        Output is a dict, virtualization_type can be both guest or host
        dict:
            type:
            role:
            technology:
    '''

    netbsd_virtual = NetBSDVirtualCollector()

    # Virtualization type for NetBSD

# Generated at 2022-06-23 02:31:27.888244
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    nbv = NetBSDVirtual()
    assert nbv.platform == 'NetBSD'
    assert nbv.virtualization_type == ''
    assert nbv.virtualization_role == ''


# Generated at 2022-06-23 02:31:37.879567
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Create a NetBSDVirtual object
    nbvirt_obj = NetBSDVirtual(module=None)

    # Return value of method get_virtual_facts
    return_value = nbvirt_obj.get_virtual_facts()

    assert return_value['virtualization_type'] == 'xen'
    assert return_value['virtualization_role'] == 'guest'
    assert 'xen' in return_value['virtualization_tech_guest']
    # Assert that get_virtual_facts returns a dict
    assert isinstance(return_value, dict)

    # Return value of method detect_virt_product
    return_value = nbvirt_obj.detect_virt_product('machdep.dmi.system-product')

    assert return_value['virtualization_type'] == ''

# Generated at 2022-06-23 02:31:40.704523
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    instance = NetBSDVirtual()
    assert isinstance(instance.get_virtual_facts(), dict)

# Generated at 2022-06-23 02:31:44.104650
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    """
    This function is used to unit test the constructor of class NetBSDVirtualCollector
    :return:
    """
    collector = NetBSDVirtualCollector()
    assert collector.platform == 'NetBSD'
    assert collector._fact_class == NetBSDVirtual
    assert collector.order == 0

# Generated at 2022-06-23 02:31:53.020404
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual_facts = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': {},
        'virtualization_tech_host': {},
    }

    netbsd_virtual = NetBSDVirtual()
    facts = netbsd_virtual.get_virtual_facts()

    assert netbsd_virtual_facts.keys() == facts.keys()

# Generated at 2022-06-23 02:31:55.158314
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    '''Unit test of NetBSDVirtualCollector'''

    virt = NetBSDVirtualCollector()
    assert virt._platform == 'NetBSD'

# Generated at 2022-06-23 02:31:58.400305
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    c = NetBSDVirtualCollector()
    assert c
    assert c._platform == 'NetBSD'
    assert c._fact_class == NetBSDVirtual

# Generated at 2022-06-23 02:32:00.253250
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual().get_virtual_facts()
    assert 'virtualization_type' in virtual_facts

# Generated at 2022-06-23 02:32:07.161487
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual()
    assert virtual.platform == 'NetBSD'
    assert virtual._platform == 'NetBSD'
    assert virtual.virtualization_type == 'NetBSD'
    assert virtual.virtualization_role == 'NetBSD'
    assert virtual.virtualization_tech_guest.pop() == 'NetBSD'
    assert virtual.virtualization_tech_host.pop() == 'NetBSD'
    assert virtual.virtualization_tech_guest.pop() == 'NetBSD'
    assert virtual.virtualization_tech_host.pop() == 'NetBSD'


# Generated at 2022-06-23 02:32:14.862193
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virt = NetBSDVirtual()

    assert virt.platform == 'NetBSD'
    assert virt.virtualization_type == ''
    assert virt.virtualization_role == ''

    # Test host detection
    virt.sysctl = {
        'machdep.dmi.system-product': 'VMware Virtual Platform',
        'machdep.dmi.system-vendor': 'VMware, Inc.',
    }

    assert virt.get_virtual_facts()['virtualization_type'] == 'VMware'
    assert virt.get_virtual_facts()['virtualization_role'] == 'host'
    assert 'vmware' in virt.get_virtual_facts()['virtualization_tech_host']

    # Test guest detection

# Generated at 2022-06-23 02:32:25.025666
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_class = NetBSDVirtual()
    hypervisor_values = ['Amazon EC2', 'Microsoft Hyper-V']
    product_values = ['KVM', 'VirtualBox', 'VMware Virtual Platform']

    # Case 1: Virtualization type of NetBSD host will be 'virtualbox'
    virtual_class.sysctl_values['machdep.dmi.system-vendor'] = 'innotek GmbH'
    virtual_class.sysctl_values['machdep.dmi.system-product'] = 'VirtualBox'

# Generated at 2022-06-23 02:32:27.556150
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert isinstance(netbsd_virtual_collector, NetBSDVirtualCollector)


# Generated at 2022-06-23 02:32:31.668125
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd = NetBSDVirtualCollector('netbsd')
    assert netbsd.platform == 'NetBSD'
    assert netbsd.fact_class == NetBSDVirtual


# Generated at 2022-06-23 02:32:38.667352
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    facter = NetBSDVirtual('/nonexistent')
    assert facter.virtualization_type == ''
    assert facter.virtualization_role == ''
    assert facter.virtualization_tech_guest == set()
    assert facter.virtualization_tech_host == set()

# Generated at 2022-06-23 02:32:41.761260
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual_obj = NetBSDVirtual()
    assert netbsd_virtual_obj.__module__ == 'ansible.module_utils.facts.virtual.netbsd'


# Generated at 2022-06-23 02:32:51.778029
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():

    virtual = NetBSDVirtual(
        module=None,
        sysctl_cmd='/sbin/sysctl',
        sysctl_exists=True,
        sysctl_debug=True,
        sysctl_args=['-n'],
        sysctl_get_cmd=['/sbin/sysctl', '-n'],
        sysctl_get_output='''
machdep.dmi.system-product=R2308WT2GS
machdep.dmi.system-vendor=Google
machdep.dmi.system-version=
machdep.dmi.system-serial-number=
machdep.dmi.system-uuid=00000000-0000-0000-0000-000000000000
machdep.hypervisor=
        ''',
    )

    virtual_facts = virtual.get_virtual_

# Generated at 2022-06-23 02:32:53.544925
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    # Constructing a NetBSDVirtualCollector object
    NetBSDVirtualCollector()

# Generated at 2022-06-23 02:33:00.285379
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    import sys
    sys.modules['ansible_netbsd_virtual_module'] = Virtual(None)
    try:
        netbsd_fact_module = NetBSDVirtual(None)
        netbsd_fact_module.get_virtual_facts()
    finally:
        del sys.modules['ansible_netbsd_virtual_module']


# Generated at 2022-06-23 02:33:04.747525
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virt = NetBSDVirtual()
    # For testing purposes, run this on all platforms first, then fix code to
    # only run on NetBSD.
    assert isinstance(virt.get_virtual_facts(), dict)

# Generated at 2022-06-23 02:33:14.386994
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():

    # Create instance of class NetBSDVirtual
    netbsd_virtual_ins = NetBSDVirtual()

    # Get values from section machdep.dmi.system-product
    with open('/sysctl.dmi.system-product', 'r') as f:
        content = f.read()

    # Set values for testing
    netbsd_virtual_ins.sysctl_all = {
        'machdep.dmi.system-product': content
    }

    # Get virtual facts
    virtual_facts = netbsd_virtual_ins.get_virtual_facts()

    # Assertion
    assert True

# Generated at 2022-06-23 02:33:17.508597
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    # Arrange
    facts_platform = 'NetBSD'

    # Act
    collector = NetBSDVirtualCollector()

    # Assert
    assert collector._fact_class._platform == facts_platform

# Generated at 2022-06-23 02:33:19.221004
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector()


# Generated at 2022-06-23 02:33:27.450812
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Create a mock of the file handle.
    sysctl_mock = FakePopen

    # Create an instance of NetBSDVirtual
    virtual_fact = NetBSDVirtual(sysctl_mock)
    virtual_fact_raw = virtual_fact.get_virtual_facts()

    # Asserts
    assert virtual_fact_raw['virtualization_type'] == 'xen'
    assert virtual_fact_raw['virtualization_role'] == 'guest'
    assert virtual_fact_raw['virtualization_tech_guest'] is not set()
    assert virtual_fact_raw['virtualization_tech_host'] == set(['xen'])



# Generated at 2022-06-23 02:33:29.896782
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virt = NetBSDVirtual({})
    assert virt.platform == "NetBSD"

# Generated at 2022-06-23 02:33:41.086926
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    """
    Test the get_virtual_facts method of NetBSDVirtual.

    Test conditions:

    (True, empty, empty) -> True
    (empty, True, empty) -> True
    (empty, empty, True) -> True
    (True, True, empty) -> True
    (True, empty, True) -> True
    (empty, True, True) -> True
    (True, True, True) -> True
    (True, False, True) -> False
    (True, True, False) -> False
    (False, True, True) -> False
    (True, False, False) -> False
    (False, True, False) -> False
    (False, False, True) -> False
    (False, False, False) -> False
    """
    f = NetBSDVirtual()


# Generated at 2022-06-23 02:33:43.649083
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd = NetBSDVirtual(None)
    assert netbsd.collector_class == NetBSDVirtualCollector
    assert netbsd.platform == 'NetBSD'

# Generated at 2022-06-23 02:33:46.472448
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_bsd_virtual_c = NetBSDVirtualCollector()
    assert net_bsd_virtual_c is not None
    assert net_bsd_virtual_c._platform == 'NetBSD'

# Generated at 2022-06-23 02:33:48.653982
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.platform == 'NetBSD'


# Generated at 2022-06-23 02:33:52.973142
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virtual_facts_collector = NetBSDVirtualCollector()
    assert virtual_facts_collector._fact_class == NetBSDVirtual
    assert virtual_facts_collector._platform == 'NetBSD'

# Generated at 2022-06-23 02:33:55.618503
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.platform == 'NetBSD'



# Generated at 2022-06-23 02:33:56.663030
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector._platform == 'NetBSD'

# Generated at 2022-06-23 02:33:57.416155
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    NetBSDVirtualCollector()

# Generated at 2022-06-23 02:34:05.090498
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual_obj = NetBSDVirtual()
    netbsd_virtual_obj.collect_sysctl_facts = lambda: dict(
        machdep=dict(
            hypervisor='',
            dmi=dict(
                system_vendor='',
                system_product=''
            )
        )
    )

# Generated at 2022-06-23 02:34:14.080434
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual = NetBSDVirtual()
    netbsd_virtual.get_virtual_facts = lambda: (
        'foo',  # virtualization_type
        'bar',  # virtualization_role
        set(),  # virtualization_tech_guest
        set(),  # virtualization_tech_host
        'baz',  # virtualization_system
    )
    facts = netbsd_virtual.get_facts()
    assert facts['virtualization_type'] == 'foo'
    assert facts['virtualization_role'] == 'bar'
    assert facts['virtualization_system'] == 'baz'