

# Generated at 2022-06-23 02:24:13.605143
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert isinstance(netbsd_virtual_collector, NetBSDVirtualCollector)
    assert isinstance(netbsd_virtual_collector._fact_class, NetBSDVirtual)
    assert netbsd_virtual_collector._platform == 'NetBSD'

# Generated at 2022-06-23 02:24:16.223451
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector._fact_class == NetBSDVirtual
    assert NetBSDVirtualCollector._platform == 'NetBSD'

# Generated at 2022-06-23 02:24:26.496611
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    '''Unit test to check if the virtual facts are properly returned by
    NetBSDVirtual class's get_virtual_facts() function.
    '''
    fake_sysctl_data = {
        'machdep.dmi.system-vendor': 'VMware, Inc.',
        'machdep.dmi.system-product': 'VMware Virtual Platform',
        'machdep.hypervisor': 'vmware',
    }
    fake_files = {
        '/dev/xencons': 'file'
    }

# Generated at 2022-06-23 02:24:29.060660
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual_obj = NetBSDVirtual()
    assert netbsd_virtual_obj.platform == 'NetBSD'

# Generated at 2022-06-23 02:24:31.421193
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    collector = NetBSDVirtualCollector()
    assert collector._platform == 'NetBSD'
    assert collector._fact_class == NetBSDVirtual


# Generated at 2022-06-23 02:24:32.803870
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert issubclass(NetBSDVirtualCollector, VirtualCollector)

# Generated at 2022-06-23 02:24:41.650914
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual = NetBSDVirtual()
    netbsd_virtual_facts = netbsd_virtual.get_virtual_facts()

    assert 'virtualization_type' in netbsd_virtual_facts
    assert 'virtualization_role' in netbsd_virtual_facts
    assert 'virtualization_tech_guest' in netbsd_virtual_facts
    assert 'virtualization_tech_host' in netbsd_virtual_facts

    if netbsd_virtual_facts['virtualization_type'] != '':
        assert netbsd_virtual_facts['virtualization_role'] != ''
    else:
        assert 'virtualization_type_facts' not in netbsd_virtual_facts

# Generated at 2022-06-23 02:24:43.965000
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert issubclass(NetBSDVirtualCollector, VirtualCollector)
    collector = NetBSDVirtualCollector()
    assert isinstance(collector, VirtualCollector)
    assert collector.platform == 'NetBSD'


# Generated at 2022-06-23 02:24:47.653648
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    """
    Test class constructor
    """
    virtual_facts = NetBSDVirtual()
    # Test method get_virtual_facts
    virtual_facts.get_virtual_facts()


# Generated at 2022-06-23 02:24:51.066248
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual._platform == 'NetBSD'
    assert netbsd_virtual._fact_class == NetBSDVirtual


# Generated at 2022-06-23 02:24:55.123113
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_facter = NetBSDVirtualCollector()
    netbsd_facter._platform = 'NetBSD'
    assert netbsd_facter._platform == 'NetBSD'
    assert netbsd_facter._fact_class == NetBSDVirtual


# Generated at 2022-06-23 02:24:57.162809
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    collector_class = NetBSDVirtualCollector

    # Constructor of class NetBSDVirtualCollector
    assert issubclass(collector_class, VirtualCollector)
    assert NetBSDVirtualCollector._fact_class is NetBSDVirtual
    assert NetBSDVirtualCollector._platform == 'NetBSD'

# Generated at 2022-06-23 02:25:04.728135
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_collector = NetBSDVirtualCollector()
    assert netbsd_collector.platform == 'NetBSD'
    assert netbsd_collector._fact_class == NetBSDVirtual


# Generated at 2022-06-23 02:25:06.501369
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virtual = NetBSDVirtualCollector()
    assert isinstance(virtual._fact_class, NetBSDVirtual)
    # assert virtual._platform == 'NetBSD'

# Generated at 2022-06-23 02:25:08.556807
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_bsd = NetBSDVirtualCollector()
    assert net_bsd._fact_class == NetBSDVirtual

# Generated at 2022-06-23 02:25:18.749391
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    """ Generate a set of virtual test cases """
    # Value of sysctl machdep.dmi.system-vendor is set to 'Google, Inc.'
    # Value of sysctl machdep.dmi.system-product is set to 'Google Compute Engine'
    # Value of sysctl machdep.hypervisor is set to 'Google'
    # Underlying hardware type is x86_64
    # Virtualization type is 'kvm'
    # Virtualization role is 'guest'
    # Virtualization technology are kvm, gce, gce_host

# Generated at 2022-06-23 02:25:19.894826
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector.__name__ == 'NetBSDVirtualCollector'

# Generated at 2022-06-23 02:25:23.893466
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert netbsd_virtual_collector.fact_class == NetBSDVirtual
    assert netbsd_virtual_collector.platform == 'NetBSD'

# Generated at 2022-06-23 02:25:24.922951
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    a = NetBSDVirtual()
    assert a != None


# Generated at 2022-06-23 02:25:31.943784
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    test_virtual = NetBSDVirtual({})
    assert test_virtual.get_virtual_facts()['virtualization_type'] == 'xen'
    assert test_virtual.get_virtual_facts()['virtualization_role'] == 'guest'
    assert test_virtual.get_virtual_facts()['virtualization_subtype'] == 'domu'
    assert test_virtual.get_virtual_facts()['virtualization_tech_guest'] == {'xen'}
    assert test_virtual.get_virtual_facts()['virtualization_tech_host'] == {'xen'}

# Generated at 2022-06-23 02:25:35.543339
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    # Check for values in constructor
    hv = NetBSDVirtual()
    assert hv
    assert hv._platform == 'NetBSD'
    assert hv.platform == 'NetBSD'
    assert hv.get_virtual_facts() == {}

# Generated at 2022-06-23 02:25:38.220049
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    result = NetBSDVirtualCollector()
    assert result._platform == "NetBSD"

# Generated at 2022-06-23 02:25:41.352784
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual({}, {}, {})
    assert virtual_facts._platform == 'NetBSD'
    assert virtual_facts.platform == 'NetBSD'
    assert not hasattr(virtual_facts, 'data')

# Generated at 2022-06-23 02:25:42.885475
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector._platform == 'NetBSD'
    assert NetBSDVirtualCollector._fact_class == NetBSDVirtual

# Generated at 2022-06-23 02:25:44.098121
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    tester = NetBSDVirtual
    tester.get_virtual_facts()

# Generated at 2022-06-23 02:25:45.856793
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    nv = NetBSDVirtualCollector()
    assert nv
    assert isinstance(nv.platform, str)

# Generated at 2022-06-23 02:25:49.027970
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.platform == 'NetBSD'
    assert netbsd_virtual._platform == 'NetBSD'

# Generated at 2022-06-23 02:25:57.826402
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    facts = NetBSDVirtual().get_virtual_facts()
    # Example facts to test
    # Facts are:
    #     {'virtualization_role': 'guest',
    #     'virtualization_type': 'xen',
    #     'virtualization_tech_guest': {'xen'},
    #     'virtualization_tech_host': {'xen'}}
    assert facts['virtualization_role'] == 'guest'
    assert facts['virtualization_type'] == 'xen'
    assert facts['virtualization_tech_guest'] == {'xen'}
    assert facts['virtualization_tech_host'] == {'xen'}

# Generated at 2022-06-23 02:26:00.902254
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual()
    assert virtual_facts.platform == 'NetBSD'
    # No need to test VirtualMixin methods, already tested in test_virtual.py


# Generated at 2022-06-23 02:26:03.065238
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual_obj = NetBSDVirtual()
    assert netbsd_virtual_obj.platform == 'NetBSD'


# Generated at 2022-06-23 02:26:06.062059
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual({})
    assert virtual.platform == 'NetBSD'
    assert virtual.collector == 'NetBSDVirtualCollector'
    assert virtual._facts == {}


# Generated at 2022-06-23 02:26:14.414206
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():

    class TestVirt():
        def __init__(self, test_vals):
            self.data = {}
            for item in test_vals:
                self.data[item['name']] = item['value']

        def __getitem__(self, item):
            if item in self.data:
                return self.data[item]
            else:
                return None


# Generated at 2022-06-23 02:26:16.785907
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    '''
    Test NetBSDVirtualCollector constructor
    '''
    assert NetBSDVirtualCollector._fact_class == NetBSDVirtual



# Generated at 2022-06-23 02:26:21.451794
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virt_collector = NetBSDVirtualCollector()
    assert netbsd_virt_collector is not None
    assert netbsd_virt_collector._fact_class == NetBSDVirtual
    assert netbsd_virt_collector._platform == 'NetBSD'

# Generated at 2022-06-23 02:26:24.224779
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
  assert NetBSDVirtualCollector.platform == 'NetBSD'
  assert NetBSDVirtualCollector.collect() is not None
  assert NetBSDVirtualCollector.get_virtual_facts() is not None

# Generated at 2022-06-23 02:26:32.032694
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual({}).get_virtual_facts()
    assert isinstance(virtual_facts['virtualization_tech_guest'], set)
    assert isinstance(virtual_facts['virtualization_tech_host'], set)
    assert virtual_facts['virtualization_type'] in ['', 'xen', 'vmware', 'kvm', 'virtualbox', 'parallels']
    assert virtual_facts['virtualization_role'] in ['guest', 'host']
    assert virtual_facts['virtualization_product_name'] in ['', 'ThinWare', 'Parallels']

# Generated at 2022-06-23 02:26:42.568812
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    '''
    Returns dict of virtual facts for NetBSD
    '''
    netbsd_virtual = NetBSDVirtual()
    # Set empty values for machdep.dmi.system-vendor and
    # machdep.dmi.system-product
    netbsd_virtual.sysctl = {
        'machdep.dmi.system-vendor': '',
        'machdep.dmi.system-product': ''}
    netbsd_virtual.get_virtual_facts()
    # Test if dict of virtual facts is not empty and if dict
    # has machdep.dmi.system-vendor
    assert netbsd_virtual.virtual_facts
    assert 'virtualization_type' in netbsd_virtual.virtual_facts
    assert 'virtualization_role' in netbsd_virtual.virtual_facts
   

# Generated at 2022-06-23 02:26:48.493420
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    module = VirtualCollector()
    virtual_facts = NetBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_type'] != ''
    assert virtual_facts['virtualization_role'] == 'guest'
    # VMware tools returns an empty string for machdep.dmi.system-vendor
    assert virtual_facts['virtualization_role'] != ''


# Generated at 2022-06-23 02:26:52.937672
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.netbsd import NetBSDVirtual
    virtual = NetBSDVirtual()
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'

# Generated at 2022-06-23 02:26:58.088637
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():

    # Create an instance of NetBSDVirtual
    test_instance = NetBSDVirtual()

    # Unit test the get_virtual_facts() method
    # We can only test the 'virtualization_type' value as the others will vary
    # depending on the system being tested on.
    test_virtual_facts = test_instance.get_virtual_facts()
    assert test_virtual_facts['virtualization_type'] in ['', 'xen']

# Generated at 2022-06-23 02:27:01.983853
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    expected_facts = {'virtualization_role': 'guest', 'virtualization_type': 'kvm'}
    test_virtual = NetBSDVirtual({})
    test_virtual.get_sysctl_value = lambda x: 'KVM'
    test_virtual.get_virtual_facts()
    assert test_virtual.facts == expected_facts

# Generated at 2022-06-23 02:27:11.600593
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # It is expected to pass this test.
    class TestFacts():
        def __init__(self):
            self.facts = {}
        def get(self, key):
            if key in self.facts:
                return self.facts[key]
            return None
        def set(self, key, value):
            self.facts[key] = value

    test_facts = TestFacts()
    test_facts.set('sysctl', {'machdep.dmi.system-product': 'VirtualBox',
                              'machdep.dmi.system-vendor': 'Oracle Corporation',
                              'machdep.hypervisor': 'Hypervisor'})
    test_virt = NetBSDVirtual(module=None, facts=test_facts)
    virtual_facts = test_virt.get_virtual_facts()
    assert virtual

# Generated at 2022-06-23 02:27:21.683559
# Unit test for method get_virtual_facts of class NetBSDVirtual

# Generated at 2022-06-23 02:27:23.736345
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    facts = NetBSDVirtualCollector(None, None).collect()
    assert 'Linux' in facts['ansible_virtualization_tech_guest']

# Generated at 2022-06-23 02:27:33.417606
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Parse a NetBSD6.2 DMI sysctl output
    sysctlfile = open("tests/unit/unittests/test_virtual_netbsd/sysctl_machdep.dmi.system-product")
    sysctloutput = sysctlfile.read()
    sysctlfile.close()

    # Parse a NetBSD 6.2 DMI sysctl output
    sysctlfile = open("tests/unit/unittests/test_virtual_netbsd/sysctl_machdep.dmi.system-vendor")
    sysctloutput2 = sysctlfile.read()
    sysctlfile.close()

    # Parse a NetBSD 7.0 amd64 hypervisor sysctl output

# Generated at 2022-06-23 02:27:35.842910
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual = NetBSDVirtualCollector()
    assert netbsd_virtual is not None


# Generated at 2022-06-23 02:27:43.045106
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual = NetBSDVirtual({})
    virtual_facts = virtual.get_virtual_facts()

    # The tests here do not check all of the virtual facts; this is
    # mainly due to the number of possibilities.
    assert virtual_facts['virtualization_type'] == \
           'xen'
    assert 'xen' in virtual_facts['virtualization_tech_guest']
    assert len(virtual_facts['virtualization_tech_guest']) == 1
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-23 02:27:53.316059
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Just the hypervisor name, empty virtualization_type
    hypervisor_sysctl = '''
machdep.hypervisor=vbox
'''
    with open('/proc/sysctl', 'w') as fh:
        fh.write(hypervisor_sysctl)

    virtual = NetBSDVirtual()
    virtual_facts = virtual.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert 'virtualbox' in virtual_facts['virtualization_tech_host']

    # Check for both virtualization_type and virtualization_role
    dmi_product_sysctl = '''
machdep.dmi.system-product=VirtualBox
'''

# Generated at 2022-06-23 02:27:56.652313
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual({})
    assert netbsd_virtual.platform == 'NetBSD'
    assert netbsd_virtual.sysctl_virtual == 'machdep.dmi.system-vendor'

# Generated at 2022-06-23 02:28:03.011179
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual({'sysctl': {'machdep.dmi.system-product': 'Bochs'},
                             'file': {'/proc/xen': None, '/dev/xen/evtchn': None, '/dev/xen/privcmd': None}},
                            {'file': {'/dev/xencons': None}})
    assert virtual.get_virtual_facts() == dict(
        virtualization_type='xen', virtualization_role='guest',
        virtualization_technologies=set(['xen']))



# Generated at 2022-06-23 02:28:05.548304
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.platform == 'NetBSD'



# Generated at 2022-06-23 02:28:10.184941
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual_facts = NetBSDVirtual()
    os.environ['IS_DMI_VENDOR'] = "0"
    os.environ['IS_DMI_PRODUCT'] = "0"
    os.environ['IS_HYPERVISOR'] = "0"
    assert netbsd_virtual_facts.get_virtual_f

# Generated at 2022-06-23 02:28:13.167959
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert issubclass(NetBSDVirtualCollector, VirtualCollector)
    assert NetBSDVirtualCollector._fact_class == NetBSDVirtual
    assert NetBSDVirtualCollector._platform == 'NetBSD'


# Generated at 2022-06-23 02:28:15.302255
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    f = NetBSDVirtualCollector()
    assert f is not None

# Generated at 2022-06-23 02:28:16.111942
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    NetBSDVirtualCollector()

# Generated at 2022-06-23 02:28:18.141585
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual()
    assert virtual_facts.platform == 'NetBSD'
    assert virtual_facts._platform == 'NetBSD'

# Generated at 2022-06-23 02:28:23.501692
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    facts_dict = dict()
    NetBSDVirtualCollector(facts=facts_dict)
    assert 'virtualization_type' in facts_dict
    assert 'virtualization_role' in facts_dict
    assert 'virtualization_tech_host' in facts_dict
    assert 'virtualization_tech_guest' in facts_dict

# Generated at 2022-06-23 02:28:31.509129
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Return of method get_virtual_facts
    virtuals = list()

    # Create a new class NetBSDVirtual
    virtual = NetBSDVirtual()

    #run method get_virtual_facts
    virtual_facts = virtual.get_virtual_facts()

    # Verify the result
    if virtual_facts['virtualization_type'] == '':
        virtuals.append('None')
    if 'xen' in virtual_facts['virtualization_tech_guest']:
        virtuals.append('xen')

    if virtuals:
        return virtuals[0]
    else:
        return 'Other'



# Generated at 2022-06-23 02:28:33.562784
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual()
    assert virtual._platform == 'NetBSD'


# Generated at 2022-06-23 02:28:36.967010
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    import sys
    import inspect
    import ansible.module_utils.facts.virtual.netbsd
    import ansible.module_utils.facts.virtual.sysctl

    assert inspect.getmro(NetBSDVirtualCollector)[1] == VirtualCollector

# Generated at 2022-06-23 02:28:41.080854
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virt_facts = {'virtual': {'role': 'guest'}, 'virtualization_type': 'xen', 'virtualization_role': 'guest',
                  'virtualization_tech_host': {'xen'}, 'virtualization_tech_guest': {'xen'}}
    assert NetBSDVirtual().get_virtual_facts() == virt_facts

# Generated at 2022-06-23 02:28:44.395118
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    # testing NetBSDVirtualCollector constructor
    NetBSDVirtualCollector()
    assert NetBSDVirtualCollector._platform == 'NetBSD'


# Generated at 2022-06-23 02:28:47.310524
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd = NetBSDVirtual()
    # Assert that the current platform is NetBSD
    assert netbsd.platform == 'NetBSD'

# Generated at 2022-06-23 02:28:57.207693
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    '''
    Unit test for method get_virtual_facts of class NetBSDVirtual
    '''
    obj = NetBSDVirtual()

# Generated at 2022-06-23 02:28:59.288221
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    from ansible.module_utils.facts.virtual.netbsd import NetBSDVirtualCollector
    nv = NetBSDVirtualCollector()
    assert nv.platform == "NetBSD"


# Generated at 2022-06-23 02:29:02.338846
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert isinstance(NetBSDVirtualCollector._fact_class, type)
    assert NetBSDVirtualCollector._fact_class.__name__ == "NetBSDVirtual"
    assert NetBSDVirtualCollector._platform == "NetBSD"

# Generated at 2022-06-23 02:29:10.768630
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec=dict(),
    )

    m_sysctl = MagicMock()
    m_sysctl.return_value = {
        'machdep.dmi.system-product': 'VirtualBox',
        'machdep.dmi.system-vendor': 'innotek GmbH',
        'machdep.hypervisor': '000'
    }
    module.get_bin_path = MagicMock(return_value='/sbin/sysctl')
    module.run_command = MagicMock(return_value=('', '', 0))
    nv = NetBSDVirtual(module=module, sysctl=m_sysctl)
    facts = nv.get_virtual_facts()

    assert facts['virtualization_type'] == 'virtualbox'

# Generated at 2022-06-23 02:29:19.428724
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    """Unitest for method get_virtual_facts of class NetBSDVirtual"""
    # Set up NetBSDVirtual class
    test_virtual = NetBSDVirtual()

    # Set up empty data structure
    data = {}
    test_virtual.populate(data)

    # Get virtual facts
    results = test_virtual.get_virtual_facts()

    # Assert nothing changed
    assert results['virtualization_type'] == ''
    assert results['virtualization_role'] == ''

    # Machdep.hypervisor sysctl test
    # TODO: Implement without a global
    test_virtual._platform = 'NetBSD'

    # Set up empty data structure
    data = {}
    test_virtual.populate(data)

    # Set up sysctl data
    data['sysctl']['machdep.hypervisor'] = 'qemu'



# Generated at 2022-06-23 02:29:21.690080
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()


# Generated at 2022-06-23 02:29:22.648386
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    NetBSDVirtualCollector()

# Generated at 2022-06-23 02:29:24.042036
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    nv = NetBSDVirtualCollector()
    assert nv.platform == 'NetBSD'

# Generated at 2022-06-23 02:29:27.014411
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # get_virtual_facts should return a dictionary of virtual facts
    # when called by a NetBSDVirtual instance
    virt = NetBSDVirtual()
    result = virt.get_virtual_facts()
    assert isinstance(result, dict)

# Generated at 2022-06-23 02:29:34.867764
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_netbsd_obj = NetBSDVirtualCollector()

    hypervisor_sysctls = {
        'machdep.dmi.system-product': 'VMWare Virtual Platform',
        'machdep.dmi.system-vendor': 'VMware, Inc.',
        'machdep.hypervisor': 'none'
    }

    sysctl_outputs = {
        'kern.hostname': 'fakehost',
        'machdep.hypervisor': 'Xen',
        'machdep.dmi.system-product': 'VMWare Virtual Platform',
        'machdep.dmi.system-vendor': 'VMware, Inc.'
    }


# Generated at 2022-06-23 02:29:37.816865
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert netbsd_virtual_collector._fact_class is NetBSDVirtual
    assert netbsd_virtual_collector._platform == "NetBSD"

# Generated at 2022-06-23 02:29:41.962237
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    nvcollector = NetBSDVirtualCollector()
    assert nvcollector._platform == 'NetBSD'
    assert nvcollector._fact_class == 'NetBSDVirtual'

# Generated at 2022-06-23 02:29:46.100178
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    expected = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }
    assert NetBSDVirtual().collect() == expected

# Generated at 2022-06-23 02:29:47.680205
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_facts = NetBSDVirtualCollector()
    assert netbsd_facts

# Generated at 2022-06-23 02:29:55.853316
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    '''Unit test for method get_virtual_facts of class NetBSDVirtual'''
    test = NetBSDVirtual({'module_setup': {'filter': '*'}})

    # Failed to find required sysctl vm.product_name
    # Failed to find required sysctl vm.product_version
    # Failed to find required sysctl vm.product_serial
    # Failed to find required sysctl vm.product_uuid
    # Failed to find required sysctl vm.product_family
    # Failed to find required sysctl vm.product_sku
    # Failed to find required sysctl machdep.hypervisor
    expected_result = {
        'virtualization_role': '',
        'virtualization_type': '',
        'virtualization_technologies': set(),
    }
    result = test.get_virtual_facts()

# Generated at 2022-06-23 02:29:57.309215
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    obj = NetBSDVirtualCollector()
    obj.get_all()

# Generated at 2022-06-23 02:29:59.179421
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virt = NetBSDVirtual()
    assert virt.platform == 'NetBSD'


# Generated at 2022-06-23 02:30:01.835106
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():

    facts = NetBSDVirtual().get_virtual_facts()
    assert 'virtualization_role' in facts
    assert 'virtualization_type' in facts
    assert 'virtualization_technologies' in facts

# Generated at 2022-06-23 02:30:11.012216
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual = NetBSDVirtual()
    virtual_facts = virtual.get_virtual_facts()

    # Check virtualization_tech_guest
    assert isinstance(virtual_facts['virtualization_tech_guest'], set)
    assert len(virtual_facts['virtualization_tech_guest']) == 0

    # Check virtualization_tech_host
    assert isinstance(virtual_facts['virtualization_tech_host'], set)
    assert len(virtual_facts['virtualization_tech_host']) == 0

    # Check virtualization_type
    assert virtual_facts['virtualization_type'] == ''

    # Check virtualization_role
    assert virtual_facts['virtualization_role'] == ''

# Generated at 2022-06-23 02:30:14.642700
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    x = NetBSDVirtual()
    assert len(x.get_virtual_facts()) == 4

# Generated at 2022-06-23 02:30:18.327855
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual()
    virtual_facts.collect()
    assert 'virtualization_type' in virtual_facts.data
    assert 'virtualization_role' in virtual_facts.data

# Generated at 2022-06-23 02:30:20.780637
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector._platform == 'NetBSD'
    assert NetBSDVirtualCollector._fact_class == NetBSDVirtual


# Generated at 2022-06-23 02:30:30.920169
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual()
    # Test empty fact_subset
    netbsdVirtual = virtual.get_virtual_facts()
    assert netbsdVirtual['virtualization_type'] == ''
    assert netbsdVirtual['virtualization_role'] == ''
    assert 'virtualization_tech_guest' not in netbsdVirtual
    assert 'virtualization_tech_host' not in netbsdVirtual
    # Test complete fact_subset
    netbsdVirtual = virtual.get_virtual_facts(['*'])
    assert 'virtualization_type' in netbsdVirtual
    assert 'virtualization_role' in netbsdVirtual
    assert 'virtualization_tech_guest' in netbsdVirtual
    assert 'virtualization_tech_host' in netbsdVirtual

# Generated at 2022-06-23 02:30:34.168743
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    nbv = NetBSDVirtual({})
    assert nbv.platform == 'NetBSD'
    assert nbv.virtual_facts == {}

# Generated at 2022-06-23 02:30:37.831325
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual()
    print(virtual.get_virtual_facts())

if __name__ == '__main__':
    test_NetBSDVirtual()

# Generated at 2022-06-23 02:30:41.707781
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert netbsd_virtual_collector._fact_class is not None
    assert netbsd_virtual_collector._platform == 'NetBSD'

# Generated at 2022-06-23 02:30:48.016819
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_system'] == ''
    assert virtual_facts['virtualization_guest_os'] == ''
    assert virtual_facts['virtualization_host_type'] == ''
    assert virtual_facts['virtualization_host_name'] == ''
    assert virtual_facts['virtualization_host_uuid'] == ''
    assert virtual_facts['virtualization_host_serial_number'] == ''
    assert not virtual_facts['virtualization_tech_guest']
    assert not virtual_facts['virtualization_tech_host']

# Generated at 2022-06-23 02:30:56.725890
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    import os
    import tempfile

    tmpdir = tempfile.mkdtemp()

    def test_data(data):
        for d in data:
            sysctl_data = d.split(',')
            for item in sysctl_data:
                sysctl = item.split('=')
                path = os.path.join(tmpdir, sysctl[0])
                os.makedirs(os.path.dirname(path))
                with open(path, "w") as f:
                    f.write(sysctl[1])

    def cleanup_test_data():
        for filename in os.listdir(tmpdir):
            path = os.path.join(tmpdir, filename)
            os.remove(path)
        os.rmdir(tmpdir)


# Generated at 2022-06-23 02:31:05.555545
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = {}
    virtual_facts['virtualization_type'] = ''
    virtual_facts['virtualization_role'] = ''
    virtual_facts['virtualization_tech_guest'] = set()
    virtual_facts['virtualization_tech_host'] = set()

    vf = NetBSDVirtual(None)

    # set empty values as default
    vf.facts['ansible_machdep']['machdep.dmi.system-product'] = ''
    vf.facts['ansible_machdep']['machdep.dmi.system-vendor'] = ''
    virtual_facts['virtualization_type'] = ''
    virtual_facts['virtualization_role'] = ''

    assert virtual_facts == vf.get_virtual_facts()


# Generated at 2022-06-23 02:31:09.804670
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual_provider = NetBSDVirtual()
    netbsd_virtual_facts = netbsd_virtual_provider.get_virtual_facts()
    assert netbsd_virtual_facts['virtualization_type'] == ''
    assert netbsd_virtual_facts['virtualization_role'] == ''

# Generated at 2022-06-23 02:31:11.272280
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsdvirtual = NetBSDVirtual()
    assert netbsdvirtual.platform == 'NetBSD'


# Generated at 2022-06-23 02:31:19.011733
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Initialize NetBSDVirtual object
    nbsd_virtual = NetBSDVirtual()

    # Set values for testing
    nbsd_virtual.sysctl_mibs = {
        'machdep.dmi.system-product': 'VirtualBox',
        'machdep.dmi.system-vendor': 'Oracle Corporation',
        'machdep.hypervisor': 'VirtualBox'
    }

    # Store the result of method get_virtual_facts
    result = nbsd_virtual.get_virtual_facts()

    # Check if result is empty
    assert result, "Result must not be empty"
    assert 'virtualization_type' in result, "Result must contains key 'virtualization_type'"
    assert 'virtualization_role' in result, "Result must contains key 'virtualization_role'"

# Generated at 2022-06-23 02:31:25.079880
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    data = {'kernel': 'NetBSD'}
    test = NetBSDVirtual(data=data, path_info=[])
    facts = test.get_virtual_facts()

    # Set these to numerical values to avoid failures on different
    # platforms that might have different names for the same value
    # (i.e. i686, x86_64, etc)
    facts['virtualization_role'] = 1
    facts['virtualization_type'] = 1
    assert facts == {
        'virtualization_role': '',
        'virtualization_type': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }

# Generated at 2022-06-23 02:31:29.611960
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsdvirtualcollector = NetBSDVirtualCollector()
    assert netbsdvirtualcollector.platform == 'NetBSD'
    assert netbsdvirtualcollector._fact_class == NetBSDVirtual
    assert netbsdvirtualcollector._platform == 'NetBSD'


# Generated at 2022-06-23 02:31:32.113650
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    # Create object
    netbsd_virtual = NetBSDVirtual()

    # Validate the fact
    assert len(netbsd_virtual.get_virtual_facts()) == 0

# Generated at 2022-06-23 02:31:36.934803
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    """
    Check NetBSDVirtualCollector is a subclass of VirtualCollector and
    NetBSDVirtual is a subclass of NetBSDVirtual
    """
    assert issubclass(NetBSDVirtualCollector, VirtualCollector)
    assert issubclass(NetBSDVirtual, Virtual)

# Generated at 2022-06-23 02:31:39.976708
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual(None)
    assert netbsd_virtual.platform == 'NetBSD'


# Generated at 2022-06-23 02:31:42.996334
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual()
    assert isinstance(virtual_facts, NetBSDVirtual)
    assert isinstance(virtual_facts, Virtual)



# Generated at 2022-06-23 02:31:46.572727
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virt = NetBSDVirtual({}, None, [])

    assert(virt.platform == 'NetBSD')

    x = {
        'virtualization_role': '',
        'virtualization_type': '',
    }

    for k in x:
        assert(x[k] == getattr(virt, k))


# Generated at 2022-06-23 02:31:57.659611
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    sysctl_data = {
        'machdep.dmi.system-product': 'VirtualBox',
        'machdep.dmi.system-vendor': 'innotek GmbH',
        'machdep.hypervisor': 'other'
    }

    virtual_data = {
        'virtualization_type': 'virtualbox',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': {'virtualbox'},
        'virtualization_tech_host': {'virtualbox'}
    }

    data = VirtualSysctlDetectionMixin.get_virtual_facts(sysctl_data, virtual_data)
    assert data['virtualization_type'] == 'virtualbox'
    assert data['virtualization_role'] == 'guest'

# Generated at 2022-06-23 02:32:05.166135
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual._platform == 'NetBSD'
    assert netbsd_virtual.sysctl_key_regex == 'machdep.dmi.(system-product|system-vendor)'
    # Note that if this fact is on a non-xen system, it will return an empty
    # dictionary
    xen_facts = {'virtualization_type': 'xen', 'virtualization_role': 'guest'}
    assert xen_facts == netbsd_virtual.get_virtual_facts()


# Generated at 2022-06-23 02:32:09.155486
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = {}
    virtual_facts['virtualization_type'] = ''
    virtual_facts['virtualization_role'] = ''

    virtual_facts['virtualization_type'] = 'VMware'
    virtual_facts['virtualization_role'] = 'guest'

    assert NetBSDVirtual() is not None


# Generated at 2022-06-23 02:32:11.656355
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    instance = NetBSDVirtualCollector()
    assert isinstance(instance._fact_class, NetBSDVirtual)
    assert isinstance(instance._platform, str)
    assert instance._platform == 'NetBSD'

# Generated at 2022-06-23 02:32:17.228842
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virt = NetBSDVirtual()    
    facts = virt.get_virtual_facts()
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts
    assert 'virtualization_tech_guest' in facts
    assert 'virtualization_tech_host' in facts
    assert facts['virtualization_type'] == ''
    assert facts['virtualization_role'] == ''

# Generated at 2022-06-23 02:32:22.857280
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual().get_virtual_facts()

    assert isinstance(virtual_facts, dict)
    assert isinstance(virtual_facts['virtualization_type'], str)
    assert isinstance(virtual_facts['virtualization_role'], str)

    assert isinstance(virtual_facts['virtualization_tech_guest'], set)
    assert isinstance(virtual_facts['virtualization_tech_host'], set)

# Generated at 2022-06-23 02:32:25.148557
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    collector = NetBSDVirtualCollector()
    assert type(collector) == NetBSDVirtualCollector
    assert collector._fact_class == NetBSDVirtual
    assert collector._platform == 'NetBSD'

# Generated at 2022-06-23 02:32:31.037883
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    nv = NetBSDVirtual()
    assert nv.__class__.__name__ == 'NetBSDVirtual'
    assert nv._platform == 'NetBSD'
    assert nv.virtual is True
    assert nv.get_virtual_facts() == {}


# Generated at 2022-06-23 02:32:41.573661
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd = NetBSDVirtual()
    output = netbsd.get_virtual_facts()
    assert(type(output) == dict)
    assert(output['virtualization_type'] in ('xen', 'xen dom0', 'kvm', '', ))
    assert(output['virtualization_role'] in ('guest', 'host', '', ))
    assert(type(output['virtualization_tech_guest']) == set)
    assert(type(output['virtualization_tech_host']) == set)

# Generated at 2022-06-23 02:32:47.691569
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    '''Unit test for method: get_virtual_facts of class: NetBSDVirtual'''
    virtual_facts = NetBSDVirtual()
    virtual_facts_dict = {}
    virtual_facts_dict = virtual_facts.get_virtual_facts()
    # assert virtual_facts_dict['virtualization_type'] == 'hvm'
    # assert virtual_facts_dict['virtualization_role'] == 'guest'

# Generated at 2022-06-23 02:32:52.643593
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    facts_obj = NetBSDVirtual()
    facts_obj.get_virtual_facts()
    assert facts_obj.virtual_facts['virtualization_type'] == 'xen'
    assert facts_obj.virtual_facts['virtualization_role'] == 'guest'
    assert facts_obj.virtual_facts['virtualization_tech_guest'] == set(['xen'])
    assert facts_obj.virtual_facts['virtualization_tech_host'] == set([])

# Generated at 2022-06-23 02:33:00.218027
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():

    # NetBSDVirtual instance
    netbsd_virtual = NetBSDVirtual()
    netbsd_virtual_facts = netbsd_virtual.get_virtual_facts()

    # Virtualization facts of Virtual()
    virtual_facts_keys = [
        'virtualization_type',
        'virtualization_role',
        'virtualization_system',
        'virtualization_technology',
    ]

    # Virtualization facts of VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_keys = [
        'virtualization_tech_guest',
        'virtualization_tech_host',
    ]

    # All virtualization facts
    keys = virtual_facts_keys + virtual_sysctl_detection_keys

    # Check all virtualization facts
    for key in keys:
        assert key in netbsd_virtual_facts

# Generated at 2022-06-23 02:33:08.778579
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual = NetBSDVirtual()
    netbsd_virtual.collect()
    netbsd_virtual_facts = netbsd_virtual.get_virtual_facts()
    assert netbsd_virtual_facts['virtualization_type'] == 'xen'
    assert netbsd_virtual_facts['virtualization_role'] == 'guest'
    assert 'xen' in netbsd_virtual_facts['virtualization_tech_guest']
    assert 'xen' not in netbsd_virtual_facts['virtualization_tech_host']

# Generated at 2022-06-23 02:33:17.298638
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    nb_virtual_facts = NetBSDVirtual({})
    nb_virtual_facts.collect_platform_facts()
    virtual_facts = nb_virtual_facts.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == 'general'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_host'] == set(['openbsd'])
    assert virtual_facts['virtualization_tech_guest'] == set(['openbsd'])


# Generated at 2022-06-23 02:33:23.617620
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual = NetBSDVirtual()
    virtual_facts = netbsd_virtual.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_guest'] == {'xen'}
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-23 02:33:26.318344
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual = NetBSDVirtual()
    assert 'virtualization_type' in netbsd_virtual.get_virtual_facts()

# Generated at 2022-06-23 02:33:34.884893
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_system': '',
        'virtualization_subsystem': '',
        'virtualization_product_name': '',
        'virtualization_product_version': '',
        'virtualization_product_brand': '',
        'virtualization_product_options': {},
        'virtualization_product_info': {},
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': set(),
        'virtualization_features': [],
    }

# Generated at 2022-06-23 02:33:37.022122
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virt_facts = NetBSDVirtual(module=None)
    assert virt_facts.get_virtual_facts() == {}

# Generated at 2022-06-23 02:33:38.104804
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualC

# Generated at 2022-06-23 02:33:43.784261
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    v = NetBSDVirtualCollector()
    v.dispatch()

    assert v.fact_class.get_virtual_facts() == {'virtualization_type': 'physical', 'virtualization_role': 'host', 'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}



# Generated at 2022-06-23 02:33:47.864163
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    # Constructor of NetBSDVirtualCollector
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert netbsd_virtual_collector._platform == 'NetBSD'
    assert netbsd_virtual_collector._fact_class.platform == 'NetBSD'


# Generated at 2022-06-23 02:33:56.584818
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    test_values = {
        'machdep.dmi.system-vendor': '',
        'machdep.hypervisor': '',
        'machdep.dmi.system-product': '',
    }
    expected_result = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }

    nv = NetBSDVirtual()

    # Call to method get_virtual_facts
    result = nv.get_virtual_facts()

    assert result == expected_result

# Generated at 2022-06-23 02:33:58.869924
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual()
    assert virtual._platform == 'NetBSD'
    assert virtual._fact_class == 'NetBSDVirtual'

# Generated at 2022-06-23 02:34:01.101053
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector
    assert NetBSDVirtualCollector._fact_class is NetBSDVirtual
    assert NetBSDVirtualCollector._platform == "NetBSD"

# Generated at 2022-06-23 02:34:06.059942
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    '''
    Unit test for method get_virtual_facts of class NetBSDVirtual
    '''
    netbsd_virtual_facts = NetBSDVirtual()
    virtual_facts = netbsd_virtual_facts.get_virtual_facts()
    assert virtual_facts['virtualization_type'] is None

# Generated at 2022-06-23 02:34:17.456032
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    import os.path

    # Make sure non-virtual environment returns empty virtual_facts
    if os.path.isfile('/usr/sbin/virtinfo') and os.path.isfile('/proc/xen/capabilities'):
        # set mock enviroment
        os.environ['ANSIBLE_VIRTUAL_FILE'] = '/usr/sbin/virtinfo'
        os.environ['ANSIBLE_VIRTUAL_PROC'] = '/proc/xen/capabilities'
        os.environ['ANSIBLE_VIRTUAL_SYSCONTROL'] = 'machdep.hypervisor'

        # set mock data for 'machdep.hypervisor'
        os.environ['ANSIBLE_VIRTUAL_FILE_MACHDEP_HYPERVISOR'] = 'FooBar'

        # set mock data