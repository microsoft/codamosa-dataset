

# Generated at 2022-06-23 02:24:13.480099
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virt = NetBSDVirtual(None)
    assert isinstance(virt, NetBSDVirtual)

# Generated at 2022-06-23 02:24:15.795296
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd = NetBSDVirtualCollector()
    assert netbsd is not None

# Generated at 2022-06-23 02:24:19.229387
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert isinstance(netbsd_virtual_collector, NetBSDVirtualCollector)
    assert isinstance(netbsd_virtual_collector.collect(), dict)


# Generated at 2022-06-23 02:24:22.706983
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virt = NetBSDVirtual()
    assert virt.platform == 'NetBSD'
    assert virt.virtualization_type == ''
    assert virt.virtualization_role == ''
    assert virt.virtualization_sysctl_path == '/netbsd'


# Generated at 2022-06-23 02:24:26.182526
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    collector = NetBSDVirtualCollector()
    assert collector._platform == 'NetBSD'
    assert collector._fact_class == NetBSDVirtual


# Generated at 2022-06-23 02:24:28.660746
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virt = NetBSDVirtual('fake/path')
    assert virt is not None


# Generated at 2022-06-23 02:24:31.468372
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual(module)
    assert virtual._platform == 'NetBSD'
    assert virtual._fact_class == 'NetBSDVirtual'


# Generated at 2022-06-23 02:24:32.975006
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual = NetBSDVirtual()
    netbsd_virtual.get_virtual_facts()

# Generated at 2022-06-23 02:24:34.038187
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    my_virtual=NetBSDVirtual()
    assert my_virtual._platform == 'NetBSD'

# Generated at 2022-06-23 02:24:36.516041
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_facts = NetBSDVirtualCollector()
    assert netbsd_facts._fact_class == NetBSDVirtual
    assert netbsd_facts._platform == 'NetBSD'

# Generated at 2022-06-23 02:24:37.732997
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual()
    assert virtual_facts.platform == 'NetBSD'

# Generated at 2022-06-23 02:24:39.165179
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector._platform == 'NetBSD'
    assert NetBSDVirtualCollector._fact_class == NetBSDVirtual

# Generated at 2022-06-23 02:24:41.410764
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.platform == 'NetBSD'

# Generated at 2022-06-23 02:24:48.855269
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual = NetBSDVirtual()
    virtual._read_sysctl_virtual_facts()

    # sysctl can not be tested on Travis CI
    # https://github.com/ansible/ansible/issues/31133
    if 'TRAVIS' not in os.environ:
        assert virtual.get_virtual_facts()['virtualization_type'] == 'kvm'
        assert virtual.get_virtual_facts()['virtualization_role'] == 'guest'


# Generated at 2022-06-23 02:24:50.335223
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd = NetBSDVirtual()
    assert netbsd is not None

# Generated at 2022-06-23 02:24:55.225414
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_fact_collector = NetBSDVirtualCollector()
    assert netbsd_fact_collector._platform == 'NetBSD'
    assert netbsd_fact_collector._fact_class.__name__ == 'NetBSDVirtual'
    assert netbsd_fact_collector._fact_class.platform == 'NetBSD'

# Generated at 2022-06-23 02:24:56.522633
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual({})
    assert netbsd_virtual.get_virtual_facts()['virtualization_type'] is not None

# Generated at 2022-06-23 02:25:09.656927
# Unit test for method get_virtual_facts of class NetBSDVirtual

# Generated at 2022-06-23 02:25:12.094165
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector._platform == 'NetBSD'

# Generated at 2022-06-23 02:25:15.333523
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert netbsd_virtual_collector._fact_class == NetBSDVirtual
    assert netbsd_virtual_collector._platform == 'NetBSD'

# Generated at 2022-06-23 02:25:24.227664
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_host = NetBSDVirtual({'ansible_facts': {'machdep.dmi.system-product': 'KVM', 'machdep.dmi.system-vendor': 'Red Hat', 'machdep.hypervisor': 'KVM'}})
    virtual_guest = NetBSDVirtual({'ansible_facts': {'machdep.dmi.system-product': 'VMware', 'machdep.dmi.system-vendor': 'VMware', 'machdep.hypervisor': 'VMware'}})
    virtual_baremetal = NetBSDVirtual({'ansible_facts': {'machdep.dmi.system-product': 'Bochs', 'machdep.dmi.system-vendor': 'Bochs', 'machdep.hypervisor': 'Bochs'}})


# Generated at 2022-06-23 02:25:31.546338
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    NetBSDVirtual.DETECTION_PLATFORM = 'NetBSD'

    # Set the sysctl file contents
    sysctl_contents = '''
machdep.dmi.system-product=VirtualBox
machdep.dmi.system-vendor=innotek GmbH
machdep.hypervisor=none
'''

    # Set sysctl file for detect_virt_product/detect_virt_vendor
    sysctl_file = '/proc/sysctl'

    # Create a NetBSDVirtual object
    virt = NetBSDVirtual()
    virt.sysctl_file = sysctl_file
    # Set the sysctl file contents
    virt.sysctl_contents = sysctl_contents

    # Call the get_virtual_facts() method
    virtual_facts = virt.get_virtual_facts()

    # Ass

# Generated at 2022-06-23 02:25:37.476009
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'openvzhn'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_guest'] == {'openvzhn'}
    assert virtual_facts['virtualization_tech_host'] == {'openvzhn'}

# Generated at 2022-06-23 02:25:38.613953
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    facts = NetBSDVirtual()

    assert facts is not None

# Generated at 2022-06-23 02:25:47.530715
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    fake_sysctl = ['machdep.dmi.system-product=Bochs',
                   'machdep.hypervisor=Bochs',
                   'hw.model=i386',
                   'hw.machine=i386']
    fake_sysctl_result = {'machdep.dmi.system-product': 'Bochs',
                          'machdep.hypervisor': 'Bochs',
                          'hw.model': 'i386',
                          'hw.machine': 'i386'}
    virtual = NetBSDVirtual(fake_sysctl)
    assert virtual.platform == 'NetBSD'
    assert virtual.sysctl_result == fake_sysctl_result



# Generated at 2022-06-23 02:25:50.732171
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert netbsd_virtual_collector._fact_class == NetBSDVirtual


# Generated at 2022-06-23 02:25:52.311494
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    v = NetBSDVirtual()
    assert v.platform == 'NetBSD'

# Generated at 2022-06-23 02:25:55.298116
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    nv = NetBSDVirtualCollector()
    assert nv.platform == "NetBSD"
    assert nv.fact_class.platform == "NetBSD"
    assert nv.fact_class().platform == "NetBSD"

# Generated at 2022-06-23 02:26:03.158309
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    netbsd_virtual = netbsd_virtual_collector.collect()
    virtual_facts = netbsd_virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_guest'] == set(['xen'])
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-23 02:26:06.159218
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    obj = NetBSDVirtualCollector()
    assert obj.platform == 'NetBSD'
    assert obj._fact_class == NetBSDVirtual
    assert issubclass(obj._fact_class, Virtual)

# Generated at 2022-06-23 02:26:07.861940
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual({})
    assert netbsd_virtual


# Generated at 2022-06-23 02:26:15.817628
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual import NetBSDVirtual

    netbsd_virtual = NetBSDVirtual()

    # test case to check virtualization_type as 'xen' and
    # virtualization_role as 'guest' if /dev/xencons exists and
    # virtualization_type as '' and virtualization_role as '' if
    # /dev/xencons does not exist
    netbsd_virtual.get_file_content = lambda x: x
    netbsd_virtual.dmi_sysctl_data = {
        'machdep.dmi.system-product': 'VirtualBox',
        'machdep.dmi.system-vendor': 'innotek GmbH',
        'machdep.hypervisor': 'QEMU'
    }
    netbsd_virtual.path_

# Generated at 2022-06-23 02:26:18.270068
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    x = NetBSDVirtualCollector()
    assert x._fact_class == NetBSDVirtual
    assert x._platform == 'NetBSD'

# Generated at 2022-06-23 02:26:29.556598
# Unit test for method get_virtual_facts of class NetBSDVirtual

# Generated at 2022-06-23 02:26:39.259972
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    o = NetBSDVirtual()

    # Return values of method get_sysctl_virtual_facts
    sysctl_virtual_facts = {
        'virtualization_type': 'test_type',
        'virtualization_role': 'test_role',
        'virtualization_tech_guest': set([]),
        'virtualization_tech_host': set(['test_tech']),
    }

    # Return values of method detect_virt_product
    test_facts = {
        'virtualization_type': 'test_type',
        'virtualization_role': 'test_role',
        'virtualization_tech_guest': set([]),
        'virtualization_tech_host': set(['test_tech']),
    }

    # Return value of method get_file_content

# Generated at 2022-06-23 02:26:43.016192
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    facts = NetBSDVirtual().get_all_facts()
    facts_count = facts['ansible_facts']['virtualization_type'] in ('', 'kvm', 'xen', 'hyperv', 'vserver')
    assert facts_count == 1


# Generated at 2022-06-23 02:26:51.097243
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = {}
    host_tech = set()
    guest_tech = set()

    # Set empty values as default
    virtual_facts['virtualization_type'] = ''
    virtual_facts['virtualization_role'] = ''

    virtual_product_facts = {'virtualization_type': 'paravirtual',
                             'virtualization_role': 'guest',
                             'virtualization_tech_guest': set(['kvm']),
                             'virtualization_tech_host': set(['kvm'])}

    guest_tech.update(virtual_product_facts['virtualization_tech_guest'])
    host_tech.update(virtual_product_facts['virtualization_tech_host'])
    virtual_facts.update(virtual_product_facts)


# Generated at 2022-06-23 02:26:59.137345
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    test_facts = {
        'machdep.dmi.system-product': 'VMware Virtual Platform',
        'machdep.dmi.system-vendor': 'VMware, Inc.',
        'machdep.hypervisor': 'VMware',
    }
    test_virtual = NetBSDVirtual(test_facts)

    assert test_virtual.get_virtual_facts() == {
        'virtualization_type': 'VMware',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': {'vmware'},
        'virtualization_tech_host': {'vmware'},
    }

# Generated at 2022-06-23 02:27:07.061452
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    v_netbsd = NetBSDVirtual()
    # suppose we don't have any virtualization technology
    v_netbsd.sysctl_all = {}
    v_netbsd.sysctl_all['machdep.dmi.system-product'] = 'IBM System x3650'
    v_netbsd.sysctl_all['machdep.dmi.system-vendor'] = 'IBM'
    v_netbsd.get_virtual_facts()

    assert v_netbsd.virtual_facts['virtualization_type'] == ''
    assert v_netbsd.virtual_facts['virtualization_type_role'] == ''

    # suppose we have hardware virtualization on a host

# Generated at 2022-06-23 02:27:17.605245
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual = NetBSDVirtual({})

    # Test get_virtual_facts() without machdep.dmi.system-product
    set_module_args({})
    virtual_facts = virtual.get_virtual_facts()

    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_type'] == ''

    # Test get_virtual_facts() with machdep.dmi.system-product
    set_module_args({'machdep.dmi.system-product': 'VirtualBox'})
    virtual_facts = virtual.get_virtual_facts()

    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_type'] == 'virtualbox'

    # Test get_virtual_facts() with machdep.hypervisor

# Generated at 2022-06-23 02:27:19.733957
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.platform == 'NetBSD'


# Generated at 2022-06-23 02:27:24.470139
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual('/nonexistant_root')
    assert netbsd_virtual
    assert netbsd_virtual._root == '/nonexistant_root'
    assert netbsd_virtual._platform == 'NetBSD'


# Generated at 2022-06-23 02:27:29.743190
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    '''Unit test for constructor of class NetBSDVirtualCollector.
    '''
    # Test NetBSDVirtualCollector.__init__()
    NetBSDVirtualCollector()

    # Test NetBSDVirtualCollector.platform is 'NetBSD'
    assert NetBSDVirtualCollector().platform == 'NetBSD'

    # Test NetBSDVirtualCollector._fact_class is NetBSDVirtual
    assert NetBSDVirtualCollector()._fact_class == NetBSDVirtual

# Generated at 2022-06-23 02:27:34.335857
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual._platform == 'NetBSD'
    assert not netbsd_virtual._is_jail
    assert netbsd_virtual._sysctl == 'sysctl'
    assert netbsd_virtual._cmdline_file == '/proc/cmdline'
    assert netbsd_virtual._sysfs_virtual_devices == []


# Generated at 2022-06-23 02:27:37.919958
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd = NetBSDVirtual()
    # Class should be 'Virtual'
    assert isinstance(netbsd, Virtual)
    # Platform should be 'NetBSD'
    assert netbsd.platform == 'NetBSD'

# Generated at 2022-06-23 02:27:39.788010
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    nv_collector = NetBSDVirtualCollector()
    assert type(nv_collector) is NetBSDVirtualCollector

# Generated at 2022-06-23 02:27:42.092933
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    fact_class = NetBSDVirtualCollector()
    assert fact_class._fact_class is NetBSDVirtual
    assert fact_class._platform == 'NetBSD'

# Generated at 2022-06-23 02:27:51.698427
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    data = {
            'machdep.dmi.system-product': 'KVM',
            'machdep.dmi.system-vendor': 'QEMU',
            'machdep.hypervisor': 'QEMU'
            }

    netbsd = NetBSDVirtual("NetBSD", None)
    netbsd.parse_sysctl = lambda x: data[x]

    facts = netbsd.get_virtual_facts()

    assert facts['virtualization_type'] == 'kvm'
    assert facts['virtualization_role'] == 'guest'
    assert sorted(facts['virtualization_tech_guest']) == ['kvm', 'qemu']
    assert sorted(facts['virtualization_tech_host']) == ['kvm', 'qemu']


# Generated at 2022-06-23 02:28:01.086283
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    fake_module = dict(
        params=dict()
    )
    virtualization_facts = dict(
        virtualization_type='',
        virtualization_role='',
        virtualization_system='',
        virtualization_product='',
        virtualization_uuid=None,
        virtual_host=dict(),
        virtual_guest=dict(),
        virtualization_tech_guest=set(),
        virtualization_tech_host=set(),
        can_virtualize=True,
        facts={},
        filesystems=[],
        mounts=[]
    )
    virtual_obj = NetBSDVirtual(fake_module)
    virtualization_facts_updater = virtual_obj.get_virtual_facts()
    assert virtualization_facts == virtualization_facts_updater

# Generated at 2022-06-23 02:28:03.048203
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd = NetBSDVirtual(None)
    assert netbsd.platform == 'NetBSD'

# Generated at 2022-06-23 02:28:05.169725
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual()
    assert virtual_facts.platform == 'NetBSD'


# Generated at 2022-06-23 02:28:16.273368
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    '''
    Define a Test class
    '''

    class TestNetBSDVirtual:
        class TestVirtualSysctlDetectionMixin:
            def __init__(self):
                self.facts = {}

            def get_file_content(self, filename):
                '''
                Provide some canned responses
                '''

                canned_responses = {}
                canned_responses['machdep.dmi.system-product'] = 'VMWare Virtual Platform'
                canned_responses['machdep.dmi.system-vendor'] = 'VMware, Inc.'
                canned_responses['machdep.hypervisor'] = 'VMWare Virtual Platform'

                if filename in canned_responses:
                    return canned_responses[filename]
                else:
                    return ''


# Generated at 2022-06-23 02:28:25.168379
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    v = NetBSDVirtual()
    sysctl_values = {
        'machdep.dmi.system-product': 'KVM',
        'machdep.hypervisor': 'KVM',
        'machdep.dmi.system-vendor': 'KVM',
    }

    v.get_sysctl_facts = lambda: sysctl_values
    facts = v.get_virtual_facts()

    assert facts['virtualization_type'] == 'kvm'
    assert facts['virtualization_role'] == 'guest'

# Generated at 2022-06-23 02:28:28.065794
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    '''Unit test for constructor of class NetBSDVirtualCollector'''
    obj = NetBSDVirtualCollector()
    assert obj._platform == 'NetBSD'

# Generated at 2022-06-23 02:28:32.514387
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    module = 'ansible_facts.facts.virtual.netbsd.NetBSDVirtualCollector'
    cls = NetBSDVirtualCollector
    assert cls._platform == 'NetBSD'
    assert cls._fact_class.platform == cls._platform
    assert cls._fact_class.__module__ == module

# Generated at 2022-06-23 02:28:36.100030
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    netbsd_virtual_str = "Fact Class: NetBSDVirtual, Fact Platform: NetBSD"
    assert str(netbsd_virtual) == netbsd_virtual_str


# Generated at 2022-06-23 02:28:38.231397
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    instance = NetBSDVirtualCollector()
    assert instance.platform == 'NetBSD'
    assert instance._fact_class == NetBSDVirtual


# Generated at 2022-06-23 02:28:38.788629
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    NetBSDVirtual()

# Generated at 2022-06-23 02:28:41.015297
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    obj = NetBSDVirtualCollector()
    assert obj.platform == 'NetBSD'
    assert isinstance(obj._fact_class, NetBSDVirtual)


# Generated at 2022-06-23 02:28:48.194622
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    facts = {
        "kernel": "NetBSD",
        "module_setup": True,
        "sysctl": {
            "machdep.dmi.system-product": "VirtualBox",
            "machdep.dmi.system-vendor": "innotek GmbH"
        }
    }
    result = NetBSDVirtual(facts).get_virtual_facts()
    assert result['virtualization_type'] == 'virtualbox'
    assert result['virtualization_role'] == 'guest'
    assert 'virtualbox' in result['virtualization_tech_guest']
    assert 'virtualbox' in result['virtualization_tech_host']
    assert 'virtualbox_vm' in result['virtualization_tech_guest']
    assert 'virtualbox_vm' in result['virtualization_tech_host']

# Generated at 2022-06-23 02:28:49.187205
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    NetBSDVirtual()


# Generated at 2022-06-23 02:28:50.702565
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual('/proc', '/sys')
    assert virtual.platform == 'NetBSD'


# Generated at 2022-06-23 02:28:53.009156
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual()
    assert virtual._platform == 'NetBSD'


# Generated at 2022-06-23 02:28:55.427114
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsdvirtual = NetBSDVirtual()
    assert netbsdvirtual.platform == 'NetBSD'

# Generated at 2022-06-23 02:28:57.632124
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_ins = NetBSDVirtual()
    assert virtual_ins.platform == 'NetBSD'


# Generated at 2022-06-23 02:29:03.885950
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Create a NetBSDVirtual object.
    virtual = NetBSDVirtual({})
    # Set the virtual facts.
    virtual.get_virtual_facts()
    # Create set from the keys of the virtual fact.
    fact_keys = set(virtual.facts.keys())
    # Create the set with the expected keys.
    expected_keys = set(['virtualization_role', 'virtualization_type', 'virtualization_tech_host', 'virtualization_tech_guest'])
    # Test for the expected keys.
    assert fact_keys == expected_keys

# Generated at 2022-06-23 02:29:07.853912
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netBSD_virtual_collector = NetBSDVirtualCollector()
    assert netBSD_virtual_collector.platform == 'NetBSD'
    assert netBSD_virtual_collector._fact_class == NetBSDVirtual


# Generated at 2022-06-23 02:29:14.898915
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual = NetBSDVirtual()
    netbsd_virtual.get_virtual_facts()

    # Form dictionary of expected results
    virtual_facts = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_product': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }
    # Verify returned results match expected results
    assert (netbsd_virtual.virtual_facts == virtual_facts)

# Generated at 2022-06-23 02:29:17.901223
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual(None)
    assert netbsd_virtual.platform == 'NetBSD'


# Generated at 2022-06-23 02:29:22.158198
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtualCollector().get_virtual_facts()
    assert virtual_facts is not None
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-23 02:29:27.156893
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert netbsd_virtual_collector._fact_class == NetBSDVirtual
    assert netbsd_virtual_collector._platform == 'NetBSD'

# Generated at 2022-06-23 02:29:35.615169
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Create a NetBSDVirtual object
    netbsd_virtual_obj = NetBSDVirtual()

    # Set the contents of /proc/cpuinfo to create a dummy output
    cpuinfo_content = '''
system type             : VMware Virtual Platform
xen_major              : 3
xen_minor              : 4
machdep.dmi.system-product: VMware Virtual Platform
machdep.dmi.system-vendor: VMware, Inc.
'''
    with open("/proc/cpuinfo", "w") as f:
        f.write("{0}".format(cpuinfo_content))

    # Call the method get_virtual_facts() to obtain virtualization facts
    virtual_facts_dict = netbsd_virtual_obj.get_virtual_facts()

# Generated at 2022-06-23 02:29:36.629629
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    nv = NetBSDVirtualCollector()

# Generated at 2022-06-23 02:29:38.078468
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    test_object = NetBSDVirtual()
    assert isinstance(test_object, NetBSDVirtual)


# Generated at 2022-06-23 02:29:39.908315
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual = NetBSDVirtual()
    netbsd_virtual.get_virtual_facts()

# Generated at 2022-06-23 02:29:50.804214
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    def open_mock(path, *args, **kwargs):
        if path == "/dev/xencons":
            return open(os.path.join(os.path.dirname(__file__), "fixtures/xencons"), "r")

        if path == "/sys/devices/system/hypervisor/uuid":
            return open(os.path.join(os.path.dirname(__file__), "fixtures/uuid"), "r")

        if path == "/sys/devices/system/hypervisor/type":
            return open(os.path.join(os.path.dirname(__file__), "fixtures/hypervisor_type"), "r")


# Generated at 2022-06-23 02:29:57.900872
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():

    netbsd_virtual = NetBSDVirtual()

    # Prepare Mocked data

# Generated at 2022-06-23 02:30:06.764754
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Prepare
    current_module_path = os.path.dirname(os.path.realpath(__file__))
    sysctl_file = 'sysctl_machdep_dmi_system_product'
    sysctl_file_path = os.path.join(current_module_path, 'unit/fixtures/', sysctl_file)

    # Create a NetBSDVirtual instance
    virtual_detection = NetBSDVirtual()

    # Create a property mock for file sysctl_machdep_dmi_system_product
    with open(sysctl_file_path, 'rb') as sysctl_file_handle:
        type(virtual_detection)._sysctl_machdep_dmi_system_product = property(lambda self: sysctl_file_handle.read())

    # Create a property mock for file machdep.

# Generated at 2022-06-23 02:30:12.471505
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # NetBSD platform variables
    sysctl_sysctl_get = {
        'machdep.dmi.system-product': 'Bochs',
        'machdep.dmi.system-vendor': 'Bochs',
        'machdep.hypervisor': 'Bochs'
    }

    # Virtual facts
    virtual_facts = {
        'virtualization_role': 'guest',
        'virtualization_type': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }

    # Virtual guest technology
    virtual_guest_technology = set()
    virtual_guest_technology.add('xen')

    # Virtual host technology
    virtual_host_technology = set()

    # Virtual facts after update
    virtual_facts_after_update

# Generated at 2022-06-23 02:30:24.349633
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.netbsd import NetBSDVirtual
    ansible_module = AnsibleModule({})
    f = NetBSDVirtual(ansible_module)

    with open('tests/unit/module_utils/facts/virtual/data/netbsd_sysctl', 'r') as myfile:
        sysctl_data = myfile.read()

    with open('tests/unit/module_utils/facts/virtual/data/netbsd_dmesg', 'r') as myfile:
        dmesg_data = myfile.read()

    with open('tests/unit/module_utils/facts/virtual/data/netbsd_dmesg_xen', 'r') as myfile:
        dmesg_xen_data = myfile.read()


# Generated at 2022-06-23 02:30:29.687544
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    facts = NetBSDVirtualCollector().collect()
    assert facts['virtualization_tech_guest'] == set()
    assert facts['virtualization_tech_host'] == set()
    assert facts['virtualization_role'] == ''
    assert facts['virtualization_type'] == ''

# Generated at 2022-06-23 02:30:33.183108
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    nc = NetBSDVirtualCollector()
    assert nc
    assert nc.platform == 'NetBSD'
    assert nc._platform == 'NetBSD'
    assert nc.fact_class == NetBSDVirtual
    assert nc._fact_class == NetBSDVirtual

# Generated at 2022-06-23 02:30:34.047684
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    # Test the init
    NetBSDVirtual()

# Generated at 2022-06-23 02:30:35.458799
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual({}, {}, {}, [])
    assert virtual._platform == 'NetBSD'

# Generated at 2022-06-23 02:30:46.354223
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual = NetBSDVirtual()

    # Test data
    data = [
        # Currently this method just checks if the directory exists,
        # no matter if empty or not. As such we only call the method with an
        # exisiting path.
        {'machdep.dmi.bios-vendor': '/dev/null'},
        {'machdep.hypervisor': '/dev/null'},
        {'machdep.dmi.system-vendor': '/dev/null'},
        {'machdep.dmi.system-product': '/dev/null'}
    ]

    # Test

# Generated at 2022-06-23 02:30:51.347964
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert netbsd_virtual_collector._fact_class == NetBSDVirtual
    assert netbsd_virtual_collector._platform == 'NetBSD'

# Generated at 2022-06-23 02:30:54.365043
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert netbsd_virtual_collector._platform == 'NetBSD'
    assert netbsd_virtual_collector._fact_class == NetBSDVirtual

# Generated at 2022-06-23 02:30:58.905309
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = dict(
        virtualization_type='',
        virtualization_role='',
        virtualization_tech_guest=set(),
        virtualization_tech_host=set(),
    )
    # test NetBSDVirtual().get_virtual_facts()
    assert NetBSDVirtual().get_virtual_facts() == virtual_facts

# Generated at 2022-06-23 02:31:05.559708
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    p1 = NetBSDVirtual()

    # Assume Virtualization_type = None
    p1.virtual = {}

    # Run get_virtual_facts If Virtualization_type = None
    p1.get_virtual_facts()

    # Assert virtualization_type = None
    assert p1.virtual['virtualization_type'] == ''

    # Assert virtualization_role = None
    assert p1.virtual['virtualization_role'] == ''

# Generated at 2022-06-23 02:31:18.080872
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    module_args = dict(gather_subset='!all,min')

# Generated at 2022-06-23 02:31:22.182861
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual._platform == 'NetBSD'
    assert netbsd_virtual._fact_class == 'NetBSDVirtual'
    assert not netbsd_virtual.detection_rules


# Generated at 2022-06-23 02:31:25.400340
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_sysname = NetBSDVirtual()
    # assert that an instance is created
    assert virtual_sysname is not None


# Generated at 2022-06-23 02:31:27.264733
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    collector = NetBSDVirtualCollector()
    assert collector.get_virtual_facts()

# Generated at 2022-06-23 02:31:28.801265
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual()
    assert virtual_facts.platform == 'NetBSD'

# Generated at 2022-06-23 02:31:30.676493
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_facts = NetBSDVirtual()
    assert netbsd_facts is not None


# Generated at 2022-06-23 02:31:34.717614
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    c = NetBSDVirtualCollector()
    assert c._fact_class == NetBSDVirtual
    assert c._platform == 'NetBSD'

# Generated at 2022-06-23 02:31:36.578836
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual()
    assert virtual_facts._platform == 'NetBSD'

# Generated at 2022-06-23 02:31:46.444923
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd = NetBSDVirtual()
    assert(netbsd.platform == 'NetBSD')
    assert(netbsd.type == '')
    assert(netbsd.role == '')
    assert(netbsd.guest_tech == set())
    assert(netbsd.host_tech == set())
    assert(netbsd.product_name == '')
    assert(netbsd.version == '')
    assert(netbsd.product_version == '')
    assert(netbsd.is_hypervisor)

# Generated at 2022-06-23 02:31:47.660391
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    NetBSDVirtualCollector()

# Generated at 2022-06-23 02:31:49.172384
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsdvirtual = NetBSDVirtual({})
    assert netbsdvirtual is not None


# Generated at 2022-06-23 02:31:52.702052
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    NetBSDVirtual_obj = NetBSDVirtual({})
    assert isinstance(NetBSDVirtual_obj.get_virtual_facts(), dict)

# Generated at 2022-06-23 02:31:54.074307
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virt = NetBSDVirtual()
    assert virt.platform == "NetBSD"

# Generated at 2022-06-23 02:31:55.817435
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual({})
    assert netbsd_virtual.platform == 'NetBSD'

# Generated at 2022-06-23 02:32:06.304904
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    sysctl_output = '''
machdep.cpuspeed: 800
machdep.dmi.system-product: VirtualBox
machdep.dmi.system-vendor: innotek GmbH
machdep.hypervisor: None
'''
    expected_virtual_facts = {
        'virtualization_type': 'virtualbox',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['virtualbox']),
        'virtualization_tech_host': set(),
    }

    netbsd_virtual = NetBSDVirtual(sysctl_output)
    virtual_facts = netbsd_virtual.get_virtual_facts()

    assert virtual_facts == expected_virtual_facts, \
        'Failed to parse sysctl output'

# Generated at 2022-06-23 02:32:10.610924
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual()
    assert virtual.virtualization_type == '', \
        'virtual.virtualization_type="%s" != %s' % (virtual.virtualization_type, '')
    assert virtual.virtualization_role == '', \
        'virtual.virtualization_role="%s" != %s' % (virtual.virtualization_role, '')

# Generated at 2022-06-23 02:32:15.820560
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual = NetBSDVirtual()
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] in ('', 'virtualbox', 'kvm', 'qemu', 'xen')
    assert virtual_facts['virtualization_role'] in ('', 'guest')

# Generated at 2022-06-23 02:32:17.511719
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virt_facts = NetBSDVirtual()
    assert virt_facts.platform == 'NetBSD'

# Generated at 2022-06-23 02:32:21.965636
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd = NetBSDVirtualCollector()
    assert netbsd.platform == 'NetBSD'
    assert netbsd._fact_class == NetBSDVirtual



# Generated at 2022-06-23 02:32:23.078021
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector._platform == 'NetBSD'

# Generated at 2022-06-23 02:32:25.763708
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    nbsd_vc = NetBSDVirtualCollector()
    nb_virtual = nbsd_vc.collect()[0]

    assert isinstance(nb_virtual, NetBSDVirtual)

# Generated at 2022-06-23 02:32:32.366890
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virt = NetBSDVirtual()
    facts = virt.get_virtual_facts()

    assert facts['virtualization_type'] == 'xen'
    assert facts['virtualization_role'] == 'guest'
    assert 'xen' in facts['virtualization_tech_guest']
    assert 'xen' in facts['virtualization_tech_host']

# Generated at 2022-06-23 02:32:35.416064
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual()
    assert virtual_facts.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }


# Generated at 2022-06-23 02:32:47.249538
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual().get_virtual_facts()

    # check of virtualization_type is expected value
    if virtual_facts['virtualization_type'] != '':
        print("virtualization_type is not empty")
    else:
        print("virtualization_type is empty")

    # check of virtualization_role is expected value
    if virtual_facts['virtualization_role'] != '':
        print("virtualization_role is not empty")
    else:
        print("virtualization_role is empty")

    for guest_tech in virtual_facts['virtualization_tech_guest']:
        print("guest_tech {}".format(guest_tech))

    for host_tech in virtual_facts['virtualization_tech_host']:
        print("host_tech {}".format(host_tech))

# Generated at 2022-06-23 02:32:49.347622
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    v = NetBSDVirtualCollector()
    assert v.get_all()['virtualization_type'] == '', "Virtualization_type is not empty"

# Generated at 2022-06-23 02:32:53.285096
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    x = NetBSDVirtual()
    facts = x.get_virtual_facts()

    assert facts['virtualization_type'] == 'xen'
    assert facts['virtualization_role'] == 'guest'
    assert facts['virtualization_tech_guest'] == {'xen'}
    assert facts['virtualization_tech_host'] == set()

# Generated at 2022-06-23 02:33:00.029181
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    Virtual.get_virtual_facts = NetBSDVirtual.get_virtual_facts
    virtual_facts = NetBSDVirtual().get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-23 02:33:11.732603
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    import sys
    if sys.version_info[0] == 2:
        builtin_module_name = '__builtin__'
    else:
        builtin_module_name = 'builtins'
    mock_open = 'ansible.module_utils.facts.virtual.netbsd.open'
    with patch(builtin_module_name + '.open', mock_open(read_data='foo'), create=True):
        netbsd_virtual = NetBSDVirtual()
        virtual_facts = netbsd_virtual.get_virtual_facts()
        assert virtual_facts['virtualization_type'] == ''
        assert virtual_facts['virtualization_role'] == ''

# Generated at 2022-06-23 02:33:12.887099
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    assert NetBSDVirtual().platform == 'NetBSD'

# Generated at 2022-06-23 02:33:14.613030
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    # Instantiation
    NetBSDVirtual()



# Generated at 2022-06-23 02:33:16.955594
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    # Constructor test for class NetBSDVirtual
    netbsd_virtual = NetBSDVirtual({})
    assert netbsd_virtual.platform == 'NetBSD'

# Generated at 2022-06-23 02:33:21.386898
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    v = NetBSDVirtual()
    assert v.platform == 'NetBSD'
    assert v.product_name is None
    assert v.product_version is None
    assert v.role is None
    assert v.type is None
    assert v.version is None

# Generated at 2022-06-23 02:33:24.554468
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.platform == 'NetBSD'

# Generated at 2022-06-23 02:33:26.073736
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert issubclass(NetBSDVirtualCollector, VirtualCollector)

# Generated at 2022-06-23 02:33:30.500828
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    """
    Unit test for constructor of class NetBSDVirtual
    """
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.platform == "NetBSD"
    assert netbsd_virtual.guest_virtualized_facts == {}

# Generated at 2022-06-23 02:33:32.382750
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.platform == 'NetBSD'

# Generated at 2022-06-23 02:33:33.974356
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_bsd_virtual_collector = NetBSDVirtualCollector()


# Generated at 2022-06-23 02:33:36.694089
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    # Setup
    virtual = NetBSDVirtual()

    # Verify
    assert 'NetBSDVirtual' == virtual.__class__.__name__


# Generated at 2022-06-23 02:33:38.458132
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    result = NetBSDVirtualCollector()
    assert(result._fact_class is not None)
    assert(result._platform is not None)

# Generated at 2022-06-23 02:33:42.496486
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd = NetBSDVirtual()
    # Assert type of netbsd object
    assert isinstance(netbsd, NetBSDVirtual)


# Generated at 2022-06-23 02:33:49.388206
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual = NetBSDVirtual()
    virtual_facts = netbsd_virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'virtualbox'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert 'vbox' in virtual_facts['virtualization_tech_guest']
    assert 'vbox' in virtual_facts['virtualization_tech_host']
    assert 'virtualbox' in virtual_facts['virtualization_tech_guest']
    assert 'virtualbox' in virtual_facts['virtualization_tech_host']

# Generated at 2022-06-23 02:33:53.478987
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    module = NetBSDVirtual(dict(), dict())
    assert module.get_virtual_facts() == dict(virtualization_type='', virtualization_role='', virtualization_tech_host=set(), virtualization_tech_guest=set())

# Generated at 2022-06-23 02:34:01.761447
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # List having the expected output of get_virtual_facts() with mocked facts
    expected_facter_facts = [
        {
            'virtualization_type': 'kvm',
            'virtualization_role': 'guest',
            'virtualization_tech_guest': {'kvm'},
            'virtualization_tech_host': set()
        }
    ]

    # List of mocked facts to be used for unit testing get_virtual_facts()
    machdep_facts = [
        {
            'machdep.dmi.system-product': 'KVM',
            'machdep.dmi.system-vendor': 'Red Hat',
            'machdep.hypervisor': 'KVM'
        }
    ]
    for machine_facts in machdep_facts:
        fact_collector = NetBSDVirtualCollect

# Generated at 2022-06-23 02:34:11.675189
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual = NetBSDVirtual()
    virtual._sysctl_output = {
        'machdep.dmi.system-product': 'VirtualBox',
        'machdep.dmi.system-vendor': 'innotek GmbH',
        'machdep.hypervisor': 'VirtualBox',
    }
    virtual._file_contents = {
        '/dev/xen/evtchn': '',
        '/dev/xen/gntdev': '',
        '/dev/xen/privcmd': '',
        '/proc/xen/capabilities': '',
    }
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'

# Generated at 2022-06-23 02:34:13.428461
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    facts_netbsd = NetBSDVirtual()
    assert facts_netbsd.platform == "NetBSD"