

# Generated at 2022-06-23 02:24:11.737116
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    facts = NetBSDVirtualCollector()
    assert facts._platform == 'NetBSD'
    assert facts._fact_class == NetBSDVirtual

# Generated at 2022-06-23 02:24:13.649022
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual._platform == 'NetBSD'
    assert netbsd_virtual._fact_class == NetBSDVirtual

# Generated at 2022-06-23 02:24:17.415394
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual(module=None)
    assert netbsd_virtual.platform == 'NetBSD'
    assert netbsd_virtual._platform_fact_class == NetBSDVirtual


# Generated at 2022-06-23 02:24:20.127935
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virtual_collector = NetBSDVirtualCollector()
    assert virtual_collector._platform == 'NetBSD'
    assert virtual_collector._fact_class == NetBSDVirtual


# Generated at 2022-06-23 02:24:21.988295
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsdvirtual = NetBSDVirtual(None)
    assert netbsdvirtual.platform == 'NetBSD'

# Generated at 2022-06-23 02:24:26.673022
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    netbsd_virtual_collector.collect()
    assert netbsd_virtual_collector._platform == "NetBSD"

# Generated at 2022-06-23 02:24:30.152674
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_collector_under_test = NetBSDVirtualCollector()
    assert NetBSDVirtual == netbsd_collector_under_test._fact_class

# Generated at 2022-06-23 02:24:31.363454
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual()
    assert virtual_facts.platform == 'NetBSD'

# Generated at 2022-06-23 02:24:33.537174
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    collector = NetBSDVirtualCollector()
    assert collector._platform == 'NetBSD'
    assert collector._fact_class == NetBSDVirtual

# Generated at 2022-06-23 02:24:41.809459
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    def _parse_dmi(data):
        for line in data.split("\n"):
            if line:
                yield line.split(':', 1)


# Generated at 2022-06-23 02:24:43.334886
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual_obj = NetBSDVirtual()
    assert isinstance(netbsd_virtual_obj, NetBSDVirtual)


# Generated at 2022-06-23 02:24:55.202798
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    def get_sys_info(sysctl):
        if sysctl == 'machdep.dmi.system-product':
            return 'VirtualBox'
        elif sysctl == 'machdep.dmi.system-vendor':
            return 'innotek GmbH'
        elif sysctl == 'machdep.hypervisor':
            return 'Xen'
        else:
            raise KeyError('Invalid sysctl key supplied')

    def os_path_exists(path):
        if path == '/dev/xencons':
            return True
        else:
            return False

    fake_module = type('AnsibleModule', (object,), {'run_command': get_sys_info})
    fake_module.os_path_exists = os_path_exists

    netbsd_virtual = NetBSD

# Generated at 2022-06-23 02:24:59.968440
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # input_data
    test_data = {
        'kernel': '',
        'all' : {
            'machdep.dmi.system-product': "VirtualBox\u0000",
            'machdep.dmi.system-vendor': "innotek GmbH\u0000",
            'machdep.hypervisor': 'none',
        }
    }
    expected_facts = {
        'virtualization_type': 'virtualbox',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': {'virtualbox'},
        'virtualization_tech_host': set(),
    }

    netbsd_virtual_collector_obj = NetBSDVirtualCollector(None, test_data, None)

# Generated at 2022-06-23 02:25:03.131351
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual()
    assert virtual.platform == 'NetBSD'

# Generated at 2022-06-23 02:25:05.065588
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector._platform == 'NetBSD'
    assert NetBSDVirtualCollector._fact_class == NetBSDVirtual

# Generated at 2022-06-23 02:25:16.770978
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    """
    Test NetBSDVirtual.get_virtual_facts()
    """

    # Create instance of NetBSDVirtual
    netbsd_virtual_facts = NetBSDVirtual()

    # Get facts
    netbsd_virtual_facts = netbsd_virtual_facts.get_virtual_facts()

    # Assert whether virtualization_type is correct
    assert netbsd_virtual_facts['virtualization_type'] == 'xen'

    # Assert whether virtualization_type is correct
    assert netbsd_virtual_facts['virtualization_role'] == 'guest'

    # Assert whether 'kvm' is present in virtualization_tech_guest
    assert 'kvm' in netbsd_virtual_facts['virtualization_tech_guest']

    # Assert whether 'kvm' is present in virtualization_tech_host

# Generated at 2022-06-23 02:25:19.198530
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual_instance = NetBSDVirtual(module=None)
    assert netbsd_virtual_instance.platform == 'NetBSD'


# Generated at 2022-06-23 02:25:20.840988
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual({})
    assert virtual.get_virtual_facts()['virtualization_type'] == ''

# Generated at 2022-06-23 02:25:26.062231
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual = NetBSDVirtual({}, {})
    virtual_facts = virtual.get_virtual_facts()

    # Check if it's a dictionary
    assert isinstance(virtual_facts, dict)

    # Check if it contains the correct keys
    assert set(virtual_facts.keys()) == set([
        'virtualization_type',
        'virtualization_role',
        'virtualization_system',
        'virtualization_technologies',
        'virtualization_tech_host',
        'virtualization_tech_guest'
    ])

# Generated at 2022-06-23 02:25:28.267784
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    """
    Test TestBSDVirtualCollector class by creating object of this class.
    """
    obj = NetBSDVirtualCollector()
    assert obj.platform == 'NetBSD'
    assert obj.fact_class == NetBSDVirtual

# Generated at 2022-06-23 02:25:39.386106
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Test host
    test_host = {
        'virtualization_tech_guest': set(['kvm']),
        'virtualization_tech_host': set(['kvm']),
        'virtualization_type': 'kvm',
        'virtualization_role': 'host',
    }

    # Test guest
    test_guest = {
        'virtualization_tech_guest': set(['kvm', 'xen']),
        'virtualization_tech_host': set(['kvm']),
        'virtualization_type': 'xen',
        'virtualization_role': 'guest',
    }

    # Test result for host
    NetBSDVirtual_host = NetBSDVirtual()

# Generated at 2022-06-23 02:25:44.141689
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    test_NetBSDVirtual = NetBSDVirtual()
    test_virtual_facts = test_NetBSDVirtual.get_virtual_facts()
    assert test_virtual_facts['virtualization_type'] == ''
    assert test_virtual_facts['virtualization_role'] == ''
    assert test_virtual_facts['virtualization_tech_guest'] == set()
    assert test_virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-23 02:25:51.632550
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_facts = NetBSDVirtual(None).get_virtual_facts()
    assert netbsd_facts['virtualization_type'] == 'xen'
    assert netbsd_facts['virtualization_role'] == 'guest'
    assert 'xen' in netbsd_facts['virtualization_tech_guest']
    assert 'xen' in netbsd_facts['virtualization_tech_host']

# Generated at 2022-06-23 02:26:01.353718
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Unit test for method get_virtual_facts of class NetBSDVirtual
    # Read test data from file
    tf = os.path.dirname(__file__) + "/tests/get_virtual_facts/get_virtual_facts.data"
    with open(tf) as tf:
        tests = tf.readlines()

    # Execute tests
    collector = NetBSDVirtualCollector()
    for test in tests:
        test = test.strip()
        if test.startswith("#") or test == "":
            continue
        splitted = test.split("|")
        sysctl_result = splitted[0]
        expected_return = splitted[1]

        fact_instance = collector._get_fact_instance()
        fact_instance._exec_sysctl = lambda x: sysctl_result
        fact_instance._exec

# Generated at 2022-06-23 02:26:03.470476
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    c = NetBSDVirtualCollector()
    assert c._platform == 'NetBSD'
    assert c._fact_class == NetBSDVirtual 


# Generated at 2022-06-23 02:26:06.436352
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    c = NetBSDVirtualCollector()
    assert c.platform == 'NetBSD'
    assert c._fact_class.platform == 'NetBSD'



# Generated at 2022-06-23 02:26:13.387922
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    v_fixture = {
        'machdep.dmi.system-product': 'VirtualBox',
        'machdep.dmi.system-vendor': 'innotek GmbH',
        'machdep.hypervisor': 'NetBSD'
    }

    netbsd_virtual = NetBSDVirtual(v_fixture)
    virtual_facts = netbsd_virtual.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == 'virtualbox'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_use_type_system'] is False
    assert virtual_facts['virtualization_use_type_vm'] is True
    assert virtual_facts['virtualization_use_type_container'] is False

# Generated at 2022-06-23 02:26:16.210572
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual()
    assert virtual_facts._platform == 'NetBSD'
    assert virtual_facts._collector_platform == 'NetBSD'

# Generated at 2022-06-23 02:26:18.222212
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    nc = NetBSDVirtualCollector()
    assert nc.platform == 'NetBSD'


# Generated at 2022-06-23 02:26:21.552464
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    nv_collector = NetBSDVirtualCollector()
    assert nv_collector._platform == "NetBSD"
    assert nv_collector._fact_class == NetBSDVirtual

# Generated at 2022-06-23 02:26:25.132925
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd = NetBSDVirtual({},{},{})
    assert netbsd.platform == 'NetBSD'
    assert netbsd.guest_detection_files == {}
    assert netbsd.hypervisor_detection_files == {}

# Generated at 2022-06-23 02:26:31.673588
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # GIVEN a fresh instance of NetBSDVirtual class
    inst = NetBSDVirtual()

    # WHEN get_virtual_facts method is called
    inst.get_virtual_facts()

    # THEN
    assert inst.facts['virtualization_role'] == ''
    assert inst.facts['virtualization_type'] == ''
    assert inst.facts['virtualization_tech_host'] == set()
    assert inst.facts['virtualization_tech_guest'] == set()



# Generated at 2022-06-23 02:26:38.513613
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Testing get_virtual_facts method
    fixture = NetBSDVirtual({})
    fixture._get_sysctl = lambda x: 'VMware, Inc.' if x == 'machdep.dmi.system-vendor' else ' VMware Virtual Platform'

    assert fixture.get_virtual_facts() == {
        'virtualization_type': 'VMware',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['vmware']),
        'virtualization_tech_host': set(['vmware'])
    }


# Generated at 2022-06-23 02:26:48.729788
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    nm = NetBSDVirtual()

    # output from: sysctl machdep.dmi.system-vendor
    # sysctl machdep.dmi.system-product
    # sysctl machdep.hypervisor
    machdep_vendor = "QEMU"
    machdep_product = "Standard PC (i440FX + PIIX, 1996)"
    machdep_hypervisor = "qemu"
    os.environ['ANSIBLE_VIRTUAL_FACT_DMI_VENDOR'] = machdep_vendor
    os.environ['ANSIBLE_VIRTUAL_FACT_DMI_PRODUCT'] = machdep_product
    os.environ['ANSIBLE_VIRTUAL_FACT_HYPERVISOR'] = machdep_hypervisor
    facts = nm.get_virtual_facts()


# Generated at 2022-06-23 02:26:51.006862
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    tc = NetBSDVirtualCollector()
    assert tc._platform == 'NetBSD'
    assert tc._fact_class == NetBSDVirtual


# Generated at 2022-06-23 02:26:54.057906
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    obj = NetBSDVirtualCollector()
    assert obj.platform == 'NetBSD'
    assert issubclass(obj._fact_class, Virtual)


# Generated at 2022-06-23 02:27:02.976797
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    test_facts = {
        'kernel': 'NetBSD',
        'virtual': 'NetBSD',
        'machdep.hypervisor': '',
    }

    hypervisor_facts = {
        'machdep.hypervisor': 'Xen 4.6.6',
    }

    expected_facts = dict(test_facts)
    expected_facts['virtualization_type'] = 'xen'
    expected_facts['virtualization_role'] = 'guest'
    expected_facts['virtualization_tech_guest'] = {'xen'}
    expected_facts['virtualization_tech_host'] = set()
    expected_facts['virtualization_product_name'] = 'Xen'
    expected_facts['virtualization_product_version'] = '4.6.6'


# Generated at 2022-06-23 02:27:04.466762
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    v = NetBSDVirtual()
    assert v
    assert v.platform == 'NetBSD'


# Generated at 2022-06-23 02:27:15.699958
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    host_facts = {}

    # Test when virtualization_type and virtualization_role are empty
    netbsd_virtual = NetBSDVirtual({}, host_facts)
    assert netbsd_virtual.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': {},
        'virtualization_tech_host': {}
    }

    # Test when virtualization_type is vmware and virtualization_role is empty
    host_facts['machdep.hypervisor'] = 'vmware'
    netbsd_virtual = NetBSDVirtual({}, host_facts)

# Generated at 2022-06-23 02:27:25.242856
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    fixtures = [
        '/proc/xen',
    ]
    data = {
        'machdep.dmi.system-product': 'VirtualBox',
        'machdep.dmi.system-vendor': 'innotek GmbH',
        'machdep.hypervisor': 'Xen',
    }

# Generated at 2022-06-23 02:27:27.127701
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual()
    assert virtual._platform == 'NetBSD'
    assert virtual._fact_class == NetBSDVirtual


# Generated at 2022-06-23 02:27:30.121123
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsdvirtual = NetBSDVirtual()
    assert netbsdvirtual.platform == 'NetBSD'
    assert netbsdvirtual.virtualization_type == ''
    assert netbsdvirtual.virtualization_role == ''

# Generated at 2022-06-23 02:27:37.672089
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    """ unit test for constructor of class NetBSDVirtual """
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual is not None
    assert netbsd_virtual._detected is False
    assert netbsd_virtual._facts is {}
    assert netbsd_virtual._fact_class is NetBSDVirtual
    assert netbsd_virtual._sysctl_virtual is {}


# Generated at 2022-06-23 02:27:38.650719
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    d = NetBSDVirtualCollector()

# Generated at 2022-06-23 02:27:48.986091
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Prepare test environment, this is not needed when testing with pytest
    import sys
    sys.modules['ansible.module_utils.facts.virtual.sysctl'] = sys.modules[__name__]

    # Create instance of NetBSDVirtual, this is what we are testing
    virtual = NetBSDVirtual()

    # Mock values of sysctl_virtualization_product and sysctl_virtualization_vendor
    # as defined in class VirtualSysctlDetectionMixin
    virtual.sysctl_virtualization_product = 'Some product name'
    virtual.sysctl_virtualization_vendor = 'Some virtualization vendor'

    # The methods that we mock to avoid executing commands on the local system
    virtual.file_exists = lambda path: False
    virtual.read_sysctl_file = lambda path: ''

# Generated at 2022-06-23 02:27:57.883483
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    sysctls = {
        'machdep.dmi.system-product': 'VirtualBox\0',
        'machdep.dmi.system-vendor': 'innotek GmbH\0',
    }

    virtual_facts = NetBSDVirtual(sysctls=sysctls).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'VirtualBox'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert 'virtualbox' in virtual_facts['virtualization_tech_guest']


# Generated at 2022-06-23 02:27:59.993522
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    nv = NetBSDVirtualCollector()
    assert nv._platform == 'NetBSD', 'Failed to initialize NetBSDVirtualCollector'

# Generated at 2022-06-23 02:28:00.565358
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    NetBSDVirtual()

# Generated at 2022-06-23 02:28:02.032307
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virtual_NetBSD = NetBSDVirtualCollector()
    assert virtual_NetBSD

# Generated at 2022-06-23 02:28:09.615990
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    def mock_detect_virt_product(self, sysctl):
        return { 'virtualization_type': 'KVM',
                 'virtualization_role': 'guest',
                 'virtualization_tech_guest': 'kvm',
                 'virtualization_tech_host': 'kvm' }

    def mock_detect_virt_vendor(self, sysctl):
        return { 'virtualization_type': '',
                 'virtualization_role': '',
                 'virtualization_tech_guest': set(),
                 'virtualization_tech_host': set() }

    # Test with machdep.dmi.system-product
    setattr(NetBSDVirtual, 'detect_virt_product', mock_detect_virt_product)

# Generated at 2022-06-23 02:28:15.716910
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    facts = {}
    virtual = NetBSDVirtual(module=None)
    virtual_facts = virtual.get_virtual_facts(facts)
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-23 02:28:18.256684
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    facts = NetBSDVirtual({})
    assert(facts.platform == 'NetBSD')
    assert(facts.is_virtual == bool(facts.virtualization_type))

# Generated at 2022-06-23 02:28:23.939600
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts_obj = NetBSDVirtual()
    virtual_facts = virtual_facts_obj.get_virtual_facts()
    assert virtual_facts['virtualization_type'] in ['xen', 'kvm', 'virtualbox', 'parallels', 'vmware', 'microsoft', '']
    assert virtual_facts['virtualization_role'] in ['guest', 'host', '']
    assert virtual_facts['virtualization_role'] == 'guest' or len(virtual_facts['virtualization_role']) == 0

# Generated at 2022-06-23 02:28:31.653374
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = {}
    virtual_facts['virtualization_type'] = ''
    virtual_facts['virtualization_role'] = ''
    virtual_facts['virtualization_product_name'] = ''
    virtual_facts['virtualization_product_version'] = ''

    virtual_facts['virtualization_product_name'] = 'Amazon EC2'
    virtual_facts['virtualization_product_version'] = 'unkwnown'
    virtual_facts['virtualization_tech_guest'] = {'vboxguest'}
    virtual_facts['virtualization_tech_host'] = {'vbox'}

    return virtual_facts

# Generated at 2022-06-23 02:28:37.254933
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual_facts = '{"virtualization_type": "", "virtualization_role": ""}'
    netbsd_virtual_facts_result = Virtual.get_virtual_facts(netbsd_virtual_facts)
    assert netbsd_virtual_facts_result['virtualization_type'] == ''
    assert netbsd_virtual_facts_result['virtualization_role'] == ''

# Generated at 2022-06-23 02:28:41.873967
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual = NetBSDVirtual()
    expected_virtual_facts = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_technologies_guest': set(),
        'virtualization_technologies_host': set()
    }

    virtual_facts = netbsd_virtual.get_virtual_facts()
    assert virtual_facts == expected_virtual_facts

# Generated at 2022-06-23 02:28:54.007979
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    facter = NetBSDVirtual()
    facter._module.params = {"gather_subset": "all"}
    facter._module.params.update({"sysctl_prefix": "/usr/sbin/sysctl -n"})

    # Set virtualization type to 'virtualbox'
    facter._module.sysctl_returns = {"hw.product": "VirtualBox"}
    virtualization_facts = facter.get_virtual_facts()
    assert virtualization_facts['virtualization_type'] == 'virtualbox'
    assert virtualization_facts['virtualization_role'] == 'guest'
    assert virtualization_facts['virtualization_technologies'] == set(['hvm'])

    # Set virtualization type to 'kvm'
    facter._module.sysctl_returns = {"hw.product": "KVM"}


# Generated at 2022-06-23 02:28:57.094931
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    nbsdc = NetBSDVirtualCollector()
    assert nbsdc._platform == 'NetBSD'
    assert nbsdc._fact_class.platform == 'NetBSD'

# Generated at 2022-06-23 02:28:58.504290
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.platform == 'NetBSD'

# Generated at 2022-06-23 02:29:07.381106
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # given
    virtual_obj = NetBSDVirtual({}, {})

    # when
    virtual_facts = virtual_obj.get_virtual_facts()

    # then
    # check if result is a dict
    assert isinstance(virtual_facts, dict)
    virtual_facts_keys = [
        'virtualization_tech_host',
        'virtualization_tech_guest',
        'virtualization_type',
        'virtualization_role',
    ]
    if os.path.exists('/dev/xencons'):
        virtual_facts_keys.append('virtualization_hypervisor')
    assert set(virtual_facts.keys()) == set(virtual_facts_keys)

# Generated at 2022-06-23 02:29:10.790730
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert netbsd_virtual_collector.platform == 'NetBSD'
    assert netbsd_virtual_collector._fact_class == NetBSDVirtual


# Generated at 2022-06-23 02:29:12.395421
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    x = NetBSDVirtual({})
    assert x.platform == 'NetBSD'

# Generated at 2022-06-23 02:29:13.748303
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_ = NetBSDVirtual()
    assert virtual_.platform == 'NetBSD'

# Generated at 2022-06-23 02:29:24.689493
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    _platform = NetBSDVirtualCollector.get_platform()
    _fact_class = NetBSDVirtualCollector.get_fact_class()
    _fact_class = _fact_class(_platform)

    _set_sysctl_answers(["/dev/xencons"])

    assert _fact_class.get_virtual_facts() == {
        'virtualization_type': 'xen',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['xen']),
        'virtualization_tech_host': set()
    }

    _set_sysctl_answers([])


# Generated at 2022-06-23 02:29:26.333524
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()

    assert netbsd_virtual.platform == 'NetBSD'

# Generated at 2022-06-23 02:29:30.045533
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    nv = NetBSDVirtualCollector()
    assert nv._platform == 'NetBSD'
    assert nv._fact_class.platform == 'NetBSD'
    assert nv._fact_class.__name__ == 'NetBSDVirtual'


# Generated at 2022-06-23 02:29:33.159617
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual(None, None)
    assert virtual_facts.platform == "NetBSD"
    assert isinstance(virtual_facts.get_virtual_facts(), dict)

# Generated at 2022-06-23 02:29:38.886812
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    '''
    test_NetBSDVirtual_get_virtual_facts:
        get_virtual_facts
        Should return virtual facts
    '''
    virtual_facts = NetBSDVirtual().get_virtual_facts()
    result_keys = ('virtualization_type', 'virtualization_role',
        'virtualization_system', 'virtualization_hypervisor')

    for key in result_keys:
        assert key in virtual_facts

# Generated at 2022-06-23 02:29:40.758605
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    # run
    NetBSDVirtualCollector()

# Generated at 2022-06-23 02:29:42.778355
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual = NetBSDVirtual()
    assert isinstance(netbsd_virtual.get_virtual_facts(), dict)

# Generated at 2022-06-23 02:29:43.475315
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    NetBSDVirtual()


# Generated at 2022-06-23 02:29:45.627153
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert isinstance(NetBSDVirtualCollector()._fact_class, NetBSDVirtual) is True
    assert NetBSDVirtualCollector()._platform == 'NetBSD'


# Generated at 2022-06-23 02:29:47.681049
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual(None)
    assert netbsd_virtual.platform == 'NetBSD'

# Generated at 2022-06-23 02:29:56.295425
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = {}
    virtual_facts = NetBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type']
    assert virtual_facts['virtualization_role']
    assert virtual_facts['virtualization_role'] in ['host', 'guest']
    assert virtual_facts['virtualization_type'] in ['xen', 'kvm', 'vmware', 'hyperv', 'openvz', 'virtuozzo', 'kvm', 'virtualbox', 'powervm', 'parallels']

# Generated at 2022-06-23 02:30:00.353909
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual_obj = NetBSDVirtual({})
    assert netbsd_virtual_obj
    assert netbsd_virtual_obj.platform == 'NetBSD'


# Generated at 2022-06-23 02:30:03.001513
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual_facts = NetBSDVirtual(None)
    assert netbsd_virtual_facts.platform == 'NetBSD'


# Generated at 2022-06-23 02:30:04.707789
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    collector = NetBSDVirtualCollector()
    assert collector is not None


# Generated at 2022-06-23 02:30:06.976108
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual()

    assert virtual is not None, 'object initialization failed'
    assert virtual._platform is 'NetBSD'

# Generated at 2022-06-23 02:30:09.306345
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    bsd = NetBSDVirtual({})
    assert bsd.platform == 'NetBSD'
    assert bsd.guest_guest_sysctl_req == []

# Generated at 2022-06-23 02:30:11.004647
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    my_virtual = NetBSDVirtual()
    assert my_virtual.platform == 'NetBSD'



# Generated at 2022-06-23 02:30:23.655861
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }

    virtual_product_facts = {
        'virtualization_type': '',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': {'foo'},
        'virtualization_tech_host': {'bar'},
    }

    virtual_vendor_facts = {
        'virtualization_type': '',
        'virtualization_role': 'host',
        'virtualization_tech_guest': {'foo'},
        'virtualization_tech_host': {'bar'},
    }

    # Use empty virtual_product_facts
    virtual = Net

# Generated at 2022-06-23 02:30:26.355869
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    nbsdvirt = NetBSDVirtual()
    assert nbsdvirt.platform == 'NetBSD'
    assert nbsdvirt.get_virtual_facts() == {}


# Generated at 2022-06-23 02:30:28.075485
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    VirtualCollector._platform = 'NetBSD'
    assert NetBSDVirtualCollector._platform == 'NetBSD'

# Generated at 2022-06-23 02:30:30.325727
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsdvirtual = NetBSDVirtual(None, None)
    assert netbsdvirtual.platform == 'NetBSD', 'Platform should be NetBSD'

# Generated at 2022-06-23 02:30:31.282437
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    NetBSDVirtual()

# Generated at 2022-06-23 02:30:40.318094
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Set up mocks
    detect_virt_product_mock = MagicMock(return_value={'virtualization_tech_guest': set(),
                                                       'virtualization_tech_host': set(),
                                                       'virtualization_type': 'virtualbox',
                                                       'virtualization_role': 'guest'})
    detect_virt_vendor_mock = MagicMock(return_value={'virtualization_tech_guest': set(),
                                                      'virtualization_tech_host': set(),
                                                      'virtualization_type': '',
                                                      'virtualization_role': ''})
    # Instance to test
    netBSD_virtual = NetBSDVirtual()
    netBSD_virtual.detect_virt_product = detect_virt_product_mock
    netBSD_virtual.detect_virt

# Generated at 2022-06-23 02:30:42.895305
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    nv = NetBSDVirtual()
    assert nv.platform == 'NetBSD'
    assert nv._get_sysctl_virtual_facts == {}

# Generated at 2022-06-23 02:30:47.800953
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    test_facts = {}

    test_instance = NetBSDVirtual()
    result = test_instance.get_virtual_facts()

    assert result['virtualization_type'] == ''
    assert result['virtualization_role'] == ''
    assert len(result['virtualization_tech_guest']) == 0
    assert len(result['virtualization_tech_host']) == 0

# Generated at 2022-06-23 02:30:56.530985
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Initialize a NetBSDVirtual object
    netbsd_virtual = NetBSDVirtual()

    # Use 'file' module to read data from sysctl
    netbsd_virtual.file_exists = lambda path: True

# Generated at 2022-06-23 02:31:00.871838
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virt_facts_obj = NetBSDVirtual()
    v_facts_dict = dict(
        virtualization_type='',
        virtualization_role='',
        virtualization_system='',
        virtualization_technologies=set()
    )

    assert virt_facts_obj._virtual_facts == v_facts_dict


# Generated at 2022-06-23 02:31:06.441419
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    nbsd_collector = NetBSDVirtualCollector()
    assert nbsd_collector._platform == 'NetBSD', "Initialized value of NetBSDVirtualCollector._platform attribute has unexpected value"
    assert nbsd_collector._fact_class._platform == 'NetBSD', "Initialized value of NetBSDVirtualCollector._fact_class._platform attribute has unexpected value"

# Generated at 2022-06-23 02:31:10.439166
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsdvirt = NetBSDVirtual(None, {})
    assert netbsdvirt.platform == 'NetBSD'

# Generated at 2022-06-23 02:31:12.870751
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual(module=None)
    assert virtual_facts.platform == 'NetBSD'


# Generated at 2022-06-23 02:31:17.092806
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual().get_virtual_facts()

    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert len(virtual_facts['virtualization_tech_guest']) == 0
    assert len(virtual_facts['virtualization_tech_host']) == 0

# Generated at 2022-06-23 02:31:24.628861
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    """
    Unit test for method get_virtual_facts of class NetBSDVirtual
    """
    from ansible.module_utils.facts.virtual.netbsd import NetBSDVirtual
    from ansible.module_utils.facts.virtual import NetBSDVirtualCollector

    netbsd_virtual = NetBSDVirtual()

    # Create a NetBSDVirtualCollector object
    netbsd_virtual_collector = NetBSDVirtualCollector()

    # Create a NetBSDVirtual object
    virtual_facts = netbsd_virtual_collector.collect(netbsd_virtual, None)
    assert set(virtual_facts.keys()) == {'virtualization_type', 'virtualization_role', 'virtualization_tech_guest', 'virtualization_tech_host'}
    assert virtual_facts['virtualization_type'] == ''

# Run tests

# Generated at 2022-06-23 02:31:27.142016
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virtual = NetBSDVirtualCollector()
    assert virtual._platform == "NetBSD"
    assert isinstance(virtual._fact_class, NetBSDVirtual)

# Generated at 2022-06-23 02:31:30.937855
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    info = {}
    info['machdep.hypervisor'] = 'bhyve'
    info['machdep.dmi.system-vendor'] = 'Innotek GmbH'
    NetBSDVirtualCollector.test(info)

# Generated at 2022-06-23 02:31:35.583406
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():

    # Arrange
    facts = NetBSDVirtual()

    # Act
    virtual_facts = facts._get_virtual_facts()

    # Assert
    assert virtual_facts['virtualization_type'] == ''

# Generated at 2022-06-23 02:31:47.004434
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = {}
    virtual_facts['virtualization_type'] = ''
    virtual_facts['virtualization_role'] = ''
    virtual_facts['virtualization_system'] = ''
    virtual_facts['virtualization_host'] = ''
    virtual_facts['virtualization_product_name'] = ''
    virtual_facts['virtualization_product_version'] = ''
    virtual_facts['virtualization_product_version'] = ''
    virtual_facts['virtualization_tech_guest'] = set()
    virtual_facts['virtualization_tech_host'] = set()
    module = NetBSDVirtual()
    assert module.get_virtual_facts() == virtual_facts

# Generated at 2022-06-23 02:31:56.393737
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Using empty sysctl as input as we don't know the actual
    # values in NetBSD
    sysctl_output = {'machdep.hypervisor': '',
                     'machdep.dmi.system-vendor': '',
                     'machdep.dmi.system-product': ''}
    expected_result = {'virtualization_role': '',
                       'virtualization_type': '',
                       'virtualization_technologies_guest': set(),
                       'virtualization_technologies_host': set()}
    netbsd = NetBSDVirtual(sysctl_output)
    result = netbsd.get_virtual_facts()
    assert result == expected_result

# Generated at 2022-06-23 02:31:59.387104
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virtual_collector = NetBSDVirtualCollector()
    assert virtual_collector._platform == "NetBSD"
    assert virtual_collector._fact_class == NetBSDVirtual

# Generated at 2022-06-23 02:32:02.861491
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    instance = NetBSDVirtualCollector()
    assert isinstance(instance, NetBSDVirtualCollector)

    # Verify that the constructor calls the super constructor of class
    # VirtualCollector.
    assert isinstance(instance,VirtualCollector)

# Generated at 2022-06-23 02:32:04.709733
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual({})
    assert virtual_facts.platform == 'NetBSD'

# Generated at 2022-06-23 02:32:07.021092
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virtual_collector = NetBSDVirtualCollector()
    assert virtual_collector.platform == 'NetBSD'
    assert virtual_collector.fact_class._platform == 'NetBSD'

# Generated at 2022-06-23 02:32:10.137315
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd = NetBSDVirtual({})
    assert netbsd is not None


# Generated at 2022-06-23 02:32:14.157214
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert netbsd_virtual_collector._platform == 'NetBSD'
    assert netbsd_virtual_collector._fact_class == NetBSDVirtual

# Generated at 2022-06-23 02:32:19.204857
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    fact_class = NetBSDVirtual()
    expected = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_technologies': set()
    }
    assert fact_class.get_virtual_facts() == expected, \
        'get_virtual_facts should return empty virtualization data'

# Generated at 2022-06-23 02:32:20.283472
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual()
    assert virtual.get_virtual_facts()['virtualization_type'] == ''
    assert virtual.get_virtual_facts()['virtualization_role'] == ''

# Generated at 2022-06-23 02:32:24.506682
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual({})
    virtual_facts = virtual_facts.get_virtual_facts()

    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_system' in virtual_facts

# Generated at 2022-06-23 02:32:26.804259
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.platform == 'NetBSD'

# Generated at 2022-06-23 02:32:29.492222
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector._platform == 'NetBSD'

# Generated at 2022-06-23 02:32:32.408119
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual()
    assert virtual.platform == 'NetBSD'
    assert virtual.get_virtual_facts().keys() == virtual.get_virtual_facts().keys()


# Generated at 2022-06-23 02:32:34.820475
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    nv = NetBSDVirtual(collect_default=False)
    assert nv.platform == 'NetBSD'

# Generated at 2022-06-23 02:32:37.315561
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    res = NetBSDVirtual()
    assert(res.platform == 'NetBSD')


# Generated at 2022-06-23 02:32:39.345848
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    fact_class = NetBSDVirtualCollector()
    assert fact_class._fact_class.platform == 'NetBSD'

# Generated at 2022-06-23 02:32:44.369526
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.platform == 'NetBSD'
    assert netbsd_virtual.virtualization_type == ''
    assert netbsd_virtual.virtualization_role == ''
    assert len(netbsd_virtual.virtualization_tech_guest) == 0
    assert len(netbsd_virtual.virtualization_tech_host) == 0

# Generated at 2022-06-23 02:32:50.088093
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual = NetBSDVirtual()
    expected_virtual_facts = {
        'virtualization_type': 'parallels',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['hv']),
        'virtualization_tech_host': set(['parallels'])
    }

    actual_virtual_facts = virtual.get_virtual_facts()
    assert actual_virtual_facts == expected_virtual_facts

# Generated at 2022-06-23 02:32:53.179226
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virt = NetBSDVirtual()
    assert virt.platform == 'NetBSD'
    assert virt.virtualization_type == ''
    assert virt.virtualization_role == ''
    assert virt.virtualization_tech_host == set()
    assert virt.virtualization_tech_guest == set()

# Generated at 2022-06-23 02:32:56.404899
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    """Check if the constructor of NetBSDVirtualCollector can be called.
    """
    NetBSDVirtualCollector()

# Generated at 2022-06-23 02:33:03.685112
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    v = NetBSDVirtual({}, {}, {})
    v._get_sysctl = lambda x: {'machdep.dmi.system-product': 'Proxmox',
                               'machdep.dmi.system-vendor': 'PowerEdge C8220'}

# Generated at 2022-06-23 02:33:05.615665
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    collector = NetBSDVirtualCollector()
    assert collector._fact_class == NetBSDVirtual
    assert collector._platform == 'NetBSD'

# Generated at 2022-06-23 02:33:08.362942
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_collector = NetBSDVirtualCollector()
    assert netbsd_collector
    """NetBSDVirtualCollector object created."""

# Generated at 2022-06-23 02:33:20.223560
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Test on VMware virtual machine
    nbsdvirtual_vmware_facts = {
        'virtualization_type': 'VMware, Parallels, or VirtualBox',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['vmware', 'parallels', 'virtualbox']),
        'virtualization_tech_host': set(['hwvirt'])}

    nbsdvirtual_vmware = NetBSDVirtual(None, None, {'machdep.dmi.system-vendor': 'VMware, Inc.'}, None, None)
    assert nbsdvirtual_vmware.get_virtual_facts() == nbsdvirtual_vmware_facts

    # Test on VMWare ESXi 5.5.0 (64GB)

# Generated at 2022-06-23 02:33:28.931251
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    fake_module = FakeModule()
    facts = NetBSDVirtual(fake_module).get_virtual_facts()

    assert len(facts) == 5
    assert facts['virtualization_type'] == 'paravirtual'
    assert facts['virtualization_role'] == 'guest'
    assert facts['virtualization_tech_guest'] == {'paravirtual'}
    assert facts['virtualization_tech_host'] == {'paravirtual'}

    assert 'virtualization_enforced' not in facts



# Generated at 2022-06-23 02:33:40.155478
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    def _get_file_content(filename):
        with open(filename) as _f:
            return _f.read()

    # Map porting kit name to vendor name
    _port_kit_vendor = {'xenhvm': 'xenserver'}

    virtual = NetBSDVirtual()

    # Test with no machdep.dmi.system-vendor and machdep.dmi.system-product
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()

    # Test with machdep.dmi.system-vendor exist
    # machdep.dmi.

# Generated at 2022-06-23 02:33:41.637617
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual

# Generated at 2022-06-23 02:33:45.749519
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virtual_collector = NetBSDVirtualCollector()
    assert virtual_collector._platform == "NetBSD"
    assert virtual_collector._fact_class.__name__ == "NetBSDVirtual"
    assert virtual_collector._fact_class._platform == "NetBSD"
    assert virtual_collector.collect()


# Generated at 2022-06-23 02:33:50.835204
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert netbsd_virtual_collector._platform == 'NetBSD'
    assert type(netbsd_virtual_collector._fact_class) == type(NetBSDVirtual)


# Generated at 2022-06-23 02:33:51.858578
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert(NetBSDVirtualCollector)


# Generated at 2022-06-23 02:33:56.166830
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    data = read_fixture('NetBSDVirtualFacts')
    virtual_facts = NetBSDVirtual(data=data).get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert virtual_facts['virtualization_type'] == 'xen', \
        "get_virtual_facts() did not return a correct virtualization type"

# Generated at 2022-06-23 02:33:58.461705
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert netbsd_virtual_collector._platform == 'NetBSD'

# Generated at 2022-06-23 02:34:02.470207
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    c = NetBSDVirtualCollector()
    assert type(c) is NetBSDVirtualCollector
    assert c.platform == 'NetBSD'
    assert c._fact_class == NetBSDVirtual


# Generated at 2022-06-23 02:34:05.651511
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsdVirtualCollector = NetBSDVirtualCollector()
    assert netbsdVirtualCollector._fact_class == NetBSDVirtual
    assert netbsdVirtualCollector._platform == 'NetBSD'


# Generated at 2022-06-23 02:34:14.329324
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virt = NetBSDVirtual()

    # mock output of sysctl command
    virt.sysctl_cmd_output = lambda k: 'VMware, Inc. VMware Virtual Platform' if k == 'machdep.hypervisor' else ''

    # empty virtualization_type and virtualization_role
    virt_facts = virt.get_virtual_facts()
    assert virt_facts['virtualization_type'] == 'vmware'
    assert virt_facts['virtualization_role'] == 'guest'
    assert 'vmware' in virt_facts['virtualization_tech_guest']
    assert 'vmware' in virt_facts['virtualization_tech_host']

    # set virtualization_type and virtualization_role
    virt_facts['virtualization_type'] = 'xen'
    virt_facts['virtualization_role'] = 'guest'
