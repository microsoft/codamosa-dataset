

# Generated at 2022-06-23 02:24:14.347467
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virtual_collector = NetBSDVirtualCollector('test_cache')
    assert isinstance(virtual_collector, VirtualCollector)
    assert virtual_collector.platform == 'NetBSD'
    assert virtual_collector._fact_class == NetBSDVirtual

# Generated at 2022-06-23 02:24:15.608196
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    NetBSDVirtual()


# Generated at 2022-06-23 02:24:17.022573
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual(None)
    assert virtual_facts


# Generated at 2022-06-23 02:24:17.994704
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    NetBSDVirtualCollector()

# Generated at 2022-06-23 02:24:27.476081
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    from collections import defaultdict
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collector import FactsCollector

    # Must contain only keys for arch, domain, fqdn, hostname, kernel, kernel_version, machine_id,
    # manufacturer, os_family, virtual, virtualization_role, virtualization_type
    dummy_facts = defaultdict(lambda: defaultdict(lambda: defaultdict(lambda: defaultdict(lambda: defaultdict(lambda: defaultdict(lambda: defaultdict(list)))))))
    dummy_facts['virtual'] = {'virtualization_role': 'guest', 'virtualization_type': 'kvm'}
    test_fact_collector = FactsCollector()
    test_fact_collector.collect(dummy_facts)
    test_netbsd_virtual

# Generated at 2022-06-23 02:24:38.012668
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    expected = dict(
        virtualization_role='guest',
        virtualization_type='chroot',
        virtualization_tech_guest=set('chroot'),
        virtualization_tech_host=set()
    )

    with open('tests/unit/module_utils/facts/virtual/netbsd.txt') as fp:
        for line in fp:
            if line.startswith('machdep.dmi.system-vendor'):
                line = 'machdep.dmi.system-vendor=None'
            else:
                line = line.rstrip()
            os.environ[line.split('=', 1)[0]] = line.split('=', 1)[1]

    actual = NetBSDVirtual().get_virtual_facts()

    assert actual == expected, 'failed to get virtual facts'

# Generated at 2022-06-23 02:24:40.433209
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    nb_virtcoll = NetBSDVirtualCollector()
    fact_class = nb_virtcoll._fact_class
    assert fact_class is NetBSDVirtual

# Generated at 2022-06-23 02:24:43.981198
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_collector = NetBSDVirtualCollector()
    assert netbsd_collector._platform == 'NetBSD'
    assert netbsd_collector._fact_class.platform == 'NetBSD'

# Generated at 2022-06-23 02:24:46.106186
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual({})
    assert netbsd_virtual.platform == "NetBSD"

# Generated at 2022-06-23 02:24:47.808575
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd = NetBSDVirtual()
    assert netbsd.platform == 'NetBSD'

# Generated at 2022-06-23 02:24:49.810217
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual._platform == 'NetBSD'

# Generated at 2022-06-23 02:24:51.832367
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virtual_collector = NetBSDVirtualCollector()
    assert virtual_collector.platform == 'NetBSD'

# Generated at 2022-06-23 02:24:54.130294
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.platform == 'NetBSD'


# Generated at 2022-06-23 02:24:55.577219
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual()
    assert virtual.platform == 'NetBSD'

# Generated at 2022-06-23 02:24:58.155223
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsdvc = NetBSDVirtualCollector()
    assert netbsdvc._fact_class == NetBSDVirtual
    assert netbsdvc._platform == 'NetBSD'



# Generated at 2022-06-23 02:25:04.789014
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert netbsd_virtual_collector._platform == 'NetBSD'
    assert netbsd_virtual_collector._fact_class == NetBSDVirtual

# Generated at 2022-06-23 02:25:08.058899
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    raw_facts = {'kernel:machdep.dmi.system-vendor': 'Parallels Software International Inc.'}
    test_instance = NetBSDVirtual(raw_facts)
    facts = test_instance.get_virtual_facts()

    assert facts['virtualization_type'] == 'parallel'

# Generated at 2022-06-23 02:25:10.420851
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual("NetBSD")
    assert virtual_facts.platform == 'NetBSD'

# Generated at 2022-06-23 02:25:16.141557
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual = NetBSDVirtual()
    virtual_facts = {}
    expected_virtual_facts = {'virtualization_type': 'xen',
                              'virtualization_role': 'guest',
                              'virtualization_tech_host': set([]),
                              'virtualization_tech_guest': set(['xen'])}

    virtual_facts.update(virtual.get_virtual_facts())
    assert virtual_facts == expected_virtual_facts

# Generated at 2022-06-23 02:25:21.062610
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual = NetBSDVirtual({})
    virtual_facts = virtual.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_guest'] == set([
        'xen'
    ])
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-23 02:25:23.848251
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert netbsd_virtual_collector._platform == "NetBSD"
    assert netbsd_virtual_collector._fact_class == NetBSDVirtual

# Generated at 2022-06-23 02:25:31.303222
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Test - virtualization_type = xen
    #        virtualization_role = guest
    #        virtualization_tech_guest = xen
    output = {'machdep.dmi.system-product': 'HVM domU',
              'machdep.dmi.system-vendor': 'Xen',
              'machdep.hypervisor': 'Xen'}
    netbsdVirtual = NetBSDVirtual(output, False)
    result = netbsdVirtual.get_virtual_facts()
    assert result['virtualization_type'] == 'xen'
    assert result['virtualization_role'] == 'guest'
    assert 'xen' in result['virtualization_tech_guest']
    assert 'xen' in result['virtualization_tech_host']

    # Test - virtualization_type = xen
    #

# Generated at 2022-06-23 02:25:41.670491
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Number of skipped tests
    skipped = 0

    # Set of supported virtualization types
    supported = {'xen', 'vmware', 'kvm', 'virtualbox', 'hyperv', 'parallels', 'bochs', 'kvm'}

    # Dictionary of sysctl mibs for virtualization
    mibs = {'machdep.dmi.system-vendor': ['kvm', 'parallels', 'virtualbox', 'vmware'],
            'machdep.hypervisor': ['kvm', 'vmware', 'hyperv', 'kvm'],
            'machdep.dmi.system-product': ['parallels', 'bochs', 'virtualbox'],
            '/dev/xencons': ['xen']}

    # Create virtual object
    virtual = NetBSDVirtual()


# Generated at 2022-06-23 02:25:49.189044
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    data = {}
    data['virtualization_type'] = ''
    data['virtualization_role'] = ''
    data['virtualization_tech_guest'] = set()
    data['virtualization_tech_host'] = set()

    netbsd_virtual = NetBSDVirtual(data)
    test_get_virtual_facts = netbsd_virtual.get_virtual_facts()
    assert test_get_virtual_facts['virtualization_type'] == ''
    assert test_get_virtual_facts['virtualization_role'] == ''
    assert test_get_virtual_facts['virtualization_tech_guest'] == set()
    assert test_get_virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-23 02:25:52.479874
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virtual_facts_dict = NetBSDVirtualCollector().collect()
    assert virtual_facts_dict['virtualization_type'] != ''
    assert virtual_facts_dict['virtualization_role'] != ''

# Generated at 2022-06-23 02:26:02.081611
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    class MockSysctl:
        def __init__(self, virtualization_type=None, virtualization_role=None, machdep_dmi_system_product=None, machdep_dmi_system_vendor=None, machdep_hypervisor=None):
            self.virtualization_type = virtualization_type
            self.virtualization_role = virtualization_role
            self.machdep_dmi_system_product = machdep_dmi_system_product
            self.machdep_dmi_system_vendor = machdep_dmi_system_vendor
            self.machdep_hypervisor = machdep_hypervisor
    class MockOS:
        def __init__(self, path_exists=None):
            self.path_exists = path_exists

    mock_sysctl = MockSysctl

# Generated at 2022-06-23 02:26:05.405634
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual = NetBSDVirtual()
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'

# Generated at 2022-06-23 02:26:12.695971
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    """Unit test for constructor of class NetBSDVirtual
    """
    virtual_1 = NetBSDVirtual()
    assert virtual_1.platform == 'NetBSD'
    assert virtual_1.extra_module_path == '/usr/local/lib/python3.4/dist-packages/libvirt/__init__.py'
    assert virtual_1.detection_order == (
        'sysctl',
        'virt-what',
        'lspci',
        'dmidecode',
        'systemd-detect-virt',
        'gce_metadata',
        'ec2_metadata',
        'openstack_metadata',
        'bsd_jail'
    )

# Generated at 2022-06-23 02:26:17.843518
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    result = NetBSDVirtualCollector()
    expected_result = {
        '_fact_class': NetBSDVirtual,
        '_platform': 'NetBSD'
    }
    assert result.__dict__ == expected_result, \
        'The constructor of NetBSDVirtualCollector does not return the correct values'


# Generated at 2022-06-23 02:26:19.547019
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector.platform == 'NetBSD'

# Generated at 2022-06-23 02:26:21.899128
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    obj = NetBSDVirtualCollector()
    assert obj.platform == 'NetBSD'
    assert obj.collector == NetBSDVirtual

# Generated at 2022-06-23 02:26:22.969434
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    NetBSDVirtualCollector()

# Generated at 2022-06-23 02:26:25.289241
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual
    assert netbsd_virtual.platform == 'NetBSD'

# Generated at 2022-06-23 02:26:27.626746
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert isinstance(netbsd_virtual, NetBSDVirtual)


# Generated at 2022-06-23 02:26:35.161518
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    r"""
    Test get_virtual_facts method of NetBSDVirtual class.
    """
    netbsd_virtual_collector = NetBSDVirtualCollector()
    netbsd_virtual_facts = netbsd_virtual_collector.collect(None, None)
    assert 'virtualization_type' in netbsd_virtual_facts
    assert 'virtualization_role' in netbsd_virtual_facts
    assert 'virtualization_tech_guest' in netbsd_virtual_facts
    assert 'virtualization_tech_host' in netbsd_virtual_facts

# Generated at 2022-06-23 02:26:39.747552
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual()
    assert virtual.platform == 'NetBSD'
    assert virtual.virtualization_type == ''
    assert virtual.virtualization_role == ''
    assert virtual.virtualization_tech_guest == set()
    assert virtual.virtualization_tech_host == set()

# Generated at 2022-06-23 02:26:40.915173
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector() is not None


# Generated at 2022-06-23 02:26:43.208325
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual

# Generated at 2022-06-23 02:26:46.045720
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    vm = NetBSDVirtual()
    assert vm.get_virtual_facts()['virtualization_type'] == 'xen'
    assert vm.get_virtual_facts()['virtualization_role'] == 'guest'

# Generated at 2022-06-23 02:26:48.949027
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virt_obj = NetBSDVirtualCollector()
    assert netbsd_virt_obj._platform == 'NetBSD'
    assert netbsd_virt_obj._fact_class == NetBSDVirtual

# Generated at 2022-06-23 02:26:59.045443
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    v = NetBSDVirtual()
    # Test with the following sysctl values.
    v.sysctl['machdep.dmi.system-product'] = 'VMware Virtual Platform'
    v.sysctl['machdep.dmi.system-vendor'] = 'VMware, Inc.'
    v.sysctl['machdep.hypervisor'] = 'VMware'
    # Test with /dev/xencons existing
    os.path.exists = MagicMock(return_value=True)
    assert v.get_virtual_facts() == {'virtualization_type': 'vmware', 'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['vmware', 'xen']), 'virtualization_tech_host': set(['vmware'])}
    # Test with /dev/x

# Generated at 2022-06-23 02:27:00.642000
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    collector = NetBSDVirtualCollector()
    assert collector.platform == 'NetBSD'
    assert isinstance(collector._fact_class, NetBSDVirtual)

# Generated at 2022-06-23 02:27:01.509845
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    pass

# Generated at 2022-06-23 02:27:03.388130
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector._platform == 'NetBSD'
    assert NetBSDVirtualCollector._fact_class.platform == 'NetBSD'


# Generated at 2022-06-23 02:27:06.175475
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    bsd_virtual = NetBSDVirtual()
    assert bsd_virtual.get_virtual_facts()

# Generated at 2022-06-23 02:27:07.280021
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    NetBSDVirtualCollector()

# Generated at 2022-06-23 02:27:10.167747
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virtual_collector = NetBSDVirtualCollector()
    assert virtual_collector._fact_class == NetBSDVirtual
    assert virtual_collector._platform == 'NetBSD'

# Generated at 2022-06-23 02:27:13.598190
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual = NetBSDVirtualCollector()
    assert netbsd_virtual.platform == 'NetBSD'
    assert netbsd_virtual._platform == 'NetBSD'
    assert netbsd_virtual._fact_class.platform == 'NetBSD'

# Generated at 2022-06-23 02:27:17.295829
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    facts = NetBSDVirtual({}).get_virtual_facts()
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts
    assert 'virtualization_tech_guest' in facts
    assert 'virtualization_tech_host' in facts

# Generated at 2022-06-23 02:27:19.419243
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    collector = NetBSDVirtualCollector()
    assert collector.platform == 'NetBSD'
    assert collector._fact_class == NetBSDVirtual


# Generated at 2022-06-23 02:27:28.669962
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    instance = NetBSDVirtual({}, {})
    product = "QEMU Standard PC (Q35 + ICH9, 2009)"
    vendor = "QEMU"
    instance.sysctl = {
        "machdep.dmi.product-name": product,
        "machdep.dmi.system-vendor": vendor
    }
    facts = instance.get_virtual_facts()

    assert facts['virtualization_type'] == 'kvm'
    assert facts['virtualization_role'] == 'guest'
    assert facts['virtualization_tech_host'] == set(['kvm'])
    assert facts['virtualization_tech_guest'] == set(['kvm'])
    assert facts['virtualization_product'] == product
    assert facts['virtualization_vendor'] == vendor

# Generated at 2022-06-23 02:27:31.876738
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert issubclass(NetBSDVirtualCollector, VirtualCollector)
    assert NetBSDVirtualCollector._fact_class == NetBSDVirtual
    assert NetBSDVirtualCollector._platform == 'NetBSD'


# Generated at 2022-06-23 02:27:39.835416
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # preparation
    fact = NetBSDVirtual('netbsd')
    fact.collect()
    # execution
    facts = fact.get_virtual_facts()
    # assertion
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts
    assert 'virtualization_technologies' in facts
    assert 'virtualization_tech_host' in facts
    assert 'virtualization_tech_guest' in facts
    assert 'virtualization_hypervisor' in facts
    # cleanup



# Generated at 2022-06-23 02:27:43.781967
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    assert NetBSDVirtual().get_virtual_facts() == {'virtualization_role': 'guest', 'virtualization_type': 'vmware', 'virtualization_tech_guest': {'vmware'}, 'virtualization_tech_host': {'vmware'}}

# Generated at 2022-06-23 02:27:46.694469
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.platform == NetBSDVirtual.platform

if __name__ == '__main__':
    test_NetBSDVirtual()

# Generated at 2022-06-23 02:27:49.666068
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'

# Generated at 2022-06-23 02:27:53.903983
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    """Completes a test for the NetBSDVirtualCollector class"""
    x = NetBSDVirtualCollector()
    y = x.collect()
    assert isinstance(y, dict)

# Generated at 2022-06-23 02:27:55.848864
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    # Check if the constructor creates an instance of NetBSDVirtual
    assert isinstance(NetBSDVirtual(), NetBSDVirtual)

# Generated at 2022-06-23 02:28:00.174645
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd = NetBSDVirtual()
    virtual_facts = netbsd.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_host'] == set()
    assert virtual_facts['virtualization_tech_guest'] == set()


# Generated at 2022-06-23 02:28:10.099167
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    test_dir = os.path.dirname(os.path.realpath(__file__))
    data_dir = os.path.join(test_dir, '../unit/facts/virtual')
    data_files = (
        'netbsd_sysctl_machdep_dmi',
        'netbsd_sysctl_machdep_hypervisor',
    )
    files = {
        os.path.join(data_dir, x): None for x in data_files
    }
    files[os.path.join(data_dir, 'netbsd_dev_xencons')] = 'xencons'

    class MockFactCollector(object):
        def __init__(self):
            self.files = files

    NetBSDVirtual._collect_platform_facts = classmethod(lambda cls: {})

# Generated at 2022-06-23 02:28:19.610043
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    test_NetBSDVirtual = NetBSDVirtual()
    sysctl_facts = {
        'machdep.dmi.system-product': 'Bochs',
        'machdep.dmi.system-vendor': 'Bochs',
        'machdep.hypervisor': '',
    }

    expected = {
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': {'vendor', 'product'},
        'virtualization_type': 'xen',
        'virtualization_role': 'guest',
    }

    virtual_facts = test_NetBSDVirtual.get_virtual_facts(sysctl_facts, [])
    assert virtual_facts == expected

# Generated at 2022-06-23 02:28:22.303415
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual()
    assert virtual_facts.get_virtual_facts() == {}

# Generated at 2022-06-23 02:28:24.180660
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual()
    assert virtual.platform == 'NetBSD'


# Generated at 2022-06-23 02:28:27.402876
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virtual_collector_obj = NetBSDVirtualCollector()
    assert virtual_collector_obj._fact_class == NetBSDVirtual
    assert virtual_collector_obj._platform == 'NetBSD'

# Generated at 2022-06-23 02:28:37.695017
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    '''
    Unit test for method get_virtual_facts of class NetBSDVirtual
    '''

    def open(self, path, mode='r'):
        return True

    def readlines(self):

        # virtual_facts_vendor_type_host
        if self.path == "/usr/include/machdep.hypervisor":
            return ["VirtualBox\n"]
        # virtual_facts_type_host
        elif self.path == "/usr/include/machdep.dmi.system-vendor":
            return ["Google\n"]
        # virtual_facts_product_type_host
        elif self.path == "/usr/include/machdep.dmi.system-product":
            return ["Google Compute Engine\n"]
        # virtual_facts_type_guest

# Generated at 2022-06-23 02:28:40.166759
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    obj = NetBSDVirtual()
    assert obj.platform == 'NetBSD'


# Generated at 2022-06-23 02:28:50.530325
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    fact_netbsd_virtual = NetBSDVirtual()
    virtual_facts = fact_netbsd_virtual.get_virtual_facts()

    virtual_tech_guest = virtual_facts['virtualization_tech_guest']
    virtual_tech_host = virtual_facts['virtualization_tech_host']

    # If we are in a virtualization env, at least one of the
    # virtualization_tech_guest or virtualization_tech_host must be not empty
    # The virtualization_tech_guest is the set of virtualization guest technology
    # The virtualization_tech_host is the set of virtualization host technology
    if os.path.exists('/dev/xencons'):
        assert 'xen' in virtual_tech_guest
        # virtualization_tech_guest and virtualization_tech_host cannot be

# Generated at 2022-06-23 02:28:57.424743
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.platform == 'NetBSD'
    assert netbsd_virtual.virtualization_type == ''
    assert netbsd_virtual.virtualization_role == ''
    assert netbsd_virtual.virtualization_tech_guest == set()
    assert netbsd_virtual.virtualization_tech_host == set()


# Generated at 2022-06-23 02:29:00.834159
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert netbsd_virtual_collector._fact_class == NetBSDVirtual
    assert netbsd_virtual_collector._platform == 'NetBSD'

# Generated at 2022-06-23 02:29:03.448386
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert netbsd_virtual_collector._fact_class.platform == 'NetBSD'


# Generated at 2022-06-23 02:29:05.711602
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    obj = NetBSDVirtualCollector()
    assert obj.platform == "NetBSD"
    assert obj.fact_class == NetBSDVirtual


# Generated at 2022-06-23 02:29:09.059941
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual({})
    assert netbsd_virtual.virtualization_type == ''
    assert netbsd_virtual.virtualization_role == ''
    assert netbsd_virtual.virtualization_subtype == ''

# Generated at 2022-06-23 02:29:10.047920
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    NetBSDVirtualCollector()
    exit()

# Generated at 2022-06-23 02:29:12.395266
# Unit test for constructor of class NetBSDVirtualCollector

# Generated at 2022-06-23 02:29:13.408438
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    NetBSDVirtualCollector()


# Generated at 2022-06-23 02:29:24.653623
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # We need to set a few things up for this to work
    # (as a side-effect of running the facts module)
    os.environ['SVTEST'] = 'True'

    facts = NetBSDVirtual()
    # Run the get_virtual_facts method; it will return a list
    # of virtual facts to which we can compare the expected list.
    # Note that the NetBSD virtual.sysctl module is mocked to
    # return this data, so if the NetBSDVirtual class changes
    # in the future, we need to reevaluate the expected list.
    virtual_fact_list = facts.get_virtual_facts()
    assert type(virtual_fact_list) is dict

# Generated at 2022-06-23 02:29:27.014193
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    '''Check for constructor of class NetBSDVirtual'''
    netbsd_virtual = NetBSDVirtual()
    assert isinstance(netbsd_virtual, NetBSDVirtual)

# Generated at 2022-06-23 02:29:28.974006
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual()
    assert virtual.platform == 'NetBSD'


# Generated at 2022-06-23 02:29:31.206193
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd = NetBSDVirtual()
    assert netbsd.platform == 'NetBSD'

# Generated at 2022-06-23 02:29:38.364007
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual = NetBSDVirtual()
    facts = {}
    facts_expected = {'virtualization_type': '', 'virtualization_role': ''}
    with open(os.devnull, 'w') as null_fh:
        facts.update(netbsd_virtual.get_virtual_facts(null_fh))

    assert facts['virtualization_type'] == facts_expected['virtualization_type']
    assert facts['virtualization_role'] == facts_expected['virtualization_role']



# Generated at 2022-06-23 02:29:42.780082
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    my_netbsd_virtual = NetBSDVirtual()
    assert my_netbsd_virtual is not None
    my_netbsd_virtual.populate()
    assert my_netbsd_virtual.data['virtualization_type'] == ''
    assert my_netbsd_virtual.data['virtualization_role'] == ''


# Generated at 2022-06-23 02:29:43.258437
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    NetBSDVirtual()

# Generated at 2022-06-23 02:29:46.634752
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd = NetBSDVirtual({})
    assert netbsd.platform == 'NetBSD'
    assert netbsd.get_virtual_facts().keys() ==\
        set(['virtualization_type', 'virtualization_role',
             'virtualization_tech_guest', 'virtualization_tech_host'])

# Generated at 2022-06-23 02:29:51.565068
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual('NetBSD').get_virtual_facts()
    assert type(virtual_facts['virtualization_type']) is str
    assert type(virtual_facts['virtualization_role']) is str
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert type(virtual_facts['virtualization_tech_guest']) is set
    assert type(virtual_facts['virtualization_tech_host']) is set



# Generated at 2022-06-23 02:29:55.572671
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd = NetBSDVirtual()
    virtual_facts = netbsd.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''

# Generated at 2022-06-23 02:30:06.309613
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Create an instance of class NetBSDVirtual
    netbsd_virtual = NetBSDVirtual(module=None)

    fake_sysctl_results = {
        'machdep.dmi.system-product': 'VMware Virtual Platform',
        'machdep.dmi.system-vendor': 'VMware, Inc.',
        'machdep.hypervisor': 'Xen',
    }
    # Returns the results of the method get_virtual_facts
    results_virtual_facts = netbsd_virtual.get_virtual_facts(sysctl_results=fake_sysctl_results)

    assert results_virtual_facts['virtualization_type'] == 'xen'
    assert results_virtual_facts['virtualization_role'] == 'guest'

# Generated at 2022-06-23 02:30:07.554190
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert 'NetBSD' in netbsd_virtual.platform

# Generated at 2022-06-23 02:30:11.728175
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual = NetBSDVirtual()
    virtual_facts = virtual.get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-23 02:30:16.640955
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    my_obj = NetBSDVirtualCollector(None, None, None, None)
    assert (my_obj._platform == 'NetBSD')

# Generated at 2022-06-23 02:30:27.322993
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    class TestConfig(object):
        def get(self, unused):
            return 'test_config_value'
    Virtual.get_config = TestConfig()

    class TestSysctl(object):
        def all(self, unused):
            if unused == ('machdep.dmi.system-product'):
                return {'machdep.dmi.system-product': 'test_machdep_dmi_system_product'}
            elif unused == ('machdep.dmi.system-vendor'):
                return {'machdep.dmi.system-vendor': 'test_machdep_dmi_system_vendor'}
            elif unused == ('machdep.hypervisor'):
                return {'machdep.hypervisor': 'test_machdep_hypervisor'}

# Generated at 2022-06-23 02:30:36.693187
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    fake_module = type('', (), {'params': {'gather_subset': []}})()
    fake_sysctl = {
        "machdep.dmi.system-product": "VMware Virtual Platform",
        "machdep.dmi.system-vendor": "VMware, Inc.",
        "machdep.hypervisor": "Xen"
    }
    netbsd_virtual = NetBSDVirtual(fake_module)
    netbsd_virtual.get_netbsd_sysctl = lambda x: fake_sysctl[x]

    # Test case when no virtualization type is detected by NetBSD Virtual.

# Generated at 2022-06-23 02:30:41.864752
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    expected_virtual_facts = {
        'virtualization_type': '',
        'virtualization_type_role': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set([]),
        'virtualization_tech_host': set([])
    }
    # Check default facts
    virtual = NetBSDVirtual()
    virtual_facts = virtual.get_virtual_facts()
    assert expected_virtual_facts == virtual_facts

# Generated at 2022-06-23 02:30:44.591469
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virtual = NetBSDVirtualCollector({})
    assert virtual
    assert virtual.get_virtual_facts()

# Generated at 2022-06-23 02:30:45.554082
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector()

# Generated at 2022-06-23 02:30:50.808999
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    # Create collector object
    collectoObj = NetBSDVirtualCollector()
    # Check instance created or not
    assert collectoObj is not None
    # Check class name
    assert collectoObj.__class__.__name__ == 'NetBSDVirtualCollector'

# Generated at 2022-06-23 02:30:53.434305
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual()
    assert virtual_facts._platform == 'NetBSD'
    assert virtual_facts._fact_class == NetBSDVirtual


# Generated at 2022-06-23 02:30:55.959303
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virtual_collector = NetBSDVirtualCollector()
    assert virtual_collector._platform == 'NetBSD'
    assert virtual_collector._fact_class == NetBSDVirtual


# Generated at 2022-06-23 02:30:57.031995
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    NetBSDVirtualCollector()

# Generated at 2022-06-23 02:31:06.026985
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] in ['', 'virtualbox', 'vmware', 'kvm', 'xen', 'hyperv']
    assert virtual_facts['virtualization_role'] in ['', 'guest', 'host']
    assert 'virtualbox' in virtual_facts['virtualization_tech_guest']
    assert 'virtualbox' in virtual_facts['virtualization_tech_host']
    assert 'vmware' in virtual_facts['virtualization_tech_guest']
    assert 'vmware' in virtual_facts['virtualization_tech_host']
    assert 'kvm' in virtual_facts['virtualization_tech_guest']
    assert 'kvm' in virtual_facts['virtualization_tech_host']
    assert 'xen' in virtual_

# Generated at 2022-06-23 02:31:11.562319
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert netbsd_virtual_collector._platform == 'NetBSD'
    assert issubclass(netbsd_virtual_collector._fact_class, NetBSDVirtual)

# Generated at 2022-06-23 02:31:13.704525
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virt_collector = NetBSDVirtualCollector()
    assert virt_collector._platform == 'NetBSD'
    assert virt_collector._fact_class == NetBSDVirtual


# Generated at 2022-06-23 02:31:22.347592
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    class MockModule(object):
        def __init__(self):
            self.params = {}

    module = MockModule()

    # Start with empty facts dict
    facts = dict()

    # Mock uname so we have known values.
    uname_result = {
        'sysname': 'NetBSD',
    }
    mock_uname_func = lambda *args: uname_result[args[0]]

    sysctl_results = {
        'machdep.dmi.system-vendor': 'BHYVE',
        'machdep.dmi.system-product': 'BHYVE',
        'machdep.hypervisor': 'BHYVE',
    }
    mock_sysctl_func = lambda command: sysctl_results[command]


# Generated at 2022-06-23 02:31:32.431275
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    fact_class = NetBSDVirtual('ansible.module_utils.facts.virtual.netbsd.NetBSDVirtual')
    ret = fact_class.get_virtual_facts()
    assert 'virtualization_type' in ret
    assert isinstance(ret['virtualization_type'], str)
    assert 'virtualization_role' in ret
    assert isinstance(ret['virtualization_role'], str)
    assert 'virtualization_tech_guest' in ret
    assert isinstance(ret['virtualization_tech_guest'], set)
    assert 'virtualization_tech_host' in ret
    assert isinstance(ret['virtualization_tech_host'], set)

# Generated at 2022-06-23 02:31:41.615847
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    facts = NetBSDVirtual()
    virtual_facts = facts.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert 'xen' in virtual_facts['virtualization_tech_guest']
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-23 02:31:43.086064
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virt = NetBSDVirtual()
    assert virt
    assert repr(virt)


# Generated at 2022-06-23 02:31:44.557799
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual_test = NetBSDVirtual()
    assert netbsd_virtual_test is not None

# Generated at 2022-06-23 02:31:47.979041
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual(None, None)
    assert netbsd_virtual.platform == 'NetBSD'

# Generated at 2022-06-23 02:31:49.397543
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    v = NetBSDVirtual()
    assert v.platform == "NetBSD"

# Generated at 2022-06-23 02:31:49.939267
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    pass

# Generated at 2022-06-23 02:31:56.792346
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virtual_facts = NetBSDVirtualCollector().collect(None, None)
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_system'] == ''
    assert virtual_facts['virtualization_product_name'] == ''
    assert virtual_facts['virtualization_product_version'] == ''
    assert virtual_facts['virtualization_product_serial'] == ''
    assert virtual_facts['virtualization_product_uuid'] == ''

# Generated at 2022-06-23 02:31:57.460325
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert True

# Generated at 2022-06-23 02:32:07.234971
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    VirtualCollector._cache = {}

    # Test that get_virtual_facts returns expected dictionary
    def mock_sysctl(data):
        def mock_call(arg):
            if arg == 'machdep.hypervisor':
                return 'The hypervisor name is kvm'
            elif arg == 'machdep.dmi.system-vendor':
                return 'System vendor is IBM'
            elif arg == 'machdep.dmi.system-product':
                return 'System product is IBM'
            return 'foo'
        return mock_call

    def mock_path_exists(data):
        def mock_call(arg):
            if arg == '/dev/xencons':
                return True
            return False
        return mock_call

    mock_module = type('module', (), {})()

# Generated at 2022-06-23 02:32:10.181920
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    nv = NetBSDVirtual()
    assert nv.platform == 'NetBSD'


# Generated at 2022-06-23 02:32:13.411325
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual(None)
    netbsd_virtual._module = None
    netbsd_virtual.get_virtual_facts()

# Generated at 2022-06-23 02:32:20.509107
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virt = NetBSDVirtual()

    # Fake the get_file_content method to return
    # proper virtualization information
    virt.get_file_content = lambda x: '''
Xen3.0.3
'''

    # Test get_virtual_facts. Test to see that at least
    # the virtualization type is set
    virtual_facts = virt.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'

# Generated at 2022-06-23 02:32:22.764824
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_instance = NetBSDVirtual(None)
    virtual_instance.collect()
    virtual_instance.get_virtual_facts()

# Generated at 2022-06-23 02:32:23.834604
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector

# Generated at 2022-06-23 02:32:26.454714
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virt_facts = NetBSDVirtualCollector().collect()
    assert 'virtualization_type' in virt_facts
    assert 'virtualization_role' in virt_facts

# Generated at 2022-06-23 02:32:30.831243
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual = NetBSDVirtual()
    virtual_facts = netbsd_virtual.get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts
    assert 'virtualization_product_name' in virtual_facts



# Generated at 2022-06-23 02:32:36.904581
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    x = NetBSDVirtualCollector()
    assert x.platform == 'NetBSD'
    assert x.fact_class == NetBSDVirtual

# Generated at 2022-06-23 02:32:39.689275
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual = NetBSDVirtualCollector()
    assert netbsd_virtual._fact_class is not None
    assert netbsd_virtual._platform is not None

# Generated at 2022-06-23 02:32:42.170046
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsdvirtualcollector = NetBSDVirtualCollector()
    assert netbsdvirtualcollector._platform == 'NetBSD'
    assert netbsdvirtualcollector.platform == 'NetBSD'

# Generated at 2022-06-23 02:32:44.338491
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual()
    assert virtual_facts is not None

# Generated at 2022-06-23 02:32:45.956983
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual()
    assert virtual.platform == 'NetBSD'

# Generated at 2022-06-23 02:32:46.547480
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    pass

# Generated at 2022-06-23 02:32:49.918661
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    from ansible.module_utils.facts.virtual.netbsd import NetBSDVirtualCollector
    c = NetBSDVirtualCollector()
    assert c.platform == "NetBSD"
    assert c._fact_class.platform == "NetBSD"
    assert c._fact_class._platform == "NetBSD"


# Generated at 2022-06-23 02:32:51.491391
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsdvirtual = NetBSDVirtual()
    netbsdvirtual.get_virtual_facts()

# Generated at 2022-06-23 02:32:52.312200
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    assert NetBSDVirtual({'module_setup': {}})

# Generated at 2022-06-23 02:33:03.575529
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    '''Unit test for method get_virtual_facts of class NetBSDVirtual'''

    facter_result_vbox = {'machdep.dmi.system-product': 'VirtualBox',
                          'machdep.dmi.system-vendor': 'innotek GmbH'}
    facter_result_vmware = {'machdep.dmi.system-product': 'VMware7,1',
                            'machdep.dmi.system-vendor': 'VMware, Inc.'}
    facter_result_xen = {'machdep.dmi.system-product': 'HVM domU',
                          'machdep.dmi.system-vendor': 'Xen',
                          'machdep.hypervisor': 'Xen'}

    virtualNetBSD_vbox = Net

# Generated at 2022-06-23 02:33:13.818586
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd = NetBSDVirtual({})

    # Test for get_virtual_facts without passing any argument
    netbsd_facts = netbsd.get_virtual_facts()
    assert netbsd_facts['virtualization_type'] == ''
    assert netbsd_facts['virtualization_role'] == ''
    assert netbsd_facts['virtualization_use_type_facts'] is True

    # Test for get_virtual_facts passing an argument - arch_string
    netbsd_facts = netbsd.get_virtual_facts(arch_string='amd64')
    assert netbsd_facts['virtualization_type'] == ''
    assert netbsd_facts['virtualization_role'] == ''
    assert netbsd_facts['virtualization_use_type_facts'] is True

    # Test for get_virtual_facts passing

# Generated at 2022-06-23 02:33:15.379308
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual()
    assert virtual_facts.platform == 'NetBSD'

# Generated at 2022-06-23 02:33:16.908753
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtualCollector()
    assert netbsd_virtual._fact_class is NetBSDVirtual

# Generated at 2022-06-23 02:33:19.896738
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual_facts = NetBSDVirtual()
    assert netbsd_virtual_facts.platform == 'NetBSD'


# Generated at 2022-06-23 02:33:31.999863
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    fake_ansible_module = type('AnsibleModule')
    fake_ansible_module.params = {}
    collected_facts = {'ansible_facts': {'ansible_virtualization_type': '',
                                         'ansible_virtualization_role': '',
                                         'ansible_virtualization_technology_guest': '',
                                         'ansible_virtualization_technology_host': '',
                                         'ansible_virtualization_hypervisor': '',
                                         'ansible_virtualization_hypervisor_product': '',
                                         'ansible_virtualization_hypervisor_product_name': ''}}
    nv = NetBSDVirtual(fake_ansible_module)
    assert {} == nv.get_virtual_facts()


# Generated at 2022-06-23 02:33:35.322853
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.get_virtual_facts() == netbsd_virtual.platform


# Generated at 2022-06-23 02:33:42.818597
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():

    # Create instance of NetBSDVirtual and assign to variable
    netbsd_virtual = NetBSDVirtual()

    # Create a dictionary to mock sysctl return and assign to variable
    sysctl_dict_mock = {
        'machdep.dmi.system-vendor': 'Dell Inc.',
        'machdep.dmi.system-product': 'PowerEdge R460',
        'machdep.hypervisor': 'None'
    }

    # Create a dictionary to mock existing files and assign to variable
    file_dict_mock = {
        'dev/xencons': False
    }

    # Create a dictionary to mock file of return data and assign to variable
    module_result = {}

    # Assign value to variable
    file_existing = False

    # Set a VirtualCollector instance in order to be able to call _

# Generated at 2022-06-23 02:33:51.928044
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    passed = False
    fail_msg = ''
    v = NetBSDVirtual('module')
    v.facts['machdep.dmi.system-product'] = 'VMware Virtual Platform'
    v.facts['machdep.dmi.system-vendor'] = 'VMware, Inc.'
    v.facts['machdep.hypervisor'] = ''
    virtual_facts = v.get_virtual_facts()
    facts = {
        'virtualization_type': 'VMware',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': {'vmware_server'},
        'virtualization_tech_host': {'vmware_server'},
    }
    if virtual_facts != facts:
        fail_msg = "test_NetBSDVirtual_get_virtual_facts: facts mismatch"

# Generated at 2022-06-23 02:33:57.525057
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual_platform = NetBSDVirtual()
    assert netbsd_virtual_platform.platform == 'NetBSD'
    assert netbsd_virtual_platform._platform == 'NetBSD'
    assert netbsd_virtual_platform.virtualization_type == ''
    assert netbsd_virtual_platform.virtualization_role == ''

# Generated at 2022-06-23 02:34:05.159711
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Set up values which would be returned by sysctl
    sysctl_values = {
        "hw.model": "Intel(R) Xeon(R) CPU E5-2680 v2 @ 2.80GHz",
        "machdep.dmi.system-product": "KVM",
        "machdep.dmi.system-vendor": "To Be Filled By O.E.M.",
        "machdep.hypervisor": "",
        "machdep.smt": "2",
        "vm.loadavg": "0.00 0.00 0.00 1/504 29340",
    }

    facts = NetBSDVirtual(None, sysctl_values=sysctl_values).get_virtual_facts()

    assert facts['virtualization_type'] == 'kvm'
    assert facts['virtualization_role']

# Generated at 2022-06-23 02:34:16.330757
# Unit test for constructor of class NetBSDVirtual