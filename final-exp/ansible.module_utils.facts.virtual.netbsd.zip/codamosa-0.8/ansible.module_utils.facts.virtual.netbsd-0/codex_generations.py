

# Generated at 2022-06-11 05:56:55.768498
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.platform == 'NetBSD'

# Generated at 2022-06-11 05:57:01.448124
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virt_detect = NetBSDVirtual()
    # NetBSD has a "machdep.hypervisor.vendor" sysctl
    assert 'machdep.hypervisor.vendor' in virt_detect.sysctl_patterns

    # NetBSD has a "machdep.dmi.system-vendor" sysctl
    assert 'machdep.dmi.system-vendor' in virt_detect.sysctl_patterns

# Generated at 2022-06-11 05:57:06.140162
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual_ins = NetBSDVirtual()
    assert netbsd_virtual_ins.get_virtual_facts() == dict(virtualization_type='',
                                                          virtualization_role='',
                                                          virtualization_tech_host=set(),
                                                          virtualization_tech_guest=set())

# Generated at 2022-06-11 05:57:07.771452
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd = NetBSDVirtual()
    assert isinstance(netbsd, NetBSDVirtual)
    assert netbsd.platform == 'NetBSD'

# Generated at 2022-06-11 05:57:09.513451
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual(None)
    assert netbsd_virtual
    assert netbsd_virtual.platform == 'NetBSD'

# Generated at 2022-06-11 05:57:10.948752
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = {}
    v = NetBSDVirtual()
    assert v.get_virtual_facts() == virtual_facts

# Generated at 2022-06-11 05:57:15.425707
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    test_object = NetBSDVirtual({})
    result = test_object.get_virtual_facts()
    assert 'virtualization_type' in result
    assert 'virtualization_role' in result
    assert 'virtualization_tech_guest' in result
    assert 'virtualization_tech_host' in result
    assert 'virtual_product_name' in result

# Generated at 2022-06-11 05:57:20.258446
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual('/usr/sbin/sysctl', '/dev/xen/evtchn')

    assert netbsd_virtual.sysctl_path == '/usr/sbin/sysctl'
    assert netbsd_virtual.evtchn_path == '/dev/xen/evtchn'

    assert netbsd_virtual.platform == 'NetBSD'

# Generated at 2022-06-11 05:57:21.173820
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    NetBSDVirtualCollector()

# Generated at 2022-06-11 05:57:26.101753
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virt_obj = NetBSDVirtual(module=None, collected_facts={})
    res = virt_obj.get_virtual_facts()
    assert res['virtualization_type'] == ''
    assert res['virtualization_role'] == ''
    assert res['virtualization_tech_host'] == set()
    assert res['virtualization_tech_guest'] == set()

# Generated at 2022-06-11 05:57:32.570258
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.platform == 'NetBSD'
    assert netbsd_virtual.collector_class == 'NetBSDVirtualCollector'

# Generated at 2022-06-11 05:57:34.855237
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector._platform == 'NetBSD'
    assert NetBSDVirtualCollector._fact_class == NetBSDVirtual


# Generated at 2022-06-11 05:57:37.978894
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual(None).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_technologies_guest'] == {'xen'}
    assert virtual_facts['virtualization_technologies_host'] == set()

# Generated at 2022-06-11 05:57:38.998020
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    NetBSDVirtualCollector()

# Generated at 2022-06-11 05:57:41.042592
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    try:
        NetBSDVirtualCollector()
        assert True
    except:
        assert False


# Generated at 2022-06-11 05:57:43.160610
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual(None)
    assert netbsd_virtual

# Generated at 2022-06-11 05:57:47.985979
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    facts = NetBSDVirtualCollector().collect(None, None)
    assert facts['virtualization_type'] == ''
    assert facts['virtualization_role'] == ''
    assert facts['virtualization_sysctl_machdep_dmi_system_product'] == ''
    assert facts['virtualization_sysctl_machdep_dmi_system_vendor'] == ''



# Generated at 2022-06-11 05:57:52.373103
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    # Create NetBSDVirtualCollector object
    obj = NetBSDVirtualCollector()
    # Check it's the correct class
    assert isinstance(obj, NetBSDVirtualCollector)
    # Check it's an instance of VirtualCollector
    assert isinstance(obj, VirtualCollector)



# Generated at 2022-06-11 05:57:53.554788
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual({}, {})
    assert virtual.__class__.__name__ == 'NetBSDVirtual'


# Generated at 2022-06-11 05:57:55.092918
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual = NetBSDVirtual()
    virtual_facts = virtual.get_virtual_facts()
    assert 'virtualization_type' in virtual_facts


# Generated at 2022-06-11 05:58:03.216797
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()

    # Check if the constructor returns an object of NetBSDVirtual class
    assert isinstance(netbsd_virtual, NetBSDVirtual)

    # Check if there is a virtualizations_type attribute
    assert hasattr(netbsd_virtual, 'virtualization_type')



# Generated at 2022-06-11 05:58:11.682699
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': {},
        'virtualization_tech_host': {}
    }

    # Setup the mocks for machdep.dmi.system-product
    setup_mocks = {
        'machdep.dmi.system-product': 'VirtualBox',
        'machdep.dmi.system-vendor': 'Oracle Corporation',
        'machdep.hypervisor': '',
        'dev_xencons': None,
    }
    virtual_facts = NetBSDVirtual.get_virtual_facts(setup_mocks, virtual_facts)

    # Assert the returned virtual_facts
    assert virtual_facts['virtualization_type'] == 'virtualbox'
    assert virtual_facts

# Generated at 2022-06-11 05:58:14.927109
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    assert NetBSDVirtualCollector._platform == 'NetBSD'
    assert NetBSDVirtualCollector._fact_class.platform == 'NetBSD'
    assert NetBSDVirtualCollector._fact_class.get_virtual_facts().has_key('virtualization_type')

# Generated at 2022-06-11 05:58:17.951152
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    my_virtual_collector = NetBSDVirtualCollector()
    assert my_virtual_collector._platform == 'NetBSD'
    assert my_virtual_collector._fact_class._platform == 'NetBSD'

# Generated at 2022-06-11 05:58:24.259256
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.platform == 'NetBSD'
    assert netbsd_virtual._sysctl.platform == netbsd_virtual.platform
    assert netbsd_virtual.sysctl_has_prefixed_values('hw.') is True
    assert netbsd_virtual.sysctl_has_prefixed_values('machdep.') is True
    assert netbsd_virtual.sysctl_has_prefixed_values('vm.') is False

# Generated at 2022-06-11 05:58:34.277484
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():

    # Create a class object
    netbsd_virt = NetBSDVirtual({})

    # Create a test dictionary
    test_dict = {}
    test_dict['virtualization_type'] = 'virtualbox'
    test_dict['virtualization_role'] = 'guest'
    test_dict['virtualization_tech_guest'] = set(['vbox'])
    test_dict['virtualization_tech_host'] = set(['vbox'])
    test_dict['virtualization_product'] = 'VirtualBox'
    test_dict['virtualization_vendor'] = 'Oracle'

    # Call the method with a test file
    output = netbsd_virt.get_virtual_facts('tests/unit/modules/netbsd_virtual.txt')

    # Compare output with test dictionary
    assert output == test_dict

# Generated at 2022-06-11 05:58:38.644179
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    v = NetBSDVirtual()
    virtual_facts = v.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-11 05:58:39.856785
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual

# Generated at 2022-06-11 05:58:49.938957
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual().get_virtual_facts()

    # Test libvirt_product_name
    libvirt_product_name = virtual_facts.get('libvirt_product_name')
    assert libvirt_product_name is None or isinstance(libvirt_product_name, str)

    # Test libvirt_system_uuid
    libvirt_system_uuid = virtual_facts.get('libvirt_system_uuid')
    assert libvirt_system_uuid is None or isinstance(libvirt_system_uuid, str)

    # Test virtualization_role
    virtualization_role = virtual_facts.get('virtualization_role')
    assert virtualization_role is None or isinstance(virtualization_role, str)

    # Test virtualization_type

# Generated at 2022-06-11 05:58:57.898658
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virt = NetBSDVirtual({}, [], [])
    if virt.platform != 'NetBSD':
        raise Exception('test must be run on a NetBSD system')

    # on a netbsd system
    facts = {}
    sysctl_virtual_facts = virt.get_virtual_facts()
    facts.update(sysctl_virtual_facts)
    if facts['virtualization_role'] == '':
        raise Exception('no virtualization role found')

    if facts['virtualization_role'] == 'guest':
        if facts['virtualization_type'] == '':
            raise Exception('no virtualization tech found')

# Generated at 2022-06-11 05:59:15.210699
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    test_host = NetBSDVirtual()

    # test_get_virtual_facts_KVM
    test_host.sysctl_output = \
        '''
        machdep.dmi.system-manufacturer = 'Red Hat'
        machdep.dmi.system-product = 'KVM'
        machdep.dmi.system-version = 'pc-0.12'
        machdep.hypervisor.vendor = 'KVM'
        machdep.hypervisor.version = 'pc-0.12'
        '''
    desired_output = \
        {
        'virtualization_type': 'KVM',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': {'kvm'},
        'virtualization_tech_host': {'kvm'}
        }

# Generated at 2022-06-11 05:59:17.327255
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert netbsd_virtual_collector


# Generated at 2022-06-11 05:59:19.644859
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert netbsd_virtual_collector._platform == 'NetBSD'
    assert netbsd_virtual_collector._fact_class == NetBSDVirtual


# Generated at 2022-06-11 05:59:23.248779
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual({}).get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-11 05:59:29.262861
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual()
    assert virtual_facts.platform == 'NetBSD'
    assert virtual_facts.get_virtual_facts()['virtualization_type'] == ''
    assert virtual_facts.get_virtual_facts()['virtualization_role'] == ''
    assert virtual_facts.get_virtual_facts()['virtualization_tech_guest'] == set()
    assert virtual_facts.get_virtual_facts()['virtualization_tech_host'] == set()

# Generated at 2022-06-11 05:59:32.238388
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.platform == 'NetBSD'
    assert 'virtualization_type' in netbsd_virtual.get_virtual_facts()

# Generated at 2022-06-11 05:59:33.582873
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector()

# Generated at 2022-06-11 05:59:35.354945
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert 'NetBSD' == netbsd_virtual.platform

# Generated at 2022-06-11 05:59:37.858655
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    """Unit test for constructor of class NetBSDVirtual"""
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.platform == 'NetBSD'

# Generated at 2022-06-11 05:59:40.630366
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual(module=None)

    assert virtual._platform == 'NetBSD'
    assert virtual._fact_class is NetBSDVirtual
    assert virtual._collector_class is NetBSDVirtualCollector



# Generated at 2022-06-11 06:00:01.303330
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():

    _machdep_dmi_system_product_data = {
        'class': 'machdep.dmi.system-product',
        'data': 'Xen,HVM domU'
    }

    _machdep_dmi_system_vendor_data = {
        'class': 'machdep.dmi.system-vendor',
        'data': 'Xen'
    }

    _machdep_hypervisor_data = {
        'class': 'machdep.hypervisor',
        'data': 'Xen 4.8.0-release'
    }

    fake_sysctl_data = [_machdep_dmi_system_product_data,
                        _machdep_dmi_system_vendor_data,
                        _machdep_hypervisor_data]

    virtual

# Generated at 2022-06-11 06:00:04.330298
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virt_fact_collector = NetBSDVirtualCollector()
    assert isinstance(virt_fact_collector, NetBSDVirtualCollector)
    assert isinstance(virt_fact_collector._fact_class, NetBSDVirtual)

# Generated at 2022-06-11 06:00:08.320310
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual({})
    assert netbsd_virtual.platform == 'NetBSD'
    assert netbsd_virtual.machdep_sysctl_name == 'machdep.hypervisor'


# Generated at 2022-06-11 06:00:15.423218
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():

    # Return values for sysctl is a list
    # [value, error]
    fake_sysctl_data = {
        'machdep.dmi.system-product': ['', 'Error'],
        'machdep.dmi.system-vendor': ['Red Hat KVM', ''],
        'machdep.hypervisor': ['tcg', ''],
        'machdep.cpu.vendor': ['GenuineIntel', ''],
    }

    collector = NetBSDVirtualCollector(context=FakeContext(sysctl_retvals=fake_sysctl_data))
    result = collector.collect()

# Generated at 2022-06-11 06:00:19.859458
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual()
    keys = virtual_facts.get_virtual_facts().keys()
    for key in ['virtualization_type', 'virtualization_role', 'virtualization_tech_guest', 'virtualization_tech_host']:
        assert key in keys


# Generated at 2022-06-11 06:00:21.183986
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual()
    assert virtual_facts._platform == 'NetBSD'

# Generated at 2022-06-11 06:00:23.689754
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''

# Generated at 2022-06-11 06:00:25.472658
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsdvirtual = NetBSDVirtual()
    assert netbsdvirtual.platform == 'NetBSD', 'Platform should be set to NetBSD'


# Generated at 2022-06-11 06:00:26.957258
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    fake_module = type('module', (), {'params': {}})
    assert NetBSDVirtual(fake_module)

# Generated at 2022-06-11 06:00:29.157405
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virtual_collector_obj = NetBSDVirtualCollector()
    assert(virtual_collector_obj.platform == "NetBSD")


# Generated at 2022-06-11 06:00:59.382018
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual()
    assert virtual_facts._platform == 'NetBSD'
    assert virtual_facts.get_all_facts() == {
        'ansible_virtualization_type': '',
        'ansible_virtualization_role': ''
    }

# Generated at 2022-06-11 06:01:01.631504
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virt = NetBSDVirtual()
    assert virt is not None


# Unit test to test that the NetBSD virtualization detection works
# correctly both on baremetal and in a virtual guest

# Generated at 2022-06-11 06:01:06.819917
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    obj = NetBSDVirtual()
    tests = [
        ('none', {
            'virtualization_type': '',
            'virtualization_role': '',
        }),
    ]

    for (test_input, expected) in tests:
        result = obj.get_virtual_facts(test_input)

        assert result['virtualization_type'] == expected['virtualization_type']
        assert result['virtualization_role'] == expected['virtualization_role']

# Generated at 2022-06-11 06:01:08.707665
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    v = NetBSDVirtual()
    assert v.platform == "NetBSD"


# Generated at 2022-06-11 06:01:12.288890
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virt = NetBSDVirtual()
    facts = virt.get_virtual_facts()
    assert facts['virtualization_type'] == 'xen'
    assert facts['virtualization_role'] == 'guest'
    assert facts['virtualization_view'] == 'guest'

# Generated at 2022-06-11 06:01:13.487534
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsdv = NetBSDVirtual()
    assert netbsdv is not None

# Generated at 2022-06-11 06:01:16.508258
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    global_module = test_module(argument_spec={})
    # Test with empty value
    vm = NetBSDVirtual(global_module)
    # Check it has the right name
    assert vm.platform == 'NetBSD'


# Generated at 2022-06-11 06:01:18.843775
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual_fact = NetBSDVirtual()
    assert isinstance(netbsd_virtual_fact, Virtual)
    assert isinstance(netbsd_virtual_fact, NetBSDVirtual)

# Generated at 2022-06-11 06:01:20.359413
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virt = NetBSDVirtual()
    assert netbsd_virt._platform == 'NetBSD'

# Generated at 2022-06-11 06:01:27.574790
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    '''Unit test to check return value of NetBSDVirtual get_virtual_facts'''
    from ansible.module_utils.facts.virtual.netbsd import NetBSDVirtual
    netbsd_collector_obj = NetBSDVirtual()

    virtual_facts_dict = {
        "virtualization_role": "",
        "virtualization_type": "",
        "virtualization_tech_guest": set(),
        "virtualization_tech_host": set()
    }
    assert virtual_facts_dict == netbsd_collector_obj.get_virtual_facts()

# Generated at 2022-06-11 06:02:44.811408
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = dict()

    # Set values as they would be if machdep.dmi.system-vendor is set
    virtual_facts['machdep.dmi.system-vendor'] = 'VMware, Inc.'
    virtual_facts['machdep.dmi.system-product'] = 'VMware Virtual Platform'
    netbsd_virtual = NetBSDVirtual({}, virtual_facts, None)
    virtual_facts = netbsd_virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'VMware'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set(['VMware'])

    # Set values as they would be if

# Generated at 2022-06-11 06:02:46.855672
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd = NetBSDVirtualCollector()
    assert netbsd
    assert netbsd._platform is 'NetBSD'
    assert netbsd._fact_class is NetBSDVirtual

# Generated at 2022-06-11 06:02:50.175755
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    facts = NetBSDVirtual()
    assert facts.virtualization_type == ''
    assert facts.virtualization_role == ''
    assert sorted(facts.virtualization_tech_guest) == sorted([])
    assert sorted(facts.virtualization_tech_host) == sorted([])


# Generated at 2022-06-11 06:02:51.677530
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virt = NetBSDVirtual()
    assert virt.platform == 'NetBSD'



# Generated at 2022-06-11 06:02:54.321884
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual().get_virtual_facts()
    assert sorted(virtual_facts.items()) == [('virtualization_role', ''),
                                        ('virtualization_type', '')]

# Generated at 2022-06-11 06:02:56.145286
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.platform == 'NetBSD'

# Generated at 2022-06-11 06:02:58.099768
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsdvirtual = NetBSDVirtualCollector()
    assert netbsdvirtual._platform == 'NetBSD'

# Generated at 2022-06-11 06:03:01.802021
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual = NetBSDVirtual('dummy')
    netbsd_virtual_facts = netbsd_virtual.get_virtual_facts()
    assert netbsd_virtual_facts['virtualization_type'] == ''
    assert netbsd_virtual_facts['virtualization_role'] == ''

# Generated at 2022-06-11 06:03:06.803159
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    _fact_class = NetBSDVirtual({}, {})
    virtual_facts = _fact_class.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'joyent'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_guest'] == set(['kvm'])
    assert virtual_facts['virtualization_tech_host'] == set(['kvm'])



# Generated at 2022-06-11 06:03:16.007263
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    import sys
    import os

    # Add a module util path, so Ansible facts can use it
    module_utils_path = os.path.join(os.path.dirname(__file__), '../../../module_utils')
    sys.path.append(module_utils_path)

    from ansible.module_utils.facts.virtual.sysctl import VirtualSysctlDetectionMixin
    import ansible.module_utils.facts.virtual.netbsd as netbsd

    netbsd_sysctl_obj = netbsd.NetBSDVirtual()
    assert isinstance(netbsd_sysctl_obj, netbsd.NetBSDVirtual)
    assert isinstance(netbsd_sysctl_obj, netbsd.VirtualSysctlDetectionMixin)

# Generated at 2022-06-11 06:06:04.408759
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert netbsd_virtual_collector._platform == 'NetBSD'
    assert netbsd_virtual_collector._fact_class.platform == 'NetBSD'

# Generated at 2022-06-11 06:06:05.794507
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd1 = NetBSDVirtual()
    assert isinstance(netbsd1.supported_facts, dict)

# Generated at 2022-06-11 06:06:14.079474
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.netbsd import NetBSDVirtual
    virtual = NetBSDVirtual()

    sysctl_mock = object()
    lspci_mock = object()

    virtual._get_sysctl = lambda x: sysctl_mock
    virtual._get_lspci = lambda x: lspci_mock

    # No virtualization information
    virtual._get_sysctl.return_value = {
        'machdep.dmi.system-product': '',
        'machdep.dmi.system-vendor': '',
    }
    virtual._get_lspci.return_value = ''

    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''

# Generated at 2022-06-11 06:06:17.934025
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual({}, {}, {})
    assert virtual.platform == 'NetBSD'
    assert virtual.virtual == 'NetBSD'
    assert virtual.virtualization_type == ''
    assert virtual.virtualization_role == ''
    assert virtual.virtualization_tech_guest == set()
    assert virtual.virtualization_tech_host == set()

# Generated at 2022-06-11 06:06:18.766985
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector



# Generated at 2022-06-11 06:06:19.575139
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector is not None

# Generated at 2022-06-11 06:06:21.512885
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    collector = NetBSDVirtualCollector()
    assert collector.platform == "NetBSD"
    assert collector.fact_class == NetBSDVirtual

# Generated at 2022-06-11 06:06:23.451315
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_role'] == ''
    assert virtu

# Generated at 2022-06-11 06:06:24.861077
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual = NetBSDVirtual()
    netbsd_virtual.get_virtual_facts()

# Generated at 2022-06-11 06:06:26.675992
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual({}, None, {})
    assert netbsd_virtual.platform == 'NetBSD'
