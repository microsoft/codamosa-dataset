

# Generated at 2022-06-11 05:56:55.861429
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_obj = NetBSDVirtualCollector()
    assert netbsd_obj is not None

# Generated at 2022-06-11 05:56:58.282696
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virt_col = NetBSDVirtualCollector()
    assert virt_col.platform == "NetBSD"
    assert virt_col._fact_class == NetBSDVirtual


# Generated at 2022-06-11 05:56:58.889104
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    pass

# Generated at 2022-06-11 05:57:00.717537
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.platform == 'NetBSD'

# Generated at 2022-06-11 05:57:06.179292
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    fact = NetBSDVirtual()

    fact.module = MockModule()

    assert fact.get_virtual_facts() == {
        "virtualization_role": "guest",
        "virtualization_type": "xen",
        "virtualization_tech_host": {
            'xen'
        },
        "virtualization_tech_guest": {
            'xen'
        }
    }


# Generated at 2022-06-11 05:57:08.128838
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virt_collector = NetBSDVirtualCollector()
    assert virt_collector._platform == 'NetBSD'
    assert virt_collector._fact_class == NetBSDVirtual

# Generated at 2022-06-11 05:57:17.378281
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_obj = NetBSDVirtual()
    virtual_obj._get_sysctl_value = mock_get_sysctl_value
    virtual_obj._get_dmesg_value = mock_get_dmesg_value
    virtual_obj._get_sysctl_mib_value = mock_get_sysctl_mib_value
    virtual_obj._get_sysctl_mib_values = mock_get_sysctl_mib_values
    facts = virtual_obj.get_virtual_facts()

    assert facts['virtualization_type'] == 'kvm'
    assert facts['virtualization_role'] == 'guest'
    assert facts['virtualization_tech_guest'].issuperset(['kvm'])
    assert facts['virtualization_tech_host'].issuperset(['kvm'])



# Generated at 2022-06-11 05:57:19.141417
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.platform == 'NetBSD'

# Generated at 2022-06-11 05:57:29.052507
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    import platform
    from ansible.module_utils.facts.virtual.sysctl import SYSCTL_DATA
    from ansible.module_utils.facts.virtual.proc import PROC_DATA

    # create a fake instance of a NetBSDVirtual object
    v = NetBSDVirtual(platform)
    v.sysctl = SYSCTL_DATA
    v.proc = PROC_DATA

    # test detection of virtual product
    virtual_product_facts = v.detect_virt_product(SYSCTL_DATA['machdep.dmi.system-product'])
    assert virtual_product_facts['virtualization_type'] == 'virtualbox'
    assert virtual_product_facts['virtualization_role'] == 'guest'

    # test detection of virtual vendor

# Generated at 2022-06-11 05:57:37.808439
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual()
    virtual_facts['sysctl.mib'] = {'machdep.dmi.system-product': 'VMware Virtual Platform',
                                   'machdep.dmi.system-vendor': 'VMware, Inc.',
                                   'machdep.hypervisor': 'VMware'}
    virtual_facts_out = virtual_facts.get_virtual_facts()
    assert virtual_facts_out['virtualization_type'] == 'vmware', 'Failed asserting virtual_facts["virtualization_type"] output.'
    assert virtual_facts_out['virtualization_role'] == 'guest', 'Failed asserting virtual_facts["virtualization_role"] output.'

# Generated at 2022-06-11 05:57:42.435987
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    NetBSDVirtual()


# Generated at 2022-06-11 05:57:47.472358
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_obj = NetBSDVirtual()
    virtual_facts = virtual_obj.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert len(virtual_facts['virtualization_tech_guest']) == 0
    assert len(virtual_facts['virtualization_tech_host']) == 0

# Generated at 2022-06-11 05:57:49.865930
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector._fact_class == NetBSDVirtual
    assert NetBSDVirtualCollector._platform == 'NetBSD'


# Generated at 2022-06-11 05:57:57.763753
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Inputs
    test_virtual_facts = NetBSDVirtual()
    inputs = {'hypervisor': "", 'product': ""}
    inputs_xen = {'hypervisor': "XenVMMXenVMM", 'product': ""}
    inputs_qemu = {'hypervisor': "", 'product': "KVM"}

    # Outputs
    outputs = {'virtualization_type': '', 'virtualization_role': '',
               'virtualization_tech_guest': set(),
               'virtualization_tech_host': set()}
    outputs_xen = {'virtualization_type': 'xen', 'virtualization_role': 'guest',
                   'virtualization_tech_guest': set(['xen']),
                   'virtualization_tech_host': set()}
    outputs_qemu

# Generated at 2022-06-11 05:58:00.278130
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual = NetBSDVirtual()
    virtual_facts = virtual.get_virtual_facts()

    assert isinstance(virtual_facts, dict)

# Generated at 2022-06-11 05:58:04.300879
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual()
    assert virtual_facts.platform == 'NetBSD'
    assert virtual_facts.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_parsed': {
            'type': '',
            'role': '',
            'hypervisor': '',
            'product': None,
            'system': None,
            'uuid': None
        },
        'virtualization_tech_guest': set([]),
        'virtualization_tech_host': set([])
    }

# Generated at 2022-06-11 05:58:05.456764
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():

    netbsd = NetBSDVirtual({}, {})

# Generated at 2022-06-11 05:58:07.162919
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual = NetBSDVirtual()

    facts = virtual.get_virtual_facts()

    assert facts['virtualization_type'] == ''
    assert facts['virtualization_role'] == ''

# Generated at 2022-06-11 05:58:08.032286
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector.virtual._platform is not None

# Generated at 2022-06-11 05:58:09.683906
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual()
    assert isinstance(virtual_facts, dict)

# Generated at 2022-06-11 05:58:26.229876
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # get_virtual_facts() is called by fill_virtual_facts() in
    # module_utils/facts/virtual/base.py, which can't be easily tested here.
    # However, get_virtual_facts() can be tested by calling it directly.
    netbsd_virtual = NetBSDVirtual()
    netbsd_virtual_facts = netbsd_virtual.get_virtual_facts()

    # This test will not always be correct if tested on a virtual machine.
    # However, it will always be correct if tested on a physical machine.
    assert netbsd_virtual_facts['virtualization_type'] == ''
    assert netbsd_virtual_facts['virtualization_role'] == ''
    assert not netbsd_virtual_facts['virtualization_tech_guest']

# Generated at 2022-06-11 05:58:28.810766
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual = NetBSDVirtualCollector()
    assert netbsd_virtual.platform == 'NetBSD'
    assert netbsd_virtual._fact_class == NetBSDVirtual


# Generated at 2022-06-11 05:58:39.056539
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Initialize NetBSDVirtual class
    virtual = NetBSDVirtual()

    # Test empty result
    virtual_facts = virtual.get_virtual_facts()
    assert 'virtualization_type' not in virtual_facts
    assert 'virtualization_role' not in virtual_facts
    assert 'virtualization_technologies' not in virtual_facts
    assert 'virtualization_tech_guest' not in virtual_facts
    assert 'virtualization_tech_host' not in virtual_facts
    assert 'virtualization_product_name' not in virtual_facts
    assert 'virtualization_product_version' not in virtual_facts

    # Test KVM guest
    virtual._sysctl_virtualization_type_product = 'KVM'
    virtual_facts = virtual.get_virtual_facts()

# Generated at 2022-06-11 05:58:44.205989
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    # Test the constructor of NetBSDVirtual, the class NetBSDVirtual
    # inherits from the class Virtual, so only test Virtual methods.
    # The method 'get_virtual_facts' of Virtual is tested in
    # 'test_virtual_facts'.
    virtual = NetBSDVirtual()
    assert virtual.platform == 'NetBSD'
    assert virtual.guest_virtualized is False
    assert virtual.host_virtualized is False
    assert virtual.virtual == {'role': '', 'type': ''}
    assert virtual.virtualization_type == ''
    assert virtual.virtualization_role == ''
    assert virtual.virtualization_technologies == set()


# Generated at 2022-06-11 05:58:52.044045
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual = NetBSDVirtual()

    # Test the empty case
    virtual_product_facts = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_product_facts': {},
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }
    virtual_vendor_facts = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_product_facts': {},
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }

# Generated at 2022-06-11 05:58:52.642323
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    assert NetBSDVirtual()

# Generated at 2022-06-11 05:59:01.022409
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    class Module(object):
        def __init__(self, sysctl_exists, sysctl_value):
            self.params = dict()
            self.params['gather_subset'] = ['all']
            self.facts = dict()
            self.facts['virtualization_type'] = ''
            self.facts['virtualization_role'] = ''

        def get_bin_path(self, binary, required=False):
            return '/sbin/sysctl'

        def sysctl_exists(self, bin_path):
            return self.sysctl_exists

        def sysctl_value(self, binary):
            return self.sysctl_value

    class ModuleUtil(object):
        def __init__(self, value):
            self.value = value


# Generated at 2022-06-11 05:59:02.738106
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual()
    assert virtual.platform == 'NetBSD'


# Generated at 2022-06-11 05:59:04.125632
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    assert NetBSDVirtual(dict(), dict()).platform == 'NetBSD'



# Generated at 2022-06-11 05:59:05.809755
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector._fact_class == NetBSDVirtual
    assert NetBSDVirtualCollector._platform == 'NetBSD'

# Generated at 2022-06-11 05:59:20.661624
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    try:
        NetBSDVirtual.get_virtual_facts()
    except Exception:
        pass

# Generated at 2022-06-11 05:59:30.296342
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = {
        'virtualization_type': 'xen',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': {'xen'},
        'virtualization_tech_host': set(),
    }
    virtual = NetBSDVirtual(module=None)
    virtual.sysctl_exists = (lambda x: True)
    virtual.sysctl_get = lambda x, default: {
        'machdep.hypervisor': 'Xen',
        'machdep.dmi.system-vendor': 'Google',
        'machdep.dmi.system-product': 'Google Compute Engine',
    }.get(x, default)
    virtual.file_exists = (lambda x: {'/dev/xencons': True}.get(x, False))

# Generated at 2022-06-11 05:59:33.965197
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_collector = NetBSDVirtualCollector()
    virtual_facts = virtual_collector.collect()
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'

# Generated at 2022-06-11 05:59:37.336021
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()

    assert(netbsd_virtual_collector._platform == 'NetBSD')
    assert(netbsd_virtual_collector._fact_class == NetBSDVirtual)

# Generated at 2022-06-11 05:59:39.474814
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsdvirtual = NetBSDVirtual({}, {}, {})
    assert netbsdvirtual._platform == 'NetBSD'



# Generated at 2022-06-11 05:59:40.953982
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual()
    assert virtual.platform == 'NetBSD'
    assert virtual.get_virtual_facts() == {}


# Generated at 2022-06-11 05:59:45.168255
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual = NetBSDVirtual(module=None)
    virtual_facts = virtual.get_virtual_facts()
    assert isinstance(virtual_facts, dict)
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_system' in virtual_facts

# Generated at 2022-06-11 05:59:55.525347
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual(None, None)

    assert netbsd_virtual.platform == 'NetBSD'
    assert netbsd_virtual.guest_fact_name == 'virtualization_tech_guest'
    assert netbsd_virtual.host_fact_name == 'virtualization_tech_host'

# Generated at 2022-06-11 05:59:57.857870
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    facts = dict()
    NetBSDVirtualCollector(facts, None)
    assert isinstance(facts['ansible_facts']['virtualization_role'], str)

# Generated at 2022-06-11 06:00:00.226282
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.data['virtualization_type'] == ''
    assert netbsd_virtual.data['virtualization_role'] == ''

# Generated at 2022-06-11 06:00:32.520488
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    expected_keys = set(['virtualization_role', 'virtualization_type',
                         'virtualization_tech_guest', 'virtualization_tech_host'])

    virtual_facts = NetBSDVirtual()
    received_keys = set(virtual_facts.get_virtual_facts().keys())
    assert expected_keys <= received_keys

# Generated at 2022-06-11 06:00:34.935797
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual({}).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'kvm'

# Generated at 2022-06-11 06:00:37.312520
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.platform == "NetBSD"
    assert netbsd_virtual.get_virtual_facts


# Generated at 2022-06-11 06:00:44.974511
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    class MockVirtual(VirtualSysctlDetectionMixin):
        def _sysctl(self, var):
            return None

    v = MockVirtual()
    v.fact_subset = dict()

    # Test no product, no vendor
    v.fact_subset['machdep.dmi.system-product'] = None
    v.fact_subset['machdep.dmi.system-vendor'] = None
    v.fact_subset['machdep.hypervisor'] = None
    assert v.get_virtual_facts() == dict(virtualization_type='', virtualization_role='', virtualization_tech_guest=set(), virtualization_tech_host=set())

    # Test product and vendor
    v.fact_subset['machdep.dmi.system-product'] = 'VirtualBox'

# Generated at 2022-06-11 06:00:53.419851
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    '''Unit test for method get_virtual_facts of class NetBSDVirtual'''
    test_class = NetBSDVirtual({})
    test_class.get_sysctl = lambda x: 'FooBar'
    test_class.file_exists = lambda x: True
    test_facts = test_class.get_virtual_facts()
    expected_facts = {
        'virtualization_type': 'kvm',
        'virtualization_role': 'host',
        'virtualization_tech_guest': {'kvm'},
        'virtualization_tech_host': set(),
    }
    assert test_facts == expected_facts, \
        'Expected %s, got %s' % (expected_facts, test_facts)

    test_class = NetBSDVirtual({})

# Generated at 2022-06-11 06:01:01.628526
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual = NetBSDVirtual()

    # Test virtualization_type and virtualization_role
    virtual_facts = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }

    # Test virtualization_type and virtualization_role for host on NetBSD Xen virtualization
    # On NetBSD, the hypervisor name is returned by machdep.dmi.system-vendor

# Generated at 2022-06-11 06:01:06.819709
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual = NetBSDVirtual(module=None)

    virtual_facts = virtual.get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_system' in virtual_facts
    assert 'virtualization_technologies' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-11 06:01:08.104358
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual()
    assert virtual_facts._platform == 'NetBSD'

# Generated at 2022-06-11 06:01:12.020138
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    collector = NetBSDVirtualCollector()
    assert collector._platform == 'NetBSD'
    assert collector._fact_class == NetBSDVirtual
    assert collector._fact_class._platform == 'NetBSD'
    assert isinstance(collector._fact_class._collector, NetBSDVirtualCollector)

# Generated at 2022-06-11 06:01:12.916447
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    x = NetBSDVirtual()
    assert x is not None

# Generated at 2022-06-11 06:02:21.007149
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    # Test with an arbitrary platform name
    NetBSDVirtualCollector('AnyPlatform')

    # Test with the actual platform name
    NetBSDVirtualCollector(NetBSDVirtualCollector._platform)



# Generated at 2022-06-11 06:02:23.192002
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    obj = NetBSDVirtualCollector()
    assert obj.platform == 'NetBSD'
    assert obj._fact_class == NetBSDVirtual
    assert obj._platform == 'NetBSD'

# Generated at 2022-06-11 06:02:25.457312
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual({})
    assert isinstance(netbsd_virtual, NetBSDVirtual)
    assert isinstance(netbsd_virtual, Virtual)


# Generated at 2022-06-11 06:02:26.899576
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual_facts = NetBSDVirtual()
    assert netbsd_virtual_facts._platform == 'NetBSD'

# Generated at 2022-06-11 06:02:29.005521
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual().get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts

# Generated at 2022-06-11 06:02:30.269422
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual()
    assert virtual.platform == 'NetBSD'

# Generated at 2022-06-11 06:02:32.906787
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual = NetBSDVirtual()
    virtual_facts = virtual.get_virtual_facts()
    assert(virtual_facts['virtualization_type'] == 'oracle')
    assert('hypervisor_host' in virtual_facts)

# Generated at 2022-06-11 06:02:36.141568
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virt = NetBSDVirtual()
    facts = virt.get_virtual_facts()
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts
    assert 'virtualization_tech_guest' in facts
    assert 'virtualization_tech_host' in facts

# Generated at 2022-06-11 06:02:38.083618
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    assert issubclass(NetBSDVirtual, Virtual)
    assert issubclass(NetBSDVirtual, VirtualSysctlDetectionMixin)

# Generated at 2022-06-11 06:02:39.518355
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd = NetBSDVirtual({}, {})
    assert netbsd.platform == "NetBSD"

# Generated at 2022-06-11 06:05:14.078275
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    NetBSDVirtualCollector()

# Generated at 2022-06-11 06:05:15.141944
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virt = NetBSDVirtual({})
    assert virt


# Generated at 2022-06-11 06:05:19.577649
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    import pytest
    import json

    facts = NetBSDVirtual().get_virtual_facts()

    tests = [
        ('virtualization_type', ''),
        ('virtualization_role', ''),
        ('virtualization_tech_guest', set()),
        ('virtualization_tech_host', set()),
    ]

    for key, expt_val in tests:
        assert key in facts, "get_virtual_facts does not provide '%s'" % key
        assert facts[key] == expt_val, "%s does not match expected value" % key

# Generated at 2022-06-11 06:05:22.985678
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual()
    facts = virtual_facts.get_virtual_facts()
    assert type(facts['virtualization_type']) is str
    assert type(facts['virtualization_role']) is str
    assert type(facts['virtualization_tech_guest']) is set
    assert type(facts['virtualization_tech_host']) is set

# Generated at 2022-06-11 06:05:26.699331
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual = NetBSDVirtual({})
    virtual_facts = virtual.get_virtual_facts()

    assert len(virtual_facts) > 0
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts
    assert 'virtualization_product_name' in virtual_facts

# Generated at 2022-06-11 06:05:30.223393
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    testobj = NetBSDVirtual({})
    # Not using assert_equal as we need to assert os.path.exists call above.
    result = testobj.get_virtual_facts()
    del result['virtualization_tech_guest']
    del result['virtualization_tech_host']

    assert result == {'virtualization_type': '', 'virtualization_role': ''}

# Generated at 2022-06-11 06:05:31.399365
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()

    assert netbsd_virtual.platform == 'NetBSD'

# Generated at 2022-06-11 06:05:35.840314
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virt_detect = NetBSDVirtual()
    virtual_facts = virt_detect.get_virtual_facts()
    assert isinstance(virtual_facts['virtualization_tech_guest'], set)
    assert isinstance(virtual_facts['virtualization_tech_host'], set)
    assert isinstance(virtual_facts['virtualization_type'], str)
    assert isinstance(virtual_facts['virtualization_role'], str)


# Generated at 2022-06-11 06:05:40.728265
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual()
    facts = virtual_facts.get_all_facts()
    assert facts['virtualization_type'], 'Virtualization_type is not set'
    assert facts['virtualization_role'], 'Virtualization_role is not set'
    assert len(facts['virtualization_tech_host']) >= 1, 'Virtualization_tech_host not set'
    assert len(facts['virtualization_tech_guest']) >= 1, 'Virtualization_tech_guest not set'

# Generated at 2022-06-11 06:05:45.388530
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    expected_platform = 'NetBSD'
    expected_virtual_type = ''
    expected_virtual_role = ''
    expected_virtual_technology = set()
    assert netbsd_virtual.platform == expected_platform
    assert netbsd_virtual.virtualization_type == expected_virtual_type
    assert netbsd_virtual.virtualization_role == expected_virtual_role
    assert netbsd_virtual.virtualization_technology == expected_virtual_technology