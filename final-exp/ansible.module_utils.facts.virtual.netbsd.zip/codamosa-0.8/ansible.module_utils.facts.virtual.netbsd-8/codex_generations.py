

# Generated at 2022-06-11 05:56:57.784143
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtualFacts = NetBSDVirtual().get_virtual_facts()
    assert 'virtualization_type' in virtualFacts
    assert 'virtualization_role' in virtualFacts
    assert 'virtualization_tech_guest' in virtualFacts
    assert 'virtualization_tech_host' in virtualFacts
    assert 'virtualization_product' in virtualFacts
    assert 'virtualization_vendor' in virtualFacts



# Generated at 2022-06-11 05:56:58.743757
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():

    virtual_facts = Virtu

# Generated at 2022-06-11 05:57:01.779166
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virt_fact_collector = NetBSDVirtualCollector()
    assert virt_fact_collector.platform == 'NetBSD'
    assert virt_fact_collector._fact_class == NetBSDVirtual

# Generated at 2022-06-11 05:57:03.668733
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsdvirtual = NetBSDVirtual()
    assert netbsdvirtual.platform == 'NetBSD'

# Generated at 2022-06-11 05:57:07.144934
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual()
    assert virtual_facts._platform == 'NetBSD'
    assert virtual_facts._fact_class == NetBSDVirtual
    assert virtual_facts._virt_subsystem == 'machdep.dmi.system-product'


# Generated at 2022-06-11 05:57:08.236659
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd = NetBSDVirtual()
    assert netbsd.platform == 'NetBSD'

# Generated at 2022-06-11 05:57:09.360672
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual()
    assert virtual_facts._platform == 'NetBSD'

# Generated at 2022-06-11 05:57:12.358638
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.platform == 'NetBSD'
    assert netbsd_virtual._platform == 'NetBSD'
    assert netbsd_virtual.get_virtual_facts() == {}

# Generated at 2022-06-11 05:57:14.487411
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.platform == 'NetBSD'



# Generated at 2022-06-11 05:57:24.173156
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.netbsd import NetBSDVirtual

    test_virtual_facts = NetBSDVirtual()

    sysctl_mock = {
        'hw.model': 'VirtualBox',
        'machdep.dmi.system-vendor': 'innotek GmbH',
        'machdep.dmi.system-product': 'VirtualBox',
        'machdep.hypervisor': 'VirtualBox'
    }

    result = test_virtual_facts.get_virtual_facts(sysctl_mock)

    assert result['virtualization_type'] == 'VirtualBox'
    assert result['virtualization_role'] == 'guest'
    assert result['virtualization_product'] == 'VirtualBox'
    assert result['virtualization_vendor'] == 'innotek GmbH'
   

# Generated at 2022-06-11 05:57:32.995693
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual()
    assert virtual_facts.is_virtual == False
    assert virtual_facts.facts['virtualization_type'] == ''
    assert virtual_facts.facts['virtualization_role'] == ''
    assert virtual_facts.facts['virtualization_tech_guest'] == set()
    assert virtual_facts.facts['virtualization_tech_host'] == set()

# Generated at 2022-06-11 05:57:39.597076
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict()
    )

    # Construct a NetBSDVirtual object
    virt = NetBSDVirtual(module=module)

    # Construct a set of reasonable input facts
    facts = dict()
    facts['kernel'] = 'BSD'
    facts['virtualization_type'] = 'systemd-nspawn'
    facts['virtualization_role'] = 'guest'

    # Call the method under test
    virt_facts = virt.get_virtual_facts(facts)

    # Make sure we got a dictionary as a result
    assert isinstance(virt_facts, dict)

    # Make sure all keys are present
    assert ('virtualization_type' in virt_facts)
    assert ('virtualization_type_role' in virt_facts)
    assert ('virtualization_role' in virt_facts)
   

# Generated at 2022-06-11 05:57:42.606303
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd = NetBSDVirtual()
    assert netbsd is not None
    assert netbsd.platform == 'NetBSD'
    assert NetBSDVirtual.platform == 'NetBSD'

# Generated at 2022-06-11 05:57:44.083238
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    a = NetBSDVirtual()
    assert a._platform == 'NetBSD'

# Generated at 2022-06-11 05:57:45.834010
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual = NetBSDVirtual({}, None)
    # TODO


# Generated at 2022-06-11 05:57:55.364390
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual = NetBSDVirtual()
    virtual._module = object()
    virtual._module.get_bin_path = lambda x: os.path.join(os.path.dirname(os.path.realpath(__file__)),
                                                          'virt_detect', x)

# Generated at 2022-06-11 05:58:01.684980
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector(None, None, ['.*'])
    assert netbsd_virtual_collector.platform == 'NetBSD'
    assert netbsd_virtual_collector.fact_class == NetBSDVirtual
    assert netbsd_virtual_collector.fact_class().platform == 'NetBSD'

# Generated at 2022-06-11 05:58:02.780187
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    NetBSDVirtualCollector()

# Generated at 2022-06-11 05:58:11.426781
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():

    class TestClass:
        def read_file(self, filename):
            return "Vendor Name: VMware, Inc."

    test_object = NetBSDVirtual()
    test_object.read_file = TestClass().read_file
    result = test_object.get_virtual_facts()

    assert result['virtualization_type'] == 'VMware'
    assert result['virtualization_role'] == 'guest'

    # Unit test for method get_virtual_facts of class NetBSDVirtual
    assert result['virtualization_tech_guest'] == set(['vmware'])
    assert result['virtualization_tech_host'] == set(['vmware'])
    assert result['virtualization_product_name'] == 'Virtual Machine'
    assert result['virtualization_product_version'] == ''


# Generated at 2022-06-11 05:58:16.383530
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual = NetBSDVirtual()
    virtual_facts = netbsd_virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert not virtual_facts['virtualization_tech_guest']
    assert not virtual_facts['virtualization_tech_host']

# Generated at 2022-06-11 05:58:24.897090
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsdvirtual = NetBSDVirtual()
    assert netbsdvirtual.platform == 'NetBSD'

# Generated at 2022-06-11 05:58:25.818737
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    assert NetBSDVirtual().get_virtual_facts() == {}

# Generated at 2022-06-11 05:58:27.068281
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    assert NetBSDVirtual(None).platform == 'NetBSD'


# Generated at 2022-06-11 05:58:28.709851
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual(module=None)
    assert netbsd_virtual.platform == "NetBSD"


# Generated at 2022-06-11 05:58:38.975167
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts_test = NetBSDVirtual()
    # Lets check facts for virtual box
    virtual_facts_test.sysctl_output_dict = {
        'machdep.dmi.product-name': 'VirtualBox',
        'machdep.dmi.system-product': 'VirtualBox',
        'machdep.dmi.system-vendor': 'innotek GmbH',
    }
    # Lets check facts for vmware

# Generated at 2022-06-11 05:58:40.492757
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    my_collector = NetBSDVirtualCollector()
    assert my_collector.platform == 'NetBSD'

# Generated at 2022-06-11 05:58:42.468318
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert issubclass(NetBSDVirtualCollector, VirtualCollector), \
           "Class NetBSDVirtualCollector should be a subclass of Class Collector"

# Generated at 2022-06-11 05:58:44.859078
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert isinstance(NetBSDVirtualCollector(), NetBSDVirtualCollector)

# Generated at 2022-06-11 05:58:52.184998
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():

    def get_sysctl_data(key):
        return {
            'machdep.dmi.system-product': 'HP ProLiant DL360',
            'machdep.dmi.system-vendor': 'HP',
            'machdep.hypervisor': '',
        }[key]

    test_FactsNetBSDVirtual = NetBSDVirtual(get_sysctl_data)
    expected_result = {
        'virtualization_type': 'vmware',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['vmware']),
        'virtualization_tech_host': set(),
        'virtualization_product_name': 'HP ProLiant DL360',
    }

    test_result = test_FactsNetBSDVirtual.get_virtual_facts()

# Generated at 2022-06-11 05:58:53.583372
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    my_obj = NetBSDVirtual()
    my_obj.get_virtual_facts()

# Generated at 2022-06-11 05:59:05.808462
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual(None).get_virtual_facts()

    virtual_facts['virtualization_role'] = 'guest'
    virtual_facts['virtualization_type'] = 'xen'

    assert virtual_facts == {
        'virtualization_type': 'xen',
        'virtualization_role': 'guest',
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': {'xen'}
    }

# Generated at 2022-06-11 05:59:16.124212
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():

    # Test case when sysctl is not installed in OS.
    with open('mock_netbsd_sysctl', 'w') as f:
        f.write("""#!/bin/sh
echo "machdep.dmi.system-product=KVM"
exit 0""")

    os.environ['PATH'] = '.:' + os.environ['PATH']
    os.chmod('mock_netbsd_sysctl', 0o755)

    facts = NetBSDVirtual().get_virtual_facts()
    assert len(facts['virtualization_tech_guest']) == 1
    assert 'kvm' in facts['virtualization_tech_guest']
    assert len(facts['virtualization_tech_host']) == 0
    assert facts['virtualization_type'] == 'kvm'

    # Test case when sys

# Generated at 2022-06-11 05:59:17.382641
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    """Test NetBSDVirtual class constructor"""
    netbsd = NetBSDVirtual()
    assert netbsd.platform == 'NetBSD'

# Generated at 2022-06-11 05:59:25.757807
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = {}
    host_tech = set()
    guest_tech = set()

    # Set empty values as default
    virtual_facts['virtualization_type'] = ''
    virtual_facts['virtualization_role'] = ''
    virtual_facts['virtualization_system'] = ''

    # Test for _detect_virt_vendor method
    virtual_facts['virtualization_system'] = ''

    if virtual_facts['virtualization_system'] == '':
        virtual_facts['virtualization_system'] = 'KVM'

    if virtual_facts['virtualization_system'] == '':
        virtual_facts['virtualization_system'] = 'LXD'

    if virtual_facts['virtualization_system'] == '':
        virtual_facts['virtualization_system'] = 'VirtualBox'


# Generated at 2022-06-11 05:59:27.892661
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'xen'

# Generated at 2022-06-11 05:59:29.672435
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virtual_collector = NetBSDVirtualCollector()
    assert virtual_collector._platform == 'NetBSD'

# Generated at 2022-06-11 05:59:31.507419
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.platform == 'NetBSD'

# Generated at 2022-06-11 05:59:37.196438
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Initialize NetBSDVirtual class
    netbsd_virtual = NetBSDVirtual()
    # Call method get_virtual_facts of class NetBSDVirtual
    virtual_facts = netbsd_virtual.get_virtual_facts()
    # Assert that virtual_facts is a dict
    assert isinstance(virtual_facts, dict)
    # Assert that dict virtual_facts is not empty
    assert virtual_facts

# Generated at 2022-06-11 05:59:44.741820
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    facts = dict()
    virt_facts = dict()
    virt_facts['virtualization_type'] = ''
    virt_facts['virtualization_role'] = ''
    virt_facts['virtualization_technologies'] = set()
    # Use values that would be found in NetBSD
    facts['machdep.dmi.system-product'] = 'Bochs	'
    facts['machdep.dmi.system-vendor'] = 'QEMU	'
    virt_module = NetBSDVirtual(facts, dict(), False)

    virtual_facts = virt_module.get_virtual_facts()
    assert virtual_facts.get('virtualization_type') == 'kvm'
    assert virtual_facts.get('virtualization_role') == 'guest'

# Generated at 2022-06-11 05:59:46.076929
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    NetBSDVirtualCollector()

# Generated at 2022-06-11 06:00:08.777796
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual = NetBSDVirtual()
    with open('/etc/sysctl.conf', 'w') as sysctl_conf:
        sysctl_conf.write('machdep.dmi.system-product = My product\nmachdep.dmi.system-vendor = My vendor\nmachdep.hypervisor = QEMU')
    os.system('sysctl -p /etc/sysctl.conf > /dev/null')
    with open('/dev/xencons', 'w') as xen_cons:
        xen_cons.write('test')

# Generated at 2022-06-11 06:00:15.673723
# Unit test for method get_virtual_facts of class NetBSDVirtual

# Generated at 2022-06-11 06:00:20.940890
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': [],
        'virtualization_tech_host': [],
    }
    collector = NetBSDVirtualCollector()
    collected_facts = collector.collect()
    assert collected_facts['ansible_virtual_facts'] == virtual_facts

# Generated at 2022-06-11 06:00:22.626743
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual('NetBSD')
    assert isinstance(virtual, NetBSDVirtual)


# Generated at 2022-06-11 06:00:24.636208
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    vc = NetBSDVirtualCollector('NetBSD')
    assert vc._fact_class is not None
    assert vc._platform == 'NetBSD'

# Generated at 2022-06-11 06:00:27.450971
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    nvc = NetBSDVirtualCollector()

    # Ensure order of constructor results is as expected
    assert nvc.platform == 'NetBSD'
    assert nvc._fact_class == NetBSDVirtual
    assert nvc._platform == 'NetBSD'

# Generated at 2022-06-11 06:00:30.740404
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd = NetBSDVirtualCollector()
    assert netbsd._platform == 'NetBSD'
    assert netbsd._fact_class == NetBSDVirtual
    assert netbsd._fact_class().platform == 'NetBSD'

# Generated at 2022-06-11 06:00:35.024655
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual().get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-11 06:00:39.224485
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    x = NetBSDVirtual()
    facts = x.get_virtual_facts()
    assert facts['virtualization_type'] == 'kvm'
    assert facts['virtualization_role'] == 'guest'
    assert facts['virtualization_tech_host'] == ['kvm']
    assert facts['virtualization_tech_guest'] == ['kvm']

# Generated at 2022-06-11 06:00:40.706854
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual is not None


# Generated at 2022-06-11 06:01:07.675896
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual != None

# Generated at 2022-06-11 06:01:12.626825
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    netbsd_virtual_fact = NetBSDVirtual(netbsd_virtual_collector)

    virtual_facts = netbsd_virtual_fact.get_virtual_facts()
    assert isinstance(virtual_facts, dict)
    assert 'virtualization_tech_guest' in virtual_facts

# Generated at 2022-06-11 06:01:16.037718
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    mock_module = MockOSModule()

    facts = NetBSDVirtual(mock_module).get_virtual_facts()

    assert facts['virtualization_type'] == ''
    assert facts['virtualization_role'] == ''
    assert facts['virtualization_system'] == ''

# Generated at 2022-06-11 06:01:17.175346
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector.platform == 'NetBSD'


# Generated at 2022-06-11 06:01:21.409317
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual = NetBSDVirtual()
    virtual_facts = netbsd_virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert len(virtual_facts['virtualization_tech_guest']) == 0
    assert len(virtual_facts['virtualization_tech_host']) == 0

# Generated at 2022-06-11 06:01:23.145985
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # get_virtual_facts method returns a dictionary
    assert isinstance(NetBSDVirtual().get_virtual_facts(), dict)

# Generated at 2022-06-11 06:01:33.533600
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual import NetBSDVirtual
    from ansible.module_utils.facts.virtual.utils import DummyVirtualFile, DummyVirtualFileDetectionMixin
    from ansible.module_utils.facts.virtual.sysctl import DummyVirtualSysctlDetectionMixin
    import os
    import sys

    # Skip tests if dmidecode is not found
    if not NetBSDVirtual.sysctl_exists():
        print("The %s has been skipped as the sysctl utility cannot be found" % sys._getframe().f_code.co_name)
        return

    # Skip tests if machdep.dmi.system-product is not found

# Generated at 2022-06-11 06:01:42.935929
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    test_virtual_facts = {}
    test_virtual_facts['virtualization_type'] = 'xen'
    test_virtual_facts['virtualization_role'] = 'guest'
    test_virtual_facts['virtualization_tech_host'] = set()
    test_virtual_facts['virtualization_tech_guest'] = {'xen'}

    test_virtual = NetBSDVirtual()

    # Assert that if machdep.dmi.system-product contains
    # "Virtual Machine" and machdep.hypervisor does not
    # exist, virtualization_type is set to 'xen'
    sysctl_dmi_system_product = 'Virtual Machine'
    sysctl_hypervisor = ''
    assert test_virtual.detect_virt_vendor(sysctl_dmi_system_product) == test_virtual_facts

# Generated at 2022-06-11 06:01:44.229683
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual()
    assert virtual_facts.platform == 'NetBSD'

# Generated at 2022-06-11 06:01:47.441232
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual()
    keys = virtual_facts.get_virtual_facts()
    assert isinstance(keys['virtualization_type'], str) is True
    assert isinstance(keys['virtualization_role'], str) is True
    assert isinstance(keys['virtualization_system'], str) is True

# Generated at 2022-06-11 06:02:28.044986
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    x = NetBSDVirtualCollector()
    assert x._platform == 'NetBSD'
    assert x._fact_class == NetBSDVirtual


# Generated at 2022-06-11 06:02:29.499836
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    NetBSDVirtualObject = NetBSDVirtual(None)
    NetBSDVirtualObject.get_virtual_facts()

# Generated at 2022-06-11 06:02:31.583537
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual({})

    assert netbsd_virtual.platform == 'NetBSD'



# Generated at 2022-06-11 06:02:32.824326
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    facts = NetBSDVirtual()
    assert facts.platform == 'NetBSD'

# Generated at 2022-06-11 06:02:37.053146
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual().get_virtual_facts()
    assert isinstance(virtual_facts['virtualization_type'], str)
    assert isinstance(virtual_facts['virtualization_role'], str)
    assert isinstance(virtual_facts['virtualization_system'], str)
    assert isinstance(virtual_facts['virtualization_uuid'], str)

# Generated at 2022-06-11 06:02:44.924767
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    facts_dict = dict()
    virtual_facts = dict()
    virtual_facts['virtualization_type'] = 'xen'
    virtual_facts['virtualization_role'] = 'guest'
    virtual_facts['virtualization_tech_guest'] = {'xen', 'chroot'}
    virtual_facts['virtualization_tech_host'] = {'xen'}
    virtual_facts['virtualization_product_name'] = 'Xen'
    virtual_facts['virtualization_product_version'] = '4.4.1'
    facts_dict['virtualization'] = virtual_facts
    collector = NetBSDVirtualCollector()
    collector.collect()
    assert collector.get_facts() == facts_dict


# Generated at 2022-06-11 06:02:53.069680
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual_collector = NetBSDVirtualCollector(None)
    netbsd_virtual = NetBSDVirtual(netbsd_virtual_collector, "machdep.dmi.system-product", "machdep.dmi.system-vendor", "machdep.hypervisor")
    netbsd_virtual_collector._set_platform('NetBSD')
    netbsd_virtual_collector._set_module_context(dict())
    expected_virtual_facts = dict()
    expected_virtual_facts['virtualization_type'] = ''
    expected_virtual_facts['virtualization_role'] = ''
    expected_virtual_facts['virtualization_tech_guest'] = set()
    expected_virtual_facts['virtualization_tech_host'] = set()

    assert netbsd_virtual.get_virtual_

# Generated at 2022-06-11 06:02:55.672652
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual(None, None, None)
    assert virtual_facts._platform == 'NetBSD'
    assert virtual_facts._fact_class == NetBSDVirtual

# Generated at 2022-06-11 06:02:59.397352
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    # Create an instance of class NetBSDVirtualCollector
    p = NetBSDVirtualCollector(None, {})
    assert isinstance(p, NetBSDVirtualCollector)
    assert isinstance(p._fact_class, NetBSDVirtual)
    assert p._platform == 'NetBSD'

# Generated at 2022-06-11 06:03:01.007626
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virt = NetBSDVirtual(None, None)
    assert virt.platform == 'NetBSD'



# Generated at 2022-06-11 06:04:22.713587
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual = NetBSDVirtual()
    virtual_facts = netbsd_virtual.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert 'xen' in virtual_facts['virtualization_tech_guest']

# Generated at 2022-06-11 06:04:26.657657
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    vm = NetBSDVirtual()
    assert vm.get_virtual_facts()['virtualization_type'] == ''
    assert vm.get_virtual_facts()['virtualization_role'] == ''
    assert vm.get_virtual_facts()['virtualization_product_name'] == ''
    assert vm.get_virtual_facts()['virtualization_product_version'] == ''


# Generated at 2022-06-11 06:04:27.918507
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virtual_collector = NetBSDVirtualCollector()
    assert virtual_collector.platform == 'NetBSD'

# Generated at 2022-06-11 06:04:29.445741
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert isinstance(NetBSDVirtualCollector()._fact_class, NetBSDVirtual)
    assert NetBSDVirtualCollector()._platform == 'NetBSD'

# Generated at 2022-06-11 06:04:32.160710
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virt_netbsd = NetBSDVirtual('NetBSD')
    assert virt_netbsd.platform == 'NetBSD'
    assert virt_netbsd.sysctl_path == 'mibs/sysctl'


# Generated at 2022-06-11 06:04:33.093772
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert isinstance(NetBSDVirtualCollector(), NetBSDVirtualCollector)

# Generated at 2022-06-11 06:04:37.091618
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virt = NetBSDVirtual('1', '2', '3')
    assert virt.platform == 'NetBSD'
    assert virt._virtualization_type_facts is not None
    assert virt._virtualization_product_facts is not None
    assert virt.sysctl_virtualization_type_facts is not None
    assert virt.sysctl_virtualization_product_facts is not None

# Generated at 2022-06-11 06:04:39.242190
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    c = NetBSDVirtualCollector()
    assert c.platform == 'NetBSD'
    assert c._fact_class == NetBSDVirtual


# Generated at 2022-06-11 06:04:39.964816
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual()
    assert virtual.platform == 'NetBSD'

# Generated at 2022-06-11 06:04:42.238806
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()

    assert netbsd_virtual.facts['virtualization_type'].lower() == ''
    assert netbsd_virtual.facts['virtualization_role'].lower() == ''