

# Generated at 2022-06-11 05:56:56.741578
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.platform == 'NetBSD'
    assert netbsd_virtual.get_virtual_facts() == {}

# Generated at 2022-06-11 05:56:58.106861
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    v_instance = NetBSDVirtual()
    assert v_instance._platform == 'NetBSD'

# Generated at 2022-06-11 05:57:04.215097
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual_obj = NetBSDVirtual()
    # Testing class type
    assert type(netbsd_virtual_obj).__name__ == 'NetBSDVirtual'
    # Testing platform attribute
    assert netbsd_virtual_obj.platform == 'NetBSD'
    # Testing get_virtual_facts() returns a dict
    assert isinstance(netbsd_virtual_obj.get_virtual_facts(), dict)


# Generated at 2022-06-11 05:57:05.580542
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    """Check if constructor of NetBSDVirtual works without raising any exceptions."""
    NetBSDVirtual()

# Generated at 2022-06-11 05:57:07.254007
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual({'module': None})
    assert netbsd_virtual.name == 'NetBSD'


# Generated at 2022-06-11 05:57:10.208317
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual_object = NetBSDVirtual()
    virtual_facts = netbsd_virtual_object.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_type_role'] == ''

# Generated at 2022-06-11 05:57:14.139608
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    facts = NetBSDVirtual().get_virtual_facts()
    assert facts['virtualization_type'] == ''
    assert facts['virtualization_role'] == ''
    assert facts['virtualization_tech_guest'] == {''}
    assert facts['virtualization_tech_host'] == set()



# Generated at 2022-06-11 05:57:23.847195
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virt_facts_mocks = {
        'machdep.dmi.system-product': '',
        'machdep.dmi.system-vendor': '',
        'machdep.hypervisor': '',
    }

    virt = NetBSDVirtual()
    virt.collect_sysctl_facts = lambda v: virt_facts_mocks[v]

    def os_path_exists_mock(f):
        if f == '/dev/xencons':
            return True

    virt.os.path.exists = os_path_exists_mock


# Generated at 2022-06-11 05:57:25.782372
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd = NetBSDVirtual()
    assert netbsd.platform == 'NetBSD'


# Generated at 2022-06-11 05:57:31.970779
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    facts_virtual_instance = NetBSDVirtual({})
    facts_virtual_result = facts_virtual_instance.get_virtual_facts()

    assert not facts_virtual_result['virtualization_type']
    assert not facts_virtual_result['virtualization_role']
    assert not facts_virtual_result['virtualization_tech_guest']
    assert not facts_virtual_result['virtualization_tech_host']
    assert not facts_virtual_result['virtualization_sysctl_host']

# Generated at 2022-06-11 05:57:45.244593
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Create the NetBSDVirtual object that will be tested
    netbsd_module = NetBSDVirtual()

    # Prepare the test data the sysctl function
    def sysctl_execute(cmd):
        return 'machdep.dmi.system-product=VMware Virtual Platform'

    # Prepare the test data the get output of the dmesg command

# Generated at 2022-06-11 05:57:52.330181
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    class FakeConfig(object):
        def __init__(self, data=None):
            if not data:
                data = {}
            self.data = data
        def get_config_data(self):
            return self.data
    c = FakeConfig({'gather_subset': ['!all', 'virtual']})
    vc = NetBSDVirtualCollector(c)
    assert isinstance(vc, NetBSDVirtualCollector)
    assert vc._fact_class == NetBSDVirtual
    assert vc._platform == 'NetBSD'

# Generated at 2022-06-11 05:57:58.046095
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    facts = {
        'machdep.dmi.system-product': 'VirtualBox',
        'machdep.dmi.system-vendor': 'Oracle',
        'machdep.hypervisor': 'VMWare',
    }

    expected = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_product_name': 'VirtualBox',
        'virtualization_vendor_name': 'Oracle',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }
    assert NetBSDVirtual(facts=facts).get_virtual_facts() == expected

# Generated at 2022-06-11 05:58:08.448907
# Unit test for method get_virtual_facts of class NetBSDVirtual

# Generated at 2022-06-11 05:58:10.583755
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()

    assert netbsd_virtual.platform == 'NetBSD'



# Generated at 2022-06-11 05:58:13.171188
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual is not None
    assert netbsd_virtual.platform == 'NetBSD'


# Generated at 2022-06-11 05:58:14.591363
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual()
    assert virtual._platform == 'NetBSD'

# Generated at 2022-06-11 05:58:19.877955
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    mock_module = type('module', (object,), {'params': {'gather_subset': ''}})
    mock_module.get_bin_path = lambda x: ''
    mock_module.run_command = lambda x: [0, '', '']
    virtual = NetBSDVirtual(mock_module)
    result = virtual.get_virtual_facts()
    assert isinstance(result, dict)

# Generated at 2022-06-11 05:58:29.356444
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    data_structure = { 'freebsd_version': '12.0-CURRENT',
                       'machdep.dmi.system-product': 'iMac5,1',
                       'machdep.dmi.system-vendor': 'Apple Computer, Inc.'
                     }
    expected_facts = {   'virtualization_role': 'guest',
                         'virtualization_type': 'xen',
                         'virtualization_tech_guest': set(['xen']),
                         'virtualization_tech_host': set([]),
                     }
    module = AnsibleModule(argument_spec={})
    module.sysctl = lambda x: data_structure[x]
    module.check_mode = False
    module.run_command = lambda x, y, z: (0, '', '')
    module.get_

# Generated at 2022-06-11 05:58:30.449892
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd = NetBSDVirtual()
    assert netbsd.platform == 'NetBSD'


# Generated at 2022-06-11 05:58:39.846246
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual(module=None)
    assert virtual._platform == 'NetBSD'
    assert virtual._fact_class == virtual.__class__
    assert virtual._additional_facts_to_gather == ['virtualization_type', 'virtualization_role', 'virtualization_technology']

# Generated at 2022-06-11 05:58:49.940734
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Create a NetBSDVirtual object
    obj = NetBSDVirtual()

    # Create a facts_module_mock, which is the same as facts_module except for
    # the name. The mocked facts_module is needed to prevent reading
    # /proc/cpuinfo and /proc/meminfo in the real system.
    class facts_module_mock:
        def __init__(self, name):
            if name == 'machdep.hypervisor':
                self.content = 'VMWare, Inc.'
            elif name == 'machdep.dmi.system-product':
                self.content = 'VMWare Virtual Platform'
            elif name == 'machdep.dmi.system-vendor':
                self.content = 'Unknown'
            elif name == '/dev/xencons':
                self.content = True

# Generated at 2022-06-11 05:58:51.381957
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    nv = NetBSDVirtualCollector()
    assert nv._platform == 'NetBSD'

# Generated at 2022-06-11 05:58:53.588545
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual(None, {})
    assert virtual_facts.platform == 'NetBSD'


# Generated at 2022-06-11 05:58:55.022170
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual()
    assert virtual.platform == 'NetBSD'

# Generated at 2022-06-11 05:58:56.088771
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    NetBSDVirtualCollector()

# Generated at 2022-06-11 05:58:58.552038
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual._platform == 'NetBSD'
    assert netbsd_virtual._fact_class == 'NetBSDVirtual'

# Generated at 2022-06-11 05:59:00.282659
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts_instance = NetBSDVirtual()
    assert virtual_facts_instance.platform == 'NetBSD'


# Generated at 2022-06-11 05:59:02.390547
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.platform == 'NetBSD'


# Generated at 2022-06-11 05:59:06.673460
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    # Create an instance of class NetBSDVirtual
    netbsd_virtual = NetBSDVirtual()
    # Check if instance is an instance of NetBSDVirtual
    assert isinstance(netbsd_virtual, NetBSDVirtual)
    # Check if instance is an instance of Virtual
    assert isinstance(netbsd_virtual, Virtual)


# Generated at 2022-06-11 05:59:23.430334
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Create a NetBSDVirtual object
    nv = NetBSDVirtual()

    # Get virtual facts
    virtual_facts = nv.get_virtual_facts()

    assert not virtual_facts['virtualization_type']
    assert not virtual_facts['virtualization_role']
    assert not virtual_facts['virtualization_tech_guest']
    assert not virtual_facts['virtualization_tech_host']

# Generated at 2022-06-11 05:59:26.814166
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_obj = NetBSDVirtual()
    virtual_obj.populate()
    assert virtual_obj._virtual_facts['virtualization_type'] != ""
    assert virtual_obj._virtual_facts['virtualization_role'] != ""


# Generated at 2022-06-11 05:59:28.891501
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual("NetBSD")
    assert netbsd_virtual.platform == "NetBSD"


# Generated at 2022-06-11 05:59:30.742825
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsdvirtual = NetBSDVirtual()
    assert netbsdvirtual.platform == 'NetBSD'


# Generated at 2022-06-11 05:59:40.869040
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    import json
    import os
    import pytest
    import sys

    if sys.version_info[0] < 3:
        from mock import ANY, Mock, patch
    else:
        from unittest.mock import ANY, Mock, patch

    from ansible.module_utils.facts.virtual.netbsd import NetBSDVirtual

    sysctl_mock = Mock()
    sysctl_mock.read_sysctl.return_value = "KVM\n"
    hv_mock = Mock()
    hv_mock.read_sysctl.return_value = "Xen 4.0\n"
    hypervisor_mock = Mock()
    hypervisor_mock.read_sysctl.return_value = "Xen 4.0\n"

# Generated at 2022-06-11 05:59:43.072947
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    x = NetBSDVirtualCollector()
    assert isinstance(x, NetBSDVirtualCollector)
    assert x._platform == "NetBSD"

# Generated at 2022-06-11 05:59:53.545673
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sysctl import SysctlVirtualizationDetectionMixin
    from ansible.module_utils.facts.virtual.common import VirtualizationFactCollector

    facts_collector = VirtualizationFactCollector(None, None, None)

    class MockNetBSDVirtual(NetBSDVirtual):
        def __init__(self):
            self.sysctlVirtualizationDetectionMixin = SysctlVirtualizationDetectionMixin()
            self.sysctlVirtualizationDetectionMixin.gather_sysctl_facts(
                facts_collector.__dict__['gather_subset'],
                facts_collector.__dict__['gather_timeout'])


# Generated at 2022-06-11 05:59:59.436066
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual = NetBSDVirtual('netbsd')
    netbsd_virtual.sysctl_command = lambda key: 'machdep.pa64.mode=1'
    virtual_facts = netbsd_virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set(['kvm'])

# Generated at 2022-06-11 06:00:00.829269
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virt = NetBSDVirtual('/proc', '/sys')
    assert 'NetBSD' == virt.platform

# Generated at 2022-06-11 06:00:02.964428
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual_facts = NetBSDVirtual().get_virtual_facts()
    assert netbsd_virtual_facts['virtualization_type'] == ''

# Generated at 2022-06-11 06:00:31.410509
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual._platform == 'NetBSD'
    assert netbsd_virtual._fact_class == NetBSDVirtual
    assert netbsd_virtual._collector_class == NetBSDVirtualCollector

# Generated at 2022-06-11 06:00:33.225448
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual()
    assert virtual_facts._platform == 'NetBSD'



# Generated at 2022-06-11 06:00:37.728806
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual()
    facts = virtual_facts.get_virtual_facts()

    assert facts['virtualization_type'] == 'xen'
    assert facts['virtualization_role'] == 'guest'
    assert facts['virtualization_tech_guest'] == {'xen'}
    assert 'virtualization_tech_host' in facts

# Generated at 2022-06-11 06:00:39.428713
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    module = 'ansible.module_utils.facts.virtual.netbsd'

    assert NetBSDVirtual(module) != None

# Generated at 2022-06-11 06:00:46.134050
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():

    # default case
    set_module_args({})
    instance = NetBSDVirtual()
    result_default = instance.get_virtual_facts()
    result_expected_default = {'virtualization_role': '', 'virtualization_type': '', 'virtualization_tech_guest': set(),
                               'virtualization_tech_host': set()}
    assert result_default == result_expected_default

    # Set values for sysctl.machdep.hypervisor to return virtualization
    # vendor/type as VIRTUALBOX/virtualbox
    set_module_args({'commands': {'sysctl':
                                  {'machdep.hypervisor': 'VirtualBox'}}})
    instance = NetBSDVirtual()
    result_hypervisor = instance.get_virtual_facts()

# Generated at 2022-06-11 06:00:50.955227
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual_class = NetBSDVirtual()
    # Set module_arg_spec empty
    netbsd_virtual_class.module_arg_spec = {}
    netbsd_virtual_class.gather_subset = ['']
    virtual_facts = netbsd_virtual_class.get_virtual_facts()
    assert virtual_facts['virtualization_type'] != ''

# Generated at 2022-06-11 06:00:53.964764
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virtual_facts_collector = NetBSDVirtualCollector()
    assert virtual_facts_collector._fact_class == NetBSDVirtual
    assert virtual_facts_collector._platform == 'NetBSD'

# Generated at 2022-06-11 06:00:58.781224
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # TODO: Pass in a valid sysctl/kvm file so we don't have to mock everything
    facts = NetBSDVirtual({}).get_virtual_facts()
    assert facts['virtualization_type'] == ''
    assert facts['virtualization_role'] == ''
    assert facts['virtualization_tech_host'] == set()
    assert facts['virtualization_tech_guest'] == set()

# Generated at 2022-06-11 06:01:01.017468
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsdvirtual = NetBSDVirtualCollector()
    assert netbsdvirtual._platform == 'NetBSD'
    assert netbsdvirtual._fact_class._platform == 'NetBSD'

# Generated at 2022-06-11 06:01:02.032826
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # TODO:
    return

# Generated at 2022-06-11 06:01:27.619067
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsdvirtual = NetBSDVirtual()


# Generated at 2022-06-11 06:01:37.616893
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Test with empty filenames
    virtual_facts = NetBSDVirtual.get_virtual_facts({})

    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()

    # Test with non-empty filenames
    virtual_facts = NetBSDVirtual.get_virtual_facts({
        'sysctl_machdep_dmi_system_product': '',
        'sysctl_machdep_dmi_system_vendor': '',
        'sysctl_machdep_hypervisor': ''
    })

    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''

# Generated at 2022-06-11 06:01:45.430239
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    from types import ModuleType
    module = ModuleType('ansible.module_utils.facts.virtual.netbsd.NetBSDVirtual')
    module.get_file_content = lambda x: 'OpenBSD\n'

    class TestClass(object):
        def __init__(self):
            self.module = module

    nbsd_virtual = NetBSDVirtual(TestClass())

    virtual_facts = nbsd_virtual.get_virtual_facts()

    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_technology' in virtual_facts
    assert virtual_facts['virtualization_type'] == 'openbsd'

# Generated at 2022-06-11 06:01:49.542226
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Arrange
    netbsd = NetBSDVirtual()

    # Act
    results = netbsd.get_virtual_facts()

    # Assert
    assert results == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()}

# Generated at 2022-06-11 06:01:51.468708
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    """
    Test NetBSDVirtual.
    """
    netbsd_virtual = NetBSDVirtual()

    assert netbsd_virtual.platform == 'NetBSD'

# Generated at 2022-06-11 06:01:53.348673
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector.platform == 'NetBSD'
    assert NetBSDVirtualCollector._fact_class.platform == 'NetBSD'

# Generated at 2022-06-11 06:02:02.208192
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virt = NetBSDVirtual()
    virtual_facts = virt.get_virtual_facts()
    assert virtual_facts.get('virtualization_type') == ''
    assert virtual_facts.get('virtualization_role') == ''

    os.environ['ANSIBLE_SYSCTL_PATH'] = 'test/unit/module_utils/facts/virtual/sysctl/fixtures'
    virt = NetBSDVirtual()
    virtual_facts = virt.get_virtual_facts()
    assert virtual_facts.get('virtualization_type') == 'Parallels'
    assert virtual_facts.get('virtualization_role') == 'guest'
    assert virtual_facts.get('virtualization_tech_guest') == {'parallels'}
    assert virtual_facts.get('virtualization_tech_host') == set()

# Generated at 2022-06-11 06:02:04.719800
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtualCollector(None, None).collect()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''

# Generated at 2022-06-11 06:02:06.390939
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    # constructor
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.platform == "NetBSD"


# Generated at 2022-06-11 06:02:09.516400
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Run unit test for:
    # get_virtual_facts of class NetBSDVirtual

    from ansible.module_utils.facts.virtual.netbsd import NetBSDVirtual
    netbsdvirtual = NetBSDVirtual()
    ret = netbsdvirtual.get_virtual_facts()
    assert ret == {}

# Generated at 2022-06-11 06:03:14.799152
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert(isinstance(netbsd_virtual_collector._fact_class(), NetBSDVirtual))
    assert(netbsd_virtual_collector._platform == 'NetBSD')


# Generated at 2022-06-11 06:03:20.517022
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    import sys
    import os
    sys.path.insert(0, os.path.dirname(os.getcwd()))

    from ansible.module_utils.facts.virtual.netbsd import NetBSDVirtual
    from ansible.module_utils.facts.virtual import VirtualCollector

    virt_collector = NetBSDVirtualCollector()
    result = virt_collector.collect()
    nb_virtual = NetBSDVirtual(collect_func=virt_collector.collect)

    assert nb_virtual.get_virtual_facts() == result

# Generated at 2022-06-11 06:03:28.424355
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Artificial mapping of sysctl names for testing purposes
    sysctl_map = {
        'machdep.dmi.system-vendor': 'Google',
        'machdep.dmi.system-product': 'Google Google Compute Engine',
        'machdep.hypervisor': 'Google Google Compute Engine'
    }
    # Create a NetBSDVirtualCollector instance and use it to get the virtual
    # facts
    objs = NetBSDVirtualCollector({}, sysctl_map)
    facts = objs.get_all_facts()

    # Assert that the virtual facts were correctly retrieved
    assert facts['virtualization_type'] == 'gce'
    assert facts['virtualization_role'] == 'guest'
    assert facts['virtualization_tech_host'] == set()

# Generated at 2022-06-11 06:03:36.938249
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual_facts = NetBSDVirtual(module=None)

    # add sysctl keys to the test class
    netbsd_virtual_facts.sysctl_keys = {
        'machdep.dmi.system-product': 'VMWare Virtual Platform',
        'machdep.dmi.system-vendor': 'VMware, Inc.',
    }

    assert netbsd_virtual_facts.get_virtual_facts() == {
        'virtualization_type': 'vmware',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': {'vmware'},
        'virtualization_tech_host': {'vmware'},
        'virtualization_product_name': 'VMWare Virtual Platform',
    }

    # add sysctl keys to the test class
   

# Generated at 2022-06-11 06:03:40.210314
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'parallel' \
        or virtual_facts['virtualization_type'] == 'jail'
    assert 'virtualization_role' in virtual_facts

# Generated at 2022-06-11 06:03:42.550434
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    facts_collector = NetBSDVirtualCollector()
    assert facts_collector.platform == 'NetBSD'
    assert facts_collector._fact_class == NetBSDVirtual

# Generated at 2022-06-11 06:03:43.672308
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual(None)
    assert virtual.platform == 'NetBSD'

# Generated at 2022-06-11 06:03:51.235293
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():

    # Test input data
    test_input_data = {
        'machdep.dmi.system-product': '',
        'machdep.dmi.system-vendor': '',
        'machdep.hypervisor': '',
        'os': [ 'NetBSD' ]
    }

    # Test expected output data
    test_expected_data = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }

    test_obj = NetBSDVirtual(None)
    test_obj.facts = test_input_data
    test_output_data = test_obj.get_virtual_facts()

    assert test_expected_data == test_output_data

# Generated at 2022-06-11 06:03:53.357602
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert netbsd_virtual_collector._fact_class == NetBSDVirtual
    assert netbsd_virtual_collector._platform == 'NetBSD'

# Generated at 2022-06-11 06:03:54.930851
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    obj = NetBSDVirtual()
    assert obj.platform == 'NetBSD'


# Generated at 2022-06-11 06:06:31.937215
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    a = NetBSDVirtualCollector()
    assert a._platform == 'NetBSD'
    assert a._fact_class == NetBSDVirtual
    assert issubclass(a._fact_class, Virtual)
    assert issubclass(a._fact_class, VirtualSysctlDetectionMixin)


# Generated at 2022-06-11 06:06:40.059505
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    test_facts = { 'virtualization_type': '',
                   'virtualization_role': '',
                   'virtualization_tech_guest': set(),
                   'virtualization_tech_host': set(),
                   'machdep.dmi.system-vendor': 'VMware, Inc.',
                   'machdep.dmi.system-product': 'VMware Virtual Platform',
                   'machdep.hypervisor': 'VMware Virtual Platform',
                   'ansible_system': 'NetBSD'}
    virtual_facts = NetBSDVirtual().get_virtual_facts(test_facts)
    assert virtual_facts['virtualization_type'] == 'VMware Virtual Platform'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert 'vmware' in virtual_facts['virtualization_tech_guest']

# Generated at 2022-06-11 06:06:42.723853
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual(None).get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_system' in virtual_facts

# Generated at 2022-06-11 06:06:46.444503
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virt_facts = NetBSDVirtual()
    actual_facts = virt_facts.get_virtual_facts()

    assert actual_facts['virtualization_type'] == 'xen'
    assert actual_facts['virtualization_role'] == 'guest'
    assert actual_facts['virtualization_tech_guest'] == set(['xen'])
    assert actual_facts['virtualization_tech_host'] == set([])



# Generated at 2022-06-11 06:06:47.754668
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virtual_collector = NetBSDVirtualCollector()
    assert virtual_collector._platform == 'NetBSD'
    assert virtual_collector._fact_class == NetBSDVirtual

# Generated at 2022-06-11 06:06:49.255025
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virt = NetBSDVirtual({},{},{},{})
    assert virt.platform == 'NetBSD'