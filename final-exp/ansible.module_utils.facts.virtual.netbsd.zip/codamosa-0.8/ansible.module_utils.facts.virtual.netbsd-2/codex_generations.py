

# Generated at 2022-06-11 05:56:54.882376
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd = NetBSDVirtual()
    assert netbsd.platform == 'NetBSD'

# Generated at 2022-06-11 05:57:05.207338
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    fact = NetBSDVirtual(None)
    fact_names = sorted(fact.get_virtual_facts().keys())


# Generated at 2022-06-11 05:57:06.616954
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual()
    assert virtual.platform == 'NetBSD'

# Generated at 2022-06-11 05:57:10.712115
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual({})
    virtual_facts.get_virtual_facts()
    assert virtual_facts.virtual_facts['virtualization_type'] == ''
    assert virtual_facts.virtual_facts['virtualization_role'] == ''
    assert virtual_facts.virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts.virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-11 05:57:12.591720
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector(None, None, None)._platform == 'NetBSD'


# Generated at 2022-06-11 05:57:15.917256
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual({})
    assert netbsd_virtual.platform == 'NetBSD'
    assert netbsd_virtual.data == {}
    assert netbsd_virtual.collector is None


# Generated at 2022-06-11 05:57:25.688448
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual = NetBSDVirtual()

    # Get virtual facts from machdep.dmi.system-product
    # Given a dmidecode output that contains a 'Virtual Machine' system product
    # Then the type and role of virtualization must be correctly identified
    virtual_product_facts = netbsd_virtual.detect_virt_product('Virtual Machine')
    assert virtual_product_facts['virtualization_type'] == 'kvm'
    assert virtual_product_facts['virtualization_role'] == 'guest'

    # Get virtual facts from machdep.dmi.system-product
    # Given a dmidecode output that contains a 'VirtualBox' system product
    # Then the type and role of virtualization must be correctly identified
    virtual_product_facts = netbsd_virtual.detect_virt_product('VirtualBox')
   

# Generated at 2022-06-11 05:57:35.652782
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    '''Check NetBSDVirtual class constructor'''
    facts = NetBSDVirtual()
    assert facts.platform == 'NetBSD'
    assert sorted(facts.virtual_facts.keys()) == ['virtualization_role', 'virtualization_type', 'virtualization_type_nic', 'virtualization_type_nic_product_name', 'virtualization_type_nic_vendor_name', 'virtualization_type_nic_version', 'virtualization_type_product_name', 'virtualization_type_role', 'virtualization_type_version', 'virtualization_type_vm', 'virtualization_type_vm_product_name', 'virtualization_type_vm_vendor_name', 'virtualization_type_vm_version', 'virtualization_type_vendor_name']
    assert not facts.virtual_facts['virtualization_type_vm']

# Generated at 2022-06-11 05:57:39.147370
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] in \
           ['', 'oracle', 'kvm', 'xen']
    assert virtual_facts['virtualization_role'] in \
           ['', 'guest', 'host']

# Generated at 2022-06-11 05:57:48.080289
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual_test_object = NetBSDVirtual(module=None)
    test_facts = netbsd_virtual_test_object.get_virtual_facts()
    assert 'virtualization_type' in test_facts
    assert 'virtualization_role' in test_facts
    assert 'virtualization_sysctl_values' in test_facts
    assert 'virtualization_tech_host' in test_facts
    assert 'virtualization_tech_guest' in test_facts
    assert 'virtualization_hypervisor' in test_facts
    assert 'virtualization_product' in test_facts
    assert 'virtualization_vendor' in test_facts


# Generated at 2022-06-11 05:57:52.656250
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    netbsd_virtual.get_all_facts()

# Generated at 2022-06-11 05:57:54.045764
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsdvirtual = NetBSDVirtual()
    if netbsdvirtual.platform != "NetBSD":
        print("Failed to set platform to \"NetBSD\"")


# Generated at 2022-06-11 05:58:00.868607
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual_params = {
        'module_name': 'facts',
        'module_args': '',
        'persistent_cache_path': './ansible_facts'
    }

    netbsd_virtual_obj = NetBSDVirtual(netbsd_virtual_params)

    assert netbsd_virtual_obj is not None
    assert netbsd_virtual_obj._platform == 'NetBSD'


# Generated at 2022-06-11 05:58:01.558128
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    NetBSDVirtualCollector()

# Generated at 2022-06-11 05:58:03.458255
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual({}, {}, {})
    assert virtual.platform == 'NetBSD'



# Generated at 2022-06-11 05:58:05.759458
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual(None, None, '', None).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''

# Generated at 2022-06-11 05:58:10.029606
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # create a NetBSDVirtual class object
    netbsd_virtual_obj = NetBSDVirtual()
    # test the get_virtual_facts method
    assert netbsd_virtual_obj.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }

# Generated at 2022-06-11 05:58:10.634000
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    NetBSDVirtual()

# Generated at 2022-06-11 05:58:11.782738
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    NetBSDVirtualCollector()

# Generated at 2022-06-11 05:58:15.808059
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual({'ansible_facts': {}})
    assert netbsd_virtual.sysctl_mib == 'kern.bootfile'
    assert len(netbsd_virtual.virtual_facts) == 0
    assert not netbsd_virtual.detection_fail_msg

# Generated at 2022-06-11 05:58:24.756078
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual()
    assert(virtual_facts.platform == 'NetBSD')

# Generated at 2022-06-11 05:58:30.125256
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual('/tmp/')
    assert virtual.platform == 'NetBSD'

    assert virtual.sysctl_virt_product_name == 'machdep.dmi.system-product'
    assert virtual.sysctl_virt_vendor_name == 'machdep.dmi.system-vendor'
    assert virtual.virt_what_name == None

    virtual_collector = NetBSDVirtualCollector()
    assert virtual_collector._fact_class == NetBSDVirtual

# Generated at 2022-06-11 05:58:31.625689
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual()
    assert(virtual.platform == 'NetBSD')



# Generated at 2022-06-11 05:58:36.536577
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    v = NetBSDVirtual()
    # Empty values as default
    v_test = {'virtualization_type': '',
              'virtualization_role': '',
              'virtualization_system': ''}
    assert v.get_virtual_facts() == v_test

# Generated at 2022-06-11 05:58:38.479124
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual({})
    assert netbsd_virtual._platform == 'NetBSD'


# Generated at 2022-06-11 05:58:39.689803
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virt = NetBSDVirtual(None)
    assert virt.platform == 'NetBSD'

# Generated at 2022-06-11 05:58:41.309876
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virtual_collector = NetBSDVirtualCollector()
    assert virtual_collector._platform == 'NetBSD'

# Generated at 2022-06-11 05:58:44.193596
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    platform_virtual = NetBSDVirtualCollector()
    assert platform_virtual._platform == 'NetBSD'
    assert platform_virtual._fact_class == NetBSDVirtual

# Generated at 2022-06-11 05:58:48.979718
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    facts = {}
    NetBSDVirtualCollector(facts=facts)
    assert facts['virtualization_type'] == 'virtualbox'
    assert facts['virtualization_role'] == 'guest'
    assert facts['virtualization_tech_host'] == set(['virtualbox'])
    assert facts['virtualization_tech_guest'] == set(['virtualbox'])

# Generated at 2022-06-11 05:58:59.357144
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    class FakeFileObject(object):
        def __init__(self):
            self.fake_data = [
                b'machdep.dmi.system-product = "KVM"\n',
                b'machdep.dmi.system-vendor = "Red Hat"\n',
                b'machdep.hypervisor = "VMware"\n'
            ]

        def __call__(self, data):
            self.fake_data.append(data)
            return self

        def read(self, data):
            return self.fake_data.pop(0)

    virtual_info = NetBSDVirtual()
    virtual_info.file_exist = True
    virtual_info.collect_file_content = FakeFileObject()
    # if below test case fail, please check values in:
    # /src/lib/

# Generated at 2022-06-11 05:59:22.066393
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Create the NetBSDVirtual object for testing.
    test_NetBSDVirtual = NetBSDVirtual({}, {})
    test_NetBSDVirtual.sysctl_values = {'machdep.dmi.system-product': 'VirtualBox',
                                        'machdep.dmi.system-vendor': 'innotek GmbH'}
    test_NetBSDVirtual.sysctl_values_from_file = {}

    # Run get_virtual_facts from NetBSDVirtual and store
    # the result
    netbsd_virtual_facts = test_NetBSDVirtual.get_virtual_facts()

    # Make sure the keys are present in the
    # netbsd_virtual_facts dictionary.
    assert ('virtualization_type' in netbsd_virtual_facts)

# Generated at 2022-06-11 05:59:23.336897
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_netbsd = NetBSDVirtual(None)
    assert virtual_netbsd

# Generated at 2022-06-11 05:59:27.461056
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert type(netbsd_virtual_collector) is NetBSDVirtualCollector
    assert netbsd_virtual_collector.platform == 'NetBSD'
    assert netbsd_virtual_collector._fact_class == NetBSDVirtual


# Generated at 2022-06-11 05:59:29.167985
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsdvirt = NetBSDVirtual(None)
    assert netbsdvirt


# Generated at 2022-06-11 05:59:36.421568
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():

    test_host_facts = dict()
    test_host_facts['kernel'] = 'NetBSD'

    netbsd_virtual_facts = NetBSDVirtual(module=None)
    virtual_facts = netbsd_virtual_facts.get_virtual_facts(test_host_facts)

    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts

    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts


# Generated at 2022-06-11 05:59:39.258437
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual().get_virtual_facts()

    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'

# Generated at 2022-06-11 05:59:45.628797
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    test_sysctl_vars = {
        'machdep.dmi.system-vendor': 'Parallels Software International Inc.',
        'machdep.dmi.system-product': 'Parallels Virtual Platform',
    }

    test_facts = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }

    # Test product detection overriden by vendor detection.
    test_facts2 = test_facts.copy()
    test_facts2['virtualization_type'] = 'parallels'
    test_facts2['virtualization_tech_guest'] = set(['parallels'])

# Generated at 2022-06-11 05:59:48.045398
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    vc = NetBSDVirtualCollector()
    assert vc._platform == 'NetBSD'
    assert vc._fact_class == NetBSDVirtual

# Generated at 2022-06-11 05:59:52.194217
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    netbsd_virtual = netbsd_virtual_collector.get_virtual_facts()

    assert netbsd_virtual['virtualization_role'] == ''
    assert netbsd_virtual['virtualization_type'] == ''

# Generated at 2022-06-11 05:59:57.323697
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_cls = NetBSDVirtual()
    assert virtual_cls.platform == 'NetBSD'
    assert virtual_cls.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_systems': set(),
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()}



# Generated at 2022-06-11 06:00:30.176768
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Create a generic facts instance
    fake_facts = dict()

    # Create a NetBSDVirtual instance
    test_netbsd_virtual = NetBSDVirtual(fake_facts)

    # Check if 'get_virtual_facts' function returns a dict
    assert isinstance(test_netbsd_virtual.get_virtual_facts(), dict)

# Generated at 2022-06-11 06:00:33.691958
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts_obj = NetBSDVirtual({})
    virtual_facts = virtual_facts_obj.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''

# Generated at 2022-06-11 06:00:42.388095
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Create the 'mock_open' instance
    mock_open_instance = mock_open(read_data='vendor_string')

    # Set the properties of the mock instance
    mock_open_instance.return_value.__iter__.return_value = ['vendor_string']

    # Mock the open builtin in the NetBSDVirtual class
    with patch.object(NetBSDVirtual, 'open', mock_open_instance):
        # Create the NetBSDVirtual instance
        netbsd = NetBSDVirtual()

        # Test the get_virtual_facts method

# Generated at 2022-06-11 06:00:46.135094
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsdvirtual_object = NetBSDVirtual()
    assert netbsdvirtual_object._platform == 'NetBSD'
    assert NetBSDVirtual()._virtual_facts['virtualization_type'] == ''
    assert netbsdvirtual_object._virtual_facts['virtualization_role'] == ''


# Generated at 2022-06-11 06:00:48.075777
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    v = NetBSDVirtual()
    assert v.platform == 'NetBSD'


# Generated at 2022-06-11 06:00:49.622773
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    v = NetBSDVirtual(None)
    assert isinstance(v.get_virtual_facts(), dict)

# Generated at 2022-06-11 06:00:52.584115
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():

    # Construct NetBSDVirtual class
    fact_class = NetBSDVirtual()
    assert fact_class._detection_methods is not None
    assert fact_class._platform is not None

# Generated at 2022-06-11 06:01:01.198047
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Check default values
    expected = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': set()
    }
    assert NetBSDVirtual(None).get_virtual_facts() == expected

    # Check for not implemented detect_virt_product
    virtual = NetBSDVirtual(None)
    virtual.detect_virt_product = None
    assert virtual.get_virtual_facts() == expected

    # Check for not implemented detect_virt_vendor
    virtual = NetBSDVirtual(None)
    virtual.detect_virt_vendor = None
    assert virtual.get_virtual_facts() == expected

    # Check for empty netbsd_product
    virtual = NetBSDVirtual(None)
    virtual.detect_

# Generated at 2022-06-11 06:01:07.352438
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # If a class inherits from NetBSDVirtual,
    # does it return only a dictionary of desired values?
    class TestClass(NetBSDVirtual):
        def __init__(self):
            self.platform = "NetBSD"

    test = TestClass()
    facts = test.get_virtual_facts()

    assert all(k in facts for k in ('virtualization_type', 'virtualization_role'))
    assert all(isinstance(facts[k], str) for k in ('virtualization_type', 'virtualization_role'))

# Generated at 2022-06-11 06:01:09.360901
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.platform == 'NetBSD'

# Generated at 2022-06-11 06:02:18.809254
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virt = NetBSDVirtual()
    expected_facts = {
            'virtualization_role': 'guest',
            'virtualization_type': 'xen',
            'virtualization_technologies': {
                'guest': {'xen'},
                'host': set()
                }
            }
    assert virt.get_virtual_facts() == expected_facts

# Generated at 2022-06-11 06:02:25.528658
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual = NetBSDVirtual()
    virtual_facts = virtual.get_virtual_facts()

    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_system' in virtual_facts
    assert 'virtualization_product' in virtual_facts
    assert 'virtualization_product_version' in virtual_facts
    assert 'virtualization_product_vendor' in virtual_facts
    assert 'virtualization_product_serial' in virtual_facts
    assert 'virtualization_product_uuid' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-11 06:02:26.934170
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    v = NetBSDVirtual({},{},{},{})
    assert v.platform == 'NetBSD'


# Generated at 2022-06-11 06:02:27.972289
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd = NetBSDVirtual()
    assert netbsd is not None

# Generated at 2022-06-11 06:02:30.639033
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsdvirtual_collector = NetBSDVirtualCollector()
    assert netbsdvirtual_collector._platform == 'NetBSD'
    assert netbsdvirtual_collector._fact_class == NetBSDVirtual

# Generated at 2022-06-11 06:02:32.194353
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsdvirtual = NetBSDVirtual()
    assert netbsdvirtual.platform == 'NetBSD'

# Generated at 2022-06-11 06:02:37.743459
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual = NetBSDVirtual()

    results = netbsd_virtual.get_virtual_facts()
    assert results['virtualization_type'] == ''
    assert results['virtualization_role'] == ''
    assert results['virtualization_system'] == ''
    assert results['virtualization_uuid'] == ''
    assert results['virtualization_product_name'] == ''
    assert len(results['virtualization_tech_guest']) == 0
    assert len(results['virtualization_tech_host']) == 0

# Generated at 2022-06-11 06:02:39.218667
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.get_virtual_facts() == {}

# Generated at 2022-06-11 06:02:43.217228
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    compare_dict = {'virtualization_type': '', 'virtualization_role': '', 'virtualization_tech_guest': {'qemu'},
                    'virtualization_tech_host': {'qemu'}}
    test_virtual = NetBSDVirtual()
    assert test_virtual.get_virtual_facts() == compare_dict

# Generated at 2022-06-11 06:02:46.357161
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # TODO: add unit test for method get_virtual_facts of class NetBSDVirtual
    # TODO: add mock for methods of class sysctl.VirtualSysctlDetectionMixin
    # TODO: add mock for methods of class Virtual
    # TODO: add mock for methods of class VirtualCollector
    pass

# Generated at 2022-06-11 06:04:04.186676
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual(module_args=dict())

    for key in ['module_args', 'virtual', 'sysctl_path']:
        assert hasattr(netbsd_virtual, key) and getattr(netbsd_virtual, key) is not None


# Generated at 2022-06-11 06:04:06.855043
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual()
    assert virtual_facts.platform == 'NetBSD'
    assert virtual_facts.get_virtual_facts() == {}

    # valid method names
    assert NetBSDVirtual().is_virtual == NetBSDVirtual().is_netbsd_virtual

# Generated at 2022-06-11 06:04:08.602741
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.platform == 'NetBSD'

# Generated at 2022-06-11 06:04:15.729599
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    obj = NetBSDVirtual()
    facts = {}
    facts['kernel'] = 'NetBSD'
    facts['machine'] = 'amd64'
    with open('/proc/cpuinfo', 'r') as cpu_info:
        obj.cpuinfo = cpu_info.read()
    with open('/proc/cmdline', 'r') as cmdline:
        obj.cmdline = cmdline.read()
    with open('/proc/mounts', 'r') as mounts:
        obj.mounts = mounts.read()
    facts['systemd'] = False
    facts['virtualization_type'] = ''
    facts['virtualization_role'] = ''
    with open('/proc/1/cmdline') as proc_1_cmdline:
        proc_1_cmdline_txt = proc_1_cmdline.read()
        facts

# Generated at 2022-06-11 06:04:17.214192
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_facts = NetBSDVirtual()
    assert netbsd_facts.is_netbsd()

# Generated at 2022-06-11 06:04:19.178241
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual_object = NetBSDVirtual()
    assert netbsd_virtual_object.platform == 'NetBSD'

# Generated at 2022-06-11 06:04:20.017110
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    NetBSDVirtualCollector()

# Generated at 2022-06-11 06:04:21.906066
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual = NetBSDVirtual()
    virtual_facts = virtual.get_virtual_facts()

    assert isinstance(virtual_facts['virtualization_type'], str)

# Generated at 2022-06-11 06:04:29.617381
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    test_facts = dict(
        virtual_facts=dict(
            machdep_dmi_system_product=dict(
                manufacturer='',
                version='',
                product='Bochs',
            ),
            machdep_dmi_system_vendor=dict(
                manufacturer='',
                version='',
                product='Parallels Software International Inc.',
            ),
            machdep_hypervisor=dict(
                manufacturer='',
                version='',
                product='VMware',
            ),
        ),
    )
    facts = NetBSDVirtual(None, test_facts).get_virtual_facts()
    # Test what gets returned
    assert facts['virtualization_type'] == 'vmware'
    assert facts['virtualization_role'] == 'guest'

# Generated at 2022-06-11 06:04:37.411576
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual = NetBSDVirtual()
    facts = {
        'machdep.dmi.system-vendor': 'ACME Inc.',
        'machdep.dmi.system-product': 'Virtual Product',
    }

    def sysctl_side_effect(mock_cmd, raise_exc=False):
        if raise_exc:
            raise Exception('oops')

        if mock_cmd[-1] in facts:
            return facts[mock_cmd[-1]]

        return ''

    sysctl_exists = os.path.exists
    sysctl_exists_side_effect = sysctl_exists('/proc/xen/capabilities')
    if not sysctl_exists_side_effect:
        os.path.exists = lambda x: x == '/dev/xencons'
