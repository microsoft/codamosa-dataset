

# Generated at 2022-06-11 05:57:05.122654
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    def _read_mock_file(filename):
        if filename == '/dev/xen/evtchn':
            return '0'
        elif filename == '/dev/xen/privcmd':
            return '0'
        elif filename == '/dev/xen/gntdev':
            return '0'
        elif filename == '/dev/xen/evtchn':
            return '0'
        return None

    def _read_sysctl_mock(sysctl):
        if sysctl == 'machdep.dmi.system-product':
            return 'KVM'
        elif sysctl == 'machdep.dmi.system-vendor':
            return 'Microsoft Corporation'
        elif sysctl == 'machdep.hypervisor':
            return 'bhyve'
        return None

    module

# Generated at 2022-06-11 05:57:06.616447
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    fact_class = NetBSDVirtual()
    assert fact_class.platform == 'NetBSD'

# Generated at 2022-06-11 05:57:15.287076
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual = NetBSDVirtual()
    netbsd_virtual.populate_sysctl = lambda: {'machdep.dmi.system-product': 'QEMU Virtual Machine',
                                              'machdep.dmi.system-vendor': 'Red Hat'}
    netbsd_virtual.virtual_facts = netbsd_virtual.get_virtual_facts()
    assert netbsd_virtual.virtual_facts['virtualization_type'] == 'kvm'
    assert netbsd_virtual.virtual_facts['virtualization_role'] == 'guest'
    assert 'xen' in netbsd_virtual.virtual_facts['virtualization_tech_guest']
    assert 'kvm' in netbsd_virtual.virtual_facts['virtualization_tech_host']

    netbsd_virtual = Net

# Generated at 2022-06-11 05:57:16.018512
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    pass

# Generated at 2022-06-11 05:57:20.751177
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual = NetBSDVirtual({})
    virtual_facts = virtual.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == 'VirtualBox'
    assert virtual_facts['virtualization_role'] == ''
    assert 'virtualbox' in virtual_facts['virtualization_tech_guest']
    assert 'virtualbox' in virtual_facts['virtualization_tech_host']

# Generated at 2022-06-11 05:57:30.884946
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():  # pylint: disable=invalid-name
    # Create an instance of class NetBSDVirtual
    virtual = NetBSDVirtual()

    # Create a fake file object with a read method that returns a specific
    # string.
    read_data = 'machdep.dmi.system-vendor: KVM\nmachdep.hypervisor: QEMU'
    fake_file_obj = type('', (object,), {'read': lambda self: read_data})

    # Create a fake NetBSD module with the above fake file object.
    fake_NetBSD_module = type('', (object,), {'_read_sysctl': lambda self, f: fake_file_obj})

    # Set the module as a member of the class as it is usually done when
    # module_utils.facts.virtual.netbsd is imported.
    virtual

# Generated at 2022-06-11 05:57:38.736916
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    mock_module = type('AnsibleModule', (object,), {
        "exit_json": lambda self, v: None,
        "fail_json": lambda self, v: None,
    })

    def get_file_content(path):
        if path == '/sbin/sysctl machdep.dmi.system-vendor':
            return 'machdep.dmi.system-vendor: Sun Microsystems\n'
        elif path == '/sbin/sysctl machdep.hypervisor':
            return 'machdep.hypervisor: Xen\n'
        elif path == '/sbin/sysctl machdep.dmi.system-product':
            return 'machdep.dmi.system-product: Netra X4250\n'

# Generated at 2022-06-11 05:57:39.415239
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    pass

# Generated at 2022-06-11 05:57:40.993851
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    # Check that the platform is NetBSD
    assert NetBSDVirtual().platform == 'NetBSD'

# Generated at 2022-06-11 05:57:43.892539
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_ins = NetBSDVirtual()
    print(virtual_ins.get_virtual_facts())

if __name__ == '__main__':
    test_NetBSDVirtual()

# Generated at 2022-06-11 05:57:49.488203
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_NetBSD = NetBSDVirtual()
    assert virtual_NetBSD.platform == 'NetBSD'


# Generated at 2022-06-11 05:57:50.815190
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual()
    assert virtual.platform == 'NetBSD'

# Generated at 2022-06-11 05:57:52.943861
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual = NetBSDVirtual()
    virtual_facts = virtual.get_virtual_facts()
    assert type(virtual_facts) == dict


# Generated at 2022-06-11 05:57:56.158570
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.platform == 'NetBSD'
    assert netbsd_virtual._platform == 'NetBSD'
    assert netbsd_virtual._fact_class == NetBSDVirtual
    assert netbsd_virtual._collector_platform == 'NetBSD'

# Generated at 2022-06-11 05:58:00.792253
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    module = AnsibleModule(
        argument_spec = dict()
    )

    def get_file_content(path):
        content = {
            'machdep.dmi.system-vendor': 'GOOGLE',
            'machdep.hypervisor': 'Xen'
        }
        return content[path].encode()

    setattr(module.params['ansible_facts']['ansible_module_mock']['subprocess'], 'check_output', get_file_content)

    netbsd_virtual = NetBSDVirtual(module)
    result = netbsd_virtual.get_virtual_facts()
    assert result['virtualization_type'] == 'xen'
    assert result['virtualization_role'] == 'guest'

# Generated at 2022-06-11 05:58:01.913303
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virtual = NetBSDVirtualCollector()
    assert virtual.platform == 'NetBSD'


# Generated at 2022-06-11 05:58:10.926483
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Virtualization of type 'xen'
    sysctl_virtype_xen = {
        'machdep.hypervisor': 'Xen',
        'machdep.dmi.system-product': 'HVM domU',
        'machdep.dmi.system-vendor': 'Xen'
    }
    sysctl_virtype_xen_expected_virtual_facts = dict(
        virtualization_type='xen',
        virtualization_role='guest',
        virtualization_tech_guest={'xen'},
        virtualization_tech_host={'xen'},
    )
    # Virtualization of type 'xenpv'

# Generated at 2022-06-11 05:58:15.438569
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual()
    assert isinstance(virtual_facts, dict)
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-11 05:58:17.292451
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual({})
    assert virtual.platform == 'NetBSD'



# Generated at 2022-06-11 05:58:18.686606
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virt = NetBSDVirtual()
    # Test the constructor
    assert virt is not None

# Generated at 2022-06-11 05:58:27.026432
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual({})
    assert virtual_facts.platform == 'NetBSD'

# Generated at 2022-06-11 05:58:28.951855
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virtual_collector = NetBSDVirtualCollector()
    assert isinstance(virtual_collector, NetBSDVirtualCollector)



# Generated at 2022-06-11 05:58:30.532681
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert netbsd_virtual_collector

# Generated at 2022-06-11 05:58:32.240998
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    obj = NetBSDVirtual()
    assert obj.platform == 'NetBSD'


# Generated at 2022-06-11 05:58:41.903109
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():

    # Expected virtual facts on a VirtualBox guest
    expected_virtual_facts_virtualbox = {
        'virtual': True,
        'virtualization_type': 'virtualbox',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['virtualbox']),
        'virtualization_tech_host': set(['virtualbox'])
    }

    # Expected virtual facts on a VMware guest
    expected_virtual_facts_vmware = {
        'virtual': True,
        'virtualization_type': 'vmware',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['vmware']),
        'virtualization_tech_host': set(['vmware'])
    }

    # Expected virtual facts on a VirtualBox host
    expected

# Generated at 2022-06-11 05:58:42.823722
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd = NetBSDVirtual()


# Generated at 2022-06-11 05:58:48.259363
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    expected = {'virtualization_role': 'guest',
                'virtualization_type': 'xen',
                'virtualization_tech_guest': set(['xen']),
                'virtualization_tech_host': set([])}

    collector = NetBSDVirtualCollector()
    facts = collector.get_virtual_facts()

    assert facts == expected

# Generated at 2022-06-11 05:58:50.912810
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_fact = NetBSDVirtual()
    assert netbsd_fact.platform == 'NetBSD'

# Generated at 2022-06-11 05:58:53.582488
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    fact_collector = NetBSDVirtualCollector()
    assert fact_collector._fact_class == NetBSDVirtual
    assert fact_collector._platform == "NetBSD"

# Generated at 2022-06-11 05:58:56.287776
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual({'ansible_facts': {}})
    assert netbsd_virtual.platform == 'NetBSD'


# Generated at 2022-06-11 05:59:12.262681
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    nbvirt = NetBSDVirtual()
    # check if sysctl path exists
    assert nbvirt.sysctl_path
    # check if sysctl exists
    assert nbvirt.sysctl

# Generated at 2022-06-11 05:59:21.184330
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    os_release_content = '''
ID=netbsd
VERSION_ID=9.0
PRETTY_NAME="NetBSD 9.0"
HOME_URL=
SUPPORT_URL=
BUG_REPORT_URL='''

    mock_uname_result = [(
        'NetBSD',
        'styx.NetBSD.org',
        '9.99.99',
        'NetBSD',
        '9.99.99',
        'i386'
    ), (
        'NetBSD',
        'zeus.NetBSD.org',
        '9.1',
        'NetBSD',
        '9.1',
        'amd64'
    )]

    def mock_uname():
        return mock_uname_result.pop()

    os_release_file_content = []
    os_

# Generated at 2022-06-11 05:59:26.631927
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert 'xen' in virtual_facts['virtualization_tech_guest']
    assert len(virtual_facts['virtualization_tech_host']) == 0
    assert len(virtual_facts['virtualization_tech_guest']) == 1

# Generated at 2022-06-11 05:59:28.809995
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    result = NetBSDVirtualCollector()
    assert result._platform == 'NetBSD'
    assert result._fact_class == NetBSDVirtual

# Generated at 2022-06-11 05:59:29.810105
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    NetBSDVirtualCollector()

# Generated at 2022-06-11 05:59:36.311820
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Test on NetBSD VM
    if os.path.exists('/proc/devices'):
        virtual_facts = NetBSDVirtual().get_virtual_facts()
        assert virtual_facts['virtualization_type'] == 'kvm'
        assert virtual_facts['virtualization_role'] == 'guest'
        assert virtual_facts['virtualization_tech_guest'] == set(['kvm'])
        assert virtual_facts['virtualization_tech_host'] == set(['kvm'])

# Generated at 2022-06-11 05:59:38.823758
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd = NetBSDVirtual()
    assert netbsd._platform == 'NetBSD'
    assert netbsd._fact_class == 'NetBSDVirtual'

# Generated at 2022-06-11 05:59:43.622017
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()

    # set fact value
    fact_value = {}
    fact_value['virtualization_type'] = ''
    fact_value['virtualization_role'] = ''
    fact_value['virtualization_system'] = ''
    fact_value['virtualization_product'] = ''

    # check if fact value is equal to default value
    assert netbsd_virtual.get_virtual_facts() == fact_value


# Generated at 2022-06-11 05:59:45.495317
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virt = NetBSDVirtual({'ansible_facts': {}})
    assert virt.platform == 'NetBSD'

# Generated at 2022-06-11 05:59:51.224332
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    collector = NetBSDVirtualCollector()
    virtual_facts = collector.get_virtual_facts()
    assert(virtual_facts['virtualization_type'] == 'xen')
    assert(virtual_facts['virtualization_role'] == 'guest')
    assert(virtual_facts['virtualization_tech_guest'] == set(['xen']))
    assert(virtual_facts['virtualization_tech_host'] == set())

# Generated at 2022-06-11 06:00:19.455495
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    NetBSDVirtual()


# Generated at 2022-06-11 06:00:28.499254
# Unit test for method get_virtual_facts of class NetBSDVirtual

# Generated at 2022-06-11 06:00:30.655176
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual({})
    assert netbsd_virtual.platform == 'NetBSD'



# Generated at 2022-06-11 06:00:32.365350
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual().get_virtual_facts()

    assert virtual_facts['virtualization_type'] != ''

# Generated at 2022-06-11 06:00:41.651613
# Unit test for method get_virtual_facts of class NetBSDVirtual

# Generated at 2022-06-11 06:00:43.610412
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual(None)

    assert netbsd_virtual.platform == 'NetBSD'


# Generated at 2022-06-11 06:00:45.188446
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual(None)
    assert netbsd_virtual.platform == 'NetBSD'

# Generated at 2022-06-11 06:00:53.582819
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    #
    # This test doesn't really do much except verify that the class exists,
    # because the real logic is tested in test_virtual_product and
    # test_virtual_vendor test cases.
    #
    fake_module = {
        'run_command': lambda args, **kwargs: (0, '', ''),
        'get_bin_path': lambda args, **kwargs: '/usr/bin/sysctl'
    }
    netbsd_virtual = NetBSDVirtual(module=fake_module)
    expected_result = {'virtualization_type': '', 'virtualization_role': '',
                       'virtualization_tech_guest': set(),
                       'virtualization_tech_host': set()}
    assert netbsd_virtual.get_virtual_facts() == expected_result

# Generated at 2022-06-11 06:01:00.420488
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    module = AnsibleModule(dict(ansible_facts=dict(machdep=dict(dmi=dict(system_product='VirtualBox')))))
    virtual_facts = NetBSDVirtual(module).get_virtual_facts()

    assert 'virtualization_type' in virtual_facts
    assert virtual_facts['virtualization_type'] == 'virtualbox'
    assert 'virtualization_role' in virtual_facts
    assert virtual_facts['virtualization_role'] == 'guest'
    assert 'virtualization_tech' in virtual_facts
    assert virtual_facts['virtualization_tech'] == 'virtualbox'



# Generated at 2022-06-11 06:01:03.897213
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()

    assert netbsd_virtual.platform == 'NetBSD'
    assert netbsd_virtual._platform_name == 'NetBSD'
    assert netbsd_virtual._sysctl_func_name == 'sysctlbyname'

# Generated at 2022-06-11 06:02:04.942770
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.platform == 'NetBSD'


# Generated at 2022-06-11 06:02:07.963684
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    expected_facts = {'virtualization_type': '',
                      'virtualization_role': '',
                      'virtualization_tech_guest': set(),
                      'virtualization_tech_host': set()}

    facts = NetBSDVirtualCollector.get_virtual_facts()
    assert isinstance(facts, dict)
    assert facts == expected_facts

# Generated at 2022-06-11 06:02:09.206696
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    assert NetBSDVirtual().get_virtual_facts() == {}
    assert NetBSDVirtualCollector().collect() == {}

# Generated at 2022-06-11 06:02:11.235018
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsdvirtual = NetBSDVirtual()
    assert netbsdvirtual is not None

if __name__ == '__main__':
    test_NetBSDVirtual()

# Generated at 2022-06-11 06:02:13.557810
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual()
    assert virtual_facts.get_virtual_facts() == {}
    assert virtual_facts.platform == "NetBSD"

# Generated at 2022-06-11 06:02:15.170239
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual(module=None)
    assert virtual.platform == 'NetBSD'



# Generated at 2022-06-11 06:02:19.608680
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual = NetBSDVirtual()
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_host'] == set()
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_product_name'] == ''

# Generated at 2022-06-11 06:02:27.440234
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Test data
    test_facts = {
        'machdep.dmi.system-product': '',
        'machdep.dmi.system-vendor': '',
        'machdep.hypervisor': '',
        }

    # Initialise fact
    virtual = NetBSDVirtual(module=None)
    virtual.get_virtual_facts = Virtual.get_virtual_facts
    virtual.collect_sysctl_facts = lambda: test_facts

    # Test each case of machdep.dmi.system-vendor/machdep.dmi.system-product
    # and machdep.hypervisor

# Generated at 2022-06-11 06:02:29.251030
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    nv_c = NetBSDVirtualCollector()
    assert nv_c._platform == nv_c._fact_class.platform

# Generated at 2022-06-11 06:02:30.987996
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    nv = NetBSDVirtual()
    assert nv.platform == 'NetBSD'



# Generated at 2022-06-11 06:05:08.258378
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    fact_collector = NetBSDVirtualCollector()
    assert fact_collector._platform == 'NetBSD'
    assert fact_collector._fact_class == NetBSDVirtual


# Generated at 2022-06-11 06:05:14.188000
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsdVirtual = NetBSDVirtual()

    # Set values for get_virtual_product_facts return dict
    virtual_product_facts = {'virtualization_type': 'virtualbox', 'virtualization_role': 'guest'}

    # Set values for get_virtual_vendor_facts return dict
    virtual_vendor_facts = {'virtualization_type': 'virtualbox', 'virtualization_role': 'guest'}

    # Set method get_virtual_product_facts return value
    netbsdVirtual.get_virtual_product_facts = lambda: virtual_product_facts

    # Set method get_virtual_vendor_facts return value
    netbsdVirtual.get_virtual_vendor_facts = lambda: virtual_vendor_facts

    # Set method is_sysctl_virtual_facts2_present return value
    netbs

# Generated at 2022-06-11 06:05:14.942560
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    NetBSDVirtual()


# Generated at 2022-06-11 06:05:18.912278
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    data = NetBSDVirtual()

    # get_virtual_facts
    assert data.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_sysctl': {
            'machdep.dmi.system-product': '',
            'machdep.dmi.system-vendor': '',
            'machdep.hypervisor': ''
        }
    }


# Generated at 2022-06-11 06:05:19.616979
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    NetBSDVirtual(None)

# Generated at 2022-06-11 06:05:20.544293
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual()
    assert virtual_facts.platform == 'NetBSD'

# Generated at 2022-06-11 06:05:21.807438
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual(None)
    assert virtual.platform == 'NetBSD'


# Generated at 2022-06-11 06:05:23.107792
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual(module=None)
    assert netbsd_virtual.platform == 'NetBSD'

# Generated at 2022-06-11 06:05:29.920523
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    facts = dict()
    fake_virtual = NetBSDVirtual(module=None, facts=facts)

    # Test for virtualization_type kvm
    fake_virtual.facts['machdep.dmi.system-product'] = 'OpenStack Nova'
    fake_virtual.get_virtual_facts() == dict(
        virtualization_type='kvm',
        virtualization_role='guest',
        virtualization_tech_guest={'kvm', 'qemu'},
        virtualization_tech_host={'kvm'}
    )

    # Test for virtualization_type kvm
    fake_virtual.facts['machdep.dmi.system-product'] = 'KVM'

# Generated at 2022-06-11 06:05:31.342322
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    test_object = NetBSDVirtual({})
    assert(test_object.get_virtual_facts()['virtualization_type'] == '')