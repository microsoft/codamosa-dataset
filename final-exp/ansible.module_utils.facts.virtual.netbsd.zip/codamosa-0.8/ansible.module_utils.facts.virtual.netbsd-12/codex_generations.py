

# Generated at 2022-06-11 05:56:56.192054
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    NetBSDVirtual(dict(), dict(), [])

# Generated at 2022-06-11 05:56:58.283287
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    # create a NetBSDVirtualCollector object
    fact = NetBSDVirtualCollector()
    assert fact._platform == 'NetBSD'


# Generated at 2022-06-11 05:57:00.573364
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    x = NetBSDVirtualCollector()
    assert x.get_all_facts().get('virtualization_type') == ''


# Generated at 2022-06-11 05:57:01.543830
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    NetBSDVirtualCollector()

# Generated at 2022-06-11 05:57:03.117468
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual()
    assert virtual.platform == 'NetBSD'

# Generated at 2022-06-11 05:57:10.675050
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    sysctl_data = {'hw.products': {'hw.product.name': 'Product1',
                                   'hw.product.vendor': 'Vendor1'}}
    sysctl_data.update({'machdep.dmi.system-vendor': 'Vendor2',
                        'machdep.dmi.system-product': 'Product2'})
    sysctl_data.update({'machdep.dmi.system-version': 'Version1'})
    sysctl_data.update({'machdep.hypervisor': 'Hypervisor1'})

    virtual = NetBSDVirtual(sysctl_data, None)
    virtual_facts = virtual.collect()

    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual

# Generated at 2022-06-11 05:57:19.519570
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = {
        'virtualization_type': 'virtualbox',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': {},
        'virtualization_tech_host': {'virtualbox'}
    }

    netbsd_virtual = NetBSDVirtual()
    sysctl = MockSysctl([
        # machdep.dmi.system-product
        'HP ProLiant MicroServer',
        # machdep.dmi.system-vendor
        'HP',
        # machdep.hypervisor
        ''
    ])
    facts = netbsd_virtual.get_virtual_facts(sysctl=sysctl)

    assert facts == virtual_facts


# Generated at 2022-06-11 05:57:21.990021
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    """
    Test for class constructor.
    """
    netbsd_virtual = NetBSDVirtual(None)
    assert netbsd_virtual


# Generated at 2022-06-11 05:57:25.781135
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    virtual_facts = netbsd_virtual_collector.get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts

# Generated at 2022-06-11 05:57:35.064992
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.virtual import NetBSDVirtual

    facts_dict = {}

    fact_collector = FactCollector(cache={}, gather_subset=["!all"])

    NetBSDVirtual_obj = NetBSDVirtual(None, fact_collector, facts_dict)
    result = NetBSDVirtual_obj.get_virtual_facts()
    assert result == {
        'virtualization_role': 'guest',
        'virtualization_type': 'xen',
        'virtualization_tech_guest': set([
            'xen'
        ]),
        'virtualization_tech_host': set([
            'xen'
        ])
    }

# Generated at 2022-06-11 05:57:43.987529
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virtual_collector = NetBSDVirtualCollector()
    assert virtual_collector._platform == 'NetBSD'


# Generated at 2022-06-11 05:57:46.516323
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    nbsdvc = NetBSDVirtualCollector()

    assert nbsdvc.platform == 'NetBSD'
    assert nbsdvc.fact_class == NetBSDVirtual


# Generated at 2022-06-11 05:57:50.058567
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual({})
    assert virtual.get_virtual_facts() == dict(
        subsystem='kern',
        virtualization_role='',
        virtualization_type='',
        virtualization_technology={},
    )

# Generated at 2022-06-11 05:57:57.866420
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts_class = NetBSDVirtual()

    # Test VMware
    sysctl_mock = {'machdep.dmi.system-vendor': 'VMware, Inc.',
                   'machdep.dmi.system-product': 'VMware Virtual Platform'}
    virtual_facts_class.sysctl_all = lambda: sysctl_mock
    virtual_facts_class.virt_what = lambda: ""

    virtual_facts = virtual_facts_class.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'VMware'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_guest'] == set(['vmware'])
    assert virtual_facts['virtualization_tech_host'] == set(['vmware'])



# Generated at 2022-06-11 05:58:00.371476
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert netbsd_virtual_collector._platform == 'NetBSD'

# Generated at 2022-06-11 05:58:01.321162
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual()
    assert virtual.platform == 'NetBSD'

# Generated at 2022-06-11 05:58:10.559243
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    from ansible_collections.ansible.community.plugins.module_utils.facts.virtual.netbsd.test_netbsd_virtual import (
        NetBSDVirtual_return_values
    )


# Generated at 2022-06-11 05:58:20.599769
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Create test object
    NetBSDVirtual_obj = NetBSDVirtual()

    # Run tests
    facts = NetBSDVirtual_obj.get_virtual_facts()
    assert facts['virtualization_type'] in ('', 'xen', 'kvm', 'hyperv', 'virtualbox', 'chroot', 'zvm', 'lxc', 'lxc-libvirt', 'openvzhn')
    assert facts['virtualization_role'] in ('', 'guest', 'host')
    assert facts['virtualization_subtype'] in ('', 'openvzhn')
    assert facts['virtualization_subsystem'] in ('', 'chroot', 'lxc-libvirt')
    assert isinstance(facts['virtualization_tech_host'], set)
    assert isinstance(facts['virtualization_tech_guest'], set)

# Generated at 2022-06-11 05:58:21.289838
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    NetBSDVirtualCollector()

# Generated at 2022-06-11 05:58:25.772878
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # The values here were taken from NetBSD 8.0
    from ansible.module_utils._text import to_text
    virtual_facts = NetBSDVirtual({}).get_virtual_facts()

# Generated at 2022-06-11 05:58:35.767104
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    nets = NetBSDVirtual()

    # Test for the existence of the class attributes
    assert nets.platform == 'NetBSD'
    assert hasattr(nets, 'get_virtual_facts')

# Generated at 2022-06-11 05:58:39.137647
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    facts = NetBSDVirtual('').get_virtual_facts()
    assert 'virtualization_tech_guest' in facts
    assert 'virtualization_tech_host' in facts
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts

# Generated at 2022-06-11 05:58:44.270147
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    netbsd_virtual_obj = netbsd_virtual_collector.collect()
    netbsd_virtual_facts = netbsd_virtual_obj.get_virtual_facts()
    assert netbsd_virtual_facts
    assert netbsd_virtual_facts['virtualization_type'] == ''
    assert netbsd_virtual_facts['virtualization_role'] == ''
    assert netbsd_virtual_facts['virtualization_tech_guest'] == set()
    assert netbsd_virtual_facts['virtualization_tech_host'] == set()


# Generated at 2022-06-11 05:58:45.191334
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    facter = NetBSDVirtual()
    assert facter.platform == 'NetBSD'


# Generated at 2022-06-11 05:58:47.727529
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert isinstance(netbsd_virtual_collector._fact_class(), NetBSDVirtual)

# Generated at 2022-06-11 05:58:50.567227
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    pytest_virtual = NetBSDVirtual(module=None)
    assert pytest_virtual


# Generated at 2022-06-11 05:58:59.986783
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    sysctl_result = {
        'machdep.dmi.system-product': 'VMware VMware Virtual Platform',
        'machdep.dmi.system-uuid': '56 4D A7 8D 8B E1 F7 B1-D6 DA 94 CC 85 E0 41 1E',
        'machdep.dmi.system-vendor': 'VMware, Inc.'
    }

    sysctl_output = ''

    for k, v in sysctl_result.items():
        sysctl_output += '{0}: {1}\n'.format(k, v)

    facts = NetBSDVirtual({}, {}, sysctl_output)
    virtual_facts = facts.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == 'VMware'
    assert virtual_facts['virtualization_role']

# Generated at 2022-06-11 05:59:01.691605
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsdvirtual = NetBSDVirtual()
    assert netbsdvirtual.platform == 'NetBSD'

# Generated at 2022-06-11 05:59:02.655616
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector.virtual() == NetBSDVirtual

# Generated at 2022-06-11 05:59:04.733001
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual_class = NetBSDVirtual(module=None)
    assert netbsd_virtual_class.platform == 'NetBSD'

# Generated at 2022-06-11 05:59:18.855847
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual()
    assert virtual.fact_subclass != None

# Generated at 2022-06-11 05:59:21.435958
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual()
    assert virtual_facts.__class__.__name__ == 'NetBSDVirtual'
    assert virtual_facts._platform == 'NetBSD'
    assert virtual_facts._fact_class is NetBSDVirtual

# Generated at 2022-06-11 05:59:31.169148
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Tests for machdep.dmi.system-product
    # The first line of machdep.dmi.system-product gives the virtualization type
    # The second line gives the virtualization role
    # The third line is the product name
    # The forth is the vendor name

    # VirtualBox
    content = '''innotek GmbH
VirtualBox
VirtualBox
innotek GmbH
'''
    sysctl_lines = content.splitlines()
    module = get_mocked_module(sysctl_lines)
    virtual = NetBSDVirtual(module)
    result = virtual.get_virtual_facts()
    assert result['virtualization_role'] == 'guest'
    assert result['virtualization_type'] == 'xen'
    assert 'oracle_vm_server' in result['virtualization_tech_guest']

# Generated at 2022-06-11 05:59:41.170411
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    detect_product_sysctl_output_1 = '''machdep.dmi.system-product: "VirtualBox"
machdep.dmi.system-vendor: "innotek"'''

    detect_vendor_sysctl_output_1 = '''machdep.dmi.system-vendor: "innotek"
machdep.dmi.system-product: "VirtualBox"'''

    detect_vendor_sysctl_output_2 = '''machdep.hypervisor: "Xen"
xen.version: "4.8.1"'''

    virtual_facts = NetBSDVirtual()

# Generated at 2022-06-11 05:59:43.074631
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual()
    assert virtual_facts.get_virtual_facts() == {}


# Generated at 2022-06-11 05:59:46.473932
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    '''
    Unit test for constructor of class NetBSDVirtual
    '''
    netbsd_virtual = NetBSDVirtual(None)
    assert isinstance(netbsd_virtual, NetBSDVirtual)

# Generated at 2022-06-11 05:59:53.795861
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    test_data = [('hypervisor', 'machdep.dmi.system-vendor', 'xen'), ('hypervisor', 'machdep.dmi.system-product', 'xen')]
    expected = {'virtualization_tech_host': {'xen'}, 'virtualization_tech_guest': {'xen'},
                'virtualization_role': 'host', 'virtualization_type': 'xen'}
    test_virtual = NetBSDVirtual(sysctl_all_exists=test_data)
    assert test_virtual.get_virtual_facts() == expected

# Generated at 2022-06-11 05:59:59.064673
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    # Test sysctl_facts
    sysctl_facts = VirtualSysctlDetectionMixin.fetch_sysctl_facts(
        VirtualSysctlDetectionMixin())
    assert sysctl_facts is not None

    # Test constructor
    virtual_facts_obj = NetBSDVirtual(sysctl_facts=sysctl_facts,
                                      module_facts={},
                                      facts={},
                                      lscpu_facts={})
    assert virtual_facts_obj is not None

# Generated at 2022-06-11 05:59:59.874367
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    nv = NetBSDVirtual()
    assert nv

# Generated at 2022-06-11 06:00:01.320171
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsdvirtual = NetBSDVirtual()
    assert netbsdvirtual.platform == 'NetBSD'


# Generated at 2022-06-11 06:00:37.518905
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virt = NetBSDVirtual()
    if virt.collect_virt_facts():
        virtual_facts = virt.get_virtual_facts()

        # Assuming the unit test is run on the host system, the
        # 'virtualization_type' should be empty that is the system would
        # not be a host or guest system of any virtualization system.
        assert virtual_facts['virtualization_type'] == ''
        assert virtual_facts['virtualization_role'] == ''

        # Assuming the unit test is run on the host system, the
        # 'virtualization_tech_guest' and 'virtualization_tech_host' should
        # be empty sets.
        assert virtual_facts['virtualization_tech_guest'] == set()
        assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-11 06:00:45.119803
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = dict()
    virtual_facts['virtualization_type'] = 'virtualbox'
    virtual_facts['virtualization_role'] = 'guest'
    virtual_facts['virtualization_tech_guest'] = set()
    virtual_facts['virtualization_tech_host'] = set()
    virtual_facts['virtualization_tech_guest'].add('linux_vserver')
    virtual_facts['virtualization_tech_host'].add('linux_vserver')
    virtual_facts['virtualization_tech_host'].add('lxc')
    virtual_facts['virtualization_tech_host'].add('libvirt')
    virtual_facts['virtualization_tech_host'].add('lxc')
    virtual_facts['virtualization_tech_host'].add('docker')


# Generated at 2022-06-11 06:00:48.078114
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    n = NetBSDVirtualCollector()
    assert n.platform == 'NetBSD'
    assert n._fact_class == NetBSDVirtual
    assert n._platform == 'NetBSD'


# Generated at 2022-06-11 06:00:55.103540
# Unit test for method get_virtual_facts of class NetBSDVirtual

# Generated at 2022-06-11 06:01:02.404496
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    v = NetBSDVirtual({'ansible_facts': {},
                       'platform': 'NetBSD'},
                      {'platform_subfamily': '6.1'})
    v.collect_platform_subset_facts = lambda: {'platform_subfamily': '6.1'}
    v.get_sysctl_facts = lambda: {'machdep.dmi.system-product': 'VMware Virtual Platform',
                                  'machdep.dmi.system-vendor': 'VMware, Inc.'}

    virtual_facts = v.get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts
    assert virtual_

# Generated at 2022-06-11 06:01:07.310806
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    openbsd_virtual = NetBSDVirtual()
    assert openbsd_virtual.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_system': '',
        'virtualization_hypervisor': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }

# Generated at 2022-06-11 06:01:08.944646
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert issubclass(NetBSDVirtualCollector, VirtualCollector)

# Generated at 2022-06-11 06:01:10.315026
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    p = NetBSDVirtual()
    assert p.platform == "NetBSD"

# Generated at 2022-06-11 06:01:12.707481
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virtual_collector = NetBSDVirtualCollector()
    assert virtual_collector.platform == 'NetBSD'
    assert virtual_collector.fact_class == NetBSDVirtual

# Generated at 2022-06-11 06:01:18.543101
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual_facts = NetBSDVirtual()
    virtual_facts_dict = netbsd_virtual_facts.get_virtual_facts()
    assert 'virtualization_type' in virtual_facts_dict
    assert 'virtualization_role' in virtual_facts_dict
    assert 'virtualization_tech_guest' in virtual_facts_dict
    assert 'virtualization_tech_host' in virtual_facts_dict
    assert 'virtualization_system' in virtual_facts_dict
    assert 'virtualization_host' in virtual_facts_dict

# Generated at 2022-06-11 06:02:24.276304
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.platform == 'NetBSD'
    assert netbsd_virtual.guest_facts == {}


# Generated at 2022-06-11 06:02:32.546353
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    sysctl_virtual_facts = {
        'machdep.hypervisor': 'XenVMMXenVMM',
        'machdep.dmi.system-product': 'Amazon EC2',
        'machdep.dmi.system-vendor': 'Amazon'
    }
    virtual = NetBSDVirtual(sysctl_virtual_facts)

# Generated at 2022-06-11 06:02:34.490857
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    facts = NetBSDVirtual().get_virtual_facts()
    assert facts['virtualization_type'] == ''
    assert facts['virtualization_role'] == ''

# Generated at 2022-06-11 06:02:35.777308
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    obj = NetBSDVirtual({})
    assert obj.platform == 'NetBSD'

# Generated at 2022-06-11 06:02:39.074141
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual()
    assert virtual_facts.virtualization_type == ''
    assert virtual_facts.virtualization_role == ''
    assert virtual_facts.virtualization_tech_guest == set()
    assert virtual_facts.virtualization_tech_host == set()

# Generated at 2022-06-11 06:02:44.062618
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Create an instance of NetBSDVirtual and get virtual facts
    nb_virtual = NetBSDVirtual()
    virtual_facts = nb_virtual.get_virtual_facts()
    # Assert that virtualization_type is set to 'xen'
    assert virtual_facts['virtualization_type'] == 'xen'
    # Assert that virtualization_role is set to 'guest'
    assert virtual_facts['virtualization_role'] == 'guest'

# Generated at 2022-06-11 06:02:44.728411
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    NetBSDVirtualCollector()

# Generated at 2022-06-11 06:02:52.772419
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Prepare test variables
    params = {
        'kernel': 'NetBSD',
        'system': 'NetBSD',
        'distribution': 'NetBSD',
        'distribution_version': '5.2',
        'virtual': 'no'
    }

    # Prepare a NetBSDVirtual object for testing and set sysctl_data
    virtual_test_obj = NetBSDVirtual(params)
    sysctl_data = {
        'machdep.dmi.system-product': 'Xen HVM domU',
        'machdep.dmi.system-vendor': '',
        'machdep.hypervisor': 'Xen',
    }
    virtual_test_obj.set_sysctl_values(sysctl_data)

    # Run method get_virtual_facts
    result = virtual_test_obj.get_

# Generated at 2022-06-11 06:02:56.473585
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    test_obj = NetBSDVirtual()
    assert test_obj._platform == "NetBSD"
    assert test_obj._fact_class == NetBSDVirtual
    assert test_obj._collector_class == NetBSDVirtualCollector
    assert test_obj.platform == "NetBSD"

# Generated at 2022-06-11 06:02:58.065990
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual()
    assert virtual_facts.platform == 'NetBSD'

# Generated at 2022-06-11 06:05:38.609979
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.platform == 'NetBSD'

# Generated at 2022-06-11 06:05:45.000801
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    module_name = "ansible.module_utils.facts.virtual.netbsd"
    mock_module = type("ansible.module_utils.facts.virtual.netbsd", (object,), {})()
    mock_module.get_bin_path = lambda arg1: "ansible"
    NetBSD_virtual = NetBSDVirtual(mock_module)
    assert NetBSD_virtual.platform == 'NetBSD'
    assert NetBSD_virtual._platform == 'NetBSD'
    assert NetBSD_virtual._fact_class == NetBSDVirtual
    assert NetBSD_virtual._sysctl_cmd == 'sysctl -n'
    assert NetBSD_virtual._compare_str == 'ansible_virtualization_type'

# Generated at 2022-06-11 06:05:47.883536
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual()
    assert virtual.get_virtual_facts() == {
        'virtual_subtype': '',
        'virtualization_role': '',
        'virtualization_type': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }

# Generated at 2022-06-11 06:05:49.811777
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    obj = NetBSDVirtualCollector()
    assert obj
    assert obj.platform == 'NetBSD'
    assert obj.fact_class == NetBSDVirtual

# Generated at 2022-06-11 06:05:51.644230
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    my_test = NetBSDVirtualCollector()
    assert my_test.platform == 'NetBSD'
    assert my_test._fact_class == NetBSDVirtual



# Generated at 2022-06-11 06:05:52.663159
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    fa = NetBSDVirtual({}, {})
    assert fa.platform == 'NetBSD'

# Generated at 2022-06-11 06:05:54.811950
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    module = AnsibleModule(argument_spec={})
    virtual = NetBSDVirtual(module)
    # Just make sure we don't crash
    assert virtual is not None

# Generated at 2022-06-11 06:06:02.784897
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual = NetBSDVirtual({})

    virtual_facts = {
        "virtualization_type": "",
        "virtualization_role": "",
        "virtualization_tech_guest": set(),
        "virtualization_tech_host": set(),
    }

    # Test: Empty host vendor
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts == {
        "virtualization_type": "",
        "virtualization_role": "",
        "virtualization_tech_guest": set(),
        "virtualization_tech_host": set(),
    }

    # Test: Hypervisor

# Generated at 2022-06-11 06:06:03.947262
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    test_virtual = NetBSDVirtual()
    assert test_virtual == None

# Generated at 2022-06-11 06:06:08.632818
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virt_facts = NetBSDVirtual({}).get_virtual_facts()
    assert 'virtualization_type' in virt_facts
    assert 'virtualization_role' in virt_facts
    assert 'virtualization_tech_host' in virt_facts
    assert 'virtualization_tech_guest' in virt_facts
    assert isinstance(virt_facts['virtualization_tech_host'], set)
    assert isinstance(virt_facts['virtualization_tech_guest'], set)