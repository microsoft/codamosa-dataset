

# Generated at 2022-06-11 05:56:58.153981
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    collecter = NetBSDVirtualCollector()
    assert collecter.platform == 'NetBSD'
    assert collecter.fact_class == NetBSDVirtual


# Generated at 2022-06-11 05:56:59.622654
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual(None)
    assert virtual.platform == 'NetBSD'

# Generated at 2022-06-11 05:57:01.400452
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd = NetBSDVirtual()
    assert netbsd != None
    assert netbsd.platform == 'NetBSD'

# Generated at 2022-06-11 05:57:03.293038
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual_facts = NetBSDVirtual()
    assert netbsd_virtual_facts.platform == "NetBSD"

# Generated at 2022-06-11 05:57:04.503789
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector  # sanity test

# Generated at 2022-06-11 05:57:08.178956
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual = NetBSDVirtual({})

    # TODO: Test with real virtualization inputs
    assert virtual.get_virtual_facts() == {
        'virtualization_role': '',
        'virtualization_type': '',
        'virtualization_tech_guest': set([]),
        'virtualization_tech_host': set([]),
    }

# Generated at 2022-06-11 05:57:10.555501
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    obj = NetBSDVirtualCollector()
    assert obj._platform == 'NetBSD'
    assert obj._fact_class is not None
    assert obj._fact_class.__name__ == 'NetBSDVirtual'



# Generated at 2022-06-11 05:57:20.448149
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    expected_return_value = {
        'virtualization_type': 'kvm',
        'virtualization_role': 'host',
        'virtualization_sysfs_id': '',
        'virtualization_sysfs_product_name': '',
        'virtualization_sysfs_product_version': '',
        'virtualization_sysfs_product_serial': '',
        'virtualization_sysfs_product_uuid': '',
        'virtualization_sysfs_product_family': '',
        'virtualization_tech_guest': {},
        'virtualization_tech_host': {'kvm'},
    }

# Generated at 2022-06-11 05:57:30.546988
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsdvirtual_obj = NetBSDVirtual({})
    netbsdvirtual_obj.sysctl_virt_vendors = {
        'QEMU/KVM': 'qemu',
        'QEMU Virtual CPU version': 'qemu',
        'VirtualBox': 'virtualbox',
    }
    netbsdvirtual_obj.sysctl_virt_products = {
        'VirtualBox': 'virtualbox',
    }

    # Test with empty sysctl dict
    empty_sysctl_dict = {}
    virtual_facts = netbsdvirtual_obj.get_virtual_facts(empty_sysctl_dict)
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert not virtual_facts['virtualization_tech_guest']
    assert not virtual

# Generated at 2022-06-11 05:57:38.582697
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    _netbsd_virtual = NetBSDVirtual()

    # "Test cases"
    # Virtualization_type is not set in dict
    _netbsd_virtual.sysctl_val_vendor = ''
    _netbsd_virtual.sysctl_val_product = ''
    _netbsd_virtual.hypervisor = ''
    _netbsd_virtual.xen_cons = ''
    _netbsd_virtual_facts = _netbsd_virtual.get_virtual_facts()

    assert _netbsd_virtual_facts['virtualization_type'] == ''
    assert _netbsd_virtual_facts['virtualization_role'] == ''
    assert _netbsd_virtual_facts['virtualization_product_name'] == ''
    assert _netbsd_virtual_facts['virtualization_product_version'] == ''


# Generated at 2022-06-11 05:57:46.799662
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    netbsd_virtual = NetBSDVirtual(netbsd_virtual_collector)

    # Check that VirtualCollector.collect() returns
    # a "dict" after it is mixed with NetBSDVirtual class.
    assert isinstance(netbsd_virtual.get_virtual_facts(), dict)

# Generated at 2022-06-11 05:57:48.123663
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    facts = NetBSDVirtual()
    assert facts._platform == 'NetBSD'

# Generated at 2022-06-11 05:57:52.740477
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual = NetBSDVirtual()
    virtual_facts = virtual.get_virtual_facts()

    assert virtual_facts['virtualization_tech_host'] == set()
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_type'] == ''

# Generated at 2022-06-11 05:57:57.059110
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    '''Unit test for method get_virtual_facts of class NetBSDVirtual'''
    virtual = NetBSDVirtual()
    virtual_facts = virtual.get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_technologies' in virtual_facts
    assert 'virtual_facts' in virtual_facts

# Generated at 2022-06-11 05:58:07.753275
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    '''Unit test for method get_virtual_facts of class NetBSDVirtual

    get_virtual_facts() should return a dict that contains the keys:
    'virtualization_type', 'virtualization_role' and 'virtualization_tech'.
    virtualization_tech is a set with the technologies used by the
    virtualization hypervisor. Eg. 'kvm', 'xen' or 'vbox'.
    '''

    module = FakeNetBSDModule()

    virtual_facts = NetBSDVirtual(module=module).get_virtual_facts()

    assert virtual_facts is not None
    assert isinstance(virtual_facts, dict)
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host'

# Generated at 2022-06-11 05:58:09.740964
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.platform == 'NetBSD'


# Generated at 2022-06-11 05:58:15.023701
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual()
    facts_platform_virtual = {
        'virtualization_role': '',
        'virtualization_type': '',
        'virtualization_technologies': [],
        'virtualization_technologies_hypervisor': [],
        'virtualization_technologies_guest': [],
    }
    assert virtual_facts.get_virtual_facts() == facts_platform_virtual

# Generated at 2022-06-11 05:58:16.471754
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    v = NetBSDVirtualCollector()
    assert v.platform == 'NetBSD'

# Generated at 2022-06-11 05:58:20.549897
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual(None)
    assert virtual.platform == 'NetBSD'
    assert virtual.virtualization_type == ''
    assert virtual.virtualization_role == ''
    assert virtual.virtualization_tech_guest == set()
    assert virtual.virtualization_tech_host == set()

# Generated at 2022-06-11 05:58:22.328103
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual(module=None)
    netbsd_virtual.get_all_facts()

# Generated at 2022-06-11 05:58:30.273140
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.platform == 'NetBSD'



# Generated at 2022-06-11 05:58:33.811691
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert issubclass(NetBSDVirtualCollector, VirtualCollector)
    assert NetBSDVirtualCollector._platform == 'NetBSD'
    assert NetBSDVirtualCollector._fact_class == NetBSDVirtual


# Generated at 2022-06-11 05:58:39.305733
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.platform == 'NetBSD'
    assert netbsd_virtual.virtualization_type == ''
    assert netbsd_virtual.virtualization_role == ''
    assert not netbsd_virtual.virtualization_tech_guest
    assert not netbsd_virtual.virtualization_tech_host
    assert not netbsd_virtual.get_virtual_facts()

# Generated at 2022-06-11 05:58:49.486152
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():

    class TestNetBSDVirtual(NetBSDVirtual):
        def __init__(self):
            self.virt_facts = {'machdep.dmi.system.product': 'VMware7,1',
                               'machdep.dmi.system.vendor': 'VMware, Inc.'}

        def _collect_platform_facts_dict(self):
            return {}

        def _collect_sysctl_facts(self, sysctl_values):
            return self.virt_facts

    nb_virtual = TestNetBSDVirtual()

    # Test multiple types returned in sysctl

# Generated at 2022-06-11 05:58:59.514028
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual_facts = NetBSDVirtual.get_virtual_facts(dict())
    assert netbsd_virtual_facts['virtualization_type'] == 'xen'
    assert netbsd_virtual_facts['virtualization_role'] == 'guest'
    assert netbsd_virtual_facts['virtualization_subtype'] == ''
    assert netbsd_virtual_facts['virtualization_system'] == ''
    assert netbsd_virtual_facts['virtualization_host_server'] == ''
    assert 'xen' in netbsd_virtual_facts['virtualization_tech_guest']
    assert len(netbsd_virtual_facts['virtualization_tech_guest']) == 1
    assert len(netbsd_virtual_facts['virtualization_tech_host']) == 0

# Generated at 2022-06-11 05:59:05.095777
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd = NetBSDVirtual(None, None, None)
    assert netbsd.platform == 'NetBSD'
    assert netbsd.virtualization_type == ''
    assert netbsd.virtualization_role == ''
    assert netbsd.virtualization_tech_host == set()
    assert netbsd.virtualization_tech_guest == set()
    assert netbsd.is_virtual == False
    assert netbsd.is_jail == False


# Generated at 2022-06-11 05:59:06.785083
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    nbsd_virt = NetBSDVirtual()
    assert nbsd_virt.platform == 'NetBSD'

# Generated at 2022-06-11 05:59:10.650844
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    # Constructor for NetBSDVirtual
    virtual_facts_class = NetBSDVirtual(module=None)

    assert virtual_facts_class is not None
    assert virtual_facts_class.platform == 'NetBSD'


# Generated at 2022-06-11 05:59:15.073549
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual = NetBSDVirtual()
    facts = netbsd_virtual.get_virtual_facts()
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts
    assert 'virtualization_tech_guest' in facts
    assert 'virtualization_tech_host' in facts

# Generated at 2022-06-11 05:59:22.982803
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # host is a hypervisor
    hypervisor_facts = {'machdep.dmi.system-vendor': 'Hewlett-Packard',
                        'machdep.hypervisor': 'VMware VMware Virtual Platform',
                        'machdep.dmi.system-product': 'ProLiant DL380 G6'}
    # host is a guest
    guest_facts = {'machdep.dmi.system-vendor': 'Hewlett-Packard',
                   'machdep.dmi.system-product': 'ProLiant DL360 G7'}

    # host is a VMware virtual machine

# Generated at 2022-06-11 05:59:37.717533
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual = NetBSDVirtual({})
    netbsd_virtual.get_virtual_facts()

# Generated at 2022-06-11 05:59:38.677263
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    NetBSDVirtualCollector()

# Generated at 2022-06-11 05:59:42.694471
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    expected_facts_dict = {
        'virtualization_role': '',
        'virtualization_type': '',
        'virtualization_tech_host': {
        },
        'virtualization_tech_guest': {
        }
    }

    facts_dict = NetBSDVirtual().get_virtual_facts()
    assert facts_dict == expected_facts_dict


# Generated at 2022-06-11 05:59:43.636044
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    NetBSDVirtual()



# Generated at 2022-06-11 05:59:45.493234
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.platform == 'NetBSD'

# Generated at 2022-06-11 05:59:48.440328
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virt = NetBSDVirtual({})
    assert virt.platform == 'NetBSD'
    assert virt._detect_virt_what() == '/usr/pkg/sbin/virt-what'

# Generated at 2022-06-11 05:59:51.445414
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_obj = NetBSDVirtualCollector()
    assert netbsd_virtual_obj._fact_class == NetBSDVirtual
    assert netbsd_virtual_obj._platform == 'NetBSD'

# Generated at 2022-06-11 05:59:54.798761
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facter = NetBSDVirtualCollector().facter()

    assert isinstance(virtual_facter, dict)
    assert 'virtualization_type' in virtual_facter
    assert 'virtualization_role' in virtual_facter

# Generated at 2022-06-11 05:59:58.418887
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert netbsd_virtual_collector.platform == 'NetBSD'
    assert netbsd_virtual_collector._fact_class == NetBSDVirtual
    assert netbsd_virtual_collector._platform == 'NetBSD'

# Generated at 2022-06-11 06:00:07.923282
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    testing = NetBSDVirtual()
    testing.sysctl_machine_hw_model = 'HP ProLiant MicroServer Gen8'
    testing.sysctl_machdep_dmi_system_vendor = 'HP'
    testing.sysctl_machdep_hypervisor = ''
    testing.set_initial_facts({})
    facts = testing.get_virtual_facts()
    assert facts['virtualization_type'] == 'hvm'
    assert facts['virtualization_role'] == 'guest'
    assert 'detect_virt_vendor' in facts['virtualization_subsystem']
    assert 'detect_virt_product' in facts['virtualization_subsystem']
    assert facts['virtualization_subsystem'] == 'detect_virt_vendor,detect_virt_product'

# Generated at 2022-06-11 06:00:35.779452
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = {}
    host_tech = set()
    guest_tech = set()

# Generated at 2022-06-11 06:00:37.436033
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    sys_name = 'NetBSD'
    NetBSDVirtual(system_info=dict(system=sys_name))

# Generated at 2022-06-11 06:00:38.815216
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual()
    assert virtual.platform == 'NetBSD'

# Generated at 2022-06-11 06:00:39.349670
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    NetBSDVirtual()

# Generated at 2022-06-11 06:00:40.822186
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual(None, "", "", "")
    assert hasattr(virtual, 'platform')



# Generated at 2022-06-11 06:00:45.490671
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd = NetBSDVirtual()
    assert netbsd.platform == 'NetBSD'
    assert netbsd.guest_detection_kernel_modules == []
    assert netbsd.virtualization_type is None
    assert netbsd._sysctl_virtualization_sysnames == {}
    assert netbsd._sysctl_virtualization_vendors == {}

# Generated at 2022-06-11 06:00:47.025352
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual()
    assert virtual.platform == 'NetBSD'


# Generated at 2022-06-11 06:00:54.703518
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    data = {
        'machdep.dmi.system-product': '',
        'machdep.hypervisor': '',
        'machdep.dmi.system-vendor': '',
    }
    results = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_product': '',
        'virtualization_product_version': '',
        'virtualization_product_serial': '',
        'virtualization_product_uuid': '',
        'virtualization_product_family': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }
    instance = NetBSDVirtual({}, data=data)
    virtual_facts = instance.get_virtual_facts()
    assert virtual_facts == results

# Generated at 2022-06-11 06:01:02.251793
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    from unittest import mock

    netbsd_virtual = NetBSDVirtual()

    host_tech = set()
    guest_tech = set()
    virtual_facts = netbsd_virtual.get_virtual_facts()

    # Set empty values as default
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''

    # Test without machdep.dmi.system-product

# Generated at 2022-06-11 06:01:04.308883
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.platform == 'NetBSD'


# Generated at 2022-06-11 06:02:06.049202
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual()
    assert virtual
    assert virtual._platform == 'NetBSD'


# Generated at 2022-06-11 06:02:07.858140
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    collect_v = NetBSDVirtual(None)
    assert collect_v._platform == 'NetBSD'

# Generated at 2022-06-11 06:02:09.115242
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.platform == 'NetBSD'

# Generated at 2022-06-11 06:02:12.278254
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector_obj = NetBSDVirtualCollector()
    assert netbsd_virtual_collector_obj._platform == "NetBSD"
    assert netbsd_virtual_collector_obj._fact_class == NetBSDVirtual


# Generated at 2022-06-11 06:02:13.986860
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    # Make sure we get a instance
    assert isinstance(NetBSDVirtual(), NetBSDVirtual)


# Generated at 2022-06-11 06:02:15.601710
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual()
    assert virtual
    assert virtual._platform == "NetBSD"


# Generated at 2022-06-11 06:02:17.269450
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert netbsd_virtual_collector._platform == 'NetBSD'

# Generated at 2022-06-11 06:02:25.457656
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():

    test_NetBSDVirtual = NetBSDVirtual({'ansible_facts': dict()})

    test_facts = dict()
    test_facts['virtualization_type'] = ''
    test_facts['virtualization_role'] = ''
    test_facts['virtualization_tech_guest'] = ''
    test_facts['virtualization_tech_host'] = ''

    test_mock_facts = dict()
    test_mock_facts['machdep.dmi.system-product'] = 'VirtualBox'
    test_mock_facts['machdep.dmi.system-vendor'] = 'innotek GmbH'
    test_mock_facts['machdep.hypervisor'] = 'qemu'

    test_NetBSDVirtual._module.params = dict()

# Generated at 2022-06-11 06:02:28.781283
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Test NetBSDVirtual.get_virtual_facts on NetBSD
    facts = NetBSDVirtual().get_virtual_facts()
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts
    assert 'virtualization_tech_guest' in facts
    assert 'virtualization_tech_host' in facts

# Generated at 2022-06-11 06:02:32.779880
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual({}).get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts


# Generated at 2022-06-11 06:05:03.498113
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    NetBSDVirtual()


# Generated at 2022-06-11 06:05:08.903859
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Initialize empty dict
    test_dict = {}
    # Test dict with values that are set as default
    test_dict['virtualization_type'] = ''
    test_dict['virtualization_role'] = ''
    # Create instance of NetBSDVirtual
    test_class_instance = NetBSDVirtual()
    # Get facts from method
    test_dict = test_class_instance.get_virtual_facts()
    # Check if the dict is empty
    assert test_dict
    # Check if the dict has the correct values
    assert test_dict['virtualization_type'] == ''
    assert test_dict['virtualization_role'] == ''

# Generated at 2022-06-11 06:05:12.574712
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Build a test object and call get_virtual_facts
    test = NetBSDVirtual({'ansible_sysctl.machdep.hypervisor': 'XenVMMXenVMM'})
    assert test.get_virtual_facts() == {
        'virtualization_role': 'guest',
        'virtualization_type': 'xen',
        'virtualization_tech_guest': {'xen'},
        'virtualization_tech_host': set()
    }

# Generated at 2022-06-11 06:05:15.495616
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_role'] == 'guest'

# Generated at 2022-06-11 06:05:19.190464
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual()
    assert virtual_facts.get_virtual_facts() == {
        'virtualization_role': '',
        'virtualization_type': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
        'virtualization_product_name': '',
        'virtualization_product_version': '',
        'virtualization_product_serial': '',
    }

# Generated at 2022-06-11 06:05:23.595935
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    collector = NetBSDVirtual()
    facts = collector.get_virtual_facts()
    assert facts['virtualization_type'] == ''
    assert facts['virtualization_role'] == ''
    assert facts['virtualization_product_name'] == 'VirtualBox'
    assert facts['virtualization_product_version'] == '1.2'
    assert facts['virtualization_tech_host'] == set(['kvm'])
    assert facts['virtualization_tech_guest'] == set(['kvm'])

# Generated at 2022-06-11 06:05:24.825512
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    collector = NetBSDVirtualCollector()
    assert collector.platform == 'NetBSD'


# Generated at 2022-06-11 06:05:26.037672
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    result = NetBSDVirtual(None)

    assert result.platform == 'NetBSD'


# Generated at 2022-06-11 06:05:27.528152
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector._platform == 'NetBSD'
    assert NetBSDVirtualCollector._fact_class == NetBSDVirtual


# Generated at 2022-06-11 06:05:30.950277
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.platform == 'NetBSD'
    assert netbsd_virtual.virtualization_type == ''
    assert netbsd_virtual.virtualization_role == ''
    assert netbsd_virtual.virtualization_tech_guest == set()
    assert netbsd_virtual.virtualization_tech_host == set()