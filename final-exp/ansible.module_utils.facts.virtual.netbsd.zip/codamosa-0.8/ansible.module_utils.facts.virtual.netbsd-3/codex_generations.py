

# Generated at 2022-06-11 05:57:05.498614
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    # pylint: disable=unused-argument,protected-access
    """ Unit test for constructor of class NetBSDVirtual """
    def __init__(self):
        self.platform = "TestPlatformString"
        self.virtual_facts = {
            "virtualization_type": "TestVirtualizationTypeString",
            "virtualization_role": "TestVirtualizationRoleString"
        }
        return self
    test_netbsd_virtual = NetBSDVirtual()
    assert test_netbsd_virtual._platform == "TestPlatformString"
    assert len(test_netbsd_virtual) == 2
    assert "virtualization_type" in test_netbsd_virtual.keys()
    assert "virtualization_role" in test_netbsd_virtual.keys()

# Generated at 2022-06-11 05:57:07.248437
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.platform == 'NetBSD'


# Generated at 2022-06-11 05:57:09.556409
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual = NetBSDVirtualCollector()
    assert netbsd_virtual.platform == 'NetBSD'
    assert netbsd_virtual._fact_class == NetBSDVirtual


# Generated at 2022-06-11 05:57:10.672457
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual()
    assert virtual.platform == 'NetBSD'

# Generated at 2022-06-11 05:57:12.450569
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual()
    assert virtual_facts.get_virtual_facts()['virtualization_type'] == ''

# Generated at 2022-06-11 05:57:22.212517
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual()

    # Set some fake sysctl_get calls for virtualization
    virtual_facts.sysctl_get = MockSysctl(
        machdep_dmi_system_vendor="QEMU",
        machdep_dmi_system_product="Standard PC (i440FX + PIIX, 1996)",
        machdep_hypervisor="QEMU",
        machdep_dmi_baseboard_product="Standard PC (i440FX + PIIX, 1996)",
        machdep_dmi_baseboard_vendor="QEMU",
    )
    # Set some fake os_path accesses
    if hasattr(Virtual, "os_path"):
        virtual_facts.os_path = MockOsPath()

    # Call the get_virtual_facts method

# Generated at 2022-06-11 05:57:32.299984
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    '''Unit test for method get_virtual_facts of class NetBSDVirtual'''
    def make_fake_sysctl_output(lines):
        def fake_sysctl(arg):
            return {'stdout': lines, 'rc': 0}
        return fake_sysctl

    def make_fake_file(content):
        def fake_file(filename):
            if content.get(filename):
                return content[filename]
            raise IOError()
        return fake_file


# Generated at 2022-06-11 05:57:34.238692
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual


# Generated at 2022-06-11 05:57:35.428538
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual({}, None)
    assert virtual.platform == 'NetBSD'

# Generated at 2022-06-11 05:57:38.429470
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_fact_collector = NetBSDVirtualCollector()
    assert netbsd_virtual_fact_collector._fact_class == NetBSDVirtual
    assert netbsd_virtual_fact_collector._platform == 'NetBSD'

# Generated at 2022-06-11 05:57:46.656135
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virt_facts = NetBSDVirtual()
    facts = virt_facts.get_virtual_facts()

    assert facts['virtualization_type'] == ''
    assert facts['virtualization_role'] == 'guest'
    assert facts['virtualization_tech_guest'] == set([])
    assert facts['virtualization_tech_host'] == set([])

# Generated at 2022-06-11 05:57:55.923516
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # pylint: disable=protected-access
    # unittest import is required to create a object of this class.
    from ansible.module_utils.facts.virtual.netbsd import NetBSDVirtual
    from ansible.module_utils.facts.virtual.sysctl import get_sysctl_info
    # pylint: enable=protected-access
    ans_module = MockAnsibleModule()
    sysctl_info = get_sysctl_info(ans_module)
    netbsd_virtual_obj = NetBSDVirtual(ans_module, sysctl_info)
    # To set the virtualization_type and virtualization_role
    sysctl_info['machdep.dmi.system-product'] = 'OpenStack Nova'

# Generated at 2022-06-11 05:58:00.086503
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual(None)
    assert virtual_facts.platform == 'NetBSD'

if __name__ == '__main__':
    pytest.main([__file__])

# Generated at 2022-06-11 05:58:02.927684
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual = NetBSDVirtualCollector()
    assert netbsd_virtual._platform == 'NetBSD'
    assert netbsd_virtual._fact_class == NetBSDVirtual

# Generated at 2022-06-11 05:58:05.183359
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():

    # Do not use the constructor directly, it could be removed without warning
    # in a future release of Ansible.
    NetBSDVirtual()

# Generated at 2022-06-11 05:58:08.004644
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    # Test for successful instantiation
    NetBSDVirtualCollector(None)
    # Test for instantiation of class with object as argument
    assert NetBSDVirtualCollector(object) is False


# Generated at 2022-06-11 05:58:10.443792
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    '''Test function for constructor of class NetBSDVirtual'''
    netbsd_virtual = NetBSDVirtual()

    assert netbsd_virtual.platform == 'NetBSD'

# Generated at 2022-06-11 05:58:11.583542
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    NetBSDVirtualCollector()

# Generated at 2022-06-11 05:58:21.458328
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    mock = {
        'machdep.dmi.system-product': 'KVM',
        'machdep.dmi.system-vendor': 'QEMU',
        'machdep.hypervisor': 'NetBSD'
    }
    my_v = NetBSDVirtual({'mock_sysctl': mock})
    virtual_facts = my_v.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'kvm'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_product'] == 'qemu'
    assert 'xen' not in virtual_facts['virtualization_tech_guest']
    assert 'xen' not in virtual_facts['virtualization_tech_host']

# Generated at 2022-06-11 05:58:30.739638
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    # Test an osversion value that doesn't exist
    facts = dict()
    with open('../test/test_data/test-osversion') as f:
        for line in f:
            line = line.split('=')
            facts[line[0]] = line[1]
    virtual = NetBSDVirtual(facts)
    assert virtual.platform == 'NetBSD'
    assert virtual.osversion == '6.99.55'
    assert virtual.oslevel == ''
    assert virtual.hostname == 'testhost'
    assert virtual.machine == 'amd64'
    assert virtual.arch == 'x86_64'
    assert virtual.usr_groups == ['wheel']
    assert virtual.selinux == {}

    # Test an osversion value that exists
    facts = dict()

# Generated at 2022-06-11 05:58:38.227144
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    NetBSDVirtual()


# Generated at 2022-06-11 05:58:39.223057
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.platform == 'NetBSD'

# Generated at 2022-06-11 05:58:40.253298
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    NetBSDVirtualCollector()

# Generated at 2022-06-11 05:58:41.310276
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual()
    assert virtual_facts.platform == 'NetBSD'

# Generated at 2022-06-11 05:58:42.331842
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector is not None

# Generated at 2022-06-11 05:58:51.437857
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.sysctl import VirtualSysctlDetectionMixin
    VirtualSysctlDetectionMixin._get_sysctl_value = get_sysctl_value

    virtual_facts = NetBSDVirtual(None).get_virtual_facts()
    virtual_facts_expected = {
        'virtualization_role': 'guest',
        'virtualization_type': 'xen',
        'virtualization_tech_guest': {'xen'},
        'virtualization_tech_host': {'xen'},
    }

    assert virtual_facts == virtual_facts_expected


# Stub Module for the method _get_sysctl_value of the class VirtualSysctlDetectionMixin.
# The method _get_sysctl_value tests for the presence of a sysctl key and returns its value if present.


# Generated at 2022-06-11 05:58:53.631904
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual(None)
    assert virtual.platform == "NetBSD"
    assert virtual.sysctl_path == ''


# Generated at 2022-06-11 05:58:55.940425
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector._platform == 'NetBSD'
    assert NetBSDVirtualCollector._fact_class.platform == 'NetBSD'

# Generated at 2022-06-11 05:58:58.435786
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.platform == 'NetBSD'
    assert netbsd_virtual.virtual == 'NetBSD'

# Generated at 2022-06-11 05:58:59.853390
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.platform == 'NetBSD'

# Generated at 2022-06-11 05:59:16.848973
# Unit test for method get_virtual_facts of class NetBSDVirtual

# Generated at 2022-06-11 05:59:20.686938
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual({})
    assert virtual.platform == "NetBSD"
    assert virtual._platform == 'NetBSD'
    assert virtual.get_virtual_facts() == {'virtualization_type': '', 'virtualization_role': '', 'virtualization_tech_host': set(), 'virtualization_tech_guest': set()}

# Generated at 2022-06-11 05:59:30.294714
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    import os
    import tempfile
    import shutil

    machdep_dmi_vendor = """[
        { "machdep.dmi.vendor": "Manufacturer" }
    ]"""

    machdep_dmi_product = """[
        { "machdep.dmi.product": "Product" }
    ]"""

    machdep_dmi_virt_info = """[
        { "machdep.dmi.system-vendor": "Manufacturer" },
        { "machdep.dmi.product": "Product" }
    ]"""

    machdep_dmi_hypervisor = """[
        { "machdep.hypervisor": "None" }
    ]"""


# Generated at 2022-06-11 05:59:32.040582
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual()

    assert virtual.platform == 'NetBSD'

# Run all virtual tests for NetBSD

# Generated at 2022-06-11 05:59:35.750000
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd = NetBSDVirtual()
    assert netbsd.platform == 'NetBSD'
    assert netbsd._platform == 'NetBSD'
    assert netbsd.get_virtual_facts() == {}


# Generated at 2022-06-11 05:59:38.678375
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual({})
    assert virtual.platform == 'NetBSD'
    assert virtual.virtualization_tech_host is not None
    assert virtual.virtualization_tech_guest is not None

# Generated at 2022-06-11 05:59:41.279357
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_facts = NetBSDVirtual()
    platform = netbsd_facts.platform
    virtual = netbsd_facts.virtual
    assert platform == 'NetBSD' and virtual == 'Xen domU'

# Generated at 2022-06-11 05:59:43.121068
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd = NetBSDVirtual({},{},{},{})
    assert netbsd.platform == 'NetBSD'

# Generated at 2022-06-11 05:59:44.094988
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    NetBSDVirtualCollector()

# Generated at 2022-06-11 05:59:45.498208
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual(module=None)
    assert virtual.platform == 'NetBSD'

# Generated at 2022-06-11 06:00:04.784809
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    obj = NetBSDVirtual()
    assert obj.virtual_facts['virtualization_type'] == ''
    assert obj.virtual_facts['virtualization_role'] == ''
    assert obj.virtual_facts['virtualization_systems'] == []
    assert obj.virtual_facts['virtualization_technologies'] == []
    assert obj.virtual_facts['virtualization_technologies_guest'] == []
    assert obj.virtual_facts['virtualization_technologies_host'] == []
    assert obj.virtual_facts['virtualization_virtual_swap'] == False

# Generated at 2022-06-11 06:00:09.092468
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    # Create an instance of NetBSDVirtual
    netBSD_virtual_instance = NetBSDVirtual()
    # Assert that the class of the newly created instance is `NetBSDVirtual`
    assert netBSD_virtual_instance.__class__.__name__ == 'NetBSDVirtual'

# Generated at 2022-06-11 06:00:11.400821
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd = NetBSDVirtualCollector()
    assert netbsd._platform == "NetBSD"
    assert netbsd._fact_class.platform == "NetBSD"


# Generated at 2022-06-11 06:00:15.134014
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsdvirtual = NetBSDVirtual()

    assert netbsdvirtual.platform == "NetBSD"
    assert netbsdvirtual.get_virtual_facts() == {
        'virtualization_role': '',
        'virtualization_type': '',
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': set()
    }


# Generated at 2022-06-11 06:00:17.009304
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual._platform == 'NetBSD'

# Generated at 2022-06-11 06:00:19.859733
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netBSD_virtual = NetBSDVirtual()
    assert netBSD_virtual._platform == 'NetBSD'
    assert netBSD_virtual._fact_class == NetBSDVirtual


# Generated at 2022-06-11 06:00:29.018236
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    test_virtual_facts = dict()
    test_virtual_facts['virtualization_type'] = ''
    test_virtual_facts['virtualization_role'] = ''
    test_virtual_facts['virtualization_tech_guest'] = set()
    test_virtual_facts['virtualization_tech_host'] = set()

    netbsd_virtual = NetBSDVirtual(module=None)
    netbsd_virtual._get_sysctl_info = mock_get_sysctl_info
    netbsd_virtual._get_sysctl_info_from_file = mock_get_sysctl_info_from_file


    test_virtual_facts = netbsd_virtual.get_virtual_facts()

    assert test_virtual_facts['virtualization_type'] == 'kvm'

# Generated at 2022-06-11 06:00:31.842816
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual._platform == "NetBSD"
    assert netbsd_virtual._fact_class == NetBSDVirtual


# Generated at 2022-06-11 06:00:34.328964
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virtual = NetBSDVirtual()
    n = virtual.get_platform()
    print(n)
    assert n == 'NetBSD'

# Generated at 2022-06-11 06:00:36.606643
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    collector = NetBSDVirtualCollector('fakestring')
    fact_class = collector.get_fact_class()

    assert fact_class._platform == 'NetBSD'

# Generated at 2022-06-11 06:01:04.891154
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.platform == 'NetBSD'

# Generated at 2022-06-11 06:01:06.505814
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual._platform == 'NetBSD'

# Generated at 2022-06-11 06:01:08.707674
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.platform == 'NetBSD'


# Generated at 2022-06-11 06:01:11.202336
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virtual_collector = NetBSDVirtualCollector()
    assert virtual_collector.platform == 'NetBSD'
    assert virtual_collector._fact_class == NetBSDVirtual

# Generated at 2022-06-11 06:01:19.741541
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    class TestNetBSDVirtual(NetBSDVirtual):
        def _get_file_content(self, path):
            return self.content[path]

    # Return values of methods
    vmware = {
        '/dev/xencons': '',
        '/proc/version':
        "Linux version 4.1.25-1-pve (root@pve) (gcc version 4.8.4 (Debian 4.8.4-1) ) #1 SMP Wed Jan 27 12:11:41 CET 2016 \n"
    }

# Generated at 2022-06-11 06:01:20.937175
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    vc = NetBSDVirtualCollector()
    assert isinstance(vc, VirtualCollector)

# Generated at 2022-06-11 06:01:22.181299
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual()
    assert virtual_facts.virtualization_type == ''

# Generated at 2022-06-11 06:01:24.481774
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual('/dev/sda1')
    assert netbsd_virtual.platform == 'NetBSD'

# Generated at 2022-06-11 06:01:25.943544
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    factory = NetBSDVirtual()

    assert factory.platform == 'NetBSD'

# Generated at 2022-06-11 06:01:30.776712
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual()

    assert virtual_facts.platform == 'NetBSD'
    assert virtual_facts.guest_virtualized == virtual_facts.VIRTUALIZATION_TECH_GUEST
    assert virtual_facts.host_virtualized == virtual_facts.VIRTUALIZATION_TECH_HOST

# Generated at 2022-06-11 06:02:41.985050
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    NetBSDVirtualCollector()

# Generated at 2022-06-11 06:02:43.499432
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    facts = NetBSDVirtual()
    assert facts.platform == 'NetBSD'


# Generated at 2022-06-11 06:02:44.962065
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual({})
    assert netbsd_virtual.platform == "NetBSD"

# Generated at 2022-06-11 06:02:46.118514
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector._platform == 'NetBSD'


# Generated at 2022-06-11 06:02:47.924936
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    constructor = NetBSDVirtualCollector()
    assert constructor._platform == 'NetBSD'
    assert constructor._fact_class == NetBSDVirtual

# Generated at 2022-06-11 06:02:49.023152
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual()

    assert virtual_facts.platform == 'NetBSD'

# Generated at 2022-06-11 06:02:50.153295
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    assert NetBSDVirtualCollector(None, None)._platform == 'NetBSD'

# Generated at 2022-06-11 06:02:52.037170
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual_facts = NetBSDVirtual({}, {}, {})
    assert netbsd_virtual_facts.get_virtual_facts() == {}

# Generated at 2022-06-11 06:02:58.469245
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual = NetBSDVirtual(module=None)
    virtual_facts = virtual.get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts
    assert virtual_facts['virtualization_type'] == 'netbsd'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtu

# Generated at 2022-06-11 06:03:00.506841
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    c = NetBSDVirtualCollector()
    assert c.platform == 'NetBSD'
    assert c._fact_class == NetBSDVirtual

# Generated at 2022-06-11 06:05:47.667362
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd = NetBSDVirtual()
    assert netbsd.platform == 'NetBSD'
    assert hasattr(netbsd, 'get_virtual_facts')
    assert hasattr(netbsd, 'detect_virt_product')
    assert hasattr(netbsd, 'detect_virt_vendor')

# Generated at 2022-06-11 06:05:50.656149
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual._platform == 'NetBSD'
    assert netbsd_virtual._fact_class == NetBSDVirtual
    assert isinstance(netbsd_virtual, Virtual)
    assert netbsd_virtual._file_contents('/proc/meminfo') == {}

# Generated at 2022-06-11 06:05:52.220175
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual([])
    virtual_facts.collect()
    assert virtual_facts.get_virtual_facts() is not None

# Generated at 2022-06-11 06:05:54.334411
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virtual_collector = NetBSDVirtualCollector()
    assert virtual_collector._fact_class == NetBSDVirtual
    assert virtual_collector._platform == "NetBSD"

# Generated at 2022-06-11 06:05:55.826099
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.platform == 'NetBSD'

# Generated at 2022-06-11 06:05:57.060994
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual()
    assert virtual_facts.platform == 'NetBSD'

# Generated at 2022-06-11 06:05:58.877259
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.platform == 'NetBSD'


# Generated at 2022-06-11 06:06:01.078411
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    v = NetBSDVirtual()
    assert NetBSDVirtual._platform == 'NetBSD'
    assert NetBSDVirtual.platform == 'NetBSD'
    assert v.platform == 'NetBSD'


# Generated at 2022-06-11 06:06:04.103815
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    import doctest
    from ansible.module_utils.facts.virtual.netbsd import NetBSDVirtual
    failed, total = doctest.testmod(NetBSDVirtual)
    if failed == 0:
        print('PASSED ALL {0} TESTS'.format(total))

# Generated at 2022-06-11 06:06:05.198559
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    f = NetBSDVirtualCollector({})
    assert f.get_virtual_facts()