

# Generated at 2022-06-11 05:56:56.049106
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-11 05:57:05.539882
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():

    virtual_facts = NetBSDVirtual().get_virtual_facts()
    expected_virtual_facts = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_system': '',
        'virtualization_role': '',
        'virtualization_host_type': '',
        'virtualization_host_role': '',
        'virtualization_host_system': '',
        'virtualization_guest_type': '',
        'virtualization_guest_role': '',
        'virtualization_guest_system': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }

    assert virtual_facts == expected_virtual_facts

# Generated at 2022-06-11 05:57:07.255176
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual._platform == 'NetBSD'


# Generated at 2022-06-11 05:57:10.208295
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    mock_module = type('module', (object,), {'params': {'gather_subset': [], 'filter': ''}})

    virtual = NetBSDVirtual(mock_module)

    assert virtual is not None
    assert virtual._platform == 'NetBSD'

# Generated at 2022-06-11 05:57:16.531081
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Setup
    fact_class = NetBSDVirtual()
    facts_dict = dict()
    facts_dict['virtualization_type'] = ''
    facts_dict['virtualization_role'] = ''
    facts_dict['virtualization_tech_guest'] = set()

    # Exercise code
    facts_dict = fact_class.get_virtual_facts()

    # Verify results
    assert len(facts_dict) > 0
    assert facts_dict['virtualization_tech_guest'] == set()

# Generated at 2022-06-11 05:57:19.791024
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    klass = NetBSDVirtual()

# Generated at 2022-06-11 05:57:22.629639
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    # test for function "get_instance"
    collector = NetBSDVirtualCollector.get_instance()
    assert collector is not None
    # test for constructor
    collector = NetBSDVirtualCollector()
    assert collector is not None

# Generated at 2022-06-11 05:57:29.622021
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    test_virtual = NetBSDVirtual({})
    test_facts = test_virtual.get_virtual_facts()
    assert 'virtualization_role' in test_facts, 'Test virtualization_role key missing'
    assert 'virtualization_type' in test_facts, 'Test virtualization_type key missing'
    assert 'virtualization_tech_guest' in test_facts, 'Test virtualization_tech_guest key missing'
    assert 'virtualization_tech_host' in test_facts, 'Test virtualization_tech_host key missing'

# Generated at 2022-06-11 05:57:38.146212
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    def get_sysctl_mock(module, option):
        if option == 'machdep.dmi.system-product':
            return 'VMware Virtual Platform'
        elif option == 'machdep.dmi.system-vendor':
            return 'VMware, Inc.'
        elif option == 'machdep.hypervisor':
            return 'None'
        else:
            return ''

    virt_obj = NetBSDVirtual()
    virt_obj.get_sysctl = get_sysctl_mock
    virtual_facts = virt_obj.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == 'vmware'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert 'vmware' in virtual_facts['virtualization_tech_guest']

# Generated at 2022-06-11 05:57:40.085042
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virtual_collector = NetBSDVirtualCollector()
    assert virtual_collector.platform == 'NetBSD'

# Generated at 2022-06-11 05:57:45.339198
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual_facts = NetBSDVirtual(module=None)
    assert netbsd_virtual_facts is not None

# Generated at 2022-06-11 05:57:48.903200
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector.__name__ == 'NetBSDVirtualCollector'
    assert NetBSDVirtualCollector._platform == 'NetBSD'
    assert NetBSDVirtualCollector._fact_class == NetBSDVirtual


# Generated at 2022-06-11 05:57:49.540041
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    NetBSDVirtual()

# Generated at 2022-06-11 05:57:51.633483
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual_facts = NetBSDVirtual()
    assert netbsd_virtual_facts.data['virtualization_type'] == ''

# Generated at 2022-06-11 05:57:53.223752
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector._platform == 'NetBSD'
    assert NetBSDVirtualCollector._fact_class == NetBSDVirtual

# Generated at 2022-06-11 05:57:56.644422
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    test_virtual_facts = NetBSDVirtual().get_virtual_facts()

    assert 'virtualization_type' in test_virtual_facts
    assert 'virtualization_role' in test_virtual_facts
    assert 'virtualization_technologies' in test_virtual_facts
    assert 'virtualization_systems' in test_virtual_facts

# Generated at 2022-06-11 05:58:04.841235
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual({"sysctl": {"machdep.dmi.system-product": "Dell PowerEdge R610",
                                                "machdep.dmi.system-vendor": "Dell Inc.",
                                                "machdep.hypervisor": "Xen"}})
    netbsd_virtual_facts = netbsd_virtual.get_virtual_facts()
    assert netbsd_virtual_facts['virtualization_type'] == 'xen'
    assert netbsd_virtual_facts['virtualization_role'] == 'guest'

# Generated at 2022-06-11 05:58:07.752525
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtualCollector()
    assert virtual.platform == 'NetBSD'
    assert virtual._fact_class.platform == 'NetBSD'
    assert virtual._platform == 'NetBSD'



# Generated at 2022-06-11 05:58:12.433573
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual = NetBSDVirtual()
    virtual_facts = virtual.get_virtual_facts()
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-11 05:58:15.391803
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert netbsd_virtual_collector._platform == 'NetBSD'
    assert netbsd_virtual_collector._fact_class == NetBSDVirtual

# Generated at 2022-06-11 05:58:22.958983
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_system'] == ''
    assert virtual_facts['virtualization_hypervisor'] == ''


# Generated at 2022-06-11 05:58:31.022445
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():

    test_subclasses = [
        NetBSDVirtual("machdep.hypervisor.vendor=Amazon EC2\nmachdep.hypervisor.version=4.4.35-58.37.amzn1.x86_64\nmachdep.hypervisor.release=2017-03-03\n")
    ]

    for test_subclass in test_subclasses:
        facts = test_subclass.get_virtual_facts()

        assert facts == {
            'virtualization_role': 'guest',
            'virtualization_type': 'xen',
            'virtualization_tech_host': set(['Xen']),
            'virtualization_tech_guest': set(['Xen']),
        }

# Generated at 2022-06-11 05:58:41.129339
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch
    from ansible_collections.ansible.community.tests.unit.modules.utils import AnsibleExitJson, AnsibleFailJson

    with patch("ansible_collections.ansible.community.plugins.module_utils.facts.virtual.netbsd.NetBSDVirtual.collect") as mock_virtual_collector_collect:
        mock_virtual_collector_collect.return_value = {}
        with patch.object(AnsibleExitJson, 'exit_json') as mock_exit_json:
            NetBSDVirtual().populate()

# Generated at 2022-06-11 05:58:50.785199
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():

    # Output of sysctl hw.model
    hw_model_output = 'Netra T4240'
    # Output of sysctl machdep.dmi.system-vendor
    machdep_dmi_system_vendor_output = 'Sun Microsystems'
    # Output of sysctl machdep.dmi.system-product
    machdep_dmi_system_product_output = 'T4240'

    # Create instance of NetBSDVirtual class
    netbsd_virtual_instance = NetBSDVirtual(hw_model_output)

    # Set return value of function get_sysctl_output
    netbsd_virtual_instance.get_sysctl_output = lambda x: (0, '', '') \
        if x == 'machdep.dmi.system-vendor' else hw_model_output

    #

# Generated at 2022-06-11 05:58:52.686735
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual({})
    assert virtual_facts is not None


# Generated at 2022-06-11 05:58:53.683013
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    obj = NetBSDVirtualCollector()
    assert obj

# Generated at 2022-06-11 05:58:56.413102
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    vc = NetBSDVirtualCollector()
    assert vc.__class__._fact_class == NetBSDVirtual
    assert vc.__class__._platform == 'NetBSD'

# Generated at 2022-06-11 05:58:58.525291
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    nv = NetBSDVirtualCollector()
    if nv.platform == 'NetBSD':
        assert True
    else:
        assert False

# Generated at 2022-06-11 05:59:02.484110
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual = NetBSDVirtual()
    virtual_facts = netbsd_virtual.get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-11 05:59:05.296145
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.platform == 'NetBSD'
    assert netbsd_virtual.get_virtual_facts() == {}


# Generated at 2022-06-11 05:59:19.099376
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    facter = {
        'machdep.dmi.system-product': 'ProLiant BL460c Gen8',
        'machdep.dmi.system-vendor': 'HP'
    }

    expected = {
        'virtualization_type': 'kvm',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['hvm', 'kvm']),
        'virtualization_tech_host': set(['kvm'])
    }

    facts = NetBSDVirtual(facter).get_virtual_facts()
    assert facts == expected



# Generated at 2022-06-11 05:59:28.227702
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Empty test
    test_data = {}
    virtual_obj = NetBSDVirtual({}, test_data)
    test_virtual_facts = virtual_obj.get_virtual_facts()
    assert test_virtual_facts == {'virtualization_type': '',
                                  'virtualization_role': '',
                                  'virtualization_tech_guest': set(),
                                  'virtualization_tech_host': set()}

    # Parse some virtualization data
    virtual_obj = NetBSDVirtual({}, {'kern.product.name': 'VMware Virtual Platform'})
    test_vmware_data = virtual_obj.get_virtual_facts()

# Generated at 2022-06-11 05:59:33.534672
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'paravirtual'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_guest'] == set(['paravirtualized'])
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-11 05:59:35.743142
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    virtual = NetBSDVirtualCollector()

    assert virtual._platform == 'NetBSD'
    assert virtual._fact_class._platform == 'NetBSD'

# Generated at 2022-06-11 05:59:38.295975
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd = NetBSDVirtual({})
    assert netbsd.platform == 'NetBSD'
    assert netbsd.get_virtual_facts() == {}


# Generated at 2022-06-11 05:59:43.739379
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual(None)
    assert virtual.platform == 'NetBSD'
    assert virtual.guest_tech() == set()
    assert virtual.host_tech() == set()
    assert virtual.guest_tech('xen') == set(['xen'])
    assert virtual.guest_tech('kvm') == set()
    assert virtual.host_tech('kvm') == set()
    assert virtual.host_tech('xen') == set()
    assert virtual.guest_tech('kvm') == set()



# Generated at 2022-06-11 05:59:51.067248
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    test_file_path = os.path.dirname(__file__) + '/../unit_tests/virtual/'
    test_files = os.listdir(test_file_path)
    for test_file in test_files:
        try:
            virtual_object = NetBSDVirtual(test_file_path + test_file)
            virtual_facts = virtual_object.get_virtual_facts()
            assert virtual_facts['virtualization_type'] != ''
            assert virtual_facts['virtualization_role'] != ''
        except:
            assert False

# Generated at 2022-06-11 05:59:55.525811
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsdvirtual = NetBSDVirtual()
    virtual_facts = netbsdvirtual.get_virtual_facts()

    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-11 05:59:56.452995
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    NetBSDVirtualCollector()

# Generated at 2022-06-11 05:59:57.740927
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    """Test NetBSD constructor"""
    virtual = NetBSDVirtual()

# Generated at 2022-06-11 06:00:13.628029
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_virtual_collector = NetBSDVirtualCollector()
    assert netbsd_virtual_collector._fact_class == NetBSDVirtual
    assert netbsd_virtual_collector._platform == 'NetBSD'

# Generated at 2022-06-11 06:00:15.099714
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    netbsd_collector = NetBSDVirtualCollector()
    assert netbsd_collector._platform == 'NetBSD'

# Generated at 2022-06-11 06:00:17.653831
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual({})
    assert virtual_facts.platform == 'NetBSD'
    assert virtual_facts.get_virtual_facts().get('virtualization_type') == ''

# Generated at 2022-06-11 06:00:19.360458
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    obj = NetBSDVirtual()
    assert obj.platform == 'NetBSD'

# Generated at 2022-06-11 06:00:25.061585
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    import sys
    import os

    if os.uname()[0] != 'NetBSD':
        sys.stderr.write('skipping NetBSD virtual test, platform not NetBSD\n')
        return

    # Call the constructor and make sure it doesn't die
    try:
        NetBSDVirtual()
    except Exception:
        assert False

    # Make sure this doesn't die
    try:
        NetBSDVirtual().collect()
    except Exception:
        assert False

# Generated at 2022-06-11 06:00:27.237606
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virt = NetBSDVirtual()
    assert virt.platform == 'NetBSD'
    assert virt.virtualization_type == ''
    assert virt.virtualization_role == ''

# Generated at 2022-06-11 06:00:28.499408
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virt = NetBSDVirtual(None)
    assert virt.platform == 'NetBSD'

# Generated at 2022-06-11 06:00:38.223213
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    """
    Test NetBSDVirtual.get_virtual_facts
    """

    test_object = NetBSDVirtual()


# Generated at 2022-06-11 06:00:45.576431
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    import platform
    import sys

    # Generate a fake triple
    fake_triple = 'x86_64-netbsd'

    # Capture original triple
    original_triple = sys.platform

    # Capture original version
    original_version = platform.version()

    # Capture original system
    original_system = platform.system()

    # Capture original release
    original_release = platform.release()

    # Set the fake triple
    platform.system = lambda: 'NetBSD'
    platform.release = lambda: fake_triple
    platform.version = lambda: '2.0'
    sys.platform = fake_triple

    # Get the collection
    collection = NetBSDVirtualCollector()

    # Test the collection
    assert collection is not None
    assert len(collection.platforms) == 1

# Generated at 2022-06-11 06:00:53.856554
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual = NetBSDVirtual()
    # Simple dict overview of the test data.
    test_facts = {}
    test_facts['virtualization_type'] = ''
    test_facts['virtualization_role'] = ''
    test_facts['virtualization_product_name'] = ''
    test_facts['virtualization_product_version'] = ''

    # First test: no machdep.dmi.system-product and machdep.dmi.system-vendor available
    virtual._sysctl_dict = {}
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts == test_facts

    # Second test: no machdep.dmi.system-product and machdep.dmi.system-vendor available
    #              but machdep.hypervisor available

# Generated at 2022-06-11 06:01:24.385389
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    v = NetBSDVirtual({'ansible_facts': {'machdep': {'dmi': {'system-vendor': 'BHYVE', 'system-product': ''}, 'hypervisor': 'BHYVE'}}})
    expected_dict = {'virtualization_type': 'bhyve',
                     'virtualization_role': 'guest',
                     'virtualization_tech_host': {'bhyve'},
                     'virtualization_tech_guest': {'bhyve'}}
    assert v.get_virtual_facts() == expected_dict

# Generated at 2022-06-11 06:01:30.463529
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsdvirtual = NetBSDVirtual()
    assert netbsdvirtual.guest == set()
    assert netbsdvirtual.host == set()
    assert netbsdvirtual.hypervisor == set()
    assert netbsdvirtual.product == set()
    assert netbsdvirtual.virtual == set()
    assert netbsdvirtual.virt_what == set()
    assert netbsdvirtual.platform == 'NetBSD'


# Generated at 2022-06-11 06:01:31.381075
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    NetBSDVirtualCollector()

# Generated at 2022-06-11 06:01:34.373887
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd = NetBSDVirtual()
    assert netbsd.platform.startswith('NetBSD'), "The platform value '%s' for class NetBSDVirtual is not valid." % netbsd.platform


# Generated at 2022-06-11 06:01:40.883784
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.virtualization_type == ''
    assert netbsd_virtual.virtualization_role == ''
    assert 'virtualization_type' in netbsd_virtual.platform_subclass.VIRTUAL_IMPLEMENTATION_SPECIFIC_FACTS
    assert 'virtualization_role' in netbsd_virtual.platform_subclass.VIRTUAL_IMPLEMENTATION_SPECIFIC_FACTS

if __name__ == '__main__':
    test_NetBSDVirtual()

# Generated at 2022-06-11 06:01:42.198648
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    collector = NetBSDVirtualCollector()
    assert collector is not None

# Generated at 2022-06-11 06:01:43.101365
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector._platform == 'NetBSD'

# Generated at 2022-06-11 06:01:44.245970
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.platform == 'NetBSD'



# Generated at 2022-06-11 06:01:48.278064
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual_constructor = NetBSDVirtual()
    hostvars = dict()
    hostvars['ansible_architecture'] = 'x86_64'
    hostvars['ansible_distribution'] = 'NetBSD'
    virtual_facts_returned = netbsd_virtual_constructor.get_virtual_facts(hostvars)
    assert virtual_facts_returned['virtualization_type'] == ''

# Generated at 2022-06-11 06:01:48.781639
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    NetBSDVirtual()

# Generated at 2022-06-11 06:02:59.635150
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_platform = NetBSDVirtual()
    assert virtual_platform._platform == 'NetBSD'


# Generated at 2022-06-11 06:03:02.495371
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual()
    assert isinstance(virtual, NetBSDVirtual)
    assert isinstance(virtual, Virtual)
    assert isinstance(virtual, VirtualSysctlDetectionMixin)
    assert virtual._platform == 'NetBSD'

# Generated at 2022-06-11 06:03:05.679847
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    detector = NetBSDVirtual()

    assert detector.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_technologies_guest': set(),
        'virtualization_technologies_host': set()
    }

# Generated at 2022-06-11 06:03:08.286701
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual(None)

    #Read
    assert netbsd_virtual.sysctl_all != None

    #Write
    netbsd_virtual.sysctl_all = None
    assert netbsd_virtual.sysctl_all == None

# Generated at 2022-06-11 06:03:17.965546
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    import sysctl

    class TestSysCtl:
        @staticmethod
        def getSysCtls():
            return {
                'machdep.dmi.system-product': 'VMware Virtual Platform',
                'machdep.dmi.system-version': 'None',
                'machdep.dmi.system-vendor': 'VMware, Inc.'
            }

    class TestSysCtlXen:
        @staticmethod
        def getSysCtls():
            return {
                'machdep.dmi.system-product': 'KVM',
                'machdep.dmi.system-vendor': 'KVM'
            }

    # Test VMware virtual facts, these values are on the test image
    virtual = NetBSDVirtual(fake_sysctl_mgr=TestSysCtl)

# Generated at 2022-06-11 06:03:23.487278
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    sysctl_mock = {'machdep.dmi.system-vendor': 'innotek GmbH',
                   'machdep.dmi.system-product': 'VirtualBox',
                   'machdep.hypervisor': '',
                   'hw.model': 'amd64'}
    file_mock = {}
    get_file_content = lambda filename: file_mock.get(filename)

    virtual = NetBSDVirtual({}, sysctl_mock, get_file_content)
    virtual_facts = virtual.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == 'virtualbox'
    assert virtual_facts['virtualization_role'] == 'guest'



# Generated at 2022-06-11 06:03:30.094757
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    import platform
    import os.path

    vnetbsd_facts = NetBSDVirtual(platform, os.path)

    vnetbsd_facts_dmi_vendor_type = {
        'machdep.dmi.system-product': 'KVM',
        'machdep.dmi.system-vendor': 'KVM',
        'machdep.hypervisor': 'kvm'
    }

    virtual_facts = vnetbsd_facts.get_virtual_facts(vnetbsd_facts_dmi_vendor_type)
    assert virtual_facts['virtualization_type'] == 'kvm'
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_product_name'] == 'KVM'

# Generated at 2022-06-11 06:03:31.079801
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    NetBSDVirtualCollector()

# Generated at 2022-06-11 06:03:33.489215
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsd_virtual = NetBSDVirtual()
    assert netbsd_virtual.platform == 'NetBSD'
    assert netbsd_virtual._platform == 'NetBSD'

# Generated at 2022-06-11 06:03:37.593023
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual = NetBSDVirtual()
    virtual_facts = netbsd_virtual.get_virtual_facts()
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_type'] == ''

# Generated at 2022-06-11 06:06:26.250510
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd = NetBSDVirtual()
    assert netbsd.get_virtual_facts()


# Generated at 2022-06-11 06:06:27.395815
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual = NetBSDVirtual()
    assert virtual._platform == 'NetBSD'

# Generated at 2022-06-11 06:06:31.627693
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    facts = {}
    virtual = NetBSDVirtual(facts)
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts == {'virtualization_tech_guest': set(),
                             'virtualization_tech_host': set(),
                             'virtualization_role': '',
                             'virtualization_type': ''}

# Generated at 2022-06-11 06:06:33.017253
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    module = NetBSDVirtual('fake_module')

    assert(module.platform == 'NetBSD')


# Generated at 2022-06-11 06:06:41.243226
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.netbsd import NetBSDVirtual
    from ansible.module_utils.facts.virtual.sysctl import VirtualSysctlDetectionMixin
    import sys
    import unittest

    class TestVirtual(VirtualSysctlDetectionMixin, NetBSDVirtual):
        def __init__(self):
            ''' We override __init__ with empty one to prevent initializing
                parent class and thus being unable to set sysctls in mocked
                sysctl call. '''
            pass

    class TestCase(unittest.TestCase):
        def test_get_virtual_facts(self):
            virtual = TestVirtual()

# Generated at 2022-06-11 06:06:47.658780
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Call function without virtual product info
    vendor, product = '', ''
    sysctl_values = {'machdep.dmi.system-vendor': vendor, 'machdep.dmi.system-product': product}
    virtual_facts = NetBSDVirtual._get_virtual_facts(sysctl_values)
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''

    # Call function with virtual product info
    vendor, product = 'Xen', 'HVM domU'
    sysctl_values = {'machdep.dmi.system-vendor': vendor, 'machdep.dmi.system-product': product}
    virtual_facts = NetBSDVirtual._get_virtual_facts(sysctl_values)