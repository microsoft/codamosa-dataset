

# Generated at 2022-06-25 01:18:10.216649
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    # Asserting that class NetBSDVirtual is a subclass of class Virtual
    assert issubclass(NetBSDVirtual, Virtual)


# Generated at 2022-06-25 01:18:14.542952
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()


# Generated at 2022-06-25 01:18:16.000794
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()

# Generated at 2022-06-25 01:18:18.125748
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_fact_instance = NetBSDVirtual()
    virtual_fact_result = virtual_fact_instance.get_virtual_facts()


# Generated at 2022-06-25 01:18:22.783598
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()

# Generated at 2022-06-25 01:18:26.610834
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    facts = net_b_s_d_virtual_0.get_virtual_facts()
    assert type(facts) is dict

# Generated at 2022-06-25 01:18:27.721265
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual = NetBSDVirtual()
    net_b_s_d_virtual.get_virtual_facts()
    assert True


# Generated at 2022-06-25 01:18:33.265087
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    assert net_b_s_d_virtual_0.get_virtual_facts() == {
        'virtualization_role': '',
        'virtualization_type': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }


# Generated at 2022-06-25 01:18:36.541419
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    net_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:18:37.669113
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()


# Generated at 2022-06-25 01:18:48.650873
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    assert net_b_s_d_virtual_0.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_sysctl': [
            'machdep.dmi.system-product',
            'machdep.dmi.system-vendor',
            'machdep.hypervisor'],
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()}


# Generated at 2022-06-25 01:18:51.719430
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual = NetBSDVirtual()
    net_b_s_d_virtual_facts = net_b_s_d_virtual.get_virtual_facts()
    assert net_b_s_d_virtual_facts != False

# Generated at 2022-06-25 01:18:52.525917
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()


# Generated at 2022-06-25 01:18:55.645367
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()


# Generated at 2022-06-25 01:18:58.381375
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    test_object = NetBSDVirtual()
    result = test_object.get_virtual_facts()
    assert isinstance(result, dict)


# Generated at 2022-06-25 01:19:02.374112
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()


# Generated at 2022-06-25 01:19:04.580706
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual = NetBSDVirtual()
    result = net_b_s_d_virtual.get_virtual_facts()
    assert isinstance(result, dict) and False is result


# Generated at 2022-06-25 01:19:05.467613
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()


# Generated at 2022-06-25 01:19:09.650787
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual({})
    assert set(net_b_s_d_virtual_0.get_virtual_facts().keys()) == set(['virtualization_role', 'virtualization_tech_guest', 'virtualization_tech_host', 'virtualization_type'])


# Generated at 2022-06-25 01:19:15.185940
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()

    assert net_b_s_d_virtual_0.platform == 'NetBSD'
    assert net_b_s_d_virtual_0.virttype == ''
    assert net_b_s_d_virtual_0.virt_what == '/usr/sbin/virt-what'

# Generated at 2022-06-25 01:19:24.701272
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector = NetBSDVirtualCollector()
    net_b_s_d_virtual_collector.collect()


# Generated at 2022-06-25 01:19:32.275485
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    mock_virtual_facts = {
        'virtualization_type': '',
        'virtualization_role': ''
    }
    net_b_s_d_virtual_0 = NetBSDVirtual()

    # Create mock values
    mock_kern_vendor = 'OpenBSD'
    mock_kern_product = 'OpenBSD'

    # Set the value for machdep.dmi.system-vendor
    net_b_s_d_virtual_0.sysctl = {
        'machdep.hypervisor': mock_kern_vendor,
        'machdep.dmi.system-vendor': mock_kern_vendor,
        'machdep.dmi.system-product': mock_kern_product
    }

    # Set the value for machdep.hypervisor
    net_b_s

# Generated at 2022-06-25 01:19:32.977241
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()


# Generated at 2022-06-25 01:19:34.995714
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()


# Generated at 2022-06-25 01:19:39.697495
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual = NetBSDVirtual()
    net_b_s_d_virtual_collector_1 = NetBSDVirtualCollector()
    virtual_facts = net_b_s_d_virtual.get_virtual_facts()
    guest_tech_0 = virtual_facts.get('virtualization_tech_guest')
    host_tech_0 = virtual_facts.get('virtualization_tech_host')


# Generated at 2022-06-25 01:19:42.615662
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()
    assert net_b_s_d_virtual_collector_0._fact_class.platform == 'NetBSD'


# Generated at 2022-06-25 01:19:44.846316
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()


# Generated at 2022-06-25 01:19:46.768716
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()


# Generated at 2022-06-25 01:19:49.143297
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    assert net_b_s_d_virtual_0._platform == 'NetBSD'


# Generated at 2022-06-25 01:19:51.161071
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()


# Generated at 2022-06-25 01:20:06.622550
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()


# Generated at 2022-06-25 01:20:08.718164
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    net_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:20:09.302485
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()


# Generated at 2022-06-25 01:20:11.207234
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    net_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:20:18.139861
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    assert net_b_s_d_virtual_0.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_system': '',
        'virtualization_technologies': set(),
        'virtualization_technologies_guest': set(),
        'virtualization_technologies_host': set(),
    }


# Generated at 2022-06-25 01:20:22.324617
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = None
    net_b_s_d_virtual_0 = NetBSDVirtual()
    virtual_facts = net_b_s_d_virtual_0.get_virtual_facts()
    return virtual_facts

if __name__ == '__main__':
    my_fact = test_NetBSDVirtual_get_virtual_facts()
    print(my_fact)

# Generated at 2022-06-25 01:20:25.323417
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()


# Generated at 2022-06-25 01:20:27.875435
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    result = net_b_s_d_virtual_0.get_virtual_facts()
    assert isinstance(result, dict)


# Generated at 2022-06-25 01:20:31.886816
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    
    assert net_b_s_d_virtual_0.get_virtual_facts() == {}


# Generated at 2022-06-25 01:20:35.378467
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()


# Generated at 2022-06-25 01:21:03.056817
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    test_case_0()
    print(VirtualCollector._platform)
    print(VirtualCollector._fact_class)
# unit test for instance of class NetBSDVirtualCollector

# Generated at 2022-06-25 01:21:06.506102
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    result = net_b_s_d_virtual_0.get_virtual_facts()
    assert 'virtualization_type' in result
    assert 'virtualization_role' in result
    assert 'virtualization_tech_guest' in result
    assert 'virtualization_tech_host' in result



# Generated at 2022-06-25 01:21:11.885234
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    instance = NetBSDVirtual({"net.bsd.vm.vmm.name": "NetBSDVM"})
    assert instance.get_virtual_facts()['virtualization_type'] == 'NetBSDVM'

# Generated at 2022-06-25 01:21:17.279708
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()

    assert net_b_s_d_virtual_0.platform == 'NetBSD'
    assert net_b_s_d_virtual_0.virtualization_type == ''
    assert net_b_s_d_virtual_0.virtualization_role == ''
    assert net_b_s_d_virtual_0.virtualization_system == ''
    assert net_b_s_d_virtual_0.virtualization_display == ''
    assert net_b_s_d_virtual_0.virtualization_uuid == ''
    assert net_b_s_d_virtual_0.virtualization_framebuffer == ''
    assert net_b_s_d_virtual_0.virtualization_cmdline == ''
    assert net_b_s_d_

# Generated at 2022-06-25 01:21:19.779729
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual = NetBSDVirtual()
    assert net_b_s_d_virtual.get_virtual_facts() == net_b_s_d_virtual.get_virtual_facts()


# Generated at 2022-06-25 01:21:26.961464
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = {'virtualization_type': '', 'virtualization_role': ''}
    net_b_s_d_virtual_collector_1 = NetBSDVirtualCollector()
    net_b_s_d_virtual_1 = net_b_s_d_virtual_collector_1.get_virtual_facts()
    assert net_b_s_d_virtual_1.get_virtual_facts() == virtual_facts


# Generated at 2022-06-25 01:21:32.245957
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
	net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()
	assert net_b_s_d_virtual_collector_0.platform == 'NetBSD'


# Generated at 2022-06-25 01:21:34.893896
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()

    net_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:21:38.633092
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = {'virtualization_tech_guest': set(),
                     'virtualization_tech_host': set()}
    virtual_facts['virtualization_type'] = ''
    virtual_facts['virtualization_role'] = ''
    virtual_facts['virtualization_system'] = ''
    virtual_facts['virtualization_product_name'] = ''
    assert NetBSDVirtual().get_virtual_facts() == virtual_facts

# Generated at 2022-06-25 01:21:42.958008
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsdvirtual_0 = NetBSDVirtual()
    assert netbsdvirtual_0 is not None


# Generated at 2022-06-25 01:22:38.304475
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    net_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:22:39.287848
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual({})

# Generated at 2022-06-25 01:22:41.860298
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual({}, {}, False, False)


if __name__ == '__main__':
     test_case_0()
     test_NetBSDVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:22:43.760059
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()


# Generated at 2022-06-25 01:22:45.384233
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()


# Generated at 2022-06-25 01:22:49.539967
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual = NetBSDVirtual()

# Generated at 2022-06-25 01:22:52.361918
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # No need to test this if platform is not NetBSD
    if os.name != 'posix' or os.uname()[0] != 'NetBSD':
        return
    net_b_s_d_virtual_0 = NetBSDVirtual()
    net_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:22:55.300491
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual = NetBSDVirtual()


# Generated at 2022-06-25 01:22:59.326429
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    result = net_b_s_d_virtual_0.get_virtual_facts()
    assert result is not None


# Generated at 2022-06-25 01:23:00.456143
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual = NetBSDVirtual()

# Generated at 2022-06-25 01:25:09.191384
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    assert net_b_s_d_virtual_0 is not None


# Generated at 2022-06-25 01:25:12.840782
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual = NetBSDVirtual()
    net_b_s_d_virtual_collector = NetBSDVirtualCollector()
    net_b_s_d_virtual.get_virtual_facts()
    print('NetBSDVirtual.get_virtual_facts')


# Generated at 2022-06-25 01:25:15.637513
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()


# Generated at 2022-06-25 01:25:21.708936
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()
    print(net_b_s_d_virtual_collector_0)


if __name__ == '__main__':
    test_NetBSDVirtualCollector()

# Generated at 2022-06-25 01:25:23.951412
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()


# Generated at 2022-06-25 01:25:28.320417
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    assert hasattr(NetBSDVirtual, 'platform')
    assert callable(getattr(NetBSDVirtual, '__init__'))
    assert callable(getattr(NetBSDVirtual, 'get_virtual_facts'))


# Generated at 2022-06-25 01:25:29.193800
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()


# Generated at 2022-06-25 01:25:30.522745
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual = NetBSDVirtual()
    net_b_s_d_virtual.get_virtual_facts()

# Generated at 2022-06-25 01:25:33.297203
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual = NetBSDVirtual(None)

# Generated at 2022-06-25 01:25:36.731127
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual = NetBSDVirtual()

    virtual_facts = net_b_s_d_virtual.get_virtual_facts()
    assert virtual_facts == {'virtualization_role': 'guest', 'virtualization_type': 'xen'}