

# Generated at 2022-06-25 01:18:14.390835
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()


# Generated at 2022-06-25 01:18:20.417863
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    virtual_facts = net_b_s_d_virtual_0.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'powervm_lx86'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_guest'] == ['powervm_lx86']
    assert virtual_facts['virtualization_tech_host'] == []


# Generated at 2022-06-25 01:18:22.364971
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()


# Generated at 2022-06-25 01:18:27.787217
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():

    assert isinstance(net_b_s_d_virtual_collector_0,NetBSDVirtualCollector)
    assert net_b_s_d_virtual_collector_0.platform == 'NetBSD'
    assert net_b_s_d_virtual_collector_0._fact_class == NetBSDVirtual


# Generated at 2022-06-25 01:18:29.338542
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()


# Generated at 2022-06-25 01:18:32.876506
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_obj = NetBSDVirtual()
    net_b_s_d_virtual_obj.get_virtual_facts()


# Generated at 2022-06-25 01:18:35.817570
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    assert net_b_s_d_virtual_0 is not None


# Generated at 2022-06-25 01:18:39.298418
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    assert NetBSDVirtual.platform == 'NetBSD'
    assert NetBSDVirtual.get_virtual_facts() == [
        'virtualization_type',
        'virtualization_role',
        'virtualization_system',
        'virtualization_tech_guest',
        'virtualization_tech_host'
    ]


# Generated at 2022-06-25 01:18:43.061134
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()

if __name__ == '__main__':
    test_case_0()
    test_NetBSDVirtual()

# Generated at 2022-06-25 01:18:45.364998
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()


# Generated at 2022-06-25 01:18:53.736065
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert net_b_s_d_virtual_collector_0.virtual == net_b_s_d_virtual_0
    assert net_b_s_d_virtual_collector_0._platform == 'NetBSD'
    assert net_b_s_d_virtual_0._platform == 'NetBSD'


# Generated at 2022-06-25 01:18:55.624745
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    arg0 = 'virtualization_type'
    arg1 = NetBSDVirtual.platform
    net_b_s_d_virtual_0 = NetBSDVirtual(arg0, arg1)

# Generated at 2022-06-25 01:18:58.899217
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()
    assert net_b_s_d_virtual_collector_0._platform == 'NetBSD'


# Generated at 2022-06-25 01:19:00.388631
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_1 = NetBSDVirtualCollector()


# Generated at 2022-06-25 01:19:02.545899
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()

# Generated at 2022-06-25 01:19:06.858243
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_data = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_product': '',
        'virtualization_distribution': '',
        'virtualization_system': '',
        'virtualization_uuid': '',
        'virtualization_hypervisor': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }
    net_b_s_d_virtual_0 = NetBSDVirtual(virtual_data)

# Generated at 2022-06-25 01:19:08.199120
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()


# Generated at 2022-06-25 01:19:09.180617
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()


# Generated at 2022-06-25 01:19:10.555229
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()


# Generated at 2022-06-25 01:19:13.571744
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()


# Generated at 2022-06-25 01:19:20.589925
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    bytes_0 = b'Y}\xd4\x85'
    int_0 = -2880
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0, int_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()



# Generated at 2022-06-25 01:19:26.540831
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    bytes_0 = b'G|r\xa3\x8b'
    int_0 = -2400
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0, int_0)
    bytes_1 = b'\x93\x91\xd8\xea\x11'
    int_1 = 69
    net_b_s_d_virtual_1 = NetBSDVirtual(bytes_1, int_1)
    if [net_b_s_d_virtual_0] != [net_b_s_d_virtual_1]:
        var_0 = net_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:19:31.086608
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    bytes_0 = b'G|r\xa3\x8b'
    int_0 = -2400
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0, int_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 01:19:40.471415
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    bytes_0 = b'\x0c\xa88\xc5\x9a'
    int_0 = -2400
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0, int_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    assert (var_0.get('virtualization_type') == '')
    assert ('virtualization_tech_host' in var_0)
    assert ('virtualization_tech_guest' in var_0)
    assert (var_0.get('virtualization_role') == '')
    bytes_1 = b'\x0c\xa88\xc5\x9a'
    int_1 = -2400
    net_b_s_d_virtual_1 = NetBSDVirtual

# Generated at 2022-06-25 01:19:42.095344
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()


# Generated at 2022-06-25 01:19:47.106332
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    bytes_0 = None
    int_0 = 0
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector(bytes_0, int_0)
    assert net_b_s_d_virtual_collector_0._fact_class == NetBSDVirtual

# Generated at 2022-06-25 01:19:56.355681
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    bytes_0 = b'\x00'
    int_0 = 0
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0, int_0)

# Generated at 2022-06-25 01:20:02.029867
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    bytes_0 = b'G|r\xa3\x8b'
    int_0 = -2400
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0, int_0)
    var_2 = net_b_s_d_virtual_0.get_virtual_facts()
    assert var_2 == {'virtualization_role': '', 'virtualization_type': '', 'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}


# Generated at 2022-06-25 01:20:07.681932
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    bytes_0 = b'G|r\xa3\x8b'
    int_0 = -2400
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0, int_0)


# Generated at 2022-06-25 01:20:11.859067
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    bytes_0 = b'T"\x1e\xe7\xab\x9a'
    int_0 = -11583
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector(bytes_0, int_0)
    var_0 = net_b_s_d_virtual_collector_0._fact_class
    var_1 = net_b_s_d_virtual_collector_0._platform

# Generated at 2022-06-25 01:20:25.211661
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xdaM\xf1\xdf\xc6\x9d\x8f\x03\xd4\xab\xff\x12^\xfa\xa2\xd6\xf9B\xd8\x90\xb0\x01\x1b\xa8\xc7\x04\xd6\xb1\xf9\x03\xf2\x96\x84\x8e'
    int_0 = 2035
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0, int_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 == {}

# Generated at 2022-06-25 01:20:31.135485
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    bytes_0 = b'\x8f\xdc\xda:\xbdI\x1e\x8c\xb1\xc9\x13'
    int_0 = -4113
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector(bytes_0,
                                                           int_0)
    assert net_b_s_d_virtual_collector_0._platform == 'NetBSD'
    assert net_b_s_d_virtual_collector_0._fact_class == NetBSDVirtual



# Generated at 2022-06-25 01:20:32.685211
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert True


# Generated at 2022-06-25 01:20:40.242012
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    # The bytes_0 constant should be equal to the value in NetBSDVirtual
    bytes_0 = b'G|r\xa3\x8b'
    int_0 = -2400
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0, int_0)
    assert(net_b_s_d_virtual_0.license_file == bytes_0)
    assert(net_b_s_d_virtual_0.max_node_id == int_0)
    assert(net_b_s_d_virtual_0.platform == 'NetBSD')


# Generated at 2022-06-25 01:20:46.492175
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    bytes_0 = b'\xa4\x03\x02\xc5\xaf\x94\x8f\xaf'
    int_0 = -1206
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0, int_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()



# Generated at 2022-06-25 01:20:50.066907
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    bytes_0 = b'G|r\xa3\x8b'
    int_0 = -2400
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0, int_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:20:56.097890
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    try:
        bytes_0 = b'G|r\xa3\x8b'
        int_0 = -2400
        net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0, int_0)
        var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    except Exception as exception_0:
        assert False


# Generated at 2022-06-25 01:21:01.022162
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert issubclass(NetBSDVirtualCollector, VirtualCollector)
    assert isinstance(NetBSDVirtualCollector, type)
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()
    var_0 = net_b_s_d_virtual_collector_0._platform
    assert var_0 == 'NetBSD'
    var_1 = net_b_s_d_virtual_collector_0._fact_class
    assert var_1 == NetBSDVirtual

# Generated at 2022-06-25 01:21:06.269986
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    bytes_0 = b'^\x92:\x00\x00\x00'
    int_0 = -22553
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector(bytes_0, int_0)
    assert net_b_s_d_virtual_collector_0._fact_class.__name__ == 'NetBSDVirtual'
    assert net_b_s_d_virtual_collector_0._platform == 'NetBSD'


# Generated at 2022-06-25 01:21:11.634287
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    bytes_0 = b'\xe1\x81\x8f\xf3'
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector(bytes_0)


# Generated at 2022-06-25 01:21:27.419572
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    bytes_0 = b'G|r\xa3\x8b'
    int_0 = -2400
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0, int_0)


# Generated at 2022-06-25 01:21:36.990068
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    bytes_0 = b'\x84\x9a\x9f\xab'
    int_0 = 117
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0, int_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    var_1 = set()
    var_0['virtualization_tech_guest'] = var_1
    var_0['virtualization_tech_host'] = var_1
    var_0['virtualization_role'] = ''
    var_0['virtualization_type'] = ''



# Generated at 2022-06-25 01:21:39.907174
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()
    # Verify the type of object
    assert net_b_s_d_virtual_collector_0.__class__.__name__ == 'NetBSDVirtualCollector'


# Generated at 2022-06-25 01:21:48.868538
# Unit test for constructor of class NetBSDVirtualCollector

# Generated at 2022-06-25 01:21:52.137542
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    bytes_0 = b'G|r\xa3\x8b'
    int_0 = -2400
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0, int_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:21:56.231552
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    bytes_0 = b'G|r\xa3\x8b'
    int_0 = -2400
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0, int_0)

    assert net_b_s_d_virtual_0._platform == 'NetBSD'


# Generated at 2022-06-25 01:21:59.671563
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()
    assert net_b_s_d_virtual_collector_0._fact_class == NetBSDVirtual

# Generated at 2022-06-25 01:22:05.189060
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    bytes_0 = b'G|r\xa3\x8b'
    int_0 = -2400
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0, int_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:22:09.369491
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    bytes_0 = b'G|r\xa3\x8b'
    int_0 = -2400
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0, int_0)
    var_0 = (net_b_s_d_virtual_0.get_virtual_facts())
    assert isinstance(var_0, dict)


# Generated at 2022-06-25 01:22:12.416169
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    bytes_0 = b'G|r\xa3\x8b'
    int_0 = -2400
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0, int_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:22:42.659654
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    bytes_0 = b'I\xd2c\xce'
    int_0 = -15709
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0, int_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:22:51.187697
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    bytes_0 = b'='
    int_0 = -2400
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0, int_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    assert (var_0 == {'virtualization_type': '', 'virtualization_role': '', 'virtualization_tech_guest': set(), 'virtualization_tech_host': set()})


# Generated at 2022-06-25 01:22:55.973639
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    bytes_0 = b'G|r\xa3\x8b'
    int_0 = -2400
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0, int_0)


# Generated at 2022-06-25 01:23:01.038985
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    bytes_0 = b'G|r\xa3\x8b'
    int_0 = -2400
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0, int_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:23:08.001364
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    bytes_0 = b'G|r\xa3\x8b'
    int_0 = -2400
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0, int_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:23:16.781148
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    bytes_0 = b'G|r\xa3\x8b'
    bytes_1 = b'G|r\xa3\x8b'
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector(bytes_0, bytes_1)
    assert net_b_s_d_virtual_collector_0._fact_class is NetBSDVirtual
    assert net_b_s_d_virtual_collector_0._platform == 'NetBSD'
    net_b_s_d_virtual_collector_0._collect()

# Generated at 2022-06-25 01:23:24.366713
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    bytes_0 = b'H\x11\xfe\xf4\xba\xbe\xa6\x85'
    int_0 = -428770965
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0, int_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    assert var_0['virtualization_type'] == ''
    assert var_0['virtualization_role'] == ''
    assert var_0['virtualization_tech_guest'] == {'xen'}
    assert var_0['virtualization_tech_host'] == set()

if __name__ == '__main__':
    test_NetBSDVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:23:27.978319
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    bytes_0 = b'G|r\xa3\x8b'
    int_0 = -2400
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0, int_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:23:30.895843
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    bytes_0 = b'G|r\xa3\x8b'
    int_0 = -2400
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0, int_0)
# Testing evaluate of function NetBSDVirtual.detect_virt_vendor

# Generated at 2022-06-25 01:23:35.747506
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    bytes_0 = b'$\xfc\xd6\xf2'
    int_0 = 173
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0, int_0)
    net_b_s_d_virtual_0.get_virtual_facts()
    try:
        net_b_s_d_virtual_0.get_virtual_facts()
    except:
        pass


# Generated at 2022-06-25 01:24:53.817817
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    bytes_0 = b'G|r\xa3\x8b'
    int_0 = -2400
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0, int_0)


# Generated at 2022-06-25 01:24:56.187258
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()

# Generated at 2022-06-25 01:24:59.346253
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()
    var_1 = net_b_s_d_virtual_collector_0.collect()


# Generated at 2022-06-25 01:25:04.630488
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    bytes_0 = b'0\xe7\x1f:)@'
    int_0 = -1703360870
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0, int_0)
    var_0 = net_b_s_d_virtual_0.platform
    assert var_0 == 'NetBSD'
    assert net_b_s_d_virtual_0.bytes_0 == bytes_0
    assert net_b_s_d_virtual_0.int_0 == int_0


# Generated at 2022-06-25 01:25:07.361669
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    assert True


# Generated at 2022-06-25 01:25:13.403342
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    bytes_0 = b'G|r\xa3\x8b'
    int_0 = -2400
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0, int_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()



# Generated at 2022-06-25 01:25:19.765282
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    bytes_0 = b'G|r\xa3\x8b'
    int_0 = -2400
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0, int_0)
    # Line coverage value: 5%
    # test get_virtual_facts which calls virtualization_vendor and virtualization_product
    assert net_b_s_d_virtual_0.get_virtual_facts() == {'virtualization_tech_host': set(), 'virtualization_tech_guest': set(), 'virtualization_role': 'guest', 'virtualization_type': 'virtualbox'}


# Generated at 2022-06-25 01:25:23.697710
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    bytes_0 = None
    int_0 = None
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0, int_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()



# Generated at 2022-06-25 01:25:32.639309
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    bytes_0 = b'!\xbc\x93\x1b'
    int_0 = -2400
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0, int_0)
    bytes_1 = b'\x90\xc3\xfc'
    int_1 = -2400
    net_b_s_d_virtual_1 = NetBSDVirtual(bytes_1, int_1)
    net_b_s_d_virtual_1.get_virtual_facts()
    bytes_2 = b'n\x8d\xec\xdd'
    int_2 = -2400
    net_b_s_d_virtual_2 = NetBSDVirtual(bytes_2, int_2)

# Generated at 2022-06-25 01:25:40.411054
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xeb\x84\x07\x8d\x08\t'
    int_0 = 7
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0, int_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()
