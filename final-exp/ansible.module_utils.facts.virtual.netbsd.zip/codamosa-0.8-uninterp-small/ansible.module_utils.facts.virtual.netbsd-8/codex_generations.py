

# Generated at 2022-06-25 01:18:10.384300
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    net_b_s_d_virtual_0.get_virtual_facts()
    pass


# Generated at 2022-06-25 01:18:14.967215
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    bool_0 = True
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector(bool_0)

# Generated at 2022-06-25 01:18:17.062459
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual(bool_0)



# Generated at 2022-06-25 01:18:18.838690
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    bool_0 = True
    net_b_s_d_virtual_0 = NetBSDVirtual(bool_0)


# Generated at 2022-06-25 01:18:21.862344
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    bool_0 = True
    net_b_s_d_virtual_0 = NetBSDVirtual(bool_0)


# Generated at 2022-06-25 01:18:26.611245
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    bool_0 = True
    net_b_s_d_virtual_0 = NetBSDVirtual(bool_0)
    assert isinstance(net_b_s_d_virtual_0, NetBSDVirtual)
    assert isinstance(net_b_s_d_virtual_0, Virtual)


# Generated at 2022-06-25 01:18:35.025845
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    bool_0 = True
    net_b_s_d_virtual_0 = NetBSDVirtual(bool_0)
    virtual_facts_dict = net_b_s_d_virtual_0.get_virtual_facts()
    # net_b_s_d_virtual_0.print_vf_facts(virtual_facts_dict)
    assert virtual_facts_dict['virtualization_type'] == 'xen'
    # assert virtual_facts_dict['virtualization_type'] == 'vmware'
    # assert virtual_facts_dict['virtualization_type'] == 'kvm'
    assert virtual_facts_dict['virtualization_type'] == 'hyperv'
    assert virtual_facts_dict['virtualization_type'] == 'docker'
    assert virtual_facts_dict['virtualization_type'] == 'lxc'
   

# Generated at 2022-06-25 01:18:41.531442
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual(False)
    net_b_s_d_virtual_0.detect_virt_product = lambda x: {'virtualization_type': '', 'virtualization_role': '', 'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}
    net_b_s_d_virtual_0.detect_virt_vendor = lambda x: {'virtualization_type': '', 'virtualization_role': '', 'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}
    assert net_b_s_d_virtual_0.get_virtual_facts() == {}


# Generated at 2022-06-25 01:18:44.941531
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    bool_0 = True
    net_b_s_d_virtual_0 = NetBSDVirtual(bool_0)
# ex: ts=4 expandtab ft=python

# Generated at 2022-06-25 01:18:49.744801
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    # Success...
    # net_b_s_d_virtual_0 = NetBSDVirtual(
    #     False
    # )

    # Failure...
    net_b_s_d_virtual_0 = NetBSDVirtual(
        True
    )

# Generated at 2022-06-25 01:18:58.075402
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    expected = {'virtualization_role': 'guest', 'virtualization_type': 'xen', 'virtualization_tech_guest': {'xen'}, 'virtualization_tech_host': set()}
    virtual_facts = net_b_s_d_virtual_0.get_virtual_facts()
    assert virtual_facts == expected

# Generated at 2022-06-25 01:19:03.159373
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    net_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:19:04.981291
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_1 = NetBSDVirtual()
    net_b_s_d_virtual_1.get_virtual_facts()



# Generated at 2022-06-25 01:19:10.485482
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_2 = NetBSDVirtual()
    net_b_s_d_virtual_2.get_virtual_facts()


# Generated at 2022-06-25 01:19:17.660372
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    net_b_s_d_virtual_0._detect_virt_product = lambda: {}
    net_b_s_d_virtual_0._detect_virt_vendor = lambda: {}
    net_b_s_d_virtual_0._cache_data = lambda: {}
    net_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:19:18.843896
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()

# Generated at 2022-06-25 01:19:30.533706
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    net_b_s_d_virtual_1 = NetBSDVirtual()
    net_b_s_d_virtual_0._get_virtual_facts_dict = {'machdep.dmi.system-product': 'VMware Virtual Platform\x00', 'machdep.dmi.system-vendor': 'VMware, Inc.\x00'}
    net_b_s_d_virtual_1._get_virtual_facts_dict = {'machdep.dmi.system-product': 'VMware Virtual Platform\x00', 'machdep.dmi.system-vendor': 'VMware, Inc.\x00'}
    net_b_s_d_virtual_actual = NetBSDVirtual()
    net_b_s_d_

# Generated at 2022-06-25 01:19:34.737746
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    assert hasattr(net_b_s_d_virtual_0, 'get_virtual_facts')



# Generated at 2022-06-25 01:19:36.128398
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector = NetBSDVirtualCollector()

# Generated at 2022-06-25 01:19:38.295833
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()


if __name__ == '__main__':
    test_case_0()
    test_NetBSDVirtualCollector()

# Generated at 2022-06-25 01:19:51.466848
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual = NetBSDVirtual()
    assert net_b_s_d_virtual.platform == 'NetBSD'

    # test method 'get_virtual_facts' of class NetBSDVirtual when there are no
    # virtualization facts available
    net_b_s_d_virtual.facts['sysctl'] = {}
    virtual_facts = net_b_s_d_virtual.get_virtual_facts()
    assert virtual_facts == {
        'virtualization_role': '',
        'virtualization_type': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()}


# Generated at 2022-06-25 01:19:53.418242
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    assert net_b_s_d_virtual_0


# Generated at 2022-06-25 01:19:54.553804
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_1 = NetBSDVirtual()

# Generated at 2022-06-25 01:19:55.645080
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()


# Generated at 2022-06-25 01:20:00.154063
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()

if __name__ == '__main__':
    import platform
    if platform.system() != 'NetBSD':
        print("ERROR: This utility is only meant to be run on NetBSD")
        sys.exit(int(os.environ.get("TEST_EXIT_CODE", 1)))
    test_case_0()
# End of file

# Generated at 2022-06-25 01:20:01.250695
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()

# Generated at 2022-06-25 01:20:03.037697
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_0_0 = NetBSDVirtualCollector()
    assert net_b_s_d_virtual_0_0._platform == 'NetBSD'

# Generated at 2022-06-25 01:20:06.547552
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_1 = NetBSDVirtualCollector()


# Generated at 2022-06-25 01:20:07.643894
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector = NetBSDVirtualCollector()

# Generated at 2022-06-25 01:20:17.086744
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    args = dict(
        dmi_sys_vendor='VMware, Inc.',
        dmi_sys_vendor_id='VMware, Inc.',
        dmi_sys_product_uuid='56 4d a1 ff ff 62 51 88-ba 54 72 fb 54 b0 e8 1a',
        dmi_sys_product_name='VMware Virtual Platform',
        dmi_sys_product_version='None'
    )
    net_b_s_d_virtual_1 = NetBSDVirtual(args=args)
    assert net_b_s_d_virtual_1.get_virtual_facts()['virtualization_type'] == 'VMware Virtual Platform'
    net_b_s_d_virtual_2 = NetBSDVirtual()
    net_b_s_d_virtual_2.dmi_sys

# Generated at 2022-06-25 01:20:27.988464
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()
    assert net_b_s_d_virtual_collector_0._platform == 'NetBSD'
    assert repr(net_b_s_d_virtual_collector_0) == "<NetBSDVirtualCollector(platform='NetBSD')>"



# Generated at 2022-06-25 01:20:29.907698
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_1 = NetBSDVirtual()
    assert net_b_s_d_virtual_1 is not None


# Generated at 2022-06-25 01:20:40.300351
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    # sysctl_0 = dict(
    #     returns=dict(
    #         machdep=dict(
    #             machdep_dmi_system_vendor='QEMU',
    #             machdep_dmi_system_product='Standard PC (i440FX + PIIX, 1996)'
    #         )
    #     )
    # )
    # results_0 = dict(
    #     virtualization_type='xen',
    #     virtualization_role='guest'
    # )

    sysctl_1 = dict(
        returns=dict(
            machdep=dict(
                machdep_dmi_system_vendor='1',
                machdep_dmi_system_product='2'
            )
        )
    )

# Generated at 2022-06-25 01:20:42.941298
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    obj = NetBSDVirtualCollector()
    print(obj)


# Generated at 2022-06-25 01:20:45.043849
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector = NetBSDVirtualCollector()


# Generated at 2022-06-25 01:20:48.659291
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_1 = NetBSDVirtual()
    assert net_b_s_d_virtual_1.platform == 'NetBSD'
    assert net_b_s_d_virtual_1.hypervisor == ''
    assert net_b_s_d_virtual_1.virtual_type == ''


# Generated at 2022-06-25 01:20:53.277504
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_1 = NetBSDVirtual(collect_echo=False)
    assert net_b_s_d_virtual_1.collect_echo() == False


# Generated at 2022-06-25 01:20:55.800084
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    net_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:21:05.026571
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    assert(net_b_s_d_virtual_0.platform == "NetBSD")
    assert(net_b_s_d_virtual_0.virtualization_type == "")
    assert(net_b_s_d_virtual_0.virtualization_role == "")
    assert(net_b_s_d_virtual_0.virtualization_subsystem == "")
    assert(net_b_s_d_virtual_0.virtualization_tech_guest == set())
    assert(net_b_s_d_virtual_0.virtualization_tech_host == set())
    assert(net_b_s_d_virtual_0.virtualization_system == "")

# Generated at 2022-06-25 01:21:07.616821
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    assert net_b_s_d_virtual_0 is not None
    assert net_b_s_d_virtual_0.platform == 'NetBSD'


# Generated at 2022-06-25 01:21:27.518639
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    host_tech = set()
    guest_tech = set()
    virtual_facts = {}

    host_tech.add('xen')
    guest_tech.add('xen')
    virtual_facts['virtualization_type'] = 'xen'
    virtual_facts['virtualization_role'] = 'guest'

    net_b_s_d_virtual_0 = NetBSDVirtual()
    assert net_b_s_d_virtual_0.get_virtual_facts()[0] == virtual_facts

# Generated at 2022-06-25 01:21:28.734737
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()

# Generated at 2022-06-25 01:21:32.779043
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()


# Generated at 2022-06-25 01:21:34.531522
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual = NetBSDVirtual()

# Generated at 2022-06-25 01:21:35.837802
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_obj = NetBSDVirtualCollector()


# Generated at 2022-06-25 01:21:37.874795
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    assert net_b_s_d_virtual_0.__class__.__name__ == 'NetBSDVirtual'


# Generated at 2022-06-25 01:21:43.129584
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    assert net_b_s_d_virtual_0.platform == "NetBSD"


# Generated at 2022-06-25 01:21:47.904799
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()
    net_b_s_d_virtual_collector_1 = NetBSDVirtualCollector()

# Generated at 2022-06-25 01:21:50.107430
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    try:
        assert net_b_s_d_virtual_0.__class__ == NetBSDVirtual
    except AssertionError as e:
        print('AssertionError: ' + str(e))


# Generated at 2022-06-25 01:21:53.943752
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    handler_0 = NetBSDVirtual()
    assert isinstance(handler_0, NetBSDVirtual)



# Generated at 2022-06-25 01:22:12.989629
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    str_0 = 'v\n!~E#h8[u\x0cWC*UtB'
    net_b_s_d_virtual_2 = NetBSDVirtual(str_0, str_0)
    assert isinstance(net_b_s_d_virtual_2, NetBSDVirtual)
    net_b_s_d_virtual_3 = NetBSDVirtual(net_b_s_d_virtual_2)
    assert isinstance(net_b_s_d_virtual_3, NetBSDVirtual)


# Generated at 2022-06-25 01:22:18.647224
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    import sys
    import inspect
    from io import StringIO

    net_b_s_d_virtual_0 = NetBSDVirtual('/dev/null', 'dummy')
    assert net_b_s_d_virtual_0 is not None

    # Constructor test case insue, but no exception raised.
    net_b_s_d_virtual_1 = NetBSDVirtual('/dev/null', 'dummy')
    assert net_b_s_d_virtual_1 is not None



# Generated at 2022-06-25 01:22:26.633386
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    str_0 = 'N\x1ah\x0c\x16\x1d\x1a\x1dey'
    net_b_s_d_virtual_0 = NetBSDVirtual(str_0, str_0)
    net_b_s_d_virtual_1 = NetBSDVirtual(net_b_s_d_virtual_0)
    var_0 = net_b_s_d_virtual_1.get_virtual_facts()


# Generated at 2022-06-25 01:22:33.302386
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    # testing constructor with
    # - correct parameter type
    # - correct parameter value
    t0_str_0 = 'v\n!~E#h8[u\x0cWC*UtB'
    t0_net_b_s_d_virtual_0 = NetBSDVirtual(t0_str_0, t0_str_0)

    # testing constructor with
    # - correct parameter type
    # - wrong parameter value
    t1_str_0 = 'i-\x00j\x1e\x10\x00\x00'
    with pytest.raises(RuntimeError):
        t1_net_b_s_d_virtual_0 = NetBSDVirtual(t1_str_0, t1_str_0)

    # testing constructor with
    # - wrong parameter type (invalid)


# Generated at 2022-06-25 01:22:41.925680
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    str_0 = 'XB\x7f\x1d!V\x1c\x1fJ$\x01\x16\x0e\x14q'
    str_1 = '\\\x16\x1de\x1e\x0f8W\x0bX\x11Ny'
    net_b_s_d_virtual_0 = NetBSDVirtual(str_0, str_1)
    del net_b_s_d_virtual_0



# Generated at 2022-06-25 01:22:52.681822
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    str_0 = 'v\n!~E#h8[u\x0cWC*UtB'
    net_b_s_d_virtual_0 = NetBSDVirtual(str_0, str_0)
    net_b_s_d_virtual_1 = NetBSDVirtual(net_b_s_d_virtual_0)
    var_0 = net_b_s_d_virtual_1.get_virtual_facts()
    assert var_0['virtualization_type'] == 'openvz'
    assert var_0['virtualization_role'] == 'guest'
    assert var_0['virtualization_tech_guest'] == set()
    assert var_0['virtualization_tech_host'] == set()
    assert var_0['virtualization_product_name'] == 'openvz'

# Generated at 2022-06-25 01:23:02.854752
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    str_0 = 'Y"\x0c[w\x1b\x1d' # 'Y"\x0c[w\x1b\x1d'
    sysctl_0 = Sysctl(str_0, str_0)
    net_b_s_d_virtual_1 = NetBSDVirtual(sysctl_0)

    str_0 = '\x1b\x1dT\x1a\x1a' # '\x1b\x1dT\x1a\x1a'
    sysctl_1 = Sysctl(str_0, str_0)
    net_b_s_d_virtual_0 = NetBSDVirtual(sysctl_1)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()

    str_

# Generated at 2022-06-25 01:23:05.679822
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()

# Generated at 2022-06-25 01:23:12.305309
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    str_0 = '\x0cRh|\x10\x0c\x0bL\x05(\x10H\x0b`[\x1b\x1a'
    net_b_s_d_virtual_0 = NetBSDVirtual(str_0, str_0)
    net_b_s_d_virtual_1 = NetBSDVirtual(net_b_s_d_virtual_0)
    var_0 = net_b_s_d_virtual_1.get_virtual_facts()

# Generated at 2022-06-25 01:23:19.188519
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    str_0 = 'v\n!~E#h8[u\x0cWC*UtB'
    net_b_s_d_virtual_0 = NetBSDVirtual(str_0, str_0)
    net_b_s_d_virtual_1 = NetBSDVirtual(net_b_s_d_virtual_0)
    var_0 = net_b_s_d_virtual_1.get_virtual_facts()


# Generated at 2022-06-25 01:24:05.359698
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    str_0 = 'v\n!~E#h8[u\x0cWC*UtB'
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()
    net_b_s_d_virtual_collector_0._init_platform_facts()
    net_b_s_d_virtual_collector_1 = NetBSDVirtualCollector(str_0)
    assert net_b_s_d_virtual_collector_0.platform == 'NetBSD'
    assert net_b_s_d_virtual_collector_0.fact_class.platform == 'NetBSD'
    assert net_b_s_d_virtual_collector_1.platform == 'NetBSD'

# Generated at 2022-06-25 01:24:09.754978
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    str_0 = 'v\n!~E#h8[u\x0cWC*UtB'
    test_case_0()


# Generated at 2022-06-25 01:24:15.609874
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    # Constructor with no arguments
    net_b_s_d_virtual_0 = NetBSDVirtual()
    assert net_b_s_d_virtual_0._platform == 'NetBSD'
    assert net_b_s_d_virtual_0._collector_platform == 'NetBSD'
    assert net_b_s_d_virtual_0._fact_class == NetBSDVirtual
    # Constructor with arguments
    net_b_s_d_virtual_1 = NetBSDVirtual('/usr/local/bin/', 'ansible')
    assert net_b_s_d_virtual_1._platform == '/usr/local/bin/'
    assert net_b_s_d_virtual_1._collector_platform == 'ansible'
    assert net_b_s_d_virtual_1._fact_class == NetBSD

# Generated at 2022-06-25 01:24:21.292943
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    str_0 = 'v\n!~E#h8[u\x0cWC*UtB'
    net_b_s_d_virtual_0 = NetBSDVirtual(str_0, str_0)
    net_b_s_d_virtual_1 = NetBSDVirtual(net_b_s_d_virtual_0)
    var_0 = net_b_s_d_virtual_1.get_virtual_facts()


# Generated at 2022-06-25 01:24:31.258525
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    # Test for constructor of class NetBSDVirtual with normal values
    str_0 = 'v\n!~E#h8[u\x0cWC*UtB'
    net_b_s_d_virtual_0 = NetBSDVirtual(str_0, str_0)
    assert net_b_s_d_virtual_0.get_virtual_facts() == {'virtualization_tech_guest': set(), 'virtualization_tech_host': set(), 'virtualization_type': '', 'virtualization_role': ''}

    # Test for constructor of class NetBSDVirtual with exception values
    str_1 = 'u\x07s\x05jzMZ#V\x0bD'
    net_b_s_d_virtual_1 = NetBSDVirtual(str_1, str_1)

# Generated at 2022-06-25 01:24:36.333607
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    str_0 = 'O\x0b\x10TQ\t^*\t\r'
    net_b_s_d_virtual_0 = NetBSDVirtual(str_0, str_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:24:40.672323
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    str_0 = 'v\n!~E#h8[u\x0cWC*UtB'
    net_b_s_d_virtual_0 = NetBSDVirtual(str_0, str_0)
    net_b_s_d_virtual_1 = NetBSDVirtual(net_b_s_d_virtual_0)
    #
    # Call method on NetBSDVirtual
    #
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    # Test case passed


# Generated at 2022-06-25 01:24:45.954442
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    str_0 = 'a\x0e\x02\r\r^\x1a\x1c\x1a>'
    net_b_s_d_virtual_2 = NetBSDVirtual(str_0, str_0)
    net_b_s_d_virtual_2.get_virtual_facts()


if __name__ == '__main__':
    test_case_0()
    test_NetBSDVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:24:51.323039
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    str_0 = 'x'
    net_b_s_d_virtual_0 = NetBSDVirtual(str_0, str_0)
    net_b_s_d_virtual_1 = NetBSDVirtual(net_b_s_d_virtual_0)
    var_0 = net_b_s_d_virtual_1.get_virtual_facts()


# Generated at 2022-06-25 01:25:00.726828
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    str_0 = 'H-/S]G'
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector(str_0, str_0)
    str_1 = 'K'
    net_b_s_d_virtual_collector_1 = NetBSDVirtualCollector(net_b_s_d_virtual_collector_0, str_1)
    net_b_s_d_virtual_collector_2 = NetBSDVirtualCollector(net_b_s_d_virtual_collector_1)
    net_b_s_d_virtual_collector_3 = NetBSDVirtualCollector(net_b_s_d_virtual_collector_1, net_b_s_d_virtual_collector_0)
    net_b_s_d_virtual_collect

# Generated at 2022-06-25 01:26:27.604016
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    str_0 = 'v\n!~E#h8[u\x0cWC*UtB'
    net_b_s_d_virtual_0 = NetBSDVirtual(str_0, str_0)

# Generated at 2022-06-25 01:26:31.441533
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    str_0 = 'v\n!~E#h8[u\x0cWC*UtB'
    net_b_s_d_virtual_0 = NetBSDVirtual(str_0, str_0)
    net_b_s_d_virtual_1 = NetBSDVirtual(net_b_s_d_virtual_0)
    var_0 = net_b_s_d_virtual_1.get_virtual_facts()


# Generated at 2022-06-25 01:26:34.777939
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert True


# Generated at 2022-06-25 01:26:38.939190
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    str_0 = 'v\n!~E#h8[u\x0cWC*UtB'
    net_b_s_d_virtual_0 = NetBSDVirtual(str_0, str_0)
    net_b_s_d_virtual_1 = NetBSDVirtual(net_b_s_d_virtual_0)
    assert net_b_s_d_virtual_1 == net_b_s_d_virtual_0
    assert net_b_s_d_virtual_1 != net_b_s_d_virtual_0
    assert net_b_s_d_virtual_1.get_virtual_facts() == {'virtualization_type': '', 'virtualization_role': '', 'virtualization_tech_guest': set([]), 'virtualization_tech_host': set([])}


# Generated at 2022-06-25 01:26:44.756288
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    str_0 = 'B|yq\x0c>;\x1a'
    net_b_s_d_virtual_0 = NetBSDVirtual(str_0, str_0)
    net_b_s_d_virtual_1 = NetBSDVirtual(net_b_s_d_virtual_0)
    var_0 = net_b_s_d_virtual_1.get_virtual_facts()

# Generated at 2022-06-25 01:26:53.723141
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    str_0 = 'v\n!~E#h8[u\x0cWC*UtB'
    net_b_s_d_virtual_0 = NetBSDVirtual(str_0, str_0)
    assert net_b_s_d_virtual_0._platform == 'NetBSD'
    net_b_s_d_virtual_1 = NetBSDVirtual(net_b_s_d_virtual_0)
    # Test results of net_b_s_d_virtual_0.get_virtual_facts()
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    assert var_0['virtualization_tech_host'] == set()
    assert var_0['virtualization_tech_guest'] == set()

# Generated at 2022-06-25 01:26:59.726512
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    str_0 = 'v\n!~E#h8[u\x0cWC*UtB'
    net_b_s_d_virtual_0 = NetBSDVirtual(str_0, str_0)
    net_b_s_d_virtual_1 = NetBSDVirtual(net_b_s_d_virtual_0)
    var_0 = net_b_s_d_virtual_1.get_virtual_facts()
    assert var_0 == {'virtualization_role': 'guest', 'virtualization_type': '', 'virtualization_tech_host': set(['kvm']), 'virtualization_tech_guest': set(['kvm'])}


# Generated at 2022-06-25 01:27:05.580407
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    str_0 = 'v\n!~E#h8[u\x0cWC*UtB'
    net_b_s_d_virtual_0 = NetBSDVirtual(str_0, str_0)
    net_b_s_d_virtual_1 = NetBSDVirtual(net_b_s_d_virtual_0)
    #print(net_b_s_d_virtual_1.get_virtual_facts())


# Generated at 2022-06-25 01:27:12.388494
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    str_0 = 'v\n!~E#h8[u\x0cWC*UtB'
    net_b_s_d_virtual_0 = NetBSDVirtual(str_0, str_0)
    net_b_s_d_virtual_1 = NetBSDVirtual(net_b_s_d_virtual_0)
    var_0 = net_b_s_d_virtual_1.get_virtual_facts()


# Generated at 2022-06-25 01:27:17.046985
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    assert callable(NetBSDVirtual.get_virtual_facts)
    assert isinstance(NetBSDVirtual.get_virtual_facts(), dict)
