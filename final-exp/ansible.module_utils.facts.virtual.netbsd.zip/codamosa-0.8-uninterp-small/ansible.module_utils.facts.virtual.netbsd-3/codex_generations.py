

# Generated at 2022-06-25 01:18:15.044787
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsdvirtual = NetBSDVirtual()
    assert netbsdvirtual.platform is not None

# Unit test - method get_virtual_facts()

# Generated at 2022-06-25 01:18:18.692382
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    # NetBSDVirtual::get_virtual_facts() is not implemented


if __name__ == '__main__':
    test_case_0()
    test_NetBSDVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:18:26.396115
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual = NetBSDVirtual()
    virtual_facts = net_b_s_d_virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_sysctl_params'] == dict()
    assert virtual_facts['virtualization_product_name'] == ''
    assert virtual_facts['virtualization_product_version'] == ''

# Generated at 2022-06-25 01:18:27.888324
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual({})
    assert net_b_s_d_virtual_0.data == {}
    assert net_b_s_d_virtual_0.platform == 'NetBSD'


# Generated at 2022-06-25 01:18:35.856921
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_fixture = NetBSDVirtual()
    assert net_b_s_d_virtual_fixture.get_virtual_facts()['virtualization_type'] == 'xen'
    assert 'xen' in net_b_s_d_virtual_fixture.get_virtual_facts()['virtualization_tech_guest']
    assert net_b_s_d_virtual_fixture.get_virtual_facts()['virtualization_role'] == 'guest'


# Generated at 2022-06-25 01:18:36.914788
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    net_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:18:38.064683
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()


# Generated at 2022-06-25 01:18:41.861830
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()


# Generated at 2022-06-25 01:18:52.245235
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Setup test environment
    net_b_s_d_virtual_0 = NetBSDVirtual()

# Generated at 2022-06-25 01:18:55.614572
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()



# Generated at 2022-06-25 01:19:00.046308
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()


# Generated at 2022-06-25 01:19:03.287442
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()
    dict_0 = net_b_s_d_virtual_collector_0.get_virtual_facts()
    assert isinstance(dict_0['virtualization_type'], str) or dict_0['virtualization_type'] is None


# Generated at 2022-06-25 01:19:04.367830
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert True
# Run same tests as for LinuxVirtual
test_case_0()
test_LinuxVirtual()

# Generated at 2022-06-25 01:19:09.762223
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    net_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:19:10.929056
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    # Testing constructor
    assert test_case_0()


# Generated at 2022-06-25 01:19:13.241654
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    result = net_b_s_d_virtual_0.get_virtual_facts()
    assert result == {'virtualization_role': '', 'virtualization_type': '', 'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}

# Generated at 2022-06-25 01:19:17.852442
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    (net_b_s_d_virtual_0).get_virtual_facts()



# Generated at 2022-06-25 01:19:19.788764
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    net_b_s_d_virtual_0.get_virtual_facts()



# Generated at 2022-06-25 01:19:23.557029
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector()
# Testing the data returned by NetBSDVirtualCollector class

# Generated at 2022-06-25 01:19:28.168523
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()


# Generated at 2022-06-25 01:19:36.313908
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    int_0 = -3005
    net_b_s_d_virtual_0 = NetBSDVirtual(int_0, int_0)
    assert net_b_s_d_virtual_0 is not None


# Generated at 2022-06-25 01:19:39.735759
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector(int_0, net_b_s_d_virtual_0)
    assert net_b_s_d_virtual_collector_0._fact_class == NetBSDVirtual
    assert net_b_s_d_virtual_collector_0._platform == 'NetBSD'


# Generated at 2022-06-25 01:19:47.509842
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    int_0 = -3924
    net_b_s_d_virtual_0 = NetBSDVirtual(int_0, int_0)
    ret_0 = net_b_s_d_virtual_0.get_virtual_facts()
    assert ret_0 == {
        'virtualization_role': 'guest',
        'virtualization_type': 'xen',
        'virtual_tech_guest': set(['xen']),
        'virtual_tech_host': set(['xen']),
    }


# Generated at 2022-06-25 01:19:50.594225
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    int_0 = -3083
    net_b_s_d_virtual_0 = NetBSDVirtual(int_0, int_0)


# Generated at 2022-06-25 01:19:57.489827
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
  int_0 = -3083
  net_b_s_d_virtual_0 = NetBSDVirtual(int_0, int_0)
  var_0 = net_b_s_d_virtual_0.get_virtual_facts()
  var_1 = net_b_s_d_virtual_0.get_virtual_facts()
  assert var_0['virtualization_role'] == 'guest'
  assert var_0['virtualization_type'] == 'xen'
  assert var_0['virtualization_tech_guest'] == set(['xen'])
  assert var_0['virtualization_tech'] == set(['xen'])


# Generated at 2022-06-25 01:20:01.961569
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    int_0 = -3083
    net_b_s_d_virtual_0 = NetBSDVirtual(int_0, int_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    var_1 = net_b_s_d_virtual_0.get_virtual_facts()
    assert var_0
    assert var_1


# Generated at 2022-06-25 01:20:07.378639
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    int_0 = -3099
    net_b_s_d_virtual_0 = NetBSDVirtual(int_0, int_0)
    # No exception should be thrown


# Generated at 2022-06-25 01:20:12.135338
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    int_0 = -3083
    net_b_s_d_virtual_0 = NetBSDVirtual(int_0, int_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    var_1 = net_b_s_d_virtual_0.get_virtual_facts()
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector(int_0, net_b_s_d_virtual_0)

# Generated at 2022-06-25 01:20:16.754652
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual(int_0, int_0)
    assert net_b_s_d_virtual_0.facts == {}, 'Failed to create NetBSDVirtual!'

# Generated at 2022-06-25 01:20:20.876530
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    int_0 = -3083
    net_b_s_d_virtual_0 = NetBSDVirtual(int_0, int_0)
    assert net_b_s_d_virtual_0._platform == 'NetBSD'
    assert net_b_s_d_virtual_0.platform == 'NetBSD'


# Generated at 2022-06-25 01:20:28.269685
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    int_0 = -10
    net_b_s_d_virtual_0 = NetBSDVirtual(int_0, int_0)


# Generated at 2022-06-25 01:20:30.189220
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    int_0 = -1084
    net_b_s_d_virtual_0 = NetBSDVirtual(int_0, int_0)


# Generated at 2022-06-25 01:20:36.879816
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    int_0 = -3083
    net_b_s_d_virtual_0 = NetBSDVirtual(int_0, int_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()

if __name__ == '__main__':
    test_NetBSDVirtual_get_virtual_facts()
    test_case_0()

# Generated at 2022-06-25 01:20:38.351591
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    int_0 = -3083
    net_b_s_d_virtual_0 = NetBSDVirtual(int_0, int_0)
    var_2 = net_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:20:43.793253
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts_local = net_b_s_d_virtual_0.get_virtual_facts()
    virtual_facts_remote = net_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:20:49.248530
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    int_0 = -3083
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector(int_0, net_b_s_d_virtual_0)
    net_b_s_d_virtual_0 = NetBSDVirtual(int_0, int_0)
    var_1 = net_b_s_d_virtual_0.get_virtual_facts()
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:20:52.400327
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()

# Generated at 2022-06-25 01:20:54.465202
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    # Constructor does not take any arguments.
    assert NetBSDVirtualCollector()

# Generated at 2022-06-25 01:20:56.058030
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    assert NetBSDVirtual


# Generated at 2022-06-25 01:20:58.025060
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    with pytest.raises(SystemExit):
        NetBSDVirtual(sys.argv, sys.argv)


# Generated at 2022-06-25 01:21:11.990922
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    int_0 = -3083
    net_b_s_d_virtual_0 = NetBSDVirtual(int_0, int_0)

# Generated at 2022-06-25 01:21:15.755344
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    int_1 = -63
    net_b_s_d_virtual_1 = NetBSDVirtual(int_1, int_1)
    assert net_b_s_d_virtual_1.get_virtual_facts() == {
        'virtualization_role': 'guest',
        'virtualization_type': 'xen',
        'virtualization_tech_guest': set(['xen']),
        'virtualization_tech_host': set()}

# Generated at 2022-06-25 01:21:22.084947
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    int_0 = -1138
    net_b_s_d_virtual_0 = NetBSDVirtual(int_0, int_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    var_1 = net_b_s_d_virtual_0.get_virtual_facts()
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector(int_0, net_b_s_d_virtual_0)

    return False if var_0 is None else True

print(test_case_0())
print(test_NetBSDVirtual())

# Generated at 2022-06-25 01:21:25.107951
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    int_0 = -36
    net_b_s_d_virtual_0 = NetBSDVirtual(int_0, int_0)

# Generated at 2022-06-25 01:21:32.253182
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    int_0 = -3083
    net_b_s_d_virtual_0 = NetBSDVirtual(int_0, int_0)
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector(int_0, net_b_s_d_virtual_0)


# Generated at 2022-06-25 01:21:37.380256
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    int_0 = -3083
    net_b_s_d_virtual_0 = NetBSDVirtual(int_0, int_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 == {'virtualization_role': 'guest', 'virtualization_type': 'xen', 'virtualization_tech_host': set(), 'virtualization_tech_guest': {'xen'}}

# Generated at 2022-06-25 01:21:40.827553
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    int_0 = -3083
    net_b_s_d_virtual_0 = NetBSDVirtual(int_0, int_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    var_1 = net_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:21:43.227096
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    int_0 = -3083
    net_b_s_d_virtual_0 = NetBSDVirtual(int_0, int_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:21:53.054837
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    int_0 = 0
    net_b_s_d_virtual_1 = NetBSDVirtual(int_0, int_0)
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector(int_0, net_b_s_d_virtual_1)
    assert net_b_s_d_virtual_collector_0._platform == "NetBSD"
    assert net_b_s_d_virtual_collector_0._fact_class == NetBSDVirtual
    assert net_b_s_d_virtual_collector_0._fact_class._platform == "NetBSD"
    assert net_b_s_d_virtual_collector_0.collect() == {}
    #assert net_b_s_d_virtual_collector_0.post_collect() == None

# Unit

# Generated at 2022-06-25 01:21:56.266528
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    int_0 = -3083
    net_b_s_d_virtual_0 = NetBSDVirtual(int_0, int_0)
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector(int_0, net_b_s_d_virtual_0)


# Generated at 2022-06-25 01:22:24.966415
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    var_3 = NetBSDVirtual(0, 0)

# Generated at 2022-06-25 01:22:26.879158
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()


if __name__ == '__main__':
    import pytest
    pytest.main()

# Generated at 2022-06-25 01:22:28.805956
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    int_0 = -1140
    net_b_s_d_virtual_0 = NetBSDVirtual(int_0, int_0)


# Generated at 2022-06-25 01:22:30.256537
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtualizer = NetBSDVirtual()
    assert(virtualizer.get_virtual_facts()['virtualization_type'] != '')


# Generated at 2022-06-25 01:22:32.491477
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    int_0 = -16211
    net_b_s_d_virtual_0 = NetBSDVirtual(int_0, int_0)
    net_b_s_d_virtual_1 = NetBSDVirtual(int_0, int_0)
    assert True


# Generated at 2022-06-25 01:22:35.320531
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    int_0 = -3083
    net_b_s_d_virtual_0 = NetBSDVirtual(int_0, int_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    var_1 = net_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 == var_1


# Generated at 2022-06-25 01:22:39.755387
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    int_0 = -17505
    net_b_s_d_virtual_0 = NetBSDVirtual(int_0, int_0)
    result = net_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:22:40.720941
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    pass


# Generated at 2022-06-25 01:22:43.029765
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    int_0 = -16279
    net_b_s_d_virtual_0 = NetBSDVirtual(int_0, int_0)
    var_2 = net_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:22:51.243902
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    int_0 = -3083
    net_b_s_d_virtual_0 = NetBSDVirtual(int_0, int_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    var_1 = net_b_s_d_virtual_0.get_virtual_facts()
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector(int_0, net_b_s_d_virtual_0)


# Generated at 2022-06-25 01:23:53.908179
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    int_0 = -3083
    net_b_s_d_virtual_0 = NetBSDVirtual(int_0, int_0)
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector(int_0, net_b_s_d_virtual_0)


# Generated at 2022-06-25 01:23:58.639693
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual(int_0, int_0)


# Generated at 2022-06-25 01:23:59.515204
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual(1, 1)


# Generated at 2022-06-25 01:24:03.542049
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    int_0 = -3083
    net_b_s_d_virtual_0 = NetBSDVirtual(int_0, int_0)
    var_2 = net_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:24:08.475015
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    int_0 = -3083
    net_b_s_d_virtual_0 = NetBSDVirtual(int_0, int_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    var_1 = net_b_s_d_virtual_0.get_virtual_facts()
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector(int_0, net_b_s_d_virtual_0)


# Generated at 2022-06-25 01:24:11.708495
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    int_0 = -3083
    net_b_s_d_virtual_0 = NetBSDVirtual(int_0, int_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    # assert type(var_0) == 'dict'


# Generated at 2022-06-25 01:24:13.068069
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    int_0 = -4
    net_b_s_d_virtual_0 = NetBSDVirtual(int_0, int_0)


# Generated at 2022-06-25 01:24:23.068893
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    # Create the ten_zero variable, if necessary
    try:
        if hasattr(test_NetBSDVirtual, 'ten_zero'):
            del test_NetBSDVirtual.ten_zero
        test_NetBSDVirtual.ten_zero = 10
        setattr(test_NetBSDVirtual, 'ten_zero', 10)
    except AttributeError:
        # Create the ten_zero variable
        test_NetBSDVirtual.ten_zero = 10
    # Assign the value ten_zero to the variable ten_zero
    ten_zero = test_NetBSDVirtual.ten_zero
    # Create the ten_zero variable, if necessary

# Generated at 2022-06-25 01:24:25.053627
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    assert net_b_s_d_virtual_collector_0.get_virtual_facts() == var_1


# Generated at 2022-06-25 01:24:29.556168
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    int_0 = -3083
    net_b_s_d_virtual_0 = NetBSDVirtual(int_0, int_0)
    var_2 = net_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:27:03.655801
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # TODO: Pytest doesn't run this test
    pass

# Generated at 2022-06-25 01:27:04.893773
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    int_0 = -3083
    net_b_s_d_virtual_0 = NetBSDVirtual(int_0, int_0)


# Generated at 2022-06-25 01:27:11.990225
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    int_0 = -3083
    net_b_s_d_virtual_0 = NetBSDVirtual(int_0, int_0)
    var_2 = net_b_s_d_virtual_0.get_virtual_facts()
    # Asserts that the two parameters are equal
    assert var_2 == {'virtualization_type': '', 'virtualization_role': '', 'virtualization_tech_host': set(), 'virtualization_tech_guest': set()}


# Generated at 2022-06-25 01:27:18.016814
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    int_0 = -3083
    net_b_s_d_virtual_1 = NetBSDVirtual(int_0, int_0, int_0)
    assert net_b_s_d_virtual_1.get_virtual_facts() == {}


# Generated at 2022-06-25 01:27:19.434265
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    int_0 = -2
    net_b_s_d_virtual_0 = NetBSDVirtual(int_0, int_0)


# Generated at 2022-06-25 01:27:24.358252
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    test_case_0()

# Generated at 2022-06-25 01:27:25.995853
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    assert isinstance(NetBSDVirtual(1, 2)._fact_class, NetBSDVirtual)
    assert NetBSDVirtual(1, 2)._platform == 'NetBSD'


# Generated at 2022-06-25 01:27:31.487047
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    int_0 = -3083
    net_b_s_d_virtual_0 = NetBSDVirtual(int_0, int_0)
    assert net_b_s_d_virtual_0.platform == 'NetBSD'

# Generated at 2022-06-25 01:27:34.412780
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    int_0 = -751
    net_b_s_d_virtual_0 = NetBSDVirtual(int_0, int_0)
    assert net_b_s_d_virtual_0.platform == 'NetBSD'


# Generated at 2022-06-25 01:27:42.426055
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    int_0 = -3083
    net_b_s_d_virtual_0 = NetBSDVirtual(int_0, int_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    var_1 = net_b_s_d_virtual_0.get_virtual_facts()
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector(int_0, net_b_s_d_virtual_0)
