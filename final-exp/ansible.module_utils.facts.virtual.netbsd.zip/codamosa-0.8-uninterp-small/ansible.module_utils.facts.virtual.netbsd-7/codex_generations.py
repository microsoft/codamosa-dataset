

# Generated at 2022-06-25 01:18:11.272629
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()


# Generated at 2022-06-25 01:18:21.439112
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    dmidecode_output = {'NetBSD': {'machdep.dmi.system-product': 'VirtualBox',
                                   'machdep.dmi.system-vendor': 'Oracle Corporation',
                                   'machdep.hypervisor': 'VMM'}}
    net_bsd_virtual = NetBSDVirtual('NetBSD')
    result = net_bsd_virtual.get_virtual_facts(dmidecode_output)

# Generated at 2022-06-25 01:18:27.821045
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    assert net_b_s_d_virtual_0.get_virtual_facts() == {
        'virtualization_role': 'guest',
        'virtualization_type': 'xen',
        'virtualization_tech_host': set(['xen']),
        'virtualization_tech_guest': set(['xen'])}


# Generated at 2022-06-25 01:18:30.090917
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    assert net_b_s_d_virtual_0 is not None


# Generated at 2022-06-25 01:18:40.519604
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    net_b_s_d_virtual_0._load_virtual_facts_subset = lambda subset: [
        {
            'fact_name': 'machdep.dmi.system-vendor',
            'fact_data': 'Microsoft Corporation'
        },
        {
            'fact_name': 'machdep.hypervisor',
            'fact_data': 'Hyper-V'
        },
        {
            'fact_name': 'machdep.dmi.system-product',
            'fact_data': 'Virtual Machine'
        }
    ]
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()

# Generated at 2022-06-25 01:18:43.137861
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    assert net_b_s_d_virtual_0.get_virtual_facts() is None


# Generated at 2022-06-25 01:18:45.726373
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_1 = NetBSDVirtualCollector()


# Generated at 2022-06-25 01:18:47.636335
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()


# Generated at 2022-06-25 01:18:48.818228
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual = NetBSDVirtual()


# Generated at 2022-06-25 01:18:50.320581
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()


# Generated at 2022-06-25 01:18:54.537124
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    assert NetBSDVirtual.get_virtual_facts() == {}

# Generated at 2022-06-25 01:18:56.571864
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    net_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:18:58.192477
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual = NetBSDVirtual()


# Generated at 2022-06-25 01:19:03.404946
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()
    assert net_b_s_d_virtual_collector_0 is not None


# Generated at 2022-06-25 01:19:04.455340
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual({})

# Stub out sysctl and open

# Generated at 2022-06-25 01:19:10.371574
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual({})
    assert callable(net_b_s_d_virtual_0.get_virtual_facts)


# Generated at 2022-06-25 01:19:15.230240
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    net_b_s_d_virtual_0 = NetBSDVirtual(
        _module=None,
        _sysctl_finder=None,
        _sysctl=None
    )


# Generated at 2022-06-25 01:19:18.140599
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual = NetBSDVirtual()
    assert net_b_s_d_virtual.get_virtual_facts() is None


# Generated at 2022-06-25 01:19:24.031071
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    assert net_b_s_d_virtual_0.platform == 'NetBSD'


# Generated at 2022-06-25 01:19:28.752200
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    """
    Test method get_virtual_facts of class NetBSDVirtual
    """

    # Setup
    net_b_s_d_virtual = NetBSDVirtual()
    # target_method = net_b_s_d_virtual.get_virtual_facts

    # Exercise
    # result = target_method()

    # Verify

    # Cleanup



# Generated at 2022-06-25 01:19:37.328073
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual = NetBSDVirtual()
    net_b_s_d_virtual.get_virtual_facts()

# Generated at 2022-06-25 01:19:42.291706
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    net_b_s_d_virtual_0.get_virtual_facts()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 01:19:48.208155
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    assert isinstance(net_b_s_d_virtual_0, Virtual)
    assert isinstance(net_b_s_d_virtual_0, NetBSDVirtual)
    assert net_b_s_d_virtual_0.platform == NetBSDVirtual.platform


# Generated at 2022-06-25 01:19:49.382992
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual = NetBSDVirtual(None)



# Generated at 2022-06-25 01:19:51.659561
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()


# Generated at 2022-06-25 01:19:53.921758
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual = NetBSDVirtual()


if __name__ == '__main__':
    test_case_0()
    test_NetBSDVirtual()

# Generated at 2022-06-25 01:19:57.151924
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual = NetBSDVirtual()
    virtual_facts = net_b_s_d_virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'

# Generated at 2022-06-25 01:19:58.241348
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()


# Generated at 2022-06-25 01:20:00.033027
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtualCollector()._fact_class()


# Generated at 2022-06-25 01:20:01.458305
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector = NetBSDVirtualCollector()


# Generated at 2022-06-25 01:20:17.763202
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()


# Generated at 2022-06-25 01:20:18.987008
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()


# Generated at 2022-06-25 01:20:21.625077
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    result = net_b_s_d_virtual_0.get_virtual_facts()
    assert result is not None


# Generated at 2022-06-25 01:20:24.296973
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    pass

# Generated at 2022-06-25 01:20:28.373906
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()
    net_b_s_d_virtual_0 = net_b_s_d_virtual_collector_0.get_virtual_facts()

if __name__ == '__main__':
    test_case_0()
    test_NetBSDVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:20:31.445972
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    test_case_0_net_b_s_d_virtual_get_virtual_facts = NetBSDVirtual().get_virtual_facts()

# Generated at 2022-06-25 01:20:35.421933
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():

    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()


# Generated at 2022-06-25 01:20:38.419248
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    # Test with parameter 'None' in constructor
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector(None)
    assert net_b_s_d_virtual_collector_0._platform == 'NetBSD'


# Generated at 2022-06-25 01:20:40.048588
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    net_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:20:42.775318
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()

# Generated at 2022-06-25 01:20:59.140841
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    int_0 = 565
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector(int_0)
    net_b_s_d_virtual_0 = NetBSDVirtual(net_b_s_d_virtual_collector_0)
    assert net_b_s_d_virtual_0


# Generated at 2022-06-25 01:21:08.008256
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    int_0 = 731
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector(int_0)
    assert net_b_s_d_virtual_collector_0._platform.__eq__('NetBSD'), "Expected: False Got: %s" % net_b_s_d_virtual_collector_0._platform
    assert net_b_s_d_virtual_collector_0._fact_class.__eq__(NetBSDVirtual), "Expected: False Got: %s" % net_b_s_d_virtual_collector_0._fact_class
    bytes_0 = b'D3\xeb\x84\x82(mGr\x9a \r\xe6'
    net_b_s_d_virtual_collector_1 = NetBSDVirtual

# Generated at 2022-06-25 01:21:11.599675
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    int_0 = 731
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector(int_0)
    bytes_0 = b'D3\xeb\x84\x82(mGr\x9a \r\xe6'
    net_b_s_d_virtual_collector_1 = NetBSDVirtualCollector(bytes_0)
    print(str(net_b_s_d_virtual_collector_1._platform))


# Generated at 2022-06-25 01:21:16.910108
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    int_0 = 701
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector(int_0)
    bytes_0 = b'\x80\xf4\x86\x9e\x1f\x92\x86w\xfb\xbf\xb7\xf0z\xaf\x9f\x9f\xe1'
    net_b_s_d_virtual_collector_1 = NetBSDVirtualCollector(bytes_0)
    net_b_s_d_virtual_0 = NetBSDVirtual(net_b_s_d_virtual_collector_1)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:21:21.970395
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    int_0 = 500
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector(int_0)
    bytes_0 = b'\x88\x1c\x08\x01\x9d\x8a\x02\x10\x97\x12\x8a\x01\x9a\x9d\x9a\x10\x10\x12\x01'
    net_b_s_d_virtual_0 = NetBSDVirtual(net_b_s_d_virtual_collector_0, bytes_0)


# Generated at 2022-06-25 01:21:32.288754
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    int_0 = 731
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector(int_0)
    bytes_0 = b'D3\xeb\x84\x82(mGr\x9a \r\xe6'
    net_b_s_d_virtual_collector_1 = NetBSDVirtualCollector(bytes_0)
    net_b_s_d_virtual_0 = NetBSDVirtual(net_b_s_d_virtual_collector_1)
    int_1 = 731
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector(int_1)
    bytes_0 = b'D3\xeb\x84\x82(mGr\x9a \r\xe6'
    net_b_

# Generated at 2022-06-25 01:21:33.671368
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    obj = NetBSDVirtual()
    assert type(obj.get_virtual_facts()) == dict


# Generated at 2022-06-25 01:21:40.712292
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    os_path_exists_0 = os.path.exists('/dev/xencons')
    int_0 = 731
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector(int_0)
    bytes_0 = b'D3\xeb\x84\x82(mGr\x9a \r\xe6'
    net_b_s_d_virtual_collector_1 = NetBSDVirtualCollector(bytes_0)
    net_b_s_d_virtual_0 = NetBSDVirtual(net_b_s_d_virtual_collector_1)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:21:41.360997
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    test_case_0()

# Generated at 2022-06-25 01:21:43.587602
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    try:
        net_b_s_d_virtual_0 = NetBSDVirtual(5)
    except Exception as e:
        assert(isinstance(e, TypeError))


# Generated at 2022-06-25 01:22:19.094495
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    int_0 = 731
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector(int_0)
    bytes_0 = b'D3\xeb\x84\x82(mGr\x9a \r\xe6'
    net_b_s_d_virtual_collector_1 = NetBSDVirtualCollector(bytes_0)
    net_b_s_d_virtual_0 = NetBSDVirtual(net_b_s_d_virtual_collector_1)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:22:29.744582
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    int_0 = 730
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector(int_0)
    net_b_s_d_virtual_0 = NetBSDVirtual(net_b_s_d_virtual_collector_0)
    bytes_0 = b'D3\xeb\x84\x82(mGr\x9a\x1b'
    net_b_s_d_virtual_collector_1 = NetBSDVirtualCollector(bytes_0)
    net_b_s_d_virtual_1 = NetBSDVirtual(net_b_s_d_virtual_collector_1)
    bytes_1 = b'D3\xeb\x84\x82(mGr\x9a)r'
    net_b_s_d_virtual_

# Generated at 2022-06-25 01:22:33.839460
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    int_0 = 731
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector(int_0)
    bytes_0 = b'D3\xeb\x84\x82(mGr\x9a \r\xe6'
    net_b_s_d_virtual_collector_1 = NetBSDVirtualCollector(bytes_0)
    assert isinstance(net_b_s_d_virtual_collector_1, NetBSDVirtualCollector)


# Generated at 2022-06-25 01:22:42.633585
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    int_0 = 731
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector(int_0)
    bytes_0 = b'D3\xeb\x84\x82(mGr\x9a \r\xe6'
    net_b_s_d_virtual_collector_1 = NetBSDVirtualCollector(bytes_0)
    net_b_s_d_virtual_0 = NetBSDVirtual(net_b_s_d_virtual_collector_1)
    assert net_b_s_d_virtual_0 is not None


# Generated at 2022-06-25 01:22:52.256927
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    int_0 = 731
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector(int_0)
    bytes_0 = b'D3\xeb\x84\x82(mGr\x9a \r\xe6'
    net_b_s_d_virtual_collector_1 = NetBSDVirtualCollector(bytes_0)
    net_b_s_d_virtual_0 = NetBSDVirtual(net_b_s_d_virtual_collector_1)
    assert net_b_s_d_virtual_0._platform == 'NetBSD', 'Expected platform is NetBSD'



# Generated at 2022-06-25 01:22:55.842882
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    assert test_case_0() == 'D3\xeb\x84\x82(mGr\x9a \r\xe6'


# Generated at 2022-06-25 01:23:02.118407
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    int_0 = 731
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector(int_0)
    bytes_0 = b'D3\xeb\x84\x82(mGr\x9a \r\xe6'
    net_b_s_d_virtual_collector_1 = NetBSDVirtualCollector(bytes_0)
    assert net_b_s_d_virtual_collector_1._platform == 'NetBSD'


# Generated at 2022-06-25 01:23:08.287476
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()
    net_b_s_d_virtual_0 = NetBSDVirtual(net_b_s_d_virtual_collector_0)
    net_b_s_d_virtual_0 = NetBSDVirtual(net_b_s_d_virtual_collector_0)


# Generated at 2022-06-25 01:23:18.713054
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    int_0 = 731
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector(int_0)
    bytes_0 = b'\xe8\x8f\x80\xde\x90\xa2\xeb\xbf\x9e\x84\x89\x91\x97\xb7\xcc'
    net_b_s_d_virtual_collector_1 = NetBSDVirtualCollector(bytes_0)
    net_b_s_d_virtual_0 = NetBSDVirtual(net_b_s_d_virtual_collector_1)
    assert_raises(Exception, net_b_s_d_virtual_0.get_virtual_facts, '') # The parameter must be of type dict
    # TODO: Current implementation of get_virtual

# Generated at 2022-06-25 01:23:22.865943
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()
    net_b_s_d_virtual_0 = NetBSDVirtual(net_b_s_d_virtual_collector_0)


# Generated at 2022-06-25 01:24:46.050706
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual(VirtualCollector())
    net_b_s_d_virtual_0.detect_virt_vendor = MagicMock()
    net_b_s_d_virtual_0.detect_virt_product = MagicMock()
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    assert var_0.get('virtualization_type') == ''
    assert var_0.get('virtualization_role') == ''
    assert var_0.get('virtualization_tech_guest') == set()
    assert var_0.get('virtualization_tech_host') == set()

# Generated at 2022-06-25 01:24:53.955841
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    int_0 = 731
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector(int_0)
    bytes_1 = b'\xc9\xab\xf3\xaa"\xa8\xe2\x15\x1f\x16\xf8\x9a\xdc'
    net_b_s_d_virtual_1 = NetBSDVirtual(net_b_s_d_virtual_collector_0, bytes_1)
    bytes_0 = b'\xdb\x04\xae\x12z\xdb\x04\xae\x12z\xdb\x04\xae\x12z'

# Generated at 2022-06-25 01:24:58.705033
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    int_0 = 539
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector(int_0)
    net_b_s_d_virtual_0 = NetBSDVirtual(net_b_s_d_virtual_collector_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:25:00.517269
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual = NetBSDVirtual()
    assert net_b_s_d_virtual is not None


# Generated at 2022-06-25 01:25:06.023208
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    try:
        int_0 = 731
        net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector(int_0)
        bytes_0 = b'D3\xeb\x84\x82(mGr\x9a \r\xe6'
        net_b_s_d_virtual_collector_1 = NetBSDVirtualCollector(bytes_0)
        net_b_s_d_virtual_0 = NetBSDVirtual(net_b_s_d_virtual_collector_1)
        var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    except Exception:
        assert False



# Generated at 2022-06-25 01:25:11.911606
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    int_0 = 691
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector(int_0)
    bytes_0 = b'\x9d\xf4\xbf\xd8\x06\x90\xda\xea\x8d\x1d'
    net_b_s_d_virtual_collector_1 = NetBSDVirtualCollector(bytes_0)
    net_b_s_d_virtual_0 = NetBSDVirtual(net_b_s_d_virtual_collector_1)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:25:17.195748
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector(None)
    net_b_s_d_virtual_0 = NetBSDVirtual(net_b_s_d_virtual_collector_0)
    assert net_b_s_d_virtual_0._platform == 'NetBSD'


# Generated at 2022-06-25 01:25:26.415913
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    int_0 = 0
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector(int_0)
    bytes_0 = b'\x00\x00\x00\x00\x00\x00\x00\x00'
    net_b_s_d_virtual_collector_1 = NetBSDVirtualCollector(bytes_0)
    net_b_s_d_virtual_0 = NetBSDVirtual(net_b_s_d_virtual_collector_1)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    bytes_1 = b'\x00\x00\x00\x00\x00\x00\x00\x00'
    net_b_s_d_virtual_collector_2

# Generated at 2022-06-25 01:25:28.560892
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    int_0 = 585
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector(int_0)


# Generated at 2022-06-25 01:25:34.563629
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    int_0 = 731
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector(int_0)
    bytes_0 = b'D3\xeb\x84\x82(mGr\x9a \r\xe6'
    net_b_s_d_virtual_collector_1 = NetBSDVirtualCollector(bytes_0)
    net_b_s_d_virtual_0 = NetBSDVirtual(net_b_s_d_virtual_collector_1)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    assert var_0['virtualization_tech_guest']==set(['xen'])
    assert var_0['virtualization_type']=='xen'
