

# Generated at 2022-06-25 01:18:10.300425
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()

# Generated at 2022-06-25 01:18:21.359541
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual(None)
    # Test with missing sysctl machdep.dmi.system-product.
    net_b_s_d_virtual_0.get_sysctl_virtual_facts = lambda fact: '', '', ''
    net_b_s_d_virtual_0.get_sysctl_virtual_facts = lambda fact: '', '', ''
    virtual_facts = net_b_s_d_virtual_0.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    # Test with VMware ESXi
    net_b_s_d_virtual_0.get_sysctl_virtual_facts = lambda fact: 'VMware ESXi', '', 'VMware ESXi'

# Generated at 2022-06-25 01:18:25.813982
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    bool_0 = False
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector(bool_0)


if __name__ == '__main__':
    test_NetBSDVirtualCollector()
    test_case_0()

# Generated at 2022-06-25 01:18:27.360762
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()

# Generated at 2022-06-25 01:18:29.305582
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    bool_0 = False
    net_b_s_d_virtual_0 = NetBSDVirtual(bool_0)


# Generated at 2022-06-25 01:18:35.569778
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    bool_0 = False
    net_b_s_d_virtual_0 = NetBSDVirtual(bool_0)
    # Input data is valid
    virtual = net_b_s_d_virtual_0.get_virtual_facts()
    assert virtual['virtualization_type'] == ''
    assert virtual['virtualization_role'] == ''



# Generated at 2022-06-25 01:18:39.639014
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    bool_0 = False
    net_b_s_d_virtual_0 = NetBSDVirtual(bool_0)
    net_b_s_d_virtual_0.facts = dict()
    net_b_s_d_virtual_0.sysctl = dict()
    dict_0 = net_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:18:42.734338
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    bool_0 = False
    net_b_s_d_virtual_0 = NetBSDVirtual(bool_0)


# Generated at 2022-06-25 01:18:48.403844
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    bool_0 = False
    net_b_s_d_virtual_0 = NetBSDVirtual(bool_0)
    #net_b_s_d_virtual_0.get_virtual_facts()

    print(net_b_s_d_virtual_0.virtual_facts)


if __name__ == "__main__":
    test_NetBSDVirtual()

# Generated at 2022-06-25 01:18:51.491729
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    bool_0 = False
    net_b_s_d_virtual_0 = NetBSDVirtual(bool_0)

    # Run method get_virtual_facts
    net_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:18:56.884763
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual = NetBSDVirtual()


# Generated at 2022-06-25 01:19:04.614972
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    # Load facts by calling get_virtual_facts function
    # Check the facts by calling the following function and check if they are not empty.
    # get_virtual_facts()
    net_bsd_virtual = NetBSDVirtualCollector()
    netbsd_virtual_facts = net_bsd_virtual.get_virtual_facts()

    assert netbsd_virtual_facts['virtualization_type'] is not None
    assert netbsd_virtual_facts['virtualization_type'] != ''
    assert netbsd_virtual_facts['virtualization_role'] is not None
    assert netbsd_virtual_facts['virtualization_type'] != ''
    assert netbsd_virtual_facts['virtualization_technology'] is not None
    assert netbsd_virtual_facts['virtualization_technology'] != ''
    assert netbsd_virtual_facts

# Generated at 2022-06-25 01:19:10.874268
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()
    # Testing instance of NetBSDVirtualCollector
    assert isinstance(net_b_s_d_virtual_collector_0,NetBSDVirtualCollector)

# Generated at 2022-06-25 01:19:14.484160
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual = NetBSDVirtual()
    assert net_b_s_d_virtual.get_virtual_facts()

# Generated at 2022-06-25 01:19:15.661166
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()

# Generated at 2022-06-25 01:19:18.806627
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'

# Generated at 2022-06-25 01:19:26.040640
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    assert(net_b_s_d_virtual_0.get_virtual_facts() == {
        'virtualization_role': '',
        'virtualization_type': '',
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': set()
    })


# Generated at 2022-06-25 01:19:28.710812
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    net_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:19:30.533425
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()
    assert net_b_s_d_virtual_collector_0._platform == 'NetBSD'

# Generated at 2022-06-25 01:19:34.379743
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()


# Generated at 2022-06-25 01:19:41.092414
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()


# Generated at 2022-06-25 01:19:43.140535
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    ansible_facts_0 = net_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:19:54.518205
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    # Check is instance created properly
    assert isinstance(net_b_s_d_virtual_collector_0._fact_class(), Virtual)

    # Check if the instance can detect the type of virtualization
    assert net_b_s_d_virtual_collector_0._fact_class().get_virtual_facts()['virtualization_type'] == 'xen'

    # Check if the instance can detect the type of virtualization tech
    assert net_b_s_d_virtual_collector_0._fact_class().get_virtual_facts()['virtualization_tech_guest'] == {'xen'}

    # Check if the instance can detect the type of virtualization role

# Generated at 2022-06-25 01:19:59.188710
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_collector = NetBSDVirtualCollector()
    net_b_s_d_virtual = NetBSDVirtual(net_b_s_d_virtual_collector.sysctl, net_b_s_d_virtual_collector.lsb_release, net_b_s_d_virtual_collector.platform)
    net_b_s_d_virtual.get_virtual_facts()

# Generated at 2022-06-25 01:20:01.289527
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    collector = NetBSDVirtualCollector()
    assert collector._platform == 'NetBSD'
    assert collector._fact_class.platform == 'NetBSD'


# Generated at 2022-06-25 01:20:03.098540
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    assert net_b_s_d_virtual_0.platform == 'NetBSD'


# Generated at 2022-06-25 01:20:06.584436
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_1 = NetBSDVirtualCollector()


# Generated at 2022-06-25 01:20:07.981435
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector = NetBSDVirtualCollector()


# Generated at 2022-06-25 01:20:13.701245
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert hasattr(NetBSDVirtualCollector, '_fact_class')
    assert NetBSDVirtualCollector._fact_class == NetBSDVirtual

    assert hasattr(NetBSDVirtualCollector, '_platform')
    assert NetBSDVirtualCollector._platform == 'NetBSD'


# Generated at 2022-06-25 01:20:16.863596
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()

# Generated at 2022-06-25 01:20:25.121557
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()


# Generated at 2022-06-25 01:20:31.345902
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    # Create an instance of the module
    net_b_s_d_virtual_collector = NetBSDVirtualCollector()
    net_b_s_d_virtual_collector_str = repr(net_b_s_d_virtual_collector)
    net_b_s_d_virtual_collector_str_matcher = "NetBSDVirtualCollector\(platform='NetBSD'\)"
    # Compare constructed string with the expectation
    assert net_b_s_d_virtual_collector_str == net_b_s_d_virtual_collector_str_matcher


# Generated at 2022-06-25 01:20:41.443769
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual(
        module_name='ansible_collections.not_real.not_real_plugins.modules.files.net_b_s_d_virtual',
        sysctl_c_state='not_real',
        sysctl_machdep_dmi_system_product='VMware Virtual Platform',
        sysctl_machdep_dmi_system_vendor='VMware, Inc.'
    )
    virtual_facts = net_b_s_d_virtual_0.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'virtualbox'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert 'virtualbox' in virtual_facts['virtualization_tech_guest']
    assert 'vmware' in virtual

# Generated at 2022-06-25 01:20:45.714734
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    set_module_args({})
    net_b_s_d_virtual_0 = NetBSDVirtual()
    net_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:20:47.239607
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    assert isinstance(net_b_s_d_virtual_collector_0, NetBSDVirtualCollector)


# Generated at 2022-06-25 01:20:51.495389
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()


# Generated at 2022-06-25 01:20:54.486605
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()


# Generated at 2022-06-25 01:20:57.192847
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Test case data
    virtual_facts = NetBSDVirtual().get_virtual_facts()

    # Test assertions
    assert virtual_facts['virtualization_type']

# Generated at 2022-06-25 01:21:02.098614
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual('machdep.dmi.system-vendor')
    pass


# Generated at 2022-06-25 01:21:08.514854
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = NetBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'virtualbox'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert len(virtual_facts['virtualization_tech_guest']) == 2
    assert virtual_facts['virtualization_tech_guest'] == {'vbox', 'hwvirt'}
    assert len(virtual_facts['virtualization_tech_host']) == 0
    assert virtual_facts['virtualization_tech_host'] == set()


# Generated at 2022-06-25 01:21:24.627041
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()


# Generated at 2022-06-25 01:21:26.076389
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual(dict())


# Generated at 2022-06-25 01:21:28.075764
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual = NetBSDVirtual()
    net_b_s_d_virtual.get_virtual_facts()


# Generated at 2022-06-25 01:21:32.852204
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()

    assert net_b_s_d_virtual_0.virtualization_type is not None



# Generated at 2022-06-25 01:21:34.676872
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()


# Generated at 2022-06-25 01:21:37.344186
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    # Test setting instance attribute virtualization_type when not in host_tech
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()
    assert net_b_s_d_virtual_collector_0.virtualization_type == []

# Generated at 2022-06-25 01:21:40.150113
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts_2 = {'virtualization_role': '', 'virtualization_type': '', 'virtualization_tech_host': set(), 'virtualization_tech_guest': set()}

    assert virtual_facts_2 == NetBSDVirtual(None).get_virtual_facts()

# Generated at 2022-06-25 01:21:42.203420
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector = NetBSDVirtualCollector()
    assert net_b_s_d_virtual_collector._platform == 'NetBSD'

# Generated at 2022-06-25 01:21:43.867343
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    # Creating an object of the class NetBSDVirtualCollector
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()


# Generated at 2022-06-25 01:21:48.757153
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    net_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:22:18.979945
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    module_args = dict()
    net_b_s_d_virtual_0 = NetBSDVirtual(module_args, platform="TestPlatform")
    assert net_b_s_d_virtual_0.platform == "TestPlatform"



# Generated at 2022-06-25 01:22:29.606181
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()

    # Testing with one fixture
    with_fixtures = [
        {
            'fixture': [],
            'expected': {
                'virtualization_type': '',
                'virtualization_role': '',
                'virtualization_system': '',
                'virtualization_product': '',
                'virtualization_tech_guest': set([]),
                'virtualization_tech_host': set([]),
            }
        }
    ]

    # Testing with fixtures
    for test_data in with_fixtures:
        test_params, expected = test_data['fixture'], test_data['expected']
        actual = net_b_s_d_virtual_0.get_virtual_facts(*test_params)
        assert actual == expected

# Generated at 2022-06-25 01:22:30.570360
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()


# Generated at 2022-06-25 01:22:31.881818
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()


# Generated at 2022-06-25 01:22:35.478383
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    assert net_b_s_d_virtual_0.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
        'virt_subsystem': 'NetBSD'
        }

# Generated at 2022-06-25 01:22:36.220216
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()

# Generated at 2022-06-25 01:22:36.926794
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()


# Generated at 2022-06-25 01:22:39.360628
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    # Constructor
    net_b_s_d_virtual_0 = NetBSDVirtual()

    assert net_b_s_d_virtual_0 is not None


# Generated at 2022-06-25 01:22:41.926381
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    print('Test for method get_virtual_facts of class NetBSDVirtual')
    net_b_s_d_virtual_0 = NetBSDVirtual()
    net_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:22:43.757389
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()


# Generated at 2022-06-25 01:23:56.064847
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_instance_0 = NetBSDVirtual()
    net_b_s_d_virtual_instance_0.sysctl_virtual_facts('machdep.dmi.system-vendor',
                                                      '/proc/xen', '/proc/xen/capabilities', '', '',
                                                      '/dev/xencons')
    net_b_s_d_virtual_instance_0.detect_virt_product('machdep.dmi.system-product')
    net_b_s_d_virtual_instance_0.detect_virt_vendor('machdep.hypervisor')
    net_b_s_d_virtual_instance_0.get_virtual_facts()

# Generated at 2022-06-25 01:24:02.001460
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert isinstance(net_b_s_d_virtual_collector_0, NetBSDVirtualCollector)
    assert net_b_s_d_virtual_collector_0._platform == 'NetBSD'
    assert net_b_s_d_virtual_collector_0._fact_class == NetBSDVirtual


# Generated at 2022-06-25 01:24:02.864376
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()


# Generated at 2022-06-25 01:24:03.861760
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()


# Generated at 2022-06-25 01:24:06.910035
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    net_b_s_d_virtual_0.get_virtual_facts()

if __name__ == '__main__':
    test_case_0()
    test_NetBSDVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:24:09.994520
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_instance = NetBSDVirtual()
    assert type(net_b_s_d_virtual_instance.get_virtual_facts()) == dict

# Generated at 2022-06-25 01:24:11.253469
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()

# Generated at 2022-06-25 01:24:16.914475
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    with open('file/proc/sysctl') as sysctl_file:
        net_b_s_d_virtual_collector = NetBSDVirtualCollector(sysctl_file)
        return net_b_s_d_virtual_collector


# Generated at 2022-06-25 01:24:22.070638
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()
    net_b_s_d_virtual_0 = net_b_s_d_virtual_collector_0.fetch_virtual_facts()
    assert(net_b_s_d_virtual_0['virtualization_tech_guest'] == set(['xen']))
    assert(net_b_s_d_virtual_0['virtualization_type'] == 'xen')



# Generated at 2022-06-25 01:24:28.650353
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()
    assert net_b_s_d_virtual_collector_0.platform == 'NetBSD'
    assert net_b_s_d_virtual_collector_0.fact_class.platform == 'NetBSD'


# Generated at 2022-06-25 01:27:09.941355
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts = NetBSDVirtual()


# Generated at 2022-06-25 01:27:13.593876
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
  net_b_s_d_virtual = NetBSDVirtual()
  net_b_s_d_virtual_facts = net_b_s_d_virtual.get_virtual_facts()

if __name__ == '__main__':
    test_case_0()
    test_NetBSDVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:27:17.723978
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    net_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:27:18.905013
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector = NetBSDVirtualCollector()


# Generated at 2022-06-25 01:27:19.786483
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()


# Generated at 2022-06-25 01:27:25.086895
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    assert net_b_s_d_virtual_0 is not None


# Generated at 2022-06-25 01:27:28.449490
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    # All values are set to default
    net_b_s_d_virtual = NetBSDVirtual()
    assert net_b_s_d_virtual.virtualization_type == ''
    assert net_b_s_d_virtual.virtualization_role == ''
    assert net_b_s_d_virtual.virtualization_tech_guest == set()
    assert net_b_s_d_virtual.virtualization_tech_host == set()

# Generated at 2022-06-25 01:27:29.238595
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()


# Generated at 2022-06-25 01:27:35.988810
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()
    results = net_b_s_d_virtual_collector_0.get_virtual_facts()
    assert results['virtualization_role'] == '', 'virtualization_role != ""'
    assert results['virtualization_type'] == '', 'virtualization_type != ""'
    assert results['virtualization_tech_guest'] == set(), 'virtualization_tech_guest != <set>'
    assert results['virtualization_tech_host'] == set(), 'virtualization_tech_host != <set>'

# Generated at 2022-06-25 01:27:39.254476
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual = NetBSDVirtual()
    net_b_s_d_virtual.get_virtual_facts()
