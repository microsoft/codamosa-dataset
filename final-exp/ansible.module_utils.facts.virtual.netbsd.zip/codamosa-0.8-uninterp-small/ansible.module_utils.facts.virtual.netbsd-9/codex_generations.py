

# Generated at 2022-06-25 01:18:15.084324
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()

# Generated at 2022-06-25 01:18:18.087236
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    list_0 = None
    net_b_s_d_virtual_0 = NetBSDVirtual(list_0)
    assert net_b_s_d_virtual_0.get_virtual_facts() != {}

# Generated at 2022-06-25 01:18:25.101972
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():

    # Pass empty list as argument
    net_b_s_d_virtual_0 = NetBSDVirtual(list())

    # Pass None as argument
    net_b_s_d_virtual_0 = NetBSDVirtual(None)

    # Pass sysctl dict with values
    net_b_s_d_virtual_0 = NetBSDVirtual({'machdep.dmi.system-product': 'PRODUCT_NAME', 'machdep.dmi.system-vendor': 'VENDOR_NAME', 'machdep.hypervisor': 'HYPERVISOR'})


# Generated at 2022-06-25 01:18:29.865034
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_1 = NetBSDVirtual(
        None,
        )
    virtual_facts_0 = net_b_s_d_virtual_1.get_virtual_facts()
    if len(virtual_facts_0['virtualization_type']) != 0:
        net_b_s_d_virtual_1._fail_json()


# Generated at 2022-06-25 01:18:34.916680
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()
    # Unit test for method NetBSDVirtualCollector.collect()
    net_b_s_d_virtual_collector_0.collect()

# Generated at 2022-06-25 01:18:38.103825
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    list_0 = None
    net_b_s_d_virtual_0 = NetBSDVirtual(list_0)
    virtual_facts = net_b_s_d_virtual_0.get_virtual_facts()
    assert type(virtual_facts) is dict

# Generated at 2022-06-25 01:18:42.216856
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()

# Generated at 2022-06-25 01:18:53.256935
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    list_0 = None
    net_b_s_d_virtual_0 = NetBSDVirtual(list_0)
    net_b_s_d_virtual_0.sysctl_vars = {
        'machdep.dmi.system-product': 'VMware Virtual Platform',
        'machdep.dmi.system-vendor': 'VMware, Inc.',
    }
    net_b_s_d_virtual_0.dmidecode_info = {
        'system-product-name': 'VMware Virtual Platform',
        'system-manufacturer': 'VMware, Inc.',
    }

# Generated at 2022-06-25 01:18:55.736312
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    list_0 = None
    net_b_s_d_virtual_0 = NetBSDVirtual(list_0)
    net_b_s_d_virtual_0 = NetBSDVirtual(list_0)


# Generated at 2022-06-25 01:19:03.572291
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    list_0 = None
    net_b_s_d_virtual_0 = NetBSDVirtual(list_0)
    net_b_s_d_virtual_0._parse_sysctl_mib_machdep_dmi_system_product = Mock(return_value=None)
    net_b_s_d_virtual_0._parse_sysctl_mib_machdep_dmi_system_vendor = Mock(return_value=None)
    net_b_s_d_virtual_0._parse_sysctl_mib_machdep_hypervisor = Mock(return_value=None)
    assert net_b_s_d_virtual_0.get_virtual_facts() == {}

from sysctl import Mock

# Generated at 2022-06-25 01:19:08.288548
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    n = NetBSDVirtual()
    n.get_virtual_facts()

# Generated at 2022-06-25 01:19:09.278044
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()

# Generated at 2022-06-25 01:19:10.066200
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    pass


# Generated at 2022-06-25 01:19:14.000542
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()

if __name__ == '__main__':
    test_case_0()
    test_NetBSDVirtual()

# Generated at 2022-06-25 01:19:19.822584
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()
    net_b_s_d_virtual_0 = NetBSDVirtual()

    result = 'failed'
    assert net_b_s_d_virtual_0.get_virtual_facts()['virtualization_type'] == '', result
    result = 'passed'
    assert net_b_s_d_virtual_0.get_virtual_facts()['virtualization_type'] == '', result

# Generated at 2022-06-25 01:19:23.556763
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()


# Generated at 2022-06-25 01:19:28.168738
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()


# Generated at 2022-06-25 01:19:28.911589
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()


# Generated at 2022-06-25 01:19:30.723925
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    net_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:19:35.420800
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    net_b_s_d_virtual_1 = NetBSDVirtual()


# Generated at 2022-06-25 01:19:44.435734
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():

    float_0 = -23.448
    net_b_s_d_virtual_0 = NetBSDVirtual(float_0)
    assert net_b_s_d_virtual_0.get_virtual_facts() == {'virtualization_type': '', 'virtualization_role': '', 'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}

# Generated at 2022-06-25 01:19:47.761688
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()
    net_b_s_d_virtual_collector_0.collect()

# Generated at 2022-06-25 01:19:52.130594
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    bool_0 = False
    float_0 = -242.8
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector(bool_0, float_0)
    dict_0 = net_b_s_d_virtual_collector_0.collect()


# Generated at 2022-06-25 01:19:55.041933
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    # No sysctl exposed virtualization facts are available
    assert len(net_b_s_d_virtual_0.get_virtual_facts()) == 0


# Generated at 2022-06-25 01:20:00.153443
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    bool_0 = False
    float_0 = -621.5
    net_b_s_d_virtual_0 = NetBSDVirtual(float_0)
    net_b_s_d_virtual_1 = NetBSDVirtual(bool_0, net_b_s_d_virtual_0)
    net_b_s_d_virtual_2 = NetBSDVirtual(float_0, net_b_s_d_virtual_0)


# Generated at 2022-06-25 01:20:01.103947
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    test_case_0()


# Generated at 2022-06-25 01:20:06.413396
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():

    bool_0 = False
    float_0 = -621.5
    net_b_s_d_virtual_0 = NetBSDVirtual(float_0)
    net_b_s_d_virtual_1 = NetBSDVirtual(bool_0, net_b_s_d_virtual_0)
    var_1 = net_b_s_d_virtual_1.get_virtual_facts()
    var_2 = net_b_s_d_virtual_1.get_virtual_facts()
    var_3 = net_b_s_d_virtual_1.get_virtual_facts()
    var_4 = net_b_s_d_virtual_1.get_virtual_facts()
    var_5 = net_b_s_d_virtual_1.get_virtual_facts()

# Generated at 2022-06-25 01:20:13.107447
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
  float_0 = -621.5
  net_b_s_d_virtual_0 = NetBSDVirtual(float_0)
  var_0 = NetBSDVirtual(float_0)
  var_1 = net_b_s_d_virtual_0.get_virtual_facts()
  assert var_1 == var_0

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 01:20:14.930828
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()


# Generated at 2022-06-25 01:20:21.550667
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    # testing constructor
    float_0 = -621.5
    net_b_s_d_virtual_0 = NetBSDVirtual(float_0)
    bool_0 = False
    net_b_s_d_virtual_1 = NetBSDVirtual(bool_0, net_b_s_d_virtual_0)
    net_b_s_d_virtual_0.get_virtual_facts()



# Generated at 2022-06-25 01:20:31.688435
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual(1.0)
    var_0 = net_b_s_d_virtual_0

# Generated at 2022-06-25 01:20:38.751118
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    bool_0 = False
    float_0 = -621.5
    net_b_s_d_virtual_0 = NetBSDVirtual(float_0)
    net_b_s_d_virtual_1 = NetBSDVirtual(bool_0, net_b_s_d_virtual_0)
    var_1 = net_b_s_d_virtual_1.get_virtual_facts()

test_case_0()

# Generated at 2022-06-25 01:20:40.048568
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()


# Generated at 2022-06-25 01:20:43.090462
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()


# Generated at 2022-06-25 01:20:48.221460
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    bool_0 = False
    float_0 = -881.5
    net_b_s_d_virtual_0 = NetBSDVirtual(float_0)
    net_b_s_d_virtual_1 = NetBSDVirtual(bool_0, net_b_s_d_virtual_0)

if __name__ == '__main__':
    test_NetBSDVirtual()

# Generated at 2022-06-25 01:20:53.977595
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    bool_0 = False
    float_0 = -534.68
    net_b_s_d_virtual_1 = NetBSDVirtual(float_0)
    net_b_s_d_virtual_0 = NetBSDVirtual(bool_0, net_b_s_d_virtual_1)


# Generated at 2022-06-25 01:20:56.718670
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    float_0 = -4.06
    net_b_s_d_virtual_0 = NetBSDVirtual(float_0)


# Generated at 2022-06-25 01:21:05.429121
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    bool_0 = False
    float_0 = -621.5
    net_b_s_d_virtual_0 = NetBSDVirtual(float_0)
    net_b_s_d_virtual_1 = NetBSDVirtual(bool_0, net_b_s_d_virtual_0)
    net_b_s_d_virtual_1.get_virtual_facts()
    var_0 = net_b_s_d_virtual_1.get_virtual_facts()


# Generated at 2022-06-25 01:21:06.998914
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
  net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()
  print(net_b_s_d_virtual_collector_0)

if __name__ == '__main__':
    test_NetBSDVirtualCollector()

# Generated at 2022-06-25 01:21:12.015997
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    try:
        var_1 = NetBSDVirtualCollector().collect()
    except BaseException:
        pass


# Generated at 2022-06-25 01:21:30.355445
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    float_0 = -621.5
    net_b_s_d_virtual_0 = NetBSDVirtual(float_0)
    assert net_b_s_d_virtual_0.get_virtual_facts() is not None


# Generated at 2022-06-25 01:21:32.633859
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    try:
        netBSDVirtualCollector_0 = NetBSDVirtualCollector()
    except NameError:
        print('NameError expected')
        return

# Generated at 2022-06-25 01:21:37.179497
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    bool_0 = False
    float_0 = -621.5
    net_b_s_d_virtual_0 = NetBSDVirtual(float_0)
    net_b_s_d_virtual_1 = NetBSDVirtual(bool_0, net_b_s_d_virtual_0)
    var_0 = net_b_s_d_virtual_1.get_virtual_facts()


# Generated at 2022-06-25 01:21:40.238690
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    bool_0 = False
    float_0 = 66.0
    net_b_s_d_virtual_0 = NetBSDVirtual(float_0)
    net_b_s_d_virtual_1 = NetBSDVirtual(bool_0, net_b_s_d_virtual_0)


# Generated at 2022-06-25 01:21:42.955908
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    float_0 = -65.050475
    net_b_s_d_virtual_0 = NetBSDVirtual(float_0)
    assert net_b_s_d_virtual_0.get_virtual_facts() == {}

test_case_0()

# Generated at 2022-06-25 01:21:50.565326
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    bool_0 = False
    float_0 = -621.5
    # Constructor test case
    net_b_s_d_virtual_0 = NetBSDVirtual(float_0)
    net_b_s_d_virtual_1 = NetBSDVirtual(bool_0, net_b_s_d_virtual_0)
    # Virtual test case for method "get_virtual_facts()"
    test_case_0()

if __name__ == '__main__':
    test_NetBSDVirtual()

# Generated at 2022-06-25 01:21:55.277602
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    bool_0 = True
    int_0 = 3
    net_b_s_d_virtual_0 = NetBSDVirtual(int_0, bool_0)
    net_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:21:57.415536
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()


# Generated at 2022-06-25 01:21:58.170528
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    assert True

# Generated at 2022-06-25 01:21:59.331781
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()

# Generated at 2022-06-25 01:22:31.984559
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()


# Generated at 2022-06-25 01:22:35.569236
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    bool_0 = False
    float_0 = -621.5
    net_b_s_d_virtual_0 = NetBSDVirtual(float_0)
    net_b_s_d_virtual_1 = NetBSDVirtual(bool_0, net_b_s_d_virtual_0)
    var_0 = net_b_s_d_virtual_1.get_virtual_facts()

# Generated at 2022-06-25 01:22:44.328809
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    bool_0 = False
    float_0 = -621.5
    net_b_s_d_virtual_0 = NetBSDVirtual(float_0)
    net_b_s_d_virtual_1 = NetBSDVirtual(bool_0, net_b_s_d_virtual_0)
    var_0 = net_b_s_d_virtual_1.get_virtual_facts()
    assert isinstance(var_0, dict)
    assert var_0 == {'virtualization_role': '', 'virtualization_type': '', 'virtualization_partial': False, 'virtualization_tech_host': set(), 'virtualization_tech_guest': set()}


# Generated at 2022-06-25 01:22:51.327543
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()
    net_b_s_d_virtual_collector_0.collect()
    var_1 = net_b_s_d_virtual_collector_0.get_all()

if __name__ == "__main__":
    test_case_0()
    test_NetBSDVirtualCollector()

# Generated at 2022-06-25 01:22:56.013187
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    float_0 = -621.5
    net_b_s_d_virtual_0 = NetBSDVirtual(float_0)
    net_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:23:01.552016
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    bool_0 = False
    float_0 = -621.5
    net_b_s_d_virtual_0 = NetBSDVirtual(float_0)
    net_b_s_d_virtual_1 = NetBSDVirtual(bool_0, net_b_s_d_virtual_0)
    var_0 = net_b_s_d_virtual_1.get_virtual_facts()



# Generated at 2022-06-25 01:23:08.438410
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    bool_0 = False
    float_0 = -621.5
    net_b_s_d_virtual_0 = NetBSDVirtual(float_0)
    net_b_s_d_virtual_1 = NetBSDVirtual(bool_0, net_b_s_d_virtual_0)
    var_0 = net_b_s_d_virtual_1.get_virtual_facts()


# Generated at 2022-06-25 01:23:11.254581
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    try:
        test_case_0()
    except Exception as err:
        print("Caught error in test_test_case_0 : {0}".format(err))
        assert False

# Generated at 2022-06-25 01:23:17.942480
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    float_0 = -621.5
    net_b_s_d_virtual_0 = NetBSDVirtual(float_0)
    assert net_b_s_d_virtual_0._platform_version == float_0
    assert net_b_s_d_virtual_0._facts == {}
    assert net_b_s_d_virtual_0.platform == 'NetBSD'


# Generated at 2022-06-25 01:23:18.694542
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
  test_case_0()

# Generated at 2022-06-25 01:24:33.871326
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    bool_0 = False
    float_0 = -621.5
    net_b_s_d_virtual_0 = NetBSDVirtual(float_0)
    net_b_s_d_virtual_1 = NetBSDVirtual(bool_0, net_b_s_d_virtual_0)
    var_0 = net_b_s_d_virtual_1.get_virtual_facts()


# Generated at 2022-06-25 01:24:43.624263
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Clean up the sysctl module to ensure that the test is not affected by
    # previous tests
    VirtualSysctlDetectionMixin.sysctl_facts = {}

    # Create a mock of the sysctl module
    def create_sysctl_mock(return_value):
        class SysctlMock:
            def __init__(self):
                self.return_value = return_value

            def sysctl(self, path):
                return self.return_value

            def sysctlbyname(self, name):
                return self.return_value

        return SysctlMock()

    # Test case 1 - not in virtualization
    VirtualSysctlDetectionMixin.sysctl = create_sysctl_mock(('', '', ''))

    net_b_s_d_virtual_0 = NetBSDVirtual(5)


# Generated at 2022-06-25 01:24:45.788701
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector(None)

# Generated at 2022-06-25 01:24:49.937005
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    bool_0 = False
    float_0 = -621.5
    net_b_s_d_virtual_0 = NetBSDVirtual(float_0)


# Generated at 2022-06-25 01:24:53.980365
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    float_0 = -621.5
    net_b_s_d_virtual_0 = NetBSDVirtual(float_0)
    net_b_s_d_virtual_1 = NetBSDVirtual(net_b_s_d_virtual_0)

# Generated at 2022-06-25 01:24:55.534796
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    net_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:24:58.964432
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    float_0 = -723.219
    net_b_s_d_virtual_0 = NetBSDVirtual(float_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:25:02.342561
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    float_0 = -621.5
    net_b_s_d_virtual_0 = NetBSDVirtual(float_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    test_case_0()

# Generated at 2022-06-25 01:25:08.168922
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector = NetBSDVirtualCollector()
    assert net_b_s_d_virtual_collector._fact_class == NetBSDVirtual

# Generated at 2022-06-25 01:25:12.910114
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    bool_0 = False
    float_0 = -621.5
    net_b_s_d_virtual_0 = NetBSDVirtual(float_0)
    net_b_s_d_virtual_1 = NetBSDVirtual(bool_0, net_b_s_d_virtual_0)
    assert isinstance(net_b_s_d_virtual_1, NetBSDVirtual)


# Generated at 2022-06-25 01:28:06.192696
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    bool_0 = False
    float_0 = -621.5
    net_b_s_d_virtual_0 = NetBSDVirtual(float_0)
    net_b_s_d_virtual_0.get_virtual_facts()
    bool_1 = True
    net_b_s_d_virtual_1 = NetBSDVirtual(bool_0, net_b_s_d_virtual_0)
    net_b_s_d_virtual_1.get_virtual_facts()
    net_b_s_d_virtual_2 = NetBSDVirtual(bool_1, net_b_s_d_virtual_1)
    net_b_s_d_virtual_2.get_virtual_facts()

# Generated at 2022-06-25 01:28:08.200778
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    assert True
