

# Generated at 2022-06-25 01:18:09.903952
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():

    bytes_0 = b'd\x17\x0c^\xd2\x88)\x18N\x08\x90\xfe'
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0)

# Generated at 2022-06-25 01:18:15.334229
# Unit test for method get_virtual_facts of class NetBSDVirtual

# Generated at 2022-06-25 01:18:22.145149
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    bytes_0 = b'\x03\x13>\xe8\x9e\xdd\x82\x93\xa8\xcd\x04D\xaa\x82\x8e\x9c^\xa7\x0b\x8b\xe7\xab\xe4\x1d\xcf\xc9\xbd\x1c\x85\x10\xa4\xdf\xcc\x01\x81\x82\x99\x7f\xf6\x0e\x07\xad\x82\xfe\x1bL\xd3\x02'
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0)


# Generated at 2022-06-25 01:18:25.852960
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    bytes_0 = b'\x17\x0c^\xd2\x88)\x18N\x08\x90\xfe'
    test_case_0()


# Generated at 2022-06-25 01:18:27.055437
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    assert NetBSDVirtual


# Generated at 2022-06-25 01:18:28.334004
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()

# Generated at 2022-06-25 01:18:39.230566
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    bytes_0 = b'd\x17\x0c^\xd2\x88)\x18N\x08\x90\xfe'
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0)
    assert net_b_s_d_virtual_0.get_virtual_facts()['virtualization_type'] == ''
    assert net_b_s_d_virtual_0.get_virtual_facts()['virtualization_role'] == ''
    bytes_1 = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    net_b_s_d_virtual_1 = NetBSDVirtual(bytes_1)
    assert net_

# Generated at 2022-06-25 01:18:49.169921
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    bytes_0 = b'd\x17\x0c^\xd2\x88)\x18N\x08\x90\xfe'
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0)
    set_0 = None
    dict_0 = {'virtualization_role': '', 'virtualization_type': '', 'virtualization_tech_host': set_0, 'virtualization_tech_guest': set_0}
    dict_1 = net_b_s_d_virtual_0.get_virtual_facts()
    assert dict_0 == dict_1


# Generated at 2022-06-25 01:18:54.253266
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    bytes_0 = b'i\x86@\x89\x92\xa8\xc1\xc2\xf7</\x0e\x9c'
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0)

    assert isinstance(net_b_s_d_virtual_0, NetBSDVirtual) is True


# Generated at 2022-06-25 01:18:55.625147
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()


# Generated at 2022-06-25 01:18:59.963269
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    str_0 = '&L'
    net_b_s_d_virtual_0 = NetBSDVirtual(str_0)


# Generated at 2022-06-25 01:19:03.544155
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    str_0 = 'O`:-QF'
    str_1 = 'Hl:zB'
    net_b_s_d_virtual_0 = NetBSDVirtual(str_0, str_1)



# Generated at 2022-06-25 01:19:13.111029
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    str_0 = 'O`:-QF'
    net_b_s_d_virtual_0 = NetBSDVirtual(str_0)
    str_1 = 'O`:-QF' + 'O`:-QF'
    str_1 = str_1*3 + 'O`:-QF'
    str_1 = str_1*2 + 'O`:-QF'
    net_b_s_d_virtual_1 = NetBSDVirtual(str_1)
    if net_b_s_d_virtual_0.sysctl_path == net_b_s_d_virtual_1.sysctl_path:
        var_0 = net_b_s_d_virtual_0.get_virtual_facts()
        var_1 = net_b_s_d_virtual_1.get_virtual_facts

# Generated at 2022-06-25 01:19:13.703155
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    pass

# Generated at 2022-06-25 01:19:19.335141
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    str_0 = 'a'
    net_b_s_d_virtual_0 = NetBSDVirtual(str_0)
    assert net_b_s_d_virtual_0._platform == 'NetBSD'


# Generated at 2022-06-25 01:19:26.244504
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    str_0 = 'epm'
    net_b_s_d_virtual_0 = NetBSDVirtual(str_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 == {}
    str_1 = '/'
    net_b_s_d_virtual_1 = NetBSDVirtual(str_1)
    var_1 = net_b_s_d_virtual_1.get_virtual_facts()
    assert var_1 == {}
    str_2 = 'Y`a]o'
    net_b_s_d_virtual_2 = NetBSDVirtual(str_2)
    var_2 = net_b_s_d_virtual_2.get_virtual_facts()
    assert var_2 == {}

# Generated at 2022-06-25 01:19:28.998797
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    str_0 = 'O`:-QF'
    net_b_s_d_virtual_0 = NetBSDVirtual(str_0)


# Generated at 2022-06-25 01:19:31.242918
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    str_0 = 'O`:-QF'
    net_b_s_d_virtual_0 = NetBSDVirtual(str_0)
    assert net_b_s_d_virtual_0._platform_facts == str_0


# Generated at 2022-06-25 01:19:35.507291
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    str_0 = 'D:*Z8'
    net_b_s_d_virtual_0 = NetBSDVirtual(str_0)


# Generated at 2022-06-25 01:19:38.903145
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    str_1 = 'O`:-QF'
    net_b_s_d_virtual_1 = NetBSDVirtual(str_1)
    net_b_s_d_virtual_2 = NetBSDVirtual(str_1)
    net_b_s_d_virtual_1 = net_b_s_d_virtual_2


# Generated at 2022-06-25 01:19:47.021202
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    pass


# Generated at 2022-06-25 01:19:56.281351
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    str_0 = 'O`:-QF'
    net_b_s_d_virtual_0 = NetBSDVirtual(str_0)
    assert net_b_s_d_virtual_0.sysctl_namespace == 'O`:-QF'
    assert net_b_s_d_virtual_0.sysctl_prefix == ''

    str_0 = ''
    net_b_s_d_virtual_0 = NetBSDVirtual(str_0)
    assert net_b_s_d_virtual_0.sysctl_namespace == ''
    assert net_b_s_d_virtual_0.sysctl_prefix == ''

    str_0 = 'machdep.dmi.system-product'
    net_b_s_d_virtual_0 = NetBSDVirtual(str_0)
    assert net

# Generated at 2022-06-25 01:19:59.591207
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    str_0 = 'O`:-QF'
    net_b_s_d_virtual_0 = NetBSDVirtual(str_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()



# Generated at 2022-06-25 01:20:01.434214
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()


# Generated at 2022-06-25 01:20:02.699423
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()


# Generated at 2022-06-25 01:20:12.632100
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    str_0 = 'O`:-QF'
    net_b_s_d_virtual_0 = NetBSDVirtual(str_0)
    assert(net_b_s_d_virtual_0 is not None)
    assert(isinstance(net_b_s_d_virtual_0, NetBSDVirtual))
    # Call method get_virtual_facts()
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    assert(var_0.get('virtualization_type') is not None)
    assert(var_0.get('virtualization_role') is not None)
    # Call method detect_virt_product()
    str_0 = 'machdep.dmi.system-product'
    var_1 = net_b_s_d_virtual_0.detect_

# Generated at 2022-06-25 01:20:23.013791
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():

    net_b_s_d_virtual_0 = NetBSDVirtual('K|[O')

    dict_0 = {}

    dict_0['virtualization_type'] = 'vmware'
    dict_0['virtualization_role'] = 'guest'
    dict_0['virtualization_tech_guest'] = set()
    dict_0['virtualization_tech_host'] = set()
    dict_1 = {}

    dict_1['virtualization_type'] = 'vmware'
    dict_1['virtualization_role'] = 'host'
    dict_1['virtualization_tech_guest'] = set()
    dict_1['virtualization_tech_host'] = set()
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:20:25.002094
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    str_0 = '+b}NXKq:83'
    arg_0 = NetBSDVirtual(str_0)
    assert arg_0._sysctl_sysctl_mib == str_0


# Generated at 2022-06-25 01:20:27.308717
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:20:31.834679
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    str_0 = 'e'
    net_b_s_d_virtual_0 = NetBSDVirtual(str_0)
    assert net_b_s_d_virtual_0 is not None


# Generated at 2022-06-25 01:20:48.640574
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()
    assert net_b_s_d_virtual_collector_0.platform == 'NetBSD'
    assert net_b_s_d_virtual_collector_0.collectors == []
    assert net_b_s_d_virtual_collector_0.fact_class == NetBSDVirtual


# Generated at 2022-06-25 01:20:54.208251
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Get str from source
    str_0 = 'O`:-QF'
    net_b_s_d_virtual_0 = NetBSDVirtual(str_0)

    # Call get_virtual_facts with no argument
    net_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:20:57.751015
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    str_0 = ''
    net_b_s_d_virtual_0 = NetBSDVirtual(str_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:21:03.649553
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    str_1 = 'O`:-QF'
    net_b_s_d_virtual_1 = NetBSDVirtual(str_1)
    var_1 = net_b_s_d_virtual_1.get_virtual_facts()



# Generated at 2022-06-25 01:21:10.081436
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    str_0 = '|J/{~>'
    net_b_s_d_virtual_0 = NetBSDVirtual(str_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    assert net_b_s_d_virtual_0.platform == 'NetBSD'
    str_1 = 'HZ_'
    net_b_s_d_virtual_1 = NetBSDVirtual(str_1)
    var_1 = net_b_s_d_virtual_1.get_virtual_facts()
    str_2 = 'hBk'
    net_b_s_d_virtual_2 = NetBSDVirtual(str_2)
    var_2 = net_b_s_d_virtual_2.get_virtual_facts()

# Unit test

# Generated at 2022-06-25 01:21:14.554895
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    str_1 = 'MNA`'
    str_2 = 'MNA`'
    str_3 = 'MNA`'
    net_b_s_d_virtual_0 = NetBSDVirtual(str_1)

    net_b_s_d_virtual_1 = NetBSDVirtual(str_1, str_2)
    assert net_b_s_d_virtual_1.virt_type == str_2

    net_b_s_d_virtual_1 = NetBSDVirtual(str_1, str_2, str_3)
    assert net_b_s_d_virtual_1.virt_what == str_3

    net_b_s_d_virtual_1 = NetBSDVirtual(str_1, virt_type=str_2)

# Generated at 2022-06-25 01:21:18.131562
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    assert False, "Unknown should have a docstring to silence pylint"

# Generated at 2022-06-25 01:21:28.003064
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    str_0 = '>cGDJds'
    net_b_s_d_virtual_0 = NetBSDVirtual(str_0)
    var_0 = net_b_s_d_virtual_0._get_virt_from_sysctl_dmi('machdep.dmi.system-product')
    var_1 = net_b_s_d_virtual_0._get_virt_from_sysctl_dmi('machdep.dmi.system-vendor')
    net_b_s_d_virtual_0._get_virt_from_sysctl_dmi('machdep.hypervisor')
    var_2 = net_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:21:35.203902
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    str_0 = 'O`:-QF'
    net_b_s_d_virtual_0 = NetBSDVirtual(str_0)
    assert (isinstance(net_b_s_d_virtual_0._sysctl_path, str)) == True
    assert (net_b_s_d_virtual_0._sysctl_path) == str_0


# Generated at 2022-06-25 01:21:37.343883
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()


# Generated at 2022-06-25 01:22:08.727587
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()
    var_0 = net_b_s_d_virtual_collector_0._platform


# Generated at 2022-06-25 01:22:14.932501
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    str_0 = 'WU9J=$e'
    net_b_s_d_virtual_0 = NetBSDVirtual(str_0)
    assert net_b_s_d_virtual_0._platform_facts['uname_string'] == 'WU9J=$e'
    str_1 = '<N`V?s'
    net_b_s_d_virtual_1 = NetBSDVirtual(str_1)
    assert net_b_s_d_virtual_1._platform_facts['uname_string'] == '<N`V?s'
    str_2 = 'i>#=u'
    net_b_s_d_virtual_2 = NetBSDVirtual(str_2)

# Generated at 2022-06-25 01:22:17.889176
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    str_0 = 'O`:-QF'
    net_b_s_d_virtual_0 = NetBSDVirtual(str_0)


# Generated at 2022-06-25 01:22:24.614894
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    str_0 = 'O`:-QF'
    net_b_s_d_virtual_0 = NetBSDVirtual(str_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:22:26.498004
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector = NetBSDVirtualCollector()
    assert net_b_s_d_virtual_collector.get_platform() == 'NetBSD'

# Generated at 2022-06-25 01:22:29.422560
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    str_0 = 'O`:-QF'
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector(str_0)

if __name__ == '__main__':
    test_case_0()
    test_NetBSDVirtualCollector()

# Generated at 2022-06-25 01:22:31.574388
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    str_0 = 'O`:-QF'
    net_b_s_d_virtual_0 = NetBSDVirtual(str_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:22:34.497154
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    str_0 = 'O`:-QF'
    net_b_s_d_virtual_0 = NetBSDVirtual(str_0)
    # Test if object was created properly
    assert net_b_s_d_virtual_0 is not None


# Generated at 2022-06-25 01:22:39.955950
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    str_0 = 'O`:-QF'
    net_b_s_d_virtual_0 = NetBSDVirtual(str_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:22:40.936779
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    test_case_0()

# Generated at 2022-06-25 01:23:43.427355
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    str_0 = 'B2@!*'
    net_b_s_d_virtual_0 = NetBSDVirtual(str_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:23:44.817427
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector._platform == 'NetBSD'
    assert NetBSDVirtualCollector._fact_class == NetBSDVirtual


# Generated at 2022-06-25 01:23:48.102443
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    str_0 = ';v{jK'
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector(str_0)
    assert callable(getattr(net_b_s_d_virtual_collector_0, '_fact_class'))

# Generated at 2022-06-25 01:23:50.182822
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    str_1 = '9@$W8'
    net_b_s_d_virtual_1 = NetBSDVirtual(str_1)
    var_1 = net_b_s_d_virtual_1.get_virtual_facts()

# Generated at 2022-06-25 01:23:55.459633
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    # Test with a sysctl string that does not exist
    net_b_s_d_virtual_0 = NetBSDVirtual("blah")
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()

    # Test with a real sysctl string.
    net_b_s_d_virtual_1 = NetBSDVirtual("machdep.dmi.system-product")
    var_0 = net_b_s_d_virtual_1.get_virtual_facts()

    # Test with a real sysctl string.
    net_b_s_d_virtual_2 = NetBSDVirtual("machdep.dmi.system-vendor")
    var_0 = net_b_s_d_virtual_2.get_virtual_facts()

    # Test with a real sysctl string.
   

# Generated at 2022-06-25 01:24:00.093868
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    str_0 = 'BHSy;V'
    net_b_s_d_virtual_0 = NetBSDVirtual(str_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:24:02.947434
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()
    net_b_s_d_virtual_collector_0.collect()


# Generated at 2022-06-25 01:24:10.084416
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    str_0 = 'O`:-QF'
    net_b_s_d_virtual_0 = NetBSDVirtual(str_0)
    var_28 = NetBSDVirtual.get_virtual_facts(net_b_s_d_virtual_0)
    str_1 = 'virtualization_type='
    str_2 = 'virtualization_role='
    str_3 = 'virtualization_tech_guest='
    str_4 = 'virtualization_tech_host='
    str_5 = ',virtualization_product_version='
    str_6 = 'virtualization_product_name='
    str_7 = 'virtualization_product_version_text='
    str_8 = 'virtualization_product_name_text='
    str_9 = 'virtualization_product_version='

# Generated at 2022-06-25 01:24:13.122067
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    str_0 = 'O`:-QF'
    net_b_s_d_virtual_0 = NetBSDVirtual(str_0)
    var_1 = net_b_s_d_virtual_0.platform
    assert var_1 == 'NetBSD'


# Generated at 2022-06-25 01:24:19.182672
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    str_0 = 'O`:-QF'
    net_b_s_d_virtual_0 = NetBSDVirtual(str_0)
    assert net_b_s_d_virtual_0.sysctl_path == r'O`:-QF'
    assert net_b_s_d_virtual_0.sysctl_cache == {}



# Generated at 2022-06-25 01:27:04.420252
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    str_0 = '0'
    net_b_s_d_virtual_0 = NetBSDVirtual(str_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 == {'virtualization_tech_guest': set(), 'virtualization_type': '', 'virtualization_tech_host': set(), 'virtualization_role': ''}


# Generated at 2022-06-25 01:27:13.715360
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    assert not NetBSDVirtual.get_virtual_facts('kvm')
    assert not NetBSDVirtual.get_virtual_facts('vmware')
    assert not NetBSDVirtual.get_virtual_facts('xen')
    assert not NetBSDVirtual.get_virtual_facts('lxc')
    assert not NetBSDVirtual.get_virtual_facts('virtualbox')
    assert not NetBSDVirtual.get_virtual_facts('openvz')
    assert not NetBSDVirtual.get_virtual_facts('libvirt')
    assert not NetBSDVirtual.get_virtual_facts('kvm')
    assert not NetBSDVirtual.get_virtual_facts('vmware')
    assert not NetBSDVirtual.get_virtual_facts('xen')
    assert not NetBSDVirtual.get_virtual_facts('lxc')
    assert not NetBSDVirtual.get_virtual_

# Generated at 2022-06-25 01:27:14.977211
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    str_0 = 'O`:-QF'
    net_b_s_d_virtual_0 = NetBSDVirtual(str_0)


# Generated at 2022-06-25 01:27:18.599726
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    str_0 = 's]lU6e'
    net_b_s_d_virtual_0 = NetBSDVirtual(str_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:27:22.623136
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual('machdep.hypervisor')
    net_b_s_d_virtual_0.detect_virt_product = detect_virt_product_0
    net_b_s_d_virtual_0.detect_virt_vendor = detect_virt_vendor_0
    dict_0 = net_b_s_d_virtual_0.get_virtual_facts()
    assert dict_0['virtualization_type'] == 'xen'
    assert dict_0['virtualization_role'] == 'guest'


# Generated at 2022-06-25 01:27:24.757737
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    str_0 = 'O`:-QF'
    net_b_s_d_virtual_0 = NetBSDVirtual(str_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:27:27.563856
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()
    var_0 = net_b_s_d_virtual_collector_0._platform
    assert (var_0 == 'NetBSD')


if __name__ == '__main__':
    test_case_0()
    test_NetBSDVirtualCollector()

# Generated at 2022-06-25 01:27:33.955696
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    str_0 = 'Z`-\n0:1'
    net_b_s_d_virtual_0 = NetBSDVirtual(str_0)
    var_1 = net_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:27:41.044096
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    str_0 = 'Q4\x1d\x1b'
    net_b_s_d_virtual_0 = NetBSDVirtual(str_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    assert 'virtualization_role' in var_0
    assert 'virtualization_type' in var_0

# Generated at 2022-06-25 01:27:46.797024
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    str_0 = 'O`:-QF'
    net_b_s_d_virtual_0 = NetBSDVirtual(str_0)
    # AssertionError: expected <{}> not <{'virtualization_role': '', 'virtualization_type': '', 'virtualization_tech_host': set(), 'virtualization_tech_guest': set()}> for get_virtual_facts() == {'virtualization_tech_guest': set(), 'virtualization_tech_host': set(), 'virtualization_type': '', 'virtualization_role': ''}
