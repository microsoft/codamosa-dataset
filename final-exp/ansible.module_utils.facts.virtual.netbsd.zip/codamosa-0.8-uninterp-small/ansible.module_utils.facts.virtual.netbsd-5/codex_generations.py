

# Generated at 2022-06-25 01:18:17.351630
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    net_b_s_d_virtual_1 = NetBSDVirtual()
    net_b_s_d_virtual_0.populate()
    net_b_s_d_virtual_1.populate()

# Generated at 2022-06-25 01:18:19.383682
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:18:30.290739
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    sysctl_list_0 = [
        'machdep.dmi.system-vendor: VMware, Inc.',
        'machdep.hypervisor: VMWare Virtual Platform',
        'machdep.dmi.system-product: VMware Virtual Platform',
    ]
    assert(NetBSDVirtual(sysctl_list_0).get_virtual_facts() == {
        'virtualization_role': 'guest',
        'virtualization_type': 'vmware',
        'virtualization_tech_host': set(['vmware']),
        'virtualization_tech_guest': set(['vmware']),
        'virtualization_product_name': 'VMware Virtual Platform',
        'virtualization_product_version': None,
        'virtualization_product_serial': None,
    })



# Generated at 2022-06-25 01:18:36.143886
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    list_0 = None
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector(list_0)

    # The above call to constructor does not raise any exception but there is
    # no assertions to verify the internal state of the returned instance of
    # NetBSDVirtualCollector

# Generated at 2022-06-25 01:18:37.275133
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()


# Generated at 2022-06-25 01:18:40.490123
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    list_0 = None
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector(list_0)
    assert net_b_s_d_virtual_collector_0._fact_class._platform == 'NetBSD', 'Failed test_NetBSDVirtualCollector'


# Generated at 2022-06-25 01:18:51.199009
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    # Verify that constructor of class NetBSDVirtual will throw exception on negative scenarios
    try:
        net_b_s_d_virtual_0 = NetBSDVirtual(None)
    except BaseException as exception_0:
        print('Exception caught: {}'.format(exception_0))
    # Verify that constructor of class NetBSDVirtual will throw exception on negative scenarios
    try:
        net_b_s_d_virtual_0 = NetBSDVirtual(None)
    except BaseException as exception_0:
        print('Exception caught: {}'.format(exception_0))
    # Verify that constructor of class NetBSDVirtual will throw exception on negative scenarios

# Generated at 2022-06-25 01:18:57.033060
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    list_0 = None
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector(list_0)
    net_b_s_d_virtual_0 = net_b_s_d_virtual_collector_0._fact_class()
    net_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:19:05.039900
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    list_0 = None
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector(list_0)
    net_b_s_d_virtual_collector_0 = net_b_s_d_virtual_collector_0
    net_b_s_d_virtual_0 = net_b_s_d_virtual_collector_0.get_virtual_facts()
    net_b_s_d_virtual_0 = net_b_s_d_virtual_0


# Generated at 2022-06-25 01:19:05.663751
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    pass


# Generated at 2022-06-25 01:19:15.466143
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xb0\x0e=\xfa\x1e\xfa\x06[@\x07\xab\x1dJ\xf1\x92\xa3\x1a\xdd'
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:19:23.031583
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    bytes_0 = b'\xb0\x0e=\xfa\x1e\xfa\x06[@\x07\xab\x1dJ\xf1\x92\xa3\x1a\xdd'
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    if ((var_0['virtualization_role'] == 'guest') and (var_0['virtualization_type'] == 'xen')):
        var_1 = True
    else:
        var_1 = False
    assert var_1


# Generated at 2022-06-25 01:19:26.518949
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    bytes_0 = b'\xb0\x0e=\xfa\x1e\xfa\x06[@\x07\xab\x1dJ\xf1\x92\xa3\x1a\xdd'
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:19:33.320005
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    bytes_0 = b'\x1a\x1b\x14\xcd\xdd\x89\xd5\x05\x8f\xac\x1f\xee\x9d\x8f\xf5\x0a'
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    bytes_1 = b'\xb0\x0e=\xfa\x1e\xfa\x06[@\x07\xab\x1dJ\xf1\x92\xa3\x1a\xdd'
    net_b_s_d_virtual_1 = NetBSDVirtual(bytes_1)
    var_1 = net_b

# Generated at 2022-06-25 01:19:38.198560
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xb0\x0e=\xfa\x1e\xfa\x06[@\x07\xab\x1dJ\xf1\x92\xa3\x1a\xdd'
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()



# Generated at 2022-06-25 01:19:41.438304
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Test case 0
    bytes_0 = b'\xb0\x0e=\xfa\x1e\xfa\x06[@\x07\xab\x1dJ\xf1\x92\xa3\x1a\xdd'
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:19:42.614461
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()

# Generated at 2022-06-25 01:19:49.501561
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xb0\x0e=\xfa\x1e\xfa\x06[@\x07\xab\x1dJ\xf1\x92\xa3\x1a\xdd'
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:19:58.323293
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xb0\x0e=\xfa\x1e\xfa\x06[@\x07\xab\x1dJ\xf1\x92\xa3\x1a\xdd'
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    # assertion: dict(set([u'virtualization_type', u'virtualization_role', u'virtualization_tech_guest', u'virtualization_tech_host']), {'virtualization_type': u'xen', 'virtualization_role': u'guest', ...})

# Generated at 2022-06-25 01:20:00.737786
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():

    assert True

if __name__ == '__main__':
    # print(test_NetBSDVirtual_get_virtual_facts())
    print('Execute all tests')

# Generated at 2022-06-25 01:20:14.368319
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    bytes_0 = b'\xb0\x0e=\xfa\x1e\xfa\x06[@\x07\xab\x1dJ\xf1\x92\xa3\x1a\xdd'
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0)
    assert net_b_s_d_virtual_0.platform == 'NetBSD'


# Generated at 2022-06-25 01:20:22.179201
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    # Create an object of NetBSDVirtual
    bytes_0 = b'\xb0\x0e=\xfa\x1e\xfa\x06[@\x07\xab\x1dJ\xf1\x92\xa3\x1a\xdd'
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0)

    # Create an object of class NetBSDVirtual using constructor NetBSDVirtual()
    net_b_s_d_virtual_1 = NetBSDVirtual()


# Generated at 2022-06-25 01:20:25.289056
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    assert net_b_s_d_virtual_0.get_virtual_facts() == {}


# Generated at 2022-06-25 01:20:29.875103
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    bytes_0 = b'\xa5\x91\x1a\xaa\xa6\xbd2\x95\x02\x00\x00\x00\x00\x00\x00\x00\x00'
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:20:40.270564
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xb0\x0e=\xfa\x1e\xfa\x06[@\x07\xab\x1dJ\xf1\x92\xa3\x1a\xdd'
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0)
    net_b_s_d_virtual_0._cache = {}
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 == 'kvm'
    var_1 = net_b_s_d_virtual_0.get_virtual_facts()
    assert var_1 == 'kvm'
    var_2 = net_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:20:45.729899
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()
    assert net_b_s_d_virtual_collector_0._fact_class == NetBSDVirtual
    assert net_b_s_d_virtual_collector_0._platform == 'NetBSD'



# Generated at 2022-06-25 01:20:49.063783
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xb0\x0e=\xfa\x1e\xfa\x06[@\x07\xab\x1dJ\xf1\x92\xa3\x1a\xdd'
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:20:58.799533
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xb0\x0e=\xfa\x1e\xfa\x06[@\x07\xab\x1dJ\xf1\x92\xa3\x1a\xdd'
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()

    assert var_0['virtualization_type'] == 'virtualbox'
    assert var_0['virtualization_role'] == 'guest'

    assert var_0['virtualization_tech_guest'] == {'virtualbox', 'hypervisor'}
    assert var_0['virtualization_tech_host'] == set()

# Generated at 2022-06-25 01:21:05.599924
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    bytes_0 = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0)
    assert net_b_s_d_virtual_0._platform == 'NetBSD'
    assert net_b_s_d_virtual_0._fact_class == NetBSDVirtual


# Generated at 2022-06-25 01:21:09.289668
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xef\x0b\x1e\xea\x18\xea\v\xa9\x1b\x1e\x04\xec\x03\x18\x0b\xeb'
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:21:24.692527
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # TODO: add test for NetBSDVirtual.get_virtual_facts
    assert False

# Generated at 2022-06-25 01:21:33.115150
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xb0\x0e=\xfa\x1e\xfa\x06[@\x07\xab\x1dJ\xf1\x92\xa3\x1a\xdd'
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:21:37.848180
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    bytes_0 = b'\xb0\x0e=\xfa\x1e\xfa\x06[@\x07\xab\x1dJ\xf1\x92\xa3\x1a\xdd'
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:21:44.127000
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
  net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()
  # No exception raised

if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1 and sys.argv[1] == '--test':
        print('Run unit tests')
        sys.exit(1)

# Generated at 2022-06-25 01:21:51.989898
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xb0\x0e=\xfa\x1e\xfa\x06[@\x07\xab\x1dJ\xf1\x92\xa3\x1a\xdd'
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0)
    # Call method get_virtual_facts of class NetBSDVirtual
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:22:00.281597
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    # test_case_0
    bytes_0 = b'\xb0\x0e=\xfa\x1e\xfa\x06[@\x07\xab\x1dJ\xf1\x92\xa3\x1a\xdd'
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    try:
        assert var_0['virtualization_type'] == 'xen'
    except AssertionError as var_1:
        raise AssertionError(var_1)


# Generated at 2022-06-25 01:22:06.431239
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    bytes_0 = b'\x9d\xdd\r\xd0\x10\xe6\x8a\x1d\xb6\x1d\x8b\x02\x15\xf6\xce\x8f'
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:22:11.915995
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    bytes_0 = b'\xb0\x0e=\xfa\x1e\xfa\x06[@\x07\xab\x1dJ\xf1\x92\xa3\x1a\xdd'
    assert NetBSDVirtual(args=bytes_0).get_virtual_facts() == {'virtualization_role': 'guest', 'virtualization_type': 'xen', 'virtualization_tech_host': set(), 'virtualization_tech_guest': {'xen'}}

# Generated at 2022-06-25 01:22:14.882652
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()
    assert net_b_s_d_virtual_collector_0.get_virtual_facts()

# Generated at 2022-06-25 01:22:16.717799
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    test_case_0()


# Generated at 2022-06-25 01:22:52.898796
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xb0\x0e=\xfa\x1e\xfa\x06[@\x07\xab\x1dJ\xf1\x92\xa3\x1a\xdd'
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0)
    net_b_s_d_virtual_0.virtual_facts = {}

    # Call method
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()

    # Assert 1
    assert var_0['virtualization_role'] == 'guest'



# Generated at 2022-06-25 01:22:59.430447
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    bytes_0 = b'\xb0\x0e=\xfa\x1e\xfa\x06[@\x07\xab\x1dJ\xf1\x92\xa3\x1a\xdd'
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0)


# Generated at 2022-06-25 01:23:06.872837
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    bytes_0 = b'\xb0\x0e=\xfa\x1e\xfa\x06[@\x07\xab\x1dJ\xf1\x92\xa3\x1a\xdd'
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:23:15.890138
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    bytes_0 = b'\xb0\x0e=\xfa\x1e\xfa\x06[@\x07\xab\x1dJ\xf1\x92\xa3\x1a\xdd'
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0)
    assert net_b_s_d_virtual_0._bytes == b'\xb0\x0e=\xfa\x1e\xfa\x06[@\x07\xab\x1dJ\xf1\x92\xa3\x1a\xdd'
    assert net_b_s_d_virtual_0.platform == 'NetBSD'


# Generated at 2022-06-25 01:23:23.751332
# Unit test for method get_virtual_facts of class NetBSDVirtual

# Generated at 2022-06-25 01:23:25.943960
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    var_0 = NetBSDVirtualCollector()


# Generated at 2022-06-25 01:23:30.164097
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xb0\x0e=\xfa\x1e\xfa\x06[@\x07\xab\x1dJ\xf1\x92\xa3\x1a\xdd'
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:23:34.091614
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:23:43.291718
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xb0\x0e=\xfa\x1e\xfa\x06[@\x07\xab\x1dJ\xf1\x92\xa3\x1a\xdd'
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:23:44.028518
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    var_1 = NetBSDVirtualCollector()

# Generated at 2022-06-25 01:24:55.720065
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    print(NetBSDVirtual.get_virtual_facts.__doc__
          )

# Generated at 2022-06-25 01:25:02.305827
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.netbsd import NetBSDVirtual
    bytes_0 = b'\xb0\x0e=\xfa\x1e\xfa\x06[@\x07\xab\x1dJ\xf1\x92\xa3\x1a\xdd'
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:25:12.715391
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()
    assert net_b_s_d_virtual_collector_0 is not None
    assert net_b_s_d_virtual_collector_0._platform is 'NetBSD'
    assert net_b_s_d_virtual_collector_0._fact_class is NetBSDVirtual
    assert net_b_s_d_virtual_collector_0._name is 'VirtualFactCollector'
    assert net_b_s_d_virtual_collector_0._collectors is ()

if __name__ == '__main__':
    print(__file__)
    print(test_case_0.__doc__)
    test_case_0()
    # Unit test for constructor of class NetBSDVirtualCollector

# Generated at 2022-06-25 01:25:18.519923
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xb0\x0e=\xfa\x1e\xfa\x06[@\x07\xab\x1dJ\xf1\x92\xa3\x1a\xdd'
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    assert var_0['virtualization_type'] == 'kvm'


# Generated at 2022-06-25 01:25:24.664957
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xb0\x0e=\xfa\x1e\xfa\x06[@\x07\xab\x1dJ\xf1\x92\xa3\x1a\xdd'
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()

    var_0 = {}
    var_1 = net_b_s_d_virtual_0.get_virtual_facts()
    var_0 = None
    var_1 = net_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:25:33.269543
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    bytes_0 = b'\x03T\x03\x00\x00\x00\x00\x00\x00\x00\x08\x10\x00\x00\x00\x00\x00'
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    assert var_0['virtualization_tech_host'] == {'kvm'}
    assert var_0['virtualization_tech_guest'] == {'kvm'}
    assert var_0['virtualization_type'] == 'kvm'
    assert var_0['virtualization_role'] == 'guest'


# Generated at 2022-06-25 01:25:42.858947
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xb0\x0e=\xfa\x1e\xfa\x06[@\x07\xab\x1dJ\xf1\x92\xa3\x1a\xdd'
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    assert var_0['virtualization_type'] == 'kvm'
    assert var_0['virtualization_role'] == 'guest'
    assert var_0['virtualization_tech_guest'] == set(['kvm'])
    assert var_0['virtualization_tech_host'] == set(['kvm'])

# Generated at 2022-06-25 01:25:45.577693
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    bytes_0 = b'\xb0\x0e=\xfa\x1e\xfa\x06[@\x07\xab\x1dJ\xf1\x92\xa3\x1a\xdd'
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0)
    assert len(net_b_s_d_virtual_0.sysctl_output) == 530


# Generated at 2022-06-25 01:25:48.744989
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    """
    Unit test for constructor of class NetBSDVirtualCollector for
    NetBSDVirtual
    """
    # Create an object of the class NetBSDVirtualCollector
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()
    # Assert that the object is an instance of class NetBSDVirtualCollector
    assert isinstance(net_b_s_d_virtual_collector_0, NetBSDVirtualCollector)


# Generated at 2022-06-25 01:25:52.359271
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    bytes_0 = b'\xaat\x19x\x11\x12\x1b\x1b\x88\xd8\x03\x8b\x89\x14\x15\x16\x8a'
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 == {'virtualization_role': 'guest', 'virtualization_type': 'kvm', 'virtualization_tech_guest': {'kvm'}, 'virtualization_tech_host': {'kvm'}, 'virtualization_product_name': ''}