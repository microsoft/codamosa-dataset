

# Generated at 2022-06-25 01:18:14.260695
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()


# Generated at 2022-06-25 01:18:20.351055
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    virtual_facts = net_b_s_d_virtual_0.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()
    assert virtual_facts['virtualization_systems'] == []
    assert virtual_facts['virtualization_environments'] == []

# Generated at 2022-06-25 01:18:22.988278
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    assert net_b_s_d_virtual_0 is not None


# Generated at 2022-06-25 01:18:26.484856
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    net_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:18:29.055376
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    assert net_b_s_d_virtual_0.platform == 'NetBSD'


# Generated at 2022-06-25 01:18:30.363949
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual = NetBSDVirtual()

# Generated at 2022-06-25 01:18:34.783200
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    assert net_b_s_d_virtual_0.get_virtual_facts() == {}

# Generated at 2022-06-25 01:18:41.888157
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    net_b_s_d_virtual_0.sysctl_machdep_dmi_system_product = "VirtualBox"
    net_b_s_d_virtual_0.sysctl_machdep_dmi_system_vendor = "innotek GmbH"
    net_b_s_d_virtual_0.sysctl_machdep_hypervisor = "0"
    net_b_s_d_virtual_0.sysctl_machdep_virtual_guest = "0"
    net_b_s_d_virtual_0.sysctl_machdep_xen_guest = "0"
    net_b_s_d_virtual_0.sysctl_machdep_dmi_system_v

# Generated at 2022-06-25 01:18:43.764415
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector.__name__ == 'NetBSDVirtualCollector'


# Generated at 2022-06-25 01:18:49.820928
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    # Return a dict of virtualization facts from sysctl
    virtual_facts = net_b_s_d_virtual_0.get_virtual_facts()
    assert virtual_facts is not None

# Generated at 2022-06-25 01:18:55.891888
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    float_0 = -1884.7166
    net_b_s_d_virtual_0 = NetBSDVirtual(float_0)


# Generated at 2022-06-25 01:19:00.408759
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    # Test with invalid input
    float_0 = -1884.7166
    net_b_s_d_virtual_0 = NetBSDVirtual(float_0)
    # Test with valid input
    float_1 = -1814.5929
    net_b_s_d_virtual_1 = NetBSDVirtual(float_1)


# Generated at 2022-06-25 01:19:02.502560
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual(float_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:19:03.005720
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    assert True

# Generated at 2022-06-25 01:19:05.990864
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    float_0 = 0.54
    net_b_s_d_virtual_c_0 = NetBSDVirtualCollector(float_0)
    var_0 = net_b_s_d_virtual_c_0.collect()

if __name__ == '__main__':
    test_case_0()
    test_NetBSDVirtualCollector()

# Generated at 2022-06-25 01:19:10.543385
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:19:16.708184
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    float_0 = -1884.7166
    net_b_s_d_virtual_0 = NetBSDVirtual(float_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    # We're just making sure it runs without raising any exceptions given the
    # current stubbed data. We can expand this test as more data is added.



# Generated at 2022-06-25 01:19:20.567257
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    float_0 = -12.4
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector(float_0)
    str_0 = net_b_s_d_virtual_collector_0.get_all_facts()
    print(str_0)

# Generated at 2022-06-25 01:19:26.987949
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual(8.99)
    net_b_s_d_virtual_1 = NetBSDVirtual(-7.5)
    net_b_s_d_virtual_2 = NetBSDVirtual(5.3)
    net_b_s_d_virtual_3 = NetBSDVirtual(3.99)
    net_b_s_d_virtual_4 = NetBSDVirtual(2.2)
    net_b_s_d_virtual_5 = NetBSDVirtual(7.8)
    net_b_s_d_virtual_6 = NetBSDVirtual(0.74)
    net_b_s_d_virtual_7 = NetBSDVirtual(0.09)
    net_b_s_d_virtual_8 = NetBSDVirtual(2.49)
   

# Generated at 2022-06-25 01:19:28.787783
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    float_0 = -0.91733
    net_b_s_d_virtual_0 = NetBSDVirtual(float_0)


# Generated at 2022-06-25 01:19:37.719797
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    float_0 = 0.2498
    net_b_s_d_virtual_0 = NetBSDVirtual(float_0)
    assert net_b_s_d_virtual_0._platform == 'NetBSD'


# Generated at 2022-06-25 01:19:41.643511
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()
    net_b_s_d_virtual_collector_0.collect()


# Generated at 2022-06-25 01:19:46.290006
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    import json
    import os
    import sys
    import unittest
    import tempfile
    import io
    import io
    import io
    import io
    import io
    import io
    import io


# Generated at 2022-06-25 01:19:49.338561
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    float_0 = -1.1911976847303968
    net_b_s_d_virtual_0 = NetBSDVirtual(float_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:19:53.721360
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    float_0 = -9878.946
    net_b_s_d_virtual_0 = NetBSDVirtual(float_0)
    net_b_s_d_virtual_0.get_virtual_facts()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 01:19:56.355629
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    float_0 = -1884.7166
    net_b_s_d_virtual_0 = NetBSDVirtual(float_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:20:00.888811
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    float_0 = -1884.7166
    net_b_s_d_virtual_0 = NetBSDVirtual(float_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    assert var_0['virtualization_type'] == 'kvm'
    assert var_0['virtualization_role'] == 'guest'


# Generated at 2022-06-25 01:20:06.333268
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    float_0 = -1225.5893
    net_b_s_d_virtual_0 = NetBSDVirtual(float_0)
    assert net_b_s_d_virtual_0._platform == 'NetBSD'
    assert net_b_s_d_virtual_0._detect_virt_product('machdep.dmi.system-product') == {'virtualization_type': '', 'virtualization_tech_host': set(), 'virtualization_tech_guest': set(), 'virtualization_role': ''}

# Generated at 2022-06-25 01:20:11.085077
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    float_0 = -1884.7166
    net_b_s_d_virtual_0 = NetBSDVirtual(float_0)
    net_b_s_d_virtual_0.__init__(float_0)


# Generated at 2022-06-25 01:20:13.860324
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    float_0 = -1884.7166
    net_b_s_d_virtual_0 = NetBSDVirtual(float_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 == {'virtualization_type': 'docker', 'virtualization_role': 'guest', 'virtualization_tech_guest': {'docker'}, 'virtualization_tech_host': {'docker'}}

# Generated at 2022-06-25 01:20:29.209704
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    float_0 = -1884.7166
    net_b_s_d_virtual_0 = NetBSDVirtual(float_0)
    assert isinstance(net_b_s_d_virtual_0, NetBSDVirtual)
    assert isinstance(net_b_s_d_virtual_0, Virtual)


# Generated at 2022-06-25 01:20:38.272988
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    float_1 = -2844.724
    net_b_s_d_virtual_1 = NetBSDVirtual(float_1)
    var_1 = net_b_s_d_virtual_1.get_virtual_facts()
    assert var_1['virtualization_type'] == ''
    assert var_1['virtualization_role'] == ''
    assert var_1['virtualization_tech_guest'] == set()
    assert var_1['virtualization_tech_host'] == set()
    assert var_1['virtualization_product_name'] == ''
    assert var_1['virtualization_product_version'] == ''


# Generated at 2022-06-25 01:20:39.339655
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()

# Generated at 2022-06-25 01:20:45.236196
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
  net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()
  var_2 = isinstance(net_b_s_d_virtual_collector_0, NetBSDVirtualCollector)
  assert var_2 == True


# Generated at 2022-06-25 01:20:46.815045
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    float_0 = -1884.7166
    net_b_s_d_virtual_0 = NetBSDVirtual(float_0)

# Generated at 2022-06-25 01:20:53.086894
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    float_0 = 578.75
    net_b_s_d_virtual_0 = NetBSDVirtual(float_0)
    assert len(net_b_s_d_virtual_0.get_virtual_facts()) >= 0


# Generated at 2022-06-25 01:20:54.507421
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    # Test for get_virtual_facts method of class NetBSDVirtual
    test_case_0()


# Generated at 2022-06-25 01:20:55.392237
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    pass



# Generated at 2022-06-25 01:21:01.222138
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    float_0 = -1884.7166
    net_b_s_d_virtual_0 = NetBSDVirtual(float_0)
    float_1 = -1884.7166
    net_b_s_d_virtual_1 = NetBSDVirtual(float_1)
    float_2 = -1884.7166
    net_b_s_d_virtual_2 = NetBSDVirtual(float_2)
    float_3 = -1884.7166
    net_b_s_d_virtual_3 = NetBSDVirtual(float_3)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    var_1 = net_b_s_d_virtual_1.get_virtual_facts()
    var_2 = net_b_s_d_virtual_

# Generated at 2022-06-25 01:21:06.176780
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    float_0 = -11.1924
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector(float_0)
    net_b_s_d_virtual_collector_0.collect()


# Generated at 2022-06-25 01:21:35.273898
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    float_0 = -2075.7395
    net_b_s_d_virtual_0 = NetBSDVirtual(float_0)
    try:
        net_b_s_d_virtual_0.get_virtual_facts()
    except AttributeError:
        pass

# Generated at 2022-06-25 01:21:36.878557
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    float_0 = -174.743
    net_b_s_d_virtual_0 = NetBSDVirtual(float_0)


# Generated at 2022-06-25 01:21:39.831301
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    float_0 = -1884.7166
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector(float_0)
    var_0 = net_b_s_d_virtual_collector_0.get_all_facts()

# Generated at 2022-06-25 01:21:44.908979
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    float_0 = 9069.74
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector(float_0)
    float_1 = -9487.8828
    net_b_s_d_virtual_collector_0.get_all_facts(float_1)


# Generated at 2022-06-25 01:21:48.722252
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    print("test_NetBSDVirtual")
    test_case_0()


test_NetBSDVirtual()

# Generated at 2022-06-25 01:21:49.800031
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()


# Generated at 2022-06-25 01:21:53.782333
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    float_0 = -3435.9
    net_b_s_d_virtual_0 = NetBSDVirtual(float_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 is not None
    assert var_0 == expected_result

expected_result = {'virtualization_tech_guest': set(),
 'virtualization_tech_host': set(),
 'virtualization_role': '',
 'virtualization_type': ''}

# Generated at 2022-06-25 01:21:56.149188
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    float_0 = -1884.7166
    net_b_s_d_virtual_0 = NetBSDVirtual(float_0)
    assert net_b_s_d_virtual_0 != None

# Generated at 2022-06-25 01:21:59.833152
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    float_0 = -1884.7166
    net_b_s_d_virtual_1 = NetBSDVirtual(float_0)
    var_0 = net_b_s_d_virtual_1.get_virtual_facts()


# Generated at 2022-06-25 01:22:02.882044
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    float_0 = 1078.2155
    net_b_s_d_virtual_0 = NetBSDVirtual(float_0)


# Generated at 2022-06-25 01:22:55.563734
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()


# Generated at 2022-06-25 01:23:00.939864
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    float_1 = -867.9017
    net_b_s_d_virtual_1 = NetBSDVirtual(float_1)
    var_2 = net_b_s_d_virtual_1.get_virtual_facts()
    print(var_2)

if __name__ == '__main__':
    test_case_0()


# Generated at 2022-06-25 01:23:06.320006
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual(0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:23:16.095193
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    float_0 = -1884.7166
    net_b_s_d_virtual_0 = NetBSDVirtual(float_0)
    float_1 = -1884.7166
    net_b_s_d_virtual_1 = NetBSDVirtual(float_1)
    float_2 = -1884.7166
    net_b_s_d_virtual_2 = NetBSDVirtual(float_2)
    float_3 = -1884.7166
    net_b_s_d_virtual_3 = NetBSDVirtual(float_3)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    var_1 = net_b_s_d_virtual_1.get_virtual_facts()
    var_2 = net_b_s_d_virtual_

# Generated at 2022-06-25 01:23:18.416942
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # TODO: Fix stub
    # float_0 = None
    # net_b_s_d_virtual_0 = NetBSDVirtual(float_0)
    # var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    assert True == False


# Generated at 2022-06-25 01:23:22.620052
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    float_0 = 2.0
    net_b_s_d_virtual_0 = NetBSDVirtual(float_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:23:25.824746
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
  net_b_s_d_virtual_0 = NetBSDVirtual()


# Generated at 2022-06-25 01:23:29.832579
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    float_0 = -1884.7166
    net_b_s_d_virtual_0 = NetBSDVirtual(float_0)
    result = net_b_s_d_virtual_0.get_virtual_facts()
    assert result == {'virtualization_type': '', 'virtualization_role': '', 'virtualization_tech_host': set(), 'virtualization_tech_guest': set()}


# Generated at 2022-06-25 01:23:34.495818
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    float_0 = -1884.7166
    net_b_s_d_virtual_0 = NetBSDVirtual(float_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:23:42.287723
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    float_0 = -1884.7166
    net_b_s_d_virtual_0 = NetBSDVirtual(float_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    dict_1 = {'virtualization_tech_guest': set([]), 'virtualization_tech_host': set([]), 'virtualization_type': '', 'virtualization_role': ''}
    assert var_0 == dict_1, "Return value of method get_virtual_facts of class NetBSDVirtual: %s" % var_0


# Generated at 2022-06-25 01:26:04.836692
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    float_0 = -1884.7166
    net_b_s_d_virtual_0 = NetBSDVirtual(float_0)

    float_1 = -1884.7166
    net_b_s_d_virtual_1 = NetBSDVirtual(float_1)
    net_b_s_d_virtual_2 = NetBSDVirtual(float_0)
    if net_b_s_d_virtual_0 != net_b_s_d_virtual_1:
        print('FAIL: expected', net_b_s_d_virtual_1, 'to be', net_b_s_d_virtual_0)
        raise Exception('FAILED')

# Generated at 2022-06-25 01:26:10.130892
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    float_0 = 4.0
    net_b_s_d_virtual_0 = NetBSDVirtual(float_0)
    virtual_facts_0 = net_b_s_d_virtual_0.get_virtual_facts()
    net_b_s_d_virtual_0 = NetBSDVirtual(float_0)
    virtual_facts_1 = net_b_s_d_virtual_0.get_virtual_facts()
    net_b_s_d_virtual_0 = NetBSDVirtual(float_0)
    virtual_facts_2 = net_b_s_d_virtual_0.get_virtual_facts()
    net_b_s_d_virtual_0 = NetBSDVirtual(float_0)
    virtual_facts_3 = net_b_s_d_virtual_0.get_virtual_facts

# Generated at 2022-06-25 01:26:12.213870
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    assert 1


# Generated at 2022-06-25 01:26:16.922141
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    float_0 = -1884.7166
    net_b_s_d_virtual_0 = NetBSDVirtual(float_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 is not None, "Failed to get virtual facts."
    assert len(var_0) != 0, "Failed to get virtual facts."
    assert "virtualization_type" in var_0, "Failed to get virtual facts."
    assert var_0.get('virtualization_type') == '' or var_0.get('virtualization_type') == 'xen', "Failed to get virtual facts."
    assert "virtualization_role" in var_0, "Failed to get virtual facts."
    assert var_0.get('virtualization_role') == '' or var_

# Generated at 2022-06-25 01:26:22.196531
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    float_1 = -5176.873
    net_b_s_d_virtual_1 = NetBSDVirtual(float_1)
    var_1 = net_b_s_d_virtual_1.get_virtual_facts()

if __name__ == "__main__":
    test_case_0()
    test_NetBSDVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:26:30.464230
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    float_0 = -14.4658
    net_b_s_d_virtual_0 = NetBSDVirtual(float_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 == {'virtualization_type': '', 'virtualization_role': '', 'virtualization_system': '', 'virtualization_tech_host': set(), 'virtualization_tech_guest': set()}
    var_1 = net_b_s_d_virtual_0.detect_virt_product('machdep.dmi.system-product')
    assert var_1 == {'virtualization_system': '', 'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}
    var_2 = net_b_s_d_virtual

# Generated at 2022-06-25 01:26:36.949867
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual = NetBSDVirtual(1.0)
    assert isinstance(net_b_s_d_virtual.get_virtual_facts(), dict)

# Basic test for class NetBSDVirtualCollector

# Generated at 2022-06-25 01:26:39.877125
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    float_0 = -9195.931
    net_b_s_d_virtual_0 = NetBSDVirtual(float_0)
    assert net_b_s_d_virtual_0._platform == 'NetBSD'


# Generated at 2022-06-25 01:26:44.005406
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    float_0 = -1884.7166
    net_b_s_d_virtual_0 = NetBSDVirtual(float_0)
    # print(net_b_s_d_virtual_0)
    # {'virtualization_type': '', 'virtualization_role': ''}
    test_case_0()


# Generated at 2022-06-25 01:26:48.290568
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()
