

# Generated at 2022-06-25 01:18:11.706734
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()
    net_b_s_d_virtual_0 = net_b_s_d_virtual_collector_0.collect(None, None)


# Generated at 2022-06-25 01:18:16.131904
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    assert net_b_s_d_virtual_0._platform == 'NetBSD'


# Generated at 2022-06-25 01:18:17.607551
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual(0)

# Generated at 2022-06-25 01:18:25.989536
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    import os
    import pytest
    import unittest
    from unittest.mock import Mock, patch

    # Patch AnsibleModule
    mock_AnsibleModule = Mock()
    mock_AnsibleModule_class = Mock()
    mock_AnsibleModule_class.return_value = mock_AnsibleModule

    with patch('ansible.module_utils.facts.virtual.netbsd.AnsibleModule', mock_AnsibleModule_class):

        # Patch sysctl_exists:
        mock_sysctl_exists = Mock()

# Generated at 2022-06-25 01:18:27.518261
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual(dict())

# Generated at 2022-06-25 01:18:28.461719
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector()


# Generated at 2022-06-25 01:18:30.403343
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    assert net_b_s_d_virtual_0

# Generated at 2022-06-25 01:18:36.886734
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    assert net_b_s_d_virtual_0.get_virtual_facts() == {'virtualization_role': 'guest', 'virtualization_type': 'kvm', 'virtualization_tech_guest': {'kvm'}, 'virtualization_tech_host': {'kvm'}}

# Generated at 2022-06-25 01:18:39.673870
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    assert net_b_s_d_virtual_0.get_virtual_facts() == {'virtualization_role': '', 'virtualization_type': ''}

# Generated at 2022-06-25 01:18:43.060709
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_object_0 = NetBSDVirtual()
    net_b_s_d_virtual_object_0.get_virtual_facts()

# Generated at 2022-06-25 01:18:49.010959
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    result = net_b_s_d_virtual_0.get_virtual_facts()
    assert isinstance(result, dict) is True

# Generated at 2022-06-25 01:18:51.456297
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()


if __name__ == "__main__":
    test_case_0()
    test_NetBSDVirtual()

# Generated at 2022-06-25 01:18:56.396607
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector = NetBSDVirtualCollector()
    # TODO: Implement assertion

if __name__ == '__main__':
    test_case_0()
    test_NetBSDVirtualCollector()

# Generated at 2022-06-25 01:19:04.396405
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    filtered_sysctl_0 = {'machdep.dmi.system-product': 'VirtualBox', 'machdep.dmi.system-vendor': 'innotek GmbH'}
    net_b_s_d_virtual_0 = NetBSDVirtual(filtered_sysctl_0)
    virtual_facts_0 = net_b_s_d_virtual_0.get_virtual_facts()
    assert(virtual_facts_0['virtualization_type'] == 'virtualbox')
    assert(virtual_facts_0['virtualization_role'] == 'guest')
    assert(virtual_facts_0['virtualization_tech_guest'] == {'virtualbox'})
    assert(virtual_facts_0['virtualization_tech_host'] == {'virtualbox'})

# Generated at 2022-06-25 01:19:09.230727
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()


# Generated at 2022-06-25 01:19:14.635701
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    # test constructor
    net_b_s_d_virtual_0 = NetBSDVirtual()

    # test properties
    assert net_b_s_d_virtual_0.platform == 'NetBSD'

    # test get_virtual_facts() method
    net_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:19:15.814231
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()


# Generated at 2022-06-25 01:19:18.036782
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
  net_b_s_d_virtual_collector = NetBSDVirtualCollector()


# Generated at 2022-06-25 01:19:21.979628
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    test_case_0()


# Generated at 2022-06-25 01:19:23.874531
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual = NetBSDVirtual()

# Generated at 2022-06-25 01:19:35.695792
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_instance = NetBSDVirtual()
    assert isinstance(net_b_s_d_virtual_instance.get_virtual_facts(), dict)


# Generated at 2022-06-25 01:19:38.648773
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()


# Generated at 2022-06-25 01:19:40.759031
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()

# Generated at 2022-06-25 01:19:48.249624
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    result = net_b_s_d_virtual_0.get_virtual_facts()
    assert result == {
        'virtualization_role': 'guest',
        'virtualization_type': 'xen',
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': {
            'xen'
        }
    }


test_NetBSDVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:19:51.188651
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    net_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:19:52.883130
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()


# Generated at 2022-06-25 01:19:54.305409
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()


# Generated at 2022-06-25 01:19:56.627615
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_1 = NetBSDVirtualCollector()
    assert net_b_s_d_virtual_collector_1._platform == 'NetBSD'



# Generated at 2022-06-25 01:19:57.716719
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    assert NetBSDVirtual().platform == 'NetBSD'


# Generated at 2022-06-25 01:20:00.428358
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual = NetBSDVirtual()
    net_b_s_d_virtual_get_virtual_facts = net_b_s_d_virtual.get_virtual_facts()

# Generated at 2022-06-25 01:20:17.485490
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    truthy_falsy = net_b_s_d_virtual_0.get_virtual_facts()
    assert truthy_falsy
    

# Generated at 2022-06-25 01:20:19.717126
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    assert net_b_s_d_virtual_0.get_virtual_facts() is not None

# Generated at 2022-06-25 01:20:23.112944
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual(dict())
    net_b_s_d_virtual_0.get_virtual_facts()


if __name__ == '__main__':
    test_case_0()
    test_NetBSDVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:20:28.948387
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual(data={})
    assert net_b_s_d_virtual_0.data == {}


# class NetBSDVirtual(Virtual)
# Method: get_virtual_facts
# Input: data={}
# Output: {'virtualization_role': '', 'virtualization_type': '', 'virtualization_tech_host': set(), 'virtualization_tech_guest': set()}
#
#

# Generated at 2022-06-25 01:20:31.719928
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    assert net_b_s_d_virtual_0.get_virtual_facts() is None


# Generated at 2022-06-25 01:20:35.381559
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()


# Generated at 2022-06-25 01:20:36.880608
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector = NetBSDVirtualCollector()


# Generated at 2022-06-25 01:20:37.969133
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
     net_b_s_d_virtual_0 = NetBSDVirtual()


# Generated at 2022-06-25 01:20:43.092095
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()


# Generated at 2022-06-25 01:20:48.401115
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    # Instantiation of class NetBSDVirtualCollector
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()
    # Instantiation of class NetBSDVirtual
    net_b_s_d_virtual_0 = NetBSDVirtual()
    # Accessing protected member variable of class NetBSDVirtual
    value = net_b_s_d_virtual_0._sysctl_get('machdep.dmi.system-product')
    # Accessing protected member variable of class NetBSDVirtual
    value = net_b_s_d_virtual_0._sysctl_get('machdep.dmi.system-vendor')
    # Assigning a int to a attribute of class NetBSDVirtual
    net_b_s_d_virtual_0.platform = 0
    # Accessing protected member variable of class NetBSDVirtual


# Generated at 2022-06-25 01:21:19.992004
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_collector = NetBSDVirtualCollector()
    net_b_s_d_virtual = net_b_s_d_virtual_collector.collect(None, None)

    assert net_b_s_d_virtual.get('virtualization_type') in ['', 'KVM']


# Generated at 2022-06-25 01:21:24.917146
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    net_b_s_d_virtual_0.populate()
    net_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:21:26.894143
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    result = net_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:21:27.731033
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    assert False

# Generated at 2022-06-25 01:21:32.010205
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    net_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:21:32.961267
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    assert NetBSDVirtual()


# Generated at 2022-06-25 01:21:35.559325
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    assert net_b_s_d_virtual_0.platform == 'NetBSD'


# Generated at 2022-06-25 01:21:36.568467
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()


# Generated at 2022-06-25 01:21:40.570293
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    net_b_s_d_virtual_0._detect_sysctl_virtual()
    net_b_s_d_virtual_0._detect_sysctl_virtual()
    net_b_s_d_virtual_0._detect_sysctl_virtual()
    net_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:21:42.870377
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()


# Generated at 2022-06-25 01:22:14.990250
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    set_0 = set()
    net_b_s_d_virtual_0 = NetBSDVirtual(set_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    assert 'virtualization_role' in var_0
    assert 'virtualization_type' in var_0
    assert var_0['virtualization_role'] == ''
    assert var_0['virtualization_type'] == ''
    assert var_0['virtualization_type_role'] == ''
    assert 'virtualization_tech' in var_0
    assert var_0['virtualization_tech'] == set()
    assert var_0['virtualization_role_facts'] == {}
    assert var_0['virtualization_type_facts'] == {}

# Generated at 2022-06-25 01:22:18.367668
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    set_0 = set()
    net_b_s_d_virtual_0 = NetBSDVirtual(set_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()



# Generated at 2022-06-25 01:22:24.397255
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # TODO: implement the real test case here
    set_0 = set()
    net_b_s_d_virtual_0 = NetBSDVirtual(set_0)
    net_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:22:28.393765
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()
    set_0 = set()
    net_b_s_d_virtual_0 = NetBSDVirtual(set_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 01:22:29.804139
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    set_0 = set()
    var_0 = NetBSDVirtual(set_0)
    assert var_0 != None


# Generated at 2022-06-25 01:22:31.924228
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    set_0 = set()
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector(set_0)
    var_0 = net_b_s_d_virtual_collector_0.get_all()

# Generated at 2022-06-25 01:22:34.015103
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    set_0 = set()
    net_b_s_d_virtual_0 = NetBSDVirtual(set_0)


# Generated at 2022-06-25 01:22:36.266561
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()
    set_0 = set()
    net_b_s_d_virtual_0 = NetBSDVirtual(set_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:22:38.609281
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()
    net_b_s_d_virtual_0 = NetBSDVirtual(set())
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:22:40.163264
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    set_0 = set()
    net_b_s_d_virtual_0 = NetBSDVirtual(set_0)


# Generated at 2022-06-25 01:23:38.640890
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    set_0 = set()
    net_b_s_d_virtual_0 = NetBSDVirtual(set_0)
    assert net_b_s_d_virtual_0._interfaces == set()


# Generated at 2022-06-25 01:23:42.617792
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    set_0 = set()
    net_b_s_d_virtual_0 = NetBSDVirtual(set_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    assert 'virtualization_type' in var_0
    assert 'virtualization_role' in var_0


# Generated at 2022-06-25 01:23:44.298408
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()
    assert net_b_s_d_virtual_collector_0


# Generated at 2022-06-25 01:23:46.673914
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    set_0 = set()
    net_b_s_d_virtual_0 = NetBSDVirtual(set_0)


# Generated at 2022-06-25 01:23:49.620765
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    pass

# Generated at 2022-06-25 01:23:56.637330
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    #- virtualization_type:
    #    - 'virtualbox'
    #  virtualization_role:
    #    - 'guest'
    set_0 = set()
    net_b_s_d_virtual_0 = NetBSDVirtual(set_0)
    assert net_b_s_d_virtual_0._virtualization_type == ''
    assert net_b_s_d_virtual_0._virtualization_role == ''
    assert net_b_s_d_virtual_0._virtualization_type_input == set_0
    assert net_b_s_d_virtual_0._virtualization_role_input == set_0
    assert net_b_s_d_virtual_0._virtualization_type_facts['virtualbox'] == 'virtualbox'
    assert net_b_s_d_virtual

# Generated at 2022-06-25 01:23:59.096403
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    set_0 = set()
    net_b_s_d_virtual_0 = NetBSDVirtual(set_0)


# Generated at 2022-06-25 01:24:00.484441
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    pass


# Generated at 2022-06-25 01:24:03.420874
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    set_0 = set()
    net_b_s_d_virtual_0 = NetBSDVirtual(set_0)
    assert net_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:24:04.560283
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    assert test_case_0() == None, "Constructor of class NetBSDVirtual is broken."


# Generated at 2022-06-25 01:26:34.841550
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():

    # Test constructing NetBSDVirtualCollector object with no params
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()

    assert net_b_s_d_virtual_collector_0._fact_class == NetBSDVirtual
    assert net_b_s_d_virtual_collector_0._platform == 'NetBSD'


# Generated at 2022-06-25 01:26:36.236158
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    var_0 = NetBSDVirtual()


# Generated at 2022-06-25 01:26:37.874535
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    set_0 = set()
    net_b_s_d_virtual_0 = NetBSDVirtual(set_0)
    net_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:26:45.518199
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()
    set_0 = set()
    net_b_s_d_virtual_0 = NetBSDVirtual(set_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    assert var_0['virtualization_role'] == ''
    assert var_0['virtualization_tech_host'] == set()
    assert var_0['virtualization_type'] == ''
    assert var_0['virtualization_tech_guest'] == set()

# Generated at 2022-06-25 01:26:47.884461
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # TODO: This is a placeholder for now - this test suite needs to be expanded
    test_case_0()

# Generated at 2022-06-25 01:26:50.239898
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()
    set_0 = set()
    net_b_s_d_virtual_0 = NetBSDVirtual(set_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:26:51.292151
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()


# Generated at 2022-06-25 01:26:53.763519
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    set_0 = set()
    net_b_s_d_virtual_0 = NetBSDVirtual(set_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:26:56.619604
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual = NetBSDVirtual(set())
    var = net_b_s_d_virtual.get_virtual_facts()


# Generated at 2022-06-25 01:26:58.529293
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()
    assert isinstance(net_b_s_d_virtual_collector_0, NetBSDVirtualCollector)
