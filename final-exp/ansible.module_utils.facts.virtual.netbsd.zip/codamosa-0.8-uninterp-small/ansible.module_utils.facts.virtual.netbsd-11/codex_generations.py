

# Generated at 2022-06-25 01:18:11.307835
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()
    assert net_b_s_d_virtual_collector_0.platform == 'NetBSD'
    assert net_b_s_d_virtual_collector_0._platform == 'NetBSD'


# Generated at 2022-06-25 01:18:14.443541
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()

# Generated at 2022-06-25 01:18:20.447609
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    net_b_s_d_virtual_0.detect_virt_product = lambda x: {'virtualization_type': 'product', 'virtualization_role': 'product'}
    net_b_s_d_virtual_0.detect_virt_vendor = lambda x: {'virtualization_type': 'vendor', 'virtualization_role': 'vendor'}
    net_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:18:22.670348
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    net_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:18:24.697865
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()


# Generated at 2022-06-25 01:18:25.875055
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()

# Unit Test for function get_virtual_facts in class NetBSDVirtualCollector

# Generated at 2022-06-25 01:18:27.435162
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()


# Generated at 2022-06-25 01:18:32.370279
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()
    net_b_s_d_virtual_0 = net_b_s_d_virtual_collector_0.collect()
    assert net_b_s_d_virtual_0.get_virtual_facts() == ''

# Generated at 2022-06-25 01:18:35.610599
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    assert net_b_s_d_virtual_0.get_virtual_facts() is not None


# Generated at 2022-06-25 01:18:38.025272
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
  net_b_s_d_virtual_0 = NetBSDVirtual()
  # expected output: {}
  print(net_b_s_d_virtual_0.get_virtual_facts())


# Generated at 2022-06-25 01:18:42.601078
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual = NetBSDVirtual()

# Generated at 2022-06-25 01:18:45.255637
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()


# Generated at 2022-06-25 01:18:51.086089
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual = NetBSDVirtual()
    result = net_b_s_d_virtual.get_virtual_facts()
    assert result['virtualization_type'] == 'qemu'
    assert result['virtualization_role'] == 'guest'
    assert result['virtualization_tech_guest'] == set()
    assert result['virtualization_tech_host'] == set()

# Unit test of method get_virtual_facts of class NetBSDVirtual

# Generated at 2022-06-25 01:18:55.972590
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_virtual_0 = NetBSDVirtual()
    assert type(net_b_s_d_virtual_virtual_0.get_virtual_facts()) is dict

# Generated at 2022-06-25 01:18:58.115060
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    pass

# Generated at 2022-06-25 01:19:04.657806
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual = NetBSDVirtual()

    virtual_facts = netbsd_virtual.get_virtual_facts()
    if virtual_facts['virtualization_type'] == '':
        assert(virtual_facts['virtualization_type'] == '')
        assert(virtual_facts['virtualization_role'] == '')


if __name__ == '__main__':
    test_case_0()
    test_NetBSDVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:19:11.435634
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    print('In test for get_virtual_facts of class NetBSDVirtual')
    net_b_s_d_virtual_0 = NetBSDVirtual()
    # AssertionError: assert 'virtualization_role' in net_b_s_d_virtual_0.get_virtual_facts()
    print('Test for get_virtual_facts of class NetBSDVirtual passed')


# Generated at 2022-06-25 01:19:17.949536
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()
    # Constructor test case
    assert net_b_s_d_virtual_collector_0


# Generated at 2022-06-25 01:19:20.158738
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    # Test if it is a instance of NetBSDVirtual class.
    assert isinstance(net_b_s_d_virtual_0, NetBSDVirtual)

# Generated at 2022-06-25 01:19:22.548662
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    virtual_facts_0 = net_b_s_d_virtual_0.get_virtual_facts()



# Generated at 2022-06-25 01:19:29.933300
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector



# Generated at 2022-06-25 01:19:34.265983
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()


# Generated at 2022-06-25 01:19:35.506464
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()


# Generated at 2022-06-25 01:19:39.048266
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    net_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:19:40.799233
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert NetBSDVirtualCollector() is not None


# Generated at 2022-06-25 01:19:51.968099
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()
    os.environ['ANSIBLE_LOCAL_TEMP'] = '/tmp/ansible'
    os.environ['ANSIBLE_NET_BSD_CONFIG'] = '/etc/ansible/facts.d/net_bsd.fact'
    net_b_s_d_virtual_0 = NetBSDVirtual()
    net_b_s_d_virtual_0_get_virtual_facts = net_b_s_d_virtual_0.get_virtual_facts()
    assert net_b_s_d_virtual_0_get_virtual_facts == {'virtualization_type': '', 'virtualization_role': '', 'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}

#

# Generated at 2022-06-25 01:19:52.994436
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert test_case_0() == None

# Generated at 2022-06-25 01:19:54.422169
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()


# Generated at 2022-06-25 01:19:55.831823
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual({})
    

# Generated at 2022-06-25 01:19:56.925762
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    result = NetBSDVirtual.get_virtual_facts(NetBSDVirtual)


# Generated at 2022-06-25 01:20:09.000172
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual(True)
    if net_b_s_d_virtual_0 is not None:
        net_b_s_d_virtual_0 = NetBSDVirtual(True)
        # Constructor should do nothing, just create the instance
        assert net_b_s_d_virtual_0 is not None


# Generated at 2022-06-25 01:20:17.229222
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    bool_0 = True
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector(bool_0)
    net_b_s_d_virtual_collector_0._fact_class = NetBSDVirtualCollector._fact_class
    net_b_s_d_virtual_collector_0._platform = NetBSDVirtualCollector._platform
    bool_0 = net_b_s_d_virtual_collector_0.collectable()
    bool_1 = net_b_s_d_virtual_collector_0.is_setup()
    bool_2 = net_b_s_d_virtual_collector_0.is_available()
    net_b_s_d_virtual_collector_0.collect()

# Generated at 2022-06-25 01:20:19.287636
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
  bool_0 = True
  net_b_s_d_virtual_0 = NetBSDVirtual(bool_0)
  assert net_b_s_d_virtual_0 != None


# Generated at 2022-06-25 01:20:21.321330
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    bool_0 = True
    net_b_s_d_virtual_0 = NetBSDVirtual(bool_0)


# Generated at 2022-06-25 01:20:24.584233
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    test_case_0()


# Generated at 2022-06-25 01:20:26.045782
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()
    test_case_0()

# Generated at 2022-06-25 01:20:28.844551
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    bool_0 = True
    net_b_s_d_virtual_0 = NetBSDVirtual(bool_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()



# Generated at 2022-06-25 01:20:32.318652
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    bool_0 = True  # True | False
    net_b_s_d_virtual_0 = NetBSDVirtual(bool_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    return var_0


# Generated at 2022-06-25 01:20:36.102902
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    bool_0 = True
    net_b_s_d_virtual_0 = NetBSDVirtual(bool_0)


# Generated at 2022-06-25 01:20:40.114978
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    bool_0 = True
    net_b_s_d_virtual_0 = NetBSDVirtual(bool_0)
    assert_equal(net_b_s_d_virtual_0.get_virtual_facts(), {'virtualization_role': 'guest', 'virtualization_type': 'xen', 'virtualization_tech_guest': {'xen'}, 'virtualization_tech_host': set()})

# Generated at 2022-06-25 01:20:56.907636
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()
    var_0 = net_b_s_d_virtual_collector_0.collect()

# Generated at 2022-06-25 01:21:03.021891
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    assert isinstance(net_b_s_d_virtual_0.get_virtual_facts(), dict)



# Generated at 2022-06-25 01:21:06.928485
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    bool_0 = True
    net_b_s_d_virtual_0 = NetBSDVirtual(bool_0)
    assert net_b_s_d_virtual_0.get_virtual_facts() == {}


# Generated at 2022-06-25 01:21:11.349179
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()

# Generated at 2022-06-25 01:21:13.471127
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    bool_0 = True
    net_b_s_d_virtual_0 = NetBSDVirtual(bool_0)
    assert net_b_s_d_virtual_0 is not None



# Generated at 2022-06-25 01:21:18.601085
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    bool_0 = True
    net_b_s_d_virtual_0 = NetBSDVirtual(bool_0)


# Generated at 2022-06-25 01:21:23.037474
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    bool_0 = True
    net_b_s_d_virtual_0 = NetBSDVirtual(bool_0)
    assert net_b_s_d_virtual_0.is_linux is True


# Generated at 2022-06-25 01:21:26.191566
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual(None)
    assert type(net_b_s_d_virtual_0) is NetBSDVirtual


# Generated at 2022-06-25 01:21:31.463441
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    bool_0 = True
    net_b_s_d_virtual_0 = NetBSDVirtual(bool_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:21:35.838477
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
  try:
	  bool_0 = True
	  net_b_s_d_virtual_0 = NetBSDVirtual(bool_0)
	  assert net_b_s_d_virtual_0.get_virtual_facts() is not None
  except Exception as e:
	  print(e)

 


# Generated at 2022-06-25 01:22:08.250532
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    bool_0 = True
    net_b_s_d_virtual_0 = NetBSDVirtual(bool_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 == {'virtualization_role': 'guest',
                     'virtualization_type': 'virtualbox',
                     'virtualization_tech_guest': set(['virtualbox']),
                     'virtualization_tech_host': set(['virtualbox'])}

# Generated at 2022-06-25 01:22:11.421211
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    bool_0 = True
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector(bool_0)
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector(bool_0)

# Generated at 2022-06-25 01:22:14.539241
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    bool_0 = True
    net_b_s_d_virtual_0 = NetBSDVirtual(bool_0)


# Generated at 2022-06-25 01:22:17.756782
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()

if __name__ == '__main__':
    test_case_0()
    test_NetBSDVirtualCollector()

# Generated at 2022-06-25 01:22:26.006813
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    bool_0 = True
    net_b_s_d_virtual_0 = NetBSDVirtual(bool_0)
    try:
        net_b_s_d_virtual_0.get_virtual_facts()
    except Exception as exception:
        print("Test test_NetBSDVirtual for NetBSDVirtual failed with " + exception)

if __name__ == '__main__':
    test_case_0()
    test_NetBSDVirtual()

# Generated at 2022-06-25 01:22:28.351762
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    bool_0 = True
    net_b_s_d_virtual_0 = NetBSDVirtual(bool_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:22:33.040056
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    bool_0 = True
    net_b_s_d_virtual_0 = NetBSDVirtual(bool_0)


# Generated at 2022-06-25 01:22:34.730487
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual(True)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 == {}



# Generated at 2022-06-25 01:22:36.218474
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    bool_0 = True
    net_b_s_d_virtual_0 = NetBSDVirtual(bool_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:22:39.558570
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()

if __name__ == '__main__':
    test_case_0()
    test_NetBSDVirtualCollector()

# Generated at 2022-06-25 01:23:42.475280
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    bool_0 = True
    net_b_s_d_virtual_0 = NetBSDVirtual(bool_0)


# Generated at 2022-06-25 01:23:49.678429
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    # Testing with None boolean
    bool_0 = None
    net_b_s_d_virtual_0 = NetBSDVirtual(bool_0)
    var_0 = net_b_s_d_virtual_0.platform
    assert var_0 == 'NetBSD'
    # Testing with False boolean
    bool_1 = False
    net_b_s_d_virtual_1 = NetBSDVirtual(bool_1)
    var_1 = net_b_s_d_virtual_1.platform
    assert var_1 == 'NetBSD'
    # Testing with True boolean
    bool_2 = True
    net_b_s_d_virtual_2 = NetBSDVirtual(bool_2)
    var_2 = net_b_s_d_virtual_2.platform
    assert var_2 == 'NetBSD'



# Generated at 2022-06-25 01:23:51.095270
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    case_0()


# Generated at 2022-06-25 01:23:54.118997
# Unit test for constructor of class NetBSDVirtualCollector

# Generated at 2022-06-25 01:24:04.852673
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    bool_0 = False
    net_b_s_d_virtual_0 = NetBSDVirtual(bool_0)
    assert net_b_s_d_virtual_0.detect_virt_product('machdep.dmi.system-product') == {'virtualization_tech_guest': set(), 'virtualization_tech_host': set(), 'virtualization_type': '', 'virtualization_role': ''}
    assert net_b_s_d_virtual_0.detect_virt_vendor('machdep.dmi.system-vendor') == {'virtualization_tech_guest': set(), 'virtualization_tech_host': set(), 'virtualization_type': '', 'virtualization_role': ''}


# Generated at 2022-06-25 01:24:09.717297
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    bool_0 = True
    net_b_s_d_virtual_0 = NetBSDVirtual(bool_0)



# Generated at 2022-06-25 01:24:13.578452
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual(True)
    assert net_b_s_d_virtual_0.get_virtual_facts() == {'virtualization_role': 'guest', 'virtualization_type': 'openvz', 'virtualization_tech_guest': set(['openvz']), 'virtualization_tech_host': set(['openvz'])}


# Generated at 2022-06-25 01:24:17.969168
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()

if __name__ == '__main__':
    test_case_0()
    test_NetBSDVirtualCollector()

# Generated at 2022-06-25 01:24:21.545102
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    bool_0 = True
    net_b_s_d_virtual_0 = NetBSDVirtual(bool_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    if var_0:
        pass


# Generated at 2022-06-25 01:24:25.672702
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    try:
        net_b_s_d_virtual_0 = NetBSDVirtual()
        net_b_s_d_virtual_0.get_virtual_facts()
    except Exception:
        assert False


# Generated at 2022-06-25 01:27:10.402594
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    try:
        test_case_0()
    except:
        assert False

# Generated at 2022-06-25 01:27:20.021430
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    bool_0 = True
    net_b_s_d_virtual_0 = NetBSDVirtual(bool_0)
    assert net_b_s_d_virtual_0.get_virtual_facts() == {'virtualization_role': '', 'virtualization_tech_host': set(), 'virtualization_type': '', 'virtualization_tech_guest': set()}
    bool_1 = True
    net_b_s_d_virtual_1 = NetBSDVirtual(bool_1)
    assert net_b_s_d_virtual_1.get_virtual_facts() == {'virtualization_role': '', 'virtualization_tech_host': set(), 'virtualization_type': '', 'virtualization_tech_guest': set()}
    bool_2 = True
    net_b_s_d_virtual_2

# Generated at 2022-06-25 01:27:24.392063
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    assert isinstance(test_case_0(), dict)

# Generated at 2022-06-25 01:27:25.515551
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()


# Generated at 2022-06-25 01:27:26.655603
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector(None)


# Generated at 2022-06-25 01:27:33.396984
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    bool_0 = True
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector(bool_0)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 01:27:39.850841
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    assert len(var_0) == 3
    assert var_0['virtualization_role'] == ''
    assert var_0['virtualization_type'] == ''


# Generated at 2022-06-25 01:27:43.344454
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    bool_0 = True
    net_b_s_d_virtual_0 = NetBSDVirtual(bool_0)


# Generated at 2022-06-25 01:27:44.424152
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()


# Generated at 2022-06-25 01:27:48.210047
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    bool_0 = True
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector(bool_0)
    net_b_s_d_virtual_collector_1 = NetBSDVirtualCollector(bool_0)
