

# Generated at 2022-06-25 01:18:09.845861
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    print(dir(net_b_s_d_virtual_0))
    net_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:18:10.736497
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()


# Generated at 2022-06-25 01:18:14.262046
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()


# Generated at 2022-06-25 01:18:19.239979
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    virtual_facts = net_b_s_d_virtual_collector_0.collect()
    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_guest'] == {'xen'}
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-25 01:18:20.195665
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    assert True

# Generated at 2022-06-25 01:18:21.862784
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()


# Generated at 2022-06-25 01:18:23.297308
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()


# Generated at 2022-06-25 01:18:27.391357
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()
    net_b_s_d_virtual_collector_0.get_virtual_facts(NetBSDVirtual)


# Generated at 2022-06-25 01:18:29.343557
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()

    # TODO: Add additional tests here

# Generated at 2022-06-25 01:18:33.997870
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    # Assert that NetBSDVirtual class has 'platform' attribute
    assert hasattr(net_b_s_d_virtual_0, 'platform')


# Generated at 2022-06-25 01:18:43.438294
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    str_0 = '7jlBKV-{'
    dict_0 = {str_0: str_0, str_0: str_0}
    list_0 = [dict_0, str_0, str_0, dict_0]
    net_b_s_d_virtual_0 = NetBSDVirtual(list_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    print(var_0)

# Generated at 2022-06-25 01:18:52.168351
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Replace sysctl call with mock data
    def mocked_sysctl(*args, **kwargs):
        return {
            'machdep.dmi.system-product': 'QEMU Standard PC (i440FX + PIIX, 1996)',
            'machdep.dmi.system-vendor': 'QEMU',
            'machdep.hypervisor': 'Xen 4.2.0-rc1 x86_64',
        }

    netbsd_virtual = NetBSDVirtual(None)
    netbsd_virtual.sysctl_all = mocked_sysctl


# Generated at 2022-06-25 01:18:58.938739
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    list_0 = [
        {
            'machdep.dmi.system-product': ''
        },
        '',
        '',
        [
            {
                'machdep.dmi.system-product': ''
            },
            '',
            '',
            {
                'machdep.dmi.system-product': ''
            }
        ]
    ]
    net_b_s_d_virtual_0 = NetBSDVirtual(list_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    var_1 = net_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 != var_1


# Generated at 2022-06-25 01:19:03.143635
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    str_0 = '7jlBKV-{'
    dict_0 = {str_0: str_0, str_0: str_0}
    list_0 = [dict_0, str_0, str_0, dict_0]
    net_b_s_d_virtual_0 = NetBSDVirtual(list_0)
    assert net_b_s_d_virtual_0.get_virtual_facts() == {}


# Generated at 2022-06-25 01:19:07.039074
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    str_1 = "machdep.hypervisor.vendor"
    str_2 = "machdep.hypervisor.version"
    str_3 = "machdep.dmi.system-vendor"
    str_4 = "machdep.dmi.system-product"
    list_1 = [str_1, str_2, str_3, str_4]
    net_b_s_d_virtual_1 = NetBSDVirtual(list_1)


# Generated at 2022-06-25 01:19:10.592814
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    str_0 = '7jlBKV-{'
    dict_0 = {str_0: str_0, str_0: str_0}
    list_0 = [dict_0, str_0, str_0, dict_0]
    net_b_s_d_virtual_0 = NetBSDVirtual(list_0)

# Generated at 2022-06-25 01:19:18.138088
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    str_0 = '7jlBKV-{'
    dict_0 = {str_0: str_0, str_0: str_0}
    list_0 = [dict_0, str_0, str_0, dict_0]
    net_b_s_d_virtual_0 = NetBSDVirtual(list_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:19:26.562466
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    str_0 = '7jlBKV-{'
    dict_0 = {str_0: str_0, str_0: str_0}
    list_0 = [dict_0, str_0, str_0, dict_0]
    net_b_s_d_virtual_0 = NetBSDVirtual(list_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:19:28.124694
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    test_case_0()


# Generated at 2022-06-25 01:19:28.964733
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    test_case_0()

# Generated at 2022-06-25 01:19:41.500392
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 == {}
    net_b_s_d_virtual_1 = NetBSDVirtual({'machdep.dmi.system-product': 'transmeta', 'machdep.hypervisor': 'xen'})
    var_1 = net_b_s_d_virtual_1.get_virtual_facts()
    assert var_1 == {'virtualization_role': 'guest', 'virtualization_type': 'xen', 'virtualization_tech_guest': set(['xen']), 'virtualization_tech_host': set(['xen'])}

# Generated at 2022-06-25 01:19:48.746815
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
  # Test for method __init__(self, sysctl_values)
  net_b_s_d_virtual_0 = NetBSDVirtual(['','','',''])
  assert str(net_b_s_d_virtual_0) == 'NetBSDVirtual []'
  net_b_s_d_virtual_0 = NetBSDVirtual(['','','',''])
  assert str(net_b_s_d_virtual_0) == 'NetBSDVirtual []'


# Generated at 2022-06-25 01:19:49.951949
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    test_case_0()


# Generated at 2022-06-25 01:19:53.556686
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    str_0 = '/dev/xencons'
    str_1 = 'machdep.dmi.system-product'
    str_2 = 'machdep.hypervisor'
    str_3 = '7jlBKV-{'

    dict_0 = {str_3: str_3, str_3: str_3}
    list_0 = [dict_0, str_3, str_3, dict_0, str_2]
    list_1 = [dict_0, str_3, str_3, dict_0, str_1]
    net_b_s_d_virtual_0 = NetBSDVirtual(list_0)

    os.path.exists = MagicMock(return_value=True)

# Generated at 2022-06-25 01:19:58.323935
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    str_0 = '7jlBKV-{'
    dict_0 = {str_0: str_0, str_0: str_0}
    list_0 = [dict_0, str_0, str_0, dict_0]
    net_b_s_d_virtual_0 = NetBSDVirtual(list_0)
    assert net_b_s_d_virtual_0.get_virtual_facts() is not None


# Generated at 2022-06-25 01:20:03.833682
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    dict_0 = {'XYv~8W': 'XYv~8W'}
    str_0 = 'xj+euX'
    str_1 = 'xj+euX'
    net_b_s_d_virtual_0 = NetBSDVirtual(str_0)
    net_b_s_d_virtual_0 = NetBSDVirtual(str_1)
    net_b_s_d_virtual_0 = NetBSDVirtual(dict_0)
    net_b_s_d_virtual_0 = NetBSDVirtual(dict_0)



# Generated at 2022-06-25 01:20:05.842025
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    list_0 = ['a', 'a', 'a', 'a', 'a']
    net_b_s_d_virtual_0 = NetBSDVirtual(list_0)
    assert not hasattr(net_b_s_d_virtual_0, 'list_0')


# Generated at 2022-06-25 01:20:10.216495
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    str_0 = '7/7'
    str_1 = '7jlBKV-{'
    dict_0 = {str_1: str_0, 'w2g#{': str_1, str_1: str_1}
    list_0 = [dict_0, str_0, str_1, dict_0]
    net_b_s_d_virtual_0 = NetBSDVirtual(list_0)


# Generated at 2022-06-25 01:20:13.243232
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    # NetBSDVirtualCollector(self, module)
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()
    assert net_b_s_d_virtual_collector_0 is not None

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 01:20:23.564943
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
  str_0 = 'oscknx'
  dict_0 = {str_0: str_0, str_0: str_0}
  str_1 = 'a7fqXr'
  dict_1 = {str_1: str_1, str_1: str_1}
  list_0 = [dict_0, str_1, str_1, dict_0]
  net_b_s_d_virtual_0 = NetBSDVirtual(list_0)
  # Call method with arguments where the expected result is set to None
  var_0 = net_b_s_d_virtual_0.get_virtual_facts()
  # Call method with arguments where the expected result is set to None
  var_1 = net_b_s_d_virtual_0.get_virtual_facts()
  # Call method

# Generated at 2022-06-25 01:20:40.412406
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    str_0 = 'vT8Wn_w0'
    dict_0 = {str_0: str_0, str_0: str_0}
    list_0 = [dict_0, str_0, str_0, dict_0]
    net_b_s_d_virtual_0 = NetBSDVirtual(list_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:20:42.774921
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    assert callable(NetBSDVirtual)


# Generated at 2022-06-25 01:20:47.551375
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    host_tech = set()
    guest_tech = set()
    list_0 = [host_tech, host_tech, host_tech]
    net_b_s_d_virtual_0 = NetBSDVirtual(list_0)
    assert isinstance(net_b_s_d_virtual_0, NetBSDVirtual)


# Generated at 2022-06-25 01:20:52.522477
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()
    assert net_b_s_d_virtual_collector_0._platform == 'NetBSD'

# Generated at 2022-06-25 01:21:00.092285
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual(list)
    str_0 = '7jlBKV-{'
    dict_0 = {str_0: str_0, str_0: str_0}
    list_0 = [dict_0, str_0, str_0, dict_0]
    net_b_s_d_virtual_0.platform_facts['machdep.hypervisor'] = 'QEMU'
    net_b_s_d_virtual_0.platform_facts['machdep.dmi.system-product'] = 'KVM'
    net_b_s_d_virtual_0.platform_facts['machdep.dmi.system-vendor'] = 'QEMU'
    assert net_b_s_d_virtual_0.get_virtual

# Generated at 2022-06-25 01:21:05.092644
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    str_0 = '_'
    dict_0 = {str_0: str_0, str_0: str_0}
    list_0 = [dict_0, str_0, str_0, dict_0]
    net_b_s_d_virtual_0 = NetBSDVirtual(list_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:21:08.637794
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector(None)
    var_0 = net_b_s_d_virtual_collector_0._fact_class
    assert isinstance(var_0, NetBSDVirtual)
    var_1 = net_b_s_d_virtual_collector_0._platform
    assert var_1 == 'NetBSD'


# Generated at 2022-06-25 01:21:14.105712
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    if os.path.exists("/dev/xencons/"):
        assert NetBSDVirtualCollector().collect() == {'virtualization_role': 'guest', 'virtualization_type': 'xen'}
    elif os.path.exists("/proc/xen/"):
        assert NetBSDVirtualCollector().collect() == {'virtualization_role': 'host', 'virtualization_type': 'xen'}
    elif os.path.exists("/proc/hypervisor/"):
        assert NetBSDVirtualCollector().collect() == {'virtualization_role': 'host', 'virtualization_type': 'kvm'}

# Generated at 2022-06-25 01:21:16.950788
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    list_0 = [{}, {}]
    net_b_s_d_virtual_0 = NetBSDVirtual(list_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 == {'virtualization_role': '', 'virtualization_type': '', 'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}


# Generated at 2022-06-25 01:21:18.151301
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_1 = NetBSDVirtual()
    var_0 = net_b_s_d_virtual_1.get_virtual_facts()


# Generated at 2022-06-25 01:21:52.361190
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    str_0 = 'Ol>&SxSxSxSxSxSxSxSxSxSxSxSxSxSxSxSxSxSxSxSxSxSxSxSxSxSxSx'
    dict_0 = {}
    list_0 = []
    net_b_s_d_virtual_0 = NetBSDVirtual(list_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    try:
        assert var_0 == dict_0
    except AssertionError as var_1:
        raise AssertionError(var_1)

# Generated at 2022-06-25 01:21:56.542567
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    list_0 = list()
    net_b_s_d_virtual_0 = NetBSDVirtual(list_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    var_1 = net_b_s_d_virtual_0.get_virtual_facts()
    assert (var_0 == var_1)


# Generated at 2022-06-25 01:21:59.638315
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    # Test case 0
    list_0 = ['', '', '']
    net_b_s_d_virtual_0 = NetBSDVirtual(list_0)


# Generated at 2022-06-25 01:22:05.488904
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    str_0 = '7jlBKV-{'
    dict_0 = {str_0: str_0, str_0: str_0}
    list_0 = [dict_0, str_0, str_0, dict_0]
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector(list_0)

# Generated at 2022-06-25 01:22:06.253954
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
  NetBSDVirtualCollector()


# Generated at 2022-06-25 01:22:07.354630
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()

# Generated at 2022-06-25 01:22:12.771303
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    list_0 = [{'Xen': '7jlBKV-{', 'Xen': '7jlBKV-{'}, '7jlBKV-{', '7jlBKV-{',
              {'Xen': '7jlBKV-{', 'Xen': '7jlBKV-{'}]
    net_b_s_d_virtual_0 = NetBSDVirtual(list_0)
    str_0 = net_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:22:19.201626
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    str_0 = '7jlBKV-{'
    dict_0 = {str_0: str_0, str_0: str_0}
    list_0 = [dict_0, str_0, str_0, dict_0]
    net_b_s_d_virtual_0 = NetBSDVirtual(list_0)
    assert net_b_s_d_virtual_0._platform == 'NetBSD'
    assert net_b_s_d_virtual_0.found is False
    assert net_b_s_d_virtual_0.facts == list_0


# Generated at 2022-06-25 01:22:26.256401
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    str_0 = '7jlBKV-{'
    dict_0 = {str_0: str_0, str_0: str_0}
    list_0 = [dict_0, str_0, str_0, dict_0]
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector(list_0)

# Generated at 2022-06-25 01:22:30.753063
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    str_0 = 'kKjFy)i!3'
    dict_0 = {str_0: str_0, str_0: [str_0, str_0]}
    list_0 = [str_0, str_0, dict_0, str_0, str_0]
    net_b_s_d_virtual_0 = NetBSDVirtual(list_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:23:30.550734
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    str_0 = '7jlBKV-{'
    dict_0 = {str_0: str_0, str_0: str_0}
    list_0 = [dict_0, str_0, str_0, dict_0]
    net_b_s_d_virtual_0 = NetBSDVirtual(list_0)
    str_1 = net_b_s_d_virtual_0.platform
    assert str_1 == 'NetBSD'
    # Testing the get_virtual_facts method of class NetBSDVirtual.
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:23:31.548287
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    try:
        test_case_0()
    except:
        assert False


# Generated at 2022-06-25 01:23:35.770588
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    str_0 = '7jlBKV-{'
    dict_0 = {str_0: str_0, str_0: str_0}
    list_0 = [dict_0, str_0, str_0, dict_0]
    net_b_s_d_virtual_0 = NetBSDVirtual(list_0)
    assert type(net_b_s_d_virtual_0) is NetBSDVirtual


# Generated at 2022-06-25 01:23:41.535399
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector({'str': 'str'})
    assert (net_b_s_d_virtual_collector_0._fact_class == NetBSDVirtual)
    assert (net_b_s_d_virtual_collector_0._platform == 'NetBSD')


if __name__ == '__main__':
    test_case_0()
    test_NetBSDVirtualCollector()

# Generated at 2022-06-25 01:23:46.795465
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Initializing the object
    net_b_s_d_virtual_0 = NetBSDVirtual()
    # Invoking the method
    result_0 = net_b_s_d_virtual_0.get_virtual_facts()
    # Test expected result
    assert result_0 == {'virtualization_type': '', 'virtualization_role': '',
                        'virtualization_tech_guest': set(), 'virtualization_tech_host': set(),
                        'virtualization_product_name': ''}


# Generated at 2022-06-25 01:23:54.382919
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    str_0 = ',p*}wDy'
    dict_0 = {str_0: str_0, str_0: str_0}
    list_0 = [dict_0, str_0, str_0, dict_0]
    net_b_s_d_virtual_0 = NetBSDVirtual(list_0)
    net_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:24:01.610251
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector = NetBSDVirtualCollector()
    assert net_b_s_d_virtual_collector is not None
    assert net_b_s_d_virtual_collector.platform is not None


# Generated at 2022-06-25 01:24:07.506387
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    # Test for str or other type
    str_0 = '7jlBKV-{'
    dict_0 = {str_0: str_0, str_0: str_0}
    list_0 = [dict_0, str_0, str_0, dict_0]
    net_b_s_d_virtual_0 = NetBSDVirtual(list_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    # Test expected Exception
    net_b_s_d_virtual_1 = NetBSDVirtual()
    var_1 = net_b_s_d_virtual_1.get_virtual_facts()
    return


# Generated at 2022-06-25 01:24:10.633486
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()
    assert net_b_s_d_virtual_collector_0._fact_class == NetBSDVirtual
    assert net_b_s_d_virtual_collector_0._platform == 'NetBSD'

# Generated at 2022-06-25 01:24:12.311880
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()

# Generated at 2022-06-25 01:26:39.392846
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    #print(NetBSDVirtual.__name__)
    net_b_s_d_virtual_0 = NetBSDVirtual()
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:26:45.149608
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    str_0 = '7nljBKL-{'
    dict_0 = {str_0: str_0, str_0: str_0}
    list_0 = [dict_0, str_0, str_0, dict_0]
    net_b_s_d_virtual_0 = NetBSDVirtual(list_0)
    assert net_b_s_d_virtual_0._legacy_facts == list_0


# Generated at 2022-06-25 01:26:50.596786
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    str_0 = '7jlBKV-{'
    dict_0 = {str_0: str_0, str_0: str_0}
    list_0 = [dict_0, str_0, str_0, dict_0]
    net_b_s_d_virtual_0 = NetBSDVirtual(list_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:26:52.589120
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector(None, None)

# Generated at 2022-06-25 01:27:00.174720
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    str_0 = 'NF1NXqG#r'
    dict_0 = {str_0: str_0, str_0: str_0}
    list_0 = [dict_0, str_0, str_0, dict_0]
    str_1 = 'k{H<v}X'
    dict_1 = {str_1: str_1, str_1: str_1}
    list_1 = [dict_1, str_1, str_1, dict_1]
    str_2 = 'sZ'
    dict_2 = {str_2: str_2, str_2: str_2}
    list_2 = [dict_2, str_2, str_2, dict_2]

# Generated at 2022-06-25 01:27:05.264662
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    str_0 = 't`N{-BJ'
    dict_0 = {str_0: str_0, str_0: str_0}
    list_0 = [dict_0, str_0, str_0, dict_0]
    net_b_s_d_virtual_0 = NetBSDVirtual(list_0)


# Generated at 2022-06-25 01:27:07.894578
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    str_0 = '7jlBKV-{'
    dict_0 = {str_0: str_0, str_0: str_0}
    list_0 = [dict_0, str_0, str_0, dict_0]
    net_b_s_d_virtual_0 = NetBSDVirtual(list_0)

    assert net_b_s_d_virtual_0 != None


# Generated at 2022-06-25 01:27:12.206276
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    str_0 = '5Zi,5:'
    dict_0 = {str_0: str_0}
    list_0 = [dict_0, str_0, str_0, dict_0]
    net_b_s_d_virtual_0 = NetBSDVirtual(list_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:27:16.894301
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    # Declaration of the NetBSDVirtualCollector object
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()

# Generated at 2022-06-25 01:27:17.724766
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    assert False
