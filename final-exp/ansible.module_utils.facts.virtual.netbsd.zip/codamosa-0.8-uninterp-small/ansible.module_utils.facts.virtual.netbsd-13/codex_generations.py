

# Generated at 2022-06-25 01:18:16.001348
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()
    assert type(net_b_s_d_virtual_collector_0) == NetBSDVirtualCollector


# Generated at 2022-06-25 01:18:17.476872
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()


# Generated at 2022-06-25 01:18:22.735875
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()

# Generated at 2022-06-25 01:18:26.567767
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()

    # Test if instance created properly
    assert net_b_s_d_virtual_0.platform == 'NetBSD'


# Generated at 2022-06-25 01:18:27.332603
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()


# Generated at 2022-06-25 01:18:29.711190
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    try:
        net_b_s_d_virtual_collector_1 = NetBSDVirtualCollector()
    except Exception:
        assert False, 'Could not initialize NetBSDVirtualCollector'

# Generated at 2022-06-25 01:18:30.840149
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()


# Generated at 2022-06-25 01:18:33.186963
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert isinstance(NetBSDVirtualCollector(), NetBSDVirtualCollector)


# Generated at 2022-06-25 01:18:38.549122
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()
    net_b_s_d_virtual_0 = net_b_s_d_virtual_collector_0.collect()
    result = net_b_s_d_virtual_0.get_virtual_facts()
    assert result is not None


# Generated at 2022-06-25 01:18:45.061259
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()
# Testing if instance of class NetBSDVirtualCollector is created succesfully
    assert isinstance(net_b_s_d_virtual_collector_0, NetBSDVirtualCollector)

# Generated at 2022-06-25 01:18:58.527486
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    virtual_facts = net_b_s_d_virtual_0.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_subsystem'] == ''
    assert virtual_facts['virtualization_system'] == ''
    assert virtual_facts['virtualization_guest_type'] == ''
    assert virtual_facts['virtualization_host_type'] == ''
    assert virtual_facts['virtualization_host_distribution'] == ''
    assert virtual_facts['virtualization_guest_distribution'] == ''
    assert virtual_facts['virtualization_host_distribution_release'] == ''

# Generated at 2022-06-25 01:19:04.009796
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()
    assert net_b_s_d_virtual_collector_0._platform == 'NetBSD'
    assert net_b_s_d_virtual_collector_0._fact_class == NetBSDVirtual


# Generated at 2022-06-25 01:19:10.596550
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()
    assert net_b_s_d_virtual_collector_0._platform == 'NetBSD'
    assert net_b_s_d_virtual_collector_0._fact_class == NetBSDVirtual


# Generated at 2022-06-25 01:19:13.663534
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()


# Generated at 2022-06-25 01:19:16.362487
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
  net_b_s_d_virtual_0 = NetBSDVirtual()


# Generated at 2022-06-25 01:19:18.249859
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    print('Unit test for constructor of class NetBSDVirtualCollector')


# Generated at 2022-06-25 01:19:22.348336
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()


# Generated at 2022-06-25 01:19:25.246161
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert net_b_s_d_virtual_collector_0.__class__ == NetBSDVirtualCollector

# No error for asserting a test case for NetBSDVirtual

# Generated at 2022-06-25 01:19:26.373804
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()


# Generated at 2022-06-25 01:19:28.928415
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    net_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:19:37.002489
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xc2\xba\xba\xb9\x96x\xec\x07?\xc0'
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0)
    test_case_0(net_b_s_d_virtual_0)

# Generated at 2022-06-25 01:19:42.205089
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    bytes_0 = b'\xc2\xba\xba\xb9\x96x\xec\x07?\xc0'
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0)


# Generated at 2022-06-25 01:19:43.995054
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    result = NetBSDVirtualCollector()
    assert isinstance(result, NetBSDVirtualCollector)

# Generated at 2022-06-25 01:19:46.647009
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()

# Generated at 2022-06-25 01:19:52.348128
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    bytes_0 = b'\xc2\xba\xba\xb9\x96x\xec\x07?\xc0'
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0)
    assert isinstance(net_b_s_d_virtual_0, NetBSDVirtual)
    assert isinstance(net_b_s_d_virtual_0, Virtual)



# Generated at 2022-06-25 01:19:54.967729
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    bytes_0 = b'\xc2\xba\xba\xb9\x96x\xec\x07?\xc0'
    var_0 = NetBSDVirtual(bytes_0)


# Generated at 2022-06-25 01:20:01.289791
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xc2\xba\xba\xb9\x96x\xec\x07?\xc0'
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    var_1 = net_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 == var_1
    assert var_0 is not var_1

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 01:20:09.646571
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()
    from ansible.module_utils.facts.virtual.sysctl import VirtualSysctlDetectionMixin

    assert net_b_s_d_virtual_collector_0._fact_class == NetBSDVirtual
    assert net_b_s_d_virtual_collector_0._platform == 'NetBSD'

if __name__ == '__main__':
    test_case_0()

    test_NetBSDVirtualCollector()

# Generated at 2022-06-25 01:20:12.965399
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xc2\xba\xba\xb9\x96x\xec\x07?\xc0'
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:20:17.855199
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    bytes_0 = b'\xc2\xba\xba\xb9\x96x\xec\x07?\xc0'
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector(bytes_0)

# Generated at 2022-06-25 01:20:30.603308
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
  expected_var = {'virtualization_role': '', 'virtualization_type': '', 'virtualization_tech_host': set(), 'virtualization_tech_guest': set()}

  # Setup test data
  bytes_0 = b'\xc2\xba\xba\xb9\x96x\xec\x07?\xc0'
  net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0)

  # Invoke method
  var_0 = net_b_s_d_virtual_0.get_virtual_facts()

  assert var_0 == expected_var

# Generated at 2022-06-25 01:20:35.753243
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    bytes_0 = b'\xc2\xba\xba\xb9\x96x\xec\x07?\xc0'
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0)

# Generated at 2022-06-25 01:20:39.303725
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    bytes_0 = b'\xc2\xba\xba\xb9\x96x\xec\x07?\xc0'
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()



# Generated at 2022-06-25 01:20:47.815837
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
   bytes_data = b'\xc2\xba\xba\xb9\x96x\xec\x07?\xc0'
   net_b_s_d_virtual_obj = NetBSDVirtual(bytes_data)
   assert net_b_s_d_virtual_obj.get_virtual_facts() == {'virtualization_tech_guest': set(), 'virtualization_tech_host': set(), 'virtualization_role': '', 'virtualization_type': ''}


# Generated at 2022-06-25 01:20:54.824868
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xc2\xba\xba\xb9\x96x\xec\x07?\xc0'
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    assert type({}) == type(var_0)


# Generated at 2022-06-25 01:21:01.183217
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xc2\xba\xba\xb9\x96x\xec\x07?\xc0'
    t_a_r_g_e_t_0 = NetBSDVirtual(bytes_0)
    var_0 = t_a_r_g_e_t_0.get_virtual_facts()

    t_a_r_g_e_t_1 = NetBSDVirtual(bytes_0)
    var_1 = t_a_r_g_e_t_1.get_virtual_facts()

    t_a_r_g_e_t_2 = NetBSDVirtual(bytes_0)
    var_2 = t_a_r_g_e_t_2.get_virtual_facts()

    # Test if all methods are called
    t_a_

# Generated at 2022-06-25 01:21:06.360800
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    bytes_0 = b'\xc2\xba\xba\xb9\x96x\xec\x07?\xc0'
    instance_of_net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector(bytes_0)


# Generated at 2022-06-25 01:21:15.014547
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    bytes_0 = b'\xc2\xba\xba\xb9\x96x\xec\x07?\xc0'
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0)
    assert net_b_s_d_virtual_0._platform == 'NetBSD'
    assert net_b_s_d_virtual_0._fact_class == NetBSDVirtual
    assert net_b_s_d_virtual_0._bytes == bytes_0
    assert net_b_s_d_virtual_0._virtual_facts['virtualization_tech_host'] == set([])


# Generated at 2022-06-25 01:21:22.854946
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # Creating a test case object
    bytes_data = b'\xc2\xba\xba\xb9\x96x\xec\x07?\xc0'
    net_b_s_d_virtual_obj = NetBSDVirtual(bytes_data)
    # Invoking the method for testing
    result_value = net_b_s_d_virtual_obj.get_virtual_facts()
    if result_value.get('virtualization_role') == '':
        print('Failed to get virtualization_role')
    elif result_value.get('virtualization_tech_host') == '':
        print('Failed to get virtualization_tech_host')
    elif result_value.get('virtualization_tech_guest') == '':
        print('Failed to get virtualization_tech_guest')

# Generated at 2022-06-25 01:21:32.099866
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xc2\xba\xba\xb9\x96x\xec\x07?\xc0'
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    assert isinstance(var_0, dict)
    assert var_0['virtualization_role'] == 'host'
    assert var_0['virtualization_type'] == 'netbsd-host'
    assert var_0['virtualization_tech_host'] == set(['netbsd'])
    assert var_0['virtualization_tech_guest'] == set()


# Generated at 2022-06-25 01:21:48.167863
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    assert True == True


# Generated at 2022-06-25 01:21:50.955161
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    bytes_0 = b'\xc2\xba\xba\xb9\x96x\xec\x07?\xc0'
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector(bytes_0)


# Generated at 2022-06-25 01:22:01.119273
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xc2\xba\xba\xb9\x96x\xec\x07?\xc0'
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0)
    # Test whether the following two methods return the same value.
    assert net_b_s_d_virtual_0.get_virtual_facts() == net_b_s_d_virtual_0._facts
    # Test whether the following two methods return the same value.
    assert net_b_s_d_virtual_0.get_virtual_facts() == net_b_s_d_virtual_0._virtual_facts
    # Test whether get_virtual_facts returns expected value.

# Generated at 2022-06-25 01:22:06.000174
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    bytes_0 = b'\xc2\xba\xba\xb9\x96x\xec\x07?\xc0'
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0)
    assert (net_b_s_d_virtual_0._platform == 'NetBSD')


# Generated at 2022-06-25 01:22:07.392276
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():

    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()

# Generated at 2022-06-25 01:22:13.929876
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xc2\xba\xba\xb9\x96x\xec\x07?\xc0'
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    assert var_0['virtualization_type'] == ''
    assert var_0['virtualization_tech_guest'] == {'kvm', 'qemu', 'qemu-kvm'}
    assert var_0['virtualization_tech_host'] == {'kvm', 'qemu', 'kvm-qemu'}
    assert var_0['virtualization_role'] == 'guest'

# Generated at 2022-06-25 01:22:17.415682
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    bytes_0 = b'\xc2\xba\xba\xb9\x96x\xec\x07?\xc0'
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0)


# Generated at 2022-06-25 01:22:25.970946
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xc2\xba\xba\xb9\x96x\xec\x07?\xc0'
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    assert var_0['virtualization_type'] == ''
    assert var_0['virtualization_role'] == ''

# Generated at 2022-06-25 01:22:29.242557
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xc2\xba\xba\xb9\x96x\xec\x07?\xc0'
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:22:33.813602
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xc2\xba\xba\xb9\x96x\xec\x07?\xc0'
    var_0 = NetBSDVirtual(bytes_0)
    var_1 = var_0.get_virtual_facts()
    var_2 = {u'virtualization_type': u'xen', u'virtualization_role': u'guest', u'virtualization_tech_host': set([]), u'virtualization_tech_guest': set([u'xen'])}
    assert var_1 == var_2


# Generated at 2022-06-25 01:23:06.647837
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    # Create an instance of the class "NetBSDVirtual"
    net_b_s_d_virtual_0 = NetBSDVirtual()
    # Store the result of the method "get_virtual_facts" in var_0 (type dict)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:23:16.242271
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual(b'\xc2\xba\xba\xb9\x96x\xec\x07?\xc0')
    net_b_s_d_virtual_1 = NetBSDVirtual(b'\xc4\x86\xca\xc6\xa0\x1e5\x15\xdb\x87')
    net_b_s_d_virtual_2 = NetBSDVirtual(b'\xc2\xba\xba\xb9\x96x\xec\x07?\xc0')
    net_b_s_d_virtual_3 = NetBSDVirtual(b'\xc4\x86\xca\xc6\xa0\x1e5\x15\xdb\x87')
    net_b_

# Generated at 2022-06-25 01:23:19.055528
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    bytes_0 = b'\xc2\xba\xba\xb9\x96x\xec\x07?\xc0'
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:23:23.854012
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # setup
    bytes_0 = b'\xc2\xba\xba\xb9\x96x\xec\x07?\xc0'
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0)
    # exercise
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:23:31.960853
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    ut_bytes_0 = b'\xc2\xba\xba\xb9\x96x\xec\x07?\xc0'
    ut_net_b_s_d_virtual_0 = NetBSDVirtual(ut_bytes_0)
    ut_var_0 = ut_net_b_s_d_virtual_0.get_virtual_facts()
    ut_var_1 = ut_var_0['virtualization_type']
    ut_var_2 = ut_var_0['virtualization_role']
    ut_var_3 = ut_var_0['virtualization_tech_guest']
    ut_var_4 = ut_var_0['virtualization_tech_host']
    assert ut_var_1 == 'xen'
    assert ut_var_2 == 'guest'
   

# Generated at 2022-06-25 01:23:35.805030
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    bytes_0 = b'\xf1\x0c\xcd\x16\x98\xfcE\x11\xce'
    bytes_1 = b'\xe6\xd3\x87\x00xC\x1c\xfeJ\x06'
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0, bytes_1)
# Creation of instance of class NetBSDVirtualCollector

# Generated at 2022-06-25 01:23:41.536167
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xc2\xba\xba\xb9\x96x\xec\x07?\xc0'
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    assert (var_0['virtualization_role'] == 'host' and var_0['virtualization_type'] == 'physical')


# Generated at 2022-06-25 01:23:44.118302
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    bytes_1 = b'\xc2\xba\xba\xb9\x96x\xec\x07?\xc0'
    net_b_s_d_virtual_1 = NetBSDVirtual(bytes_1)
    var_1 = net_b_s_d_virtual_1.get_virtual_facts()


# Generated at 2022-06-25 01:23:46.214393
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    var_1 = NetBSDVirtual(None)
    var_1.get_virtual_facts()

# Generated at 2022-06-25 01:23:54.119127
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    bytes_0 = b'\xc2\xba\xba\xb9\x96x\xec\x07?\xc0'
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    var_1 = net_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:25:02.001342
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    assert True


# Generated at 2022-06-25 01:25:09.606249
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    bytes_0 = b'\xc2\xba\xba\xb9\x96x\xec\x07?\xc0'
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:25:11.233899
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    assert net_b_s_d_virtual_0 is None

# Generated at 2022-06-25 01:25:14.057038
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    bytes_0 = b'\xc2\xba\xba\xb9\x96x\xec\x07?\xc0'
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0)
    assert isinstance(net_b_s_d_virtual_0, NetBSDVirtual)


# Generated at 2022-06-25 01:25:23.820281
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    bytes_0 = b'\xc2\xba\xba\xb9\x96x\xec\x07?\xc0'
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    assert var_0['virtualization_type'] == 'xen'
    assert var_0['virtualization_role'] == 'guest'
    assert var_0['virtualization_tech_guest'] == {'xen'}
    assert var_0['virtualization_tech_host'] == {'xen'}


# Generated at 2022-06-25 01:25:29.872649
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    bytes_0 = b'\xc2\xba\xba\xb9\x96x\xec\x07?\x00'
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector(bytes_0)

    assert net_b_s_d_virtual_collector_0._platform == 'NetBSD'
    assert net_b_s_d_virtual_collector_0._fact_class == NetBSDVirtual


# Generated at 2022-06-25 01:25:32.492569
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    bytes_0 = b'\xc2\xba\xba\xb9\x96x\xec\x07?\xc0'
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0)


# Generated at 2022-06-25 01:25:39.808678
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xc2\xba\xba\xb9\x96x\xec\x07?\xc0'
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:25:43.396806
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xc2\xba\xba\xb9\x96x\xec\x07?\xc0'
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 == {'virtualization_type': '', 'virtualization_role': '', 'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}

# Generated at 2022-06-25 01:25:48.830734
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    bytes_0 = b'\xc2\xba\xba\xb9\x96x\xec\x07?\xc0'
    net_b_s_d_virtual_0 = NetBSDVirtual(bytes_0)
