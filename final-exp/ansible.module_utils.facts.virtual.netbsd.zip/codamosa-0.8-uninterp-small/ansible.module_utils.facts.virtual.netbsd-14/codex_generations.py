

# Generated at 2022-06-25 01:18:15.695948
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    net_b_s_d_virtual_0 = NetBSDVirtual(list_0)

# Generated at 2022-06-25 01:18:17.145180
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual(list_0)

# Generated at 2022-06-25 01:18:18.912653
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    list_0 = []
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector(list_0)



# Generated at 2022-06-25 01:18:25.724474
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    list_0 = []
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector(list_0)
    net_b_s_d_virtual_0 = net_b_s_d_virtual_collector_0._fact_class(list_0)
    result = net_b_s_d_virtual_0.get_virtual_facts()
    assert isinstance(result, dict)

# Generated at 2022-06-25 01:18:28.334405
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual(None)
    net_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:18:30.410316
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    net_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:18:35.242154
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    list_0 = []
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector(list_0)
    net_b_s_d_virtual_collector_0.populate()

# Generated at 2022-06-25 01:18:40.430124
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    list_0 = []
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector(list_0)

    net_b_s_d_virtual_0 = NetBSDVirtual(net_b_s_d_virtual_collector_0)
    net_b_s_d_virtual_0.get_all_facts()
    net_b_s_d_virtual_0.get_virtual_facts()


if __name__ == '__main__':
    test_NetBSDVirtual()

# Generated at 2022-06-25 01:18:42.478825
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual(None)


# Generated at 2022-06-25 01:18:43.334098
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # No test at the moment
    pass

# Generated at 2022-06-25 01:18:48.522092
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual() # FIXME: constructor call


# Generated at 2022-06-25 01:18:57.601687
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    int_0 = 420
    list_0 = []
    net_b_s_d_virtual_0 = NetBSDVirtual(int_0, list_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()

    # AssertionError: 0 != 1 : {} != {'virtualization_tech_guest': set(), 'virtualization_role': '', 'virtualization_type': '', 'virtualization_tech_host': set()}
    assert var_0 == {'virtualization_tech_guest': set(), 'virtualization_role': '', 'virtualization_type': '', 'virtualization_tech_host': set()}


# Generated at 2022-06-25 01:19:04.481425
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    int_0 = 420
    list_0 = []
    net_b_s_d_virtual_0 = NetBSDVirtual(int_0, list_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()


if __name__ == "__main__":
    print('No unit test is implemented for module_utils.facts.virtual.netbsd')

# Generated at 2022-06-25 01:19:07.910056
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    int_0 = 420
    list_0 = []
    net_b_s_d_virtual_0 = NetBSDVirtual(int_0, list_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 == {'virtualization_type': '', 'virtual_facts': {'virtualization_type': '', 'virtualization_role': '', 'virtualization_system': 'NetBSD', 'virtualization_technology': {'guest': [], 'host': []}}}


# Generated at 2022-06-25 01:19:09.452621
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()

# Test class NetBSDVirtual

# Generated at 2022-06-25 01:19:13.395202
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    int_0 = 420
    list_0 = []
    net_b_s_d_virtual_0 = NetBSDVirtual(int_0, list_0)


# Generated at 2022-06-25 01:19:22.050795
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    int_0 = 420
    list_0 = []
    net_b_s_d_virtual_0 = NetBSDVirtual(int_0, list_0)
    str_0 = 'virtualization_tech_host'
    str_1 = 'virtualization_tech_guest'
    str_2 = 'virtualization_role'
    str_3 = 'virtualization_type'
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    assert var_0[str_0] == frozenset([]), 'assertion failed'
    assert var_0[str_1] == frozenset([]), 'assertion failed'
    assert var_0[str_2] == '', 'assertion failed'

# Generated at 2022-06-25 01:19:25.095447
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    int_1 = 420
    list_1 = []
    net_b_s_d_virtual_1 = NetBSDVirtual(int_1, list_1)
    var_1 = net_b_s_d_virtual_1.get_virtual_facts()

    assert var_1 == {}


# Generated at 2022-06-25 01:19:34.464080
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    int_0 = 420
    list_0 = []
    net_b_s_d_virtual_0 = NetBSDVirtual(int_0, list_0)
    assert net_b_s_d_virtual_0._platform == 'NetBSD'
    assert net_b_s_d_virtual_0._subplatform == ''
    assert net_b_s_d_virtual_0._version == '5.0.2'
    net_b_s_d_virtual_1 = NetBSDVirtual(int_0, list_0)
    assert net_b_s_d_virtual_1._sysname == 'NetBSD'
    assert net_b_s_d_virtual_1._machine == 'amd64'
    assert net_b_s_d_virtual_1._version == '5.0.2'

#

# Generated at 2022-06-25 01:19:40.618110
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    int_0 = 420
    list_0 = []
    net_b_s_d_virtual_0 = NetBSDVirtual(int_0, list_0)
    assert net_b_s_d_virtual_0._fact_class == NetBSDVirtual
    assert net_b_s_d_virtual_0._platform == 'NetBSD'
    assert net_b_s_d_virtual_0.platform == 'NetBSD'
    assert net_b_s_d_virtual_0.get_virtual_facts() == {'virtualization_tech_guest': set(), 'virtualization_tech_host': set(), 'virtualization_type': '', 'virtualization_role': ''}

# Generated at 2022-06-25 01:19:53.922713
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    int_0 = 420
    list_0 = []
    net_b_s_d_virtual_0 = NetBSDVirtual(int_0, list_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 == {'virtualization_role': '', 'virtualization_type': '', 'virtualization_technologies': {'host': set(), 'guest': set()}, 'virtualization_technologies_version': {'host': set(), 'guest': set()}}


# Generated at 2022-06-25 01:19:57.452716
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    int_0 = 420
    list_0 = []
    net_b_s_d_virtual_0 = NetBSDVirtual(int_0, list_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    assert isinstance(var_0, dict)


# Generated at 2022-06-25 01:20:00.776350
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    int_0 = 420
    list_0 = []
    net_b_s_d_virtual_0 = NetBSDVirtual(int_0, list_0)
    assert isinstance(net_b_s_d_virtual_0, NetBSDVirtual)


# Generated at 2022-06-25 01:20:11.493384
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    int_0 = 211
    list_0 = []
    net_b_s_d_virtual_0 = NetBSDVirtual(int_0, list_0)

# Generated at 2022-06-25 01:20:21.240323
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    int_0 = 420
    list_0 = []
    net_b_s_d_virtual_0 = NetBSDVirtual(int_0, list_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    var_1 = type(var_0)
    str_0 = 'dict'
    var_2 = var_1 == str_0
    var_3 = {
        'virtualization_role': '',
        'virtualization_type': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }
    var_4 = var_0 == var_3
    assert var_2 and var_4


# Generated at 2022-06-25 01:20:27.016702
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    int_0 = 420
    list_0 = []
    net_b_s_d_virtual_0 = NetBSDVirtual(int_0, list_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:20:31.693892
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    int_0 = 420
    list_0 = []
    net_b_s_d_virtual_0 = NetBSDVirtual(int_0, list_0)
    # noinspection PyProtectedMember
    get_virtual_facts_ret_0 = net_b_s_d_virtual_0._get_virtual_facts()
    str_0 = str(get_virtual_facts_ret_0)
    assert type(str_0) == str


# Generated at 2022-06-25 01:20:38.752544
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    int_0 = 420
    list_0 = []
    net_b_s_d_virtual_0 = NetBSDVirtual(int_0, list_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 == {'virtualization_type': '', 'virtualization_role': '', 'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}

# Generated at 2022-06-25 01:20:47.557162
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    int_0 = 420
    list_0 = []
    net_b_s_d_virtual_0 = NetBSDVirtual(int_0, list_0)
    assert net_b_s_d_virtual_0._sysctl_override == int_0
    assert net_b_s_d_virtual_0._sysctl_params == list_0
    assert net_b_s_d_virtual_0.platform == 'NetBSD'


# Generated at 2022-06-25 01:20:54.396117
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    int_0 = 420
    list_0 = []
    net_b_s_d_virtual_0 = NetBSDVirtual(int_0, list_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    if var_0 is False:
        raise Exception('get_virtual_facts failed')

# Generated at 2022-06-25 01:21:16.478186
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    int_0 = int()
    list_0 = list()
    net_b_s_d_virtual_0 = NetBSDVirtual(int_0, list_0)
    assert net_b_s_d_virtual_0._platform == 'NetBSD'
    assert net_b_s_d_virtual_0._collect_block == int()
    assert net_b_s_d_virtual_0._sysctl_platform is None
    assert net_b_s_d_virtual_0._sysctl_exists is True
    assert isinstance(net_b_s_d_virtual_0._os_version, str) is True
    assert isinstance(net_b_s_d_virtual_0._sysctl_cmd, str) is True

# Generated at 2022-06-25 01:21:18.231293
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    int_0 = 420
    list_0 = []
    net_b_s_d_virtual_0 = NetBSDVirtual(int_0, list_0)
    assert isinstance(net_b_s_d_virtual_0, NetBSDVirtual)


# Generated at 2022-06-25 01:21:22.717262
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    int_0 = 420
    list_0 = []
    net_b_s_d_virtual_0 = NetBSDVirtual(int_0, list_0)
    assert net_b_s_d_virtual_0


# Generated at 2022-06-25 01:21:31.733032
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    int_0 = 420
    list_0 = []
    net_b_s_d_virtual_0 = NetBSDVirtual(int_0, list_0)
    assert net_b_s_d_virtual_0._platform == 'NetBSD'
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    assert isinstance(var_0, dict)
    assert var_0['virtualization_type'] == ''
    assert var_0['virtualization_role'] == ''
    assert var_0['virtualization_tech_host'] == set()
    assert var_0['virtualization_tech_guest'] == set()


# Generated at 2022-06-25 01:21:39.287422
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    int_0 = 420
    list_0 = []
    net_b_s_d_virtual_0 = NetBSDVirtual(int_0, list_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    assert ('virtualization_tech_host' in var_0 )
    assert ('virtualization_tech_guest' in var_0 )
    assert ('virtualization_type' in var_0 )
    assert ('virtualization_role' in var_0 )
    assert (var_0['virtualization_type'] != '' )
    assert (var_0['virtualization_role'] != '' )
    assert (var_0['virtualization_tech_guest'] == set() )
    assert (var_0['virtualization_tech_host'] == set() )

# Unit

# Generated at 2022-06-25 01:21:42.322111
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    int_0 = 420
    list_0 = []
    net_b_s_d_virtual_0 = NetBSDVirtual(int_0, list_0)
    assert net_b_s_d_virtual_0.platform == 'NetBSD'


# Generated at 2022-06-25 01:21:48.442311
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    int_0 = 688
    list_0 = []
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector(int_0, list_0)
    assert(isinstance(net_b_s_d_virtual_collector_0, NetBSDVirtualCollector))

# Generated at 2022-06-25 01:21:53.278261
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    int_0 = 420
    list_0 = []
    net_b_s_d_virtual_0 = NetBSDVirtual(int_0, list_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    assert var_0['virtualization_type'] == 'xen'
    assert var_0['virtualization_role'] == 'guest'
    assert var_0['virtualization_tech_host'] == {'xen'}
    assert var_0['virtualization_tech_guest'] == {'xen'}

# Generated at 2022-06-25 01:21:54.632527
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()

test_case_0()

# Generated at 2022-06-25 01:22:00.866941
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    int_0 = 212
    list_0 = []
    net_b_s_d_virtual_0 = NetBSDVirtual(int_0, list_0)
    print(net_b_s_d_virtual_0.virtualization_type)
    print(net_b_s_d_virtual_0.virtualization_role)
    print(net_b_s_d_virtual_0.virtualization_tech_guest)
    print(net_b_s_d_virtual_0.virtualization_tech_host)



# Generated at 2022-06-25 01:22:33.907963
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    int_0 = 420
    list_0 = []
    net_b_s_d_virtual_0 = NetBSDVirtual(int_0, list_0)

    var_0 = net_b_s_d_virtual_0.get_virtual_facts()

    assert not var_0

# Generated at 2022-06-25 01:22:39.089658
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    int_0 = 420
    list_0 = []
    net_b_s_d_virtual_0 = NetBSDVirtual(int_0, list_0)


# Generated at 2022-06-25 01:22:41.925198
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    int_0 = 420
    list_0 = []
    net_b_s_d_virtual_0 = NetBSDVirtual(int_0, list_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:22:45.744787
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    int_0 = 420
    list_0 = []
    net_b_s_d_virtual_0 = NetBSDVirtual(int_0, list_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:22:50.713764
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    int_0 = 34
    list_0 = []
    net_b_s_d_virtual_0 = NetBSDVirtual(int_0, list_0)


# Generated at 2022-06-25 01:22:55.367454
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()

if __name__ == '__main__':
    test_case_0()
    test_NetBSDVirtualCollector()

# Generated at 2022-06-25 01:23:00.477202
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    int_0 = 712
    list_0 = []
    net_b_s_d_virtual_0 = NetBSDVirtual(int_0, list_0)
    # Testing method get_virtual_facts of class NetBSDVirtual
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:23:06.503638
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    int_0 = 420
    list_0 = []
    net_b_s_d_virtual_0 = NetBSDVirtual(int_0, list_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:23:07.921730
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()

# Generated at 2022-06-25 01:23:12.571224
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    int_0 = 619
    list_0 = []
    net_b_s_d_virtual_0 = NetBSDVirtual(int_0, list_0)
    assert net_b_s_d_virtual_0._kernel_release == int_0
    assert net_b_s_d_virtual_0._sysctl_facts == list_0


# Generated at 2022-06-25 01:24:24.565258
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    netbsdvirtual = NetBSDVirtual()
    assert type(netbsdvirtual) == NetBSDVirtual

# Generated at 2022-06-25 01:24:29.349390
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    int_0 = 420
    list_0 = []
    net_b_s_d_virtual_0 = NetBSDVirtual(int_0, list_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    assert var_0


# Generated at 2022-06-25 01:24:32.697298
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    int_0 = 420
    list_0 = []
    net_b_s_d_virtual_0 = NetBSDVirtual(int_0, list_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    assert var_0['virtualization_type'] == ''


# Generated at 2022-06-25 01:24:36.571217
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    int_0 = 420
    list_0 = []
    net_b_s_d_virtual_0 = NetBSDVirtual(int_0, list_0)
    assert (net_b_s_d_virtual_0._connection.connection == int_0)
    assert (net_b_s_d_virtual_0._facts_cache == list_0)


# Generated at 2022-06-25 01:24:37.662115
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    try:
        NetBSDVirtualCollector()
    except NameError:
        assert True
    else:
        assert False


# Generated at 2022-06-25 01:24:41.471984
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    int_0 = 899
    list_0 = [ 767, 514, 6, 755 ]
    net_b_s_d_virtual_0 = NetBSDVirtual(int_0, list_0)
    assert net_b_s_d_virtual_0._fact_class == 'NetBSDVirtual'
    assert net_b_s_d_virtual_0._platform == 'NetBSD'


# Generated at 2022-06-25 01:24:45.851887
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    int_0 = 420
    list_0 = []
    net_b_s_d_virtual_0 = NetBSDVirtual(int_0, list_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    assert type(var_0) == dict



# Generated at 2022-06-25 01:24:50.196153
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    int_0 = 420
    list_0 = []
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector(int_0, list_0)


# Generated at 2022-06-25 01:24:56.188482
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    # NOTE: The following test will fail if run in a VM
    net_b_s_d_virtual_0 = NetBSDVirtual(0, [])
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    # The following assertion could be different for each run
    assert var_0 == {'virtualization_type': '', 'virtualization_role': '',
                     'virtualization_tech_host': set(), 'virtualization_tech_guest': set()}

# Generated at 2022-06-25 01:24:57.636165
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
  test_case_0()


# Generated at 2022-06-25 01:27:42.023516
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    int_0 = 420
    list_0 = []
    net_b_s_d_virtual_0 = NetBSDVirtual(int_0, list_0)
    assert net_b_s_d_virtual_0._sysctl == list_0
    assert net_b_s_d_virtual_0._sysctl_defaults == int_0
    assert net_b_s_d_virtual_0._platform == 'NetBSD'


# Generated at 2022-06-25 01:27:47.142217
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    int_0 = 420
    list_0 = []
    net_b_s_d_virtual_0 = NetBSDVirtual(int_0, list_0)
    net_b_s_d_virtual_0.get_virtual_facts()



# Generated at 2022-06-25 01:27:48.849881
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    # matching
    assert NetBSDVirtual is not None
    # non-matching
    assert NetBSDVirtual is not None


# Generated at 2022-06-25 01:27:51.104972
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    int_0 = 420
    list_0 = []
    net_b_s_d_virtual_0 = NetBSDVirtual(int_0, list_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:27:56.713281
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    int_0 = 420
    list_0 = []
    net_b_s_d_virtual_0 = NetBSDVirtual(int_0, list_0)

# Generated at 2022-06-25 01:27:59.029976
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    int_0 = 420
    list_0 = []
    net_b_s_d_virtual_0 = NetBSDVirtual(int_0, list_0)
    assert net_b_s_d_virtual_0.platform == 'NetBSD'


# Generated at 2022-06-25 01:28:03.560210
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    int_0 = 473
    list_0 = []
    net_b_s_d_virtual_0 = NetBSDVirtual(int_0, list_0)
    net_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:28:09.516556
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    int_0 = 420
    list_0 = []
    net_b_s_d_virtual_0 = NetBSDVirtual(int_0, list_0)
    assert net_b_s_d_virtual_0._platform == "NetBSD"
    assert net_b_s_d_virtual_0.facts == {}
