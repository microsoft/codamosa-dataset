

# Generated at 2022-06-25 01:18:14.197369
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    net_b_s_d_virtual_0.get_virtual_facts()

if __name__ == '__main__':
    test_case_0()
    test_NetBSDVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:18:16.753671
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    net_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:18:17.544973
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()


# Generated at 2022-06-25 01:18:22.530414
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    test_case_0()

# Generated at 2022-06-25 01:18:29.825706
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():

    net_b_s_d_virtual_0 = NetBSDVirtual()
    net_b_s_d_virtual_1 = NetBSDVirtual()
    # Testing if the class could be instantiated
    assert net_b_s_d_virtual_0 is not None
    # Testing if the class could be instantiated
    assert net_b_s_d_virtual_1 is not None
    # Testing if instances are different
    assert net_b_s_d_virtual_0 != net_b_s_d_virtual_1

# Generated at 2022-06-25 01:18:34.870602
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    virtual_facts = net_b_s_d_virtual_0.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'physical'

# Generated at 2022-06-25 01:18:37.119668
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    assert net_b_s_d_virtual_0.platform == 'NetBSD'


# Generated at 2022-06-25 01:18:41.412647
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    assert net_b_s_d_virtual_0.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': set(),
        'virtualization_product': '',
        'virtualization_vendor': '',
    }


# Generated at 2022-06-25 01:18:42.346697
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    test_case_0()


# Generated at 2022-06-25 01:18:53.382772
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual = NetBSDVirtual()

    with open('/proc/cpuinfo', 'r') as proc_cpu_info:
        proc_cpu_info_contents = proc_cpu_info.read()

    with open('/proc/meminfo', 'r') as proc_mem_info:
        proc_mem_info_contents = proc_mem_info.read()

    with open('/proc/self/mountstats', 'r') as proc_self_mount_stats:
        proc_self_mount_stats_contents = proc_self_mount_stats.read()

    with open('/proc/cmdline', 'r') as proc_cmd_line:
        proc_cmd_line_contents = proc_cmd_line.read()

    net_b_s_d_virtual._module = Ansible

# Generated at 2022-06-25 01:19:02.512966
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()


# Generated at 2022-06-25 01:19:03.489553
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()


# Generated at 2022-06-25 01:19:09.959494
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    result = net_b_s_d_virtual_0.get_virtual_facts()

if __name__ == '__main__':
    test_case_0()
    test_NetBSDVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:19:20.352989
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    ansible_facts = dict()
    ansible_facts['ansible_processor_architecture'] = 'amd64'
    ansible_facts['ansible_system'] = 'NetBSD'
    ansible_facts['kernel'] = 'NetBSD'
    ansible_facts['ansible_machine'] = 'amd64'
    ansible_facts['ansible_kernel'] = 'NetBSD'
    ansible_facts['kernel_version'] = '8.0'
    ansible_facts['ansible_os_family'] = 'BSD'
    ansible_facts['ansible_processor_count'] = 1
    ansible_facts['ansible_memtotal_mb'] = 1024
    ansible_facts['ansible_all_ipv4_addresses']

# Generated at 2022-06-25 01:19:30.143419
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    ansible_facts = {'sysctl': {'machdep.dmi.system-product': 'VMware Virtual Platform', 'machdep.dmi.system-vendor': 'VMware, Inc.'}}
    net_b_s_d_virtual_0.sysctl = ansible_facts['sysctl']
    expected = [{'virtualization_type': 'vmware', 'virtualization_role': 'guest', 'virtualization_tech_guest': 'vmware', 'virtualization_tech_host': 'vmware'}]
    actual = net_b_s_d_virtual_0.get_virtual_facts()
    assert (actual == expected)

# Generated at 2022-06-25 01:19:32.625625
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()


# Generated at 2022-06-25 01:19:38.385775
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    assert net_b_s_d_virtual_0.platform == 'NetBSD'
    net_b_s_d_virtual_0.get_virtual_facts()
    assert net_b_s_d_virtual_0.facts['virtualization_role'] in ['guest', 'host']
    assert net_b_s_d_virtual_0.facts['virtualization_type'] in ['xen']

# Generated at 2022-06-25 01:19:47.634891
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_collector_1 = NetBSDVirtualCollector()

    print("%s" % net_b_s_d_virtual_collector_1)
#    assert(net_b_s_d_virtual_collector_1['virtualization_type'] == 'None' or '??')
#    assert(net_b_s_d_virtual_collector_1['virtualization_role'] == 'None' or '??')
#    assert(net_b_s_d_virtual_collector_1['virtualization_sysctl_args'] == list())

# Generated at 2022-06-25 01:19:48.982932
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()


# Generated at 2022-06-25 01:19:51.324488
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()


# Generated at 2022-06-25 01:20:04.178246
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual = NetBSDVirtual()
    res = net_b_s_d_virtual.get_virtual_facts()
    if 'virtualization_type' not in res or not res['virtualization_type']:
        assert False, "Failed to get virtualization_type"
    if 'virtualization_role' not in res or not res['virtualization_role']:
        assert False, "Failed to get virtualization_role"
    if res['virtualization_role'] == 'guest' and not res['virtualization_type']:
        assert False, "virtualization_role is guest but there is no virtualization_type"
    return

# Generated at 2022-06-25 01:20:07.562004
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    rep = net_b_s_d_virtual_0.get_virtual_facts()
    assert rep == dict()


# Generated at 2022-06-25 01:20:08.644690
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()

# Generated at 2022-06-25 01:20:10.251238
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 01:20:20.288043
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    facts = dict(
        ansible_facts=dict(
            ansible_product_name='',
            ansible_system='NetBSD',
            ansible_machine='x86_64',
            ansible_distribution='NetBSD',
            ansible_distribution_version='8.99.3',
            ansible_product_version='8.99.3',
        )
    )
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector(facts)

# Generated at 2022-06-25 01:20:22.498137
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    net_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:20:31.188496
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    fact_class_obj = NetBSDVirtual()
    data = """
machdep.dmi.system-product = 'Xen HVM domU'
machdep.hypervisor = 'Xen'
machdep.dmi.system-vendor = 'Xen'
"""
    fact_class_obj.read_file_lines = lambda x: data.splitlines()
    result = fact_class_obj.get_virtual_facts()
    assert result['virtualization_role'] == 'guest'
    assert result['virtualization_type'] == 'xen'
    assert 'xen' in result['virtualization_tech_guest']


# Generated at 2022-06-25 01:20:36.456853
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_1 = NetBSDVirtualCollector()
    assert net_b_s_d_virtual_collector_1.machdep.platform == 'NetBSD'


# Generated at 2022-06-25 01:20:38.457992
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    assert 'virtualization_type' in net_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:20:46.016408
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    assert net_b_s_d_virtual_0.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set([]),
        'virtualization_tech_host': set([]),
    }

# Generated at 2022-06-25 01:21:01.739024
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()


# Generated at 2022-06-25 01:21:07.271353
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    assert net_b_s_d_virtual_0.get_virtual_facts() == {'virtualization_role': 'guest', 'virtualization_type': 'xen', 'virtualization_tech_host': set(), 'virtualization_tech_guest': {'xen'}}

# Generated at 2022-06-25 01:21:11.555794
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    class_0 = NetBSDVirtual(None)


# Generated at 2022-06-25 01:21:13.668346
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    virtual_facts = net_b_s_d_virtual_0.get_virtual_facts()
    assert virtual_facts == dict()


# Generated at 2022-06-25 01:21:18.070106
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()


# Generated at 2022-06-25 01:21:19.111445
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()


# Generated at 2022-06-25 01:21:27.355021
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()

    # Test for no matching sysctl
    virtual_facts = net_b_s_d_virtual_collector_0.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-25 01:21:28.571402
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()


# Generated at 2022-06-25 01:21:32.416695
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    test_var_0 = NetBSDVirtualCollector()


# Generated at 2022-06-25 01:21:33.495340
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()

# Generated at 2022-06-25 01:22:10.426690
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0_obj = NetBSDVirtual()
    net_b_s_d_virtual_0_obj.all_facts = {}
    net_b_s_d_virtual_0_obj.all_facts['ansible_system_vendor'] = 'Google'
    net_b_s_d_virtual_0_obj.all_facts['ansible_machine_id'] = '42'
    net_b_s_d_virtual_0_obj.all_facts['ansible_kernel'] = '2.6.32-504.3.3.el6.x86_64'
    net_b_s_d_virtual_0_obj.all_facts['ansible_product_name'] = 'Google Compute Engine'
    net_b_s_d_virtual_0_obj

# Generated at 2022-06-25 01:22:13.965448
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    assert callable(TestAnsibleModule.get_virtual_facts)

# Generated at 2022-06-25 01:22:17.722788
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector = NetBSDVirtualCollector()
    assert net_b_s_d_virtual_collector._platform == 'NetBSD'
    assert net_b_s_d_virtual_collector._fact_class == NetBSDVirtual


# Generated at 2022-06-25 01:22:29.102170
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual({})
    net_b_s_d_virtual_1 = NetBSDVirtual(
        {
            'machdep.hypervisor': '4.4.0-151-generic',
            'machdep.dmi.system-vendor': 'Bochs',
            'machdep.dmi.system-product': 'VirtualBox'
        }
    )
    net_b_s_d_virtual_2 = NetBSDVirtual(
        {
            'machdep.hypervisor': 'VMWare Virtual Platform',
            'machdep.dmi.system-vendor': 'Bochs'
        }
    )

# Generated at 2022-06-25 01:22:31.058442
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()

    # Setup of test data

    # Run tested method
    net_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:22:32.069057
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()



# Generated at 2022-06-25 01:22:34.296694
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    assert net_b_s_d_virtual_0.platform == 'NetBSD'


# Generated at 2022-06-25 01:22:39.122256
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    assert {} == net_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:22:41.439463
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    assert net_b_s_d_virtual_0.get_virtual_facts()['virtualization_type'] == ''


# Generated at 2022-06-25 01:22:43.642386
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_0 = NetBSDVirtual()


# Generated at 2022-06-25 01:23:51.263324
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    virtual_facts_0 = NetBSDVirtual()
    assert virtual_facts_0.platform == 'NetBSD'


# Generated at 2022-06-25 01:23:54.452877
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    netbsd_virtual_0 = NetBSDVirtual({})
    netbsd_virtual_0.get_virtual_facts()

if __name__ == "__main__":
    test_case_0()
    test_NetBSDVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:23:59.157821
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    net_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:24:01.858391
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual = NetBSDVirtual()

# Generated at 2022-06-25 01:24:03.689140
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    assert NetBSDVirtual.__module__ == 'ansible.module_utils.facts.virtual.net_b_s_d'
    assert NetBSDVirtual.platform == 'NetBSD'


# Generated at 2022-06-25 01:24:11.229789
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector = NetBSDVirtualCollector()

    # Test sysctl_filter
    assert net_b_s_d_virtual_collector.sysctl_filter(None) == None

    # Test machdep_dmi_system_vendor
    assert net_b_s_d_virtual_collector.machdep_dmi_system_vendor(None) == None

    # Test machdep_dmi_system_product
    assert net_b_s_d_virtual_collector.machdep_dmi_system_product(None) == None



# Generated at 2022-06-25 01:24:12.874961
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_0 = NetBSDVirtual()
    net_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:24:17.209585
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()



# Generated at 2022-06-25 01:24:21.281242
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()
    net_b_s_d_virtual_0 = NetBSDVirtual(net_b_s_d_virtual_collector_0)
    virtual_facts_0 = net_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:24:28.827801
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()
    net_b_s_d_virtual_0 = NetBSDVirtual(net_b_s_d_virtual_collector_0)
    net_b_s_d_virtual_0 = NetBSDVirtual(net_b_s_d_virtual_collector_0)

# Generated at 2022-06-25 01:25:42.941268
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    pass

# Generated at 2022-06-25 01:25:49.389879
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_collector_1 = NetBSDVirtualCollector()
    net_b_s_d_virtual_1 = NetBSDVirtual(net_b_s_d_virtual_collector_1)
    var_1 = net_b_s_d_virtual_1.get_virtual_facts()

# Generated at 2022-06-25 01:25:51.195499
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()
    assert net_b_s_d_virtual_collector_0._fact_class == NetBSDVirtual
    assert net_b_s_d_virtual_collector_0._platform == 'NetBSD'

# Generated at 2022-06-25 01:25:57.201925
# Unit test for constructor of class NetBSDVirtual
def test_NetBSDVirtual():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()
    net_b_s_d_virtual_0 = NetBSDVirtual(net_b_s_d_virtual_collector_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:26:00.554272
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()
    net_b_s_d_virtual_0 = NetBSDVirtual(net_b_s_d_virtual_collector_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 is not None
    assert var_0 == {'virtualization_type': '', 'virtualization_role': '', 'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}

# Generated at 2022-06-25 01:26:06.385219
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()
    net_b_s_d_virtual_0 = NetBSDVirtual(net_b_s_d_virtual_collector_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    # The method get_virtual_facts to return virtual_facts dictionary
    assert var_0 == {'virtualization_type': False, 'virtualization_role': False}

# Generated at 2022-06-25 01:26:07.784126
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()


# Generated at 2022-06-25 01:26:13.204310
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    check_ansible_module(
        test_case_0
    )
# ===========================================


# ===========================================
# Module execution.
if __name__ == '__main__':
    from ansible.module_utils.facts.virtual import main
    main()

# Generated at 2022-06-25 01:26:14.128569
# Unit test for constructor of class NetBSDVirtualCollector
def test_NetBSDVirtualCollector():
    net_b_s_d_virtual_collector_1 = NetBSDVirtualCollector()


# Generated at 2022-06-25 01:26:17.773099
# Unit test for method get_virtual_facts of class NetBSDVirtual
def test_NetBSDVirtual_get_virtual_facts():
    net_b_s_d_virtual_collector_0 = NetBSDVirtualCollector()
    net_b_s_d_virtual_0 = NetBSDVirtual(net_b_s_d_virtual_collector_0)
    var_0 = net_b_s_d_virtual_0.get_virtual_facts()
    assert 'virtualization_role' in var_0.keys()
    assert 'virtualization_type' in var_0.keys()
    assert 'virtualization_tech_host' in var_0.keys()
    assert 'virtualization_tech_guest' in var_0.keys()
