

# Generated at 2022-06-21 10:22:51.106994
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    p = ParserGenerator()
    p.dump_dfa("x", [])
    p.dump_dfa("x", [DFAState({}, 0)])
    p.dump_dfa("x", [DFAState({}, 1)])
    p.dump_dfa("x", [DFAState({}, 1), DFAState({}, 0)])
    p.dump_dfa("x", [DFAState({}, 1), DFAState({}, 1)])
    p.dump_dfa("x", [DFAState({}, 0), DFAState({}, 0)])
    p.dump_dfa("x", [DFAState({}, 0), DFAState({}, 1)])
    p.dump_dfa("x", [DFAState({}, 1), DFAState({}, 0)])
    #

# Generated at 2022-06-21 10:22:54.536543
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    def test(input):
        tokens = Lexer.tokenize(input)
        pg = ParserGenerator(tokens, '<test>', 1)
        start, finish = pg.parse_atom()
        pg.dump_nfa('test', start, finish)
    test('x')
    test('foo')
    test('"bar"')
    test('"bar"+')
    test('("bar")*')
    test('("bar"+)*')
    test('("foo"* | "bar"*)+')
    test("('foo'* | 'bar'*)*")

# Generated at 2022-06-21 10:22:59.116670
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    parser = ParserGenerator()
    assert parser.parse_rhs() == (
        NFAState([(None, NFAState([(None, NFAState([(None, NFAState())])), (None, NFAState())]))]),
        NFAState(),
    )



# Generated at 2022-06-21 10:23:08.817306
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    import io
    import grammar
    import pickle
    import tokenize
    import token
    import parser
    import pgen2
    parser = pgen2.ParserGenerator()
    f = io.BytesIO(b'"""\n"""')
    parser.generator = tokenize.generate_tokens(f.readline)
    try:
        parser.gettoken()
        parser.type
        parser.value
        parser.begin
        parser.end
        parser.line
        parser.parse_alt()
    except SyntaxError:
        pass
    f = io.StringIO("""abcd""")
    parser.generator = tokenize.generate_tokens(f.readline)
    try:
        parser.parse_alt()
    except SyntaxError:
        pass

# Generated at 2022-06-21 10:23:10.253588
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    pg = PgenGrammar()
    assert pg



# Generated at 2022-06-21 10:23:14.856006
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    print("method make_grammar of class ParserGenerator")
    print("  This can't be unit tested.  Run pgen.py instead.")

# Generated at 2022-06-21 10:23:26.141186
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    import tokenize as tokenize_module

    class MockParserGenerator:
        def __init__(self, tokens) -> None:
            self.tokens = tokens

        def raise_error(self, msg: str, *args: Any) -> None:
            raise SyntaxError(msg % args)

        def gettoken(self) -> None:
            self.type, self.value, _, _, _ = self.tokens.pop(0)

    for t, v in tokenize_module.tokenize(" "):
        if t in (tokenize_module.NEWLINE, tokenize_module.COMMENT):
            continue
        if t == tokenize_module.ENDMARKER:
            break
        pg = MockParserGenerator([(t, v, None, None, None)])
        pg.gettoken()
       

# Generated at 2022-06-21 10:23:34.977893
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    pg = ParserGenerator()
    pg.make_nfa()
    pg.addfirstsets()
    assert ('file_input', {'("async"|"await")', '("def"|"class")', '("@")', '("import"|"from")', '("\\n")', '("("|"["|"{")', '(";"|"\\n")', '("async"|"await")'}) == (
        'file_input',
        pg.first['file_input'],
    )
    assert ('decorator', {'("\\n")', '("@")'}) == ('decorator', pg.first['decorator'])

# Generated at 2022-06-21 10:23:40.136942
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    source = """
    A: 'a'
    """
    p = ParserGenerator()
    dfa = p.make_dfa(*p.parse_rhs_from_file(StringIO(source)))
    p.dump_dfa("A", dfa)



# Generated at 2022-06-21 10:23:41.670841
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    pg = ParserGenerator()
    return pg


# Generated at 2022-06-21 10:24:29.641519
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    g = ParserGenerator(
        """
expr: term ('+' term)*
term: factor ('*' factor)*
factor: ('+'|'-')* atom
atom: NAME | NUMBER | '(' expr ')'
"""
    )


# Generated at 2022-06-21 10:24:39.224742
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    pg = ParserGenerator()
    pg.first = {}
    pg.dfas = {}
    pg.startsymbol = "file_input"
    pg.filename = "example"

# Generated at 2022-06-21 10:24:45.444106
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
	from .. import tokenize
	from .. import Token

	from typing import Text, List, Tuple, Any, Optional, TypeVar, Generic, Iterator

	pgen = Grammar(
		"""
		a: 'a'
		"""
	) #type: Grammar

	pgen.raise_error("msg")


# Generated at 2022-06-21 10:24:54.372206
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    g = ParserGenerator("<string>")
    g.type = token.NAME
    g.value = "foo"
    assert g.expect(token.NAME) == "foo"
    g.gettoken = lambda: None
    g.type = token.NAME
    g.value = "bar"
    assert g.expect(token.NAME, "bar") == "bar"
    del g.gettoken
    try:
        g.expect(token.NAME, "bar")
        assert False, "expect should raise SyntaxError for bad input"
    except SyntaxError:
        pass


# Generated at 2022-06-21 10:25:04.867038
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    nfa_start = NFAState()
    nfa_final = NFAState()
    nfa_start.addarc(NFAState(), 'a')
    nfa_start.addarc(nfa_final, None)
    nfa_final.addarc(NFAState(), 'b')

    pg = ParserGenerator()
    dfa_start, dfa_final = pg.make_dfa(nfa_start, nfa_final)

    assert dfa_start.nfaset == {nfa_start}, 'dfa_start.nfaset'
    final_dfa = pg.dfas['final'] = [dfa_final]
    assert dfa_final.nfaset == {nfa_final}, 'dfa_final.nfaset'
    pg.simplify_

# Generated at 2022-06-21 10:25:12.319749
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    from pgen2.parse import build_grammar

    def eq(*args, **kw):
        for x, y in zip(args[:-1], args[1:]):
            if x != y:
                print(x)
                print(y)
        assert args[:-1] == args[1:], kw.get("msg")

    def check(grammar_text: Text) -> None:
        glist, symbols, lr_method = build_grammar(grammar_text, debug=0)
        # print(glist)
        pg = ParserGenerator(grammar_text)
        ns = pg.convert()
        # print(ns.dfas)
        eq(ns.dfas, glist[2].dfas)
    check("""
      single: NAME
    """)

# Generated at 2022-06-21 10:25:25.299080
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    import sys
    import io
    from tokenize import tokenize as tokenize_function, untokenize as untokenize_function, generate_tokens, tok_name
    from tokenize import NUMBER, NAME, STRING, ENDMARKER, NEWLINE, INDENT
    import token

    debug_flag = 0

    # Tuple of (token_type, token_string) pairs, for later comparison.

# Generated at 2022-06-21 10:25:29.789154
# Unit test for method addarc of class DFAState
def test_DFAState_addarc():
    a = DFAState({}, None)
    b = DFAState({}, None)
    a.addarc(b, '"a"')
    assert a.arcs['"a"'] is b

# Generated at 2022-06-21 10:25:38.942013
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    pg = ParserGenerator()
    pg.addfirstsets()

    def compare(n: str, f: Set[Text]) -> None:
        assert pg.first.get(n) is not None, n
        assert f.issubset(pg.first[n].keys()), (n, f, pg.first[n].keys())

    compare("STMT", {"import", "from"})
    compare("FILE_INPUT", {"class", "def", "import", "from"})
    compare("atom", {"NAME", "'('", "'['", "'{'"})
    compare("simple_stmt", {"BREAK", "CONTINUE", "DEL", "RETURN", "PASS", "RAISE", "YIELD"})

# Generated at 2022-06-21 10:25:42.932937
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    pg = ParserGenerator([(None, '    1: a : b\n    2: b : "b"\n')])
    assert pg.dfas["a"] == pg.dfas["b"]


# Generated at 2022-06-21 10:26:39.257567
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    pg = ParserGenerator()

# Generated at 2022-06-21 10:26:52.206778
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    from . import parsetok_lextab as lextab
    from . import parsetok_parsetab as parsetab
    from . import parsetok_pgen
    convert = ParserGenerator(lextab).convert
    pgen = convert(parsetab)
    pyc = pgen.dump_pyc()
    parser = parsetok_pgen.ParserGenerator(pyc)
    assert parser.first["expr"] == {
        "NAME": 1,
        "LPAR": 1,
        "MINUS": 1,
        "PLUS": 1,
        "TILDE": 1,
        "NUMBER": 1,
    }

# Generated at 2022-06-21 10:26:56.996886
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():
    ds = DFAState(
        {NFAState(): 1, NFAState(): 1},
        NFAState(),
    )
    ds.arcs = {"a": ds, "b": ds}
    ds.unifystate(ds, None)
    assert ds.arcs == {"a": None, "b": None}



# Generated at 2022-06-21 10:27:08.838480
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    class AST:
        def __init__(self, type: int, value: Any) -> None:
            self.type = type
            self.value = value
            self.lineno = 0
            self.col_offset = 0
        def __repr__(self) -> str:
            return "AST(%r, %r)" % (self.type, self.value)

    def make_ast(type: int, value: Any) -> AST:
        return AST(type, value)

    def make_rule(name: Text, items: List[Tuple[int, Any]]) -> Tuple[AST, AST]:
        return make_ast(type_of_NAME, name), items

    def make_alt(items: List[Tuple[int, Any]]) -> List[Tuple[int, Any]]:
        return items



# Generated at 2022-06-21 10:27:10.310137
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    parser = ParserGenerator()
    parser.gettoken()


# Generated at 2022-06-21 10:27:13.099106
# Unit test for constructor of class NFAState
def test_NFAState():
    a = NFAState()
    assert a.arcs == []
    a.addarc(NFAState())
    assert a.arcs == [(None, NFAState())]
    a.addarc(NFAState(), 'x')
    assert a.arcs == [(None, NFAState()), ('x', NFAState())]



# Generated at 2022-06-21 10:27:22.107005
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    pg = ParserGenerator()
    start = NFAState()
    finish = NFAState()
    start.addarc(finish, "a")
    start.addarc(finish, "b")
    start.addarc(finish, "a")
    dfa = pg.make_dfa(start, finish)
    assert len(dfa) == 2
    pg.dump_dfa("(start)", dfa)

# Generated at 2022-06-21 10:27:28.326002
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    for mod in (token,):
        mod.NL = -1  # Dummy value
    input = """
    # test of dump_nfa
    a = 1
    b = 2
    """
    pg = ParserGenerator()
    pg.parse_grammar(input)
    pg.build_grammar()
    #pg.dump_nfa("a", pg.dfas["a"][0], pg.dfas["a"][-1])


# Generated at 2022-06-21 10:27:39.820826
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    import os
    import sys
    import io
    import unittest
    from unary import MethodTester

    class Test(unittest.TestCase):
        def test_parse(self) -> None:
            code = """
from gramma import ParserGenerator, ast_grammar

with ParserGenerator(ast_grammar.get_grammar()) as pg:
    class Parser(pg.Parser):
        def f(self, x):
            return repr(x)
    parser = Parser()
"""
            with io.StringIO() as err:
                old = sys.stderr
                sys.stderr = err

# Generated at 2022-06-21 10:27:48.072488
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    pg = ParserGenerator()
    pg.begin = (0,0)
    pg.end = (10,10)
    pg.line = "xxx"
    pg.filename = "/tmp/foo.py"
    pg._tokens = iter([(token.OP, ";"), (token.NAME, "yadda"), (token.OP, ":")])
    pg.gettoken()
    pg.expect(token.OP, ";")
    pg.expect(token.NAME, "yadda")
    pg.expect(token.OP, ":")

# Generated at 2022-06-21 10:28:42.143891
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    # http://bugs.python.org/issue12750
    pgen = ParserGenerator([], [])
    d = DFAState({}, isfinal=True)
    pgen.dfas = {
        "s": [DFAState({}, isfinal=True), DFAState({}, isfinal=False)],
        "t": [d, d],
        "u": [DFAState({}, isfinal=True), DFAState({}, isfinal=False)],
        "v": [d, d],
    }
    pgen.addfirstsets()

# ***** Tests for pgen module *****


# Generated at 2022-06-21 10:28:53.916040
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    pg = ParserGenerator()
    pg.dfas = {
        "a": [DFAState({"a": 1, "b": 2}, False),
              DFAState({"a": 1, "b": 2}, True)],
        "b": [DFAState({"a": 1, "b": 2}, True),
              DFAState({"a": 1, "b": 2}, True)]
    }
    pg.first = {"a": {"a": 1, "b": 1}, "b": {"a": 1, "b": 1}}
    c = PgenGrammar()
    pg.make_first(c, "a")
    assert c.labels == [(token.NAME, "a"), (token.NAME, "b")]
    c = PgenGrammar()

# Generated at 2022-06-21 10:28:56.416671
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    f = open("Parser/Parser/python.grammar")
    try:
        pgen = ParserGenerator(f)
    finally:
        f.close()
    with pytest.raises(SyntaxError):
        pgen.raise_error("dummy error")

# Generated at 2022-06-21 10:29:04.953602
# Unit test for method __eq__ of class DFAState
def test_DFAState___eq__():

    class Dummy(object):
        def __init__(self, value: Any) -> None:
            self.value = value

        def __repr__(self) -> str:
            return "Dummy(%s)" % self.value

    d = {}
    d[DFAState({"foo": "bar"}, "baz")] = 1
    d[DFAState({"foo": "bar"}, "baz")] = 2
    d[DFAState({"foo": Dummy(2)}, Dummy(4))] = 3
    d[DFAState({"foo": Dummy(2)}, Dummy(4))] = 4
    assert len(d) == 2
    x = DFAState({"foo": "bar"}, "baz")
    assert x == x
    assert x in d
    x = DFA

# Generated at 2022-06-21 10:29:16.450447
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    lines = iter(
        [
            " # comment 1",
            "expr: xor_expr ('|' xor_expr)*",
            "     | NAME",
            "xor_expr: and_expr ('^' and_expr)*",
            'and_expr: "(" expr ")"',
            "        | atom",
            "atom: NAME [+*]",
            "    | STRING",
            "",
            "# comment 2",
            "",
            "dotted_name: NAME ('.' NAME)*",
            "",
        ]
    )
    pg = ParserGenerator()
    dfas, startsymbol = pg.parse_grammar(lines, "<testdata>")
    assert startsymbol == "expr"
    pg.dump_dfa("expr", dfas["expr"])
    pg.dump

# Generated at 2022-06-21 10:29:19.180625
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():

    lines = ["(a + b)"]
    pg = ParserGenerator()
    g = pg.parse_grammar(lines)

    # Does not raise
    pg.dump_nfa('test dump_nfa', g.start, g.finish)


# Generated at 2022-06-21 10:29:30.044129
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    from .parsetok import generate_tokens
    from io import StringIO
    # first use case
    s = "<one> <two> <three>"
    p = ParserGenerator(generate_tokens(StringIO(s).readline))
    tokens = list(p.generator)
    p.gettoken()
    assert p.type == token.NAME and p.value == "<one>"
    p.gettoken()
    assert p.type == token.NAME and p.value == "<two>"
    p.gettoken()
    assert p.type == token.NAME and p.value == "<three>"
    p.gettoken()
    assert p.type == token.ENDMARKER
    # second use case
    s = "Foo: 'foo'\n"

# Generated at 2022-06-21 10:29:40.562464
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    import io
    from _tokenize import generate_tokens
    for name, text in [('"a"', 'a'), ('"ab"', 'ab'), ('NAME', 'a'), ('NAME', 'ab')]:
        tokens = list(generate_tokens(io.StringIO(name).readline))
        parser = ParserGenerator(tokens, "<testcase>")
        a, b = parser.parse_atom()
        assert a is not None
        assert b is not None
        assert a.arcs == [(text, b)]
test_ParserGenerator_parse_atom()


# Generated at 2022-06-21 10:29:46.277560
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    pg = ParserGenerator()
    c = pg.converter("hello")
    c.symbol2number = dict(hello=0, hi=1)
    c.labels = [(token.NUMBER, None), (token.LPAR, None)]
    assert pg.make_first(c, "hi") == {0: 1}
    assert pg.make_first(c, "hello") == {1: 1, 0: 1}



# Generated at 2022-06-21 10:29:48.113947
# Unit test for function generate_grammar
def test_generate_grammar():
    p = ParserGenerator()
    g = p.make_grammar()
    g.check_all()
    g.write_grammar("Grammar.txt")

#
#
#
#
#