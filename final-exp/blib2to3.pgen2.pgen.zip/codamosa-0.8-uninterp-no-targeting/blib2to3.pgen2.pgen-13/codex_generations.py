

# Generated at 2022-06-21 10:23:09.105911
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    pg = ParserGenerator()
    pg.make_dfas(test_grammar)
    pg.addfirstsets()
    assert pg.first["atom"] == {"(": 1, "NAME": 1, "NUMBER": 1}
    assert pg.first["listmaker"] == {"(": 1, "NAME": 1, "NUMBER": 1}
    assert pg.first["power"] == {"(": 1, "NAME": 1, "NUMBER": 1}
    assert pg.first["term"] == {"NAME": 1, "NUMBER": 1}
    assert pg.first["testlist"] == {"NAME": 1}
    assert pg.first["testlist_comp"] == {"(": 1, "NAME": 1}

# Generated at 2022-06-21 10:23:23.037961
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    class Test:

        def __init__(self, *args) -> None:
            self.args = args

        def __eq__(self, other: Any) -> bool:
            return isinstance(other, Test) and self.args == other.args

        def __hash__(self) -> int:
            return hash(self.args)

    start = Test(0)
    finish = Test(1)
    start.addarc(Test(2), None)
    start.addarc(Test(3), "a")
    start.addarc(Test(4), None)
    start.addarc(Test(5), "b")
    Test(2).addarc(finish, None)
    Test(3).addarc(Test(6), None)
    Test(3).addarc(Test(7), None)

# Generated at 2022-06-21 10:23:30.297975
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    pg = ParserGenerator()
    pg.make_dfas("", "S:S")
    pg.dfas["S"][0].arcs.clear()
    pg.dfas["S"][0].addarc(pg.dfas["S"][0])
    pg.addfirstsets()
    assert not pg.first["S"]

    pg = ParserGenerator()
    pg.make_dfas("", "S: BBC\nB: 'b'\nC: 'c'")
    pg.addfirstsets()
    assert pg.first["S"] == {"b": 1}

    pg = ParserGenerator()
    pg.make_dfas("", "S: BBC\nB: 'b' B\nC: 'c'")
    pg.addfirstsets()

# Generated at 2022-06-21 10:23:42.371978
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    # The input
    test_src = b'print("hello world")\n'
    # The expected result of parsing
    expected_result = "<class '__main__.NFAState'>, <class '__main__.NFAState'>" 
    # Parse test_src
    generator = ParserGenerator()
    generator.parse_atom(test_src)
    # Check result
    actual_result = str(generator.parse_atom(test_src))
    assert actual_result == expected_result, 'Expected "%s", got "%s"' % (
        expected_result, actual_result)

if __name__ == "__main__":
    # Run the unit tests in this file
    import cProfile
    cProfile.run('test_ParserGenerator_parse_atom()')


# Generated at 2022-06-21 10:23:46.732938
# Unit test for function generate_grammar
def test_generate_grammar():

    p = ParserGenerator("Grammar.txt")
    g = p.make_grammar()
    assert isinstance(g, PgenGrammar)


pgen = generate_grammar()

# END OF PARSER GENERATOR

# Generated at 2022-06-21 10:23:57.145817
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    """Testing method calcfirst of class ParserGenerator"""

    pg = ParserGenerator()
    assert pg.first is None
    pg.addfirstsets()
    assert pg.first is not None
    #
    expr2 = pg.dfas['expr_stmt', 2]
    assert pg.calcfirst(('expr_stmt', 2)) == None
    #
    # expr_stmt ::= testlist '=' testlist
    # testlist ::= test (',' test)*
    # test ::= or_test ['if' or_test 'else' test] | lambdef
    # or_test ::= and_test ('or' and_test)*
    # and_test ::= not_test ('and' not_test)*
    # not_test ::= 'not' not_test | comparison
    # comp_op ::=

# Generated at 2022-06-21 10:24:04.057616
# Unit test for method addarc of class NFAState
def test_NFAState_addarc():
    a = NFAState()
    b = NFAState()
    a.addarc(b)
    assert repr(a) == "NFAState(arcs=[(None, NFAState())])"
test_NFAState_addarc()


# Generated at 2022-06-21 10:24:14.595979
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    from pprint import pprint

    class DFAState:
        def __init__(self, nfaset, isfinal):
            self.nfaset = nfaset
            self.isfinal = isfinal

        def addarc(self, st, label):
            self.arcs[label] = st

        def __repr__(self):
            return "DFAState({}, {})".format(self.nfaset, self.isfinal)


    dfa = []
    s0 = DFAState({'a': 1, 'b': 1}, False)
    s0.arcs = {'a': 'x', 'b': 'y'}
    dfa.append(s0)
    s1 = DFAState({'c': 1, 'd': 1}, False)
    s1.arc

# Generated at 2022-06-21 10:24:24.270237
# Unit test for method __eq__ of class DFAState
def test_DFAState___eq__():
    n1 = NFAState()
    n2 = NFAState()
    n3 = NFAState()
    d1 = DFAState({n1: 1, n2: 1}, n2)
    d2 = DFAState({n1: 1, n2: 1}, n2)
    assert d1 == d2
    d2 = DFAState({n1: 1, n3: 1}, n2)
    assert d1 != d2
    d3 = DFAState({n1: 1, n2: 1}, n2)
    d4 = DFAState({n1: 1, n2: 1}, n2)
    d1.addarc(d3, "foo")
    d2.addarc(d4, "bar")
    assert d1 != d2

# Generated at 2022-06-21 10:24:35.471136
# Unit test for constructor of class DFAState
def test_DFAState():
    nfa_states = [NFAState() for i in range(2)]
    nfa_final_state = nfa_states[1]

    assert not nfa_states[0].arcs
    assert not nfa_states[1].arcs

    state = DFAState(nfa_states[0].__dict__, nfa_final_state)
    assert isinstance(state, DFAState)
    assert not state.arcs
    assert state.isfinal is False
    assert state.nfaset == nfa_states[0].__dict__

    state = DFAState(nfa_states[1].__dict__, nfa_final_state)
    assert isinstance(state, DFAState)
    assert not state.arcs
    assert state.isfinal is True
    assert state.nfaset

# Generated at 2022-06-21 10:25:30.092998
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():
    # This is a tricky data structure: dfa[1]->dfa[5] is the same
    # state as dfa[2]->dfa[4].  Thus dfa[1]->dfa[2]->dfa[4] is a
    # cycle.
    dfa1 = DFAState({}, None)
    dfa2 = DFAState({}, None)
    dfa3 = DFAState({}, None)
    dfa4 = DFAState({}, None)
    dfa5 = DFAState({}, None)
    dfa1.arcs["a"] = dfa2
    dfa2.arcs["b"] = dfa4  # same as dfa5
    dfa3.arcs["*"] = dfa5
    # print "before", dfa1.arcs
    # print

# Generated at 2022-06-21 10:25:39.207045
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():    # type: ignore
    import pgen.grammar

    # A list of pairs:
    #  - method argument
    #  - expected method result

# Generated at 2022-06-21 10:25:43.386012
# Unit test for method addarc of class NFAState
def test_NFAState_addarc():
    x = NFAState()
    y = NFAState()
    x.addarc(y)
    assert x.arcs == [("None", y)]
# Unit tests for method __init__ of class NFAState

# Generated at 2022-06-21 10:25:52.027488
# Unit test for constructor of class NFAState
def test_NFAState():
    n1 = NFAState()
    n2 = NFAState()
    n3 = NFAState()
    assert n1.arcs == []
    assert n2.arcs == []
    assert n3.arcs == []
    n1.addarc(n2, "foo")
    assert n1.arcs == [("foo", n2)]
    n1.addarc(n3)
    assert n1.arcs == [("foo", n2), (None, n3)]
    assert n2.arcs == []
    assert n3.arcs == []



# Generated at 2022-06-21 10:26:04.078167
# Unit test for function generate_grammar
def test_generate_grammar(): # hint: pytest tests/test_parser.py::test_generate_grammar
    filename = "Grammar.txt"
    parser = ParserGenerator(filename)
    assert parser.make_grammar() is not None
    assert parser.make_grammar() == grammar
    assert grammar is not None
    assert isinstance(grammar, PgenGrammar)
    assert isinstance(grammar.dfas, dict)
    assert isinstance(grammar.labels, list)
    assert isinstance(grammar.first, dict)
    assert isinstance(grammar.startsymbol, str)
    assert isinstance(grammar.tokens, dict)
    assert isinstance(grammar.keywords, dict)

# Unit tests for class ParserGenerator

# Generated at 2022-06-21 10:26:15.575253
# Unit test for method addarc of class DFAState
def test_DFAState_addarc():
    assert True
    a = DFAState({}, None)
    b = DFAState({}, None)
    assert a != b
    a.addarc(b, "x")
    assert a.arcs == {"x": b}, a.arcs
    # Can't add the same label twice
    pytest.raises(AssertionError, a.addarc, b, "x")
    a.addarc(b, "y")
    assert a.arcs == {"x": b, "y": b}, a.arcs
    # Can add a different label to the same state
    a.addarc(b, "z")
    assert a.arcs == {"x": b, "y": b, "z": b}, a.arcs
    # Can't add a different state for the same label

# Generated at 2022-06-21 10:26:16.196126
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    PgenGrammar()



# Generated at 2022-06-21 10:26:19.340646
# Unit test for function generate_grammar
def test_generate_grammar():
    p = ParserGenerator()
    p.make_grammar()






# The main function
if __name__ == "__main__":
    print("Hello, pyParserGenerator!")
    # import pyParserGenerator
    # pyParserGenerator.generate_grammar()
    generate_grammar()

# Generated at 2022-06-21 10:26:30.246051
# Unit test for method calcfirst of class ParserGenerator

# Generated at 2022-06-21 10:26:34.830047
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    from test.test_tokenize import tokenize
    from io import StringIO
    parser = ParserGenerator(tokenize(StringIO(''), '<unknown>'), '<unknown>')
    with pytest.raises(SyntaxError):
        parser.expect(token.ENDMARKER)

# Generated at 2022-06-21 10:27:37.036031
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():

    def helper(text, substring):
        p = ParserGenerator()
        nfa_states, final_state = p.parse_rhs()
        p.dump_nfa("?", nfa_states, final_state)
        assert substring in str(p), text

    helper("a | b", "(-> 0) b ->")
    helper("a | 'b'", "(-> 0) 'b' ->")
    helper("[a]", "(-> 0) a -> 2")
    helper(" [a]", "(-> 4) a -> 2")
    helper("a+", "(-> 0) a -> 0")
    helper("a*", "(-> 0) a -> 1")
    helper("[a]*", "(-> 0) a -> 1")
    helper("[a]*", "(-> 1) a -> 1")
    helper

# Generated at 2022-06-21 10:27:48.216776
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    rg = ParserGenerator()
    rg.dfas = {"S": [DFAState({}, False)]}
    rg.addfirstsets()
    assert rg.first["S"] == {}
    rg.dfas = {"S": [DFAState({}, False)], "A": [DFAState({}, False)]}
    rg.addfirstsets()
    assert rg.first["S"] == {}
    assert rg.first["A"] == {}
    rg.dfas = {"S": [DFAState({}, False)], "A": [DFAState({}, False)], "B": [DFAState({}, False)]}
    rg.addfirstsets()
    assert rg.first["S"] == {}
    assert rg.first["A"] == {}
    assert rg.first["B"] == {}

# Generated at 2022-06-21 10:27:53.102783
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    from unittest.mock import Mock
    p = ParserGenerator()
    gettoken = Mock(return_value=('value', 'foo'))
    parse_atom = Mock(return_value=(313, 37))
    p.gettoken = gettoken
    p.parse_atom = parse_atom
    assert p.parse_item() == ((313, 37), (313, 37))
    gettoken.assert_called_with()
    parse_atom.assert_called_with()

    gettoken.reset_mock()
    parse_atom.reset_mock()
    p.value = '+'
    assert p.parse_item() == ((313, 37), (313, 37))
    gettoken.assert_called_with()
    parse_atom.assert_called_with()

    gettoken.reset_mock()

# Generated at 2022-06-21 10:27:59.808141
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    pg = ParserGenerator()
    a = NFAState()
    b = NFAState()
    c = NFAState()
    a.addarc('a', b)
    a.addarc('b', c)
    b.addarc('c', c)
    c.addarc('d', b)
    pg.dump_nfa('name', a, c)


# Generated at 2022-06-21 10:28:10.097751
# Unit test for method parse_atom of class ParserGenerator

# Generated at 2022-06-21 10:28:12.527342
# Unit test for constructor of class NFAState
def test_NFAState():
    a = NFAState()
    b = NFAState()
    a.addarc(b)
    assert list(a.arcs) == [(None, b)]



# Generated at 2022-06-21 10:28:21.467927
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    p = ParserGenerator()
    try:
        p.filename = "foo"
        p.end = (5,6)
        p.line = "hello"
        p.raise_error("hello")
    except SyntaxError as e:
        assert str(e) == 'hello'
        assert e.filename == "foo"
        assert e.lineno == 5
        assert e.offset == 6
        assert e.text == "hello"
        return
    assert False, 'test of ParserGenerator.raise_error failed'



# Generated at 2022-06-21 10:28:25.758161
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    """Verify that the constructor for PgenGrammar doesn't have to have a
    keyword argument."""
    c1 = PgenGrammar()
    assert c1.keywords == {}
    c2 = PgenGrammar(keywords={"statement": 1})
    assert c2.keywords != {}



# Generated at 2022-06-21 10:28:35.279277
# Unit test for function generate_grammar
def test_generate_grammar():
    dfa = PgenGrammar("Grammar.txt")
    root, dfas = dfa.generate("Grammar.txt")
    dfa_dict = {root: dfas}
    assert dfa_dict.keys() == {'file_input'}
    assert dfa_dict["file_input"][4].arcs == {'NAME': 7, 'STRING': 5}
    assert dfa_dict["file_input"][1].arcs == {'NEWLINE': 4}
    assert dfa_dict["file_input"][2].isfinal == True
    assert dfa_dict["file_input"][0].isfinal == False


test_generate_grammar()


# Generated at 2022-06-21 10:28:42.638466
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    # ATTENTION: the line numbers of the test data would get incremented
    # by 1 after including the docstring to this function in the coverage analysis
    import _ast
    import ast
    from ast import parse
    from pgen2.parse import ParseError, ParserGenerator
    s = "a : '[b]' '[' '|' '|' \n"
    # pylint: disable=blacklisted-name

# Generated at 2022-06-21 10:30:22.498317
# Unit test for constructor of class NFAState
def test_NFAState():
    n = NFAState()
    assert n.arcs == []


# Generated at 2022-06-21 10:30:28.180560
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    o = ParserGenerator()
    o.dump_dfa(
        "foo",
        [
            DFAState({}, None),
            DFAState({1: 1}, None),
            DFAState({2: 1}, None),
            DFAState({3: 1}, None),
        ],
    )


if __name__ == "__main__":
    # Test
    test_ParserGenerator_dump_dfa()

# Generated at 2022-06-21 10:30:37.821334
# Unit test for method addarc of class NFAState
def test_NFAState_addarc():
    s = NFAState()
    s.addarc(NFAState(), "a")
    assert len(s.arcs) == 1
    s.addarc(NFAState(), "b")
    assert len(s.arcs) == 2
    s.addarc(NFAState())
    assert len(s.arcs) == 3
    assert [label for label, next in s.arcs] == ["a", "b", None]
    s.addarc(NFAState(), "b")
    assert len(s.arcs) == 4
    assert [label for label, next in s.arcs] == ["a", "b", None, "b"]
    s.addarc(NFAState())
    assert len(s.arcs) == 5

# Generated at 2022-06-21 10:30:41.955367
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    pg = ParserGenerator()
    pg.add_file("<test>", """\
# This is a comment
start: a b c
a: "foo"
b: "bar"
c: "bat"
""")
    pg.make_grammar()


# Generated at 2022-06-21 10:30:52.834095
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    class MockGenerator(object):
        def __init__(self, items: List[Tuple[int, str, int, int, str]]) -> None:
            self.items: List[Tuple[int, str, int, int, str]] = items
            self.i = 0

        def __iter__(self) -> Iterator[Tuple[int, str, int, int, str]]:
            return self

        def __next__(self) -> Tuple[int, str, int, int, str]:
            if self.i >= len(self.items):
                raise StopIteration
            x = self.items[self.i]
            self.i += 1
            return x
