

# Generated at 2022-06-21 10:23:17.811294
# Unit test for method dump_nfa of class ParserGenerator

# Generated at 2022-06-21 10:23:21.915001
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    # Constructor of class PgenGrammar
    PgenGrammar()
    # __init__
    # called by Grammar.__init__
    assert PgenGrammar.__init__ == grammar.Grammar.__init__


# Generated at 2022-06-21 10:23:30.256181
# Unit test for method expect of class ParserGenerator

# Generated at 2022-06-21 10:23:42.372678
# Unit test for method make_grammar of class ParserGenerator

# Generated at 2022-06-21 10:23:49.612438
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    def check(s, t):
        print(s, t)
        list(ParserGenerator(s))
    check("", (None, None))
    check(",", (",", None))
    for i in ["(", "[", "|", "+", "*"]:
        check(i, (i, None))
        check(i + "a", (i, "a"))
    check('""', ("STRING", ""))
    check('"a"', ("STRING", "a"))
    check('"\\""', ("STRING", '"'))
    check('"\\"a\\""', ("STRING", '"a"'))
    check('"\\"\\""', ("STRING", '""'))
    check('"\\"\\"a\\"\\""', ("STRING", '""a""'))
   

# Generated at 2022-06-21 10:24:02.527218
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    pg = ParserGenerator()
    # a) Empty sequence
    a, b = pg.parse_alt()
    assert a.arcs == b.arcs == []
    assert a is not b
    # b) Single item
    pg.value = 'name'
    a, b = pg.parse_alt()
    assert a.arcs == b.arcs == [(None, b)]
    # c) Two items
    pg.value = 'name2'
    a, c = pg.parse_alt()
    assert a.arcs == c.arcs == [(None, c)]
    b.addarc(a)
    assert a.arcs == [
        (None, b),
        (None, c),
        ]
    assert b.arcs == [
        (None, a),
        ]
    assert c

# Generated at 2022-06-21 10:24:06.416604
# Unit test for constructor of class NFAState
def test_NFAState():
    s = NFAState()
    assert s.arcs == []
    s.addarc(NFAState())
    expected_arcs = [(None, NFAState())]
    assert s.arcs == expected_arcs



# Generated at 2022-06-21 10:24:16.202983
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    import io, tokenize, pgen2.token, pgen2.grammar
    filename = 'testtext'
    text = '''




a : 'a'

b : 'b'
b :
    | 'b'

c : 'c' 'c'

d : 'd' | 'e' | 'f'

'''

    def get_tokenizer(text, filename=filename):
        return tokenize.tokenize(io.BytesIO(text.encode('utf-8')).readline)
    tokengen = get_tokenizer(text)
    pg = pgen2.grammar.ParserGenerator(tokengen, filename)
    pg.gettoken()
    assert pg.type == token.NAME
    assert pg.value == 'a'

# Generated at 2022-06-21 10:24:27.706489
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    pg = ParserGenerator()
    
    # 1. Test: RHS -> ALT ('|' ALT)* 
    #   S -> aAb
    pg.rhs = 'a Ab' 
    pg.rhs_to_input()
    pg.parse()
    assert pg.output_list[0][0]    == 'S'
    assert pg.output_list[0][1]    == 'a'
    assert pg.output_list[0][2]    == 'A'
    assert pg.output_list[0][3]    == 'b'
    
    #   S -> S S
    pg.rhs = 'S S'
    pg.rhs_to_input()
    pg.parse()
    assert pg.output_list[1][0]    == 'S'

# Generated at 2022-06-21 10:24:38.087127
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    from .automaton import FAIL
    from .parse import ParserGenerator
    pg = ParserGenerator(
        """
        s: a
        a: 'a'
        b: 'b' | 'c'
        c: 'd'
        d: 'c' | 'e'
        """.splitlines()
    )
    c = pg.convert()
    first = c.make_first(c, "a")
    assert first[c.labels[2][0]] == 1
    first = c.make_first(c, "b")
    assert first[c.labels[3][0]] == 1
    assert first[c.labels[4][0]] == 1
    first = c.make_first(c, "c")

# Generated at 2022-06-21 10:25:36.727925
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    p = ParserGenerator()
    file_open = open("./python/Tokens.py")
    p.generator = tokenize.generate_tokens(file_open.readline)
    p.gettoken()
    assert p.type == token.NAME
    assert p.value == "Token"
    p.gettoken()
    assert p.type == token.NAME
    assert p.value == "="
    p.gettoken()
    assert p.type == token.NAME
    assert p.value == "type"
    p.gettoken()
    assert p.type == token.NAME
    assert p.value == "("


# Generated at 2022-06-21 10:25:39.335336
# Unit test for method addarc of class NFAState
def test_NFAState_addarc():
    a = NFAState()
    b = NFAState()
    a.addarc(b)
    assert a.arcs == [(None, b)]

# Generated at 2022-06-21 10:25:50.177373
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    import io
    import sys
    import tokenize

# Generated at 2022-06-21 10:25:57.736712
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    pg = PgenGrammar(token.grammar)
    pg = PgenGrammar(grammar)
    try:
        pg = PgenGrammar(grammar.Grammar)
    except TypeError:
        pass
    try:
        pg = PgenGrammar(token)
    except TypeError:
        pass
    try:
        pg = PgenGrammar(tokenize)
    except TypeError:
        pass



# Generated at 2022-06-21 10:26:10.129049
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    # See issue #8366: test tokenizer replacement
    # This test fails with the old tokenizer.
    pg = ParserGenerator()
    pg.make_label(None, 'IDENTIFIER'), pg.make_label(None, 'NUMBER')
    pg.make_label(None, 'STRING'), pg.make_label(None, 'op')
    pg.make_label(None, 'NAME'), pg.make_label(None, 'KEYWORD')
    pg.make_label(None, '"and"'), pg.make_label(None, '"or"')
    # 'op' not in grammar.opmap
    raises(ValueError, pg.make_label, None, 'op')
    # 'KEYWORD' not in token.tok_name

# Generated at 2022-06-21 10:26:18.521846
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    p = ParserGenerator()
    a = DFAState({}, 0)
    b = DFAState({}, 0)
    c = DFAState({}, 0)
    d = DFAState({}, 0)
    a.addarc(b, "a")
    b.addarc(b, "a")
    c.addarc(b, "a")
    c.addarc(d, "b")
    d.addarc(b, "a")
    d.addarc(d, "b")
    dfa = [a, b, c, d]
    p.simplify_dfa(dfa)
    assert dfa == [a, b, b, d]

# Generated at 2022-06-21 10:26:21.934220
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    filename = "test grammar"
    p = ParserGenerator(filename, tokenize.tokenize(io.BytesIO(b'print "hi"').readline))
    assert p.expect(token.NAME)=="print"
    assert p.expect(token.STRING)=='"hi"'
    raises(SyntaxError, p.expect, token.NAME, "print")


# Generated at 2022-06-21 10:26:34.422986
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    pg = ParserGenerator()
    pg.dfas = {}
    a = NFAState()
    aa = NFAState()
    b = NFAState()
    bb = NFAState()
    c = NFAState()
    cc = NFAState()
    d = NFAState()
    dd = NFAState()
    e = NFAState()
    ee = NFAState()
    a.addarc(aa, "c")
    a.addarc(b, "a")
    aa.addarc(c, "d")
    b.addarc(bb, "b")
    bb.addarc(c, "d")
    c.addarc(d, "e")
    c.addarc(cc, "c")
    d.addarc(dd, "d")
   

# Generated at 2022-06-21 10:26:38.927031
# Unit test for method addarc of class DFAState
def test_DFAState_addarc():
    from pickle import loads, dumps
    nfa1 = NFAState(); nfa2 = NFAState()
    a = DFAState({nfa1: 1}, nfa1)
    a.addarc(a, 'x')
    acopy = loads(dumps(a))
    assert acopy.arcs == {'x': acopy}

# Generated at 2022-06-21 10:26:46.428581
# Unit test for method addarc of class DFAState
def test_DFAState_addarc():
    class C(DFAState):
        pass
    a = C({1:1}, 1)
    b = C({2:1}, 2)
    c = C({3:1}, 3)
    a.addarc(b, "ab")
    a.addarc(c, "ac")
    assert a.arcs["ab"] is b
    assert a.arcs["ac"] is c


# Generated at 2022-06-21 10:27:50.983466
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    ## XXX not tested:
    ## - token.NAME
    ## - keywords
    ## - operators
    # <kw>: (name, expected result)
    kws = [("False", token.NAME), ("None", token.NAME), ("True", token.NAME)]
    # <op>: (name, expected result)
    ops = [("@", token.AT), ("->", token.RARROW), ("==", token.EQ), ("*=", token.EQEQ)]
    con = ParserGenerator.Converter()
    # Test keywords
    for name, expected in kws:
        assert con.make_label(con, name) == expected
    # Test operators
    for name, expected in ops:
        assert con.make_label(con, name) == expected



# Generated at 2022-06-21 10:28:03.238213
# Unit test for function generate_grammar
def test_generate_grammar():
    # The code below is a simple test of my code, that you can use to check
    # that the code that you write for this exercise works as you expect. To
    # use it, you will need to change the file name in the call to
    # generate_grammar to the file name of your version of the grammar file.
    yacc = generate_grammar(Path('Grammar.txt'))
    # print(yacc.dfas)
    # print(yacc.start)
    # print(yacc.tokens)
    assert(yacc.keywords == dict())

# Generated at 2022-06-21 10:28:07.936590
# Unit test for constructor of class NFAState
def test_NFAState():
    s = NFAState()
    s.addarc("next", "label")
    assert s.arcs == [(None, "next")]
    s.addarc("next", "label")
    assert s.arcs == [(None, "next"), (None, "next")]


# Generated at 2022-06-21 10:28:15.970705
# Unit test for constructor of class NFAState
def test_NFAState():
    s = NFAState()
    assert len(s.arcs) == 0
    s.addarc(NFAState())
    assert len(s.arcs) == 1
    a, b = s.arcs[0]
    assert a is None
    assert isinstance(b, NFAState)
    s.addarc(NFAState(), "a")
    assert len(s.arcs) == 2
    a, b = s.arcs[1]
    assert a == "a"
    assert isinstance(b, NFAState)


# Generated at 2022-06-21 10:28:27.210481
# Unit test for method __eq__ of class DFAState
def test_DFAState___eq__():
    a = DFAState({}, NFAState())
    b = DFAState({}, NFAState())
    c = DFAState({}, NFAState())
    a.addarc(a, "a")
    b.addarc(a, "a")
    c.addarc(a, "a")
    c.addarc(a, "b")
    assert not a == b
    assert not a == c
    assert not b == c
    b.addarc(a, "b")
    assert not a == b
    assert b == c

    x = DFAState({}, NFAState())
    y = DFAState({}, NFAState())
    z = DFAState({}, NFAState())
    x.addarc(y, "a")
    y.addarc(z, "b")

# Generated at 2022-06-21 10:28:35.798915
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    p = ParserGenerator()
    p.dfas = {
        "s": [DFAState({0: 1}, False), DFAState({2: 1}, True)],
        "a": [DFAState({3: 1}, False), DFAState({4: 1}, False), DFAState({}, True)],
        "b": [DFAState({}, True)],
    }
    p.startsymbol = "s"
    p.addfirstsets()
    assert p.first == {"s": {"a": 1, "b": 1}, "a": {}, "b": {}}

# Generated at 2022-06-21 10:28:42.902484
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    pg = ParserGenerator()
    pg.add_dfa("A", [], [])
    pg.add_dfa("B", [], [], isfinal=True)
    pg.add_dfa("C", [("a", 1)], [], isfinal=True)
    pg.add_dfa("D", [("a", 1), ("b", 2)], [0, 2])
    pg.add_dfa("E", [("a", 1), ("a", 2)], [0, 2])
    pg.add_dfa("F", [("a", 1), ("a", 1)], [0, 2])
    print(pg.dfas["A"])
    print(pg.dfas["B"])
    print(pg.dfas["C"])

# Generated at 2022-06-21 10:28:44.420209
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    PgenGrammar(None, None, None, None)


# Generated at 2022-06-21 10:28:47.998174
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    """Testing of constructor of class PgenGrammar"""
    p_grammar = PgenGrammar("", [])



# Generated at 2022-06-21 10:28:50.287478
# Unit test for method addarc of class DFAState
def test_DFAState_addarc():
    n1 = NFAState()
    n2 = NFAState()
    st = DFAState({n1: 1}, n2)
    st.addarc(st, "label")
    assert st.arcs == {"label": st}

