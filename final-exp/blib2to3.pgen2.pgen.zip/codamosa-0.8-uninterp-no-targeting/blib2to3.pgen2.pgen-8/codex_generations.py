

# Generated at 2022-06-21 10:23:04.677998
# Unit test for constructor of class DFAState
def test_DFAState():
    assert DFAState({}, NFAState()) == DFAState({}, NFAState())
    assert DFAState({NFAState():1}, NFAState()) != DFAState({NFAState():1}, NFAState())
    assert DFAState({NFAState():1}, NFAState()) != DFAState({NFAState():1}, NFAState())
    a = DFAState({NFAState():1}, NFAState())
    b = DFAState({NFAState():1}, NFAState())
    a.arcs["arc"] = b
    assert a != b
    b.arcs["arc"] = a
    assert a == b


# Generated at 2022-06-21 10:23:13.983431
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    pg = ParserGenerator()
    c = pg.make_label(pg, 'NAME')
    assert c == 1
    c = pg.make_label(pg, '"and"')
    assert c == 2
    c = pg.make_label(pg, 'NUMBER')
    assert c == 3
    c = pg.make_label(pg, '"def"')
    assert c == 4


if __name__ == "__main__":
    import sys

    if len(sys.argv) != 2:
        raise SystemExit("Usage: %s grammar_file" % sys.argv[0])
    filename = sys.argv[1]
    with open(filename, "r", encoding="utf-8") as file:
        pg = ParserGenerator().parse_grammar(file, filename)

# Generated at 2022-06-21 10:23:25.584796
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    return
    g = ParserGenerator()
    c = g.make_converter()
    def check(label: str, value: int) -> None:
        ilabel = g.make_label(c, label)
        assert c.labels[ilabel] == (value, None)

    check("TEST", token.TEST)
    check("NAME", token.NAME)
    check("'test'", token.STRING)
    check("'(test)'", token.STRING)
    check("'x123'", token.STRING)
    check('"test"', token.NAME)
    check('"if"', token.NAME)
    # check("'test'", token.STRING)

    # print c.symbol2number
    # print c.labels
    # print c.dfas


# Generated at 2022-06-21 10:23:34.949575
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    pg = ParserGenerator()
    pg.make_grammar("""
        s: 'a'*
        s: 'b'
        c: 'c'
    """)
    grammar = pg.make_grammar("""
        s: 'a'* 'b'
        c: 'c'
    """)

# Generated at 2022-06-21 10:23:38.311705
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():

    class Dummy(object):
        pass

    d1 = DFAState({}, Dummy())
    d2 = DFAState({}, Dummy())
    d3 = DFAState({}, Dummy())

    d1.addarc(d2, 'x')
    d1.addarc(d3, 'y')
    d1.unifystate(d3, d2)

    assert d1.arcs['x'] is d2
    assert d1.arcs['y'] is d2

# Generated at 2022-06-21 10:23:49.069117
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():  # pylint: disable=too-many-locals
    # pylint: disable=maybe-no-member
    s = []
    for line in __doc__.splitlines():
        if line and not line.isspace():
            s.append(line)
    s = "\n".join(s)
    gen = ParserGenerator(s)
    assert gen.type == tokenize.ENCODING
    assert gen.value == "utf-8"
    gen.gettoken()
    assert gen.type == token.INDENT
    assert gen.value == "    "
    gen.gettoken()
    assert gen.type == token.NAME
    assert gen.value == "class"
    gen.gettoken()
    assert gen.type == token.NAME
    assert gen.value == "ParserGenerator"
    gen.get

# Generated at 2022-06-21 10:23:55.602864
# Unit test for method addarc of class DFAState
def test_DFAState_addarc():
    a = DFAState({}, None)
    assert a.arcs == {}
    a.addarc(None, "a")
    assert a.arcs == {"a": None}
    a.addarc(None, "b")
    assert a.arcs == {"a": None, "b": None}
    a.addarc(None, "a")
    assert a.arcs == {"a": None, "b": None}


# Generated at 2022-06-21 10:24:08.251081
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    class MockedFileReader:
        def __init__(self, mocker, fileinput):
            self.fileinput = fileinput
            self.mocker = mocker
            self.mockReadLine = mocker.patch.object(fileinput.__class__, "readline")
            self._addReadlineResult(tokenize.NAME, "0")
            self._addReadlineResult(tokenize.OP, "=")
            self._addReadlineResult(tokenize.NAME, "0")
            self._addReadlineResult(tokenize.NEWLINE, "")
            self._addReadlineResult(tokenize.NAME, "1")
            self._addReadlineResult(tokenize.OP, "=")
            self._addReadlineResult(tokenize.NAME, "1")

# Generated at 2022-06-21 10:24:11.688253
# Unit test for constructor of class DFAState
def test_DFAState():
    a = NFAState()
    b = NFAState()
    c = NFAState()
    a.addarc(b)
    b.addarc(c)
    d = NFAState()
    e = NFAState()
    assert DFAState({a, b}, c) != DFAState({d, e}, e)
    assert DFAState({a, b}, c) != DFAState({b}, c)
    assert DFAState({a, b}, c) != DFAState({a, b}, b)
    assert DFAState({a, b}, c) == DFAState({a, b}, c)



# Generated at 2022-06-21 10:24:17.451953
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():
    st1 = DFAState({}, None)
    st2 = DFAState({}, None)
    st1.unifystate(st1, st2)
    assert st1 is st2
    assert not st1.arcs
    st1.addarc(st1, "label")
    st1.unifystate(st1, st2)
    assert list(st1.arcs.items()) == [("label", st2)]
# End unit test for method unifystate of class DFAState


# Generated at 2022-06-21 10:25:10.911714
# Unit test for method addarc of class DFAState
def test_DFAState_addarc():
   _ = DFAState({NFAState(): 1}, NFAState())


# Generated at 2022-06-21 10:25:23.895118
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    import io
    import tokenize

    def tokenize_by_line(text: str) -> Iterator[Tuple[int, str, Any, Any, Any]]:
        it = tokenize.generate_tokens(io.StringIO(text).readline)
        while True:
            tup = next(it)
            if tup[2][0] > 1:
                return
            yield tup

    pg = ParserGenerator()
    pg.add_token(tokenize_by_line(""))
    pg.add_token(tokenize_by_line(
        "a: 'a'\n"
        "b: 'b'\n"
    ))

# Generated at 2022-06-21 10:25:35.266145
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    import io
    import unittest.mock

    pg = ParserGenerator()
    fp = io.StringIO()
    with unittest.mock.patch('sys.stdout', fp):
        pg.dump_dfa('a', [])
    assert fp.getvalue() == "Dump of DFA for a\n"

    fp = io.StringIO()
    with unittest.mock.patch('sys.stdout', fp):
        pg.dump_dfa('a', [DFAState({}, False), DFAState({}, True)])
    assert fp.getvalue() == "Dump of DFA for a\n  State 0\n  State 1 (final)\n"

    fp = io.StringIO()

# Generated at 2022-06-21 10:25:41.191277
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    pg = ParserGenerator()
    pg.add_production(None, ["expr_ty"], """
        ('(' expr_ty ',' expr_ty ')'
        | ('[' expr_ty ',' expr_ty ']')) [':' expr_ty]
    """)
    pg.done()
    print(len(pg.dfas["expr_ty"]))


# Generated at 2022-06-21 10:25:43.240335
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    assert ParserGenerator("").parse_item() == (None, None)

# Generated at 2022-06-21 10:25:52.375276
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    p = ParserGenerator()
    p.dfas = dict(
        A=DFA(0),
        B=DFA(0),
        C=DFA(0),
        D=DFA(0),
        E=DFA(0),
        F=DFA(0),
        G=DFA(0),
        H=DFA(0),
        I=DFA(0),
        J=DFA(0),
        K=DFA(0),
        L=DFA(0),
        M=DFA(0),
    )

# Generated at 2022-06-21 10:26:04.916050
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    import tokenize

    def test(input, expected):
        def queue_gen(seq):
            for item in seq:
                yield item

        pg = ParserGenerator()
        pg.generator = queue_gen(tokenize.generate_tokens(StringIO(input).readline))
        pg.gettoken()
        result = pg.parse_atom()
        assert result == expected, "%r != %r" % (result, expected)

    test("(a)", (NFAState(1, arcs={(None, NFAState(2))}), NFAState(2),))
    test("a", (NFAState(1, arcs={("a", NFAState(2))}), NFAState(2),))

# Generated at 2022-06-21 10:26:16.334328
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    import os
    import tokenize
    import io

    d = {}
    exec(open(os.path.join(os.path.dirname(__file__), "Grammar.txt"), "r").read(), d)

    pgen = d['pgen']

    try:
        # Make sure the generated grammar is sane.
        p = pgen.ParserGenerator()
        assert p.compile(io.StringIO(r"""
          # This comment is OK
          # This one as well
        """))
    except SyntaxError:
        pass

    # And we can compile even if there is a comment previous to the first
    # rule
    p = pgen.ParserGenerator()

# Generated at 2022-06-21 10:26:21.592017
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    class MyParserGenerator(ParserGenerator):
        def __init__(self, grammar, startsymbol):
            ParserGenerator.__init__(self, grammar, startsymbol)
        def make_dfa(self, start, finish):
            return [start, finish]  # skip the actual DFA construction
        def simplify_dfa(self, dfa):
            pass  # skip the DFA simplification
        def test_calcfirst(self):
            return self.calcfirst("single_input")
    p = MyParserGenerator(grammar, "single_input")
    assert p.test_calcfirst() is None
try:
    from . import ast
except ImportError:
    from ast import ast

# This is the main entry point for the parser; given a lexical scanner,
# returns a grammar object.

# Generated at 2022-06-21 10:26:34.102439
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    from . import grammar
    from . import symbols
    pgen = ParserGenerator(grammar.pgen_grammar, symbols.pgen_symbols)
    pgen.addfirstsets()
    # pprint.pprint(pgen.first)
    assert pgen.first

# Generated at 2022-06-21 10:28:31.550988
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    import io
    import unittest
    from . import grammar
    from .tokenize import generate_tokens
    from .token import tok_name
    pgen = ParserGenerator()
    with io.StringIO(
        """\
# This is a comment
expr: xor ('|' xor)*
xor: and ('^' and)*
and: not ('&' not)*
not: '~' not | comparison
"""
    ) as f:
        g = pgen.make_grammar(f, "mygrammar")
    assert g.opmap["|"] == token.OP
    for s, t in g.symbol2number.items():
        assert isinstance(t, int)
        assert t >= 256
        assert t not in g.number2symbol

# Generated at 2022-06-21 10:28:40.635385
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    # Test with pure tokenize
    test_result = PgenGrammar._tokenize(tokenize.generate_tokens(
        StringIO('1 + 1').__iter__().__next__))
    assert test_result == [GoodTokenInfo(tokenize.NUMBER, '1', 1, 0, '1'),
                           GoodTokenInfo(tokenize.OP, '+', 1, 2, '+'),
                           GoodTokenInfo(tokenize.NUMBER, '1', 1, 4, '1')]
    # Test with grammar
    test_result2 = PgenGrammar._tokenize(tokenize.generate_tokens(
        StringIO('1 + 1').__iter__().__next__))

# Generated at 2022-06-21 10:28:42.072289
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    g = PgenGrammar()
    assert g is not None



# Generated at 2022-06-21 10:28:44.744179
# Unit test for method addarc of class DFAState
def test_DFAState_addarc():
    a = DFAState({NFAState(): 1}, NFAState())
    a.addarc(DFAState({NFAState(): 1}, NFAState()), "x")



# Generated at 2022-06-21 10:28:47.951534
# Unit test for constructor of class NFAState
def test_NFAState():
    a = NFAState()
    assert isinstance(a, NFAState)



# Generated at 2022-06-21 10:28:58.864916
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    import io
    import unittest
    from . import pgen2
    from .token import TokenInfo, tok_name
    from .tokenize import tokenize
    from .parser import ParserGenerator
    from . import token
    from . import grammar
    from . import symbol
    from . import driver
    from . import error
    from . import pytoken
    from . import pgen2
    from . import tokenize2
    from . import token
    from . import grammar
    def main(argv: List[str]) -> int:
        if len(argv) > 2 or (len(argv) == 2 and argv[1] == "-h"):
            print("usage: python %s [filename]" % argv[0])

# Generated at 2022-06-21 10:29:06.037952
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    import sys

    import parser

    p = ParserGenerator(parser.grammar, parser.syms, parser.labels)

    print("DFA for start symbol:")
    p.dump_dfa("single_input", p.dfas["single_input"])

# Generated at 2022-06-21 10:29:17.260094
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    pgen = ParserGenerator()
    dfa = [
        [  # Transitions of state 0
            (token.NAME, 1),
            (token.NUMBER, 2),
            (token.STRING, 3),
        ],
        [  # Transitions of state 1
            (token.NAME, 0),
        ],
        [  # Transitions of state 2
            (token.NUMBER, 0),
        ],
        [  # Transitions of state 3
            (token.STRING, 0),
        ],
    ]
    c = pgen.make_grammar(dfa)
    assert c.symbol2number[c.startsymbol] == 0
    assert c.symbol2number["sym1"] == 1
    assert c.symbol2number["sym2"] == 2
    assert c.symbol2

# Generated at 2022-06-21 10:29:18.186191
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    assert False, "Test cases needed"



# Generated at 2022-06-21 10:29:29.267552
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    import py.test

    def check(pg: ParserGenerator, ref: Any) -> None:
        res = pg.parse()
        assert res == ref

    s = r"""
    foo :: bar baz
        | bing
    bar :: "{" baz "}"
    baz :: NAME
        | STRING
    """

    pg = ParserGenerator(s)