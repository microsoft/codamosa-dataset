

# Generated at 2022-06-21 10:23:03.584478
# Unit test for constructor of class DFAState
def test_DFAState():
    N = NFAState
    D = DFAState
    a = N()
    b = N()
    c = N()
    d = N()
    d.addarc(a, 'a')
    d.addarc(b, 'b')
    c.addarc(d, 'c')
    c.addarc(d, 'd')
    c.addarc(c, 'e')
    c.addarc(a, 'f')
    a.addarc(a, 'g')
    a.addarc(a, 'h')
    a.addarc(a, 'i')
    a.addarc(a, 'j')
    a.addarc(a, 'k')
    a.addarc(a, 'l')
    a.addarc(a, 'm')
    a.addarc

# Generated at 2022-06-21 10:23:09.458097
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    a = ParserGenerator(StringIO("a+ b* c"))
    a.gettoken()
    a.parse_alt()
    b = ParserGenerator(StringIO("a+ b | c"))
    b.gettoken()
    b.parse_alt()
    c = ParserGenerator(StringIO("a+ (b | c)"))
    c.gettoken()
    c.parse_alt()
    assert True

# Generated at 2022-06-21 10:23:14.745404
# Unit test for constructor of class DFAState
def test_DFAState():
    a = DFAState({'a': 1}, 'b')
    assert a.nfaset == {'a': 1}
    assert a.isfinal == True
    assert a.arcs == {}


# Generated at 2022-06-21 10:23:26.061574
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    with open("Grammar/Grammar", encoding="utf-8") as file:
        text = file.read()
    stream = io.StringIO(text)
    generator = tokenize.generate_tokens(stream.readline)
    pgen = ParserGenerator()    
    pgen.generator = generator
    pgen.gettoken()
    assert pgen.type == token.NAME, pgen.type
    assert pgen.value == "file_input", pgen.value
    assert pgen.begin == (1, 0), pgen.begin
    assert pgen.end == (1, 8), pgen.end
    assert pgen.line == "file_input: ( NEWLINE | stmt )* ENDMARKER\n", pgen.line
    pgen.gettoken()
    assert pgen

# Generated at 2022-06-21 10:23:34.977880
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    pg = ParserGenerator()
    pg.type = token.NAME
    pg.value = "name"

# Generated at 2022-06-21 10:23:41.634082
# Unit test for method addarc of class NFAState
def test_NFAState_addarc():
    s = NFAState()
    t = NFAState()
    s.addarc(t)
    s.addarc(t, 'x')
    s.addarc(t, 'x')
    assert s.arcs == [(None, t), ('x', t), ('x', t)]
# Test method test_NFAState_addarc of class NFAState
test_NFAState_addarc()



# Generated at 2022-06-21 10:23:48.858047
# Unit test for constructor of class DFAState
def test_DFAState():
    d = DFAState({1: None}, 1)
    assert d.nfaset == {1: None}
    assert d.isfinal
    d.arcs = {'a': 3}
    d2 = DFAState({1: None}, 2)
    assert d2.nfaset == {1: None}
    assert not d2.isfinal
    d2.arcs = {'a': 3}
    assert d != d2
    d3 = DFAState({1: None}, 1)
    assert d3.nfaset == {1: None}
    assert d3.isfinal
    d3.arcs = {'a': 3}
    d4 = DFAState({1: None}, 1)
    assert d4.nfaset == {1: None}

# Generated at 2022-06-21 10:23:51.504603
# Unit test for method addarc of class NFAState
def test_NFAState_addarc():
    in0 = NFAState()
    in1 = NFAState()
    in2 = str()
    in0.addarc(in1,in2)
    assert in0.arcs == [(in2,in1)], "test #0 failed"



# Generated at 2022-06-21 10:23:57.043280
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    pg = ParserGenerator()
    pg.build()
    pg.converter = None
    for name in pg.dfas:
        pg.dump_dfa(name, pg.dfas[name])
if __name__ == "__main__":
    test_ParserGenerator_dump_dfa()


# Generated at 2022-06-21 10:24:08.153994
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    def testtoken(tokens, expect):
        pg = ParserGenerator()
        pg.line = "This is a test"
        pg.generator = iter(tokens)
        pg.gettoken()
        assert (pg.type, pg.value) == expect

    testtoken([(1, ""), (4, "")], (4, ""))
    testtoken([(1, ""), (tokenize.COMMENT, "test"), (4, "")], (4, ""))
    testtoken([(1, ""), (tokenize.NL, ""), (4, "")], (4, ""))
    testtoken([(1, "")], (1, ""))

# Generated at 2022-06-21 10:25:06.420936
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    import io, tokenize
    stream = io.StringIO("<<EOF>>")
    generator = tokenize.generate_tokens(stream.readline)
    p = ParserGenerator(generator, "foo.txt")
    p.gettoken()
    assert p.type == token.ENDMARKER
    assert p.value == "<<EOF>>"
    with pytest.raises(SyntaxError):
        p.gettoken()

# Generated at 2022-06-21 10:25:15.958363
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    test_cases = [
        # (filename: str, pattern: str, expected)
        ("tiny.py", "r'\\'", ""),
        ("tiny.py", "r'\\\\'", ""),
    ]
    for filename, pattern, expected in test_cases:
        parser = ParserGenerator()
        with open(filename) as fp:
            a, z = parser.parse_line(pattern, fp)
            assert a is not None
            assert z is not None
            parser.dump_nfa(pattern, a, z)
        print("%s %s -> %s ok" % (filename, repr(pattern), repr(expected)))


# Generated at 2022-06-21 10:25:29.155869
# Unit test for method __eq__ of class DFAState
def test_DFAState___eq__():
    import sys
    s1 = DFAState({"one": 1, "two": 1}, "two")
    s2 = DFAState({"one": 1, "two": 1}, "two")
    s3 = DFAState({"one": 1, "two": 1}, "one")
    s4 = DFAState({"one": 1, "two": 1}, "two")
    s5 = DFAState({"one": 1, "two": 1}, "two")
    s5.arcs["label"] = s5
    s6 = DFAState({"one": 1, "two": 1}, "two")
    s6.arcs["label"] = s6
    s7 = DFAState({"one": 1, "two": 1}, "two")
    s7.arcs["label"] = s8 = DFA

# Generated at 2022-06-21 10:25:32.256065
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    """Test method parse_alt of ParserGenerator.

    Test cases:

    >>> pg = ParserGenerator()
    >>> pg.parse_alt()
    Traceback (most recent call last):
    ...
    SyntaxError: expected (...), got 3/''

    """
    pg = ParserGenerator()
    pg.parse_alt()
# Unit tests for class ParserGenerator

# Generated at 2022-06-21 10:25:40.599127
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    import unittest
    from test.test_grammar import TestParserByGrammar
    from test.support import captured_stdout

    # re-use TestParserByGrammar
    class TestParserByGenerator(TestParserByGrammar, unittest.TestCase):
        def setUp(self):
            super().setUp()
            self.pg = ParserGenerator(self.grammar, self.symbols)

        # override method _test_grammar, to test _add_dfa_rules
        def _test_grammar(self, start_symbol, test_tokens, expected_grammar):
            """The base test case to test the generated grammar."""

            # use a new grammar, since this grammar should not be used by other tests

# Generated at 2022-06-21 10:25:45.885384
# Unit test for function generate_grammar
def test_generate_grammar():
    p = ParserGenerator("/Users/mliang/Documents/GitHub/Nabbit/grammar.txt")
    g = p.make_grammar()
    assert g.intokens.keys() == set(range(len(g.tokens) + 1))
    print("ALL TESTS PASSED")


# Generated at 2022-06-21 10:25:48.698564
# Unit test for constructor of class DFAState
def test_DFAState():
    final = NFAState()
    dfa = DFAState({final: 1}, final)
    assert dfa.isfinal
    assert dfa.arcs == {}
    assert dfa.nfaset == {final: 1}



# Generated at 2022-06-21 10:25:56.735721
# Unit test for constructor of class DFAState
def test_DFAState():
    nfas1: Dict[NFAState, Any] = dict([(NFAState(), 1)])
    ds1 = DFAState(nfas1, nfas1.keys())
    ds2 = DFAState(nfas1, nfas1.keys())
    assert ds1 == ds2
    ds3 = DFAState(nfas1, NFAState())
    assert ds1 != ds3


# Generated at 2022-06-21 10:26:02.903468
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    from . import parser as py_parser
    parser = py_parser.ParserGenerator(py_parser.grammar)
    parser.addfirstsets()
    dfas, startsymbol = parser.make_pgen_grammar()
    parser.dump_nfa('test', dfas['expr_stmt'][0], dfas['expr_stmt'][1])


# Generated at 2022-06-21 10:26:14.510702
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    obj = ParserGenerator()
    obj.type = 1
    obj.value = "Value"
    obj.begin = (1, 2)
    obj.end = (3, 4)
    obj.line = "Line"
    # Method signature expected: (type: int, value: Optional[Any]=None) -> Any
    assert obj.expect(obj.type, obj.value) == obj.value
    obj.type = 1
    obj.value = "Value"
    obj.begin = (1, 2)
    obj.end = (3, 4)
    obj.line = "Line"
    try:
        obj.expect(obj.type)
    except AssertionError as e:
        assert str(e) == "expected 1/None, got 1/Value"
    obj.type = 1

# Generated at 2022-06-21 10:27:25.207672
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    """

    >>> import tokenize
    >>> p = ParserGenerator()
    >>> p.filename = "tokenize.py"
    >>> p.line = b'# Comment'
    >>> p.gettoken = lambda : None
    >>> try: p.raise_error('%s %s %s %s %s', 1, 2, 3, 4, 5)
    ... except SyntaxError as e:
    ...   print(e.msg)
    ...   print(e.filename)
    ...   print(e.lineno)
    ...   print(e.offset)
    ...   print(e.text)
    1 2 3 4 5
    tokenize.py
    1
    0
    # Comment
    """



# Generated at 2022-06-21 10:27:36.050550
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    from . import pgen2

    pg = pgen2.ParserGenerator()

    pg.add_dfa(
        name="expr_stmt",
        start=0,
        end=5,
        arcs=(
            (0, 1, None),
            (1, 2, "testlist_star_expr"),
            (2, 3, "="),
            (3, 4, "testlist"),
            (4, 5, "\n"),
        ),
    )
    pg.add_dfa(
        name="testlist_star_expr",
        start=0,
        end=2,
        arcs=((0, 1, "test"), (0, 1, "star_expr"), (1, 2, "testlist_star_expr_cont")),
    )

# Generated at 2022-06-21 10:27:43.609964
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    pg = ParserGenerator()
    print(pg)
# End unit test

if __name__ == "__main__":
    import sys

    pg = ParserGenerator()
    pg.set_grammar(sys.argv[1], sys.stdin.read())
    c = pg.make_pgen_grammar()
    with open(sys.argv[2], "wb") as f:
        c.save(f)

# Generated at 2022-06-21 10:27:54.822353
# Unit test for method simplify_dfa of class ParserGenerator

# Generated at 2022-06-21 10:28:01.030683
# Unit test for method addarc of class DFAState
def test_DFAState_addarc():
    a = DFAState({}, None)
    b = DFAState({}, None)
    print(a.arcs)
    print(b.arcs)
    a.addarc(b)
    print(a.arcs)
    print(b.arcs)

test_DFAState_addarc()

# Unit tests for method unifystate of class DFAState

# Generated at 2022-06-21 10:28:08.605467
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    g = ParserGenerator()
    input = """\
# rules for a silly expression evaluator
expr: term ('+' expr | '-' expr |)
term: factor ('*' term | '/' term |)
factor: '(' expr ')' | NAME | NUMBER
"""
    g.parse_grammar(input)
    g.addfirstsets()
    g.make_nfa()
    g.make_dfa()
    g.simplify_dfa()



# Generated at 2022-06-21 10:28:20.616683
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    pg = ParserGenerator()
    a, z = pg.parse_atom()
    assert a.arcs == []
    assert z.arcs == []
    a, z = pg.parse_atom()
    assert a.arcs == []
    assert z.arcs == []
    pg.gettoken()
    a, z = pg.parse_atom()
    assert a.arcs == []
    assert z.arcs == []
    pg.gettoken()
    a, z = pg.parse_atom()
    assert a.arcs == []
    assert z.arcs == []
    pg.gettoken()
    a, z = pg.parse_atom()
    assert a.arcs == []
    assert z.arcs == []
    pg.gettoken()

# Generated at 2022-06-21 10:28:30.999548
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():
    a = DFAState(dict(a=1), None)
    b = DFAState(dict(b=1), None)
    c = DFAState(dict(c=1), None)
    d = DFAState(dict(d=1), None)
    a.addarc(b, c)
    a.addarc(c)
    a.addarc(d, c)
    a.unifystate(b, c)
    assert a.arcs == {None: c, c: c}
    a.unifystate(c, d)
    assert a.arcs == {None: d, c: d}


if __name__ == "__main__":
    from writing import write_tables

    dfa, startsymb = make_lexer_dfa()

# Generated at 2022-06-21 10:28:37.771393
# Unit test for constructor of class NFAState
def test_NFAState():
    ng = NFAState()
    nf = NFAState()
    ng.addarc(nf, label=None)
    assert ng.arcs == [(None, nf)]
    ng.addarc(nf, label='    ')
    assert ng.arcs == [(None, nf), ('    ', nf)]
    ng.addarc(nf, label='x')
    assert ng.arcs == [(None, nf), ('    ', nf), ('x', nf)]


# Generated at 2022-06-21 10:28:49.915473
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    from _ast import Load, Store, Add, Sub, Div, Mult
    from _ast import Num, Tuple, Name, List, Subscript, Index, BinOp, UnaryOp
    from _ast import USub, UAdd, Invert, Not, LShift, RShift, BitOr, BitXor, BitAnd, MatMult
    from _ast import AugAssign, Print, Exec, Yield
    from _ast import Expr, Module, FunctionDef, Return, Pass, Global, Import, ImportFrom
    from _ast import If, While, For, And, Or, Not, Compare, Call, IfExp, Dict, Attribute

    pg = ParserGenerator()
    pg.add_rule("expr", ["expr", "+", "expr"], lambda x, y, z: BinOp(x, Add(), z))