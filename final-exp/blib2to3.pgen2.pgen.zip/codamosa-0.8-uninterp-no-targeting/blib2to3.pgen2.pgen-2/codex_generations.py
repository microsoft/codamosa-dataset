

# Generated at 2022-06-21 10:22:06.550989
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    dfas = {
        "s": [
            DFAState(
                {NFAState(None): 1},
                NFAState({(None, NFAState()): 1}),
            ),
            DFAState(
                {NFAState({(None, NFAState()): 1}): 1}, False
            ),
            DFAState(
                {NFAState(None): 1}, False
            ),
        ],
    }
    pg = ParserGenerator()
    pg.simplify_dfa(dfas["s"])
    expected = [
        DFAState(
            {NFAState(None): 1},
            NFAState({(None, NFAState()): 1}),
        ),
    ]
    assert dfas["s"] == expected

# Generated at 2022-06-21 10:22:11.752459
# Unit test for function generate_grammar
def test_generate_grammar():
    class Tests:
        def test_calcfirst(self):
            p = ParserGenerator("Grammar.txt")
            p.calcfirst('decorator')
            assert p.first['decorator'] == {'@':1}

    tests = Tests()
    tests.test_calcfirst()

# Generated at 2022-06-21 10:22:14.689932
# Unit test for method addarc of class NFAState
def test_NFAState_addarc():
    nfa = NFAState()
    nfa.addarc(42, 3.14)
    assert nfa.arcs == [(3.14, 42)]

# Generated at 2022-06-21 10:22:19.691566
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    pg = ParserGenerator()
    pg.gettoken = _gettoken
    pg.raise_error = _raise_error
    pg.return_none = _return_none
    assert pg.parse_item() == (None, None)
    del pg


# Generated at 2022-06-21 10:22:27.699804
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    # XXX This is a hack, there must be a better way to do this.  I
    # think there should be a function in tokenize that just gives
    # generators of tokens given an input string.
    fobj = io.StringIO(" \t\n" + "1" + " \t\n")
    tup = next(tokenize.generate_tokens(fobj.readline))
    assert tup == (tokenize.NUMBER, "1", (2, 0), (2, 1), "\n1 \t\n"), tup
    assert next(tokenize.generate_tokens(fobj.readline)) == (tokenize.ENDMARKER, "", (3, 0), (3, 0), "")
    gen = ParserGenerator().generator
    tup = next(gen)

# Generated at 2022-06-21 10:22:40.416305
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    gen = ParserGenerator()
    gen.gettoken = lambda: None
    gen.value = None
    gen.begin = (0, 0)
    gen.end = (0, 0)
    gen.line = ''
    gen.filename = '<string>'
    gen.grammar = {}  # Dict[str, "GrammarRule"]
    gen.first = {}  # Dict[str, Dict[str, int]]
    gen.dfas = {}  # Dict[str, List["DFAState"]]
    gen.states = []  # List[Dict[Any, List["DFAState"]]]
    gen.start = 0  # int
    gen.labels = []  # List[Tuple[int, Optional[str]]]
    gen.tokens: Dict[int, int]

# Generated at 2022-06-21 10:22:49.021713
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    py = """
if 1:
    xxx = 123

# comment
if 1:
    yyy = 456

if 1:
    zzz = 789
"""
    pr = ParserGenerator(py.split("\n"))
    pr.make_grammar()
    assert pr.dfas["yyy"][0].arcs == {("if", None): pr.dfas["yyy"][1]}
    assert pr.dfas["yyy"][1].arcs == {("1", None): pr.dfas["yyy"][2]}
    assert pr.dfas["yyy"][2].arcs == {(":", None): pr.dfas["yyy"][3]}

# Generated at 2022-06-21 10:22:58.655700
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    pg = ParserGenerator()
    pg.filename = "test"
    pg.type = token.NAME
    pg.value = "foo"
    pg.begin = (0, 0)
    pg.end = (0, 0)
    pg.line = ""
    a, b = pg.parse_alt()
    assert len(a.arcs) == 1
    assert a.arcs[0][0] == "foo"
    assert a.arcs[0][1] is b
    assert len(b.arcs) == 0

# Generated at 2022-06-21 10:23:08.349691
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():
    alphabets = ["a", "b", "c"]
    states = [DFAState({}, None) for _ in range(5)]
    start, Z0, Z1, Z2, Z3 = states
    start.addarc(Z0, "a")
    start.addarc(Z1, "b")
    start.addarc(Z2, "c")
    Z0.addarc(Z3, "a")
    Z3.addarc(Z3, "c")
    Z1.addarc(Z2, "b")
    Z2.addarc(Z0, "c")

# Generated at 2022-06-21 10:23:10.537925
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    pg = ParserGenerator()
    with pytest.raises(SyntaxError):
        pg.raise_error("a message")

# Generated at 2022-06-21 10:24:13.923705
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    class FakeGenerator:
        def __init__(self, type_: int, value: Any) -> None:
            self.type = type_
            self.value = value

    pg = ParserGenerator(FakeGenerator(token.NAME, "foo"))
    assert pg.expect(token.NAME) == "foo"
    assert pg.expect(token.NAME) == "foo"

##     pg = ParserGenerator(FakeGenerator(token.NAME, "bar"))
##     try:
##         pg.expect(token.NAME, "foo")
##     except SyntaxError:
##         pass
##     else:
##         assert False, 'expected SyntaxError, but didn\'t get one'



# Generated at 2022-06-21 10:24:18.291755
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    from . import parser
    pg = parser.ParserGenerator()
    pg.addline("expr: expr '+' expr | expr '*' expr | '(' expr ')' | NAME")
    pg.addline("     | '-' expr %prec UMINUS")
    pg.addline("     | NUMBER")
    pg.addline("")
    pg.addline("func: NAME '(' [expr (',' expr)*] ')'")
    pg.addline("")
    pg.addline("stmt: if_stmt | while_stmt | assign_stmt")
    pg.addline("")
    pg.addline("if_stmt: 'if' expr ':' suite")
    pg.addline("")

# Generated at 2022-06-21 10:24:30.856041
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    import os, sys
    assert os.path.basename(sys.argv[0]) == "pgen2.py", sys.argv[0]
    srcdir = os.path.dirname(os.path.abspath(sys.argv[0]))
    with open(os.path.join(srcdir, "Grammar.txt"), "r") as f:
        pg = ParserGenerator()
        pg.driver(f, "Grammar.txt")
        grammar = pg.make_grammar(converter=GrammarConverter)
        assert isinstance(grammar, pgen2.grammar.Grammar)
        assert grammar.start == grammar.symbol2number["file_input"]
        # XXX Need to add more tests here



# Generated at 2022-06-21 10:24:34.386698
# Unit test for method addarc of class DFAState
def test_DFAState_addarc():
    s1 = DFAState({}, NFAState())
    s2 = DFAState({}, NFAState())
    s1.addarc(s2, label='a')
    s1.addarc(s2, label='b')

# Generated at 2022-06-21 10:24:46.863708
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    # Make sure make_dfa works correctly
    # Test case: non-empty, non-left-recursive grammar

    pgen = ParserGenerator()
    a1 = pgen.make_nfastate()
    z1 = pgen.make_nfastate()
    a1.addarc(z1, "a")
    b1 = pgen.make_nfastate()
    z1.addarc(b1)
    z1.addarc(z1)

    # This should produce two DFA states, even after simplification
    dfa = pgen.make_dfa(a1, z1)
    pgen.simplify_dfa(dfa)
    assert len(dfa) == 2

    assert dfa[0].isfinal


# Generated at 2022-06-21 10:24:49.210957
# Unit test for constructor of class DFAState
def test_DFAState():
    b = DFAState({}, None)
    assert b.nfaset == {}
    assert b.isfinal is False
    assert b.arcs == {}

# Generated at 2022-06-21 10:25:01.960915
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    p = ParserGenerator()
    p.filename = "test_selector"

# Generated at 2022-06-21 10:25:10.724382
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    parser = ParserGenerator()
    parser.generator = iter(
        [
            (tokenize.NAME, "a", (0, 0), (0, 0), ""),
            (tokenize.NAME, "b", (0, 0), (0, 0), ""),
            (tokenize.NAME, "c", (0, 0), (0, 0), ""),
            (tokenize.NAME, "d", (0, 0), (0, 0), ""),
            (tokenize.NAME, "e", (0, 0), (0, 0), ""),
            (tokenize.NAME, "f", (0, 0), (0, 0), ""),
            (tokenize.NAME, "g", (0, 0), (0, 0), ""),
        ]
    )
    parser.gettoken()

# Generated at 2022-06-21 10:25:23.142101
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    import test.test_tokenize
    test_tokenize.fixTestCase(__name__)
    from test.test_tokenize import TokenTests
    from test.test_tokenize import INDENT, DEDENT, NL, COMMENT, NAME, NUMBER, OP
    
    test_tokenize.fixTestCase(__name__)
    from test.test_tokenize import TokenTests
    from test.test_tokenize import INDENT, DEDENT, NL, COMMENT, NAME, NUMBER, OP
    
    pg = ParserGenerator()
    pg.addproduction("file_input", [("stmt", 1, None)])
    pg.addproduction("stmt", [("simple_stmt", 0, None)])
    pg.addproduction("stmt", [("compound_stmt", 0, None)])

# Generated at 2022-06-21 10:25:32.623550
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    class Mock:
        type = token.NAME
        value = "x"
        begin = (1, 2)
        end = (1, 3)
        line = "line"

        def raise_error(self, msg, *args):
            assert msg == "expected %s/%s, got %s/%s"
            assert args[0] == token.OP
            assert args[1] == "="
            assert args[2] == token.NAME
            assert args[3] == "x"

    m = Mock()
    m.expect(token.OP, "=")



# Generated at 2022-06-21 10:26:17.754851
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    pg = ParserGenerator()
    pg.make_first(None, 'value')


# Generated at 2022-06-21 10:26:23.782389
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    # Test with string as label
    p = ParserGenerator()
    p.make_label = lambda c, label: label
    p.labels = []
    p.symbol2number = {'loops': 0}
    p.symbol2label = {'loops': None}
    p.tokens = {token.NAME: 0, token.WHILE: 1}
    p.keywords = {'while': 0}
    # Test that the method doesn't crash, and that the value it returns
    # is a dictionary
    retval = p.make_first(p, 'loops')
    assert isinstance(retval, dict)



# Generated at 2022-06-21 10:26:25.611847
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label(): # TODO
    pass # TODO



# Generated at 2022-06-21 10:26:36.563212
# Unit test for method __eq__ of class DFAState
def test_DFAState___eq__():
    nfa1 = NFAState()
    nfa2 = NFAState()
    nfa3 = NFAState()
    dfa1 = DFAState({nfa1: 1, nfa2: 1}, nfa3)
    dfa2 = DFAState({nfa1: 1, nfa2: 1}, nfa3)

    dfa3 = DFAState({nfa1: 1, nfa2: 1, nfa3: 1}, nfa3)
    dfa4 = DFAState({nfa1: 1, nfa2: 1, nfa3: 1}, nfa3)
    dfa5 = DFAState({nfa1: 1, nfa2: 1, nfa3: 2}, nfa3)


# Generated at 2022-06-21 10:26:41.353692
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    def ohno(msg: str, *args: Any) -> NoReturn:
        raise AssertionError("ohno called")
    pg = ParserGenerator("")
    pg.raise_error = ohno
    pg.filename = "filename"
    pg.end = (1, 2)
    pg.gettoken()
    assert pg.type == 0
    pg.raise_error("%s/%s", token.NAME, "foo")  # No crash
    try:
        pg.raise_error("%s/%s", token.NAME, "foo") # no crash
    except SyntaxError as e:
        _, _, _, line = e.args[0]
        assert line == 'expected NAME/foo, got ENDMARKER/'
    pg.value = "value"

# Generated at 2022-06-21 10:26:44.067301
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    pg = ParserGenerator()
    pg.first = {"foo": None}
    pg.dfas = {"foo": ["dfa", "state", "set"]}
    pg.addfirstsets()
    assert pg.first == {"foo": {"dfa", "state", "set"}}
    pg.first["foo"] = None
    pg.addfirstsets()
    # pass



# Generated at 2022-06-21 10:26:44.999218
# Unit test for constructor of class NFAState
def test_NFAState():
    s = NFAState()
    assert len(s.arcs) == 0


# Generated at 2022-06-21 10:26:56.323015
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    def _test_parse(data: str, start: str) -> None:
        parser = ParserGenerator()
        tree = parser.parse(data)
        assert start == tree.start

# Generated at 2022-06-21 10:27:08.032596
# Unit test for method dump_nfa of class ParserGenerator

# Generated at 2022-06-21 10:27:09.994022
# Unit test for constructor of class NFAState
def test_NFAState():
    s = NFAState()
    assert len(s.arcs) == 0


# Generated at 2022-06-21 10:28:02.653659
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    pg = ParserGenerator()
    pg.addfirstsets()
    try:
        pg.calcfirst("parse_stmt")
    except ValueError:
        pass
    else:
        assert False, "recursion not detected"



# Generated at 2022-06-21 10:28:11.465718
# Unit test for method make_first of class ParserGenerator

# Generated at 2022-06-21 10:28:23.878083
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    import io

    gen = ParserGenerator()
    gen.add_rhs("foo", "bar baz")
    gen.add_rhs("foo", "txt1 txt2")
    gen.add_rhs("bar", "txt3")
    gen.add_rhs("baz", "txt4")
    gen.set_startsymbol("foo")
    gen.make_grammar()
    with io.StringIO() as f:
        gen.dump_grammar(f)
        dumped = f.getvalue()

# Generated at 2022-06-21 10:28:34.380069
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    pg = ParserGenerator()
    nfa = [
        NFAState(),
        NFAState(),
        NFAState(),
        NFAState(),
        NFAState(),
        NFAState(),
    ]
    pg.dump_nfa("test", nfa[0], nfa[1])
    nfa[0].addarc(nfa[1], '"a"')
    nfa[1].addarc(nfa[1], '"b"')
    nfa[1].addarc(nfa[2])
    nfa[1].addarc(nfa[3])
    nfa[2].addarc(nfa[4], '"c"')
    nfa[3].addarc(nfa[4], '"d"')

# Generated at 2022-06-21 10:28:42.199014
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    from . import pgen2

    p = pgen2.ParserGenerator()

    a, z = p.parse_rhs()
    assert a is z, "got %s, %s" % (a, z)

    a, z = p.parse_rhs()
    assert a is z, "got %s, %s" % (a, z)

    p.first += ["and"]
    a, z = p.parse_rhs()
    assert a is z, "got %s, %s" % (a, z)

    p.first += ["or"]
    a, z = p.parse_rhs()
    assert a is not z, "got %s, %s" % (a, z)
    assert len(a.arcs) == 2

# Generated at 2022-06-21 10:28:52.398521
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    # check that the *set* of states in a DFA is simplified
    pgen = ParserGenerator()
    pgen.dfas["name"] = [
        pgen.make_dfa_state({"A": 1}),
        pgen.make_dfa_state({"A": 1, "C": 1}),
        pgen.make_dfa_state({"C": 1}),
        pgen.make_dfa_state({"B": 1}),
    ]
    pgen.simplify_dfa(pgen.dfas["name"])
    assert len(pgen.dfas["name"]) == 3

# Generated at 2022-06-21 10:29:02.712065
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    dfa = [
        DFAState({"A0": 1}, None),
        DFAState({"A0": 1, "A1": 1}, None),
        DFAState({"A0": 1, "A1": 1}, None),
        DFAState({"A0": 1, "A2": 1}, None),
        DFAState({"A0": 1, "A3": 1}, None),
    ]
    dfa[0].addarc(dfa[2], "go")
    dfa[1].addarc(dfa[2], "go")
    dfa[2].addarc(dfa[1], "stop")
    dfa[2].addarc(dfa[3], "go")
    dfa[3].addarc(dfa[2], "go")

# Generated at 2022-06-21 10:29:06.637277
# Unit test for method addarc of class DFAState
def test_DFAState_addarc():
    s = DFAState({}, NFAState())  # empty state
    s.nfaset = {NFAState()}
    s.addarc(s)
    assert s.arcs == {None: s}


# Generated at 2022-06-21 10:29:17.723903
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    a = NFAState()
    b = NFAState()
    c = NFAState()
    d = NFAState()
    e = NFAState()
    a.addarc(b, "a")
    a.addarc(c, "b")
    b.addarc(a, "c")
    b.addarc(e, None)
    c.addarc(b, "d")
    d.addarc(e, None)
    e.addarc(c, "e")
    begin = a
    end = e
    dfa = ParserGenerator().make_dfa(begin, end)
    assert len(dfa) == 5
    dfa = ParserGenerator().make_dfa(begin, end)
    dfa = ParserGenerator().make_dfa(begin, end)


# Generated at 2022-06-21 10:29:21.542618
# Unit test for constructor of class NFAState
def test_NFAState():
    s = NFAState()
    assert isinstance(s, NFAState)
    assert isinstance(s.arcs, list)
    assert not s.arcs

