

# Generated at 2022-06-21 10:21:59.741335
# Unit test for method __eq__ of class DFAState
def test_DFAState___eq__():
    # This method cannot be unit tested by its own,
    # because of a reference to the class DFAState in the body.
    pass



# Generated at 2022-06-21 10:22:04.595569
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():  # TODO: Delete this function?
    # Simple test case
    pgen = ParserGenerator()
    a, z = pgen.parse_atom()
    assert isinstance(a, NFAState)
    assert isinstance(z, NFAState)
    assert a.arcs == []
    assert z.arcs == []
    assert a != z

# Generated at 2022-06-21 10:22:06.650414
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    import io
    import sys
    import tokenize
    import unittest


# Generated at 2022-06-21 10:22:16.060920
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    pg = ParserGenerator()
    pg.filename = "file name"
    pg.end = (2, 3)
    pg.line = "line text"
    class e(Exception):
        pass
    try:
        pg.raise_error('%s %s', 'error', 'text')
        raise e
    except SyntaxError as got:
        res = str(got)
    except e:
        res = ""
    assert 'SyntaxError: error text in file "file name", line 2' == res
    try:
        pg.raise_error('%s %s %s %s %s %s', 'error', 'text')
        raise e
    except SyntaxError as got:
        res = str(got)
    except e:
        res = ""

# Generated at 2022-06-21 10:22:22.978287
# Unit test for method __eq__ of class DFAState
def test_DFAState___eq__():
    import random as r
    from collections import defaultdict
    from itertools import product
    from unittest import TestCase
    from typing import Any, Dict, Tuple

    class DFAStateEqTest(TestCase):
        def test(self) -> None:
            dfa: Dict[Tuple[bool, Dict[Any, Any]], Tuple[int, int]] = defaultdict(lambda: (0,0))
            repeats = 0
            for state_i in range(10):
                nfaset_i = {(i,): 1}
                for state_j in range(state_i + 1, 20):
                    nfaset_j = {(i, j): 1 for i, j in product(range(4), range(5))}

# Generated at 2022-06-21 10:22:28.994773
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    _pg = ParserGenerator(_dfas, _startsymbol)
    for name in list(_pg.dfas.keys()):
        _pg.calcfirst(name)
    _pg.addfirstsets()
    assert _pg.first == {
        'stmt': {'expr': 1, 'if_stmt': 1}, 'if_stmt': {'if': 1}, 'suite': {'NEWLINE': 1,
                                                                          'simple_stmt': 1},
        'simple_stmt': {'NAME': 1}, 'expr_stmt': {'expr': 1}, 'expr': {'expr': 1,
                                                                      'factor': 1}, 'factor':
        {'NAME': 1}}

# Generated at 2022-06-21 10:22:41.386736
# Unit test for constructor of class DFAState
def test_DFAState():
    nfaset1 = {NFAState():1, NFAState():1, NFAState():1}
    nfaset2 = {NFAState():1, NFAState():1}
    final = NFAState()
    dfa = DFAState(nfaset1, final)
    assert not dfa.isfinal
    dfa = DFAState(nfaset2, final)
    assert dfa.isfinal == True  # noqa: E712
    # Another unit test for constructor of class DFAState
    nfaset3 = {NFAState():1, NFAState():1, NFAState():1}
    nfaset4 = {NFAState():1, NFAState():1}
    final1 = NFAState()
    final2 = NFAState()
    dfa1

# Generated at 2022-06-21 10:22:43.972437
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    pgen = ParserGenerator()
    # print_parser(pgen.grammar, pgen.converter.states, pgen.startsymbol)


# Generated at 2022-06-21 10:22:50.993477
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    # Test with a very simple grammar that uses both "null
    # transitions" and lookahead; the latter tests for null
    # transitions in recursive parts of the grammar.
    pg = ParserGenerator()
    pg.addrule("s", ["a"])
    pg.addrule("s", ["b"])
    pg.addrule("a", ["a", "c"])
    pg.addrule("b", ["d", "b"])
    pg.addrule("b", [""])
    pg.addrule("c", [""])
    pg.addrule("d", [""])
    # Test the null transitions first

# Generated at 2022-06-21 10:23:01.521882
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    a = ParserGenerator()
    a.dfas = {}
    a.first = {}
    a.calcfirst("x")
    assert a.first["x"] == {"x": 1}, a.first["x"]
    a.calcfirst("y")
    assert a.first["y"] == {"y": 1}, a.first["y"]
    a.calcfirst("x2")
    assert a.first["x2"] == {"x": 1}, a.first["x2"]
    a.calcfirst("y2")
    assert a.first["y2"] == {"y": 1}, a.first["y2"]
    a.calcfirst("x3")
    assert a.first["x3"] == {"x": 1}, a.first["x3"]
    a.calcfirst("y3")


# Generated at 2022-06-21 10:23:26.990501
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    pg = ParserGenerator()
    pg.filename = "<string>"
    pg.line = "a = 1\n"
    pg.generator = tokenize.generate_tokens(iter((pg.line + "\n").encode("utf-8")).__next__)
    nfa, finish = pg.parse_item()
    assert finish is nfa
    nfa, finish = pg.parse_item()
    assert finish is nfa


# Generated at 2022-06-21 10:23:35.110624
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    import io
    import sys
    import tokenize
    # For testing, grammar is defined as a string with embedded newlines

# Generated at 2022-06-21 10:23:47.286266
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    # pytype: disable=attribute-error
    p = ParserGenerator()
    p.dfas = {"S": [DFAState({}, None), DFAState({}, None)], "A": []}
    p.dfas["S"][0].addarc(p.dfas["A"], "a")
    p.addfirstsets()
    assert p.first["S"] == {"a": 1}
    assert p.first["A"] == {}

    p = ParserGenerator()
    p.dfas = {"S": [DFAState({}, None), DFAState({}, None)], "A": []}
    p.dfas["S"][0].addarc(p.dfas["S"], "a")
    p.addfirstsets()
    assert p.first["S"] is None

    p = Parser

# Generated at 2022-06-21 10:23:52.601815
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    obj = ParserGenerator()
    a: 'NFAState' = NFAState()
    z: 'NFAState' = NFAState()
    a.addarc(z, '"hi"')
    obj.line = "hi"
    obj.type = token.STRING
    obj.value = '"hi"'
    actual = obj.parse_item()
    assert actual == (a, z)

# Generated at 2022-06-21 10:24:05.173906
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    import io
    import tokenize
    parsergen = ParserGenerator()
    parsergen.set_filename("test_ParserGenerator_parse_atom")
    parsergen.set_input(io.StringIO("( x )"))
    parsergen.gettoken()
    assert parsergen.type == token.OP, "type must be OP"
    assert parsergen.value == "(", "value must be ("
    a, z = parsergen.parse_atom()
    assert a is not None, "a must not be None"
    assert z is not None, "z must not be None"
    assert len(a.arcs) == 1, "a must have 1 arc"
    assert a.arcs[0][0] == "x", "arc must be labeled x"

# Generated at 2022-06-21 10:24:15.536112
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    from test.test_tokenize import tokenize, untokenize
    from test import support
    import io

    pg = ParserGenerator()
    pg.setup()

    tokenizer = tokenize(io.BytesIO(b"\n").readline)
    pg.generator = iter(tokenizer)

    pg.gettoken()
    pg.expect(token.NEWLINE)

    tokenizer = tokenize(io.BytesIO(b"a\n").readline)
    pg.generator = iter(tokenizer)

    pg.gettoken()
    pg.expect(token.NAME, "a")

    tokenizer = tokenize(io.BytesIO(b"a\n").readline)
    pg.generator = iter(tokenizer)

    pg.gettoken()

# Generated at 2022-06-21 10:24:24.769676
# Unit test for method addarc of class NFAState
def test_NFAState_addarc():
    nfa1 = NFAState()
    nfa2 = NFAState()
    nfa3 = NFAState()
    assert nfa1.arcs == []
    nfa1.addarc(nfa2, "A")
    assert nfa1.arcs == [("A",nfa2)]
    nfa1.addarc(nfa3, "B")
    assert nfa1.arcs == [("A",nfa2),("B",nfa3)]
    nfa1.addarc(nfa2, "C")
    assert nfa1.arcs == [("A",nfa2),("B",nfa3),("C",nfa2)]


# Generated at 2022-06-21 10:24:31.624583
# Unit test for method addarc of class NFAState
def test_NFAState_addarc():
    state = NFAState()
    next1 = NFAState()
    state.addarc(next1, 'a')
    next2 = NFAState()
    state.addarc(next2)
    assert len(state.arcs) == 2
    assert state.arcs[0] == ('a', next1)
    assert state.arcs[1] == (None, next2)

# Module helper function to print NFAState instances

# Generated at 2022-06-21 10:24:40.165864
# Unit test for method __eq__ of class DFAState
def test_DFAState___eq__():
    ns0_0 = NFAState()
    ns0_1 = NFAState()
    ns1_0 = NFAState()
    ns1_1 = NFAState()
    ns2_0 = NFAState()
    ns2_1 = NFAState()
    for i in range(2):
        for j in range(2):
            for k in range(2):
                isfinal = i or j or k
                nfaset = {ns0_0: 1, ns1_0: 1, ns2_0: 1}
                if i:
                    nfaset[ns0_1] = 1
                if j:
                    nfaset[ns1_1] = 1
                if k:
                    nfaset[ns2_1] = 1

# Generated at 2022-06-21 10:24:52.042206
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    global obj

# Generated at 2022-06-21 10:25:39.809541
# Unit test for method __eq__ of class DFAState
def test_DFAState___eq__():
    import io
    import unittest

    class DFAState___eq___Tests(unittest.TestCase):
        nfa_state1 = NFAState()
        nfa_state2 = NFAState()
        nfa_state3 = NFAState()

        def test___eq__(self):
            dfa_state1 = DFAState({self.nfa_state1: 1}, self.nfa_state2)
            dfa_state2 = DFAState({}, self.nfa_state3)
            self.assertFalse(dfa_state1 == dfa_state2)
            dfa_state2 = DFAState({self.nfa_state1: 1}, self.nfa_state2)
            self.assertTrue(dfa_state1 == dfa_state2)
            dfa_state

# Generated at 2022-06-21 10:25:48.131705
# Unit test for constructor of class DFAState
def test_DFAState():
    dfa = {}  # type: Dict[NFAState, DFAState]

    def makeDFAState(nfaset, final):
        key = frozenset(nfaset)
        if key in dfa:
            if final in nfaset != dfa[key].isfinal:
                raise ValueError("inconsistent value for isfinal")
            return dfa[key]
        else:
            result = DFAState(nfaset, final)
            assert dfa.setdefault(key, result) is result
            return result

    start = NFAState()
    final = NFAState()
    start.addarc(final)
    dfa[start, final] = makeDFAState({start}, final)
    dfa[start, start] = makeDFAState({start}, start)
   

# Generated at 2022-06-21 10:25:52.046036
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    pgen = ParserGenerator()
    pgen.type = token.NAME
    pgen.value = '"module"'
    pgen.expect(token.NAME, '"module"')
    #
    with pytest.raises(SyntaxError):
        pgen.expect(token.OP, ':')

# Generated at 2022-06-21 10:26:01.358993
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    source = """
        a: b? c
        b: 'b'
        c: 'c'
        """
    parser = ParserGenerator(source)
    try:
        parser.parse()
    except SyntaxError as err:
        assert err.args[0] == "expected (NAME | STRING), got OP /?", (
            err.args[0],
            "expected (NAME | STRING), got OP /?",
        )
    else:
        assert False, "Should have raised SyntaxError, got nothing"



# Generated at 2022-06-21 10:26:03.267504
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    pgen = ParserGenerator()
    assert repr(pgen) == "<ParserGenerator instance>"



# Generated at 2022-06-21 10:26:14.845293
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    """Test method make_first of class ParserGenerator."""
    pg = ParserGenerator()

    class C:
        pass

    c = C()
    c.labels: List[Tuple[int, Text]] = []
    c.keywords = {}
    c.tokens = {}
    c.symbol2label = {}

# Generated at 2022-06-21 10:26:22.076011
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    pg = ParserGenerator(None)

# Generated at 2022-06-21 10:26:29.788079
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    pg = ParserGenerator()
    pg.dfas = {"A": [FakeDFAState([("a", FakeDFAState("<1>")), ("B", FakeDFAState("<2>"))])], "B": [FakeDFAState([("c", FakeDFAState("<3>"))])]}
    pg.calcfirst("A")
    assert pg.first["A"] == {"a": 1, "c": 1}


# Generated at 2022-06-21 10:26:33.638758
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    import tokenize
    pg = ParserGenerator(None, (tokenize.NL, ''), None, None)
    pg.gettoken()
    pg.type
    pg.value
    pg.begin
    pg.end
    pg.line



# Generated at 2022-06-21 10:26:41.711527
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    pg = ParserGenerator()
    pg.first.clear()
    pg.calcfirst("r")
    assert pg.first["r"] == {"'a'": 1, "'b'": 1}
    pg.calcfirst("s")
    assert pg.first["s"] == {"'a'": 1, "'c'": 1}
    pg.calcfirst("t")
    assert pg.first["t"] == {"'b'": 1, "'c'": 1}
    pg.calcfirst("v")
    assert pg.first["v"] == {"'a'": 1, "'d'": 1}
    pg.calcfirst("w")
    assert pg.first["w"] == {"'d'": 1}

# Generated at 2022-06-21 10:28:24.980569
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    g = ParserGenerator(StringIO(GrammarStr))
    g.calcfirst('expr')

# Generated at 2022-06-21 10:28:31.795846
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    pg = ParserGenerator()
    dfa = [
        DFAState({NFAState(): 1, NFAState(): 1}, None),
        DFAState({NFAState(): 1}, None),
        DFAState({NFAState(): 1, NFAState(): 1}, None),
    ]
    dfa[0].addarc(dfa[1], '1')
    dfa[0].addarc(dfa[2], '2')
    pg.dump_dfa('name', dfa)


# Generated at 2022-06-21 10:28:39.549420
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    # Test that NL, COMMENT and ENDMARKER are ignored
    import io
    import tokenize
    for s in ["", "\n", "#comment\n", "#comment\n#comment", "#comment\n\n"]:
        g = ParserGenerator()
        g.filename = ""
        g.generator = tokenize.generate_tokens(io.BytesIO(s.encode("utf-8")).readline)
        g.gettoken()
        assert g.type == token.ENDMARKER
        assert g.value == ""
        assert g.begin == (0, 0)
        assert g.line == ""


# Generated at 2022-06-21 10:28:44.466874
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():
    a = DFAState({}, NFAState())
    b = DFAState({}, NFAState())
    a.addarc(b)
    c = DFAState({}, NFAState())
    a.addarc(c)
    a.unifystate(b, c)
    assert a.arcs == {"": c, None: c}



# Generated at 2022-06-21 10:28:56.810568
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    pg = ParserGenerator()
    pg.type = token.NAME
    pg.value = 'some_name'
    pg.begin = (1, 2)
    pg.end = (3, 4)
    pg.line = 'line contents'
    from io import StringIO
    from tokenize import generate_tokens
    s = StringIO('   \n   \n')
    g = generate_tokens(s.readline)
    pg.generator = g
    # Test expected functionality
    pg.gettoken()
    assert pg.type == tokenize.NL
    assert pg.value == '\n'
    pg.gettoken()
    assert pg.type == tokenize.NL
    assert pg.value == '\n'
    # Test error handling
    #
    # This block of code is commented out because

# Generated at 2022-06-21 10:29:05.152267
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    pg = ParserGenerator()
    # Simplest possible RHS: just a name
    pg.gettoken = lambda: None  # type: ignore
    pg.value = "foo"
    pg.type = token.NAME
    a, z = pg.parse_rhs()
    assert repr(a) == repr(NFAState(arcs=[("foo", NFAState())]))
    assert repr(z) == repr(NFAState())
    assert a.arcs == [(("foo", NFAState()),)]
    # Slightly more complex RHS: two names
    pg.gettoken = lambda: None  # type: ignore
    pg.value = "foo"
    pg.type = token.NAME
    a, z = pg.parse_rhs()

# Generated at 2022-06-21 10:29:08.602743
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    parser_gen = ParserGenerator()
    with open(__file__) as f:
        parser_gen.parse_grammar(f.read())



# Generated at 2022-06-21 10:29:14.358634
# Unit test for constructor of class DFAState
def test_DFAState():
    a, b, c, d = map(NFAState, "abcd")
    dfa = DFAState({a: 1, b: 2, c: 3}, a)
    assert dfa.nfaset == {a: 1, b: 2, c: 3}
    assert dfa.isfinal is True
    assert dfa.arcs == {}


# Generated at 2022-06-21 10:29:18.482809
# Unit test for constructor of class NFAState
def test_NFAState():
    from typing import NoReturn
    from lib2to3 import pygram

    class TestState(NFAState):
        def test_init(self) -> NoReturn:
            self.arcs = [(None, 1), (None, 2), ("ab", 3)]

    state = TestState()
    assert state.arcs == [(None, 1), (None, 2), ("ab", 3)]



# Generated at 2022-06-21 10:29:29.474208
# Unit test for method addarc of class DFAState
def test_DFAState_addarc():
    # Create a trivial NFA with two states, the second of which is the
    # final state
    final = NFAState()
    a = NFAState()
    a.addarc(final)
    # Create the corresponding DFA
    assert a.arcs == [(None, final)]
    assert final.arcs == []
    d = DFAState({a: 1, final: 1}, final)
    assert d.arcs == {}
    assert d.isfinal
    # Add a loop on the DFA
    aa = DFAState({a: 1}, final)
    assert aa.arcs == {}
    assert aa.isfinal
    aa.addarc(aa, "a")
    assert aa.arcs == {"a": aa}
    assert aa.isfinal
