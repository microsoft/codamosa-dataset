

# Generated at 2022-06-21 10:22:16.095543
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    import unittest

    class Test(unittest.TestCase):
        def test(self):
            parser = ParserGenerator()
            parser.generator = iter([(2, "b"), (4, "c")])
            parser.gettoken()
            parser.expect(4, "c")

    unittest.main()

# Generated at 2022-06-21 10:22:23.008542
# Unit test for function generate_grammar
def test_generate_grammar():
    p = ParserGenerator(filename="Grammar.txt")

# Generated at 2022-06-21 10:22:33.299215
# Unit test for constructor of class DFAState
def test_DFAState():
    a = NFAState()
    b = NFAState()
    c = NFAState()
    d = NFAState()
    a.addarc(b, "1")
    a.addarc(c, "1")
    a.addarc(b, "2")
    b.addarc(d, None)
    c.addarc(d, None)
    c.addarc(a, None)

    dfa = Parser("").make_dfa(a, d)
    Parser("").simplify_dfa(dfa)
    # Parser("").dump_dfa("blah", dfa)
    dfa_map: Dict[DFAState, int] = {}
    for i, state in enumerate(dfa):
        dfa_map[state] = i


# Generated at 2022-06-21 10:22:44.642641
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    pg = ParserGenerator()

    # test case 1:
    pg.type = token.NAME
    pg.value = "NAME"
    pg.generator = iter([(
        token.NAME, "add_operator", (1, 0), (1, 11), "add_operator : '+' '+' | '-' '-'\n"
    )])
    result = pg.parse_rhs()
    assert result == (pg.pg_vocabulary["add_operator"].nfa_start, pg.pg_vocabulary["add_operator"].nfa_finish)
    # result = (NFAState, NFAState)
    
    # test case 2:
    pg.type = token.NEWLINE
    pg.value = "\n"

# Generated at 2022-06-21 10:22:47.916226
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():
    f = NFAState()
    g = NFAState()
    h = NFAState()
    a = DFAState({f:1, g:1}, h)
    b = DFAState({g:1, h:1}, f)
    c = DFAState({f:1}, g)
    a.addarc(b, "b")
    a.addarc(c, "c")
    a.unifystate(b, c)
    assert a.arcs == {"b": c, "c": c}
    assert b.arcs == {}
    assert c.arcs == {}



# Generated at 2022-06-21 10:22:50.325334
# Unit test for method addarc of class DFAState
def test_DFAState_addarc():
    state_a = DFAState({}, None)
    state_b = DFAState({}, None)
    state_a.addarc(state_b, 'a')
    assert state_a.arcs['a'] is state_b
    with pytest.raises(AssertionError):
        state_a.addarc(state_b, 'a')


# Generated at 2022-06-21 10:23:01.921042
# Unit test for method addarc of class DFAState
def test_DFAState_addarc():
    state1 = DFAState(dict(), NFAState())
    nfastate1 = NFAState()
    nfastate2 = NFAState()
    state2 = DFAState(dict(), nfastate1)
    state1.addarc(state2, "label")
    assert state1.arcs == {"label": state2}
    state1.addarc(state2, "label")
    assert state1.arcs == {"label": state2}
    state3 = DFAState(dict(), nfastate1)
    state1.addarc(state3, "label")
    assert state1.arcs == {"label": state2}
    state1.addarc(state3, "label2")
    assert state1.arcs == {"label": state2, "label2": state3}

# Generated at 2022-06-21 10:23:10.962967
# Unit test for function generate_grammar
def test_generate_grammar():
    # Test all the things we care about
    g = generate_grammar()
    assert g.start["file_input"] == 0
    # ast.Module is the root of the AST
    assert g.dfas["file_input"][0].isfinal

    # The first node in production 'testlist_star_expr' is a Node
    # named 'test'
    assert g.labels[g.dfas["testlist_star_expr"][0].arcs["test"].isfinal][0] \
        == "test"
    assert g.labels[g.dfas["atom"][0].arcs["("].isfinal][0] == "trailer"

# Generated at 2022-06-21 10:23:24.253360
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    p = ParserGenerator()

# Generated at 2022-06-21 10:23:34.369821
# Unit test for constructor of class DFAState
def test_DFAState():
    nfa_a = NFAState()
    nfa_b = NFAState()
    nfa_c = NFAState()
    dfa_a = DFAState({nfa_a : 1, nfa_b : 1}, nfa_a)
    dfa_b = DFAState({nfa_b : 1, nfa_c : 1}, nfa_c)
    assert dfa_a != dfa_b
    assert dfa_a != "abc"
    dfa_b = DFAState({nfa_a : 1, nfa_b : 1}, nfa_a)
    assert dfa_a == dfa_b
    dfa_b = DFAState({nfa_a : 1, nfa_b : 1, nfa_c : 1}, nfa_a)
    assert dfa

# Generated at 2022-06-21 10:24:02.061517
# Unit test for method addarc of class NFAState
def test_NFAState_addarc():
    nfa = NFAState()
    nfa.addarc(nfa, 'label')
    nfa.addarc(nfa)


# Generated at 2022-06-21 10:24:05.500764
# Unit test for method addarc of class NFAState
def test_NFAState_addarc():
    nfas = NFAState()
    nfas2 = NFAState()
    nfas.addarc(nfas2,'label')
    assert nfas.arcs == [(nfas2, 'label')]


# Generated at 2022-06-21 10:24:15.765390
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    pg = ParserGenerator()

# Generated at 2022-06-21 10:24:26.852156
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    import re

    s = ParserGenerator()
    s.make_dfas(
        r"""
        S = r'a+' | 'b'
        T = r'a+' | 'b' 'b' | 'a'
        """
    )
    s.addfirstsets()
    assert s.first["S"].keys() == {"a", "b"}
    assert s.first["T"].keys() == {"a", "b"}
    assert "ab" not in re.compile("|".join(sorted(s.first["S"]))).match("ab")
    assert "ab" not in re.compile("|".join(sorted(s.first["T"]))).match("ab")
    s = ParserGenerator()

# Generated at 2022-06-21 10:24:28.055151
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    pass # Stub


# Generated at 2022-06-21 10:24:36.209351
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    f = io.StringIO("expr: term ( '+' term)*\nterm: NAME\n")
    pg = ParserGenerator()
    pg.parse_file(f)
    dfa = pg.dfas["expr"]
    pg.simplify_dfa(dfa)
    assert len(dfa) == 3
    assert dfa[0].arcs == {'NAME': 1}
    assert dfa[1].arcs == {'+': 2, None: 2}
    assert dfa[2].arcs == {'NAME': 1}
    return



# Generated at 2022-06-21 10:24:37.513230
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    pgm = PgenGrammar()



# Generated at 2022-06-21 10:24:41.281422
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():
    f = DFAState({}, NFAState())
    g = DFAState({}, NFAState())
    h = DFAState({}, NFAState())
    f.addarc(g, "l1")
    f.addarc(h, "l2")
    f.unifystate(g, h)
    assert f.arcs == {"l1": h, "l2": h}

# Generated at 2022-06-21 10:24:52.728666
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    import ast
    import sys
    from _ast import ast
    from _ast import parse
    from token import tok_name
    from . import grammar


# Generated at 2022-06-21 10:25:03.863960
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    nfa = ParserGenerator()
    nfa.gettoken()
    nfa.add_token()
    nfa.gettoken()
    nfa.add_token()
    nfa.gettoken()
    nfa.add_token()
    nfa.gettoken()
    nfa.add_token()
    nfa.gettoken()
    nfa.add_token()
    nfa.gettoken()
    nfa.add_token()
    nfa.gettoken()
    nfa.add_token()
    nfa.insert_empty()
    nfa.insert_empty()
    nfa.insert_empty()
    nfa.insert_empty()
    nfa.insert_empty()
    nfa.insert_empty()
    nfa.insert_empty()
    nfa.insert_empty

# Generated at 2022-06-21 10:25:37.317823
# Unit test for method addarc of class DFAState
def test_DFAState_addarc():
    a = DFAState({}, None)
    b = DFAState({}, None)
    a.addarc(b, "a")
    assert a.arcs == {"a": b}
    assert b.arcs == {}
test_DFAState_addarc()

# Generated at 2022-06-21 10:25:38.882643
# Unit test for constructor of class NFAState
def test_NFAState():
    ns = NFAState()
    ns.addarc(ns, 'b')


# Generated at 2022-06-21 10:25:49.804606
# Unit test for method make_dfa of class ParserGenerator

# Generated at 2022-06-21 10:25:54.058977
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    p = ParserGenerator().parse
    with tempfile.TemporaryDirectory() as tmpdir:
        fn = os.path.join(tmpdir, "pgen.py")

# Generated at 2022-06-21 10:26:02.766961
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():
    a = DFAState({}, None)
    b = DFAState({}, None)
    c = DFAState({}, None)
    a.addarc(b, "abcd")
    a.addarc(c, "efgh")
    a.unifystate(b, c)
    assert a.arcs["abcd"] is c
    assert a.arcs["efgh"] is c


# A state of the DFA, which is a set of NFA states
DFAState = DFAState  # for type checking



# Generated at 2022-06-21 10:26:14.424910
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    # Simple test
    pg = ParserGenerator()
    pg.add_nonterminal("file_input", "stmt* ENDMARKER")
    pg.add_nonterminal("stmt", "'print' test")
    pg.add_nonterminal("test", "or_test")
    pg.add_nonterminal("or_test", "and_test ('or' and_test)*")
    pg.add_nonterminal("and_test", "not_test ('and' not_test)*")
    pg.add_nonterminal("not_test", "('not' not_test | comparison)")
    pg.add_nonterminal("comparison", "expr (comp_op expr)*")

# Generated at 2022-06-21 10:26:18.593053
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    pg = ParserGenerator()

    with open("test_ParserGenerator.txt") as file:
        pg.add_module("test", file.read())
    pg.build()

    for symbol in pg.symbol2label:
        print(symbol, pg.symbol2label[symbol])


if __name__ == "__main__":
    test_ParserGenerator()

# Generated at 2022-06-21 10:26:27.300682
# Unit test for constructor of class DFAState
def test_DFAState():
    # fmt: off
    s = NFAState()
    s.addarc(s)
    t = NFAState()
    t.addarc(t)
    t.addarc(s)
    assert NFAState() != NFAState()
    assert NFAState() != s
    assert s != t
    assert s != NFAState()
    assert s != s
    assert t != s
    assert t != t

    x = DFAState({s: 1}, t)
    y = DFAState({s: 1}, t)
    assert x == y
    assert not (x != y)
    assert NFAState() != x

    x.addarc(x, "a")
    x.addarc(y, "b")
    x.addarc(y, "c")

# Generated at 2022-06-21 10:26:33.686248
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():
    A = DFAState({}, None)
    B = DFAState({}, None)
    C = DFAState({}, None)
    A.addarc(B, "first")
    A.addarc(C, "second")
    A.unifystate(B, C)
    assert A.arcs["first"] is C
    assert A.arcs["second"] is C

# Generated at 2022-06-21 10:26:36.894684
# Unit test for constructor of class DFAState
def test_DFAState():
    a1 = NFAState()
    a2 = NFAState()
    a3 = NFAState()
    a = DFAState({a1: 1}, a3)
    b = DFAState({a1: 1}, a3)
    c = DFAState({a2: 1}, a3)
    d = DFAState({a1: 1}, a2)
    assert a == b
    assert a != c
    assert a != d



# Generated at 2022-06-21 10:27:58.689009
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    g = ParserGenerator("data/graminit.txt", "<string>")

    # Create a dummy converter
    class DummyConverter:
        symbol2number = {
            "atom": 1,
            "test": 2,
            "suite": 3,
            "expr": 4,
            "expr_stmt": 5,
        }
        symbol2label = {}
        tokens = {
            token.NAME: 1,
            token.NEWLINE: 2,
        }
        keywords = {}
        labels = []

    converter = DummyConverter()
    # Add first sets for symbols to the ParserGenerator object

# Generated at 2022-06-21 10:28:09.787870
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    import io
    import os
    import sys
    import token
    import tokenize
    import unittest

    from . import pgen2
    from . import token

    from test.support import run_unittest


    TESTFN = "pg_test_grammar.txt"

    def conv(s: str) -> bytes:
        return s.encode("utf-8")


    def detokenize(tokens: Sequence[Tuple[int, Text]]) -> Text:
        result = []
        tok_name = token.tok_name
        INDENT = token.INDENT
        DEDENT = token.DEDENT
        NEWLINE = token.NEWLINE
        ENDMARKER = token.ENDMARKER

# Generated at 2022-06-21 10:28:13.288270
# Unit test for constructor of class DFAState
def test_DFAState():
    a = NFAState()
    b = NFAState()
    c = NFAState()
    a.addarc(b)
    b.addarc(b)
    b.addarc(c)
    d = DFAState({a: 1, b: 1, c: 1}, c)
    assert d.nfaset == {a: 1, b: 1, c: 1}
    assert d.isfinal
    assert d.arcs == {None: b}



# Generated at 2022-06-21 10:28:15.741878
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    pg = ParserGenerator()
    assert pg.dfas == {}
    # pg.dump()


# Generated at 2022-06-21 10:28:27.168494
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():
    # (a) --> (b) --> (c)
    #      |------------->
    # We want to unify (a) and (c).  The arcs variable in (b) is
    # { label: (a), label: (c) }, so it should become { label: (c) }
    # after the unification.
    class Dummy(DFAState):
        def __init__(self, nfaset: Dict[NFAState, Any], final: NFAState) -> None:
            super().__init__(nfaset, final)
            self.arcs = {label: [self, next] for label, next in self.arcs.items()}

    a = Dummy({}, None)
    b = Dummy({}, None)
    c = Dummy({}, None)

# Generated at 2022-06-21 10:28:28.976728
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    pg = PgenGrammar()
    assert type(pg) is PgenGrammar



# Generated at 2022-06-21 10:28:39.225570
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    pg = ParserGenerator()
    assert pg.convert(
        """
        %start S

        S: A "B"
          | [A] "B"
          | "C"

        A: "D"
          | "E"

        B: "F"
          | "G"
          | "H"
          | "I"
    """,
        "<string>",
    )


# Dump out the DFA tables as a set of tables for use by the parser
# module.  The DFA for a rule such as this:
#
#   expr: expr + term | expr - term | term
#
# Might look like this:
#
# expr ::=
#   (<expr> '+' <term>               # add
#   | <expr> '-' <term>               # subtract
#   |

# Generated at 2022-06-21 10:28:48.798802
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    # Create a ParserGenerator instance
    parser = ParserGenerator()
    # Check that the ParserGenerator instance has the attribute type
    assert hasattr(parser, "type")
    # Check that the ParserGenerator instance has the attribute value
    assert hasattr(parser, "value")
    # Check that the ParserGenerator instance has the attribute begin
    assert hasattr(parser, "begin")
    # Check that the ParserGenerator instance has the attribute end
    assert hasattr(parser, "end")
    # Check that the ParserGenerator instance has the attribute line
    assert hasattr(parser, "line")


# Generated at 2022-06-21 10:28:50.064372
# Unit test for function generate_grammar
def test_generate_grammar():
    p = ParserGenerator("Grammar.txt")
    assert p.make_grammar()



# Generated at 2022-06-21 10:28:54.008423
# Unit test for constructor of class NFAState
def test_NFAState():
    state_1 = NFAState()
    state_2 = NFAState()
    label: Optional[str] = None
    state_1.addarc(state_2, label)
    assert state_1.arcs == [(None, state_2)]
