

# Generated at 2022-06-21 10:22:38.743283
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    pgen = ParserGenerator(grammar)

    def expect_first(name, set):
        assert set == pgen.first[name].keys()

    expect_first("atom", "(' [ ( NAME NUMBER STRING ')".split())
    expect_first("trailer", "[ ( '.' ')".split())
    expect_first("power", "(' [ ( ~ - NAME NUMBER STRING ')".split())



# Generated at 2022-06-21 10:22:40.427610
# Unit test for constructor of class NFAState
def test_NFAState():
    # Make sure that adding an arc to an NFAState actually works.
    a = NFAState()
    assert len(a.arcs) == 0
    b = NFAState()
    a.addarc(b)
    assert len(a.arcs) == 1



# Generated at 2022-06-21 10:22:45.372550
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    import io
    import unittest


# Generated at 2022-06-21 10:22:50.178552
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    c = PgenGrammar()
    assert c.make_label(c, "NAME") == 0
    assert c.make_label(c, "LPAR") == 1
    assert c.make_label(c, "foo") == 2
    assert c.make_label(c, "foo") == 2
    assert c.make_label(c, "bar") == 3
    assert c.labels == [(token.NAME, None),
                        (token.LPAR, None), (2, None), (3, None)]


# Generated at 2022-06-21 10:23:01.454279
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    pg = ParserGenerator()
    dfa, start = pg.parse()
    print(dfa, start)
    print(pg.first)

if __name__ == "__main__":
    test_ParserGenerator_parse()

# End of parser.py

# Grammar for Python parser
#
#  See https://docs.python.org/3.4/reference/grammar.html for a description
#  of the Python grammar.
#
#  NOTE: Parsing Python is not an easy task, especially if you want to
#        produce a fast parser.  In my experience, the best solution is to
#        build a two-stage parser using regular expressions to generate
#        tokens and then a recursive descent parser to do the actual
#        parsing.  The code below is an attempt to produce a single-stage
#        parser using

# Generated at 2022-06-21 10:23:10.620149
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    from . import tokenize
    from .token import token

    g = tokenize.generate_tokens(io.StringIO("x = 3\n").readline)
    next(g)

    pg = ParserGenerator()
    pg.generator = g
    pg.gettoken()
    assert pg.type == token.NAME
    assert pg.value == "x"
    assert pg.begin == (0, 0)
    assert pg.end == (0, 1)
    assert pg.line == "x = 3\n"

    pg.gettoken()
    assert pg.type == token.OP
    assert pg.value == "="
    assert pg.begin == (0, 2)
    assert pg.end == (0, 3)
    assert pg.line == "x = 3\n"

    pg.gettoken

# Generated at 2022-06-21 10:23:24.030213
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    import unittest
    import copyreg as copy_reg
    import pickle
    import sys

    class TestParserGenerator(unittest.TestCase):
        # Unittest cases for method expect of class ParserGenerator
        def setUp(self):
            self.pg = ParserGenerator()
            def _pickle(self):
                return self.__class__, ()
            copy_reg.pickle(ParserGenerator, _pickle)
        def check_expect_same(self, type, value, got_type, got_value, got_begin, got_end,
                              got_line):
            self.assertEqual(type, got_type)
            self.assertEqual(value, got_value)
            self.assertEqual(self.pg.begin, got_begin)

# Generated at 2022-06-21 10:23:24.801718
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    assert PgenGrammar()


# Generated at 2022-06-21 10:23:33.661331
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    pgen = ParserGenerator(
        """
        s: [a]+
        a: 'a'
        """
    )
    collected = []
    original_dump_dfa = pgen.dump_dfa
    def patched_dump_dfa(self, name, dfa):
        original_dump_dfa(name, dfa)
        collected.append((name, dfa))
    pgen.dump_dfa = patched_dump_dfa
    assert pgen.dfas
    assert collected
    assert len(collected) == 2
    assert collected[0][0] == "s"
    assert collected[1][0] == "a"

# Generated at 2022-06-21 10:23:45.999273
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    class DummyConverter:
        def __init__(self):
            self.tokens = {}
            self.keywords = {}
            self.dfas = {}
            self.symbol2number = {}
            self.symbol2label = {}
            self.labels = []
    c = DummyConverter()
    p = ParserGenerator()
    p.make_label(c, "NAME")
    assert c.labels == [(token.NAME, None)]
    p.make_label(c, "NUMBER")
    assert c.labels == [(token.NAME, None), (token.NUMBER, None)]
    p.make_label(c, "STRING")
    assert c.labels == [(token.NAME, None), (token.NUMBER, None), (token.STRING, None)]

# Generated at 2022-06-21 10:24:37.933039
# Unit test for constructor of class DFAState
def test_DFAState():
    a = DFAState({}, None)
    b = DFAState({}, None)
    c = DFAState({}, None)
    a.addarc(b, "label")
    assert set(a.arcs) == {"label"}
    assert a.arcs["label"] is b
    assert a == DFAState({}, None)
    assert a != b
    assert a == DFAState({}, None)
    b.addarc(c, "label")
    assert a != b
    assert b.arcs["label"] is c
    b.unifystate(c, a)
    assert b.arcs["label"] is a
    b.unifystate(a, c)
    assert b.arcs["label"] is c



# Generated at 2022-06-21 10:24:50.148369
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    class MockDict(dict):
        def __init__(self):
            pass
    class MockObj(object):
        def __init__(self):
            self.__dict__ = {}
    def test_expect_tokenize_file():
        def test_expect_tokenize_file_():
            class MockC(object):
                def __init__(self):
                    self.name = 'test_expect_tokenize_file_'
            test_expect_tokenize_file_ = MockC()

# Generated at 2022-06-21 10:24:51.779477
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    pg = ParserGenerator()
    pg.dfas = {}
    pg.addfirstsets()


# Generated at 2022-06-21 10:24:54.475578
# Unit test for constructor of class NFAState
def test_NFAState():
    s = NFAState()
    s.addarc(NFAState(), "a")
    s.addarc(NFAState())



# Generated at 2022-06-21 10:25:04.966599
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    p = ParserGenerator()
    p.filename = "<test>"
    p.line = "abc def"
    p.generator = tokenize.generate_tokens(p.getline)
    try:
        p.gettoken()
        t = p.parse_item()
        print(t)
        # p.gettoken()
        # t = p.parse_item()
        # print t
    except SyntaxError as e:
        print(e)
        print(e.args)
        print(e.args[0])
        print(e.args[1])
        print(e.args[2])
        print(e.args[3])
        print(repr(e.args))
        print(repr(e.args[0]))

# Generated at 2022-06-21 10:25:12.850003
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    from _testcapi import IS_PY3
    pg = ParserGenerator()
    input = '"hi there"\n'
    if IS_PY3:
        input = input.encode("utf-8")
    pg.tokengen = tokenize.generate_tokens(io.StringIO(input).readline)
    assert pg.gettoken() == (token.STRING, '"hi there"')
    pg.gettoken()
    assert pg.value == '\n'
    assert pg.type == token.NEWLINE
    pg.gettoken()
    assert pg.value == ''
    assert pg.type == token.ENDMARKER

# Generated at 2022-06-21 10:25:18.245144
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    pg = ParserGenerator()
    dfa = [
        DFAState({"hello": 1, "world": 1}, True),
        DFAState({"world": 1, "world": 1}, True),
    ]
    pg.dump_dfa("xxx", dfa)



# Generated at 2022-06-21 10:25:21.364011
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    gen = ParserGenerator("")
    rr = gen.parse_alt()
    assert 0, "unimplemented"

# Generated at 2022-06-21 10:25:33.644568
# Unit test for method __eq__ of class DFAState
def test_DFAState___eq__():
    a = DFAState({}, None)
    b = DFAState({}, None)
    assert a == b

    class Foo:
        pass

    a = DFAState({}, Foo())
    b = DFAState({}, Foo())
    assert a == b

    a = DFAState({}, None)
    a.addarc(a, "")
    b = DFAState({}, None)
    b.addarc(b, "")
    assert a == b

    a = DFAState({}, None)
    c = DFAState({}, None)
    a.addarc(a, "")
    a.addarc(c, "")
    b = DFAState({}, None)
    d = DFAState({}, None)
    b.addarc(d, "")

# Generated at 2022-06-21 10:25:41.489035
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    lines = [
        "def p_module(p):",
        "    '''",
        "    module ::= (stmt NEWLINE)*",
        "    '''",
        "    if len(p) > 2:",
        "        p[0] = ast.Stmt(p, lineno=p[2].lineno)",
        "    else:",
        "        p[0] = ast.Stmt(p)",
    ]
    f = StringIO("\n".join(lines))
    pg = ParserGenerator(f)
    dfa = pg.parse_rhs()
    print(dfa)

# Class representing a state in a nondeterministic finite automaton (NFA)
# NOTE: This class is not used by parser.py. It's only used by the code in pgen.py.


# Generated at 2022-06-21 10:27:27.241300
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    # This test is not used as a unit test, but rather just to show how
    # dump_dfa can be used.  The output of this function is hardwired
    # into the test_marshal module.
    import sys
    import os
    from . import token
    from . import grammar
    from . import pygram

    def get_parser():
        # Build a parser from the grammar module
        pgen = ParserGenerator(pygram.python_grammar_no_print_statement)
        pgen.parse_grammar()
        return pgen.make_pgen_grammar()

    pgen = get_parser()
    c = Converter(pgen)
    g = c.convert()

    def dump_dfa(name: Text, dfa: Sequence["DFAState"]) -> None:
        global d

# Generated at 2022-06-21 10:27:38.564756
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    assert PgenParser.parse_atom('1') == (1)
    assert PgenParser.parse_atom('-1') == (-1)
    assert PgenParser.parse_atom('1+2') == (1+2)
    assert PgenParser.parse_atom('1 + 2') == (1 + 2)
    assert PgenParser.parse_atom('1+2+3') == (1+2+3)
    assert PgenParser.parse_atom('1 + 2 + 3') == (1 + 2 + 3)
    assert PgenParser.parse_atom('x') == (x)
    assert PgenParser.parse_atom('x + 1') == (x + 1)
    assert PgenParser.parse_atom('1 + x') == (1 + x)

# Generated at 2022-06-21 10:27:42.448314
# Unit test for method addarc of class DFAState
def test_DFAState_addarc():
    a = DFAState({}, None)
    b = DFAState({}, None)
    a.addarc(b, "abc")
    assert a.arcs == {"abc": b}



# Generated at 2022-06-21 10:27:50.894474
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    import pyclbr
    pg = ParserGenerator([])
    f = StringIO()
    pg.make_grammar(f)

    # Verify that f is valid Python code by loading the generated grammar,
    # passing it to compile() and executing the compiled code.
    ns = {}
    code = compile(f.getvalue(), "<grammar>", "exec")
    exec(code, ns)

    # Verify that the grammar has the correct class structure.
    # Verify that there are no generated functions that are not properly
    # attributes of a generated class.
    cls: Dict[Text, Any] = pyclbr.readmodule("_generated_grammar", [])
    for name in cls:
        cls = cls[name]
        break
    cls: Dict[Text, Any]
    assert cls, cl

# Generated at 2022-06-21 10:27:51.907202
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    PgenGrammar()



# Generated at 2022-06-21 10:28:04.818560
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    p = ParserGenerator()
    p.init_dfas({}, "single")
    a = p.new_nfa_state()
    b = p.new_nfa_state()
    c = p.new_nfa_state()
    d = p.new_nfa_state()
    e = p.new_nfa_state()
    # a: NAME -> b
    # b: NAME -> c
    # c: NAME -> b
    # d: NAME -> e
    # e: NAME -> d
    a.addarc(b, 'NAME')
    b.addarc(c, 'NAME')
    c.addarc(b, 'NAME')
    d.addarc(e, 'NAME')
    e.addarc(d, 'NAME')
    captured_output = io.StringIO()
   

# Generated at 2022-06-21 10:28:17.070591
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    import unittest
    import unittest.mock

    from .parser import ParserGenerator

    class MockTokenizer:
        def __init__(self, iterable):
            self._iterable = iterable
            self._iterator = iter(iterable)

        def __iter__(self):
            return self._iterator

    class Test(unittest.TestCase):
        def test_basic(self):
            pg = ParserGenerator("test", ("A", "B"))
            iterable = (
                ("NAME", "A", (1, 0), (1, 1), "A"),
                ("OP", "|", (2, 3), (2, 4), " | "),
                ("NAME", "B", (2, 7), (2, 8), "B"),
            )

# Generated at 2022-06-21 10:28:19.737198
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    pg = ParserGenerator()
    try:
        pg.raise_error("error message")
    except SyntaxError:
        pass

# Generated at 2022-06-21 10:28:21.178736
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    PG = PgenGrammar()

# Unit tests for constructor of class Grammar

# Generated at 2022-06-21 10:28:31.701221
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    p = ParserGenerator([])
    msg = 'testing %s for "%s"'
    e1 = SyntaxError(
        msg,
        ("test_pgen.py", 5, 10, "test_raise_error"),
    )
    e2 = SyntaxError(
        msg % ("A", "B"),
        ("test_pgen.py", 5, 10, "test_raise_error"),
    )
    caught = None
    try:
        p.raise_error(msg, "A", "B")
    except SyntaxError as e:
        caught = e
    assert e1 == caught
    assert e2 == caught
    # Following is a test of the exception message itself.
    caught = None