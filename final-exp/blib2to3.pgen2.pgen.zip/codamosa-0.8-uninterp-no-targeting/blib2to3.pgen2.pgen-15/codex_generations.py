

# Generated at 2022-06-21 10:22:21.522931
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    from . import grammar

    pg = ParserGenerator()
    pg.set_grammar(grammar)
    pg.construct_dfas()

# Some unit tests for the grammar generators



# Generated at 2022-06-21 10:22:23.251049
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    g = PgenGrammar()
    assert isinstance(g, grammar.Grammar)


# Generated at 2022-06-21 10:22:33.759606
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    pg = ParserGenerator()
    pg.add_rule("", [("expr", 1, -1)])
    pg.add_rule("expr", [("expr", 2, -1), ("term", 1, -1)])
    pg.add_rule("expr", [("term", 1, -1)])
    pg.add_rule("term", [("factor", 1, -1)])
    pg.add_rule("factor", [("(", 1, -1), ("expr", 1, -1), (")", 1, -1)])
    pg.add_rule("factor", [("NUMBER", 1, -1)])
    grammar = pg.make_grammar()
    print(grammar)
    # XXX Should be able to make the last rule produce a token.NUMBER, but
    # XXX I can't make that

# Generated at 2022-06-21 10:22:44.992604
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    def check(grammar_source, expected_asms, **kwargs):
        with temp_coding(kwargs.get("encoding", "iso-8859-1")):
            pg = ParserGenerator()
            asms = pg.parse_grammar(grammar_source, "grammar source")
            assert asms == expected_asms
    #

# Generated at 2022-06-21 10:22:51.508507
# Unit test for method make_label of class ParserGenerator

# Generated at 2022-06-21 10:22:55.347950
# Unit test for method addarc of class NFAState
def test_NFAState_addarc():
    S = NFAState
    a = S()
    b = S()
    a.addarc(b)
    assert a.arcs == [(None, b)], a.arcs



# Generated at 2022-06-21 10:23:01.791876
# Unit test for function generate_grammar
def test_generate_grammar():
    grammar = generate_grammar()
    assert isinstance(grammar, PgenGrammar), "generate_grammar() must return PgenGrammar instance"
    assert isinstance(grammar.dfas, dict), "generate_grammar() must return PgenGrammar instance"
    assert isinstance(grammar.labels, list), "generate_grammar() must return PgenGrammar instance"
    assert isinstance(gramram.keywords, dict), "generate_grammar() must return PgenGrammar instance"
    assert isinstance(gramram.start, str), "generate_grammar() must return PgenGrammar instance"
    assert isinstance(gramram.tokens, dict), "generate_grammar() must return PgenGrammar instance"

# Generated at 2022-06-21 10:23:06.002136
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    from io import StringIO

    g = ParserGenerator()

    g.parse_alt(StringIO("a|b"), 0, "", [])
    g.parse_alt(StringIO("a ( | b"), 0, "", [(3, "("), (4, "|"), (6, "b")])


# Generated at 2022-06-21 10:23:09.428238
# Unit test for constructor of class NFAState
def test_NFAState():
    head = NFAState()
    body = NFAState()
    tail = NFAState()
    head.addarc(body)
    body.addarc(tail)
    body.addarc(body)
    head.addarc(tail, 'label')



# Generated at 2022-06-21 10:23:13.562467
# Unit test for method addarc of class DFAState
def test_DFAState_addarc():
    DFAState({}, NFAState()).addarc(DFAState({}, NFAState()), "")


# Generated at 2022-06-21 10:24:03.258957
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    parser = ParserGenerator()
    parser.filename = "<string>"
    parser.line = '# test_ParserGenerator_expect()\n'
    parser.type = token.NUMBER
    parser.value = '42'
    parser.begin = (1, 2)
    parser.end = (1, 5)
    parser.generator = iter([])
    parser.expect(token.NUMBER, '42')
    with pytest.raises(SyntaxError):
        parser.expect(token.NUMBER, '42')

# Generated at 2022-06-21 10:24:13.828030
# Unit test for constructor of class DFAState
def test_DFAState():
    epsilon = NFAState()
    s0 = DFAState({epsilon: 1}, epsilon)
    s1 = DFAState({epsilon: 1}, epsilon)
    s2 = DFAState({epsilon: 1}, epsilon)
    s0.addarc(s1, "a")
    s0.addarc(s1, "b")
    epsilon.addarc(s2)
    s2.addarc(s1, "a")
    s2.addarc(s2, "a")
    s2.addarc(s1, "b")
    s2.addarc(s2, "b")
    assert s0 == s1
    assert hash(s0) == hash(s1)  # Shouldn't crash


# Generated at 2022-06-21 10:24:17.633512
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    # Checks that a new PgenGrammar object created without arguments has
    # empty self.dfas, self.states and self.symbol2label attributes.
    p = PgenGrammar()
    assert p.dfas == []
    assert p.states == []
    assert p.symbol2label == {}



# Generated at 2022-06-21 10:24:19.156559
# Unit test for function generate_grammar
def test_generate_grammar():
    print(generate_grammar())


# This function is used to represent the state of the parser
# and the semantic action code.

# Generated at 2022-06-21 10:24:32.376678
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():
    s0 = DFAState({}, "")
    s1 = DFAState({}, "")
    s2 = DFAState({}, "")
    s0.addarc(s1, "a")
    s1.addarc(s0, "b")
    s3 = DFAState({}, "")
    s0.addarc(s3, "c")
    s0.addarc(s3, "d")
    s0.addarc(s3, "e")
    s0.addarc(s2, "f")
    s0.addarc(s2, "g")
    s3.addarc(s2, "h")
    assert s1.arcs == {"b": s0}

# Generated at 2022-06-21 10:24:40.604907
# Unit test for method __eq__ of class DFAState
def test_DFAState___eq__():
    from . import pgen2 as b_pgen2
    from . import pgen2_gen  # In the same folder as this module.
    from . import token as b_token

    # Test the equality method for DFAState instances.

    class Dummy_b_pgen2(b_pgen2.ParserGenerator):
        def __init__(self) -> None:
            super().__init__([])
            self.dfas = {}  # type: Dict[str, List[DFAState]]


# Generated at 2022-06-21 10:24:49.753737
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    _filename = r"grammar.txt"
    _tokenize_generator = iter([(1, "a", (1, 0), (1, 1), "a"), (0, "", (2, 0), (2, 0), "")])
    _gen = ParserGenerator(_filename, _tokenize_generator)
    with pytest.raises(SyntaxError) as excinfo:
        _gen.raise_error("test_ParserGenerator_raise_error")
    tb = excinfo.traceback



# Generated at 2022-06-21 10:25:02.346873
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    # Skip test if imported by regrtest
    if (
        "regrtest" in sys.modules
        or "pytest" in sys.modules
        or "test" in sys.modules
    ):
        return
    # This test is only relevant if the system Python library
    # has not already parsed and compiled its parser.
    if "parser" in sys.modules:
        return
    # Stub the parser module
    sys.modules["parser"] = type(sys)("parser")
    sys.modules["parser"].__file__ = "parser.py"
    sys.modules["parser"].__path__ = []
    sys.modules["parser"].__package__ = "parser"
    # Create a ParserGenerator instance, and add a test case.
    pg = ParserGenerator()

# Generated at 2022-06-21 10:25:04.273583
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    pg = PgenGrammar()

    assert pg.keywords["NAME"] == (1,)
    assert pg.start == "<start>"



# Generated at 2022-06-21 10:25:12.171055
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    p = ParserGenerator()
    dfa = [
        DFAState({1: 1}, False),
        DFAState({}, True),
        DFAState({2: 2}, False),
        DFAState({}, True),
    ]
    assert dfa[0].arcs == {'a': dfa[1]}
    assert dfa[1].arcs == {}
    assert dfa[2].arcs == {'a': dfa[3]}
    assert dfa[3].arcs == {}
    p.simplify_dfa(dfa)
    assert dfa == [dfa[0]]

    p = ParserGenerator()

# Generated at 2022-06-21 10:26:41.745024
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    p: ParserGenerator = ParserGenerator([])
    dfa = []
    state = NFAState()
    state.arcs = [('a', ','), ('a', "','")]
    state.addarc(state)
    dfa.append(DFAState({state: 1}, state))
    p.symbol2number['expr'] = 0
    p.symbol2number['exprlist'] = 1
    p.symbol2number['exprlist_comma'] = 2
    p.symbol2number[','] = 3
    p.symbol2number['NAME'] = 1
    p.dfas = {
        'expr': dfa,
        'exprlist': dfa,
        'exprlist_comma': dfa,
    }

# Generated at 2022-06-21 10:26:54.611250
# Unit test for constructor of class DFAState
def test_DFAState():
    a = NFAState()
    a.addarc(a)
    b = NFAState()
    b.addarc(a)
    c = NFAState()
    c.addarc(a)
    d = NFAState()
    d.addarc(a)

    st1 = DFAState({a: 1, b: 1}, a)
    st2 = DFAState({a: 1, b: 1}, a)
    st3 = DFAState({a: 1, b: 1, c: 1}, a)
    st4 = DFAState({a: 1, b: 1, c: 1}, a)
    st5 = DFAState({a: 1, b: 1}, c)
    st6 = DFAState({a: 1, b: 1}, c)

# Generated at 2022-06-21 10:27:06.963787
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    import io
    import tokenize

    parser = ParserGenerator()

    def tokenize_lines(
        lines: List[Text],
    ) -> Iterator[Tuple[int, Text, Tuple[int, int], Tuple[int, int], Text]]:
        text = "\n".join(lines)
        source = io.BytesIO(text.encode("utf-8"))
        source.name = "<string>"
        return tokenize.tokenize(source.readline)

    def get_token(
        gen: Iterator[Tuple[int, Text, Tuple[int, int], Tuple[int, int], Text]]
    ) -> None:
        token = next(gen)
        parser.type = token[0]
        parser.value = token[1]
        parser.begin = token[2]
       

# Generated at 2022-06-21 10:27:15.951447
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    class MockGrammar:
        def __init__(self):
            self.dfas = {}
            self.first = {}
            self.startsymbol = ''
    p = ParserGenerator(MockGrammar())
    p.type = token.NAME
    p.value = 'NAME'
    p.gettoken = lambda: None
    assert p.parse_item() == (p.NFAState(0), p.NFAState(1))
    p.type = token.STRING
    p.value = "'a'"
    p.gettoken = lambda: None
    assert p.parse_item() == (p.NFAState(2), p.NFAState(3))
    p.type = token.OP
    p.value = '['
    p.gettoken = lambda: None
    p.parse_

# Generated at 2022-06-21 10:27:27.371978
# Unit test for method __eq__ of class DFAState
def test_DFAState___eq__():
    s = DFAState({}, None)
    assert s == DFAState({}, None)



# Generated at 2022-06-21 10:27:32.960144
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():
    a = DFAState({}, None)
    b = DFAState({}, None)
    a.addarc(a, "a")
    a.addarc(b, "b")
    a.addarc(a, "c")
    b.addarc(a, "d")
    a.unifystate(b, a)
    assert (
        repr(list(sorted(a.arcs.items()))) == "[('a', <DFAState {}>), ('c', <DFAState {}>)]"
    )
    a.unifystate(a, b)
    assert (
        repr(list(sorted(a.arcs.items()))) == "[('a', <DFAState {}>), ('b', <DFAState {}>)]"
    )

# Generated at 2022-06-21 10:27:34.708276
# Unit test for constructor of class DFAState
def test_DFAState():
    a = DFAState({1: 1}, 1)
    other = DFAState({1: 1}, 2)
    never_equal = DFAState({1: 1}, 2)
    assert a != other
    assert other == never_equal

# Generated at 2022-06-21 10:27:46.156408
# Unit test for constructor of class DFAState
def test_DFAState():
    from collections import namedtuple
    from typing import NamedTuple, TypeVar
    T = TypeVar("T")

    def check_dfa_state(
        s: DFAState,
        nfaset: Dict[T, Any],
        isfinal: bool,
        arcs: Dict[Text, T],
    ) -> None:
        assert isinstance(s, DFAState)
        assert isinstance(nfaset, dict)
        assert s.nfaset == nfaset
        assert s.isfinal == isfinal
        assert isinstance(arcs, dict)
        assert s.arcs == arcs

    n1 = NamedTuple("n1", [("a", Any), ("b", Any)])

# Generated at 2022-06-21 10:27:59.015158
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    import unittest
    import doctest
    import sys
    import os
    import io
    import xml.etree.ElementTree as ET

    if ET is None:
        print("XML parsing support not available, skipping test_ParserGenerator_make_dfa.", file=sys.stderr)
        return

    #############################
    ## Doctest for make_dfa() ##
    #############################

# Generated at 2022-06-21 10:28:09.561579
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    class Label(object):
        def __init__(self) -> None:
            self.labels = []
            self.symbol2label = {}
            self.symbol2number = {}
            self.tokens = {}
            self.keywords = {}

    pg = ParserGenerator()
    c = Label()