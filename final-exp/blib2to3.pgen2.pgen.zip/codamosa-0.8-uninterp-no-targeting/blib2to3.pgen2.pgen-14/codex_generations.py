

# Generated at 2022-06-21 10:22:27.303505
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    pg = ParserGenerator()
    assert pg



# Generated at 2022-06-21 10:22:31.864042
# Unit test for function generate_grammar
def test_generate_grammar():
    mod = generate_grammar("test/test_grammar.txt")
    assert mod.make_grammar()


if __name__ == "__main__":
    mod = generate_grammar()
    mod.dump_grammar()

# Generated at 2022-06-21 10:22:42.823774
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    from . import parse
    from . import ast
    from . import grammar
    from . import token
    from . import pgen2
    from . import parse3
    p = parse.Parser()
    g = pgen2.Generator(p.grammar, parse3, grammar.Grammar(grammar.parse_grammar(p.grammar, "Grammar (partial)")))
    g.make_grammar()
    g.init_rules()
    g.expr()
    g.add_str()
    g.add_class()
    g.add_newline()
    g.generate_input()
    c = pgen2.Converter(g.grammar)
    p.make_grammar()
    print('.')

# Generated at 2022-06-21 10:22:45.644580
# Unit test for method addarc of class DFAState
def test_DFAState_addarc():
    dfa = [DFAState({}, None)]
    state = DFAState({}, None)
    dfa[0].addarc(state, 'a')
    assert state in dfa

# Generated at 2022-06-21 10:22:58.422785
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    import pgen2.grammar
    g = pgen2.grammar.Grammar(pgen2.grammar.DEFAULT_GRAMMAR)
    p = ParserGenerator(g)
    p.addfirstsets()
    assert p.first["trailer"]["("] == 1
    assert p.first["testlist"]["*"] == 1
    assert p.first["testlist_gexp"]["*"] == 1
    assert p.first["testlist_gexp"]["*"] == 1
    assert p.first["dictorsetmaker"]["{"] == 1
    assert p.first["dictorsetmaker"]["*"] == 1
    assert p.first["nfargs"]["*"] == 1
    assert p.first["nfargs"]["*"] == 1

# Generated at 2022-06-21 10:23:02.593452
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    filename = os.path.join(os.path.dirname(__file__), "Grammar.txt")
    with open(filename, encoding="utf-8") as f:
        g = ParserGenerator().make_grammar(f)
        assert isinstance(g, PgenGrammar)



# Generated at 2022-06-21 10:23:10.396291
# Unit test for constructor of class NFAState
def test_NFAState():
    a = NFAState()
    b = NFAState()
    assert repr(a.arcs) == "[]"
    a.addarc(b)
    assert repr(a.arcs) == "[(None, <NFAState object at 0x7fb14c01af60>)]"
    a.addarc(b, "A")
    assert repr(a.arcs) == "[(None, <NFAState object at 0x7fb14c01af60>), ('A', <NFAState object at 0x7fb14c01af60>)]"
    assert repr(b.arcs) == "[]"



# Generated at 2022-06-21 10:23:23.984611
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    import re as _re
    import token as _token

    p = ParserGenerator([], [], [])
    assert p.make_label(p, "expr") == 0
    assert p.make_label(p, "NAME") == 1
    assert p.make_label(p, "'x'") == 2
    assert p.make_label(p, "'and'") == 3
    assert p.make_label(p, "variable_stmt") == 0
    assert p.make_label(p, "NAME") == 1
    assert p.make_label(p, "'='") == 4
    assert p.make_label(p, "'and'") == 3
    assert p.make_label(p, "expr") == 0
    assert p.make_label(p, "NAME") == 1
    assert p.make

# Generated at 2022-06-21 10:23:30.773485
# Unit test for method addarc of class DFAState
def test_DFAState_addarc():
    nfa0 = NFAState()
    nfa1 = NFAState()
    nfa2 = NFAState()
    nfa3 = NFAState()
    nfa0.addarc(nfa1, 'a')
    nfa0.addarc(nfa1, 'b')
    nfa0.addarc(nfa2, 'c')
    nfa1.addarc(nfa3, 'd')
    nfa2.addarc(nfa3, 'e')
    nfa3.addarc(nfa3, 'f')
    nfa3.addarc(nfa0, 'g')
    dfa0 = DFAState({nfa0: 1, nfa1: 1, nfa2: 1}, nfa3)

# Generated at 2022-06-21 10:23:34.858250
# Unit test for constructor of class DFAState
def test_DFAState():
    # Test that we can construct a DFAState with a fake NFAState
    # instead of the real thing.
    class FakeNFAState:
        pass

    d = {FakeNFAState(): None}
    final = FakeNFAState()
    s = DFAState(d, final)
    assert s.nfaset == d
    assert s.isfinal == (final in d)


# Local variables:
# mode: python
# End:

# Generated at 2022-06-21 10:24:10.723711
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    import random
    import sys
    import tokenize
    
    sys.setrecursionlimit(1000000)
    
    # Test with random data
    
    for i in range(1000):
        s = ""
        for _ in range(random.randint(5, 30)):
            s += chr(ord('a') + random.randint(0, 25))
        s += ': '
        for _ in range(random.randint(5, 20)):
            if random.random() < 0.2:
                s += chr(ord('a') + random.randint(0, 25))
            elif random.random() < 0.3:
                s += '('

# Generated at 2022-06-21 10:24:19.137201
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    def testit(text, expected):
        pg = ParserGenerator(None)
        pg.gettoken()
        pg.value = text
        pg.type = token.STRING
        a, z = pg.parse_alt()
        print("")
        pg.dump_nfa("nfa", a, z)
        dfa = pg.make_dfa(a, z)
        print("")
        pg.dump_dfa("dfa", dfa)

    testit("a", {"a"})
    testit("a b", {"a", "b"})
    testit("a|b", {"a", "b"})
    testit("a|b|c", {"a", "b", "c"})
    testit("a b|c", {"a", "b", "c"})
    test

# Generated at 2022-06-21 10:24:32.376649
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    pg = ParserGenerator()

# Generated at 2022-06-21 10:24:43.397738
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    p = ParserGenerator("f", TextIOWrapper(BytesIO()))
    class T:
        pass
    t = T()
    t.LINESEP = '''
'''
    p.type = 1
    p.value = "foo"
    p.end = (1, 1)
    p.line = "xxx"

# Generated at 2022-06-21 10:24:49.429145
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    pg = ParserGenerator()
    pg.add_dfa("start", pg.parse_string("(A|B) C"))
    pg.dump_nfa("start", *pg.dfas["start"][0:2])
    pg.dump_dfa("start", pg.dfas["start"])


# Generated at 2022-06-21 10:24:53.155610
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    pg = ParserGenerator()
    a, b = pg.parse_alt()
    assert a == b and a.arcs == []

# Generated at 2022-06-21 10:25:04.142323
# Unit test for function generate_grammar
def test_generate_grammar():
    p = ParserGenerator(StringIO("a: 'a' | 'b'\n"))
    p.make_grammar()
    p = ParserGenerator(StringIO("a: 'a'*\n"))
    p.make_grammar()
    p = ParserGenerator(StringIO("a: 'a'+\n"))
    p.make_grammar()
    p = ParserGenerator(StringIO("a: 'a' 'b'\n"))
    p.make_grammar()
    p = ParserGenerator(StringIO("a: 'a' | 'a' | 'a'\n"))
    p.make_grammar()
    p = ParserGenerator(StringIO("a: 'a' | b\nb: 'a' | 'b'\n"))
    p.make_

# Generated at 2022-06-21 10:25:09.587559
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    # This is a simple example grammar:
    #
    #    a: b   # RHS of a is b          # NB: no newline after :
    #    b: "b" # RHS of b is singleton
    #
    pg = ParserGenerator()
    a = NFAState()
    z = NFAState()
    a.addarc(z, "b")
    assert pg.parse_rhs() == (a, z)



# Generated at 2022-06-21 10:25:12.634539
# Unit test for method addarc of class NFAState
def test_NFAState_addarc():
    s = NFAState()
    t = NFAState()
    s.addarc(t, '"x"')
    assert s.arcs == [('"x"', t)]


# Generated at 2022-06-21 10:25:24.043261
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():
    state0 = DFAState({}, None)
    # state1 -> state3, state2 -> state3, state0 -> state2, state0 -> state1
    state1 = DFAState({}, None)
    state2 = DFAState({}, None)
    state3 = DFAState({}, None)
    state1.addarc(state3)
    state2.addarc(state3)
    state0.addarc(state2)
    state0.addarc(state1)
    state0.unifystate(state1, state3)
    assert state0.arcs == {None: state2, None: state3}

# Testing for method DFAState.unifystate

# Generated at 2022-06-21 10:27:36.575863
# Unit test for constructor of class DFAState
def test_DFAState():
    x = DFAState({}, None)
    assert x.nfaset == {}
    assert x.isfinal == False
    assert x.arcs == {}
    y = DFAState({}, None)
    assert y.nfaset == {}
    assert y.isfinal == False
    assert y.arcs == {}
    assert not (x == y)

# Generated at 2022-06-21 10:27:47.864766
# Unit test for method addarc of class DFAState
def test_DFAState_addarc():
    _a = DFAState({}, NFAState())
    _b = DFAState({}, NFAState())
    _c = DFAState({}, NFAState())
    with pytest.raises(AssertionError):
        _a.addarc(_b, '_b')
        _a.addarc(_b, '_b')
        assert hasattr(_a.arcs, 'key')
        assert not hasattr(_a.arcs, 'value')
        _a.addarc(_b, '_b')
        _a.addarc(_c, '_b')
        assert hasattr(_a.arcs, 'key')
        assert not hasattr(_a.arcs, 'value')
        assert not hasattr(_c.arcs, 'key')
        assert not hasattr(_c.arcs, 'value')

# Generated at 2022-06-21 10:27:51.003527
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    assert ParserGenerator("").parse_alt() == (NFAState(), NFAState())

# Generated at 2022-06-21 10:28:03.296761
# Unit test for method __eq__ of class DFAState
def test_DFAState___eq__():
    eq = DFAState.__eq__
    ns = NFAState()
    s = DFAState({ns: 1}, ns)
    assert not eq(s, None)
    assert not eq(s, 42)
    assert not eq(s, DFAState({ns: 1}, ns))
    assert not eq(s, DFAState({ns: 1}, NFAState()))
    assert not eq(s, DFAState({}, ns))
    t = DFAState({ns: 1}, NFAState())
    assert eq(t, DFAState({ns: 1}, NFAState()))
    assert eq(t, DFAState({ns: 2}, NFAState()))
    assert not eq(t, DFAState({NFAState(): 1}, NFAState()))
    u = DFAState({ns: 1}, ns)

# Generated at 2022-06-21 10:28:15.173393
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    # Perform some random tests.
    start = grammar._ParserGenerator__NFAState()
    finish = grammar._ParserGenerator__NFAState()
    nfa = [start, finish]
    dfa = [grammar._ParserGenerator__DFAState({start: 1}, finish)]
    nfastates = [start]
    for i in range(300):
        arc = grammar._ParserGenerator__NFAState()
        nfastates.append(arc)
    for i in range(1000):
        src = random.choice(nfastates)
        dst = random.choice(nfastates)
        src.addarc(dst)
    for i in range(500):
        src = random.choice(nfastates)
        dst = random.choice(nfastates)

# Generated at 2022-06-21 10:28:26.701070
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
  s = r"""
       expr: xor_expr ('|' xor_expr)*
       xor_expr: and_expr ('^' and_expr)*
       and_expr: shift_expr ('&' shift_expr)*
       shift_expr: arith_expr ('<<' arith_expr | '>>' arith_expr)*
       arith_expr: term (('+'|'-') term)*
       term: factor (('*'|'/'|'%') factor)*
       factor: ('+'|'-'|'~') factor | power
       power: atom trailer* ['**' factor]
       """
  pg = ParserGenerator(list(tokenize.generate_tokens(StringIO(s).readline)))
  pg.parse()
  return pg


# Generated at 2022-06-21 10:28:29.586620
# Unit test for method addarc of class DFAState
def test_DFAState_addarc():
    """Verify that DFAState.addarc works as expected."""
    s = DFAState({}, None)
    s.addarc(s, "a")
    assert s.arcs == {'a': s}
    s.addarc(s, "a")
    assert s.arcs == {'a': s}


# Generated at 2022-06-21 10:28:34.101728
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    p = ParserGenerator()
    p.setup("x")
    a, z = p.parse_atom()
    assert a.arcs == [(None, z)], a.arcs
    assert z.arcs == [], z.arcs

# Generated at 2022-06-21 10:28:42.031354
# Unit test for method addfirstsets of class ParserGenerator

# Generated at 2022-06-21 10:28:47.528108
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    pg = ParserGenerator()
    pg.addfirstsets()
    assert pg.first['file_input']['import'] == 1
    assert pg.first['file_input']['def'] == 1
    assert pg.first['file_input'][None] == 1


# Generated at 2022-06-21 10:30:42.392220
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():

    class TestPG(ParserGenerator):
        token = token
        grammar = grammar
        START_SYM = 'file_input'