

# Generated at 2022-06-21 10:22:41.384867
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    pg = ParserGenerator()
    pg.add_dfa('A', [
        [
            ('"a"', 1),
            ('"b"', 2),
        ],
        [
            ('"a"', 2),
        ],
        [
            ('"b"', 0),
            ('"a"', 1),
            ('"a"', 2),
            ('"b"', 3),
        ],
        [
            ('"a"', 0),
        ],
    ], False)
    pg.add_dfa('B', [
        [
            ('"a"', 1),
        ],
        [
            ('"a"', 1),
            ('"b"', 2),
        ],
        [
            ('"b"', 0),
        ],
    ], False)
    pg.addfirstsets

# Generated at 2022-06-21 10:22:47.316289
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():

    class Subclass(ParserGenerator):
        def __init__(self) -> None:
            self.f = lambda s: s

    class NFAState:
        def __init__(self, isfinal=False) -> None:
            self.arcs: Dict["NFAState", int] = {}
            self.isfinal = isfinal

        def addarc(self, next: "NFAState") -> None:
            self.arcs[next] = 1

        def unifystate(self, old: "NFAState", new: "NFAState") -> None:
            # print "unifystate", old.arcs, new.arcs
            if old in self.arcs:
                del self.arcs[old]
                assert new not in self.arcs
                self.arcs[new] = 1
            #

# Generated at 2022-06-21 10:22:48.145918
# Unit test for function generate_grammar
def test_generate_grammar():
    assert generate_grammar() is not None

# Generated at 2022-06-21 10:22:53.281300
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():
    # This is a hand-constructed test data set.
    #
    # It's a state with two arcs, one of them self-referential.
    a = DFAState({}, NFAState())
    b = DFAState({}, NFAState())
    d = DFAState({}, NFAState())
    a.arcs["a"] = a
    a.arcs["b"] = b
    b.arcs["b"] = d

    # We want to unify b with a, so that a.arcs["b"] == a.
    # This is what the method should achieve:
    a.arcs["b"] = a

    # Now test it
    a.unifystate(b, a)
    assert a.arcs["b"] is a

    # Test that it also follows the self-referential arc
   

# Generated at 2022-06-21 10:23:04.672434
# Unit test for method parse_item of class ParserGenerator

# Generated at 2022-06-21 10:23:17.270555
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    from typing import Iterable
    from . import ast

    class DummyTypeDef(ast.TypeDef):
        def __init__(self):
            self.name = "dummytype"
            self.kind = ast.UNION
            self.attributes = {}
            self.variants = []
            self.doc = "dummy type"
            self.type = None

    def parse_grammar() -> Iterable[Tuple[int, str, Any, Any, str]]:
        yield (token.NAME, "startsymbol", (1, 0), (1, 0), "startsymbol")
        yield (token.OP, ":", (1, 0), (1, 0), ":")
        yield (token.NAME, "rule1", (1, 0), (1, 0), "rule1")

# Generated at 2022-06-21 10:23:27.460537
# Unit test for method parse_item of class ParserGenerator

# Generated at 2022-06-21 10:23:29.374452
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    gen = ParserGenerator()
    gen = gen
    assert False, "Test not implemented"



# Generated at 2022-06-21 10:23:41.914119
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    # Check that method gettoken correctly reads token pairs from
    # the tokenize module.  Method gettoken is implicitly tested
    # by the other test cases in this file.

    # First test a simple case.
    text = "aa (bb) /* ccc */ dd"
    expected_tokens = [
        (token.NAME, "aa"),
        (token.OP, "("),
        (token.NAME, "bb"),
        (token.OP, ")"),
        (token.NAME, "dd"),
    ]
    pg = ParserGenerator()
    pg.gettoken()
    for expected in expected_tokens:
        assert pg.type == expected[0], (expected, pg.type)
        assert pg.value == expected[1], (expected, pg.value)
        pg.gettoken()
    assert pg

# Generated at 2022-06-21 10:23:47.325668
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    c = ParserGenerator().make_label(c, "abc")
    # In Python 3 and Python 2, assert 'abc' == 'abc' holds
    # In Python 2 and Python 3, assert 'abc' == u'abc' fails
    assert 'abc' == 'abc'
    assert b'abc' == 'abc'



# Generated at 2022-06-21 10:24:41.598782
# Unit test for function generate_grammar
def test_generate_grammar():
    expected_grammar = {
        "START": [DFAState({NFAState(): 1}, NFAState())],
        "STRING": [DFAState({NFAState(): 1}, NFAState())],
        "NUMBER": [DFAState({NFAState(): 1}, NFAState())],
        "NAME": [DFAState({NFAState(): 1}, NFAState())],
        "NEWLINE": [DFAState({NFAState(): 1}, NFAState())],
        "ENDMARKER": [DFAState({NFAState(): 1}, NFAState())],
    }
    pgen = ParserGenerator("Grammar.txt")
    grammar = pgen.make_grammar()
    assert expected_grammar == grammar
test_generate_grammar()



# Generated at 2022-06-21 10:24:52.903264
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    import unittest
    import tokenize
    from io import BytesIO

    class TestCase(unittest.TestCase):
        def setUp(self) -> None:
            self.stream = BytesIO(b"(a|b)+")
            self.parser = ParserGenerator()
            self.generator = self.parser.tokenize(self.stream)
            self.type, self.value, self.begin, self.end, self.line = next(
                self.generator
            )

        def test_parse_item_1(self) -> None:
            from . import pgen
            from .pgen import ParserGenerator, NFAState

            self.assertEqual(self.value, "(")
            a, z = self.parser.parse_item()

# Generated at 2022-06-21 10:25:01.874588
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    generator = iter([])
    pg = ParserGenerator(generator)

    def methodcall(self, msg: str, *args: Any) -> NoReturn:
        self.raise_error(msg, *args)
    pg.raise_error = MethodType(methodcall, pg)

    try:
        pg.raise_error("test message", "abc", 123)
    except SyntaxError as e:
        # print(e)
        if e.msg != "test message abc 123":
            raise AssertionError()
        else:
            pass
    else:
        raise AssertionError()



# Generated at 2022-06-21 10:25:10.439490
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    pg = ParserGenerator()

    class DFAState:

        def __init__(self, nfaset: Dict[int, int], finish: int) -> None:
            self.nfaset = nfaset
            self.isfinal = finish in nfaset
            self.arcs: Dict[str, Dict[int, int]] = {}

        def addarc(self, next: "DFAState", label: Any = None) -> None:
            assert isinstance(next, DFAState)
            label = label or 0
            self.arcs[label] = next.nfaset

        def unifystate(self, old: "DFAState", new: "DFAState") -> None:
            assert isinstance(old, DFAState)
            assert isinstance(new, DFAState)

# Generated at 2022-06-21 10:25:22.833361
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    parser = ParserGenerator()
    parser.dfas = {
        "single_input": [
            DFAState({}, False),
            DFAState({}, True)
        ]
    }
    parser.addfirstsets()
    assert parser.first == {
        "single_input": {
            "NEWLINE": 1,
            "STRING": 1
        }
    }


if __name__ == "__main__":
    # doctest.testmod()
    import sys
    import time
    t1 = time.time()
    if len(sys.argv) > 1:
        for filename in sys.argv[1:]:
            with tokenize.open(filename) as f:
                src = f.read()
            parser = ParserGenerator()
            parser.setupstr(src, filename)


# Generated at 2022-06-21 10:25:34.822278
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    class NFAState:
        def __init__(self, arcs: List[Tuple[Text, "NFAState"]]) -> None:
            self.arcs = arcs
    # test: NFAState -> DFAState
    def closure(state: NFAState) -> Dict[NFAState, int]:
        base: Dict[NFAState, int] = {}
        addclosure(state, base)
        return base

    # test: NFAState -> None
    def addclosure(state: NFAState, base: Dict[NFAState, int]) -> None:
        if state in base:
            return
        base[state] = 1
        for label, next in state.arcs:
            if label is None:
                addclosure(next, base)

    class DFAState:
        pass
    # test:

# Generated at 2022-06-21 10:25:46.225475
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():

    def check_rhs(str, expected):
        gen = ParserGenerator()
        gen.setup_parser()
        gen.type = token.OP
        gen.value = ':'
        gen.line = str
        gen.begin = (0,0)
        gen.end = (0, 0)
        gen.filename = ''
        a, z = gen.parse_rhs()
        # gen.dump_nfa('', a, z)

    def check_rhs2(str, expected):
        gen = ParserGenerator()
        gen.setup_parser()
        gen.type = token.OP
        gen.value = ':'
        gen.line = str
        gen.begin = (0,0)
        gen.end = (0, 0)
        gen.filename = ''
        a, z = gen

# Generated at 2022-06-21 10:25:47.352774
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    assert PgenGrammar



# Generated at 2022-06-21 10:25:54.744189
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    """
    The method expect() of class ParserGenerator should raise
    SyntaxError if it receives a type/value mismatching the
    expected type/value.
    """
    pg = ParserGenerator()
    try:
        pg.expect(token.NAME, "name")
    except SyntaxError as e:
        assert not str(e)
    else:
        assert False
    pg.type = token.NAME
    pg.value = "name"
    pg.filename = "filename"
    pg.end = (1, 2)
    pg.line = "line"
    try:
        pg.expect(token.NAME, "name")
    except SyntaxError as e:
        assert str(e) == "expected NAME/name, got NAME/name"
    else:
        assert False

# Generated at 2022-06-21 10:25:59.176361
# Unit test for constructor of class NFAState
def test_NFAState():
    n = NFAState()
    assert n.arcs == []
    state2 = NFAState()
    n.addarc(state2)
    assert len(n.arcs) == 1
    assert n.arcs[0][1] is state2



# Generated at 2022-06-21 10:27:52.146350
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    class DFAState:
        def __init__(self, arcs: Dict[str, "DFAState"]) -> None:
            self.arcs = arcs

        def __eq__(self, other: Any) -> bool:
            if not isinstance(other, DFAState):
                return False
            if self.arcs.keys() != other.arcs.keys():
                return False
            for label, next in self.arcs.items():
                if next is not other.arcs[label]:
                    return False
            return True

        def __hash__(self) -> int:
            try:
                return self.__hashval
            except AttributeError:
                self.__hashval = h = 0
                for label, next in self.arcs.items():
                    h = h * 1000003 + hash(label)

# Generated at 2022-06-21 10:27:54.176739
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    with open("Grammar.txt", "r") as f:
        PgenGrammar(f)


# Generated at 2022-06-21 10:28:07.253302
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    pg = ParserGenerator()

# Generated at 2022-06-21 10:28:19.036830
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    pgen = ParserGenerator()
    pgen.dfas = {}
    pgen.first = {}
    pgen.dfas["foo"] = [DFAState({}, False)]
    pgen.dfas["foo"][0].addarc(pgen.dfas["foo"][0], "a")
    pgen.dfas["foo"][0].addarc(pgen.dfas["foo"][0], "b")
    pgen.dfas["foo"][0].isfinal = True
    pgen.dfas["bar"] = [DFAState({}, False)]
    pgen.dfas["bar"][0].addarc(pgen.dfas["foo"][0], None)
    pgen.dfas["baz"] = [DFAState({}, False)]

# Generated at 2022-06-21 10:28:29.259211
# Unit test for function generate_grammar
def test_generate_grammar():
    g = generate_grammar()
    print(g.__class__, g)
    print(len(g.keywords))
    print(len(g.states))
    print(g.start)
    print(g.literals)
    print(g.symbol2label)
    print(len(g.dfas))
    print(len(g.labels))
    print(len(g.dfas))
    print(len(g.first))

    def print_tokens(toks):
        for t in toks:
            print(token.tok_name[t], end=" ")
        print()

    print_tokens([t for t, v in g.literals])
    print_tokens(g.tokens.keys())

# Generated at 2022-06-21 10:28:39.477019
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    pg = ParserGenerator()
    pg.build_parser("a : 'a'")
    assert pg.parse_alt() == (pg.dfas["a"][0], pg.dfas["a"][1])

    pg.build_parser("a : 'a''b'")
    a, z = pg.parse_alt()
    b = a.arcs[0][1]
    assert (a.arcs, z.arcs) == ([(None, b)], [(None, z)])

    pg.build_parser("a : 'a''b''c'")
    a, z = pg.parse_alt()
    b = a.arcs[0][1]
    c = b.arcs[0][1]

# Generated at 2022-06-21 10:28:50.948735
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    import StringIO
    s = StringIO.StringIO("""
        S: 'a'
        A: S | 'b'
        C: 'b' | 'a'
        D: 'd' | 'c'
    """)
    g = ParserGenerator()
    # print "parse..."
    g.parse_grammar(s)
    # print "addfirstsets..."
    g.addfirstsets()
    # print "calcfirst S..."
    f = g.calcfirst("S")
    assert f == {'a': 1}, f
    # print "calcfirst A..."
    f = g.calcfirst("A")
    assert f == {'a': 1, 'b': 1}, f
    # print "calcfirst C..."
    f = g.calcfirst("C")

# Generated at 2022-06-21 10:29:01.634293
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    class TestConverter:
        symbol2number: Dict[str, int]
        symbol2label: Dict[str, int]
        tokens: Dict[int, int]
        keywords: Dict[str, int]
        labels: List[Tuple[int, str]]
        def __init__(self) -> None:
            self.symbol2number = {}
            self.symbol2label = {}
            self.tokens = {}
            self.keywords = {}
            self.labels = []
    pg = ParserGenerator()

    # Check make_label on numeric tokens
    c = TestConverter()
    assert pg.make_label(c, "ENDMARKER") == 0
    assert c.labels == [(0, None)]
    assert pg.make_label(c, "NAME")

# Generated at 2022-06-21 10:29:04.713342
# Unit test for method addarc of class NFAState
def test_NFAState_addarc():
    state = NFAState()
    next = NFAState()
    state.addarc(next)
    assert state.arcs == [(None, next)]
    state.addarc(next, "label")
    assert state.arcs == [(None, next), ("label", next)]

# Generated at 2022-06-21 10:29:11.255406
# Unit test for function generate_grammar
def test_generate_grammar():
    g = generate_grammar()
    print("Grammar ready.")
    print("  tokens:", g.tokens)
    print("  start:", g.start)
    print("  dfas:", g.dfas)
    print("  labels:", g.labels)
    print("  first:", g.first)

test_generate_grammar()
