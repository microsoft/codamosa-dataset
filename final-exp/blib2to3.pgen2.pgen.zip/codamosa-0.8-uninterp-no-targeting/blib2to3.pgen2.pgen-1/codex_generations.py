

# Generated at 2022-06-21 10:22:49.965463
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    pass

# Constructor signature help
PgenGrammar.__init__

# pylint: disable=unsubscriptable-object


# Generated at 2022-06-21 10:22:54.570354
# Unit test for function generate_grammar
def test_generate_grammar():
    grammar_file = "Grammar.txt"
    p = ParserGenerator(grammar_file)
    return p.make_grammar()
# Test case
test_generate_grammar()


# Generated at 2022-06-21 10:23:03.591304
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    with open(os.path.join(os.path.dirname(__file__), "Grammar.txt"), "r") as f:
        pg = PgenGrammar(f)
        assert isinstance(pg, grammar.Grammar)
        assert pg.start == 'file_input'
        assert pg.tokens['t_NAME'] == '\\x00?[a-zA-Z_]\\x00?[a-zA-Z0-9_]*'
        assert pg.tokens['t_COMMENT'] == (
            r"(\#|\\\n|<\\\n)*"
            r"(\#[^\\\n]*(?:\\.[^\\\n]*)*)"
            r"(\#|\\\n|\\\n>)?"
        )

# Generated at 2022-06-21 10:23:10.827935
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    a = NFAState()
    b = NFAState()
    c = NFAState()
    d = NFAState()
    a.addarc(b, "x")
    a.addarc(c, "y")
    c.addarc(a, "1")
    c.addarc(d, "2")
    d.addarc(b, "3")
    d.addarc(d, None)

    pg = ParserGenerator()
    pg.dump_nfa("test_ParserGenerator_dump_nfa", a, d)



# Generated at 2022-06-21 10:23:17.489521
# Unit test for method addarc of class DFAState
def test_DFAState_addarc():
    N = NFAState()
    s = DFAState({N: 1}, N)
    N2 = NFAState()
    s.addarc(DFAState({N2: 1}, N2), "a")
    assert repr(s.arcs) == "{'a': <DFAState for 1 states>}"

# Generated at 2022-06-21 10:23:27.606573
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    pg = ParserGenerator()
    pg.dfas = {
        "file_input": [
            DFAState({}, False),
            DFAState({"stmt": DFAState({}, False)}, True),
            DFAState({"stmt": DFAState({}, False)}, False),
        ],
        "stmt": [DFAState({}, False)],
    }
    pg.calcfirst("file_input")
    # print pg.first["file_input"]
    assert pg.first["file_input"] == {"stmt": 1}

# Generated at 2022-06-21 10:23:35.280348
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    #  Args:
    #
    #    o start - An initial NFA state
    #
    #    o finish - A final NFA state
    #
    #  Returns:
    #
    #    A list of DFA states, and a dictionary mapping state numbers
    #    (integers) to lists of NFA states.
    # 
    #
    a = NFAState()
    z = NFAState()
    dfa = ParserGenerator.make_dfa(None, a, z)
    eq = "assert dfa == [None]"
    exec(eq)
    a = NFAState()
    z = NFAState()
    a.addarc(z, "a")  # Not a valid NFA, but legal

# Generated at 2022-06-21 10:23:47.405226
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    # Test for method addfirstsets()
    parser = ParserGenerator()
    parser.dfas = {'foo': [DFAState({}, 0)], 'bar': [DFAState({}, 0)],
        'baz': [DFAState({}, 0)]}
    parser.dfas['foo'][0].addarc(parser.dfas['bar'][0], 'a')
    parser.dfas['foo'][0].addarc(parser.dfas['baz'][0], 'b')
    parser.dfas['bar'][0].addarc(parser.dfas['foo'][0], ('a', 'b'))
    parser.startsymbol = 'foo'
    parser.addfirstsets()

# Generated at 2022-06-21 10:23:58.972390
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    """Test method make_first of class PgenParser."""
    source = """
        # Grammar
        start: a | b
        a: 'a'
        b: 'b'
        """
    gen = ParserGenerator()
    gen.setup(source, "PgenGrammar")
    gen.addfirstsets()
    c = gen._convert()  # type: ignore
    C = c.make_first(c, "a")
    A = C[c.labels.index(('a', None))]
    assert A == 1
    B = c.make_first(c, "b")
    assert B[c.labels.index(('b', None))] == 1
    assert C[c.labels.index(('b', None))] == 1

# Generated at 2022-06-21 10:24:10.242217
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    # Test adapted from test_pgen.py
    pg = ParserGenerator()
    nfa0 = NFAState()
    nfa1 = NFAState()
    nfa2 = NFAState()
    nfa3 = NFAState()
    nfa0.addarc(nfa1, "a")
    nfa0.addarc(nfa2, "a")
    nfa2.addarc(nfa3, "a")
    nfa3.addarc(nfa1, "b")
    nfa2.addarc(nfa1, "b")
    dfa = pg.make_dfa(nfa0, nfa1)
    # pg.dump_dfa("test_make_dfa", dfa)
    assert len(dfa) == 3

# Generated at 2022-06-21 10:24:37.094961
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    import io
    import os
    import sys
    import unittest
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    class TestParse_item(unittest.TestCase):

        def test_parse_item_1(self):
            grammar = """
            file_input: (NEWLINE | stmt)* ENDMARKER
            """
            buf = io.StringIO(grammar)
            pgen = ParserGenerator(buf, '<string>')
            pgen.parse()
        
    unittest.main()


if __name__ == '__main__':
    test_ParserGenerator_parse_item()

# Generated at 2022-06-21 10:24:38.573978
# Unit test for method addarc of class DFAState
def test_DFAState_addarc():
    s = DFAState({}, None)
    s.addarc(s, 'a')



# Generated at 2022-06-21 10:24:42.068433
# Unit test for method __eq__ of class DFAState
def test_DFAState___eq__():
    class DFAStateSubclass(DFAState):
        pass
    assert DFAStateSubclass({}, None) != 42
    assert DFAStateSubclass({}, None) != DFAStateSubclass({}, None)
    assert not (DFAStateSubclass({}, None) == 42)
    assert not (DFAStateSubclass({}, None) == DFAStateSubclass({}, None))

# Generated at 2022-06-21 10:24:53.176570
# Unit test for constructor of class ParserGenerator

# Generated at 2022-06-21 10:25:03.290341
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    from .compiler import Compiler
    from .parser import Parser
    from .compilertools import showgrammar
    c = Compiler()
    g = ParserGenerator(open("../Parser/Grammar.txt", encoding="latin-1")).make_grammar(c)
    showgrammar(g)
    print("-" * 40)
    print(g.__class__)
    p = Parser(g)
    p.parsetokens(
        (toktype, tokvalue)
        for toktype, tokvalue, _, _, _ in tokenize.tokenize(open("../Parser/Grammar.txt").readline)
    )
# End unit test



# Generated at 2022-06-21 10:25:11.464299
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    p = ParserGenerator()
    p.startsymbol = "A"
    p.dfas["B"] = [DFAState({}, False), DFAState({}, True)]
    p.dfas["C"] = [DFAState({}, False), DFAState({}, True)]
    p.dfas["D"] = [DFAState({}, False), DFAState({}, True)]
    p.dfas["A"] = [
        DFAState({0: 1}, False),
        DFAState({"a": 1, "b": 2}, False),
        DFAState({0: 3}, False),
        DFAState({"a": 1, "b": 2}, False),
        DFAState({}, True),
    ]
    p.simplify_dfa(p.dfas["A"])

# Generated at 2022-06-21 10:25:24.389219
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():

    # pgen's err.pgen puts stuff on the stack
    from . import graminit

    pg = ParserGenerator()
    pg.object_names["name"] = "expr"
    pg.object_names["first"] = "expr"
    pg.object_names["second"] = "expr"
    pg.addrule("name", "first second")

    def ex(r: str) -> str:
        return ", ".join(map(repr, sorted(r.split())))

    pg.addrule("first", "")
    pg.addrule("first", "name")
    pg.addrule("first", "first name")

    pg.addrule("second", "")
    pg.addrule("second", "name")
    pg.addrule("second", "second name")

    pg.build()

    pg.dump

# Generated at 2022-06-21 10:25:35.693613
# Unit test for method addfirstsets of class ParserGenerator

# Generated at 2022-06-21 10:25:42.649287
# Unit test for method __eq__ of class DFAState
def test_DFAState___eq__():
    class DFAState(object):
        __slots__ = "a", "b"

        def __init__(self, a, b) -> None:
            self.a, self.b = a, b

        def __eq__(self, other) -> bool:
            if self.a != other.a or self.b != other.b:
                return False
            return True

        def __hash__(self) -> int:
            return hash((self.a, self.b))

    def check() -> None:
        d1 = DFAState(1, None)
        d2 = DFAState(1, None)
        assert d1 == d2
        d3 = DFAState(2, None)
        assert d1 != d3
        d4 = DFAState(1, 2)
        assert d1 != d

# Generated at 2022-06-21 10:25:52.004153
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    def do_test(source: Text) -> Tuple[NFAState, NFAState]:
        gen = ParserGenerator()
        gen.src = io.StringIO(source)
        gen.filename = "UnitTest"
        gen.gettoken()
        return gen.parse_rhs()

    start, finish = do_test("[]")
    assert len(start.arcs) == 1
    assert len(start.arcs[0][1].arcs) == 1
    assert start.arcs[0][1].arcs[0][1] is finish

    start, finish = do_test("a | b")
    assert start.arcs[0][1].arcs[0][0] == "a"
    assert start.arcs[1][1].arcs[0][0] == "b"

    start,

# Generated at 2022-06-21 10:26:40.455917
# Unit test for method parse of class ParserGenerator

# Generated at 2022-06-21 10:26:52.788053
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    pg = ParserGenerator()
    pg.setup([(token.NAME, "NAME"),
              (token.OP, ":"),
              (token.OP, "|"),
              (token.OP, "+"),
              (token.OP, "*"),
              (token.OP, "("),
              (token.STRING, "'abc'"),
              (token.OP, ")"),
              (token.STRING, "'def'"),
              (token.STRING, "'ghi'"),
              (token.ENDMARKER, "")])
    a, z = pg.parse_rhs()
    assert a.arcs == [(None, a)]
    assert len(a.arcs) == 1
    assert z.arcs == []
    assert len(z.arcs) == 0

# Generated at 2022-06-21 10:26:56.853701
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    from . import grammar_nts_and_rules_for_testing

    p = ParserGenerator()
    p.setup(*grammar_nts_and_rules_for_testing)
    p.dump_nfa('test', p.dfas['test'][0], p.dfas['test'][-1])

# Generated at 2022-06-21 10:27:08.662059
# Unit test for constructor of class PgenGrammar

# Generated at 2022-06-21 10:27:13.467158
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
  import os
  p = os.path.dirname(__file__)
  pg = ParserGenerator()
  pg.parse_grammar(os.path.join(p, "Grammar"))
  pg.dump_grammar()
  gram = pg.make_grammar()

if __name__ == "__main__":
    test_ParserGenerator_make_first()

# Generated at 2022-06-21 10:27:26.578640
# Unit test for constructor of class DFAState
def test_DFAState():
    a = DFAState({}, None)
    b = DFAState({}, None)
    assert a == b

    c = DFAState({'x': 1}, None)
    d = DFAState({'y': 2}, None)
    assert not c == d

    e = DFAState({}, None)
    e.addarc(d, 'x')
    e.addarc(e, 'y')
    assert not a == e

    f = DFAState({}, None)
    f.addarc(d, 'x')
    f.addarc(f, 'y')
    assert not e == f

    g = DFAState({}, None)
    g.addarc(d, 'x')
    g.addarc(g, 'y')
    assert e == g



# Generated at 2022-06-21 10:27:37.592025
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    pgen = ParserGenerator()

    pgen.gettoken = Mock(
      side_effect=[
        (1, '<first>', (0, 0), (0, 0), '<first> : NAME\n'),
        (1, 'NAME', (0, 0), (0, 0), '<first> : NAME\n'),
        (1, '<second>', (0, 0), (0, 0), '<first> : NAME\n<second> : NAME\n')
      ]
    )

    pgen.parse_item = Mock(return_value=(1, 2)) 
    pgen.expect = Mock(
      side_effect=[
        '<first>',
        '[',
        'NAME',
        ']'
      ]
    )

    actual = pgen.parse_alt()
    expected

# Generated at 2022-06-21 10:27:48.509411
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    import sys
    import _ast
    """
    This unit test has been added manually. It's purpose is to check that
    the method calcfirst of class ParserGenerator doesn't crash on a certain
    kind of recursion.

    The grammar of the Python language in Parser/Python.asdl is:

    mod: (stmt)*
    expr: [...]
    stmt: pass_stmt | [...]

    pass_stmt: 'pass'

    The method calcfirst is called for the non-terminal "mod". It then calls
    calcfirst for the non-terminals "pass_stmt" and "expr". This call for
    "pass_stmt" raises ValueError.
    """
    pg = ParserGenerator()
    assert isinstance(sys, type)
    assert isinstance(pg, ParserGenerator)

# Generated at 2022-06-21 10:27:55.653854
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    states = [DFAState([NFAState({NFAState(1): 1}), NFAState({NFAState(2): 1})], True)]
    pg = ParserGenerator()
    pg.simplify_dfa(states)
    assert states[0].nfaset == {NFAState({NFAState(1): 1}), NFAState({NFAState(2): 1})}



# Generated at 2022-06-21 10:28:08.162045
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    pg = ParserGenerator()
    pg.source = [
        "foo = 42",
        "bar = bar bar bar bar bar bar bar bar bar bar bar bar bar bar bar bar",
    ]
    for i in range(len(pg.source)):
        pg.gettoken()
        assert pg.type == token.NAME
        assert pg.value == "foo"
        assert pg.begin == (i + 1, 0)
        assert pg.end == (i + 1, 3)
        pg.gettoken()
        assert pg.type == token.OP
        assert pg.value == "="
        pg.gettoken()
        assert pg.type == token.NUMBER
        assert pg.value == "42"
        pg.gettoken()
        assert pg.type == tokenize.NEWLINE
        pg.gettoken()

# Generated at 2022-06-21 10:29:28.253558
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    import textwrap
    import pgen.pgen2.convert
    import pgen.pgen2.parse
    import pgen.pgen2.driver
    import pgen.pgen2.tokenize


# Generated at 2022-06-21 10:29:41.297606
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    class PgenSyntaxError(Exception):
        def __init__(self, msg):
            self.msg = msg

    # The code executed when testing graminit.py is not exactly the
    # same as the code executed normally.  For example, future
    # statements are inserted in graminit.py, but not here.  The
    # results should be *very* similar though.
    def compare_grammars(pgen: ParserGenerator) -> None:
        with open("Lib/lib2to3/Grammar.txt") as f:
            grammar_lines = f.read().splitlines()
        start = end = None
        while end is None:
            start = start + 1 if start is not None else 0

# Generated at 2022-06-21 10:29:44.666202
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    pg = ParserGenerator()
    dfa = pg.make_dfa(NFAState(), NFAState())
    assert len(dfa) == 2
    a, z = dfa
    assert len(a.arcs) == 0
    assert z.isfinal


# Generated at 2022-06-21 10:29:46.391964
# Unit test for constructor of class DFAState
def test_DFAState():
    raise SyntaxError("test_DFAState() not implemented")


# Debugging aid only

# Generated at 2022-06-21 10:29:58.622190
# Unit test for method __eq__ of class DFAState
def test_DFAState___eq__():
    """Class DFAState: method __eq__"""
    assert DFAState({}, None) == DFAState({}, None)
    assert DFAState({}, None) != DFAState({NFAState(): 1}, None)
    assert DFAState({NFAState(): 1}, None) == DFAState({NFAState(): 1}, None)
    assert DFAState({NFAState(): 1}, None) != DFAState({NFAState(): 2}, None)
    assert DFAState({NFAState(): 1}, None) != DFAState({NFAState(): 1, NFAState(): 1}, None)
    assert DFAState({NFAState(): 1}, NFAState()) == DFAState({NFAState(): 1}, NFAState())

# Generated at 2022-06-21 10:30:05.746328
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    for args in [
        ('a : "a"\n', 'a'),
        ('a : "a"\n', 'a', {'a': 1}),
        ('a : "a" | "b"\n', 'a', {'a': 1, 'b': 1}),
        ('a : []\n', 'a'),
        ('a : [ "a" ]\n', 'a', {'a': 1}),
        ('a : [ "a" | "b" ]\n', 'a', {'a': 1, 'b': 1}),
    ]:
        pg = ParserGenerator(*args[:-1])
        dfa = pg.make_dfa(*pg.parse()[args[-1]][0])
        assert len(dfa) == 2
        assert dfa[0].isf

# Generated at 2022-06-21 10:30:16.787775
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    # Arrange
    parser = ParserGenerator()
    parser.gettoken = mock.Mock()
    parser.gettoken.side_effect = (
        (None, None, None, None, None),
        (token.OP, ")", None, None, None),
        (None, "{", None, None, None),
    )
    parser.raise_error = mock.Mock()
    parser.raise_error.return_value = None

    # Act
    result = parser.parse_atom()

    # Assert
    assert result is None
    parser.gettoken.assert_has_calls(
        [
            mock.call(),
            mock.call(),
            mock.call(),
            mock.call(),
        ],
        any_order=False,
    )
    parser.raise_error.assert_has_

# Generated at 2022-06-21 10:30:27.765481
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    pg = ParserGenerator()
    pg.lexer.filename = "<test>"
    pg.lexer.line = "xxxxxx: xxxxxx xxxxxx"
    pg.lexer.pos = 0
    def test(s: str, alt: List[Optional[str]]) -> None:
        pg.lexer.line = s
        pg.lexer.pos = 0
        a, b = pg.parse_alt()
        assert a is not b
        assert len(a.arcs) == 1
        assert a.arcs[0][0] is None
        assert len(b.arcs) == 1
        assert b.arcs[0][0] is None
        assert b.arcs[0][1] is a
        state = a

# Generated at 2022-06-21 10:30:37.471408
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    class MockObject:
        pass
    obj = MockObject()
    obj.generator = iter(
        [
            (token.OP, "("),
            (token.NAME, "expr"),
            (token.OP, ")"),
            (token.ENDMARKER, ""),
        ]
    )
    obj.type = None
    obj.value = None
    obj.filename = None
    obj.begin = (1, 1)
    obj.end = (1, 1)
    obj.line = ""
    obj.gettoken = ParserGenerator.gettoken
    obj.raise_error = ParserGenerator.raise_error
    obj.expect(token.OP, "(")
    assert obj.type == token.OP and obj.value == "("
    obj.expect(token.NAME, "expr")

# Generated at 2022-06-21 10:30:48.669875
# Unit test for constructor of class DFAState
def test_DFAState():
    f1 = NFAState()
    f2 = NFAState()
    a = DFAState({f1: 1}, f1)
    b = DFAState({f1: 1}, f1)
    c = DFAState({f1: 1}, f2)
    a.addarc(a, "a")
    b.addarc(a, "a")
    c.addarc(c, "a")
    d = DFAState({f1: 1, f2: 1}, f1)
    d.addarc(d, "a")
    e = DFAState({f1: 1, f2: 1}, f1)
    e.addarc(d, "a")

    assert a == b
    assert a != c
    assert c != d
    assert d == e