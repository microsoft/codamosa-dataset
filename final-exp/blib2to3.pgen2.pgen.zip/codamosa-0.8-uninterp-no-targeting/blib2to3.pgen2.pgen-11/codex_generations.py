

# Generated at 2022-06-21 10:22:17.569672
# Unit test for method __eq__ of class DFAState
def test_DFAState___eq__():
    s1 = DFAState({1:1, 2:1}, 1)
    s2 = DFAState({1:1, 2:1}, 1)
    assert s1 == s2

    for (a, b) in itertools.product((True, False), (True, False)):
        s1 = DFAState({1:1, 2:1}, a)
        s2 = DFAState({1:1, 2:1}, b)
        assert s1 != s2

    # Note: order of arcs doesn't matter
    s1 = DFAState({1:1, 2:1}, True)
    s1.arcs["a"] = s1
    s1.arcs["b"] = s1
    s2 = DFAState({1:1, 2:1}, True)

# Generated at 2022-06-21 10:22:19.295559
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    pg = ParserGenerator()



# Generated at 2022-06-21 10:22:21.876700
# Unit test for method addarc of class DFAState
def test_DFAState_addarc():
    d1 = DFAState({}, NFAState())
    d2 = DFAState({}, NFAState())
    d1.addarc(d2, "foo")
    assert d1.arcs == {"foo": d2}

# Generated at 2022-06-21 10:22:28.761508
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    gen = ParserGenerator()
    gen.filename = "<testfile>"
    gen.gettoken = lambda: None
    gen.value = "("
    gen.type = token.OP

    def make_state() -> NFAState:
        a = NFAState()
        a.addarc(a, "")
        return a

    gen.parse_item = lambda: (make_state(), make_state())
    a, z = gen.parse_alt()
    assert a.arcs == [
        (None, a),
        ("", z),
    ]

    def testit(input):
        gen.value = input[0]
        gen.type = token.OP
        gen.gettoken = iter(input).__next__
        gen.parse_item = lambda: (make_state(), make_state())
        a

# Generated at 2022-06-21 10:22:41.287402
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    parser = _ParserGenerator(tokenize.generate_tokens(io.BytesIO(b"foo").readline))
    a, z = parser.parse_item()
    assert parser.value == "", "parser.value is %r" % parser.value
    assert a.arcs == [(None, z)], "a.arcs is %r" % a.arcs
    assert a.arcs[0][1].arcs == [("foo", z)], "a.arcs[0][1].arcs is %r" % a.arcs[0][1].arcs

    parser = _ParserGenerator(tokenize.generate_tokens(io.BytesIO(b"foo*").readline))
    a, z = parser.parse_item()

# Generated at 2022-06-21 10:22:49.530188
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    p = ParserGenerator()
    p.startsymbol = "s"
    p.dfas = {
        "s": [DFAState({}, False), DFAState({}, True)],
        "s1": [DFAState({}, False), DFAState({}, True)],
        "s2": [DFAState({}, False), DFAState({}, True)],
    }
    p.first = {"s": {"a": 1}, "s1": {"b": 1, "c": 1}, "s2": {"b": 1, "d": 1}}

    c = p.make_converter()
    c.symbol2number = {"s": 1, "s1": 2, "s2": 3}

# Generated at 2022-06-21 10:23:01.309249
# Unit test for method addfirstsets of class ParserGenerator

# Generated at 2022-06-21 10:23:03.028000
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    assert ParserGenerator("").parse_alt() == ({}, {})

# Generated at 2022-06-21 10:23:14.801999
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    import io
    import sys
    import types
    if sys.version_info >= (3, 8):
        # Extract the code object of the test method
        co = test_ParserGenerator_dump_nfa.__code__
    else:
        # Extract the code object of the test method
        co = test_ParserGenerator_dump_nfa.__func__.__code__
    # Get a reference to the underlying bytecode of the code object
    bytecode = co.co_code
    # Generate a token sequence from the bytecode
    tokens = list(tokenize.tokenize(io.BytesIO(bytecode).readline))
    # Remove ENDMARKER from the end
    del tokens[-1]
    # Check that the remaining tokens are the ones we expect

# Generated at 2022-06-21 10:23:23.326281
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    pgen = ParserGenerator()
    a = pgen.NFAState()
    b = pgen.NFAState()
    c = pgen.NFAState()
    d = pgen.NFAState()
    a.addarc(b, 'foo')
    a.addarc(c, 'bar')
    c.addarc(d, None)
    pgen.dump_nfa('name', a, d)

if __name__ == "__main__":
    test_ParserGenerator_dump_nfa()

# Generated at 2022-06-21 10:23:52.741424
# Unit test for constructor of class NFAState
def test_NFAState():
    s = NFAState()
    assert isinstance(s, NFAState)
    assert s.arcs == []

    t = NFAState()
    s.addarc(t)
    assert s.arcs == [(None, t)]

    u = NFAState()
    s.addarc(u, "label")
    assert s.arcs == [(None, t), ("label", u)]


# Generated at 2022-06-21 10:24:05.405959
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    print("test_ParserGenerator_calcfirst")
    pg = ParserGenerator()
    pg.start_rule("r0", "(r1 r2)")
    pg.rule("r1", "a | b")
    pg.rule("r2", "c | d")
    # print pg.rules
    assert pg.startsymbol == "r0"
    assert pg.rules == [
        ("r0", [(["a", "c"], None), (["b", "c"], None), (["a", "d"], None), (["b", "d"], None)]),
        ("r1", [(["a"], None), (["b"], None)]),
        ("r2", [(["c"], None), (["d"], None)]),
    ]
    pg.addfirstsets()

# Generated at 2022-06-21 10:24:09.741622
# Unit test for function generate_grammar
def test_generate_grammar():
    make_dummy_grammar()
    p = ParserGenerator()
    p.make_grammar(tokens=tokens, start="file_input")
    assert p.dfas["single_input"]
    assert p.dfas["file_input"]

# Generated at 2022-06-21 10:24:13.149923
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    generator = ParserGenerator()
    generator.gettoken = lambda: None
    generator.value = "("
    generator.type = token.OP
    a = generator.parse_atom()
    assert a == 1


# Generated at 2022-06-21 10:24:14.855476
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    print("========== Test ParserGenerator ==========")
    ParserGenerator(grammar)

# Generated at 2022-06-21 10:24:25.102181
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    pg = ParserGenerator()
    pg.dfas["file_input"] = [DFAState(), DFAState(), DFAState()]
    pg.dfas["file_input"][0].addarc(pg.dfas["file_input"][1], "NEWLINE")
    pg.dfas["file_input"][0].addarc(pg.dfas["file_input"][2], "stmt")
    pg.dfas["file_input"][1].addarc(pg.dfas["file_input"][2], "stmt")
    pg.dfas["file_input"][2].isfinal = True
    pg.dfas["stmt"] = [DFAState(), DFAState()]

# Generated at 2022-06-21 10:24:36.167973
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    p = ParserGenerator()
    p.generator = tokenize.generate_tokens(io.StringIO(teststring))
    p.gettoken()
    print('ParserGenerator.parse_item()')
    print('   X   |   Y   |  expect  |  result  |')
    print('-----------------------------------')
    #   X   |   Y   |  expect  |  result  |
    p.parse_item()
    p.parse_item()
    p.parse_item()
    p.parse_item()
    p.parse_item()
    p.parse_item()
    p.parse_item()
    p.parse_item()
    p.parse_item()
    p.parse_item()
    p.parse_item()
    p.parse_item()
    p

# Generated at 2022-06-21 10:24:40.607026
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    with open(test_input, "rb") as f:
        p = tokenize.generate_tokens(f.readline)
    assert isinstance(p, Iterator)
    grammar_ = PgenGrammar(p)
    assert isinstance(grammar_, PgenGrammar)



# Generated at 2022-06-21 10:24:46.709680
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    import doctest
    from . import parser

    doctest.testmod(parser)
    if coverage is not None:
        coverage.stop()
        coverage.save()
        print("Coverage report:")
        coverage.report()
        coverage.html_report()


test_ParserGenerator_expect()

# Generated at 2022-06-21 10:24:54.915116
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    import unittest
    from . import test_parser
    from .test_parser import Driver
    from . import token
    import tempfile, sys
    from io import StringIO
    from .pygram import pygram, error
    from . import pytree

    class TestParser(unittest.TestCase):
        def test_pgen_addfirstsets(self):
            driver = Driver("grammar3", test_parser)
            # Copied from test_grammar3.py
            def p_single_input3(p):
                """
                single_input3 ::= NEWLINE | simple_stmt | compound_stmt NEWLINE
                """

            def p_simple_stmt3(p):
                """
                simple_stmt ::= small_stmt (';' small_stmt)* [';'] NEWLINE
                """



# Generated at 2022-06-21 10:25:19.879249
# Unit test for method addarc of class NFAState
def test_NFAState_addarc():
    a = NFAState()
    b = NFAState()
    a.addarc(b, 'label')
    assert a.arcs[0] == ('label', b)
    a.addarc(b)
    assert a.arcs[1] == (None, b)


# Generated at 2022-06-21 10:25:26.884132
# Unit test for function generate_grammar
def test_generate_grammar():
    grammar = generate_grammar()
    assert grammar.dfas
    print("DFA states:", len(grammar.dfas))
    print("DFA first sets:", sum(len(fs) for fs in grammar.first.values()))
    assert not grammar.first["stmt"]["class"]  # can't start with "class"


if __name__ == "__main__":
    test_generate_grammar()

# Generated at 2022-06-21 10:25:32.765970
# Unit test for method addarc of class DFAState
def test_DFAState_addarc():
    """
    >>> s = DFAState({}, NFAState())
    >>> t = DFAState({}, NFAState())
    >>> s.addarc(t, 'label')
    >>> s.arcs
    {'label': <__main__.DFAState object at 0xb7df6cec>}
    """
    pass


# Generated at 2022-06-21 10:25:40.946362
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    pg = ParserGenerator(None)
    def parse(g):
        pg.generator = g
        pg.gettoken()
        return pg.parse_alt()
    # An empty ALT should not give empty NFA
    assert parse(tokenize.generate_tokens("")) == (
        pg.nfastate_struct[0],
        pg.nfastate_struct[1],
    )
    # ITEM: '[' RHS ']' | ATOM ['+' | '*']
    def test_case(input, output):
        assert parse(tokenize.generate_tokens(input + "\n")) == output
    test_case("[foo bar]", (pg.nfastate_struct[0], pg.nfastate_struct[1]))

# Generated at 2022-06-21 10:25:43.800358
# Unit test for constructor of class NFAState
def test_NFAState():
    nfa = NFAState()
    nfa.addarc(NFAState())
    nfa.addarc(NFAState(), 'label')


# Generated at 2022-06-21 10:25:56.159986
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    pg = ParserGenerator()

    class N1(NFAState):
        def __init__(self):
            super().__init__()
            self.n1_a = NFAState()

    s = N1()
    f = NFAState()
    s.n1_a.addarc(f)
    s.addarc(s.n1_a)
    pg.dump_nfa("N1", s, f)

    class N2(NFAState):
        def __init__(self):
            super().__init__()
            self.n2_a = NFAState()
            self.n2_a.n2_b = NFAState()
            self.n2_a.n2_b.addarc(self.n2_a)

    s = N2()
    f

# Generated at 2022-06-21 10:25:59.464494
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    r"""Test case for method make_grammar of class ParserGenerator."""
    raise NotImplementedError("Method not implemented: test_ParserGenerator_make_grammar")

# Generated at 2022-06-21 10:26:10.907329
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    pg = ParserGenerator([])
    dfa = [DFAState({0: 1}, None), DFAState({1: 1}, None), DFAState({1: 1}, None)]
    dfa[0].addarc(dfa[1], "S")
    dfa[0].addarc(dfa[2], "T")
    dfa[1].addarc(dfa[0], "B")
    dfa[2].addarc(dfa[0], "A")
    pg.simplify_dfa(dfa)
    assert dfa[0].arcs == {'A': dfa[0], 'B': dfa[0], 'S': dfa[0], 'T': dfa[0]}

# Generated at 2022-06-21 10:26:19.792816
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    import python_ta
    import pgen2
    import pprint
    import sys
    import os.path

    if len(sys.argv) > 1:
        filename = sys.argv[1]
        if not os.path.exists(filename):
            sys.exit("Input file %s does not exist" % filename)
    else:
        filename = "Python/graminit.c"
    with open(filename, "rb") as f:
        data = f.read()
    pg = pgen2.ParserGenerator(data, filename)
    gr, tok = pg.make_grammar()
    print("Grammar")
    pprint.pprint(gr)
    print("\nTokens")
    pprint.pprint(tok)


if __name__ == "__main__":
    test

# Generated at 2022-06-21 10:26:24.659718
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():
    a = DFAState({1: 1}, 1)
    b = DFAState({2: 2}, 1)
    a.arcs = {1: a, 2: b}
    b.arcs = {1: a, 2: b}
    a.unifystate(b, a)
    assert a.arcs == {1: a, 2: a}
    assert b.arcs == {1: a, 2: a}



# Generated at 2022-06-21 10:27:16.854096
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    from pgen2.grammar import Nonterminal, Production
    from pgen2.pgen import ParserGenerator
    from pgen2.pgen import ParserGeneratorError

    class Rule(Nonterminal):
        def __init__(self, name, parser):
            self.name = name
            self.parser = parser
            self.cfg = self.parser.cfg

    class Eval(Nonterminal):
        def __init__(self, name, parser):
            self.name = name
            self.parser = parser
            self.cfg = self.parser.cfg

    class CFG(object):
        def __init__(self, parser):
            self.parser = parser


# Generated at 2022-06-21 10:27:27.921941
# Unit test for function generate_grammar
def test_generate_grammar():
    grammar = generate_grammar()
    assert grammar.name == "Grammar"
    assert "Grammar" in grammar.states
    assert "Grammar" in grammar.dfas
    assert "file_input" in grammar.states
    assert "file_input" in grammar.dfas
    assert grammar.start == "file_input"
    assert isinstance(grammar.tokens, dict)
    assert isinstance(grammar.keywords, dict)
    assert isinstance(grammar.labels, list)
    assert isinstance(grammar.dfas, dict)
    assert isinstance(grammar.states, dict)
    assert isinstance(grammar.first, dict)

    assert grammar.keywords["and"] == 4
    assert grammar.keywords["or"] == 4
    assert grammar.keywords["not"]

# Generated at 2022-06-21 10:27:39.326559
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    from pgen2.pgen import DFAState
    dfa = [
        DFAState({0: 1}, 0),
        DFAState({1: 1}, 1),
        DFAState({2: 1}, 2),
        DFAState({3: 1}, 3),
    ]
    dfa[0].addarc(dfa[1], 'x')
    dfa[0].addarc(dfa[2], 'y')
    dfa[1].addarc(dfa[3], 'z')

    dfa[2].addarc(dfa[1], 'x')
    dfa[2].addarc(dfa[3], 'z')

    dfa[3].addarc(dfa[2], 'y')
    dfa[3].addarc(dfa[3], 'z')

    Parser

# Generated at 2022-06-21 10:27:49.370677
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    # Test the method calcfirst of class ParserGenerator.
    # calcfirst should compute the set of all the symbols that can
    # appear at the beginning of a string generated by a given rule.
    pg = ParserGenerator()
    pg.calcfirst(
        """
        S: 'a' S 'b'
        S: 'c'
        S:
        """
    )
    assert pg.first["S"] == {"a": 1, "c": 1, None: 1}, pg.first["S"]
    pg = ParserGenerator()
    pg.calcfirst(
        """
        S: S Q Q
        S:
        Q: 'a'
        Q: 'b'
        """
    )
    assert pg.first["S"] == {"a": 1, "b": 1, None: 1}, pg

# Generated at 2022-06-21 10:28:01.450356
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    # This function leaves the DFA indices in an order that's convenient for
    # debugging (the states are numbered in the order they appear in the DFA).
    def simplify_dfa(dfa: List["DFAState"], final: int) -> List["DFAState"]:
        changes = True
        while changes:
            changes = False
            for i, state_i in enumerate(dfa):
                if state_i.isfinal and final not in state_i.arcs:
                    state_i.addarc(dfa[final], 0)
                for j in range(i + 1, len(dfa)):
                    state_j = dfa[j]
                    if state_i == state_j:
                        # print "  unify", i, j
                        del dfa[j]

# Generated at 2022-06-21 10:28:11.089777
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    # This is a test for method dump_nfa of class ParserGenerator.
    pg = ParserGenerator()
    nfa_states = [NFAState() for state in range(6)]
    start, finish = nfa_states[0], nfa_states[5]
    name = "foo"
    nfa_states[0].addarc(nfa_states[1], "x")
    nfa_states[1].addarc(nfa_states[2], "y")
    nfa_states[1].addarc(start)
    nfa_states[2].addarc(nfa_states[3])
    nfa_states[3].addarc(nfa_states[4])
    nfa_states[3].addarc(start)
    nfa_states[4].addarc(finish)

# Generated at 2022-06-21 10:28:16.882586
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():
    # Create this graph:
    #  0 -- a --> 1 -- a --> 2
    #  |      ^         ^      |
    #  |      |         |      |
    #  V      |         |      V
    #  3 <-- b <-- 4 <-- b <-- 5
    a, b, c, d, e, f, g, h, i, j = map(DFAState, range(10))
    a.addarc(b, "a")
    b.addarc(c, "a")
    c.addarc(d, "a")
    d.addarc(e, "a")
    e.addarc(f, "a")
    b.addarc(g, "b")
    g.addarc(h, "b")
    h.addarc(i, "b")
   

# Generated at 2022-06-21 10:28:27.375746
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    # test_parse_atom is a unit test for method parse_atom of class ParserGenerator
    import unittest

    class TestParserGenerator(unittest.TestCase):
        def test_parse_atom(self):
            # To test method parse_atom, we "parse" the string "(foo)"
            # using a dummy generator that returns one token per call:
            # (name, "(", name, ")", None) and test the result.
            p = ParserGenerator()
            p.generator = iter([('(', '('), ('NAME', 'foo'), (')', ')')])
            p.gettoken()
            p.gettoken()
            p.gettoken()
            p.gettoken()
            a, z = p.parse_atom()

# Generated at 2022-06-21 10:28:35.564464
# Unit test for constructor of class DFAState
def test_DFAState():
    # Check the function __eq__ from class DFAState
    a = DFAState({NFAState(): 1}, NFAState())
    b = DFAState({NFAState(): 1}, NFAState())
    c = DFAState({NFAState(): 1}, NFAState())
    d = DFAState({NFAState(): 1}, NFAState())
    assert a != b
    assert a == c
    assert a == d
    d.arcs["label"] = a
    d.isfinal = True
    assert d != c
    assert d == d



# Generated at 2022-06-21 10:28:42.786092
# Unit test for method parse of class ParserGenerator

# Generated at 2022-06-21 10:29:14.681066
# Unit test for constructor of class NFAState
def test_NFAState():
    a = NFAState()
    b = NFAState()
    c = NFAState()
    d = NFAState()
    e = NFAState()
    a.addarc(b)
    a.addarc(c)
    b.addarc(d)
    b.addarc(e, "a")
    e.addarc(d, "b")
    e.addarc(e, "a")
    dfa = PgenParser.make_dfa(a, d)
    PgenParser.dump_dfa("<test>", dfa)
    PgenParser.simplify_dfa(dfa)
    PgenParser.dump_dfa("<test>", dfa)


# Generated at 2022-06-21 10:29:19.971301
# Unit test for constructor of class NFAState
def test_NFAState():
    a = NFAState()
    b = NFAState()
    c = NFAState()

    assert a.arcs == []
    assert b.arcs == []
    assert c.arcs == []

    a.addarc(c, 'c')
    assert a.arcs == [('c', c)]
    b.addarc(a)
    assert b.arcs == [(None, a)]
    c.addarc(b, 'b')
    assert c.arcs == [('b', b)]



# Generated at 2022-06-21 10:29:24.564315
# Unit test for method addarc of class DFAState
def test_DFAState_addarc():
    a = DFAState({},NFAState())
    b = DFAState({},NFAState())

    a.addarc(b,'a')
    assert a.arcs['a'] == b
    

# Generated at 2022-06-21 10:29:28.731875
# Unit test for constructor of class DFAState
def test_DFAState():
    a = DFAState({"aaa":1}, "aaa")
    assert a.nfaset == {"aaa":1}
    assert a.isfinal == True
    b = DFAState({"bbb":1}, "aaa")
    assert a == b
    assert a != DFAState({"bbb":1}, "bbb")


# Generated at 2022-06-21 10:29:29.454360
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    pass

# Generated at 2022-06-21 10:29:39.394953
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    pg = ParserGenerator("test_pgen.py")
    tests = [("expr", {"'*'", "'+'", "'('", "'-'", "NUMBER", "NAME"}),
             ("term", {"'*'", "'('", "NAME", "NUMBER"}),
             ("factor", {"'('", "NAME", "NUMBER"})]
    for nonterm, first in tests:
        pg.calcfirst(nonterm)
        assert pg.first[nonterm] == first
    pg.calcfirst("bogus")
    assert False

# Generated at 2022-06-21 10:29:48.739849
# Unit test for method addarc of class DFAState
def test_DFAState_addarc():
    # test uniqueness constraint
    A = DFAState({}, NFAState())
    B = DFAState({}, NFAState())
    A.addarc(B, 'a')
    with raises(AssertionError, match="'a' not in .*"):
        A.addarc(B, 'a')
    with raises(AssertionError, match="'a' not in .*"):
        A.addarc(A, 'a')
    with raises(AssertionError, match="'a' not in .*"):
        A.unifystate(A, B)
        A.addarc(A, 'a')
    A.unifystate(B, A)
    with raises(AssertionError, match="'a' not in .*"):
        A.addarc(A, 'a')

# Generated at 2022-06-21 10:29:50.455936
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    pg = PgenGrammar()



# Generated at 2022-06-21 10:29:56.840577
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    gen = ParserGenerator()
    gen.add_rhs("a", ["x"])
    dfa, startsymbol = gen.parse()

# Generated at 2022-06-21 10:30:04.705385
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
  with captured_output() as (out, err):
    converted = ParserGenerator.make_grammar(grammar)
    sys.stdout = sys.__stdout__