

# Generated at 2022-06-17 16:51:05.592221
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    pg = ParserGenerator()
    pg.gettoken = lambda: None
    pg.value = "("
    pg.parse_item = lambda: (NFAState(), NFAState())
    pg.parse_alt()
    pg.value = ")"
    pg.parse_alt()
    pg.value = "|"
    pg.parse_alt()
    pg.value = "("
    pg.parse_alt()
    pg.value = ")"
    pg.parse_alt()
    pg.value = "|"
    pg.parse_alt()
    pg.value = "("
    pg.parse_alt()
    pg.value = ")"
    pg.parse_alt()
    pg.value = "|"
    pg.parse_alt()
    pg.value = "("
    pg.parse_alt

# Generated at 2022-06-17 16:51:09.371581
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    pg = ParserGenerator()
    pg.dump_nfa("foo", NFAState(), NFAState())
    pg.dump_nfa("bar", NFAState(), NFAState())


# Generated at 2022-06-17 16:51:17.200581
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    pg = ParserGenerator()
    pg.add_production("start", ["start", "start", "start"])
    pg.add_production("start", ["start", "start", "start"])
    pg.add_production("start", ["start", "start", "start"])
    pg.add_production("start", ["start", "start", "start"])
    pg.add_production("start", ["start", "start", "start"])
    pg.add_production("start", ["start", "start", "start"])
    pg.add_production("start", ["start", "start", "start"])
    pg.add_production("start", ["start", "start", "start"])
    pg.add_production("start", ["start", "start", "start"])

# Generated at 2022-06-17 16:51:21.884433
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    pg = PgenGrammar()
    assert pg.start == "file_input"
    assert pg.keywords == {}
    assert pg.tokens == []
    assert pg.symbol2number == {}
    assert pg.number2symbol == {}
    assert pg.dfas == {}
    assert pg.states == {}
    assert pg.literals == {}
    assert pg.error_func == None
    assert pg.error_func_name == None
    assert pg.type2name == {}
    assert pg.name2type == {}
    assert pg.p_error == None
    assert pg.p_accept == None
    assert pg.startsymbol == None
    assert pg.symbol2label == {}
    assert pg.first == {}
    assert pg.dfa_start == {}
    assert pg.dfa_prefix

# Generated at 2022-06-17 16:51:33.916419
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    pg = ParserGenerator()
    pg.dfas = {
        "a": [DFAState({}, False), DFAState({}, True)],
        "b": [DFAState({}, False), DFAState({}, True)],
        "c": [DFAState({}, False), DFAState({}, True)],
    }
    pg.dfas["a"][0].addarc(pg.dfas["a"][1], "a")
    pg.dfas["a"][0].addarc(pg.dfas["b"][0], "b")
    pg.dfas["b"][0].addarc(pg.dfas["c"][0], "c")
    pg.dfas["c"][0].addarc(pg.dfas["a"][1], "a")
    pg.df

# Generated at 2022-06-17 16:51:43.001592
# Unit test for method simplify_dfa of class ParserGenerator

# Generated at 2022-06-17 16:51:54.546464
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    pg = ParserGenerator()
    pg.gettoken = lambda: None
    pg.value = "a"
    pg.parse_item = lambda: (NFAState(), NFAState())
    a, z = pg.parse_alt()
    assert a.arcs == [(None, z)]
    assert z.arcs == []
    pg.value = "b"
    pg.parse_item = lambda: (NFAState(), NFAState())
    pg.parse_alt()
    assert a.arcs == [(None, z), (None, z)]
    assert z.arcs == []
    pg.value = "c"
    pg.parse_item = lambda: (NFAState(), NFAState())
    pg.parse_alt()

# Generated at 2022-06-17 16:52:01.976638
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    pg = ParserGenerator()
    pg.generator = tokenize.generate_tokens(StringIO("a").readline)
    pg.gettoken()
    a, z = pg.parse_atom()
    assert a.arcs == [(None, z)], a.arcs
    assert z.arcs == [], z.arcs
    assert a.arcs[0][1] is z
    assert a.arcs[0][0] == "a"


# Generated at 2022-06-17 16:52:04.226070
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    pg = ParserGenerator()
    pg.dump_nfa("foo", NFAState(), NFAState())

# Generated at 2022-06-17 16:52:14.557936
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    # Simplify a DFA with a single state.
    dfa = [DFAState({NFAState(): 1}, NFAState())]
    ParserGenerator.simplify_dfa(dfa)
    assert len(dfa) == 1
    # Simplify a DFA with two states that are identical.
    dfa = [DFAState({NFAState(): 1}, NFAState()), DFAState({NFAState(): 1}, NFAState())]
    ParserGenerator.simplify_dfa(dfa)
    assert len(dfa) == 1
    # Simplify a DFA with two states that are different.

# Generated at 2022-06-17 16:53:22.721895
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    pg = ParserGenerator()
    pg.generator = iter([
        (token.NAME, "foo", (0, 0), (0, 3), "foo"),
        (token.OP, "+", (0, 3), (0, 4), ""),
        (token.ENDMARKER, "", (0, 4), (0, 4), ""),
    ])
    pg.gettoken()
    a, z = pg.parse_item()
    assert a.arcs == [(None, z)]
    assert z.arcs == [("foo", None)]
    assert pg.value == "+"
    assert pg.type == token.OP
    assert pg.value == "+"
    assert pg.type == token.OP


# Generated at 2022-06-17 16:53:33.564939
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    pg = ParserGenerator()
    pg.symbol2number = {'foo': 1, 'bar': 2, 'baz': 3}
    pg.labels = [(1, None), (2, None), (3, None)]
    pg.tokens = {token.NAME: 4, token.NUMBER: 5, token.STRING: 6}
    pg.keywords = {'def': 7, 'class': 8}
    c = pg.make_converter()
    assert c.make_label(c, 'foo') == 1
    assert c.make_label(c, 'bar') == 2
    assert c.make_label(c, 'baz') == 3
    assert c.make_label(c, 'NAME') == 4
    assert c.make_label(c, 'NUMBER') == 5
   

# Generated at 2022-06-17 16:53:46.701767
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    import io
    import tokenize
    from typing import Iterator
    from token import TokenInfo

    def tokenize_lines(lines: Iterator[str]) -> Iterator[TokenInfo]:
        for line in lines:
            for tup in tokenize.generate_tokens(io.StringIO(line).readline):
                yield tup

    pg = ParserGenerator()
    pg.generator = tokenize_lines(iter(["# comment\n", "a = 1\n"]))
    pg.gettoken()
    assert pg.type == token.NAME
    assert pg.value == "a"
    pg.gettoken()
    assert pg.type == token.OP
    assert pg.value == "="
    pg.gettoken()
    assert pg.type == token.NUMBER

# Generated at 2022-06-17 16:53:57.704831
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    import io
    import tokenize
    import unittest

    class TestCase(unittest.TestCase):
        def test_parse(self):
            pg = ParserGenerator()
            pg.parse(io.StringIO(test_grammar))
            self.assertEqual(len(pg.dfas), 8)
            self.assertEqual(pg.startsymbol, "file_input")
            self.assertEqual(len(pg.first["file_input"]), 3)
            self.assertEqual(len(pg.first["eval_input"]), 3)
            self.assertEqual(len(pg.first["single_input"]), 3)
            self.assertEqual(len(pg.first["decorator"]), 2)

# Generated at 2022-06-17 16:54:07.368388
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    pg = ParserGenerator()

# Generated at 2022-06-17 16:54:16.929671
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    pg = ParserGenerator()
    a = NFAState()
    z = NFAState()
    a.addarc(z, "a")
    dfa = pg.make_dfa(a, z)
    assert len(dfa) == 2
    assert len(dfa[0].arcs) == 1
    assert len(dfa[1].arcs) == 0
    assert dfa[0].arcs["a"] is dfa[1]
    assert dfa[0].isfinal == False
    assert dfa[1].isfinal == True

    a = NFAState()
    z = NFAState()
    a.addarc(z, "a")
    a.addarc(z, "b")
    dfa = pg.make_dfa(a, z)
    assert len(dfa)

# Generated at 2022-06-17 16:54:27.839210
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    p = ParserGenerator()
    dfa = [
        DFAState({NFAState(): 1}, NFAState()),
        DFAState({NFAState(): 1}, NFAState()),
        DFAState({NFAState(): 1}, NFAState()),
        DFAState({NFAState(): 1}, NFAState()),
        DFAState({NFAState(): 1}, NFAState()),
    ]
    dfa[0].addarc(dfa[1], "a")
    dfa[0].addarc(dfa[2], "b")
    dfa[1].addarc(dfa[3], "c")
    dfa[2].addarc(dfa[3], "c")
    dfa[3].addarc(dfa[4], "d")

# Generated at 2022-06-17 16:54:35.574937
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    pg = ParserGenerator()
    a = NFAState()
    z = NFAState()
    a.addarc(z, "a")
    dfa = pg.make_dfa(a, z)
    assert len(dfa) == 2
    assert len(dfa[0].arcs) == 1
    assert len(dfa[1].arcs) == 0
    assert dfa[0].arcs[0][0] == "a"
    assert dfa[0].arcs[0][1] is dfa[1]
    assert dfa[1].isfinal


# Generated at 2022-06-17 16:54:42.804290
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    pg = ParserGenerator()
    pg.generator = iter([(token.NAME, "a", (1, 0), (1, 1), "a")])
    pg.gettoken()
    assert pg.parse_item() == (NFAState([(None, NFAState([("a", NFAState([]))]))]),
                               NFAState([]))
    pg.generator = iter([(token.NAME, "a", (1, 0), (1, 1), "a"),
                         (token.OP, "+", (1, 1), (1, 2), "a+")])
    pg.gettoken()
    a, z = pg.parse_item()
    assert a == NFAState([(None, NFAState([("a", NFAState([]))]))])

# Generated at 2022-06-17 16:54:53.767191
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    pg = ParserGenerator()
    pg.dfas = {
        "a": [DFAState({}, False), DFAState({}, True)],
        "b": [DFAState({}, False), DFAState({}, True)],
        "c": [DFAState({}, False), DFAState({}, True)],
    }
    pg.dfas["a"][0].addarc(pg.dfas["b"][0], "x")
    pg.dfas["a"][0].addarc(pg.dfas["c"][0], "y")
    pg.dfas["b"][0].addarc(pg.dfas["c"][0], "z")
    pg.startsymbol = "a"
    pg.addfirstsets()

# Generated at 2022-06-17 16:55:49.795690
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    import io
    import tokenize
    import unittest
    from test.support import captured_stdout

    class TestParserGenerator(unittest.TestCase):
        def test_gettoken(self):
            pg = ParserGenerator()
            with captured_stdout() as stdout:
                pg.gettoken()
            self.assertEqual(stdout.getvalue(), "")
            self.assertEqual(pg.type, tokenize.ENDMARKER)
            self.assertEqual(pg.value, "")
            self.assertEqual(pg.begin, (1, 0))
            self.assertEqual(pg.end, (1, 0))
            self.assertEqual(pg.line, "")
            with captured_stdout() as stdout:
                pg.gettoken()

# Generated at 2022-06-17 16:55:55.852701
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    import io
    import token
    import tokenize
    import unittest
    import unittest.mock

    from . import grammar
    from . import pgen2


# Generated at 2022-06-17 16:56:06.748331
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    pg = ParserGenerator()
    pg.filename = "test"
    pg.line = "line"
    pg.type = token.NAME
    pg.value = "value"
    pg.begin = (1, 2)
    pg.end = (3, 4)
    pg.gettoken = lambda: None
    pg.raise_error = lambda msg, *args: None
    pg.expect(token.NAME)
    pg.expect(token.NAME, "value")
    try:
        pg.expect(token.NAME, "other")
    except SyntaxError:
        pass
    else:
        assert False, "expected SyntaxError"
    try:
        pg.expect(token.OP, "value")
    except SyntaxError:
        pass

# Generated at 2022-06-17 16:56:19.251549
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    pg = ParserGenerator()
    pg.add_production("start", ["a", "b"])
    pg.add_production("start", ["a", "c"])
    pg.add_production("a", ["d"])
    pg.add_production("a", ["e"])
    pg.add_production("b", ["f"])
    pg.add_production("b", ["g"])
    pg.add_production("c", ["h"])
    pg.add_production("c", ["i"])
    pg.add_production("d", ["j"])
    pg.add_production("d", ["k"])
    pg.add_production("e", ["l"])
    pg.add_production("e", ["m"])
    pg.add_production("f", ["n"])
    pg

# Generated at 2022-06-17 16:56:29.981732
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    pg = ParserGenerator()
    pg.dfas = {
        "a": [DFAState({NFAState(): 1}, False), DFAState({NFAState(): 1}, True)],
        "b": [DFAState({NFAState(): 1}, False), DFAState({NFAState(): 1}, True)],
        "c": [DFAState({NFAState(): 1}, False), DFAState({NFAState(): 1}, True)],
    }
    pg.first = {
        "a": {"a": 1, "b": 1},
        "b": {"c": 1},
        "c": {"c": 1},
    }
    c = pg.make_converter()
    assert c.labels == [(1, "a"), (1, "b"), (1, "c")]

# Generated at 2022-06-17 16:56:36.154700
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    pg = ParserGenerator()
    pg.symbol2number = {"foo": 1, "bar": 2, "baz": 3}
    pg.labels = []
    pg.symbol2label = {}
    pg.tokens = {token.NAME: 4, token.NUMBER: 5, token.STRING: 6}
    pg.keywords = {"def": 7, "class": 8}
    c = pg.make_converter()
    assert c.symbol2number == {"foo": 1, "bar": 2, "baz": 3}
    assert c.labels == []
    assert c.symbol2label == {}
    assert c.tokens == {token.NAME: 4, token.NUMBER: 5, token.STRING: 6}

# Generated at 2022-06-17 16:56:46.259847
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    pg = ParserGenerator()
    pg.make_scanner()
    pg.make_parser()
    pg.dump_dfa("file_input", pg.dfas["file_input"])
    pg.dump_dfa("eval_input", pg.dfas["eval_input"])
    pg.dump_dfa("single_input", pg.dfas["single_input"])
    pg.dump_dfa("decorator", pg.dfas["decorator"])
    pg.dump_dfa("decorators", pg.dfas["decorators"])
    pg.dump_dfa("decorated", pg.dfas["decorated"])
    pg.dump_dfa("async_funcdef", pg.dfas["async_funcdef"])

# Generated at 2022-06-17 16:56:48.230160
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    pg = ParserGenerator()
    pg.parse()


# Generated at 2022-06-17 16:56:55.521484
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    pg = ParserGenerator()
    a = NFAState()
    z = NFAState()
    a.addarc(z, "a")
    a.addarc(z, "b")
    dfa = pg.make_dfa(a, z)
    assert len(dfa) == 2
    assert len(dfa[0].arcs) == 2
    assert len(dfa[1].arcs) == 0


# Generated at 2022-06-17 16:57:01.954756
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    from . import pgen2
    from . import token
    from . import grammar

    class DummyConverter:
        def __init__(self):
            self.labels = []
            self.symbol2number = {}
            self.symbol2label = {}
            self.tokens = {}
            self.keywords = {}

    c = DummyConverter()
    pg = pgen2.ParserGenerator()
    pg.make_label(c, "NAME")
    pg.make_label(c, "NUMBER")
    pg.make_label(c, "STRING")
    pg.make_label(c, "foo")
    pg.make_label(c, "bar")
    pg.make_label(c, "'+'")
    pg.make_label(c, "'-'")


# Generated at 2022-06-17 16:58:02.951356
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    import pgen2.pgen
    from pgen2.pgen import ParserGenerator
    from pgen2.pgen import PgenGrammar
    from pgen2.pgen import DFAState
    from pgen2.pgen import NFAState
    from pgen2.pgen import token
    from pgen2.pgen import grammar
    from pgen2.pgen import tokenize
    from pgen2.pgen import token
    from pgen2.pgen import grammar
    from pgen2.pgen import tokenize
    from pgen2.pgen import token
    from pgen2.pgen import grammar
    from pgen2.pgen import tokenize
    from pgen2.pgen import token
    from pgen2.pgen import grammar
    from pgen2.pgen import tokenize

# Generated at 2022-06-17 16:58:10.396652
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    import pgen2.pgen
    import pgen2.driver
    import pgen2.parse
    import pgen2.tokenize
    import pgen2.grammar
    import pgen2.convert
    import pgen2.pgen
    import pgen2.driver
    import pgen2.parse
    import pgen2.tokenize
    import pgen2.grammar
    import pgen2.convert
    import pgen2.pgen
    import pgen2.driver
    import pgen2.parse
    import pgen2.tokenize
    import pgen2.grammar
    import pgen2.convert
    import pgen2.pgen
    import pgen2.driver
    import pgen2.parse
    import pgen2.tokenize
    import pgen2.grammar


# Generated at 2022-06-17 16:58:22.332388
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    pg = ParserGenerator()
    pg.gettoken = lambda: None
    pg.value = '('
    pg.type = token.OP
    pg.parse_rhs = lambda: (NFAState(), NFAState())
    pg.expect = lambda type, value: None
    pg.parse_item()
    pg.value = '['
    pg.parse_item()
    pg.value = 'NAME'
    pg.type = token.NAME
    pg.parse_item()
    pg.value = 'STRING'
    pg.type = token.STRING
    pg.parse_item()
    pg.value = '+'
    pg.parse_item()
    pg.value = '*'
    pg.parse_item()
    pg.value = ')'
    pg.parse_item()
    pg

# Generated at 2022-06-17 16:58:34.814505
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    pg = ParserGenerator()
    pg.dfas = {
        "a": [DFAState({}, False), DFAState({}, True)],
        "b": [DFAState({}, False), DFAState({}, True)],
        "c": [DFAState({}, False), DFAState({}, True)],
    }
    pg.first = {"a": {"a": 1}, "b": {"b": 1}, "c": {"c": 1}}
    c = pg.make_converter()
    assert c.symbol2number == {"a": 0, "b": 1, "c": 2}
    assert c.symbol2label == {"a": 3, "b": 4, "c": 5}

# Generated at 2022-06-17 16:58:44.867544
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    pg = ParserGenerator()
    pg.dfas = {
        "a": [DFAState({}, False), DFAState({}, True)],
        "b": [DFAState({}, False), DFAState({}, True)],
        "c": [DFAState({}, False), DFAState({}, True)],
    }
    pg.dfas["a"][0].addarc(pg.dfas["b"][0], "b")
    pg.dfas["a"][0].addarc(pg.dfas["c"][0], "c")
    pg.dfas["b"][0].addarc(pg.dfas["c"][0], "c")
    pg.startsymbol = "a"
    pg.addfirstsets()

# Generated at 2022-06-17 16:58:53.835026
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    pg = ParserGenerator()
    pg.filename = "test_ParserGenerator_raise_error"
    pg.end = (1, 2)
    pg.line = "line"
    try:
        pg.raise_error("msg %s %s", "arg1", "arg2")
    except SyntaxError as e:
        assert e.msg == "msg arg1 arg2"
        assert e.filename == "test_ParserGenerator_raise_error"
        assert e.lineno == 1
        assert e.offset == 2
        assert e.text == "line"
    else:
        assert False, "Expected SyntaxError"



# Generated at 2022-06-17 16:59:06.247582
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    import io
    import tokenize
    import unittest
    from test.support import captured_stderr, captured_stdout

    class ParserGeneratorTestCase(unittest.TestCase):
        def test_raise_error(self):
            # Test that the error message contains the line number
            # and the line itself.
            pg = ParserGenerator()
            pg.filename = "test_raise_error"
            pg.end = (1, 2)
            pg.line = "line 1\nline 2"
            with captured_stderr() as stderr:
                with self.assertRaises(SyntaxError):
                    pg.raise_error("test %s", "message")
            self.assertEqual(stderr.getvalue(), "test message\n")
            # Test that the error message contains the

# Generated at 2022-06-17 16:59:13.135045
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    pg = ParserGenerator()
    a = NFAState()
    z = NFAState()
    a.addarc(z, "a")
    dfa = pg.make_dfa(a, z)
    assert len(dfa) == 2
    assert dfa[0].arcs == {"a": dfa[1]}
    assert dfa[1].arcs == {}
    assert dfa[0].nfaset == {a: 1, z: 1}
    assert dfa[1].nfaset == {z: 1}
    assert dfa[0].isfinal == False
    assert dfa[1].isfinal == True

    a = NFAState()
    z = NFAState()
    a.addarc(z, "a")
    a.addarc(z, "b")
   

# Generated at 2022-06-17 16:59:17.631916
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    pg = ParserGenerator()
    pg.dfas = {'foo': [DFAState({NFAState(): 1}, NFAState()), DFAState({NFAState(): 1}, NFAState())]}
    pg.dump_dfa('foo', pg.dfas['foo'])


# Generated at 2022-06-17 16:59:27.996885
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    import io
    import tokenize
    from typing import Iterator, Tuple
    from . import ParserGenerator
    from . import NFAState
    from . import DFAState

    def tokenize_string(s: str) -> Iterator[Tuple[int, str, Tuple[int, int], Tuple[int, int], str]]:
        return tokenize.tokenize(io.BytesIO(s.encode("utf-8")).readline)

    def test(s: str, expected: Tuple[NFAState, NFAState]) -> None:
        generator = tokenize_string(s)
        parser = ParserGenerator(generator, "<string>")
        a, z = parser.parse_atom()
        assert a == expected[0]
        assert z == expected[1]
