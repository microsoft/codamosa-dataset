

# Generated at 2022-06-17 16:51:42.000882
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    pg = ParserGenerator()
    pg.add_production("a", "b c")
    pg.add_production("b", "d")
    pg.add_production("b", "e")
    pg.add_production("c", "f")
    pg.add_production("c", "g")
    pg.add_production("d", "h")
    pg.add_production("e", "i")
    pg.add_production("f", "j")
    pg.add_production("g", "k")
    pg.add_production("h", "l")
    pg.add_production("i", "m")
    pg.add_production("j", "n")
    pg.add_production("k", "o")
    pg.add_production("l", "p")

# Generated at 2022-06-17 16:51:54.004167
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    import io
    import tokenize
    from typing import Any, Iterator, Tuple
    from . import ParserGenerator

    class MockParserGenerator(ParserGenerator):
        def __init__(self, filename: str, text: str) -> None:
            self.filename = filename
            self.generator = tokenize.generate_tokens(io.StringIO(text).readline)
            self.gettoken()

        def gettoken(self) -> None:
            tup = next(self.generator)
            while tup[0] in (tokenize.COMMENT, tokenize.NL):
                tup = next(self.generator)
            self.type, self.value, self.begin, self.end, self.line = tup
            # print token.tok_name[self.type], repr(

# Generated at 2022-06-17 16:52:05.249461
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    pg = ParserGenerator()
    pg.parse_rhs()
    pg.parse_rhs()
    pg.parse_rhs()
    pg.parse_rhs()
    pg.parse_rhs()
    pg.parse_rhs()
    pg.parse_rhs()
    pg.parse_rhs()
    pg.parse_rhs()
    pg.parse_rhs()
    pg.parse_rhs()
    pg.parse_rhs()
    pg.parse_rhs()
    pg.parse_rhs()
    pg.parse_rhs()
    pg.parse_rhs()
    pg.parse_rhs()
    pg.parse_rhs()
    pg.parse_rhs()
    pg.parse_rhs()
    pg.parse_rhs()
   

# Generated at 2022-06-17 16:52:16.709485
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    pg = ParserGenerator()
    a = NFAState()
    z = NFAState()
    a.addarc(z, "a")
    dfa = pg.make_dfa(a, z)
    assert len(dfa) == 2
    assert dfa[0].nfaset == {a: 1}
    assert dfa[1].nfaset == {z: 1}
    assert dfa[0].arcs == {"a": dfa[1]}
    assert dfa[1].arcs == {}

    a = NFAState()
    z = NFAState()
    a.addarc(z, "a")
    a.addarc(z, "b")
    dfa = pg.make_dfa(a, z)
    assert len(dfa) == 2
    assert d

# Generated at 2022-06-17 16:52:26.334402
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    pg = ParserGenerator()
    pg.dump_dfa("foo", [DFAState({}, None)])
    pg.dump_dfa("foo", [DFAState({}, None), DFAState({}, None)])
    pg.dump_dfa("foo", [DFAState({}, None), DFAState({}, None), DFAState({}, None)])
    pg.dump_dfa("foo", [DFAState({}, None), DFAState({}, None), DFAState({}, None)])
    pg.dump_dfa("foo", [DFAState({}, None), DFAState({}, None), DFAState({}, None)])
    pg.dump_dfa("foo", [DFAState({}, None), DFAState({}, None), DFAState({}, None)])
    pg.dump_dfa

# Generated at 2022-06-17 16:52:38.566946
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    pg = ParserGenerator()
    pg.gettoken = lambda: None
    pg.value = "("
    pg.type = token.OP
    pg.parse_item = lambda: (NFAState(), NFAState())
    pg.parse_alt()
    pg.parse_alt()
    pg.parse_alt()
    pg.parse_alt()
    pg.parse_alt()
    pg.parse_alt()
    pg.parse_alt()
    pg.parse_alt()
    pg.parse_alt()
    pg.parse_alt()
    pg.parse_alt()
    pg.parse_alt()
    pg.parse_alt()
    pg.parse_alt()
    pg.parse_alt()
    pg.parse_alt()
    pg.parse_alt()
    pg.parse_alt()


# Generated at 2022-06-17 16:52:42.574395
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    import pgen2.pgen
    p = pgen2.pgen.ParserGenerator()
    p.make_first(None, "")


# Generated at 2022-06-17 16:52:56.090491
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    pg = ParserGenerator()
    pg.dfas = {
        "a": [DFAState({}, False), DFAState({}, False)],
        "b": [DFAState({}, False), DFAState({}, False)],
        "c": [DFAState({}, False), DFAState({}, False)],
    }
    pg.first = {
        "a": {"a": 1, "b": 1},
        "b": {"c": 1},
        "c": {"a": 1, "b": 1, "c": 1},
    }
    c = pg.make_converter()
    assert c.labels == [(token.NAME, "a"), (token.NAME, "b"), (token.NAME, "c")]

# Generated at 2022-06-17 16:53:09.045059
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    pg = ParserGenerator()
    pg.add_nonterminal("foo", "bar")
    pg.add_nonterminal("bar", "baz")
    pg.add_nonterminal("bar", "baz", "quux")
    pg.add_nonterminal("bar", "baz", "quux", "xyzzy")
    pg.add_nonterminal("bar", "baz", "quux", "xyzzy", "plugh")
    pg.add_nonterminal("bar", "baz", "quux", "xyzzy", "plugh", "thud")
    pg.add_nonterminal("bar", "baz", "quux", "xyzzy", "plugh", "thud", "foo")

# Generated at 2022-06-17 16:53:20.309506
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    pg = ParserGenerator()

# Generated at 2022-06-17 16:54:18.009125
# Unit test for method parse_rhs of class ParserGenerator

# Generated at 2022-06-17 16:54:28.541279
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    # XXX This is a bit of a hack; we should really be testing the
    # output of the parser generator, not the input to the parser.
    # But it's better than nothing.
    pg = ParserGenerator()
    pg.add_production("file_input", ["NEWLINE", "stmt", "NEWLINE"])
    pg.add_production("file_input", ["NEWLINE"])
    pg.add_production("stmt", ["simple_stmt"])
    pg.add_production("stmt", ["compound_stmt"])
    pg.add_production("simple_stmt", ["small_stmt", "SEMI", "NEWLINE"])

# Generated at 2022-06-17 16:54:38.383121
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    pg = ParserGenerator()
    pg.dfas = {
        "a": [DFAState({}, False), DFAState({}, False)],
        "b": [DFAState({}, False), DFAState({}, False)],
        "c": [DFAState({}, False), DFAState({}, False)],
    }
    pg.dfas["a"][0].addarc(pg.dfas["a"][1], "a")
    pg.dfas["a"][0].addarc(pg.dfas["b"][0], "b")
    pg.dfas["b"][0].addarc(pg.dfas["c"][0], "c")
    pg.dfas["c"][0].addarc(pg.dfas["a"][0], "a")
    pg.df

# Generated at 2022-06-17 16:54:43.262332
# Unit test for function generate_grammar
def test_generate_grammar():
    p = ParserGenerator("Grammar.txt")
    g = p.make_grammar()
    assert g.start == "file_input"

# Generated at 2022-06-17 16:54:47.013146
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    pg = ParserGenerator()
    pg.dump_nfa("foo", NFAState(), NFAState())

# Generated at 2022-06-17 16:54:54.005177
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    pg = ParserGenerator()
    a = NFAState()
    z = NFAState()
    a.addarc(z, "a")
    a.addarc(z, "b")
    dfa = pg.make_dfa(a, z)
    assert len(dfa) == 2
    assert len(dfa[0].arcs) == 2
    assert dfa[0].arcs["a"] is dfa[1]
    assert dfa[0].arcs["b"] is dfa[1]
    assert dfa[1].arcs == {}
    assert dfa[1].isfinal


# Generated at 2022-06-17 16:55:02.704482
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    import io
    import sys
    import unittest
    from test.support import captured_stdout

    class ParserGenerator_dump_dfa(unittest.TestCase):
        def test_0(self):
            pg = ParserGenerator()
            pg.add_rhs("foo", ["bar", "baz"])
            pg.add_rhs("bar", ["'a'", "'b'"])
            pg.add_rhs("baz", ["'c'", "'d'"])
            pg.add_rhs("baz", ["'e'", "'f'"])
            pg.add_rhs("baz", ["'g'", "'h'"])
            pg.add_rhs("baz", ["'i'", "'j'"])

# Generated at 2022-06-17 16:55:13.000741
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    pg = ParserGenerator()
    pg.add_production("a", "b c")
    pg.add_production("b", "d | e")
    pg.add_production("c", "f | g")
    pg.add_production("d", "h")
    pg.add_production("e", "i")
    pg.add_production("f", "j")
    pg.add_production("g", "k")
    pg.add_production("h", "l")
    pg.add_production("i", "m")
    pg.add_production("j", "n")
    pg.add_production("k", "o")
    pg.add_production("l", "p")
    pg.add_production("m", "q")
    pg.add_production("n", "r")

# Generated at 2022-06-17 16:55:24.894287
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    # Test that ParserGenerator.dump_dfa() works as expected
    pg = ParserGenerator()

# Generated at 2022-06-17 16:55:37.271713
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    pg = ParserGenerator()
    pg.parse_item()
    pg.parse_item()
    pg.parse_item()
    pg.parse_item()
    pg.parse_item()
    pg.parse_item()
    pg.parse_item()
    pg.parse_item()
    pg.parse_item()
    pg.parse_item()
    pg.parse_item()
    pg.parse_item()
    pg.parse_item()
    pg.parse_item()
    pg.parse_item()
    pg.parse_item()
    pg.parse_item()
    pg.parse_item()
    pg.parse_item()
    pg.parse_item()
    pg.parse_item()
    pg.parse_item()
    pg.parse_item()
    pg.parse_item

# Generated at 2022-06-17 16:57:21.959610
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    p = ParserGenerator()
    dfa = [
        DFAState({NFAState(): 1}, NFAState()),
        DFAState({NFAState(): 1}, NFAState()),
        DFAState({NFAState(): 1}, NFAState()),
        DFAState({NFAState(): 1}, NFAState()),
        DFAState({NFAState(): 1}, NFAState()),
        DFAState({NFAState(): 1}, NFAState()),
        DFAState({NFAState(): 1}, NFAState()),
        DFAState({NFAState(): 1}, NFAState()),
        DFAState({NFAState(): 1}, NFAState()),
        DFAState({NFAState(): 1}, NFAState()),
    ]

# Generated at 2022-06-17 16:57:33.016872
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    import tokenize
    import io
    import sys
    import unittest
    import unittest.mock

    class TestCase(unittest.TestCase):
        def test_gettoken(self):
            with unittest.mock.patch.object(sys, "stdin", io.StringIO("1+1")):
                pg = ParserGenerator()
                pg.gettoken()
                self.assertEqual(pg.type, tokenize.NUMBER)
                self.assertEqual(pg.value, "1")
                pg.gettoken()
                self.assertEqual(pg.type, tokenize.OP)
                self.assertEqual(pg.value, "+")
                pg.gettoken()
                self.assertEqual(pg.type, tokenize.NUMBER)
                self.assertEqual

# Generated at 2022-06-17 16:57:41.480466
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    pg = ParserGenerator()

# Generated at 2022-06-17 16:57:50.921890
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    pg = ParserGenerator()
    pg.generator = tokenize.generate_tokens(StringIO("foo").readline)
    pg.gettoken()
    assert pg.value == "foo"
    a, z = pg.parse_atom()
    assert a.arcs == [(None, z), ("foo", z)]
    assert z.arcs == []
    pg.gettoken()
    assert pg.type == token.ENDMARKER

# Generated at 2022-06-17 16:57:55.702388
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    pg = ParserGenerator()
    pg.filename = "test"
    pg.line = "x : a b c | d e f"
    pg.generator = tokenize.generate_tokens(StringIO(pg.line).readline)
    pg.gettoken()
    a, z = pg.parse_rhs()
    assert a.arcs == [(None, a.next[0]), (None, a.next[1])]
    assert a.next[0].arcs == [("a", a.next[0].next[0])]
    assert a.next[0].next[0].arcs == [("b", a.next[0].next[0].next[0])]
    assert a.next[0].next[0].next[0].arcs == [("c", z)]

# Generated at 2022-06-17 16:58:06.224183
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    pg = ParserGenerator()
    pg.add_production("start", ["a", "b"])
    pg.add_production("start", ["c", "d"])
    pg.add_production("start", ["e"])
    pg.add_production("start", ["f", "g"])
    pg.add_production("start", ["h", "i", "j"])
    pg.add_production("start", ["k", "l", "m", "n"])
    pg.add_production("start", ["o", "p", "q", "r", "s"])
    pg.add_production("start", ["t", "u", "v", "w", "x", "y"])
    pg.add_production("start", ["z"])

# Generated at 2022-06-17 16:58:16.483740
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    import sys
    import io
    import tokenize
    import token
    import grammar
    import pgen2.pgen
    import pgen2.parse
    import pgen2.driver
    import pgen2.token
    import pgen2.convert
    import pgen2.pgen
    import pgen2.parse
    import pgen2.driver
    import pgen2.token
    import pgen2.convert
    import pgen2.pgen
    import pgen2.parse
    import pgen2.driver
    import pgen2.token
    import pgen2.convert
    import pgen2.pgen
    import pgen2.parse
    import pgen2.driver
    import pgen2.token
    import pgen2.convert
    import pgen2.pgen
   

# Generated at 2022-06-17 16:58:26.306279
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    pg = ParserGenerator()
    pg.dfas = {
        "a": [DFAState({}, False), DFAState({}, False)],
        "b": [DFAState({}, False), DFAState({}, False)],
        "c": [DFAState({}, False), DFAState({}, False)],
    }
    pg.dfas["a"][0].addarc(pg.dfas["b"][0], "b")
    pg.dfas["a"][0].addarc(pg.dfas["c"][0], "c")
    pg.dfas["b"][0].addarc(pg.dfas["c"][0], "c")
    pg.dfas["b"][1].addarc(pg.dfas["c"][1], "c")
    pg.df

# Generated at 2022-06-17 16:58:38.606506
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    pg = ParserGenerator()
    pg.gettoken = lambda: None
    pg.value = "("
    pg.parse_item = lambda: (NFAState(), NFAState())
    pg.parse_alt()
    pg.value = "("
    pg.parse_alt()
    pg.value = "("
    pg.parse_alt()
    pg.value = "("
    pg.parse_alt()
    pg.value = "("
    pg.parse_alt()
    pg.value = "("
    pg.parse_alt()
    pg.value = "("
    pg.parse_alt()
    pg.value = "("
    pg.parse_alt()
    pg.value = "("
    pg.parse_alt()
    pg.value = "("
    pg.parse_alt()
   

# Generated at 2022-06-17 16:58:41.071227
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    pg = ParserGenerator()
    pg.parse()
