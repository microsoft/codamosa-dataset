

# Generated at 2022-06-17 16:50:56.751492
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    assert PgenGrammar



# Generated at 2022-06-17 16:51:09.463050
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    import io
    import tokenize
    from typing import Iterator
    from typing import Tuple
    from typing import Union
    from typing import cast
    from typing import Any
    from typing import List
    from typing import Optional
    from typing import Text
    from typing import Dict
    from typing import Sequence
    from typing import TypeVar
    from typing import Callable
    from typing import cast
    from typing import TYPE_CHECKING
    from typing import overload
    from typing import Generic
    from typing import Type
    from typing import Union
    from typing import Any
    from typing import Tuple
    from typing import List
    from typing import Optional
    from typing import Text
    from typing import Dict
    from typing import Sequence
    from typing import TypeVar
    from typing import Callable
    from typing import cast
    from typing import TYPE_CHECKING
   

# Generated at 2022-06-17 16:51:17.248203
# Unit test for method __eq__ of class DFAState
def test_DFAState___eq__():
    a = DFAState({}, None)
    b = DFAState({}, None)
    assert a == b
    a.isfinal = True
    assert a != b
    b.isfinal = True
    assert a == b
    a.arcs["foo"] = a
    assert a != b
    b.arcs["foo"] = b
    assert a == b
    a.arcs["bar"] = a
    assert a != b
    b.arcs["bar"] = b
    assert a == b
    b.arcs["foo"] = b.arcs["bar"]
    assert a != b
    a.arcs["foo"] = a.arcs["bar"]
    assert a == b
    a.arcs["bar"] = a
    assert a != b
    b.arcs["bar"] = b
   

# Generated at 2022-06-17 16:51:29.138164
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    # This is a test for the method simplify_dfa of class ParserGenerator.
    # It is not run automatically.
    import unittest

    class TestCase(unittest.TestCase):
        def test_simplify_dfa(self):
            # This is a test for the method simplify_dfa of class ParserGenerator.
            # It is not run automatically.
            pg = ParserGenerator()
            pg.add_rhs("a", "b")
            pg.add_rhs("b", "c")
            pg.add_rhs("c", "d")
            pg.add_rhs("d", "e")
            pg.add_rhs("e", "f")
            pg.add_rhs("f", "g")
            pg.add_rhs("g", "h")

# Generated at 2022-06-17 16:51:34.501769
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    pg = ParserGenerator()
    pg.type = token.NAME
    pg.value = "foo"
    pg.gettoken = lambda: None
    pg.parse_item = lambda: (None, None)
    pg.parse_alt()


# Generated at 2022-06-17 16:51:43.326517
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    import io
    import tokenize
    import unittest


# Generated at 2022-06-17 16:51:49.731674
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    pg = ParserGenerator()
    pg.dump_nfa("foo", NFAState(), NFAState())
    pg.dump_nfa("bar", NFAState(), NFAState())
    pg.dump_nfa("baz", NFAState(), NFAState())


# Generated at 2022-06-17 16:51:57.164436
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    pg = ParserGenerator()
    a = NFAState()
    b = NFAState()
    c = NFAState()
    d = NFAState()
    a.addarc(b, "a")
    a.addarc(c, "b")
    b.addarc(d, "c")
    c.addarc(d, "d")
    dfa = pg.make_dfa(a, d)
    assert len(dfa) == 3
    assert dfa[0].arcs == {"a": dfa[1], "b": dfa[2]}
    assert dfa[1].arcs == {"c": dfa[2]}
    assert dfa[2].arcs == {"d": dfa[2]}

# Generated at 2022-06-17 16:52:08.437456
# Unit test for method simplify_dfa of class ParserGenerator

# Generated at 2022-06-17 16:52:17.030309
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    import tokenize
    from io import StringIO
    from typing import Iterator, Tuple
    from typing import TYPE_CHECKING
    if TYPE_CHECKING:
        from typing import Generator
    def tokenize_string(s: str) -> "Generator[Tuple[int, str, Tuple[int, int], Tuple[int, int], str], None, None]":
        return tokenize.generate_tokens(StringIO(s).readline)
    def test(s: str, expected: List[Tuple[int, str]]) -> None:
        pg = ParserGenerator(tokenize_string(s))
        result = []
        while pg.type != token.ENDMARKER:
            result.append((pg.type, pg.value))
            pg.gettoken()
        assert result == expected
    test

# Generated at 2022-06-17 16:52:48.538308
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    pg = ParserGenerator()
    pg.generator = iter([(token.NAME, "foo", (1, 0), (1, 3), "foo")])
    pg.gettoken()
    assert pg.type == token.NAME
    assert pg.value == "foo"
    assert pg.begin == (1, 0)
    assert pg.end == (1, 3)
    assert pg.line == "foo"


# Generated at 2022-06-17 16:53:01.504489
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    pg = ParserGenerator()
    pg.add_dfa("a", [["b", "c"]])
    pg.add_dfa("b", [["d", "e"]])
    pg.add_dfa("c", [["f", "g"]])
    pg.add_dfa("d", [["h", "i"]])
    pg.add_dfa("e", [["j", "k"]])
    pg.add_dfa("f", [["l", "m"]])
    pg.add_dfa("g", [["n", "o"]])
    pg.add_dfa("h", [["p", "q"]])
    pg.add_dfa("i", [["r", "s"]])
    pg.add_dfa("j", [["t", "u"]])


# Generated at 2022-06-17 16:53:13.162714
# Unit test for method simplify_dfa of class ParserGenerator

# Generated at 2022-06-17 16:53:22.238264
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    pg = ParserGenerator()
    pg.dfas = {
        "a": [DFAState({}, False), DFAState({}, True)],
        "b": [DFAState({}, False), DFAState({}, True)],
        "c": [DFAState({}, False), DFAState({}, True)],
        "d": [DFAState({}, False), DFAState({}, True)],
        "e": [DFAState({}, False), DFAState({}, True)],
    }
    pg.dfas["a"][0].addarc(pg.dfas["b"][0], "a")
    pg.dfas["a"][0].addarc(pg.dfas["c"][0], "b")

# Generated at 2022-06-17 16:53:33.247937
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    pg = ParserGenerator()
    pg.parse_item()
    pg.parse_item()
    pg.parse_item()
    pg.parse_item()
    pg.parse_item()
    pg.parse_item()
    pg.parse_item()
    pg.parse_item()
    pg.parse_item()
    pg.parse_item()
    pg.parse_item()
    pg.parse_item()
    pg.parse_item()
    pg.parse_item()
    pg.parse_item()
    pg.parse_item()
    pg.parse_item()
    pg.parse_item()
    pg.parse_item()
    pg.parse_item()
    pg.parse_item()
    pg.parse_item()
    pg.parse_item()
    pg.parse_item

# Generated at 2022-06-17 16:53:46.318316
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    pg = ParserGenerator()
    pg.generator = tokenize.generate_tokens(io.StringIO("[").readline)
    pg.gettoken()
    assert pg.value == "["
    a, z = pg.parse_atom()
    assert a.arcs == [(None, z)]
    assert z.arcs == []
    pg.generator = tokenize.generate_tokens(io.StringIO("foo").readline)
    pg.gettoken()
    assert pg.value == "foo"
    a, z = pg.parse_atom()
    assert a.arcs == [("foo", z)]
    assert z.arcs == []
    pg.generator = tokenize.generate_tokens(io.StringIO("'foo'").readline)
    pg.gettoken

# Generated at 2022-06-17 16:53:51.572928
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    pg = ParserGenerator()
    pg.dfas = {
        "a": [DFAState({}, False), DFAState({}, False)],
        "b": [DFAState({}, False), DFAState({}, False)],
        "c": [DFAState({}, False), DFAState({}, False)],
    }
    pg.first = {
        "a": {"a": 1, "b": 1},
        "b": {"b": 1},
        "c": {"c": 1},
    }
    c = pg.make_converter()
    assert c.symbol2number["a"] == 0
    assert c.symbol2number["b"] == 1
    assert c.symbol2number["c"] == 2

# Generated at 2022-06-17 16:54:02.876558
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    pg = ParserGenerator()
    pg.gettoken = lambda: None
    pg.type = token.NAME
    pg.value = "foo"
    a, z = pg.parse_atom()
    assert a.arcs == [(None, z)]
    assert z.arcs == []
    assert a.arcs[0][1] is z
    pg.type = token.STRING
    pg.value = "bar"
    a, z = pg.parse_atom()
    assert a.arcs == [(None, z)]
    assert z.arcs == []
    assert a.arcs[0][1] is z
    pg.type = token.OP
    pg.value = "("
    a, z = pg.parse_atom()
    assert a.arcs == [(None, z)]
    assert z.arc

# Generated at 2022-06-17 16:54:07.373225
# Unit test for method parse_item of class ParserGenerator

# Generated at 2022-06-17 16:54:16.983657
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    pg = ParserGenerator()
    pg.make_scanner()
    pg.parse_grammar(GRAMMAR)
    pg.addfirstsets()
    pg.make_parser()
    pg.dump_dfa("file_input", pg.dfas["file_input"])
    pg.dump_dfa("eval_input", pg.dfas["eval_input"])
    pg.dump_dfa("single_input", pg.dfas["single_input"])
    pg.dump_dfa("decorator", pg.dfas["decorator"])
    pg.dump_dfa("decorators", pg.dfas["decorators"])
    pg.dump_dfa("decorated", pg.dfas["decorated"])

# Generated at 2022-06-17 16:55:27.118796
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    pg = ParserGenerator()
    pg.dump_nfa("foo", NFAState(), NFAState())
    pg.dump_nfa("bar", NFAState(), NFAState())
    pg.dump_nfa("baz", NFAState(), NFAState())


# Generated at 2022-06-17 16:55:39.413144
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    import io
    import tokenize
    import unittest
    from test.support import captured_stdout
    from typing import List, Tuple

    class TestCase(unittest.TestCase):
        def test_gettoken(self) -> None:
            pg = ParserGenerator()
            pg.filename = "test_gettoken"
            pg.generator = tokenize.generate_tokens(io.StringIO("a = 1").readline)
            pg.gettoken()
            self.assertEqual(pg.type, token.NAME)
            self.assertEqual(pg.value, "a")
            pg.gettoken()
            self.assertEqual(pg.type, token.OP)
            self.assertEqual(pg.value, "=")
            pg.gettoken()
            self.assertE

# Generated at 2022-06-17 16:55:51.920831
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    g = PgenGrammar()
    assert g.start == "file_input"
    assert g.keywords == {}
    assert g.tokens == {}
    assert g.symbol2label == {}
    assert g.dfas == {}
    assert g.states == {}
    assert g.literals == {}
    assert g.number2symbol == {}
    assert g.symbol2number == {}
    assert g.p_rules == {}
    assert g.p_rules_all == {}
    assert g.p_rules_by_funcs == {}
    assert g.p_argmap == {}
    assert g.p_number2symbol == {}
    assert g.p_symbol2number == {}
    assert g.p_number2file == {}
    assert g.p_file2number == {}
   

# Generated at 2022-06-17 16:56:04.901268
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    pg = ParserGenerator()
    pg.init_grammar()
    pg.gettoken = lambda: None
    pg.value = '('
    pg.type = token.OP
    pg.parse_item()
    pg.value = '['
    pg.type = token.OP
    pg.parse_item()
    pg.value = 'NAME'
    pg.type = token.NAME
    pg.parse_item()
    pg.value = 'STRING'
    pg.type = token.STRING
    pg.parse_item()
    pg.value = '+'
    pg.type = token.OP
    pg.parse_item()
    pg.value = '*'
    pg.type = token.OP
    pg.parse_item()
    pg.value = ')'

# Generated at 2022-06-17 16:56:17.904546
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    pg = ParserGenerator()
    pg.dfas = {
        "a": [DFAState({}, False), DFAState({}, True)],
        "b": [DFAState({}, False), DFAState({}, True)],
        "c": [DFAState({}, False), DFAState({}, True)],
    }
    pg.first = {"a": {"a": 1}, "b": {"b": 1}, "c": {"c": 1}}
    pg.symbol2number = {"a": 1, "b": 2, "c": 3}
    pg.labels = [(1, None), (2, None), (3, None)]
    pg.tokens = {}
    pg.keywords = {}
    c = pg.make_converter()

# Generated at 2022-06-17 16:56:29.915293
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    pg = ParserGenerator()
    pg.add_rule("a", ["b", "c"])
    pg.add_rule("b", ["d", "e"])
    pg.add_rule("c", ["f", "g"])
    pg.add_rule("d", ["h", "i"])
    pg.add_rule("e", ["j", "k"])
    pg.add_rule("f", ["l", "m"])
    pg.add_rule("g", ["n", "o"])
    pg.add_rule("h", ["p", "q"])
    pg.add_rule("i", ["r", "s"])
    pg.add_rule("j", ["t", "u"])
    pg.add_rule("k", ["v", "w"])

# Generated at 2022-06-17 16:56:42.340801
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    pg = ParserGenerator()
    c = pg.make_converter()
    assert c.make_label(c, "NAME") == 0
    assert c.make_label(c, "NUMBER") == 1
    assert c.make_label(c, "STRING") == 2
    assert c.make_label(c, "'+'") == 3
    assert c.make_label(c, "'-'") == 4
    assert c.make_label(c, "'*'") == 5
    assert c.make_label(c, "'/'") == 6
    assert c.make_label(c, "'('") == 7
    assert c.make_label(c, "')'") == 8
    assert c.make_label(c, "'='") == 9

# Generated at 2022-06-17 16:56:44.611083
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    pg = ParserGenerator()
    pg.dump_nfa("foo", NFAState(), NFAState())

# Generated at 2022-06-17 16:56:56.900065
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    p = ParserGenerator()
    c = p.make_converter()
    assert c.make_label(c, "NAME") == 0
    assert c.make_label(c, "NUMBER") == 1
    assert c.make_label(c, "STRING") == 2
    assert c.make_label(c, "if") == 3
    assert c.make_label(c, "elif") == 4
    assert c.make_label(c, "else") == 5
    assert c.make_label(c, "while") == 6
    assert c.make_label(c, "for") == 7
    assert c.make_label(c, "in") == 8
    assert c.make_label(c, "def") == 9
    assert c.make_label(c, "class") == 10

# Generated at 2022-06-17 16:57:09.381184
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    import io
    import tokenize
    from typing import Iterator
    from typing import Tuple
    from typing import Union
    from typing import cast
    from typing import Any
    from typing import List
    from typing import Dict
    from typing import Text
    from typing import Optional
    from typing import Sequence
    from typing import Callable
    from typing import TypeVar
    from typing import Generic
    from typing import overload
    from typing import Type
    from typing import cast
    from typing import TYPE_CHECKING
    from typing import NoReturn
    from typing import NamedTuple
    from typing import NewType
    from typing import Set
    from typing import FrozenSet
    from typing import Mapping
    from typing import Hashable
    from typing import Iterable
    from typing import Iterator
    from typing import Container
    from typing import Sized

# Generated at 2022-06-17 16:59:41.271562
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    """Unit test for constructor of class PgenGrammar"""
    pg = PgenGrammar()
    assert pg.start == "file_input"
    assert pg.keywords == {}
    assert pg.tokens == []
    assert pg.symbol2number == {}
    assert pg.number2symbol == {}
    assert pg.dfas == {}
    assert pg.states == []
    assert pg.literals == {}
    assert pg.symbol2label == {}
    assert pg.first == {}
    assert pg.error_func == None
    assert pg.error_func_name == None
    assert pg.type2tokens == {}
    assert pg.p_rules == {}
    assert pg.p_rules_all == {}
    assert pg.p_rules_opt == {}
    assert pg.p_rules_

# Generated at 2022-06-17 16:59:50.889331
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    pg = ParserGenerator()
    pg.setup("test", "a: 'a'")
    pg.addfirstsets()
    a, z = pg.parse_rhs()
    assert isinstance(a, NFAState)
    assert isinstance(z, NFAState)
    assert a.arcs == [(None, z)]
    assert z.arcs == [("a", None)]
    pg.setup("test", "a: 'a' | 'b'")
    pg.addfirstsets()
    a, z = pg.parse_rhs()
    assert isinstance(a, NFAState)
    assert isinstance(z, NFAState)
    assert a.arcs == [(None, z)]
    assert z.arcs == [("a", None), ("b", None)]

# Generated at 2022-06-17 16:59:51.789713
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    assert PgenGrammar()



# Generated at 2022-06-17 17:00:01.034584
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    pg = ParserGenerator()