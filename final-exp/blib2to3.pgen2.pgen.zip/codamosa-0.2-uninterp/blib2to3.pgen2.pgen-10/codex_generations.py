

# Generated at 2022-06-17 16:51:03.481443
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    pg = ParserGenerator()
    pg.symbol2number = {
        "NAME": 1,
        "NUMBER": 2,
        "STRING": 3,
        "expr": 4,
        "term": 5,
        "factor": 6,
    }
    pg.labels = []
    pg.tokens = {}
    pg.keywords = {}
    pg.symbol2label = {}
    pg.make_label(pg, "NAME")
    pg.make_label(pg, "NUMBER")
    pg.make_label(pg, "STRING")
    pg.make_label(pg, "expr")
    pg.make_label(pg, "term")
    pg.make_label(pg, "factor")
    pg.make_label(pg, '"and"')

# Generated at 2022-06-17 16:51:13.023510
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    # Test that expect raises SyntaxError if the token is not as expected
    pg = ParserGenerator()
    pg.type = token.NAME
    pg.value = "foo"
    pg.filename = "foo.py"
    pg.end = (1, 2)
    pg.line = "foo"
    try:
        pg.expect(token.STRING, "bar")
    except SyntaxError as e:
        assert e.args == ("expected STRING/bar, got NAME/foo", ("foo.py", 1, 2, "foo"))
    else:
        assert False, "expected SyntaxError"



# Generated at 2022-06-17 16:51:18.968829
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    pg = ParserGenerator()
    pg.dfas = {
        "a": [DFAState({}, False), DFAState({}, True)],
        "b": [DFAState({}, False), DFAState({}, True)],
        "c": [DFAState({}, False), DFAState({}, True)],
    }
    pg.dfas["a"][0].addarc(pg.dfas["a"][1], "a")
    pg.dfas["a"][0].addarc(pg.dfas["b"][0], "b")
    pg.dfas["b"][0].addarc(pg.dfas["c"][0], "c")
    pg.dfas["c"][0].addarc(pg.dfas["a"][0], "a")
    pg.df

# Generated at 2022-06-17 16:51:29.964722
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    pg = ParserGenerator()
    pg.setup("foo", "foo : '[' bar ']'")
    pg.gettoken()
    a, z = pg.parse_rhs()
    assert a.arcs == [(None, z)]
    assert z.arcs == []
    assert a.arcs[0][1] is z
    assert z.arcs == []
    assert a.arcs[0][0] is None
    assert a.arcs[0][1] is z
    assert z.arcs == []
    assert a.arcs[0][0] is None
    assert a.arcs[0][1] is z
    assert z.arcs == []
    assert a.arcs[0][0] is None
    assert a.arcs[0][1] is z
    assert z.arcs

# Generated at 2022-06-17 16:51:35.629641
# Unit test for method __eq__ of class DFAState
def test_DFAState___eq__():
    a = DFAState({}, None)
    b = DFAState({}, None)
    assert a == b
    a.arcs = {"a": a}
    assert a != b
    b.arcs = {"a": b}
    assert a == b
    b.arcs = {"a": a}
    assert a == b
    b.arcs = {"a": a, "b": b}
    assert a != b
    a.arcs = {"a": a, "b": a}
    assert a != b
    b.arcs = {"a": a, "b": a}
    assert a == b
    a.isfinal = True
    assert a != b
    b.isfinal = True
    assert a == b
    a.arcs = {"a": a, "b": b}
    assert a

# Generated at 2022-06-17 16:51:43.872438
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    pg = ParserGenerator()

# Generated at 2022-06-17 16:51:51.335840
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    pg = ParserGenerator()
    pg.generator = iter([(token.NAME, "foo", (1, 0), (1, 3), "foo\n")])
    pg.gettoken()
    assert pg.type == token.NAME
    assert pg.value == "foo"
    assert pg.begin == (1, 0)
    assert pg.end == (1, 3)
    assert pg.line == "foo\n"


# Generated at 2022-06-17 16:51:56.285918
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    pg = ParserGenerator()
    pg.dfas = {'x': [DFAState({NFAState(): 1}, NFAState()), DFAState({NFAState(): 1}, NFAState())]}
    pg.dump_dfa('x', pg.dfas['x'])


# Generated at 2022-06-17 16:52:07.701020
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    pg = ParserGenerator()
    pg.dfas = {
        "a": [DFAState({}, False), DFAState({}, False)],
        "b": [DFAState({}, False), DFAState({}, False)],
        "c": [DFAState({}, False), DFAState({}, False)],
        "d": [DFAState({}, False), DFAState({}, False)],
        "e": [DFAState({}, False), DFAState({}, False)],
    }
    pg.dfas["a"][0].addarc(pg.dfas["b"][0], "b")
    pg.dfas["a"][0].addarc(pg.dfas["c"][0], "c")

# Generated at 2022-06-17 16:52:16.567197
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    import tokenize
    import io
    import sys
    import unittest
    import unittest.mock

    class TokenizeMock(unittest.mock.Mock):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.tokens = []

        def tokenize(self, readline):
            for t in self.tokens:
                yield t

    class ParserGeneratorTest(unittest.TestCase):
        def test_gettoken(self):
            pg = ParserGenerator(io.StringIO(""), "")
            pg.generator = TokenizeMock()

# Generated at 2022-06-17 16:52:41.985808
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    pg = ParserGenerator()
    pg.filename = "test_filename"
    pg.end = (1, 2)
    pg.line = "test_line"
    try:
        pg.raise_error("test_msg")
    except SyntaxError as e:
        assert e.msg == "test_msg"
        assert e.filename == "test_filename"
        assert e.lineno == 1
        assert e.offset == 2
        assert e.text == "test_line"
    else:
        assert False, "Expected SyntaxError"

# Generated at 2022-06-17 16:52:53.719668
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    pg = ParserGenerator()
    pg.dfas = {
        "a": [DFAState({}, False), DFAState({}, True)],
        "b": [DFAState({}, False), DFAState({}, True)],
        "c": [DFAState({}, False), DFAState({}, True)],
    }
    pg.first = {"a": {"a": 1}, "b": {"b": 1}, "c": {"c": 1}}
    c = pg.make_converter()
    assert c.first == [{"a": 1}, {"b": 1}, {"c": 1}]

# Generated at 2022-06-17 16:53:06.673077
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    pg = ParserGenerator()
    pg.gettoken = lambda: None
    pg.value = "("
    pg.parse_item = lambda: (NFAState(), NFAState())
    pg.parse_alt()
    pg.value = "("
    pg.parse_alt()
    pg.value = "("
    pg.parse_alt()
    pg.value = "("
    pg.parse_alt()
    pg.value = "("
    pg.parse_alt()
    pg.value = "("
    pg.parse_alt()
    pg.value = "("
    pg.parse_alt()
    pg.value = "("
    pg.parse_alt()
    pg.value = "("
    pg.parse_alt()
    pg.value = "("
    pg.parse_alt()
   

# Generated at 2022-06-17 16:53:12.990989
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    pg = ParserGenerator()
    pg.add_rhs("foo", "bar")
    pg.add_rhs("bar", "baz")
    pg.add_rhs("bar", "qux")
    pg.add_rhs("baz", "quux")
    pg.add_rhs("baz", "corge")
    pg.add_rhs("qux", "grault")
    pg.add_rhs("qux", "garply")
    pg.add_rhs("qux", "waldo")
    pg.add_rhs("qux", "fred")
    pg.add_rhs("quux", "plugh")
    pg.add_rhs("quux", "xyzzy")
    pg.add_rhs("corge", "thud")
    dfa

# Generated at 2022-06-17 16:53:22.160288
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    c = ParserGenerator()
    c.symbol2number = {"foo": 1, "bar": 2}
    c.tokens = {token.NAME: 3, token.NUMBER: 4}
    c.keywords = {"def": 5, "class": 6}
    c.labels = [
        (1, None),
        (2, None),
        (token.NAME, None),
        (token.NUMBER, None),
        (token.NAME, "def"),
        (token.NAME, "class"),
    ]
    c.symbol2label = {"foo": 0, "bar": 1}
    assert c.make_label(c, "foo") == 0
    assert c.make_label(c, "bar") == 1
    assert c.make_label(c, "NAME") == 2
   

# Generated at 2022-06-17 16:53:33.153947
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    pg = ParserGenerator()
    pg.gettoken()
    assert pg.type == token.ENDMARKER
    assert pg.value == ""
    assert pg.begin == (1, 0)
    assert pg.end == (1, 0)
    assert pg.line == ""
    pg.gettoken()
    assert pg.type == token.ENDMARKER
    assert pg.value == ""
    assert pg.begin == (1, 0)
    assert pg.end == (1, 0)
    assert pg.line == ""
    pg.generator = iter([(token.NAME, "foo", (1, 0), (1, 3), "foo")])
    pg.gettoken()
    assert pg.type == token.NAME
    assert pg.value == "foo"
    assert pg.begin == (1, 0)


# Generated at 2022-06-17 16:53:46.239850
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    pg = ParserGenerator()
    pg.dfas = {
        "a": [DFAState({}, False), DFAState({}, False)],
        "b": [DFAState({}, False), DFAState({}, False)],
        "c": [DFAState({}, False), DFAState({}, False)],
    }
    pg.dfas["a"][0].addarc(pg.dfas["a"][1], "a")
    pg.dfas["a"][0].addarc(pg.dfas["b"][0], "b")
    pg.dfas["b"][0].addarc(pg.dfas["c"][0], "c")
    pg.dfas["c"][0].addarc(pg.dfas["a"][0], "a")
    pg.df

# Generated at 2022-06-17 16:53:55.653096
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    pg = ParserGenerator()
    pg.generator = tokenize.generate_tokens(io.StringIO("a b | c d").readline)
    pg.gettoken()
    a, z = pg.parse_rhs()
    assert a.arcs == [(None, a.next)]
    assert a.next.arcs == [("a", a.next.next)]
    assert a.next.next.arcs == [("b", z)]
    assert z.arcs == [(None, z.next)]
    assert z.next.arcs == [("c", z.next.next)]
    assert z.next.next.arcs == [("d", z)]

# Generated at 2022-06-17 16:54:06.099747
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    pg = ParserGenerator()
    pg.add_production("S", ["a", "b", "c"])
    pg.add_production("S", ["d", "e", "f"])
    pg.add_production("S", ["g", "h", "i"])
    pg.add_production("S", ["j", "k", "l"])
    pg.add_production("S", ["m", "n", "o"])
    pg.add_production("S", ["p", "q", "r"])
    pg.add_production("S", ["s", "t", "u"])
    pg.add_production("S", ["v", "w", "x"])
    pg.add_production("S", ["y", "z"])

# Generated at 2022-06-17 16:54:13.317365
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    import tokenize
    from io import StringIO
    from typing import Tuple
    from typing import Iterator
    from typing import Any
    from typing import NoReturn
    from typing import Text
    from typing import Optional
    from typing import Sequence
    from typing import Dict
    from typing import List
    from typing import Set
    from typing import Union
    from typing import TYPE_CHECKING
    from typing import overload
    from typing import Tuple
    from typing import Iterator
    from typing import Any
    from typing import NoReturn
    from typing import Text
    from typing import Optional
    from typing import Sequence
    from typing import Dict
    from typing import List
    from typing import Set
    from typing import Union
    from typing import TYPE_CHECKING
    from typing import overload
    from typing import Tuple
    from typing import Iterator

# Generated at 2022-06-17 16:54:41.285050
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    g = PgenGrammar()
    assert g.start == "file_input"
    assert g.keywords == {}
    assert g.tokens == []
    assert g.literals == []
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.dfas == {}
    assert g.states == {}
    assert g.error_func == None
    assert g.error_recovery == False
    assert g.optimize == True
    assert g.parsing_context == {}
    assert g.parsing_context["single_input"] == False
    assert g.parsing_context["file_input"] == True
    assert g.parsing_context["eval_input"] == False

# Generated at 2022-06-17 16:54:49.854143
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    p = ParserGenerator()
    p.filename = "test_ParserGenerator_raise_error"
    p.end = (1, 2)
    p.line = "line"
    try:
        p.raise_error("msg")
    except SyntaxError as e:
        assert e.msg == "msg"
        assert e.filename == "test_ParserGenerator_raise_error"
        assert e.lineno == 1
        assert e.offset == 2
        assert e.text == "line"
    else:
        assert False, "did not raise"


# Generated at 2022-06-17 16:55:01.494269
# Unit test for constructor of class PgenGrammar

# Generated at 2022-06-17 16:55:12.658945
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    """Unit test for method dump_dfa of class ParserGenerator"""
    import unittest
    import io
    import tokenize
    import token
    import grammar
    import pgen2.pgen

    class TestParserGenerator(unittest.TestCase):
        def test_dump_dfa(self):
            # Test for method dump_dfa( ... )
            pg = pgen2.pgen.ParserGenerator()
            pg.parse(io.StringIO("a: 'a'\n"), "test_dump_dfa")
            pg.dump_dfa("a", pg.dfas["a"])
            # self.assertEqual(expected, pg.dump_dfa("a", pg.dfas["a"]))
            # self.assertRaises(TypeError, pg.dump_dfa, "a

# Generated at 2022-06-17 16:55:15.781011
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    pg = ParserGenerator()
    pg.dump_nfa("foo", NFAState(), NFAState())

# Generated at 2022-06-17 16:55:22.349090
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    pg = ParserGenerator()

# Generated at 2022-06-17 16:55:30.056603
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    pg = ParserGenerator()
    pg.add_rhs("foo", ["bar", "baz"])
    pg.add_rhs("bar", ["'a'", "'b'"])
    pg.add_rhs("baz", ["'c'", "'d'"])
    pg.add_rhs("baz", ["'e'", "'f'"])
    pg.add_rhs("baz", ["'g'", "'h'"])
    pg.add_rhs("baz", ["'i'", "'j'"])
    pg.add_rhs("baz", ["'k'", "'l'"])
    pg.add_rhs("baz", ["'m'", "'n'"])

# Generated at 2022-06-17 16:55:41.386764
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    import io
    import tokenize
    from . import grammar

    def test(s: str, type: int, value: Optional[Any] = None) -> None:
        f = io.StringIO(s)
        g = ParserGenerator(tokenize.generate_tokens(f.readline))
        g.gettoken()
        g.expect(type, value)

    test("", token.ENDMARKER)
    test("\n", token.ENDMARKER)
    test("\n\n", token.ENDMARKER)
    test("\n\n\n", token.ENDMARKER)
    test("\n\n\n\n", token.ENDMARKER)
    test("\n\n\n\n\n", token.ENDMARKER)

# Generated at 2022-06-17 16:55:50.222569
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    """Unit test for constructor of class PgenGrammar"""
    # Test 1:
    # Check that the constructor of class PgenGrammar
    # raises a TypeError if the first argument is not a string
    # or a file object.
    #
    # The test is successful if the constructor raises a TypeError.
    #
    # The test fails if the constructor does not raise a TypeError.
    #
    # The test is inconclusive if the constructor raises an exception
    # other than TypeError.
    #
    # The test is inconclusive if the constructor does not raise an exception.
    #
    # The test is inconclusive if the constructor raises a TypeError
    # but the message of the TypeError does not contain the string
    # "first argument must be a string or a file object".

# Generated at 2022-06-17 16:55:56.169177
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    pg = ParserGenerator()
    a = NFAState()
    z = NFAState()
    a.addarc(z, "a")
    dfa = pg.make_dfa(a, z)
    assert len(dfa) == 2
    assert dfa[0].nfaset == {a: 1}
    assert dfa[1].nfaset == {z: 1}
    assert dfa[0].arcs == {"a": dfa[1]}
    assert dfa[1].arcs == {}
    assert dfa[0].isfinal == False
    assert dfa[1].isfinal == True
    a = NFAState()
    z = NFAState()
    a.addarc(z, "a")
    a.addarc(z, "b")
    dfa = pg

# Generated at 2022-06-17 16:56:44.574499
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    pg = ParserGenerator()
    pg.dfas = {
        "a": [DFAState({}, False), DFAState({}, True)],
        "b": [DFAState({}, False), DFAState({}, True)],
        "c": [DFAState({}, False), DFAState({}, True)],
    }
    pg.dfas["a"][0].addarc(pg.dfas["b"][0], "a")
    pg.dfas["a"][0].addarc(pg.dfas["c"][0], "b")
    pg.dfas["b"][0].addarc(pg.dfas["c"][0], "c")
    pg.dfas["c"][0].addarc(pg.dfas["a"][0], "d")
    pg.df

# Generated at 2022-06-17 16:56:54.314312
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    pg = ParserGenerator()
    dfa = [
        DFAState({NFAState(): 1}, NFAState()),
        DFAState({NFAState(): 1}, NFAState()),
        DFAState({NFAState(): 1}, NFAState()),
    ]
    dfa[0].addarc(dfa[1], "a")
    dfa[0].addarc(dfa[2], "b")
    dfa[1].addarc(dfa[2], "c")
    dfa[2].addarc(dfa[2], "d")
    pg.simplify_dfa(dfa)
    assert len(dfa) == 2
    assert dfa[0].arcs == {"a": dfa[1], "b": dfa[1]}

# Generated at 2022-06-17 16:57:01.913981
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    pg = ParserGenerator()
    pg.type = token.NAME
    pg.value = "foo"
    assert pg.expect(token.NAME) == "foo"
    pg.type = token.NAME
    pg.value = "bar"
    pg.expect(token.NAME, "bar")
    pg.type = token.NAME
    pg.value = "bar"
    try:
        pg.expect(token.NAME, "baz")
    except SyntaxError:
        pass
    else:
        assert False, "expected SyntaxError"
    pg.type = token.NAME
    pg.value = "bar"
    try:
        pg.expect(token.NUMBER, "bar")
    except SyntaxError:
        pass
    else:
        assert False, "expected SyntaxError"


# Generated at 2022-06-17 16:57:13.654181
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    pg = ParserGenerator()
    pg.dfas = {
        "a": [DFAState({}, False), DFAState({}, True)],
        "b": [DFAState({}, False), DFAState({}, True)],
        "c": [DFAState({}, False), DFAState({}, True)],
    }
    pg.dfas["a"][0].addarc("b", pg.dfas["b"][0])
    pg.dfas["a"][0].addarc("c", pg.dfas["c"][0])
    pg.dfas["b"][0].addarc("c", pg.dfas["c"][0])
    pg.dfas["c"][0].addarc("b", pg.dfas["b"][0])

# Generated at 2022-06-17 16:57:16.282054
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    pg = ParserGenerator()
    pg.dfas = {
        'a': [DFAState({'a': 1, 'b': 1}, False), DFAState({}, True)],
        'b': [DFAState({'a': 1}, True)],
    }
    pg.calcfirst('a')
    assert pg.first['a'] == {'a': 1, 'b': 1}


# Generated at 2022-06-17 16:57:25.775275
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    import pgen2.pgen
    pgen = pgen2.pgen.ParserGenerator()
    pgen.make_label(None, "NAME")
    pgen.make_label(None, "NUMBER")
    pgen.make_label(None, "STRING")
    pgen.make_label(None, "if")
    pgen.make_label(None, "and")
    pgen.make_label(None, "or")
    pgen.make_label(None, "not")
    pgen.make_label(None, "in")
    pgen.make_label(None, "is")
    pgen.make_label(None, "lambda")
    pgen.make_label(None, "def")
    pgen.make_label(None, "class")

# Generated at 2022-06-17 16:57:30.874560
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    pg = ParserGenerator()
    pg.dfas = {'a': [DFAState({NFAState(): 1}, NFAState()), DFAState({NFAState(): 1}, NFAState())]}
    pg.dump_dfa('a', pg.dfas['a'])


# Generated at 2022-06-17 16:57:40.260447
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    p = ParserGenerator()
    a = DFAState({}, None)
    b = DFAState({}, None)
    c = DFAState({}, None)
    d = DFAState({}, None)
    a.addarc(b, "a")
    a.addarc(c, "b")
    b.addarc(d, "c")
    c.addarc(d, "c")
    d.addarc(a, "d")
    d.addarc(b, "e")
    d.addarc(c, "e")
    dfa = [a, b, c, d]
    p.simplify_dfa(dfa)
    assert len(dfa) == 3
    assert dfa[0] == a
    assert dfa[1] == b
    assert dfa

# Generated at 2022-06-17 16:57:50.595130
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    pg = ParserGenerator()
    a = NFAState()
    z = NFAState()
    a.addarc(z, "a")
    dfa = pg.make_dfa(a, z)
    assert len(dfa) == 2
    assert len(dfa[0].arcs) == 1
    assert dfa[0].arcs["a"] is dfa[1]
    assert dfa[1].isfinal
    assert dfa[1].arcs == {}

# Generated at 2022-06-17 16:58:02.399507
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    pg = ParserGenerator()
    pg.filename = "test.py"
    pg.end = (1, 2)
    pg.line = "line"
    try:
        pg.raise_error("msg")
    except SyntaxError as e:
        assert e.msg == "msg"
        assert e.filename == "test.py"
        assert e.lineno == 1
        assert e.offset == 2
        assert e.text == "line"
    else:
        assert False, "Expected SyntaxError"
    try:
        pg.raise_error("msg %s %s", "foo", "bar")
    except SyntaxError as e:
        assert e.msg == "msg foo bar"
    else:
        assert False, "Expected SyntaxError"

# Generated at 2022-06-17 16:59:20.996849
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    pg = ParserGenerator()
    pg.dump_nfa("foo", NFAState(), NFAState())

# Generated at 2022-06-17 16:59:29.553874
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    import io
    import tokenize
    import unittest
    import unittest.mock

    class ParserGeneratorTestCase(unittest.TestCase):
        def test_raise_error(self):
            # Arrange
            generator = ParserGenerator()
            generator.filename = "filename"
            generator.end = (1, 2)
            generator.line = "line"
            msg = "msg"
            args = ("arg1", "arg2")
            expected = SyntaxError(msg % args, ("filename", 1, 2, "line"))

            # Act
            try:
                generator.raise_error(msg, *args)
            except SyntaxError as e:
                actual = e

            # Assert
            self.assertEqual(expected.msg, actual.msg)

# Generated at 2022-06-17 16:59:39.021472
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    pg = ParserGenerator()
    pg.add_production("a", "b c")
    pg.add_production("b", "d | e")
    pg.add_production("c", "f | g")
    pg.add_production("d", "h")
    pg.add_production("e", "i")
    pg.add_production("f", "j")
    pg.add_production("g", "k")
    pg.add_production("h", "l")
    pg.add_production("i", "m")
    pg.add_production("j", "n")
    pg.add_production("k", "o")
    pg.add_production("l", "p")
    pg.add_production("m", "q")
    pg.add_production("n", "r")

# Generated at 2022-06-17 16:59:48.786657
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    import io
    import tokenize
    from typing import Iterator
    from typing import Tuple
    from typing import Union

    def get_tokens(s: str) -> Iterator[Tuple[int, str, Tuple[int, int], Tuple[int, int], str]]:
        return tokenize.tokenize(io.BytesIO(s.encode("utf-8")).readline)

    def test(s: str, expected: Union[int, str]) -> None:
        pg = ParserGenerator(get_tokens(s), "<test>")
        pg.gettoken()
        if isinstance(expected, int):
            assert pg.type == expected
        else:
            assert pg.value == expected

    test("", token.ENDMARKER)

# Generated at 2022-06-17 16:59:58.372746
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    pg = ParserGenerator()
    pg.gettoken = lambda: None
    pg.value = "a"
    pg.parse_item = lambda: (1, 2)
    pg.parse_alt()
    pg.value = "|"
    pg.parse_alt()
    pg.value = "b"
    pg.parse_alt()
    pg.value = "|"
    pg.parse_alt()
    pg.value = "c"
    pg.parse_alt()
    pg.value = "|"
    pg.parse_alt()
    pg.value = "d"
    pg.parse_alt()
    pg.value = "|"
    pg.parse_alt()
    pg.value = "e"
    pg.parse_alt()
    pg.value = "|"

# Generated at 2022-06-17 17:00:07.909965
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    pg = ParserGenerator()
    pg.parse_alt()
    pg.parse_alt()
    pg.parse_alt()
    pg.parse_alt()
    pg.parse_alt()
    pg.parse_alt()
    pg.parse_alt()
    pg.parse_alt()
    pg.parse_alt()
    pg.parse_alt()
    pg.parse_alt()
    pg.parse_alt()
    pg.parse_alt()
    pg.parse_alt()
    pg.parse_alt()
    pg.parse_alt()
    pg.parse_alt()
    pg.parse_alt()
    pg.parse_alt()
    pg.parse_alt()
    pg.parse_alt()
    pg.parse_alt()
    pg.parse_alt()
    pg.parse_alt