

# Generated at 2022-06-17 16:51:15.815601
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    pg = ParserGenerator()

# Generated at 2022-06-17 16:51:28.557779
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    pg = ParserGenerator()
    pg.gettoken = lambda: None
    pg.value = "("
    pg.parse_item = lambda: (None, None)
    pg.parse_alt()
    pg.value = ")"
    pg.parse_alt()
    pg.value = "|"
    pg.parse_alt()
    pg.value = "]"
    pg.parse_alt()
    pg.value = "+"
    pg.parse_alt()
    pg.value = "*"
    pg.parse_alt()
    pg.value = "foo"
    pg.parse_alt()
    pg.value = "bar"
    pg.parse_alt()
    pg.value = "baz"
    pg.parse_alt()

# Generated at 2022-06-17 16:51:40.103750
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    from . import parser
    from . import token
    from . import tokenize
    from . import grammar
    from . import symbol
    from . import pgen
    from . import pygram
    from . import pytree
    from . import python_grammar_no_print_statement
    from . import python_grammar
    from . import python_grammar_nt
    from . import python_grammar_nt_no_print_statement
    from . import python_grammar_no_print_statement_no_simple_stmt
    from . import python_grammar_no_simple_stmt
    from . import python_grammar_nt_no_simple_stmt
    from . import python_grammar_nt_no_print_statement_no_simple_stmt
    from . import python_grammar_no_print_statement_

# Generated at 2022-06-17 16:51:52.192784
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    pg = ParserGenerator()
    pg.add_nonterminal("foo", "bar")
    pg.add_nonterminal("bar", "baz")
    pg.add_nonterminal("bar", "baz", "bar")
    pg.add_nonterminal("baz", "quux")
    pg.add_nonterminal("baz", "quux", "baz")
    pg.add_nonterminal("baz", "quux", "bar")
    pg.add_nonterminal("quux", "NAME")
    pg.add_nonterminal("quux", "NUMBER")
    pg.add_nonterminal("quux", "STRING")
    pg.add_nonterminal("quux", "LPAR", "foo", "RPAR")
    pg.add_nonterminal

# Generated at 2022-06-17 16:52:03.905108
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    pg = ParserGenerator()
    pg.dfas = {
        "a": [DFAState({}, False), DFAState({}, False)],
        "b": [DFAState({}, False), DFAState({}, False)],
    }
    pg.symbol2number = {"a": 1, "b": 2}
    pg.labels = [(1, None), (2, None)]
    pg.tokens = {1: 3, 2: 4}
    pg.keywords = {"a": 5, "b": 6}
    pg.symbol2label = {"a": 7, "b": 8}
    pg.first = {
        "a": {"a": 1, "b": 1},
        "b": {"a": 1, "b": 1},
    }
    c = pg.make_con

# Generated at 2022-06-17 16:52:14.264963
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    pg = ParserGenerator()
    pg.labels = []
    pg.tokens = {}
    pg.keywords = {}
    pg.symbol2number = {}
    pg.symbol2label = {}
    pg.make_label(pg, "NAME")
    pg.make_label(pg, "NUMBER")
    pg.make_label(pg, "STRING")
    pg.make_label(pg, "foo")
    pg.make_label(pg, "bar")
    pg.make_label(pg, "'+'")
    pg.make_label(pg, "'-'")
    pg.make_label(pg, "'*'")
    pg.make_label(pg, "'/'")
    pg.make_label(pg, "'('")

# Generated at 2022-06-17 16:52:21.961243
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    pg = ParserGenerator()
    pg.dfas = {
        "foo": [DFAState({}, False), DFAState({}, False)],
        "bar": [DFAState({}, False), DFAState({}, False)],
    }
    pg.labels = [
        (token.NAME, "foo"),
        (token.NAME, "bar"),
        (token.NAME, "baz"),
        (token.NAME, "qux"),
    ]
    pg.symbol2number = {
        "foo": 0,
        "bar": 1,
        "baz": 2,
        "qux": 3,
    }
    pg.symbol2label = {
        "foo": 0,
        "bar": 1,
    }

# Generated at 2022-06-17 16:52:34.424671
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    pg = ParserGenerator()
    a = NFAState()
    z = NFAState()
    a.addarc(z, "a")
    dfa = pg.make_dfa(a, z)
    assert len(dfa) == 2
    assert dfa[0].nfaset == {a: 1}
    assert dfa[1].nfaset == {z: 1}
    assert dfa[0].arcs == {"a": dfa[1]}
    assert dfa[1].arcs == {}
    assert dfa[0].isfinal == False
    assert dfa[1].isfinal == True
    a = NFAState()
    z = NFAState()
    a.addarc(z, "a")
    a.addarc(z, "b")
    dfa = pg

# Generated at 2022-06-17 16:52:38.971906
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    pg = ParserGenerator()
    pg.dump_nfa("foo", NFAState(), NFAState())
    pg.dump_nfa("bar", NFAState(), NFAState())
    pg.dump_nfa("baz", NFAState(), NFAState())


# Generated at 2022-06-17 16:52:53.769524
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    import io
    import tokenize
    from typing import List, Tuple
    from . import grammar
    from . import pgen
    from . import token
    from . import tokenize as tokenize_mod
    from .pgen import ParserGenerator
    from .token import TokenInfo
    from .tokenize import TokenInfo as TokenInfo_mod
    from .tokenize import TokenInfo as TokenInfo_mod
    from .tokenize import TokenInfo as TokenInfo_mod
    from .tokenize import TokenInfo as TokenInfo_mod
    from .tokenize import TokenInfo as TokenInfo_mod
    from .tokenize import TokenInfo as TokenInfo_mod
    from .tokenize import TokenInfo as TokenInfo_mod
    from .tokenize import TokenInfo as TokenInfo_mod
    from .tokenize import TokenInfo as TokenInfo_mod

# Generated at 2022-06-17 16:53:32.545516
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    pg = ParserGenerator()

# Generated at 2022-06-17 16:53:44.890037
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    pg = ParserGenerator()
    pg.dfas = {
        "a": [DFAState({}, False), DFAState({}, False)],
        "b": [DFAState({}, False), DFAState({}, False)],
        "c": [DFAState({}, False), DFAState({}, False)],
    }
    pg.dfas["a"][0].addarc(pg.dfas["a"][1], "a")
    pg.dfas["a"][0].addarc(pg.dfas["b"][0], "b")
    pg.dfas["b"][0].addarc(pg.dfas["c"][0], "c")
    pg.dfas["b"][1].addarc(pg.dfas["c"][1], "c")
    pg.df

# Generated at 2022-06-17 16:53:56.085615
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    pg = ParserGenerator()
    a = NFAState()
    z = NFAState()
    a.addarc(z, "a")
    dfa = pg.make_dfa(a, z)
    assert len(dfa) == 2
    assert dfa[0].nfaset == {a: 1}
    assert dfa[1].nfaset == {z: 1}
    assert dfa[0].arcs == {"a": dfa[1]}
    assert dfa[1].arcs == {}

    a = NFAState()
    z = NFAState()
    a.addarc(z, "a")
    a.addarc(z, "b")
    dfa = pg.make_dfa(a, z)
    assert len(dfa) == 2
    assert d

# Generated at 2022-06-17 16:54:06.456375
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    pg = ParserGenerator()
    pg.add_dfa("a", [DFAState({NFAState(): 1}, NFAState())])
    pg.add_dfa("b", [DFAState({NFAState(): 1}, NFAState())])
    pg.add_dfa("c", [DFAState({NFAState(): 1}, NFAState())])
    pg.add_dfa("d", [DFAState({NFAState(): 1}, NFAState())])
    pg.add_dfa("e", [DFAState({NFAState(): 1}, NFAState())])
    pg.add_dfa("f", [DFAState({NFAState(): 1}, NFAState())])
    pg.add_dfa("g", [DFAState({NFAState(): 1}, NFAState())])
   

# Generated at 2022-06-17 16:54:13.721941
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    import io
    import tokenize
    import unittest

    class TestCase(unittest.TestCase):
        def test_expect(self):
            pg = ParserGenerator()
            pg.filename = "test_expect"
            pg.generator = tokenize.generate_tokens(io.StringIO("foo").readline)
            pg.gettoken()
            self.assertEqual(pg.expect(token.NAME), "foo")
            pg.gettoken()
            self.assertRaises(SyntaxError, pg.expect, token.NAME)
            pg.gettoken()
            self.assertRaises(SyntaxError, pg.expect, token.NAME, "bar")
            pg.gettoken()

# Generated at 2022-06-17 16:54:26.380409
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    g = PgenGrammar()
    assert g.start == "file_input"
    assert g.keywords == {}
    assert g.tokens == []
    assert g.literals == []
    assert g.dfas == {}
    assert g.states == {}
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.p_rules == {}
    assert g.p_rules_all == {}
    assert g.p_rules_opt == {}
    assert g.p_rules_default == {}
    assert g.p_rules_prec == {}
    assert g.p_rules_assoc == {}
    assert g.p_argmap == {}
    assert g.p_argmap_all == {}
    assert g.p_argmap_opt == {}
   

# Generated at 2022-06-17 16:54:36.687329
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    pg = ParserGenerator()
    pg.gettoken = lambda: None
    pg.type = token.NAME
    pg.value = "foo"
    assert pg.parse_item() == (NFAState([(None, NFAState([("foo", NFAState())])),
                                         (None, NFAState())]),
                               NFAState([(None, NFAState())]))
    pg.value = "+"
    assert pg.parse_item() == (NFAState([(None, NFAState([("foo", NFAState())])),
                                         (None, NFAState())]),
                               NFAState([(None, NFAState([("foo", NFAState())])),
                                         (None, NFAState())]))
    pg.value = "*"
    assert pg.parse_item()

# Generated at 2022-06-17 16:54:51.629659
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    pg = ParserGenerator()
    pg.generator = tokenize.generate_tokens(io.StringIO("a").readline)
    pg.gettoken()
    a, z = pg.parse_atom()
    assert a.arcs == [(None, z)]
    assert z.arcs == []
    assert a.arcs[0][1] is z
    assert z.arcs == []
    assert a.arcs[0][0] == "a"
    assert a.arcs[0][1] is z
    assert z.arcs == []
    assert a.arcs[0][0] == "a"
    assert a.arcs[0][1] is z
    assert z.arcs == []
    assert a.arcs[0][0] == "a"
    assert a.arc

# Generated at 2022-06-17 16:55:00.420465
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    import io
    import tokenize
    import unittest

    class TestCase(unittest.TestCase):
        def test_dump_dfa(self):
            pg = ParserGenerator()
            pg.parse_grammar(io.StringIO("""
                # Test for method dump_dfa of class ParserGenerator
                start: 'a'
                """))
            pg.dump_dfa("start", pg.dfas["start"])

    unittest.main(__name__, None, None, None)

# Generated at 2022-06-17 16:55:11.598063
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    g = PgenGrammar()
    assert g.start == "file_input"
    assert g.keywords == {}
    assert g.tokens == []
    assert g.literals == []
    assert g.dfas == {}
    assert g.pstr == ""
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.states == []
    assert g.error_func == None
    assert g.error_func_name == None
    assert g.symbol2label == {}
    assert g.first == {}
    assert g.dfa2symbol == {}
    assert g.symbol2dfa == {}
    assert g.startsymbol == None
    assert g.symbol2name == {}
    assert g.name2symbol == {}

# Generated at 2022-06-17 16:56:24.048715
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    pg = ParserGenerator()
    pg.dfas = {
        "expr": [
            DFAState({}, False),
            DFAState({}, True),
            DFAState({}, True),
            DFAState({}, True),
        ],
        "term": [
            DFAState({}, False),
            DFAState({}, True),
            DFAState({}, True),
        ],
        "factor": [
            DFAState({}, False),
            DFAState({}, True),
            DFAState({}, True),
        ],
    }

# Generated at 2022-06-17 16:56:26.433830
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    pg = ParserGenerator()
    pg.dump_nfa("foo", NFAState(), NFAState())

# Generated at 2022-06-17 16:56:34.606752
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    pg = ParserGenerator()
    pg.gettoken()
    assert pg.type == token.ENDMARKER
    assert pg.value == ""
    assert pg.begin == (1, 0)
    assert pg.end == (1, 0)
    assert pg.line == ""
    pg.gettoken()
    assert pg.type == token.ENDMARKER
    assert pg.value == ""
    assert pg.begin == (1, 0)
    assert pg.end == (1, 0)
    assert pg.line == ""

# Generated at 2022-06-17 16:56:45.611155
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    pg = ParserGenerator()
    pg.dfas = {
        "a": [DFAState({}, False), DFAState({}, False)],
        "b": [DFAState({}, False), DFAState({}, False)],
        "c": [DFAState({}, False), DFAState({}, False)],
    }
    pg.dfas["a"][0].addarc(pg.dfas["a"][1], "a")
    pg.dfas["a"][0].addarc(pg.dfas["b"][0], "b")
    pg.dfas["b"][0].addarc(pg.dfas["c"][0], "c")
    pg.dfas["c"][0].addarc(pg.dfas["c"][1], "c")
    pg.df

# Generated at 2022-06-17 16:56:57.169210
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    pg = ParserGenerator()
    pg.dfas = {
        "a": [DFAState({}, False), DFAState({}, False)],
        "b": [DFAState({}, False), DFAState({}, False)],
        "c": [DFAState({}, False), DFAState({}, False)],
    }
    pg.first = {"a": {"a": 1}, "b": {"b": 1}, "c": {"c": 1}}
    c = pg.make_converter()

# Generated at 2022-06-17 16:57:02.068001
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    pg = ParserGenerator()
    pg.dump_nfa("foo", NFAState(), NFAState())
    pg.dump_nfa("bar", NFAState(), NFAState())


# Generated at 2022-06-17 16:57:06.754763
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    pg = ParserGenerator()

# Generated at 2022-06-17 16:57:14.545698
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    pg = ParserGenerator()
    pg.generator = tokenize.generate_tokens(StringIO("foo").readline)
    pg.gettoken()
    a, z = pg.parse_atom()
    assert a.arcs == [(None, z), ("foo", z)]
    assert z.arcs == []
    pg.gettoken()
    assert pg.type == token.ENDMARKER


# Generated at 2022-06-17 16:57:24.504903
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    pg = ParserGenerator()
    pg.generator = tokenize.generate_tokens(StringIO("a").readline)
    pg.gettoken()
    assert pg.type == token.NAME
    assert pg.value == "a"
    a, z = pg.parse_atom()
    assert a.arcs == [(None, z)]
    assert z.arcs == []
    assert a.arcs == [(None, z)]
    assert z.arcs == []
    pg.generator = tokenize.generate_tokens(StringIO("'a'").readline)
    pg.gettoken()
    assert pg.type == token.STRING
    assert pg.value == "'a'"
    a, z = pg.parse_atom()
    assert a.arcs == [(None, z)]

# Generated at 2022-06-17 16:57:35.869681
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    pg = ParserGenerator()
    pg.dfas = {
        "foo": [DFAState({}, False), DFAState({}, True)],
        "bar": [DFAState({}, False), DFAState({}, True)],
        "baz": [DFAState({}, False), DFAState({}, True)],
    }
    pg.first = {"foo": {"a": 1, "b": 1}, "bar": {"a": 1, "c": 1}, "baz": {"b": 1, "c": 1}}
    c = pg.make_converter()
    assert c.labels == [(token.NAME, "a"), (token.NAME, "b"), (token.NAME, "c")]

# Generated at 2022-06-17 16:59:41.181008
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    pg = ParserGenerator()
    pg.make_label(None, "NAME")
    pg.make_label(None, "'+'")
    pg.make_label(None, '"and"')
    pg.make_label(None, '"and"')
    pg.make_label(None, '"and"')
    pg.make_label(None, '"and"')
    pg.make_label(None, '"and"')
    pg.make_label(None, '"and"')
    pg.make_label(None, '"and"')
    pg.make_label(None, '"and"')
    pg.make_label(None, '"and"')
    pg.make_label(None, '"and"')

# Generated at 2022-06-17 16:59:50.798553
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    import io
    import tokenize
    from typing import Tuple
    from typing import List
    from typing import Dict
    from typing import Text
    from typing import Sequence
    from typing import Optional
    from typing import Any
    from typing import NoReturn
    from typing import Union
    from typing import Type
    from typing import Callable
    from typing import cast
    from typing import TYPE_CHECKING
    from typing import overload
    from typing import Generic
    from typing import TypeVar
    from typing import Iterator
    from typing import Iterable
    from typing import List
    from typing import Dict
    from typing import Text
    from typing import Sequence
    from typing import Optional
    from typing import Any
    from typing import NoReturn
    from typing import Union
    from typing import Type
    from typing import Callable
    from typing import cast

# Generated at 2022-06-17 16:59:52.060341
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    assert isinstance(PgenGrammar(), PgenGrammar)


# Generated at 2022-06-17 17:00:01.213074
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    pg = ParserGenerator()
    pg.add_nonterminal("foo", ["bar", "baz"])
    pg.add_nonterminal("bar", ["baz", "quux"])
    pg.add_nonterminal("baz", ["quux", "quuux"])
    pg.add_nonterminal("quux", ["quuux", "quuuux"])
    pg.add_nonterminal("quuux", ["quuuux", "quuuuux"])
    pg.add_nonterminal("quuuux", ["quuuuux", "quuuuuux"])
    pg.add_nonterminal("quuuuux", ["quuuuuux", "quuuuuuux"])