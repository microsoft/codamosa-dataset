

# Generated at 2022-06-17 16:51:19.782877
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    pg = ParserGenerator()
    pg.parse_grammar(
        """
        # This is a comment
        start: 'a'
        """
    )
    pg.dump_nfa("start", pg.dfas["start"][0], pg.dfas["start"][-1])


# Generated at 2022-06-17 16:51:30.876540
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    pg = ParserGenerator()
    a = NFAState()
    z = NFAState()
    a.addarc(z, "a")
    dfa = pg.make_dfa(a, z)
    assert len(dfa) == 2
    assert len(dfa[0].arcs) == 1
    assert len(dfa[1].arcs) == 0
    assert dfa[0].arcs["a"] is dfa[1]
    assert dfa[0].isfinal == False
    assert dfa[1].isfinal == True
    assert dfa[0].nfaset == {a: 1, z: 1}
    assert dfa[1].nfaset == {z: 1}
    #
    a = NFAState()
    z = NFAState()
    a.add

# Generated at 2022-06-17 16:51:41.898305
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    import io
    import tokenize
    import unittest

    class Test(unittest.TestCase):
        def test_expect(self):
            pg = ParserGenerator()
            pg.filename = "<test>"
            pg.line = "x = 1"
            pg.type = token.NAME
            pg.value = "x"
            pg.begin = (1, 0)
            pg.end = (1, 1)

# Generated at 2022-06-17 16:51:53.880343
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    pg = ParserGenerator()
    a = NFAState()
    z = NFAState()
    a.addarc(z, "a")
    dfa = pg.make_dfa(a, z)
    assert len(dfa) == 2
    assert dfa[0].isfinal
    assert not dfa[1].isfinal
    assert dfa[0].arcs == {"a": dfa[1]}
    assert dfa[1].arcs == {}

    a = NFAState()
    z = NFAState()
    a.addarc(z, "a")
    a.addarc(z, "b")
    dfa = pg.make_dfa(a, z)
    assert len(dfa) == 2
    assert dfa[0].isfinal

# Generated at 2022-06-17 16:52:05.199050
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    pg = ParserGenerator()
    pg.generator = tokenize.generate_tokens(StringIO("a").readline)
    pg.gettoken()
    a, z = pg.parse_item()
    assert a.arcs == [(None, z)]
    assert z.arcs == []
    pg.generator = tokenize.generate_tokens(StringIO("a*").readline)
    pg.gettoken()
    a, z = pg.parse_item()
    assert a.arcs == [(None, z)]
    assert z.arcs == [(None, a)]
    pg.generator = tokenize.generate_tokens(StringIO("a+").readline)
    pg.gettoken()
    a, z = pg.parse_item()

# Generated at 2022-06-17 16:52:15.121815
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    pg = ParserGenerator()

# Generated at 2022-06-17 16:52:22.469235
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    from . import parser
    from . import token
    from . import grammar
    from . import symbol
    from . import pgen
    from . import pygram
    from . import pytoken
    from . import pgen2
    from . import pgen2_grammar
    from . import pgen2_parse
    from . import pgen2_token
    from . import pgen2_convert
    from . import pgen2_driver
    from . import pgen2_grammar
    from . import pgen2_parse
    from . import pgen2_token
    from . import pgen2_convert
    from . import pgen2_driver
    from . import pgen2_grammar
    from . import pgen2_parse
    from . import pgen2_token
    from . import pgen2_convert


# Generated at 2022-06-17 16:52:35.005978
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    pg = ParserGenerator()
    c = pg.make_converter()
    assert c.make_label(c, 'NAME') == 0
    assert c.make_label(c, 'NUMBER') == 1
    assert c.make_label(c, 'STRING') == 2
    assert c.make_label(c, '"and"') == 3
    assert c.make_label(c, '"or"') == 4
    assert c.make_label(c, '"not"') == 5
    assert c.make_label(c, '"in"') == 6
    assert c.make_label(c, '"is"') == 7
    assert c.make_label(c, '"if"') == 8
    assert c.make_label(c, '"else"') == 9

# Generated at 2022-06-17 16:52:43.301851
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    import io
    import tokenize
    import unittest
    from typing import List, Tuple, Union

    class TestCase(unittest.TestCase):
        def test_make_grammar(self) -> None:
            pg = ParserGenerator()
            pg.add_production("start", ["a", "b", "c"])
            pg.add_production("start", ["d", "e", "f"])
            pg.add_production("start", ["g", "h", "i"])
            pg.add_production("a", ["x", "y", "z"])
            pg.add_production("a", ["1", "2", "3"])
            pg.add_production("a", ["p", "q", "r"])

# Generated at 2022-06-17 16:52:56.421613
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    import unittest

    class TestCase(unittest.TestCase):
        def test_simplify_dfa(self):
            # Test that simplify_dfa() works correctly.
            #
            # The method is not theoretically optimal, but works well
            # enough.  Algorithm: repeatedly look for two states that
            # have the same set of arcs (same labels pointing to the
            # same nodes) and unify them, until things stop changing.
            #
            # This test case is designed to exercise the code that
            # handles the case where the two states being unified are
            # the same.  In that case, the code must not loop
            # infinitely.

            class DFAState:
                def __init__(self, arcs: Dict[str, "DFAState"]) -> None:
                    self.arcs = arcs

               

# Generated at 2022-06-17 16:53:33.968482
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    pg = ParserGenerator()
    pg.gettoken = lambda: None
    pg.value = "("
    pg.type = token.OP
    pg.parse_rhs = lambda: (1, 2)
    assert pg.parse_item() == (1, 2)
    pg.value = "["
    assert pg.parse_item() == (1, 2)
    pg.value = "NAME"
    pg.type = token.NAME
    pg.parse_atom = lambda: (3, 4)
    assert pg.parse_item() == (3, 4)
    pg.value = "+"
    assert pg.parse_item() == (3, 4)
    pg.value = "*"
    assert pg.parse_item() == (3, 3)
    pg.value = "?"
    assert pg.parse_

# Generated at 2022-06-17 16:53:46.829057
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    pg = ParserGenerator()
    pg.add_production("S", ["a", "b"])
    pg.add_production("S", ["c"])
    pg.add_production("S", ["d", "e"])
    pg.add_production("S", ["f", "g"])
    pg.add_production("S", ["h", "i"])
    pg.add_production("S", ["j", "k"])
    pg.add_production("S", ["l", "m"])
    pg.add_production("S", ["n", "o"])
    pg.add_production("S", ["p", "q"])
    pg.add_production("S", ["r", "s"])
    pg.add_production("S", ["t", "u"])
    pg.add_production

# Generated at 2022-06-17 16:53:57.908502
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    import io
    import tokenize
    from typing import Any, Iterator, Tuple
    from . import grammar

    def make_generator(s: str) -> Iterator[Tuple[int, str, Any, Any, str]]:
        for tup in tokenize.tokenize(io.BytesIO(s.encode("utf-8")).readline):
            yield tup

    def test(s: str, type: int, value: Optional[Any] = None) -> None:
        p = ParserGenerator(make_generator(s), "test")
        p.gettoken()
        p.expect(type, value)

    test("abc", token.NAME, "abc")
    test("abc", token.NAME)
    test("abc", token.NAME, "def")

# Generated at 2022-06-17 16:54:07.497834
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    pg = ParserGenerator()
    pg.make_scanner()
    pg.parse_grammar(GRAMMAR)
    pg.addfirstsets()
    pg.make_parser()
    pg.dump_dfa("expr", pg.dfas["expr"])
    pg.dump_dfa("testlist_star_expr", pg.dfas["testlist_star_expr"])
    pg.dump_dfa("testlist", pg.dfas["testlist"])
    pg.dump_dfa("test", pg.dfas["test"])
    pg.dump_dfa("or_test", pg.dfas["or_test"])
    pg.dump_dfa("and_test", pg.dfas["and_test"])

# Generated at 2022-06-17 16:54:17.209924
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    pg = ParserGenerator()
    pg.add_dfa("a", [DFAState({NFAState(): 1}, NFAState())])
    pg.add_dfa("b", [DFAState({NFAState(): 1}, NFAState())])
    pg.add_dfa("c", [DFAState({NFAState(): 1}, NFAState())])
    pg.add_dfa("d", [DFAState({NFAState(): 1}, NFAState())])
    pg.add_dfa("e", [DFAState({NFAState(): 1}, NFAState())])
    pg.add_dfa("f", [DFAState({NFAState(): 1}, NFAState())])
    pg.add_dfa("g", [DFAState({NFAState(): 1}, NFAState())])
   

# Generated at 2022-06-17 16:54:28.020390
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    pg = ParserGenerator()

# Generated at 2022-06-17 16:54:33.624899
# Unit test for function generate_grammar
def test_generate_grammar():
    grammar = generate_grammar()
    assert grammar.start == "file_input"

# Generated at 2022-06-17 16:54:39.612785
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    pg = ParserGenerator()
    pg.dfas = {
        "start": [
            DFAState({NFAState(0, [("a", NFAState(1))]), NFAState(1, [("b", NFAState(2))])}, NFAState(2)),
            DFAState({NFAState(2, [("c", NFAState(3))])}, NFAState(3)),
        ]
    }
    pg.dump_dfa("start", pg.dfas["start"])


# Generated at 2022-06-17 16:54:45.280569
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    pg = ParserGenerator()
    pg.type = token.NAME
    pg.value = "foo"
    pg.expect(token.NAME)
    pg.expect(token.NAME, "foo")
    pg.expect(token.NAME, "bar")
    try:
        pg.expect(token.NAME, "bar")
    except SyntaxError:
        pass
    else:
        assert False, "expected SyntaxError"
    try:
        pg.expect(token.OP, "bar")
    except SyntaxError:
        pass
    else:
        assert False, "expected SyntaxError"
    try:
        pg.expect(token.OP, ":")
    except SyntaxError:
        pass
    else:
        assert False, "expected SyntaxError"

# Generated at 2022-06-17 16:54:54.080773
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    pg = ParserGenerator()
    a = NFAState()
    z = NFAState()
    a.addarc(z, "a")
    dfa = pg.make_dfa(a, z)
    assert len(dfa) == 2
    assert dfa[0].nfaset == {a: 1}
    assert dfa[1].nfaset == {z: 1}
    assert dfa[0].arcs == {"a": dfa[1]}
    assert dfa[1].arcs == {}
    assert dfa[0].isfinal == False
    assert dfa[1].isfinal == True
    assert dfa[0].label == None
    assert dfa[1].label == None

# Generated at 2022-06-17 16:56:00.316271
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    pg = ParserGenerator()
    pg.setup("foo : 'a' | 'b' | 'c'")
    a, z = pg.parse_rhs()
    assert a.arcs == [(None, a.next)]
    assert a.next.arcs == [('a', a.next.next)]
    assert a.next.next.arcs == [('b', a.next.next.next)]
    assert a.next.next.next.arcs == [('c', z)]
    assert z.arcs == []


# Generated at 2022-06-17 16:56:08.248188
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    pg = ParserGenerator()

# Generated at 2022-06-17 16:56:21.576443
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    pgen = ParserGenerator()
    pgen.generator = tokenize.generate_tokens(io.StringIO("(a)"))
    pgen.gettoken()
    a, z = pgen.parse_atom()
    assert a.arcs == [(None, z)]
    assert z.arcs == []
    pgen.generator = tokenize.generate_tokens(io.StringIO("a"))
    pgen.gettoken()
    a, z = pgen.parse_atom()
    assert a.arcs == [("a", z)]
    assert z.arcs == []
    pgen.generator = tokenize.generate_tokens(io.StringIO('"a"'))
    pgen.gettoken()
    a, z = pgen.parse_atom()

# Generated at 2022-06-17 16:56:31.384550
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    pg = ParserGenerator()
    pg.generator = tokenize.generate_tokens(StringIO("(a)").readline)
    pg.gettoken()
    a, z = pg.parse_atom()
    assert a.arcs == [(None, z)]
    assert z.arcs == []
    pg.generator = tokenize.generate_tokens(StringIO("a").readline)
    pg.gettoken()
    a, z = pg.parse_atom()
    assert a.arcs == [("a", z)]
    assert z.arcs == []
    pg.generator = tokenize.generate_tokens(StringIO('"a"').readline)
    pg.gettoken()
    a, z = pg.parse_atom()

# Generated at 2022-06-17 16:56:44.015839
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    import io
    import tokenize

    def test(s: str) -> None:
        f = io.StringIO(s)
        p = ParserGenerator()
        p.generator = tokenize.generate_tokens(f.readline)
        p.gettoken()
        print(p.type, repr(p.value))

    test("")
    test("#")
    test("#\n")
    test("#\n\n")
    test("#\n\n\n")
    test("#\n\n\n\n")
    test("#\n\n\n\n\n")
    test("#\n\n\n\n\n\n")
    test("#\n\n\n\n\n\n\n")

# Generated at 2022-06-17 16:56:53.776268
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    pg = ParserGenerator()
    pg.generator = iter([(token.NAME, "a", (1, 0), (1, 1), "a")])
    pg.gettoken()
    a, z = pg.parse_rhs()
    assert a.arcs == [(None, z)]
    assert z.arcs == []
    pg.generator = iter([(token.NAME, "a", (1, 0), (1, 1), "a"), (token.OP, "|", (1, 1), (1, 2), "|"), (token.NAME, "b", (1, 2), (1, 3), "b")])
    pg.gettoken()
    a, z = pg.parse_rhs()
    assert a.arcs == [(None, z)]
    assert z.arcs == []
    pg

# Generated at 2022-06-17 16:57:01.898006
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    pg = ParserGenerator()
    pg.filename = "test"
    pg.end = (1, 2)
    pg.line = "line"
    try:
        pg.raise_error("msg")
    except SyntaxError as e:
        assert e.args == ("msg", ("test", 1, 2, "line"))
    else:
        assert False, "expected SyntaxError"
    try:
        pg.raise_error("msg %s %s", "a", "b")
    except SyntaxError as e:
        assert e.args == ("msg a b", ("test", 1, 2, "line"))
    else:
        assert False, "expected SyntaxError"

# Generated at 2022-06-17 16:57:13.602200
# Unit test for method simplify_dfa of class ParserGenerator

# Generated at 2022-06-17 16:57:15.689644
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    from pgen2.pgen import ParserGenerator
    pg = ParserGenerator()
    pg.parse_grammar(
        """
        start: 'a'
        """
    )
    pg.dump_nfa("start", pg.dfas["start"][0], pg.dfas["start"][1])

# Generated at 2022-06-17 16:57:25.322613
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    pg = ParserGenerator()
    a = NFAState()
    z = NFAState()
    a.addarc(z, "a")
    a.addarc(z, "b")
    dfa = pg.make_dfa(a, z)
    assert len(dfa) == 1
    assert len(dfa[0].arcs) == 2
    assert dfa[0].arcs["a"] is dfa[0]
    assert dfa[0].arcs["b"] is dfa[0]
    assert dfa[0].isfinal
    a = NFAState()
    z = NFAState()
    a.addarc(z, "a")
    a.addarc(z, "b")
    a.addarc(z, "c")
    dfa = pg.make_df

# Generated at 2022-06-17 16:59:34.815954
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    import sys
    import io
    import tokenize
    import token
    from . import pgen2
    from . import grammar

    def make_label(c: pgen2.ParserGenerator, label: Text) -> int:
        return c.make_label(c, label)

    def make_first(c: pgen2.ParserGenerator, name: Text) -> Dict[int, int]:
        return c.make_first(c, name)

    def make_dfa(c: pgen2.ParserGenerator, name: Text) -> List[pgen2.DFAState]:
        return c.dfas[name]

    def make_converter(c: pgen2.ParserGenerator) -> pgen2.PgenGrammar:
        return c.make_converter()


# Generated at 2022-06-17 16:59:39.045475
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    pg = ParserGenerator()

# Generated at 2022-06-17 16:59:49.151823
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    pg = ParserGenerator()
    pg.generator = tokenize.generate_tokens(io.StringIO("a | b").readline)
    pg.gettoken()
    a, z = pg.parse_rhs()
    assert a.arcs == [(None, a.arcs[0][1])]
    assert a.arcs[0][1].arcs == [("a", z)]
    assert z.arcs == [("b", z)]

# Generated at 2022-06-17 16:59:56.324948
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    pg = ParserGenerator()
    pg.generator = tokenize.generate_tokens(io.StringIO("a b c").readline)
    pg.gettoken()
    a, z = pg.parse_rhs()
    assert a.arcs == [(None, a.next)]
    assert a.next.arcs == [("a", a.next.next)]
    assert a.next.next.arcs == [("b", a.next.next.next)]
    assert a.next.next.next.arcs == [("c", z)]
    assert z.arcs == []


# Generated at 2022-06-17 17:00:03.693520
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    # This is not theoretically optimal, but works well enough.
    # Algorithm: repeatedly look for two states that have the same
    # set of arcs (same labels pointing to the same nodes) and
    # unify them, until things stop changing.

    # dfa is a list of DFAState instances
    def simplify_dfa(dfa: List["DFAState"]) -> None:
        changes = True
        while changes:
            changes = False
            for i, state_i in enumerate(dfa):
                for j in range(i + 1, len(dfa)):
                    state_j = dfa[j]
                    if state_i == state_j:
                        # print "  unify", i, j
                        del dfa[j]