

# Generated at 2022-06-17 16:51:48.430223
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    p = ParserGenerator()
    p.make_dfa = lambda start, finish: [start, finish]
    dfa = [DFAState({0: 1}, 1), DFAState({1: 1}, 1)]
    p.simplify_dfa(dfa)
    assert dfa == [DFAState({0: 1}, 1)]

# Generated at 2022-06-17 16:51:59.654032
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    pg = ParserGenerator()
    pg.dfas = {}
    pg.first = {}

# Generated at 2022-06-17 16:52:10.753739
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    import io
    import tokenize
    from typing import Iterator
    from typing import Tuple
    from typing import Union
    from typing import cast
    from typing import Any
    from typing import Optional
    from typing import List
    from typing import Dict
    from typing import Text
    from typing import Sequence
    from typing import Set
    from typing import Callable
    from typing import TypeVar
    from typing import Generic
    from typing import NamedTuple
    from typing import cast
    from typing import overload
    from typing import TYPE_CHECKING
    from typing import Union
    from typing import Iterable
    from typing import AnyStr
    from typing import Tuple
    from typing import Optional
    from typing import List
    from typing import Dict
    from typing import Text
    from typing import Sequence
    from typing import Set
    from typing import Callable
   

# Generated at 2022-06-17 16:52:20.129153
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    pg = ParserGenerator()
    pg.labels = []
    pg.symbol2number = {"foo": 1, "bar": 2}
    pg.symbol2label = {}
    pg.tokens = {token.NAME: 3, token.NUMBER: 4}
    pg.keywords = {"def": 5, "class": 6}
    assert pg.make_label(pg, "foo") == 1
    assert pg.make_label(pg, "bar") == 2
    assert pg.make_label(pg, "NAME") == 3
    assert pg.make_label(pg, "NUMBER") == 4
    assert pg.make_label(pg, '"def"') == 5
    assert pg.make_label(pg, '"class"') == 6

# Generated at 2022-06-17 16:52:32.575877
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    import io
    import tokenize
    from . import grammar
    from . import token
    from . import pgen2
    from . import pgen
    from . import pygram
    from . import pytree
    from . import symbol
    from . import symbol_helper
    from . import token_helper
    from . import token_constants
    from . import token_utils
    from . import python_grammar_no_print_statement
    from . import python_grammar
    from . import python_grammar_nts
    from . import python_grammar_nts_extras
    from . import python_grammar_nts_extras_2
    from . import python_grammar_nts_extras_3
    from . import python_grammar_nts_extras_4
    from . import python_

# Generated at 2022-06-17 16:52:41.819913
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    pg = ParserGenerator()
    pg.dfas = {
        "a": [DFAState({}, False), DFAState({}, False)],
        "b": [DFAState({}, False), DFAState({}, False)],
        "c": [DFAState({}, False), DFAState({}, False)],
    }
    pg.first = {"a": {"a": 1, "b": 1}, "b": {"b": 1}, "c": {"c": 1}}
    c = pg.make_converter()
    assert c.labels == [(token.NAME, "a"), (token.NAME, "b"), (token.NAME, "c")]
    assert c.symbol2number == {"a": 0, "b": 1, "c": 2}

# Generated at 2022-06-17 16:52:55.648673
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    pg = ParserGenerator()
    pg.dump_nfa("foo", NFAState(), NFAState())
    pg.dump_nfa("foo", NFAState(), NFAState())
    pg.dump_nfa("foo", NFAState(), NFAState())
    pg.dump_nfa("foo", NFAState(), NFAState())
    pg.dump_nfa("foo", NFAState(), NFAState())
    pg.dump_nfa("foo", NFAState(), NFAState())
    pg.dump_nfa("foo", NFAState(), NFAState())
    pg.dump_nfa("foo", NFAState(), NFAState())
    pg.dump_nfa("foo", NFAState(), NFAState())
    pg.dump_nfa("foo", NFAState(), NFAState())


# Generated at 2022-06-17 16:53:08.625220
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    pg = ParserGenerator()
    pg.generator = tokenize.generate_tokens(StringIO("a").readline)
    pg.gettoken()
    assert pg.parse_item() == (NFAState([(None, NFAState([('a', NFAState([]))]))]),
                               NFAState([('a', NFAState([]))]))
    pg.generator = tokenize.generate_tokens(StringIO("a+").readline)
    pg.gettoken()
    assert pg.parse_item() == (NFAState([(None, NFAState([('a', NFAState([]))]))]),
                               NFAState([('a', NFAState([]))]))

# Generated at 2022-06-17 16:53:20.006941
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    pg = ParserGenerator()
    pg.generator = tokenize.generate_tokens(io.StringIO("a").readline)
    pg.gettoken()
    a, z = pg.parse_atom()
    assert a.arcs == [(None, z)]
    assert z.arcs == []
    assert a.arcs[0][1] is z
    assert z.arcs == []
    assert a.arcs[0][0] is None
    assert a.arcs[0][1] is z
    assert z.arcs == []
    assert a.arcs[0][0] is None
    assert a.arcs[0][1] is z
    assert z.arcs == []
    assert a.arcs[0][0] is None
    assert a.arcs[0][1]

# Generated at 2022-06-17 16:53:31.541084
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    pg = ParserGenerator()
    pg.dfas = {
        "a": [DFAState({}, False), DFAState({}, False)],
        "b": [DFAState({}, False), DFAState({}, False)],
        "c": [DFAState({}, False), DFAState({}, False)],
    }
    pg.dfas["a"][0].addarc(pg.dfas["a"][1], "a")
    pg.dfas["a"][0].addarc(pg.dfas["b"][0], "b")
    pg.dfas["b"][0].addarc(pg.dfas["c"][0], "c")
    pg.dfas["c"][0].addarc(pg.dfas["a"][1], "a")
    pg.df

# Generated at 2022-06-17 16:54:30.545753
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    pg = PgenGrammar()
    assert pg.start == "file_input"
    assert pg.keywords == {}
    assert pg.tokens == []
    assert pg.literals == []
    assert pg.symbol2number == {}
    assert pg.number2symbol == {}
    assert pg.dfas == {}
    assert pg.states == {}
    assert pg.error_func == None
    assert pg.error_func_name == None
    assert pg.startsymbol == None
    assert pg.symbol2label == {}
    assert pg.label2symbol == {}
    assert pg.first == {}
    assert pg.productions == []
    assert pg.p_error == None
    assert pg.p_accept == None
    assert pg.p_empty == None
    assert pg.p_start == None

# Generated at 2022-06-17 16:54:32.506912
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    pg = ParserGenerator()
    pg.dump_nfa("foo", NFAState(), NFAState())
    pg.dump_nfa("bar", NFAState(), NFAState())
    pg.dump_nfa("baz", NFAState(), NFAState())


# Generated at 2022-06-17 16:54:40.980418
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    pg = ParserGenerator()
    pg.dump_dfa("foo", [DFAState({}, None)])
    pg.dump_dfa("foo", [DFAState({}, None), DFAState({}, None)])
    pg.dump_dfa("foo", [DFAState({}, None), DFAState({}, None), DFAState({}, None)])
    pg.dump_dfa("foo", [DFAState({}, None), DFAState({}, None), DFAState({}, None), DFAState({}, None)])
    pg.dump_dfa("foo", [DFAState({}, None), DFAState({}, None), DFAState({}, None), DFAState({}, None), DFAState({}, None)])

# Generated at 2022-06-17 16:54:51.868904
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    pg = ParserGenerator()
    pg.gettoken = lambda: None
    pg.value = "("
    pg.parse_item = lambda: (None, None)
    pg.parse_alt()
    pg.value = ")"
    pg.parse_alt()
    pg.value = "|"
    pg.parse_alt()
    pg.value = "("
    pg.parse_alt()
    pg.value = ")"
    pg.parse_alt()
    pg.value = "|"
    pg.parse_alt()
    pg.value = "("
    pg.parse_alt()
    pg.value = ")"
    pg.parse_alt()
    pg.value = "|"
    pg.parse_alt()
    pg.value = "("
    pg.parse_alt()
    pg

# Generated at 2022-06-17 16:55:02.518358
# Unit test for constructor of class PgenGrammar

# Generated at 2022-06-17 16:55:13.285029
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    pg = ParserGenerator()
    pg.dfas = {
        "a": [DFAState({}, False), DFAState({}, True)],
        "b": [DFAState({}, False), DFAState({}, True)],
        "c": [DFAState({}, False), DFAState({}, True)],
    }
    pg.dfas["a"][0].addarc(pg.dfas["b"][0], "a")
    pg.dfas["a"][0].addarc(pg.dfas["c"][0], "b")
    pg.dfas["b"][0].addarc(pg.dfas["c"][0], "c")
    pg.dfas["c"][0].addarc(pg.dfas["a"][0], "d")
    pg.cal

# Generated at 2022-06-17 16:55:25.204485
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    pg = ParserGenerator()
    pg.add_nonterminal("start", "expr")
    pg.add_nonterminal("expr", "expr + term")
    pg.add_nonterminal("expr", "expr - term")
    pg.add_nonterminal("expr", "term")
    pg.add_nonterminal("term", "term * factor")
    pg.add_nonterminal("term", "term / factor")
    pg.add_nonterminal("term", "factor")
    pg.add_nonterminal("factor", "( expr )")
    pg.add_nonterminal("factor", "NUMBER")
    pg.build()
    pg.dump()
    pg.write_tables("pgen_test.py")

if __name__ == "__main__":
    test_ParserGener

# Generated at 2022-06-17 16:55:37.616508
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    pg = PgenGrammar()
    assert pg.start is None
    assert pg.keywords == {}
    assert pg.tokens == {}
    assert pg.dfas == {}
    assert pg.parsers == {}
    assert pg.symbol2number == {}
    assert pg.number2symbol == {}
    assert pg.states == []
    assert pg.literals == []
    assert pg.symbol2label == {}
    assert pg.symbol2name == {}
    assert pg.symbol2type == {}
    assert pg.symbol2value == {}
    assert pg.symbol2first == {}
    assert pg.symbol2follow == {}
    assert pg.symbol2empty == {}
    assert pg.symbol2error == {}
    assert pg.symbol2nont == {}

# Generated at 2022-06-17 16:55:51.532706
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    pg = ParserGenerator()
    c = pg.make_converter()
    assert c.make_label(c, "NAME") == 0
    assert c.make_label(c, "NUMBER") == 1
    assert c.make_label(c, "STRING") == 2
    assert c.make_label(c, "LPAR") == 3
    assert c.make_label(c, "RPAR") == 4
    assert c.make_label(c, "LSQB") == 5
    assert c.make_label(c, "RSQB") == 6
    assert c.make_label(c, "COLON") == 7
    assert c.make_label(c, "COMMA") == 8
    assert c.make_label(c, "SEMI") == 9

# Generated at 2022-06-17 16:56:04.569250
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    pg = ParserGenerator()
    pg.dfas = {
        "a": [DFAState({}, False), DFAState({}, False)],
        "b": [DFAState({}, False), DFAState({}, False)],
        "c": [DFAState({}, False), DFAState({}, False)],
    }
    pg.first = {
        "a": {"a": 1, "b": 1},
        "b": {"b": 1, "c": 1},
        "c": {"c": 1},
    }
    pg.startsymbol = "a"
    c = pg.make_converter()
    assert c.symbol2number["a"] == 0
    assert c.symbol2number["b"] == 1
    assert c.symbol2number["c"] == 2
   

# Generated at 2022-06-17 16:57:43.525316
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    pg = PgenGrammar()
    assert pg.symbol2number == {}
    assert pg.number2symbol == {}
    assert pg.states == []
    assert pg.dfas == []
    assert pg.start == None
    assert pg.keywords == {}
    assert pg.tokens == []
    assert pg.literals == []
    assert pg.symbol2label == {}
    assert pg.label2symbol == {}
    assert pg.symbol2name == {}
    assert pg.name2symbol == {}
    assert pg.symbol2type == {}
    assert pg.type2symbol == {}
    assert pg.symbol2first == {}
    assert pg.symbol2follow == {}
    assert pg.symbol2prec == {}
    assert pg.symbol2assoc == {}

# Generated at 2022-06-17 16:57:54.421920
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    pg = ParserGenerator()
    a = NFAState()
    b = NFAState()
    c = NFAState()
    d = NFAState()
    e = NFAState()
    f = NFAState()
    g = NFAState()
    h = NFAState()
    i = NFAState()
    j = NFAState()
    k = NFAState()
    l = NFAState()
    m = NFAState()
    n = NFAState()
    o = NFAState()
    p = NFAState()
    q = NFAState()
    r = NFAState()
    s = NFAState()
    t = NFAState()
    u = NFAState()
    v = NFAState()
    w = NFAState()
    x = NFAState

# Generated at 2022-06-17 16:58:05.334312
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    pg = ParserGenerator()
    a = NFAState()
    z = NFAState()
    a.addarc(z, "a")
    dfa = pg.make_dfa(a, z)
    assert len(dfa) == 2
    assert len(dfa[0].arcs) == 1
    assert len(dfa[1].arcs) == 0
    assert dfa[0].arcs["a"] is dfa[1]
    assert dfa[1].isfinal

    a = NFAState()
    z = NFAState()
    a.addarc(z, "a")
    a.addarc(z, "b")
    dfa = pg.make_dfa(a, z)
    assert len(dfa) == 2

# Generated at 2022-06-17 16:58:14.975333
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    g = PgenGrammar()
    assert g.start is None
    assert g.keywords == {}
    assert g.tokens == []
    assert g.dfas == {}
    assert g.states == {}
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.pstrings == {}
    assert g.error_func == None
    assert g.literals == []
    assert g.states == {}
    assert g.symbol2label == {}
    assert g.first == {}
    assert g.error_func == None
    assert g.error_count == 0



# Generated at 2022-06-17 16:58:23.713327
# Unit test for method simplify_dfa of class ParserGenerator

# Generated at 2022-06-17 16:58:36.504029
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    pg = ParserGenerator()
    pg.parse_rhs()
    pg.parse_rhs()
    pg.parse_rhs()
    pg.parse_rhs()
    pg.parse_rhs()
    pg.parse_rhs()
    pg.parse_rhs()
    pg.parse_rhs()
    pg.parse_rhs()
    pg.parse_rhs()
    pg.parse_rhs()
    pg.parse_rhs()
    pg.parse_rhs()
    pg.parse_rhs()
    pg.parse_rhs()
    pg.parse_rhs()
    pg.parse_rhs()
    pg.parse_rhs()
    pg.parse_rhs()
    pg.parse_rhs()
    pg.parse_rhs()
   

# Generated at 2022-06-17 16:58:51.088418
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    pg = ParserGenerator()
    pg.gettoken = lambda: None
    pg.value = "a"
    pg.parse_item = lambda: (1, 2)
    pg.parse_item = lambda: (3, 4)
    pg.value = "|"
    pg.parse_item = lambda: (5, 6)
    pg.parse_item = lambda: (7, 8)
    pg.value = "|"
    pg.parse_item = lambda: (9, 10)
    pg.parse_item = lambda: (11, 12)
    pg.value = "b"
    a, z = pg.parse_alt()
    assert a == 1
    assert z == 12


# Generated at 2022-06-17 16:58:54.326125
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    pg = ParserGenerator()
    pg.dump_nfa("foo", NFAState(), NFAState())
    pg.dump_nfa("bar", NFAState(), NFAState())
    pg.dump_nfa("baz", NFAState(), NFAState())

# Generated at 2022-06-17 16:59:06.453885
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    pg = ParserGenerator()
    pg.dfas = {
        "a": [DFAState({}, False), DFAState({}, True)],
        "b": [DFAState({}, False), DFAState({}, True)],
        "c": [DFAState({}, False), DFAState({}, True)],
    }
    pg.dfas["a"][0].addarc(pg.dfas["a"][1], "a")
    pg.dfas["a"][0].addarc(pg.dfas["b"][0], "b")
    pg.dfas["b"][0].addarc(pg.dfas["c"][0], "c")
    pg.dfas["c"][0].addarc(pg.dfas["a"][0], "a")
    pg.cal

# Generated at 2022-06-17 16:59:16.858165
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    import io
    import tokenize
    import unittest
    from unittest import mock

    class TestCase(unittest.TestCase):
        def test_dump_nfa(self):
            with mock.patch("sys.stdout", new_callable=io.StringIO) as mock_stdout:
                pg = ParserGenerator()
                pg.filename = "test_dump_nfa"
                pg.generator = tokenize.generate_tokens(
                    io.StringIO("a: b c | d e").readline
                )
                pg.gettoken()
                dfas, startsymbol = pg.parse()
                pg.addfirstsets()
                pg.dump_nfa("a", dfas["a"][0], dfas["a"][1])