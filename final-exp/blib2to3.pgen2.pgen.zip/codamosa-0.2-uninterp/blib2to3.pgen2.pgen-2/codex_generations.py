

# Generated at 2022-06-17 16:51:04.284317
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    pg = ParserGenerator()
    pg.setup("foo", "a : 'a'")
    pg.addfirstsets()
    pg.make_parser()


# Generated at 2022-06-17 16:51:14.741801
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    pg = ParserGenerator()
    pg.generator = iter([
        (token.NAME, "foo", (1, 0), (1, 3), "foo"),
        (token.NEWLINE, "\n", (1, 3), (1, 4), "\n"),
        (token.NAME, "bar", (2, 0), (2, 3), "bar"),
        (token.NEWLINE, "\n", (2, 3), (2, 4), "\n"),
        (token.ENDMARKER, "", (3, 0), (3, 0), ""),
    ])
    pg.gettoken()
    assert pg.type == token.NAME
    assert pg.value == "foo"
    a, z = pg.parse_atom()
    assert a.arcs == [(None, z)]
    assert z.arcs == []

# Generated at 2022-06-17 16:51:27.976436
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    import tokenize
    from io import StringIO
    from typing import Iterator
    from typing import Tuple
    from typing import Union

    def _tokenize(source: str) -> Iterator[Tuple[int, str, Tuple[int, int], Tuple[int, int], str]]:
        return tokenize.tokenize(StringIO(source).readline)

    def _test(source: str, expected: Union[int, str]):
        pg = ParserGenerator()
        pg.generator = _tokenize(source)
        pg.gettoken()
        assert pg.value == expected

    _test("", "")
    _test("\n", "")
    _test("# comment\n", "")
    _test("# comment\n\n", "")

# Generated at 2022-06-17 16:51:39.630450
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    import tokenize
    import io
    from typing import Iterator
    from typing import Tuple
    from typing import Any
    from typing import NoReturn
    from typing import Optional
    from typing import Text
    from typing import Sequence
    from typing import Dict
    from typing import List
    from typing import Union
    from typing import Callable
    from typing import TypeVar
    from typing import cast
    from typing import TYPE_CHECKING
    from typing import overload
    from typing import Generic
    from typing import Type
    from typing import cast
    from typing import Any
    from typing import List
    from typing import Tuple
    from typing import Dict
    from typing import Text
    from typing import Union
    from typing import Optional
    from typing import Callable
    from typing import TypeVar
    from typing import Generic
    from typing import Type

# Generated at 2022-06-17 16:51:52.608248
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    import io
    import tokenize
    import unittest

    class TestParserGenerator(unittest.TestCase):
        def test_dump_dfa(self):
            pg = ParserGenerator()
            pg.add_dfa("a", [[[(None, 1)], [(None, 2)], [(None, 3)], [(None, 4)]]])
            pg.dump_dfa("a", pg.dfas["a"])

# Generated at 2022-06-17 16:52:04.320878
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    import io
    import tokenize
    from typing import Iterator, Tuple
    from . import pgen2
    from .pgen2 import token
    from .pgen2.pgen import ParserGenerator
    from .pgen2.pgen2_grammar import Grammar

    def tokenize_string(s: str) -> Iterator[Tuple[int, str, Tuple[int, int], Tuple[int, int], str]]:
        return tokenize.tokenize(io.BytesIO(s.encode("utf-8")).readline)

    def test_gettoken(s: str, expected: Tuple[int, str, Tuple[int, int], Tuple[int, int], str]) -> None:
        pg = ParserGenerator(Grammar())

# Generated at 2022-06-17 16:52:14.598185
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    pg = ParserGenerator()
    pg.make_dfa = lambda a, z: [DFAState({a: 1}, z)]
    pg.simplify_dfa([DFAState({0: 1}, 0), DFAState({0: 1}, 1)])
    pg.simplify_dfa([DFAState({0: 1}, 0), DFAState({1: 1}, 1)])
    pg.simplify_dfa([DFAState({0: 1}, 0), DFAState({1: 1}, 1), DFAState({0: 1}, 1)])
    pg.simplify_dfa([DFAState({0: 1}, 0), DFAState({1: 1}, 1), DFAState({2: 1}, 1)])

# Generated at 2022-06-17 16:52:22.155013
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    pg = ParserGenerator()
    pg.symbol2number = {"foo": 1, "bar": 2}
    pg.tokens = {token.NAME: 3, token.NUMBER: 4}
    pg.keywords = {"def": 5, "class": 6}
    pg.labels = [(token.NAME, "foo"), (token.NAME, "bar"), (token.NAME, "def")]
    pg.symbol2label = {"foo": 0, "bar": 1}
    assert pg.make_label(None, "foo") == 0
    assert pg.make_label(None, "bar") == 1
    assert pg.make_label(None, "baz") == 2
    assert pg.make_label(None, "NAME") == 3
    assert pg.make_label(None, "NUMBER") == 4

# Generated at 2022-06-17 16:52:28.838294
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    from . import grammar
    from . import token
    from . import tokenize
    from . import pgen2
    from .pgen2 import driver
    from .pgen2 import tokenize as pgen2_tokenize
    from .pgen2 import parse as pgen2_parse
    from .pgen2 import pgen
    from .pgen2 import convert
    from .pgen2 import grammar as pgen2_grammar
    from .pgen2 import pgen as pgen2_pgen
    from .pgen2 import convert as pgen2_convert
    from .pgen2 import driver as pgen2_driver
    from .pgen2 import main as pgen2_main
    from .pgen2 import parse_grammar as pgen2_parse_grammar

# Generated at 2022-06-17 16:52:37.329196
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    pg = ParserGenerator()
    c = pg.make_converter()
    assert pg.make_label(c, "NAME") == 0
    assert pg.make_label(c, "NUMBER") == 1
    assert pg.make_label(c, "STRING") == 2
    assert pg.make_label(c, "if") == 3
    assert pg.make_label(c, "while") == 4
    assert pg.make_label(c, "def") == 5
    assert pg.make_label(c, "class") == 6
    assert pg.make_label(c, "foo") == 7
    assert pg.make_label(c, "bar") == 8
    assert pg.make_label(c, "baz") == 9

# Generated at 2022-06-17 16:53:18.490177
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    pg = ParserGenerator()
    pg.generator = iter([(token.NAME, "foo", (1, 0), (1, 3), "foo\n")])
    pg.gettoken()
    assert pg.type == token.NAME
    assert pg.value == "foo"
    assert pg.begin == (1, 0)
    assert pg.end == (1, 3)
    assert pg.line == "foo\n"
    pg.generator = iter(
        [
            (tokenize.COMMENT, "# foo", (1, 0), (1, 5), "foo\n"),
            (tokenize.NL, "\n", (2, 0), (2, 1), "\n"),
            (token.NAME, "bar", (3, 0), (3, 3), "bar\n"),
        ]
    )


# Generated at 2022-06-17 16:53:30.967374
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    pg = ParserGenerator()
    pg.gettoken = lambda: None
    pg.value = "("
    pg.type = token.OP
    pg.parse_rhs = lambda: (NFAState(), NFAState())
    pg.gettoken = lambda: None
    pg.value = ")"
    pg.type = token.OP
    assert pg.parse_item() == (NFAState(), NFAState())
    pg.value = "NAME"
    pg.type = token.NAME
    assert pg.parse_item() == (NFAState(), NFAState())
    pg.value = "STRING"
    pg.type = token.STRING
    assert pg.parse_item() == (NFAState(), NFAState())
    pg.value = "+"
    pg.type = token.OP

# Generated at 2022-06-17 16:53:43.026395
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    pg = ParserGenerator()
    c = pg.make_converter()
    assert c.make_label(c, "NAME") == 0
    assert c.make_label(c, "NUMBER") == 1
    assert c.make_label(c, "STRING") == 2
    assert c.make_label(c, "if") == 3
    assert c.make_label(c, "else") == 4
    assert c.make_label(c, "elif") == 5
    assert c.make_label(c, "while") == 6
    assert c.make_label(c, "for") == 7
    assert c.make_label(c, "in") == 8
    assert c.make_label(c, "def") == 9
    assert c.make_label(c, "class") == 10

# Generated at 2022-06-17 16:53:53.747975
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    import io
    import tokenize
    import unittest
    from test.support import captured_stderr

    class TestCase(unittest.TestCase):
        def test_raise_error(self):
            with captured_stderr() as stderr:
                with self.assertRaises(SyntaxError):
                    ParserGenerator(
                        tokenize.generate_tokens(io.StringIO("").readline),
                        "<string>",
                    ).raise_error("expected %s/%s, got %s/%s", "foo", "bar", "baz", "qux")

# Generated at 2022-06-17 16:54:00.128227
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    pg = ParserGenerator()
    pg.add_production("foo", [("bar", "baz")])
    pg.add_production("bar", [("baz", "baz")])
    pg.add_production("baz", [("baz", "baz")])
    pg.add_production("baz", [])
    pg.make_grammar()


# Generated at 2022-06-17 16:54:08.788110
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    pg = ParserGenerator()
    pg.add_production("foo", "bar baz")
    pg.add_production("bar", "baz")
    pg.add_production("bar", "baz baz")
    pg.add_production("baz", "baz")
    pg.add_production("baz", "baz baz")
    pg.add_production("baz", "baz baz baz")
    pg.add_production("baz", "baz baz baz baz")
    pg.add_production("baz", "baz baz baz baz baz")
    pg.add_production("baz", "baz baz baz baz baz baz")

# Generated at 2022-06-17 16:54:20.143901
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    pg = ParserGenerator()
    pg.gettoken = lambda: None
    pg.type = token.NAME
    pg.value = "foo"
    pg.filename = "foo.py"
    pg.end = (1, 2)
    pg.line = "foo"
    a, z = pg.parse_item()
    assert a.arcs == [(None, z)]
    assert z.arcs == []
    pg.type = token.STRING
    pg.value = "bar"
    a, z = pg.parse_item()
    assert a.arcs == [("bar", z)]
    assert z.arcs == []
    pg.type = token.OP
    pg.value = "("
    a, z = pg.parse_item()
    assert a.arcs == [(None, z)]
   

# Generated at 2022-06-17 16:54:30.452711
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    pg = ParserGenerator()
    a = NFAState()
    z = NFAState()
    a.addarc(z, "a")
    dfa = pg.make_dfa(a, z)
    assert len(dfa) == 2
    assert dfa[0].nfaset == {a: 1}
    assert dfa[1].nfaset == {z: 1}
    assert dfa[0].arcs == {"a": dfa[1]}
    assert dfa[1].arcs == {}
    assert dfa[0].isfinal == False
    assert dfa[1].isfinal == True
    #
    a = NFAState()
    z = NFAState()
    a.addarc(z, "a")
    a.addarc(z, "b")
    d

# Generated at 2022-06-17 16:54:36.911137
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    pg = ParserGenerator()

# Generated at 2022-06-17 16:54:51.733389
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    # This is a unit test for method simplify_dfa of class ParserGenerator.
    # It is not run automatically.  To run it, type "python -m pgen2.pgen"
    # at the command line.

    # This test is based on a bug report by Fredrik Johansson.

    # The bug was that simplify_dfa would loop forever.  The reason
    # was that it would unify two states, then later try to unify
    # one of the unified states with another state, and fail to
    # notice that they were the same.  The fix was to change the
    # unifystate method to update the arcs of the states it is
    # called on.

    pg = ParserGenerator()

# Generated at 2022-06-17 16:55:42.386083
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    pg = ParserGenerator()
    pg.dfas = {
        "a": [DFAState({NFAState(): 1}, False), DFAState({NFAState(): 1}, False)],
        "b": [DFAState({NFAState(): 1}, False), DFAState({NFAState(): 1}, False)],
        "c": [DFAState({NFAState(): 1}, False), DFAState({NFAState(): 1}, False)],
    }
    pg.dfas["a"][0].addarc(pg.dfas["a"][1], "a")
    pg.dfas["a"][0].addarc(pg.dfas["b"][0], "b")
    pg.dfas["b"][0].addarc(pg.dfas["c"][0], "c")
    pg

# Generated at 2022-06-17 16:55:49.064184
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    pg = ParserGenerator()
    pg.dfas = {'foo': [DFAState({NFAState(): 1}, NFAState()), DFAState({NFAState(): 1}, NFAState())]}
    pg.dump_dfa('foo', pg.dfas['foo'])


# Generated at 2022-06-17 16:55:55.262062
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    pg = ParserGenerator()

# Generated at 2022-06-17 16:56:06.481630
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    pg = ParserGenerator()
    pg.dfas = {
        "a": [DFAState({}, False), DFAState({}, True)],
        "b": [DFAState({}, False), DFAState({}, True)],
        "c": [DFAState({}, False), DFAState({}, True)],
    }
    pg.first = {
        "a": {"a": 1, "b": 1},
        "b": {"c": 1},
        "c": {"a": 1, "b": 1},
    }
    c = pg.make_converter()
    assert c.make_first(c, "a") == {1: 1, 2: 1}
    assert c.make_first(c, "b") == {3: 1}

# Generated at 2022-06-17 16:56:07.929167
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    assert PgenGrammar()



# Generated at 2022-06-17 16:56:21.323633
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    pg = ParserGenerator()
    a = NFAState()
    z = NFAState()
    a.addarc(z, "a")
    dfa = pg.make_dfa(a, z)
    assert len(dfa) == 1
    assert dfa[0].nfaset == {a: 1, z: 1}
    assert dfa[0].arcs == {"a": dfa[0]}
    assert dfa[0].isfinal
    a = NFAState()
    z = NFAState()
    a.addarc(z, "a")
    a.addarc(z, "b")
    dfa = pg.make_dfa(a, z)
    assert len(dfa) == 1

# Generated at 2022-06-17 16:56:29.915379
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    import io
    import tokenize
    import unittest

    class ParserGeneratorTestCase(unittest.TestCase):
        def test_parse(self):
            s = """\
            # This is a comment
            start: '[' expr ']'
            expr: expr '+' term | expr '-' term | term
            term: term '*' factor | term '/' factor | factor
            factor: '(' expr ')' | NAME | NUMBER
            """
            f = io.StringIO(s)
            g = ParserGenerator()
            g.parse(f, "test")

    unittest.main()

# Generated at 2022-06-17 16:56:42.339333
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    pg = ParserGenerator()
    pg.dfas = {
        "a": [DFAState({}, False), DFAState({}, False)],
        "b": [DFAState({}, False), DFAState({}, False)],
        "c": [DFAState({}, False), DFAState({}, False)],
        "d": [DFAState({}, False), DFAState({}, False)],
        "e": [DFAState({}, False), DFAState({}, False)],
    }
    pg.dfas["a"][0].addarc(pg.dfas["b"][0], "b")
    pg.dfas["a"][0].addarc(pg.dfas["c"][0], "c")

# Generated at 2022-06-17 16:56:53.174834
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    import io
    import tokenize
    from typing import List
    from typing import Tuple
    from typing import Union
    from typing import cast

    def tokenize_string(s: str) -> List[Tuple[int, str, Tuple[int, int], Tuple[int, int], str]]:
        return list(tokenize.tokenize(io.BytesIO(s.encode("utf-8")).readline))

    def test_expect(s: str, type: int, value: Optional[str] = None) -> None:
        tokens = tokenize_string(s)
        p = ParserGenerator("<test>", tokens)
        p.gettoken()
        p.expect(type, value)


# Generated at 2022-06-17 16:56:58.659878
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    pg = ParserGenerator()
    pg.generator = tokenize.generate_tokens(io.StringIO("a").readline)
    pg.gettoken()
    a, z = pg.parse_item()
    assert a.arcs == [(None, z)]
    assert z.arcs == []
    assert a.arcs == [(None, z)]
    assert z.arcs == []
    pg.generator = tokenize.generate_tokens(io.StringIO("a+").readline)
    pg.gettoken()
    a, z = pg.parse_item()
    assert a.arcs == [(None, z)]
    assert z.arcs == [(None, a)]
    assert a.arcs == [(None, z)]
    assert z.arcs == [(None, a)]
   

# Generated at 2022-06-17 16:58:30.276910
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    pg = ParserGenerator()
    c = pg.make_converter()
    assert c.make_label(c, "NAME") == 0
    assert c.make_label(c, "NUMBER") == 1
    assert c.make_label(c, "STRING") == 2
    assert c.make_label(c, "LPAR") == 3
    assert c.make_label(c, "RPAR") == 4
    assert c.make_label(c, "LSQB") == 5
    assert c.make_label(c, "RSQB") == 6
    assert c.make_label(c, "COLON") == 7
    assert c.make_label(c, "COMMA") == 8
    assert c.make_label(c, "SEMI") == 9

# Generated at 2022-06-17 16:58:34.859141
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    pg = ParserGenerator()
    pg.gettoken = lambda: None
    pg.value = "("
    pg.parse_item = lambda: (NFAState(), NFAState())
    pg.parse_alt()

# Generated at 2022-06-17 16:58:44.941939
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    pg = ParserGenerator()
    dfa = [
        DFAState({NFAState(): 1}, NFAState()),
        DFAState({NFAState(): 1}, NFAState()),
        DFAState({NFAState(): 1}, NFAState()),
        DFAState({NFAState(): 1}, NFAState()),
    ]
    dfa[0].addarc(dfa[1], "a")
    dfa[0].addarc(dfa[2], "b")
    dfa[1].addarc(dfa[3], "c")
    dfa[2].addarc(dfa[3], "d")
    pg.simplify_dfa(dfa)
    assert len(dfa) == 3

# Generated at 2022-06-17 16:58:54.870543
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    import io
    import tokenize
    import unittest
    from . import parser_generator


# Generated at 2022-06-17 16:59:05.107093
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    # Test that the error message is correct
    pg = ParserGenerator()
    pg.filename = "test_ParserGenerator_raise_error"
    pg.end = (1, 2)
    pg.line = "line"
    try:
        pg.raise_error("%s %s", "foo", "bar")
    except SyntaxError as e:
        assert e.msg == "foo bar"
        assert e.filename == "test_ParserGenerator_raise_error"
        assert e.lineno == 1
        assert e.offset == 2
        assert e.text == "line"
    else:
        assert False, "Expected SyntaxError"



# Generated at 2022-06-17 16:59:12.379225
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    pg = ParserGenerator()
    pg.dfas = {
        "a": [DFAState({}, False), DFAState({}, False)],
        "b": [DFAState({}, False), DFAState({}, False)],
        "c": [DFAState({}, False), DFAState({}, False)],
    }
    pg.first = {
        "a": {"a": 1, "b": 1},
        "b": {"b": 1, "c": 1},
        "c": {"a": 1, "b": 1, "c": 1},
    }
    c = pg.make_converter()
    assert c.make_first(c, "a") == {0: 1, 1: 1}

# Generated at 2022-06-17 16:59:18.636727
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    pg = ParserGenerator()
    pg.symbol2number = {
        "foo": 1,
        "bar": 2,
        "baz": 3,
    }
    pg.labels = [
        (token.NAME, "foo"),
        (token.NAME, "bar"),
        (token.NAME, "baz"),
        (token.NAME, "qux"),
        (token.NAME, "quux"),
        (token.NAME, "corge"),
        (token.NAME, "grault"),
        (token.NAME, "garply"),
        (token.NAME, "waldo"),
        (token.NAME, "fred"),
        (token.NAME, "plugh"),
        (token.NAME, "xyzzy"),
        (token.NAME, "thud"),
    ]
    pg.sy

# Generated at 2022-06-17 16:59:28.481091
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    pg = ParserGenerator()
    pg.dfas = {
        "a": [DFAState({}, False), DFAState({}, False)],
        "b": [DFAState({}, False), DFAState({}, False)],
        "c": [DFAState({}, False), DFAState({}, False)],
    }
    pg.dfas["a"][0].addarc(pg.dfas["b"][0], "b")
    pg.dfas["a"][0].addarc(pg.dfas["c"][0], "c")
    pg.dfas["b"][0].addarc(pg.dfas["c"][0], "c")
    pg.dfas["c"][0].addarc(pg.dfas["a"][0], "a")
    pg.cal

# Generated at 2022-06-17 16:59:38.580896
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    pg = ParserGenerator()
    pg.generator = tokenize.generate_tokens(io.StringIO("a").readline)
    pg.gettoken()
    a, z = pg.parse_atom()
    assert a.arcs == [(None, z)]
    assert z.arcs == []
    assert a.arcs[0][1] is z
    assert z.arcs == []
    assert a.arcs[0][0] is None
    assert a.arcs[0][1] is z
    assert z.arcs == []
    assert a.arcs[0][0] is None
    assert a.arcs[0][1] is z
    assert z.arcs == []
    assert a.arcs[0][0] is None
    assert a.arcs[0][1]

# Generated at 2022-06-17 16:59:45.554529
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    pg = ParserGenerator()
    pg.dfas = {'foo': [DFAState({NFAState(): 1}, NFAState()), DFAState({NFAState(): 1}, NFAState())]}
    pg.dump_dfa('foo', pg.dfas['foo'])
