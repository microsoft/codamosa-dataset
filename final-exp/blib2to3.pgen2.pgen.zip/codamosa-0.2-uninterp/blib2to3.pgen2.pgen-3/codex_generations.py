

# Generated at 2022-06-17 16:50:52.543931
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    assert PgenGrammar()



# Generated at 2022-06-17 16:51:02.719735
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    pg = ParserGenerator()
    a = NFAState()
    z = NFAState()
    a.addarc(z, "a")
    dfa = pg.make_dfa(a, z)
    assert len(dfa) == 2
    assert dfa[0].arcs == {"a": dfa[1]}
    assert dfa[1].arcs == {}
    assert dfa[0].nfaset == {a}
    assert dfa[1].nfaset == {z}
    assert dfa[0].isfinal == False
    assert dfa[1].isfinal == True

# Generated at 2022-06-17 16:51:13.825605
# Unit test for method simplify_dfa of class ParserGenerator

# Generated at 2022-06-17 16:51:27.188598
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    pg = ParserGenerator()
    a = NFAState()
    z = NFAState()
    a.addarc(z, "a")
    dfa = pg.make_dfa(a, z)
    assert len(dfa) == 2
    assert dfa[0].nfaset == {a: 1}
    assert dfa[1].nfaset == {z: 1}
    assert dfa[0].arcs == {"a": dfa[1]}
    assert dfa[1].arcs == {}

    a = NFAState()
    z = NFAState()
    a.addarc(z, "a")
    a.addarc(z, "b")
    dfa = pg.make_dfa(a, z)
    assert len(dfa) == 2
    assert d

# Generated at 2022-06-17 16:51:34.053389
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    # This is a unit test for the method simplify_dfa of class ParserGenerator.
    # It is not run by default.  To run it, execute this file.
    #
    # This test is not very good, because it doesn't check that the
    # result is correct.  It just checks that the method doesn't crash.
    #
    # The test is based on the example in the docstring of the
    # ParserGenerator class.
    pg = ParserGenerator()
    pg.add_rhs("start", ["a", "b", "c"])
    pg.add_rhs("start", ["a", "b", "d"])
    pg.add_rhs("start", ["a", "e"])
    pg.add_rhs("start", ["f"])

# Generated at 2022-06-17 16:51:46.725642
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    pg = ParserGenerator()
    pg.dump_dfa("foo", [DFAState({}, False), DFAState({}, True)])
    pg.dump_dfa("foo", [DFAState({}, False, {'a': [DFAState({}, True)]})])
    pg.dump_dfa("foo", [DFAState({}, False, {'a': [DFAState({}, False)]})])
    pg.dump_dfa("foo", [DFAState({}, False, {'a': [DFAState({}, False)], 'b': [DFAState({}, True)]})])
    pg.dump_dfa("foo", [DFAState({}, False, {'a': [DFAState({}, False)], 'b': [DFAState({}, False)]})])
    pg.dump_dfa

# Generated at 2022-06-17 16:51:58.589927
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    pg = ParserGenerator()
    pg.add_rule("a", ["b", "c"])
    pg.add_rule("b", ["d", "e"])
    pg.add_rule("c", ["f", "g"])
    pg.add_rule("d", ["h", "i"])
    pg.add_rule("e", ["j", "k"])
    pg.add_rule("f", ["l", "m"])
    pg.add_rule("g", ["n", "o"])
    pg.add_rule("h", ["p", "q"])
    pg.add_rule("i", ["r", "s"])
    pg.add_rule("j", ["t", "u"])
    pg.add_rule("k", ["v", "w"])

# Generated at 2022-06-17 16:52:09.734175
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    pg = ParserGenerator()
    a = NFAState()
    z = NFAState()
    a.addarc(z, "a")
    dfa = pg.make_dfa(a, z)
    assert len(dfa) == 2
    assert dfa[0].arcs == {"a": dfa[1]}
    assert dfa[1].arcs == {}
    assert dfa[1].isfinal
    assert not dfa[0].isfinal
    a = NFAState()
    z = NFAState()
    a.addarc(z, "a")
    a.addarc(z, "b")
    dfa = pg.make_dfa(a, z)
    assert len(dfa) == 2

# Generated at 2022-06-17 16:52:18.573530
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    import io
    import tokenize
    from . import grammar

    def test(text: str, expected: Dict[Text, List["DFAState"]]) -> None:
        # print "Testing", repr(text)
        f = io.StringIO(text)
        tokens = tokenize.generate_tokens(f.readline)
        p = ParserGenerator()
        dfas, startsymbol = p.parse(tokens, "<string>")
        assert dfas == expected
        assert startsymbol == "file_input"


# Generated at 2022-06-17 16:52:30.349628
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    pg = ParserGenerator()
    pg.dfas = {
        "a": [DFAState({}, False), DFAState({}, True)],
        "b": [DFAState({}, False), DFAState({}, True)],
        "c": [DFAState({}, False), DFAState({}, True)],
        "d": [DFAState({}, False), DFAState({}, True)],
        "e": [DFAState({}, False), DFAState({}, True)],
        "f": [DFAState({}, False), DFAState({}, True)],
        "g": [DFAState({}, False), DFAState({}, True)],
    }
    pg.dfas["a"][0].addarc(pg.dfas["b"][0], "a")
    pg.df

# Generated at 2022-06-17 16:53:05.230503
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    pg = ParserGenerator()
    pg.dfas = {
        "a": [
            DFAState({NFAState(): 1}, None),
            DFAState({NFAState(): 1}, None),
            DFAState({NFAState(): 1}, None),
        ],
        "b": [
            DFAState({NFAState(): 1}, None),
            DFAState({NFAState(): 1}, None),
            DFAState({NFAState(): 1}, None),
        ],
    }
    pg.dfas["a"][0].addarc(pg.dfas["a"][1], "a")
    pg.dfas["a"][1].addarc(pg.dfas["a"][2], "b")

# Generated at 2022-06-17 16:53:17.630661
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    pg = ParserGenerator()

# Generated at 2022-06-17 16:53:30.618656
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    pg = ParserGenerator()
    pg.add_production("foo", ["bar", "baz"])
    pg.add_production("bar", ["baz", "baz"])
    pg.add_production("baz", ["'a'", "'b'"])
    pg.add_production("baz", ["'c'"])
    pg.add_production("baz", ["'d'"])
    pg.add_production("baz", ["'e'"])
    pg.add_production("baz", ["'f'"])
    pg.add_production("baz", ["'g'"])
    pg.add_production("baz", ["'h'"])
    pg.add_production("baz", ["'i'"])

# Generated at 2022-06-17 16:53:42.669646
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    pg = ParserGenerator()

# Generated at 2022-06-17 16:53:53.394921
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    pg = ParserGenerator()
    pg.generator = tokenize.generate_tokens(io.StringIO("(a|b)").readline)
    pg.gettoken()
    a, z = pg.parse_atom()
    assert a.arcs == [(None, z)]
    pg.generator = tokenize.generate_tokens(io.StringIO("a").readline)
    pg.gettoken()
    a, z = pg.parse_atom()
    assert a.arcs == [("a", z)]
    pg.generator = tokenize.generate_tokens(io.StringIO('"a"').readline)
    pg.gettoken()
    a, z = pg.parse_atom()
    assert a.arcs == [("a", z)]
    pg.generator

# Generated at 2022-06-17 16:54:04.574251
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    import io
    import tokenize
    from typing import Iterator
    from typing import Tuple

    def get_tokens(s: str) -> Iterator[Tuple[int, str, Tuple[int, int], Tuple[int, int], str]]:
        f = io.StringIO(s)
        return tokenize.generate_tokens(f.readline)

    pg = ParserGenerator()
    pg.generator = get_tokens("a = 1")
    pg.gettoken()
    assert pg.type == token.NAME
    assert pg.value == "a"
    pg.gettoken()
    assert pg.type == token.OP
    assert pg.value == "="
    pg.gettoken()
    assert pg.type == token.NUMBER
    assert pg.value == "1"

# Generated at 2022-06-17 16:54:11.287824
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    pg = ParserGenerator()
    pg.add_production("S", ("a", "b", "c"))
    pg.add_production("S", ("a", "b", "d"))
    pg.add_production("S", ("a", "e"))
    pg.add_production("S", ("f",))
    pg.add_production("S", ("g",))
    pg.add_production("S", ("h",))
    pg.add_production("S", ("i",))
    pg.add_production("S", ("j",))
    pg.add_production("S", ("k",))
    pg.add_production("S", ("l",))
    pg.add_production("S", ("m",))
    pg.add_production("S", ("n",))

# Generated at 2022-06-17 16:54:20.355399
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    pg = ParserGenerator()
    pg.generator = tokenize.generate_tokens(io.StringIO("a").readline)
    pg.gettoken()
    assert pg.parse_item() == (NFAState([(None, NFAState([('a', None)]))]),
                               NFAState([(None, None)]))
    pg.generator = tokenize.generate_tokens(io.StringIO("a+").readline)
    pg.gettoken()
    a, z = pg.parse_item()
    assert a == NFAState([(None, NFAState([('a', None)]))])
    assert z == NFAState([(None, NFAState([('a', None)]))])

# Generated at 2022-06-17 16:54:24.696241
# Unit test for function generate_grammar
def test_generate_grammar():
    # Test the parser generator
    p = ParserGenerator("Grammar.txt")
    p.make_grammar()
    # print p.dfas
    # print p.first
    # print p.labels
    # print p.keywords
    # print p.tokens
    # print p.dfas["expr_stmt"][0].arcs.keys()
    # print p.dfas["expr_stmt"][0].arcs[p.keywords["print"]].arcs.keys()
    # print p.dfas["expr_stmt"][0].arcs[p.keywords["print"]].arcs[p.tokens[token.NAME]].arcs.keys()
    # print p.dfas["expr_stmt"][0].arcs[p.keywords["print"]

# Generated at 2022-06-17 16:54:35.261412
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    pg = ParserGenerator()
    pg.gettoken = lambda: None
    pg.value = "("
    pg.parse_item = lambda: (NFAState(), NFAState())
    pg.parse_alt()
    pg.value = ")"
    pg.parse_alt()
    pg.value = "|"
    pg.parse_alt()
    pg.value = "("
    pg.parse_alt()
    pg.value = ")"
    pg.parse_alt()
    pg.value = "|"
    pg.parse_alt()
    pg.value = "("
    pg.parse_alt()
    pg.value = ")"
    pg.parse_alt()
    pg.value = "|"
    pg.parse_alt()
    pg.value = "("
    pg.parse_alt

# Generated at 2022-06-17 16:55:25.541111
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    pg = ParserGenerator()
    pg.gettoken = lambda: None
    pg.value = "("
    pg.type = token.OP
    pg.parse_rhs = lambda: (NFAState(), NFAState())
    pg.expect = lambda type, value: None
    pg.parse_item()
    pg.value = "["
    pg.parse_item()
    pg.value = "NAME"
    pg.type = token.NAME
    pg.parse_item()
    pg.value = "STRING"
    pg.type = token.STRING
    pg.parse_item()
    pg.value = "+"
    pg.parse_item()
    pg.value = "*"
    pg.parse_item()
    pg.value = "?"

# Generated at 2022-06-17 16:55:27.189075
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    # Test the constructor of class PgenGrammar
    PgenGrammar()



# Generated at 2022-06-17 16:55:39.450176
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    pg = ParserGenerator()
    pg.symbol2number = {'foo': 1, 'bar': 2}
    pg.labels = []
    pg.tokens = {1: 3, 2: 4, 3: 5}
    pg.keywords = {'baz': 6}
    c = pg.make_converter()
    assert c.make_label(c, 'foo') == 1
    assert c.make_label(c, 'bar') == 2
    assert c.make_label(c, 'NAME') == 3
    assert c.make_label(c, 'NUMBER') == 4
    assert c.make_label(c, 'STRING') == 5
    assert c.make_label(c, 'baz') == 6
    assert c.make_label(c, '+') == 7


# Generated at 2022-06-17 16:55:51.948294
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    pg = ParserGenerator()
    pg.symbol2number = {
        "NAME": 1,
        "NUMBER": 2,
        "STRING": 3,
        "expr": 4,
        "term": 5,
        "factor": 6,
    }
    pg.labels = []
    pg.tokens = {}
    pg.keywords = {}
    pg.symbol2label = {}
    c = pg.make_converter()
    assert c.make_label(c, "NAME") == 1
    assert c.make_label(c, "NUMBER") == 2
    assert c.make_label(c, "STRING") == 3
    assert c.make_label(c, "expr") == 4
    assert c.make_label(c, "term") == 5

# Generated at 2022-06-17 16:55:55.554125
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    pg = ParserGenerator()
    assert pg.dfas == {}
    assert pg.first == {}
    assert pg.startsymbol is None


# Generated at 2022-06-17 16:56:06.630140
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    pg = ParserGenerator()
    c = pg.converter()
    assert pg.make_label(c, "NAME") == 0
    assert pg.make_label(c, "NUMBER") == 1
    assert pg.make_label(c, "STRING") == 2
    assert pg.make_label(c, "foo") == 3
    assert pg.make_label(c, "bar") == 4
    assert pg.make_label(c, "baz") == 5
    assert pg.make_label(c, "foo") == 3
    assert pg.make_label(c, "bar") == 4
    assert pg.make_label(c, "baz") == 5
    assert pg.make_label(c, "foo") == 3
    assert pg.make_label(c, "bar") == 4


# Generated at 2022-06-17 16:56:19.207285
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    from . import pgen2
    from . import token

    def test(grammar: str) -> None:
        pg = pgen2.ParserGenerator(grammar)
        for name, dfa in pg.dfas.items():
            pg.dump_dfa(name, dfa)

    test(
        """
        expr: x='(' x=expr ')' {x}
           | x=expr '*' y=expr {x*y}
           | x=expr '+' y=expr {x+y}
           | INT {int(x)}
        """
    )

# Generated at 2022-06-17 16:56:27.354200
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    pg = ParserGenerator()
    pg.setup("abc : 'a' | 'b' | 'c'")
    a, z = pg.parse_rhs()
    assert a.arcs == [(None, a.next), ("a", z), ("b", z), ("c", z)]
    assert z.arcs == []
    assert a.next.arcs == []
    assert a.next.next is None
    assert z.next is None


# Generated at 2022-06-17 16:56:31.087244
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    pg = ParserGenerator()
    pg.dfas = {'foo': [DFAState({NFAState(): 1}, NFAState()),
                       DFAState({NFAState(): 1}, NFAState())]}
    pg.dump_dfa('foo', pg.dfas['foo'])


# Generated at 2022-06-17 16:56:41.235412
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    import unittest

    class TestCase(unittest.TestCase):
        def test_simplify_dfa(self):
            # Test that simplify_dfa() doesn't change the DFA
            pg = ParserGenerator()
            dfa = pg.make_dfa(NFAState(), NFAState())
            pg.simplify_dfa(dfa)
            self.assertEqual(len(dfa), 1)
            self.assertEqual(len(dfa[0].arcs), 0)

    unittest.main()

# Generated at 2022-06-17 16:58:07.804387
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    pg = ParserGenerator()
    pg.gettoken = lambda: None
    pg.value = "("
    pg.type = token.OP
    pg.parse_rhs = lambda: (1, 2)
    assert pg.parse_item() == (1, 2)
    pg.value = "["
    assert pg.parse_item() == (1, 2)
    pg.value = "NAME"
    pg.type = token.NAME
    pg.parse_atom = lambda: (3, 4)
    assert pg.parse_item() == (3, 4)
    pg.value = "+"
    assert pg.parse_item() == (3, 4)
    pg.value = "*"
    assert pg.parse_item() == (3, 3)


# Generated at 2022-06-17 16:58:16.771436
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    pg = ParserGenerator()
    pg.symbol2number = {"foo": 1, "bar": 2}
    pg.tokens = {token.NAME: 3, token.NUMBER: 4, token.STRING: 5}
    pg.keywords = {"def": 6, "class": 7}
    pg.labels = [
        (token.NAME, "def"),
        (token.NAME, "class"),
        (token.NAME, "foo"),
        (token.NAME, "bar"),
        (token.NAME, "NAME"),
        (token.NAME, "NUMBER"),
        (token.NAME, "STRING"),
    ]
    pg.symbol2label = {"foo": 2, "bar": 3}
    assert pg.make_label(pg, "foo") == 2
    assert pg.make_label

# Generated at 2022-06-17 16:58:26.406706
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    pg = ParserGenerator()
    pg.add_rhs("foo", "bar baz")
    pg.add_rhs("foo", "bar baz")
    pg.add_rhs("foo", "bar baz")
    pg.add_rhs("foo", "bar baz")
    pg.add_rhs("foo", "bar baz")
    pg.add_rhs("foo", "bar baz")
    pg.add_rhs("foo", "bar baz")
    pg.add_rhs("foo", "bar baz")
    pg.add_rhs("foo", "bar baz")
    pg.add_rhs("foo", "bar baz")
    pg.add_rhs("foo", "bar baz")

# Generated at 2022-06-17 16:58:36.030792
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    pg = ParserGenerator()
    a = NFAState()
    z = NFAState()
    a.addarc(z, "a")
    dfa = pg.make_dfa(a, z)
    assert len(dfa) == 2
    assert dfa[0].nfaset == {a: 1, z: 1}
    assert dfa[1].nfaset == {z: 1}
    assert dfa[0].arcs == {"a": dfa[1]}
    assert dfa[1].arcs == {}

# Generated at 2022-06-17 16:58:42.613470
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    # Test that the error message is correct
    try:
        raise ParserGenerator([]).raise_error("%s %s", "a", "b")
    except SyntaxError as e:
        assert e.msg == "a b"
        assert e.filename == "<string>"
        assert e.lineno == 1
        assert e.offset == 0
        assert e.text == ""
    else:
        assert False, "Expected SyntaxError"

# Generated at 2022-06-17 16:58:54.281092
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    pg = ParserGenerator()
    a = NFAState()
    z = NFAState()
    a.addarc(z, "a")
    dfa = pg.make_dfa(a, z)
    assert len(dfa) == 2
    assert dfa[0].nfaset == {a: 1}
    assert dfa[1].nfaset == {z: 1}
    assert dfa[0].arcs == {"a": dfa[1]}
    assert dfa[1].arcs == {}

    a = NFAState()
    z = NFAState()
    a.addarc(z, "a")
    a.addarc(z, "b")
    dfa = pg.make_dfa(a, z)
    assert len(dfa) == 2
    assert d

# Generated at 2022-06-17 16:59:06.456219
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    pg = ParserGenerator()
    pg.gettoken = lambda: None
    pg.value = "("
    pg.parse_rhs = lambda: (1, 2)
    pg.gettoken = lambda: None
    pg.value = ")"
    assert pg.parse_item() == (1, 2)
    pg.value = "["
    pg.gettoken = lambda: None
    pg.value = "]"
    assert pg.parse_item() == (1, 2)
    pg.value = "NAME"
    pg.gettoken = lambda: None
    pg.value = "+"
    assert pg.parse_item() == (1, 2)
    pg.value = "*"
    assert pg.parse_item() == (1, 1)
    pg.value = "NAME"

# Generated at 2022-06-17 16:59:16.857885
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    pg = ParserGenerator()

# Generated at 2022-06-17 16:59:27.596272
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    import io
    import tokenize
    import unittest

    class TestCase(unittest.TestCase):
        def test_gettoken(self):
            pg = ParserGenerator()
            pg.filename = "<test>"
            pg.generator = tokenize.generate_tokens(io.StringIO("a = 1\n").readline)
            pg.gettoken()
            self.assertEqual(pg.type, token.NAME)
            self.assertEqual(pg.value, "a")
            self.assertEqual(pg.begin, (1, 0))
            self.assertEqual(pg.end, (1, 1))
            self.assertEqual(pg.line, "a = 1\n")
            pg.gettoken()

# Generated at 2022-06-17 16:59:37.991742
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    pg = ParserGenerator()
    pg.add_production("a", ["b", "c"])
    pg.add_production("a", ["d", "e"])
    pg.add_production("b", ["f"])
    pg.add_production("b", ["g"])
    pg.add_production("c", ["h"])
    pg.add_production("c", ["i"])
    pg.add_production("d", ["j"])
    pg.add_production("d", ["k"])
    pg.add_production("e", ["l"])
    pg.add_production("e", ["m"])
    pg.add_production("f", ["n"])
    pg.add_production("f", ["o"])
    pg.add_production("g", ["p"])
    pg