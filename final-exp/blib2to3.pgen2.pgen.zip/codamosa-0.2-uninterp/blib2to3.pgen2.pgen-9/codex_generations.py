

# Generated at 2022-06-17 16:51:51.808560
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    import io
    import tokenize
    from typing import Generator
    from typing import Tuple
    from typing import Union
    from typing import cast
    from typing import Any
    from typing import List
    from typing import Optional
    from typing import Text
    from typing import Dict
    from typing import Sequence
    from typing import TypeVar
    from typing import Callable
    from typing import Type
    from typing import cast
    from typing import overload
    from typing import NamedTuple
    from typing import Iterable
    from typing import Iterator
    from typing import Tuple
    from typing import Union
    from typing import List
    from typing import Optional
    from typing import Text
    from typing import Dict
    from typing import Sequence
    from typing import TypeVar
    from typing import Callable
    from typing import Type
    from typing import cast

# Generated at 2022-06-17 16:51:55.226929
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    pg = ParserGenerator()
    pg.dfas = {'foo': [DFAState({NFAState(): 1}, NFAState()), DFAState({NFAState(): 1}, NFAState())]}
    pg.dump_dfa('foo', pg.dfas['foo'])


# Generated at 2022-06-17 16:52:06.781220
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    pg = ParserGenerator()
    pg.filename = "test_ParserGenerator_raise_error"
    pg.end = (1, 2)
    pg.line = "line"
    try:
        pg.raise_error("msg")
    except SyntaxError as e:
        assert e.msg == "msg"
        assert e.filename == "test_ParserGenerator_raise_error"
        assert e.lineno == 1
        assert e.offset == 2
        assert e.text == "line"
    else:
        assert False, "Expected SyntaxError"
    try:
        pg.raise_error("msg %s %s", 3, 4)
    except SyntaxError as e:
        assert e.msg == "msg 3 4"

# Generated at 2022-06-17 16:52:16.036671
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    import io
    import tokenize
    import unittest
    import unittest.mock

    class MockTokenizer(unittest.mock.Mock):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

# Generated at 2022-06-17 16:52:19.005600
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    pg = ParserGenerator()
    pg.dump_nfa("foo", NFAState(), NFAState())
    pg.dump_nfa("bar", NFAState(), NFAState())
    pg.dump_nfa("baz", NFAState(), NFAState())


# Generated at 2022-06-17 16:52:19.743425
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    PgenGrammar()



# Generated at 2022-06-17 16:52:32.035661
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    pg = ParserGenerator()
    pg.add_nonterminal("file_input", [
        ("NEWLINE", "NEWLINE"),
        ("stmt", "stmt"),
        ("file_input", "file_input", "stmt"),
        ("file_input", "file_input", "NEWLINE"),
        ("file_input", "file_input", "NEWLINE", "stmt"),
    ])
    pg.add_nonterminal("stmt", [
        ("simple_stmt", "simple_stmt"),
        ("compound_stmt", "compound_stmt"),
    ])

# Generated at 2022-06-17 16:52:41.449615
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    import io
    import tokenize
    import unittest

    class ParserGeneratorTest(unittest.TestCase):
        def test_parse(self):
            pg = ParserGenerator()
            pg.parse(io.StringIO("a: 'a'\n"))
            pg.parse(io.StringIO("a: 'a'\n"))
            pg.parse(io.StringIO("a: 'a'\n"))
            pg.parse(io.StringIO("a: 'a'\n"))
            pg.parse(io.StringIO("a: 'a'\n"))
            pg.parse(io.StringIO("a: 'a'\n"))
            pg.parse(io.StringIO("a: 'a'\n"))

# Generated at 2022-06-17 16:52:55.382327
# Unit test for method simplify_dfa of class ParserGenerator

# Generated at 2022-06-17 16:53:08.332005
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    pg = ParserGenerator()
    pg.parse(
        """
        start: '[' expr ']'
        expr: expr '+' term | expr '-' term | term
        term: term '*' factor | term '/' factor | factor
        factor: '(' expr ')' | NAME | NUMBER
        """
    )
    assert pg.dfas["start"][0].arcs == {"[": pg.dfas["start"][0].arcs["["]}

# Generated at 2022-06-17 16:53:50.735854
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    pg = ParserGenerator()
    pg.dfas = {
        "a": [DFAState({}, False), DFAState({}, True)],
        "b": [DFAState({}, False), DFAState({}, True)],
        "c": [DFAState({}, False), DFAState({}, True)],
    }
    pg.first = {"a": {"a": 1}, "b": {"b": 1}, "c": {"c": 1}}
    c = pg.make_converter()
    assert c.first == {
        0: {0: 1},
        1: {1: 1},
        2: {2: 1},
    }

# Generated at 2022-06-17 16:54:02.381170
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    pg = ParserGenerator()
    pg.setup()
    pg.addtoken(token.NAME, "foo")
    pg.addtoken(token.OP, ":")
    pg.addtoken(token.NAME, "bar")
    pg.addtoken(token.OP, "|")
    pg.addtoken(token.NAME, "baz")
    pg.addtoken(token.NEWLINE)
    pg.addtoken(token.ENDMARKER)
    pg.make_rhs()
    assert pg.rhs == [
        [("bar", None), ("baz", None)],
    ]

# Generated at 2022-06-17 16:54:07.226172
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    pg = ParserGenerator()
    pg.generator = iter([(token.NAME, "foo", (1, 0), (1, 3), "foo\n")])
    pg.gettoken()
    assert pg.type == token.NAME
    assert pg.value == "foo"
    assert pg.begin == (1, 0)
    assert pg.end == (1, 3)
    assert pg.line == "foo\n"


# Generated at 2022-06-17 16:54:17.969525
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    pg = ParserGenerator()
    pg.dfas = {
        "a": [DFAState({}, False), DFAState({}, True)],
        "b": [DFAState({}, False), DFAState({}, True)],
    }
    pg.symbol2number = {"a": 0, "b": 1}
    pg.labels = [
        (token.NAME, "a"),
        (token.NAME, "b"),
        (token.NAME, "c"),
        (token.NAME, "d"),
        (token.NAME, "e"),
        (token.NAME, "f"),
    ]
    pg.tokens = {token.NAME: 0, token.NUMBER: 1, token.STRING: 2}

# Generated at 2022-06-17 16:54:28.508672
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    import pgen2.pgen
    import pgen2.token
    import pgen2.grammar
    import pgen2.converter
    import pgen2.pgen
    import pgen2.token
    import pgen2.grammar
    import pgen2.converter
    import pgen2.pgen
    import pgen2.token
    import pgen2.grammar
    import pgen2.converter
    import pgen2.pgen
    import pgen2.token
    import pgen2.grammar
    import pgen2.converter
    import pgen2.pgen
    import pgen2.token
    import pgen2.grammar
    import pgen2.converter
    import pgen2.pgen
    import pgen2.token

# Generated at 2022-06-17 16:54:38.346555
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    pg = ParserGenerator()
    pg.add_nonterminal("foo", [("bar", None), ("baz", None)])
    pg.add_nonterminal("bar", [("'x'", None)])
    pg.add_nonterminal("baz", [("'y'", None)])
    pg.add_nonterminal("start", [("foo", None)])
    pg.compile()
    assert pg.dfas["foo"][0].arcs == {'x': pg.dfas["foo"][1], 'y': pg.dfas["foo"][2]}
    assert pg.dfas["foo"][1].arcs == {'y': pg.dfas["foo"][2]}
    assert pg.dfas["foo"][2].arcs == {}
    assert pg.dfas

# Generated at 2022-06-17 16:54:39.681801
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    pg = ParserGenerator()
    pg.parse_item()
    assert False, "Test failed"

# Generated at 2022-06-17 16:54:52.551193
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    pgen_grammar = PgenGrammar()
    assert pgen_grammar.start == "file_input"
    assert pgen_grammar.keywords == {}
    assert pgen_grammar.tokens == []
    assert pgen_grammar.symbol2number == {}
    assert pgen_grammar.number2symbol == {}
    assert pgen_grammar.dfas == {}
    assert pgen_grammar.states == {}
    assert pgen_grammar.first == {}
    assert pgen_grammar.error_func == None
    assert pgen_grammar.error_func_name == None
    assert pgen_grammar.literals == []
    assert pgen_grammar.symbol2label == {}
    assert pgen_grammar.label2symbol == {}

# Generated at 2022-06-17 16:55:04.774802
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    pg = ParserGenerator()
    a = NFAState()
    z = NFAState()
    a.addarc(z, "a")
    dfa = pg.make_dfa(a, z)
    assert len(dfa) == 2
    assert len(dfa[0].arcs) == 1
    assert len(dfa[1].arcs) == 0
    assert dfa[0].arcs["a"] is dfa[1]
    assert dfa[0].isfinal == False
    assert dfa[1].isfinal == True

    a = NFAState()
    z = NFAState()
    a.addarc(z, "a")
    a.addarc(z, "b")
    dfa = pg.make_dfa(a, z)
    assert len(dfa)

# Generated at 2022-06-17 16:55:13.411617
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    pg = ParserGenerator()
    pg.add_nonterminal("file_input", [
        ("NEWLINE", "stmt", "NEWLINE"),
        ("NEWLINE", "stmt", "NEWLINE", "file_input"),
        ("NEWLINE", "file_input"),
        ("NEWLINE"),
        ("ENDMARKER"),
    ])
    pg.add_nonterminal("stmt", [
        ("simple_stmt"),
        ("compound_stmt"),
    ])

# Generated at 2022-06-17 16:56:33.954695
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    pg = ParserGenerator()

# Generated at 2022-06-17 16:56:45.262873
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    pg = ParserGenerator()
    a = NFAState()
    z = NFAState()
    a.addarc(z, "a")
    dfa = pg.make_dfa(a, z)
    assert len(dfa) == 2
    assert dfa[0].nfaset == {a: 1}
    assert dfa[1].nfaset == {z: 1}
    assert dfa[0].arcs == {"a": dfa[1]}
    assert dfa[1].arcs == {}
    assert dfa[0].isfinal == False
    assert dfa[1].isfinal == True
    #
    a = NFAState()
    z = NFAState()
    a.addarc(z, "a")
    a.addarc(z, "b")
    d

# Generated at 2022-06-17 16:56:51.605427
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    pg = ParserGenerator()
    pg.generator = iter([(token.NAME, "foo", (1, 0), (1, 3), "foo")])
    pg.gettoken()
    assert pg.type == token.NAME
    assert pg.value == "foo"
    assert pg.begin == (1, 0)
    assert pg.end == (1, 3)
    assert pg.line == "foo"


# Generated at 2022-06-17 16:56:59.206719
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    import io
    import tokenize
    import unittest
    from test.support import captured_stderr
    from typing import List
    from typing import Tuple
    from typing import Union
    from typing import cast
    from typing import TYPE_CHECKING
    if TYPE_CHECKING:
        from typing import Generator
        from typing import Optional

# Generated at 2022-06-17 16:57:11.761826
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    import io
    import tokenize
    import unittest
    import unittest.mock

    from typing import Any, List, Tuple

    from . import grammar

    class MockTokenize:
        def __init__(self, filename: str, readline: str) -> None:
            self.filename = filename
            self.readline = readline
            self.tokens: List[Tuple[int, str, Tuple[int, int], Tuple[int, int], str]] = []

        def tokenize(self, readline: Any) -> Any:
            self.tokens = []
            tokenize.tokenize(readline, self.tokeneater)
            return iter(self.tokens)


# Generated at 2022-06-17 16:57:14.837357
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    pg = ParserGenerator()
    a = NFAState()
    z = NFAState()
    a.addarc(z, "a")
    dfa = pg.make_dfa(a, z)
    assert len(dfa) == 2
    assert dfa[0].isfinal == False
    assert dfa[1].isfinal == True
    assert dfa[0].arcs == {'a': [dfa[1]]}
    assert dfa[1].arcs == {}


# Generated at 2022-06-17 16:57:24.705152
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    pg = ParserGenerator()
    pg.dump_nfa("foo", NFAState(), NFAState())
    pg.dump_nfa("foo", NFAState(), NFAState())
    pg.dump_nfa("foo", NFAState(), NFAState())
    pg.dump_nfa("foo", NFAState(), NFAState())
    pg.dump_nfa("foo", NFAState(), NFAState())
    pg.dump_nfa("foo", NFAState(), NFAState())
    pg.dump_nfa("foo", NFAState(), NFAState())
    pg.dump_nfa("foo", NFAState(), NFAState())
    pg.dump_nfa("foo", NFAState(), NFAState())
    pg.dump_nfa("foo", NFAState(), NFAState())


# Generated at 2022-06-17 16:57:29.959471
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    pg = ParserGenerator()
    pg.gettoken = lambda: None
    pg.value = "("
    pg.parse_item = lambda: (None, None)
    pg.parse_atom = lambda: (None, None)
    pg.parse_rhs = lambda: (None, None)
    pg.parse_alt()


# Generated at 2022-06-17 16:57:39.712000
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    import io
    import tokenize
    import unittest
    from test.support import captured_stdout, captured_stderr

    class Test(unittest.TestCase):
        def test_expect(self):
            with captured_stderr() as stderr:
                with captured_stdout() as stdout:
                    with self.assertRaises(SyntaxError):
                        pg = ParserGenerator()
                        pg.generator = tokenize.generate_tokens(io.StringIO("").readline)
                        pg.filename = "<string>"
                        pg.gettoken()
                        pg.expect(token.NAME, "foo")
                    self.assertEqual(stdout.getvalue(), "")

# Generated at 2022-06-17 16:57:53.030686
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    pg = ParserGenerator()
    c = pg.make_converter()
    assert c.make_label(c, "NAME") == 0
    assert c.make_label(c, "NUMBER") == 1
    assert c.make_label(c, "STRING") == 2
    assert c.make_label(c, "if") == 3
    assert c.make_label(c, "while") == 4
    assert c.make_label(c, "def") == 5
    assert c.make_label(c, "class") == 6
    assert c.make_label(c, "foo") == 7
    assert c.make_label(c, "bar") == 8
    assert c.make_label(c, "baz") == 9
    assert c.make_label(c, "|") == 10