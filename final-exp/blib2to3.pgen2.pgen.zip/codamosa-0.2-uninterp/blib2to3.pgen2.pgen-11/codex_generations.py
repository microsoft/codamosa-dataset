

# Generated at 2022-06-17 16:51:31.743989
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    pg = ParserGenerator()
    pg.dfas = {
        "a": [DFAState({}, False), DFAState({}, False)],
        "b": [DFAState({}, False), DFAState({}, False)],
        "c": [DFAState({}, False), DFAState({}, False)],
    }
    pg.dfas["a"][0].addarc(pg.dfas["b"][0], "x")
    pg.dfas["a"][0].addarc(pg.dfas["c"][0], "y")
    pg.dfas["b"][1].addarc(pg.dfas["a"][1], "z")
    pg.dfas["c"][1].addarc(pg.dfas["a"][1], "z")
    pg.add

# Generated at 2022-06-17 16:51:42.429496
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    pg = ParserGenerator()
    pg.gettoken()
    assert pg.type == token.ENDMARKER
    assert pg.value == ""
    assert pg.begin == (1, 0)
    assert pg.end == (1, 0)
    assert pg.line == ""
    pg.gettoken()
    assert pg.type == token.ENDMARKER
    assert pg.value == ""
    assert pg.begin == (1, 0)
    assert pg.end == (1, 0)
    assert pg.line == ""
    pg.generator = tokenize.generate_tokens(io.StringIO("a = 1").readline)
    pg.gettoken()
    assert pg.type == token.NAME
    assert pg.value == "a"
    assert pg.begin == (1, 0)

# Generated at 2022-06-17 16:51:54.297308
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    pg = ParserGenerator()
    pg.make_dfa(NFAState(), NFAState())
    pg.make_dfa(NFAState(), NFAState())
    pg.make_dfa(NFAState(), NFAState())
    pg.make_dfa(NFAState(), NFAState())
    pg.make_dfa(NFAState(), NFAState())
    pg.make_dfa(NFAState(), NFAState())
    pg.make_dfa(NFAState(), NFAState())
    pg.make_dfa(NFAState(), NFAState())
    pg.make_dfa(NFAState(), NFAState())
    pg.make_dfa(NFAState(), NFAState())
    pg.make_dfa(NFAState(), NFAState())

# Generated at 2022-06-17 16:52:05.738695
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    import io
    import tokenize
    import unittest
    import warnings

    class TestParserGenerator(unittest.TestCase):
        def test_raise_error(self):
            with warnings.catch_warnings(record=True) as w:
                warnings.simplefilter("always")
                with self.assertRaises(SyntaxError) as cm:
                    ParserGenerator(
                        io.StringIO(""),
                        "test_raise_error",
                        tokenize.generate_tokens,
                        token,
                    ).raise_error("test_raise_error")
                self.assertEqual(
                    cm.exception.msg,
                    "test_raise_error",
                )
                self.assertEqual(
                    cm.exception.filename,
                    "test_raise_error",
                )
               

# Generated at 2022-06-17 16:52:17.536691
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    pg = ParserGenerator()
    pg.generator = tokenize.generate_tokens(StringIO("foo").readline)
    pg.gettoken()
    a, z = pg.parse_atom()
    assert a.arcs == [(None, z)]
    assert z.arcs == []
    assert a.arcs[0][1] is z
    assert a.arcs[0][0] == "foo"
    assert a.arcs[0][0] is not None
    assert a.arcs[0][0] is not z
    assert a.arcs[0][0] is not a
    assert a.arcs[0][0] is not z.arcs
    assert a.arcs[0][0] is not a.arcs

# Generated at 2022-06-17 16:52:19.634206
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    assert PgenGrammar()



# Generated at 2022-06-17 16:52:27.232627
# Unit test for method raise_error of class ParserGenerator

# Generated at 2022-06-17 16:52:36.574099
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    # Test with a single grammar file
    g = PgenGrammar(grammar.Grammar("Grammar/Grammar", "Grammar/Grammar", "Grammar/Grammar"))
    assert g.start == "file_input"

# Generated at 2022-06-17 16:52:51.938434
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    import io
    import tokenize
    from typing import List, Tuple
    from . import ParserGenerator
    from . import token
    from . import grammar
    from . import pgen
    from . import pgen2
    from . import pgen2_grammar
    from . import pgen2_parse
    from . import pgen2_token
    from . import pgen_main
    from . import pgen_parse
    from . import pgen_token
    from . import pygram
    from . import pygram_parse
    from . import pygram_token
    from . import pygram_utils
    from . import token
    from . import tokenize
    from . import token_utils
    from . import utils
    from . import utils_ast
    from . import utils_grammar
    from . import utils

# Generated at 2022-06-17 16:53:05.170156
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    from io import StringIO
    from tokenize import tokenize
    from token import NAME, OP, STRING, ENDMARKER
    from test.support import captured_stdout
    s = StringIO("""\
    a: b c
    b: 'b'
    c: 'c'
    """)
    g = ParserGenerator()
    g.generator = tokenize(s.readline)
    g.gettoken()
    g.expect(NAME)
    g.expect(OP, ":")
    g.expect(NAME)
    g.expect(NAME)
    g.expect(ENDMARKER)
    with captured_stdout() as output:
        g.generator = tokenize(s.readline)
        g.gettoken()

# Generated at 2022-06-17 16:53:56.085523
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    assert PgenGrammar()



# Generated at 2022-06-17 16:54:06.418183
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    pg = ParserGenerator()
    pg.filename = "test_ParserGenerator_raise_error"
    pg.end = (1, 2)
    pg.line = "line"
    try:
        pg.raise_error("msg")
    except SyntaxError as e:
        assert e.msg == "msg"
        assert e.filename == "test_ParserGenerator_raise_error"
        assert e.lineno == 1
        assert e.offset == 2
        assert e.text == "line"
    else:
        assert False, "Expected SyntaxError"
    try:
        pg.raise_error("msg %s", "arg")
    except SyntaxError as e:
        assert e.msg == "msg arg"
        assert e.filename == "test_ParserGenerator_raise_error"

# Generated at 2022-06-17 16:54:13.670015
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    pg = ParserGenerator()
    a = NFAState()
    z = NFAState()
    a.addarc(z, "a")
    dfa = pg.make_dfa(a, z)
    assert len(dfa) == 2
    assert dfa[0].arcs == {"a": dfa[1]}
    assert dfa[1].arcs == {}
    assert dfa[1].isfinal
    a = NFAState()
    z = NFAState()
    a.addarc(z, "a")
    a.addarc(z, "b")
    dfa = pg.make_dfa(a, z)
    assert len(dfa) == 2
    assert dfa[0].arcs == {"a": dfa[1], "b": dfa[1]}

# Generated at 2022-06-17 16:54:26.378274
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    pg = ParserGenerator()
    pg.dfas = {
        "a": [DFAState({}, False), DFAState({}, True)],
        "b": [DFAState({}, False), DFAState({}, True)],
        "c": [DFAState({}, False), DFAState({}, True)],
    }
    pg.first = {"a": {"a": 1}, "b": {"b": 1}, "c": {"c": 1}}
    c = pg.make_converter()
    assert c.symbol2number == {"a": 0, "b": 1, "c": 2}
    assert c.symbol2label == {"a": 0, "b": 1, "c": 2}
    assert c.labels == [(0, None), (1, None), (2, None)]
   

# Generated at 2022-06-17 16:54:36.687369
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    pg = ParserGenerator()
    pg.dfas = {
        "a": [DFAState({}, False), DFAState({}, True)],
        "b": [DFAState({}, False), DFAState({}, True)],
        "c": [DFAState({}, False), DFAState({}, True)],
    }
    pg.dfas["a"][0].addarc(pg.dfas["a"][1], "a")
    pg.dfas["a"][0].addarc(pg.dfas["b"][0], "b")
    pg.dfas["b"][0].addarc(pg.dfas["c"][0], "c")
    pg.dfas["c"][0].addarc(pg.dfas["a"][0], "a")
    pg.cal

# Generated at 2022-06-17 16:54:51.630305
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    pgen_grammar = PgenGrammar()
    assert pgen_grammar.start == 'file_input'
    assert pgen_grammar.keywords == {}
    assert pgen_grammar.tokens == {}
    assert pgen_grammar.symbol2label == {}
    assert pgen_grammar.dfas == {}
    assert pgen_grammar.states == {}
    assert pgen_grammar.literals == {}
    assert pgen_grammar.symbol2number == {}
    assert pgen_grammar.number2symbol == {}
    assert pgen_grammar.symbol2name == {}
    assert pgen_grammar.name2symbol == {}
    assert pgen_grammar.error_func == None
    assert pgen_grammar.error_func_name == None

# Generated at 2022-06-17 16:55:00.970500
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    pg = ParserGenerator()
    a = NFAState()
    b = NFAState()
    c = NFAState()
    d = NFAState()
    e = NFAState()
    a.addarc(b, "a")
    a.addarc(c, "b")
    b.addarc(d, "c")
    b.addarc(e, "d")
    c.addarc(e, "e")
    d.addarc(e, "f")
    pg.dump_nfa("test", a, e)

# Generated at 2022-06-17 16:55:10.763857
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    import io
    import tokenize
    import unittest

    class TestCase(unittest.TestCase):
        def test_make_grammar(self):
            pg = ParserGenerator()
            pg.add_production("file_input", [("stmt", 1, -1)])
            pg.add_production("stmt", [("simple_stmt", 0, 1)])
            pg.add_production("simple_stmt", [("small_stmt", 1, -1), ("NEWLINE", 0, 1)])
            pg.add_production("small_stmt", [("expr_stmt", 1, 1)])
            pg.add_production("expr_stmt", [("testlist", 1, -1), ("augassign", 0, 1), ("yield_expr", 0, 1)])
            pg

# Generated at 2022-06-17 16:55:22.483281
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    import io
    import tokenize
    from typing import Any, Iterator, Tuple
    from typing_extensions import Literal
    from . import ParserGenerator
    from . import token
    from . import grammar
    from . import NFAState
    from . import DFAState
    from . import PgenGrammar
    from . import PgenParser
    from . import PgenStack
    from . import PgenState
    from . import Pgen
    from . import PgenGrammar
    from . import PgenParser
    from . import PgenStack
    from . import PgenState
    from . import Pgen
    from . import PgenGrammar
    from . import PgenParser
    from . import PgenStack
    from . import PgenState
    from . import Pgen
    from . import PgenGram

# Generated at 2022-06-17 16:55:27.615282
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    pg = ParserGenerator()
    pg.make_scanner()
    pg.parse_grammar(dedent("""\
        start: 'a'
        """))
    pg.addfirstsets()
    dfa = pg.dfas["start"]
    pg.dump_dfa("start", dfa)
    assert dfa[0].arcs == {'a': dfa[0]}
    assert dfa[0].isfinal

# Generated at 2022-06-17 16:57:15.064917
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    import io
    import tokenize
    from typing import Tuple

    def test(input: str, expected: Tuple[int, str]) -> None:
        # type: (str, Tuple[int, str]) -> None
        input = io.StringIO(input)
        generator = tokenize.generate_tokens(input.readline)
        parser = ParserGenerator(generator, "<test>")
        parser.gettoken()
        actual = (parser.type, parser.value)
        assert actual == expected, actual

    test("", (token.ENDMARKER, ""))
    test("\n", (token.ENDMARKER, ""))
    test("\n\n", (token.ENDMARKER, ""))
    test("\n\n\n", (token.ENDMARKER, ""))

# Generated at 2022-06-17 16:57:25.301624
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    pg = ParserGenerator()

# Generated at 2022-06-17 16:57:36.307719
# Unit test for method simplify_dfa of class ParserGenerator

# Generated at 2022-06-17 16:57:43.536788
# Unit test for method simplify_dfa of class ParserGenerator

# Generated at 2022-06-17 16:57:48.938273
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    pg = ParserGenerator()
    pg.dfas = {
        "a": [DFAState({}, False), DFAState({}, False)],
        "b": [DFAState({}, False), DFAState({}, False)],
        "c": [DFAState({}, False), DFAState({}, False)],
        "d": [DFAState({}, False), DFAState({}, False)],
        "e": [DFAState({}, False), DFAState({}, False)],
        "f": [DFAState({}, False), DFAState({}, False)],
    }
    pg.dfas["a"][0].addarc(pg.dfas["b"][0], "b")

# Generated at 2022-06-17 16:57:55.801649
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    pg = ParserGenerator()
    pg.dfas = {
        "a": [DFAState({}, False), DFAState({}, False)],
        "b": [DFAState({}, False), DFAState({}, False)],
        "c": [DFAState({}, False), DFAState({}, False)],
    }
    pg.dfas["a"][0].addarc(pg.dfas["b"][0], "x")
    pg.dfas["a"][0].addarc(pg.dfas["c"][0], "y")
    pg.dfas["b"][0].addarc(pg.dfas["c"][0], "z")
    pg.dfas["c"][0].addarc(pg.dfas["c"][0], "z")
    pg.cal

# Generated at 2022-06-17 16:58:00.524938
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    pg = ParserGenerator()
    pg.filename = "test_filename"
    pg.end = (1, 2)
    pg.line = "test_line"
    try:
        pg.raise_error("test_msg")
    except SyntaxError as e:
        assert e.msg == "test_msg"
        assert e.filename == "test_filename"
        assert e.lineno == 1
        assert e.offset == 2
        assert e.text == "test_line"
    else:
        assert False, "Expected SyntaxError"


# Generated at 2022-06-17 16:58:08.917804
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    pg = PgenGrammar()
    assert pg.start == "file_input"
    assert pg.keywords == {}
    assert pg.tokens == []
    assert pg.symbol2number == {}
    assert pg.number2symbol == {}
    assert pg.dfas == {}
    assert pg.states == {}
    assert pg.literals == {}
    assert pg.error_func == None
    assert pg.type2name == {}
    assert pg.name2type == {}
    assert pg.p_rules == {}
    assert pg.p_rules_all == {}
    assert pg.p_rules_by_name == {}
    assert pg.p_argmap == {}
    assert pg.p_argmap_all == {}
    assert pg.p_argmap_by_name == {}
    assert pg.p

# Generated at 2022-06-17 16:58:11.192827
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    pg = ParserGenerator()
    pg.dump_nfa("foo", NFAState(), NFAState())

# Generated at 2022-06-17 16:58:19.585271
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    pg = ParserGenerator()
    a = NFAState()
    z = NFAState()
    a.addarc(z, "a")
    a.addarc(z, "b")
    dfa = pg.make_dfa(a, z)
    assert len(dfa) == 1
    assert len(dfa[0].arcs) == 2
    assert dfa[0].arcs["a"] is dfa[0]
    assert dfa[0].arcs["b"] is dfa[0]
    assert dfa[0].isfinal
    #
    a = NFAState()
    z = NFAState()
    a.addarc(z, "a")
    a.addarc(z, "b")
    a.addarc(z, "c")