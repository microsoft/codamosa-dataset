

# Generated at 2022-06-17 16:50:53.754620
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    pg = ParserGenerator()
    pg.add_production("S", ["a", "b"])
    pg.add_production("S", ["c"])
    pg.add_production("S", ["d", "e"])
    pg.add_production("S", ["f", "g", "h"])
    pg.add_production("S", ["i", "j", "k", "l"])
    pg.add_production("S", ["m", "n", "o", "p", "q"])
    pg.add_production("S", ["r", "s", "t", "u", "v", "w"])
    pg.add_production("S", ["x", "y", "z", "0", "1", "2", "3"])

# Generated at 2022-06-17 16:50:56.752482
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    pg = ParserGenerator()
    pg.dump_nfa("foo", NFAState(), NFAState())


# Generated at 2022-06-17 16:51:09.463586
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    pg = ParserGenerator()
    a = NFAState()
    z = NFAState()
    a.addarc(z, "a")
    dfa = pg.make_dfa(a, z)
    assert len(dfa) == 1
    assert dfa[0].nfaset == {a: 1, z: 1}
    assert dfa[0].arcs == {"a": dfa[0]}
    assert dfa[0].isfinal
    a = NFAState()
    z = NFAState()
    a.addarc(z, "a")
    a.addarc(z, "b")
    dfa = pg.make_dfa(a, z)
    assert len(dfa) == 1

# Generated at 2022-06-17 16:51:12.176079
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    pg = ParserGenerator()
    pg.dump_nfa("foo", NFAState(), NFAState())

# Generated at 2022-06-17 16:51:19.309665
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    pg = ParserGenerator()
    pg.generator = tokenize.generate_tokens(io.StringIO("foo").readline)
    pg.gettoken()
    a, z = pg.parse_atom()
    assert a.arcs == [(None, z), ("foo", z)]
    assert z.arcs == []


# Generated at 2022-06-17 16:51:30.142025
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    import io
    import tokenize
    import unittest
    from typing import List, Tuple

    class TestCase(unittest.TestCase):
        def test_dump_nfa(self):
            # type: () -> None
            pg = ParserGenerator()
            pg.add_nonterminal("file_input", [("stmt", "*")])
            pg.add_nonterminal("stmt", [("simple_stmt", "?"), ("compound_stmt", "?")])
            pg.add_nonterminal("simple_stmt", [("small_stmt", "+"), ("NEWLINE", ""), ("SEMI", "*")])
            pg.add_nonterminal("small_stmt", [("expr_stmt", ""), ("print_stmt", "")])
            pg.add

# Generated at 2022-06-17 16:51:41.544214
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    pg = ParserGenerator()

# Generated at 2022-06-17 16:51:52.021337
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    pg = ParserGenerator()
    a = NFAState()
    z = NFAState()
    a.addarc(z, "a")
    a.addarc(z, "b")
    dfa = pg.make_dfa(a, z)
    assert len(dfa) == 2
    assert dfa[0].nfaset == {a: 1, z: 1}
    assert dfa[1].nfaset == {z: 1}
    assert dfa[0].arcs == {"a": dfa[1], "b": dfa[1]}
    assert dfa[1].arcs == {}



# Generated at 2022-06-17 16:52:03.719831
# Unit test for method make_grammar of class ParserGenerator

# Generated at 2022-06-17 16:52:05.577631
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    pg = ParserGenerator()
    pg.parse_item()


# Generated at 2022-06-17 16:52:26.328256
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    PgenGrammar()


# Generated at 2022-06-17 16:52:38.504634
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    pg = ParserGenerator()
    pg.labels = []
    pg.symbol2number = {"foo": 1}
    pg.symbol2label = {"foo": 2}
    pg.tokens = {3: 4}
    pg.keywords = {"bar": 5}
    assert pg.make_label(pg, "foo") == 2
    assert pg.make_label(pg, "bar") == 5
    assert pg.make_label(pg, "3") == 4
    assert pg.make_label(pg, "'baz'") == 6
    assert pg.make_label(pg, '"baz"') == 7

# Generated at 2022-06-17 16:52:45.377004
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    pg = ParserGenerator()
    pg.dfas = {'a': [DFAState({NFAState(): 1}, NFAState()), DFAState({NFAState(): 1}, NFAState())]}
    pg.dump_dfa('a', pg.dfas['a'])


# Generated at 2022-06-17 16:52:57.585972
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    pg = ParserGenerator()

# Generated at 2022-06-17 16:53:01.405948
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    # Test that the constructor of class PgenGrammar works
    PgenGrammar()



# Generated at 2022-06-17 16:53:13.060806
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    pg = ParserGenerator()
    pg.type = token.NAME
    pg.value = "foo"
    assert pg.expect(token.NAME) == "foo"
    pg.type = token.NAME
    pg.value = "bar"
    assert pg.expect(token.NAME) == "bar"
    pg.type = token.NAME
    pg.value = "baz"
    try:
        pg.expect(token.NAME, "quux")
    except SyntaxError:
        pass
    else:
        assert False, "expected SyntaxError"
    pg.type = token.NAME
    pg.value = "quux"
    assert pg.expect(token.NAME, "quux") == "quux"
    pg.type = token.NAME
    pg.value = "quux"


# Generated at 2022-06-17 16:53:22.187123
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    pg = ParserGenerator()
    pg.dfas = {
        "a": [DFAState({}, False), DFAState({}, False)],
        "b": [DFAState({}, False), DFAState({}, False)],
        "c": [DFAState({}, False), DFAState({}, False)],
        "d": [DFAState({}, False), DFAState({}, False)],
        "e": [DFAState({}, False), DFAState({}, False)],
        "f": [DFAState({}, False), DFAState({}, False)],
    }
    pg.dfas["a"][0].addarc(pg.dfas["b"][0], "b")

# Generated at 2022-06-17 16:53:33.218509
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    pg = ParserGenerator()
    pg.dfas = {
        "a": [DFAState({}, False), DFAState({}, False)],
        "b": [DFAState({}, False), DFAState({}, False)],
        "c": [DFAState({}, False), DFAState({}, False)],
    }
    pg.first = {
        "a": {"a": 1, "b": 1},
        "b": {"a": 1, "b": 1},
        "c": {"a": 1, "b": 1},
    }
    c = pg.make_converter()
    assert c.make_first(c, "a") == {c.symbol2label["a"]: 1, c.symbol2label["b"]: 1}

# Generated at 2022-06-17 16:53:46.277827
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    pg = ParserGenerator()
    pg.dump_nfa("foo", NFAState(), NFAState())
    pg.dump_nfa(
        "foo",
        NFAState([(None, NFAState())]),
        NFAState([(None, NFAState())]),
    )
    pg.dump_nfa(
        "foo",
        NFAState([(None, NFAState()), (None, NFAState())]),
        NFAState([(None, NFAState()), (None, NFAState())]),
    )
    pg.dump_nfa(
        "foo",
        NFAState([(None, NFAState()), (None, NFAState())]),
        NFAState([(None, NFAState())]),
    )
    pg.dump_n

# Generated at 2022-06-17 16:53:51.555749
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    pg = ParserGenerator()
    pg.symbol2number = {"foo": 1, "bar": 2, "baz": 3}
    pg.labels = []
    pg.symbol2label = {}
    pg.tokens = {token.NAME: 4, token.NUMBER: 5, token.STRING: 6}
    pg.keywords = {"if": 7, "else": 8, "elif": 9, "while": 10}
    c = pg.make_converter()
    assert c.make_label(c, "foo") == 1
    assert c.make_label(c, "bar") == 2
    assert c.make_label(c, "baz") == 3
    assert c.make_label(c, "NAME") == 4

# Generated at 2022-06-17 16:54:52.441757
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    pg = ParserGenerator()
    pg.filename = "test"
    pg.line = "test"
    pg.type = token.NAME
    pg.value = "NAME"
    pg.gettoken = lambda: None
    pg.raise_error = lambda *args: None
    pg.parse_atom()
    pg.type = token.STRING
    pg.value = "STRING"
    pg.parse_atom()
    pg.type = token.OP
    pg.value = "("
    pg.parse_atom()
    pg.type = token.OP
    pg.value = ")"
    pg.parse_atom()
    pg.type = token.OP
    pg.value = ")"
    pg.parse_atom()
    pg.type = token.OP
    pg.value = ")"

# Generated at 2022-06-17 16:55:04.776751
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    pg = ParserGenerator()
    pg.gettoken = lambda: None
    pg.value = "("
    pg.type = token.OP
    pg.parse_rhs = lambda: (None, None)
    pg.parse_atom = lambda: (None, None)
    pg.parse_item()
    pg.value = ")"
    pg.parse_item()
    pg.value = "["
    pg.parse_item()
    pg.value = "]"
    pg.parse_item()
    pg.value = "NAME"
    pg.type = token.NAME
    pg.parse_item()
    pg.value = "STRING"
    pg.type = token.STRING
    pg.parse_item()
    pg.value = "+"
    pg.parse_item()

# Generated at 2022-06-17 16:55:16.757431
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    pg = ParserGenerator()
    pg.add_nonterminal("expr", ["expr", "+", "expr"], ["expr", "-", "expr"])
    pg.add_nonterminal("expr", ["expr", "*", "expr"])
    pg.add_nonterminal("expr", ["expr", "/", "expr"])
    pg.add_nonterminal("expr", ["(", "expr", ")"])
    pg.add_nonterminal("expr", ["NUMBER"])
    pg.add_nonterminal("expr", ["NAME"])
    pg.add_nonterminal("expr", ["NAME", "(", ")"])
    pg.add_nonterminal("expr", ["NAME", "(", "expr", ")"])

# Generated at 2022-06-17 16:55:22.107915
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    pg = ParserGenerator()
    try:
        pg.raise_error("%s %s", "foo", "bar")
    except SyntaxError as e:
        assert e.args == ("foo bar", (None, 0, 0, ""))
    else:
        assert False, "Expected SyntaxError"

# Generated at 2022-06-17 16:55:29.966135
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    import io
    import tokenize
    from typing import Iterator
    from typing import Tuple
    from typing import Union
    from typing import cast
    from typing import Any
    from typing import Optional
    from typing import List
    from typing import Dict
    from typing import Text
    from typing import Sequence
    from typing import Callable
    from typing import TypeVar
    from typing import Generic
    from typing import Type
    from typing import overload
    from typing import NamedTuple
    from typing import Set
    from typing import Mapping
    from typing import FrozenSet
    from typing import Deque
    from typing import Counter
    from typing import Hashable
    from typing import Iterable
    from typing import Container
    from typing import Sized
    from typing import AbstractSet
    from typing import MutableSet
    from typing import MutableMapping

# Generated at 2022-06-17 16:55:41.329936
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    pg = ParserGenerator()
    pg.type = token.NAME
    pg.value = "foo"
    pg.gettoken = lambda: None
    pg.raise_error = lambda msg, *args: None
    pg.expect(token.NAME)
    pg.expect(token.NAME, "foo")
    pg.expect(token.NAME, "bar")
    pg.expect(token.OP, "foo")
    pg.expect(token.OP, "bar")
    pg.expect(token.OP, "foo")
    pg.expect(token.OP, "bar")
    pg.expect(token.OP, "foo")
    pg.expect(token.OP, "bar")
    pg.expect(token.OP, "foo")

# Generated at 2022-06-17 16:55:52.567805
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    import io
    import tokenize
    import unittest
    import unittest.mock
    from . import parser
    from . import pgen2


# Generated at 2022-06-17 16:56:05.379541
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    pg = ParserGenerator()
    pg.dfas = {
        "a": [DFAState({}, False), DFAState({}, True)],
        "b": [DFAState({}, False), DFAState({}, True)],
        "c": [DFAState({}, False), DFAState({}, True)],
    }
    pg.dfas["a"][0].addarc(pg.dfas["a"][1], "a")
    pg.dfas["a"][0].addarc(pg.dfas["b"][0], "b")
    pg.dfas["b"][0].addarc(pg.dfas["c"][0], "c")
    pg.dfas["c"][0].addarc(pg.dfas["a"][0], "a")
    pg.df

# Generated at 2022-06-17 16:56:17.989566
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    pg = ParserGenerator()
    pg.add_rhs("a", "b c")
    pg.add_rhs("a", "d")
    pg.add_rhs("b", "e")
    pg.add_rhs("b", "f")
    pg.add_rhs("c", "g")
    pg.add_rhs("c", "h")
    pg.add_rhs("d", "i")
    pg.add_rhs("d", "j")
    pg.add_rhs("e", "k")
    pg.add_rhs("e", "l")
    pg.add_rhs("f", "m")
    pg.add_rhs("f", "n")
    pg.add_rhs("g", "o")
    pg.add_rhs

# Generated at 2022-06-17 16:56:27.996777
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    from . import pgen
    from . import token
    from . import grammar

    # Test case 1
    #
    # This is a regression test for issue #15894.
    #
    # The issue was that the method ParserGenerator.make_grammar()
    # would raise a ValueError exception if the grammar contained
    # a rule that was left-recursive.
    #
    # The test case below is a grammar that contains a left-recursive
    # rule.  The test case checks that the method make_grammar()
    # does not raise a ValueError exception.
    #
    # The test case also checks that the method make_grammar()
    # returns a grammar that is equivalent to the grammar that
    # was passed to the method.
    #
    # The test case checks that the grammar is equivalent by
    # comparing

# Generated at 2022-06-17 16:57:21.002469
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    import io
    import tokenize
    import unittest
    from test.support import captured_stdout

    class TestCase(unittest.TestCase):
        def test_make_grammar(self):
            with captured_stdout() as stdout:
                pg = ParserGenerator()
                pg.make_grammar(
                    io.StringIO(
                        """
        start: '[' expr ']'
        expr: expr '+' term | expr '-' term | term
        term: term '*' factor | term '/' factor | factor
        factor: '(' expr ')' | NUMBER
        """
                    )
                )

# Generated at 2022-06-17 16:57:28.880217
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    pg = ParserGenerator()
    pg.labels = []
    pg.symbol2number = {"foo": 1}
    pg.symbol2label = {}
    pg.tokens = {}
    pg.keywords = {}
    assert pg.make_label(pg, "foo") == 0
    assert pg.make_label(pg, "foo") == 0
    assert pg.make_label(pg, "bar") == 1
    assert pg.make_label(pg, "bar") == 1
    assert pg.make_label(pg, "NAME") == 2
    assert pg.make_label(pg, "NAME") == 2
    assert pg.make_label(pg, "NUMBER") == 3
    assert pg.make_label(pg, "NUMBER") == 3

# Generated at 2022-06-17 16:57:39.400264
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    pg = ParserGenerator()
    pg.dfas = {
        "a": [DFAState({}, False), DFAState({}, False)],
        "b": [DFAState({}, False), DFAState({}, False)],
        "c": [DFAState({}, False), DFAState({}, False)],
        "d": [DFAState({}, False), DFAState({}, False)],
    }
    pg.dfas["a"][0].addarc(pg.dfas["b"][0], "b")
    pg.dfas["a"][0].addarc(pg.dfas["c"][0], "c")
    pg.dfas["a"][0].addarc(pg.dfas["d"][0], "d")

# Generated at 2022-06-17 16:57:46.598774
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    pg = ParserGenerator()
    pg.add_production("S", ["S", "a"])
    pg.add_production("S", ["S", "b"])
    pg.add_production("S", ["a"])
    pg.add_production("S", ["b"])
    pg.make_grammar()
    assert pg.first["S"] == {"a": 1, "b": 1}
    assert pg.dfas["S"][0].arcs == {"a": pg.dfas["S"][1], "b": pg.dfas["S"][2]}
    assert pg.dfas["S"][1].arcs == {"a": pg.dfas["S"][1], "b": pg.dfas["S"][2]}

# Generated at 2022-06-17 16:57:55.198669
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    pg = ParserGenerator()
    pg.gettoken = lambda: None
    pg.value = "a"
    pg.parse_item = lambda: (NFAState(), NFAState())
    a, z = pg.parse_alt()
    assert a.arcs == [(None, NFAState())]
    assert z.arcs == []
    pg.value = "b"
    pg.parse_item = lambda: (NFAState(), NFAState())
    pg.parse_alt()
    assert a.arcs == [(None, NFAState()), (None, NFAState())]
    assert z.arcs == []
    pg.value = "c"
    pg.parse_item = lambda: (NFAState(), NFAState())
    pg.parse_alt()

# Generated at 2022-06-17 16:57:59.452114
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    pg = ParserGenerator()
    pg.dump_nfa("foo", NFAState(), NFAState())
    pg.dump_nfa("bar", NFAState(), NFAState())
    pg.dump_nfa("baz", NFAState(), NFAState())

# Generated at 2022-06-17 16:58:08.455001
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    # Test that ParserGenerator.gettoken() skips comments and newlines
    pg = ParserGenerator()
    pg.generator = tokenize.generate_tokens(io.StringIO("# comment\n").readline)
    pg.gettoken()
    assert pg.type == token.ENDMARKER
    pg.generator = tokenize.generate_tokens(io.StringIO("\n# comment\n").readline)
    pg.gettoken()
    assert pg.type == token.ENDMARKER
    pg.generator = tokenize.generate_tokens(io.StringIO("\n\n# comment\n").readline)
    pg.gettoken()
    assert pg.type == token.ENDMARKER
    pg.generator = tokenize.generate_tokens

# Generated at 2022-06-17 16:58:17.079535
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    # Test with a valid file
    pgen_grammar = PgenGrammar(os.path.join(os.path.dirname(__file__), "Grammar.txt"))
    assert pgen_grammar.start == "file_input"

# Generated at 2022-06-17 16:58:23.551525
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    pg = ParserGenerator()
    pg.filename = "test_ParserGenerator_raise_error"
    pg.end = (1, 2)
    pg.line = "line"
    try:
        pg.raise_error("%s %s", "foo", "bar")
    except SyntaxError as e:
        assert e.args == ("foo bar", ("test_ParserGenerator_raise_error", 1, 2, "line"))
    else:
        assert False, "expected SyntaxError"


# Generated at 2022-06-17 16:58:30.500827
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    pg = ParserGenerator()
    pg.dfas = {
        "a": [DFAState({}, False), DFAState({}, False)],
        "b": [DFAState({}, False), DFAState({}, False)],
        "c": [DFAState({}, False), DFAState({}, False)],
        "d": [DFAState({}, False), DFAState({}, False)],
        "e": [DFAState({}, False), DFAState({}, False)],
    }
    pg.dfas["a"][0].addarc(pg.dfas["b"][0], "b")
    pg.dfas["a"][0].addarc(pg.dfas["c"][0], "c")