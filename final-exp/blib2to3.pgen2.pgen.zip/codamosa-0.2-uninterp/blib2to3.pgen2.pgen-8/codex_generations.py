

# Generated at 2022-06-17 16:51:02.488141
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    pg = ParserGenerator()
    pg.parse()

# Generated at 2022-06-17 16:51:13.663241
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    pg = ParserGenerator()
    pg.labels = []
    pg.symbol2number = {}
    pg.symbol2label = {}
    pg.tokens = {}
    pg.keywords = {}
    pg.make_label(pg, "NAME")
    pg.make_label(pg, "NUMBER")
    pg.make_label(pg, "STRING")
    pg.make_label(pg, "expr")
    pg.make_label(pg, "term")
    pg.make_label(pg, "factor")
    pg.make_label(pg, "NAME")
    pg.make_label(pg, "NUMBER")
    pg.make_label(pg, "STRING")
    pg.make_label(pg, "expr")

# Generated at 2022-06-17 16:51:26.999168
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    pg = ParserGenerator()
    pg.add_production("a", ["b", "c"])
    pg.add_production("b", ["b", "c"])
    pg.add_production("b", ["d"])
    pg.add_production("c", ["e"])
    pg.add_production("c", ["f"])
    pg.add_production("d", ["g"])
    pg.add_production("e", ["g"])
    pg.add_production("f", ["h"])
    pg.add_production("g", ["i"])
    pg.add_production("h", ["i"])
    pg.add_production("i", ["j"])
    pg.add_production("j", ["k"])
    pg.add_production("k", ["l"])
    pg

# Generated at 2022-06-17 16:51:38.782308
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    import io
    import tokenize
    import unittest

    class TestCase(unittest.TestCase):
        def test_parse(self):
            # Test the parser generator
            pg = ParserGenerator()
            pg.add_nonterminal("file_input", [
                ("(NEWLINE | stmt)* ENDMARKER", None),
                ])
            pg.add_nonterminal("stmt", [
                ("simple_stmt", None),
                ("compound_stmt", None),
                ])
            pg.add_nonterminal("simple_stmt", [
                ("small_stmt (';' small_stmt)* [';'] NEWLINE", None),
                ])

# Generated at 2022-06-17 16:51:42.766460
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    pg = ParserGenerator()
    assert pg.dfas == {}
    assert pg.first == {}
    assert pg.startsymbol is None


# Generated at 2022-06-17 16:51:54.479444
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    pg = ParserGenerator()
    pg.gettoken = lambda: None
    pg.type = token.NAME
    pg.value = "foo"
    pg.filename = "foo.py"
    pg.end = (1, 0)
    pg.line = ""
    a, z = pg.parse_item()
    assert a.arcs == [(None, z)]
    assert z.arcs == []
    assert a.arcs == [(None, z)]
    assert z.arcs == []
    pg.type = token.STRING
    pg.value = "bar"
    a, z = pg.parse_item()
    assert a.arcs == [("bar", z)]
    assert z.arcs == []
    pg.type = token.OP
    pg.value = "("
    a, z = pg

# Generated at 2022-06-17 16:52:05.946144
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    pg = ParserGenerator()
    c = pg.make_converter()
    assert c.make_label(c, "NAME") == 0
    assert c.make_label(c, "NUMBER") == 1
    assert c.make_label(c, "STRING") == 2
    assert c.make_label(c, "LPAR") == 3
    assert c.make_label(c, "RPAR") == 4
    assert c.make_label(c, "LSQB") == 5
    assert c.make_label(c, "RSQB") == 6
    assert c.make_label(c, "COLON") == 7
    assert c.make_label(c, "COMMA") == 8
    assert c.make_label(c, "SEMI") == 9

# Generated at 2022-06-17 16:52:06.824205
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    pg = ParserGenerator()
    pg.parse_item()


# Generated at 2022-06-17 16:52:19.096181
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    pg = ParserGenerator()
    pg.gettoken = lambda: None
    pg.value = "("
    pg.type = token.OP
    pg.parse_rhs = lambda: (1, 2)
    pg.parse_atom = lambda: (3, 4)
    assert pg.parse_item() == (1, 2)
    pg.value = "["
    assert pg.parse_item() == (1, 2)
    pg.value = "NAME"
    pg.type = token.NAME
    assert pg.parse_item() == (3, 4)
    pg.value = "STRING"
    pg.type = token.STRING
    assert pg.parse_item() == (3, 4)
    pg.value = "+"
    assert pg.parse_item() == (3, 4)

# Generated at 2022-06-17 16:52:30.783306
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    pg = ParserGenerator()
    a = NFAState()
    z = NFAState()
    a.addarc(z, "a")
    dfa = pg.make_dfa(a, z)
    assert len(dfa) == 2
    assert dfa[0].arcs == {"a": dfa[1]}
    assert dfa[1].arcs == {}
    assert dfa[0].nfaset == {a: 1, z: 1}
    assert dfa[1].nfaset == {z: 1}
    assert dfa[0].isfinal == False
    assert dfa[1].isfinal == True
    assert dfa[0].final == z
    assert dfa[1].final == z


# Generated at 2022-06-17 16:53:19.104943
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    # Test with a file-like object
    with open(os.path.join(os.path.dirname(__file__), "Grammar.txt"), "r") as f:
        g = PgenGrammar(f)
    # Test with a filename
    g = PgenGrammar(os.path.join(os.path.dirname(__file__), "Grammar.txt"))
    # Test with a string
    with open(os.path.join(os.path.dirname(__file__), "Grammar.txt"), "r") as f:
        g = PgenGrammar(f.read())
    # Test with a list of tokens

# Generated at 2022-06-17 16:53:31.050704
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    pg = ParserGenerator()
    pg.dfas = {
        "a": [DFAState({}, False), DFAState({}, False)],
        "b": [DFAState({}, False), DFAState({}, False)],
        "c": [DFAState({}, False), DFAState({}, False)],
        "d": [DFAState({}, False), DFAState({}, False)],
        "e": [DFAState({}, False), DFAState({}, False)],
        "f": [DFAState({}, False), DFAState({}, False)],
    }
    pg.dfas["a"][0].addarc(pg.dfas["b"][0], "a")

# Generated at 2022-06-17 16:53:43.024254
# Unit test for method simplify_dfa of class ParserGenerator

# Generated at 2022-06-17 16:53:53.746013
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    import io
    import tokenize
    import unittest

    class TestCase(unittest.TestCase):
        def test_parse_rhs(self):
            pg = ParserGenerator()
            pg.filename = "test"
            pg.generator = tokenize.generate_tokens(io.StringIO("a b c").readline)
            pg.gettoken()
            a, z = pg.parse_rhs()
            self.assertEqual(a.arcs, [(None, a.next), ("a", a.next.next)])
            self.assertEqual(a.next.arcs, [(None, a.next.next), ("b", a.next.next.next)])

# Generated at 2022-06-17 16:54:04.818812
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    pg = ParserGenerator()
    pg.generator = iter([(token.NAME, "foo", (1, 0), (1, 3), "foo")])
    pg.gettoken()
    a, z = pg.parse_atom()
    assert a.arcs == [(None, z)]
    assert z.arcs == []
    assert a.arcs == [(None, z)]
    assert z.arcs == []
    pg.generator = iter([(token.STRING, "'foo'", (1, 0), (1, 5), "'foo'")])
    pg.gettoken()
    a, z = pg.parse_atom()
    assert a.arcs == [("foo", z)]
    assert z.arcs == []
    assert a.arcs == [("foo", z)]
    assert z.arcs

# Generated at 2022-06-17 16:54:11.341057
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    import io
    import tokenize
    from typing import Iterator
    from typing import Tuple
    from typing import Union

    def get_tokenizer(
        readline: Callable[[], str]
    ) -> Iterator[Tuple[int, str, Tuple[int, int], Tuple[int, int], str]]:
        return tokenize.generate_tokens(readline)

    def get_parser(
        readline: Callable[[], str]
    ) -> ParserGenerator:
        return ParserGenerator(get_tokenizer(readline))

    def readline() -> str:
        return "a = 1"

    parser = get_parser(readline)
    parser.gettoken()
    assert parser.type == token.NAME
    assert parser.value == "a"

# Generated at 2022-06-17 16:54:13.305840
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    pg = PgenGrammar()
    assert isinstance(pg, PgenGrammar)


# Generated at 2022-06-17 16:54:22.115920
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    pg = ParserGenerator()
    pg.gettoken = lambda: None
    pg.value = "("
    pg.parse_item = lambda: (NFAState(), NFAState())
    pg.parse_alt()
    pg.value = "("
    pg.parse_alt()
    pg.value = "("
    pg.parse_alt()
    pg.value = ")"
    pg.parse_alt()
    pg.value = ")"
    pg.parse_alt()
    pg.value = ")"
    pg.parse_alt()
    pg.value = ")"
    pg.parse_alt()
    pg.value = ")"
    pg.parse_alt()
    pg.value = ")"
    pg.parse_alt()
    pg.value = ")"
    pg.parse_alt()
   

# Generated at 2022-06-17 16:54:23.346419
# Unit test for function generate_grammar
def test_generate_grammar():
    p = ParserGenerator("Grammar.txt")
    return p.make_grammar()

if __name__ == "__main__":
    print(generate_grammar())

# Generated at 2022-06-17 16:54:34.328713
# Unit test for method simplify_dfa of class ParserGenerator

# Generated at 2022-06-17 16:55:28.519628
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    # This is a unit test for the method simplify_dfa of class ParserGenerator.
    # It is not run by default.  To run it, type "python -m pgen2.pgen2"
    # at the command line.
    import pprint

    def test(dfa: List[DFAState]) -> None:
        print("Before:")
        pprint.pprint(dfa)
        ParserGenerator.simplify_dfa(dfa)
        print("After:")
        pprint.pprint(dfa)

    test([DFAState({0: 1}, 0), DFAState({1: 1}, 0)])
    test([DFAState({0: 1}, 0), DFAState({0: 1}, 0)])

# Generated at 2022-06-17 16:55:40.031472
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    pg = ParserGenerator()

# Generated at 2022-06-17 16:55:49.458510
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    pg = ParserGenerator()
    pg.add_rhs("foo", "a b c")
    pg.add_rhs("bar", "a b | c d")
    pg.add_rhs("baz", "a b | c d | e f")
    pg.add_rhs("qux", "a b | c d | e f | g h")
    pg.add_rhs("quux", "a b | c d | e f | g h | i j")
    pg.add_rhs("corge", "a b | c d | e f | g h | i j | k l")
    pg.add_rhs("grault", "a b | c d | e f | g h | i j | k l | m n")

# Generated at 2022-06-17 16:55:53.285213
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    pg = ParserGenerator()
    pg.setup("x: 'x' | 'y'")
    a, z = pg.parse_rhs()
    assert a.arcs == [(None, a.next), ('x', z), ('y', z)]
    assert z.arcs == []


# Generated at 2022-06-17 16:55:55.034030
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    PgenGrammar()



# Generated at 2022-06-17 16:56:06.360515
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    pg = ParserGenerator()
    dfa = [
        DFAState({NFAState(): 1}, None),
        DFAState({NFAState(): 1}, None),
        DFAState({NFAState(): 1}, None),
        DFAState({NFAState(): 1}, None),
        DFAState({NFAState(): 1}, None),
        DFAState({NFAState(): 1}, None),
        DFAState({NFAState(): 1}, None),
        DFAState({NFAState(): 1}, None),
    ]
    dfa[0].addarc(dfa[1], "a")
    dfa[0].addarc(dfa[2], "b")
    dfa[0].addarc(dfa[3], "c")

# Generated at 2022-06-17 16:56:11.245584
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    pg = ParserGenerator()
    pg.make_parser()
    pg.dump_nfa("file_input", pg.dfas["file_input"][0], pg.dfas["file_input"][-1])


# Generated at 2022-06-17 16:56:23.903342
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    pg = ParserGenerator()
    pg.dfas = {
        "a": [DFAState({}, False), DFAState({}, False)],
        "b": [DFAState({}, False), DFAState({}, False)],
        "c": [DFAState({}, False), DFAState({}, False)],
        "d": [DFAState({}, False), DFAState({}, False)],
        "e": [DFAState({}, False), DFAState({}, False)],
        "f": [DFAState({}, False), DFAState({}, False)],
    }
    pg.dfas["a"][0].addarc(pg.dfas["b"][0], "b")

# Generated at 2022-06-17 16:56:25.324934
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    pg = ParserGenerator()
    pg.parse_alt()

# Generated at 2022-06-17 16:56:33.502419
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    pg = ParserGenerator()
    pg.add_rhs("foo", "bar")
    pg.add_rhs("bar", "baz")
    pg.add_rhs("bar", "baz baz")
    pg.add_rhs("baz", "quux")
    pg.add_rhs("baz", "quux quux")
    pg.add_rhs("quux", "NAME")
    pg.add_rhs("quux", "NUMBER")
    pg.add_rhs("quux", "STRING")
    pg.add_rhs("quux", "LPAR", "foo", "RPAR")
    pg.add_rhs("quux", "foo", "foo")
    pg.add_rhs("quux", "foo", "foo", "foo")
   

# Generated at 2022-06-17 16:59:22.825936
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    import unittest
    import io
    import tokenize
    import token
    import grammar
    import pgen2.pgen
    import pgen2.parse
    import pgen2.driver
    import pgen2.token
    import pgen2.grammar
    import pgen2.convert
    import pgen2.pgen


# Generated at 2022-06-17 16:59:30.685907
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    from . import pgen
    from . import token
    from . import tokenize
    from . import grammar
    from . import symbol
    from . import pygram
    from . import pytree
    from . import python_grammar_no_print_statement
    from . import python_grammar
    from . import python_grammar_nt
    from . import python_grammar_lextab
    from . import python_grammar_yacctab
    from . import python_grammar_token
    from . import python_grammar_tokenize
    from . import python_grammar_pgen
    from . import python_grammar_pgen2
    from . import python_grammar_pgen2_concrete
    from . import python_grammar_pgen2_parse
    from . import python_grammar_pgen2

# Generated at 2022-06-17 16:59:39.301863
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    import io
    import tokenize
    import unittest

    class TestParserGenerator(unittest.TestCase):
        def test_gettoken(self):
            pg = ParserGenerator()
            pg.filename = "<string>"
            pg.generator = tokenize.generate_tokens(io.StringIO("foo").readline)
            pg.gettoken()
            self.assertEqual(pg.type, token.NAME)
            self.assertEqual(pg.value, "foo")
            self.assertEqual(pg.begin, (1, 0))
            self.assertEqual(pg.end, (1, 3))
            self.assertEqual(pg.line, "foo")

    unittest.main()

# Generated at 2022-06-17 16:59:43.814669
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    pg = ParserGenerator()
    pg.dump_dfa('name', [DFAState({NFAState(): 1}, NFAState())])

# Generated at 2022-06-17 16:59:55.458046
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    from . import grammar
    pg = ParserGenerator(grammar.symbol2number)
    pg.parse_rhs()
    pg.parse_rhs()
    pg.parse_rhs()
    pg.parse_rhs()
    pg.parse_rhs()
    pg.parse_rhs()
    pg.parse_rhs()
    pg.parse_rhs()
    pg.parse_rhs()
    pg.parse_rhs()
    pg.parse_rhs()
    pg.parse_rhs()
    pg.parse_rhs()
    pg.parse_rhs()
    pg.parse_rhs()
    pg.parse_rhs()
    pg.parse_rhs()
    pg.parse_rhs()
    pg.parse_rhs()
    pg.parse_

# Generated at 2022-06-17 17:00:03.223992
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    pg = ParserGenerator()