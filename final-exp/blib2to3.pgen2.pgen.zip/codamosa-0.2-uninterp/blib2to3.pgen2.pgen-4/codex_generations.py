

# Generated at 2022-06-17 16:51:29.097950
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    p = ParserGenerator()
    dfa = [
        DFAState({NFAState(): 1}, NFAState()),
        DFAState({NFAState(): 1}, NFAState()),
        DFAState({NFAState(): 1}, NFAState()),
        DFAState({NFAState(): 1}, NFAState()),
    ]
    dfa[0].addarc(dfa[1], "a")
    dfa[0].addarc(dfa[2], "b")
    dfa[1].addarc(dfa[3], "c")
    dfa[2].addarc(dfa[3], "d")
    dfa[3].addarc(dfa[0], "e")
    p.simplify_dfa(dfa)
    assert len(dfa) == 3

# Generated at 2022-06-17 16:51:40.768639
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    pg = ParserGenerator()
    pg.gettoken = lambda: None
    pg.value = "a"
    pg.parse_item = lambda: (NFAState(), NFAState())
    a, z = pg.parse_alt()
    assert a is not z
    assert a.arcs == [(None, z)]
    assert z.arcs == []
    pg.value = "b"
    b, y = pg.parse_alt()
    assert b is not y
    assert b.arcs == [(None, y)]
    assert y.arcs == []
    assert a.arcs == [(None, z)]
    assert z.arcs == [(None, b)]
    assert b.arcs == [(None, y)]
    assert y.arcs == []
    pg.value = "c"
    c, x

# Generated at 2022-06-17 16:51:53.477166
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    import io
    import tokenize
    from pgen2.parse import ParserGenerator

    def check(input, expected):
        f = io.StringIO(input)
        g = ParserGenerator()
        g.setup_parser(f, "test")
        g.gettoken()
        a, z = g.parse_rhs()
        assert a.arcs == expected

    check("a", [(None, "a")])
    check("a b", [(None, "a"), (None, "b")])
    check("a | b", [(None, "a"), (None, "b")])
    check("a | b | c", [(None, "a"), (None, "b"), (None, "c")])

# Generated at 2022-06-17 16:52:01.651020
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    pg = ParserGenerator()
    c = pg.make_converter()
    assert c.make_label(c, "NAME") == 0
    assert c.make_label(c, "NUMBER") == 1
    assert c.make_label(c, "STRING") == 2
    assert c.make_label(c, "if") == 3
    assert c.make_label(c, "while") == 4
    assert c.make_label(c, "def") == 5
    assert c.make_label(c, "class") == 6
    assert c.make_label(c, "foo") == 7
    assert c.make_label(c, "bar") == 8
    assert c.make_label(c, "baz") == 9

# Generated at 2022-06-17 16:52:12.286796
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    pg = ParserGenerator()
    a = NFAState()
    z = NFAState()
    a.addarc(z, "a")
    dfa = pg.make_dfa(a, z)
    assert len(dfa) == 2
    assert dfa[0].nfaset == {a: 1}
    assert dfa[1].nfaset == {z: 1}
    assert dfa[0].arcs == {"a": dfa[1]}
    assert dfa[1].arcs == {}

    a = NFAState()
    z = NFAState()
    a.addarc(z, "a")
    a.addarc(z, "b")
    dfa = pg.make_dfa(a, z)
    assert len(dfa) == 2
    assert d

# Generated at 2022-06-17 16:52:14.961419
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    pg = ParserGenerator()
    pg.dump_nfa("test", NFAState(), NFAState())
    pg.dump_nfa("test", NFAState(), NFAState())


# Generated at 2022-06-17 16:52:22.366390
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    pg = ParserGenerator()
    pg.setup("test", "a: b c | d e")
    a, z = pg.parse_rhs()
    assert isinstance(a, NFAState)
    assert isinstance(z, NFAState)
    assert a.arcs == [(None, a.arcs[0][1])]
    assert z.arcs == [(None, z.arcs[0][1])]
    assert a.arcs[0][1].arcs == [("b", a.arcs[0][1].arcs[0][1])]
    assert a.arcs[0][1].arcs[0][1].arcs == [("c", z)]

# Generated at 2022-06-17 16:52:34.932926
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    pg = ParserGenerator()
    pg.dfas = {
        "foo": [DFAState({}, False), DFAState({}, False)],
        "bar": [DFAState({}, False), DFAState({}, False)],
        "baz": [DFAState({}, False), DFAState({}, False)],
    }
    pg.dfas["foo"][0].addarc(pg.dfas["foo"][1], "a")
    pg.dfas["foo"][0].addarc(pg.dfas["bar"][0], "b")
    pg.dfas["bar"][0].addarc(pg.dfas["baz"][0], "c")
    pg.dfas["bar"][0].addarc(pg.dfas["baz"][1], "d")
   

# Generated at 2022-06-17 16:52:43.254856
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    pg = ParserGenerator()
    pg.add_production("a", ["b", "c"])
    pg.add_production("b", ["d"])
    pg.add_production("c", ["d"])
    pg.add_production("d", ["e"])
    pg.add_production("e", ["f"])
    pg.add_production("f", ["g"])
    pg.add_production("g", ["h"])
    pg.add_production("h", ["i"])
    pg.add_production("i", ["j"])
    pg.add_production("j", ["k"])
    pg.add_production("k", ["l"])
    pg.add_production("l", ["m"])
    pg.add_production("m", ["n"])
    pg.add_

# Generated at 2022-06-17 16:52:56.369010
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    import io
    import tokenize
    from typing import Iterator
    from typing import Tuple

    def get_tokens(s: str) -> Iterator[Tuple[int, str, Tuple[int, int], Tuple[int, int], str]]:
        return tokenize.generate_tokens(io.StringIO(s).readline)

    pg = ParserGenerator()
    pg.generator = get_tokens("a = 1")
    pg.gettoken()
    assert pg.type == token.NAME
    assert pg.value == "a"
    pg.gettoken()
    assert pg.type == token.OP
    assert pg.value == "="
    pg.gettoken()
    assert pg.type == token.NUMBER
    assert pg.value == "1"
    pg.gettoken

# Generated at 2022-06-17 16:54:18.009926
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    pg = ParserGenerator()
    pg.dump_nfa("foo", NFAState(), NFAState())
    pg.dump_nfa("foo", NFAState(), NFAState())
    pg.dump_nfa("foo", NFAState(), NFAState())
    pg.dump_nfa("foo", NFAState(), NFAState())
    pg.dump_nfa("foo", NFAState(), NFAState())
    pg.dump_nfa("foo", NFAState(), NFAState())
    pg.dump_nfa("foo", NFAState(), NFAState())
    pg.dump_nfa("foo", NFAState(), NFAState())
    pg.dump_nfa("foo", NFAState(), NFAState())
    pg.dump_nfa("foo", NFAState(), NFAState())


# Generated at 2022-06-17 16:54:28.572748
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    pg = ParserGenerator()
    pg.gettoken = lambda: None
    pg.value = "("
    pg.parse_item = lambda: (NFAState(), NFAState())
    pg.parse_alt()
    pg.value = "("
    pg.parse_alt()
    pg.value = "("
    pg.parse_alt()
    pg.value = "("
    pg.parse_alt()
    pg.value = "("
    pg.parse_alt()
    pg.value = "("
    pg.parse_alt()
    pg.value = "("
    pg.parse_alt()
    pg.value = "("
    pg.parse_alt()
    pg.value = "("
    pg.parse_alt()
    pg.value = "("
    pg.parse_alt()
   

# Generated at 2022-06-17 16:54:38.417339
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    pg = ParserGenerator()
    pg.dump_dfa("test", [])
    pg.dump_dfa("test", [DFAState({}, None)])
    pg.dump_dfa("test", [DFAState({}, None), DFAState({}, None)])
    pg.dump_dfa("test", [DFAState({}, None), DFAState({}, None), DFAState({}, None)])
    pg.dump_dfa("test", [DFAState({}, None), DFAState({}, None), DFAState({}, None), DFAState({}, None)])
    pg.dump_dfa("test", [DFAState({}, None), DFAState({}, None), DFAState({}, None), DFAState({}, None), DFAState({}, None)])
    pg.dump_dfa

# Generated at 2022-06-17 16:54:44.540716
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    pg = ParserGenerator()
    pg.generator = tokenize.generate_tokens(StringIO("(a)").readline)
    pg.gettoken()
    assert pg.parse_atom() == (NFAState([(NFAState(), "a")]), NFAState())
    pg.generator = tokenize.generate_tokens(StringIO("a").readline)
    pg.gettoken()
    assert pg.parse_atom() == (NFAState([(NFAState(), "a")]), NFAState())
    pg.generator = tokenize.generate_tokens(StringIO("'a'").readline)
    pg.gettoken()
    assert pg.parse_atom() == (NFAState([(NFAState(), "a")]), NFAState())

# Generated at 2022-06-17 16:54:54.275071
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    import io
    import tokenize
    from . import grammar
    from . import pgen

    def test(input: str, expected: str) -> None:
        f = io.StringIO(input)
        g = pgen.ParserGenerator()
        g.setup_grammar(grammar)
        g.parse_grammar(f)
        g.addfirstsets()
        f = io.StringIO()
        g.dump_nfa("single_input", g.dfas["single_input"][0], g.dfas["single_input"][-1])
        assert f.getvalue() == expected


# Generated at 2022-06-17 16:55:05.794552
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    pg = ParserGenerator()
    pg.dfas = {
        "a": [DFAState({}, False), DFAState({}, False)],
        "b": [DFAState({}, False), DFAState({}, False)],
        "c": [DFAState({}, False), DFAState({}, False)],
        "d": [DFAState({}, False), DFAState({}, False)],
        "e": [DFAState({}, False), DFAState({}, False)],
        "f": [DFAState({}, False), DFAState({}, False)],
        "g": [DFAState({}, False), DFAState({}, False)],
    }
    pg.dfas["a"][0].addarc(pg.dfas["b"][0], "b")
    pg.df

# Generated at 2022-06-17 16:55:13.908573
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    pg = ParserGenerator()

# Generated at 2022-06-17 16:55:19.395705
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    pg = ParserGenerator()
    pg.gettoken = lambda: None
    pg.type = token.NAME
    pg.value = "a"
    pg.filename = "test"
    pg.end = (1, 1)
    pg.line = "a"
    assert pg.parse_item() == (NFAState([(None, NFAState([("a", None)]))]),
                               NFAState([("a", None)]))
    pg.value = "("
    pg.type = token.OP
    pg.gettoken = lambda: None
    pg.type = token.NAME
    pg.value = "b"
    assert pg.parse_item() == (NFAState([(None, NFAState([("b", None)]))]),
                               NFAState([("b", None)]))
    pg.value

# Generated at 2022-06-17 16:55:28.668046
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    import io
    import tokenize
    import unittest
    from test.support import captured_stderr

    class TestParserGenerator(unittest.TestCase):

        def test_raise_error(self):
            pg = ParserGenerator()
            pg.filename = 'test'
            pg.end = (1, 2)
            pg.line = 'line'
            with captured_stderr() as stderr:
                try:
                    pg.raise_error('msg')
                except SyntaxError as e:
                    self.assertEqual(e.msg, 'msg')
                    self.assertEqual(e.filename, 'test')
                    self.assertEqual(e.lineno, 1)
                    self.assertEqual(e.offset, 2)

# Generated at 2022-06-17 16:55:40.474120
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    import io
    import tokenize
    import unittest

    class TestCase(unittest.TestCase):
        def test_dump_dfa(self):
            pg = ParserGenerator()

# Generated at 2022-06-17 16:57:01.893063
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    # Test case for issue #12076.
    pg = ParserGenerator()

# Generated at 2022-06-17 16:57:13.548794
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    pg = ParserGenerator()
    pg.add_dfa("a", [("b", 1), ("c", 2)], [("d", 3)])
    pg.add_dfa("b", [("c", 4), ("d", 5)], [("e", 6)])
    pg.add_dfa("c", [("d", 7), ("e", 8)], [("f", 9)])
    pg.add_dfa("d", [("e", 10), ("f", 11)], [("g", 12)])
    pg.add_dfa("e", [("f", 13), ("g", 14)], [("h", 15)])
    pg.add_dfa("f", [("g", 16), ("h", 17)], [("i", 18)])

# Generated at 2022-06-17 16:57:24.186383
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    pg = ParserGenerator()
    pg.dfas = {
        "a": [DFAState({}, False), DFAState({}, True)],
        "b": [DFAState({}, False), DFAState({}, True)],
    }
    pg.symbol2number = {"a": 0, "b": 1}
    pg.labels = [(0, None), (1, None)]
    pg.first = {"a": {"a": 1}, "b": {"b": 1}}
    c = PgenGrammar()
    c.symbol2number = {"a": 0, "b": 1}
    c.labels = [(0, None), (1, None)]
    c.tokens = {0: 0, 1: 1}
    c.keywords = {}
    c.dfas = {}


# Generated at 2022-06-17 16:57:35.825028
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    pg = ParserGenerator()
    pg.dump_nfa("foo", NFAState(), NFAState())
    pg.dump_nfa("foo", NFAState(), NFAState())
    pg.dump_nfa("foo", NFAState(), NFAState())
    pg.dump_nfa("foo", NFAState(), NFAState())
    pg.dump_nfa("foo", NFAState(), NFAState())
    pg.dump_nfa("foo", NFAState(), NFAState())
    pg.dump_nfa("foo", NFAState(), NFAState())
    pg.dump_nfa("foo", NFAState(), NFAState())
    pg.dump_nfa("foo", NFAState(), NFAState())
    pg.dump_nfa("foo", NFAState(), NFAState())


# Generated at 2022-06-17 16:57:39.400307
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    # Test the constructor of class PgenGrammar
    #
    # This test doesn't check anything. It just exercises the code.
    #
    # The constructor of class PgenGrammar is tested by the
    # test_pgen.test_pgen() function.
    PgenGrammar()


# Generated at 2022-06-17 16:57:43.779219
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    pg = ParserGenerator()
    try:
        pg.raise_error("expected %s/%s, got %s/%s", token.NAME, "foo", token.OP, ":")
    except SyntaxError as e:
        assert e.msg == "expected NAME/foo, got OP/:"
        assert e.filename == "<string>"
        assert e.lineno == 1
        assert e.offset == 0
        assert e.text == ""
    else:
        assert False, "expected SyntaxError"


# Generated at 2022-06-17 16:57:54.527955
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    pg = ParserGenerator()
    pg.dfas = {
        "a": [DFAState({}, False), DFAState({}, True)],
        "b": [DFAState({}, False), DFAState({}, True)],
        "c": [DFAState({}, False), DFAState({}, True)],
    }
    pg.first = {"a": {"a": 1}, "b": {"b": 1}, "c": {"c": 1}}
    c = pg.make_converter()
    assert c.symbol2number == {"a": 0, "b": 1, "c": 2}
    assert c.labels == [(0, None), (1, None), (2, None)]

# Generated at 2022-06-17 16:58:05.376095
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    import io
    import tokenize
    import unittest
    import unittest.mock

    from typing import List, Tuple

    from . import grammar

    class MockTokenizer:
        def __init__(self, lines: List[str]) -> None:
            self.lines = lines
            self.i = 0

        def __iter__(self) -> "MockTokenizer":
            return self

        def __next__(self) -> Tuple[int, str, Tuple[int, int], Tuple[int, int], str]:
            if self.i >= len(self.lines):
                raise StopIteration
            line = self.lines[self.i]
            self.i += 1
            return (tokenize.NAME, line, (0, 0), (0, len(line)), line)


# Generated at 2022-06-17 16:58:16.416792
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    pg = ParserGenerator()
    pg.generator = iter([(token.NAME, "a", (1, 0), (1, 1), "a")])
    pg.gettoken()
    a, z = pg.parse_rhs()
    assert a.arcs == [(None, z)]
    assert z.arcs == [(None, a)]
    assert a.arcs == [(None, z)]
    assert z.arcs == [(None, a)]
    assert a.arcs == [(None, z)]
    assert z.arcs == [(None, a)]
    assert a.arcs == [(None, z)]
    assert z.arcs == [(None, a)]
    assert a.arcs == [(None, z)]
    assert z.arcs == [(None, a)]

# Generated at 2022-06-17 16:58:26.269909
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    p = ParserGenerator()
    dfa = [
        DFAState({NFAState(): 1}, None),
        DFAState({NFAState(): 1}, None),
        DFAState({NFAState(): 1}, None),
        DFAState({NFAState(): 1}, None),
        DFAState({NFAState(): 1}, None),
        DFAState({NFAState(): 1}, None),
        DFAState({NFAState(): 1}, None),
        DFAState({NFAState(): 1}, None),
    ]
    dfa[0].addarc(dfa[1], "a")
    dfa[0].addarc(dfa[2], "b")
    dfa[1].addarc(dfa[3], "c")