

# Generated at 2022-06-17 16:52:03.677711
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    pg = ParserGenerator()
    pg.gettoken = lambda: None
    pg.value = "("
    pg.parse_item = lambda: (NFAState(), NFAState())
    pg.parse_alt()


# Generated at 2022-06-17 16:52:14.093240
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    pg = ParserGenerator()
    a = NFAState()
    z = NFAState()
    a.addarc(z, "a")
    dfa = pg.make_dfa(a, z)
    assert len(dfa) == 2
    assert dfa[0].nfaset == {a: 1}
    assert dfa[1].nfaset == {z: 1}
    assert dfa[0].arcs == {"a": dfa[1]}
    assert dfa[1].arcs == {}
    assert dfa[0].isfinal == False
    assert dfa[1].isfinal == True
    b = NFAState()
    a.addarc(b, "b")
    dfa = pg.make_dfa(a, z)
    assert len(dfa) == 3

# Generated at 2022-06-17 16:52:20.320172
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    pg = ParserGenerator()
    pg.gettoken = lambda: None
    pg.value = "("
    pg.type = token.OP
    pg.parse_rhs = lambda: (NFAState(), NFAState())
    pg.gettoken = lambda: None
    pg.value = ")"
    pg.type = token.OP
    a, z = pg.parse_item()
    assert isinstance(a, NFAState)
    assert isinstance(z, NFAState)
    assert a.arcs == [(None, z)]
    pg.value = "NAME"
    pg.type = token.NAME
    a, z = pg.parse_item()
    assert isinstance(a, NFAState)
    assert isinstance(z, NFAState)
    assert a.arcs == [("NAME", z)]

# Generated at 2022-06-17 16:52:27.578750
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    import io
    import tokenize
    import unittest
    from . import grammar

    class TestCase(unittest.TestCase):
        def test_make_grammar(self):
            pg = ParserGenerator()
            pg.add_production("file_input", [("stmt", True)])
            pg.add_production("stmt", [("expr", True)])
            pg.add_production("expr", [("atom", True)])
            pg.add_production("atom", [("NAME", False)])
            pg.add_production("atom", [("NUMBER", False)])
            pg.add_production("atom", [("STRING", False)])
            pg.add_production("atom", [("'('", False), ("expr", True), ("')'", False)])

# Generated at 2022-06-17 16:52:36.770948
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    pg = ParserGenerator()
    pg.generator = tokenize.generate_tokens(io.StringIO("foo").readline)
    pg.gettoken()
    assert pg.parse_atom() == (NFAState([(None, NFAState([("foo", NFAState([]))]))]), NFAState([]))
    pg.generator = tokenize.generate_tokens(io.StringIO("'foo'").readline)
    pg.gettoken()
    assert pg.parse_atom() == (NFAState([(None, NFAState([("foo", NFAState([]))]))]), NFAState([]))
    pg.generator = tokenize.generate_tokens(io.StringIO("(foo)").readline)
    pg.gettoken()

# Generated at 2022-06-17 16:52:51.975028
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    pg = ParserGenerator()
    pg.gettoken = lambda: None
    pg.value = "("
    pg.type = token.OP
    pg.parse_item = lambda: (NFAState(), NFAState())
    pg.parse_alt()
    pg.value = "|"
    pg.parse_alt()
    pg.value = ")"
    pg.parse_alt()
    pg.value = "("
    pg.parse_alt()
    pg.value = ")"
    pg.parse_alt()
    pg.value = "("
    pg.parse_alt()
    pg.value = "|"
    pg.parse_alt()
    pg.value = ")"
    pg.parse_alt()
    pg.value = "("
    pg.parse_alt()

# Generated at 2022-06-17 16:52:57.961661
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    pg = ParserGenerator()
    a = NFAState()
    z = NFAState()
    a.addarc(z, "a")
    dfa = pg.make_dfa(a, z)
    assert len(dfa) == 2
    assert dfa[0].nfaset == {a: 1, z: 1}
    assert dfa[1].nfaset == {z: 1}
    assert dfa[0].arcs == {"a": dfa[1]}
    assert dfa[1].arcs == {}
    assert dfa[0].isfinal == False
    assert dfa[1].isfinal == True
    a = NFAState()
    z = NFAState()
    a.addarc(z, "a")
    a.addarc(z, "b")
   

# Generated at 2022-06-17 16:53:10.457616
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    pg = ParserGenerator()
    pg.type = token.NAME
    pg.value = "foo"
    pg.filename = "foo.py"
    pg.end = (1, 2)
    pg.line = "foo"
    pg.expect(token.NAME)
    pg.expect(token.NAME, "foo")
    pg.expect(token.NAME, "bar")
    try:
        pg.expect(token.NAME, "bar")
    except SyntaxError:
        pass
    else:
        raise TestFailed("expected SyntaxError")
    try:
        pg.expect(token.NUMBER)
    except SyntaxError:
        pass
    else:
        raise TestFailed("expected SyntaxError")

# Generated at 2022-06-17 16:53:21.156497
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    pg = PgenGrammar()
    assert pg.start == None
    assert pg.keywords == {}
    assert pg.tokens == {}
    assert pg.dfas == {}
    assert pg.p_rules == {}
    assert pg.symbol2number == {}
    assert pg.number2symbol == {}
    assert pg.states == []
    assert pg.literals == []
    assert pg.error_func == None
    assert pg.error_func_name == None
    assert pg.file == None
    assert pg.callbacks == {}
    assert pg.symbol2label == {}
    assert pg.symbol2value == {}
    assert pg.symbol2first == {}
    assert pg.check_assignment == True
    assert pg.check_arguments == True
    assert pg.check_return == True


# Generated at 2022-06-17 16:53:32.327720
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    import io
    import tokenize
    from typing import Iterator
    from typing import Tuple

    def gettokens(s: str) -> Iterator[Tuple[int, str, Tuple[int, int], Tuple[int, int], str]]:
        f = io.StringIO(s)
        g = tokenize.generate_tokens(f.readline)
        for t in g:
            yield t

    def test(s: str) -> None:
        pg = ParserGenerator()
        pg.generator = gettokens(s)
        pg.gettoken()
        print(pg.type, pg.value)

    test("")
    test("\n")
    test("# comment\n")
    test("# comment\n\n")

# Generated at 2022-06-17 16:54:28.139950
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    pg = ParserGenerator()
    pg.dump_nfa("foo", NFAState(), NFAState())
    pg.dump_nfa("foo", NFAState(), NFAState())

# Generated at 2022-06-17 16:54:38.040171
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    pg = ParserGenerator()
    c = pg.make_grammar()

# Generated at 2022-06-17 16:54:44.247191
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    pg = ParserGenerator()
    pg.filename = "test_ParserGenerator_parse_atom"
    pg.line = "x = 1"
    pg.generator = tokenize.generate_tokens(StringIO(pg.line).readline)
    pg.gettoken()
    assert pg.type == token.NAME
    assert pg.value == "x"
    a, z = pg.parse_atom()
    assert a.arcs == [(None, z)]
    assert z.arcs == []
    pg.gettoken()
    assert pg.type == token.OP
    assert pg.value == "="
    a, z = pg.parse_atom()
    assert a.arcs == [(None, z)]
    assert z.arcs == []
    pg.gettoken()
    assert pg.type == token

# Generated at 2022-06-17 16:54:54.176998
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    pg = ParserGenerator()
    pg.symbol2number = {"foo": 1, "bar": 2}
    pg.labels = []
    pg.tokens = {}
    pg.keywords = {}
    pg.symbol2label = {}
    pg.make_label(None, "foo")
    pg.make_label(None, "bar")
    pg.make_label(None, "NAME")
    pg.make_label(None, "NUMBER")
    pg.make_label(None, "STRING")
    pg.make_label(None, '"if"')
    pg.make_label(None, '"else"')
    pg.make_label(None, '"elif"')
    pg.make_label(None, '"while"')

# Generated at 2022-06-17 16:55:05.724525
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    pg = ParserGenerator()

# Generated at 2022-06-17 16:55:13.852871
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    pg = ParserGenerator()
    pg.generator = tokenize.generate_tokens(StringIO("a").readline)
    pg.gettoken()
    a, z = pg.parse_atom()
    assert a.arcs == [(None, z)]
    assert z.arcs == []
    assert a.arcs[0][1] is z
    assert z.arcs == []
    assert a.arcs[0][0] is None
    assert a.arcs[0][1] is z
    assert z.arcs == []
    assert a.arcs[0][0] is None
    assert a.arcs[0][1] is z
    assert z.arcs == []
    assert a.arcs[0][0] is None
    assert a.arcs[0][1] is z

# Generated at 2022-06-17 16:55:19.351662
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    import io
    import tokenize
    import unittest
    from test.support import captured_stdout

    class ParserGeneratorTestCase(unittest.TestCase):
        def test_make_grammar(self):
            with captured_stdout() as stdout:
                pg = ParserGenerator()
                pg.make_grammar(io.StringIO(GRAMMAR))
            self.assertEqual(stdout.getvalue(), EXPECTED)

    GRAMMAR = """\
# Grammar

start: items
items: items item
     |
item: 'a'
    | 'b'
"""


# Generated at 2022-06-17 16:55:28.645864
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    pg = ParserGenerator()
    a = NFAState()
    z = NFAState()
    a.addarc(z, "a")
    dfa = pg.make_dfa(a, z)
    assert len(dfa) == 2
    assert len(dfa[0].arcs) == 1
    assert dfa[0].arcs["a"] is dfa[1]
    assert dfa[1].isfinal
    assert not dfa[0].isfinal

    a = NFAState()
    z = NFAState()
    a.addarc(z, "a")
    a.addarc(z, "b")
    dfa = pg.make_dfa(a, z)
    assert len(dfa) == 2
    assert len(dfa[0].arcs) == 2


# Generated at 2022-06-17 16:55:40.474099
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    pg = ParserGenerator()
    c = pg.make_converter()
    assert c.make_label(c, "NAME") == 0
    assert c.make_label(c, "NUMBER") == 1
    assert c.make_label(c, "STRING") == 2
    assert c.make_label(c, "LPAR") == 3
    assert c.make_label(c, "RPAR") == 4
    assert c.make_label(c, "LSQB") == 5
    assert c.make_label(c, "RSQB") == 6
    assert c.make_label(c, "COLON") == 7
    assert c.make_label(c, "COMMA") == 8
    assert c.make_label(c, "SEMI") == 9

# Generated at 2022-06-17 16:55:49.580071
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    import io
    import tokenize
    from typing import Iterator
    from typing import Tuple
    from typing import Union
    from typing import cast
    from typing import Any
    from typing import Dict
    from typing import List
    from typing import Text
    from typing import Sequence
    from typing import Optional
    from typing import NoReturn
    from typing import TYPE_CHECKING
    from typing import overload
    from typing import Callable
    from typing import TypeVar
    from typing import Generic
    from typing import cast
    from typing import get_type_hints
    from typing import NamedTuple
    from typing import Union
    from typing import Any
    from typing import Dict
    from typing import List
    from typing import Text
    from typing import Sequence
    from typing import Optional
    from typing import NoReturn
    from typing import TYPE_CHECKING
   

# Generated at 2022-06-17 16:56:51.272312
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    import io
    import tokenize
    from token import NAME, OP, STRING
    pg = ParserGenerator()
    pg.filename = "<test>"
    pg.generator = tokenize.generate_tokens(io.StringIO("a = b").readline)
    pg.gettoken()
    assert pg.type == NAME
    assert pg.value == "a"
    pg.gettoken()
    assert pg.type == OP
    assert pg.value == "="
    pg.gettoken()
    assert pg.type == NAME
    assert pg.value == "b"
    pg.gettoken()
    assert pg.type == tokenize.ENDMARKER
    assert pg.value == ""

# Generated at 2022-06-17 16:56:56.917476
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    pg = ParserGenerator()
    c = pg.make_converter()
    assert c.make_label(c, "NAME") == 0
    assert c.make_label(c, "NUMBER") == 1
    assert c.make_label(c, "STRING") == 2
    assert c.make_label(c, "LPAR") == 3
    assert c.make_label(c, "RPAR") == 4
    assert c.make_label(c, "LSQB") == 5
    assert c.make_label(c, "RSQB") == 6
    assert c.make_label(c, "COLON") == 7
    assert c.make_label(c, "COMMA") == 8
    assert c.make_label(c, "SEMI") == 9

# Generated at 2022-06-17 16:57:09.425579
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    pg = ParserGenerator()
    pg.dump_dfa("foo", [DFAState({}, False)])
    pg.dump_dfa("foo", [DFAState({}, True)])
    pg.dump_dfa("foo", [DFAState({}, False), DFAState({}, True)])
    pg.dump_dfa("foo", [DFAState({}, False), DFAState({}, False)])
    pg.dump_dfa("foo", [DFAState({}, True), DFAState({}, True)])
    pg.dump_dfa("foo", [DFAState({}, True), DFAState({}, False)])
    pg.dump_dfa("foo", [DFAState({}, False), DFAState({}, True), DFAState({}, False)])

# Generated at 2022-06-17 16:57:21.733710
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    import io
    import tokenize
    import unittest
    import unittest.mock

    class MockTokenizer:
        def __init__(self, *args, **kwargs):
            pass


# Generated at 2022-06-17 16:57:29.352212
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    pg = ParserGenerator()
    pg.add_production("S", ["a", "b"])
    pg.add_production("S", ["a", "c"])
    pg.add_production("S", ["d"])
    pg.add_production("S", ["e", "f"])
    pg.add_production("S", ["g"])
    pg.add_production("S", ["h", "i"])
    pg.add_production("S", ["j"])
    pg.add_production("S", ["k", "l"])
    pg.add_production("S", ["m"])
    pg.add_production("S", ["n", "o"])
    pg.add_production("S", ["p"])
    pg.add_production("S", ["q", "r"])
   

# Generated at 2022-06-17 16:57:37.015388
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    pg = ParserGenerator()
    pg.add_production("a", ("b", "c"))
    pg.add_production("b", ("d", "e"))
    pg.add_production("c", ("f", "g"))
    pg.add_production("d", ("h", "i"))
    pg.add_production("e", ("j", "k"))
    pg.add_production("f", ("l", "m"))
    pg.add_production("g", ("n", "o"))
    pg.add_production("h", ("p", "q"))
    pg.add_production("i", ("r", "s"))
    pg.add_production("j", ("t", "u"))
    pg.add_production("k", ("v", "w"))

# Generated at 2022-06-17 16:57:52.114276
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    pg = ParserGenerator()
    c = pg.make_converter()
    assert c.make_label(c, "NAME") == 0
    assert c.make_label(c, "NUMBER") == 1
    assert c.make_label(c, "STRING") == 2
    assert c.make_label(c, "if") == 3
    assert c.make_label(c, "and") == 4
    assert c.make_label(c, "or") == 5
    assert c.make_label(c, "not") == 6
    assert c.make_label(c, "in") == 7
    assert c.make_label(c, "is") == 8
    assert c.make_label(c, "def") == 9
    assert c.make_label(c, "class") == 10


# Generated at 2022-06-17 16:58:02.996502
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    import io
    import tokenize
    from . import grammar

    def _test(text: str, expected: str) -> None:
        f = io.StringIO(text)
        gen = tokenize.generate_tokens(f.readline)
        parser = ParserGenerator(gen, "test")
        parser.parse()
        for name in sorted(parser.dfas.keys()):
            dfa = parser.dfas[name]
            a = dfa[0]
            z = dfa[-1]
            parser.dump_nfa(name, a, z)
        assert parser.output.getvalue() == expected


# Generated at 2022-06-17 16:58:14.934925
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    pg = ParserGenerator()
    pg.gettoken = lambda: None
    pg.value = "("
    pg.type = token.OP
    pg.parse_item = lambda: (NFAState(), NFAState())
    pg.parse_alt()
    pg.value = ")"
    pg.parse_alt()
    pg.value = "|"
    pg.parse_alt()
    pg.value = "("
    pg.parse_alt()
    pg.value = ")"
    pg.parse_alt()
    pg.value = "|"
    pg.parse_alt()
    pg.value = "("
    pg.parse_alt()
    pg.value = ")"
    pg.parse_alt()
    pg.value = "|"
    pg.parse_alt()

# Generated at 2022-06-17 16:58:24.923106
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    # This test is a bit fragile, since it depends on the order of
    # states in the DFA.  But it's better than nothing.
    pg = ParserGenerator()
    dfa = [
        DFAState({NFAState(): 1}, NFAState()),
        DFAState({NFAState(): 1}, NFAState()),
        DFAState({NFAState(): 1}, NFAState()),
        DFAState({NFAState(): 1}, NFAState()),
        DFAState({NFAState(): 1}, NFAState()),
        DFAState({NFAState(): 1}, NFAState()),
        DFAState({NFAState(): 1}, NFAState()),
    ]
    dfa[0].addarc(dfa[1], "a")