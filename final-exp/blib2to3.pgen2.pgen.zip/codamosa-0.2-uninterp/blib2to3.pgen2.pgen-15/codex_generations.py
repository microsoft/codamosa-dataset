

# Generated at 2022-06-17 16:51:29.098224
# Unit test for function generate_grammar
def test_generate_grammar():
    g = generate_grammar()
    assert g.start == "file_input"

# Generated at 2022-06-17 16:51:37.120083
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    pg = ParserGenerator()
    a = NFAState()
    z = NFAState()
    a.addarc(z, "a")
    dfa = pg.make_dfa(a, z)
    assert len(dfa) == 2
    assert dfa[0].arcs == {"a": dfa[1]}
    assert dfa[1].arcs == {}
    assert dfa[0].isfinal == False
    assert dfa[1].isfinal == True

# Generated at 2022-06-17 16:51:44.690956
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    from io import StringIO
    from tokenize import tokenize
    from token import tokenize as tokenize2
    from token import tokenize as tokenize3
    from token import tokenize as tokenize4
    from token import tokenize as tokenize5
    from token import tokenize as tokenize6
    from token import tokenize as tokenize7
    from token import tokenize as tokenize8
    from token import tokenize as tokenize9
    from token import tokenize as tokenize10
    from token import tokenize as tokenize11
    from token import tokenize as tokenize12
    from token import tokenize as tokenize13
    from token import tokenize as tokenize14
    from token import tokenize as tokenize15
    from token import tokenize as tokenize16
    from token import tokenize as tokenize17
    from token import tokenize as token

# Generated at 2022-06-17 16:51:56.032618
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    pg = ParserGenerator()
    pg.dfas = {
        "a": [DFAState({}, False), DFAState({}, False)],
        "b": [DFAState({}, False), DFAState({}, False)],
        "c": [DFAState({}, False), DFAState({}, False)],
    }
    pg.first = {
        "a": {"a": 1, "b": 1},
        "b": {"c": 1},
        "c": {"c": 1},
    }
    c = pg.make_converter()
    assert c.make_first(c, "a") == {1: 1, 2: 1}
    assert c.make_first(c, "b") == {3: 1}

# Generated at 2022-06-17 16:52:07.451945
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    pg = ParserGenerator()
    pg.generator = tokenize.generate_tokens(io.StringIO("a").readline)
    pg.gettoken()
    assert pg.parse_item() == (NFAState([(None, NFAState([('a', NFAState([]))]))]),
                               NFAState([('a', NFAState([]))]))
    pg.generator = tokenize.generate_tokens(io.StringIO("a+").readline)
    pg.gettoken()
    assert pg.parse_item() == (NFAState([(None, NFAState([('a', NFAState([]))]))]),
                               NFAState([('a', NFAState([]))]))

# Generated at 2022-06-17 16:52:16.448552
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    pg = ParserGenerator()
    pg.add_rhs("foo", "bar")
    pg.add_rhs("bar", "baz")
    pg.add_rhs("bar", "baz baz")
    pg.add_rhs("baz", "quux")
    pg.add_rhs("baz", "quux quux")
    pg.add_rhs("quux", "NAME")
    pg.add_rhs("quux", "STRING")
    pg.add_rhs("quux", "NUMBER")
    pg.add_rhs("quux", "LPAR", "foo", "RPAR")
    pg.add_rhs("quux", "LBRACKET", "foo", "RBRACKET")

# Generated at 2022-06-17 16:52:26.179100
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    pg = ParserGenerator()
    pg.generator = tokenize.generate_tokens(io.StringIO("a b | c d").readline)
    pg.gettoken()
    a, z = pg.parse_rhs()
    assert a.arcs == [(None, a.next[0]), ("a", a.next[1])]
    assert a.next[0].arcs == [(None, a.next[0].next[0]), ("b", z)]
    assert a.next[1].arcs == [(None, a.next[1].next[0]), ("c", a.next[1].next[1])]
    assert a.next[1].next[0].arcs == [(None, a.next[1].next[0].next[0]), ("d", z)]
    assert a.next

# Generated at 2022-06-17 16:52:31.460378
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    p = ParserGenerator()

# Generated at 2022-06-17 16:52:34.529333
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    pg = ParserGenerator()
    pg.dump_nfa("name", "start", "finish")
    pg.dump_nfa("name", "start", "finish")

# Generated at 2022-06-17 16:52:43.028083
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    pg = ParserGenerator()
    pg.parse_rhs()
    pg.parse_rhs()
    pg.parse_rhs()
    pg.parse_rhs()
    pg.parse_rhs()
    pg.parse_rhs()
    pg.parse_rhs()
    pg.parse_rhs()
    pg.parse_rhs()
    pg.parse_rhs()
    pg.parse_rhs()
    pg.parse_rhs()
    pg.parse_rhs()
    pg.parse_rhs()
    pg.parse_rhs()
    pg.parse_rhs()
    pg.parse_rhs()
    pg.parse_rhs()
    pg.parse_rhs()
    pg.parse_rhs()
    pg.parse_rhs()
   

# Generated at 2022-06-17 16:54:07.560136
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    pg = ParserGenerator()
    pg.symbol2number = {"foo": 1, "bar": 2}
    pg.keywords = {"and": 3, "or": 4}
    pg.tokens = {token.NAME: 5, token.NUMBER: 6, token.STRING: 7}
    pg.labels = []
    pg.symbol2label = {}
    pg.tokens = {}
    pg.keywords = {}
    assert pg.make_label(None, "foo") == 1
    assert pg.make_label(None, "bar") == 2
    assert pg.make_label(None, "and") == 3
    assert pg.make_label(None, "or") == 4
    assert pg.make_label(None, "NAME") == 5

# Generated at 2022-06-17 16:54:17.353583
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    pg = ParserGenerator()
    c = pg.make_converter()
    assert c.make_label(c, "NAME") == 0
    assert c.make_label(c, "NUMBER") == 1
    assert c.make_label(c, "STRING") == 2
    assert c.make_label(c, "LPAR") == 3
    assert c.make_label(c, "RPAR") == 4
    assert c.make_label(c, "LSQB") == 5
    assert c.make_label(c, "RSQB") == 6
    assert c.make_label(c, "COLON") == 7
    assert c.make_label(c, "COMMA") == 8
    assert c.make_label(c, "SEMI") == 9

# Generated at 2022-06-17 16:54:28.127766
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    # Test case for issue #9073: simplify_dfa() should not raise an
    # exception.
    pg = ParserGenerator()

# Generated at 2022-06-17 16:54:38.002381
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    pg = ParserGenerator()
    pg.symbol2number = {"foo": 1, "bar": 2}
    pg.labels = []
    pg.tokens = {}
    pg.keywords = {}
    pg.symbol2label = {}
    c = pg.make_converter()
    assert c.make_label(c, "foo") == 0
    assert c.make_label(c, "bar") == 1
    assert c.make_label(c, "NAME") == 2
    assert c.make_label(c, "NUMBER") == 3
    assert c.make_label(c, "STRING") == 4
    assert c.make_label(c, "'+'") == 5
    assert c.make_label(c, "'*'") == 6

# Generated at 2022-06-17 16:54:52.080348
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    pg = ParserGenerator()
    pg.generator = tokenize.generate_tokens(StringIO("a").readline)
    pg.gettoken()
    a, z = pg.parse_atom()
    assert a.arcs == [(None, z)]
    assert z.arcs == []
    assert a.arcs[0][1] is z
    assert z.arcs == []
    assert a.arcs[0][0] == "a"
    assert a.arcs[0][1] is z
    assert z.arcs == []
    assert a.arcs[0][0] == "a"
    assert a.arcs[0][1] is z
    assert z.arcs == []
    assert a.arcs[0][0] == "a"

# Generated at 2022-06-17 16:54:56.205000
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    pg = ParserGenerator()
    pg.dump_nfa("foo", NFAState(), NFAState())

# Generated at 2022-06-17 16:55:07.567542
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    import io
    import tokenize
    from . import grammar
    from . import pgen

    def test(text: str, expected: str) -> None:
        f = io.StringIO(text)
        g = tokenize.generate_tokens(f.readline)
        p = pgen.ParserGenerator(g, "test")
        dfas, startsymbol = p.parse()
        assert startsymbol == expected
        p.addfirstsets()
        c = p.make_converter()
        c.dump()

    test(
        """
        start: 'a'
        """,
        "start",
    )
    test(
        """
        start: 'a' | 'b'
        """,
        "start",
    )

# Generated at 2022-06-17 16:55:14.868706
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    from . import pgen
    from . import token

    def make_dfa(arcs: List[Tuple[int, str, int]]) -> List[DFAState]:
        dfa = []
        for i, (label, next) in arcs:
            if i >= len(dfa):
                dfa.append(DFAState({}, None))
            dfa[i].addarc(dfa[next], label)
        return dfa

    def check_dfa(dfa: List[DFAState], arcs: List[Tuple[int, str, int]]) -> None:
        assert len(dfa) == len(arcs)
        for i, (label, next) in arcs:
            assert dfa[i].arcs[label] is dfa[next]


# Generated at 2022-06-17 16:55:25.699425
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    pg = ParserGenerator()

# Generated at 2022-06-17 16:55:38.240927
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    pg = ParserGenerator()
    pg.dfas = {
        "a": [DFAState({}, False), DFAState({}, True)],
        "b": [DFAState({}, False), DFAState({}, True)],
    }
    pg.symbol2number = {"a": 0, "b": 1}
    pg.labels = [(0, None), (1, None)]
    pg.tokens = {0: 0, 1: 1}
    pg.keywords = {"a": 0, "b": 1}
    pg.first = {"a": {"a": 1, "b": 1}, "b": {"a": 1, "b": 1}}
    pg.startsymbol = "a"
    c = pg.make_converter()

# Generated at 2022-06-17 16:57:24.102619
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    pg = ParserGenerator()
    pg.type = token.NAME
    pg.value = "foo"
    pg.expect(token.NAME)
    pg.expect(token.NAME, "foo")
    pg.expect(token.NAME, "bar")
    try:
        pg.expect(token.NAME, "bar")
    except SyntaxError as e:
        assert e.msg == "expected NAME/bar, got NAME/foo"
        assert e.filename == "<string>"
        assert e.lineno == 1
        assert e.offset == 0
        assert e.text == ""
    else:
        assert False, "expected SyntaxError"


# Generated at 2022-06-17 16:57:35.049680
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    import io
    import tokenize
    import unittest
    from unittest import mock

    class TestCase(unittest.TestCase):
        def test_it(self):
            generator = tokenize.generate_tokens(io.StringIO("").readline)
            pg = ParserGenerator(generator, "<string>")
            with self.assertRaises(SyntaxError) as cm:
                pg.raise_error("expected %s/%s, got %s/%s", "a", "b", "c", "d")
            self.assertEqual(cm.exception.args, ("expected a/b, got c/d", ("<string>", 1, 0, "")))

    unittest.main()

# Generated at 2022-06-17 16:57:42.790692
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    pg = ParserGenerator()
    pg.dfas = {
        "a": [DFAState({}, False), DFAState({}, True)],
        "b": [DFAState({}, False), DFAState({}, True)],
        "c": [DFAState({}, False), DFAState({}, True)],
    }
    pg.dfas["a"][0].addarc(pg.dfas["b"][0], "x")
    pg.dfas["a"][0].addarc(pg.dfas["c"][0], "y")
    pg.dfas["b"][0].addarc(pg.dfas["a"][0], "z")
    pg.dfas["b"][0].addarc(pg.dfas["c"][0], "w")
    pg.df

# Generated at 2022-06-17 16:57:52.521903
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    pg = ParserGenerator()
    pg.parse(
        """
        start: '[' expr ']'
        expr: expr '+' term | expr '-' term | term
        term: term '*' factor | term '/' factor | factor
        factor: '(' expr ')' | NAME | NUMBER
        """
    )
    pg.addfirstsets()
    pg.make_parser()
    pg.make_pgen()
    pg.make_parsetab()
    pg.dump_grammar()
    pg.dump_table()



# Generated at 2022-06-17 16:57:59.284896
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    pg = ParserGenerator()
    a = NFAState()
    z = NFAState()
    a.addarc(z, "a")
    dfa = pg.make_dfa(a, z)
    assert len(dfa) == 2
    assert len(dfa[0].arcs) == 1
    assert dfa[0].arcs["a"] is dfa[1]
    assert dfa[1].isfinal
    assert dfa[1].arcs == {}


# Generated at 2022-06-17 16:58:06.288373
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    pg = ParserGenerator()
    pg.type = token.NAME
    pg.value = "foo"
    assert pg.expect(token.NAME) == "foo"
    pg.type = token.OP
    pg.value = ":"
    assert pg.expect(token.OP, ":") == ":"
    with pytest.raises(SyntaxError):
        pg.expect(token.OP, ";")
    with pytest.raises(SyntaxError):
        pg.expect(token.NAME)


# Generated at 2022-06-17 16:58:16.478569
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    pg = ParserGenerator()
    pg.make_scanner()
    pg.parse_grammar(GRAMMAR)
    pg.addfirstsets()
    pg.make_parser()
    pg.dump_dfa("file_input", pg.dfas["file_input"])
    pg.dump_dfa("eval_input", pg.dfas["eval_input"])
    pg.dump_dfa("single_input", pg.dfas["single_input"])
    pg.dump_dfa("decorator", pg.dfas["decorator"])
    pg.dump_dfa("decorators", pg.dfas["decorators"])
    pg.dump_dfa("decorated", pg.dfas["decorated"])

# Generated at 2022-06-17 16:58:26.305634
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    import io
    import tokenize
    from . import pgen2
    from . import pgen2_grammar
    from . import pgen2_parse
    from . import pgen2_token

    # Test data
    data = """\
# This is a comment
expr: x '+' y
    | '(' expr ')'
x: 'x'
y: 'y'
"""

    # Parse the test data
    generator = tokenize.generate_tokens(io.StringIO(data).readline)
    parser = pgen2_parse.ParserGenerator(generator, "test_dump_nfa")
    dfas, startsymbol = parser.parse()

    # Dump the NFA for the first rule

# Generated at 2022-06-17 16:58:38.607604
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    pg = ParserGenerator()
    a = NFAState()
    z = NFAState()
    a.addarc(z, "a")
    dfa = pg.make_dfa(a, z)
    assert len(dfa) == 2
    assert dfa[0].nfaset == {a: 1}
    assert dfa[1].nfaset == {z: 1}
    assert dfa[0].arcs == {("a", dfa[1]): 1}
    assert dfa[1].arcs == {}
    assert dfa[0].isfinal == False
    assert dfa[1].isfinal == True
    assert dfa[0].label == None
    assert dfa[1].label == None
    assert dfa[0].number == 0
    assert dfa[1].number

# Generated at 2022-06-17 16:58:52.801967
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    pg = ParserGenerator()
    a = NFAState()
    z = NFAState()
    a.addarc(z, "a")
    dfa = pg.make_dfa(a, z)
    assert len(dfa) == 2
    assert dfa[0].arcs == {"a": dfa[1]}
    assert dfa[1].arcs == {}
    assert dfa[0].isfinal == False
    assert dfa[1].isfinal == True
    assert dfa[0].nfaset == {a: 1}
    assert dfa[1].nfaset == {z: 1}
    a = NFAState()
    z = NFAState()
    a.addarc(z, "a")
    a.addarc(z, "b")
    dfa = pg