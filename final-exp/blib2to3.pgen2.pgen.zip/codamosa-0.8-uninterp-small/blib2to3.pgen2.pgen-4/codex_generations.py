

# Generated at 2022-06-25 15:00:12.149125
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    # Test case data
    string = '\x0bF\'^m@rCs"Kh)jB7'

# Generated at 2022-06-25 15:00:19.064710
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    # Test 1:
    parser_generator_1 = ParserGenerator('\n\n\n#\n#\nNon-terminal symbols\n#\n#\n')
    parser_generator_1.gettoken()
    parser_generator_1.gettoken()
    parser_generator_1.gettoken()
    parser_generator_1.gettoken()
    # test 1.1
    parser_generator_1.gettoken()

    # test 2.1
    parser_generator_1.gettoken()
    parser_generator_1.gettoken()


if __name__ == '__main__':
    test_case_0()
    test_ParserGenerator_make_dfa()

# Generated at 2022-06-25 15:00:23.033473
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    print("Testing method parse_alt of class ParserGenerator:")
    str_0 = '\x0bF\'^m@rCs"Kh)jB7'
    parser_generator_0 = ParserGenerator(str_0)


# Generated at 2022-06-25 15:00:31.053533
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    str_0 = '\x0bF\'^m@rCs"Kh)jB7'
    parser_generator_0 = ParserGenerator(str_0)
    c_0 = parser_generator_0.make_grammar()
# There is not really a test for method make_grammar because it does
# not really change anything in the ParserGenerator object.
# We test to make sure there is no exception thrown.

    # Create a string representation of c_0 object
    str_0 = str(c_0)

    # Assert that the string representation of c_0 object is what we expect
    assert str_0 == "C"



# Generated at 2022-06-25 15:00:36.915829
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    from . import pgen

    # initilizing the test data
    str_0 = (
        'aPu^O\' #2l_u;tt("HV{Gp\'&)#z7q3*"m"f!\'a(Z:ITo/i@]\'1a/\\0e"x"|\'r"Eo("*\n'
    )
    list_0 = []
    list_1 = []
    parser_generator_0 = ParserGenerator(str_0)

    # unit test start
    # initilizing the test data
    nfa_state_0 = NFAState(None, set())
    nfa_state_1 = NFAState(None, set())
    nfa_state_2 = NFAState(None, set())
    nfa_state_3

# Generated at 2022-06-25 15:00:50.465747
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    str_0 = '/gMv~'
    parser_generator_0 = ParserGenerator(str_0)
    str_1 = '0'
    parser_generator_0.value = str_1
    int_0 = tokenize.NUMBER
    parser_generator_0.type = int_0
    str_2 = 'tR9}1W\x14;}'
    parser_generator_0.raise_error(str_2)
    str_3 = 'f@=\x16.j\x0cE"\x0c'
    parser_generator_0.value = str_3
    int_1 = token.STRING
    parser_generator_0.type = int_1
    str_4 = '9b\x16\x0f\x06\x19'

# Generated at 2022-06-25 15:01:00.642151
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    str_0 = '\x0bF\'^m@rCs"Kh)jB7'
    parser_generator_0 = ParserGenerator(str_0)

    dfa_list = list()
    dfa_list.append(DFAState(set(), set()))
    dfa_list.append(DFAState(set(), set()))
    dfa_list.append(DFAState(set(), set()))
    dfa_list.append(DFAState(set(), set()))
    dfa_list.append(DFAState(set(), set()))

    # arc label is a symbol name
    # arc label is a named token
    # arc label is a keyword
    # arc label is an operator
    # arc label is not supported



# Generated at 2022-06-25 15:01:08.730404
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    # Case 1: Using an invalid token as the type
    str_1 = '\x0bF\'^m@rCs"Kh)jB7'
    parser_generator_1 = ParserGenerator(str_1)
    try:
        parser_generator_1.expect(token.OP, ":")
    except SyntaxError:
        pass
    else:
        assert "Unexpected error: No exception raised!"
    # Case 2: Using an invalid value
    str_2 = '\x0bF\'^m@rCs"Kh)jB7'
    parser_generator_2 = ParserGenerator(str_2)
    try:
        parser_generator_2.expect(token.NAME, "name")
    except SyntaxError:
        pass

# Generated at 2022-06-25 15:01:20.369158
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    grammar_generator_0 = ParserGenerator(str_0)
    # str_1 = '\x0bF\'^m@rCs"Kh)jB7'
    str_1 = '\x0bF\'^m@rCs"Kh)jB7'
    converter_0 = Converter(str_1)
    # str_2 = '\x0bF\'^m@rCs"Kh)jB7'
    str_2 = '\x0bF\'^m@rCs"Kh)jB7'
    converter_1 = Converter(str_2)
    # str_3 = '\x0bF\'^m@rCs"Kh)jB7'
    str_3 = '\x0bF\'^m@rCs"Kh)jB7'
    converter

# Generated at 2022-06-25 15:01:23.747091
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    str_0 = '\x0bF\'^m@rCs"Kh)jB7'
    parser_generator_0 = ParserGenerator(str_0)
    parser_generator_0.parse_alt()


# Generated at 2022-06-25 15:01:54.213306
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    tup_0 = ParserGenerator.parse(100, [100], '\x0bF\'^m@rCs"Kh)jB7', ['\x0bF\'^m@rCs"Kh)jB7'])
    str_0 = str(tup_0)
    str_1 = str(('\x0bF\'^m@rCs"Kh)jB7', []))
    assert compare(str_0, str_1)


# Generated at 2022-06-25 15:01:56.832324
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    str_0 = '\x0bF\'^m@rCs"Kh)jB7'
    assert_equal(ParserGenerator.make_grammar(str_0), None)


# Generated at 2022-06-25 15:02:03.847871
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    data = b'\x0bF\'^m@rCs"Kh)jB7'
    # test decoding bytestring argument
    p = ParserGenerator(data)
    # test encoding bytestring result

# Generated at 2022-06-25 15:02:05.978637
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    # Pass str_0 to the function
    try:
        assert ParserGenerator.make_grammar(str_0)
    except:
        assert False


# Generated at 2022-06-25 15:02:08.594790
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    assert ParserGenerator


# Generated at 2022-06-25 15:02:10.673964
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    str_0 = '\x0bF\'^m@rCs"Kh)jB7'

    def test_case_0(self):
        # ATOM: '(' RHS ')' | NAME | STRING
        pass

# Generated at 2022-06-25 15:02:12.828072
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    code = """
if 1:
    pass
"""
    generator = ParserGenerator()
    generator.parse_string(code)
    # print (generator.dfas)
    # print (generator.first)
    assert False # TODO: implement your test here


# Generated at 2022-06-25 15:02:16.469182
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    str_0 = '\x0bF\'^m@rCs"Kh)jB7'
    # Test 0 for method parse_alt
    assert True
if __name__ == '__main__':
    test_ParserGenerator_parse_alt()
    test_case_0()

# Generated at 2022-06-25 15:02:18.609496
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    # TODO: Test case 0
    pass


# Generated at 2022-06-25 15:02:21.963837
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    p = ParserGenerator(['TOKEN'], 'S')
    p.make_pgen()
    p.addfirstsets()
    assert p.first['TOKEN'] == {'TOKEN': 1}


# Generated at 2022-06-25 15:02:47.455654
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    pytest.skip()

# Generated at 2022-06-25 15:02:58.079951
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    n_f_a_state_0 = NFAState()
    n_f_a_state_1 = NFAState()
    n_f_a_state_0.addarc(n_f_a_state_1, 'x')
    d_f_a_state_0 = DFAState({n_f_a_state_0}, n_f_a_state_1)
    d_f_a_state_1 = DFAState({n_f_a_state_1}, n_f_a_state_1)
    d_f_a_state_0.addarc(d_f_a_state_1, 'x')
    p_g = ParserGenerator()
    a_t_o_m_0 = 'w'

# Generated at 2022-06-25 15:03:09.627876
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    class TestParserGenerator(ParserGenerator):
        def dump_nfa(self, name: Text, start: "NFAState", finish: "NFAState") -> None:
            self.assertIs(name, "name")
            self.assertIs(start, n_f_a_state_0)
            self.assertIs(finish, n_f_a_state_0)
            # TODO: Implement this test
            raise NotImplementedError

    n_f_a_state_1 = NFAState()
    n_f_a_state_2 = NFAState()
    n_f_a_state_3 = NFAState()
    n_f_a_state_4 = NFAState()
    n_f_a_state_5 = NFAState()
    n_f_a_state

# Generated at 2022-06-25 15:03:17.375810
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    n_p_g_0 = ParserGenerator()
    test_Num_token_tok_name = []
    test_Num_value = []
    test_Num_begin = []
    test_Num_end = []
    test_Num_line = []


    for i in range(1000):
        tup = next(n_p_g_0.generator)
        test_Num_token_tok_name.append(token.tok_name[tup[0]])
        test_Num_value.append(tup[1])
        test_Num_begin.append(tup[2])
        test_Num_end.append(tup[3])
        test_Num_line.append(tup[4])


# Generated at 2022-06-25 15:03:26.243582
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    f = io.StringIO('''\
def: 'def' NAME parameters ['->' test] ':' suite
''')
    p = ParserGenerator()
    p.generator = tokenize.generate_tokens(f.readline)
    p.gettoken()
    a, z = p.parse()
    assert a is not z
    assert a.arcs == []
    assert z.arcs == []
    assert a.arcs == z.arcs
    p.make_dfa(a, z)


if __name__ == '__main__':
    test_ParserGenerator_make_dfa()

# Generated at 2022-06-25 15:03:29.087852
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    # Make sure that exception is raised
    # if parse() is called with a non-string
    # filename.
    ParserGenerator(None)
    ParserGenerator("parser-gen.grammar")
    # The above is a comment to make this
    # function multi-line.


# Generated at 2022-06-25 15:03:37.435851
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():

    assert fn_to_test == "make_label"
    assert param_pgen_grammar_0 == None
    assert param_label_0 == None
    assert param_label_1 == None
    assert param_label_2 == None
    assert param_label_3 == None
    assert param_label_4 == None
    assert param_label_5 == None
    assert param_label_6 == None
    assert param_label_7 == None
    assert param_label_8 == None
    assert param_label_9 == None

    assert param_c_0 == None
    assert n_f_a_state_0.arcs == {}
    assert n_f_a_state_0.final == False
    assert n_f_a_state_0.label == None

# Generated at 2022-06-25 15:03:45.070597
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    init_fnastates()
    init_dfastates()
    dfa = ParserGenerator('test_ParserGenerator_make_dfa',
                          'compiler/parser-gen.py').make_dfa(fnastates[0], fnastates[1])
    assert(dfa[0] == dfastates[0])
    assert(dfa[1] == dfastates[1])
    assert(dfa[2] == dfastates[2])
    assert(dfa[3] == dfastates[3])


# Generated at 2022-06-25 15:03:52.920762
# Unit test for method parse of class ParserGenerator

# Generated at 2022-06-25 15:03:58.455621
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    n_f_a_state_0 = NFAState()
    n_f_a_state_1 = NFAState()
    n_f_a_state_0.addarc(n_f_a_state_1)
    sut = ParserGenerator()
    assert isinstance(sut, ParserGenerator)
    expected = [DFAState({n_f_a_state_0: 1, n_f_a_state_1: 1}, n_f_a_state_1)]
    actual = sut.make_dfa(n_f_a_state_0, n_f_a_state_1)
    assert expected == actual


# Generated at 2022-06-25 15:05:39.574897
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    g_p_g_0_0 = ParserGenerator("test_grammar_0.txt")
    g_p_g_0_0.parse()


# Generated at 2022-06-25 15:05:42.112534
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    # Test case for method parse of class ParserGenerator
    assert ParserGenerator(None).parse() == (None, None)


# Generated at 2022-06-25 15:05:50.822629
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    assert PgenGrammar("./test.txt").__class__ == PgenGrammar
    assert PgenGrammar("./test.txt").symbol2number == {}
    assert PgenGrammar("./test.txt").number2symbol == {}
    assert PgenGrammar("./test.txt").states == []
    assert PgenGrammar("./test.txt").start == 0
    assert PgenGrammar("./test.txt").dfas == {}
    assert PgenGrammar("./test.txt").keywords == {}
    assert PgenGrammar("./test.txt").toknames == {}
    assert PgenGrammar("./test.txt").attr2label == {}


# Generated at 2022-06-25 15:06:01.014855
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    parser_generator_0 = ParserGenerator(StringIO.StringIO(
            "a: b c|d\nb: e|f\nc: g|\nd: h|\ne: i|\nf: i|\ng: |\nh: i|\ni: |\n"))

# Generated at 2022-06-25 15:06:07.123028
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    test_cases = [
        # test case 0
        ((test_case_0, token.NAME, "foo" ), 0),
        # test case 1
        ((test_case_0, token.OP, "[" ), 1),
    ]
    for test_case, expected_value in test_cases:
        args = test_case[0:2]
        assert test_case[2] == test_case[2]  # yapf: disable
        assert ParserGenerator(*args).make_label(*test_case[2:3]) == expected_value



# Generated at 2022-06-25 15:06:09.084695
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    converter = PgenConverter()
    converter.read_grammar(False)
    converter.addfirstsets()
    #print(converter.first)


# Generated at 2022-06-25 15:06:15.173051
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    p_g_0 = ParserGenerator()
    n_f_a_state_0 = NFAState()
    n_f_a_state_0.isfinal = True
    n_f_a_state_1 = NFAState()
    n_f_a_state_1.isfinal = True
    n_f_a_state_2 = NFAState()
    n_f_a_state_2.isfinal = True
    n_f_a_state_3 = NFAState()
    n_f_a_state_3.isfinal = True
    n_f_a_state_4 = NFAState()
    d_f_a_state_0 = DFAState({n_f_a_state_1: 1}, n_f_a_state_0)
    d_f

# Generated at 2022-06-25 15:06:20.705937
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    p_g_0 = ParserGenerator("")

    result_DFAState_1, result_DFAState_2 = p_g_0.parse_rhs()
    # tests case when self.value != "|"

    result_DFAState_3, result_DFAState_4 = p_g_0.parse_rhs()
    # tests case when self.value == "|"


# Generated at 2022-06-25 15:06:25.735258
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    n_f_a_state_0 = NFAState()
    n_f_a_state_1 = NFAState()
    n_f_a_state_0.addarc(n_f_a_state_1)
    n_f_a_state_1.addarc(n_f_a_state_0)
    parser_generator_2 = ParserGenerator()
    parser_generator_2.make_dfa(n_f_a_state_0, n_f_a_state_1)


# Generated at 2022-06-25 15:06:32.864086
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    n_f_a_state_1 = NFAState()
    n_f_a_state_2 = NFAState()

    n_f_a_state_1.add_transition(NFAState.EPSILON, n_f_a_state_2)
    assert n_f_a_state_1.next[NFAState.EPSILON] == (n_f_a_state_2,)
    n_f_a_state_2.add_transition(NFAState.EPSILON, n_f_a_state_1)
    assert n_f_a_state_1.next[NFAState.EPSILON] == (n_f_a_state_2,)
    assert n_f_a_state_2.next[NFAState.EPSILON]