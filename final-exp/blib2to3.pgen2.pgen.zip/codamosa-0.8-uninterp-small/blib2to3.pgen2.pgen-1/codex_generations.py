

# Generated at 2022-06-25 15:00:19.373240
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    parser_generator_0 = ParserGenerator()
    parser_generator_0.addfirstsets()


# Generated at 2022-06-25 15:00:29.344975
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    parser_generator = ParserGenerator()
    # test subcase 0
    n_f_a_state_0 = parser_generator.parse_rhs()
    # test subcase 1
    test_raise_exception = False
    try:
        n_f_a_state_0 = parser_generator.parse_rhs()
    except AttributeError:
        test_raise_exception = True
    if test_raise_exception == False:
        raise AssertionError("No exception was raised")
    # test subcase 2
    test_raise_exception = False
    try:
        n_f_a_state_0 = parser_generator.parse_rhs()
    except AttributeError:
        test_raise_exception = True

# Generated at 2022-06-25 15:00:35.427430
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    start_n_f_a_state_0 = NFAState()
    finish_n_f_a_state_0 = NFAState()
    parser_generator_0 = ParserGenerator()
    name_0 = 'a'
    parser_generator_0.dump_nfa(name_0, start_n_f_a_state_0, finish_n_f_a_state_0)


# Generated at 2022-06-25 15:00:40.333953
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    """Test simplify_dfa."""
    parser_generator_0 = ParserGenerator()
    dfa_0 = [DFAState(None, None)]
    parser_generator_0.simplify_dfa(dfa_0)


# Generated at 2022-06-25 15:00:45.714632
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    start = NFAState()
    finish = NFAState()
    start.addarc(finish)
    lnfa = ParserGenerator()
    lnfa.dump_nfa( "name", start, finish )
    assert isinstance(start, NFAState)


# Generated at 2022-06-25 15:00:55.940806
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    expected = "Dump of NFA for None\n" \
               "  State 0 \n" \
               "    -> 0"
    output_filepath = "expout.txt"
    with open(output_filepath, "w") as output:
        original_stdout = sys.stdout
        sys.stdout = output
        test_case_0()
        sys.stdout = original_stdout

    with open(output_filepath, "r") as output:
        actual = "".join(output.readlines())
    print("Expected:")
    print(expected)
    print("Actual:")
    print(actual)
    assert expected == actual


# Generated at 2022-06-25 15:01:05.599359
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    from . import pgen2_gr
    c = pgen2_gr.GrammarC()

# Generated at 2022-06-25 15:01:16.143997
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    parser_generator_0 = ParserGenerator()
    pgen_grammar_0 = PgenGrammar()
    pgen_grammar_0.symbol2number = {'":="': 0, '"else"': 3, '"if"': 1, '"while"': 2}
    pgen_grammar_0.symbol2label = {'":="': 2, '"else"': 0, '"if"': 1, '"while"': 3}
    assert parser_generator_0.make_label(pgen_grammar_0, '":="') == 2
    assert parser_generator_0.make_label(pgen_grammar_0, '"else"') == 0
    assert parser_generator_0.make_label(pgen_grammar_0, '"if"')

# Generated at 2022-06-25 15:01:27.168355
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    # test case 1
    nfa_state_0 = NFAState()
    nfa_state_1 = NFAState()
    nfa_state_2 = NFAState()
    nfa_state_3 = NFAState()
    nfa_state_0.addarc(nfa_state_1, "Newline")
    nfa_state_1.addarc(nfa_state_2, "int")
    nfa_state_2.addarc(nfa_state_3)
    nfa_state_3.addarc(nfa_state_1, "int")
    nfa_state_3.addarc(nfa_state_3, "Newline")
    nfa_state_3.addarc(nfa_state_3, "*")
    nfa_state_3.addarc

# Generated at 2022-06-25 15:01:28.005149
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    test_case_0()


# Generated at 2022-06-25 15:02:42.395589
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    tup = ('(', 1, 1, 1, '(')
    parser_generator_0 = ParserGenerator('', '')
    parser_generator_0.type = tup[0]
    parser_generator_0.value = tup[1]
    parser_generator_0.begin = tup[2]
    parser_generator_0.end = tup[3]
    parser_generator_0.line = tup[4]
    parser_generator_0.gettoken()
    object_0 = parser_generator_0.parse_item()
    assert isinstance(object_0, tuple) and len(object_0) == 2
    assert isinstance(object_0[0], NFAState)
    assert isinstance(object_0[1], NFAState)

# Unit

# Generated at 2022-06-25 15:02:54.176000
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    # NFAState
    assert n_f_a_state_0

    grammar_0_0 = ParserGenerator.make_grammar(None, "grammar_0_0", "grammar_0_1")
    # PgenGrammar
    assert grammar_0_0

    grammar_0_0_0 = ParserGenerator.make_grammar(None, "grammar_0_0_0", "grammar_0_0_1")
    # PgenGrammar
    assert grammar_0_0_0

    grammar_0_0_0_0 = ParserGenerator.make_grammar(None, "grammar_0_0_0_0", "grammar_0_0_0_1")
    # PgenGrammar
    assert grammar_0_0_0_0

   

# Generated at 2022-06-25 15:02:58.333888
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    parser_generator_0 = ParserGenerator()
    n_f_a_state_0 = NFAState()
    str_arg_0 = "abc"
    parser_generator_0.dump_nfa(str_arg_0, n_f_a_state_0, n_f_a_state_0)

# Generated at 2022-06-25 15:03:03.437165
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    parser_generator_0 = ParserGenerator()
    pgen_gennerator_0 = PgenGrammar()
    label = "<>"
    assert parser_generator_0.make_label(pgen_gennerator_0, label) == 1


# Generated at 2022-06-25 15:03:13.153696
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    nfa_0 = NFAState()
    nfa_1 = NFAState()
    nfa_2 = NFAState()
    nfa_3 = NFAState()
    nfa_4 = NFAState()
    nfa_5 = NFAState()
    nfa_6 = NFAState()
    nfa_7 = NFAState()
    nfa_8 = NFAState()
    nfa_9 = NFAState()
    nfa_10 = NFAState()
    nfa_11 = NFAState()
    nfa_12 = NFAState()
    nfa_13 = NFAState()
    nfa_14 = NFAState()
    nfa_15 = NFAState()
    nfa_16 = NFAState()
    nfa_17 = NFAState()
   

# Generated at 2022-06-25 15:03:15.037350
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    c = ParserGenerator("Grammar.txt")
    a, z = c.parse_atom("(")


# Generated at 2022-06-25 15:03:20.649537
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    filename = inspect.getfile(ParserGenerator)
    p_g_0 = ParserGenerator(filename)
    # Failure should raise an exception
    with pytest.raises(AssertionError) as excinfo:
        p_g_0.dump_dfa("__name__", "__dfa__")
    # Unit test of function dump_dfa
    p_g_1 = ParserGenerator(filename)
    p_g_1.dump_dfa("__name__", "__dfa__")
    # Unit test of function addarc
    p_g_2 = ParserGenerator(filename)
    p_g_2.addarc(n_f_a_state_0, n_f_a_state_0)


# Generated at 2022-06-25 15:03:25.641841
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    n_f_a_state_0 = NFAState()
    n_f_a_state_1 = NFAState()
    n_f_a_state_0.addarc(n_f_a_state_1, "(")
    n_f_a_state_0.addarc(n_f_a_state_1, ")")
    n_f_a_state_0.addarc(n_f_a_state_1, None)
    n_f_a_state_2 = NFAState()
    n_f_a_state_3 = NFAState()
    n_f_a_state_2.addarc(n_f_a_state_3, "|")

# Generated at 2022-06-25 15:03:35.728221
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    n_f_a_state_0 = NFAState()
    n_f_a_state_1 = NFAState()
    n_f_a_state_2 = NFAState()
    n_f_a_state_3 = NFAState()
    n_f_a_state_0.addarc(n_f_a_state_1)
    n_f_a_state_1.addarc(n_f_a_state_2)
    n_f_a_state_2.addarc(n_f_a_state_3)
    assert n_f_a_state_0.arcs == {(None, n_f_a_state_1),}

# Generated at 2022-06-25 15:03:40.174857
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    try:
        ParserGenerator().simplify_dfa([])
    except RuntimeError:
        print("  RuntimeError")
    try:
        ParserGenerator().simplify_dfa([n_f_a_state_0])
    except RuntimeError:
        print("  RuntimeError")


# Generated at 2022-06-25 15:05:22.690761
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    assert PgenGrammar() == PgenGrammar()



# Generated at 2022-06-25 15:05:24.887775
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    g_rammar_0 = ParserGenerator()
    g_rammar_0.parse_item()  # Expected NoReturn


# Generated at 2022-06-25 15:05:31.273202
# Unit test for method make_label of class ParserGenerator

# Generated at 2022-06-25 15:05:37.110933
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    # Define objects and variables
    parser_generator_0 = ParserGenerator()
    msg_0 = "expected %s/%s, got %s/%s"
    # Call test method
    parser_generator_0.raise_error(
        msg_0,
        token.NEWLINE,
        ":",
        token.NAME,
        "s",
        filename="grammar.txt",
        end=(1, 0, "s"),
    )


# Generated at 2022-06-25 15:05:38.914014
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    v_grammar = ParserGenerator().make_grammar("")
    assert True


# Generated at 2022-06-25 15:05:49.019347
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    n_f_a_state_0 = NFAState()
    n_f_a_state_1 = NFAState()
    n_f_a_state_0.addarc(n_f_a_state_1, 'NAME')

    n_f_a_state_2 = NFAState()
    n_f_a_state_2.addarc(n_f_a_state_0)
    n_f_a_state_2.addarc(n_f_a_state_1)

    n_f_a_state_3 = NFAState()
    n_f_a_state_3.addarc(n_f_a_state_2, 'NAME')


# Generated at 2022-06-25 15:05:53.491155
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    parser_generator_0 = ParserGenerator("", StringIO(""))
    parser_generator_0.lexer()
    try:
        parser_generator_0.parse_alt()
    except:
        # raise AssertionError("Expected no exception")
        pass


# Generated at 2022-06-25 15:06:03.779368
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    pgen_grammar_0 = PgenGrammar()
    n_f_a_state_1 = NFAState()
    n_f_a_state_1.arcs = [
        (None, n_f_a_state_0),
        ("|", n_f_a_state_0),
        (None, n_f_a_state_0),
        ("|", n_f_a_state_0),
        (None, n_f_a_state_0),
        ("|", n_f_a_state_0),
    ]
    n_f_a_state_1.addarc(n_f_a_state_0)
    n_f_a_state_0.addarc(n_f_a_state_1)
    assert pgen_grammar_

# Generated at 2022-06-25 15:06:06.192013
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    parser_generator_0 = ParserGenerator()
    n_f_a_state_0, n_f_a_state_1 = parser_generator_0.parse_rhs()


# Generated at 2022-06-25 15:06:13.040754
# Unit test for function generate_grammar
def test_generate_grammar():
    import sys
    import os
    import io
    from Grammar import Grammar

    # Create a dummy file to hold a grammar specification that can
    # be parsed by the pgen parser generator.
    lines = [
        "a: 'a'",
        "b: 'b'",
        "aa: a a",
        "aaaa: aa aa",
        "bb: b b",
        "abba: a bb b a",
    ]
    filename = "gen_grammar.txt"
    f = open(filename, "w")
    for line in lines:
        f.write(line)
        f.write(os.linesep)
    f.close()

    # Generate a pgen grammar from the specification.
    grammar = generate_grammar(filename)

    # Save the grammar to a file.
   

# Generated at 2022-06-25 15:07:18.667619
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    # The code in the body of the test case should throw an exception
    # when a test fails; use this to count failures.  You may need to
    # redefine this function or write your own depending on how you
    # implement your tests.
    failures = 0

    # Create an instance of ParserGenerator
    parser_generator_0 = ParserGenerator()

    # Call the method with arguments: name
    try:
        parser_generator_0.calcfirst("name")
    except SystemExit as e:
        # Catch sys.exit() calls, which are used to abort the test.
        # The argument to sys.exit() is an integer status code.
        # Return that code (0 for success, anything else for failure).
        return e.code

# Generated at 2022-06-25 15:07:19.289730
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    grammar = ParserGenerator('').parse()

# Generated at 2022-06-25 15:07:20.104249
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    pass


# Generated at 2022-06-25 15:07:29.143319
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    n_f_a_state_0 = NFAState()
    n_f_a_state_1 = NFAState()
    n_f_a_state_2 = NFAState()
    n_f_a_state_0.addarc(n_f_a_state_1, None)
    n_f_a_state_1.addarc(n_f_a_state_2, None)
    assert isinstance(n_f_a_state_0, NFAState)
    assert isinstance(n_f_a_state_1, NFAState)
    assert isinstance(n_f_a_state_2, NFAState)
    n_f_a_state_0.addarc(n_f_a_state_2, None)
    assert n_f_a_state_

# Generated at 2022-06-25 15:07:30.130778
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    parser = ParserGenerator()
    a, z = parser.parse_rhs()


# Generated at 2022-06-25 15:07:39.009858
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    class Foo:
        def __init__(self, i: int, j: int) -> None:
            self.i = i
            self.j = j

        def __eq__(self, other) -> bool:
            if not isinstance(other, Foo):
                return NotImplemented
            return self.i == other.i and self.j == other.j

    class Bar:
        def __init__(self) -> None:
            pass

        def __eq__(self, other) -> bool:
            return isinstance(other, Bar)
    bar = Bar()
    p = ParserGenerator("foo")
    assert p.dump_dfa("baz", [Foo(1, 2), bar]) is None

# Generated at 2022-06-25 15:07:45.606742
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    lines = ['def foo():', '    if x:', '        y', '    else:', '        z']
    lines2 = ['if x: y']
    pg = ParserGenerator()
    # syntax error in rhs
    with pytest.raises(ValueError) as excinfo:
        pg.parse("x: foo | bar | baz")
    assert "recursion for rule 'x'" in str(excinfo.value)
    # simple indentation

# Generated at 2022-06-25 15:07:55.528591
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    n_f_a_state_1 = NFAState()
    n_f_a_state_2 = NFAState()
    n_f_a_state_1.arcs.append((None, n_f_a_state_2))
    n_f_a_state_1.arcs.append(("a", n_f_a_state_2))
    n_f_a_state_3 = NFAState()
    n_f_a_state_4 = NFAState()
    n_f_a_state_3.arcs.append((None, n_f_a_state_4))
    n_f_a_state_3.arcs.append(("b", n_f_a_state_4))
    n_f_a_state_5 = NFAState()
   

# Generated at 2022-06-25 15:08:03.987209
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    from . import parser
    grammar.symbol2number = {}
    grammar.number2symbol = {}
    for name in grammar.symbol2label.keys():
        grammar.symbol2number[name] = len(grammar.symbol2number)
        grammar.number2symbol[len(grammar.symbol2number)-1] = name

    pg = ParserGenerator(parser.tokenize) # type: ignore
    pg.calcfirst("_ts")
    pg.calcfirst("AND_expr")
    pg.calcfirst("ATOM")
    pg.calcfirst("arglist")
    pg.calcfirst("argument")
    pg.calcfirst("arguments")
    pg.calcfirst("assert_stmt")
    pg.calcfirst("assign")
    pg.calcfirst

# Generated at 2022-06-25 15:08:04.931023
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    n_f_a_state_0 = NFAState()

