

# Generated at 2022-06-25 15:00:31.255231
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    c_0 = PgenGrammar(0, 'a', [], [], ['a', 'b'], {}, {'a': 0, 'b': 1}, {}, {'a': 0, 'b': 1}, {0: {}, 1: {'a': 1}}, None)
    ParserGenerator.make_first(c_0, 'a')
    ParserGenerator.make_first(c_0, 'b')


# Generated at 2022-06-25 15:00:41.029610
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    # Test failure of type assertion
    with pytest.raises(AssertionError):
        parser_generator = ParserGenerator()
        start = NFAState()
        finish = NFAState()
        name = ""
        parser_generator.dump_nfa(name, start, finish)
    # Test successful completion of dump_nfa
    parser_generator = ParserGenerator()
    start = NFAState()
    finish = NFAState()
    name = ""
    parser_generator.dump_nfa(name, start, finish)



# Generated at 2022-06-25 15:00:53.773895
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    __tracebackhide__ = True
    n_f_a_state_0 = NFAState()
    n_f_a_state_1 = NFAState()
    n_f_a_state_2 = NFAState()
    n_f_a_state_3 = NFAState()
    n_f_a_state_4 = NFAState()
    n_f_a_state_5 = NFAState()
    n_f_a_state_6 = NFAState()
    n_f_a_state_0.addarc(n_f_a_state_1, "a")
    n_f_a_state_0.addarc(n_f_a_state_2, "b")

# Generated at 2022-06-25 15:01:03.789611
# Unit test for method parse of class ParserGenerator

# Generated at 2022-06-25 15:01:06.976874
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    case_0 = ParserGenerator("")
    test_case_0()


# Generated at 2022-06-25 15:01:09.895038
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    parser_generator_0 = ParserGenerator()
    parser_generator_0.dump_nfa("name", "start", "finish")


# Generated at 2022-06-25 15:01:10.734114
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    pass


# Generated at 2022-06-25 15:01:16.412145
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    pgenparser = ParserGenerator()
    test_str = "a"
    test_str = test_str.encode()
    test_str = io.BytesIO(test_str)
    pgenparser.filename = "test_ParserGenerator_expect"
    pgenparser.generator = tokenize.generate_tokens(test_str.readline)
    pgenparser.gettoken()
    pgenparser.expect(1)


# Generated at 2022-06-25 15:01:27.245153
# Unit test for method dump_nfa of class ParserGenerator

# Generated at 2022-06-25 15:01:31.375399
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    #
    # Constructor from list of productions
    #

    # Empty grammar
    g = PgenGrammar([], [])
    assert g.start == "file_input"
    assert g.keywords == {}
    assert g.tokens == ["NAME", "NEWLINE", "NUMBER", "STRING", "ENDMARKER"]
    assert g.symbol2number == {}
    assert g.number2symbol == {}
    assert g.dfas == {}
    assert len(g._lr0_item_cache) == 0
    assert len(g._lr0_gotos) == 0
    assert g.lr0_gotos_cache == {}

    # Grammar with a production
    g = PgenGrammar(["file_input: NAME"], [])
    assert g.start == "file_input"


# Generated at 2022-06-25 15:02:01.391935
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():

    # Instantiation of the class to be tested
    p_g_parser_generator = ParserGenerator()

    # Instantiation of the class under test and
    # setting of its attribute type
    p_g_parser_generator.type = token.NAME

    # Invocation of the method to be tested
    value = p_g_parser_generator.expect(token.NAME)

    # Verification of the effects of the method to be tested
    assert value == p_g_parser_generator.value
    assert p_g_parser_generator.type == token.NAME

    try:
        # Invocation of the method to be tested
        p_g_parser_generator.expect(token.NUMBER, '9')
    except:
        pass
    else:
        raise Exception("ValueError expected")

    # Instant

# Generated at 2022-06-25 15:02:03.373914
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    parser_generator_0 = ParserGenerator(None, None)
    parser_generator_0.dump_nfa('Hello', 0, 0)


# Generated at 2022-06-25 15:02:06.140832
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    print("Running test_ParserGenerator_dump_dfa")
    try:
        assert False
    except AssertionError:
        pass
    print("Done test_ParserGenerator_dump_dfa")


# Generated at 2022-06-25 15:02:10.226307
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    generator_0 = ParserGenerator(1, object())
    n_f_a_state_0 = NFAState()
    n_f_a_state_1 = NFAState()
    n_f_a_state_0.addarc(n_f_a_state_1, "(")
    n_f_a_state_2 = n_f_a_state_0
    assert n_f_a_state_2 is n_f_a_state_0
    assert len(n_f_a_state_0.arcs) == 1



# Generated at 2022-06-25 15:02:22.285479
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    NoReturn_0 = None  # type: Optional[Any]
    SyntaxError_0 = None  # type: Optional[Any]
    token_0 = None  # type: Optional[Any]
    tokenize_0 = None  # type: Optional[Any]
    tuple_0 = None  # type: Optional[Any]

    class PgenGrammar_0(object):
        def __init__(self, *args: Any) -> None:
            pass

    pgen_grammar_0 = PgenGrammar_0()
    parser_generator_0 = ParserGenerator(pgen_grammar_0, pgen_grammar_0, pgen_grammar_0, pgen_grammar_0, pgen_grammar_0)

# Generated at 2022-06-25 15:02:25.393228
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    # NOTE: The following is an extract from a test of the original source
    # The original source test did not have an explicit assertion
    parser_generator_0 = ParserGenerator()
    #parser_generator_0.parse_alt()


# Generated at 2022-06-25 15:02:33.102122
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    # Set up
    class TestDot:
        def __init__(self, value_list):
            self.value_list = value_list
        def __call__(self, *args):
            return self.value_list.pop(0)
    dot = TestDot((0, 1))
    test_parser_generator = ParserGenerator()
    test_parser_generator.generator = dot

    # Testing
    assert test_parser_generator.gettoken() is None
    assert test_parser_generator.generator.value_list == []
    assert test_parser_generator.type == 0
    assert test_parser_generator.value == 1


# Generated at 2022-06-25 15:02:41.394268
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    parser_generator_0 = ParserGenerator(tokenize.generate_tokens(BytesIO(b"").readline))
    n_f_a_state_0 = NFAState()
    n_f_a_state_1 = NFAState()
    tuple_0 = (n_f_a_state_0, n_f_a_state_1)
    d_f_a_state_0 = DFAState(tuple_0)
    d_f_a_state_1 = DFAState(tuple_0)
    d_f_a_state_2 = DFAState(tuple_0)
    list_0 = []
    d_f_a_state_3 = DFAState(tuple_0)
    list_1 = []
    d_f_a_state_

# Generated at 2022-06-25 15:02:53.409007
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    parser_generator_0 = ParserGenerator(None)
    parser_generator_0.type = 2
    parser_generator_0.line = "(1, 6)"
    parser_generator_0.parser_generator_gettoken()
    parser_generator_0.type = 2
    parser_generator_0.line = "(2, 6)"
    parser_generator_0.parser_generator_gettoken()
    parser_generator_0.type = 2
    parser_generator_0.line = "(1, 2)"
    parser_generator_0.parser_generator_gettoken()
    # Initialization of object NFAState
    n_f_a_state_0 = NFAState()
    # Initialization of object NFAState
    n_f_a_state_1 = N

# Generated at 2022-06-25 15:03:01.056852
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    n_f_a_state_0 = NFAState()
    n_f_a_state_1 = NFAState()
    dfa_state_0 = DFAState(n_f_a_state_0, n_f_a_state_1)
    dfa_state_0.addarc(dfa_state_0, "v0")
    dfa_state_1 = DFAState(n_f_a_state_1, n_f_a_state_0)
    dfa_state_1.addarc(dfa_state_1, "v1")
    dfa_state_1.addarc(dfa_state_0, "v2")
    dfa_state_2 = DFAState(n_f_a_state_0, n_f_a_state_0)

# Generated at 2022-06-25 15:03:49.874050
# Unit test for method make_first of class ParserGenerator

# Generated at 2022-06-25 15:03:52.689029
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    # inputs
    arg0 = str()
    arg1 = int()
    arg2 = int()
    arg3 = str()

    # invocation
    ret = ParserGenerator.parse(arg0, arg1, arg2, arg3)


# Generated at 2022-06-25 15:03:59.168880
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    c_0 = PgenGrammar()
    label_0 = "["
    label_0 = "["
    test_ParserGenerator_make_label_0 = c_0.make_label(c_0, label_0)
    number_0 = 0
    test_ParserGenerator_make_label_0 = test_ParserGenerator_make_label_0 == number_0
    label_0 = "NAME"
    label_0 = "NAME"
    test_ParserGenerator_make_label_1 = c_0.make_label(c_0, label_0)
    number_0 = 1
    test_ParserGenerator_make_label_1 = test_ParserGenerator_make_label_1 == number_0
    label_0 = "STRING"
    label_0 = "STRING"
   

# Generated at 2022-06-25 15:04:01.769596
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    parser_generator_0 = ParserGenerator(None, None)
    parser_generator_0.parse_alt()



# Generated at 2022-06-25 15:04:07.698363
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    """Test method expect of class ParserGenerator"""


if __name__ == "__main__":
    import sys

    def main():
        # fn = 'C:\\Users\\Dinesh\\Anaconda3\\lib\\difflib.py'
        # fn = '/usr/lib/python3.7/tokenize.py'
        fn = sys.argv[1]
        print("Parsing", fn)
        pg = ParserGenerator()
        with open(fn, "rb") as f:
            pg.parse_file(f)
        conv = Converter(pg.dfas, pg.first, pg.startsymbol)
        symbols = sorted(conv.symbol2number.keys())
        for symbol in symbols:
            name = "pgen_%s" % symbol

# Generated at 2022-06-25 15:04:13.126433
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    r"""
    parser_generate.ParserGenerator.parse()
    """
    if __debug__:
        pytest.skip("incomplete test")

    # Test a simplistic grammar of two values, one of them a string
    # and the other a list consisting of two subvalues.
    s = """
    start: 'value'
    value: string | list
    string: NAME
    list: '['(string | list)*']'
    """
    grammar = compile(s, '<string>', 'exec')
    for name in dir(grammar):
        value = getattr(grammar, name)
        if isinstance(value, int):
            token_names[value] = name
    ParserGenerator(s, 'start', 'grammar')



# Generated at 2022-06-25 15:04:14.878394
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    def f(c: PgenGrammar, name: Text) -> None:
        pass
    parsergen = ParserGenerator(token.tok_name)
    parsergen.make_first = f
    del f


# Generated at 2022-06-25 15:04:16.293950
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    assert isinstance(ParserGenerator.gettoken.__doc__, str)


# Generated at 2022-06-25 15:04:22.219637
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():

    # Test case 0
    # Test for class method ParserGenerator.make_label
    # Test for case where there are no rules
    # Constructor for test case 0
    # Creates the following grammar: {}
    def test_case_0_make_label():
        cases = {}
        obj = ParserGenerator(cases)


# Generated at 2022-06-25 15:04:28.992440
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    test_pg = ParserGenerator()
    names = ["expr", "exprlist", "exprlist_cont"]
    for name in names:
        try:
            dfa = test_pg.dfas[name]
            test_pg.calcfirst(name)
            assert test_pg.first[name] is not None
            continue
        except ValueError:
            pass
    print("test_ParserGenerator_calcfirst() passed")


# Generated at 2022-06-25 15:06:14.083178
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    c_0 = ParserGenerator()
    l_0 = "-="
    l_0_0 = c_0.make_label(c_0, l_0)

if __name__ == "__main__":
    parser = ParserGenerator()
    print(parser.get_source())

# Generated at 2022-06-25 15:06:16.115566
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    case_0 = ParserGenerator("")
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 15:06:26.273473
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    # Setup
    n_f_a_state_0 = NFAState()
    n_f_a_state_1 = NFAState()
    tuple_0 = (n_f_a_state_0, n_f_a_state_1)
    str_0 = "("
    str_1 = ")"
    str_2 = "NAME"
    str_3 = "STRING"
    expected_0 = (n_f_a_state_0, n_f_a_state_1)
    expected_1 = (n_f_a_state_0, n_f_a_state_1)
    expected_2 = (n_f_a_state_0, n_f_a_state_1)

    # Testing with stg. that calls raise_error
    # Testing with stg.

# Generated at 2022-06-25 15:06:30.789331
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    p_g_0 = ParserGenerator()
    d_f_a_state_0 = DFAState()
    d_f_a_state_0.nfaset = {
    }
    d_f_a_state_0.arcs = {
        'x': d_f_a_state_0
    }
    p_g_0.simplify_dfa([d_f_a_state_0])


# Generated at 2022-06-25 15:06:31.844093
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    number_0 = ParserGenerator(None, None, None)



# Generated at 2022-06-25 15:06:39.853042
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    line_1 = (None, '"x"')
    line_2 = (None, '"y"')
    lines_0 = ((line_1, 'x'), (line_2, 'y'))
    tuple_0 = (lines_0, 'x')
    dfas, startsymbol = ParserGenerator.parse(tuple_0)
    assert dfas == {'x': [DFAState({}, None), DFAState({}, None)], 'y': [DFAState({}, None), DFAState({}, None)]}
    assert startsymbol == 'x'


# Generated at 2022-06-25 15:06:41.723270
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    # parser_generator_0 = ParserGenerator.__new__(ParserGenerator)
    test_case_0()

# Generated at 2022-06-25 15:06:50.971280
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    # Test precondition: n_f_a_state_0._arcs is empty
    n_f_a_state_0 = NFAState()
    tuple_0 = (n_f_a_state_0, n_f_a_state_0)
    lst = [NFAState(), NFAState(), NFAState(), NFAState(), NFAState()]
    for state in lst:
        if not state._arcs:
            break
    else:
        assert False, 'Precondition is false: not (state._arcs is empty)'
    # Test precondition: n_f_a_state_2._arcs is empty
    n_f_a_state_2 = NFAState()

# Generated at 2022-06-25 15:06:59.087128
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    nfa_states, start_symbol = ParserGenerator(
        tokenize.generate_tokens(io.StringIO("").readline), "<string>"
    ).parse()
    dfa_0 = ParserGenerator.make_dfa(nfa_states, start_symbol)
    # print(dfa_0)
    # nfa_states_0, start_symbol_0 = ParserGenerator(
    #     tokenize.generate_tokens(io.StringIO("").readline), "<string>"
    # ).parse()


# Generated at 2022-06-25 15:07:01.122524
# Unit test for function generate_grammar
def test_generate_grammar():
    assert generate_grammar() is not None


if __name__ == "__main__":
    BASE = Path(__file__).parent.parent
    grammar = generate_grammar(BASE / "Grammar.txt")
    with open(BASE / "Parser/pgen.py", "w") as outfile:
        grammar.dump(outfile)