

# Generated at 2022-06-25 15:00:24.146181
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    f = open(NFA.txt, 'r')
    str_0 = f.read()
    parser_generator_0 = ParserGenerator(str_0)

    tuple_0 = parser_generator_0.parse()
    assert tuple_0[0] != None
    assert tuple_0[1] != None
    f.close()


if __name__ == "__main__":
    test_case_0()
    # test_ParserGenerator_parse()
    print("Completed Successfully")

# Generated at 2022-06-25 15:00:27.571200
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    str_0 = 'Y__l>>E\x0c_n-'
    parser_generator_0 = ParserGenerator(str_0)
    tuple_0 = parser_generator_0.parse_rhs()


# Generated at 2022-06-25 15:00:29.219280
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    str_0 = 'Y__l>>E\x0c_n-'
    parser_generator_0 = ParserGenerator(str_0)


# Generated at 2022-06-25 15:00:35.247287
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    # Test type error for msg
    try:
        ParserGenerator('Y__l>>E\x0c_n-').raise_error(False)
        raise RuntimeError
    except TypeError:
        pass
    # Test incorrect value for msg
    try:
        ParserGenerator('Y__l>>E\x0c_n-').raise_error('')
        raise RuntimeError
    except TypeError:
        pass

# Generated at 2022-06-25 15:00:48.407170
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    parser_generator_0 = ParserGenerator('')
    parser_generator_0.make_dfa = MagicMock()
    parser_generator_0.simplify_dfa = MagicMock()
    parser_generator_0.make_first = MagicMock()
    parser_generator_0.make_label = MagicMock()
    parser_generator_0.make_grammar()
    assert parser_generator_0.make_dfa.call_count == len(parser_generator_0.dfas.keys())
    assert parser_generator_0.simplify_dfa.call_count == len(parser_generator_0.dfas.keys())
    n_make_first = len(parser_generator_0.dfas.keys())

# Generated at 2022-06-25 15:00:51.381999
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    string_0 = 'NAME+'
    parser_generator_0 = ParserGenerator(string_0)
    parser_generator_0.parse_alt()


# Generated at 2022-06-25 15:00:56.915008
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    # Test with correct argument
    try:
        str_1 = 'Y__l>>E\x0c_n-'
        parser_generator_1 = ParserGenerator(str_1)
        tuple_1 = parser_generator_1.raise_error('expect %s', 'result')
    except SyntaxError:
        assert True


# Generated at 2022-06-25 15:01:01.412007
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    str_0 = 'F\x1e\x14\x11;'
    parser_generator_0 = ParserGenerator(str_0)
    _, str_1 = parser_generator_0.parse_rhs()
    assert str_1 == 'F\x1e\x14\x11;'


# Generated at 2022-06-25 15:01:05.227611
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    string_0 = 'H(_\\\x14\x0fI'
    parser_generator_0 = ParserGenerator(string_0)
    test_tuple_0 = parser_generator_0.parse_rhs()


# Generated at 2022-06-25 15:01:08.732217
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    str_0 = 'G'
    parser_generator_0 = ParserGenerator(str_0)
    parser_generator_0.type = token.NEWLINE
    tuple_0 = parser_generator_0.parse_alt()


# Generated at 2022-06-25 15:02:00.825550
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    str_0 = 'r'
    pgen = ParserGenerator(str_0)
    pgen.gettoken()
    assert pgen.type == 1
    assert pgen.value == 'r'
    assert pgen.begin == (1, 0)
    assert pgen.end == (1, 1)
    assert pgen.line == 'r\n'


# Generated at 2022-06-25 15:02:08.682548
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():

    # Setup
    pg = ParserGenerator()

    # Testing
    with pytest.raises(NameError):
        pg.expect(None, None)

    pg.gettoken()
    pg.gettoken()
    pg.gettoken()
    assert pg.expect(NAME) == 'foo'
    assert pg.expect(OP, ':') == ':'
    assert pg.expect(NAME) == 'bar'
    assert pg.expect(NEWLINE) == '\n'

    pg.gettoken()
    assert pg.expect(NAME) == 'baz'
    assert pg.expect(OP, ':') == ':'
    assert pg.expect(NAME) == 'bar'
    assert pg.expect(OP, '|') == '|'
    assert pg.expect(NAME)

# Generated at 2022-06-25 15:02:09.441283
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    str_0 = 'r'
    pass


# Generated at 2022-06-25 15:02:10.103195
# Unit test for method calcfirst of class ParserGenerator

# Generated at 2022-06-25 15:02:19.137417
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    str_0 = ',bar: bar bar | bar\n,'
    t = ParserGenerator(str_0, 'test')
    str_1 = '[: import_as_name : DOT NAME\n]'
    t_0 = ParserGenerator(str_1, 'test')
    t_1 = t_0.make_dfa(t_0.dfas['import_as_name'][0], t_0.dfas['import_as_name'][-1])
    t.simplify_dfa(t_1)


# Generated at 2022-06-25 15:02:29.724205
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    str_0 = 'r'
    parser = ParserGenerator(str_0)
    str_1 = 'a'
    list_0 = [DFAState(set_0, 'a') for set_0 in [{'a'}, {'a'}]]
    parser.dump_dfa(str_1, list_0)
    str_2 = 'a'
    list_1 = [DFAState(set_1, 'b') for set_1 in [{'b'}, {'b'}]]
    parser.dump_dfa(str_2, list_1)
    str_3 = 'a'
    list_2 = [DFAState(set_2, 'b') for set_2 in [{'b'}, {'b'}]]

# Generated at 2022-06-25 15:02:36.901636
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    pg = ParserGenerator()
    str_0 = 'r'
    str_1 = '['
    int_2 = 2
    # Normal case
    try:
        pg.expect(str_0, str_1)

    # Clean up
    finally:
        pass

    # Normal case
    try:
        pg.expect(str_0, int_2)

    # Clean up
    finally:
        pass


# Generated at 2022-06-25 15:02:38.556160
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    str_0 = 'r'
    pgen_grammar_0 = PgenGrammar(str_0)


# Generated at 2022-06-25 15:02:39.369975
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    # Put your code here
    pass


# Generated at 2022-06-25 15:02:45.113104
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    str_0 = 'r'
    str_1 = 'r'
    str_2 = 'r'
    str_3 = 'r'
    str_4 = 'r'
    parser_0 = ParserGenerator()
    nfa_state_0 = NFAState()
    nfa_state_1 = NFAState()
    nfa_state_2 = NFAState()
    nfa_state_3 = NFAState()
    nfa_state_4 = NFAState()
    nfa_state_5 = NFAState()
    nfa_state_6 = NFAState()
    nfa_state_7 = NFAState()
    nfa_state_8 = NFAState()
    nfa_state_9 = NFAState()
    nfa_state_10 = NFAState()


# Generated at 2022-06-25 15:03:36.915984
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    src = '\n'
    src += 'def: decorator NEWLINE'
    src += 'decorator: \'@\' dotted_name [\'(\' [arglist] \')\'] NEWLINE'
    src += '        | \'@\' dotted_name NEWLINE [decorator]'
    src += 'dotted_name: NAME (\'.\' NAME)*'
    src += 'arglist: argument (\',\' argument)* [\',\']'
    src += '        | argument \',\' \',\' [\'*\' [\'*\'] NAME [\',\' \'**\' NAME]]'
    src += '        | \'*\' [\'*\'] NAME [\',\' \'**\' NAME]'
    src += '        | \'**\' NAME'
    src += 'argument: test [comp_for] | test \'=\' test'

# Generated at 2022-06-25 15:03:40.316000
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    str_0 = 'Y__l>>E\x0c_n-'
    parser_generator_0 = ParserGenerator(str_0)
    parser_generator_0.expect(token.OP, '+')



# Generated at 2022-06-25 15:03:45.919681
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    str_0 = 'Y__l>>E\x0c_n-'
    parser_generator_0 = ParserGenerator(str_0)
    nfa_state_0 = NFAState()
    nfa_state_1 = NFAState()
    parser_generator_0.dump_nfa("str_0", nfa_state_0, nfa_state_1)


# Generated at 2022-06-25 15:03:52.750899
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    # Test 1: construct PgenGrammar instance
    PgenGrammar_instance = PgenGrammar()

    # Test 2: check PgenGrammar.productions, should be empty
    assert PgenGrammar_instance.productions == {}

    # Test 3: check PgenGrammar.nonterms, should be empty
    assert PgenGrammar_instance.nonterms == set()

    # Test 4: check PgenGrammar.dfas, should be empty
    assert PgenGrammar_instance.dfas == {}

    # Test 5: check PgenGrammar.start, should have value None
    assert PgenGrammar_instance.start == None



# Generated at 2022-06-25 15:03:56.538975
# Unit test for method __eq__ of class DFAState
def test_DFAState___eq__():
    obj = DFAState({NFAState(): None}, NFAState())
    value = obj.__eq__(DFAState({NFAState(): None}, NFAState()))
    print(value)
    assert value == True
    value = obj.__eq__(DFAState({NFAState(): None}, NFAState()))
    print(value)
    assert value == True
    value = obj.__eq__(DFAState({NFAState(): None}, NFAState()))
    print(value)
    assert value == True
    value = obj.__eq__(DFAState({NFAState(): None}, NFAState()))
    print(value)
    assert value == True

# Generated at 2022-06-25 15:04:07.172369
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    str_0 = 'qc\x076*\x0eH'
    str_1 = 'H\x0c\x07\x0b\x0eF\x0b\x0c'
    pgen_grammar_0 = PgenGrammar(str_0, str_1)
    str_2 = 'c\x076*\x0eH'
    str_3 = 'H\x0c\x07\x0b\x0eF\x0b\x0c'
    pgen_grammar_1 = PgenGrammar(str_2, str_3)
    assert pgen_grammar_0 == pgen_grammar_1
    assert pgen_grammar_0 is not pgen_grammar_1


# Generated at 2022-06-25 15:04:13.137638
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    str_0 = 'a: (t\x08\x00\x00\x00\x00\x00\x00\x00|\x00\x04\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00)\n'
    parser_generator_0 = ParserGenerator(str_0)
    tuple_0 = parser_generator_0.parse_item()
    parser_generator_0.make_grammar()


# Generated at 2022-06-25 15:04:19.436493
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    def func_0(parser_generator_0: ParserGenerator):
        return parser_generator_0.make_grammar()

    parser_generator_0 = ParserGenerator('>\x08', '\x0e')
    pgen_grammar_0 = func_0(parser_generator_0)
    str_0 = pgen_grammar_0.make_grammar()


# Generated at 2022-06-25 15:04:30.567171
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    list_0 = ['', '', '', '', '', '', '', '', '', '', '']
    tuple_0 = (list_0, list_0)
    pgen_grammar_0 = PgenGrammar(tuple_0)

# Generated at 2022-06-25 15:04:32.843578
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    str_0 = '\x17\x03\n'
    parser_generator_0 = ParserGenerator(str_0)
    parser_generator_0.gettoken()
    parser_generator_0.expect(token.STRING, None)


# Generated at 2022-06-25 15:07:43.733430
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    str_0 = 'fIMG\x0e\x04:VC'
    parser_generator_0 = ParserGenerator(str_0)
    tuple_0 = parser_generator_0.parse_rhs()
    # Assert TypeError raised during assignment
    try:
        tuple_1 = parser_generator_0.parse_rhs()
    except TypeError:
        pass
    else:
        raise AssertionError


# Generated at 2022-06-25 15:07:48.697821
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    str_0 = 'BJ\x12"&\x1d\x0es\x1b1'
    parser_generator_0 = ParserGenerator(str_0)
    parser_generator_1 = ParserGenerator(str_0)
    assert parser_generator_0 == parser_generator_1


# Generated at 2022-06-25 15:07:52.381636
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    str_0 = 'Y__l>>E\x0c_n-'
    parser_generator_0 = ParserGenerator(str_0)
    tuple_0 = parser_generator_0.parse()
    assert_equal(tuple_0, (None, None))


# Generated at 2022-06-25 15:07:56.969423
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    str_0 = 'Y__l>>E\x0c_n-'
    parser_generator_0 = ParserGenerator(str_0)
    tuple_0 = parser_generator_0.parse()
    assert tuple_0 == ('Y__l>>E\x0c_n-',)


# Generated at 2022-06-25 15:08:04.944806
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    parser_generator_0 = ParserGenerator('_')
    parser_generator_1 = ParserGenerator('a')
    parser_generator_1_copy = ParserGenerator('a')
    parser_generator_2 = ParserGenerator('A')
    parser_generator_2_copy = ParserGenerator('A')
    parser_generator_3 = ParserGenerator('0')
    parser_generator_3_copy = ParserGenerator('0')
    parser_generator_4 = ParserGenerator('+')
    parser_generator_4_copy = ParserGenerator('+')
    parser_generator_5 = ParserGenerator('"ab"')
    parser_generator_5_copy = ParserGenerator('"ab"')
    parser_generator_6 = Pars

# Generated at 2022-06-25 15:08:09.641093
# Unit test for function generate_grammar
def test_generate_grammar():
    pgen_grammar = generate_grammar()
    # Check the grammar generated by the parser generator
    assert pgen_grammar.startsymbol == "file_input"
    assert pgen_grammar.keywords == {
        'False': 1,
        'None': 2,
        'True': 3,
        'async': 4,
        'await': 5}
    assert len(pgen_grammar.dfas) == 21
    assert len(pgen_grammar.first) == 21
    # Check the dfa for function_def
    function_def_dfa = pgen_grammar.dfas["function_def"]
    assert len(function_def_dfa) == 4
    # Check the arcs of the start state

# Generated at 2022-06-25 15:08:15.129435
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    str_0 = '7I\'H'
    E._S(str_0)
    str_1 = 's\t\\'
    str_2 = '\\E\x0cW9'
    # Unit test for method make_first of class ParserGenerator
    def test_ParserGenerator_make_first():
        str_0 = '7I\'H'
        E._S(str_0)
        str_1 = 's\t\\'
        str_2 = '\\E\x0cW9'


# Generated at 2022-06-25 15:08:25.123666
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    str_0 = '\n    def test_case_1():\n        str_0 = \'p: "(" k:p ")" \'\n        parser_generator_0 = ParserGenerator(str_0)\n        tuple_0 = parser_generator_0.parse_item()\n        assert isinstance(tuple_0,tuple)\n        str_1 = \'p: "(" p ")" \'\n        parser_generator_1 = ParserGenerator(str_1)\n        tuple_1 = parser_generator_1.parse_item()\n        assert isinstance(tuple_1,tuple)'
    parser_generator_0 = ParserGenerator(str_0)
    tuple_0 = parser_generator_0.parse_item()

# Generated at 2022-06-25 15:08:27.227796
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    str_0 = ''
    parser_generator_0 = ParserGenerator(str_0)
    assert (parser_generator_0.make_dfa(0, 1) == 1) is not True


# Generated at 2022-06-25 15:08:30.149510
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    str_0 = 'Y__l>>E\x0c_n-'
    parser_generator_0 = ParserGenerator(str_0)
    tuple_0 = parser_generator_0.parse_rhs()
    return parser_generator_0
