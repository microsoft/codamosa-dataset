

# Generated at 2022-06-25 15:01:03.467322
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    test_case_0()


# Generated at 2022-06-25 15:01:05.462167
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    # Create dummy input
    parser_generator = ParserGenerator()
    parser_generator.parse_item()


# Generated at 2022-06-25 15:01:07.700041
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():

    # create instance
    test_obj = ParserGenerator()

    # call method
    test_obj.parse_atom()

    # verify
    assert True


# Generated at 2022-06-25 15:01:12.012370
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    # Create a dummy grammar
    p = ParserGenerator()
    c = PgenGrammar()
    parser = Parser("test_case_0_make_label", p)
    p.make_label(c, '"+"')



# Generated at 2022-06-25 15:01:23.071797
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    a = NFAState()
    b = NFAState()
    c = NFAState()
    d = NFAState()
    e = NFAState()
    f = NFAState()
    g = NFAState()
    h = NFAState()
    i = NFAState()
    j = NFAState()
    k = NFAState()
    l = NFAState()
    m = NFAState()
    n = NFAState()
    o = NFAState()
    p = NFAState()
    q = NFAState()
    r = NFAState()
    s = NFAState()
    t = NFAState()
    u = NFAState()
    v = NFAState()
    w = NFAState()
    x = NFAState()
    y = NFAState()

# Generated at 2022-06-25 15:01:30.793830
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    parser_generator_0 = ParserGenerator()
    parser_generator_0.nfa_stats.append(NFAState())
    parser_generator_0.nfa_stats.append(NFAState())
    parser_generator_0.addfirstsets()

if __name__ == "__main__":
    import sys
    if len(sys.argv) == 1:
        sys.argv.append("Lib/test/grammar.txt")
    filename = sys.argv[1]
    print("Parsing", filename)
    header, dfas, startsymbol = parse_grammar(filename, "single")
    print("Header is", header)
    print("Start symbol is", startsymbol)
    for name, dfa in dfas.items():
        print(name)

# Generated at 2022-06-25 15:01:38.841396
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    n_f_a_state_0 = NFAState()
    n_f_a_state_1 = NFAState()
    n_f_a_state_2 = NFAState()
    n_f_a_state_3 = NFAState()
    n_f_a_state_4 = NFAState()
    n_f_a_state_5 = NFAState()
    n_f_a_state_6 = NFAState()
    n_f_a_state_7 = NFAState()
    n_f_a_state_8 = NFAState()
    n_f_a_state_9 = NFAState()
    n_f_a_state_10 = NFAState()
    n_f_a_state_11 = NFAState()
    n_f_a_

# Generated at 2022-06-25 15:01:47.919694
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    n_f_a_state_0 = NFAState()
    n_f_a_state_1 = NFAState()
    n_f_a_state_2 = NFAState()
    n_f_a_state_3 = NFAState()
    n_f_a_state_3.arcs = []
    n_f_a_state_3.arcs.append((None, n_f_a_state_1))
    n_f_a_state_4 = NFAState()
    n_f_a_state_4.arcs = []
    n_f_a_state_4.arcs.append((None, n_f_a_state_2))

# Generated at 2022-06-25 15:01:57.843448
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    # Test method simplify_dfa of class ParserGenerator

    # Case 0, simplify_dfa: i = j = 0, unify states 0 and 1, remove state 1
    # Other simplifications possible
    #
    #  State 0
    #    name -> 0
    #    number -> 0
    #    string -> 0
    #  State 1
    #    name -> 0
    #    number -> 0
    #    string -> 0
    #
    s = ParserGenerator()
    n_f_a_state_0 = NFAState()
    n_f_a_state_1 = NFAState()
    n_f_a_state_0.addarc(n_f_a_state_1, "name")

# Generated at 2022-06-25 15:02:02.084719
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    n_f_a_state_0 = NFAState()
    n_f_a_state_1 = NFAState()
    d_f_a_state_0 = DFAState(n_f_a_state_0, n_f_a_state_1)
    d_f_a_state_1 = DFAState(n_f_a_state_0, n_f_a_state_1)
    d_f_a_state_0.addarc(d_f_a_state_1)
    d_f_a_state_1.addarc(d_f_a_state_0)
    d_f_a_state_2 = DFAState(n_f_a_state_0, n_f_a_state_1)
    d_f_a_state_

# Generated at 2022-06-25 15:03:02.134821
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    # Verify that method simplify_dfa is able to handle a
    #  DFA that has a cycle that involves multiple states
    #  (via an arc from one state to a second state, and an
    #  arc from the second state back to the first state).
    #
    # The following DFA (from the grammar for Python 'import' statements)
    # has two states, 0 and 1.  It has two arcs, one from state 0 to state 1
    # and another from state 1 back to state 0.
    n_f_a_state_0 = NFAState()
    n_f_a_state_1 = NFAState()
    n_f_a_state_0.addarc(n_f_a_state_1, None)

# Generated at 2022-06-25 15:03:10.223019
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    _g = tokenize.StringIO("'(':\\n")
    _g = tokenize.generate_tokens(_g.readline)
    parser_generator = ParserGenerator("test_case_0.py", _g)

    parser_generator.gettoken();
    try:
        parser_generator.expect(token.OP, "(")
        raise AssertionError("unexpected success")
    except SyntaxError as e:
        assert e.args == ("expected OP/(, got OP/')", ("test_case_0.py", 1, 0, ")"),)


# Generated at 2022-06-25 15:03:16.320678
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    grammar = """
        S : NAME
        """
    parser = ParserGenerator()
    parser.parse_string(grammar)
    dfas, startsymbol = parser.dfas, parser.startsymbol
    assert startsymbol == "S"
    assert len(dfas["S"]) == 1
    assert list(dfas["S"][0].arcs.keys()) == ["NAME"]
    for dfa in dfas.values():
        for state in dfa:
            state.reachable = True
    parser.addfirstsets()
    parser.make_labels()


# Generated at 2022-06-25 15:03:20.323489
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    pgen_grammar_0 = ParserGenerator()
    symbol_2_number_0 = {}
    label_0 = pgen_grammar_0.make_first(pgen_grammar_0, symbol_2_number_0)


# Generated at 2022-06-25 15:03:21.917308
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    pg = PgenGrammar()


# Generated at 2022-06-25 15:03:25.742574
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    parser_generator_0 = ParserGenerator('test_generate_parsetab.py')
    parser_generator_0.raise_error('expected %s/%s, got %s/%s', token.NAME, None, token.OP, '(')


# Generated at 2022-06-25 15:03:35.795432
# Unit test for method make_grammar of class ParserGenerator

# Generated at 2022-06-25 15:03:45.964906
# Unit test for method calcfirst of class ParserGenerator

# Generated at 2022-06-25 15:03:50.587573
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    global n_f_a_state_0
    d_f_a_state_0.addarc(n_f_a_state_0, None)
    d_f_a_state_1.addarc(n_f_a_state_0, '<')
    d_f_a_state_2.addarc(d_f_a_state_0, 't')
    d_f_a_state_3.addarc(d_f_a_state_0, 't')
    a = NFAState()
    z = NFAState()
    d_f_a_state_0.addarc(a)
    z.addarc(d_f_a_state_0)
    d_f_a_state_1.addarc(a)

# Generated at 2022-06-25 15:03:57.317354
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    # When there are more tokens from the token generate, it should return that token
    parser_generator = ParserGenerator()
    parser_generator.gettoken()
    parser_generator.gettoken()
    parser_generator.gettoken()
    parser_generator.gettoken()
    parser_generator.gettoken()
    parser_generator.gettoken()


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("-o", dest="outputfile")
    parser.add_argument("file")
    args = parser.parse_args()

    f = open(args.file)
    source = f.read()
    f.close()

    c = ParserGenerator()
    c.parse_grammar(source)
   

# Generated at 2022-06-25 15:06:19.270286
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    pg = ParserGenerator()

    def generate():
        for item in (
            (token.NAME, "def", (0, 1), (0, 3), "def "),
            (token.NAME, "function", (0, 4), (0, 11), "function"),
            (token.NEWLINE, "\n", (0, 11), (0, 12), "\n"),
            (token.NEWLINE, "\n", (1, 0), (1, 1), "\n"),
        ):
            yield item

    pg.generator = generate()
    pg.gettoken()
    assert pg.type == token.NAME
    assert pg.value == "def"
    assert pg.begin == (0, 1)
    assert pg.end == (0, 3)
    assert pg.line == "def "
    pg.gettoken()


# Generated at 2022-06-25 15:06:22.109370
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    print("=(1)============================================")
    parser_generator_0 = ParserGenerator()

    print("=(2)============================================")
    grammar_0 = grammar.Grammar(None)
    parser_generator_0.parse_grammar(grammar_0)


# Generated at 2022-06-25 15:06:28.890969
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    print("Begin testing method parse_alt of class ParserGenerator")

    # Test case 0
    print("Test case 0")
    parser_generator_0 = ParserGenerator()
    parser_generator_0.parse_item = ParserGenerator.parse_item.__get__(parser_generator_0)
    parser_generator_0.parse_alt.__func__(parser_generator_0)

    # Test case 1
    print("Test case 1")
    parser_generator_1 = ParserGenerator()
    parser_generator_1.parse_alt.__func__(parser_generator_1)

    # Test case 2
    print("Test case 2")
    parser_generator_2 = ParserGenerator()
    parser_generator_2.parse_rhs = ParserGenerator

# Generated at 2022-06-25 15:06:31.844163
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    p = ParserGenerator("")
    p._token = None
    p._no_more_tokens = False
    p.expected = None
    p.expected_type = None
    p.expected_value = None
    p.had_token = False
    p._check_gettoken()


# Generated at 2022-06-25 15:06:37.818879
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    n_f_a_state_0 = NFAState()
    n_f_a_state_1 = NFAState()

    n_f_a_state_2 = NFAState()
    n_f_a_state_3 = NFAState()
    n_f_a_state_4 = NFAState()
    n_f_a_state_5 = NFAState()

    p_gen_converter_0 = PgenConverter()
    p_gen_converter_0.labels = [(1, None), (2, None)]
    p_gen_converter_0.symbol2number = { "b": 1, "c": 2 }
    p_gen_converter_0.symbol2label = { "b": 0, "c": 1 }

    n_f

# Generated at 2022-06-25 15:06:48.359885
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    begin_line_number = 6
    n_f_a_state_0 = NFAState()
    """State 0 for 'test_ParserGenerator_dump_nfa' at line 6"""
    n_f_a_state_1 = NFAState()
    """State 1 for 'test_ParserGenerator_dump_nfa' at line 7"""
    n_f_a_state_0.addarc(n_f_a_state_1)
    """Arc from state 0 to state 1 for 'test_ParserGenerator_dump_nfa' at line 8"""
    n_f_a_state_0.addarc(n_f_a_state_0, label="a")
    """Arc from state 0 to state 0 for 'test_ParserGenerator_dump_nfa' at line 9"""
    n_f_a

# Generated at 2022-06-25 15:06:58.169480
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    test_case_0()
    s_a_state_0 = DFAState({n_f_a_state_0: 1}, n_f_a_state_0)
    f_a_state_0 = DFAState({n_f_a_state_0: 1}, n_f_a_state_0)
    e_states = [s_a_state_0]
    for s_a_state_1 in e_states:
        arcs = {}
        for n_f_a_state_2 in s_a_state_1.nfaset:
            for label, next in n_f_a_state_2.arcs:
                # if label is not None:
                if label is None:
                    addclosure(next, arcs.setdefault(label, {}))
                else:
                    add

# Generated at 2022-06-25 15:06:59.926280
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    filename = "./test/grammar"
    pg = ParserGenerator()
    pg.read_grammar(filename)
    pg.make_grammar()


# Generated at 2022-06-25 15:07:04.765584
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    p_gen_erator_0 = ParserGenerator()
    n_f_a_state_0, n_f_a_state_1 = p_gen_erator_0.parse_rhs()


# Generated at 2022-06-25 15:07:10.827217
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    pg = ParserGenerator()
    name = "dummy"
    a = NFAState()
    z = NFAState()
    dfa = pg.make_dfa(a, z)
    assert isinstance(a, NFAState)
    assert isinstance(z, NFAState)
    assert isinstance(dfa, list)
    assert len(dfa) > 0
