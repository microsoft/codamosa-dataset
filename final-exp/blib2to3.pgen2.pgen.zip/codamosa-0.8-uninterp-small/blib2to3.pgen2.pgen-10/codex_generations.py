

# Generated at 2022-06-25 15:00:12.428386
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    print('test_ParserGenerator_raise_error...')
    try:
        parser_generator_0 = ParserGenerator()
        str_0 = '%c*9^T#T:F`?'
        parser_generator_0.raise_error(str_0, False, False)
    except:
        pass
    n_f_a_state_0 = NFAState()
    str_0 = 'W8;/=D3>&:Z^0#5]WQbF\\kI'
    try:
        parser_generator_0.raise_error(str_0, n_f_a_state_0, n_f_a_state_0)
    except:
        pass

# Generated at 2022-06-25 15:00:13.344568
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    pass


# Generated at 2022-06-25 15:00:14.886536
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    g = PgenGrammar(str_0, debug)
    print(str_0)



# Generated at 2022-06-25 15:00:26.939213
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    grammar_file_path = './grammar_tests/grammar_test.txt'
    with open(grammar_file_path, 'r') as f:
        string = f.read()

    ParseGrammar = ParserGenerator()
    ParseGrammar.parse_file(file_path=grammar_file_path)
    ParseGrammar.convert()
    # print(ParseGrammar.convert().labels)

    # ParseGrammar.make_label('')
    # print(ParseGrammar)
    # c = ParseGrammar.convert()
    # ParseGrammar.make_first(c,'file_input')
    # print(c.states)

test_case_0()
test_ParserGenerator_make_label()

# Generated at 2022-06-25 15:00:34.584568
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    n_f_a_state_0 = NFAState()
    str_0 = '`$s$0\t$\r7*8M/JAT'
    tuple_0 = (
        n_f_a_state_0,
        '`$s$0\t$\r7*8M/JAT',
        NFAState(),
        )
    n_f_a_state_1 = NFAState()
    dict_0 = {
        (n_f_a_state_1, '`$s$0\t$\r7*8M/JAT'): NFAState(),
        }
    unicode_0 = unicode('`$s$0\t$\r7*8M/JAT')
    int_0 = 1684347444
    dict_1 = dict()


# Generated at 2022-06-25 15:00:46.954234
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    n_f_a_state_0 = NFAState()
    n_f_a_state_1 = NFAState()
    n_f_a_state_2 = NFAState()
    n_f_a_state_3 = NFAState()
    n_f_a_state_4 = NFAState()
    n_f_a_state_5 = NFAState()
    n_f_a_state_6 = NFAState()
    n_f_a_state_7 = NFAState()
    n_f_a_state_8 = NFAState()
    n_f_a_state_9 = NFAState()
    n_f_a_state_10 = NFAState()
    n_f_a_state_11 = NFAState()
    n_f_a_

# Generated at 2022-06-25 15:00:58.866684
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    n_f_a_state_0 = NFAState()
    n_f_a_state_1 = NFAState()
    str_0 = '`$s$0\t$\r7*8M/JAT'
    str_1 = "'"
    list_0 = [str_0] + [str_1]
    str_2 = '['
    str_3 = ']'
    list_1 = [str_2] + [str_3]
    list_2 = [None, None]
    tuple_0 = (token.STRING, str_0)
    tuple_1 = (token.OP, str_1)
    tuple_2 = (token.OP, str_2)
    tuple_3 = (token.OP, str_3)

# Generated at 2022-06-25 15:01:07.612480
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    str_0 = '`$s$0\t$\r7*8M/JAT'
    # Function make_first of class ParserGenerator has type signature:
    #
    #     (self: ParserGenerator, c: PgenGrammar, name: Text) -> Dict[Text, int]

    # XXX Maybe this should be a method on a subclass of converter?
    str_1 = '`$s$0\t$\r7*8M/JAT'
    # Function make_label of class ParserGenerator has type signature:
    #
    #     (self: ParserGenerator, c: PgenGrammar, label: Text) -> int
    n_f_a_state_0 = NFAState()

# Generated at 2022-06-25 15:01:16.196269
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    # Input:
    dfa_to_test = [
        DFAState({
            NFAState(
                [
                    ((None, NFAState()), (None, NFAState()))
                ],
                False
            )
        },
            True
        ),
        DFAState(
            {
                NFAState(
                    [
                        ((None, NFAState()), (None, NFAState()))
                    ],
                    False
                )
            },
            True
        )
    ]

    # Expected output:
    expected_output = [
        DFAState({
            NFAState(
                [
                    ((None, NFAState()), (None, NFAState()))
                ],
                False
            )
        },
            True
        )
    ]

    # Compare the outputs of test and

# Generated at 2022-06-25 15:01:27.245399
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    # gram1.txt, case 0
    # If the docstring of this function is changed,
    # test/test_pgen.py should also get changed.
    print("")
    print("=== Test 0 ===")

# Generated at 2022-06-25 15:02:19.233531
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    n_f_a_state_0 = NFAState()
    str_0 = '`$s$0\t$\r7*8M/JAT'
    n_f_a_state_0.addarc(str_0)
    n_f_a_state_0.addarc(n_f_a_state_0)
    n_f_a_state_0.addarc(str_0)
    n_f_a_state_0.addarc(str_0)
    n_f_a_state_0.addarc(str_0)

    ParserGenerator.dump_nfa('s1', n_f_a_state_0, n_f_a_state_0)


# Generated at 2022-06-25 15:02:29.750397
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    obj_0 = ParserGenerator()
    assert isinstance(obj_0, ParserGenerator)
    # CASE 0:
    parser_gen_0 = ParserGenerator()
    object_0 = object()
    object_1 = object()
    object_2 = object()
    object_3 = object()
    object_4 = object()
    object_5 = object()
    object_6 = object()
    object_7 = object()
    object_8 = object()
    object_9 = object()
    object_10 = object()
    object_11 = object()
    object_12 = object()
    object_13 = object()
    object_14 = object()
    object_15 = object()
    object_16 = object()
    object_17 = object()
    object_18 = object()
    object

# Generated at 2022-06-25 15:02:36.607864
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    first_0 = {'single_input': {'STRING', 'NAME'}}
    print (first_0)
    print(type(first_0))
    for key in first_0:

        #print ("{}", first_0[key])
        value = first_0[key]
        if key == 'single_input':
            print ("yes it is single input")
        print (value)



# Generated at 2022-06-25 15:02:42.074395
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    str_0 = '`$s$0\t$\r7*8M/JAT'
    str_1 = 'T'
    str_2 = 'R'
    str_3 = 'E'
    str_4 = 'B'
    str_5 = 'P'
    str_6 = 'u'
    str_7 = '-'
    str_8 = '+'
    str_9 = 'S'
    str_10 = '='
    str_11 = 'N'
    str_12 = 'A'
    str_13 = '*'
    str_14 = 'I'
    str_15 = '#'
    str_16 = '$'
    s_0 = set()
    str_17 = 'K'
    str_18 = 'G'

# Generated at 2022-06-25 15:02:53.852264
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    bit_vector_0 = BitVector(bitstring='010000')
    bit_vector_1 = BitVector(bitstring='111111')
    dfa_state_0 = DFAState(bit_vector_0, bit_vector_1)
    list_0 = list()
    dfa_state_0.arcs = list_0
    bit_vector_2 = BitVector(bitstring='010000')
    bit_vector_3 = BitVector(bitstring='111111')
    dfa_state_1 = DFAState(bit_vector_2, bit_vector_3)
    list_1 = list()
    dfa_state_1.arcs = list_1
    parser_generator_3 = ParserGenerator()
    list_2 = list()
    parser_generator_3.dfas = list_

# Generated at 2022-06-25 15:03:01.307670
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    n_f_a_state_0 = NFAState()
    n_f_a_state_1 = NFAState()
    n_f_a_state_2 = NFAState()
    n_f_a_state_3 = NFAState()
    n_f_a_state_4 = NFAState()
    n_f_a_state_5 = NFAState()
    n_f_a_state_6 = NFAState()
    n_f_a_state_7 = NFAState()
    n_f_a_state_8 = NFAState()
    state_dict_0 = {}
    d_f_a_state_0 = DFAState(state_dict_0, n_f_a_state_0)
    d_f_a_state_1 = DFAState

# Generated at 2022-06-25 15:03:02.891055
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    # Create an instance of the class
    py_obj_conn = ParserGenerator()
    # Invoke the method via instance
    py_obj_conn.make_grammar()


# Generated at 2022-06-25 15:03:05.475275
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    # This should raise a ValueError...
    # Don't know how to make a ValueError out of the error = expecte method.
    pass


# Generated at 2022-06-25 15:03:07.313972
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    parser_generator = ParserGenerator()
    parser_generator.parse_item()


# Generated at 2022-06-25 15:03:15.914326
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    obj = ParserGenerator()
    obj.parse_alt

    n_f_a_state_0 = NFAState()
    n_f_a_state_0.arcs.append((None, None))
    str_0 = (['0', 'K\tL'])
    n_f_a_state_0.arcs.append((str_0, None))
    assert_raises(SyntaxError, obj.parse_alt)
    str_1 = ('j-o?~pb')
    obj.value = str_1
    n_f_a_state_1 = NFAState()
    obj.parse_item = MagicMock(return_value=[n_f_a_state_1, n_f_a_state_1])

# Generated at 2022-06-25 15:04:20.834095
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    pg_generator = ParserGenerator()
    test_case_0()


# Generated at 2022-06-25 15:04:24.027600
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    grammar_0 = {}
    str_0 = '`$s$0\t$\r7*8M/JAT'


# Generated at 2022-06-25 15:04:27.358237
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    n_f_a_state_0 = NFAState()
    test_ParserGenerator_expect_0(n_f_a_state_0)


# Generated at 2022-06-25 15:04:35.208715
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    str_0 = '`$s$0\t$\r7*8M/JAT'
    n_f_a_state_0 = NFAState()
    n_f_a_state_1 = NFAState()
    n_f_a_state_0.addarc(n_f_a_state_1, str_0)
    tup_0 = (n_f_a_state_0, n_f_a_state_1)
    str_1 = '["'
    n_f_a_state_2 = NFAState()
    n_f_a_state_3 = NFAState()
    n_f_a_state_2.addarc(n_f_a_state_3, str_1)

# Generated at 2022-06-25 15:04:38.537042
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    def test_method_parse_item(arg1: Text, arg2: Union[Text, int]) -> Union[Text, int]:
        return arg1, arg2
    method_parse_item = test_method_parse_item


# Generated at 2022-06-25 15:04:48.037117
# Unit test for function generate_grammar
def test_generate_grammar():
    os.chdir(sys.path[0])
    log.info("Working dir: %s", os.getcwd())

    # The C version of this function stores the function name as a
    # global variable, so it can't be called twice. The Python version
    # must have a different name, otherwise we get a recursive call.
    if sys.version_info < (3, 6) or 1 <= int(os.getenv("PY_GENGRAMMAR_FORCE") or 0):
        py_gen_grammar = generate_grammar
        py_gen_grammar.__name__ = "generate_grammar"
        py_gen_grammar()
        log.info("Generated grammar.txt with py_gen_grammar()")
    else:
        generate_grammar("Grammar.txt")

# Generated at 2022-06-25 15:04:55.353430
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    """
    test_parser_generator_raise_error
    """
    n_f_a_state_0 = NFAState()
    n_f_a_state_0.addarc(('\x7f', NFAState()))
    n_f_a_state_0.addarc(('\x7f', NFAState()))
    n_f_a_state_0.addarc(('&', NFAState()))
    dfa = ParserGenerator.make_dfa(n_f_a_state_0, NFAState())
    ParserGenerator.simplify_dfa(dfa)
    if True:
        raise Exception('AssertionError')


# Generated at 2022-06-25 15:04:57.473672
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    expected = None
    actual = None
    assert expected == actual


# Generated at 2022-06-25 15:05:07.015313
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    file_path = './test_case/pgen.out'
    lines = open(file_path).readlines()
    assert lines

    pgen = ParserGenerator(lines)
    pgen.type = token.NAME
    pgen.value = 'atom'
    pgen.begin = (1, 0)
    pgen.end = (1, 4)
    pgen.line = 'atom:  atom [bracket] (paren)\n'

    pgen.gettoken()
    assert pgen.type == token.NAME
    assert pgen.value == 'atom'
    assert pgen.begin == (1, 0)
    assert pgen.end == (1, 4)
    assert pgen.line == 'atom:  atom [bracket] (paren)\n'

    pgen.gettoken()

# Generated at 2022-06-25 15:05:16.766191
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    class DFAStateMock:
        def __init__(self):
            self.arcs = {}
            self.isfinal = False
            self.nfaset = {}
        def addarc(self, nfa_state_mock, value):
            self.arcs[nfa_state_mock] = value
            self.nfaset[nfa_state_mock] = 1
        def unifystate(self, dfa_state_mock, dfa_state_mock_2):
            self.arcs[dfa_state_mock_2] = self.arcs[dfa_state_mock]
            del self.arcs[dfa_state_mock]
            self.nfaset[dfa_state_mock_2] = 1
            del self.nf

# Generated at 2022-06-25 15:07:49.272734
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    PgenParser = ParserGenerator()


# Generated at 2022-06-25 15:07:58.847703
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    parser_generator_0 = ParserGenerator()
    n_f_a_state_0 = NFAState()
    str_0 = '`$s$0\t$\r7*8M/JAT'
    n_f_a_state_1 = NFAState()
    n_f_a_state_1.__init__(n_f_a_state_1)
    double_0 = 0.0
    n_f_a_state_1._NFAState__start_time = double_0
    #
    n_f_a_state_2 = NFAState()
    n_f_a_state_2.__init__(n_f_a_state_2)
    double_1 = 0.0
    n_f_a_state_2._NFAState__start

# Generated at 2022-06-25 15:08:06.304580
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    pgen_grammar_0 = PgenGrammar()
    list_0 = list()
    pgen_grammar_0.states = list_0
    dfa_state_0 = DFAState(nfaset=None, finish=None)
    dfa_state_0.arcs = dict()
    list_0.append(dfa_state_0)
    str_0 = 'Py5R@F\x0bA\t9'
    pgen_grammar_0.start = str_0
    pgen_grammar_0.first = dict()
    pgen_grammar_0.keywords = dict()
    pgen_grammar_0.tokens = dict()
    pgen_grammar_0.dfas = dict()
    pgen_grammar_0.labels

# Generated at 2022-06-25 15:08:15.482169
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    parser_generator = ParserGenerator()

    text_0 = 'a = 0'
    string_io = io.StringIO(text_0)
    parser_generator.generator = tokenize.generate_tokens(string_io.readline)
    parser_generator.gettoken()

    except_info = None
    try:
        parser_generator.expect(1, 'a')
    except SyntaxError as e:
        except_info = e
    assert except_info.msg == 'expected 1/a, got 1/=', 'Line : 81'
    assert except_info.filename == '<unknown>', 'Line : 82'
    assert except_info.lineno == 1, 'Line : 83'
    assert except_info.offset == 2, 'Line : 84'
    assert except_info

# Generated at 2022-06-25 15:08:18.338347
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    c_0 = PgenGrammar([])
    p_0 = ParserGenerator()
    p_0.make_label(c_0, str_0)


# Generated at 2022-06-25 15:08:22.323977
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    try:
        parser_generator_0 = ParserGenerator(None)
        parser_generator_0.parse_atom()
    except Exception as exception_0:
        assert isinstance(exception_0, RuntimeError)


# Generated at 2022-06-25 15:08:28.849513
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    dfa_str = [
        DFAState((NFAState()), (NFAState())),
        DFAState((NFAState()), (NFAState())),
        DFAState((NFAState()), (NFAState())),
        DFAState((NFAState()), (NFAState())),
        DFAState((NFAState()), (NFAState())),
        DFAState((NFAState()), (NFAState())),
        DFAState((NFAState()), (NFAState())),
        DFAState((NFAState()), (NFAState())),
    ]
    name = "test_name"
    ParserGenerator.dump_dfa(name, dfa_str)


# Generated at 2022-06-25 15:08:38.449383
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    # The following input should produce the following output
    # input: `$s$0\t$\r7*8M/JAT
    # output: 8
    n_f_a_state_0 = NFAState()
    str_0 = '`$s$0\t$\r7*8M/JAT'
    parser_generator = ParserGenerator()
    f = open('python27_lib/token.py', 'r')
    t = parser_generator.parse_item(f)
    m = hashlib.md5()
    m.update(t)
    str_1 = m.digest()
    str_2 = str_1[3:10]
    int_0 = int(str_2)
    return int_0


# Generated at 2022-06-25 15:08:42.202024
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    filenam_0 = '<input>'
    str_0 = '''\
a: b
b: c
c: 'x' | 'y'

'''
    str_1 = '<input>'
    str_2 = ''
    str_3 = '`$s$0\t$\r7*8M/JAT'
