

# Generated at 2022-06-25 15:00:12.330737
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    pg = ParserGenerator()
    g, s = pg.parse()


# Generated at 2022-06-25 15:00:19.158659
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    pgen_grammar_0 = PgenGrammar()
    msg = 'expected %s/%s, got %s/%s'
    args = ['(...)', None, '=', '=']
    try:
        with pytest.raises(SyntaxError) as excinfo:
            pgen_grammar_0.raise_error(msg, *args)
        assert excinfo.value.msg == 'expected (...)/None, got =/='
    except:
        with pytest.raises(SyntaxError) as excinfo:
            pgen_grammar_0.raise_error(msg, *args)
        assert excinfo.value.msg == 'expected (...)/None, got =/='



# Generated at 2022-06-25 15:00:29.169552
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    pgen_grammar_0 = ParserGenerator()
    pgen_grammar_0.generator = "ab"
    # Call gettoken
    pgen_grammar_0.gettoken()
    assert token.tok_name[pgen_grammar_0.type] == "NAME"
    assert pgen_grammar_0.value == "a"
    assert pgen_grammar_0.begin == (0, 0)
    assert pgen_grammar_0.end == (0, 1)
    assert pgen_grammar_0.line == "a"
    # Call gettoken
    pgen_grammar_0.gettoken()
    assert token.tok_name[pgen_grammar_0.type] == "NAME"

# Generated at 2022-06-25 15:00:40.612257
# Unit test for method make_grammar of class ParserGenerator

# Generated at 2022-06-25 15:00:46.269356
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    parser_generator_0 = ParserGenerator(None, None)
    pgen_grammar_0 = PgenGrammar()
    a, z = parser_generator_0.parse_rhs()
    assert isinstance(a, NFAState)
    assert isinstance(z, NFAState)
    assert a != z



# Generated at 2022-06-25 15:00:58.128372
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    """
    def make_grammar():
    """
    pgen_grammar_1 = PgenGrammar()
    num_failures_1: int = 0
    # input_1
    # Arguments:
    #     : int
    #     : int
    #     : int
    #     : int
    #     : int
    #     : int
    #     : int
    #     : int
    #     : int
    #     : int
    #     : int
    #     : int
    #     : int
    #     : int
    #     : int
    #     : int
    #     : int
    #     : int
    #     : int
    #     : int
    #     : int
    #     : int
    #     : int
    #     : int
   

# Generated at 2022-06-25 15:01:07.102668
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    pgen_grammar = PgenGrammar()

# Generated at 2022-06-25 15:01:11.636164
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    pgen_grammar_1 = PgenGrammar()
    c_2 = pgen_grammar_1.make_converter()
    name_3 = 'test'  # type: str
    c_2.make_first(c_2, name_3)


# Generated at 2022-06-25 15:01:22.665743
# Unit test for method parse of class ParserGenerator

# Generated at 2022-06-25 15:01:24.726193
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    with open("Grammar.txt") as fp:
        pg = ParserGenerator()
        pg.make_grammar(fp)


# Generated at 2022-06-25 15:01:48.449538
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    pgen_grammar_0 = PgenGrammar()
    a_0, b_0 = pgen_grammar_0.parse_alt()
    print(a_0, b_0)


# Generated at 2022-06-25 15:01:53.087484
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    pg = ParserGenerator()
    # mock up some ParserGenerator attributes
    pg.type = token.NAME
    pg.value = "nuitka"
    pg.generator = []
    # call parse_atom
    pg.parse_atom()



# Generated at 2022-06-25 15:01:59.077717
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    # A RHS : ALT ('|' ALT)*
    # B ALT: ITEM+
    # C ITEM: '[' RHS ']' | ATOM ['+' | '*']
    # D ATOM: '(' RHS ')' | NAME | STRING
    tape: List[int] = []
    pgen_grammar_0 = ParserGenerator(tape)
    args = []
    # No tracebacks should be raised
    # The expected result is 0
    pgen_grammar_0.parse_rhs()


# Generated at 2022-06-25 15:02:06.721653
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    # Instantiating the class
    pgen_grammar_0 = ParserGenerator()

    from io import StringIO

    comment = StringIO("# Test comment\n")
    tokenize.tokenize(comment.readline)

    pgen_grammar_0.filename = "PgenGrammar.py"
    pgen_grammar_0.end = (1, 0)
    pgen_grammar_0.line = "Testing raise_error"

    try:
        pgen_grammar_0.raise_error("Test %s %s", "raise_error", "test")
    except SyntaxError:
        print("Test raise_error in class PgenGrammar: SyntaxError")


# Generated at 2022-06-25 15:02:08.711363
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    pgen_grammar = PgenGrammar()
    some_str = pgen_grammar.dump_dfa("some_str", "some_dfa")


# Generated at 2022-06-25 15:02:11.955239
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    pgen_grammar_0 = PgenGrammar()
    pgen_grammar_0.make_label("pgen_grammar_0")


# Generated at 2022-06-25 15:02:14.719193
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    import unittest
    from .treebuilder import TreeBuilderBase

    class Dummy(TreeBuilderBase):

        def build(self) -> None:
            raise NotImplementedError

    dummy = Dummy()
    parser = ParserGenerator(dummy)
    # parser.make_dfa(start, finish)
    # TODO: implement
    # raise NotImplementedError

    return dummy, parser


# Generated at 2022-06-25 15:02:24.633555
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():

    pgen_grammar_1 = PgenGrammar()
    input_stream_1 = "("
    pgen_grammar_1.generator = tokenize.generate_tokens(io.StringIO(input_stream_1).readline)
    pgen_grammar_1.gettoken()
    pgen_grammar_1.parse_item()
    assert pgen_grammar_1.type == 41
    assert pgen_grammar_1.value == "("
    assert pgen_grammar_1.begin == (1, 1)
    assert pgen_grammar_1.end == (1, 2)
    assert pgen_grammar_1.line == "\n"


# Generated at 2022-06-25 15:02:29.153185
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    import sys
    import io
    strm = io.StringIO()
    pgen_grammar_0 = PgenGrammar()
    pgen_grammar_0.dump_dfa("[", [DFAState({NFAState(): 1}, NFAState())])
    value_0 = strm.getvalue()
    assert value_0 == "Dump of DFA for [\n  State 0 \n    [ -> 0\n", "Expected different output from dump_dfa"


# Generated at 2022-06-25 15:02:31.421888
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    """Test cases for method parse_item of class ParserGenerator."""
    parser_generator = ParserGenerator()
    assert parser_generator.parse_item() == (None, None)


# Generated at 2022-06-25 15:03:31.280242
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    pgen_grammar_0 = PgenGrammar()
    # @adds: 0
    pgen_grammar_0.gettoken()
    # eq_(pgen_grammar_0.type, expected)
    # eq_(pgen_grammar_0.value, expected)
    # eq_(pgen_grammar_0.begin, expected)
    # eq_(pgen_grammar_0.end, expected)
    # eq_(pgen_grammar_0.line, expected)



# Generated at 2022-06-25 15:03:36.393370
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    # Use case:
    pgen_grammar_0 = PgenGrammar()
    # Expected value (maybe partially):
    # a =
    # z =
    # <Check for a, z and assert 'self.value == ("(", "[", "NAME", "STRING")' fails>
    # self.gettoken()
    # raise_error('expected (...) or NAME or STRING, got %s/%s', self.type, self.value)
    assert False, "Not implemented"


# Generated at 2022-06-25 15:03:43.642555
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    pgen_grammar_1 = PgenGrammar()
    c_1 = pgen_grammar_1.make_converter()
    name_1 = 'name'
    pgen_grammar_1.make_first(c_1, name_1)

if __name__ == '__main__':
    import sys
    pgen_grammar_2 = PgenGrammar()
    if len(sys.argv) > 1:
        pgen_grammar_2.generate(sys.argv[1])

# Generated at 2022-06-25 15:03:48.556043
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    pgen_grammar_0 = PgenGrammar()
    dfa_0 = pgen_grammar_0.make_dfa(pgen_grammar_0.NFAState(), pgen_grammar_0.NFAState())
    pgen_grammar_0.dump_dfa("test_ParserGenerator_dump_dfa", dfa_0)


# Generated at 2022-06-25 15:03:53.026787
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    with pytest.raises(StopIteration) as excinfo:
        pgen_grammar_0 = PgenGrammar()
        pgen_grammar_0.generator = iter(list())
        pgen_grammar_0.gettoken()
    assert excinfo.value.args[0] == ''


# Generated at 2022-06-25 15:03:55.210010
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    pgen_grammar0 = PgenGrammar()
    assert pgen_grammar0.states == []
    assert pgen_grammar0.dfas == []
    assert pgen_grammar0.start == 0


# Generated at 2022-06-25 15:03:57.525326
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    from . import parser_def
    parser_gen = ParserGenerator(parser_def, "ParserGenerator.make")
    dfas, startsymbol = parser_gen.parse()
    assert len(dfas) > 0


# Generated at 2022-06-25 15:04:03.275075
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    pgen_grammar_1 = PgenGrammar()
    s = """\
test_str: 'a+' 'b'"""
    pgen_grammar_1.parsestr(s)
    dfa = pgen_grammar_1.dfas['test_str']
    a = dfa[0]
    z = dfa[2]
    assert a.arcs == {'a': a, 'b': z}
    # a = dfa[0]
    # aa = dfa[2]
    # z = dfa[4]
    # assert a.arcs == {'a': aa, 'b': z}
    # assert aa.arcs == {'b': z, 'a': aa}
    # assert z.arcs == {}



# Generated at 2022-06-25 15:04:04.584449
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    pgen_grammar_0 = PgenGrammar()
    pgen_grammar_0.calcfirst(name=str())


# Generated at 2022-06-25 15:04:05.635038
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    assert (isinstance(pgen_grammar_0, PgenGrammar))


# Generated at 2022-06-25 15:05:47.244282
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    pgen_grammar_0 = ParserGenerator()
    pgen_grammar_0.type = token.NAME
    pgen_grammar_0.value = "open"
    assert pgen_grammar_0.expect(token.NAME, "open") == "open"
    assert pgen_grammar_0.type == token.NAME
    assert pgen_grammar_0.value == "open"
    try:
        pgen_grammar_0.expect(token.NAME, "for")
    except SyntaxError as e:
        assert e.msg == "expected NAME/for, got NAME/open"
        assert e.filename == "<string>"
        assert e.lineno == 1
        assert e.offset == 5

# Generated at 2022-06-25 15:05:56.784140
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    # input data
    input_class_ParserGenerator = ParserGenerator()
    input_class_ParserGenerator.type = token.OP
    input_class_ParserGenerator.value = ":"
    input_class_ParserGenerator.gettoken()
    input_class_ParserGenerator.type = token.STRING
    input_class_ParserGenerator.value = "\n"
    input_class_ParserGenerator.gettoken()
    input_class_ParserGenerator.type = token.NAME
    input_class_ParserGenerator.value = "finish"
    input_class_ParserGenerator.gettoken()
    input_class_ParserGenerator.type = token.NAME
    input_class_ParserGenerator.value = "a"
    input_class_ParserGenerator.gettoken()
    input_class_Parser

# Generated at 2022-06-25 15:06:05.868727
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    filename = "Grammar/Parser/Python.asdl"
    assert os.path.exists(filename)
    # pgen_grammar = ParserGenerator.parse_grammar(filename)
    pgen_grammar = ParserGenerator.parse_grammar_file(filename)
    gram = pgen_grammar.convert()

    assert isinstance(gram.start, int)
    assert isinstance(gram.states, List[List[List[Tuple[int, Optional[int]]]]])
    assert isinstance(gram.dfas, Dict[int, Tuple[List[List[Tuple[int, int]]], Dict[int, int]]])
    assert isinstance(gram.labels, List[Tuple[int, Optional[str]]])


# Generated at 2022-06-25 15:06:11.398666
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    pgen_grammar_1 = PgenGrammar()
    pgen_grammar_2 = PgenGrammar()
    pgen_grammar_3 = PgenGrammar()
    pgen_grammar_4 = PgenGrammar()
    pgen_grammar_1.calcfirst("test_label_0")
    pgen_grammar_2.calcfirst("test_label_1")
    pgen_grammar_3.calcfirst("test_label_2")
    pgen_grammar_4.calcfirst("test_label_3")


# Generated at 2022-06-25 15:06:19.473545
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    # Test with empty input
    input_list_list_list_list_list_list : list = []
    result_list_list_list : list = ParserGenerator.simplify_dfa(input_list_list_list_list_list_list)
    expected_list_list_list = [ [[]] ]
    assert result_list_list_list == expected_list_list_list, "expected " + str(expected_list_list_list) + " but got " + str(result_list_list_list)

# Generated at 2022-06-25 15:06:26.636006
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    class Mock_PgenGrammar:
        def __init__(self):
            self.value = None
            self.type = None
            self.end = None
            self.line = None
            self.begin = None
            self.raise_error = lambda a, b=None: None
        def gettoken(self):
            pass
        def expect(self, arg1, arg2=None):
            pass
        def parse_rhs(self):
            return (None, None)
        def parse_atom(self):
            return (None, None)
    pgen_grammar_1 = Mock_PgenGrammar()
    pgen_grammar_1.value = "["
    pgen_grammar_1.parse_item()
    pgen_grammar_1.value = None
    pgen_gram

# Generated at 2022-06-25 15:06:28.418850
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    pgen_grammar_0 = PgenGrammar()
    pgen_grammar_0.parse_item()


# Generated at 2022-06-25 15:06:32.166378
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    arg_0 = PgenGrammar()
    # XXX Fails on <> ... !=
    # ValueError: rule_descr_list is ambiguous; <> is in the
    # first sets of expr_stmt as well as decorator
    arg_1 = '<>'
    res_2 = PgenGrammar.make_label(arg_0, arg_1)


# Generated at 2022-06-25 15:06:34.982519
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    from . import grammar
    from . import token

    pgen = ParserGenerator(grammar, __name__)
    pgen.make_grammar()
    pgen.write_grammar()
    pgen.write_tables()
    pgen.write_parsetab()



# Generated at 2022-06-25 15:06:45.764024
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    input_text = test_input_text
    pgen_grammar = ParserGenerator(input_text)

    pgen_grammar_tokens = [
        # PLY uses token.NAME
    ]
    pgen_grammar_keywords = {}
    class pgen_grammar_converter(object):
        labels = []
        tokens = {}
        keywords = {}
        states = []
        dfas = {}
        symbol2number = {}
        symbol2label = {}
    pgen_grammar_c = pgen_grammar_converter()
    pgen_grammar_label = pgen_grammar.make_label(pgen_grammar_c, pgen_grammar_label)
    assert pgen_grammar_label is not None


# Generated at 2022-06-25 15:08:24.735089
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    s = '''example : rules | rules'''
    pg = ParserGenerator()
    text = pg.clean_grammar(s)
    tokens = tokenize.tokenize(BytesIO(text).readline)
    pg.generator = tokens
    pg.gettoken()
    a, b = pg.parse_alt()
    assert a is not None
    assert b is not None


# Generated at 2022-06-25 15:08:26.736611
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    parser_generator_0 = ParserGenerator("<string>")
    a_0, z_0 = parser_generator_0.parse_rhs()
    a_0, z_0 = parser_generator_0.parse_rhs()
    a_0, z_0 = parser_generator_0.parse_rhs()


# Generated at 2022-06-25 15:08:27.954241
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    pgen_grammar = PgenGrammar()
    pgen_grammar.addfirstsets()

# Generated at 2022-06-25 15:08:36.509198
# Unit test for function generate_grammar
def test_generate_grammar():
    grammar = generate_grammar()
    assert grammar.start == 'file_input'
    assert isinstance(grammar.parsing_table, dict)
    assert isinstance(grammar.labels, list)
    assert isinstance(grammar.dfas, dict)
    assert 'compound_stmt' in grammar.parsing_table
    assert ('compound_stmt', 1) in grammar.parsing_table['compound_stmt']
    assert grammar.parsing_table['compound_stmt'][('compound_stmt', 1)] == ('stmt', 1)
    assert 'expr_stmt' in grammar.dfas
    assert 'stmt' in grammar.dfas
    
    
print("Tests passed!")