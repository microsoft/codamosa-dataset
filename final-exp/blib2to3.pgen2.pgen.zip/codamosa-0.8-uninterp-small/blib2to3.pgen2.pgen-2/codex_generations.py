

# Generated at 2022-06-25 15:00:18.964041
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    def test_case_1():
        n_f_a_state_0 = NFAState()
        n_f_a_state_1 = NFAState()
        n_f_a_state_2 = NFAState()
        n_f_a_state_3 = NFAState()
        n_f_a_state_4 = NFAState()
        n_f_a_state_0.addarc(n_f_a_state_1, None)
        n_f_a_state_0.addarc(n_f_a_state_3, None)
        n_f_a_state_1.addarc(n_f_a_state_2, None)
        n_f_a_state_1.addarc(n_f_a_state_4, None)
        n

# Generated at 2022-06-25 15:00:24.866373
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    # XXX: Is this test expected to fail?
    # Test make_label in absence of gettoken
    gen = ParserGenerator()
    # label is not a str, but Text
    # gen.type is a str, but int
    label_0 = 1
    type_0 = 1
    gen.gettoken = lambda: 1
    gen.make_label(n_f_a_state_0, label_0)


# Generated at 2022-06-25 15:00:31.668391
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    p_g_p_g_0 = ParserGenerator()
    n_f_a_state_0 = NFAState()
    n_f_a_state_1 = NFAState()
    n_f_a_state_0.addarc(n_f_a_state_1, "TYPE")
    tup_0 = p_g_p_g_0.parse_item()
    assert tup_0[0] == n_f_a_state_0
    assert tup_0[1] == n_f_a_state_1


# Generated at 2022-06-25 15:00:40.785954
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():

    def assert_expect(self, type, value=None):
        if self.type != type or (value is not None and self.value != value):
            self.raise_error("expected %s/%s, got %s/%s", type, value, self.type, self.value)
        value = self.value
        self.gettoken()
        return value

    p = ParserGenerator("")
    assert_expect(p,1,"1")
    assert_expect(p,1,"1")


# Generated at 2022-06-25 15:00:48.498612
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    g = ParserGenerator()
    input = StringIO(
        """\
[0-9]+
"""
    )
    output = g.parse(input, '<text>')
    assert output == (
        [
            [
                [([0], None), ([1], None), ([2], None), ([3], None), ([4], None)]
            ],
        ],
        0,
    )


# Generated at 2022-06-25 15:00:59.508225
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    # Two of the states are the same.
    dfa_0 = [DFAState({NFAState(): 1}, NFAState()), DFAState({NFAState(): 1}, NFAState())]
    # Run the method being tested
    parser_generator_0 = ParserGenerator()
    parser_generator_0.simplify_dfa(dfa_0)
    # Check that we got expected results
    assert len(dfa_0) == 1, "Expected: 1\nActual: " + len(dfa_0)
    # Check the argument is unmodified
    assert len(dfa_0) == 1
    assert dfa_0[0].arcs == {}, "Expected: {}\nActual: " + dfa_0[0].arcs


# Generated at 2022-06-25 15:01:08.018022
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    n_f_a_state_0 = NFAState()
    n_f_a_state_1 = NFAState()
    n_f_a_state_0.addarc(n_f_a_state_1)
    n_f_a_state_0.addarc(n_f_a_state_1, "a")
    n_f_a_state_0.addarc(n_f_a_state_1, "b")
    n_f_a_state_0.addarc(n_f_a_state_1, "a")
    n_f_a_state_0.addarc(n_f_a_state_1, "b")
    n_f_a_state_0.addarc(n_f_a_state_1, "a")
    n

# Generated at 2022-06-25 15:01:12.589556
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    options: Dict[str, bool] = {}
    gen = ParserGenerator(options)
    a, z = gen.parse_item()
    assert a, 'Return value of function parse_item is incorrect'
    assert z, 'Return value of function parse_item is incorrect'


# Generated at 2022-06-25 15:01:14.259602
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    p = ParserGenerator()
    p.dump_dfa("name", "dfa")


# Generated at 2022-06-25 15:01:19.877031
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    p_g_0 = ParserGenerator()
    n_f_a_state_0 = test_case_0()
    p_g_0.dump_nfa("name_0", n_f_a_state_0, n_f_a_state_0)


# Generated at 2022-06-25 15:02:00.018153
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    generator = tokenize.generate_tokens(iter(StringIO('<token-stream>').readline, '').__next__)
    pgen = ParserGenerator('<token-stream>', generator)
    pgen.raise_error('Message 1')
    with pytest.raises(SyntaxError):
        pgen.raise_error('Message 2')
    pgen.raise_error('Message 3', 'Argument 1')
    with pytest.raises(SyntaxError):
        pgen.raise_error('Message %s', 'Argument 2')
    with pytest.raises(SyntaxError):
        pgen.raise_error('Message %s %s', 'Argument 3', 'Argument 4')

# Generated at 2022-06-25 15:02:02.638216
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    n_p_g = ParserGenerator("")
    n_p_g.type = 0
    n_p_g.value = ""
    n_p_g.expect(0, None)


# Generated at 2022-06-25 15:02:07.942177
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    g = ParserGenerator()
    p = g.make_grammar()

    assert(len(p.gramsymb2nums) == 0)
    assert(len(p.gramsymbols) == 0)
    assert(p.p_type == 0)
    assert(len(p.grammar) == 0)
    assert(len(p.labels) == 0)
    assert(len(p.dfas) == 0)
    assert(p.start == 0)


# Generated at 2022-06-25 15:02:12.059853
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    global n_f_a_state_0
    parser_generator_0 = ParserGenerator()
    assert parser_generator_0.dump_dfa(None, None) is None


# Generated at 2022-06-25 15:02:14.632018
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    a, b = ParserGenerator.make_first(test_case_0(), "")
    return a


# Generated at 2022-06-25 15:02:22.977756
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    g = PgenGrammar()
    assert g.name == "PgenGrammar"
    assert g.symbol2number == {"empty": 0}
    assert g.number2symbol == {"0": "empty"}
    assert g.keywords == {}
    assert g.start == "file_input"
    assert g.tokens == []
    assert g.dfas == []
    assert g.states == []
    assert g.first == {}
    assert g.productions == {}
    assert g.grammar == {}
    assert g.dfa_states == []


# Generated at 2022-06-25 15:02:31.088798
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    n_f_a_state_0 = NFAState()
    n_f_a_state_0.arcs(None, n_f_a_state_0)
    n_f_a_state_0.addarc(n_f_a_state_0, "NAME")
    n_f_a_state_0.addarc(n_f_a_state_0, "NUMBER")
    n_f_a_state_0.addarc(n_f_a_state_0, "STRING")
    n_f_a_state_0.addarc(n_f_a_state_0, "<>")
    n_f_a_state_0.addarc(n_f_a_state_0, "{")

# Generated at 2022-06-25 15:02:37.925996
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    nfa_states = [n_f_a_state_0, n_f_a_state_1]
    dfas = []
    states = []
    for state in nfa_states:
        arcs = {}
        for label, next in sorted(state.arcs.items()):
            addclosure(next, arcs.setdefault(label, {}))
        states.append(DFAState(arcs, finish))
    dfas = states
    return dfas



# Generated at 2022-06-25 15:02:38.882443
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    assert False, "test_expect"


# Generated at 2022-06-25 15:02:39.700750
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    with SuppressOutput():
        test_case_0()




# Generated at 2022-06-25 15:03:13.677086
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    parser_generator_instance = ParserGenerator()
    # TO DO: add test case for parse


# Generated at 2022-06-25 15:03:23.584404
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    # Create an instance of PgenParser
    pgen_parser_0 = PgenParser()

    # Create an instance of StringIO
    string_io_0 = StringIO()

    # Call method parse on pgen_parser_0 with arguments string_io_0 and 'ParserGenerator'
    result_0 = pgen_parser_0.parse(string_io_0, 'ParserGenerator')

    # Create an instance of PgenGrammarConverter
    pgen_grammar_converter_0 = PgenGrammarConverter()

    # Call method convert on pgen_grammar_converter_0 with argument result_0
    pgen_grammar_converter_0.convert(result_0)

# Generated at 2022-06-25 15:03:27.488254
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    # Set up parameters
    pg = ParserGenerator()
    dfa_1 = [0, 1]
    name_1 = "2"

    # Invoke method
    pg.dump_dfa(name_1, dfa_1)


# Generated at 2022-06-25 15:03:35.967951
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    n_p_gen = ParserGenerator()
    p_gen_conv_0 = ParserGeneratorConverter()
    p_gen_conv_1 = ParserGeneratorConverter()
    dfas = {
        'expr_stmt': [
            DFAState({n_f_a_state_0: 1}, None),
            DFAState({}, None),
            DFAState({}, None),
            DFAState({}, None),
            DFAState({}, None),
        ],
    }
    first = {'expr_stmt': {"'test'": 1, 'test': 1, 'x': 1}}
    sym_tkn = {'test': 1, 'x': 1}
    sym_lab = {'expr_stmt': 0}
    n_p_gen.dfas = dfas

# Generated at 2022-06-25 15:03:46.136461
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    question_mark_0 = "?"
    square_close_0 = "]"
    square_open_0 = "["
    doc_0 = "__doc__"
    name_0 = "NAME"
    square_open_1 = "["
    square_close_1 = "]"
    bar_0 = "|"
    name_2 = "NAME"
    name_1 = "NAME"
    pgen_0 = ParserGenerator(tuple())
    test_ParserGenerator_test_ParserGenerator_test_case_0(pgen_0)
    test_ParserGenerator_test_ParserGenerator_test_case_1(pgen_0)
    test_ParserGenerator_test_ParserGenerator_test_case_2(pgen_0)

# Generated at 2022-06-25 15:03:50.763779
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    n_f_a_state_0 = NFAState()
    n_f_a_state_1 = NFAState()
    n_f_a_state_2 = NFAState()
    n_f_a_state_3 = NFAState()
    n_f_a_state_4 = NFAState()
    n_f_a_state_5 = NFAState()
    n_f_a_state_0.addarc(n_f_a_state_1, 'x')
    n_f_a_state_0.addarc(n_f_a_state_2, 'y')
    n_f_a_state_1.addarc(n_f_a_state_3, 'z')

# Generated at 2022-06-25 15:03:57.826492
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    parser_generator_0 = ParserGenerator('test.py')
    next(parser_generator_0.generator)
    parser_generator_0.gettoken()
    print("\n")
    parser_generator_0.gettoken()
    print("\n")
    parser_generator_0.gettoken()
    print("\n")
    parser_generator_0.gettoken()
    print("\n")

test_case_0()
test_ParserGenerator_gettoken()

# Generated at 2022-06-25 15:04:04.416073
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    parser_generator_0 = ParserGenerator()
    try:
        assert_raises(ValueError, parser_generator_0.calcfirst, "test_ParserGenerator_calcfirst.test_case_0")
    except:
        stderr.write(
            "Exception raised during processing of test case test_ParserGenerator_calcfirst.test_case_0()\n"
        )
        raise


# Generated at 2022-06-25 15:04:05.308288
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    parser = ParserGenerator()
    parser.calc_first()#


# Generated at 2022-06-25 15:04:11.489650
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    n_f_a_state_0 = NFAState()
    n_f_a_state_0.addarc(n_f_a_state_0)
    i_0 = {n_f_a_state_0: 1}
    i_1 = {n_f_a_state_0: 1}
    i_2 = {}
    i_3 = {}
    i_4 = {}
    i_5 = {}
    i_6 = {}
    i_7 = {}
    parser_generator_0 = ParserGenerator(None, None, None)
    parser_generator_0.type = (
        token.STRING
    )  # tokenize.tok_name['STRING']  # 'STRING'
    parser_generator_0.value = '""'
    n_f

# Generated at 2022-06-25 15:05:42.738750
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    n_f_a_state_0 = NFAState()
    n_f_a_state_0.arcs = {(None, n_f_a_state_0): 1}
    n_f_a_state_1 = NFAState()
    n_f_a_state_1.arcs = {(None, n_f_a_state_1): 1}
    pgen = ParserGenerator()
    pgen.dfas = {"x": [n_f_a_state_0], "y": [n_f_a_state_1]}
    pgen.first = {"x": None, "y": {(None, n_f_a_state_1): 1}}
    pgen.startsymbol = "S"
    c = pgen.make_pgen_grammar()
   

# Generated at 2022-06-25 15:05:46.810565
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    c = PgenGrammar()
    names = ["foo"]
    ret = ParserGenerator().make_first(c, names[0])
    assert ret is not None # should never be None



# Generated at 2022-06-25 15:05:53.292285
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    grammar_0 = ParserGenerator()
    grammar_0.startsymbol = "Dot"

# Generated at 2022-06-25 15:05:57.421473
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    parser_generator_0 = ParserGenerator()
    str_1 = '"'
    int_0 = token.STRING
    assert parser_generator_0.expect(int_0, str_1) == str_1


# Generated at 2022-06-25 15:05:58.940460
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    tgrammar_0 = PgenGrammar()
    assert tgrammar_0 is not None


# Generated at 2022-06-25 15:05:59.973498
# Unit test for method gettoken of class ParserGenerator

# Generated at 2022-06-25 15:06:00.937423
# Unit test for function generate_grammar
def test_generate_grammar():
    assert generate_grammar()


# Generated at 2022-06-25 15:06:08.782783
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    p_g_0 = ParserGenerator()
    n_f_a_state_0 = NFAState()
    n_f_a_state_1 = NFAState()
    n_f_a_state_0.addarc(n_f_a_state_1, None)
    p_g_0.parse_item = lambda : (n_f_a_state_0, n_f_a_state_1)
    p_g_0.value = '+'
    p_g_0.gettoken = lambda : None
    a_0, b_0 = p_g_0.parse_alt()
    assert a_0 is n_f_a_state_0
    assert b_0 is n_f_a_state_1


# Generated at 2022-06-25 15:06:20.359970
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    # Initialize an instance of ParserGenerator, named 'pgen'
    pgen = ParserGenerator()

    # Set up a string for the function 'parse_alt' to parse.
    pgen.value = '[' # Sets up a mock string
    pgen.gettoken() # Calls the method 'gettoken' on 'pgen'
    
    # Call the method 'parse_alt' on 'pgen'
    # parse_alt returns two NFAState objects, and they are passed as 
    #   references to the NFAState objects 'a' and 'z'
    a, z = pgen.parse_alt()
    
    # Extract the value of the attribute 'arcs' of 'a'.
    temp = a.arcs

    # Assert that the value of the attribute 'arcs' of 'a' is an empty list

# Generated at 2022-06-25 15:06:23.231179
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    pg = ParserGenerator()
    test_case_0()
    # Tests method dump_nfa(name, start, finish)
    pg.dump_nfa('name', n_f_a_state_0, n_f_a_state_0)
