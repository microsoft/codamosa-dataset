

# Generated at 2022-06-25 15:00:09.677004
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    parser_generator_0 = ParserGenerator()
    parser_generator_0.gettoken()


# Generated at 2022-06-25 15:00:10.914178
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    parser_generator_0 = ParserGenerator()
    parser_generator_0.addfirstsets()

# Generated at 2022-06-25 15:00:11.886163
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    p = ParserGenerator()

    assert p.first == { }


# Generated at 2022-06-25 15:00:18.637231
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    s = "--"
    p = ParserGenerator(s)
    p.type = token.OP
    p.value = "-"
    p.begin = (1, 1)
    p.end = (1, 3)
    p.line = "--\n"
    msg = "expected (...) or NAME or STRING, got 94/-"
    exc_raised = False
    try:
        p.raise_error(msg)
    except SyntaxError:
        exc_raised = True
    assert exc_raised
    assert str(SyntaxError) == "invalid token"
    test_case_0()
    test_case_0()
    test_case_0()


# Generated at 2022-06-25 15:00:21.798874
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    gram = PgenGrammar({'nfa': ()})
    assert isinstance(gram, PgenGrammar)
    assert isinstance(gram, grammar.Grammar)


# Generated at 2022-06-25 15:00:26.750231
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    # pgen_parser_data.pgen_grammar_data.pgen_grammar.pgen_parser.ParserGenerator
    # assert getattr(pgen_parser_data, "pgen_grammar_data").getattr(
    #     "pgen_grammar"
    # ).getattr("pgen_parser").getattr("ParserGenerator").make_first()
    pass

# Generated at 2022-06-25 15:00:34.653684
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    # Test data copied JSON dump of internal states
    n_f_a_state_1 = NFAState()
    n_f_a_state_2 = NFAState()
    n_f_a_state_3 = NFAState()
    n_f_a_state_4 = NFAState()
    n_f_a_state_5 = NFAState()
    n_f_a_state_6 = NFAState()
    n_f_a_state_7 = NFAState()
    n_f_a_state_8 = NFAState()
    n_f_a_state_9 = NFAState()
    n_f_a_state_10 = NFAState()
    n_f_a_state_11 = NFAState()
    n_f_a_state_12 = N

# Generated at 2022-06-25 15:00:40.773981
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    # Python/pgen.c: test_case_0
    pgen = ParserGenerator()
    pgen.generator = tokenize.tokenize(io.BytesIO(b"('x)').get_token()").readline)
    try:
        pgen.parse_alt()
        assert False, "ValueError expected"
    except ValueError as e:
        pass

# Generated at 2022-06-25 15:00:53.480612
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    n_f_a_state_0 = NFAState()
    n_f_a_state_1 = NFAState()
    n_f_a_state_0.addarc(n_f_a_state_1)
    n_f_a_state_2 = NFAState()
    n_f_a_state_3 = NFAState()
    n_f_a_state_2.addarc(n_f_a_state_3)
    n_f_a_state_4 = NFAState()
    n_f_a_state_5 = NFAState()
    n_f_a_state_4.addarc(n_f_a_state_5)

# Generated at 2022-06-25 15:00:57.791624
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    test_cases = (
        [],
        [
            "a : 'b'",
            "c : a 'd'",
            "e : c 'f'",
        ],
    )
    for gram in test_cases:
        check_ParserGenerator_parse(gram)



# Generated at 2022-06-25 15:01:34.876727
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    n_f_a_state_0 = NFAState()
    n_f_a_state_1 = NFAState()
    n_f_a_state_0.addarc(n_f_a_state_1, None)
    n_f_a_state_0.addarc(n_f_a_state_1, "A")
    n_f_a_state_2 = NFAState()
    n_f_a_state_3 = NFAState()
    n_f_a_state_2.addarc(n_f_a_state_3, None)
    n_f_a_state_2.addarc(n_f_a_state_3, "B")
    n_f_a_state_4 = NFAState()
    n_f_a_state_

# Generated at 2022-06-25 15:01:38.821647
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    for _ in range(20):
        parser = ParserGenerator()
        a, z = parser.parse_rhs()


# Generated at 2022-06-25 15:01:41.241164
# Unit test for function generate_grammar
def test_generate_grammar():
    pgen_grammar = generate_grammar()
    print(pgen_grammar)
    assert pgen_grammar is not None

if __name__ == "__main__":
    test_generate_grammar()

if __name__ == "__main__":
    p = ParserGenerator()
    g = p.make_grammar()

# Generated at 2022-06-25 15:01:42.413884
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    # No tests implemented yet
    pass


# Generated at 2022-06-25 15:01:46.871384
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    dfa_0 = [DFAState({n_f_a_state_0: 1}, n_f_a_state_0)]
    test_case_0()
    test_ParserGenerator_simplify_dfa_0 = ParserGenerator()
    test_ParserGenerator_simplify_dfa_0.simplify_dfa(dfa_0)


# Generated at 2022-06-25 15:01:53.513780
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    pgen_grammar_0 = PgenGrammar()
    parsergenerator_0 = ParserGenerator(pgen_grammar_0)
    converter_0 = Converter(parsergenerator_0)
    c_0 = converter_0.make_first(n_f_a_state_0, n_f_a_state_0)
    assert c_0 is None


# Generated at 2022-06-25 15:01:58.063208
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    tokenize.TokenInfo
    # cfg = ParserGenerator(open('nastygrammar'))
    for fname in os.listdir("."):
        if fname.endswith(".grammar"):
            print("Testing", fname, "...")
            try:
                cfg = ParserGenerator(open(fname))
            except:
                print("  Test failed")
                raise



# Generated at 2022-06-25 15:02:02.510689
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    # Test:
    #    parser = ParserGenerator(list(tokenize.generate_tokens(tokens)))
    #    pgen_grammar = parser.parse()
    #    parser.addfirstsets()
    test_case_0()
    assert False, "Test failed"
    # No exception raised

# Generated at 2022-06-25 15:02:08.129806
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    p_g_0 = ParserGenerator(
        "",
        tokenize.generate_tokens(StringIO("").readline),
        "<stdin>",
    )
    try:
        ParserGenerator.raise_error(p_g_0, "", "")
    except SyntaxError as e:
        assert e.msg == ""
        assert e.filename == "<stdin>"
        assert e.lineno == 1
        assert e.offset == 0
        assert e.text == ""


# Generated at 2022-06-25 15:02:20.039096
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    parser_generator = ParserGenerator()

    # Tests for method calcfirst
    parser_generator.dfas['x'] = [DFAState({}, False)]
    parser_generator.calcfirst('x')

    parser_generator.dfas['x'] = [DFAState({n_f_a_state_0: 1}, False)]
    n_f_a_state_0.addarc(n_f_a_state_0, 'y')
    parser_generator.calcfirst('x')

    parser_generator.dfas['x'] = [DFAState({n_f_a_state_0: 1}, False)]
    n_f_a_state_0.addarc(n_f_a_state_0, 'x')
    parser_generator.calcfirst('x')

# Generated at 2022-06-25 15:03:14.578353
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    n_f_a_state_0 = NFAState()

    parser_generator_0 = ParserGenerator(n_f_a_state_0)

    parser_generator_0.gettoken()

# Generated at 2022-06-25 15:03:19.952539
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    test_case_0()
    input_0 = ParserGenerator('')
    expected_0 = 0
    actual_0 = input_0.make_label(NFAState, '')
    assert expected_0 == actual_0
    print(actual_0)
    # Here's some code you can use to test your work locally.

# The main routine for testing

# Generated at 2022-06-25 15:03:31.797543
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    # Tests the make_dfa method of class ParserGenerator.
    #
    # Note: The test case is taken from W3C gt:
    # https://www.w3.org/TR/1999/REC-gt-19991002/
    n_f_a_states = test_case_0.__code__.co_consts[0]
    assert n_f_a_states.co_varnames == ("n_f_a_state_0",)

# Generated at 2022-06-25 15:03:38.658946
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    # From <stdin>
    dfas: Dict[Text, List[DFAState]]
    startsymbol: Text
    input_str = '''
module:
  stmt+

stmt:
  'module' NAME ':' suite
  | CLASSNAME

suite:
  simple_stmt
  | NEWLINE INDENT stmt+ DEDENT

simple_stmt:
  small_stmt (';' small_stmt)* [';'] NEWLINE
  | NEWLINE

small_stmt:
  atoms

atoms:
  'pass'
  | NAME ('=' atoms)*
  | 'print' atoms
  | 'print'
  | 'print(' atoms ')'
  | '=' NAME

CLASSNAME: 'class'

'''

# Generated at 2022-06-25 15:03:41.429942
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    converter = ParserGenerator()
    label = 'x'
    c = PgenGrammar()
    converter.make_label(c, label)


# Generated at 2022-06-25 15:03:50.727818
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    n_f_a_state_0 = NFAState()
    n_f_a_state_1 = NFAState()
    n_f_a_state_0.addarc(n_f_a_state_1, 'a')
    n_f_a_state_2 = NFAState()
    n_f_a_state_1.addarc(n_f_a_state_2, 'b')
    d_f_a_state_3 = DFAState({n_f_a_state_0: 1, n_f_a_state_1: 1, n_f_a_state_2: 1}, n_f_a_state_2)

# Generated at 2022-06-25 15:04:01.268071
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():

    # No exception raised
    n_f_a_state_0 = NFAState()
    d_f_a_state_0 = DFAState({n_f_a_state_0: 1}, n_f_a_state_0)
    parser_generator_0 = ParserGenerator(
        [({n_f_a_state_0: 1}, n_f_a_state_0)], n_f_a_state_0
    )

    # No exception raised
    parser_generator_1 = ParserGenerator(
        [({d_f_a_state_0: 1}, d_f_a_state_0)], d_f_a_state_0
    )

test_ParserGenerator()



# Generated at 2022-06-25 15:04:07.926385
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    parser_generator_0 = ParserGenerator()
    n_f_a_state_0 = NFAState()
    n_f_a_state_1 = NFAState()
    n_f_a_state_0.addarc(n_f_a_state_1, 'None')
    assert (
        parser_generator_0.parse_item()
        == (n_f_a_state_0, n_f_a_state_1)
    )

# Generated at 2022-06-25 15:04:13.677042
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    print("Testing method 'parse_item' of class 'ParserGenerator'")
    # Set up the input
    p_g_1 = ParserGenerator()
    p_g_1.type = token.NAME
    p_g_1.value = "("
    # Set up the expected output
    p_i_0 = "("
    # Invoke the test method
    p_i_1 = p_g_1.parse_item()
    # Verify the results
    assert "(p_i_1)" == "(p_i_0)"
    print("Test passed")


# Generated at 2022-06-25 15:04:15.655702
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    pass

# Local Variables:
# compile-command: "python test_parser.py"
# End:

# Generated at 2022-06-25 15:06:19.825370
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    parser_generator_0 = ParserGenerator()
    # Method make_dfa of class ParserGenerator
    assert parser_generator_0.make_dfa(n_f_a_state_0, n_f_a_state_0) == []


# Generated at 2022-06-25 15:06:26.977211
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    generator_0 = (1, 2, 3)
    n_f_a_state_1 = NFAState()
    n_f_a_state_2 = NFAState()
    n_f_a_state_3 = NFAState()
    n_f_a_state_4 = NFAState()
    n_f_a_state_5 = NFAState()
    n_f_a_state_6 = NFAState()
    n_f_a_state_7 = NFAState()
    n_f_a_state_8 = NFAState()
    n_f_a_state_9 = NFAState()
    n_f_a_state_10 = NFAState()
    n_f_a_state_11 = NFAState()
    n_f_a_state_12

# Generated at 2022-06-25 15:06:27.793271
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    pg = PgenGrammar()
    assert pg is not None


if __name__ == "__main__":
    test_PgenGrammar()

# Generated at 2022-06-25 15:06:34.639689
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    # NOTE: the type of this function is inferred
    # by stubtest.test_function_signatures()
    # The types below are added to pass type checks
    parser_generator = ParserGenerator()
    assert isinstance(parser_generator.parse_item(), Tuple[NFAState, NFAState])
    # NOTE: the type of this function is inferred
    # by stubtest.test_function_signatures()
    # The types below are added to pass type checks
    parser_generator = ParserGenerator()
    assert isinstance(parser_generator.parse_item(), Tuple[NFAState, NFAState])
    # NOTE: the type of this function is inferred
    # by stubtest.test_function_signatures()
    # The types below are added to pass type checks
    parser_generator = ParserGener

# Generated at 2022-06-25 15:06:36.780039
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    a_dfa_0 = ParserGenerator(a_nfa_0) # test the constructor
    assert a_dfa_0

# Unit test to verify if the parse method returns a valid value

# Generated at 2022-06-25 15:06:48.073171
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    n_f_a_state_0 = NFAState()
    n_f_a_state_1 = NFAState()
    n_f_a_state_2 = NFAState()
    n_f_a_state_0.addarc(n_f_a_state_1, None)
    n_f_a_state_1.addarc(n_f_a_state_2, None)
    n_f_a_state_2.addarc(n_f_a_state_1, None)
    n_f_a_state_2.addarc(n_f_a_state_0, None)

# Generated at 2022-06-25 15:06:57.799578
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    n_f_a_state_0 = NFAState()
    n_f_a_state_1 = NFAState()
    n_f_a_state_0.addarc(n_f_a_state_1, None)
    dfa_0 = [
        DFAState({n_f_a_state_0: 1}, None)
    ]

    p = ParserGenerator()
    result = p.addfirstsets()

    assert token.NEWLINE == 10, "token.NEWLINE should be 10 for token, got %d instead" % token.NEWLINE
    assert p.grammar.opmap['|'] == token.VBAR, "p.grammar.opmap['|'] should be token.VBAR for p.grammar, got %d instead" % p.grammar.opmap['|']
   

# Generated at 2022-06-25 15:07:02.235483
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    py_gram_gen_2 = ParserGenerator("grammar.txt")
    py_gram_gen_2.gettoken()
    py_gram_gen_2.raise_error("expected (...) or NAME or STRING, got {0}/{1}",
                              py_gram_gen_2.type, py_gram_gen_2.value)
    py_gram_gen_2.parse_rhs()
    py_gram_gen_2.parse_alt()
    py_gram_gen_2.parse_atom()


# Generated at 2022-06-25 15:07:04.961065
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    #pgen = ParserGenerator()
    #pgen.parse_atom()
    pass



# Generated at 2022-06-25 15:07:15.146596
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    pg = PgenGrammar()
    assert pg.symbol2number == {
        "<EOF>": 0,
        "<ERROR>": 1,
        "<UNKNOWN>": 2,
        "EMPTY": 3,
        "error": 4,
    }
    assert pg.number2symbol == {"0": "<EOF>", "1": "<ERROR>", "2": "<UNKNOWN>", "3": "EMPTY", "4": "error"}
    assert pg.symbol2label == {
        "<EOF>": "EOF",
        "<ERROR>": "ERROR",
        "<UNKNOWN>": "UNKNOWN",
    }
    assert pg.start == "start"
    assert pg.keywords == {}
    assert pg.literals == []
    assert pg.tok_rhs_group == {}
   