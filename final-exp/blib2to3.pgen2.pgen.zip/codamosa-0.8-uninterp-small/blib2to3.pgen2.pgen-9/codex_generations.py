

# Generated at 2022-06-25 14:59:58.695922
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    # Test case 0
    pgen_grammar_0 = PgenGrammar()
    source_0 = "[a b] c+"
    # AssertionError
    with pytest.raises(AssertionError):
        assert pgen_grammar_0.parse_item(source_0)
    # Test case 1
    pgen_grammar_1 = PgenGrammar()
    source_1 = "a* b c+"
    assert pgen_grammar_1.parse_item(source_1)



# Generated at 2022-06-25 15:00:05.549451
# Unit test for method dump_nfa of class ParserGenerator

# Generated at 2022-06-25 15:00:07.765204
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    raise NotImplementedError


# Generated at 2022-06-25 15:00:09.833415
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    pgen_grammar_0 = PgenGrammar()
    try:
        pgen_grammar_0.raise_error('test', 'test')
    except SyntaxError:
        pass


# Generated at 2022-06-25 15:00:13.552911
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    # Arrange
    pg = ParserGenerator()
    
    # Act/Assert
    with pytest.raises(SyntaxError, match="This is a test message"):
        pg.raise_error("This is a test message")
       
    # Act/Assert
    with pytest.raises(SyntaxError, match="This is a test message with args"):
        pg.raise_error("This is a test message %s", "with args")


# Generated at 2022-06-25 15:00:17.690060
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    #
    # Call to addfirstsets of class ParserGenerator
    #
    pgen_grammar_0 = PgenGrammar()

    #
    # Verification: The first sets of each symbol is calculated
    #
    if not (pgen_grammar_0.first):
        print("Error: ParserGenerator Failed to calculate first sets")
        return
    return


# Generated at 2022-06-25 15:00:20.720019
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    # Create a class instance
    pgen_grammar_0 = PgenGrammar()
    # Call the method
    pgen_grammar_0.calcfirst(pgen_grammar_0)


# Generated at 2022-06-25 15:00:27.278122
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    # Test args not used
    ParserGenerator.make_label(PgenGrammar, "foo")
    global pgen_grammar_0
    pgen_grammar_0 = PgenGrammar()

    # Unit test for method make_label of class ParserGenerator
    global pgen_grammar_0
    pgen_grammar_0 = PgenGrammar()
    pgen_grammar_0.make_label(PgenGrammar, "foo")


# Generated at 2022-06-25 15:00:28.664813
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    pgen_grammar_0 = PgenGrammar()
    pgen_grammar_0.gettoken()


# Generated at 2022-06-25 15:00:39.558164
# Unit test for method make_grammar of class ParserGenerator

# Generated at 2022-06-25 15:01:14.880842
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    str_0 = '=KJ&K3$P7st\x0by:<$}'
    parser_generator_0 = ParserGenerator(str_0)
    parser_0 = parser_generator_0.generate()
    str_1 = '[1, 2, 3]'
    parser_generator_1 = ParserGenerator(str_1)
    parser_1 = parser_generator_1.generate()
    str_2 = '(1, 2, 3)'
    parser_generator_2 = ParserGenerator(str_2)
    parser_2 = parser_generator_2.generate()
    str_3 = "{'a': 1, 'b': 2}"
    parser_generator_3 = ParserGenerator(str_3)
    parser_3 = parser_generator_

# Generated at 2022-06-25 15:01:20.193065
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    test_case_0()

str_0 = '9(+@z\x7f3cJh39'
parser_generator_0 = ParserGenerator(str_0)
tuple_0 = parser_generator_0.parse_alt()

# Generated at 2022-06-25 15:01:27.013500
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    # Use case 0: Argument value for label is '"', 'a', '"', 'b', '"' and value for c.tokens is {33: 1}
    str_0 = '"a"b"'

    # Instantiate a subclass of ParserGenerator with str_0 as input
    parser_generator_0 = ParserGenerator(str_0)

    # Call method make_label of parser_generator_0 with c.tokens being {33: 1}
    parser_generator_0.make_label({33: 1})


# Generated at 2022-06-25 15:01:31.357018
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    unit_test0_filename = os.path.join(os.path.dirname(__file__), 'unit_test.pgen')
    with open(unit_test0_filename, 'r') as unit_test_data_file:
        unit_test0_data = unit_test_data_file.read()
    unit_test0_grammar = PgenGrammar(unit_test0_data)
    unit_test0_result = unit_test0_grammar.get_nonterminals()
    assert unit_test0_result == {'bit', 'bit_or_expr', 'bit_xor_expr', 'factor', 'power', 'shift_expr', 'term', 'test', 'testlist_comp', 'testlist_star_expr', 'xor_expr'}


# Generated at 2022-06-25 15:01:34.386312
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    # Create a TestCase instance
    test_case_0 = TestCase()
    # Invoke the expect method of class ParserGenerator
    test_case_0.test_expect()


# Generated at 2022-06-25 15:01:41.007993
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    str_0 = '\x1a\x00\x00\x00\x00\x00\x00\x00'
    parser_generator_0 = ParserGenerator(str_0)
    int_0 = parser_generator_0.make_label(parser_generator_0, '\x08')
    assert int_0 == 0


# Generated at 2022-06-25 15:01:48.942468
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    string_0 = '=KJ&K3$P7st\x0by:<$}'
    parser_generator_0 = ParserGenerator(string_0)
    assert parser_generator_0.filename == string_0
    assert parser_generator_0.syntaxerror_obj is None
    assert parser_generator_0.start is None
    assert parser_generator_0.end is None
    assert parser_generator_0.line is None
    assert parser_generator_0.type == 2
    assert parser_generator_0.value == '='
    assert parser_generator_0.begin == (1, 0)
    assert parser_generator_0.end == (1, 1)

# Generated at 2022-06-25 15:01:54.985498
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    try:
        str_0 = '@q3C\x7f\x03/]o!\x02\x00\x0c'
        parser_generator_0 = ParserGenerator(str_0)
        parser_generator_0.expect(token.NAME)
    except AssertionError as e_0:
        print(e_0.args)


# Generated at 2022-06-25 15:02:00.272275
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    str_0 = '"aaa" | "bbbb"\n'
    parser_generator_0 = ParserGenerator(str_0)
    # For the case of expect receiving two arguments
    parser_generator_0.gettoken()
    parser_generator_0.expect(token.STRING)
    parser_generator_0.gettoken()
    parser_generator_0.gettoken()
    parser_generator_0.expect(token.STRING, "bbbb")
    # For the case of expect receiving only one argument
    parser_generator_0.gettoken()
    parser_generator_0.expect(token.ENDMARKER)


# Generated at 2022-06-25 15:02:01.768619
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    # Test method gettoken by manually setting the input and feeding it to the
    # method.
    assert False


# Generated at 2022-06-25 15:02:56.203349
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    string_0 = 'IWpV8=UTA\nXE$}Z2sU'
    with open(string_0, 'r') as file_0:
        parser_generator_0 = ParserGenerator(file_0.read())
    tuple_0 = parser_generator_0.parse_item()


# Generated at 2022-06-25 15:03:01.106388
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    str_0 = ')e\xb6\xdb\xcd\xcb\xbc\xbd\xbb\xb0'
    parser_generator_0 = ParserGenerator(str_0)
    str_1 = '^P$\x86.N\x90^-\x7f\xdb\xd7\xbf\x1a\x8b'
    pgen_grammar_0 = PgenGrammar(str_1)
    parser_generator_0.make_label(pgen_grammar_0, 'X')


# Generated at 2022-06-25 15:03:11.643821
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    list_0 = list()
    item = DFAState(set(), object())
    list_0.append(item)
    item = DFAState(set(), object())
    list_0.append(item)
    item = DFAState(set(), object())
    list_0.append(item)
    item = DFAState(set(), object())
    list_0.append(item)
    item = DFAState(set(), object())
    list_0.append(item)
    item = DFAState(set(), object())
    list_0.append(item)
    item = DFAState(set(), object())
    list_0.append(item)
    item = DFAState(set(), object())
    list_0.append(item)

# Generated at 2022-06-25 15:03:14.172363
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    filename = "Grammar.txt"
    parser_generator = ParserGenerator(filename)
    parser_generator.make_grammar()


# Generated at 2022-06-25 15:03:21.565198
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    str_0 = 'F#%+6uX)<a>0"ZDS*q\x7f:2z`R\x1a\x1a$<xGXCTdR=8c'
    parser_generator_0 = ParserGenerator(str_0)
    parser_generator_0.gettoken()
    assert parser_generator_0.type == token.STRING, parser_generator_0.type
    parser_generator_0.parse_atom()


# Generated at 2022-06-25 15:03:25.240401
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    str_0 = '=KJ&K3$P7st\x0by:<$}'
    parser_generator_0 = ParserGenerator(str_0)
    tuple_0 = parser_generator_0.parse_atom()


# Generated at 2022-06-25 15:03:32.716350
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    str_0 = '[\x00T1>yE6Uo\x00J(]\n'
    parser_generator_0 = ParserGenerator(str_0)
    tuple_0 = parser_generator_0.parse_rhs()
    parser_generator_0.dump_nfa('a', tuple_0[0], tuple_0[1])
    parser_generator_0.dump_nfa('a', tuple_0[0], tuple_0[1])


# Generated at 2022-06-25 15:03:43.882881
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    str_0 = 'OJg'
    # TODO: Why does str_1 = '=AFQ' work but str_1 = '=AFQ\x04' throws an exception?
    # str_1 = '=AFQ\x04'
    str_1 = '=AFQ'
    str_2 = '4p3t\n'
    str_3 = 'r\x7f'
    str_4 = 'y<}'
    str_5 = '\x0f\x01/%\x7f'
    str_6 = 'm{1'
    str_7 = '\x00\x00\x00'
    str_8 = '\x0c\x04\x08\x07\x01'

# Generated at 2022-06-25 15:03:49.729117
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    str_0 = 'zKw=&\x7fQZ^<6(by~6{f'
    parser_generator_0 = ParserGenerator(str_0)
    state_0 = NFAState()
    state_1 = NFAState()
    parser_generator_0.dump_nfa(str_0, state_0, state_1)
    parser_generator_0.dump_nfa(str_0, state_0, state_0)


# Generated at 2022-06-25 15:03:51.369151
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    obj_0 = ParserGenerator()
    tuple_0 = obj_0.parse_atom()


# Generated at 2022-06-25 15:05:52.635090
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    # Create an instance of ParserGenerator
    str_0 = '=KJ&K3$P7st\x0by:<$}'
    parser_generator_0 = ParserGenerator(str_0)
    try:
        parser_generator_0.raise_error(';;')
    except SyntaxError as e_0:
        assert isinstance(e_0, SyntaxError)


# Generated at 2022-06-25 15:05:58.027501
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    str_0 = '=KJ&K3$P7st\x0by:<$}'
    parser_generator_0 = ParserGenerator(str_0)
    tuple_0 = parser_generator_0.parse_rhs()
    converter_0 = Converter()
    parser_generator_0.make_grammar(converter_0)


# Generated at 2022-06-25 15:06:05.010861
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    # Create NFA
    start_state = NFAState()
    final_state = NFAState()
    start_state.addarc(final_state, 'a')

    # Create DFA
    dfa_states = [ DFAState({start_state : 1}, final_state) ]

    # Create ParserGenerator instance
    parser_gen = ParserGenerator("")

    # Call dump_dfa with the DFA and verify output.
    try:
        parser_gen.dump_dfa("name", dfa_states)
    except:
        pass
    assert True



# Generated at 2022-06-25 15:06:07.360295
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    try:
        str_0 = ''
        parser_generator_0 = ParserGenerator(str_0)
        tuple_0 = parser_generator_0.parse_rhs()

        assert False
    except ValueError as exception_0:

        assert exception_0.__str__ == "Empty productions are not allowed."


# Generated at 2022-06-25 15:06:12.752597
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    str_0 = '=KJ&K3$P7st\x0by:<$}'
    parser_generator_0 = ParserGenerator(str_0)
    nfa_state_0, nfa_state_1 = parser_generator_0.parse_alt()
    parser_generator_0.dump_nfa(int(0), nfa_state_0, nfa_state_1)


# Generated at 2022-06-25 15:06:16.698008
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    string_0 = '"~~~BEGIN_"|"_END~~~"|<>"'
    parser_generator_0 = ParserGenerator(string_0)
    list_0 = parser_generator_0.states


# Generated at 2022-06-25 15:06:20.577427
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    with open("Grammar.txt", "r") as f:
        str_0 = f.read()
        parser_generator_0 = ParserGenerator(str_0)
        parser_generator_0.make_grammar()



# Generated at 2022-06-25 15:06:23.705481
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    # Test case with empty string.
    # Error expected: IndexError.
    with pytest.raises(IndexError):
        str_0 = ''
        parser_generator_0 = ParserGenerator(str_0)
        parser_generator_0.addfirstsets()


# Generated at 2022-06-25 15:06:26.139304
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    str_0 = '=KJ&K3$P7st\x0by:<$}'
    parser_generator_0 = ParserGenerator(str_0)
    parser_generator_0.make_grammar()


# Generated at 2022-06-25 15:06:27.655184
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    test_case_0()

if __name__ == "__main__":
    test_ParserGenerator_dump_dfa()