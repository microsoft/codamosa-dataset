

# Generated at 2022-06-25 15:00:30.089600
# Unit test for method make_label of class ParserGenerator

# Generated at 2022-06-25 15:00:38.997432
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    # this_file = os.path.abspath(__file__)
    # sample = os.path.join(os.path.dirname(this_file), "sample.g")
    # p = ParserGenerator()
    # p.parse_file(sample)
    # p.addfirstsets()
    # p.make_dfas()
    # assert len(p.dfas["file_input"]) == 42
    # c = p.make_grammar()
    # assert len(c.states[c.start]) == 42
    pass


# Generated at 2022-06-25 15:00:44.958023
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    parsergenerator_0 = ParserGenerator(None)
    msg = "  "
    try:
        parsergenerator_0.raise_error(msg)
    except SyntaxError as result:
        assert result.text == "  "
    else:
        pytest.fail("Expected an exception to be raised")


# Generated at 2022-06-25 15:00:48.406395
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    # type: () -> None
    with pytest.raises(RuntimeError):
        parser_generator = ParserGenerator()
        parser_generator.gettoken()



# Generated at 2022-06-25 15:00:49.847218
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    assert 0 == 1


# Generated at 2022-06-25 15:00:54.003713
# Unit test for method parse_atom of class ParserGenerator

# Generated at 2022-06-25 15:00:58.833113
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    # Start of test case parse
    test_grammar = "start: 'BEGIN' NAME NAME \n start: 'END' NAME NAME \n"
    test_file = "source.txt"
    parser = ParserGenerator(test_file, test_grammar)
    # End of test case parse
    return parser



# Generated at 2022-06-25 15:01:01.322398
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    s_0 = ParserGenerator(None, None, None)
    s_1 = None
    s_2 = s_0.addfirstsets()


# Generated at 2022-06-25 15:01:05.545861
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    parser_generator_0 = ParserGenerator("file_0")
    try:
        parser_generator_0.expect(0, None)
    except SyntaxError as err:
        assert err.args == ("expected 0/None, got 0/''", ("file_0", 0, 0, "file_0 ? 0 0"))

# Generated at 2022-06-25 15:01:11.225469
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    pg = ParserGenerator()
    # TODO: Write this test
    assert False, "Test not implemented"


# Generated at 2022-06-25 15:01:47.697216
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    pargen = ParserGenerator()
    pargen.gettoken()
    pargen.end = (1, 1)
    pargen.line = "line"
    pargen.filename = "filename"
    pargen.raise_error("error")
    try:
        pargen.raise_error("%s %s %s", 1, 2, 3)
        raise Exception("Did not raise exception as expected")
    except SyntaxError as ex:
        assert ex.args[0] == "1 2 3", "'" + ex.args[0] + "' != '1 2 3'"
        assert ex.args[1] == ("filename", 1, 1, "line")

# Generated at 2022-06-25 15:01:57.619050
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    n_f_a_state_0 = NFAState()
    n_f_a_state_1 = NFAState()
    n_f_a_state_0.addarc(n_f_a_state_1)
    n_f_a_state_1.addarc(n_f_a_state_0)
    dfa_0 = [DFAState({n_f_a_state_0}, n_f_a_state_1)]
    dfa_0[0].addarc(dfa_0[0], None)
    parser_generator_0 = ParserGenerator({'gen' : dfa_0})
    parser_generator_0.addfirstsets()
    assert parser_generator_0.first['gen'] == {None: 1}


# Generated at 2022-06-25 15:02:02.136282
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    parser_generator_0 = ParserGenerator(iter([]), "") # type: ignore
    try:
        parser_generator_0.raise_error("")
    except SyntaxError:
        pass

test_case_0()



# Generated at 2022-06-25 15:02:07.447974
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    r = ParserGenerator(["10"], "")
    check(r.startsymbol == "file_input")
    check(len(r.dfas) == 69)
    check(len(r.first) == 29)
    for name in r.first:
        if name in ("term", "factor"):
            check(r.first[name] == None)
    for name in r.dfas:
        check(name in r.first, "Missing first set for production %s" % name)


# Generated at 2022-06-25 15:02:19.648441
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    n_f_a_state_0 = NFAState()
    n_f_a_state_1 = NFAState()
    n_f_a_state_2 = NFAState()
    n_f_a_state_3 = NFAState()
    n_f_a_state_4 = NFAState()
    n_f_a_state_5 = NFAState()
    n_f_a_state_6 = NFAState()
    n_f_a_state_7 = NFAState()
    parser_generator = ParserGenerator()
    tuple_0 = parser_generator.parse_alt()
    assert tuple_0 == (n_f_a_state_6, n_f_a_state_7)


# Generated at 2022-06-25 15:02:24.761377
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    parser_generator_1 = ParserGenerator()
    n_f_a_state_1, n_f_a_state_2 = parser_generator_1.parse_atom()
    assert isinstance(n_f_a_state_1, NFAState)
    assert isinstance(n_f_a_state_2, NFAState)


# Generated at 2022-06-25 15:02:28.002060
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    c_class_1 = PgenGrammar()

    # Creating a dummy string variable
    x_str_0 = 'a'

    # Calling function make_label
    x_int_0 = ParserGenerator.make_label(c_class_1, x_str_0 )

    # Assertion Error
    raise AssertionError


# Generated at 2022-06-25 15:02:30.498828
# Unit test for function generate_grammar
def test_generate_grammar():
    with open("./test_data/test_grammar.txt", "r") as test_case:
        # Match against the expected value
        expected = test_case.read()
        # Generate the grammar
        output = pprint.pformat(generate_grammar())
        # Check against the expected value
        assert output == expected


# Generated at 2022-06-25 15:02:33.578572
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    pgen_0 = ParserGenerator()
    pgen_0.make_first(pgen_0, '')


# Generated at 2022-06-25 15:02:36.805228
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    py_grammar = grammar.Grammar(grammar.start)
    pg = ParserGenerator(py_grammar, py_grammar.start)
    assert pg is not None


# Generated at 2022-06-25 15:03:32.304508
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    tokenizer = tokenize.tokenize([1, 2, 3])
    iterator = iter(tokenizer)
    next(iterator)
    parser_generator = ParserGenerator(iterator)
    print(parser_generator.gettoken())


# Generated at 2022-06-25 15:03:35.862306
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    print("Test dump_nfa")
    parser_generator_0 = ParserGenerator(iter([(1, 'a', (0, 0), (0, 0), '')]))
    parser_generator_0.dump_nfa("a", n_f_a_state_0, n_f_a_state_0)


# Generated at 2022-06-25 15:03:46.008594
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    global py_grammar_0, py_grammar_1, py_grammar_2, py_grammar_3, py_grammar_4, py_grammar_5, py_grammar_6, py_grammar_7, py_grammar_8, py_grammar_9, py_grammar_10, py_grammar_11, py_grammar_12, py_grammar_13, py_grammar_14, py_grammar_15, py_grammar_16, py_grammar_17, py_grammar_18, py_grammar_19, py_grammar_20, py_grammar_21, py_grammar_22, py_grammar_23, py_grammar_24, py_grammar_25, py_grammar_26, py_grammar_27, py

# Generated at 2022-06-25 15:03:46.631877
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    assert PgenGrammar() != None


# Generated at 2022-06-25 15:03:51.557152
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    n_f_a_state_0 = NFAState()
    n_f_a_state_1 = NFAState()
    n_f_a_state_2 = NFAState()
    n_f_a_state_3 = NFAState()
    n_f_a_state_4 = NFAState()
    n_f_a_state_5 = NFAState()
    n_f_a_state_6 = NFAState()
    n_f_a_state_7 = NFAState()
    n_f_a_state_8 = NFAState()
    n_f_a_state_9 = NFAState()
    n_f_a_state_10 = NFAState()
    n_f_a_state_11 = NFAState()
    n_f_a_

# Generated at 2022-06-25 15:03:55.605252
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    # Create a parser generator
    s = """
    # This is a parser generator
    
    # These are rules

    start:       NAME NUMBER
    stuff:       'a' | 'b'
    other:       thing? | 'c'
    thing:       NAME RULE
    RULE:        'a' | 'b' | 'c'
    """

    p = ParserGenerator(s.splitlines())
    assert p.startsymbol == "start"


# Generated at 2022-06-25 15:03:59.475431
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    t_case_1 = token.Token("T_CASE", 0, 1, "T_CASE", (1, 3), (123, 123), "T_CASE")
    t_case_2 = token.Token("T_CASE", 0, 1, "T_CASE", (1, 3), (123, 123), "T_CASE")
    PgenGrammar(t_case_1)
    PgenGrammar(t_case_2)


# Generated at 2022-06-25 15:04:04.845849
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    names = ["name1", "name2", "name3"]
    dfas = {"name1": PgenGrammar.DFAState({"a": 1}, True), "name2": PgenGrammar.DFAState({"b": 1}, True), "name3": PgenGrammar.DFAState({"c": 1}, True)}
    first = {"name1": {"a": 1}, "name2": {"a": 1}, "name2": {"a": 1}}
    pgen = ParserGenerator(names, dfas, "name2", first)
    pgen.calcfirst("name2")
    assert pgen.first == {"name1": {"a": 1}, "name2": {"a": 1}, "name3": {"c": 1}}


# Generated at 2022-06-25 15:04:11.047322
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    input_pg = ParserGenerator()
    #
    # Define the parser rules!
    #
    input_pg.add_rule("start", ["expr"])
    input_pg.add_rule("expr", ["expr", "expr"])
    input_pg.add_rule("expr", ["(", "expr", ")"])
    input_pg.add_rule("expr", ["[a-zA-Z_]"])
    #
    expected_call_arg = [
        "expr",
        ["expr", "expr"],
        ["(", "expr", ")"],
        ["[a-zA-Z_]"],
    ]
    expected_result = None
    expected_rs = (
        None
    )  # Expected rval for this method.  result of parse_rhs(expected_call

# Generated at 2022-06-25 15:04:22.084840
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    import io
    import tokenize
    n_f_a_state_0 = NFAState()
    n_f_a_state_1 = NFAState()
    n_f_a_state_2 = NFAState()
    n_f_a_state_0.addarc(n_f_a_state_1, "A")
    n_f_a_state_1.addarc(n_f_a_state_2, None)
    n_f_a_state_2.addarc(n_f_a_state_2, "B")
    n_f_a_state_2.addarc(n_f_a_state_1, "B")
    n_f_a_state_2.addarc(n_f_a_state_0, "A")
    n_

# Generated at 2022-06-25 15:06:51.095978
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    n_f_a_state_0 = NFAState()
    n_f_a_state_1 = NFAState()
    n_f_a_state_2 = NFAState()
    n_f_a_state_3 = NFAState()
    n_f_a_state_4 = NFAState()
    n_f_a_state_5 = NFAState()
    n_f_a_state_6 = NFAState()
    n_f_a_state_7 = NFAState()
    n_f_a_state_8 = NFAState()
    n_f_a_state_9 = NFAState()
    dfa_state_0 = DFAState({n_f_a_state_0: 1}, n_f_a_state_9)
    dfa_

# Generated at 2022-06-25 15:07:00.902491
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    global n_f_a_state_0
    n_f_a_state_0 = NFAState()
    # print(n_f_a_state_0.arcs)
    n_f_a_state_0.addarc(n_f_a_state_0, 'NAME')
    n_f_a_state_0.arcs.append((None, n_f_a_state_0))

    # d = {}
    # d.update({('NAME'): 1})
    # assert(n_f_a_state_0.arcs == d)

    parser_generator_0 = ParserGenerator()
    parser_generator_0.first = {'var': None}
    parser_generator_0.dfas = {'var': [n_f_a_state_0]}

# Generated at 2022-06-25 15:07:04.960586
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    """test_ParserGenerator_parse_rhs()"""
    # FIXME: add test code
    n_f_a_state_0 = NFAState()


# Generated at 2022-06-25 15:07:08.760656
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    print("Test dump_nfa")
    parser_generator = ParserGenerator()
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 15:07:14.303170
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    pgen_grammar_0 = PgenGrammar()
    converter_0 = Converter(pgen_grammar_0)
    pgen_grammar_0.symbol2number["name"] = 0
    pgen_grammar_0.labels.append((0, None))
    pgen_grammar_0.symbol2label["name"] = 0
    converter_0.make_first(pgen_grammar_0, "name")


# Generated at 2022-06-25 15:07:22.437818
# Unit test for method parse of class ParserGenerator

# Generated at 2022-06-25 15:07:29.973982
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    pg = ParserGenerator(re)

    test_case = []
    test_case.append((token.NAME, 'foo'))
    test_case.append((token.STRING, '"bar"'))
    test_case.append((token.NAME, 'baz'))

    # test_case 0:
    pg.type = test_case[0][0]
    pg.value = test_case[0][1]

    n_f_a_state_0 = NFAState()
    n_f_a_state_1 = NFAState()
    n_f_a_state_0.addarc(n_f_a_state_1, 'foo')

    result = pg.parse_atom()
    assert len(result) == 2
    assert result[0] == n_f_a_state_

# Generated at 2022-06-25 15:07:30.903310
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    assert False, "Failed to get the case the unit test is looking for"



# Generated at 2022-06-25 15:07:32.019271
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    # Test with nondeterministic automat.
    parser_generator_0 = ParserGenerator(n_f_a_state_0)



# Generated at 2022-06-25 15:07:36.641942
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    """Test :py:meth:`calcfirst` of :py:class:`ParserGenerator` class."""
    n_f_a_state_1 = NFAState()
    n_f_a_state_2 = NFAState()
    n_f_a_state_1.addarc(n_f_a_state_2, 'NAME')
    n_f_a_state_2.addarc(n_f_a_state_1, None)
    n_f_a_state_2.addarc(n_f_a_state_2, '+')
    n_f_a_state_2.addarc(n_f_a_state_2, '*')
    p_gen = ParserGenerator()