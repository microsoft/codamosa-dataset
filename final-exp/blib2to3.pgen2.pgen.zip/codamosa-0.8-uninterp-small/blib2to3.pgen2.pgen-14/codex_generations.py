

# Generated at 2022-06-25 15:00:33.592616
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    # Variables defined here:
    # dfas: {str: [DFAState]}
    # first: {str: {str: int}}
    # generator: <generator object test_ParserGenerator_calcfirst.<locals>._generator at 0x7fb6f5d89fc0>
    # name: str
    # nfa: {str: NFAState}
    # pg: ParserGenerator
    # symbol: str
    # total_set: {str: int}
    pg = ParserGenerator()

# Generated at 2022-06-25 15:00:39.324974
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    assert ParserGenerator().make_label(None, 'A') == 0
    assert ParserGenerator().make_label(None, 'A') == 2
    assert ParserGenerator().make_label(None, 'A') == 4
    assert ParserGenerator().make_label(None, 'A') == 6


# Generated at 2022-06-25 15:00:51.802982
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    parser_generator_0 = ParserGenerator("")
    n_f_a_state_0 = NFAState()
    n_f_a_state_1 = NFAState()
    n_f_a_state_2 = NFAState()
    n_f_a_state_3 = NFAState()
    n_f_a_state_4 = NFAState()
    n_f_a_state_5 = NFAState()
    n_f_a_state_6 = NFAState()
    n_f_a_state_7 = NFAState()
    n_f_a_state_8 = NFAState()
    n_f_a_state_9 = NFAState()
    n_f_a_state_10 = NFAState()
    n_f_a_state

# Generated at 2022-06-25 15:00:53.286150
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    # Nothing to unit test
    pass


# Generated at 2022-06-25 15:01:03.336063
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    # verify that the make_first method returns the expected value
    # (1) DFAs are the same
    pgen_grammar_0 = PgenGrammar()
    n_f_a_state_0 = NFAState()
    n_f_a_state_0.addarc(n_f_a_state_0, "int")
    n_f_a_state_0.addarc(n_f_a_state_0, "@")
    n_f_a_state_0.addarc(n_f_a_state_0, "%")
    n_f_a_state_0.addarc(n_f_a_state_0, "^")
    n_f_a_state_0.addarc(n_f_a_state_0, "&")
    n_f

# Generated at 2022-06-25 15:01:14.817586
# Unit test for function generate_grammar
def test_generate_grammar():
    pgen_grammar = generate_grammar()
    assert pgen_grammar.keywords == {'False': 1, 'None': 0, 'True': 2}
    assert pgen_grammar.literals == {'False': 1, 'None': 0, 'True': 2}

# Generated at 2022-06-25 15:01:26.011208
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    c = PgenGrammar()
    c.labels = []
    c.symbol2label = {}
    c.tokens = {}
    c.keywords = {}
    c.symbol2number = {'dot': 0, 'tokens': 1, 'token': 2, 'NAME': 3, 'NUMBER': 4, 'STRING': 5}
    def test_case_0():
        label = 'token'
        itoken = getattr(token, label, None)
        assert isinstance(itoken, int)
        assert itoken in token.tok_name
        c.labels.append((itoken, None))
        c.tokens[itoken] = len(c.labels) - 1
        ans_0 = len(c.labels) - 1

# Generated at 2022-06-25 15:01:32.436562
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    # Common setup for all tests.
    p_g_p = ParserGenerator()

    # Set up tokenizer generator
    gen = tokenize.tokenize(StringIO("").readline)
    next(gen)  # Go past first ENCODING token

    p_g_p.generator = gen

    # Test case 1: calling parse_atom with an initial self.value of '(' (a '(')
    p_g_p.type, p_g_p.value, p_g_p.begin, p_g_p.end, p_g_p.line = next(
        gen, (tokenize.ENDMARKER, "", (0, 0), (0, 0), "")
    )
    p_g_p.value = "("

# Generated at 2022-06-25 15:01:39.316843
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    class MockParserGenerator:
        def __init__(self):
            NFAState.__init__(self)
        def __eq__(self, other):
            return self is other
    # test
    mock_parser_generator = MockParserGenerator()
    mock_parser_generator.value = '('
    mock_parser_generator.type = token.OP
    mock_parser_generator.parse_rhs = lambda: (NFAState(), NFAState())
    try:
        mock_parser_generator.parse_atom()
    except SyntaxError:
        pass
    else:
        raise Exception('parse_atom() should raise SyntaxError')
    mock_parser_generator.value = 'XYZ'
    mock_parser_generator.type = token.NAME

# Generated at 2022-06-25 15:01:44.035473
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    grammar = """
    a:
        'a'
        b
    b:
        'b'
    c:
        'c'
    """
    parser = ParserGenerator()
    parser.setup_parser(grammar, "test_ParserGenerator_addfirstsets")
    parser.addfirstsets()


# Generated at 2022-06-25 15:02:31.919479
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    """
    Method parse_atom is a utility method for testing parse_item method
    """
    # Initializations
    str_0 = '(['
    parser_generator_0 = ParserGenerator(str_0)
    parser_generator_0.gettoken()
    # Calling and asserting parse_atom method
    result_boolean = parser_generator_0.parse_atom()

# Unit test of parse_atom method

# Generated at 2022-06-25 15:02:35.977886
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    str_0 = '.$e]i8u0}#@+xG'
    parser_generator_0 = ParserGenerator(str_0)
    parser_generator_0.addfirstsets()


# Generated at 2022-06-25 15:02:37.450274
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    test_case_0()

# Unit tests for the rest of the class
# Test case 1

# Generated at 2022-06-25 15:02:40.990070
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    lst_0 = [DFAState({NFAState(): 1}, NFAState()), DFAState({NFAState(): 1}, NFAState())]
    str_0 = 'e'
    parser_generator_0 = ParserGenerator(str_0)
    parser_generator_0.simplify_dfa(lst_0)


# Generated at 2022-06-25 15:02:44.152409
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    str_0 = '.$e]i8u0}#@+xG'
    parser_generator_0 = ParserGenerator(str_0)


# Generated at 2022-06-25 15:02:45.501528
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    test_case_0()


# Testing with coverage

# Generated at 2022-06-25 15:02:57.279485
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    str_0 = '9XxF.t{=%t'
    parser_generator_0 = ParserGenerator(str_0)
    a, z = parser_generator_0.parse_item()
    assert not (isinstance(a, NFAState))
    a, z = parser_generator_0.parse_item()
    assert not (isinstance(a, NFAState))
    a, z = parser_generator_0.parse_item()
    assert isinstance(a, NFAState)
    str_0 = 'E(<+$4f'
    parser_generator_0 = ParserGenerator(str_0)
    a, z = parser_generator_0.parse_item()
    assert isinstance(a, NFAState)

# Generated at 2022-06-25 15:03:03.044592
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    str_0 = 'L9X(Fb&l'
    parser_generator_0 = ParserGenerator(str_0)
    error_msg_0 = 'not-implemented'
    error_msg_1 = 'not-implemented'
    parser_generator_0.dump_dfa(error_msg_0, error_msg_1)


# Generated at 2022-06-25 15:03:11.012316
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    converter = Converter()
    parser_generator = ParserGenerator('')
    assert parser_generator.make_label(converter, '"') == parser_generator.make_label(converter, "'")
    assert parser_generator.make_label(converter, '"') == 0
    assert parser_generator.make_label(converter, '"|"') == 1
    assert parser_generator.make_label(converter, '"<"') == 2
    assert parser_generator.make_label(converter, "'<'") == 2



# Generated at 2022-06-25 15:03:22.369137
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    """Unit test for constructor of class PgenGrammar"""
    # initialization
    str_0 = '.$e]i8u0}#@+xG'
    str_1 = 'y'
    str_2 = 'a'
    str_3 = 'q'
    str_4 = 'c'
    str_5 = '2'
    str_6 = 'p'
    str_7 = 'o'
    str_8 = '#@,z/B8'
    dict_0 = dict()
    # call to __init__ with arguments
    # initialization
    str_9 = '*'
    str_10 = 'Z,H'
    str_11 = 'd'
    str_12 = ')'
    str_13 = '#'
    dict_0 = dict()
    # call to __

# Generated at 2022-06-25 15:05:03.101913
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    str_0 = '.$e]i8u0}#@+xG'
    var_0 = PgenGrammar(str_0)
    
    
    


# Generated at 2022-06-25 15:05:06.368495
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    str_0 = '.$e]i8u0}#@+xG'
    parser_generator_0 = ParserGenerator(str_0)
    parser_generator_0.parse_item()

# Generated at 2022-06-25 15:05:16.596565
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    print('Testing method calcfirst of class ParserGenerator')

    try:
        input_file_0 = './tests/input/test_input_0'
        parser_generator_0 = ParserGenerator(input_file_0)
        parser_generator_0.calcfirst("if_stmt")
        # For the case of parsing if_stmt, the first set should contain
        # one token, if.
        first_set_0 = parser_generator_0.first["if_stmt"]
        assert first_set_0 == {"if" : 1}

    except:
        print("ERROR!")
        traceback.print_exc()
        assert False


# Generated at 2022-06-25 15:05:25.531356
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    str_0 = 'x'
    str_1 = ''''@'''
    str_2 = ''''a'''
    str_3 = ''''z'''
    str_4 = ''''A'''
    str_5 = ''''Z'''
    str_6 = ''''_'''
    str_7 = ''''0'''
    str_8 = ''''9'''
    str_9 = ''''None'''
    str_10 = ''''NAME'''
    str_11 = '_'
    str_12 = 'i'
    str_13 = ''''='''


    # Function call on line 414
    result_0 = parser_generator_0.make_label(converter_0, str_0)
    # Function call on

# Generated at 2022-06-25 15:05:28.174953
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    str_0 = '{C#; mW,T[-D^K@\-p6w+.!|J=uV+d'
    parser_generator_0 = ParserGenerator(str_0)
    parser_generator_0.parse_item()


# Generated at 2022-06-25 15:05:30.458863
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    test_case_0()


# Generated at 2022-06-25 15:05:32.559090
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    assert True


test_case_0()
test_PgenGrammar()

# Generated at 2022-06-25 15:05:33.877778
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    # Test case with expected result
    assert True
    # Test case with exception as expected result
    # assert False


# Generated at 2022-06-25 15:05:40.261448
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    str_0 = '\n        def p_suite(self, p):\n            """\n            suite: simple_stmt | NEWLINE INDENT stmt+ DEDENT\n            """\n            if len(p) == 2:\n                p[0] = ast.Interactive(p[1])\n            else:\n                p[0] = ast.Suite(p[3])\n        '
    parser_generator_0 = ParserGenerator(str_0)
    parser_generator_0.addfirstsets()


# Generated at 2022-06-25 15:05:49.153419
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():

    # Start of test code

    grammar_0 = 'stmts: stmt\nstmt: for_stmt | assign_stmt\nfor_stmt: NAME "=" expr "to" expr\nassign_stmt: NAME "=" expr\nexpr: term ("+"|"-") expr | term\nterm: factor ("*"|"/") term | factor\nfactor: NUMBER | NAME'
    parser_generator_0 = ParserGenerator(grammar_0)
    parser_generator_0.make_pgen()
    parser_generator_0.dump_nfa(stmts, for_stmt)

    # End of test code

