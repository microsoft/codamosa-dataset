

# Generated at 2022-06-25 15:00:27.187124
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    test_ParserGenerator = ParserGenerator(
        """
        # A one-token lookahead parser.
        #
        # Written by Fredrik Lundh, May 1997
        #
        # Modified by Guido van Rossum, July 1998:
        # Added error-recovery support.
        #
        # Modified by Bill Tutt, April 2000:
        # Added support for single-quoted string literals.
        # <snip>
        #
        # This grammar is the basis for a simple expression parser.
        # It's not perfect, so don't go overboard with this code.
        """
    )
    from io import BytesIO
    from test.support import captured_stdout
    from tokenize import tokenize_loop
    from pgen2.generator import Generator, token_from_tokenno

# Generated at 2022-06-25 15:00:34.911003
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    filename = "../../Lib/parser/pgen2/parser.out"
    p_file = open(filename, "rb")
    p_parser = ParserGenerator()
    p_dfas, p_startsymbol = p_parser.parse()
    p_parser.addfirstsets()
    p_converter = PgenConverter()
    p_converter.make_grammar(p_dfas, p_startsymbol)
    p_converter.grammar.dump()

    p_name = 'funcdef'
    p_dfa = p_dfas['funcdef']
    p_dfa_state_0 = DFAState({n_f_a_state_0: True}, n_f_a_state_0)

# Generated at 2022-06-25 15:00:44.143819
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    # case 0
    _n_f_a_state_0 = NFAState()
    _n_f_a_state_1 = NFAState()
    _n_f_a_state_0.addarc(_n_f_a_state_1, 'c')
    _a, _z = ParserGenerator(None, None, None, None, None, None).parse_item()
    assert (_a == _n_f_a_state_0 and _z == _n_f_a_state_1)


# Generated at 2022-06-25 15:00:47.265518
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    # Input:
    c = PgenGrammar()
    name = "?name"
    # Output:
    assert c.make_first(c, name) == {}


# Generated at 2022-06-25 15:00:58.832817
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    n_f_a_state_0 = NFAState()
    n_f_a_state_1 = NFAState()
    n_f_a_state_2 = NFAState()
    n_f_a_state_3 = NFAState()
    n_f_a_state_4 = NFAState()
    n_f_a_state_5 = NFAState()
    n_f_a_state_6 = NFAState()
    # Declaration of local variable a
    a = None
    # Declaration of local variable z
    z = None
    parser_generator_0 = ParserGenerator("<string>")
    # '\n'
    token_0 = (token.NEWLINE, '\n', (1, 1), (1, 2), '\n')
    # ''
    token

# Generated at 2022-06-25 15:01:03.266593
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    c_parser_generator_0 = ParserGenerator()
    c_parser_generator_0.type = 314159
    c_parser_generator_0.value = "314159"
    c_parser_generator_0.expect(314159)

if __name__ == "__main__":
    main(sys.stdin, sys.stdout, sys.stderr, sys.argv)
    test_ParserGenerator_expect()
else:
    # We're being imported; make the module globals be attributes of
    # the module, instead of of __main__.
    globals().update(locals())

# Generated at 2022-06-25 15:01:05.920358
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    p = ParserGenerator()
    dfa = [DFAState({NFAState(): 1}, NFAState())]
    p.dump_dfa('test string', dfa)


# Generated at 2022-06-25 15:01:13.356177
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():

    # Create NFAState instance
    n_f_a_state_0 = NFAState()

    # Call method
    try:
        ParserGenerator.dump_dfa("name", [n_f_a_state_0])
    except Exception as inst:
        raise AssertionError("Failure in call to method dump_dfa of class ParserGenerator")


# Generated at 2022-06-25 15:01:24.503961
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    """Test 'make_label' method of class ParserGenerator."""
    grammar = get_sample_grammar()
    case0 = ParserGenerator(grammar)
    pgen_grammar = PgenGrammar()
    assert case0.make_label(pgen_grammar, "['[']") == 0
    assert case0.make_label(pgen_grammar, "['~=']") == 1
    assert case0.make_label(pgen_grammar, "['<']") == 2
    assert case0.make_label(pgen_grammar, "['>']") == 3
    assert case0.make_label(pgen_grammar, "['!=']") == 4
    assert case0.make_label(pgen_grammar, "['.']") == 5
    assert case0

# Generated at 2022-06-25 15:01:31.632008
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    """Test for method expect of class ParserGenerator"""
    n_f_a_state_0 = NFAState()
    n_f_a_state_1 = NFAState()
    n_f_a_state_0.addarc(n_f_a_state_1, None)
    d_f_a_state_0 = DFAState({n_f_a_state_0: 1}, n_f_a_state_1)
    d_f_a_state_1 = DFAState({n_f_a_state_1: 1}, n_f_a_state_1)
    d_f_a_state_0.addarc(d_f_a_state_1, None)
    parser_generator_0 = ParserGenerator([d_f_a_state_0])

# Generated at 2022-06-25 15:02:39.467703
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():

    class NFAState:
        def __init__(self):
            pass

        def __eq__(self, other):
            return (type(self) == type(other)) and (self.__dict__ == other.__dict__)

        def __ne__(self, other):
            return not self.__eq__(other)

        def __repr__(self):
            return repr(self.__dict__)

    class DFAState:
        def __init__(self, nfaset, finish):
            self.nfaset = nfaset
            self.isfinal = finish in nfaset
            self.arcs = {}
            self.arcsorder = []


# Generated at 2022-06-25 15:02:43.516831
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    pgen = ParserGenerator('test_ParserGenerator_gettoken', tokenize.tokenize(StringIO('name: alfa').readline))
    assert pgen.value is None
    pgen.gettoken()
    assert pgen.value == 'name'
    pgen.gettoken()
    assert pgen.value == ':'
    pgen.gettoken()
    assert pgen.value == 'alfa'
    pgen.gettoken()
    assert pgen.value is None


# Generated at 2022-06-25 15:02:48.249800
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    # global tokenize, token, NFAState, DFAState, ParserGenerator
    n_f_a_state_0 = NFAState()
    n_f_a_state_1 = NFAState()
    n_f_a_state_2 = NFAState()
    n_f_a_state_3 = NFAState()
    n_f_a_state_4 = NFAState()
    n_f_a_state_5 = NFAState()
    n_f_a_state_6 = NFAState()
    n_f_a_state_7 = NFAState()
    n_f_a_state_8 = NFAState()
    n_f_a_state_9 = NFAState()
    n_f_a_state_10 = NFAState()
    n

# Generated at 2022-06-25 15:02:58.660033
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    nfa_case_0_0 = NFAState()
    nfa_case_0_1 = NFAState()

    dfa_case_0_0 = DFAState({nfa_case_0_0: 1}, nfa_case_0_0)
    dfa_case_0_1 = DFAState({nfa_case_0_1: 1}, nfa_case_0_1)

    dfa = [dfa_case_0_0, dfa_case_0_1]

    class_to_test = ParserGenerator()
    class_to_test.simplify_dfa(dfa)

    assert len(dfa) == 1

# Generated at 2022-06-25 15:03:01.866592
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    test_case__0_n_f_a_state_0 = test_case_0()


# Generated at 2022-06-25 15:03:08.923129
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    n_f_a_state_0 = NFAState()
    n_f_a_state_1 = NFAState()
    dfa_state_0 = DFAState(set([]), n_f_a_state_0)
    dfa_state_1 = DFAState(set([]), n_f_a_state_0)
    parser_generator_0 = ParserGenerator(set([]), set([]), set([]), set([]))
    parser_generator_0.addfirstsets()


# Generated at 2022-06-25 15:03:13.519530
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    #  Test that the result of make_first is a dict.
    n_f_a_state_0 = NFAState()
    p_c = ParserGenerator()
    p_c_make_first = p_c.make_first(n_f_a_state_0, '')
    assert (isinstance(p_c_make_first, dict) == True)

# Generated at 2022-06-25 15:03:16.966122
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    expected_value_0 = None
    actual_value_0 = test_case_0()
    assert actual_value_0 == expected_value_0

if __name__ == "__main__":
    test_ParserGenerator_dump_dfa()

# Generated at 2022-06-25 15:03:27.574367
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    """
    This unit test is derived from Python 3.2.3 Grammar/Grammar
    """

    # Source code of Python grammar

# Generated at 2022-06-25 15:03:31.869634
# Unit test for method __eq__ of class DFAState
def test_DFAState___eq__():
    method = getattr(DFAState, "__eq__", None)
    assert method is not None
    method.__dict__.clear()
    test_case_0()


# Generated at 2022-06-25 15:04:43.179508
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    n_f_a_state_0 = NFAState()
    n_f_a_state_1 = NFAState()
    n_f_a_state_0.addarc(n_f_a_state_1)
    n_f_a_state_0.addarc(n_f_a_state_0)
    n_f_a_state_1.addarc(n_f_a_state_0)
    n_f_a_state_1.addarc(n_f_a_state_1, 'a')
    d_f_a = ParserGenerator.make_dfa(None, n_f_a_state_0, n_f_a_state_1)
    d_f_a_state1 = DFAState(n_f_a_state_1)

# Generated at 2022-06-25 15:04:44.810089
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    py_grammar_0 = ParserGenerator()
    py_grammar_0.parse()


# Generated at 2022-06-25 15:04:46.185602
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    assert True  # No code in dump_nfa, can't unit test


# Generated at 2022-06-25 15:04:53.021895
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    import _ast

# Generated at 2022-06-25 15:04:56.621517
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    file_name = "top_tr_parser.txt"
    parser_generator = ParserGenerator()
    assert set(token.tok_name) == set(token.__dict__)
    parser_generator.parse(file_name)
    # fails because:
    # 1) Token '*' is missing in opmap
    # 2) Token '<<' is missing in opmap
    # 3) Token '>>' is missing in opmap
    # 4) Token '..' is missing in opmap

# Generated at 2022-06-25 15:05:00.086140
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    parser_generator_0 = ParserGenerator("")
    parser_generator_0.raise_error("expected %s/%s, got %s/%s", token.OP, "*", token.OP, "^")


# Generated at 2022-06-25 15:05:05.407978
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    pg = ParserGenerator()
    pg.type = token.NAME
    pg.value = "abc"
    pg.gettoken = lambda : None
    a, z = pg.parse_atom()
    assert not a.arcs
    assert not z.arcs
    assert a.arcs2 == [(None, z)]
    assert z.arcs2 == [(None, a)]


# Generated at 2022-06-25 15:05:06.409652
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    # XXX
    return


# Generated at 2022-06-25 15:05:16.631283
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    n_f_a_state_0 = NFAState()
    n_f_a_state_1 = NFAState()
    n_f_a_state_0.addarc(n_f_a_state_1)
    n_f_a_state_2 = NFAState()
    n_f_a_state_0.addarc(n_f_a_state_2)
    n_f_a_state_3 = NFAState()
    n_f_a_state_0.addarc(n_f_a_state_3)
    n_f_a_state_4 = NFAState()
    n_f_a_state_3.addarc(n_f_a_state_4)
    n_f_a_state_5 = NFAState()
    n_

# Generated at 2022-06-25 15:05:25.567359
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    # Note that this test also covers the method dump_dfa
    nfa_state_0 = NFAState()
    nfa_state_1 = NFAState()
    nfa_state_2 = NFAState()
    nfa_state_3 = NFAState()
    nfa_state_0.addarc(nfa_state_1, 'word')
    nfa_state_1.addarc(nfa_state_2)
    nfa_state_2.addarc(nfa_state_3, 'word')
    nfa_state_3.addarc(nfa_state_1)
    parser_generator_0 = ParserGenerator()
    str_0 = ''