

# Generated at 2022-06-25 15:00:15.139024
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    with open(test_grammar) as grammar_file:
        t = ParserGenerator(grammar_file)
    # XXX: fix test case
    # t.parse()


# Generated at 2022-06-25 15:00:27.140879
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    # Set up:
    state_0 = DFAState({"closure_30": 1, "closure_31": 1, "closure_32": 1, "closure_33": 1, "closure_34": 1, "closure_35": 1, "closure_36": 1, "closure_37": 1, "closure_38": 1, "closure_39": 1, "closure_40": 1, "closure_41": 1, "closure_42": 1, "closure_43": 1, "closure_44": 1}, "closure_34")

# Generated at 2022-06-25 15:00:34.861633
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    pgen = ParserGenerator()

# Generated at 2022-06-25 15:00:40.111480
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    p = ParserGenerator()
    names = list(p.dfas.keys())
    names.sort()
    for name in names:
        if name not in p.first:
            p.calcfirst(name)
        # print name, p.first[name].keys()


# Generated at 2022-06-25 15:00:52.478011
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    # Create a parser generator for parsing Python grammar
    pg = ParserGenerator()
    # Create a converter
    converter = PgenGrammar()
    # Get the labels defined in the Python grammar
    labels = converter.labels
    # Get the symbol2number dict
    symbol2number = converter.symbol2number
    # Make labels for the Python grammar
    pg.make_label(converter, "test")
    # Check if the token NAME is available in the symbol2number dict
    assert token.NAME in list(symbol2number.values())
    # Check if the symbol "test" is available in the symbol2number dict
    assert "test" in list(symbol2number.keys())
    # Check if the label "NAME" is available in the labels list
    assert (token.NAME, None) in labels

# Test case for

# Generated at 2022-06-25 15:00:55.892200
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    pgen = ParserGenerator("", "", ['a', 'b'])
    pgen_addfirstsets = lambda : pgen.addfirstsets()
    return pgen, pgen_addfirstsets


# Generated at 2022-06-25 15:01:05.505408
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    # dfa is a list of DFAState instances
    a = NFAState()
    b = NFAState()
    c = NFAState()
    d = NFAState()

    a.addarc(b, "a")
    a.addarc(c, "b")
    b.addarc(d, "c")
    c.addarc(d, "d")

    dfa = [DFAState(a.closure(), d), DFAState(b.closure(), d), DFAState(c.closure(), d)]

    # dfa is a list of DFAState instances
    p = ParserGenerator()
    assert p.simplify_dfa(dfa) == None
    assert len(dfa) == 2
    assert dfa[0].arcs["a"] == dfa[1]

# Generated at 2022-06-25 15:01:11.201661
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    pgen_grammar = generate_grammar()

    pgen_grammar.dump_nfa(
        "factor",
        make_state(
            None,
            [
                make_state(
                    make_state(
                        make_state(
                            None,
                            [
                                make_state(
                                    make_state(
                                        make_state(None, []),
                                    ),
                                ),
                            ],
                            "]",
                        ),
                    ),
                    ")",
                ),
            ],
            "factor",
        ),
        make_state(None, [], "factor"),
    )


# Generated at 2022-06-25 15:01:22.213786
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    p = ParserGenerator()
    p.fc = PgenGrammar()
    p.make_first(p.fc, 's')
    assert p.fc.labels == [(1, None), (2, 'b'), (3, 'a')]
    assert p.fc.tokens == {}
    assert p.fc.keywords == {}
    assert p.fc.symbol2label == {'s': 0, 'a': 2, 'b': 1}
    assert p.fc.symbol2number == {'s': 0, 'a': 1, 'b': 2}
    p.make_first(p.fc, 'a')

# Generated at 2022-06-25 15:01:25.335134
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    pg = ParserGenerator()
    data = """
            start: 'x'
            """
    pg.parse_grammar(data)
    pg.dfas = {'start': []}  # Hack
    pg.addfirstsets()


# Generated at 2022-06-25 15:02:04.735857
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    # Test that the class PgenGrammar has at least one method
    assert len(dir(PgenGrammar)) > 1



# Generated at 2022-06-25 15:02:11.725337
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    pgen_grammar_0 = generate_grammar()
    # Test make_dfa
    pgen_grammar_0.dfas["test_dfa"] = [pgen_grammar_0.dfas["test_dfa"][0],
                                       pgen_grammar_0.dfas["test_dfa"][0]]
    dfa_for_test_dfa = pgen_grammar_0.make_dfa(pgen_grammar_0.dfas["test_dfa"][0],
                                               pgen_grammar_0.dfas["test_dfa"][1])

# Generated at 2022-06-25 15:02:21.964596
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    pg = ParserGenerator()
    class DFAState:
        def __init__(self, state_name: str) -> None:
            self.state_name = state_name

        def __repr__(self) -> str:
            return self.state_name

    pg.dump_nfa(
        "test_case",
        DFAState("A"),
        DFAState("B"),
    )

    pg.dump_dfa(
        "test_case",
        [DFAState("A"), DFAState("B")],
    )

if __name__ == "__main__":
    test_case_0()
    test_ParserGenerator_dump_nfa()

# Generated at 2022-06-25 15:02:30.439089
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    parser = ParserGenerator()
    parser.gettoken = lambda: None
    parser.value = '*'
    parser.type = None
    parser.raise_error = lambda msg, *args: None
    parser.parse_atom = lambda: (None, None)
    a, z = parser.parse_item()
    assert a == z, (a, z)
    parser.value = '('
    a, z = parser.parse_item()
    assert a is not z, (a, z)
    parser.value = '['
    a, z = parser.parse_item()
    assert a is not z, (a, z)


# Generated at 2022-06-25 15:02:40.029192
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    pg_0 = ParserGenerator()
    pgen_grammar_0 = pg_0.make_grammar()
    assert isinstance(pgen_grammar_0, PgenGrammar)
    assert isinstance(pgen_grammar_0.keywords, dict)
    assert isinstance(pgen_grammar_0.labels, list)
    assert isinstance(pgen_grammar_0.start, int)
    assert isinstance(pgen_grammar_0.states, list)
    assert isinstance(pgen_grammar_0.symbol2label, dict)
    assert isinstance(pgen_grammar_0.symbol2number, dict)
    assert isinstance(pgen_grammar_0.tokens, dict)


# Generated at 2022-06-25 15:02:45.160035
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    from . import token
    from .grammar import ParserGenerator
    parser = ParserGenerator()
    parser.dfas = {
        "foo": [
            DFAState({}, None),
            DFAState({}, None),
        ]
    }
    parser.dump_nfa("foo", [])


# Generated at 2022-06-25 15:02:52.515577
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    # Arrange
    generate_grammar()
    parser_generator = ParserGenerator()
    parser_generator.value = "}"

    # Act
    a, z = parser_generator.parse_alt()

    # Assert
    assert isinstance(a, NFAState)
    assert isinstance(z, NFAState)
    assert a == z
    assert a.arcs == []


# Generated at 2022-06-25 15:02:54.225996
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    assert ParserGenerator(tokenize.generate_tokens(StringIO("1").readline))



# Generated at 2022-06-25 15:02:58.762760
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    pg = ParserGenerator()
    names = ['S', 'S2']
    name = 'S'
    dfa = DFA('S')
    dfa.construct_automaton(0)
    pg.dfas = {'S': dfa, 'S2': dfa}
    pg.first = {'S': None, 'S2': None}
    pg.calcfirst(name)
    assert isinstance(pg.first[name], dict)


# Generated at 2022-06-25 15:03:02.780442
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    pgen = ParserGenerator(Path("test.py"), "encoding")
    assert pgen.parse_atom() == (a, z)


# Generated at 2022-06-25 15:03:43.787784
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    from blib2to3.pgen2.pgen import PgenGrammar



# Generated at 2022-06-25 15:03:51.063449
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    nfa_states_0: List[NFAState] = [NFAState(), NFAState(), NFAState()]
    start: NFAState = nfa_states_0[0]
    finish: NFAState = nfa_states_0[2]
    start.addarc(nfa_states_0[1], "a")
    nfa_states_0[1].addarc(nfa_states_0[2], "b")
    dfa_0 = ParserGenerator.make_dfa(start, finish)
    assert len(dfa_0) == 2


if __name__ == "__main__":
    generate_grammar()

# Generated at 2022-06-25 15:03:55.096037
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    grammar = r"""
        a : 'a'
    """
    parser_generator = ParserGenerator()
    parser_generator.make_parser(grammar)


# Generated at 2022-06-25 15:04:01.068850
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    pgen = ParserGenerator()
    pgen.add_production(["expr"], ["expr", "+", "expr"])
    pgen.add_production(["expr"], ["expr", "-", "expr"])
    pgen.add_production(["expr"], ["expr", "*", "expr"])
    pgen.add_production(["expr"], ["(", "expr", ")"])
    pgen.add_production(["expr"], ["INTEGER"])
    pgen.add_production(["expr"], ["FLOAT"])
    pgen.add_production(["INTEGER"], ["INTNUM"])
    pgen.add_production(["FLOAT"], ["FLOATNUM"])
    pgen.generate_table()



# Generated at 2022-06-25 15:04:09.302260
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    if sys.version_info < (3, 3):
        return
    # Set up a test case
    pgen_grammar_0 = generate_grammar()
    # Invoke the method under test
    result = pgen_grammar_0.parse()
    # Make sure it's what we expect
    dfa_0 = ParserGenerator._build_dfa()
    startsymbol_0 = ParserGenerator._build_startsymbol()
    assert dfa_0 == result[0]
    assert startsymbol_0 == result[1]


# Generated at 2022-06-25 15:04:19.572559
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    nfa_states, nfa_start, nfa_finish = build_nfa_1()

    parser_generator = ParserGenerator()
    dfa_states = parser_generator.make_dfa(nfa_start, nfa_finish)

    assert dfa_states[0].nfaset == {
        nfa_start,
        nfa_states[2],
        nfa_states[4],
        nfa_states[6],
        nfa_finish,
    }
    assert dfa_states[1].nfaset == {nfa_states[1], nfa_states[3]}
    assert dfa_states[2].nfaset == {nfa_states[5], nfa_states[7]}


# Generated at 2022-06-25 15:04:31.294470
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    parser_generator = ParserGenerator()
    tokenizer = tokenize.tokenize(io.BytesIO(
        b"SELECT % (SELECT % (SELECT % (SELECT %)) | 'z'))"
    ).readline)
    generator = parser_generator.tokenize(tokenizer)

    # SELECT % (SELECT % (SELECT % (SELECT %)) | 'z'))
    parser_generator.gettoken()
    assert parser_generator.value == "SELECT"
    assert parser_generator.type == token.NAME
    parser_generator.gettoken()
    assert parser_generator.value == "%"
    assert parser_generator.type == token.OP
    parser_generator.gettoken()
    assert parser_generator.value == "SELECT"
    assert parser_generator.type == token.NAME
   

# Generated at 2022-06-25 15:04:33.938359
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    # Create an instance of ParserGenerator
    obj = ParserGenerator(None, None)
    # Call dump_nfa
    #obj.dump_nfa(name, start, finish)
    raise NotImplementedError


# Generated at 2022-06-25 15:04:44.349111
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    pg = ParserGenerator()
    a = DFAState({"a" : 1, "b" : 1, "c" : 1}, True)
    a.addarc("a", a)
    a.addarc("b", a)
    a.addarc("c", a)
    b = DFAState({"a" : 1, "b" : 1, "c" : 1}, False)
    b.addarc("a", b)
    b.addarc("b", b)
    b.addarc("c", b)
    c = DFAState({"a" : 1, "b" : 1}, False)
    c.addarc("a", c)
    c.addarc("b", c)
    c.addarc("c", c)

# Generated at 2022-06-25 15:04:52.864504
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    start_symbol = 'MSTART'

    pgen_grammar_0 = generate_grammar()
    parser_generator_0 = ParserGenerator(pgen_grammar_0, start_symbol)
    nfa_start_0 = NFAState()
    newline_0 = nfa_start_0.addarc(NFAState(), 'NEWLINE')
    rule_0 = newline_0.addarc(NFAState(), 'RULE')
    rule_1 = newline_0.addarc(NFAState(), 'RULE')
    endmarker_0 = rule_1.addarc(NFAState(), 'ENDMARKER')
    nfa_finish_0 = endmarker_0

# Generated at 2022-06-25 15:05:52.837208
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    # ParserGenerator.dump_dfa() checked against the pure-Python
    # parser
    import os

    import test.test_grammar

    delta = {}
    g = test.test_grammar.Grammar()
    parser = ParserGenerator(g)
    g.dfas = parser.dfas
    test_dir = os.path.dirname(__file__) or os.curdir
    for rule in g.parsing_rules:
        if rule in ("root", "eval_input", "single_input"):
            continue
        fname = os.path.join(test_dir, rule + ".grammar")
        try:
            with open(fname) as f:
                data = f.read()
        except IOError:
            continue

# Generated at 2022-06-25 15:06:03.148618
# Unit test for method expect of class ParserGenerator

# Generated at 2022-06-25 15:06:10.696517
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    pgen = ParserGenerator("")
    testdata = [
        ("(", 'expected (...), got OP/"("',),
        ("+", 'expected (...), got OP/"+"',),
        ("abc", 'expected (...), got NAME/"abc"',),
        ("[']", 'expected (...), got NAME/"["',),
        ('[""]',
        'expected (...), got OP/"["',),
    ]

    pass_ = True  # flag to track success, fail

# Generated at 2022-06-25 15:06:21.768457
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    pgen_grammar_0 = generate_grammar()
    assert PgenGrammar == type(pgen_grammar_0)
    pgen_grammar_1 = generate_grammar()
    assert PgenGrammar == type(pgen_grammar_1)
    pgen_grammar_2 = generate_grammar()
    assert PgenGrammar == type(pgen_grammar_2)
    pgen_grammar_3 = generate_grammar()
    assert PgenGrammar == type(pgen_grammar_3)
    pgen_grammar_4 = generate_grammar()
    assert PgenGrammar == type(pgen_grammar_4)
    pgen_grammar_5 = generate_grammar()

# Generated at 2022-06-25 15:06:24.951850
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    parser = ParserGenerator()
    parser.addfirstsets()
    grammar = parser.make_grammar()


# Generated at 2022-06-25 15:06:30.184669
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    pg = ParserGenerator()
    # test case 1
    test_dfa = []
    test_dfa.append(DFAState({0: 1, 1: 1}, False))
    test_dfa.append(DFAState({2: 1}, False))
    test_dfa.append(DFAState({3: 1}, False))
    test_dfa[0].addarc(test_dfa[1], '0')
    test_dfa[0].addarc(test_dfa[2], '1')
    pg.simplify_dfa(test_dfa)
    assert len(test_dfa) == 2


# Generated at 2022-06-25 15:06:32.001735
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    pg = ParserGenerator()
    ParserGenerator.dump_dfa(pg, "j", [DFAState({}, None), DFAState({}, None)])


# Generated at 2022-06-25 15:06:33.620033
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    pgen_grammar_0 = generate_grammar()
    pgen_grammar_0.make_label(1, 2)


# Generated at 2022-06-25 15:06:37.615082
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    # pgen_grammar_0 = generate_grammar()
    pgen_parser = ParserGenerator()
    pgen_parser.gettoken()
    msg = "expected %s/%s, got %s/%s"
    args = (tokenize.COMMENT, None, tokenize.NL, None)
    try:
        pgen_parser.raise_error(msg, *args)
    except SyntaxError as err:
        assert msg % args in str(err)
    else:
        raise AssertionError


# Generated at 2022-06-25 15:06:39.853454
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    # pgen_grammar_0 = ParserGenerator.make_grammar()
    pass


# Generated at 2022-06-25 15:08:38.448595
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    # Test case #0
    assert True
