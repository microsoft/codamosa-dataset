

# Generated at 2022-06-25 15:00:46.547970
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    parser_generator = ParserGenerator(None, '', '', None)
    parser_generator.value = "("
    parser_generator.gettoken = lambda:0
    parser_generator.parse_rhs = lambda:0
    parser_generator.gettoken = lambda:0
    parser_generator.parse_atom = lambda:0
    parser_generator.raise_error = lambda *args, **kwargs:0
    parser_generator.gettoken = lambda:0
    parser_generator.gettoken = lambda:0
    parser_generator.gettoken = lambda:0
    parser_generator.parse_item()

if __name__ == "__main__":
    test_ParserGenerator_parse_item()
    test_case_0()

# Generated at 2022-06-25 15:00:48.495097
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
	# data
	code = "<> ^@"
	pgen = ParserGenerator(code)
	assert pgen.parse_atom() == (NFAState(0), NFAState(1))


# Generated at 2022-06-25 15:00:59.509158
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    s = ' if 1: pass'
    g = ParserGenerator.generator(s, '<string>')
    while True:
        if g.type == 1:
            break
        g.gettoken()
    assert g.value == 'if'
    assert g.begin == (0, 0)
    assert g.end == (0, 2)
    g.gettoken()
    assert g.value == '1'
    assert g.type == 3
    assert g.begin == (0, 3)
    assert g.end == (0, 4)
    assert g.line == ' if 1: pass\n'
    g.gettoken()
    assert g.value == ':'
    assert g.type == 4
    g.gettoken()
    assert g.type == 1
    assert g.value == 'pass'

# Generated at 2022-06-25 15:01:06.711963
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    text = """"
File:       lib2to3/pgen2/pgen.py

Module:     lib2to3.pgen2.pgen

Version:    $Id: pgen.py,v 1.1 2008/07/20 22:18:43 eddy Exp $

Purpose:    Driver for generating a parser (rather than using pypy's Parser/
            Grammar classes).
"""
    parser = ParserGenerator(text)
    result = parser.parse()
    assert len(result) == 2
    assert isinstance(result[0], dict)


# Generated at 2022-06-25 15:01:16.145307
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    pg = ParserGenerator()

# Generated at 2022-06-25 15:01:19.194122
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    pgen_grammar_1 = generate_grammar()


# Generated at 2022-06-25 15:01:26.103912
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    parser_generator = ParserGenerator()
    try:
        parser_generator.gettoken()
    except AttributeError as ae:
        print(ae)

    parser_generator.generator = ((1, "1"), (2, "2"))
    parser_generator.gettoken()
    assert parser_generator.type == 1
    assert parser_generator.value == "1"
    parser_generator.gettoken()
    assert parser_generator.type == 2
    assert parser_generator.value == "2"


# Generated at 2022-06-25 15:01:32.525814
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    nfa_states = [NFAState() for _ in range(4)]
    nfa_states[0].addarc(nfa_states[1], 'a')
    nfa_states[1].addarc(nfa_states[2], 'b')
    nfa_states[2].addarc(nfa_states[3])

    dfa_states = []  # type: List[DFAState]
    dfa_states.append(DFAState({nfa_states[0]:1}, nfa_states[3]))
    dfa_states.append(DFAState({nfa_states[1]:1}, nfa_states[3]))
    dfa_states.append(DFAState({nfa_states[2]:1}, nfa_states[3]))

# Generated at 2022-06-25 15:01:39.365659
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    c = PgenGrammar()
    # ParserGenerator.make_label arguments are: (self, c: PgenGrammar, label: Text)
    # Test for non-zero length label
    # Test for label containing non-alphabetic characters
    assert 1 == c.make_label(c, "1")

    # Test for label containing an alphabetic character
    # Test for label containing an alphabetic character that has a uppercase equivalent
    # Test for label containing an alphabetic character that has a uppercase equivalent but is not uppercase
    # Test for label that is equal to an existing label in c.symbol2label
    assert 1 == c.make_label(c, "NAME")

    # Test for label that is not present in c.symbols2label
    # Test for label that is not present in c.

# Generated at 2022-06-25 15:01:40.346091
# Unit test for function generate_grammar
def test_generate_grammar():
    assert generate_grammar()  # We don't currently test anything about the result


# Generated at 2022-06-25 15:02:13.767453
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    lines = ['a: b {c} | d "e"']
    pg = ParserGenerator()
    (dfa, start) = pg.parse_grammar(lines)
    pg.dump_nfa('a', dfa[0], dfa[-1])


# Generated at 2022-06-25 15:02:15.640060
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    pg = ParserGenerator()
    assert isinstance(pg, ParserGenerator)



# Generated at 2022-06-25 15:02:22.523856
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    start = NFAState()
    finish = NFAState()
    start.addarc(finish, "a")
    parser = ParserGenerator()
    dfa = parser.make_dfa(start, finish)
    assert len(dfa) == 1
    assert dfa[0].nfaset == {start: 1, finish: 1}
    assert dfa[0].arcs == {"a": (dfa[0], None)}


# Generated at 2022-06-25 15:02:25.397333
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    pgen_grammar_0_obj = ParserGenerator()
    pgen_grammar_0_obj.make_first(pgen_grammar_0_obj, 'NAME')


# Generated at 2022-06-25 15:02:35.266200
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    # Test with simple grammar
    grammar_simple = """
        start: NAME
        """
    # Test with empty grammar
    grammar_empty = ""

    # Test with simple grammar with a regular expression in it
    grammar_regexp = """
        start: NAME | STRING
        """

    # Test with simple grammar with multiple regular expressions in it
    grammar_regexps = """
        start: NAME | NAME STRING | STRING
        """

    # Test with simple grammar with zero or one regular expression in it
    grammar_regexps_optional = """
        start: NAME | NAME?
        """

    # Test with simple grammar with zero or more regular expressions in it
    grammar_regexps_any = """
        start: NAME | NAME*
        """
    # Test with simple grammar with one or more regular expressions in it
    grammar_re

# Generated at 2022-06-25 15:02:40.962384
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    parser_generator = ParserGenerator()
    cases = (
        (
            ("simple1.txt", "simple1.py"),
            ("simple2.txt", "simple2.py"),
            ("simple3.txt", "simple3.py"),  # from issue3440
            ("simple4.txt", "simple4.py"),  # from issue3440 with tabs
            ("simple5.txt", "simple5.py"),  # from issue3440 with multiline
            ("issue10191.txt", "issue10191.py"),  # from issue10191
        ),
    )
    for gram_file, py_file in cases[0]:
        gram_data = get_data(gram_file)
        py_data = get_data(py_file)
        converter = parser_generator.parse(gram_data)

# Generated at 2022-06-25 15:02:50.370286
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    global pgen_grammar_0
    pgen_grammar_0 = generate_grammar()
    global pgen_grammar_1
    pgen_grammar_1 = generate_grammar()
    # This test is based on the grammar of python 3.7
    # The rules of the grammar are at the end of this file.
    pgen_grammar_0.parse_item()
    pgen_grammar_1.parse_item()
    pgen_grammar_0.parse_item()
    pgen_grammar_1.parse_item()

    # Invoke default method to try to generate other tests


# Generated at 2022-06-25 15:02:53.627181
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    pgen_grammar_0 = generate_grammar()
    assert pgen_grammar_0 is not None


# Generated at 2022-06-25 15:02:59.467283
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    g = ParserGenerator()
    g.dfas = {
        "s": [
            DFAState(
                {
                    NFAState(): 1,
                    NFAState(arcs={("a", NFAState())}): 1,
                    NFAState(arcs={("b", NFAState())}): 1,
                },
                False,
            )
        ]
    }
    g.calcfirst("s")
    assert g.first == {"s": {"a": 1, "b": 1}}


# Generated at 2022-06-25 15:03:07.268489
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    pgen_grammar_0 = generate_grammar()
    grammar_0 = open("../../3.7/Lib/py_grammar.txt").read()
    pgen_0 = ParserGenerator(grammar_0, pgen_grammar_0)
    pgen_0.parse()
    assert len(pgen_0.dfas.keys()) == 59
    assert len(pgen_0.first.keys()) == 59


# Generated at 2022-06-25 15:04:01.097035
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():

    str = "a = 2 # this is a comment"
    list = tokenize.generate_tokens(StringIO(str).readline)
    p = ParserGenerator()
    p.generator = list

    p.gettoken()

    assert p.type == token.NAME
    assert p.value == "a"
    assert p.begin == (0, 0)
    assert p.end == (0, 1)
    assert p.line == "a = 2 # this is a comment\n"

    p.gettoken()

    assert p.type == token.OP
    assert p.value == "="
    assert p.begin == (0, 2)
    assert p.end == (0, 3)
    assert p.line == "a = 2 # this is a comment\n"

    p.gettoken()



# Generated at 2022-06-25 15:04:05.694427
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    pg = ParserGenerator()
    # input: string, filename, start
    tokens = tokenize.generate_tokens(BytesIO('x = "abc"\nNM = NM | "-"').readline)
    pg.generator = tokens
    pg.type, pg.value = token.INDENT, ''
    pg.filename = ''
    pg.begin, pg.end, pg.line = (0, 1, 0), (0, 1, 0), ''
    # expected: None
    assert pg.gettoken() is None
    assert pg.type == token.NAME and pg.value == 'x'
    assert pg.begin == (0, 1, 0)
    assert pg.end == (0, 2, 0)
    assert pg.line == 'x = "abc"\n'

# Generated at 2022-06-25 15:04:10.909149
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    from mypy.pgen2.token import token
    from mypy.pgen2.pgen import ParserGenerator
    pg = ParserGenerator({'a': [[(token.NAME, 'b'), (token.NAME, 'c')],
                                [(token.NAME, 'b'), (token.NAME, 'a')]],
                          'b': [[(token.NAME, 'd')],
                                [(token.NAME, 'd'), (token.NAME, 'b')]]},
                         'a')
    assert (pg.first['a'] == {'d': 1})
    assert (pg.first['b'] == {'d': 1})


# Generated at 2022-06-25 15:04:12.012679
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    parser_generator = ParserGenerator()
    parser_generator.parse_alt()


# Generated at 2022-06-25 15:04:19.573070
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    """Test method calcfirst in class ParserGenerator."""

    # Generate a dummy grammar so that a ParserGenerator is created.
    pgen_grammar_0 = generate_grammar()

    # Construct an instance of class ParserGenerator.
    pgen_obj_0 = ParserGenerator(pgen_grammar_0)

    # Call a method of the instance to verify that it works.
    pgen_obj_0.calcfirst("x")

    print("Test of method calcfirst in class ParserGenerator: success")


# Generated at 2022-06-25 15:04:23.943529
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    pg = ParserGenerator()
    pg.dfas = {}
    pg.first = {}
    pg.calcfirst("a")
    # FIXME: write this test!
    # assert <value> == <expected_value>


# Generated at 2022-06-25 15:04:26.910234
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    parser_generator = ParserGenerator('test.py', None, None)
    parser_generator.parse_alt


# Generated at 2022-06-25 15:04:29.365611
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    try:
        pgen_grammar_0 = PgenGrammar(["\r\n"])
    except Exception as e:
        print(str(e))
    else:
        assert False


# Generated at 2022-06-25 15:04:36.301605
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    pgen_grammar_0 = generate_grammar()
    # Test attribute startsymbol is set to 'moduledef'
    assert pgen_grammar_0.startsymbol == 'moduledef'
    # Test attribute first is set to {'decorator': {'@': 1}, 'classdef': {'class': 1}, 'expr_stmt': {'break': 1, 'continue': 1, 'return': 1, 'raise': 1, 'yield': 1, 'del': 1, 'import': 1, 'global': 1, 'nonlocal': 1, 'assert': 1}, 'simple_stmt': {'break': 1, 'continue': 1, 'return': 1, 'raise': 1, 'yield': 1, 'del': 1, 'import': 1, 'global': 1, 'nonlocal': 1, 'assert': 1},

# Generated at 2022-06-25 15:04:46.186289
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    pgen_grammar_1 = ParserGenerator()
    pgen_grammar_1.calcfirst('file_input')
    pgen_grammar_1.calcfirst('expr_stmt')
    pgen_grammar_1.calcfirst('classdef')
    pgen_grammar_1.calcfirst('small_stmt')
    pgen_grammar_1.calcfirst('expr_stmt')
    pgen_grammar_1.calcfirst('suite')
    pgen_grammar_1.calcfirst('stmt')
    pgen_grammar_1.calcfirst('atom')
    pgen_grammar_1.calcfirst('term')
    pgen_grammar_1.calcfirst('atom')
    pgen_grammar_1.cal