

# Generated at 2022-06-25 15:00:32.152223
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar(): # pylint: disable=too-many-branches
    f = io.StringIO(TEST_GRAMMAR)
    pgen = ParserGenerator()
    pgen.generate_grammar(f.name)
    assert pgen.goals == {'file_input'}
    assert pgen.startsymbol == 'file_input'
    assert isinstance(pgen.st, Grammar)
    assert isinstance(pgen.first, dict)
    assert len(pgen.first) == len(pgen.st._symbol2number)
    # Number of keys in first == number of dfas:
    assert len(pgen.first) == len(pgen.dfas)
    # PgenGrammar.pgen_grammar == pgen.st, but
    # PgenGrammar.pgen

# Generated at 2022-06-25 15:00:34.093920
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    pg = ParserGenerator()
    pg.raise_error("Not implemented yet")

# Generated at 2022-06-25 15:00:39.951127
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    global n_f_a_state_0
    test_case_0()
    # CASE: NFA is empty
    d_f_a_1 = ParserGenerator.dump_nfa(n_f_a_state_0, '', '', True)
    assert d_f_a_1 == None


# Generated at 2022-06-25 15:00:41.076827
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    test_case_0()


# Generated at 2022-06-25 15:00:46.406764
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    print("Testing ParserGenerator.dump_nfa()")
    pg = None
    dump_nfa = pg.dump_nfa('name', NFAState(), NFAState())
    assert dump_nfa == None
    print("ParserGenerator.dump_nfa() passes")


# Generated at 2022-06-25 15:00:54.151779
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    # See _pytest.nodes.Item.
    nfa_state_1 = NFAState()
    test_module_0 = ParserGenerator(nfa_state_1)
    type_0 = int(10)
    value_0 = Optional[""]
    assert test_module_0.expect(type_0, value_0) == "", "Return value: " + repr(test_module_0.expect(type_0, value_0))


# Generated at 2022-06-25 15:00:58.180998
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    a = NFAState()
    b = NFAState()
    a.addarc(b, "a")
    a.addarc(b)
    parser_generator_0 = ParserGenerator()
    parser_generator_0.dump_nfa("a", a, b)

# Generated at 2022-06-25 15:01:02.215100
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    from ply.parsetok import ParserGenerator
    from ply.lex import LexToken

    # Prepare arguments:
    tok = LexToken("token", "value")

    # Execute method:
    result = ParserGenerator.parse_alt(tok)

    assert result is None


# Generated at 2022-06-25 15:01:04.660881
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    assert False


# /Users/dalkescientific/Dev/python/unpyc3/unpyc3/unpyc3/pgen_main.c

# Generated at 2022-06-25 15:01:14.991350
# Unit test for method dump_dfa of class ParserGenerator

# Generated at 2022-06-25 15:01:42.413101
# Unit test for function generate_grammar
def test_generate_grammar():
    pgen = ParserGenerator()
    grammar = pgen.make_grammar()
    print(grammar)


if __name__ == "__main__":
    test_generate_grammar()

# Generated at 2022-06-25 15:01:46.469353
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    p = ParserGenerator()
    g = p.make_grammar()
    assert g is not None, "test_ParserGenerator_make_grammar"


if __name__ == "__main__":
    setup()
    try:
        test_ParserGenerator_make_grammar()
    finally:
        teardown()

# Generated at 2022-06-25 15:01:49.708572
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    pgen_grammar_0 = PgenGrammar(pgen_grammar_0)
    raise NotImplementedError("test_PgenGrammar")


# Generated at 2022-06-25 15:01:54.170735
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    file = open('test_make_grammar.py')
    try:
        g = ParserGenerator().make_grammar(file)
    finally:
        file.close()
    assert g.__class__ is PgenGrammar

# Generated at 2022-06-25 15:01:57.100696
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    dfa = n_f_a_state_0
    c = test_case_0()
    test_case_0().make_label(c,label)
    print("Test for method make_label() performed successfully.")


# Generated at 2022-06-25 15:02:04.044279
# Unit test for function generate_grammar
def test_generate_grammar():
    grammar = generate_grammar()
    assert isinstance(grammar, PgenGrammar)
    assert isinstance(grammar.dfas["single_input"][0].nfaset, dict)
    assert isinstance(grammar.labels[0], tuple)
    assert isinstance(grammar.first["eval_input"], dict)
    assert isinstance(grammar.dfas["single_input"][0].arcs, dict)
    assert isinstance(grammar.dfas["simple_stmt"][0], DFAState)
    assert isinstance(grammar.dfas["subscript"][0], DFAState)
    assert isinstance(grammar.dfas["classdef"][0].nfaset, dict)
    assert isinstance(grammar.labels[0], tuple)

# Generated at 2022-06-25 15:02:08.723546
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    PG = ParserGenerator()
    n_f_a_state_0 = NFAState()
    NFAState_1 = NFAState()
    n_f_a_state_0.addarc(NFAState_1)
    expected_0 = (n_f_a_state_0, NFAState_1)
    actual = PG.parse_rhs()
    assert actual == expected_0


# Generated at 2022-06-25 15:02:18.870592
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    par_ge_0 = ParserGenerator()
    pa_ge_0 = PgenGrammar()
    label_0 = "ab"
    pa_ge_0.labels.append((token.ENCODING, None))
    pa_ge_0.labels.append((token.ENCODING, None))
    pa_ge_0.labels.append((token.ENCODING, None))
    pa_ge_0.labels.append((token.ENCODING, None))

    label_0 = par_ge_0.make_label(pa_ge_0, label_0)

    # Asserts
    assert label_0 == 4


# Generated at 2022-06-25 15:02:23.655265
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    """
    Unit test for method ParserGenerator.dump_nfa
    """
    parser_generator_0 = ParserGenerator()
    try:
        parser_generator_0.dump_nfa(1, 2, 3)
    except NameError:
        print('test_case_1 failed')


# Generated at 2022-06-25 15:02:26.504585
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    test_object_0 = ParserGenerator()
    test_dfa_0 = [DFAState((), None), DFAState((), None)]
    test_object_0.simplify_dfa(test_dfa_0)


# Generated at 2022-06-25 15:04:29.767189
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    parser_generator_0 = ParserGenerator()
    dfa_0 = []
    name_0 = ""
    parser_generator_0.dump_dfa(
        name_0, dfa_0
    )


# Generated at 2022-06-25 15:04:36.496053
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    parser_generator_instance_0_0 = ParserGenerator()
    parser_generator_instance_0_0.grammar = """
    expr:
        | expr '*' factor (100)
        | expr '/' factor (101)
        | expr '+' term   (102)
        | expr '-' term   (103)
        | term
    term:
        | term '*' factor (110)
        | term '/' factor (111)
        | factor
    factor:
        | '(' expr ')'
        | '-' factor (113)
        | NUMBER
    """
    parser_generator_instance_0_0.parse()

# Generated at 2022-06-25 15:04:46.390792
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    try:
        converter = Converter()
        pgen_grammar = converter.make_grammar()
    except:
        assert False, "Failure to instantiate ParserGenerator"
    try:
        (symbol_name, pgen_grammar) = pgen_grammar
        parser_generator = ParserGenerator(symbol_name, pgen_grammar, 'start')
        first_dict = parser_generator.first
    except:
        assert False, "Failure to instantiate ParserGenerator"

# Generated at 2022-06-25 15:04:53.228520
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    n_f_a_state_0 = NFAState()
    n_f_a_state_1 = NFAState()
    n_f_a_state_2 = NFAState()
    n_f_a_state_3 = NFAState()
    n_f_a_state_4 = NFAState()
    n_f_a_state_5 = NFAState()
    n_f_a_state_6 = NFAState()
    n_f_a_state_7 = NFAState()
    n_f_a_state_8 = NFAState()
    n_f_a_state_9 = NFAState()
    n_f_a_state_10 = NFAState()
    n_f_a_state_11 = NFAState()
    n_f_a_

# Generated at 2022-06-25 15:04:56.261664
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    file_name = "example_grammar.txt"
    parser_generator = ParserGenerator(file_name)
    parser_generator.gettoken()
    parser_generator.parse_rhs()


# Generated at 2022-06-25 15:05:06.326034
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    n_f_a_state_1 = NFAState()
    n_f_a_state_2 = NFAState()
    n_f_a_state_3 = NFAState()
    n_f_a_state_1.addarc(n_f_a_state_2, '"(')
    n_f_a_state_1.addarc(n_f_a_state_3)
    n_f_a_state_2.addarc(n_f_a_state_3, '"*"')
    n_f_a_state_3.addarc(n_f_a_state_2, '"+"')
    n_f_a_state_2.addarc(n_f_a_state_3, '"-"')
    n_f_a_state

# Generated at 2022-06-25 15:05:10.915041
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    test_case_0()
    parser_generator_0 = ParserGenerator()
    generator_0 = tokenize.tokenize(StringIO('foo').readline)
    parser_generator_0.generator = generator_0
    parser_generator_0.gettoken()



# Generated at 2022-06-25 15:05:19.429580
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    n_f_a_state_0 = NFAState()
    n_f_a_state_1 = NFAState()
    n_f_a_state_2 = NFAState()
    n_f_a_state_3 = NFAState()
    n_f_a_state_1.addarc(n_f_a_state_3, 'x')
    n_f_a_state_2.addarc(n_f_a_state_3, 'y')
    n_f_a_state_0.addarc(n_f_a_state_2, 'x')
    n_f_a_state_0.addarc(n_f_a_state_1, None)

# Generated at 2022-06-25 15:05:27.353029
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    c = PgenGrammar()
    name = 'expr'
    dfa = ParserGenerator.make_dfa(n_f_a_state_0, n_f_a_state_0)
    c.symbol2number[name] = 0
    c.symbol2label[name] = 0
    c.labels.append((0, None))
    c.states.append([])
    c.dfas[0] = (ParserGenerator.make_dfa(n_f_a_state_0, n_f_a_state_0), ParserGenerator.make_first(c, name))
    return


# Generated at 2022-06-25 15:05:33.051106
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    # Setup test case
    n_f_a_state_0 = NFAState()
    n_f_a_state_0.addarc(n_f_a_state_0, "hello")
    n_f_a_state_0.addarc(n_f_a_state_0)
    n_f_a_state_1 = NFAState()
    n_f_a_state_2 = NFAState()
    n_f_a_state_0.addarc(n_f_a_state_1, "world")
    n_f_a_state_1.addarc(n_f_a_state_2, "foo")
    n_f_a_state_2.addarc(n_f_a_state_1)
    # Call method

# Generated at 2022-06-25 15:07:56.323437
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    parser_generator_0 = ParserGenerator()
    parser_generator_1 = ParserGenerator()
    parser_generator_2 = ParserGenerator()
    parser_generator_1.symbols = OrderedDict()
    parser_generator_1.first = OrderedDict()
    parser_generator_1.dfas = OrderedDict()
    parser_generator_2.symbols = OrderedDict()
    parser_generator_2.first = OrderedDict()
    parser_generator_2.dfas = OrderedDict()
    parser_generator_0.symbols = OrderedDict()
    parser_generator_0.first = OrderedDict()
    parser_generator_0.dfas = OrderedDict()
    parser_gener

# Generated at 2022-06-25 15:08:04.447503
# Unit test for method make_dfa of class ParserGenerator

# Generated at 2022-06-25 15:08:13.109393
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    pgen_grammar_0 = PgenGrammar()
    n_f_a_state_0 = NFAState()
    n_f_a_state_0.name = "def"
    n_f_a_state_1 = NFAState()
    n_f_a_state_0.arcs.append((n_f_a_state_1, "0"))
    n_f_a_state_1.arcs.append((n_f_a_state_0, None))
    pgen_grammar_0.states.append([n_f_a_state_0])
    pgen_grammar_0.start = 0
    label = "__main__"
    # label should be in symbol2label

# Generated at 2022-06-25 15:08:15.081900
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    parser_generator_0 = ParserGenerator("a")
    parser_generator_0.gettoken()


# Generated at 2022-06-25 15:08:15.843075
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    pass



# Generated at 2022-06-25 15:08:22.511008
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    grammar_str = ' b: "a" | "b" "c" | "c"\n'
    test_parser_generator = ParserGenerator()
    test_parser_generator.scan(StringIO(grammar_str))
    a, z = test_parser_generator.parse_rhs()
    assert isinstance(a, NFAState)
    assert isinstance(z, NFAState)


# Generated at 2022-06-25 15:08:29.399442
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    dummy_symbol_table = None
    dummy_startsymbol = None
    dummy_dfas = None
    dummy_first = {
        'atom': {'(': 1, 'NAME': 1, 'STRING': 1},
        'item': {'(': 1, 'NAME': 1, 'STRING': 1, '[' : 1},
        'rhs': {'(': 1, 'NAME': 1, 'STRING': 1, '[' : 1},
        'alt': {'(': 1, 'NAME': 1, 'STRING': 1, '[' : 1},
        'mstart': {'(': 1, 'NAME': 1, 'STRING': 1, '[' : 1},
    }

# Generated at 2022-06-25 15:08:39.338403
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    """Tests dump_dfa method of class ParserGenerator"""
    d_f_a_state_0 = DFAState(closure(start), finish)
    d_f_a_state_1 = DFAState()
    d_f_a_state_2 = DFAState()
    d_f_a_state_2.nfaset = n_f_a_state_0
    d_f_a_state_2.isfinal = isfinal
    d_f_a_state_3 = DFAState()
    d_f_a_state_3.nfaset = n_f_a_state_0
    d_f_a_state_3.isfinal = isfinal
    d_f_a_state_3.arcs = arcs
    d_f_a_state_4