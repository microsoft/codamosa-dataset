

# Generated at 2022-06-11 19:46:49.662519
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    """Method dump_dfa"""
    # For coverage
    pg = ParserGenerator()
    dfa = [
        DFAState({NFAState(): 1}, NFAState()),
        DFAState({NFAState(): 1, NFAState(): 1}, NFAState())
    ]
    pg.dump_dfa("test", dfa)

# Generated at 2022-06-11 19:46:51.459032
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    pggr = PgenGrammar()



# Generated at 2022-06-11 19:47:01.696100
# Unit test for function generate_grammar
def test_generate_grammar():
    from glob import glob
    from mypy.misc import generate_pickle_data, write_pickle, pickle_filename
    for fn in glob("Grammar*"):
        print(fn)
        # XXX Do we want a 'Mypy'?
        grammar = generate_grammar(Path(fn))
        fn = pickle_filename(fn, 'PyPy')
        if fn.exists():
            continue
        outfile = fn.with_suffix(fn.suffix + '.new')
        generate_pickle_data(grammar, outfile)
        write_pickle(grammar, outfile)
        outfile.rename(fn)


if __name__ == "__main__":
    test_generate_grammar()
    print("Done")

# Generated at 2022-06-11 19:47:10.415108
# Unit test for method calcfirst of class ParserGenerator

# Generated at 2022-06-11 19:47:20.895367
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    # This function tests the method calcfirst of class ParserGenerator.
    # The tests rely on the internal layout of the methods of class
    # ParserGenerator and will probably fail if ParserGenerator is
    # changed in some way.

    # Create a ParserGenerator object with a simple parsing table.
    # The table has only one rule:
    #     stmt : simple_stmt
    # The set FIRST(stmt) consists of only one symbol: "simple_stmt".
    pg = ParserGenerator()
    pg.dfas = {"stmt": [DFAState({NFAState(): 1}, NFAState())],
               "simple_stmt": [DFAState({NFAState(): 1}, NFAState())]}
    pg.startsymbol = "stmt"

    # Calculate the first sets.
   

# Generated at 2022-06-11 19:47:29.205829
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    pg = ParserGenerator()
    dfa = pg.make_dfa(pg.make_nfa("a"), pg.make_nfa("b"))
    assert [state.arcs for state in dfa] == [{"a": dfa[0]}]
    dfa = pg.make_dfa(pg.make_nfa("a|b"), pg.make_nfa("b"))
    assert [state.arcs for state in dfa] == [{"a": dfa[0], "b": dfa[0]}]
    dfa = pg.make_dfa(pg.make_nfa("a(b|c)"), pg.make_nfa("d"))

# Generated at 2022-06-11 19:47:36.281844
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    pg = ParserGenerator()
    a, b, c, d, e, f, g, h, i, j, k, l, m, n, o, p, q, r, s, t, u, v, w, x, y, z = [
        DFAState() for _ in range(26)
    ]
    dfa = [a, b, c, d]
    a.addarc(b, "a")
    a.addarc(c, "a")
    a.addarc(c, "b")
    b.addarc(d)
    c.addarc(b, "b")
    c.addarc(d)
    pg.simplify_dfa(dfa)
    assert len(dfa) == 3
    assert dfa[0].arcs[("a", b)]

# Generated at 2022-06-11 19:47:39.491765
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    # Test case for a range; this test case intentionally exposes a bug in the
    # optimizer, which is fixed in calcfirst.
    pg = ParserGenerator("test_ParserGenerator_parse_alt", ["abc_def"])
    a, z = pg.parse_alt()
    assert a.arcs == [(("a", "b"), a.arcs[0][1])]

    print("test_ParserGenerator_parse_alt() succeeded")



# Generated at 2022-06-11 19:47:47.314438
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    pg = ParserGenerator()
    c = pg.make_converter()
    # Test keywords
    assert c.make_label(c, '"and"') == c.make_label(c, '"and"')
    assert c.make_label(c, '"and"') != c.make_label(c, '"or"')
    assert c.make_label(c, '"and"') != c.make_label(c, '"if"')
    # Test named tokens
    assert c.make_label(c, '"NUMBER"') == c.make_label(c, '"NUMBER"')
    assert c.make_label(c, '"NUMBER"') != c.make_label(c, '"NAME"')

# Generated at 2022-06-11 19:47:58.200497
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    import pgen2.grammar
    pg = pgen2.grammar.ParserGenerator(
        """
        file_input: (NEWLINE | stmt)* ENDMARKER
        stmt: simple_stmt | compound_stmt
        simple_stmt: NAME '=' NAME ';'
        compound_stmt: if_stmt | while_stmt
        if_stmt: 'if' NAME ':' suite
        while_stmt: 'while' NAME ':' suite
        suite: simple_stmt | NEWLINE INDENT stmt+ DEDENT
        """
    )
    g = pg.parse()
    c = g.converter
    labels = c.labels
    assert labels[c.make_label(c, "NAME")] == (token.NAME, None)

# Generated at 2022-06-11 19:48:38.521520
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    c = PgenGrammar()
    dummy_label = tuple()
    c.labels = [dummy_label]*256
    c.tokens = {33: 0, 34: 1, 35: 2}
    assert c.make_label(c, "!") == 33
    assert c.make_label(c, '"') == 34
    assert c.make_label(c, "#") == 35
    assert c.make_label(c, "0") == 256
    assert c.make_label(c, "asdf") == 257
    assert c.make_label(c, "f") == 258
    assert c.make_label(c, "+") == 259
    assert c.make_label(c, "||") == 0
    assert c.make_label(c, "|=") == 260
   

# Generated at 2022-06-11 19:48:43.828425
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    pg = ParserGenerator()
    start = NFAState()
    z = NFAState()
    start.addarc(z, '"abc"')
    start.addarc(z, '"def"')
    start.addarc(z, '"ghi"')
    dfa = pg.make_dfa(start, z)
    import pprint

    pprint.pprint(dfa)

# Generated at 2022-06-11 19:48:49.627997
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    gen = ParserGenerator()
    gen.setup()

    # testcase: 1
    # The sequence of tokens is:
    #     NAME (':') NAME (NEWLINE)
    gen.generator = gen._tokenize("foo: bar\n")
    a, z = gen.parse_rhs()
    assert a.arcs == [(None, gen.nfastates[2])]
    assert z.arcs == []
    assert gen.nfastates[1].arcs == [('bar', gen.nfastates[3])]
    assert gen.nfastates[2].arcs == [('foo', gen.nfastates[1])]
    assert gen.nfastates[3].arcs == []

    # testcase: 2
    # The sequence of tokens is:
    #     NAME (':') NAME ('|

# Generated at 2022-06-11 19:48:57.703910
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    import pgen2.token
    import pgen2.grammar
    import pgen2.parser
    import pgen2.pgen
    import pgen2.driver
    import pgen2.converter
    import pgen2.parse
    import pgen2.parsetok

    # The method being tested is make_first:
    #   def make_first(self, c: PgenGrammar, name: Text) -> Dict[int, int]:
    # Invocation is:
    #   c.symbol2label[name] = self.make_first(c, name)

    # create the parser generator
    pgen = pgen2.pgen.ParserGenerator()

    # create the parser
    parser = pgen.create_parser()
    # create DFA table which includes information about first sets
   

# Generated at 2022-06-11 19:49:02.310405
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    pg = ParserGenerator()
    c = pg.converter()
    pg.addfirstsets()
    assert pg.make_first(c, 'ALIAS') == {1: 1, 2: 1, 4: 1, 5: 1}
    assert pg.make_first(c, 'atom') == {
        1: 1,
        2: 1,
        3: 1,
        4: 1,
        5: 1,
        6: 1,
        7: 1,
        8: 1,
        9: 1,
        10: 1,
        11: 1,
        12: 1,
        13: 1,
        14: 1,
    }

# Generated at 2022-06-11 19:49:13.592857
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    import PickleGrammar
    g = ParserGenerator()
    g.run(PickleGrammar.grammar, PickleGrammar.pickleOpMap)
    # Test make_first when the first set only contains keywords.
    # The first set of stringtuple2singlequote is {'tuple': 1,
    # 'string': 1} and the first set of stringtuple2singlequote_mk
    # should be the same.
    assert g.first["stringtuple2singlequote_mk"] == {
        'string': 1,
        'tuple': 1,
    }
    # Test make_first when the first set only contains token numbers.
    # The first set of stringtuple2singlequote is {'tuple': 1,
    # 'string': 1} and the first set of stringtuple2singlequote

# Generated at 2022-06-11 19:49:23.071247
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    pg = ParserGenerator()

    def diff(expected: Sequence["NFAState"], actual: Sequence["NFAState"]):
        for i, state in enumerate(expected):
            if actual[i] != state:
                print(i, ":")
                print("  expected:", str(state))
                print("    actual:", str(actual[i]))
                print()

    # Check parse_item, using NFA directly
    # ------------------------------------
    #   a -- b

# Generated at 2022-06-11 19:49:33.935279
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    from io import StringIO
    from tokenize import tokenize
    from token import COMMENT, NAME, STRING, NL, OP
    from _ast import PyCF_ONLY_AST

    def setUp(self):
        # Build an AST
        a = compile("1 + 2", "?", "eval", PyCF_ONLY_AST)
        # Serialize the AST
        s = dump(a)
        # Build a generator
        g = tokenize(StringIO(s).readline)

        # Create a node
        e = Expression()
        e._fields = ('parent', 'left', 'right')
        # Parse the serialized AST into a node
        e.parent = e
        e.left = Name(id='a', ctx=Load())
        e.right = Num(n=1)
        # Serialize the node


# Generated at 2022-06-11 19:49:36.237583
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
  # build a ParserGenerator
  pg = ParserGenerator()
  # TODO


# Generated at 2022-06-11 19:49:46.816061
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    p = ParserGenerator()
    start = NFAState(None)
    finish = NFAState(None)
    start.addarc(finish)
    a, b, c, d, e, f, g, h, i, j, k, l, m, n, o, p, q, r, s, t, u, v, w, x, y, z, aa = [
        NFAState(None)
        for x in range(26)
    ]
    start.addarc(a, "a")
    a.addarc(b, "b")
    a.addarc(d, "d")
    b.addarc(c, "c")
    c.addarc(finish)
    d.addarc(e, "e")
    e.addarc(f, "f")


# Generated at 2022-06-11 19:50:28.232606
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    from . import pgen
    pg: pgen.ParserGenerator = pgen.ParserGenerator()
    dfas, startsymbol = pg.parsestring("""
    a: 'a' (b | d e)* 'c'
    b: 'b'
    c: x | y | z
    x: 'x'
    y: 'y'
    z: 'z'
    d: 'd'
    e: 'e'""")
    pg.addfirstsets()
    pg.make_parse_table()
    pg.dump_nfa(dfas["a"])
    pg.dump_nfa(dfas["b"])
    pg.dump_nfa(dfas["c"])
    pg.dump_nfa(dfas["x"])

# Generated at 2022-06-11 19:50:40.799403
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    from StringIO import StringIO


# Generated at 2022-06-11 19:50:45.538891
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    pg = ParserGenerator(None)
    pg.dfas = {'foo': [DFAState({0: 1}, False), DFAState({}, False)], 'bar': [DFAState({1: 1}, False), DFAState({}, False)]}
    pg.addfirstsets()
    assert pg.first == {'foo': {1: 1}, 'bar': {0: 1}}

# Generated at 2022-06-11 19:50:56.694873
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    # XXX This is quite incomplete

    pg = ParserGenerator()
    pg.add("S", ["a"])
    pg.add("S", ["b"])
    pg.add("S", ["S", "S"])
    pg.add("S", [""])
    pg.add("S", ["a", "S"])
    pg.add("S", ["b", "S"])
    pg.compute_first()
    pg.addfirstsets()
    print("FIRST")
    for name in sorted(pg.first.keys()):
        print(name, pg.first[name])

    pg = ParserGenerator()
    pg.add("S", ["a"])
    pg.add("S", ["b"])
    pg.add("S", ["S", "S"])
    pg.add

# Generated at 2022-06-11 19:51:10.236067
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    lines = [
        "def foo() -> int:\n",
        '    return "bar"'
    ]
    tokenizer = tokenize.generate_tokens(lines.__iter__().__next__)
    p = ParserGenerator(tokenizer, "<testfile>")
    a, z = p.parse_atom()
    assert a.arcs == [(None, z)]

    lines = [
        "def foo() -> int:\n",
        '    return "bar"'
    ]
    tokenizer = tokenize.generate_tokens(lines.__iter__().__next__)
    p = ParserGenerator(tokenizer, "<testfile>")
    a, z = p.parse_atom()
    assert a.arcs == [(None, z)]


# Generated at 2022-06-11 19:51:19.812997
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    src = 'asdf\n'
    for type in range(256):
        p = ParserGenerator(StringIO(src))
        p.type = type
        p.value = 'x'
        p.expect(type, 'x')
        try:
            p.expect(type, 'y')
        except SyntaxError:
            pass
        else:
            print(type)
            assert False
    src = "ab 'cd' ef \"gh\"\n"
    p = ParserGenerator(StringIO(src))
    for type in (token.NAME, token.STRING):
        p.gettoken()
        p.expect(type)
    try:
        p.expect(token.NAME)
    except SyntaxError:
        pass
    else:
        print('name')
       

# Generated at 2022-06-11 19:51:32.357480
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    # Result of this was checked against parser module's reference dfa
    pg = ParserGenerator()
    pg.p("single : NAME")
    pg.p("double : single single")
    pg.p("triple : single single single")
    pg.p("expr : triple | double | single")
    pg.make_grammar()
    assert pg.dfas["single"]
    assert pg.dfas["single"]
    assert pg.dfas["double"]
    assert pg.dfas["triple"]
    assert pg.dfas["expr"]
    pg.dump_dfa("single", pg.dfas["single"])
    pg.dump_dfa("double", pg.dfas["double"])
    pg.dump_dfa("triple", pg.dfas["triple"])

# Generated at 2022-06-11 19:51:36.967794
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    pg = ParserGenerator(tokenize.generate_tokens(StringIO('a').readline))
    result = pg.parse_alt()
    expected = (NFAState(), NFAState())
    assert result == expected



# Generated at 2022-06-11 19:51:48.647494
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    pg = ParserGenerator()
    pg.dfas = {
        "a": [DFAState({}, 0), DFAState({}, 1), DFAState({}, 0)],
        "b": [DFAState({}, 0), DFAState({}, 0)],
        "c": [DFAState({}, 0), DFAState({}, 0)],
    }
    pg.dfas["a"][0].addarc(pg.dfas["b"][0])
    pg.dfas["a"][0].addarc(pg.dfas["c"][0])
    pg.dfas["b"][1].addarc(pg.dfas["c"][0])
    pg.calcfirst("a")

# Generated at 2022-06-11 19:51:58.488324
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    items = {
        "x": "ab [cd]",
        "y": "fg [hi]",
        "z": "z|[ab] [xy]",
    }
    p = ParserGenerator(items)
    p.calcfirst("x")
    assert p.first["x"] == {"a": 1, "[": 1, "c": 1, "d": 1, "b": 1}, p.first["x"]
    p.calcfirst("y")
    assert p.first["y"] == {"f": 1, "[": 1, "h": 1, "i": 1, "g": 1}, p.first["y"]
    py.test.raises(ValueError, p.calcfirst, "z")

# Generated at 2022-06-11 19:53:09.719351
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    parser = ParserGenerator(
        """
        a : b c
        b : '-' | '+'
        c : '0' | '1' | '2'
        """
    )
    parser.addfirstsets()
    assert parser.first["a"] == {"-": 1, "+": 1, "0": 1, "1": 1, "2": 1}
    assert parser.first["b"] == {"-": 1, "+": 1}
    assert parser.first["c"] == {"0": 1, "1": 1, "2": 1}



# Generated at 2022-06-11 19:53:13.831196
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    mod = PgenGrammar("Grammar/Grammar.txt")
    assert mod.start == "file_input"
    assert len(mod.symbol2number) == 132
    assert len(mod.number2symbol) == 132




# Generated at 2022-06-11 19:53:18.412062
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    while True:
        try:
            pg = ParserGenerator(None)
            pg.make_first(None)
            break
        except:
            pass
    else:
        raise AssertionError



# Generated at 2022-06-11 19:53:22.266850
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    pg = ParserGenerator()
    s = NFAState()
    s.addarc(NFAState(), "a")
    s.addarc(NFAState(), "b")
    s.addarc(NFAState(), "c")
    pg.dump_nfa("name", s, s)
    print("end")


# Generated at 2022-06-11 19:53:24.269700
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    pg = ParserGenerator()
    assert pg.expect(token.NAME) == "foo"
    # assert(pg.expect(token.NAME), "bar")


# Generated at 2022-06-11 19:53:29.915373
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    for type in grammar.tok_name:
        name = grammar.tok_name[type]
        p = ParserGenerator()
        label = p.make_label(None, name)
        assert label == type, (label, type, name)
    for name, type in grammar.opmap.items():
        p = ParserGenerator()
        label = p.make_label(None, name)
        assert label == type, (label, type, name)


## Unit test for ParserGenerator
# def test_ParserGenerator():
#     import sys
#     import time

#     if len(sys.argv) == 1:
#         fname = 'Parser/Grammar.txt'
#     else:
#         fname = sys.argv[1]
#     print 'Reading grammar from', f

# Generated at 2022-06-11 19:53:36.129710
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    # We pass in a list so we can mutate it.
    #
    # The parser grammar is an EBNF grammar.  If a production has a
    # single expression in it, then that expression is the same as
    # the production.  If it has two or more expressions, then
    # they are inside parentheses.  The expressions are evaluated
    # in order.
    #
    # A production of the form  X: NAME ':' RHS '\n'  gives the
    # token NAME to the method production_NAME.  A production of
    # the form  RULE: '|' ALT  gives the token '|' to the method
    # production_RULE to indicate that multiple productions for
    # RULE follow.

    class SampleParserGenerator(ParserGenerator):
        def production_atom(self, token):
            return token

# Generated at 2022-06-11 19:53:42.669328
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    import textwrap, sys

# Generated at 2022-06-11 19:53:55.183717
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    def t(input_: str, expected: str, print_grammar=False) -> None:
        pg = ParserGenerator()
        try:
            dfa = pg.parse_rhs(input_)
            result = pg.pretty_grammar(dfa)
            if print_grammar:
                print("result:")
                print(result)
            assert result == expected
        except SyntaxError as e:
            pytest.fail(f"Unexpected syntax error: {e!r}")

    t("A", OUT_A)
    t("A B", OUT_AB)
    t("A | B", OUT_AorB)
    t("A B | C", OUT_ABorC)
    t("A | B C", OUT_AorBC)

# Generated at 2022-06-11 19:54:06.703637
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    def exec_parse_alt(s: str, expected_output: str) -> None:
        o = io.StringIO()
        ps = ParserGenerator(io.StringIO(s))
        ps.parse_alt()
        assert o.getvalue() == expected_output, "Test Failed"  # noqa

    exec_parse_alt("a", None)

    exec_parse_alt("a|b", None)

    exec_parse_alt("a b", None)

    exec_parse_alt("a|b c", None)

    exec_parse_alt("[a-zA-Z_][a-zA-Z0-9_]*", None)
