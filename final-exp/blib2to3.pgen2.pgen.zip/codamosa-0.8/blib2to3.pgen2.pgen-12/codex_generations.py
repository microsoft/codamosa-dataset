

# Generated at 2022-06-11 19:47:00.021038
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    """This is a docstring.
    """
    # Method dump_dfa of class ParserGenerator
    # Calling function dump_dfa
    name = 'name'
    dfa = [0]
    ParserGenerator.dump_dfa(name, dfa)

# Generated at 2022-06-11 19:47:09.797597
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    from pgen2 import token, driver
    from pgen2.pgen import ParserGenerator, convert_grammar
    pg = ParserGenerator([], [], [], [], [], [], [], [], [], token, driver)
    pg.arcs = []
    pg.parse()
    convert_grammar(pg).dump_nfa('', pg.start, pg.dfas['file_input'][-1])
    convert_grammar(pg).dump_dfa('', pg.dfas['file_input'])

if __name__ == "__main__":
    test_ParserGenerator_dump_nfa()
import sys

from tokenize import tokenize, untokenize, NUMBER, STRING, NAME, OP

from pgen2.grammar import STORE, OPARG, ADDOPT

# Generated at 2022-06-11 19:47:12.494327
# Unit test for method parse_rhs of class ParserGenerator

# Generated at 2022-06-11 19:47:21.667129
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    import grammar

    gr = grammar.Grammar()
    gr.update(
        """
        expr: xor_expr ('|' xor_expr)*
        xor_expr: and_expr ('^' and_expr)*
        and_expr: shift_expr ('&' shift_expr)*
        shift_expr: a_expr (('<<'|'>>') a_expr)*
        a_expr: m_expr (('+'|'-') m_expr)*
        m_expr: atom (('*'|'/'|'%'|'//') atom)*
        atom: ('+'|'-'|'~') atom | power
        power: atom ('**' factor)*
        """
    )
    # print gr.dump()
    pg = ParserGenerator(gr)
    pg.parse()
    # print pg

# Generated at 2022-06-11 19:47:32.130060
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    # Argument 1: [filename]
    # Argument 2: [string]
    input = (
        "(expression operator expression)",
        "['+' | '-' | '*' | '/' | '%' | '**' | '<<' | '>>' | '&' | '^' | '|']",
        "(NAME | NUMBER | STRING + ('+' + STRING)* | '(' + expression + ')' | '[' + "
        "listmaker + ']' | '{' + dictmaker + '}' | '`' + expression + '`')",
        "atom trailer+",
        "NAME"
    )

    def verify(grammar: ParserGenerator, filename: str, exp: str) -> None:
        for line in str(grammar).splitlines():
            print(line)
        grammar.parse()

# Generated at 2022-06-11 19:47:39.533248
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    p = ParserGenerator(["\n"])
    # print(p.type)
    # print(p.value)
    # print(p.begin)
    # print(p.end)
    # print(p.line)
    assert p.type == 2
    assert p.value == '""'
    assert p.begin == (1, 0)
    assert p.end == (1, 0)
    assert p.line == "\n"
    p.expect(2, None)
PgenGrammar.add_method("expect", test_ParserGenerator_expect)


# Generated at 2022-06-11 19:47:47.342473
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    pg = ParserGenerator(None, [])
    class DummyConverter:
        def __init__(self) -> None:
            self.labels = []  # type: List[Tuple[int, Optional[str]]]
            self.symbol2number = {}  # type: Dict[str, int]
            self.tokens = {}  # type: Dict[int, int]
            self.keywords = {}  # type: Dict[str, int]
            self.symbol2label = {}  # type: Dict[str, int]
    #
    c = DummyConverter()
    #
    def test(input, expected):
        result = pg.make_label(c, input)
        assert result == expected, (input, result, expected)
    ## test('"foo"

# Generated at 2022-06-11 19:47:48.997888
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    pg = PgenGrammar()
    assert isinstance(pg, grammar.Grammar)
    assert isinstance(pg, PgenGrammar)



# Generated at 2022-06-11 19:47:59.912027
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    """Method simplify_dfa of class ParserGenerator

    Args:

    Returns:
        None

    Raises:
        AssertionError if not True

    """
    # No tests yet
    # print 'A'
    # pg = ParserGenerator()
    # pg.addtoken('NAME', r'[a-zA-Z_][a-zA-Z_0-9]*')
    # pg.addtoken('NUMBER', r'[0-9]+')
    # pg.addtoken('PLUS', '\\+')
    # pg.addtoken('TIMES', '\\*')
    # pg.addtoken('LPAR', '\\(')
    # pg.addtoken('RPAR', '\\)')
    # pg.addtoken('EQUAL', '=')
    # pg.

# Generated at 2022-06-11 19:48:04.331135
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    s = """\
        start: items NEWLINE
             | NEWLINE
        items: items item
             | item
        item: NAME ':' NAME
            | NAME
        NEWLINE: "\n"
        %ignore " "
        """
    pg = ParserGenerator()
    pg.parse(s)


# Generated at 2022-06-11 19:48:40.884815
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    pg = ParserGenerator()
    pg.dfas = {"top": [DFAState({}, None)]}
    pg.dfas["top"][0].addarc(pg.dfas["top"][0], "a")
    pg.dfas["top"][0].addarc(pg.dfas["top"][0], "b")
    pg.dfas["top"][0].addarc(pg.dfas["top"][0], "c")
    pg.dfas["top"][0].addarc(pg.dfas["top"][0], "d")
    pg.dfas["top"][0].addarc(pg.dfas["top"][0], "e")
    pg.dfas["top"][0].addarc(pg.dfas["top"][0], "f")

# Generated at 2022-06-11 19:48:46.605849
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    pg = ParserGenerator()

# Generated at 2022-06-11 19:48:52.826020
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    parser = ParserGenerator()
    c = PgenGrammar()
    parser.make_label(c, "NAME")
    parser.make_label(c, "NUMBER")
    parser.make_label(c, "STRING")
    parser.make_label(c, '"if"')
    parser.make_label(c, '"else"')
    parser.make_label(c, '"elif"')
    parser.make_label(c, '"while"')
    parser.make_label(c, '"for"')
    parser.make_label(c, '"in"')
    parser.make_label(c, '"def"')
    parser.make_label(c, '"class"')
    parser.make_label(c, '"pass"')

# Generated at 2022-06-11 19:49:04.791671
# Unit test for method make_grammar of class ParserGenerator

# Generated at 2022-06-11 19:49:17.071921
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    import os
    import sys
    import tokenize
    import unittest

    def test(data, expected):
        buf = Buffer("")
        buf.write(data)
        buf.seek(0)
        generator = tokenize.generate_tokens(buf.readline)
        pg = ParserGenerator(generator)
        for expected_tok in expected:
            print(expected_tok)
            pg.gettoken()
            print(pg.type, pg.value)
            assert pg.type == expected_tok[0]
            assert pg.value == expected_tok[1]
            if expected_tok[0] != token.EOF:
                assert pg.begin == expected_tok[2], (
                    pg.begin,
                    expected_tok[2],
                )

# Generated at 2022-06-11 19:49:19.744244
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    a = ParserGenerator()
    a.dfas = {
        "x": [DFAState({}, False)],
        "y": [DFAState({}, False)],
    }
    a.calcfirst("x")


# Generated at 2022-06-11 19:49:30.133687
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    from . import token
    from . import symbol
    # Test the python.g grammar
    pg = ParserGenerator()
    with open(symbol.__file__, "rb") as f:
        encoding = token.detect_encoding(f.readline)[0]
    if encoding == "utf-8":
        # Workaround: the tokenizer in tokenize.py doesn't support UTF-8 decodable
        # line continuations.  Luckily, the symbol.py grammar doesn't use them
        # (as of this writing).
        encoding = "iso-8859-1"
    with open(symbol.__file__, encoding=encoding) as f:
        pg.parse_grammar(f)

# Generated at 2022-06-11 19:49:42.254574
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    from cStringIO import StringIO
    from tokenize import generate_tokens
    from tokenize import token
    from tokenize import untokenize

    g = ParserGenerator()
    for _ in g.parse_item():
        pass
    test_cases = [
        "  *(x   )    ",
        "  [x+y] +[1, 2, 3]  ",
        "x*(y+z)*u",
        '("bad"|"stuff")*',
        '("bad"\n|\n"stuff")+',
    ]
    for case in test_cases:
        s = StringIO(case)
        g.generator = generate_tokens(s.readline)
        g.gettoken()
        print(untokenize(list(g.generator)))

# Generated at 2022-06-11 19:49:55.134459
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    pg = ParserGenerator()
    # test program
    pg.pgen()

    # check result
    print("-"*20, "First sets")
    for name in pg.first:
        print("%-15s: %r" % (name, pg.first[name]))
    assert pg.first['suite'] == {None: 1, 'simple_stmt': 1, 'NEWLINE': 1}
    assert pg.first['compound_stmt'] == {'if_stmt': 1, 'while_stmt': 1, 'for_stmt': 1}
    assert pg.first['file_input'] == {'NEWLINE': 1, 'stmt': 1}
    assert pg.first['expr_stmt'] == {'test': 1}
    assert pg.first['test'] == {'or_test': 1}

# Generated at 2022-06-11 19:50:03.852832
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    p = ParserGenerator()
    dfa = [DFAState({}, isfinal=True), DFAState({}, isfinal=False)]
    dfa[0].addarc(dfa[1], '"a"')
    dfa[0].addarc(dfa[0], '"a"')
    dfa[1].addarc(dfa[0], '"a"')
    dfa[1].addarc(dfa[1], '"a"')
    p.dump_dfa("test", dfa)

# Generated at 2022-06-11 19:50:42.721058
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    from . import _testcapi
    # ParserGenerator.raise_error: test error message with unicode
    if not _testcapi.IS_PY3 and hasattr(_testcapi.US, "encode"):
        # on Python 2, we have to make sure to embed unicode in a byte string,
        # for compatibility with the underlying tp_print implementation
        def f(self):
            self.raise_error("\xe2\x98\xa2", "\xe2\x98\xa2")
        # Also check that tp_print outputs a byte string
        def f2(self):
            self.raise_error("\xe2\x98\xa2".encode())
        # This will throw an exception which will have a message
        # containing the encoded character
        #
        # Without the fix for issue #

# Generated at 2022-06-11 19:50:44.457223
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    pg = ParserGenerator()
    parse = pg.parse_rhs
    finish = pg.finish
    parse("a | b", finish)


# Generated at 2022-06-11 19:50:55.203708
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    pg = ParserGenerator()
    pg.dfas['a'] = [DFAState()] * 2
    pg.dfas['b'] = [DFAState()] * 2
    pg.dfas['c'] = [DFAState()] * 2
    pg.dfas['d'] = [DFAState()] * 2
    pg.dfas['a'][0].arcs['a'] = pg.dfas['a'][1]
    pg.dfas['a'][0].arcs['b'] = pg.dfas['b'][1]
    pg.dfas['a'][0].arcs['c'] = pg.dfas['c'][1]
    pg.dfas['a'][0].arcs['d'] = pg.dfas['d'][1]

# Generated at 2022-06-11 19:51:08.516752
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    import StringIO

    g = ParserGenerator()
    g.generator = tokenize.generate_tokens(StringIO.StringIO('a | b').readline)
    a, b = g.parse_alt()

# Generated at 2022-06-11 19:51:18.216516
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    from io import BytesIO, TextIOWrapper
    from test.support import captured_stdout, findfile, run_unittest, unlink
    import tokenize
    import types
    import unittest
    
    
    
    
    
    
    
    
    
    
    class ExceptionHookTestCase(unittest.TestCase):
    
        def setUp(self):
            repl = {"INDENT": tokenize.INDENT, "DEDENT": tokenize.DEDENT}
            self.addCleanup(unlink, findfile("tokenize_tests"))
            with open(findfile("tokenize_tests"), "rb") as fp:
                text = fp.read().decode("latin-1")
            self.text = text % repl

# Generated at 2022-06-11 19:51:21.403890
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    # ParserGenerator.expect
    pg = ParserGenerator("", "")  # None, None)
    pg.type = token.NAME
    pg.value = "lang"
    result = pg.expect(token.NAME)
    assert result == "lang"
    try:
        pg.expect(token.NAME, "python")
        assert False, "expected exception"
    except SyntaxError:
        pass



# Generated at 2022-06-11 19:51:28.802369
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    global PGEN
    f = io.StringIO("""
    ENDMARKER: ''
""")
    t = tokenize.generate_tokens(f.readline)
    PGEN = ParserGenerator(t, "foo.txt")
    PGEN.parse_item()
    PGEN.parse_item()
    PGEN.parse_item()

# Generated at 2022-06-11 19:51:36.921727
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    from . import grammar
    from .pgen import ParserGenerator
    import re


# Generated at 2022-06-11 19:51:45.295136
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    gram = ParserGenerator.make_grammar(
        """
        start: "(" ")" | "(" start ")" | "(" start "*" ")"
        """
    )
    assert isinstance(gram, ParserGenerator)
    assert gram.startsymbol == "start"
    assert list(gram.dfas.keys()) == ["start"]
    assert all(isinstance(s, DFAState) for s in gram.dfas["start"])



# Generated at 2022-06-11 19:51:56.341268
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    from .grammar import Grammar
    from . import driver
    from . import token
    from . import tokenizer
# <<<<<<< HEAD
#     from . import node
# =======
# >>>>>>> b89ef0f1eae539efa5cba8af94cfde38f5dfa9d9
    from pprint import pprint

    pg = ParserGenerator()
    pg.add_block(
        """
        exp: atom ('+' atom)* 'END'
        atom: '(' exp ')' | NAME | NUMBER
        """
    )
# <<<<<<< HEAD
#     pprint(pg.make_labels()) # doctest: +ELLIPSIS
#     pprint(pg.make_dfa('exp')) # doctest: +ELLIPSIS
#     pprint(pg.make

# Generated at 2022-06-11 19:53:57.994422
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    pg = ParserGenerator("test.pg", None)
    pg.test_input("test", "NAME")
    pg.test_input("|", "|")
    pg.test_input("NAME", "NAME")
    pg.test_input("NAME", "NAME")
    pg.test_input("'NAME'", "STRING")
    pg.test_input("'NAME'", "STRING")
    pg.test_input("NAME", "NAME")
    pg.test_input("NAME", "NAME")
    pg.test_input("[", "[")
    pg.test_input("NAME", "NAME")
    pg.test_input("|", "|")
    pg.test_input("NAME", "NAME")
    pg.test_input("]", "]")

# Generated at 2022-06-11 19:54:00.095091
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    _g = ParserGenerator()
    _g._check_sanity()


# Generated at 2022-06-11 19:54:08.551708
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    s = "foo : 'a' | 'b' | 'c'\n"
    parser = ParserGenerator()
    p = parser.parse(s)
    d = p.make_first(None, "foo")
    assert len(d) == 3
    if sys.version_info[0] >= 3:
        # Testing a bug report by I Galanakis
        s = "foo : 'a' | 'ß' | 'c'\n"
        parser = ParserGenerator(unicode_literals=True)
        p = parser.parse(s)
        d = p.make_first(None, "foo")
        assert set(d.keys()) == {"'a'", "'ß'", "'c'"}



# Generated at 2022-06-11 19:54:20.157653
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    """
    The following test function tests the method
    ParserGenerator.addfirstsets.
    """
    import sys
    from pgen2.pgen import ParserGenerator
    from pgen2.token import NAME, NUMBER, STRING, OP
    from pgen2.grammar import Grammar
    #
    s = """\
    a: '[' b c ']'
      | '(' b ')'
    b: '{' NAME '}'
    c: NAME '=' NUMBER
    """
    #
    g = Grammar(s)
    pg = ParserGenerator(g, "a")
    pg.addfirstsets()
    #
    assert pg.first["a"] == {"[": 1, "(": 1}
    assert pg.first["b"] == {"{": 1}

# Generated at 2022-06-11 19:54:32.599371
# Unit test for method parse of class ParserGenerator

# Generated at 2022-06-11 19:54:44.741867
# Unit test for method addfirstsets of class ParserGenerator

# Generated at 2022-06-11 19:54:48.398542
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    """Unit test for ParserGenerator.raise_error"""

    def tester(msg: str, *args: Any) -> NoReturn:
        raise SyntaxError(msg, (1, 1, 1), args)
    ParserGenerator.raise_error = tester  # type: ignore


# Generated at 2022-06-11 19:54:56.319221
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    import StringIO
    from . import pgen
    text = """
        stmt: simple_stmt | compound_stmt
        simple_stmt: small_stmt (';' small_stmt)* [';'] NEWLINE
        small_stmt: (expr_stmt | del_stmt | pass_stmt | flow_stmt |
                     import_stmt | global_stmt | nonlocal_stmt | assert_stmt)
        expr_stmt: testlist_star_expr (augassign (yield_expr|testlist) |
                    ('=' (yield_expr|testlist_star_expr))*)
        testlist_star_expr: (test|star_expr) (',' test|star_expr)* [',']
        star_expr: '*' test
    """
    f = StringIO.StringIO

# Generated at 2022-06-11 19:55:07.268458
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    a = ParserGenerator()
    a.add_nonterminal("foo", "STRING | NAME")
    a.add_nonterminal("bar", "foo bar | foo")
    a.add_nonterminal("baz", "bar+")
    c = a.make_grammar()
    assert c.labels == [(token.STRING, None), (token.NAME, None)]
    assert c.keywords == {}
    assert c.tokens == {token.NAME: 1, token.STRING: 0}
    assert c.start == 2
    assert c.symbol2number == {'bar': 0, 'baz': 2, 'foo': 1}
    assert c.symbol2label == {'bar': 0, 'baz': 0, 'foo': 1}

# Generated at 2022-06-11 19:55:16.138290
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    def test_one(s, expected):
        pg = ParserGenerator()
        pg.setup_parser(tokenize.generate_tokens(StringIO(s).readline))
        a, z = pg.parse_alt()
        pg.expect(token.ENDMARKER)
        assert pg.nfastates == []
        assert pg.gettokens() == expected

    yield test_one, "foo", [['foo', None]]
    yield test_one, "foo bar", [['foo', None], ['bar', None]]
