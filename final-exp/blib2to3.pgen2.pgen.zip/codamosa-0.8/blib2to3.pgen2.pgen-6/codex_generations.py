

# Generated at 2022-06-11 19:47:16.636610
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    pygram = Pygram()
    pgen = ParserGenerator(pygram)
    c = EmptyConverter("<test-string>")
    c.labels = []
    c.symbol2label = {}
    c.symbol2number = {"a": ord("a")}
    c.tokens = {}
    c.keywords = {}
    for name in pygram.symbol2label:
        c.symbol2label[name] = pygram.symbol2label[name]

    name = "NAME"
    ilabel = pgen.make_label(c, name)
    assert ilabel == token.NAME, name
    assert c.labels[ilabel] == (token.NAME, None)
    assert c.tokens[token.NAME] == ilabel

    name = "a"


# Generated at 2022-06-11 19:47:29.749019
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    # These should all succeed.
    for conv in [
        GrammarConverter1(
            [],
            {},
            collections.defaultdict(lambda: None),
            "",
            token.NAME,
            "",
            0,
            {"": 0},
            {},
            {},
            [],
            None,
        )
    ]:
        conv.make_label(conv, "NAME")
        conv.make_label(conv, "STRING")
        conv.make_label(conv, "LPAR")
        conv.make_label(conv, "x")
        conv.make_label(conv, '"x"')
        conv.make_label(conv, "'x'")
        conv.make_label(conv, '"if"')

# Generated at 2022-06-11 19:47:32.746891
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    pg = ParserGenerator()
    pg.generator = tokenize.generate_tokens(io.StringIO('(a)').readline)
    pg.gettoken()
    pg.parse_atom()



# Generated at 2022-06-11 19:47:41.584089
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    pg = ParserGenerator()
    pg.generator = tokenize.generate_tokens(io.StringIO("a | b").__iter__())
    pg.gettoken()
    def test(pg):
        a, z = pg.parse_item()
        assert len(a.arcs) == 1
        assert a.arcs[0] == (None, z)
        return a, z
    test(pg); pg.expect(token.OP, "|"); test(pg)
    pg.generator = tokenize.generate_tokens(io.StringIO("a+ | b").__iter__())
    pg.gettoken(); a, z = test(pg); assert a == z
    pg.expect(token.OP, "+"); test(pg); pg.expect(token.OP, "|");

# Generated at 2022-06-11 19:47:49.116982
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    f = ParserGenerator()
    a = NFAState()
    z = NFAState()
    a.addarc(z, "b")
    assert f.make_dfa(a, z) == [DFAState({a: 1, z: 1}, z, {"b": (z,)})]
    a = NFAState()
    z = NFAState()
    a.addarc(z, "b")
    a.addarc(z, "c")
    assert f.make_dfa(a, z) == [DFAState({a: 1, z: 1}, z, {"b": (z,), "c": (z,)})]
    a = NFAState()
    b = NFAState()
    c = NFAState()
    z = NFAState()

# Generated at 2022-06-11 19:47:57.921350
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    test_dict = {
        "expr": {
            "1": [("atom", 2)],
            "2": [("atom", 2), ("'+'", 3), ("atom", 4)],
            "3": [("'+'", 3), ("atom", 4)],
            "4": [("atom", 4)]
        },
        "atom": {
            "1": [("'('", 2)],
            "2": [("expr", 3)],
            "3": [("')'", 4)],
            "4": [("NAME", 6)],
            "5": [("NUMBER", 6)],
            "6": []
        },
        "start": {
            "0": [("expr", 1)]
        }
    }

# Generated at 2022-06-11 19:48:02.411073
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    pg = ParserGenerator()
    pg.make_scanner()
    dfa = [17, 25, 15, 3]
    pg.simplify_dfa(dfa)
    expected_dfa = [17, 25, 15, 3]
    assert dfa == expected_dfa
# UNIT TEST ENDS HERE


# Generated at 2022-06-11 19:48:13.434321
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    for str in (
        "(foo + bar)",
        "(foo | bar)",
        "(foo) *",
        "[foo | bar]",
        "foo",
        "foo +",
        "foo *",
        "foo | bar",
        '"foo"',
        '"foo" +',
        '"foo" *',
        '"foo" | bar',
    ):
        print(str)
        p = ParserGenerator()
        p.setup("", StringIO(str))
        a, b = p.parse_item()
        print("states:", len(a.arcs), len(b.arcs))
        print("reached:", a.reached, b.reached)
        print("firstpos:", a.firstpos, b.firstpos)



# Generated at 2022-06-11 19:48:23.441488
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    # function parse calls function make_dfa, which calls function simplify_dfa.
    # simplify_dfa is not tested here, because the results of parse are tested
    # elsewhere.
    pgen = ParserGenerator()
    
    input = """
        # Test various combinations of optional, single, and multiple.
        start: a
        a: eps | 'a' | name | string
        name: 'b' | 'c'
        string: 'd' | 'e'
        integer: 'f' | 'g'
        """
    pgen.add_module('pgen_input', input)
    pgen.make_parsing_table()
    

# Generated at 2022-06-11 19:48:24.957347
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    x = PgenGrammar()


# Generated at 2022-06-11 19:48:58.306210
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    a = NFAState()
    b = NFAState()
    c = NFAState()
    d = NFAState()
    e = NFAState()
    f = NFAState()
    a.addarc(b, "a")
    a.addarc(c, "x")
    b.addarc(d)
    b.addarc(e)
    c.addarc(f, "y")
    f.addarc(c)
    d.addarc(d)
    e.addarc(a)
    pg = ParserGenerator()
    dfa = pg.make_dfa(a, d)
    assert dfa[0].arcs == {("a",): dfa[1], ("x",): dfa[2]}
    assert dfa[0].isfinal is False
    assert d

# Generated at 2022-06-11 19:49:10.048528
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    pg = ParserGenerator()
    pg.add_rhs("rhs", ['x', 'y', 'z'])
    pg.add_rhs("rhs", ['a', 'b', 'c'])
    pg.add_rhs("rhs", ['w', 't'])

    dfas, startsymbol = pg.parse()
    assert startsymbol == "rhs"
    assert sorted(dfas.keys()) == ["rhs"]

    a, b, c, d, e, f = dfas['rhs']
    i = dfas['rhs'].index
    assert a.arcs == {'a': b, 'w': d, 'x': b}
    assert b.arcs == {'b': c}
    assert c.arcs == {'c': f}

# Generated at 2022-06-11 19:49:20.341525
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    pg = ParserGenerator(None, None)
    assert(pg.type == tokenize.ENDMARKER)
    source = '# comment # another comment\nname : "-";\n'
    pg.gettoken()
    assert(pg.type == tokenize.NAME)
    assert(pg.value == 'name')
    pg.gettoken()
    assert(pg.type == token.OP)
    assert(pg.value == ':')
    pg.gettoken()
    assert(pg.type == token.STRING)
    assert(pg.value == '-')
    pg.gettoken()
    assert(pg.type == token.OP)
    assert(pg.value == ';')
# End unit test


# Generated at 2022-06-11 19:49:31.863052
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    # XXX
    r"""Input to parser"""
    pgen = ParserGenerator()
    pgen.parse(test_grammar)
    output = pgen.makeparsertable()
    assert output == test_output

if __name__ == "__main__":
    import sys

    pgen = ParserGenerator()
    if len(sys.argv) > 1:
        filename = sys.argv[1]
    else:
        filename = "Grammar.txt"
    try:
        with open(filename, "r", encoding="latin-1") as f:
            text = f.read()
        output = pgen.parse(text)
    except SyntaxError as err:
        print(sys.exc_info()[1])
    else:
        print(output)

# Generated at 2022-06-11 19:49:44.291291
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    from .pgen2_grammar import example2
    from . import pgen2_parse
    from .pgen2_convert import convert
    from .pgen2_convert import DFAParser
    from .pgen2_parse import get_dfa_parser

    print("Testing method make_dfa")

    try:
        dfa_parser = get_dfa_parser()
        parse_tree = dfa_parser.parse(example2)
        print(parse_tree)
    except SyntaxError as exc:
        print("SyntaxError:", str(exc))
    else:
        parser_generator = pgen2_parse.ParserGenerator(
            filename="example2.txt", text=example2
        )
        start = parser_generator.make_dfa(parse_tree)

# Generated at 2022-06-11 19:49:56.119064
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    """Unit test for constructor of class PgenGrammar."""
    g = PgenGrammar()
    assert g._dfas == {}, "expected empty _dfas, got %r" % (g._dfas,)
    assert g.keywords == {}, "expected empty keywords, got %r" % (g.keywords,)
    assert g.tokens == {}, "expected empty tokens, got %r" % (g.tokens,)
    assert g.punctuation == [], "expected empty punctuation, got %r" % (g.punctuation,)
    assert g.symbolic_literals == [], \
           "expected empty symbolic_literals, got %r" % (g.symbolic_literals,)

# Generated at 2022-06-11 19:50:08.177043
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    d = "  | a | b"
    dfas, start = ParserGenerator().parse_string(d)
    assert dfas == {"S": [DFAState({0: 1, 1: 1, 2: 1}, False)],}, dfas
    for dfa in dfas.values():
        assert len(dfa) == 1, dfa

    d = "  | a | b | c"
    dfas, start = ParserGenerator().parse_string(d)
    assert dfas == {"S": [DFAState({0: 1, 1: 1, 2: 1, 3: 1}, False)],}, dfas
    for dfa in dfas.values():
        assert len(dfa) == 1, dfa

    d = "  | a b | c"

# Generated at 2022-06-11 19:50:12.933162
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    import io
    from grammar2dfa import ParserGenerator
    g = ParserGenerator(io.StringIO('baz'))
    baz = g.expect(token.NAME)
    g.expect(token.ENDMARKER)
    assert baz == "baz"



# Generated at 2022-06-11 19:50:20.660040
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    assert False, "Unimplemented"
if __name__ == "__main__":
    import doctest
    doctest.testmod()


# The NFA states are represented as a dict of dicts of dicts.  The
# keys are state numbers, the second keys are label ids, the third
# keys are state numbers again.  The values are 1.  The implicit
# starting state is number 0, and the implicit ending state is
# number -1.

# The DFA states are represented as a dict of dicts.  The keys are
# state numbers, the second keys are label ids, the values are state
# numbers.

# The dfa dict is a dict mapping names to dfa dicts.

# There is also a list of lists; the outer list runs over the states
# in number order; each inner list runs over arcs in

# Generated at 2022-06-11 19:50:29.827589
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    m = ParserGenerator()
    m.gettoken = lambda: None
    m.type, m.value = token.NAME, '"name"'
    m.filename, m.end, m.line = '<string>', (1, 2), 'line'
    g = m.parse_atom()
    assert type(g) == tuple
    assert len(g) == 2
    assert type(g[0]) == NFAState
    assert type(g[1]) == NFAState
    assert len(g[0].arcs) == 1
    assert len(g[1].arcs) == 1
    assert type(g[0].arcs[0][0]) == str
    assert g[0].arcs[0][0] == '"name"'

# Generated at 2022-06-11 19:51:10.818290
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    source = """
            x: 'x'
            y: 'y'
            z: 'z'
            """
    pgen = ParserGenerator()

    # Method to be tested
    pgen.make_grammar(source, "test")

    print("Tokens:")
    for tok in dir(token):
        if tok[:3] == "NT_":
            print("%s: %s" % (tok, getattr(token, tok)))
    print("Labels:")
    for tok in token.tok_name:
        print("%d: %s" % (tok, token.tok_name[tok]))
    print("Variables:")
    print(pgen.variables)
    print("Productions:")
    print(pgen.productions)
   

# Generated at 2022-06-11 19:51:19.410324
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    NFAState = ParserGenerator.NFAState
    pg = ParserGenerator()

# Generated at 2022-06-11 19:51:32.357052
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    import tokenize, io, sys
    from token import NAME, STRING
    p = ParserGenerator("??")
    p.generator = tokenize.generate_tokens(io.StringIO("a = 'b'\n").readline)
    p.gettoken()
    assert (p.type, p.value) == (NAME, 'a')
    p.gettoken()
    assert (p.type, p.value) == (tokenize.OP, '=')
    p.gettoken()
    assert (p.type, p.value) == (STRING, "'b'")
    p.gettoken()
    assert (p.type, p.value) == (tokenize.NL, '')
    p.gettoken()

# Generated at 2022-06-11 19:51:36.850977
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    assert isinstance(PgenGrammar, type)
    assert len(PgenGrammar.__bases__) == 1
    assert PgenGrammar.__bases__[0] == grammar.Grammar



# Generated at 2022-06-11 19:51:48.585223
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    def f():
        raise SyntaxError("message", ("", 0, 0, "line"))

# Generated at 2022-06-11 19:51:59.211796
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    p = ParserGenerator()
    python_grammar = p.parse_grammar(grammar.grammar)
    python_grammar_data = p.dump_grammar(python_grammar)
    new_p = ParserGenerator()
    c = new_p.make_grammar(python_grammar_data)
    assert c.start == 1
    assert c.states == [[[(4, 1), (5, 2)]]]
    assert c.dfas == {1: ([[[(4, 1), (5, 2)]]], {4: 1})}
    assert c.labels == [(token.NEWLINE, None), (token.INDENT, None), (token.DEDENT, None)]
    assert c.keywords == {}

# Generated at 2022-06-11 19:52:07.567221
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    pgen = ParserGenerator()
    c = pgen.make_converter()
    assert c.make_label(c, "NAME") == 0
    assert c.make_label(c, "NUMBER") == 1
    assert c.make_label(c, "STRING") == 2
    assert c.make_label(c, '"foo"') == 3
    assert c.make_label(c, '"bar"') == 4
    assert c.make_label(c, '"baz"') == 5
    assert c.make_label(c, "foobar") == 0
    assert c.make_label(c, "foobaz") == 1
    # TODO add more tests here



# Generated at 2022-06-11 19:52:17.077884
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    pg = ParserGenerator()
    pg.addtoken("PLUS", r"\+")
    pg.addtoken("NAME", r"[a-zA-Z_][a-zA-Z0-9_]*")
    pg.addtoken("NUMBER", r"\d+")
    pg.addtoken("LBRACKET", r"\[")
    pg.addtoken("RBRACKET", r"\]")
    pg.addtoken("LPAR", r"\(")
    pg.addtoken("RPAR", r"\)")
    pg.addtoken("STAR", r"\*")
    pg.addtoken("VBAR", r"\|")
    pg.addtoken("DOT", r"\.")
    pg.addtoken("AT", r"@")

# Generated at 2022-06-11 19:52:29.079743
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    import io
    import tokenize

    def parse_item(s: str) -> Tuple[NFAState, NFAState]:
        lines = iter(s.splitlines(True))
        next(lines)
        tokens = tokenize.generate_tokens(lambda: next(lines))
        filename = "<testcase>"
        pg = ParserGenerator(tokens, filename)
        return pg.parse_item()

    def dump(a: NFAState, z: NFAState) -> None:
        todo = [a]
        for i, state in enumerate(todo):
            print("State", i, state is z and "(final)" or "")
            for label, next in state.arcs:
                if next in todo:
                    j = todo.index(next)
                else:
                    j

# Generated at 2022-06-11 19:52:43.236136
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    from test.test_grammar import ParserGeneratorTestCase
    from test.support import captured_stdout

    for test in ParserGeneratorTestCase.token_tests + ParserGeneratorTestCase.bracket_tests + ParserGeneratorTestCase.paren_tests:
        with captured_stdout() as stdout, captured_stdout() as stderr:
            pg = ParserGenerator()
            print(test[0], '\n')
            dfa = pg.dfas[test[0]]
            state = dfa[0]
            arcs = []
            for label, next in sorted(state.arcs.items()):
                arcs.append((label, dfa.index(next)))
            print('First state: ', arcs)
            print('\n')
            print(pg)



# Generated at 2022-06-11 19:53:55.885934
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    import io
    # Read a file in UTF-8
    content = io.open('nfa.py', encoding="utf-8").read()
    # Convert the file to bytes
    lines = content.encode("utf-8")
    # lines = open('nfa.py')
    gen = tokenize.generate_tokens(io.BytesIO(lines).readline)
    p = ParserGenerator(gen, "nfa.py")
    while True:
        p.gettoken()
        if p.type == token.ENDMARKER:
            break
        assert p.type != token.ENCODING
        typ = token.tok_name[p.type]
        print("%10s  %-15r %-20r" % (typ, p.value, p.line))


# Generated at 2022-06-11 19:54:00.743191
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    pg = ParserGenerator({}, "test.py", "")
    assert next(pg.get_generator()) == (token.ENDMARKER, "", (0, 0), (0, 0), "")



# Generated at 2022-06-11 19:54:09.232465
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    import unittest

    def _test(expected_result, name, value):
        p = ParserGenerator(StringIO(value))
        actual_result = getattr(p, name)()
        if not hasattr(expected_result, "__len__"):
            expected_result = (expected_result,)
        if not hasattr(actual_result, "__len__"):
            actual_result = (actual_result,)
        assert len(actual_result) == len(expected_result)
        for i in range(len(actual_result)):
            expected = expected_result[i]
            actual = actual_result[i]
            assert expected is not actual

# Generated at 2022-06-11 19:54:20.630181
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    p = ParserGenerator()
    c = PgenGrammar()
    assert p.make_label(c, "foo") == 0
    assert p.make_label(c, "foo") == 0
    assert p.make_label(c, "foo") == 0
    assert p.make_label(c, "NAME") == 1
    assert p.make_label(c, "NAME") == 1
    assert p.make_label(c, "NAME") == 1
    assert p.make_label(c, "'+'") == 2
    assert p.make_label(c, "'+'") == 2
    assert p.make_label(c, "'+'") == 2
    assert c.labels == [(0, None), (token.NAME, None), (token.OP, None)]

# Generated at 2022-06-11 19:54:30.909824
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    s = """
    S: (A|B) C
    A: D
    B: D
    C: D
    D: 'd'
    """
    gen = ParserGenerator()
    gen.parse_grammar(s)
    for name, dfa in sorted(gen.dfas.items()):
        start = dfa[0]
        finish = dfa[-1]
        gen.dump_nfa(name, start, finish)
test_ParserGenerator_dump_nfa.__test__ = False
# Unit tests for method dump_dfa of class ParserGenerator

# Generated at 2022-06-11 19:54:39.222847
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    from genshi.core import TEXT
    from genshi.core import START
    from genshi.core import END
    generator = ParserGenerator()
    obs = generator._parse_atom('(', ['<', '#if', '(', '(', '(', '(', ')', '>'])
    assert isinstance(obs[0], NFAState)
    assert isinstance(obs[1], NFAState)
    assert isinstance(obs[0].arcs[0], tuple)
    assert isinstance(obs[0].arcs[0][0], str)
    assert isinstance(obs[0].arcs[0][1], NFAState)
    assert isinstance(obs[1].arcs[0], tuple)
    assert isinstance(obs[1].arcs[0][0], str)

# Generated at 2022-06-11 19:54:48.563853
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    pg = ParserGenerator()
    pg.add("start", ["a", "b", "c", "d"])
    dfa = pg.make_dfa(pg.nfa.start, pg.nfa.finish)

# Generated at 2022-06-11 19:54:55.183517
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    class C:
        labels = []
        symbol2label = {}
        def sym_name(self, i: int) -> str:
            return self.labels[i][0]
        def label2sym(self, i: int) -> int:
            return self.labels[i][0]
        def label2str(self, i: int) -> str:
            return self.labels[i][1]
    pg = ParserGenerator()
    pg.dfas = {"foo": [DFAState(None, True), DFAState(None, False)]}
    pg.first = {"foo": {"x": 1, "y": 1}}
    c = C()
    c.symbol2number = {"foo": 17}

# Generated at 2022-06-11 19:55:06.779210
# Unit test for method make_label of class ParserGenerator

# Generated at 2022-06-11 19:55:11.003606
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    pg = ParserGenerator('ParserGenerator', 'pgen')
    with pytest.raises(SyntaxError):
        pg.raise_error('Test')
# End: unit test