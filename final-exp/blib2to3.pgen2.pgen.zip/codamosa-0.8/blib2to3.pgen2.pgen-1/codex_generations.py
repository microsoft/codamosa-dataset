

# Generated at 2022-06-11 19:47:18.700486
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    pg = ParserGenerator()

# Generated at 2022-06-11 19:47:30.354901
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    source = """
# File: grammar.txt

stmt: simple_stmt | compound_stmt

simple_stmt: small_stmt (';' small_stmt)* [';'] NEWLINE

small_stmt: (expr_stmt | print_stmt  | del_stmt | pass_stmt | flow_stmt |
             import_stmt | global_stmt | exec_stmt | assert_stmt)

expr_stmt: testlist (augassign (yield_expr|testlist) |
                     ('=' (yield_expr|testlist))*)
"""
    p = ParserGenerator()
    dfas, startsymbol = p.parse_string(source)


# Generated at 2022-06-11 19:47:39.724480
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    text = """\
    # Comment
    NAME: 'a'
    """
    pg = ParserGenerator()
    pg.set_grammar(text)
    pg.gettoken()
    assert (pg.type, pg.value) == (token.NAME, "NAME")
    pg.gettoken()
    assert (pg.type, pg.value) == (token.OP, ":")
    pg.gettoken()
    assert (pg.type, pg.value) == (token.STRING, "'a'")
    pg.gettoken()
    assert (pg.type, pg.value) == (token.NEWLINE, "\n")
    pg.gettoken()
    assert (pg.type, pg.value) == (token.ENDMARKER, "")

# Generated at 2022-06-11 19:47:47.479463
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    pg = ParserGenerator()
    a = NFAState()
    z = NFAState()
    a.addarc(z, "x")
    dfa = pg.make_dfa(a, z)
    assert len(dfa) == 1
    assert dfa[0] == DFAState(a.closure(), z)
    a.addarc(z)
    dfa = pg.make_dfa(a, z)
    assert len(dfa) == 2
    assert dfa[0] == DFAState({a:1}, z)
    assert dfa[1] == DFAState(z.closure(), z)
    pg.simplify_dfa(dfa)
    assert len(dfa) == 1

# Generated at 2022-06-11 19:47:58.323243
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    # Test method gettoken of class ParserGenerator
    # with fixed input
    # gettoken()()
    pg = ParserGenerator(test_input1)
    assert pg.gettoken() == (
        token.NAME,
        "expr",
        (1, 0),
        (1, 4),
        "expr:  atom ('+' atom)*\n",
    )
    (
        pg.type,
        pg.value,
        pg.begin,
        pg.end,
        pg.line,
    ) = (
        token.NAME,
        "expr",
        (1, 0),
        (1, 4),
        "expr:  atom ('+' atom)*\n",
    )

# Generated at 2022-06-11 19:48:05.955957
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    pg = ParserGenerator()
    pg.type = token.NAME
    pg.value = '"foo"'
    #name = self.expect(token.NAME)
    #self.expect(token.OP, ":")
    #a, z = self.parse_rhs()
    #self.expect(token.NEWLINE)
    #self.dump_nfa(name, a, z)
    #dfa = self.make_dfa(a, z)
    #self.dump_dfa(name, dfa)
    #oldlen = len(dfa)
    #self.simplify_dfa(dfa)
    #newlen = len(dfa)
    
    name = pg.expect(token.NAME)
    pg.expect(token.OP, ":")
   

# Generated at 2022-06-11 19:48:07.960223
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    pg = ParserGenerator()
    pg.make_dfa(NFAState(), NFAState())



# Generated at 2022-06-11 19:48:09.429968
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    assert ParserGenerator
    pg = ParserGenerator()
    assert pg



# Generated at 2022-06-11 19:48:20.667902
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    import sys
    import tokenize

    class Token:
        def __init__(self, type: int, string: Text):
            self.type = type
            self.string = string

    pg = ParserGenerator()
    pg.add_dfa(
        "test",
        [
            DFAState(
                {"abc1": 1, "abc2": 2},
                {"abc3": 3, "abc4": 4, "abc5": 5},
            )
        ],
    )
    pg.dump_dfa("test", pg.dfas["test"])


# Generated at 2022-06-11 19:48:31.203105
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    generator = ParserGenerator()
    def my_iter(tokens):
        for token in tokens:
            yield token
    generator.generator = my_iter([(1,"d")])
    generator.type = 1
    generator.value = "d"
    generator.end = (1,1)
    generator.line = "This is a test"
    generator.raise_error = lambda *args, **kwargs: None
    assert generator.expect(1,"d") == "d"
    assert generator.type == 1
    assert generator.value == "d"


# Generated at 2022-06-11 19:49:10.639809
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    source = """\
# Test ParserGenerator.addfirstsets

# This is a test.
s : 'this' { 'is' } t
t : 'a test'
| 'another test'
"""
    pg = ParserGenerator()
    pg.parse_grammar(source)
    first = {
        "s": {"this": 1, "a": 1, "another": 1},
        "t": {"a": 1, "another": 1},
    }
    pg.addfirstsets()
    assert pg.first == first



# Generated at 2022-06-11 19:49:13.043161
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    p = ParserGenerator()
    p.make_first(None, "")  # XXX typecheck


# Generated at 2022-06-11 19:49:20.811915
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    # Test case to illustrate what it is all about
    pg = ParserGenerator()
    s = r"""tup = "tuple" type = "1" | "2" | "3" """
    pg.parsestr(s)
    pg.addfirstsets()
    # print pg.first["tup"]
    # print pg.first["type"]
    dfa = pg.make_dfa(pg.dfas["tup"][0], pg.dfas["tup"][1])
    # print dfa[0].arcs
    # print dfa[0].isfinal
    # print dfa[1].arcs
    # print dfa[1].isfinal
    # print dfa[2].arcs
    # print dfa[2].isfinal

# Generated at 2022-06-11 19:49:32.259857
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    import StringIO
    from .tokenizer import tokenize

    def write(s: str) -> None:
        sys.stdout.write(s)

# Generated at 2022-06-11 19:49:44.686069
# Unit test for method __eq__ of class DFAState
def test_DFAState___eq__():
    import random

    a = DFAState({}, None)
    b = DFAState({}, None)
    assert a == b
    assert a != b.arcs

    a.isfinal = True
    assert a != b
    b.isfinal = True
    assert a == b

    # Iterate over random permutations of the arcs dictionary, making
    # sure that changing the order doesn't change equality.
    for n in range(1000):
        a.arcs = {}
        b.arcs = {}
        for i in range(5):
            label = str(i)
            a.addarc(a, label)
            b.addarc(b, label)
        for i in range(100):
            label = str(i)
            x = random.choice([a, b])

# Generated at 2022-06-11 19:49:56.205926
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    from io import StringIO
    from test.test_tokenize import tokenize
    s = StringIO("def foo():\n    if False:\n        pass\n    elif True:\n        pass\n")
    g = tokenize(s.readline)
    pg = ParserGenerator()
    pg.filename = "foo"
    pg.generator = g
    pg.gettoken()
    assert pg.type == token.NAME
    assert pg.value == "def"
    pg.gettoken()
    assert pg.type == token.NAME
    assert pg.value == "foo"
    pg.gettoken()
    assert pg.type == token.OP
    assert pg.value == "("
    pg.gettoken()
    assert pg.type == token.OP
    assert pg.value == ")"
    pg.get

# Generated at 2022-06-11 19:50:08.264207
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    c = ParserGenerator()
    # These are fixed line numbers in the grammar for "strop"

# Generated at 2022-06-11 19:50:18.038842
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    """
    The PgenGrammar class takes a string, a list of tuples,
    and an optional filename.
    """
    assert issubclass(PgenGrammar, grammar.Grammar)
    assert not hasattr(PgenGrammar, "parse")
    assert not hasattr(PgenGrammar, "production")
    assert not hasattr(PgenGrammar, "symbol2number")
    assert not hasattr(PgenGrammar, "number2symbol")
    assert not hasattr(PgenGrammar, "symbol2label")
    assert not hasattr(PgenGrammar, "label2str")

    # test PgenGrammar(gstr, symbols, kwds)
    # symbols = [(symbol, (number, firsts, nullable, prod))]
   

# Generated at 2022-06-11 19:50:25.393778
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    with open("Parser/Python.asdl") as f:
        pg = ParserGenerator()
        dfas, startsymbol = pg.parse(f)
        assert len(dfas["suite"][0].arcs) == 2  # if stmt / simple_stmt
        assert len(dfas["expr"][0].arcs) == 2  # xor_expr / and_expr
        assert "yield_expr" not in dfas



# Generated at 2022-06-11 19:50:31.697686
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    from pgen2.grammar import Grammar
    from pgen2.pgen import dump_grammar

    def fix(s: str) -> str:
        return re.sub(r"\([^)]*\)\[\d+\]", r"(...)[\1]", s)

    s = """
    a: (a|b)
    b: c
    c: d
    """.strip()
    grammar = Grammar(s)
    pg = ParserGenerator(grammar.startsymbol, grammar.dfas, grammar.first)
    pg.dump_nfa('a', grammar.dfas['a'][0], grammar.dfas['a'][-1])

# Generated at 2022-06-11 19:51:14.511189
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    x = '''
    a: b c
    b: d "|" | "|"
    c: "a" | "b"
    d: "a" "b"
    e: f "g"
    f: "e"
    g: "e"
    '''
    dfa = ParserGenerator().parse(x)

    def dump_dfa(states):
        for i, state in enumerate(states):
            print(i, state.isfinal and "final" or "not final")
            for label, next in state.arcs.items():
                print(i, label, states.index(next))

    dump_dfa(dfa)
    assert dfa[0].arcs.keys() == {"b", "c"}

# Generated at 2022-06-11 19:51:17.132127
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    class GrammarTest(PgenGrammar):
        pass


# Generated at 2022-06-11 19:51:26.047628
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    p = ParserGenerator(["graminit.txt"], "grammar.txt")
    p.make_grammar()
    p.addfirstsets()
    assert p.make_first(None, "suite") == {'\t': 1, '\n': 1, 'cdef': 1, 'def': 1, 'if': 1, 'open': 1, 'return': 1, 'with': 1}

# Generated at 2022-06-11 19:51:34.777715
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    converter = ParserGenerator.Converter()
    pgen = ParserGenerator()

# Generated at 2022-06-11 19:51:47.585204
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    pg = ParserGenerator()
    pg.make_tokenizer("a")
    assert pg.parse_item() == pg.make_nfa("a")
    pg.make_tokenizer("foo")
    assert pg.parse_item() == pg.make_nfa("foo")
    pg.make_tokenizer("'foo'")
    assert pg.parse_item() == pg.make_nfa("'foo'")
    pg.make_tokenizer("foo+")
    assert pg.parse_item() == pg.make_nfa("foo+")
    pg.make_tokenizer("foo*")
    assert pg.parse_item() == pg.make_nfa("foo*")
    pg.make_tokenizer("(foo)")
    assert pg.parse_item() == pg.make_nfa("foo")


# Generated at 2022-06-11 19:51:58.487663
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    pg = ParserGenerator()
    pg.add_nonterminal("a", [("+", "b"), ("+", "c")])
    pg.add_nonterminal("b", [("NAME",)])
    pg.add_nonterminal("c", [("NAME",)])
    pg.add_nonterminal("d", [("a",)])
    pg.add_nonterminal("e", [("b",), ("c",)])
    pg.add_nonterminal("f", [("a",)])
    pg.addfirstsets()
    assert pg.first["a"].keys() == ["NAME"]
    assert pg.first["b"].keys() == ["NAME"]
    assert pg.first["c"].keys() == ["NAME"]

# Generated at 2022-06-11 19:52:11.383954
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    pg = ParserGenerator(
        """
        # Nonterminal definitions
        stmt: {(}[compound_stmt] BREAK_LOOP | simple_stmt BREAK_LOOP | CONTINUE_LOOP {)}
        """
    )
    dfa = pg.dfas["stmt"]
    pg.dump_dfa("stmt", dfa)

    # The output of this unit test must be manually checked.
    #
    # The set of states of the DFA and the mapping of labels onto
    # labels is implementation dependent.
    #
    # XXX The following does not work:
    #
    # >>> dfa
    # [State 0
    #     0 -> 4
    #     5 -> 4
    #     6 -> 4
    #     7 -> 4
    #     8 -> 4
    #    

# Generated at 2022-06-11 19:52:18.406617
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    from tokenize import generate_tokens
    from io import StringIO
    from grako.util import trim
    from textwrap import dedent
    buf = StringIO(dedent("""
    root: a
    """.strip()))
    gen = generate_tokens(buf.readline)
    pg = ParserGenerator()
    pg.generator = gen
    dfas, startsymbol = pg.parse()
    assert len(dfas) == 1, dfas.keys()
    assert startsymbol == 'root', startsymbol
    root = dfas['root']
    assert len(root) == 1, len(root)
    states = list(root[0].arcs.keys())
    assert len(states) == 1, states
    assert states[0] == 'a', states[0]

# Generated at 2022-06-11 19:52:30.231045
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    StringIO = cast("TextIO", io.StringIO)
    input = StringIO("a b 'c'")
    gen = tokenize.generate_tokens(input.readline)
    p = ParserGenerator(gen, "<test>")
    p.gettoken()
    a, z = p.parse_alt()
    assert a.arcs == [(None, p.nfastates[1])]
    assert p.nfastates[1].arcs == [("a", p.nfastates[2])]
    assert p.nfastates[2].arcs == [(None, p.nfastates[3])]
    assert p.nfastates[3].arcs == [("b", p.nfastates[4])]

# Generated at 2022-06-11 19:52:41.875010
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    pgen = ParserGenerator()
    c = pgen.make_grammar([], [])
    pgen.make_label(c, "x")
    pgen.make_label(c, "y")
    pgen.make_label(c, "21")
    pgen.make_label(c, '"z"')
    assert pgen.make_first(c, "x") == {0: 1}
    assert pgen.make_first(c, "y") == {1: 1}
    assert pgen.make_first(c, "21") == {2: 1}
    assert pgen.make_first(c, '"z"') == {3: 1}

# Generated at 2022-06-11 19:53:54.252338
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    parser = ParserGenerator()
    def t(input, expected_type, expected_value):
        parser.type, parser.value = None, None
        parser.parse_atom()
        assert parser.type == expected_type
        assert parser.value == expected_value
    for type in [token.NAME, token.STRING]:
        for input, expected_value in [("NAME", "NAME"), ('"STRING"', "STRING")]:
            t((type, input), type, expected_value)

# Generated at 2022-06-11 19:54:05.874373
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    p = ParserGenerator()
    p.parse_nfas(
"""
    s: a b
    a: 'a'
    b: 'b'
"""
    )
    dfas = p.dfas
    assert len(dfas) == 3
    a, b, s = dfas["a"], dfas["b"], dfas["s"]
    assert len(a) == 2
    assert len(b) == 2
    assert len(s) == 2
    assert a[0].isfinal == False
    assert a[1].isfinal == True
    assert b[0].isfinal == False
    assert b[1].isfinal == True
    assert s[0].isfinal == False
    assert s[1].isfinal == True
    assert s[0].arcs == {None: s[1]}
   

# Generated at 2022-06-11 19:54:11.082539
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    import unittest

    class Test_ParserGenerator_parse_alt(unittest.TestCase):
        def test_method(self):
            p = ParserGenerator()
            with self.assertRaises(SyntaxError):
                p.parse_alt()
                self.fail("No error was raised")

    unittest.main(exit=False)

# Generated at 2022-06-11 19:54:21.777830
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    filename = "<test file>"
    pgen = ParserGenerator(filename)


# Generated at 2022-06-11 19:54:27.476117
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    dfas, startsymbol = ParserGenerator().parse_string(
        """
        expr:
            term
            | term '+' expr
        term:
            NAME
            | NAME '*' term
        """,
        "expr",
    )
    print(dfas)
    assert False

# Generated at 2022-06-11 19:54:30.742380
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    this = PgenGrammar(token.NT_OFFSET, 1)
    assert this.labels == 8192
    assert this.start == 1



# Generated at 2022-06-11 19:54:39.104057
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    p = ParserGenerator()

    dfa = []
    s0 = DFAState(set([0]), True)
    dfa.append(s0)
    s1 = DFAState(set([1]), True)
    dfa.append(s1)
    s2 = DFAState(set([2]), True)
    dfa.append(s2)
    s3 = DFAState(set([3]), True)
    dfa.append(s3)
    s4 = DFAState(set([4]), True)
    dfa.append(s4)

    s0.addarc(s0, None)
    s0.addarc(s0, 'a')
    s0.addarc(s1, 'b')
    s0.addarc(s2, 'c')


# Generated at 2022-06-11 19:54:41.286995
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    x = PgenGrammar(grammar.Grammar())
    assert isinstance(x, PgenGrammar)


# Generated at 2022-06-11 19:54:50.959150
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    
    # Set sys.path so that the unit test can find the input grammar file
    import sys, os
    sys.path = [os.path.join(os.path.dirname(__file__), "Example")] + sys.path

    # Import the input grammar file
    import calc_input
    pg = ParserGenerator()
    
    # Parse the input grammar file
    dfas, startsymbol = pg.parse(calc_input.grammar, "single_input")
    print("\n".join(["states for %s: %d" % (name, len(dfa)) for name, dfa in dfas.items()]))
    print("startsymbol is", startsymbol)
    
    # Print the output file using the print method of the converter

# Generated at 2022-06-11 19:54:57.589891
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    import unittest

    from . import parser
    from . import token

