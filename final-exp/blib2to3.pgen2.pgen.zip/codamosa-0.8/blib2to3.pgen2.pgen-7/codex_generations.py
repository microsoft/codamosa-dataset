

# Generated at 2022-06-11 19:46:42.246138
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():

    g = ParserGenerator()

    # Call the method
    line = g.raise_error("msg")

    assert line == line




# Generated at 2022-06-11 19:46:48.737396
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    fd, name = tempfile.mkstemp()
    with os.fdopen(fd, "w") as f:
        f.write('start: "a"\n')
    pg = ParserGenerator()
    pg.parse_file(name)
    os.remove(name)


# Generated at 2022-06-11 19:46:58.043504
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    p = ParserGenerator()
    start = NFAState()
    finish = NFAState()
    start.addarc(finish, "a")
    dfa = p.make_dfa(start, finish)
    assert len(dfa) == 1
    assert len(dfa[0].arcs) == 1
    assert dfa[0].isfinal is True
    start = NFAState()
    finish = NFAState()
    start.addarc(NFAState(), "a")
    start.addarc(finish, "b")
    dfa = p.make_dfa(start, finish)
    assert len(dfa) == 3
    assert len(dfa[0].arcs) == 2
    assert dfa[0].isfinal is False
    assert len(dfa[1].arcs)

# Generated at 2022-06-11 19:47:00.102452
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    pg = ParserGenerator()
    assert pg.parse_alt() == (NFAState(), NFAState())


# Generated at 2022-06-11 19:47:09.860184
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    def testcase(input, index, finished, start, arcs):
        d, s = ParserGenerator().parse_rhs(input, index)
        assert d == finished
        assert s == start
        assert len(s.arcs) == len(arcs)
        for i, ((label, next), (check, checknext)) in enumerate(zip(s.arcs, arcs)):
            assert label == check
            assert next == checknext
        return d
    def test(input, arcs):
        return testcase(input, 0, True, NFAState(), arcs)
    def test0(input, arcs):
        return testcase(input, 0, False, NFAState(), arcs)
    def test1(input, arcs):
        return testcase(input, 1, True, NFAState(), arcs)

# Generated at 2022-06-11 19:47:11.507456
# Unit test for method dump_dfa of class ParserGenerator

# Generated at 2022-06-11 19:47:20.895491
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    import token
    import tokenize

    filename = "input"
    line = ""
    generator = tokenize.generate_tokens(iter([line]).__iter__())
    parser = ParserGenerator(generator, filename)
    assert parser.expect(token.ENDMARKER) is None
    assert parser.expect(token.NAME, "a") == "a"
    parser.gettoken()
    with pytest.raises(SyntaxError):
        parser.expect(token.NAME)
    with pytest.raises(SyntaxError):
        parser.expect(token.STRING)
    with pytest.raises(SyntaxError):
        parser.expect(token.OP, "")


# Generated at 2022-06-11 19:47:22.800830
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    g = PgenGrammar()
    assert isinstance(g, grammar.Grammar)
    assert isinstance(g, PgenGrammar)



# Generated at 2022-06-11 19:47:31.436314
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    dfa = [
        DFAState({'x': 1, 'y': 1}, 'z', False),
        DFAState({'z': 1}, 'z', True),
    ]
    first = dfa[0].arcs
    first['x'].arcs['x'] = dfa[0].arcs['y']
    first['y'].arcs['y'] = first['y']
    first['z'] = dfa[1]
    print(first['y'].arcs['y'] is first['y'])
    pgen = ParserGenerator()
    pgen.dump_dfa('name', dfa)

# Generated at 2022-06-11 19:47:40.701856
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    # This is an automatically generated unit test for method
    # ParserGenerator.raise_error of class ParserGenerator,
    # generated using the tools/generate_tests.py script.
    #
    # See that script for more information.
    instance = ParserGenerator(
        source=b"",
        filename="filename.txt",
        pgen_grammar=None,
        symbols={},
        first={},
        dfas={},
        startsymbol="startsymbol",
        generator=None,
        type=42,
        value="value",
        begin=(1, 2),
        end=(3, 4),
        line="line",
    )

# Generated at 2022-06-11 19:48:23.410002
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    pg = ParserGenerator()
    pg.dfas = {"foo": None, "bar": None, "baz": None}
    pg.first = {
        "bar": {"x": 1, "y": 1},
        "baz": {"y": 1},
        "foo": {"a": 1, "x": 1, "y": 1},
    }
    c = pg.make_converter()
    assert c.make_first(c, "bar") == {c.labels.index(("x", None)): 1,
                                      c.labels.index(("y", None)): 1}
    assert c.make_first(c, "baz") == {c.labels.index(("y", None)): 1}

# Generated at 2022-06-11 19:48:33.655681
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    rg = NFAState()
    rb = NFAState()
    rc = NFAState()
    rg.addarc(rb, 'a')
    rg.addarc(rc, 'a')
    rg.addarc(rb, 'b')
    rb.addarc(rc, 'a')
    rb.addarc(rb, 'a')
    rb.addarc(rb, 'b')
    rc.addarc(rc, 'b')
    rg.addarc(rc, None)
    rb.addarc(rc, None)
    p = ParserGenerator()
    dfa = p.make_dfa(rg, rc)
    # p.dump_dfa('', dfa)
    assert len(dfa) == 3
    assert dfa[0].isfinal == False
    assert d

# Generated at 2022-06-11 19:48:39.273147
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    filename = "ParserGenerator_parse_rhs"
    pg = ParserGenerator()
    pg.setup_parser(filename)
    with open(filename) as file:
        pg.prepare_file(file)
    r, s = pg.parse_rhs()

    assert isinstance(r, NFAState)
    assert isinstance(s, NFAState)

    pass

if __name__ == "__main__":
    test_ParserGenerator_parse_rhs()



# Generated at 2022-06-11 19:48:46.652882
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    from .test_pgen2 import check_ParserGenerator
    check_ParserGenerator(ParserGenerator)

if __name__ == "__main__":
    import sys

    if sys.argv[1:]:
        # pgen2.py sample-grammar
        filename = sys.argv[1]
    else:
        # pgen2.py --test
        filename = "Grammar.txt"
    f = open(filename)
    text = f.read()
    f.close()
    pg = ParserGenerator()
    gram = pg.parsestring(text, filename)
    gram.dump()
    print("---")
    c = gram.convert()
    c.dump()
    c.write("Grammar")

# Generated at 2022-06-11 19:48:50.355255
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    pg = ParserGenerator()
    s = "(single|double) quoted string"
    i = iter(tokenize.generate_tokens(StringIO(s).readline))
    a, z = pg.parse_atom(i)
    assert a is z
    assert len(a.arcs) == 2
    for label, next in a.arcs:
        assert label in ("single", "double")


if __name__ == "__main__":
    test_ParserGenerator_parse_atom()

# Generated at 2022-06-11 19:48:58.190865
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    import re

    class DebugGenerator(ParserGenerator):
        def dump_dfa(self, name, dfa):
            print("Dump of DFA for", name)
            for i, state in enumerate(dfa):
                print("  State", i, state.isfinal and "(final)" or "")
                for label, next in sorted(state.arcs.items()):
                    print("    %s -> %d" % (repr(label), dfa.index(next)))

    pg = DebugGenerator([], [], [])

    print()
    print("Test 1")
    dfa = pg.make_dfa(*pg.parse_alt([(token.NAME, "a"), (token.OP, "+")]))
    print()
    print("Test 2")

# Generated at 2022-06-11 19:49:09.907940
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    # states (existential quantifiers, remember?)
    a, b, c, d, e, f, g, h, i, j, k, l, m, n, o, p = [DFAState({}) for i in range(16)]
    dfa = [a, b, c, d, e, f, g, h, i, j, k, l, m, n, o, p]

    # arcs (universal quantifiers, remember?)
    for state in dfa:
        for target in dfa:
            for label in ("x", "y"):
                state.addarc(target, label)

    pg = ParserGenerator()
    pg.simplify_dfa(dfa)

    assert len(dfa) == 1
    assert dfa[0].arcs == a.arcs

# Unit test

# Generated at 2022-06-11 19:49:20.885997
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    import parser
    import tokenize
    import io
    import token
    import sys

    text = """
# A test case with a single rule
foo: bar baz quux | NAME     # NOTE: The baz also matches the |
        | NUMBER | STRING
bar: "foo"
baz: 'bar'
quux: '''foo'''

# A test case with a left recursion:
expr: expr op term | term
term: NAME | NUMBER
op: "+" | "-" | "*"
"""
    tokens = tokenize.generate_tokens(io.StringIO(text).readline)
    p = ParserGenerator()
    p.setup(tokens, "testfile")
    p.addfirstsets()
    c = p.make_grammar((parser,))


# Generated at 2022-06-11 19:49:32.259747
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    pg = ParserGenerator()
    result = pg.make_grammar(
        """
        b : a | c ;
        a : A ;
        c : C ;
        """
    )
    # The following is a list of tuples ('symbol', set('first set')).
    # It is sorted for easier testing.
    assert sorted(result[0].items()) == [
        ('a', [('A', None)]),
        ('b', [('A', None), ('C', None)]),
        ('c', [('C', None)]),
    ]
    assert result[1] == 'b'

    pg = ParserGenerator()

# Generated at 2022-06-11 19:49:42.860883
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    pg = ParserGenerator(StringIO(""))
    pg.first["name"] = {"value1":1, "value2":1, "value3":1}
    pg.symbol2number = {"name":5}
    #
    c = PgenGrammar()
    c.symbol2number = {"value1":1, "value2":2, "value3":3}
    c.labels = [(1,None), (2,None), (3,None)]
    #
    first = pg.make_first(c, "name")
    return first == {1:1, 2:1, 3:1}


# Generated at 2022-06-11 19:50:54.880304
# Unit test for method addfirstsets of class ParserGenerator

# Generated at 2022-06-11 19:51:08.470387
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    text = """
        test: bar | baz
        bar: foo
        baz: foo
        foo: NAME
    """
    p = ParserGenerator().parse(text)
    assert len(p.dfas) == 4
    assert len(p.first) == 0
    p.addfirstsets()
    assert p.first["test"] == {
        "NAME": 1
    }
    assert p.first["bar"] == {
        "NAME": 1
    }
    assert p.first["baz"] == {
        "NAME": 1
    }
    assert p.first["foo"] == {
        "NAME": 1
    }


if __name__ == "__main__":
    import sys

    if len(sys.argv) == 2:
        filename = sys.argv[1]

# Generated at 2022-06-11 19:51:18.185112
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    def _test(src):
        pg = ParserGenerator()
        grammar = pg.make_grammar(src)
        return grammar
    def _test_with_copy(src):
        pg = ParserGenerator()
        pg.make_grammar(src)
        grammar = pg.make_grammar(src)
        return grammar
    def _test_with_pickle(src):
        pg = ParserGenerator()
        pg.make_grammar(src)
        data = pickle.dumps(pg)
        pg2 = pickle.loads(data)
        grammar = pg2.make_grammar(src)
        return grammar
    def _test_with_pyc(src):
        pg = ParserGenerator()
        pg.make_grammar(src)

# Generated at 2022-06-11 19:51:24.385950
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    from os.path import join as path_join
    from .indenter import Indenter
    from .tokenizer import Tokenizer
    grammar = ParserGenerator(
        {
            Indenter: "indenter",
            Tokenizer: "tokenizer",
            ParserGenerator: "pgen",
            PgenGrammar: "pgen_grammar",
        },
        path_join(__path__[0], "Grammar.txt"),
    ).make_grammar()  # type: ignore
# End of unit test



# Generated at 2022-06-11 19:51:33.436209
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    pg = ParserGenerator()
    pg.dfas["foo"] = [DFAState({}, False), DFAState({}, True)]
    pg.first["bar"] = {"x": 1, "y": 1}
    pg.symbol2number["foo"] = 1
    c = pg.convert()
    pg.make_first(c, "bar")
    # The result is a set of labels, e.g.
    # {'COMMA': 4, 'DOT': 8, 'ELLIPSIS': 9, 'ID': 12, 'LPAR': 13, 'LSQB': 15,
    # 'NAME': 11, 'NUMBER': 10, 'OP': 2, 'STRING': 5}



# Generated at 2022-06-11 19:51:37.389304
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    g = ParserGenerator()
    ##assert g.expect(token.ENDMARKER) == "^Z"
    assert g.expect(token.NAME) == "NAME"
    assert g.expect(token.OP, ":") == ":"
    assert g.expect(token.OP, ":") == ":"
    g.expect(token.ENDMARKER)


# Generated at 2022-06-11 19:51:48.900018
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    # Test case from issue #3555
    p = ParserGenerator()
    start = DFAState({0: 1}, isfinal=True)
    start.addarc(DFAState({1: 1}, isfinal=True), "a")
    start.addarc(DFAState({2: 1}, isfinal=True), "b")
    start.addarc(DFAState({3: 1}, isfinal=True), "c")
    dfa = [start]
    p.simplify_dfa(dfa)
    assert len(dfa) == 3
    assert dfa[0].nfaset == {0: 1}
    assert dfa[1].nfaset == {1: 1}
    assert dfa[2].nfaset == {2: 1}
    #
    start = DFA

# Generated at 2022-06-11 19:51:56.705144
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    import pprint, io
    from .parser import ParserGenerator
    parser = ParserGenerator(io.StringIO("alt: x | y\n"), 'test', False)
    dfa = parser.dfas['alt']
    out = io.StringIO()
    parser.dump_dfa('alt', dfa)
    assert out.getvalue().endswith("""Dump of DFA for alt
  State 0 {}
    x -> 1
    y -> 2
  State 1 (final)
  State 2 (final)
""")

# Generated at 2022-06-11 19:52:06.662770
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    test_text = """
\t[0-9]+
"""
    with pytest.raises(SyntaxError) as exc_info:
        ParserGenerator(test_text).parse()
    assert exc_info.match(r'SyntaxError\(msg=\'expected \(...\) or NAME or STRING, got 1/\'\[0-9\'\)\', file=\'<string>\', line=3, column=1\)')

    test_text = """
\t[0-9]+
"""
    with pytest.raises(SyntaxError) as exc_info:
        ParserGenerator(test_text).parse()

# Generated at 2022-06-11 19:52:16.424618
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    import io
    import sys
    import tokenize
    from unittest import mock
    from . import pgen
    from .grammar import STRING

    ys = tokenize.generate_tokens(io.StringIO("").readline)
    p = pgen.ParserGenerator(ys, "<unit test>")

    # Patch gettoken() to remove the call to next() over an IO object.
    p.gettoken = lambda: None
    # Patch raise_error's call to raise SyntaxError to print msg arg only
    p.raise_error = lambda m, *a: print(m)


# Generated at 2022-06-11 19:54:32.822021
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    pg = ParserGenerator(
        "S",
        {"S": [[("a", 1), ("b", 0)], [("c", 1), ("d", 0)]]},
        {"S": 1},
    )
    assert pg.startsymbol == "S"
    assert pg.dfas == {"S": [{}, {}]}
    assert pg.first == {"S": {"a": 1, "b": 1, "c": 1, "d": 1}}


# Generated at 2022-06-11 19:54:41.016998
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    s = """
S: "-" S | "(" S ")" S | "0"
"""
    parser = ParserGenerator()
    parser.compile(s)
    r = parser.dfas["S"][0].nfaset
    assert len(r) == 5
    for i, state in enumerate(r):
        # print i, state.arcs
        if i == 0 or i == 4:
            assert len(state.arcs) == 1
            assert state.arcs[0][0] == "0"
        elif i == 1:
            assert len(state.arcs) == 3
            assert state.arcs[0][0] == "-"
            assert state.arcs[1][0] == "("
            assert state.arcs[2][0] == None

# Generated at 2022-06-11 19:54:44.115931
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    pg = ParserGenerator()
    pg.input("foo")
    pg.gettoken()
    pg.parse_item()
    assert False, "TODO: test this"

# Generated at 2022-06-11 19:54:49.213882
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    pg = ParserGenerator(["# a comment\n\nLBRACE : '['\n"], "fname")
    pg.gettoken()
    assert pg.type == token.NAME
    pg.expect(token.NAME, "LBRACE")
    assert pg.value == "LBRACE"
    pg.expect(token.OP, ":")
    pg.expect(token.STRING, "[")


# Generated at 2022-06-11 19:54:53.422450
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    import sys
    import io
    import tokenize
    generator = iter(tokenize.generate_tokens(io.StringIO("(test)").readline))
    parser = ParserGenerator(generator, "", "")

    parser.gettoken()
    a, z = parser.parse_atom()
    assert (a.arcs, z.arcs) == ([(None, z)], [(None, a)])


# Generated at 2022-06-11 19:55:06.293274
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    def test(s : str, expected : Tuple["NFAState","NFAState"]):
        parser_gen = ParserGenerator()
        parser_gen.init_grammar()
        parser_gen.init_dfas()
        tokens = parser_gen.tokenize(s)
        actual = parser_gen.parse_item()
        assert expected == actual


# Generated at 2022-06-11 19:55:18.546148
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    import io
    import sys
    import token

    code = """\
# comment
expr:
    x='x'
    | x='x' '+' y  # comment
    | x='x' '-' y

# comment
"""
    f = io.StringIO(code)
    tokr = tokenize.generate_tokens(f.readline)
    tokr = (tok for tok in tokr if tok[0] not in (token.COMMENT, token.NL))
    parser = ParserGenerator(tokr, "foo.py")
    dfas, startsymbol = parser.parse()

    # Test ParserGenerator.dump_nfa()
    saved = sys.stdout

# Generated at 2022-06-11 19:55:26.509086
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    foo = ParserGenerator()
    class C:
        labels: List[Tuple[int, Optional[Text]]] = []
        symbol2number: Dict[Text, int] = {}
        symbol2label: Dict[Text, int] = {}
        dfas: Dict[int, Tuple[List[Any], Dict[int, int]]] = {}
        tokens: Dict[int, int] = {}
        keywords: Dict[Text, int] = {}
    c = C()
    c.symbol2number = {
        "a": 1,
        "b": 2,
        "c": 3,
        "d": 4,
        "e": 5,
        "f": 6,
        "g": 7,
        "h": 8,
        "i": 9}
    foo.make_

# Generated at 2022-06-11 19:55:33.118113
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    parser = ParserGenerator()
    parser.addfirstsets()
    assert parser.first["atom"] == {
        "(": 1,
        "CHAR": 1,
        "NAME": 1,
        "NUMBER": 1,
        "OP": 1,
        "STRING": 1,
        "operator": 1,
        "trailer": 1,
    }
    assert parser.first["factor"] == {"+": 1, "-": 1, "(": 1, "NOT": 1, "NAME": 1, "NUMBER": 1}
    assert parser.first["power"] == {"CHAR": 1, "NAME": 1, "NUMBER": 1, "OP": 1, "STRING": 1}


# Generated at 2022-06-11 19:55:44.949125
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    from . import parser
    from .pgen import Grammar
    from .token import generate_tokens
    import tokenize
    import io
