

# Generated at 2022-06-11 19:46:21.622076
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    pg = ParserGenerator()
    a, b = pg.parse_atom()
    assert a == b

# Generated at 2022-06-11 19:46:26.645550
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():

    def check(expected, *args):
        obj = ParserGenerator()
        obj.dump_nfa(*args)
        assert obj.output == expected

    def check_many(expected, cases):
        obj = ParserGenerator()
        for args in cases:
            obj.dump_nfa(*args)
        assert obj.output == expected

    GREETING = "Dump of NFA for greeting"
    GREETING1 = "  State 0"
    GREETING2 = "  State 1 (final)"
    GREETING3 = "    -> 1"
    GREETING4 = "    'hi ' -> 2"
    GREETING5 = "    'hello ' -> 3"
    GREETING6 = "  State 2"
    GREETING7 = "  State 3"

# Generated at 2022-06-11 19:46:32.918983
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    pg = ParserGenerator()
    pg.dfas["name"] = [DFAState({}, False)]
    pg.first["name"] = {"abc": 1}
    pg.calcfirst("name")
    assert pg.first["name"] == {"abc": 1}
    pg.dfas["name"] = [DFAState({}, False), DFAState({}, True)]
    pg.calcfirst("name")
    assert pg.first["name"] == {"abc": 1, 0: 1}
    pg.dfas["name"][0].addarc(pg.dfas["name"][1])
    pg.calcfirst("name")
    assert pg.first["name"] == {"abc": 1, 0: 1}
    pg.dfas["name"][1].addarc(pg.dfas["name"][0])


# Generated at 2022-06-11 19:46:43.107916
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    import filecmp
    from .pgen2 import token

    def _compare_dfas(dfas, dfas_expected):
        for name in sorted(dfas):
            dfa = dfas[name]
            dfa_expected = dfas_expected[name]
            assert [state.isfinal for state in dfa] == [state.isfinal for state in dfa_expected], (
                name,
                [state.isfinal for state in dfa],
                [state.isfinal for state in dfa_expected],
            )

            arcs = []
            for state in dfa:
                arcs.append([(l, dfa.index(n)) for l, n in sorted(state.arcs.items())])
            arcs_expected = []

# Generated at 2022-06-11 19:46:54.660435
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    gen = ParserGenerator()
    gen.add_production("root", ["one"])
    gen.add_production("one", ["two"])
    gen.add_production("one", ["three"])
    gen.add_production("two", ["a", "b"])
    gen.add_production("two", ["a"])
    gen.add_production("two", ["b"])
    gen.add_production("two", ["c"])
    gen.add_production("three", ["a", "b"])
    gen.add_production("three", ["c"])
    gen.add_production("three", ["d"])
    gen.add_production("three", ["e"])
    gen.addfirstsets()
    states = []

# Generated at 2022-06-11 19:47:01.423325
# Unit test for method gettoken of class ParserGenerator

# Generated at 2022-06-11 19:47:08.873701
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    import difflib
    from .grammar import Lib2to3Grammar

    cases = [
        Lib2to3Grammar,
        Grammar,
        Grammar,
    ]
    for cls in cases:
        pg = cls()
        c = pg.parse_grammar()
        c2 = pg.convert()
        s = c2.sourcetext()
        for line in difflib.ndiff(pg.sourcetext.splitlines(), s.splitlines()):
            print(line)

__all__ = ("Grammar", "NFASTATE")

# Generated at 2022-06-11 19:47:14.323482
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    input = 'a'
    parser = ParserGenerator([(token.NAME, 'a')])
    actual = parser.parse_atom()
    expected = (NFAState([(None, NFAState())]), NFAState())
    assert actual == expected



# Generated at 2022-06-11 19:47:19.382466
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    pg = PgenGrammar()
    assert pg.p_start == "file_input"
    assert pg.symbol2number["file_input"] == 256
    assert pg.number2symbol[256] == "file_input"


# Unit-test: init_parsing()
#   Tests that init_parsing() returns a list of tokens starting with an ENDMARKER

# Generated at 2022-06-11 19:47:25.875156
# Unit test for method addarc of class NFAState
def test_NFAState_addarc():
    nfa_state_object = NFAState()
    next_value = NFAState()
    nfa_state_object.addarc(next_value, None)
    # print(nfa_state_object.arcs)
    nfa_state_object.addarc(next_value, "label")
    # print(nfa_state_object.arcs)



# Generated at 2022-06-11 19:48:01.507090
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    foo = ParserGenerator()
    dfas = {}
    try:
        from .pgen2_grammar import dfas as dfas
    except:
        pass
    for name, dfa_states in dfas.items():
        dfa = [DFAState(nfa_set, None) for nfa_set in dfa_states]
        for i, state in enumerate(dfa):
            for label, next in state.arcs.items():
                state.arcs[label] = dfa[next]
        foo.dfas[name] = dfa
        foo.dump_dfa(name, dfa)



# Generated at 2022-06-11 19:48:06.510134
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    g = ParserGenerator("foo")
    g.gettoken()
    assert g.type == token.NAME
    assert g.value == "foo"
    g.gettoken()
    assert g.type == token.ENDMARKER
    assert g.value == ""


# Generated at 2022-06-11 19:48:18.052393
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    c = ParserGenerator()
    c.labels = []
    c.symbol2number = {"NAME": 1, "expr": 2}
    c.tokens = {token.NAME: 3, token.PLUS: 4, token.NEWLINE: 5}
    c.keywords = {"def": 6, "2": 7}
    c.symbol2label = {"NAME": 8}
    assert c.make_label(c, "NAME") == 8
    assert c.make_label(c, "expr") == 0
    assert c.make_label(c, "token.PLUS") == 4
    assert c.make_label(c, '"def"') == 6
    assert c.make_label(c, '"2"') == 7

# Generated at 2022-06-11 19:48:22.878499
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    p = ParserGenerator()
    p.first = {'a': {'<': 1}}
    grammar = p.make_grammar()
    labels = grammar.labels
    assert_equals(labels, [
        (token.NAME, "<"),
        (token.NAME, "a")
    ])
    assert_equals(grammar.first[grammar.symbol2number["a"]], {0: 1})

# Generated at 2022-06-11 19:48:24.791785
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    test_files = (
        [
            "../resources/Scratch/startup.txt",
        ]
    )

    for file in test_files:
        p1 = PgenGrammar(file)



# Generated at 2022-06-11 19:48:34.148333
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    pg = ParserGenerator()
    # (('a'|'b')*|'c')
    start = NFAState()
    finish = NFAState()
    a = NFAState()
    b = NFAState()
    c = NFAState()
    start.addarc(a)
    start.addarc(c)
    a.addarc(b, 'a')
    a.addarc(b, 'b')
    b.addarc(a)
    c.addarc(finish, 'c')
    dfa = pg.make_dfa(start, finish)
    print("Dump of DFA")
    for i, state in enumerate(dfa):
        print("  state", i, state.isfinal and "(final)" or "")

# Generated at 2022-06-11 19:48:34.860396
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error(): assert True


# Generated at 2022-06-11 19:48:36.280486
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    pg = ParserGenerator()
    pg.parse()


# Generated at 2022-06-11 19:48:44.607629
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    from . import token
    p = ParserGenerator(tokenize.generate_tokens(StringIO("()").readline), "<input>")
    p.gettoken()
    a, z = p.parse_atom()
    assert p.value == ")"
    assert a.arcs == []
    assert z.arcs == []

    p = ParserGenerator(tokenize.generate_tokens(StringIO("a").readline), "<input>")
    p.gettoken()
    a, z = p.parse_atom()
    assert p.type == token.ENDMARKER
    assert a.arcs == [(None, z)]
    assert z.arcs == [("a", a)]


# Generated at 2022-06-11 19:48:46.208461
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    p = ParserGenerator()
    p.dump_nfa('foo', NFAState(), NFAState())
    assert False, "unimplemented"


# Generated at 2022-06-11 19:49:42.109363
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    pg = ParserGenerator()
    pg.make_labels()
    assert pg.make_first(pg, "<stmt>") == {1: 1}
    assert pg.make_first(pg, "<suite>") == {1: 1}
    assert pg.make_first(pg, "<decorated>") == {1: 1}
    assert pg.make_first(pg, "<classdef>") == {1: 1}
    assert pg.make_first(pg, "<funcdef>") == {1: 1}
    assert pg.make_first(pg, "<parameters>") == {1: 1, 33: 1}
    assert pg.make_first(pg, "<varargslist>") == {1: 1, 33: 1}
    assert pg.make_first(pg, "<typedargslist>")

# Generated at 2022-06-11 19:49:54.909596
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    import io
    import tokenize
    from .pgen2 import driver


# Generated at 2022-06-11 19:50:07.767093
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    TestCase = unittest.TestCase
    r"""Test the 'calcfirst' function."""
    # Assume the grammar is contained in a string.

# Generated at 2022-06-11 19:50:17.663380
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    from .pgen import ParserGenerator
    from .dfa import DFAState
    from .converter import PgenGrammar
    import token, tokenize
    pgen = ParserGenerator()
    pgen.addtoken("NAME", token.NAME)
    pgen.addtoken("STRING", token.STRING)
    pgen.addtoken("r'[a-z]*'", token.NAME)
    pgen.addtoken("r'if'", token.NAME)
    pgen.addtoken("r'then'", token.NAME)
    pgen.addtoken("r'else'", token.NAME)
    pgen.addtoken("r'while'", token.NAME)
    pgen.addtoken("r'do'", token.NAME)

# Generated at 2022-06-11 19:50:19.751282
# Unit test for function generate_grammar
def test_generate_grammar():
    p = ParserGenerator("Grammar.txt")
    p.make_grammar()



# Generated at 2022-06-11 19:50:27.377284
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    pg = ParserGenerator(["var: NAME | '[' RULE ']'"])
    a, z = pg.parse_rhs()
    pg.dump_nfa("var", a, z)
    # Output:
    # Dump of NFA for var
    #   State 0
    #     NAME -> 1
    #     [' -> 2
    #   State 1
    #     -> 2
    #   State 2
    #     RULE -> 3
    #   State 3
    #     ] -> 4
    #   State 4

# Generated at 2022-06-11 19:50:29.367355
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    pg = ParserGenerator()
    pg.parse(r"""
        # This is a comment
        start: word word word
        word: WORD '!' | WORD
        """)



# Generated at 2022-06-11 19:50:39.588553
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    from .converter import PgenGrammar
    parser = ParserGenerator()
    c = PgenGrammar()
    c.symbols.append('foo')
    c.symbol2number['foo'] = 1
    c.labels.append((token.NAME, 'bar'))
    c.tokens[token.NAME] = 2
    assert parser.make_label(c, 'foo') == 1
    assert parser.make_label(c, 'NAME') == 2
    assert parser.make_label(c, '"baz"') == 3



# Generated at 2022-06-11 19:50:49.661272
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    from test.libregrtest.refleak import DashboardReport

    def test_expect(text):
        gen = ParserGenerator()
        gen.filename = "test"
        gen.type = token.STRING
        gen.value = "foo"
        gen.begin = (0, 0)
        gen.end = (0, 0)
        gen.line = ""
        gen.generator = iter([(token.ENDMARKER, "", gen.end, gen.end, "")])
        got = gen.expect(token.STRING, text)
        assert got == text, got
        with pytest.raises(SyntaxError):
            gen.expect(token.NAME, text)

    test_expect("foo")
    test_expect("bar")



# Generated at 2022-06-11 19:50:55.322353
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    p = ParserGenerator()
    p.generator = iter(
        [
            (token.NAME, "foo", (1, 0), (1, 3), "foo"),
            (token.ENDMARKER, "", (2, 0), (2, 0), ""),
        ]
    )
    p.gettoken()
    assert p.type == token.NAME
    p.parse_atom()

# Generated at 2022-06-11 19:54:48.740277
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    print("Testing make_grammar")
    from .pgen2 import driver as pgen2_driver
    from .pgen2 import pgen

    parser, samples = pgen2_driver.test_grammar_samples()

    for sample in samples:
        if len(sample) == 2:
            # Normal case
            name, (grammar, first, follow) = sample
            print("Testing", name)

        else:
            # Special case
            name, (grammar, first, follow), messages = sample
            print("Testing", name, "with extra error messages")

        print("Grammar", grammar)
        print("Firsts", first)

        p = ParserGenerator(parser, grammar)
        g = p.make_grammar()


# Generated at 2022-06-11 19:54:54.172787
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    pg = ParserGenerator()
    pg.make_generator("test", "a: 'a'\n")
    a, z = pg.parse_rhs()
    assert z is not None
    assert z is not a
    assert len(a.arcs) == 1
    assert a.arcs[0][0] == 'a'
    assert a.arcs[0][1] is z
    assert not a.arcs[0][1].arcs



# Generated at 2022-06-11 19:55:06.453503
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    # ParserGenerator.simplify_dfa(dfa, todo):
    nfa1 = NFAState()
    nfa2 = NFAState()
    nfa3 = NFAState()
    nfa4 = NFAState()
    nfa5 = NFAState()
    nfa6 = NFAState()
    nfa7 = NFAState()
    nfa8 = NFAState()
    nfa9 = NFAState()
    nfa10 = NFAState()
    nfa11 = NFAState()
    nfa12 = NFAState()
    nfa13 = NFAState()
    nfa14 = NFAState()


# Generated at 2022-06-11 19:55:18.588938
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    pg = ParserGenerator()

    # Using numbers for symbol names so we can easily tell which are
    # non-terminals and which are terminals.
    pg.add_non_terminal('1', [('2', '3', '4')])
    pg.add_non_terminal('2', [('5', '1')])
    pg.add_non_terminal('3', [('6',)])
    pg.add_non_terminal('4', [('1',)])
    # left recursion
    pg.add_non_terminal('5', [('1',)])

    pg.addfirstsets()
    pg.check()
    c = pg.convert()

# Generated at 2022-06-11 19:55:21.307229
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    pg = ParserGenerator()
    # Test with no arguments, defaulting to stdin
    pg.generate_parser([])
    # Test with a filename
    pg.generate_parser([sys.argv[0]])


# Generated at 2022-06-11 19:55:29.940757
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    pgen = ParserGenerator()
    dfa = [DFAState({'a': 1, 'b': 1}, False)]
    dfa.append(DFAState({'a': 1, 'b': 1}, False))
    dfa.append(DFAState({'a': 1, 'b': 1}, False))
    dfa.append(DFAState({'a': 1, 'b': 1}, False))
    dfa[0].addarc(dfa[2], 'a')
    dfa[0].addarc(dfa[1], 'b')
    dfa[1].addarc(dfa[0], 'a')
    dfa[1].addarc(dfa[3], 'b')
    dfa[2].addarc(dfa[3], 'a')
    dfa[2].addarc

# Generated at 2022-06-11 19:55:37.689716
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    pg = ParserGenerator()
    pg.initdfas()
    # Simplest case: a single edge with no labels
    a = pg.newnfastate()
    z = pg.newnfastate()
    a.addarc(z, None)
    dfa = pg.make_dfa(a, z)
    assert len(dfa) == 1
    assert not dfa[0].isfinal
    assert not dfa[0].arcs
    # Another simple case: a -> b -> c -> d
    # where a, b, c and d are all states, and a, c and d are final
    a = pg.newnfastate()
    b = pg.newnfastate()
    c = pg.newnfastate()
    d = pg.newnfastate()

# Generated at 2022-06-11 19:55:50.942351
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    parser = ParserGenerator("<no filename>", iter([]), debug=1)
    # 1
    parser.type = token.STRING
    parser.value = "foo"
    parser.gettoken = lambda: None
    result = parser.parse_rhs()
    assert len(result) == 2 and isinstance(result[0], NFAState) and \
        isinstance(result[1], NFAState)
    # 2
    parser.type = token.NAME
    parser.value = "bar"
    parser.gettoken = lambda: None
    result = parser.parse_rhs()
    assert len(result) == 2 and isinstance(result[0], NFAState) and \
        isinstance(result[1], NFAState)
    # 3
    parser.type = token.OP