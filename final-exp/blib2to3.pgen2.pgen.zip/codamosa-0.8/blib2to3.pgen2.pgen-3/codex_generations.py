

# Generated at 2022-06-11 19:47:02.974458
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    class ParserGenerator_fake(object):
        def __init__(self):
            self.value = None
            self.type = None
            self.begin = None
            self.end = None
            self.line = None
        def raise_error(self, msg: str, *args: Any) -> NoReturn:
            raise SyntaxError()
    fake = ParserGenerator_fake()
    one = (fake.type, fake.value, fake.begin, fake.end, fake.line)
    two = (fake.type, fake.value, fake.begin, fake.end, fake.line)
    good_cases = [((token.NAME, "name", one, one, ""), ("name", "name")),
            ((token.STRING, "string", one, one, ""), ("string", "string"))]
   

# Generated at 2022-06-11 19:47:10.798214
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    pg = ParserGenerator()
    pg.filename = "(test file)"
    pg.type = 0
    pg.value = ""
    pg.begin = (0, 0)
    pg.end = (0, 0)
    pg.line = ""
    pg._state = 0
    #with open("Grammar", "rb") as f:
    #    pg.generator = tokenize.generate_tokens(f.readline)


# Generated at 2022-06-11 19:47:14.955423
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
	pg = ParserGenerator()
	pg.generator = tokenize.generate_tokens(StringIO("a").readline)
	pg.gettoken()
	a, z = pg.parse_rhs()
	assert a.arcs == {("a", z)}
	assert z.arcs == set()

	pg.generator = tokenize.generate_tokens(StringIO("abc").readline)
	pg.gettoken()
	a, z = pg.parse_rhs()
	assert a.arcs == {("a", b)}
	assert b.arcs == {("b", c)}
	assert c.arcs == {("c", z)}
	assert z.arcs == set()


# Generated at 2022-06-11 19:47:27.212022
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    a = ParserGenerator(iter([]))
    a.dfas = {"foo": [DFAState({}, False), DFAState({}, False)], "bar": [DFAState({}, True)]}
    a.dfas["foo"][0].addarc(a.dfas["foo"][1], "baz")
    a.dfas["foo"][0].addarc(a.dfas["foo"][0], "baz")
    a.dfas["foo"][0].addarc(a.dfas["foo"][1], "qux")
    a.dfas["foo"][0].addarc(a.dfas["bar"][0], "baz")
    a.calcfirst("foo")
    assert a.first['foo'] == {'qux': 1}
    a = Parser

# Generated at 2022-06-11 19:47:34.501652
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    pg = ParserGenerator()
    pg.generator = iter([(token.NAME, "footle", (0, 0), (0, 5), "footle")])
    pg.gettoken()
    pg.parse_item()

    pg.generator = iter([(token.NAME, "footle", (0, 0), (0, 5), "footle")])
    pg.gettoken()
    pg.parse_item()
    pg.gettoken()
    pg.parse_item()
    pg.gettoken()
    pg.parse_item()

# Generated at 2022-06-11 19:47:42.411842
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    print("test_ParserGenerator_parse:")
    pg = ParserGenerator()

# Generated at 2022-06-11 19:47:49.676615
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    parser = ParserGenerator()
    parser.gettoken = unittest.mock.Mock()

# Generated at 2022-06-11 19:48:00.806090
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    pg = ParserGenerator()
    assert pg.make_label({}, "") is None
    assert pg.make_label({}, "a") is None
    assert pg.make_label({}, "1") is None
    assert pg.make_label({}, "'a'") is None
    assert pg.make_label({}, '"a"') is None
    assert pg.make_label({}, "'a") is None
    assert pg.make_label({}, '"a') is None
    assert pg.make_label({}, "a'") is None
    assert pg.make_label({}, "a\"") is None
    assert pg.make_label({}, "expr") is None
    assert pg.make_label({}, "NUMBER") is None
    assert pg.make_label({}, "token.NUMBER") is None

   

# Generated at 2022-06-11 19:48:06.005256
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    pg = ParserGenerator(None, None)
    pg.type = token.NAME
    pg.value = "toto"
    pg.filename = "abc"
    pg.end = 0, 0
    pg.line = ""
    pg.expect(token.NAME)
    pg.type = token.OP
    pg.value = "+"
    pg.expect(token.OP, "+")
    pg.type = token.NAME
    pg.value = "toto"
    pg.expect(token.OP, "+")
    pg.expect(token.NAME, "-")



# Generated at 2022-06-11 19:48:17.783933
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    #
    # Try different kinds of labels:
    #
    import token
    import grammar

    tp = ParserGenerator()
    c = tp.convert()
    assert c.make_label(c, "NAME") == 0
    assert c.labels[0] == (token.NAME, None)
    assert c.tokens[token.NAME] == 0
    assert c.make_label(c, "NAME") == 0
    #
    assert c.make_label(c, "NUMBER") == 1
    assert c.labels[1] == (token.NUMBER, None)
    assert c.tokens[token.NUMBER] == 1
    assert c.make_label(c, "NUMBER") == 1
    assert len(c.labels) == 2

# Generated at 2022-06-11 19:49:17.163279
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    # SF bug 506286 -- infinite loop when a symbol has two FIRST sets
    # that overlap and one is nullable.
    pgen = ParserGenerator()
    pgen.add_rhs("start", ["foo", "bar"])
    pgen.add_rhs("foo", ["foo", "x"])
    pgen.add_rhs("foo", [])
    pgen.start = "start"
    pgen.calcfirstsets()
    pgen.make_grammar()

# Generated at 2022-06-11 19:49:24.403845
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    # Compare ParserGenerator.make_grammar's output
    # with that of my handwritten converter.
    original = ElispGrammar().convert()
    new_converter = ParserGenerator()
    pos = new_converter.make_grammar(original)


# Generated at 2022-06-11 19:49:34.705843
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    pg = ParserGenerator()
    pg.generator = iter([
        (tokenize.NAME, 'x', (0, 0), (0, 1), ''),
        (tokenize.OP, ':', (0, 2), (0, 3), ''),
        (tokenize.NAME, '', (0, 4), (0, 4), ''),
        (tokenize.OP, '|', (0, 5), (0, 6), ''),
        (tokenize.NAME, '', (0, 7), (0, 7), ''),
        (tokenize.NEWLINE, '\n', (0, 8), (0, 9), ''),
        (tokenize.ENDMARKER, '', (0, 10), (0, 10), '')
    ])
    pg.gettoken()

# Generated at 2022-06-11 19:49:36.482955
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    assert isinstance(PgenGrammar, type)


# Generated at 2022-06-11 19:49:47.095157
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    # Test gluing together bits of the compiler to make a pygram.grammar.
    # I'm hoping to replace much of the code in python/compile.c
    # with it.

    # hack so this test can be run repeatedly
    import pygram.symbol
    pygram.symbol.sym_name.clear()
    pygram.symbol.sym_name.update(pygram.symbol.sym_name_init)


# Generated at 2022-06-11 19:49:51.544286
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    pg = ParserGenerator()
    pg.generator = tokenize.generate_tokens(io.StringIO('x = 8\n').readline)
    for n in range(4):
        pg.gettoken()
    assert pg.value == 8


# Generated at 2022-06-11 19:50:02.683268
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    pgen = ParserGenerator()
    a = NFAState()
    b = NFAState()
    c = NFAState()
    d = NFAState()
    e = NFAState()
    f = NFAState()
    a.addarc(c)
    a.addarc(b, "a")
    b.addarc(c, "b")
    b.addarc(d)
    c.addarc(e, "c")
    e.addarc(f)
    d.addarc(f)
    dfa = pgen.make_dfa(a, f)
    pgen.simplify_dfa(dfa)
    assert len(dfa) == 2
    assert len(dfa[0].arcs) == 3

# Generated at 2022-06-11 19:50:11.926328
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    gen = ParserGenerator("")  # doctest: +ELLIPSIS
    gen.type = token.NAME
    gen.value = "foo"
    assert gen.expect(token.NAME) == "foo"
    gen.type = token.STRING
    gen.value = '"bar"'
    assert gen.expect(token.STRING) == '"bar"'
    assert pytest.raises(SyntaxError, gen.expect, token.NAME)
    assert pytest.raises(SyntaxError, gen.expect, token.STRING, "bar")

# Generated at 2022-06-11 19:50:20.102099
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    test_input = '    return a, z'
    def test_method(input_str):
        try:
            tokens = list(tokenize.tokenize(BytesIO(input_str.encode("utf-8")).readline))
            return ParserGenerator(tokens).parse_atom()
        except StopIteration:
            return None
    assert test_method('') is None
    assert test_method('a') is None
    assert test_method('return') is None
    assert test_method('return return') is None
    assert test_method('return a') is None
    assert test_method('return a,') is None
    assert test_method('return a, z') is not None
    assert test_method('return a, z,') is None
    assert test_method('return a, z z') is None

# Generated at 2022-06-11 19:50:29.774750
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    t = DFA_Tester(ParserGenerator, "addfirstsets")

# Generated at 2022-06-11 19:51:26.201982
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    class C:
        labels = []
        symbol2number = {
            "foo": 1,
            "bar": 2,
            "baz": 3,
        }
        symbol2label = {
            "foo": 101,
            "bar": 102,
            "baz": 103,
        }
        tokens = {
            token.NAME: 201,
            token.NUMBER: 202,
            token.STRING: 203,
        }
        keywords = {
            'if': 301,
            'or': 302,
            'and': 303,
            # ...
        }

    c = C()
    p = ParserGenerator()
    p.make_label(c, 'NAME') == 201
    p.make_label(c, 'NUMBER') == 202

# Generated at 2022-06-11 19:51:27.676006
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    p = PgenGrammar()
    assert p is not None



# Generated at 2022-06-11 19:51:33.730050
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    """This is a test for the method parse_rhs of the ParserGenerator class"""
    pg = ParserGenerator("abc: def\n")
    a, z = pg.parse_rhs()
    assert isinstance(a, NFAState)
    assert len(a.arcs) == 1
    assert a.arcs[0][1] is z
    assert a.arcs[0][0] == "def"
    assert isinstance(z, NFAState)
    assert len(z.arcs) == 0


# Generated at 2022-06-11 19:51:46.948509
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    # XXX 1.54, 1.55, and 1.89 fail
    names = [
        "NAME",
        "NUMBER",
        "STRING",
        "def",
        "class",
        "async",
        "await",
        # "foo",
        # "=",
        # "==",
        # "!",
        # "[",
        # "{",
        # "<",
        # "<>",
        # "=>",
    ]
    text = "\n".join(names)
    gen = ParserGenerator()
    gen.parsedoc(text)
    gen.addfirstsets()
    c = gen.make_converter()

# Generated at 2022-06-11 19:51:53.326703
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    generator = ParserGenerator()
    # RHS: ALT ('|' ALT)*
    # ALT: ITEM+
    # ITEM: '[' RHS ']' | ATOM ['+' | '*']
    a, z = generator.parse_item()
test_ParserGenerator_parse_item()

# Generated at 2022-06-11 19:52:04.090276
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    import pgen2.parse
    import pgen2.pgen
    import pgen2.driver
    import pgen2.pgen

    class PG(pgen2.pgen.ParserGenerator):
        def __str__(self):
            return str(self.grammar)

    pe = parser.ParserError()
    pg = PG(pe)
    pg.grammar = test_grammar
    pg.make_grammar()



# Generated at 2022-06-11 19:52:14.782964
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
  import nfa
  nfa0 = nfa.NFAState()
  nfa1 = nfa.NFAState()
  nfa2 = nfa.NFAState()
  nfa3 = nfa.NFAState()
  nfa4 = nfa.NFAState()
  nfa5 = nfa.NFAState()
  nfa6 = nfa.NFAState()
  nfa7 = nfa.NFAState()
  nfa8 = nfa.NFAState()
  nfa9 = nfa.NFAState()
  nfa10 = nfa.NFAState()
  nfa11 = nfa.NFAState()
  nfa12 = nfa.NFAState()
  nfa13 = nfa.NFAState()
  nfa14 = nfa.NFAState()

# Generated at 2022-06-11 19:52:27.010765
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    import py
    import pgen2.pgen
    #
    # Load file and compute first sets
    #
    pg = pgen2.pgen.ParserGenerator()
    pg.load_grammar(py.path.local(__file__).dirpath().join('Grammar.txt'))
    pg.addfirstsets()
    #
    # Compare expected and actual output
    #
    expected = {}  # type: Dict[int, Tuple[List[Tuple[Optional[int], Optional[Text]]], Dict[int, int]]]
    for line in open(py.path.local(__file__).dirpath().join('Grammar.pgen')):
        name, kind, args = eval(line)
        if kind == "symbol":
            expected[name] = eval(args)
    #

# Generated at 2022-06-11 19:52:39.381017
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    p = ParserGenerator()
    p.addfirstsets()

# Generated at 2022-06-11 19:52:47.503957
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    fname = sys.path[0] + '/data/3.5/Grammar.txt'
    with open(fname, "r") as f:
        pgen = ParserGenerator().parse_grammar(f)
    pgen.addfirstsets()
    first = pgen.first

# Generated at 2022-06-11 19:54:36.949498
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    msg = "test message"
    pg = ParserGenerator(None)
    pg.end = (1, 2)
    pg.filename = "<string>"
    pg.line = "line"
    try:
        pg.raise_error(msg)
        raise AssertionError("pg.raise_error(\"%s\") didn't raise an exception" % msg)
    except SyntaxError as e:
        msg_error = "%s\n%%s" % msg
        assert e.msg == msg_error % "(<string>, 1, 2, line)", e.msg
        import traceback

        lines = traceback.format_exception_only(SyntaxError, e)
        assert len(lines) == 1, len(lines)
        assert lines[0].endswith(msg_error % "<string>" + "\n"), repr

# Generated at 2022-06-11 19:54:41.075179
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    pg = ParserGenerator()
    rule1 = Rule("rule", "a b c")
    rule2 = Rule("rule2", "d e")
    pg.add_rule(rule1)
    pg.add_rule(rule2)

# Generated at 2022-06-11 19:54:50.663568
# Unit test for method make_dfa of class ParserGenerator

# Generated at 2022-06-11 19:54:56.560326
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    def check_dfas(c) -> None:
        assert c.dfas
        assert len(c.dfas) == len(c.symbol2label) == len(c.symbol2number)
        for label, value in c.labels:
            if isinstance(label, int):
                assert label in c.tokens
            else:
                assert isinstance(value, str)
        for name, number in c.symbol2number.items():
            assert number in c.symbol2label
        for name, label in c.symbol2label.items():
            assert c.labels[label][0] == name
            assert name in c.symbol2number
        for number, label in c.symbol2label.items():
            assert isinstance(number, int)
            assert number in c.symbol2

# Generated at 2022-06-11 19:55:01.551591
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    parser = ParserGenerator("foo")
    parser.gettoken = lambda: 'foo'
    line = parser.gettoken()
    s = parser.parse_item()
    assert line == 'foo'
    assert s is not None

# Generated at 2022-06-11 19:55:10.178694
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    # The grammar for this test is in test1.txt, but hardcoded here
    # for convenience.  The grammar allows parentheses and square
    # brackets in arbitrary places in arithmetic expressions.
    grammar = ParserGenerator()

    # Add tokens to the symbol table
    grammar.add_token(token.PLUS, "PLUS")
    grammar.add_token(token.MINUS, "MINUS")
    grammar.add_token(token.STAR, "STAR")
    grammar.add_token(token.SLASH, "SLASH")
    grammar.add_token(token.LPAR, "LPAR")
    grammar.add_token(token.RPAR, "RPAR")
    grammar.add_token(token.LBRACE, "LBRACE")
    grammar.add_token(token.RBRACE, "RBRACE")


# Generated at 2022-06-11 19:55:20.222531
# Unit test for method parse of class ParserGenerator

# Generated at 2022-06-11 19:55:23.477194
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    pg = ParserGenerator(())
    pg.gettoken = lambda: None
    pg.type = token.OP
    pg.value = "("
    pg.parse_item()



# Generated at 2022-06-11 19:55:30.653970
# Unit test for method make_grammar of class ParserGenerator

# Generated at 2022-06-11 19:55:37.850912
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    # case [1]: single token
    start = NFAState()
    finish = NFAState()
    start.addarc(finish, 'a')
    assert ParserGenerator.parse_rhs(None, None, None, None, start, finish, None) == \
        ((start, finish), (start, finish))

    # case [2]: '|' single token
    start = NFAState()
    finish = NFAState()
    start.addarc(finish, 'a')
    assert ParserGenerator.parse_rhs(None, None, None, None, start, finish, '|') == \
        ((start, finish), (start, finish))

    # case [3]: single token '|'
    start = NFAState()
    finish = NFAState()