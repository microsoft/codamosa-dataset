

# Generated at 2022-06-11 19:46:43.952383
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    from .dfa import DFAState
    from .nfa import NFAState

    dfa = [
        DFAState(
            {
                NFAState(
                    {
                        (None, NFAState()),
                        ("b", NFAState({(None, NFAState()), ("a", NFAState())})),
                    }
                ): 1,
            },
            None,
        ),
        DFAState({NFAState({("b", NFAState())}): 1}, None),
        DFAState({NFAState(): 1}, None),
    ]
    dfa[0].addarc(dfa[1], "a")
    dfa[0].addarc(dfa[2], "c")
    dfa[1].addarc(dfa[2], "c")
    dfa[2].isf

# Generated at 2022-06-11 19:46:55.386976
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    pg = ParserGenerator()

    def _test_make_label(pg, label, expected):
        pg.labels = []
        pg.symbol2label = {}
        pg.keywords = {}
        pg.tokens = {}
        pg.symbol2number = {}
        for i in range(0, 256):
            pg.symbol2number[chr(i)] = i
        result = pg.make_label(pg, label)
        assert expected == result, (expected, result)
        del pg.labels[:]
        # XXX Can't del the rest because it's a closure


# Generated at 2022-06-11 19:47:06.932949
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    class DFAState:
        def __init__(self, nfaset: Dict[NFAState, int], isfinal: bool) -> None:
            self.nfaset = nfaset
            self.isfinal = isfinal
            self.arcs = {}  # type: Dict[str, NFAState]

        def __eq__(self, other: Any) -> bool:
            return isinstance(other, DFAState) and self.arcs == other.arcs

        def unifystate(self, old: "DFAState", new: "DFAState") -> None:
            for dst in self.arcs:
                if dst is old:
                    self.arcs[dst] = new


# Generated at 2022-06-11 19:47:19.130934
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    import io
    import tokenize
    import unittest
    import convert
    import unparse
    import parse
    import pgen
    import test.support
    import test.lib2to3.test_symparser
    import test.lib2to3.pgen2.tokenize
    import test.lib2to3.pgen2.tokenize

    class TestCase(unittest.TestCase):

        def test_expect(self):
            parser_generator = pgen.ParserGenerator()
            fout = io.StringIO()
            with test.support.captured_output("stderr", fout):
                unittest.TestCase.assertRaises(
                    self, ValueError, parser_generator.expect, "test_expect"
                )

# Generated at 2022-06-11 19:47:31.269441
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    from . import tokenize
    from .token import token
    from . import grammar

    class Testcase(ParserGenerator):
        pass

    p = Testcase(tokenize.generate_tokens(iter(["42 1"]).__next__), grammar.opmap)

    try:
        p.raise_error("expected %s/%s, got %s/%s", 1, 2, 3, 4)
    except SyntaxError as err:
        assert str(err) == "expected 1/2, got 3/4"
    else:
        raise


# Generated at 2022-06-11 19:47:40.628940
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    parser = ParserGenerator()
    c = PgenGrammar()
    parser.make_label(c, 'foo')
    parser.make_label(c, '"bar"')
    parser.make_label(c, "'baz'")
    parser.make_label(c, 'NAME')
    parser.make_label(c, 'NUMBER')
    parser.make_label(c, 'STRING')
    parser.make_label(c, 'bar')
    parser.make_label(c, '"foo"')
    parser.make_label(c, "'bar'")
    parser.make_label(c, 'baz')
    parser.make_label(c, '"baz"')
    parser.make_label(c, "'baz'")


# Generated at 2022-06-11 19:47:47.284942
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
#     def f(input):
#         pass
    try:
        pg = ParserGenerator()
        pg.parse('''
        start: rule1 rule2 'after'
        rule1: rule2 name
        rule2: 'toplevel' name
        ''')
        assert pg.startsymbol == 'start'
        assert pg.first == {
            'rule1': {'toplevel': 1},
            'rule2': {'toplevel': 1},
            'start': {'toplevel': 1}
        }
        assert pg.dfas
    except:
        print('test_ParserGenerator() did not return')



# Generated at 2022-06-11 19:47:54.148374
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():

    # Arrange
    generator = ParserGenerator()
    tokens = iter([(token.NAME, 'KEYWORD', (1, 0), (1, 7), 'KEYWORD')])
    generator.generator = tokens

    # Act
    generator.gettoken()
    generator.expect(token.NAME)

    # Assert
    assert True, "Unit test for ParserGenerator.expect() failed."

# Generated at 2022-06-11 19:48:04.301968
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    p = ParserGenerator()
    print("test result: %r" % p.dump_nfa.__doc__,)
    imports = """import sys
if sys.version_info < (3, 6, 0):
    raise Exception("This script requires Python 3.6 or later")
"""
    pgen_source = '''
%% grammar foo
%% start: "foo"

%% lexer
%% literal: NAME
%% pattern: [A-Za-z_]+[A-Za-z_0-9]*

%% literal: STRING
%% pattern: '"' [^"]* '"'

%% literal: NEWLINE
%% pattern: \n

%% literal: ENDMARKER
%% pattern: \Z
'''

# Generated at 2022-06-11 19:48:05.292439
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error(): pass


# Generated at 2022-06-11 19:49:00.012006
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    grammar = """
        test: (a | b+)*
        """
    dfas = ParserGenerator().make_dfas(StringIO(grammar))
    assert len(dfas) == 1, "got %d entries" % len(dfas)
    assert len(dfas[0]) == 5, "got %d states" % len(dfas[0])
    ParserGenerator().simplify_dfa(dfas[0])
    assert len(dfas[0]) == 3, "got %d states" % len(dfas[0])



# Generated at 2022-06-11 19:49:11.261978
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    pg = ParserGenerator(
        {
            "expr": [
                ["expr", "|", "x"],
                ["expr", "+", "expr"],
                ["(", "expr", ")"],
                ["NUMBER"],
            ],
            "x": [["NAME"]],
        },
        "expr",
    )

    # get the generated grammar
    grammar = pg.grammar()
    assert grammar

    # get the generated DFA
    dfa = pg.dfa()
    assert dfa

    # test states
    assert len(dfa.states) == 4
    assert len(dfa.states[0]) == 15
    assert len(dfa.states[1]) == 14
    assert len(dfa.states[2]) == 13
    assert len(dfa.states[3]) == 10

    # test

# Generated at 2022-06-11 19:49:21.769812
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
  pg = ParserGenerator()
  pg._ParserGenerator__generator = iter([(0, '234', (1, 0), (1, 0), '234')])

# Generated at 2022-06-11 19:49:33.049721
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    p = ParserGenerator()
    x = p.make_dfa(NFAState(), NFAState())
    p.simplify_dfa(x)
    assert len(x) == 1

    x = p.make_dfa(NFAState(), NFAState())
    x[0].addarc(x[0], "a")
    p.simplify_dfa(x)
    assert len(x) == 1

    x = p.make_dfa(NFAState(), NFAState())
    x[0].addarc(x[0], "a")
    x[0].addarc(x[0], "b")
    p.simplify_dfa(x)
    assert len(x) == 1

    x = p.make_dfa(NFAState(), NFAState())


# Generated at 2022-06-11 19:49:41.255399
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():

    # ParserGenerator.make_first returns a dict mapping labels to 1
    pg = ParserGenerator()
    first = {'x': 1}
    pg.first = {'a': first}
    i = {'x': 1}
    assert pg.make_first(None, 'a') == i

    # ParserGenerator.make_first raises a ValueError when the first set contains
    # two labels that are also keywords
    pg = ParserGenerator()
    first = {'and': 1, 'x': 1}
    pg.first = {'a': first}
    with pytest.raises(ValueError) as excinfo:
        pg.make_first(None, 'a')

# Generated at 2022-06-11 19:49:50.343329
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    class Mock:
        def __init__(self):
            self.type = 0
            self.value = ''
            self.begin = (0,0)
            self.end = (0,0)
            self.line = ''
        def gettoken(self):
            return
        def raise_error(self, msg: str, *args: Any) -> NoReturn:
            return
        def parse_atom(self) -> Tuple[NFAState, NFAState]:
            return (NFAState(), NFAState())

    tpg = ParserGenerator()
    tpg.generator = [('', '', (0,0), (0,0), '')]
    tpg.type = 0
    tpg.value = '('
    tpg.begin = (0,0)

# Generated at 2022-06-11 19:50:01.007156
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    from pgen2 import token
    from pgen2 import pgen
    from pgen2.pgen import ParserGenerator

    pg = ParserGenerator()
    pg.add_rhs(['comp_op', 'expr', 'expr'])
    pg.add_rhs(['print_stmt', 'rvalue'])
    pg.add_rhs(['print_stmt', 'rvalue', 'rvalue', 'rvalue'])
    pg.add_rhs(['rvalue', 'expr'])
    pg.add_rhs(['rvalue', 'star_expr'])
    pg.add_rhs(['rvalue', 'power', 'star_expr', 'trailer'])
    pg.add_rhs(['rvalue', 'star_expr', 'trailer'])
    pg.add_

# Generated at 2022-06-11 19:50:09.502905
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    c = ParserGenerator()
    dfa = c.NFAState()
    dfb = c.NFAState()
    dfc = c.NFAState()
    dfa.addarc(dfb, 'a')
    dfb.addarc(dfc, 'b')
    dfa.addarc(dfc, 'c')
    dfas = {'S': [dfa]}
    c.dfas = dfas
    c.addfirstsets()
    assert c.first == {'S': {'a': 1, 'c': 1}}


# Generated at 2022-06-11 19:50:10.595153
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    pass


# Generated at 2022-06-11 19:50:19.572715
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    def assert_nfa(
        name: str,
        chars: Sequence[Tuple[str, Optional[str]]],
        arcs: Sequence[Tuple[int, Optional[str], int]],
    ) -> None:
        p = ParserGenerator()
        p.make_tokenizer(chars)
        start, finish = p.parse_rhs()
        dfa = p.make_dfa(start, finish)
        assert len(dfa) == len(arcs)
        for i, (state, arcinfo) in enumerate(zip(dfa, arcs)):
            assert i == arcinfo[0], (name, i, arcinfo[0])
            expected = arcinfo[1]

# Generated at 2022-06-11 19:51:06.888415
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    import tokenize, io
    p = ParserGenerator(tokenize.generate_tokens(io.StringIO("def foo: pass")))
    p.expect(token.NAME)
    p.expect(token.NAME, "foo")
    p.expect(token.OP, ":")
    p.expect(token.NAME, "pass")


# Generated at 2022-06-11 19:51:17.220968
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    """Test case for ParserGenerator.make_grammar"""
    pgen = ParserGenerator([])
    pgen.startsymbol = "startsymbol"
    pgen.dfas = {"startsymbol": [DFAState({}, True)]}
    g = pgen.make_grammar()
    assert isinstance(g, PgenGrammar)
    assert g.start == 0
    assert g.start == g.symbol2number[pgen.startsymbol]
    assert g.start == g.symbol2label[pgen.startsymbol]
    assert isinstance(g.dfas, Dict[int, Tuple[List[List[Tuple[int, Optional["DFAState"]]]], Dict[int, int]]])

# Generated at 2022-06-11 19:51:26.077754
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    p = ParserGenerator({}, "")
    p.dfas = {"a": [DFAState({})], "b": [DFAState({})]}
    p.first = {}
    p.calcfirst("a")
    assert p.first["a"] is None, p.first["a"]
    p.dfas["a"][0].arcs = [("b", p.dfas["b"][0])]
    p.calcfirst("a")
    assert p.first["a"] == {}, p.first["a"]
    p.dfas["b"][0].arcs = [("c", p.dfas["b"][0])]
    p.calcfirst("a")
    assert p.first["a"] == {"c": 1}, p.first["a"]



# Generated at 2022-06-11 19:51:32.629608
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    def parse(src: str) -> List[str]:
        parser = ParserGenerator()
        tokens = parser.parse_alt(tokenize.generate_tokens(io.StringIO(src).readline))
        return [tok[1] for tok in tokens]
    assert parse("a b | c d") == ["a", "b", "|", "c", "d"]
    assert parse("a 'b' | c d") == ["a", "'b'", "|", "c", "d"]

# Generated at 2022-06-11 19:51:46.169691
# Unit test for constructor of class ParserGenerator

# Generated at 2022-06-11 19:51:47.502612
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    pg = ParserGenerator()
    pg.parse_alt()


# Generated at 2022-06-11 19:51:58.435827
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    import unittest.mock

    pgen = ParserGenerator("foobarbaz")
    pgen.filename = "fuz"
    pgen.line = "buz"
    pgen.end = (12, 34)
    pgen.value = "boz"
    pgen.type = 42

    source_code = "foobarbaz"
    with unittest.mock.patch("tokenize.tokenize", return_value=iter([(0, "boz", (12, 34), (12, 37), "buz")])):
        with unittest.mock.patch("token.tok_name[42]", side_effect=ArithmeticError):
            with pytest.raises(SyntaxError) as error:
                pgen.expect(tokenize.NAME, "foob")


# Generated at 2022-06-11 19:52:07.891786
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    # See if this works for the non-empty string case
    pg = ParserGenerator()
    dfas, startsymbol = pg.parse_string(
        """
    start: 'foo' | 'bar'
    """
    )
    startdfa = dfas[startsymbol]
    assert startdfa[0].arcs == {"foo": startdfa[1], "bar": startdfa[2]}
    assert startdfa[1].arcs == {}
    assert startdfa[2].arcs == {}
    assert startdfa[1].isfinal
    assert startdfa[2].isfinal

# Generated at 2022-06-11 19:52:11.559528
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    parser_gen = ParserGenerator()
    parser_gen.expect(1, None)
    parser_gen.expect(1, None)



# Generated at 2022-06-11 19:52:17.624008
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    import io

    def t(start, finish, expected):
        out = io.StringIO()
        ParserGenerator(io.StringIO(start)).dump_nfa("test", start, finish, out)
        assert out.getvalue() == expected


    t(
        "a = a\n",
        NFAState([(None, NFAState([])), (None, NFAState([])), (None, NFAState([]))], []),
        """\
Dump of NFA for test
  State 0
    -> 1
    -> 2
    -> 3
  State 1
  State 2
  State 3
""",
    )

# Generated at 2022-06-11 19:53:56.402434
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    def _check(type, value, begin, end, msg, args):
        with pytest.raises(SyntaxError) as e:
            p.type = type
            p.value = value
            p.begin = begin
            p.end = end
            p.raise_error(msg, *args)
        return e.value
    def _checkmessage(err, expected):
        assert err.filename == "fname"
        assert err.lineno == 2
        assert err.offset == 3
        assert re.match(r'expected\s+\d+,\s+got\s+\d+/None', err.msg)
        return err.msg
    p = ParserGenerator("fname", [])
    p.line = "line"
    msg = "oops %s %d"

# Generated at 2022-06-11 19:54:07.707614
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    import sys
    import StringIO
    from pgen2.tokenizer import generate_tokens
    from pgen2.grammar import Grammar

    if sys.version_info < (3, 0):
        def compare(expected: bytes, actual: bytes) -> None:
            print("expected:", repr(expected))
            print("actual  :", repr(actual))
            assert expected == actual
    else:
        def compare(expected: bytes, actual: bytes) -> None:
            print("expected:", repr(expected))
            print("actual  :", repr(actual))
            assert expected.encode("latin-1") == actual

    filename = "<string>"
    pg = ParserGenerator(Grammar(), filename, generate_tokens(filename, b"b: 'a' | ''\n"))

# Generated at 2022-06-11 19:54:19.465558
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    import tokenize

    def test(tokens, expected):
        pg = ParserGenerator()
        pg.filename = "test"
        pg.line = "0123456789"
        pg.generator = iter(tokens)
        pg.gettoken()
        actual = pg.parse_atom()
        assert actual == expected, (actual, expected)

    test(
        [
            (61, "("),
            (40, "_"),
            (61, ")"),
            (61, "+"),
        ],
        (NFAState([], []), NFAState([], [(None, NFAState([], []))])),
    )

# Generated at 2022-06-11 19:54:20.762067
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    PG = ParserGenerator()
    PG.parse()


# Generated at 2022-06-11 19:54:32.508833
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    """Tests a basic case of ParserGenerator.dump_dfa"""
    pg = ParserGenerator()
    dfa = [DFAState({
        NFAState('1', "foo", None),
        NFAState('2', "foo", None),
        NFAState('3', "foo", None)}, False),
           DFAState({
               NFAState('4', "foo", None),
               NFAState('5', "foo", None),
               NFAState('6', "foo", None)}, False)]
    dfa[0].addarc(dfa[1], "bar")
    pg.dump_dfa("foo", dfa)
    assert True, "test_ParserGenerator_dump_dfa didn't crash"


# Generated at 2022-06-11 19:54:44.742331
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    pg = ParserGenerator()
    pg.dfas = {
        "a": [DFAState({"b": 1}, True), DFAState({}, False)],
        "b": [DFAState({"c": 1, "a": 2}, True), DFAState({}, False)],
        "c": [DFAState({"d": 1, "b": 2}, True), DFAState({}, False)],
        "d": [DFAState({"d": 1}, True), DFAState({}, False)],
    }
    pg.addfirstsets()
    assert pg.first["a"] == {"c": 1}
    assert pg.first["b"] == {"c": 1, "a": 1}
    assert pg.first["c"] == {"d": 1, "b": 1}

# Generated at 2022-06-11 19:54:53.702742
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():

    class TestConverter(Converter):

        def make_label(self, c: PgenGrammar, label: Text) -> int:
            return int(label)

    pg = ParserGenerator()
    g = pg.make_grammar(
        test_grammar,
        {"tokens": ["ONE", "TWO"]},
        TestConverter,
        filename="<test_grammar>",
    )

    assert g.labels
    assert g.labels == [(1, None), (2, None)]
    assert g.start == 1
    assert g.states

# Generated at 2022-06-11 19:55:06.325520
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    with open('../Grammar/Grammar/Grammar') as f:
        parsegen = ParserGenerator(f)
        parsegen.gettoken()
        assert(parsegen.type == token.NAME)
        assert(parsegen.value == "single_input")
        parsegen.gettoken()
        assert(parsegen.type == token.OP)
        assert(parsegen.value == ":")
        parsegen.gettoken()
        assert(parsegen.type == token.NAME)
        assert(parsegen.value == "file_input")
        parsegen.gettoken()
        assert(parsegen.type == token.OP)
        assert(parsegen.value == "|")
        parsegen.gettoken()
        assert(parsegen.type == token.NAME)

# Generated at 2022-06-11 19:55:18.587786
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    import io

    # Test that raise_error reports correct location of error if
    # input has non-default encoding
    pg = ParserGenerator()
    # (line, column, expected line, expected column)
    testcases = [
        (1, 1, 1, 1),
        (1, 10, 1, 10),
        (2, 7, 2, 7),
        (3, 11, 3, 11),
        (9, 40, 9, 40),
    ]

    def get_location(buf: io.TextIOBase) -> None:
        try:
            pg.parse_grammar(buf)
        except SyntaxError as err:
            return err.lineno, err.offset
        raise Exception("no error was raised")


# Generated at 2022-06-11 19:55:28.748824
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    class Dummy:
        pass

    a = Dummy()
    b = Dummy()
    c = Dummy()
    d = Dummy()
    e = Dummy()
    a.arcs = {0: [c], 1: [b]}  # type: Dict[str, List["DFAState"]]
    b.arcs = {0: [c], 1: [c], 2: [d]}
    c.arcs = {0: [b], 1: [c], 2: [d]}
    d.arcs = {0: [b], 1: [c], 2: [d]}
    e.arcs = {0: [c], 1: [b]}

    dfa = [a, b, c, d, e]  # type: List[Dummy]
    simplify_dfa(dfa)