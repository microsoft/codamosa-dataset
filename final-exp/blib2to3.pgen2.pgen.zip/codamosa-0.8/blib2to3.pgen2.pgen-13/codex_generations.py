

# Generated at 2022-06-11 19:46:44.147768
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    import io
    import parser  # An implementation of ParserGenerator
    ll1 = parser.ParserGenerator()
    ll1.make_grammar(io.StringIO("abc : 8"))

# Generated at 2022-06-11 19:46:55.450976
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    import textwrap, re

# Generated at 2022-06-11 19:47:06.932863
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    pg = ParserGenerator()
    pg.line = "hello"
    pg.type = 1; pg.value = "hi"; pg.begin = (1, 1); pg.end = (1, 4)
    generator = iter([
        (
            token.NL,
            '\n',
            (1, 4),
            (2, 0),
            'hello\n',
        ),
        (
            token.STRING,
            "'bye'",
            (2, 0),
            (2, 5),
            '',
        ),
    ])
    pg.generator = generator
    pg.gettoken()
    assert pg.type == token.STRING
    assert pg.value == "'bye'"
    assert pg.begin == (2, 0)
    assert pg.end == (2, 5)
    assert pg

# Generated at 2022-06-11 19:47:18.819349
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    pg = ParserGenerator()
    pg.gettoken = lambda: None
    pg.add_rhs = lambda x, y: None
    pg.make_dfa = lambda x, y: None
    pg.dfas = {}
    pg.startsymbol = None
    pg.first = {}
    source = "foo: bar baz\nbar: NAME\nbaz: NUMBER | NAME"
    pg.parse_grammar(source)
    pg.addfirstsets()

    assert len(pg.first) == 3
    assert pg.first["foo"].keys() == {"NAME", "NUMBER"}
    assert pg.first["bar"].keys() == {"NAME"}
    assert pg.first["baz"].keys() == {"NAME", "NUMBER"}



# Generated at 2022-06-11 19:47:31.100405
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    pg = ParserGenerator()
    pg.parse_alt()
    pg = ParserGenerator()
    pg.dfas = {
        'A': [
            DFAState(
                {
                    NFAState(): 1,
                    NFAState(): 1,
                }, NFAState()
            )
        ],
        'B': [
            DFAState({NFAState(): 1}, NFAState()),
            DFAState({NFAState(): 1}, NFAState()),
        ],
        'C': [
            DFAState({NFAState(): 1}, NFAState())
        ],
        'D': [
            DFAState({NFAState(): 1}, NFAState())
        ],
        'E': [
            DFAState({NFAState(): 1}, NFAState())
        ],
    }


# Generated at 2022-06-11 19:47:34.035795
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    pgm = ParserGenerator()
    assert pgm.parse_atom() == (NFAState(), NFAState())


# Generated at 2022-06-11 19:47:39.878395
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():

    # Some test data to be passed to the method under test
    f = io.StringIO("""
    0 (:
    """)
    g = tokenize.generate_tokens(f.readline)
    # Remove the first token
    next(g)
    p = ParserGenerator(g, "no file")
    c = p.make_converter()
    # This is the actual method we're testing
    result = p.make_label(c, "0")
    assert result == 0, result



# Generated at 2022-06-11 19:47:47.617482
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    pg = ParserGenerator()
    pg.make_scanner()
    pg.parse_grammar(dedent("""
    start: 'a'
    expr: NAME
    """))
    pg.addfirstsets()
    assert pg.first == {"start": {"a": 1}, "expr": {"NAME": 1}}


if __name__ == "__main__":
    import sys

    if len(sys.argv) != 2:
        print("usage: %s filename" % sys.argv[0], file=sys.stderr)
        sys.exit(2)
    filename = sys.argv[1]

    pg = ParserGenerator()
    pg.make_scanner()
    pg.parse_grammar(open(filename).read())
    print(pg.convert().dump())

# Generated at 2022-06-11 19:47:58.441190
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    parser = ParserGenerator()
    c = PgenGrammar()
    parser.make_label(c, "NAME")
    parser.make_label(c, "|")
    parser.make_label(c, "NUMBER")
    parser.make_label(c, "\'+\'")
    parser.make_label(c, "\'.\'")
    parser.make_label(c, "\"print\"")
    parser.make_label(c, "\"%\"")
    parser.make_label(c, "\"try\"")
    parser.make_label(c, "\"if\"")
    parser.make_label(c, "\"else\"")
    parser.make_label(c, "\"elif\"")
    parser.make_label(c, "\"while\"")
    parser.make_

# Generated at 2022-06-11 19:48:00.288500
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    _print = None
    parser = _ParserGenerator(_print)
    parser.parse_alt()

# Generated at 2022-06-11 19:48:57.577722
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    # from pprint import pprint
    from token import NAME, OP, STRING
    from tokenize import COMMENT, NL
    from typing import Generator

    def gen() -> Generator[Token, None, None]:
        yield (NAME, "A", (1, 0), (1, 1), "A")
        yield (COMMENT, " # foo", (1, 1), (1, 8), "A # foo")
        yield (NL, "", (1, 8), (1, 9), "")
        yield (NAME, "B", (2, 0), (2, 1), "B")
        yield (OP, ":", (2, 1), (2, 2), ":")
        yield (STRING, "'a'", (2, 2), (2, 5), "'a'")

# Generated at 2022-06-11 19:49:03.621888
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    pp = ParserGenerator()
    pp.dfas = {'a': [DFAState({'A': 1}, {})], 'b': [DFAState({}, {'B': 1})]}
    pp.addfirstsets()
    assert pp.first['a'] == {'A': 1}
    assert pp.first['b'] == {}


# Generated at 2022-06-11 19:49:05.861390
# Unit test for method dump_nfa of class ParserGenerator

# Generated at 2022-06-11 19:49:14.442675
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    pg = ParserGenerator()
    init = NFAState()
    # note: symbol here can be a NAME, STRING or STRING_INITIAL
    pg.add_rhs(init, [("symbol", None)])
    rhs_to_complete = init.arcs[0][1]
    symbol1 = "symbol1"
    symbol2 = "symbol2"
    pg.dfas[symbol1] = [DFAState({(NFAState(), 1): 1}, None)]
    pg.dfas[symbol2] = [DFAState({(NFAState(), 1): 1}, None)]
    pg.first[symbol1] = {symbol1: 1}
    pg.first[symbol2] = {symbol2: 1}
    symbol_nfa = NFAState()
   

# Generated at 2022-06-11 19:49:22.536686
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    from _tokenize import generate_tokens

    generator = generate_tokens(StringIO('abc 123 "abc" # comment\n').readline)
    pg = ParserGenerator(generator, 'test_ParserGenerator_raise_error')
    pg.gettoken()
    try:
        pg.expect(token.NAME, 'def')
    except SyntaxError as e:
        assert e.args == (
            "expected NAME/def, got NAME/abc",
            ('test_ParserGenerator_raise_error', 1, 1, 'abc 123 "abc" # comment\n'),
        )
    else:
        raise AssertionError("Expected SyntaxError")


# Generated at 2022-06-11 19:49:33.767403
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    pg = ParserGenerator()
    G = grammar.Grammar()
    pg.grammar = G

    start = NFAState()
    a = NFAState()
    b = NFAState()
    c = NFAState()
    d = NFAState()
    finish = NFAState()

    start.addarc(a)
    start.addarc(c)
    a.addarc(b, "a")
    b.addarc(finish, "b")
    c.addarc(d, "c")
    d.addarc(b, "d")
    b.addarc(finish)

    dfa = pg.make_dfa(start, finish)
    assert len(dfa) == 5
    assert dfa[0].arcs["a"] == dfa[1]

# Generated at 2022-06-11 19:49:39.527262
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    with open(str(py.path.local(pgen_py.__file__))) as f:
        pgen = ParserGenerator(f.readline)
        a, z = pgen.parse_atom()
        assert a == NFAState([(None, z)])
test_ParserGenerator_parse_atom.todo = "Temporarily disabled"


# Generated at 2022-06-11 19:49:47.889268
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    input = "{'a': ['b', 'c'], 'b':['d']}"
    grammarStr = ast.literal_eval(input)
    gen = ParserGenerator(grammarStr, convert=False) # test the convert=False case
    print(gen.pgenGrammar)
    gen = ParserGenerator(grammarStr) # test default case
    print(gen.pgenGrammar)

# test_ParserGenerator()

# ______________________________________________________________________

# CLASS EXTRACTOR:
# Extracts grammar information from the AST of Python source

# For example, '3 + 4' yields [3, '+', 4]

# Generated at 2022-06-11 19:49:53.446445
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    from . import grammar
    pg = ParserGenerator(grammar)
    pg.addfirstsets()
    for rule in sorted(pg.dfas):
        start, finish = pg.dfas[rule][0], pg.dfas[rule][-1]
        finish.isfinal = True
        pg.dump_nfa(rule, start, finish)

# Generated at 2022-06-11 19:49:57.436791
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    # SyntaxError: expected NAME, got OP/*
    with pytest.raises(SyntaxError):
        pg = grammar.ParserGenerator(
            [
                "a: *",
                "",
                "b: a"
            ]
        )
        pg_parse = pg.parse()

# Generated at 2022-06-11 19:51:03.450572
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    """Test method dump_dfa"""
    pgen = ParserGenerator()
    pgen.dump_dfa(None, None)


# Generated at 2022-06-11 19:51:07.855300
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    pg = ParserGenerator()
    a = NFAState()
    b = NFAState()
    c = NFAState()
    d = NFAState()
    a.addarc(b, None)
    a.addarc(c, "x")
    b.addarc(d, None)
    c.addarc(d, None)
    dfa = pg.make_dfa(a, d)
    print(len(dfa), "states")
    for i, state in enumerate(dfa):
        print(i, state, sorted(state.arcs.keys()), state.isfinal)


# Generated at 2022-06-11 19:51:17.821715
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    p = ParserGenerator()
    # p.parse_item()
    # p.parse_item('(')
    # p.parse_item('(')
    # p.parse_item('(')
    # p.parse_item('[')
    p.parse_item()
    # p.parse_item('(')
    p.parse_item()
    # p.parse_item('[')
    p.parse_item()
    # p.parse_item('[')
    p.parse_item()
    # p.parse_item('(')
    p.parse_item()
    # p.parse_item('[')
    p.parse_item()
    # p.parse_item('[')
    p.parse_item()
    # p.parse_item('[')
    p.parse

# Generated at 2022-06-11 19:51:26.353217
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    from pythonparser import token
    from typing import List, Tuple

    def _test_parse_atom(test_name: str, input_source: str, expected_output: Tuple[List[Tuple[int, Text]], Text]):
        pg = ParserGenerator()
        output = pg.parse_atom()
        assert output == expected_output, '%s: %s != %s' % (test_name, output, expected_output)

    pg = ParserGenerator()

    test_name = '1'
    input_source = 'NAME'
    expected_output = (token.NAME, 'NAME')
    _test_parse_atom(test_name, input_source, expected_output)

    test_name = '2'
    input_source = 'name'

# Generated at 2022-06-11 19:51:34.612824
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    pg = ParserGenerator()
    pg.parse("""
# This is a comment
start: 'hello' NAME '!'  # This is another comment
           # and this again
    | 'bye' NAME
""")
    assert pg.dfas["start"][0].arcs == {
        "'hello'": pg.dfas["start"][1],
        "'bye'": pg.dfas["start"][2],
    }
    assert pg.dfas["start"][1].arcs == {token.NAME: pg.dfas["start"][3]}
    assert pg.dfas["start"][2].arcs == {token.NAME: pg.dfas["start"][3]}

# Generated at 2022-06-11 19:51:47.548810
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    import StringIO

    s = StringIO.StringIO("while True:\n    x = 'x'\n")
    g = ParserGenerator("test", s).generator
    assert next(g) == (token.NAME, "while", (1, 0), (1, 5), "while True:\n")
    assert next(g) == (token.NAME, "True", (1, 6), (1, 10), "while True:\n")
    assert next(g) == (token.OP, ":", (1, 11), (1, 12), "while True:\n")
    assert next(g) == (token.NEWLINE, "", (1, 12), (1, 12), "while True:\n")

# Generated at 2022-06-11 19:51:58.435280
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    from importlib.machinery import SourceFileLoader
    from io import StringIO
    from typing import NamedTuple

    class Token(NamedTuple):
        type: int
        string: str
        begin: Tuple[int, int]
        end: Tuple[int, int]
        line: str

    def fake_generator():
        yield Token(token.STRING, '"foo"', (1, 1), (1, 5), 'foo')
        yield Token(token.STRING, '"bar"', (2, 1), (2, 5), 'bar')
        yield Token(token.STRING, '"baz"', (3, 1), (3, 5), 'baz')

    parser = PgenParser(StringIO('"foo"\n"bar"\n'), '<string>')

# Generated at 2022-06-11 19:52:11.296535
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    from . import grammar
    from . import literals
    from .grammar import _PgenGrammar

    gr = _PgenGrammar(grammar.start, grammar.g, grammar.dfas)
    gr.addfirstsets()
    for name, first in literals.first:
        assert gr.first[name] == first
    # Make sure that all the literals are actually used
    tokens = set()
    for rules in literals.literal_inc.values():
        for rule in rules:
            tokens.add(rule[0])
    assert tokens == set(grammar.tokens.values())
    # Check the literals set of each non-terminal
    for name, rules in literals.literal_inc.items():
        for rule in rules:
            assert name in rule[2]
    # Check

# Generated at 2022-06-11 19:52:18.366946
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    x = ParserGenerator()
    x.dfas = {
        "a": [DFAState({0: 1})],
        "b": [DFAState({1: 1})],
        "c": [DFAState({2: 1})],
        "d": [DFAState({3: 1})],
        "e": [DFAState({4: 1})],
        "f": [DFAState({5: 1})],
    }
    for name in "bcd":
        x.dfas[name][0].addarc("a", x.dfas[name][0])
        x.dfas[name][0].addarc("b", x.dfas[name][0])

# Generated at 2022-06-11 19:52:30.194802
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    dfas = {}  # type: Dict[Text, List[DFAState]]
    startsymbol = "s"  # type: Text
    first = {}  # type: Dict[Text, int]
    pg = ParserGenerator(dfas, first, startsymbol)
    name = "name1"
    assert name not in dfas
    dfas[name] = [
        DFAState({"a"}, "b"),
        DFAState({"b"}, "c"),
        DFAState({"c"}, "d"),
    ]
    assert name not in first
    first[name] = None
    assert name not in pg.first
    pg.calcfirst(name)
    assert name in pg.first
    expected = {"a", "b", "c", "d"}

# Generated at 2022-06-11 19:54:46.564197
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    import textwrap

    src = """
        expr: term
            | expr '+' term     # Add
        term: factor
            | term '*' factor   # Multiply
        factor: INTEGER
        """
    g = ParserGenerator()
    g.parse_grammar(textwrap.dedent(src))
    g.addfirstsets()
    assert g.first["expr"] == {"INTEGER": 1, "'+'": 1}
    assert g.first["term"] == {"INTEGER": 1, "'*'": 1}
    assert g.first["factor"] == {"INTEGER": 1}

if __name__ == "__main__":
    import sys
    from . import grammar

    g = ParserGenerator()

# Generated at 2022-06-11 19:54:55.132879
# Unit test for method make_dfa of class ParserGenerator

# Generated at 2022-06-11 19:55:06.751375
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    import unittest

    class ParserGenerator_make_dfa_Tests(unittest.TestCase):
        def test_simple(self):
            nfa1 = NFAState()
            nfa2 = NFAState()
            nfa1.addarc(nfa2, "a")
            dfa = ParserGenerator.make_dfa(nfa1, nfa2)
            self.assertEqual(len(dfa), 2)
            self.assertIs(dfa[0].nfaset, nfa1.closure())
            self.assertIs(dfa[1].nfaset, nfa2.closure())
            self.assertEqual(dfa[0].arcs, {"a": dfa[1]})

        def test_loop(self):
            nfa1 = NFA

# Generated at 2022-06-11 19:55:16.835125
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    """Unit test for PgenGrammar"""

    # Unit test for PgenGrammar()
    # Test case 1
    expected_value = None
    expected_type = PgenGrammar
    actual_value = PgenGrammar()
    actual_type = type(actual_value)
    assert expected_type == actual_type, "test_PgenGrammar_testcase_1: " + str(expected_type) + " expected, but " + str(actual_type) + " returned"
    assert actual_value is not None, "test_PgenGrammar_testcase_1: None returned"


# Generated at 2022-06-11 19:55:26.793168
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    def check(source, expected_tokens):
        pg = ParserGenerator()
        pg.gen = (t for t in expected_tokens)
        # test only gettoken(), not get_generator()
        pg.generator = tokenize.tokenize(b(source))
        for expected_token in expected_tokens:
            pg.gettoken()
            assert (pg.type, pg.value, pg.begin, pg.end, pg.line) == expected_token

    # test gettoken()
    # expected_tokens = [(type, value, begin, end, line), ...]
    #   type: token type
    #   value: token value
    #   begin: (row, col)
    #   end: (row, col)
    #   line: line string


# Generated at 2022-06-11 19:55:33.671457
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    from . import parser_generator as TESTPG   # relative import
    from . import parser_grammar as TESTPGG  # relative import

    generator = TESTPG.ParserGenerator()
    pg = generator.parse_grammar(TESTPGG.parser_grammar_def)
    pg.dump_nfa("factor", pg.dfas["factor"][0], pg.dfas["factor"][1])
    pg.dump_nfa("varargslist", pg.dfas["varargslist"][0], pg.dfas["varargslist"][1])
    pg.dump_nfa("varargslist_end", pg.dfas["varargslist_end"][0],
                pg.dfas["varargslist_end"][1])



# Generated at 2022-06-11 19:55:45.388160
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    # Simplify a DFA that has a simple redundant state.
    dfa = [
        DFAState({}, False),
        DFAState({}, False),
        DFAState({}, False),
        DFAState({}, True),
    ]
    dfa[0].addarc(dfa[1], "x")
    dfa[0].addarc(dfa[2], "y")
    dfa[1].addarc(dfa[3], "z")
    dfa[2].addarc(dfa[3], "z")
    # print "DFA before"
    # for i, state in enumerate(dfa):
    #     print "  State", i, state.isfinal and "(final)" or ""
    #     for label, next in sorted(state.arcs.items()):
    #         print