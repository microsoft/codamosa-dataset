

# Generated at 2022-06-11 19:46:55.539581
# Unit test for function generate_grammar
def test_generate_grammar():
    lark_version = '0.7.4'
    grammar = generate_grammar()
    assert grammar.version == lark_version
    assert grammar.start == 'start'
    assert len(grammar.keywords) == 9
    assert len(grammar.tokens) == 27
    assert len(grammar.labels) == 27+9
    assert len(grammar.dfas) == len(grammar.labels)
    assert grammar.first['string']['r'] == 1 or grammar.first['string']['R'] == 1
    assert grammar.first['string']['u'] == 1 or grammar.first['string']['U'] == 1
    assert grammar.first['string']['b'] == 1 or grammar.first['string']['B'] == 1


# Generated at 2022-06-11 19:47:07.014658
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    print("Testing dump_dfa()")
    pg = ParserGenerator()
    pg.add_dfa('foo', [[0,0], [0,1]])
    pg.add_dfa('bar', [[1,1], [1,2]])
    pg.add_startsymbol('foo')
    pg.addfirstsets()
    cursor = pg.make_cursor()
    # test_debug()
    assert cursor.labels == [(1, None), (2, None)]
    assert cursor.states == [[[(0, 1)], [(1, 1)]]]
    assert cursor.dfas == {0: (([[(0, 1)], [(1, 1)]]), {1: 1})}
    assert cursor.keywords == {}

# Generated at 2022-06-11 19:47:19.167584
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    import StringIO

    def test(text: str, result: Tuple[NFAState, NFAState], kind: str) -> None:
        print("parse_item(%r) -> %r (%s)" % (text, result, kind))
        input = StringIO.StringIO(text)
        p = ParserGenerator(input)
        a, z = p.parse_item()
        assert a.arcs == result[0].arcs, "left"
        assert z.arcs == result[1].arcs, "right"

    test("a", (NFAState([(None, NFAState([("a", NFAState())])),]), NFAState()), "atomic")

# Generated at 2022-06-11 19:47:27.861688
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():

    pg = ParserGenerator()
    pg.first = {'a': {'b': 1}, 'c': {'d': 1}}
    pg.calcfirst('b')
    assert pg.first == {'a': {'b': 1}, 'c': {'d': 1}, 'b': {'a': 1}}
    pg.calcfirst('a')
    assert pg.first == {'a': {'b': 1}, 'c': {'d': 1}, 'b': {'a': 1}}


# Generated at 2022-06-11 19:47:37.350396
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    def test_comments(source: str) -> ParserGenerator:
        apg = ParserGenerator()
        source = source.replace("\t", " ")
        apg.parse_item_test(source)
        return apg
    test_comments("")
    test_comments("#")
    test_comments("# comment")
    test_comments("# comment\n")
    test_comments(" # comment\n")
    test_comments("   # comment\n")
    test_comments("# comment\n\n")
    apg = test_comments("a")
    assert len(apg.nfastack) == 0
    apg = test_comments("a # comment\n")
    assert len(apg.nfastack) == 0
    apg = test_comments("a + # comment\n")

# Generated at 2022-06-11 19:47:41.214130
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
  p = ParserGenerator()

  # Testcase 1
  p.value = "["
  p.parse_alt()

  # Testcase 2
  p.value = "("
  p.parse_alt()

  # Testcase 3
  p.value = "NAME"
  p.parse_alt()

  # Testcase 4
  p.value = "STRING"
  p.parse_alt()

  # Testcase 5
  p.value = "+"
  p.parse_alt()

  # Testcase 6
  p.value = "*"
  p.parse_alt()

# Generated at 2022-06-11 19:47:48.825856
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    import copy
    import glob
    import os
    from .pgen2.parse import pgen
    from .pgen2.tokenize import generate_tokens, untokenize
    from .pgen2.pgen import _generate_grammar_tokens, concat
    from . import token
    from . import _compat
    from . import _tokenize

    # Create a list of the grammar files in the distribution
    g_files = glob.glob("Grammar/Grammar*")
    # Add the Python.asdl file used by the AST Module
    g_files.append("Parser/Python.asdl")
    # Add the top-level grammar file
    g_files.append("Grammar/Grammar")
    # Filter out any non-Grammar files

# Generated at 2022-06-11 19:47:55.231665
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    pg = ParserGenerator()
    pg.dfas = {"x": [], "y": []}
    pg.first = {"x": None, "y": {"a": 1, "b": 1}}
    pg.addfirstsets()
    assert pg.first == {"x": {"a": 1, "b": 1}, "y": {"a": 1, "b": 1}}



# Generated at 2022-06-11 19:48:02.861818
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    p = ParserGenerator()
    p.parse_grammar("test", "simple : 'a' 'b'\n")
    dfa = p.dfas["simple"]
    out = io.StringIO()
    p.dump_dfa("simple", dfa, out)
    assert out.getvalue() == """\
Dump of DFA for simple
  State 0
    'a' -> 1
  State 1 (final)
    'b' -> 2
  State 2 (final)
    'a' -> 1
    'b' -> 2
"""


# Generated at 2022-06-11 19:48:13.920772
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    nfa = ParserGenerator()
    nfa.add("file_input", [("(stmt '\\n')*", "ENDMARKER")])
    nfa.add("stmt", [("simple_stmt", "|", "compound_stmt")])
    nfa.add("simple_stmt", [("small_stmt", "(',' small_stmt)* [';'] NEWLINE")])
    nfa.add("small_stmt", [("(expr_stmt | del_stmt | pass_stmt | flow_stmt | import_stmt | global_stmt | nonlocal_stmt | assert_stmt)")])

# Generated at 2022-06-11 19:49:03.578301
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    grammar = r"""
    stmt ::= print
    print ::= "print"
    """
    dfa, startsymbol = ParserGenerator().parsestr(grammar)
    # print(dfa)
    assert dfa['print'][0].arcs == {None: [1]}
    assert dfa['print'][1].arcs == {'print': [2]}
    assert dfa['print'][2].arcs == {}
    assert dfa['print'][2].isfinal == True
    assert dfa['print'][0].isfinal == False
    assert dfa['print'][1].isfinal == False
    assert dfa['stmt'][0].arcs == {None: [1]}
    assert dfa['stmt'][1].arcs == {'print': [2]}
   

# Generated at 2022-06-11 19:49:14.080783
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    dfa = [DFAState({NFAState(): 1}, NFAState())]
    ParserGenerator.simplify_dfa(dfa)
    print("Simplification:", dfa)
    assert dfa == [DFAState({NFAState(): 1}, NFAState())]

    a, b, c, d, e, f, g, h, i, j, k, l, m, n, o, p, q, r, s, t, u, v, w, x, y, z = [
        DFAState({NFAState(): 1}, NFAState()) for _ in range(26)
    ]
    a.addarc(c, "a")
    a.addarc(e, "a")
    b.addarc(f, "b")

# Generated at 2022-06-11 19:49:23.171554
# Unit test for method parse_alt of class ParserGenerator

# Generated at 2022-06-11 19:49:32.432055
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    # This example is taken from the `parser module' documentation:
    # <http://docs.python.org/lib/module-parser.html>
    # Note that the output of this script differs from the output shown
    # in the documentation because the order of the rules has changed.
    script = """
        expr ::= expr "+" term
              |  expr "-" term
              |  term

        term ::= term "*" factor
              |  term "/" factor
              |  factor

        factor ::= "(" expr ")"
              |  NUMBER
    """
    pgen = ParserGenerator(script)
    print("%r" % pgen.dfas)



# Generated at 2022-06-11 19:49:34.270003
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    PgenGrammar()



# Generated at 2022-06-11 19:49:39.674054
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    pg = ParserGenerator("")
    # Method make_label is supposed to be overridden in subclasses.
    # It's hard to write a unit test for it here because it accesses
    # the instance variables of its caller, which would be an
    # instance of a ParserGenerator subclass.


_parser_generator_parser = None



# Generated at 2022-06-11 19:49:46.199197
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    import unittest

    class Test(unittest.TestCase):
        def test(self):
            import io
            import pgen2.grammar

            def generate_g():
                g = pgen2.grammar.Grammar()
                g.load(io.StringIO("x: 'x'\ny: 'y'\n"))
                return g

            pg = ParserGenerator()
            pg._grammar = generate_g()
            pg.addfirstsets()
            pg.make_grammar(["x"])

            import io

            output = io.StringIO()
            orig_stdout = sys.stdout
            sys.stdout = output
            pg.dump_dfa("x", pg.dfas["x"])
            sys.stdout = orig_stdout

# Generated at 2022-06-11 19:49:53.453013
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    """ test calcfirst """
    pg = ParserGenerator(
        """\
        START: A
        A: B
        B: C | x | ""
        C: y | ""
        """,
        grammar.opmap,
    )
    pg.addfirstsets()
    assert pg.first["A"] == {"y", "x", ""}
    assert pg.first["B"] == {"y", "x", ""}
    assert pg.first["C"] == {"y", ""}



# Generated at 2022-06-11 19:50:01.353185
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    pg = ParserGenerator(None)
    pg.type = token.NAME
    pg.value = "name"
    pg.begin = (2, 3)
    pg.end = (2, 7)
    pg.line = "line"
    pg.filename = "file"
    pg.expect(token.NAME, "name")
    try:
        pg.expect(token.OP, ":")
    except SyntaxError:
        pass
    else:
        raise Exception("did not get expected SyntaxError")


# Generated at 2022-06-11 19:50:13.026784
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    from .parser import ParserError
    from .pgen import ParserGenerator
    try:
        pg = ParserGenerator(
            [
                "a : 'x' | 'x' a\n",
                "b : 'y' | 'y' b\n",
                "c : 'z'\n",
                "d : (a | b | c) (a | b | c)*\n",
            ]
        )
    except SyntaxError as err:
        raise ParserError("%s: %s" % (err.filename, err))
    pg.addfirstsets()
    assert pg.first["a"].keys() == {"'x'"}
    assert pg.first["b"].keys() == {"'y'"}
    assert pg.first["c"].keys() == {"'z'"}


# Generated at 2022-06-11 19:50:59.549132
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    import pgen2.parser
    if hasattr(pgen2.parser, "ParserGenerator"):
        # pgen2.parser.ParserGenerator is a class
        pg = pgen2.parser.ParserGenerator()
        filename = "filename.py"
        pg.filename = filename
        pg.end = (0, 0)
        pg.line = "line"
        assert pg.raise_error("msg") == None
        file_contents = [
            "#!/usr/bin/env python3",
            "print('Hello World from', __name__)",
            "def test():",
            "    return 'Hello World from function'",
            "if __name__ == '__main__':",
            "    print(test())",
        ]
        file_name = "00.py"

# Generated at 2022-06-11 19:51:09.565287
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    import unittest
    import io

    class Test(unittest.TestCase):
        def test(self):
            pg = ParserGenerator()
            f = io.StringIO("x | x y | x y z")
            pg.setup_input(f, "<testcase>")
            a, z = pg.parse_alt()
            self.assertEqual(len(a.arcs), 3)
            for next in a.arcs:
                self.assertEqual(next.arcs[0][0], "x")

    unittest.main()

# Generated at 2022-06-11 19:51:18.772011
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    from .pgen2_tokenize import generate_tokens, RULE

    def run_parser(source: Text, *args: Any) -> Tuple[List[DFAState], Text]:
        gen = generate_tokens(source)
        parser = ParserGenerator(gen, *args)
        return parser.parse()

    # Test empty items
    dfa, start = run_parser("*empty* : []")
    assert start == "*empty*"
    assert len(dfa) == 1
    assert len(dfa[0].arcs) == 0
    dfa, start = run_parser("*empty* : [(]")
    assert len(dfa) == 1
    assert len(dfa[0].arcs) == 0
    dfa, start = run_parser("*empty* : ()")
   

# Generated at 2022-06-11 19:51:26.905750
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    ##fname = '<string>'
    input = 'x: a b\n'
    pg = ParserGenerator()
    dfa, startsymbol = pg.parse_string(input)
    ##print dfa
    ##print startsymbol
    assert startsymbol == 'x'
    assert len(dfa) == 1
    assert len(dfa['x']) == 2
    assert dfa['x'][0].arcs == {'a': dfa['x'][1]}
    assert dfa['x'][1].arcs == {'b': dfa['x'][1]}

    input = 'x: a | b c | d\n'
    pg = ParserGenerator()
    dfa, startsymbol = pg.parse_string(input)
    ##print dfa
    ##print start

# Generated at 2022-06-11 19:51:35.030314
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    def test_gettoken(pg: ParserGenerator, input: str, exp_type: int, exp_value: str):
        pg.generator = pg.tokenize(input)
        pg.gettoken()
        pg.assertEqual(pg.type, exp_type)
        pg.assertEqual(pg.value, exp_value)

    # test_gettoken(<ParserGenerator object>, <input>, <exp_type>, <exp_value>)
    test_gettoken(
        ParserGenerator(),
        "a: 'a'\n",
        token.NAME,
        "a",
    )
    test_gettoken(
        ParserGenerator(),
        "'a'\n",
        token.STRING,
        "'a'",
    )

# Generated at 2022-06-11 19:51:41.094462
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    pg = ParserGenerator()
    pg.dfas = dfas
    a = pg.dfas["factor"][0]
    z = pg.dfas["factor"][2]
    dfa = pg.make_dfa(a, z)
    assert len(dfa) == 4
    assert set(map(type, dfa)) == set([DFAState])
    # state 0
    assert not dfa[0].isfinal
    assert dfa[0].arcs == {None: dfa[1], "(": dfa[2]}
    # state 1
    assert not dfa[1].isfinal
    assert dfa[1].arcs == {None: dfa[3]}
    # state 2
    assert not dfa[2].isfinal

# Generated at 2022-06-11 19:51:44.050329
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    pg = ParserGenerator()
    dfa = [
        DFAState(None, False)
    ]
    pg.dump_dfa('test', dfa)


# Generated at 2022-06-11 19:51:47.906718
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    r"""Test the method parse of class ParserGenerator"""
    p = ParserGenerator()
    print(p.parse("""
    test: abc
    abc: | "ab" "c"
    """))
test_ParserGenerator_parse()


# Generated at 2022-06-11 19:51:58.702305
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    pg = ParserGenerator()

    pg.generator = tokenize_helper("(")
    pg.gettoken()
    with pytest.raises(SyntaxError):
        pg.parse_atom()

    pg.generator = tokenize_helper(")")
    pg.gettoken()
    with pytest.raises(SyntaxError):
        pg.parse_atom()

    pg.generator = tokenize_helper("|")
    pg.gettoken()
    with pytest.raises(SyntaxError):
        pg.parse_atom()

    pg.generator = tokenize_helper("+")
    pg.gettoken()
    with pytest.raises(SyntaxError):
        pg.parse_atom()

    pg.generator = tokenize_helper("*")

# Generated at 2022-06-11 19:52:11.513450
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    pgen = ParserGenerator()
    pgen.startsymbol = "s"
    pgen.symbol2label = {"s": "s"}
    pgen.labels = [("s", None)]
    pgen.labels.append((1, None))
    pgen.labels.append((2, None))
    pgen.labels.append((3, None))
    pgen.labels.append((4, None))
    pgen.labels.append((5, None))
    pgen.labels.append((6, None))
    pgen.labels.append((7, None))
    pgen.labels.append((8, None))
    pgen.labels.append((9, None))
    pgen.labels.append((10, None))

# Generated at 2022-06-11 19:53:40.872196
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    """
    Test method ParserGenerator.addfirstsets
    """
    # Test sample 1
    pg = ParserGenerator()
    pg.build([("expr", ("[" "expr" "]") | "(" "expr" ")" | "single")])
    pg.addfirstsets()
    assert pg.first["expr"] == {"single": 1, "[": 1, "(": 1}

# Generated at 2022-06-11 19:53:54.002191
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    from pypy.module._codecs import interp_codecs as codecs
    import _ast as ast
    from pypy.interpreter.pyparser.grammar import compiler_grammar
    from pypy.interpreter.pyparser import pytokenizer, grammar
    p = ParserGenerator(pytokenizer.tokenizer_table)
    p.dfas, p.startsymbol = compiler_grammar
    c = p.make_grammar(codecs.decode_utf8('pypy.interpreter.pyparser.pygrammar', 'strict'))
    try:
        import pickle
    except ImportError:
        pass
    else:
        dump = pickle.dumps(c)
        c2 = pickle.loads(dump)
        assert c == c

# Generated at 2022-06-11 19:54:05.628362
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    def _(c: ParserGenerator, label: Text) -> int:
        # Wrapper for make_label; the code generator can't handle a
        # method of the code generator :-(
        return c.make_label(c, label)

    c1 = ParserGenerator()
    assert _(c1, "NAME") == 0
    assert _(c1, "COMMA") == 1
    assert _(c1, "'foo'") == 2
    assert _(c1, '"foo"') == 3
    assert _(c1, '"if"') == 4
    assert _(c1, "foo") == 0

    c2 = ParserGenerator()
    assert _(c2, "COMMA") == 0
    assert _(c2, "NAME") == 1

# Generated at 2022-06-11 19:54:17.257389
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    # Simple tests
    pg = ParserGenerator()
    start = DFAState({}, None)
    states = [start]
    for i in range(5):
        state = DFAState({}, None)
        states.append(state)
        start.addarc(state, "abc")
    pg.simplify_dfa(states)
    assert len(states) == 1
    states = [start]
    for i in range(5):
        state = DFAState({}, None)
        states.append(state)
        start.addarc(state, "abc")
        state.addarc(start, "def")
    pg.simplify_dfa(states)
    assert len(states) == 2
    start, state = states
    assert state.arcs == {"def": start}

    # Real examples

# Generated at 2022-06-11 19:54:28.011099
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    """Test a parser that recognizes XML tags."""
    source = """
        start: "<" NAME ">" (CHAR | start) "<" "/" NAME ">"
        NAME: "[a-zA-Z][0-9]*"
        CHAR: "[^<]*"
        """
    pgen = ParserGenerator()
    pgen.parse_grammar(source)
    pgen.build_automaton()
    # print pgen.write_tables()
    # print pgen.write_grammar_text()
    pgast = pgen.pgast  # type: ignore

# Generated at 2022-06-11 19:54:37.698337
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    pg = ParserGenerator()

    def do_test(spec, expect):
        a, b = pg.parse_alt()
        assert str(a) == expect, (spec, expect, a)

    do_test("1", '[0:1:0] -> [1:1:0]')
    do_test("1 2 3", '[0:1:0] -> [1:1:0] -> [2:2:0] -> [3:3:0]')
    do_test("1 [2] 3", '[0:1:0] -> [1:1:0] -> [2:2:1] -> [3:3:1] -> [4:3:0]')

# Generated at 2022-06-11 19:54:39.197968
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    pass



# Generated at 2022-06-11 19:54:43.825543
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    pg = ParserGenerator()
    pg.build()
    grammar = pg.make_grammar()

# Generated at 2022-06-11 19:54:47.110215
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    """Method parse_alt of class ParserGenerator"""
    parser = ParserGenerator()
    parser.input("a (b c | d e) | f g")
    assert parser.parse_alt() == (NFAState(), NFAState())



# Generated at 2022-06-11 19:54:55.506404
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    pg = ParserGenerator(
        cStringIO(
            """
            def foo():
                pass
        """
        ),
        "test_ParserGenerator_raise_error",
    )
    pg.gettoken()
    pg.gettoken()
    pg.expect(token.NAME)
    try:
        pg.expect(token.NAME, "bar")
    except SyntaxError as e:
        assert e.msg == "expected NAME/bar, got NAME/foo"
        assert e.filename == "test_ParserGenerator_raise_error"
        assert e.lineno == 1
        assert e.offset == 8
        assert e.text == "def foo():\n                pass\n"
    else:
        assert False, "Expected a SyntaxError"
