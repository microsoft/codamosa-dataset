

# Generated at 2022-06-11 19:46:40.522711
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    p = ParserGenerator()
    p.parse_grammar(grammar)
    p.addfirstsets()
    dfa = p.make_dfa(p.nfas["eval_input"], p.nfas["empty"])
    p.simplify_dfa(dfa)
    buf = io.StringIO()
    buf.write("from . import token\n")
    buf.write("from .grammar import STORE\n")
    buf.write("def addtoken(type, string, start, end, line):\n")
    buf.write("    return type, string, (start, end), line, STORE\n\n")
    buf.write("states = %r\n" % dfa)

# Generated at 2022-06-11 19:46:53.362537
# Unit test for method calcfirst of class ParserGenerator

# Generated at 2022-06-11 19:47:01.686702
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    expected = (
        (("a",), ("b",), ("c",), ("a", "b"), ("a", "c"), ("b", "c"), ("a", "b", "c")),
        (("+",), ("*",), ("+", "*")),
        (("[", "]"),),
        (("]",),),
        ((")",),),
        ((")", "["),),
    )
    for rules, _ in expected:
        for rule in rules:
            pg = ParserGenerator()
            pg.init(["a: " + " ".join(rule)])
            _, _ = pg.parse()

# Generated at 2022-06-11 19:47:10.414475
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    with open(r"C:\Users\mahav\Documents\GitHub\pycparser\PyCFiles\graminit.py", "r") as f:
        input = f.read()
    p = ParserGenerator()
    dfa, startsymbol = p.parse(input)
    c = p.make_grammar(dfa, startsymbol)
    def oops(msg: Text, *args: Any) -> NoReturn:
        raise SystemExit("Fatal error: " + msg % args)
    for i, (states, first) in enumerate(c.dfas):
        for j, state in enumerate(states):
            for t in state:
                if type(t) is str:
                    oops("Rule %d:%d has unnumbered label %s", i, j, t)

# Generated at 2022-06-11 19:47:20.896172
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    from . import dfa
    from . import nfa
    from . import parser

    grammar = parser.ParserGenerator()
    expected = """Dump of NFA for expr
  State 0
    -> 1
  State 1
    -> 2
  State 2 (final)
  State 3
    -> 2
    -> 2
  State 4
    -> 2
    -> 2
  State 5
    -> 2
    -> 2
  State 6
    -> 2
    -> 2
  State 7
    -> 2
    -> 2
  State 8
    -> 2
    -> 2
  State 9
    -> 2
    -> 2
  State 10
"""
    lines = expected.splitlines()
    assert len(lines) > 1
    assert len(lines[0]) > 1
    assert len(lines[1]) > 1

# Generated at 2022-06-11 19:47:29.208958
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    with mock.patch('parser.tokenize.tokenize') as tokenize:
        tokenize.return_value = [
            (token.NAME, 'foo', (0, 0), (0, 0), '\n'),
            (token.OP, ':', (0, 0), (0, 0), '\n'),
            (token.NAME, 'bar', (0, 0), (0, 0), '\n'),
            (token.NAME, 'baz', (0, 0), (0, 0), '\n'),
            (token.NEWLINE, '\n', (0, 0), (0, 0), '\n'),
            (token.ENDMARKER, '', (0, 0), (0, 0), '\n'),
        ]
        result = ParserGenerator('filename').parse_rhs()

# Generated at 2022-06-11 19:47:36.308289
# Unit test for method simplify_dfa of class ParserGenerator

# Generated at 2022-06-11 19:47:44.930094
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    def check(expected: List["Tuple[int, int]"], source: str) -> None:
        pg = ParserGenerator()
        alt = pg.parse_alt()
        def all_states(nfa_state: "NFAState") -> "Set[NFAState]":
            """Return the set of all NFA states reachable from the given
            state.
            """
            result = {nfa_state}
            for label, next in nfa_state.arcs:
                result.update(all_states(next))
            return result

        def state_code(nfa_state: "NFAState") -> int:
            return id(nfa_state)


# Generated at 2022-06-11 19:47:48.515787
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    x = PgenGrammar()
    assert isinstance(x,grammar.Grammar)

# Unit test class PgenGrammar with assertions that produce output

# Generated at 2022-06-11 19:47:59.203691
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    lines = ["name = 'hoge'|'fuga' NEWLINE | 'foo' NEWLINE", ""]
    pg = ParserGenerator(lines)
    dfas, startsymbol = pg.parse()
    assert len(dfas) == 1
    dfa = dfas[startsymbol]
    assert startsymbol == "name"
    assert len(dfa) == 5
    assert dfa[0].arcs == {
        ("hoge", dfa[1]),
        ("fuga", dfa[2]),
        ("foo", dfa[4]),
    }
    assert dfa[1].arcs == {("NEWLINE", dfa[3])}
    assert dfa[3].isfinal
    assert dfa[2].arcs == {("NEWLINE", dfa[3])}

# Generated at 2022-06-11 19:48:31.527137
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    code = """
        a : b c d | e f | g h | i
        b : '(' a ')'
        c : '[' a ']'
        d : NAME '+'
        e : NAME
        f : NAME '*'
        g : STRING
        h : STRING '+'
        i : STRING '*'
        """
    with open(TESTFN, "w") as f:
        f.write(code)
    gen = ParserGenerator()
    gen.parse_grammar_file(TESTFN)
    for name, dfa in sorted(gen.dfas.items()):
        gen.dump_dfa(name, dfa)


# Generated at 2022-06-11 19:48:39.640371
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    import io
# Test the same results as what is produced
# by running pgen.py directly as __main__
    pg = ParserGenerator()
    with io.open(__file__, encoding="utf-8") as f:
        pg.parsestring(f.read())
    pg = ParserGenerator()
    with io.open(__file__, encoding="utf-8") as f:
        pg.parsefile(f)


if __name__ == "__main__":

    pg = ParserGenerator()
    pg.parsestring(sys.stdin.read())
    print(pg.makegrammar())

# Generated at 2022-06-11 19:48:47.050869
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    pgen = ParserGenerator()
    pgen.dfas = {
        "thing": [DFAState({}, final=True)],
        "stuff": [DFAState({}, final=True)],
        "expr": [DFAState({}, final=True)],
        "exprlist": [
            DFAState({"thing": [0], "stuff": [0], "expr": [0]}, final=True),
            DFAState({"thing": [1], "stuff": [1], "expr": [1]}, final=True),
        ],
    }
    pgen.addfirstsets()
    for name, dfa in pgen.dfas.items():
        assert not dfa[0].arcs, name
    assert set(pgen.first["thing"]) == {"thing"}

# Generated at 2022-06-11 19:48:54.608808
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    pg = ParserGenerator()
    pg.add_dfa("a", [
        DFAState({0: 1, 1: 1}, False),
        DFAState({2: 1}, True),
        DFAState({3: 1}, True),
    ])
    pg.add_dfa("b", [
        DFAState({0: 1, 3: 1}, False),
        DFAState({2: 1}, False),
        DFAState({3: 1}, True),
    ])
    pg.add_dfa("c", [
        DFAState({0: 1, 3: 1}, False),
        DFAState({2: 1}, True),
    ])

# Generated at 2022-06-11 19:49:05.613336
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    t = ParserGenerator([])
    t.dfas = {
        "start" :
                 [DFAState({NFAState() : 1, NFAState() : 1}, None)],
        "one"   :
                 [DFAState({NFAState() : 1}, None)],
        "two"   :
                 [DFAState({NFAState() : 1}, None)]}
    t.dfas["start"][0].addarc(t.dfas["one"][0], "a")
    t.dfas["start"][0].addarc(t.dfas["two"][0], "b")
    t.dfas["one"][0].addarc(t.dfas["two"][0], "c")

# Generated at 2022-06-11 19:49:11.884782
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    pg = ParserGenerator()
    pg.gettoken = lambda: None
    pg.generator = iter(
        [
            (token.NAME, "A"),
            (token.OP, ":"),
            (token.NAME, "a"),
            (token.NEWLINE, "\n"),
        ]
    )
    pg.parse_rhs()



# Generated at 2022-06-11 19:49:22.030100
# Unit test for method dump_nfa of class ParserGenerator

# Generated at 2022-06-11 19:49:33.286113
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    pg = ParserGenerator()
    pg.setup()

# Generated at 2022-06-11 19:49:36.532214
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    p = ParserGenerator()
    g = PgenGrammar()
    p.symbol2number = g.symbol2number = {'name': 0, 'value': 1}
    p.make_first(g, 'name')
    p.make_first(g, 'value')


# Generated at 2022-06-11 19:49:47.149562
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    import py_grammar  # Imports parser.py, which imports this.  Grr.
    py_grammar_rules = py_grammar.parser_h_grammar
    class MockParserGenerator(ParserGenerator):
        def __init__(self, rules: str) -> None:
            self.generator = tokenize.generate_tokens(
                io.StringIO(rules).readline
            )
            self.gettoken()
            self.dfas = {}  # type: Dict[Text, List[DFAState]]
            self.first = {}  # type: Dict[Text, Dict[int, int]]
            self.addfirstsets()
    test_generator = MockParserGenerator(py_grammar_rules)
    # The unit test for method parse_item is in the function test_R

# Generated at 2022-06-11 19:50:31.398168
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    class MockParserGenerator(ParserGenerator):
        def __init__(self) -> None:
            self.value = ""
            self.type = 0
            self.expect_called = False
            self.gettoken_called = False
        def expect(self, type: int, value: Any = None) -> str:
            assert type == token.OP
            assert value is None or value == "]"
            assert self.gettoken_called
            self.expect_called = True
            return "]"
        def gettoken(self) -> None:
            self.gettoken_called = True
    pg = MockParserGenerator()
    a, z = pg.parse_item()
    assert pg.expect_called
    assert pg.gettoken_called
    assert pg.value == "]"

# Generated at 2022-06-11 19:50:43.498654
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    pg = ParserGenerator()
    pg.first = {}

# Generated at 2022-06-11 19:50:54.231398
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    pg = ParserGenerator()
    match = pg.parse_item.__code__.co_varnames[: pg.parse_item.__code__.co_argcount]
    env = {
        "pg": pg,
        "NFAState": NFAState,
        "type": pg.type,
        "value": pg.value,
        "gettoken": pg.gettoken,
        "parse_rhs": pg.parse_rhs,
        "parse_atom": pg.parse_atom,
    }
    exec(pg.parse_item.__code__, env)
    parse_item = env["parse_item"]
    pg.type = token.STRING
    pg.value = "foo"
    a, z = parse_item()

# Generated at 2022-06-11 19:51:07.347529
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    """
    >>> p = ParserGenerator("")
    >>> dfa1 = p.make_dfa(NFAState(), NFAState())
    >>> dfa1[0].addarc(0, "a")
    >>> dfa2 = p.make_dfa(NFAState(), NFAState())
    >>> dfa2[0].addarc(0, "b")
    >>> dfas = {"start":[dfa1, 0, {"NAME":1}], "NAME":[dfa2, 0, {}]}
    >>> p.dfas = dfas
    >>> p.first = {}
    >>> p.addfirstsets()
    >>> p.first
    {'NAME': {'b': 1}, 'start': {'a': 1, 'b': 1}}
    """



# Generated at 2022-06-11 19:51:11.384793
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    parser = ParserGenerator()

    # Dump of NFA for STRING
    assert parser.dump_nfa("STRING", NFAState(), NFAState()) == None
    assert list(parser.stream) == []



# Generated at 2022-06-11 19:51:19.014162
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    pgen = ParserGenerator()
    pgen.make_grammar(
        """
        start: other*
        other: 'a' 'b' | 'c'
        """
    )
    assert pgen.dfas == {'other': [DFAState({0: 1}, isfinal=False), DFAState({}, isfinal=True)], 'start': [DFAState({0: 1}, isfinal=False), DFAState({0: 1}, isfinal=True)]}
    assert pgen.first == {'other': {'c': 1, 'ab': 1}, 'start': {'c': 1, 'ab': 1}}
    assert pgen.startsymbol == 'start'

# Generated at 2022-06-11 19:51:27.039467
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    from textwrap import dedent

    def make_nfa(source: Text) -> Tuple[ParserGenerator, ParserGenerator.NFAState, ParserGenerator.NFAState]:
        nfa = ParserGenerator()
        nfa.parse_grammar(dedent(source))
        return nfa, nfa.start, nfa.finish


# Generated at 2022-06-11 19:51:33.473382
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    filename = os.path.join(os.path.dirname(__file__), "graminit.txt")
    with open(filename, "r") as f:
        pg = ParserGenerator(f.readline)
        pg.gettoken()
        for name in pg.dfas:
            pg.expect(tokenize.NAME, name)
            pg.expect(tokenize.OP, ':')
            pg.parse_rhs()
        pg.expect(tokenize.ENDMARKER)

# Generated at 2022-06-11 19:51:46.776911
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    def check(source: str, expect: Sequence[Tuple[int, str]]) -> None:
        pg = parser.ParserGenerator()
        pg.setup("test.txt", StringIO(source))
        actual = []
        while pg.type != token.ENDMARKER:
            actual.append((pg.type, pg.value))
            pg.gettoken()
        assert actual == expect, (actual, expect)


# Generated at 2022-06-11 19:51:51.053572
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    class DFAState:
        pass

    p = ParserGenerator()
    p.dump_dfa("test", [DFAState()])



# Generated at 2022-06-11 19:53:26.602496
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    lines = [
        "def foo(): # abc\n",
        "  while 1:\n",
        "    if 1:\n",
        "      def bar():\n",
        "        '''def'''\n",
    ]
    if sys.version_info[0] >= 3:
        from io import StringIO

        f = StringIO("".join(lines))
    else:
        from io import BytesIO as StringIO

        f = StringIO("".join(lines).encode("utf-8"))
    gen = tokenize.generate_tokens(f.readline)
    p = ParserGenerator()
    p.generator = gen
    p.gettoken()
    p.filename = "myfile.py"
    start, finish = p.parse_rhs()

# Generated at 2022-06-11 19:53:32.200997
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    # Test with Grammar
    pg = ParserGenerator("Grammar")
    pg.dump_nfa("test", pg.start, pg.start)


pg = ParserGenerator("Grammar")
gram = pg.parse()
pg.dump_dfa("test", gram)

if __name__ == "__main__":
    import sys

    pg = ParserGenerator("Grammar")
    gram = pg.parse()
    print("### Grammar")
    print("pg.dfas =")
    dump_obj(pg.dfas)
    print("pg.first =")
    dump_obj(pg.first)
    print("pg.startsymbol =", pg.startsymbol)
    print("### Grammar-DFA")
    print("pg.dfas =")

# Generated at 2022-06-11 19:53:33.849492
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    # write your code here...
    pass


# Generated at 2022-06-11 19:53:40.680659
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    from . import token
    # Test ParserGenerator.__init__
    pg = ParserGenerator()
    assert pg.debuglevel == 0
    assert pg.startsymbol == ''
    assert pg.symbols == []
    assert pg.dfas == {}
    assert pg.first == {}
    # Test ParserGenerator.__repr__
    s = repr(pg)
    assert (s == "<ParserGenerator start='' symbols=[]>") or (s == "<ParserGenerator start='' symbols=[] first={}>")
    # Test ParserGenerator.parse
    pg.parse(r"""\
    expr:
        x_or_y '+' expr | x_or_y
    x_or_y:
        'x' | 'y'
    """)
    assert pg.startsymbol

# Generated at 2022-06-11 19:53:54.001186
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    from pgen2.driver import Driver
    from pgen2.pgen import ParserGenerator

    pgen = ParserGenerator()
    for file in driver.files:
        pgen.parse_grammar(file)
        pgen.make_automaton()
        for name, dfa in sorted(pgen.dfas.items()):
            pgen.dump_nfa(name, dfa[0], dfa[-1])
    return pgen

if __name__ == "__main__":
    parser = ParserGenerator()
    for filename in sys.argv[1:]:
        parser.parse_grammar(filename)
    parser.make_automaton()
    driver = Driver(parser)
    driver.generate_parser(open("Parser/pgen.py", "w"))

#

# Generated at 2022-06-11 19:54:03.952277
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    c = ParserGenerator()
    c.labels = []
    c.symbol2number = {"NUMBER": 2, "NAME": 3}
    c.symbol2label = {}
    c.tokens = {token.NUMBER: 5}
    c.keywords = {"None": 7}
    assert c.make_label(c, "None") == 7
    assert c.make_label(c, "NUMBER") == 2
    assert c.make_label(c, "NAME") == 3
    c.symbol2label["NAME"] = 3
    assert c.make_label(c, "NAME") == 3



# Generated at 2022-06-11 19:54:14.757527
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    pg = ParserGenerator()

# Generated at 2022-06-11 19:54:24.190657
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    import token, tokenize
    generator = iter([
        (token.NAME, "hello"),
        (token.OP, ":"),
        (token.NAME, "world"),
        (token.NEWLINE, ""),
        (token.NAME, "foo"),
        (token.OP, "="),
        (token.STRING, '"hello"'),
        (token.ENDMARKER, ""),
    ])
    x = ParserGenerator('<test>', generator)
    x.gettoken()
    x.expect(token.NAME, "hello")
    x.expect(token.OP, ":")
    x.expect(token.NAME, "world")
    x.expect(token.NEWLINE)
    x.expect(token.NAME, "foo")

# Generated at 2022-06-11 19:54:31.360011
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    pg = ParserGenerator()
    pg.type = token.NAME
    pg.value = "var"
    pg.expect(token.NAME)
    pg.type = token.NAME
    pg.value = "var"
    pg.expect(token.NAME, "var")
    pg.type = token.NAME
    pg.value = "var"
    pg.expect(token.NAME, "xvar")



# Generated at 2022-06-11 19:54:39.549773
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    from .pgen import ParserGenerator
    pg = ParserGenerator()
    pg.gettoken = lambda: None
    class fake_DFAState:
        def __init__(self, nfaset, isfinal=False):
            self.nfaset = nfaset
            self.isfinal = isfinal
            self.arcs = {}
        def addarc(self, next, label):
            self.arcs[label] = next
        def __eq__(self, other):
            return self.arcs == other.arcs and self.isfinal == other.isfinal
    a, b, c, d, e, f, g, h, i, j, k, l, m, n = [fake_DFAState(x) for x in range(14)]