

# Generated at 2022-06-11 19:46:28.009416
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    import collections
    import itertools
    from pgen2.pgen import ParserGenerator
    from pgen2.tokenize import tokenize
    from pgen2.grammar import Grammar

    def tokenize_lines(s):
        tokens = []
        for line in s.splitlines():
            tokens.extend(
                tokenize(iter([line]).__next__, line, True, False, False).__next__()
            )
        return tokens

    def compare_output(tokens, src, maxdfa=None):
        pg = ParserGenerator(Grammar(src), "single")
        dfa = pg.make_dfa(pg.start, pg.finish)

        assert len(dfa) == len(pg.dfas)

# Generated at 2022-06-11 19:46:35.622068
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    import os
    import pgen2.driver
    from pgen2.parse import ParserGenerator

    from . import token

    def test_pgen(pgen: ParserGenerator) -> None:
        tokenizer = pgen.make_pgen_grammar()

# Generated at 2022-06-11 19:46:42.619083
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    assert repr(PgenGrammar("")) == "PgenGrammar('', {})"
    assert repr(PgenGrammar("", {}, "grammar.py")) == "PgenGrammar('', {}, 'grammar.py')"
    assert repr(PgenGrammar("", {}, "grammar.py", "asdl.py")) == "PgenGrammar('', {}, 'grammar.py', 'asdl.py')"


# These are no longer used and should be deleted

# Generated at 2022-06-11 19:46:54.289154
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    parser = ParserGenerator()

    def parse(input:str) -> Tuple["NFAState", "NFAState"]:
        parser.setup(input)
        return parser.parse_item()

    def dump(a: "NFAState", z: "NFAState") -> str:
        return "%s -> %s" % (a.arcs, z.arcs)

    assert dump(*parse('("foo")')) == '[] -> [(None, <PgenNFAState %d>)]' % id(z)
    assert dump(*parse("foo")) == '[[("foo", <PgenNFAState %d>)]' % id(z)

# Generated at 2022-06-11 19:47:02.694087
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    def check(before, after):
        p = ParserGenerator()
        dfa = [DFAState(None, None), DFAState(None, None), DFAState(None, None)]
        for i, state in enumerate(dfa):
            for label, next in before[i]:
                state.addarc(dfa[next], label)
        p.simplify_dfa(dfa)
        for i, state in enumerate(dfa):
            arcs = state.arcs
            if arcs:
                labels = sorted(arcs.keys())
                j = labels.index
                assert [j(label) for label in labels] == after[i]
            else:
                assert after[i] == []

    check([[], [], []], [[], [], []])

# Generated at 2022-06-11 19:47:10.762742
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    pg = ParserGenerator([])
    pg.type = token.STRING
    pg.value = "'hello'"
    pg.gettoken = Mock()
    pg.parse_item = Mock()
    pg.parse_item.return_value = (NFAState(0), NFAState(1))
    a, z = pg.parse_alt()
    assert a.id == 0
    assert z.id == 1

    pg.value = "|"
    pg.gettoken = Mock()
    pg.parse_item = Mock()
    pg.parse_item.return_value = (NFAState(0), NFAState(1))
    a, z = pg.parse_alt()
    assert a.id == 0
    assert z.id == 1

    pg.value = "'foo'"

# Generated at 2022-06-11 19:47:20.957852
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    nfa0 = NFAState()
    nfa1 = NFAState()
    nfa0.addarc(nfa1, "a")
    nfa1.addarc(nfa0, "b")
    pg = ParserGenerator()
    dfa = pg.make_dfa(nfa0, nfa1)
    assert len(dfa) == 2
    assert dfa[0].isfinal == 0
    assert dfa[1].isfinal == 1

    nfa2 = NFAState()
    nfa2.addarc(nfa0)
    nfa0.addarc(nfa1, "a")
    dfa = pg.make_dfa(nfa0, nfa1)
    assert len(dfa) == 3
    assert dfa[0].isfinal == 0
    assert d

# Generated at 2022-06-11 19:47:29.274818
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    pgen = ParserGenerator()
    # s = "<start> -> <a> <b>"
    a = NFAState()
    b = NFAState()
    a.addarc(b)
    aa = pgen.make_dfa(a, b)
    pgen.dfas["a"] = aa
    pgen.first["a"] = {"x": 1, "y": 1}
    # t = "<start> -> <a> <b>"
    a = NFAState()
    b = NFAState()
    a.addarc(b)
    aa = pgen.make_dfa(a, b)
    pgen.dfas["b"] = aa
    pgen.first["b"] = {"y": 1, "z": 1}
    # s = "<start> -> <

# Generated at 2022-06-11 19:47:38.213537
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    p = ParserGenerator()
    p.stdtokenize(
        dedent(
            '''\
            def: "def" name ":" "pass"
            '''
        )
    )
    print(p.dfas)
    assert p.startsymbol == "def"
    dfa = p.dfas["def"]
    assert len(dfa) == 2
    assert dfa[0].arcs == {'"def"': dfa[1]}
    assert dfa[1].arcs == {'name': dfa[1], '":":': dfa[1], '"pass"': dfa[1]}
    print(p.first)
    print(p.make_converter().labels)



# Generated at 2022-06-11 19:47:40.021453
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    p = ParserGenerator()
    p.filename = "foo"
    p.end = (1, 2)
    p.line = "line"
    p = ParserGenerator()
    p.raise_error("%s", "foo")

# Generated at 2022-06-11 19:48:20.027377
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    # dummy
    print("XXX Not implemented")



# Generated at 2022-06-11 19:48:26.380588
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    """Method make_grammar of class ParserGenerator"""
    _ = ParserGenerator()
    # Expecting AttributeError
    with expect_except(AttributeError):
        _.make_grammar()

# Generated at 2022-06-11 19:48:35.820501
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    # Method parse_alt
    pg = ParserGenerator()
    pg.initlexer(b"r: (a b c) | d e f | g")
    a, z = pg.parse_alt()
    assert isinstance(a, NFAState)
    assert isinstance(z, NFAState)
    assert len(a.arcs) == 1 and a.arcs[0][0] is None
    assert len(z.arcs) == 3
    # print a, z
    # assert 0, (a, z)

# Generated at 2022-06-11 19:48:44.340796
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    pg = ParserGenerator(None)
    pg.symbol2number = {}
    pg.labels = []
    pg.tokens = {}
    pg.keywords = {}
    pg.symbol2label = {}
    first = {}
    name = 'NAME'
    d = dict(NAME=1, NUMBER=1)  # type: Dict[Text, Any]
    pg.first = {name: d}
    label = 'NAME'
    assert isinstance(pg.make_first(pg, name), dict)
    pg.labels.append((2, 3))
    pg.symbol2label[name] = 1
    assert label in d
    assert isinstance(pg.make_first(pg, name), dict)
    symbol = 'NAME'
    pg.symbol2number[name] = 1

# Generated at 2022-06-11 19:48:46.398219
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    with pytest.raises(SyntaxError):
        ParserGenerator(None, [(token.NAME, "foo", (1, 1), (1, 1), "foo")]).expect(token.NAME, "bar")


# Generated at 2022-06-11 19:48:49.802499
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    PgenGrammar()


# Generated at 2022-06-11 19:48:57.825101
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    pg = ParserGenerator()
    # the following example is adapted from the grammar for python2.5:
    # start symbol: file_input
    # rule file_input: (NEWLINE | stmt)* ENDMARKER
    # rule stmt: simple_stmt | compound_stmt
    # rule simple_stmt: small_stmt (';' small_stmt)* [';'] NEWLINE
    # rule small_stmt: (expr_stmt | print_stmt  | del_stmt | pass_stmt | flow_stmt |
    #                    import_stmt | global_stmt | exec_stmt | assert_stmt)
    # rule expr_stmt: testlist (augassign (yield_expr|testlist) |
    #                    ('=' (yield_expr|testlist))*)
    #

# Generated at 2022-06-11 19:49:02.315918
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    g = ParserGenerator()

# Generated at 2022-06-11 19:49:13.639628
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    # Function parse_rhs parses a RHS.

    def check(s: Text, answer: Text) -> None:
        rhs = ParserGenerator(StringIO(s)).parse_rhs()
        print(rhs)
        trigraphs = {">": "|", "=": "}", "/": "\\", "-": "~"}
        s = s.translate(str.maketrans(trigraphs))
        testcase = answer == s
        assert testcase, "parse_rhs(%r) -> %r, should be %r" % (s, rhs, s)

    check("x", "x")
    check("[x]", "[x ]")
    check("[]", "[ ]")
    check("[('x')]", "[('x' )]")

# Generated at 2022-06-11 19:49:23.070610
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    pg = ParserGenerator(0)
    # Put some DFAStates in a list
    dfa = [DFAState({}, final=False), DFAState({}, final=True)]
    dfa[0].addarc(dfa[1], "foo")
    pg.dump_dfa("test", dfa)

# The parser generator grammar
