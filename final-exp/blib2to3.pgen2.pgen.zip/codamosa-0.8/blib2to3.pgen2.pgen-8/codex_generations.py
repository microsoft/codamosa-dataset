

# Generated at 2022-06-11 19:47:22.490521
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    from GrammarMaker import ParserGenerator
    from Grammar import grammar
    for rule in grammar.grammar_rules.keys():
        parser = ParserGenerator(grammar.grammar_rules[rule])
        parser.parse_alt()
    print('OK')

# Generated at 2022-06-11 19:47:32.707926
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    nfa1 = NFAState()
    nfa2 = NFAState()
    nfa3 = NFAState()
    nfa4 = NFAState()
    nfa1.addarc(nfa2, 'A')
    nfa2.addarc(nfa3, 'B')
    nfa3.addarc(nfa2, 'A')
    nfa2.addarc(nfa4, 'C')
    nfa4.addarc(nfa3, 'B')
    dfa1 = DFAState({nfa1: 1, nfa2: 1, nfa3: 1, nfa4: 1}, nfa4)
    dfa2 = DFAState({nfa3: 1, nfa4: 1}, nfa4)
    dfa1.addarc(dfa2, 'A')

# Generated at 2022-06-11 19:47:41.582889
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    import os
    import sys
    import unittest

    from . import grammar
    from . import token

    class TestCase(unittest.TestCase):
        def test_make_grammar(self):
            self.maxDiff = None
            pg = ParserGenerator()
            grammar_path = os.path.join(sys.exec_prefix, "Lib", "grammar.txt")
            pg.parse_grammar(grammar_path)
            c = pg.make_grammar()
            self.assertEqual(c.debug, 0)
            self.assertEqual(c.start, 1)

# Generated at 2022-06-11 19:47:49.121169
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    pg = ParserGenerator()
    token = next(tokenize.tokenize(">= > = == =="))
    pg.type = token.exact_type
    pg.value = token.string
    pg.begin = (token.start[0], token.start[1])
    pg.end = (token.end[0], token.end[1])
    pg.line = token.line
    pg.gettoken()
    assert pg.type == token.exact_type, pg.type
    assert pg.value == token.string, pg.value
    assert pg.begin == (token.start[0], token.start[1]), pg.begin
    assert pg.end == (token.end[0], token.end[1]), pg.end
    assert pg.line == token.line, pg.line
    return True


# Generated at 2022-06-11 19:47:59.996496
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    s = """
        a ::= "a";
        b ::= "b";
        c ::= "c";
    """
    pg = ParserGenerator()
    pg.parse_grammar(s)
    # This can't go wrong.  But let's check anyway.
    assert len(pg.first) == 3
    assert pg.first["a"] == {"a": 1}
    assert pg.first["b"] == {"b": 1}
    assert pg.first["c"] == {"c": 1}
    # Make sure the graph is well-formed.
    def check_dfa(dfa):
        for state in dfa:
            for label, next in state.arcs.items():
                assert label in pg.symbol2number
                assert next in dfa

# Generated at 2022-06-11 19:48:05.275561
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    pg = ParserGenerator()
    # The following call to simplify_dfa fails because of indices
    # being out of range (because of the duplicate state being removed
    # and the index list of arcs not being updated).
    states = pg.make_dfa(NFAState(), NFAState())
    pg.simplify_dfa(states)

# Generated at 2022-06-11 19:48:17.126683
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    def parse(s: Text) -> Dict[Text, List[List[Tuple[Text, Text]]]]:
        a = ParserGenerator()
        a.parse(s)
        return a.dfas

    assert parse("a : 'x'") == {"a": [[(None, "x")]]}
    assert parse("a : b\n") == {"a": [[(None, "b")]]}
    assert parse("a : 'x' | 'y'") == {"a": [[(None, "x")], [(None, "y")]]}
    assert parse("a : 'x' b\n") == {"a": [[(None, "x"), (None, "b")]]}

# Generated at 2022-06-11 19:48:22.776363
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    pg = ParserGenerator()
    pg.generator = pg._setup_generator()
    pg.gettoken() # 0.0 '['
    pg.gettoken() # 6.0 'a'
    assert pg.parse_atom() == (
        NFAState(arcs=[(None, NFAState(arcs=[('a', NFAState())]))]),
        NFAState(arcs=[('a', NFAState())]),
    ), 'parse_atom()'

# Generated at 2022-06-11 19:48:25.671267
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    parser = ParserGenerator()
    parser.expect(1,2)

# Generated at 2022-06-11 19:48:36.741798
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    P = ParserGenerator()
    dfa = [DFAState({"foo": 1, "bar": 1}, True), DFAState({"foo": 1, "bar": 1}, False)]
    dfa[0].addarc(dfa[1], "a")
    dfa[0].addarc(dfa[0], "b")
    dfa[1].addarc(dfa[0], "c")
    dfa[1].addarc(dfa[1], "d")
    assert len(dfa) == 2
    P.simplify_dfa(dfa)
    assert len(dfa) == 1

# Generated at 2022-06-11 19:49:10.455896
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    p = ParserGenerator()
    p._init_pgen()
    p.f = io.StringIO("""a b'c' (d|e)
f""")
    p.gettoken()
    start, finish = p.parse_alt()



# Generated at 2022-06-11 19:49:12.424028
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    pg = ParserGenerator()
    return pg.parse_item()


# Generated at 2022-06-11 19:49:13.507017
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    PgenGrammar()



# Generated at 2022-06-11 19:49:23.015593
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    from .pgen2_tokenize import generate_tokens

    grammar = """
    start: NAME | "foo"
    NAME: "[a-z]+"
    """
    pg = ParserGenerator()
    pg.pgen(grammar, "test_pgen")

    pg.dump_nfa('start', pg.dfas['start'][0], pg.dfas['start'][1])
    tokens = generate_tokens(grammar)
    pg.dump_dfa('start', pg.make_dfa(pg.dfas['start'][0], pg.dfas['start'][1]))
    pg.simplify_dfa(pg.make_dfa(pg.dfas['start'][0], pg.dfas['start'][1]))

# Generated at 2022-06-11 19:49:33.935227
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    pg = ParserGenerator()
    try:
        pg.raise_error(msg="msg", args=())
    except SyntaxError as e:
        assert e.msg == "msg"
        assert e.filename == None
        assert e.lineno == 0
        assert e.offset == 0
        assert e.text == ''
    except:
        assert False
    pg.end = (1, 2)
    pg.line = "line"
    pg.filename = "filename"
    try:
        pg.raise_error(msg="msg", args=())
    except SyntaxError as e:
        assert e.msg == "msg"
        assert e.filename == "filename"
        assert e.lineno == 1
        assert e.offset == 2
        assert e.text == 'line'
    except:
        assert False

# Generated at 2022-06-11 19:49:41.978811
# Unit test for method parse of class ParserGenerator

# Generated at 2022-06-11 19:49:42.693929
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    # XXX: Implement tests
    pass


# Generated at 2022-06-11 19:49:46.401891
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    # TODO: implement following test
    raise NotImplementedError()

# Generated at 2022-06-11 19:49:47.909955
# Unit test for function generate_grammar
def test_generate_grammar():
    p = ParserGenerator(Path(grammar_path))
    assert p.make_grammar().start is not None
    assert p.make_grammar().keywords["and"] > 255
# Unit tests for class ParserGenerator

# Generated at 2022-06-11 19:49:58.269800
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    pg = Grammar()
    pg.add_rule(r'''atoms: '[' rhs ']' | NAME | STRING
rhs: ALT ('|' ALT)*
ALT: ITEM+
ITEM: '[' rhs ']' | ATOM ['+' | '*']
ATOM: '(' rhs ')' | NAME | STRING

NAME: '\w+'
STRING: '\".*?\"'
ALT: '\[.*?\]'
''')
    pg.startsymbol = "atoms"
    pg.compile()

    struct = pg.builder.dfas["NAME"]
    print(struct)
    start = struct[0]
    finish = struct[-1]
    assert start.isfinal == False
    assert finish.isfinal == True


# Generated at 2022-06-11 19:50:39.070124
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    import unittest

    class Tests(unittest.TestCase):

        def test_issue28217(self):
            pg = ParserGenerator()
            pg.add_rhs("expr", "expr or_test", "or_test")
            pg.add_rhs("or_test", "and_test", "or_test or and_test")
            pg.add_rhs("and_test", "not_test", "and_test and not_test")
            pg.add_rhs("not_test", "not not_test", "(", "xor_expr")
            pg.add_rhs("xor_expr", "xor_expr xor and_expr", "and_expr")
            pg.add_rhs("and_expr", "and_expr and shift_expr", "shift_expr")
           

# Generated at 2022-06-11 19:50:43.414978
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    filename = "<string>"
    msg = "test message"
    try:
        pg = ParserGenerator(filename, msg)
        pg.raise_error("test %s", "message")
    except SyntaxError as e:
        assert e.args == (msg, (filename, 1, 0, msg)), e.args



# Generated at 2022-06-11 19:50:45.372664
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    pg = ParserGenerator()
    message = "expected a token but didn't get one."
    pg.raise_error(message)

# Generated at 2022-06-11 19:50:56.012959
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    import io
    import unittest
    import builtins
    import tokenize
    class Loose(builtins.object):
        def __getattr__(self, name):
            return name
        def __repr__(self):
            return "Loose"
    class TestException(Exception):
        pass
    l = Loose()
    class Test(unittest.TestCase):

        def get_token(self, *args):
            self.next += 1
            try:
                return self.tokens[self.next - 1]
            except IndexError:
                return (tokenize.ENDMARKER, "")
        def get_value(self, *args):
            return self.get_token(args)[1]

# Generated at 2022-06-11 19:51:09.088765
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    from typing import Any, List
    from .converter import PgenGrammar

    class C:
        labels: List[Tuple[int, str]]
        symbol2number: Dict[str, int]
        symbol2label: Dict[str, int]
        tokens: Dict[int, int]
        keywords: Dict[str, int]

    def make_label(parser: ParserGenerator, label: str) -> int:
        c = C()
        c.labels = []
        c.symbol2number = {}
        c.symbol2label = {}
        c.tokens = {}
        c.keywords = {}
        parser.make_label(c, label)
        return c.labels[0][0]

    p = ParserGenerator()

# Generated at 2022-06-11 19:51:18.555292
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    # Test cases for method parse_atom of class ParserGenerator
    class MockGrammar:
        def __init__(self) -> None:
            self.first: Dict[str, Dict[str, int]] = {}

    def check(s: str, expected: Tuple[str, str]) -> None:
        pg = ParserGenerator(StringIO(s), "<test string>", MockGrammar())
        pg.gettoken()
        a, z = pg.parse_atom()
        assert len(a.arcs) == 1, a.arcs
        assert a.arcs[0][0] == expected[0], a.arcs[0][0]
        assert len(z.arcs) == 0, z.arcs
        assert pg.type == token.ENDMARKER, pg.type

    #

# Generated at 2022-06-11 19:51:26.766074
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    # print "calcfirst of ParserGenerator"
    p = ParserGenerator()
    p.add_production('expr', ['expr', '+', 'expr'])
    p.add_production('expr', ['expr', '-', 'expr'])
    p.add_production('expr', ['(', 'expr', ')'])
    p.add_production('expr', ['NUMBER'])
    p.addfirstsets()

    f = p.first['expr']
    assert len(f) == 4
    assert '+' in f
    assert '-' in f
    assert '(' in f
    assert 'NUMBER' in f

    f = p.first['expr+']
    assert len(f) == 4
    assert '+' in f
    assert '-' in f
    assert '(' in f

# Generated at 2022-06-11 19:51:33.964577
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    gen = ParserGenerator()
    gen.gettoken = lambda: None # Hack to suppress TokenError
    gen.raise_error = lambda *args: None # Hack to suppress SyntaxError
    spec = """\
spam: eggs
eggs: ham [sausages] | spam
"""
    print(spec)
    spec = open("spec").read()
    gen.setup(spec)
    dfas, startsymbol = gen.parse()
    for name, dfa in sorted(dfas.items()):
        gen.dump_nfa(name, dfa[0].nfaset[0], dfa[0].finish)


# Generated at 2022-06-11 19:51:47.071619
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    from . import tokenize
    from io import StringIO
    g = ParserGenerator()
    g.filename = "foo"
    g.line = "x = 1"
    g.type = token.NAME
    g.value = "x"
    g.begin = (1, 0)
    g.end = (1, 1)
    g.gettoken = lambda *args: None
    g.generator = iter(
        tokenize.generate_tokens(StringIO("= 1").readline)  # type: ignore
    )
    g.raise_error = lambda msg, *args: None
    msg = "msg %s %d"
    args = ("foo", 42)
    try:
        g.expect(token.OP, "*")
    except:
        pass

# Generated at 2022-06-11 19:51:52.282206
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    p = ParserGenerator()
    p.add_dfa('a', [DFAState({'b': 1}, True), DFAState({}), DFAState({})])

# Generated at 2022-06-11 19:52:52.894602
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    # Check that the expected exception is raised
    with pytest.raises(SyntaxError):
        p = ParserGenerator("")
        p.expect(1, 'a')

    # Check that the attribute type is set correctly
    pg = ParserGenerator("")
    pg.type = 1
    pg.expect(2, 'a')
    assert pg.type == 2, "pg.type should be 2"

    # Check that the attribute value is set correctly
    pg.expect(1, 'a')
    assert pg.value == 'a', "pg.value should be 'a'"


# Generated at 2022-06-11 19:53:03.062985
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    pg = ParserGenerator()
    state1 = DFAState({1: 1}, False)
    state2 = DFAState({2: 1}, False)
    state1.addarc(state2, "a")
    state1.addarc(state2, "b")
    state1.addarc(state2, "b")
    state3 = DFAState({3: 1}, False)
    state2.addarc(state3, "b")
    state2.addarc(state3, "a")
    state4 = DFAState({4: 1}, False)
    state3.addarc(state4, "a")
    state1.addarc(state4, "a")
    state0 = DFAState({0: 1}, False)
    state0.addarc(state1, "a")
    state4

# Generated at 2022-06-11 19:53:09.254331
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    p = ParserGenerator()
    from tokenize import tokenize
    from io import StringIO
    p.generator = tokenize(StringIO('foo').readline)
    p.gettoken()
    a, z = p.parse_item()
    assert a == NFAState()
    assert z == NFAState()
    assert a.arcs == [(None, z)]
    assert z.arcs == []

# Generated at 2022-06-11 19:53:20.578527
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    dfa = [
        DFAState({"a": 1}, False),
        DFAState({"b": 1}, False),
        DFAState({"c": 1}, False),
        DFAState({"d": 1}, False),
    ]
    dfa[0].addarc(dfa[1], "0")
    dfa[0].addarc(dfa[2], "0")
    dfa[1].addarc(dfa[3], "0")
    dfa[2].addarc(dfa[3], "0")
    dfa[3].addarc(dfa[0], "0")

    parser = ParserGenerator()
    parser.simplify_dfa(dfa)

    assert len(dfa) == 3, (len(dfa), dfa)

# Generated at 2022-06-11 19:53:27.523109
# Unit test for method simplify_dfa of class ParserGenerator

# Generated at 2022-06-11 19:53:31.817149
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    pg = ParserGenerator()
    c = pg.make_converter()
    assert pg.make_label(c, "NAME") == 0, "Bug in make_label"
    assert pg.make_label(c, "foo") == 0, "Bug in make_label"
    assert pg.make_label(c, "'hello'") == 1, "Bug in make_label"
    assert pg.make_label(c, "'hello'") == 1, "Bug in make_label"
    assert pg.make_label(c, "'world'") == 2, "Bug in make_label"

# Generated at 2022-06-11 19:53:39.374736
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():  # Known fails: no coverage.
    # Test that ParserGenerator.make_first works.
    pg = ParserGenerator()

# Generated at 2022-06-11 19:53:51.292497
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():

    print("Testing method gettoken of class ParserGenerator")

    code = """\
    def f(x):
        '''
        x -> x + 1
        '''
        pass
    """
    parser = ParserGenerator(code)
    for tok in tokenize.tokenize(io.BytesIO(code.encode("utf-8")).readline):
        parser.type = tok.type
        if tok.type == token.STRING:
            parser.value = eval(tok.string)
        else:
            parser.value = tok.string
        parser.begin = tok.start
        parser.end = tok.end
        parser.line = tok.line
        # print (tok.type, tok.string, tok.start, tok.end, tok.line)

# Generated at 2022-06-11 19:53:57.619337
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    p = ParserGenerator(None)
    lst = [
        (token.NAME, "p"),
        (token.OP, ":"),
        (token.NEWLINE, "\n"),
        (token.ENDMARKER, "end"),
    ]
    for tup in lst:
        p.type, p.value = None, None
        p.gettoken()
        assert p.type == tup[0]
        assert p.value == tup[1]
    print("ParserGenerator.gettoken() OK")



# Generated at 2022-06-11 19:54:07.860916
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    cfg = """
    expr : (expr '+' term | expr '-' term | term)
    term : term '*' factor | term '/' factor | factor
    factor : '+' factor | '-' factor | '(' expr ')' | NUMBER
    """
    gen = ParserGenerator(cfg, "expr")
    gen.addfirstsets()
    first = {}
    for name, dfa in sorted(gen.dfas.items()):
        first[name] = set()
        for state in dfa:
            for label, next in state.arcs.items():
                if label == token.NAME:
                    first[name].add(label)