

# Generated at 2022-06-11 19:46:43.702757
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    from . import grammar
    from .grammar import PgenGrammar
    assert issubclass(grammar.PgenGrammar, PgenGrammar)
    assert not issubclass(PgenGrammar, grammar.PgenGrammar)
    assert issubclass(PgenGrammar, grammar.Grammar)


# Generated at 2022-06-11 19:46:55.232678
# Unit test for method parse of class ParserGenerator

# Generated at 2022-06-11 19:47:02.365831
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    pg = ParserGenerator(io.StringIO("a b"))
    assert pg.expect(token.NAME) == "a"
    assert (pg.expect(token.NAME), pg.expect(token.NAME)) == ("b", None)
    try:
        pg.expect(token.NAME)
    except SyntaxError:
        pass
    else:
        raise AssertionError



# Generated at 2022-06-11 19:47:10.620330
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    pg = ParserGenerator()

# Generated at 2022-06-11 19:47:20.958086
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    from .tokenizer import generate_tokens, tok_name
    from io import StringIO
    gen = generate_tokens(StringIO("print(1+2)"))
    pg = ParserGenerator()
    pg.generator = gen
    pg.gettoken()
    assert pg.type == token.NAME
    assert pg.value == "print"
    pg.gettoken()
    assert pg.type == token.OP
    assert pg.value == "("
    pg.gettoken()
    assert pg.type == token.NUMBER
    assert pg.value == "1"
    pg.gettoken()
    assert pg.type == token.OP
    assert pg.value == "+"
    pg.gettoken()
    assert pg.type == token.NUMBER
    assert pg.value == "2"

# Generated at 2022-06-11 19:47:25.044431
# Unit test for function generate_grammar
def test_generate_grammar():
    p = ParserGenerator()
    p.p_newline_or_space()
    assert p.grammar.dfas["NEWLINE_OR_SPACE"][0].arcs == {
        " ": p.grammar.dfas["NEWLINE_OR_SPACE"][0],
        "\n": p.grammar.dfas["NEWLINE_OR_SPACE"][0],
    }

Generator = GeneratorType[Token, Tree]


# Generated at 2022-06-11 19:47:34.334470
# Unit test for method make_grammar of class ParserGenerator

# Generated at 2022-06-11 19:47:41.518384
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    e = None
    try:
        p = ParserGenerator(tokenize.generate_tokens(StringIO('a "b" ek').readline))
        assert p.expect(token.NAME) == "a"
        assert p.expect(token.STRING) == "b"
        assert p.expect(token.NAME) == "ek"
        assert p.expect(token.NAME, "fk") == "fk"
    except BaseException as err:
        e = err
    assert e is not None, "Unexpected success"
    assert type(e) is SyntaxError, "Wrong exception type (expected SyntaxError, got %s)" % type(e)

# Generated at 2022-06-11 19:47:48.672663
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    # Test case adapted from Lib/test/test_tokenize.py
    filename = "<string>"
    buf = ["x = # hi\n"]
    p = ParserGenerator()
    gen = p.generate_tokens(buf, filename)  # type: ignore
    next(gen)
    gen.send((token.NAME, "x", (1, 0), (1, 1), "x = # hi\n"))

    exc = raises(SyntaxError, gen.send, (token.OP, "=", (1, 2), (1, 3), "x = # hi\n"))
    msg = str(exc)
    assert msg == "expected ==, got =/="



# Generated at 2022-06-11 19:47:57.662326
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    import io
    import sys

    sio = io.StringIO()
    sys.stdout = sio
    data = """
    # calculate simple arithmetic expressions
    # with +, - and parentheses

    expr ::= (expr)
    expr ::= expr "+" expr
    expr ::= expr "-" expr
    expr ::= NUMBER
    """
    pg = ParserGenerator()
    pg.parse(data)
    pg.make_grammar()
    print(pg.grammar)
    sio.seek(0)

# Generated at 2022-06-11 19:48:29.014807
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    class ParserGenerator(ParserGenerator_Helper):
        def __init__(self, i):
            self.i = i
        def raise_error(self, msg: str,*args: Any) -> NoReturn:
            raise self.i
    try:
        raise Exception("Ignore this exception.")
    except:
        try:
            raise AssertionError("Unit test for method raise_error of class ParserGenerator failed.")
        except:
            raise ParserGenerator(sys.exc_info())


# Generated at 2022-06-11 19:48:40.118932
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    class DFAState:
        """Dummy DFA state for unit testing and debugging"""

        def __init__(self, nfaset: Dict[Text, int], finish: "NFAState") -> None:
            self.nfaset = nfaset
            self.isfinal = finish in nfaset
            self.arcs: Dict[Text, "DFAState"] = {}

        def addarc(self, next: "DFAState", label: Text) -> None:
            self.arcs[label] = next

        def unifystate(self, j: "DFAState", i: "DFAState") -> None:
            arcs = {}
            for label, state in self.arcs.items():
                if state == j:
                    arcs[label] = i
                else:
                    arcs[label]

# Generated at 2022-06-11 19:48:46.292244
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    # The NFA for rule funcdef
    class State0(NFAState):
        def __init__(self):
            NFAState.__init__(self)
            self.addarc(State1(), "def")
            self.addarc(State11(), "async")

    class State1(NFAState):
        def __init__(self):
            NFAState.__init__(self)
            self.addarc(State2(), token.NAME)

    class State2(NFAState):
        def __init__(self):
            NFAState.__init__(self)
            self.addarc(State3(), "(")

    class State3(NFAState):
        def __init__(self):
            NFAState.__init__(self)
            self.addarc(State4(), ")")

# Generated at 2022-06-11 19:48:52.297670
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    import tokenize
    from io import BytesIO
    from pgen2.pgen import ParserGenerator
    pg = ParserGenerator()
    pg.generator = tokenize.tokenize(
        BytesIO(b"abc [ def | ghi ] jkl * [(mn) | (op)]").readline
    )
    pg.gettoken()
    assert pg.parse_atom() == (pg.NFAState(id=0), pg.NFAState(id=1, arcs=[(b"abc", 1)]))
    assert pg.parse_item() == (
        pg.NFAState(id=2),
        pg.NFAState(id=3, arcs=[(b"abc", 1), (None, 2)]),
    )

# Generated at 2022-06-11 19:48:59.495018
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    # Test the construction of a parser generator from a grammar
    gr = Grammar()
    gr.add_rule('file_input',
                ('NEWLINE', '|',
                 ('stmt', 'endmarker')),
                ('file_input', 'stmt', 'NEWLINE'),
                ('stmt', 'endmarker'))
    gr.add_rule('stmt',
                ('simple_stmt',),
                ('compound_stmt'))

# Generated at 2022-06-11 19:49:10.637351
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    pg = ParserGenerator()
    a = NFAState()
    b = NFAState()
    a.addarc(b, "a")
    a.addarc(b, "b")
    b.addarc(b, "a")
    dfa = pg.make_dfa(a, b)
    assert len(dfa) == 2, dfa


if __name__ == "__main__":
    options, args = getopt.getopt(sys.argv[1:], "do:")
    options = dict(options)
    destfile = options.get("-o")
    if destfile:
        destfile = open(destfile, "w")
    else:
        destfile = sys.stdout
    if "-d" in options:
        debug_output = 1

# Generated at 2022-06-11 19:49:21.468838
# Unit test for method parse_item of class ParserGenerator

# Generated at 2022-06-11 19:49:32.809723
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    # check for issue 1715716: handle comment after continuation line
    source = "a = b \\ # Continuation comment\nc"
    gen = ParserGenerator()
    g = gen.parse(source)
    token_lst = list(g)

# Generated at 2022-06-11 19:49:44.728129
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    from pgen2.pgen import ParserGenerator
    from pgen2.grammar import Grammar
    import pprint
    import io
    # for Python 2
    s = u"""# This is a comment
    # and so is this
    start: alt
    alt: item+
    item: atom item*
    atom: "a"
    """
    p = ParserGenerator(s)
    c = p.make_grammar()
    f = io.BytesIO()
    c.dump(f)

# Generated at 2022-06-11 19:49:52.470170
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    pg = ParserGenerator()
    pg.add_dfa("expr", [{"factor": 1}, {"expr'": 1}])
    pg.add_dfa("expr'", [{"+": 1, "factor": 1}, {"expr'": 1}, {None: 1}])
    pg.add_dfa("factor", [{"term": 1}, {"factor'": 1}])
    pg.add_dfa("factor'", [{"*": 1, "term": 1}, {"factor'": 1}, {None: 1}])
    pg.add_dfa("term", [{"(": 1, "expr": 1, ")": 1}, {"NUMBER": 1}])
    pg.calculate_first_sets()
    pg.calculate_follow_sets()
    pg.calculate_predict_sets()
   

# Generated at 2022-06-11 19:50:26.266317
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    pg = ParserGenerator()
    pg.type = token.NAME
    pg.value = "foo"
    pg.gettoken = lambda: None
    # Normal case
    pg.expect(token.NAME, "foo")
    # Error case
    try:
        pg.expect(token.NAME, "bar")
    except SyntaxError:
        pass
    else:
        raise AssertionError
    try:
        pg.expect(token.STRING, "bar")
    except SyntaxError:
        pass
    else:
        raise AssertionError


# Generated at 2022-06-11 19:50:29.878749
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    def TestInput(tokens: List[Tuple[int, str]]) -> Iterator[Tuple[int, str, Tuple[int, int], Tuple[int, int], str]]:
        for i, (token, value) in enumerate(tokens):
            yield token, value, (0, 0), (0, 0), str(tokens)

# Generated at 2022-06-11 19:50:42.679954
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    def check(source: List[str], expected_result: Tuple[Dict[Text, List["DFAState"]], Text]):
        grammar = "".join(source)
        dfa, startsymbol = ParserGenerator().parse(grammar, "<string>")
        assert dfa == expected_result[0]
        assert startsymbol == expected_result[1]

    # test case
    a = NFAState()
    b = NFAState()
    a.addarc(b, "a")

    c = NFAState()
    d = NFAState()
    c.addarc(d, "b")

    aa = NFAState()
    z = NFAState()
    aa.addarc(a)
    z.addarc(z)
    aa.addarc(c)
   

# Generated at 2022-06-11 19:50:48.257575
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    import io, tokenize
    #tuple(tokenize.tokenize([
    #    "a = b + c"
    #]))
    p = ParserGenerator(io.StringIO("a = b + c"))
    assert p.expect(token.NAME) == "a"
    assert p.expect(token.OP, "=") == "="
    assert p.expect(token.NAME) == "b"
    assert p.expect(token.OP, "+") == "+"
    assert p.expect(token.NAME) == "c"

    import sys
    try:
        p.expect(token.OP, "xxxx")
    except SyntaxError:
        (a, b, c, d) = sys.exc_info()[1].args
        print(a)

# Generated at 2022-06-11 19:50:55.676695
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    pg = ParserGenerator()
    # Test: ALT: ITEM+
    pg.gettoken = lambda: (1, '"a"')
    pg.value = '"a"'
    pg.parse_item = lambda: ('start', 'finish')
    pg.value = '"b"'
    x = pg.parse_alt()
    assert x == ('start', 'finish')
    pg.value = '+'
    y = pg.parse_alt()
    assert y == ('start', 'finish')  # does not match parse_item behavior


# Generated at 2022-06-11 19:51:06.685121
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    # Test to ensure that the ParserGenerator constructor
    # works as expected.
    pg = ParserGenerator()
    assert str(pg) == \
        "ParserGenerator(" \
        "ParserGenerator.PgenGrammar(" \
        "labels=[], " \
        "tokens={}, " \
        "keywords={}, " \
        "symbol2number={}, " \
        "symbol2label={}, " \
        "start=0, " \
        "states=[], " \
        "dfas={}), " \
        "converter=None" \
        ")"


# Generated at 2022-06-11 19:51:16.775199
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    parser = ParserGenerator()
    parser.dfas["test"] = [DFAState({}, False), DFAState({}, False)]
    parser.dfas["test"][0].addarc(parser.dfas["test"][1], "a")
    parser.dfas["test"][0].addarc(parser.dfas["test"][1], "b")
    parser.dfas["test"][1].addarc(parser.dfas["test"][1], "b")
    parser.dfas["test"][0].addarc(parser.dfas["test"][0], "a")
    parser.startsymbol = "test"
    parser.addfirstsets()
    assert parser.first["test"] == {"a": 1, "b": 1}


# Generated at 2022-06-11 19:51:22.188052
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    p = ParserGenerator()
    msg = "expected %s/%s, got %s/%s"
    args = token.NAME, ":", token.ENDMARKER, ""
    try:
        p.raise_error(msg, *args)
    except SyntaxError as e:
        assert e.msg == msg % args, e
    else:
        assert False, "expected exception"



# Generated at 2022-06-11 19:51:33.497353
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    p = ParserGenerator()
    p.add_token(token.NAME, "foo")
    p.add_token(token.NAME, "bar")
    p.add_token(token.NAME, "baz")
    p.add_token(token.OP, "=")
    p.add_token(token.STRING, '"quux"')
    p.add_token(token.OP, "|")
    p.add_token(token.OP, "[")
    p.add_token(token.OP, "]")
    p.add_token(token.OP, "(")
    p.add_token(token.OP, ")")
    p.add_token(token.OP, "+")
    p.add_token(token.OP, "*")

# Generated at 2022-06-11 19:51:39.918912
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    pg = ParserGenerator()
    # Test make_grammar
    def test(src: str, exp_result: str) -> None:
        res = pg.make_grammar(src)
        assert res == exp_result, (src, res, exp_result)

    test(r'ab = "a" "b"', r'ab = "\x00"')
    test(r'abc = "a" "b" "c"', r'abc = "\x00"')
    test(r'ab|abc = "a" "b"', r'ab = "\x01"')
    test(r'ab|abc = "a" "b" | "a" "b" "c"', r'ab = "\x01"\nabc = "\x01" "\x00"')

# Generated at 2022-06-11 19:52:32.748128
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    _input = 'simple_stmt: small_stmt (';' small_stmt)* [';'] NEWLINE\n'
    _output = "Dump of NFA for simple_stmt\n  State 0 \n    -> 1\n  State 1 (final)\n  State 2 \n    ';' -> 3\n    -> 4\n  State 3 \n    small_stmt -> 1\n    ; -> 4\n  State 4 \n    -> 6\n    ; -> 7\n  State 5 \n    small_stmt -> 1\n  State 6 (final)\n  State 7 \n    small_stmt -> 1\n    ; -> 4\n  State 8 \n    -> 9\n    ; -> 7\n  State 9 \n    NEWLINE -> 6\n"
    from io import StringIO

# Generated at 2022-06-11 19:52:39.637870
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    from .pgen2 import parser as pgen_parser
    pg = pgen_parser.ParserGenerator()
    pg.pgen()
    for name in sorted(pg.dfas):
        print(name)
        pg.dump_nfa(name, *pg.parse_grammar(pg.grammar[name]))


# Generated at 2022-06-11 19:52:47.645174
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    # Build input
    input = io.StringIO()
    input.write("# -*- pgen -*-\n")
    input.write("expr: xor_expr ('|' xor_expr)*\n")
    input.write("xor_expr: and_expr ('^' and_expr)*\n")
    input.write("and_expr: shift_expr ('&' shift_expr)*\n")
    input.write("shift_expr: arith_expr (('<<' | '>>') arith_expr)*\n")
    input.write("arith_expr: term (('+' | '-') term)*\n")
    input.write("term: factor (('*' | '@' | '/' | '%' | '//') factor)*\n")

# Generated at 2022-06-11 19:52:48.914103
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    assert isinstance(PgenGrammar(), PgenGrammar)



# Generated at 2022-06-11 19:52:56.028884
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    def make_label(pg, label):
        return pg.make_label(pg.convert(), label)
    a = ParserGenerator()
    a.add_nonterminal("a")
    assert make_label(a, "a") == 0
    assert a.convert().labels[0][0] == 0
    b = ParserGenerator()
    b.add_nonterminal("a")
    b.add_nonterminal("b")
    assert make_label(b, "b") == 1
    assert b.convert().labels[1][0] == 1
    def l1():
        a = ParserGenerator()
        a.add_nonterminal("NAME")
        assert make_label(a, "NAME") == 2

# Generated at 2022-06-11 19:52:59.910836
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    import pgen2.parse
    generator = pgen2.parse.ParserGenerator().generate_grammar(pgen2.parse.grammar)
    assert generator.expect(token.OP, ":") == ":"


# Generated at 2022-06-11 19:53:03.794268
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    assert ParserGenerator.parse_alt(ParserGenerator()) == (
        NFAState(),
        NFAState(),
    )
    assert ParserGenerator.parse_alt(ParserGenerator()) == (
        NFAState(),
        NFAState(),
    )

# Generated at 2022-06-11 19:53:13.304797
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    def dump(start, finish):
        todo = [start]
        for i, state in enumerate(todo):
            print("  State", i, state is finish and "(final)" or "")
            for label, next in state.arcs:
                if next in todo:
                    j = todo.index(next)
                else:
                    j = len(todo)
                    todo.append(next)
                if label is None:
                    print("    -> %d" % j)
                else:
                    print("    %s -> %d" % (label, j))

    pg = ParserGenerator()
    src = "a : b c d\n"
    pg.parse_grammar([src])
    for name in ["a"]:
        dfa = pg.dfas[name]

# Generated at 2022-06-11 19:53:21.953384
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    pgen = ParserGenerator()
    pgen.dfas = {"foo": mock_dfa()}
    pgen.first = {"foo": {"'a'": 1, "'b'": 1, "'c'": 1}}
    assert pgen.first["foo"] is not None
    c = pgen.to_converter()

# Generated at 2022-06-11 19:53:28.460825
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    p = ParserGenerator(StringIO("foo"))
    assert p.parse_atom() == (
        NFAState(arcs={("foo", NFAState())}),
        NFAState(arcs={}),
    )
    p = ParserGenerator(StringIO('"foo"'))
    assert p.parse_atom() == (
        NFAState(arcs={("foo", NFAState())}),
        NFAState(arcs={}),
    )
    p = ParserGenerator(StringIO("foo bar"))
    assert p.parse_atom() == (
        NFAState(arcs={("foo", NFAState())}),
        NFAState(arcs={}),
    )
    p = ParserGenerator(StringIO("'foo'"))