

# Generated at 2022-06-11 19:47:00.021051
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    pg = ParserGenerator()
    g = pg.make_grammar(grammar_def, "expr_context")

# Generated at 2022-06-11 19:47:09.796848
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    parser = ParserGenerator()
    parser.dfas = {
        "a": [
            DFAState({}, False),
            DFAState({}, False),
            DFAState({}, False),
            DFAState({}, False),
        ],
        "b": [
            DFAState({}, False),
            DFAState({}, False),
            DFAState({}, False),
            DFAState({}, False),
        ],
        "c": [
            DFAState({}, False),
            DFAState({}, False),
            DFAState({}, False),
            DFAState({}, False),
        ],
        "d": [
            DFAState({}, False),
            DFAState({}, False),
            DFAState({}, False),
            DFAState({}, False),
        ],
    }

# Generated at 2022-06-11 19:47:20.560302
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    class TestParserGenerator(unittest.TestCase):
        def check(self, input: str, expected: List[Tuple[str, str]]):
            # The format of expected is a list of pairs: a string giving
            # the label of the arc, and another string giving the label
            # of the destination state.
            pgen = ParserGenerator()
            pgen.setup(tokenize.generate_tokens(StringIO(input).readline))
            start, finish = pgen.parse_alt()
            result = [
                (label, str(destination))
                for label, destination in start.arcs
                if label
            ]
            self.assertEqual(result, expected)

    test = TestParserGenerator()
    test.check("a", [("a", "1")])
    test.check

# Generated at 2022-06-11 19:47:31.678868
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    import io
    import tokenize
    g = ParserGenerator()
    g.add_rhs("abc", """
        'a'
          'b'
        | 'c'
    """)
    nfa = g.dfas["abc"]
    assert len(nfa) == 3  # 3 states
    assert len(nfa[0].arcs) == 2  # 3 arcs
    out = io.StringIO()
    g.dump_nfa("hello", nfa[0], nfa[-1])

# Generated at 2022-06-11 19:47:40.933559
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    pg = ParserGenerator()
    import tokenize
    from io import BytesIO
    for t in tokenize.generate_tokens(BytesIO(b"a b c\r\n").readline):
        if t[0] not in (tokenize.COMMENT, tokenize.NL):
            pg.value = t[1]
            pg.begin = t[2]
            pg.end = t[3]
            pg.line = t[4]
            pg.type = t[0]
            if pg.type == tokenize.ENCODING:
                pg.type = tokenize.STRING
                pg.value = "''"
            print(t[0], repr(t[1]), pg.type, repr(pg.value), pg.begin, pg.end, pg.line)
test_ParserGenerator

# Generated at 2022-06-11 19:47:45.632438
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    p = ParserGenerator()
    p.simplify_dfa(["abc", "abc", "abc"]) == ["abc"]
    p.simplify_dfa(["abc", "ab", "abc"]) == ["abc", "ab"]
    p.simplify_dfa(["abc", "ab", "ac"]) == ["abc", "ab", "ac"]

# Generated at 2022-06-11 19:47:57.359940
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():

    pg = ParserGenerator()
    i = iter([
        (token.STRING, "'if'", (1, 1), (1, 3), "if\n"),
        (token.NAME, "asd", (1, 1), (1, 3), "asd\n"),
        (token.STRING, "'if'", (1, 1), (1, 3), "'if'\n"),
        (token.NAME, "else", (1, 1), (1, 3), "else\n"),
    ])
    pg.generator = i
    pg.gettoken()
    a, z = pg.parse_atom()
    assert a.arcs == [("if", z)]
    assert z.arcs == []
    pg.gettoken()
    a, z = pg.parse_atom()
    assert a.arc

# Generated at 2022-06-11 19:48:05.466285
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    import pytest
    from . import grammar

    pg = ParserGenerator(grammar)
    pg.calcfirst("compound_stmt")
    assert pg.first["compound_stmt"]["if"] == 1
    assert pg.first["compound_stmt"]["while"] == 1
    assert pg.first["compound_stmt"]["for"] == 1
    assert pg.first["compound_stmt"]["try"] == 1
    assert pg.first["compound_stmt"]["def"] == 1
    assert pg.first["compound_stmt"]["class"] == 1
    assert pg.first["compound_stmt"]["@"] == 1
    assert pg.first["compound_stmt"]["async"] == 1

# Generated at 2022-06-11 19:48:17.220668
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    import io

    p = ParserGenerator()
    p.add_file("Grammar.txt", io.StringIO('''
        NUMBER	: (DECIMAL | OCTAL | HEXADECIMAL | BINARY) [SUFFIX]
        SUFFIX	: [lL] | [uU] | [uU][lL] | [lL][uU]

        DECIMAL	:	)0( | [1-9] [0-9]*
        OCTAL	:	"0" [0-7]*
        HEXADECIMAL	:	([0-9] | [a-f] | [A-F])+ [hH]
        BINARY	:	([0-1] [bB] | [bB])
    '''))
    p.parse

# Generated at 2022-06-11 19:48:25.010535
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    import unittest
    from unittest import mock
    from importlib import resources
    import io

    class Test(unittest.TestCase):
        def setUp(self):
            self.p = pgen2.ParserGenerator(io.StringIO(""), "")

        def test_parentheses(self):
            self.assertEqual(
                self.p.parse_atom(),
                (pgen2.NFAState(), pgen2.NFAState()),
            )
        def test_name(self):
            self.assertEqual(
                self.p.parse_atom(),
                (pgen2.NFAState(), pgen2.NFAState()),
            )

# Generated at 2022-06-11 19:49:07.215402
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    #assert False, "Test not implemented"
    def test(s):
        g = ParserGenerator()
        s = tokenize.untokenize(tokenize.generate_tokens(StringIO(s).readline))
        a, z = g.parse_alt('', s)
        a.dot()
    #test("a | b | c")
    test("attr := ID [ '=' ID ]")


# Generated at 2022-06-11 19:49:18.878181
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    import io
    import token
    try:
        ParserGenerator(
            io.StringIO(""),
        ).raise_error(
            "expected foo or bar, got %s/%s", token.OP, "!"
        )
    except SyntaxError as exc:
        if exc.msg != "expected foo or bar, got OP/!":
            raise
    else:
        raise Exception("expected SyntaxError from ParserGenerator.raise_error")


# A PgenGrammar is the output of the ParserGenerator class.  It's a
# "compiled" version of the input grammar.  You can feed it to the
# Parser class, which will use it to create an instance of the
# Parser.

# Generated at 2022-06-11 19:49:24.219105
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    """Unit test for constructor of class PgenGrammar"""
    with open('test.grm', 'r') as f:
        actual = PgenGrammar(f).states[0]
    expected = set(['x y z', 'x', 'y', 'z'])
    assert actual == expected


# Generated at 2022-06-11 19:49:34.490520
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    pgen = ParserGenerator()

# Generated at 2022-06-11 19:49:39.465255
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    import pgen
    s = '''
E: T ("+" T)*
T: "(" E ")" | NUMBER
'''
    p = pgen.ParserGenerator()
    dfa = p.parse_grammar(s)
    # print p
    # print dfa


# Generated at 2022-06-11 19:49:49.644947
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    a = NFAState()
    b = NFAState()
    c = NFAState()
    d = NFAState()
    e = NFAState()
    a.addarc(b, "a")
    a.addarc(b, "b")
    b.addarc(c, "c")
    b.addarc(d, "d")
    b.addarc(d, "e")
    d.addarc(e, "e")
    e.addarc(b)
    assert ParserGenerator.make_dfa(a, b) == [
        DFAState({a: 1, b: 1}, b),
        DFAState({c: 1}, b),
        DFAState({d: 1, e: 1}, b),
    ]

# Generated at 2022-06-11 19:49:59.587710
# Unit test for method parse_rhs of class ParserGenerator

# Generated at 2022-06-11 19:50:05.287323
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    gen = ParserGenerator()
    gen.filename = "foo.py"
    gen.line = "a = b + c"
    gen.begin = (1, 0)
    gen.end = (1, 0)
    gen.value = "a"
    gen.type = token.NAME
    gen.gettoken = lambda: None

    with assert_raises(SyntaxError):
        gen.expect(token.NEWLINE)

    with assert_raises(SyntaxError):
        gen.expect(token.OP, '?')

    gen.value = '+'
    gen.expect(token.OP, '+')

    gen.expect(token.OP)



# Generated at 2022-06-11 19:50:10.826135
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    import pgen2._pgen, pgen2.parsers as parsers
    p = parsers.PythonParserGenerator(pgen2._pgen.pgen)
    p.addfirstsets()
    p.make_grammar()
    p.dump_dfa("import_from", p.pgen.dfas['import_from'])


# Generated at 2022-06-11 19:50:19.709202
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    pgen = ParserGenerator()
    pgen.make_label(None, "foo")
    pgen.make_label(None, "foo")
    pgen.make_label(None, "bar")
    pgen.make_label(None, "baz")

    pgen.make_label(None, '"bip"')
    pgen.make_label(None, '"bap"')
    pgen.make_label(None, '"bup"')

    pgen.make_label(None, '"while"')
    pgen.make_label(None, '"while"')
    pgen.make_label(None, '"while"')

    pgen.make_label(None, '"+"')
    pgen.make_label(None, '"+"')
   

# Generated at 2022-06-11 19:51:06.043096
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    P = ParserGenerator()
    dfa = [
        DFAState(nfaset={"A": 1}, isfinal=False, arcs={"a": "B"}),
        DFAState(nfaset={"B": 1}, isfinal=False, arcs={"b": "C"}),
        DFAState(nfaset={"C": 1}, isfinal=True, arcs={}),
        DFAState(nfaset={"C": 1, "D": 1}, isfinal=True, arcs={}),
    ]
    P.simplify_dfa(dfa)

# Generated at 2022-06-11 19:51:16.580974
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    from blib2to3.pgen2.parse import ParseError, ParseFile

    def fail() -> NoReturn:
        raise AssertionError("This call should have failed")

    try:
        PgenGrammar({}, fail)
    except TypeError:
        pass
    else:
        fail()

    try:
        ParseFile("non-existent-file", "f")
    except ParseError:
        pass
    else:
        fail()

    class MockPgenGrammar(PgenGrammar):
        def read_grammar(self, filename: str) -> None:
            # Just consume the filename, so we don't try to read it.
            pass

    pg = MockPgenGrammar("non-existent-file", "f")


# Generated at 2022-06-11 19:51:25.660541
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    # Make sure that the parser can start with any of the following:
    #   1. a symbol (NAME),
    #   2. a named token (STRING), or
    #   3. a parenthesized expression (OP).

    # 1. test NAME
    pg = ParserGenerator()
    pg.init("blah")
    gen = pg.tokenize()
    pg.nexttoken()
    assert pg.value == "blah"
    a, z = pg.parse_atom()
    assert a.arcs == [(None, z)]
    assert z.arcs == []
    assert pg.type == token.ENDMARKER

    # 2. test STRING
    pg = ParserGenerator()
    pg.init("'blah'")
    gen = pg.tokenize()
    pg.nexttoken()
   

# Generated at 2022-06-11 19:51:34.548368
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    pg = _ParserGenerator()
    next = iter([
        (token.NAME, "A", None, None, None),
        (token.OP, "|", None, None, None),
        (token.NAME, "B", None, None, None),
        (token.ENDMARKER, "", None, None, None),
    ]).__next__
    pg.generator = Generator(pg, next)
    pg.generator.send(None)
    pg.gettoken()
    pg.expect(token.NAME)
    pg.expect(token.OP, "|")
    pg.expect(token.NAME)
    pg.expect(token.ENDMARKER)

# Generated at 2022-06-11 19:51:47.510327
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    pgen = ParserGenerator()

# Generated at 2022-06-11 19:51:53.729066
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    grammar = """\
    A : a
    B : 'b'
    C : A "c"
    D : 'd' E
    E : B
    """
    parser = ParserGenerator(grammar, "D")
    parser.calcfirst("D")
    assert parser.first["D"] == {"d": 1}

# Generated at 2022-06-11 19:52:01.614303
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    pg = ParserGenerator()
    pg.token = token
    pg.type = token.STRING
    pg.value = '"a"'
    pg.gettoken = lambda : None
    pg.raise_error = lambda *a: None
    pg.parse_alt = lambda : (None, None)
    pg.parse_atom = lambda : (None, None)
    pg.parse_rhs = lambda : (None, None)
    pg.parse_item()
    pg.type = token.OP
    pg.value = '['
    pg.parse_item()
    # Should not raise an exception

# Generated at 2022-06-11 19:52:13.705889
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    pg = ParserGenerator()
    pg.addtoken("*")
    pg.addtoken("+")
    pg.addtoken("(")
    pg.addtoken(")")
    pg.addtoken("[")
    pg.addtoken("]")
    pg.addtoken("|")
    pg.addtoken("abc")
    pg.addtoken("123")
    pg.addtoken("foo")
    pg.addtoken("bar")
    pg.addtoken("spam")
    pg.addtoken("ham")
    pg.make_grammar("s : a | b c | d e | f g | h i j | [ k | l ] m | n [ o | p [ q | r ] ] | s t | u v w\n")
    pg.build()
    pg.validate()
    pg.pickle

# Generated at 2022-06-11 19:52:15.592825
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    pgen = ParserGenerator()
    pgen.gettoken()


# Generated at 2022-06-11 19:52:27.655693
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    import pprint
    from . import pgen

    def check(expected: Sequence[Tuple[int, str]], arg: Text) -> None:
        pg = pgen.ParserGenerator()
        c = pg.make_converter()
        c.symbol2number[arg] = 0
        actual = []
        for label in expected:
            ilabel = pg.make_label(c, arg + '_' + label)
            actual.append((ilabel, label))

# Generated at 2022-06-11 19:53:28.858899
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    parser = ParserGenerator()
    parser.generator = tokenize.generate_tokens(io.StringIO("a+b"))
    parser.filename = "test"
    parser.gettoken()
    start, finish = parser.parse_alt()
    assert isinstance(start, NFAState)
    assert isinstance(finish, NFAState)
    assert len(start.arcs) == 1
    assert len(finish.arcs) == 0
    assert start.arcs[0][0] == "a"
    assert start.arcs[0][1] == finish
    assert len(finish.arcs) == 0


P = TypeVar("P", bound="ParserGenerator")


# Generated at 2022-06-11 19:53:33.423145
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    # Simplify a DFA

    a = DFAState({}, None)
    b = DFAState({}, None)
    c = DFAState({}, None)
    a.addarc(b, "a")
    a.addarc(b, "b")
    b.addarc(c, "b")

    print("Before")
    dump_dfa("", [a])

    ParserGenerator.simplify_dfa([a])

    print("After")
    dump_dfa("", [a])



# Generated at 2022-06-11 19:53:40.305005
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    with ExpectError("expected (...) or NAME or STRING, got 3/None"):
        gen = ParserGenerator("foo", (
            (tokenize.OP, "("), (tokenize.NEWLINE, "\n"),
            (tokenize.ENDMARKER, None)))
        gen.parse_atom()
    with ExpectError("expected (...) or NAME or STRING, got 2/None"):
        gen = ParserGenerator("foo", (
            (tokenize.NAME, "("), (tokenize.NEWLINE, "\n"),
            (tokenize.ENDMARKER, None)))
        gen.parse_atom()

# Generated at 2022-06-11 19:53:53.690264
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    msg = "expected %s/%s, got %s/%s"
    o = ParserGenerator()
    try:
        o.raise_error(msg, token.NAME, "foo", token.OP, "::")
    except SyntaxError as e:
        assert str(e) == "expected NAME/foo, got OP/::"
    else:
        assert False, "should have raised SyntaxError"
# TestParserGenerator.py ends here

# MyPy annotation and type checker
#
# This program is part of the Python 3.7 distribution and governed by its
# license.  Please see the LICENSE.txt file that should have been included
# as part of this package.
#
# Adapted from PEP 484 and PEP 526.  In Python, annotations are stored in the
# '__annotations__'

# Generated at 2022-06-11 19:54:05.343773
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    print("Testing ParserGenerator")
    pg = ParserGenerator()
    pg.add_nonterminal("g", "a", "|", "b")
    pg.add_nonterminal("a", "a", "b", "c")
    pg.add_nonterminal("b", "a", "b")
    pg.add_nonterminal("c", "a", "b")
    pg.add_pattern_ebnf("a", "(", ")", "[", "]", "{", "}", "|")
    pg.add_pattern_ebnf("b", "a", "b", "c", "d")
    pg.addfirstsets()
    gen = pg.make_converter().generate_to_list()
    print(gen)

import unittest


# Generated at 2022-06-11 19:54:16.815356
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    pg = ParserGenerator()

    # This is a small example
    pg.add("file_input: (NEWLINE | stmt)* ENDMARKER")
    pg.add("stmt: simple_stmt | compound_stmt")
    pg.add("simple_stmt: small_stmt (';' small_stmt)* [';'] NEWLINE")
    pg.add("small_stmt: (expr_stmt | del_stmt | pass_stmt | flow_stmt | import_stmt | global_stmt | nonlocal_stmt | assert_stmt)")
    pg.add("compound_stmt: if_stmt | while_stmt | for_stmt | try_stmt | with_stmt | funcdef | classdef | decorated | async_stmt")

# Generated at 2022-06-11 19:54:27.661936
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    from . import c_grammar as grammar

# Generated at 2022-06-11 19:54:37.402646
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    x = ParserGenerator()
    x.dump_dfa("foo", [[("a", 4), ("b", 5)], [("a", 4), ("b", 7)], [("a", 4), ("b", 7)], [("a", 4), ("b", 7)], [("b", 6)], [("a", 4), ("b", 7)], [("a", 4), ("b", 7)], [("a", 4), ("b", 7)], [("a", 4), ("b", 7)]])

# Generated at 2022-06-11 19:54:48.456254
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    with tempfile.NamedTemporaryFile(mode="w") as f:
        f.write("1\n2\n")
        f.flush()
        p = ParserGenerator(f.name)
        p.gettoken()
        assert p.value == "1"
        assert p.type == token.NUMBER
        p.gettoken()
        assert p.value == "\n"
        assert p.type == tokenize.NL
        p.gettoken()
        assert p.value == "2"
        assert p.type == token.NUMBER
        p.gettoken()
        assert p.value == "\n"
        assert p.type == tokenize.NL
        p.gettoken()
        assert p.value == ""
        assert p.type == token.ENDMARKER



# Generated at 2022-06-11 19:54:55.116219
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    import re
    import unittest

    from .pgen2.pgen import ParserGenerator
    from .pgen2.parse import ParseError

    class Tester(unittest.TestCase):
        def do(self, regex, s):
            p = ParserGenerator()
            p.parse(regex)
            pat = re.compile(regex)
            if pat.match(s) is None:
                m = "Pattern %r should not match %r" % (regex, s)
            elif pat.match(s).group() != s:
                m = "Pattern %r should match %r, not %r" % (
                    regex,
                    s,
                    pat.match(s).group(),
                )
            else:
                m = None