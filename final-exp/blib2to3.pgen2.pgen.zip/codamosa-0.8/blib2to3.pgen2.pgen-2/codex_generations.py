

# Generated at 2022-06-11 19:47:24.170221
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    generator = ParserGenerator()
    generator.gettoken()
    for _ in range(3):
        assert generator.type == token.ENDMARKER
        assert generator.value == ""
        generator.gettoken()

# Generated at 2022-06-11 19:47:33.850555
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    pg = ParserGenerator()
    c = pg.make_converter()
    c.labels = []
    c.keywords = {}
    c.symbol2number = {"foo": 1}
    c.tokens = {}
    c.symbol2label = {}

    label = pg.make_label(c, "foo")
    assert label == 0
    assert c.labels == [(1, None)]
    assert c.keywords == {}
    assert c.symbol2number == {"foo": 1}
    assert c.tokens == {}
    assert c.symbol2label == {"foo": 0}

    label = pg.make_label(c, "bar")
    assert label == 0
    assert c.labels == [(1, None)]
    assert c.keywords == {}
    assert c

# Generated at 2022-06-11 19:47:37.517339
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    from . import parsetok
    p = ParserGenerator(None)
    p.generator = parsetok("a = b c | d f")
    p.gettoken()
    a, z = p.parse_alt()
    assert z.succeeding == [z]

# Generated at 2022-06-11 19:47:42.277519
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():

    # Test case for method parse of class ParserGenerator
    # Test error condition: no matching ENDMARKER
    pg = ParserGenerator(
        [
            (token.NAME, "foo"),
            (token.OP, ":"),
            (token.NAME, "bar"),
            (token.NEWLINE, "\n"),
            (token.NAME, "bar"),
            (token.OP, ":"),
            (token.NAME, "foo"),
            (token.NEWLINE, "\n"),
        ]
    )
    try:
        dfas, startsymbol = pg.parse()
    except ValueError as e:
        assert str(e) == "no matching '<ENDMARKER>'"
    else:
        assert 0, "This should have been a ValueError"
    # Test proper termination with ENDMARKER

# Generated at 2022-06-11 19:47:46.581973
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    print("Testing PgenGrammar class")
    assert PgenGrammar('./grammar1.tbl')


# PgenDriver
#
# A class to drive the loading and parsing of a grammar.

# Generated at 2022-06-11 19:47:57.664522
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    def t(s: str, result: Tuple[Dict[Text, List["DFAState"]], Text]) -> None:
        # print('test_ParserGenerator_parse: s=%r' % (s,))
        pg = ParserGenerator()
        dfas, startsymbol = pg.parse(s)
        # import pprint; pprint.pprint(dfas)
        assert dfas == result[0]
        assert startsymbol == result[1]

# Generated at 2022-06-11 19:48:05.598218
# Unit test for method parse of class ParserGenerator

# Generated at 2022-06-11 19:48:17.311659
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    g = ParserGenerator()
    g.dfas['add'] = [
        DFAState({'NUMBER': 1}, False),
        DFAState({}, True)
        ]
    g.dfas['atom'] = [
        DFAState({'(': 1, 'NUMBER': 2}, False),
        DFAState({'add': 3}, False),
        DFAState({}, True),
        DFAState({'+': 4}, False),
        DFAState({'atom': 5}, False),
        DFAState({}, True)
        ]
    g.dfas['term'] = [
        DFAState({'atom': 1}, False),
        DFAState({'*': 2}, False),
        DFAState({'term': 3}, False),
        DFAState({}, True)
        ]
   

# Generated at 2022-06-11 19:48:23.952820
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    pg = ParserGenerator("filename", ["a"])
    try:
        pg.raise_error("msg: %s %s", "arg1", "arg2")
    except SyntaxError as e:
        assert e.msg == "msg: arg1 arg2"
        assert e.filename == "filename"
        line, col = e.lineno, e.offset
        assert line == 1
        assert col == 1
        line = e.text.split("\n")[line - 1]
        assert line == "a"
        assert col == len(line)
    else:
        assert False, "did not raise"


# Generated at 2022-06-11 19:48:33.799584
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    from .test_grammar import _dump_dfa
    parser = ParserGenerator()
    parser.parsestring(
        r"""
%begin_grammar
%%
BEGINFILE: file_input
file_input: (NEWLINE | stmt)* ENDMARKER
stmt: expr_stmt
expr_stmt: testlist NEWLINE
testlist: test
test: NAME
%%
%end_grammar
"""
    )
    dfa = parser.dfas['file_input']
    _dump_dfa(dfa)
    assert dfa[0].isfinal
    assert dfa[0].arcs[0] == dfa[3]
    assert dfa[1].isfinal
    assert dfa[1].arcs[6] == dfa[2]
    assert dfa[1].arc

# Generated at 2022-06-11 19:48:56.519190
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():

    try:
        pg = PgenGrammar()
    except Exception as failure:
        raise AssertionError(failure)



# Generated at 2022-06-11 19:49:07.974153
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    from . import gendfa
    import compileall
    import sys
    # XXX the hit count doesn't tell us whether Python is using the
    # XXX new or old pickle files, even after a rehash; it's just
    # XXX the number of times the code in gendfa.py was executed.
    # XXX The following assumes that Python wasn't used before
    # XXX gendfa.py was compiled.
    old_hit_count = gendfa.ParserGenerator.addfirstsets.__code__.co_firstlineno
    compileall.compile_dir(sys.path[0], force=1)
    new_hit_count = gendfa.ParserGenerator.addfirstsets.__code__.co_firstlineno
    assert new_hit_count > old_hit_count


# Generated at 2022-06-11 19:49:11.230946
# Unit test for method __eq__ of class DFAState
def test_DFAState___eq__():
    print("test_DFAState___eq__")
    assert DFAState({}, None) != DFAState({}, None)  # fails without __hash__=None

test_DFAState___eq__()

# Generated at 2022-06-11 19:49:21.731272
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():

    class FakeToken:
        def __init__(self, ttype, tstring, tobject):
            self.type = ttype
            self.string = tstring
            self.object = tobject
            self.start = (0, 0)
            self.end = (0, 0)
            self.line = ''

    def eat_token(ttype, tstring, tobject, tbegin, tend, tline):
        return FakeToken(ttype, tstring, tobject)

    def get_start_and_end(tok):
        return tok.start, tok.end

    tokens = [
        eat_token(token.NAME, 'foo', 'foo', 0, 0, ''),
        eat_token(token.ENDMARKER, '', None, 0, 0, '')
    ]


# Generated at 2022-06-11 19:49:33.010321
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    def check(input:str, expected:Dict[str, Any]) -> None:
        p = ParserGenerator()
        p.build(input)
        p.addfirstsets()
        assert expected == p.first


# Generated at 2022-06-11 19:49:44.769895
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    from test.support import import_fresh_module

    token = import_fresh_module("token", blocked=["_token"])
    tokenize = import_fresh_module("tokenize", blocked=["_tokenize"])
    ParserGenerator = import_fresh_module(
        "ParserGenerator",
        blocked=["_ParserGenerator", "token", "tokenize"],
        fresh=[token, tokenize],
    )
    import io, sys
    if sys.platform.startswith("win"):
        filename = "C:\\Temp\\g.txt"
        line = "<p>\r\n<a href=\"http://foo.bar.com\">Foobar</a>\r\n</p>"
    else:
        filename = "g.txt"

# Generated at 2022-06-11 19:49:56.287344
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    import io
    import lib2to3.pgen2.tokenize
    import lib2to3.pgen2.parse

    class MockGrammar(object):
        def __init__(self, lhs, rhs):
            self.lhs = lhs
            self.rhs = rhs

    # The following is an excerpt from file.py of Python 3.2
    # ref: http://svn.python.org/view/python/branches/py3k/Lib/lib2to3/pgen2/parse.py?revision=85632&view=markup

# Generated at 2022-06-11 19:50:04.186287
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    pg = ParserGenerator()
    pg.labels = []
    pg.symbol2number = {"A": 10, "B": 111}
    pg.symbol2label = {"A": 0}
    pg.tokens = {1: 2}
    pg.keywords = {'""': 4}
    c = pg.make_converter()

    assert c.make_label(c, "A") == 0
    assert c.make_label(c, "B") == 1
    assert c.make_label(c, "NAME") == 3
    assert c.make_label(c, "NEWLINE") == 5
    assert c.make_label(c, "''") == 7
    assert c.make_label(c, "'''") == 8

# Generated at 2022-06-11 19:50:14.951667
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    import StringIO
    import unittest

    class TestCase(unittest.TestCase):
        def check(self, text, expected):
            s = StringIO.StringIO()
            gen = ParserGenerator(tokenize.generate_tokens(StringIO.StringIO(text).readline),
                                  source_name='<string>')
            gen.dump_nfa('foo', gen.parse()[0]['NAME'][0], gen.parse()[0]['NAME'][-1])
            self.assertEqual(s.getvalue(), expected)

    suite = unittest.TestSuite()
    suite.addTest(TestCase('check'))
    runner = unittest.TextTestRunner()
    runner.run(suite)


# Generated at 2022-06-11 19:50:25.022748
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    pg = ParserGenerator()
    a1 = NFAState()
    a2 = NFAState()
    a3 = NFAState()
    a4 = NFAState()
    a5 = NFAState()
    a6 = NFAState()
    a1.addarc(a2, "x")
    a3.addarc(a4, "y")
    a5.addarc(a6, "")
    a2.addarc(a3)
    a4.addarc(a5)
    a6.addarc(a1)
    pg.dump_nfa("junk", a1, a4)


# Generated at 2022-06-11 19:51:12.573144
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    from . import pgen
    class DumpGrammar(PgenGrammar):
        def __init__(self, start):
            pgen.PgenGrammar.__init__(self, start, "S -> 'x'")
        def p_S(self, args): return args[1]
    g = DumpGrammar(["S"])
    assert str(g) == "S -> 'x'"



# Generated at 2022-06-11 19:51:20.448725
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    pg = ParserGenerator()
    t = '\n'.join(['# comment', '', 'expr: atom+'])
    pg.gettoken = pg.gettoken.__wrapped__
    pg.generator = tokenize.generate_tokens(io.StringIO(t).readline)
    next(pg.generator)
    pg.gettoken()
    assert pg.type == 59, pg.type     # token.NEWLINE
    assert pg.value == '\n', pg.value
    assert pg.begin == (1, 0), pg.begin
    assert pg.end == (1, 1), pg.end
    assert pg.line == '# comment\n', pg.line
    pg.gettoken()
    assert pg.type == 59, pg.type     # token.NEWLINE
    assert pg.value

# Generated at 2022-06-11 19:51:32.629093
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():


    import token
    import tokenize
    import io
    import sys

    dfa = [
        DFAState({NFAState(0): 1}, final=False),
        DFAState({NFAState(0): 1, NFAState(1): 1}, final=False),
        DFAState({NFAState(0): 1}, final=False),
        DFAState({NFAState(1): 1}, final=True),
        DFAState({NFAState(0): 1, NFAState(1): 1}, final=False),
        DFAState({NFAState(0): 1}, final=False),
        DFAState({NFAState(0): 1, NFAState(1): 1}, final=True),
    ]
    dfa[0].addarc(dfa[1], 0)

# Generated at 2022-06-11 19:51:46.170860
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    from grammar_parser import ParserGenerator
    from io import StringIO
    from tokenize import generate_tokens
    pg = ParserGenerator(StringIO("while True:\n  pass\n"), "pg.py")
    for _ in range(3):
        tup = next(pg.generator)
        pg.gettoken()
        assert tup == (token.NAME, "while", (1, 0), (1, 0), "while True:\n")
    for _ in range(3):
        tup = next(pg.generator)
        pg.gettoken()
        assert tup == (token.NAME, "True", (1, 6), (1, 6), "while True:\n")
    for _ in range(3):
        tup = next(pg.generator)
        pg.gettoken()


# Generated at 2022-06-11 19:51:57.299446
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    p = ParserGenerator()
    c = p.convert()
    assert c.make_first(c, "file_input") == {0: 1}
    assert c.make_first(c, "term") == {11: 1, 12: 1, 13: 1, 1: 1, 3: 1, 10: 1, 6: 1}
    assert c.make_first(
        c, "term_name"
    ) == {16: 1, 17: 1, 18: 1, 19: 1, 20: 1, 21: 1, 22: 1, 23: 1, 24: 1, 25: 1}
    assert c.make_first(c, "varargslist_name") == {16: 1, 17: 1, 18: 1, 19: 1, 20: 1}

# Generated at 2022-06-11 19:52:05.511984
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    r = r"""
    str_content: "str_content"
    str_content: %s{str_chars}%c
    """
    pgen = ParserGenerator()
    pgen.parsestr(r)
    pgen.addfirstsets()
    f = pgen.first
    assert "str_content" in f
    assert "\"str_content\"" in f["str_content"]
    assert "%s{str_chars}%c" in f["str_content"]
    assert "NOTTHERE" not in f["str_content"]
    assert "NOTTHERE" not in f

# Generated at 2022-06-11 19:52:09.172682
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    pg = ParserGenerator()
    # Call the method.
    try:
        pg.raise_error("test msg {} foo = {}", "bar", "baz")
    except SyntaxError as e:
        # Verify that the exception object raises the right message.
        assert e.msg == "test msg bar foo = baz"


# ======================================================================
# The following code consists of a main program and two test cases.



# Generated at 2022-06-11 19:52:17.785017
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    pg = ParserGenerator()
    assert pg.parse_item() == (NFAState(arcs=[(None, NFAState(arcs=[(None, NFAState())]))]), NFAState())
    assert pg.parse_item() == (NFAState(arcs=[('foo', NFAState())]), NFAState())
    assert pg.parse_item() == (NFAState(arcs=[('foo+', NFAState())]), NFAState(arcs=[('foo+', NFAState())]))
    assert pg.parse_item() == (NFAState(arcs=[('foo+*', NFAState())]), NFAState(arcs=[(None, NFAState(arcs=[('foo+*', NFAState())]))]))

# Generated at 2022-06-11 19:52:24.872926
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    import sys
    import io
    from . import tokenize

    def print_(string=''):
        print(string)

    def fullpath(path):
        path = str(path)
        if path.startswith('<'):
            path = path[1:-1].split('>')[-1]
        return os.path.join(sys.path[0], path)


# Generated at 2022-06-11 19:52:33.077247
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    import sys

    class TestParserGenerator(ParserGenerator):
        def __init__(self, start: Text, filename: Text) -> None:
            self.first = {}
            self.dfas = {}
            self.startsymbol = start
            self.filename = filename
            self.gettoken()
            self.parse_grammar()
            self.check_left_recursion()
            self.addfirstsets()

        def parse_grammar(self) -> None:
            while self.type != token.ENDMARKER:
                while self.type == token.NEWLINE:
                    self.gettoken()
                name = self.expect(token.NAME)
                self.expect(token.OP, ":")
                a, z = self.parse_rhs()
                self.expect(token.NEWLINE)

# Generated at 2022-06-11 19:54:16.293668
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    import io
    import unittest
    from unittest import mock

    test_cases = (
        ("(", token.OP, "("),
        (")", token.OP, ")"),
        ("+", token.OP, "+"),
        ("*", token.OP, "*"),
        ("[", token.OP, "["),
        ("]", token.OP, "]"),
        ("|", token.OP, "|"),
        ("foo", token.NAME, "foo"),
        ('"bar"', token.STRING, "bar"),
        ('\'"baz"', token.STRING, "baz"),
    )
    for data, type, value in test_cases:
        mock_generator = mock.MagicMock()

# Generated at 2022-06-11 19:54:26.833496
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    pg = ParserGenerator()
    g = (
        "x: 'x'\n"
        "y: 'y'\n"
        "z: x | y\n"
        "a: b\n"
        "b: 'b'\n"
        "c: a*\n"
        "d: e | f\n"
        "e: 'e'\n"
        "f: 'f'\n"
        "g: d*\n"
    )
    pg.generator = tokenize.generate_tokens(StringIO(g).readline)
    pg.gettoken()
    # print(pg.filename)
    pg.parse()
    pg.dump_nfa("z", *pg.dfas["z"])

# Generated at 2022-06-11 19:54:36.870994
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():

    def t(c, x):
        return ParserGenerator.make_label(c, x)

    c = ParserGenerator()
    c.labels = []
    c.tokens = {}
    c.keywords = {}
    c.symbol2number = {}
    c.symbol2label = {}
    assert t(c, 'NAME') == 0
    assert t(c, 'NAME') == 0
    assert t(c, 'NUMBER') == 1
    assert t(c, 'STRING') == 2
    assert t(c, '"foo"') == 3
    assert t(c, '"foo"') == 3
    assert t(c, '"abc"') == 4
    assert t(c, "abc") == 5
    assert ("abc",) in c.labels

# Generated at 2022-06-11 19:54:44.547125
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    # Check that the dump_nfa() method produces correct output
    # for a particular NFA with 2 states.
    p = ParserGenerator()
    a = NFAState()
    z = NFAState()
    z.isfinal = True
    a.addarc(z, "a")
    a.addarc(z, "b")
    a.addarc(a, "c")
    p.dump_nfa("foo", a, z)
    assert 0

# Generated at 2022-06-11 19:54:53.487406
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    r = r"""
    root: ('a' ('b' ('c' ('d' 'e')))? ('f' ('g' ('h' ('i' 'j')))?))
         | ('+' ('-' ('*' ('/' ('1' ('2' ('3' ('4' '5')))))))? ('6' ('7' ('8' ('9' '0')))?))
    """
    pg = ParserGenerator()
    pg.parsestring(r)
    pg.addfirstsets()
    root = pg.first["root"]
    assert list(root.keys()) == ['"+"', "'a'"]
    p1 = root['"+"']
    assert p1 == 1
    p2 = root["'a'"]
    assert p2 == 1

# Generated at 2022-06-11 19:55:04.122936
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    p = ParserGenerator()
    p.make_dfas("""
        START: A | B | C
        A: 'a'
        B: 'b'
        C: 'c'
        D: 'd'
    """)

    c = p.make_converter()

    assert c.make_first(c, 'A') == {
        "a": 1,
    }

    assert c.make_first(c, 'START') == {
        "a": 1,
        "b": 1,
        "c": 1,
    }


# Generated at 2022-06-11 19:55:11.656510
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    pg = ParserGenerator()
    pg.dfas = {
        "a": [DFAState({}, False), DFAState({}, True)],
        "b": [ DFAState({}, False), DFAState({}, False), DFAState({}, True)],
        "c": [DFAState({}, False), DFAState({}, True)],
    }
    pg.calcfirst("a")
    pg.calcfirst("b")
    pg.calcfirst("c")
    assert pg.first == {
        "a": {},
        "b": {},
        "c": {},
    }
    pg.dfas["a"][0].addarc("b", pg.dfas["a"][1])

# Generated at 2022-06-11 19:55:19.799944
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    class TestParserGenerator(ParserGenerator):
        def raise_error(self, msg: str, *args: Any) -> NoReturn:
            raise SyntaxError(msg, (0, 0, 0, ""))

    grammar = b"""
    foo: bar
    bar: '(' bar ')' | '[' bar ']' | NAME | STRING+
    """
    tgp = TestParserGenerator(grammar)
    tgp.dump_nfa(
        "foo", tgp.dfas["foo"][0], tgp.dfas["foo"][-1]  # type: ignore[index]
    )



# Generated at 2022-06-11 19:55:25.330065
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    p = ParserGenerator()
    p.generator = tokenize.generate_tokens(tokenize.BytesIO('"a"'.encode()).readline)
    p.gettoken()
    p.parse_atom()
    p.generator = tokenize.generate_tokens(tokenize.BytesIO('a'.encode()).readline)
    p.gettoken()
    p.parse_atom()



# Generated at 2022-06-11 19:55:32.934463
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    # This is a cpython version of a function

    class NFAState:
        def __init__(self, arcs: Optional[List[Tuple[str, "NFAState"]]] = None) -> None:
            self.arcs = arcs or []

        def addarc(self, next: "NFAState", label: Optional[str] = None) -> None:
            self.arcs.append((label, next))

    nfa0 = NFAState()
    nfa1 = NFAState()
    nfa2 = NFAState()
    nfa3 = NFAState()
    nfa4 = NFAState()
    nfa5 = NFAState()

    nfa0.addarc(nfa1, "a")
    nfa0.addarc(nfa3, None)
    nfa1.addarc