

# Generated at 2022-06-23 15:51:24.966481
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    pg = ParserGenerator()
    dfa = pg.parse(
        """
        # This grammar has two rules, start and int.  The start rule
        # matches either an int by itself, or an int followed by a
        # star and another int.  The int rule matches any string of
        # digits.  If you parse the string "42*17" with this grammar,
        # you get a parse tree where the operator node has 42 on its
        # left, 17 on its right, and '*' as its value.

        start: int ( "*" int )?
        int: /d+/
        """
    )

# Generated at 2022-06-23 15:51:35.069133
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    pg = ParserGenerator()

# Generated at 2022-06-23 15:51:42.713610
# Unit test for method addarc of class DFAState
def test_DFAState_addarc():
    nfa_a = NFAState()
    nfa_z = NFAState()
    dfa_a = DFAState({nfa_a: 1}, final=nfa_z)
    dfa_z = DFAState({nfa_z: 1}, final=nfa_z)
    dfa_a.addarc(dfa_z, "label")
    assert dfa_a.arcs == {"label": dfa_z}


# Generated at 2022-06-23 15:51:45.581825
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    pg = ParserGenerator()
    with io.StringIO() as output:
        pg.dump_dfa("abc", [])
        assert output.getvalue() == ""



# Generated at 2022-06-23 15:51:47.274420
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    pg = ParserGenerator()
    pg.make_label("symbol")
# Test of class ParserGenerator

# Generated at 2022-06-23 15:51:57.886638
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    text = """\
    %start  s
              s: a b
              a: 'a' | 'ab'
              b: 'b' | 'ba'
    """
    pg = ParserGenerator()
    pg.parse_grammar(io.StringIO(text))
    pg.addfirstsets()
    f = pg.first
    assert f["a"].keys() == {"a", "ab"}
    assert f["b"].keys() == {"b", "ba"}
    assert f["s"].keys() == {"a", "ab"}

    text = """\
    %start  s
              s: a b | a 'ab'
              a: 'a'
              b: 'b'
    """
    pg = ParserGenerator()
    pg.parse_grammar(io.StringIO(text))


# Generated at 2022-06-23 15:52:05.389965
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    g = ParserGenerator()
    g.gettoken = fake_gettoken
    g.type = token.NAME
    g.value = "foo"
    g.filename = "test"
    g.begin = (1, 1)
    g.end = (1, 4)
    g.line = "foo"
    a, b = g.parse_alt()
    assert a.arcs[0][1] is b
    assert b.arcs == []
test_ParserGenerator_parse_alt()



# Generated at 2022-06-23 15:52:18.317453
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    # Test case adapted from Lib/test/test_parser.py
    simple_grammar = """
        start: NAME NAME
        """
    g = ParserGenerator()
    g.parse(simple_grammar)
    g.addfirstsets()
    c = g.make_grammar()
    assert c.start == 2
    assert c.states[2][0] == [["NAME", 3], [0, 2]]
    assert c.states[2][1] == [["NAME", 4]]
    assert c.states[2][2] == []
    assert c.states[2][3] == []
    assert c.states[2][4] == []

# Generated at 2022-06-23 15:52:23.650028
# Unit test for method __eq__ of class DFAState
def test_DFAState___eq__():
    d1 = DFAState({}, None)
    d2 = DFAState({}, None)
    assert d1 == d2
    d3 = DFAState({}, None)
    d3.addarc(d3, "a")
    assert d1 != d3
    d4 = DFAState({}, None)
    d4.addarc(d4, "b")
    assert d1 != d4
    d5 = DFAState({}, None)
    d5.addarc(d5, "a")
    assert d3 == d5


# Generated at 2022-06-23 15:52:35.416885
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    pg = ParserGenerator()
    pg.test_grammar = """\
        start: items
        items: items item | item
        item: NAME | STRING
    """
    pg.make_parsers()
    start = pg.dfas["start"][0]
    assert (
        [
            (label, pg.dfas["items"].index(next))
            for (label, next) in start.arcs
        ]
        == [(None, 0)]
    )
    items = pg.dfas["items"]
    assert (
        [
            (label, items.index(next))
            for (label, next) in items[0].arcs
        ]
        == [(None, 1)]
    )

# Generated at 2022-06-23 15:52:46.070342
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    class DummyConverter:
        labels: List[Tuple[int, Optional[Any]]] = []
        symbol2number: Dict[Text, int] = {}
        symbol2label: Dict[Text, int] = {}
        tokens: Dict[int, int] = {}
        keywords: Dict[Text, int] = {}

    class DummyParserGenerator:
        converter = DummyConverter() # type: ignore

    dummy = DummyParserGenerator()
    dummy.make_label(dummy.converter, "NAME")
    assert dummy.converter.tokens[token.NAME] == 0
    dummy.make_label(dummy.converter, "NUMBER")
    assert dummy.converter.tokens[token.NUMBER] == 1

# Generated at 2022-06-23 15:52:56.031001
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    generator = ParserGenerator("")
    generator.dfas["foo"] = [DFAState({}, False)]
    generator.dfas["bar"] = [DFAState({}, False)]
    generator.dfas["baz"] = [DFAState({}, False)]
    generator.dfas["quux"] = [DFAState({}, False)]
    generator.dfas["foo"][0].addarc(generator.dfas["foo"][0], "a")
    generator.dfas["foo"][0].addarc(generator.dfas["foo"][0], "b")
    generator.dfas["foo"][0].addarc(generator.dfas["bar"][0], "c")

# Generated at 2022-06-23 15:53:07.305651
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    p = ParserGenerator()
    p.generator = tokenize.generate_tokens(io.StringIO("").readline)
    p.next()
    assert p.parse_item() == (
        p.NFAState(arcs=[(None, p.NFAState(arcs=[(None, p.NFAState())]))]),
        p.NFAState(),
    )
    p.next()
    assert p.parse_item() == (
        p.NFAState(arcs=[(None, p.NFAState(arcs=[(None, p.NFAState())]))]),
        p.NFAState(),
    )
    p.next()

# Generated at 2022-06-23 15:53:12.173228
# Unit test for method addarc of class DFAState
def test_DFAState_addarc():
    a = DFAState({}, None)
    b = DFAState({}, None)
    a.addarc(a, "a")
    a.addarc(a, "b")
    print("a.arcs = ", a.arcs)
    print("a.arcs['a'] = ", a.arcs["a"])
    a.addarc(b, "a")
    print("a.arcs = ", a.arcs)
    print("a.arcs['a'] = ", a.arcs["a"])

# Generated at 2022-06-23 15:53:22.637771
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    # Build termgrammar
    termgrammar = ParserGenerator("termgrammar")

# Generated at 2022-06-23 15:53:30.591433
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():

    # Try calling with no arguments
    with pytest.raises(TypeError):
        PgenGrammar()

    # Try calling with a single bad argument
    with pytest.raises(TypeError):
        PgenGrammar(None)

    # Try calling with a single good argument
    with pytest.raises(TypeError):
        grammar = PgenGrammar(Grammar())


# Generated at 2022-06-23 15:53:41.697478
# Unit test for constructor of class DFAState
def test_DFAState():
    a, b, c, d, e, f, g, h = [NFAState() for _ in range(8)]
    s1 = DFAState({a: 1, b: 1, c: 1}, c)
    s2 = DFAState({a: 1, d: 1, e: 1}, e)
    s3 = DFAState({a: 1, b: 1, c: 1}, c)
    s4 = DFAState({a: 1, d: 1, e: 1}, e)
    s1.addarc(s2, "x")
    s1.addarc(s2, "y")
    s2.addarc(s1, "y")
    s2.addarc(s3, "z")
    s3.addarc(s4, "z")

# Generated at 2022-06-23 15:53:54.254317
# Unit test for method parse_item of class ParserGenerator

# Generated at 2022-06-23 15:53:58.947494
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    pg = ParserGenerator()
    pg.file = StringIO("1")
    pg.generator = tokenize.generate_tokens(pg.file.readline)
    pg.gettoken()
    pg.parse_item()

# Generated at 2022-06-23 15:54:03.748051
# Unit test for method addarc of class DFAState
def test_DFAState_addarc():
    d = DFAState({}, NFAState())
    e = DFAState({}, NFAState())
    f = DFAState({}, NFAState())
    d.addarc(e, 'label')
    d.addarc(f, 'other')
    assert d.arcs == {'label': e, 'other': f}


# Generated at 2022-06-23 15:54:07.351302
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():

    class my_ParserGenerator(ParserGenerator):

        def gettoken(self) -> None:
            pass

    t = my_ParserGenerator()

    t.filename
    t.type
    t.value
    t.begin
    t.end
    t.line


# Generated at 2022-06-23 15:54:11.876046
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    import sys

    from pgen2.grammar import Grammar

    # Test dump_dfa
    print("Dump sample grammar:")
    gr = Grammar(sys.modules[__name__])
    pg = ParserGenerator(gr)
    pg.dump_dfa("stmt", pg.dfas.get("stmt"))

# Generated at 2022-06-23 15:54:13.512068
# Unit test for constructor of class NFAState
def test_NFAState():
    nfa_state = NFAState()
    assert nfa_state.arcs == []


# Generated at 2022-06-23 15:54:20.593027
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    pg = ParserGenerator()
    pg.dfas = {
        "a": [DFAState({"a1": 1}, False)],
        "b": [DFAState({"b1": 1}, False)],
        "c": [DFAState({"c1": 1}, False)],
        "d": [DFAState({"d1": 1}, False)],
        "e": [DFAState({}, True)],
        "f": [DFAState({}, True)],
    }
    pg.startsymbol = "s"
    pg.first = {"c": {"c1": 1}}
    pg.addfirstsets()

# Generated at 2022-06-23 15:54:23.538478
# Unit test for constructor of class NFAState
def test_NFAState():
    state = NFAState()
    assert state.arcs == []
    state.addarc(state, "test")
    assert state.arcs == [("test", state)]


# Generated at 2022-06-23 15:54:27.719865
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    source = """
expr: x | '(' expr ')'
x: 'x'
"""
    print("[test_ParserGenerator_dump_nfa]")
    pg = ParserGenerator()  # noqa: F841
    pg.build(source)



# Generated at 2022-06-23 15:54:28.640068
# Unit test for method __eq__ of class DFAState
def test_DFAState___eq__(): assert None in (None, None, [None]) and [None] in [[None], [None], [None]]


# Generated at 2022-06-23 15:54:34.447668
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():
    a = DFAState({}, NFAState())
    b = DFAState({}, NFAState())
    c = DFAState({}, NFAState())
    a.addarc(b, "x")
    a.addarc(c, "y")
    a.addarc(a, "z")
    a.unifystate(b, c)
    assert a.arcs == {"x": c, "y": c, "z": c}



# Generated at 2022-06-23 15:54:45.696287
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    import StringIO
    import tokenize
    import token
    import pytoken
    s = StringIO.StringIO(
        """\
foo: 'foo'
bar: 'bar'
"""
    )
    tk = tokenize.generate_tokens(s.readline)  # type: Any
    g = ParserGenerator(tk, "test", "test.txt")
    dfa = g.dfas["foo"]
    s = StringIO.StringIO()
    g.dump_nfa("foo", dfa[0], dfa[1], file=s)
    assert s.getvalue() == """\
Dump of NFA for foo
  State 0
    'foo' -> 1
  State 1 (final)
"""
    g = ParserGenerator(tk, "test", "test.txt")


# Generated at 2022-06-23 15:54:57.766478
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    pg = ParserGenerator()
    pg.dfas = {
        'foo': [DFAState({}, False), DFAState({}, False), DFAState({}, False)],
        'bar': [DFAState({}, False), DFAState({}, False), DFAState({}, True)],
        'baz': [DFAState({}, False), DFAState({}, False), DFAState({}, False)],
    }
    pg.dfas['foo'][1].addarc(pg.dfas['bar'][2], 'hello')
    pg.dfas['baz'][1].addarc(pg.dfas['bar'][2], 'there')
    pg.dfas['baz'][1].addarc(pg.dfas['foo'][2], 'world')

# Generated at 2022-06-23 15:55:02.668982
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    f = open(__file__, "rb")
    try:
        parser = ParserGenerator(f.readline)
        try:
            parser.raise_error("expected %%r, got %%r", "foo", "bar")
        except SyntaxError:
            pass
        else:
            assert False, "should raise SyntaxError"
    finally:
        f.close()


# Generated at 2022-06-23 15:55:06.426064
# Unit test for function generate_grammar
def test_generate_grammar():
    p = ParserGenerator("Grammar.txt")
    the_grammar = p.make_grammar()
    the_grammar.check_all()
test_generate_grammar()


# Generated at 2022-06-23 15:55:09.570240
# Unit test for method addarc of class NFAState
def test_NFAState_addarc():
    my_next = NFAState()
    my_self = NFAState()
    my_self.addarc(my_next, None)


# Generated at 2022-06-23 15:55:19.086054
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    pg = ParserGenerator(token.tok_name.copy())
    pg.dfas = {
        "file_input": [],
        "eval_input": [],
        "single_input": [],
        "stmt": [],
        "simple_stmt": [],
        "small_stmt": [],
        "expr_stmt": [],
        "testlist_star_expr": [],
        "augassign": [],
        "test": [],
    }
    pg.dfas["file_input"].append(DFAState({}, False))
    pg.dfas["file_input"][0].addarc(pg.dfas["file_input"][0], "stmt")
    pg.dfas["eval_input"].append(DFAState({}, False))
    pg

# Generated at 2022-06-23 15:55:23.851260
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    from .pygram import python_symbols as syms

    pg = ParserGenerator([(x, x) for x in syms.all_symbols], [], [])
    pg.build()  # build DFAs
    for name, dfa in pg.dfas.items():
        pg.dump_dfa(name, dfa)



# Generated at 2022-06-23 15:55:30.428820
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    # Test the method dump_nfa of class ParserGenerator.
    p = ParserGenerator()
    # Test 1: dump the grammar for the string literals
    p.add_rhs("atom", "STRING")
    start, finish = p.parse_rhs()
    p.dump_nfa("atom", start, finish)
    # Test 2: dump the grammar for the string literals or identifiers
    p.add_rhs("atom", "STRING | NAME")
    start, finish = p.parse_rhs()
    p.dump_nfa("atom", start, finish)
if __name__ == "__main__":
    test_ParserGenerator_dump_nfa()

# Generated at 2022-06-23 15:55:42.391785
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    pgen = ParserGenerator()

    def test(lines, expected):
        source = "\n".join(lines)
        print("\nparse_rhs(%r)" % source)
        a, z = pgen.parse_rhs()
        got = (a.arcs, z.arcs)
        print("expect: %r, got: %r" % (expected, got))

    test(["x"], ([("x", None)], []))
    test(["x", "|", "y"], ([("x", None), ("y", None)], []))
    test(["[", "x", "]"], ([], [("x", None)]))
    test(["[", "x", "|", "y", "]"], ([], [("x", None), ("y", None)]))

# Generated at 2022-06-23 15:55:49.589266
# Unit test for method __eq__ of class DFAState
def test_DFAState___eq__():
    a, b = DFAState({}, None), DFAState({}, None)
    assert a == b
    c, d = DFAState({}, None), DFAState({}, None)
    c.addarc(a, "a")
    c.addarc(b, "b")
    d.addarc(b, "b")
    d.addarc(a, "a")
    assert a == b
    assert c == d
    assert d == c
    c.addarc(a, "a")
    assert c != d


# Generated at 2022-06-23 15:56:00.766884
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    """Unit test for method parse_alt of class ParserGenerator

    """
    pg = ParserGenerator()
    tup = pg.parse_alt()
    assert tup == (None, None)
    # note: this test assumes that parse_atom is fully tested
    pg.value = "("
    pg.gettoken = lambda: None
    pg.parse_rhs = lambda: (None, None)
    tup = pg.parse_alt()
    assert tup == (None, None)
    pg.value = "["
    pg.parse_rhs = lambda: (None, None)
    tup = pg.parse_alt()
    assert tup == (None, None)
    pg.value = "("
    pg.parse_rhs = lambda: (None, None)
    tup = pg.parse_

# Generated at 2022-06-23 15:56:11.196674
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    pg = ParserGenerator(None, None)
    class FakeState:
        def __init__(self, nfaset: Dict[NFAState, int], isfinal: bool) -> None:
            self.nfaset = nfaset
            self.isfinal = isfinal
        def __eq__(self, other: object) -> bool:
            return self.nfaset == other.nfaset
        def unifystate(self, old: "FakeState", new: "FakeState") -> None:
            ...
    class FakeDfaState:
        def __init__(self) -> None:
            ...
        def addarc(self, next: "FakeDfaState", label: Text) -> None:
            ...

# Generated at 2022-06-23 15:56:24.851279
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    from . import pgen2

    g = ParserGenerator(None)
    c = pgen2.PgenGrammar()
    for i in range(256):
        # print i, repr(chr(i))
        # print g.make_label(c, repr(chr(i)))
        # print g.make_label(c, repr(chr(i)).replace('\\', '\\\\'))
        g.make_label(c, repr(chr(i)))
        if chr(i) not in "'\"\\":
            # print g.make_label(c, "'" + chr(i) + "'")
            # print g.make_label(c, '"' + chr(i) + '"')
            g.make_label(c, "'" + chr(i) + "'")

# Generated at 2022-06-23 15:56:33.636514
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    grammarfile = StringIO(
        '''
        from . import token, grammar

        def p_int(p):
            "int : INTNUMBER"

        def p_float(p):
            "float : FLOATNUMBER"

        def p_expr(p):
            """expr : expr '+' expr
                    | expr '*' expr
                    | '(' expr ')'
            """

        # Ignored for now

        def p_error(p):
            raise SyntaxError
        '''
    )
    generator = ParserGenerator()
    c = generator.make_grammar(grammarfile, "test_parser")
    assert len(c.states) == 8

# Generated at 2022-06-23 15:56:36.501040
# Unit test for constructor of class NFAState
def test_NFAState():
    global nfa_state
    nfa_state = NFAState()
    assert nfa_state.arcs == []



# Generated at 2022-06-23 15:56:46.958031
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    from io import StringIO

# Generated at 2022-06-23 15:56:56.330824
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():
    # Create the following structure:
    #      a        b
    #  o-------o-------o
    #   \     / \     /
    #    \   /   \   /
    #     \ /     \ /
    #      o       o
    #        c
    a = DFAState({}, None)
    b = DFAState({}, None)
    c = DFAState({}, None)
    a.addarc(c, "a")
    b.addarc(c, "b")
    c.addarc(a, "a")
    c.addarc(b, "b")
    assert a.arcs["a"] == c
    assert b.arcs["b"] == c
    assert c.arcs["a"] == a
    assert c.arcs["b"] == b
    # Unify

# Generated at 2022-06-23 15:57:02.409947
# Unit test for constructor of class DFAState
def test_DFAState():
    nfaset = {"foo": 1}
    final = NFAState()
    state = DFAState(nfaset, final)
    assert state.arcs == {}
    assert state.nfaset == nfaset
    assert state.isfinal

    other = DFAState({"foo": 1}, NFAState())
    assert state.__eq__(other)
    assert not state.__eq__(NFAState())
    other = DFAState({"bar": 1}, final)
    assert not state.__eq__(other)
    assert not state.__eq__(None)



# Generated at 2022-06-23 15:57:04.194582
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():

    from . import token

    p = token.get_pattern()
    g = PgenGrammar(p)



# Generated at 2022-06-23 15:57:16.281140
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    import unittest

    import io

    import _testcapi

    class NFAState:
        def __init__(self, label: Text = None, arcs: List[Tuple[Text, "NFAState"]] = None) -> None:
            self.label = label
            self.arcs = arcs or []
            self.number = None  # type: Optional[int]

        def addarc(self, next: "NFAState", label: Optional[Text] = None) -> None:
            if label:
                self.arcs.append((label, next))
            else:
                self.arcs.append((None, next))

        def unifystate(self, old: "NFAState", new: "NFAState") -> None:
            for i, arc in enumerate(self.arcs):
                label, next

# Generated at 2022-06-23 15:57:23.370447
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    a = ParserGenerator(["expr", "expr : '['", "expr : NAME"])
    assert a.parse_atom() == (NFAState(), NFAState())
    assert a.parse_atom() == (NFAState(), NFAState())
    assert a.parse_atom() == (NFAState(), NFAState())
    assert a.parse_atom() == (NFAState(), NFAState())
    with pytest.raises(SyntaxError):
        a.parse_atom()

# Generated at 2022-06-23 15:57:33.844772
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():

    a = DFAState({}, NFAState())
    b = DFAState({}, NFAState())
    c = DFAState({}, NFAState())
    d = DFAState({}, NFAState())
    e = DFAState({}, NFAState())

    a.addarc(b, "x")
    a.addarc(c, "y")
    b.addarc(d, "z")
    c.addarc(d, "z")
    d.addarc(e, "w")
    d.addarc(d, "x")
    assert a.arcs == {"x": b, "y": c}
    assert b.arcs == {"z": d}
    assert c.arcs == {"z": d}
    assert d.arcs == {"w": e, "x": d}


# Generated at 2022-06-23 15:57:44.378794
# Unit test for constructor of class DFAState
def test_DFAState():
    # pylint: disable=unused-variable,redefined-outer-name
    a = NFAState()
    b = NFAState()
    c = NFAState()
    d = NFAState()
    a.addarc(b)
    b.addarc(b)
    b.addarc(c)
    c.addarc(c, "hello")
    c.addarc(d, "bye")
    d.addarc(d)
    states = [DFAState({a: 1}, c), DFAState({b: 1, c: 1}, c)]
    for st in states:
        assert(st.nfaset == {a: 1} or st.nfaset == {b: 1, c: 1})
        assert(st.isfinal)

# Generated at 2022-06-23 15:57:52.259351
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    p = ParserGenerator()
    dfa = p.make_dfa(*p.parse_rhs())
    p.simplify_dfa(dfa)
    dfa = p.make_dfa(*p.parse_rhs())
    p.simplify_dfa(dfa)
    dfa = p.make_dfa(*p.parse_rhs())
    p.simplify_dfa(dfa)
    dfa = p.make_dfa(*p.parse_rhs())
    p.simplify_dfa(dfa)


_ADD_DOCSTRING = """
        if self.min and self.max:
            return self.max - self.min
"""


# Generated at 2022-06-23 15:58:01.760493
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    for s, v in (
        ("foo", [("foo", None)]),
        ("(foo)", [("foo", None)]),
        ("foo+", [("foo", "+")]),
        ("[foo]", [("foo", None)]),
        ("foo | bar", [("foo", None), ("bar", None)]),
        ("foo | (bar)", [("foo", None), ("bar", None)]),
        ("(foo | bar)", [("foo", None), ("bar", None)]),
        ('"foo"', [("foo", None)]),
    ):
        pg = ParserGenerator(list(tokenize.generate_tokens(iter([s]).__next__)))
        result = []
        while pg.value != "|":
            a, z = pg.parse_item()

# Generated at 2022-06-23 15:58:13.130750
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    import io
    import tokenize

    pg = ParserGenerator()
    pg.generator = tokenize.tokenize(io.BytesIO(b"["))
    pg.gettoken()
    pg.expect(token.OP, "[")
    assert pg.type == tokenize.ENDMARKER
    assert pg.value is None
    pg.filename = "<string>"
    pg.end = (1, 0)
    pg.line = b""
    try:
        pg.expect(token.OP, "]")
    except SyntaxError:
        assert True
    else:
        assert False, "Expected SyntaxError"



# Generated at 2022-06-23 15:58:21.536743
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():
    class Test:
        def __init__(self, val: Any) -> None:
            self.x = val
    a = Test(0)
    b = Test(1)
    x = DFAState({a: 1}, a)
    y = DFAState({b: 1}, b)
    y.unifystate(b, a)
    assert y.x == 0
    y.unifystate(a, b)
    assert y.x == 1
test_DFAState_unifystate()

# Generated at 2022-06-23 15:58:30.678488
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    states = [DFAState({0: 1}, 0)]
    states[0].addarc(states[0], "a")
    states[0].addarc(states[0], "b")
    pg = ParserGenerator()
    pg.simplify_dfa(states)
    assert len(states) == 1

    states = [DFAState({0: 1}, 0)]
    states[0].addarc(states[0], "a")
    states[0].addarc(states[0], "b")
    states.append(states[0].copy())
    pg = ParserGenerator()
    pg.simplify_dfa(states)
    assert len(states) == 1

    states = [DFAState({0: 1}, 0)]
    states[0].addarc(states[0], "a")


# Generated at 2022-06-23 15:58:40.543612
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    global dfa_dump, nfa_dump
    p = ParserGenerator()

# Generated at 2022-06-23 15:58:53.355639
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    generator = ParserGeneratorTest()
    a = generator.make_NFA("foo")
    z = generator.make_NFA("bar")
    a.addarc("x", z)
    a.addarc("y", z)
    a.addarc("z", z)
    a.addarc("x", a)
    a.addarc("y", a)
    a.addarc("z", a)
    dfa = generator.make_dfa(a, z)
    print("Dump of DFA for foo:bar:")
    for i, state in enumerate(dfa):
        print("  State", i, state.isfinal and "(final)" or "")

# Generated at 2022-06-23 15:58:56.016249
# Unit test for constructor of class NFAState
def test_NFAState():
    """Unit test for constructor of class NFAState"""
    nfa_state = NFAState()
    assert nfa_state.arcs == []
    assert nfa_state.addarc(None) is None



# Generated at 2022-06-23 15:59:06.583383
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    pgen = ParserGenerator()
    a = NFAState()
    b = NFAState()
    c = NFAState()
    a.addarc('a', b)
    a.addarc('b', c)
    # print '\n'.join([
    #     line.rstrip()
    #     for line in pgen.dump_nfa("test_nfa", a, c).split('\n')
    # ])
    print("\n".join(pgen.dump_nfa("test_nfa", a, c).split("\n")))
    # Dump of NFA for test_nfa
    #   State 0
    #     a -> 1
    #     b -> 2
    #   State 1
    #   State 2
    #   State 3



# Generated at 2022-06-23 15:59:16.662284
# Unit test for constructor of class DFAState
def test_DFAState():
    a = DFAState({NFAState(): 1}, NFAState())
    assert a.isfinal == False
    b = DFAState({NFAState(): 1}, NFAState())
    assert a != b
    assert not a.arcs
    a.addarc(b, "foo")
    assert a.arcs["foo"] is a.arcs["foo"] is b
    assert a != b
    assert a != (NFAState(),)
    b.addarc(a, "bar")
    assert a.arcs["foo"] is b and b.arcs["bar"] is a
    assert a == b
    b.addarc(a, "baz")
    assert a != b
    assert a.arcs["foo"] is b and b.arcs["bar"] is a
    assert b.arcs["baz"]

# Generated at 2022-06-23 15:59:21.389985
# Unit test for method addarc of class DFAState
def test_DFAState_addarc():
    a = DFAState({}, NFAState())
    b = DFAState({}, NFAState())
    a.addarc(b, "foo")
    b.addarc(a, "bar")


# Generated at 2022-06-23 15:59:29.752868
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    import pickle

    # pickle generated by cparser.c

# Generated at 2022-06-23 15:59:38.517647
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    # ParserGenerator.raise_error()
    # This method can be called in any state (no preconditions)
    generator = ParserGenerator()
    # This is the only method that can raise an exception
    #parse_rhs: (NEWLINE | RULE)* ENDMARKER
    #parse_rhs: ALT ('|' ALT)*
    generator = ParserGenerator()
    generator.gettoken()
    generator.type = token.OP
    generator.value = ":"
    generator.expect(token.OP,":")

# Generated at 2022-06-23 15:59:44.303847
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    import io
    import tokenize

    class membuf(io.StringIO):
        # Workaround for <python3.5 bug:
        # https://bugs.python.org/issue22417
        # Ignore EINTR in readline().
        def readline(self, size=-1) -> str:
            while True:
                try:
                    return super().readline(size)
                except IOError as e:
                    if e.errno == errno.EINTR:
                        continue
                    raise
    # Unit test for method gettoken of class ParserGenerator
    def test_ParserGenerator_gettoken():
        pg = ParserGenerator(membuf(""), "")
        # Unit test for method raise_error of class ParserGenerator
        def test_ParserGenerator_raise_error():
            pg = ParserGenerator

# Generated at 2022-06-23 15:59:53.475430
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    p = ParserGenerator()

    def f(name: Text) -> Dict[Text, int]:
        dfa = [DFAState({"a": 1, "b": 1, "c": 1}, 0)]
        dfa.append(DFAState({}, 1))
        p.dfas = {"foo": dfa}
        p.first = {"foo": {"a": 1, "b": 1}}
        c = p.make_converter()
        return c.first

    f.describe = "make_first"
    f.expect = {"a": 1, "b": 1, "c": 1, "foo": 2}
    return f



# Generated at 2022-06-23 15:59:57.676557
# Unit test for function generate_grammar
def test_generate_grammar():
    # Test with a custom grammar
    p = ParserGenerator(Path(__file__).parent / "testdata/grammar.txt")
    g = p.make_grammar()
    print(g.number2symbol)
    print(g.symbol2number)
    print(g.dfas)
    print(g.labels)
    p.addfirstsets()
    print(p.first)

    # Test with the standard grammar
    module = sys.modules[__name__]
    g = generate_grammar(find_grammar())  # type: ignore
    assert module.Grammar is g, (module.Grammar, g)
    assert module.START is g.START, (module.START, g.START)
    print(g.number2symbol)

# Generated at 2022-06-23 16:00:05.455831
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    pg = ParserGenerator()
    p = pg.parse_atom()
    p[1].addarc(p[1])
    dfa = pg.make_dfa(p[0], p[1])
    assert len(dfa) == 1
    assert dfa[0].arcs == {}
    p[0].addarc(p[1])
    dfa = pg.make_dfa(p[0], p[1])
    assert len(dfa) == 1
    assert dfa[0].arcs == {None: dfa[0]}


# Generated at 2022-06-23 16:00:17.864981
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    # Find a DFA for "ab[]*"

    class NFAState:
        __slots__ = ("arcs",)

        def __init__(self) -> None:
            self.arcs: List[Tuple[str, "NFAState"]] = []

        def addarc(self, to: "NFAState", label: Optional[str] = None) -> None:
            self.arcs.append((label, to))

    start = NFAState()
    finish = NFAState()
    start.addarc(finish, "a")
    finish2 = NFAState()
    finish.addarc(finish2, "b")
    finish.addarc(finish, "[]")
    finish2.addarc(finish, "*")


# Generated at 2022-06-23 16:00:28.553810
# Unit test for constructor of class DFAState
def test_DFAState():
    a = NFAState()
    b = NFAState()
    c = NFAState()
    d = NFAState()
    e = NFAState()
    f = NFAState()
    a.addarc(b, "A")
    a.addarc(c, "A")
    b.addarc(d, "B")
    c.addarc(d, "B")
    d.addarc(e)
    e.addarc(f)
    state = DFAState({a, b}, f)
    assert state.isfinal
    assert state.nfaset == {a, b}
    assert state.arcs == {"A": DFAState({c}, f), "B": DFAState({e}, f)}
    # Can use the 'is' operator, because we only constructed a single
    #

# Generated at 2022-06-23 16:00:38.559192
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    from pgen2.tokenize import generate_tokens
    from pgen2.grammar import ParserGenerator
    from io import StringIO
    text="""\
def: 'def'
"""
    parser = ParserGenerator()
    parser.setup(StringIO(text))
    parser.gettoken()
    parser.parse()

# Generated at 2022-06-23 16:00:45.150524
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    # Init
    pg = ParserGenerator()
    pg._line_offset = 0
    pg._line_start = 0
    pg._current_indent = 0
    pg._indents = []
    pg._type = token.NAME
    pg._value = "abc"
    # Call the method
    with pytest.raises(StopIteration):
        pg.parse_alt()


# Generated at 2022-06-23 16:00:53.483264
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    from . import pgen2
    from . import tokenize
    import sys

    def find_grammar(name: str) -> Optional[str]:
        for dir in sys.path:
            fn = os.path.join(dir, name)
            if os.path.exists(fn):
                return fn
        logger.warning("warning: can't find %s", name)
        return None

    if not find_grammar("Grammar.txt"):
        # sys.exit(1)
        pass

# Generated at 2022-06-23 16:01:05.900056
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    pg = ParserGenerator()
    pg.dfas = dfa_test_pg_dfas
    try:
        pg.first
    except AttributeError:
        pass
    else:  # pragma: no cover
        raise AssertionError

    pg.addfirstsets()


# Generated at 2022-06-23 16:01:14.781627
# Unit test for method __eq__ of class DFAState
def test_DFAState___eq__():
    a, b, c = DFAState({1: 1}, 1), DFAState({2: 2}, 2), DFAState({3: 3}, 3)
    assert a == a
    assert not a != a
    assert a != b
    assert not a == b
    assert a != c
    assert not a == c
    assert b != c
    assert not b == c
    # Test NFAState equality.
    a, b = DFAState({1: 1}, 1), DFAState({1: 1}, 1)
    assert a == b
    assert not a != b
    a.arcs["a"] = b
    assert a != b
    a.arcs["a"] = a
    assert a == b
    a, b = DFAState({1: 1}, 1), DFAState({1: 1}, 1)
   

# Generated at 2022-06-23 16:01:25.002176
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    parser = ParserGenerator("""['+'|'-']
    ['0'-'9']+
    ['.' ['0'-'9']+]?
    ["e" ['+'|'-'] ['0'-'9']+]?
    """)
    dfas, startsymbol = parser.build_grammar()
    assert startsymbol == "number"
    dfa = dfas["number"]
    assert 5 <= len(dfa) <= 8  # varies depending on how many states are merged
    assert not dfa[0].isfinal
    assert not dfa[-1].isfinal
    assert dfa[-2].isfinal
    # XXX Verify that the DFA looks right
    parser = ParserGenerator("""
    NAME [NAME|NUMBER]*
    """)