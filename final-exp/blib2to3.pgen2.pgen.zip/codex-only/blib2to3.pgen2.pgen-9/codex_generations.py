

# Generated at 2022-06-23 15:51:21.357694
# Unit test for constructor of class DFAState
def test_DFAState():
    class D(DFAState):
        def addarc(self, next, label):
            pass
        def unifystate(self, old, new):
            pass
    x = D({1: 1, 2: 1}, 2)
    y = D({1: 1, 2: 1}, 2)
    assert x == y
    assert not x != y
    assert hash(x) == hash(y)
    assert x is not y
    assert x in {y}
    assert y in {x}
    assert x in {y, y}
    assert y in {x, x}
    assert len({x, y, x}) == 1



# Generated at 2022-06-23 15:51:29.225823
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    pg = ParserGenerator()
    pg.first = {"a": {"x": 1, "y": 1}, "b": {"y": 1, "z": 1}, "c": {"x": 1}}
    g = pg.make_grammar()
    a = g.labels[g.symbol2number["a"]][0]
    assert a == g.symbol2number["a"]
    assert g.first[a] == {"x": 1, "y": 1}
    b = g.labels[g.symbol2number["b"]][0]
    assert b == g.symbol2number["b"]
    assert g.first[b] == {"y": 1, "z": 1}
    c = g.labels[g.symbol2number["c"]][0]
    assert c == g.symbol

# Generated at 2022-06-23 15:51:39.521629
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    # -> None
    # ParserGenerator.raise_error:
    pg = ParserGenerator()
    try:
        pg.raise_error("testing %r", 42)
    except SyntaxError:
        pass
    # ParserGenerator.raise_error:
    pg = ParserGenerator()
    try:
        pg.raise_error("testing %d", 42)
    except SyntaxError as e:
        assert str(e) == "testing 42"


# class NFAState:
#     __slots__ = ["arcs", "isfinal"]
#     def __init__(self, isfinal=0):
#         self.arcs = []
#         self.isfinal = isfinal
#     def addarc(self, next, label=None):
#         self.arcs.append((label, next

# Generated at 2022-06-23 15:51:44.855378
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    import io
    import tokenize
    text = '"x" "y"\n'
    type, value, begin, end, line = [None] * 5
    generator = tokenize.generate_tokens(io.StringIO(text).readline)
    pg = ParserGenerator()
    pg.filename, pg.generator = "tokenize", generator
    pg.gettoken()
    assert pg.type == token.STRING
    assert pg.value == "x"
    assert pg.begin == (1, 0)
    assert pg.end == (1, 3)
    assert pg.line == '"x" "y"\n'
    pg.gettoken()
    assert pg.type == token.STRING
    assert pg.value == "y"
    assert pg.begin == (1, 4)
   

# Generated at 2022-06-23 15:51:56.091622
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():

    def make_grammar():
        pgen = ParserGenerator()
        pgen.add_dfa("A", [DFAState({"a": DFAState([], False), "b": DFAState([], True)})])
        pgen.add_dfa("B", [DFAState({"c": DFAState([], False)})])
        pgen.addfirstsets()
        return pgen


# Generated at 2022-06-23 15:52:06.581482
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    # Test the make_dfa method of ParserGenerator.
    pg = ParserGenerator()
    start = NFAState()
    a = NFAState()
    b = NFAState()
    c = NFAState()
    d = NFAState()
    e = NFAState()
    f = NFAState()
    g = NFAState()
    h = NFAState()
    finish = NFAState()
    start.addarc(a, "a")
    a.addarc(b, "b")
    a.addarc(g, None)
    b.addarc(c, "c")
    b.addarc(e, None)
    c.addarc(d, "d")
    c.addarc(e, None)
    d.addarc(finish, None)
   

# Generated at 2022-06-23 15:52:12.962662
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    pg = ParserGenerator()
    pg.gettoken = lambda: None
    pg.type = 1
    pg.value = 'x'
    pg.begin = 2
    pg.end = 3
    pg.line = 'line'
    pg.generator = iter(())
    pg.filename = 'file'
    try:
        pg.expect(1, 'x')
        pg.expect(2, 'y')
    except SyntaxError:
        pass
    else:
        assert False, "expect(...) without arguments did not raise SyntaxError"
    try:
        pg.raise_error('%s')
    except SyntaxError:
        pass
    else:
        assert False, "raise_error(...) without arguments did not raise SyntaxError"

# Generated at 2022-06-23 15:52:14.255488
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    __bound_method = test_ParserGenerator_calcfirst


__method = test_ParserGenerator_calcfirst


# Generated at 2022-06-23 15:52:22.922506
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    pgen = ParserGenerator()
    dfa = []
    dfa.append(DFAState({NFAState(): 1}, None))
    dfa.append(DFAState({NFAState(): 1}, None, "a"))
    dfa.append(DFAState({NFAState(): 1}, None))
    dfa[0].addarc(dfa[1])
    dfa[0].addarc(dfa[2])
    dfa[1].addarc(dfa[2])
    assert len(dfa) == 3
    pgen.simplify_dfa(dfa)
    assert len(dfa) == 2


# Python grammar in grammar format


# Generated at 2022-06-23 15:52:30.646935
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    import io
    import tokenize
    s = io.StringIO(
        "a = '\\n' + b\nc = '\\n' + d\nclass E():\n    pass\n"
    )
    g = tokenize.generate_tokens(s.readline)
    pg = ParserGenerator(g)
    pg.gettoken()
    assert pg.type == token.NAME
    assert pg.value == "a"
    pg.gettoken()
    assert pg.type == token.OP
    assert pg.value == "="
    pg.gettoken()
    assert pg.type == token.STRING
    assert pg.value == "'\\n'"
    pg.gettoken()
    assert pg.type == token.OP
    assert pg.value == "+"
    pg.gettoken()
   

# Generated at 2022-06-23 15:52:42.669310
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    nfa1 = NFAState()
    nfa2 = NFAState()
    nfa3 = NFAState()
    nfa4 = NFAState()
    nfa5 = NFAState()
    nfa1.addarc(nfa2, "a")
    nfa1.addarc(nfa3, "b")
    nfa2.addarc(nfa4, "c")
    nfa2.addarc(nfa5, "d")
    nfa3.addarc(nfa4, "e")
    nfa3.addarc(nfa5, "f")
    dfa = ParserGenerator.make_dfa(nfa1, nfa4)
    assert len(dfa) == 4

# Generated at 2022-06-23 15:52:53.716915
# Unit test for method make_dfa of class ParserGenerator

# Generated at 2022-06-23 15:53:05.369739
# Unit test for method addarc of class NFAState
def test_NFAState_addarc():
    nfas = NFAState()
    nfas1 = NFAState()
    nfas.addarc(nfas1, '1')
    assert nfas.arcs == [('1', nfas1)]
    nfas.addarc(nfas1, '1')
    assert nfas.arcs == [('1', nfas1), ('1', nfas1)]


DFAState = typing.NamedTuple(
    "DFAState",
    [
        ("nfaset", Dict[NFAState, int]),
        ("isfinal", bool),
        ("arcs", Dict[Text, "DFAState"]),
    ],
)



# Generated at 2022-06-23 15:53:13.166469
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    pg = ParserGenerator("", [], BytesIO("").readline)
    pg.end = (2, 3)
    pg.line = b'def x():\n  pass'

    try:
        pg.raise_error("foo %s", "bar")
        assert False, "Unexpected success"
    except SyntaxError as e:
        assert str(e) == "foo bar"
        assert e.filename == ""
        assert e.lineno == 2
        assert e.offset == 3
        assert e.text == b'def x():\n  pass'

    try:
        pg.raise_error("foo %s %s", "bar", "spam")
        assert False, "Unexpected success"
    except SyntaxError as e:
        assert str(e) == "foo bar spam"
        assert e

# Generated at 2022-06-23 15:53:20.829567
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    pg = ParserGenerator()
    def g():
        yield (token.NAME, 'a', (0,0), (0,0), 'a')
        yield (token.NEWLINE, '\n', (0,0), (0,0), '\n')
        yield StopIteration
    pg.generator = g()
    pg.gettoken()
    assert pg.type == token.NAME
    assert pg.value == 'a'
    pg.gettoken()
    assert pg.type == token.ENDMARKER
    assert pg.value is None


# Generated at 2022-06-23 15:53:26.859472
# Unit test for function generate_grammar
def test_generate_grammar():
    # For the moment, we simply check if the generated file is the same
    # as the built-in one.  This checks that it is syntactically correct.
    from .python import Parser
    from . import token
    from . import tokenize
    import pickle
    import os
    import io
    import unittest

    def test(filename, modname):
        path = os.path.join(os.path.dirname(__file__), "Parser", filename)
        with open(path, "rb") as f:
            expected = pickle.load(f)
        with io.StringIO() as f:
            g = generate_grammar(filename)
            f.write("# Generated by generate_grammar()\n")

# Generated at 2022-06-23 15:53:32.106518
# Unit test for method addarc of class DFAState
def test_DFAState_addarc():
    s = DFAState({NFAState(): 0}, NFAState())
    t = DFAState({NFAState(): 0}, NFAState())
    s.addarc(t, 'a')
    assert s.arcs['a'] is t



# Generated at 2022-06-23 15:53:43.214509
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    pg = ParserGenerator()
    a = NFAState()
    b = NFAState()
    c = NFAState()
    d = NFAState()
    e = NFAState()
    f = NFAState()
    a.addarc(b, 'a')
    a.addarc(c, 'b')
    c.addarc(b)
    d.addarc(e, 'c')
    d.addarc(f, 'd')
    e.addarc(c)
    f.addarc(d)
    a.addarc(d)
    b.addarc(f)
    f.addarc(b)
    aa = NFAState()
    zz = NFAState()
    aa.addarc(a)
    b.addarc(zz)

# Generated at 2022-06-23 15:53:48.935328
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    parser = ParserGenerator()
    parser.filename = "foo"
    parser.end = (1, 2)
    parser.line = "line"
    try:
        parser.raise_error("msg %s %s", 3, 4)
    except SyntaxError as exc:
        assert exc.msg == "msg 3 4"
        assert exc.filename == "foo"
        assert exc.lineno == 1
        assert exc.offset == 2
        assert exc.text == "line"
    else:
        assert False, "Expected SyntaxError"


# Class DFAState

# Generated at 2022-06-23 15:53:50.555521
# Unit test for method __eq__ of class DFAState
def test_DFAState___eq__():
    a = DFAState((), None)
    b = DFAState((), None)
    assert (a == b) == (a.__eq__(b))



# Generated at 2022-06-23 15:54:00.126100
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    from .parser import ParserGenerator
    from .converter import Converter
    # Make a fake grammar module using get_grammar_lr_table()
    import _mock_grammar
    _mock_grammar.type_ignore.append("Mock_Grammar")
    _mock_grammar.opmap["Mock_Grammar"] = 0
    _mock_grammar.tokens.append("Mock_Grammar")
    _mock_grammar.sym_name["Mock_Grammar"] = None
    _mock_grammar.sym_name["Mock_Name"] = "Mock_Name"
    _mock_grammar.sym_name["Mock_String"] = "Mock_String"

# Generated at 2022-06-23 15:54:03.348884
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    p = ParserGenerator()
    p.dump_nfa("expr",
        NFAState(None, [(None, NFAState())]),
        NFAState())


# Generated at 2022-06-23 15:54:06.594545
# Unit test for method addarc of class DFAState
def test_DFAState_addarc():
    d=DFAState({},NULL)
    e=DFAState({},NULL)
    d.addarc(e,"label")
    assert d.arcs["label"]==e
test_DFAState_addarc()


# Generated at 2022-06-23 15:54:14.902987
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():
    import unittest
    from typing import TypeVar, Generic
    T = TypeVar('T')
    class Dummy(Generic[T]):
        pass
    d1 = Dummy()  # type: Dummy[DFAState]
    d2 = Dummy()  # type: Dummy[DFAState]
    s1 = DFAState({}, None)
    s2 = DFAState({}, None)
    s3 = DFAState({}, None)
    s1.addarc(s1)
    s1.addarc(s3)
    d1.arcs = {}
    d1.arcs[s1] = 1
    d1.arcs[s3] = 2
    d2.arcs = {}
    d2.arcs[s2] = 3

# Generated at 2022-06-23 15:54:27.761271
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    """Test case to check method parse_item"""
    p = ParserGenerator()
    p.gettoken = lambda: None
    p.value = '['
    assert p.parse_item() == (None, None)
    p.value = '('
    assert p.parse_item() == (None, None)
    p.type = token.NAME
    assert p.parse_item() == (None, None)
    p.type = token.STRING
    assert p.parse_item() == (None, None)
    p.expect = lambda type, value=None: None
    p.value = '+'
    assert p.parse_item() == (None, None)
    p.value = '*'
    assert p.parse_item() == (None, None)

# Generated at 2022-06-23 15:54:34.130636
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    pg = ParserGenerator()
    from io import StringIO
    pg = ParserGenerator()
    pg.generator = tokenize.generate_tokens(StringIO('<a>').readline)
    pg.gettoken()
    a, z = pg.parse_atom()
    assert pg.type == token.ENDMARKER
    check_nfa(a, z, [('a', None)])

# Generated at 2022-06-23 15:54:39.001874
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    pg = ParserGenerator()

# Generated at 2022-06-23 15:54:43.228453
# Unit test for constructor of class NFAState
def test_NFAState():
    ns = NFAState()
    ns.addarc(NFAState(), "a")
    assert len(ns.arcs) == 1
    assert ns.arcs[0][0] == "a"
    assert isinstance(ns.arcs[0][1], NFAState)


# Generated at 2022-06-23 15:54:46.430800
# Unit test for constructor of class DFAState
def test_DFAState():
    dummy = NFAState()
    d = DFAState({dummy: 1}, dummy)
    assert d.nfaset == {dummy: 1}
    assert d.isfinal is True
    assert d.arcs == {}
    assert d != dummy



# Generated at 2022-06-23 15:54:58.637225
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    import io
    import sys
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tempdir:
        filename = os.path.join(tempdir, "test_ParserGenerator.py")
        with open(filename, "w") as file:
            file.write(
                """
            def test():
                if 1:
                    x = True
                else:
                    x = True
                print(x)
        """
            )

        from tokenize import tokenize  # type: ignore

        with open(filename, "rb") as file:
            gen = tokenize(file.readline)
            parser = ParserGenerator(gen, filename)
            dfas, startsymbol = parser.parse()
            for name, dfa in sorted(dfas.items()):
                print(name)
                c = parser.make_

# Generated at 2022-06-23 15:55:10.768838
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    generator = tokenize.generate_tokens(io.BytesIO("a = 1\n".encode()).readline)
    parser = ParserGenerator(token.NAME, "a", {"a": []}, generator, "<string>")
    print(parser.type, parser.value)
    parser.expect(token.NAME, "a")
    print(parser.type, parser.value)
    parser.expect(token.OP, "=")
    print(parser.type, parser.value)
    parser.expect(token.NUMBER, "1")
    print(parser.type, parser.value)
    parser.expect(token.NEWLINE)
    print(parser.type, parser.value)
    print("done")


# Generated at 2022-06-23 15:55:12.430021
# Unit test for method addarc of class NFAState
def test_NFAState_addarc():
    nfa = NFAState()
    nfa.addarc(nfa)



# Generated at 2022-06-23 15:55:17.444519
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    for rule in grammar.grammar:
        if ":" in rule:
            # a : b c
            name, rule = rule.split(':')
            name = name.strip()
        else:
            name = '_'
        dfas = ParserGenerator(name, rule).make_parser()
        dfas.dump_dfa(name, dfas.dfas[name])



# Generated at 2022-06-23 15:55:23.779447
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    class DFAStateMock(object):
        def __init__(self, nfaset: Dict[NFAState, int]):
            self.nfaset = nfaset
        def __eq__(self, other) -> bool:
            return self.nfaset == other.nfaset
        def unifystate(self, old: "NFAState", new: "NFAState") -> None:
            for arc in (self.nfaset, self.arcs, self.final):
                if old in arc:
                    if new in arc:
                        del arc[old]
                    else:
                        arc[new] = arc[old]
                        del arc[old]
    parser_generator = ParserGenerator()

# Generated at 2022-06-23 15:55:34.688129
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    
    from pgen2 import driver, parse, token
    from pgen2.parse import ParseError
    from pgen2.pgen import ParserGenerator
    
    class MockParserGenerator(ParserGenerator):
        def __init__(self):
            
            self.symbol2number = {
                'keyword': 3, 
                'string': 0, 
                }
            self.labels = [
                (0, '_STRING'), 
                ]
            self.symbol2label = {
                'string': 0, 
                }
            self.tokens = {
                55: 1, 
                }
            self.keywords = {
                'keyword': 2, 
                }
            
    generator = MockParserParserGenerator()
    label = 'name'

# Generated at 2022-06-23 15:55:36.975694
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    p = ParserGenerator("", "")
    p.expect(1) # This would raise an AssertionError

# Generated at 2022-06-23 15:55:46.142032
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    """
    This is an example of the parser generator input grammar.
    """

    def get_example_grammar() -> Text:
        """Returns the string:
        MSTART: (NEWLINE | RULE)* ENDMARKER
        RULE: NAME ':' RHS NEWLINE
        RHS: ALT ('|' ALT)*
        ALT: ITEM+
        ITEM: '[' RHS ']' | ATOM ['+' | '*']
        ATOM: '(' RHS ')' | NAME | STRING
        """

# Generated at 2022-06-23 15:55:55.403390
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    source = """
    fruit:  apple | orange | pear
    """
    g = ParserGenerator(source)
    dfa = g.dfas["fruit"]
    states = []
    for state in dfa:
        arcs = {}
        for label, next in state.arcs.items():
            arcs[label] = dfa.index(next)
        states.append(arcs)
    dfa = states
    assert dfa == [[{"apple": 1}, {"orange": 2}, {"pear": 3}], [{}], [{}], [{}]]


# Generated at 2022-06-23 15:55:59.876293
# Unit test for constructor of class NFAState
def test_NFAState():
    a = NFAState()
    b = NFAState()
    c = NFAState()
    a.arcs = [("label1", b), ("label2", c)]
    assert a.arcs == [("label1", b), ("label2", c)]



# Generated at 2022-06-23 15:56:10.217721
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    generator = ParserGenerator()
    a = NFAState()
    z = NFAState()
    a.addarc(z, "a")
    a.addarc(a, None)
    start = a
    finish = z
    dfa = generator.make_dfa(start, finish)
    assert dfa[0].nfaset == {a: 1, z: 1}
    assert dfa[1].nfaset == {z: 1}
    assert dfa[0].arcs == {("a", dfa[1])}

    b = NFAState()
    b.addarc(a, None)
    b.addarc(b, None)
    b.addarc(z, "b")
    start = b
    finish = z

# Generated at 2022-06-23 15:56:18.072530
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    def make_grammar(source: str, start: str) -> PgenGrammar:
        gen = ParserGenerator()
        return gen.make_grammar(source, start)

    # Test coverage of the basic case
    grammar = make_grammar("a: 'a'\n", "a")
    assert grammar.labels[0] == (grammar.tokens["a"], None)

    # Test coverage of an unrecognized token
    grammar = make_grammar("a: 'b'\n", "a")
    assert grammar.labels[0] == (token.NAME, "b")

    # Test coverage of a keyword
    grammar = make_grammar("a: 'and'\n", "a")
    assert grammar.labels[0] == (token.NAME, "and")

    # Test coverage of

# Generated at 2022-06-23 15:56:28.031362
# Unit test for method addarc of class DFAState
def test_DFAState_addarc():
    a, b, c, d, e, f, g, h, i, j, k, l, m, n, o, p, q, r, s, t, u, v, w, x, y, z = [
        NFAState() for _ in range(26)
    ]
    dfa = [
        DFAState({a: 1, b: 1, c: 1}, c),
        DFAState({d: 1, e: 1, f: 1}, f),
        DFAState({g: 1, h: 1, i: 1}, i),
    ]
    df = 0
    dfa[df].addarc(dfa[df + 1], "X")
    df += 1
    dfa[df].addarc(dfa[df + 1], "Y")
    df += 1

# Generated at 2022-06-23 15:56:35.677455
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    pg = ParserGenerator()
    tests = [
        ("a",
         [],
         ""),
        ("a b",
         [],
         ""),
        (r"a\ b",
         [],
         ""),
        ("a 'b'",
         [],
         ""),
        ("a 'b' | c 'd'",
         [],
         ""),
        ("a (b | c)",
         [(0, 1, 'b'), [1, 2]]),
        ("a (b | c) | d (e | f)",
         [(0, 1, 'b'), [1, 2], [2, 3], (3, 4, 'd'), [4, 5]]),
    ]

# Generated at 2022-06-23 15:56:39.700317
# Unit test for constructor of class NFAState
def test_NFAState():
    a = NFAState()
    b = NFAState()
    c = NFAState()
    a.addarc(b, "b")
    a.addarc(c)
    assert a.arcs == [("b", b), (None, c)]



# Generated at 2022-06-23 15:56:51.479433
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    pg = ParserGenerator()

# Generated at 2022-06-23 15:56:56.069173
# Unit test for function generate_grammar
def test_generate_grammar():
    parser = ParserGenerator('Grammar.txt')
    (dfas, startsymbol) = parser.parse()
    parser.make_grammar()

# Main program
if __name__ == "__main__":
    print(generate_grammar())

# Generated at 2022-06-23 15:57:07.224428
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    import io
    import unittest
    from .testing import make_grammar

    # unit test for calcfirst method
    # created from test_pgen.py's test_pgen_calcfirst
    # with re-written grammar and removed duplicates

    # NOTE: Names in the re-written grammar below must be updated when
    # the grammar changes in Lib/test/test_pgen.py


# Generated at 2022-06-23 15:57:08.507168
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    s = PgenGrammar()
    assert s



# Generated at 2022-06-23 15:57:10.643006
# Unit test for constructor of class DFAState
def test_DFAState():
    x = NFAState()
    y = NFAState()
    z = NFAState()
    d = DFAState({x: 1, y: 1}, z)
    assert d.nfaset == {x: 1, y: 1}
    assert d.isfinal
    assert d.arcs == {}


# Generated at 2022-06-23 15:57:18.378192
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    start = NFAState()
    a, b, c, d, z = [NFAState() for i in range(5)]
    start.addarc(a, "a")
    start.addarc(b, "b")
    b.addarc(c, "c")
    c.addarc(c, None)
    a.addarc(d, "d")
    d.addarc(z)
    d.addarc(z, "e")
    pg = ParserGenerator()
    dfa = pg.make_dfa(start, z)
    assert len(dfa) == 3
    for state in dfa:
        assert state.nfaset
    assert dfa[0].arcs == {"a": [dfa[1]], "b": [dfa[2]]}
    assert dfa

# Generated at 2022-06-23 15:57:29.273842
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    # This really tests the make_first procedure, but using a
    # ParserGenerator instance is convenient because it ensures that
    # we test make_first on all the symbols.
    from . import config
    from . import token

    build_grammar = config.BuildGrammar()
    g = ParserGenerator(build_grammar, "Grammar")
    c = g.converter()

    # When the actual _PyParser.c is built, firstsets.py is run to
    # print the result of calling make_first on each symbol.  (See
    # also test_buildgrammar.py).  Let's do the same thing here:
    v: Dict[Text, Set[int]] = {}
    for symbol, (states, first) in sorted(c.dfas.items()):
        v[symbol]

# Generated at 2022-06-23 15:57:39.423888
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    from Token import Token
    from io import StringIO
    from _tokenize import generate_tokens
    from pprint import pprint
    from typing import Generator
    from sys import version_info
    from token import ENDMARKER, NAME, OP, STRING
    from tokenize import COMMENT, NL
    import unittest
    import warnings

    def generator(
        reader: StringIO
    ) -> Generator[Tuple[int, str, Tuple[int, int], Tuple[int, int], str], None, None]:
        reader = StringIO(textwrap.dedent(reader.getvalue()))
        for tup in generate_tokens(reader.readline):
            if tup[0] == NL:
                continue

# Generated at 2022-06-23 15:57:47.697771
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():
    x = DFAState({0: None}, 0)
    y = DFAState({0: None}, 0)
    x.addarc(x, "x")
    y.addarc(y, "y")
    assert x != y
    assert "x" in x.arcs and "y" in y.arcs
    assert x.arcs["x"] is x
    assert y.arcs["y"] is y
    unittest.assertRaises(AssertionError, lambda: x.unifystate(x, y))
    x.unifystate(y, x)
    assert x == y
    assert "x" in x.arcs and "x" in y.arcs
    assert "y" not in x.arcs and "y" not in y.arcs

# Generated at 2022-06-23 15:57:54.098323
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    from types import ModuleType
    from . import ast
    mod = ModuleType('ast')
    mod.__dict__.update(ast.__dict__)
    ParserGenerator().make_grammar(mod, 'test_grammar.py')

if __name__ == '__main__':
    test_ParserGenerator_make_grammar()

# Generated at 2022-06-23 15:57:57.726343
# Unit test for constructor of class NFAState
def test_NFAState():
    a = NFAState()
    b = NFAState()
    a.addarc(b)
    c = NFAState()
    c.addarc(a)



# Generated at 2022-06-23 15:58:02.527024
# Unit test for method addarc of class NFAState
def test_NFAState_addarc():
    nex = NFAState()
    nfa = NFAState()
    nfa.addarc(nex)
    assert nfa.arcs == [(None, nex)]
try:
    test_NFAState_addarc()
except:
    pass



# Generated at 2022-06-23 15:58:15.099271
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():
    s1 = DFAState({}, None)
    s2 = DFAState({}, None)
    s3 = DFAState({}, None)
    s4 = DFAState({}, None)
    s1.addarc(s2, "a")
    s1.addarc(s3, "b")
    s2.addarc(s4, "c")
    s2.addarc(s4, "d")
    s3.addarc(s4, "e")
    s4.addarc(s2, "f")
    assert s1.arcs["a"] is s2
    assert s1.arcs["b"] is s3
    assert s2.arcs["c"] is s4
    assert s2.arcs["d"] is s4

# Generated at 2022-06-23 15:58:19.874013
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    g = ParserGenerator()
    g.expr("expr", "expr + term | term")
    g.expr("term", "term * factor | factor")
    g.expr("factor", "NAME | NUMBER")
    g.dfas, g.startsymbol = g.parse()


# Generated at 2022-06-23 15:58:29.274130
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    pg = ParserGenerator([])
    pg.dfas = {
        'foo': [DFAState({}, False)],
        'bar': [DFAState({}, False)],
        'baz': [DFAState({}, False)],
    }
    pg.first = {
        'foo': None,
        'bar': {},
        'baz': {'a': 1, 'b': 1},
    }
    pg.addfirstsets()
    assert pg.first == {
        'foo': {'a': 1, 'b': 1},
        'bar': {'a': 1, 'b': 1},
        'baz': {'a': 1, 'b': 1},
    }

# Generated at 2022-06-23 15:58:39.902735
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    pg = ParserGenerator()
    pg.generator = generate_tokens(StringIO('foo : bar "baz"').readline)
    start, finish = pg.parse_rhs()
    assert start.arcs == [(None, start.arcs[None, 1][0])]
    assert start.arcs[None, 1][0].arcs == [
        (None, start.arcs[None, 1][0].arcs[None, 1][0]),
        ('baz', start.arcs[None, 1][0].arcs[None, 1][1]),
    ]
    assert start.arcs[None, 1][0].arcs[None, 1][1].arcs == [('baz', finish)]

# Generated at 2022-06-23 15:58:43.586220
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    pg = ParserGenerator()
    text = '""|"id" (","|"=") "id"|"id" ("+"|"-"|"*"|"/") "id"'
    pg.setup_parser(text)
    a, z = pg.parse_rhs()
    pg.dump_nfa(text, a, z)


# Generated at 2022-06-23 15:58:49.187608
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    # ParserGenerator
    pg = ParserGenerator()

    # Load grammar
    assert isinstance(get_source(grammar), str)
    pg.load_grammar(get_source(grammar))

    # Create grammar
    c = pg.make_grammar(grammar.symbol2number)
    assert c.start == grammar.symbol2number["file_input"]
    assert isinstance(c.start, int)
    assert isinstance(c.states, list)
    assert isinstance(c.labels, list)

    # Dump created grammar.
    print("\n\n" + "=" * 50)
    for x in c.labels:
        print("%d: %s" % x)

# Generated at 2022-06-23 15:58:55.907359
# Unit test for method addarc of class NFAState
def test_NFAState_addarc():
    from pgen2.pgen import NFAState, dump_nfa

    start = NFAState()
    for a in range(4):
        b = NFAState()
        start.addarc(b, chr(ord("a") + a))
        for c in range(4):
            d = NFAState()
            b.addarc(d, chr(ord("0") + c))
            d.addarc(start)
    print("With addarc() ...")
    dump_nfa("start", start, start)



# Generated at 2022-06-23 15:58:57.916662
# Unit test for constructor of class NFAState
def test_NFAState():
    a = NFAState()
    b = NFAState()
    a.addarc(b, "abc")
    assert a.arcs[0][0] == "abc"
    assert a.arcs[0][1] is b



# Generated at 2022-06-23 15:59:08.318236
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    import io
    import unittest

    from test.support import captured_stdout

    class FixedParserGenerator(ParserGenerator):
        """Version of ParserGenerator that uses fixed nfa indices"""

        def dump_nfa(self, name: str, start: "NFAState", finish: "NFAState") -> None:
            print("Dump of NFA for", name)
            todo = [start]
            i = 0
            while i < len(todo):
                state = todo[i]
                print("  State", i, state is finish and "(final)" or "")
                for label, next in state.arcs:
                    if next in todo:
                        j = todo.index(next)
                    else:
                        j = len(todo)
                        todo.append(next)

# Generated at 2022-06-23 15:59:10.832297
# Unit test for method addarc of class NFAState
def test_NFAState_addarc():
    a = NFAState()
    b = NFAState()
    a.addarc(b, "c")
    assert len(a.arcs) == 1
    assert a.arcs[0][0] == "c"
    assert a.arcs[0][1] is b

# --- Test cases ---------------------------------------------------------------


# Generated at 2022-06-23 15:59:18.294906
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    p = ParserGenerator()
    a = p.NFAState()
    z = p.NFAState()
    a.addarc(z, 'a')
    dfa = p.make_dfa(a, z)
    assert len(dfa) == 1
    assert dfa[0].nfaset == {a: 1, z: 1}
    assert dfa[0].arcs == {'a': dfa[0]}
    # print "len(dfa) ==", len(dfa)

# Generated at 2022-06-23 15:59:26.535060
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    dfas = [
        DFAState({}, False),
        DFAState({}, False),
        DFAState({}, False),
        DFAState({}, False),
        DFAState({}, False),
    ]
    dfas[0].addarc(dfas[1], "a")
    dfas[0].addarc(dfas[2], "b")
    dfas[1].addarc(dfas[3], "b")
    dfas[2].addarc(dfas[3], "a")
    dfas[3].addarc(dfas[4], "c")
    ParserGenerator.simplify_dfa(dfas)
    assert len(dfas) == 4



# Generated at 2022-06-23 15:59:30.524719
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    """
    Suppress the name warnings from mypy, as there is no way to check
    for a name without a string.
    """
    assert isinstance(PgenGrammar.from_file(Path), PgenGrammar)


# Generated at 2022-06-23 15:59:38.292796
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    from . import ast  # Module needed for Pickle
    from .pytoken import (
        ParserGenerator,
        PgenGrammar,
        NFAState,
        DFAState,
        Tuple2,
        Dict2,
        StrList1,
        IntList2,
    )

    pgen = ParserGenerator()
    pgen.make_parsetab()
    name = "expr"
    dfa = pgen.dfas[name]

# Generated at 2022-06-23 15:59:39.496745
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    pg = ParserGenerator([], [])
    pg.gettoken()



# Generated at 2022-06-23 15:59:51.735348
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    pg = ParserGenerator()
    pg.filename = "<string>"
    for input, result in [
        ('"x"', (0,0,0,0,"x",
                 (token.STRING, '"x"'),
                 ('"x"', ('x',)),
                 'x')),
        ('NAME', (0,0,0,0,"NAME",
                  (token.NAME, 'NAME'),
                  ('NAME', ('NAME',)),
                  'NAME')),
        ('(a)', (0,0,0,0,"a",
                 (token.NAME, 'a'),
                 ('a', ('a',)),
                 'a')),
    ]:
        pg.generator = tokenize.generate_tokens(io.StringIO(input).readline)
        pg.gettoken()

# Generated at 2022-06-23 16:00:04.785805
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    s: ParserGenerator = ParserGenerator("", "<string>")
    s.first = {'single': {'single': 1}, 'pair': {'pair': 1}, 'empty': {}, 'error': {'error': 1}}
    s.dfas = {'single': [DFAState({symbol("start"): 1}, {symbol("single"): 1})], 'pair': [DFAState({symbol("start"): 1}, {symbol("pair"): 1})], 'empty': [DFAState({symbol("start"): 1}, {symbol("empty"): 1})], 'error': [DFAState({symbol("start"): 1}, {symbol("error"): 1})]}
    s.calcfirst("single")
    # assert 0, repr(s.first)
test_ParserGenerator_

# Generated at 2022-06-23 16:00:08.470935
# Unit test for function generate_grammar
def test_generate_grammar():
    res = generate_grammar(filename="Grammar.txt")
    assert type(res) is PgenGrammar


# Generated at 2022-06-23 16:00:14.638779
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():
    dfa = [DFAState({}, None)]
    old = dfa[0]
    new = DFAState({}, None)
    dfa.append(new)
    dfa[0].addarc(old, "ab")
    dfa[0].unifystate(old, new)
    assert dfa[0].arcs["ab"] is new


# Generated at 2022-06-23 16:00:25.111931
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    import unittest

    class TestParserGenerator_raise_error(unittest.TestCase):
        def test_0(self):
            try:
                pg = ParserGenerator(tokenize.generate_tokens(""), "<string>")
                pg.raise_error("expected %s/%s, got %s/%s", token.NAME, "hello", token.STRING, "goodbye")
                self.fail("unreachable")
            except SyntaxError as e:
                assert e.args[0] == "expected NAME/hello, got STRING/goodbye"
                assert e.args[1] == ("<string>", 1, 0, "")



# Generated at 2022-06-23 16:00:32.243196
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    import sys
    import builtins
    builtins.__dict__.clear()
    try:
        pgen = ParserGenerator()
        pgen.generator = iter([
            (token.NAME, "test", (0, 0), (0, 0), "\n"),
        ])
        pgen.filename = "test"
        pgen.gettoken()
        pgen.raise_error("test %s", "message")
    except SyntaxError as e:
        assert e.filename == "test"
        assert e.lineno == 1
        assert e.offset == 0
        assert e.text == "\n"
        assert str(e) == "test message"
    else:
        assert False, "expected a SyntaxError"



# Generated at 2022-06-23 16:00:36.411345
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    pg = ParserGenerator()
    c = pg.convert(pg.pgen_grammar)
    assert c.make_label(c, '"foo"') == 10
    assert c.make_label(c, '"True"') == 6
# Unit tests for method convert of class ParserGenerator.

# Generated at 2022-06-23 16:00:45.536198
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    from . import pgen

    """\
    A LANGUAGE L = { a^n b^n c^n | n >= 1 }.
    """
    # L: S
    # S: F 'c'
    # F: 'a' F 'b' | T
    # T: 'a' T 'b' | ''

    pgen = pgen.ParserGenerator([("S", [("F", "c")]), ("F", [("a", "F", "b"), "T"]), ("T", [("a", "T", "b"), ""])])
    pgen.addfirstsets()
    assert pgen.first["S"] == {"a": 1, "": 1}
    assert pgen.first["F"] == {"a": 1, "": 1}

# Generated at 2022-06-23 16:00:53.804482
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    x = ParserGenerator()
    x.generator = iter([
        (token.STRING, "'x'", (0, 0), (0, 0), ''),
        (token.NAME, "x", (1, 0), (1, 0), ''),
        (token.ENDMARKER, "", (2, 0), (2, 0), '')
    ])
    x.gettoken()
    a, z = x.parse_atom()
    assert a.arcs == [(None, z)]
    assert z.arcs == []
    x.gettoken()
    a, z = x.parse_atom()
    assert a.arcs == [('x', z)]
    assert z.arcs == []
    x.gettoken()
    assert_raises(StopIteration, x.gettoken)
test_

# Generated at 2022-06-23 16:01:05.390065
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    generator = ParserGenerator()
    nfa_states, start_symbol = generator.parse(r"""\
    start: (first | second) third
    first: "first"
    second: "second"
    third: "third"
    """)
    print("nfa_states:", nfa_states)
    print("start_symbol:", start_symbol)
    assert start_symbol == "start"
    assert len(nfa_states["start"]) == 2
    assert len(nfa_states["first"]) == 2
    assert len(nfa_states["second"]) == 2
    assert len(nfa_states["third"]) == 2
test_ParserGenerator_parse_alt()


# Generated at 2022-06-23 16:01:14.706585
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    '''(ParserGenerator) -> boolean'''

    def check(file: Text, dfas: Dict[Text, List["DFAState"]], start: Text) -> None:
        for name, dfa in dfas.items():
            for state in dfa:
                for label, next in state.arcs.items():
                    assert label[0] != "-", (file, name, label)
        if file == "expr":
            # from pprint import pprint
            # pprint(dfas["expr_stmt"][0].arcs)
            assert len(dfas["factor"][0].arcs) == 4, (
                dfas["factor"][0].arcs, file
            )
        assert len(dfas) >= 4, file
        assert start

    # Test case 1
    file = inspect.getsource