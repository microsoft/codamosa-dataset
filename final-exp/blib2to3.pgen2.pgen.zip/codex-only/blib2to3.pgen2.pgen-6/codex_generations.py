

# Generated at 2022-06-23 15:51:22.335840
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():

    # Test case for dump_dfa.
    #
    # ParserGenerator.dump_dfa(self, name, dfa)

    class DFAState(object):

        def __init__(
            self,
            nfaset: Dict[NFAState, int],
            isfinal: Any,
            arcs: Optional[Dict[str, Any]]
        ) -> None:
            self.nfaset = nfaset
            self.isfinal = isfinal
            self.arcs = arcs

    class NFAState(object):

        def __init__(self) -> None:
            self.arcs = []

        def addarc(self, label: Any, next: Any) -> None:
            self.arcs.append((label, next))


# Generated at 2022-06-23 15:51:29.703082
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    # Create two dead states that should be merged.
    dfa = [
        DFAState({}, None),
        DFAState({}, None),
        DFAState({4: 1}, None),
        DFAState({5: 1}, None),
        DFAState({}, None),
        DFAState({}, None),
        DFAState({}, None),
        DFAState({}, None),
        DFAState({}, None),
        DFAState({}, None),
        DFAState({}, None),
    ]
    dfa[0].addarc(dfa[1], "b")
    dfa[3].addarc(dfa[5], "b")
    dfa[2].addarc(dfa[3], "a")
    dfa[4].addarc(dfa[5], "a")
   

# Generated at 2022-06-23 15:51:40.176071
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    from . import pgen2
    from . import token
    # NOTE: This unit test depends on the definition of ParserGenerator in this
    # file, which is subject to change.

    vals = {}

# Generated at 2022-06-23 15:51:42.984308
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    # This will raise a SyntaxError.
    pytest.raises(SyntaxError, ParserGenerator, "", "")



# Generated at 2022-06-23 15:51:46.519469
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    r = ParserGenerator(["x"], "x", [])
    for dfa in sorted(r.dfas.values()):
        assert dfa[0].isfinal


# Generated at 2022-06-23 15:51:57.885597
# Unit test for constructor of class NFAState
def test_NFAState():
    a = NFAState()
    b = NFAState()
    a.addarc(b)
    assert a.arcs == [(None, b)]
    a.addarc(b, "foo")
    assert a.arcs == [(None, b), ("foo", b)]
    a.addarc(b, "")
    assert a.arcs == [(None, b), ("foo", b), ("", b)]
    a.addarc(a)
    assert a.arcs == [(None, b), ("foo", b), ("", b), (None, a)]
    a.addarc(a, "foo")
    assert a.arcs == [(None, b), ("foo", b), ("", b), (None, a), ("foo", a)]
    a.addarc(b, "bar")
    assert a.arcs

# Generated at 2022-06-23 15:52:00.459718
# Unit test for constructor of class NFAState
def test_NFAState():
    x = NFAState()
    y = NFAState()
    z = NFAState()
    assert not x.arcs
    x.addarc(y)
    assert x.arcs == [ (None, y) ]
    x.addarc(z, "a")
    assert x.arcs == [ (None, y), ("a", z) ]


# Generated at 2022-06-23 15:52:11.564636
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    # Test method name taken from _testcapi.c
    global source  # This is a global variable in _testcapi.c
    source = 'abc'
    global expected_type  # This is a global variable in _testcapi.c
    expected_type = token.NAME
    global expected_token  # This is a global variable in _testcapi.c
    expected_token = 'abc'
    expected_begin = (1, 0)
    expected_end = (1, 3)
    expected_line = 'abc'

    class CheckToken:
        def __init__(self, type, token, begin, end, line):
            self.type = type
            self.token = token
            self.begin = begin
            self.end = end
            self.line = line
            self.check_token()


# Generated at 2022-06-23 15:52:17.627408
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    import io

    try:
        parser = ParserGenerator()
    except Exception as e:
        print(e)
        assert False

    try:
        p = parser.parsestring("")
    except Exception as e:
        print(e)
        assert False

    try:
        p = parser.parsestring("a: 1+9|3 ;")
    except Exception as e:
        print(e)
        assert False

    try:
        stream = io.StringIO('a: "a" | "b"')
        p = parser.parsefile(stream)
    except Exception as e:
        print(e)
        assert False

# Generated at 2022-06-23 15:52:24.457793
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    o = ParserGenerator(token.tokenize(BytesIO(b"(1)").readline))
    o.gettoken()
    assert o.type == token.OP
    assert o.value == "("
    assert o.begin == (1, 0)
    assert o.end == (1, 1)
    assert o.line == "("
    a, z = o.parse_atom()
    assert a.arcs == [(None, z)]
    assert z.arcs == []
test_ParserGenerator_parse_atom()

# Generated at 2022-06-23 15:52:35.800598
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    import unittest

    class ParserGenerator_parse_item(unittest.TestCase):

        # Confirm that a name is parsed as a single arc in the NFA
        def test_name(self):
            pg = ParserGenerator()
            iterator = iter([(token.NAME, 'NAME', (0, 0), (0, 0), "")])
            pg.generator = iterator
            pg.gettoken()
            a, z = pg.parse_item()
            self.assertEqual(len(a.arcs), 1, "should be one arc leaving a")
            self.assertEqual(len(z.arcs), 0, "should be no arcs leaving z")
            self.assertEqual(a.arcs[0], (z, 'NAME'), "arc should be labeled NAME")

        # Confirm that a

# Generated at 2022-06-23 15:52:46.290656
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    lines = """
    a: 'b' | 'c'
    d: 'b'
    """.splitlines()
    pg = ParserGenerator()
    try:
        pg.parsestring(lines)
    except SyntaxError:
        pass
    else:
        raise TestFailed("expected a syntax error")
    lines = """
    a: 'b' | 'c'
    a: 'd'
    """.splitlines()
    pg = ParserGenerator()
    try:
        pg.parsestring(lines)
    except SyntaxError:
        pass
    else:
        raise TestFailed("expected a syntax error")
    lines = """
    a: 'b' | 'c'
    d: 'b'*
    """.splitlines()
    pg = ParserGenerator()

# Generated at 2022-06-23 15:52:55.450596
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    import textwrap
    input = textwrap.dedent('''
        # comment
        start: rule
        rule: 'x'
           | 'y'
           | rule 'z'
           | rule rule
    ''')
    pgen = ParserGenerator()
    pgen.parsegrammar(input)
    pgen.addfirstsets()
    dfa = pgen.dfas['rule']
    state = dfa[0]
    assert state.arcs == {'x': dfa[1], 'y': dfa[2]}
    assert state.isfinal is False
    assert pgen.first['rule'] == {'x': 1, 'y': 1}


# Generated at 2022-06-23 15:53:05.059490
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    from .pgen2 import ParseError
    from . import pygram
    pg = ParserGenerator(pygram.python_grammar, pygram.python_grammar_flags, pygram.python_grammar_encoding, 'grammar.txt')
    pg.make_pgen_grammar()
    assert len(pg.first) == 0
    try:
        pg.addfirstsets()
    except ValueError as e:
        raise ParseError(f'Internal pgen2 error: {e}')
    assert len(pg.first) == len(pg.dfas)
# class ParserGenerator


# Generated at 2022-06-23 15:53:11.630524
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    with open('Grammar.txt', 'r') as f:
        generated_PgenGrammar_instance = PgenGrammar(f, 'root', 'Grammar')
    with open('/Users/valerian/Documents/University/4th_year/4th_semester/SDP/SDP-project/blib2to3/pgen2/Grammar.txt') as f:
        assert generated_PgenGrammar_instance == PgenGrammar(f, 'root', 'Grammar')



# Generated at 2022-06-23 15:53:20.842950
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    import unittest.mock
    import tokenize
    from lib2to3 import pytree
    from lib2to3.pygram import python_symbols as syms

    def parse_rhs(p: ParserGenerator):
        with unittest.mock.patch.object(
            p, "gettoken", wraps=p.gettoken
        ) as gettoken_mock:

            def side_effect():
                p.type = tokenize.NAME
                p.value = "NAME"

# Generated at 2022-06-23 15:53:33.727726
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    p = ParserGenerator()
    p.add_production("A", ["c", "A", "d"])
    p.add_production("A", ["c", "d"])
    names = list(p.dfas.keys())
    names.sort()
    assert names == ["A"], names
    dfa = p.dfas["A"]
    assert len(dfa) == 4, len(dfa)
    assert len(dfa[0].arcs) == 2, dfa[0].arcs
    assert dfa[0].arcs["c"] is dfa[1], dfa[0].arcs["c"]
    assert dfa[1].arcs["A"] is dfa[2], dfa[1].arcs["A"]

# Generated at 2022-06-23 15:53:35.830153
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    a = grammar.Grammar()


# Parsing a string that contains the serialized grammar

# Generated at 2022-06-23 15:53:45.962720
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    pg = ParserGenerator()
    grammar_file = "Grammar/Grammar"
    f = open(grammar_file, "rb")
    s = f.read()
    f.close()
    pg.generator = tokenize.tokenize(io.BytesIO(s).readline)
    pg.gettoken()
    if 1:
        pg.dump_nfa("expr_context", pg.expr_contexts[0], pg.expr_contexts[1])
        pg.dump_nfa("bool_op", pg.boolops[0], pg.boolops[1])
        pg.dump_nfa("test", pg.tests[0], pg.tests[1])
        pg.dump_nfa("term", pg.terms[0], pg.terms[1])

# Generated at 2022-06-23 15:53:55.126526
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    from .pgen2.tokenize import generate_tokens, untokenize, generate_tokens


    class ParserGenerator2(ParserGenerator):

        def make_grammar(
            self, lines: List[str], start_symbol: str = "file_input"
        ) -> "pgen2.Grammar":
            from . import pgen2

            return pgen2.Grammar(lines, start_symbol)


    tester = ParserGenerator2()
    tester.copymetavars = False
    tester.make_grammar(["s: 'a'"])



# Generated at 2022-06-23 15:54:01.094383
# Unit test for constructor of class NFAState
def test_NFAState():
    a, b, c = map(NFAState, range(3))
    a.addarc(b, "A")
    a.addarc(a, "B")
    a.addarc(c)
    assert a.arcs == [("A", b), (None, a), (None, c)]


# Generated at 2022-06-23 15:54:07.792800
# Unit test for method addarc of class DFAState
def test_DFAState_addarc():
    state1 = DFAState()
    state2 = DFAState()
    state3 = DFAState()
    state1.addarc(state2, 'a')
    state1.addarc(state3, 'b')
    assert state1.arcs == {'a': state2, 'b': state3}
    # Test that addarc raises an exception if the label is already there
    try:
        state1.addarc(state1, 'a')
        assert False  # Should never return here
    except KeyError:
        pass


# Generated at 2022-06-23 15:54:12.280925
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    grammar_path = os.path.join(
        os.path.dirname(__file__), "..", "..", "..", "Grammar", "Grammar"
    )
    with open(grammar_path, "rb") as f:
        g = PgenGrammar(f.read())


# Generated at 2022-06-23 15:54:19.805194
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    from token import COMMENT, NL

    class Test_ParserGenerator_dump_nfa:
        pass

    testdata = """
    S: A
    A: '[' B ']'
    B: 'a'
    B: 'b'
    """
    converted = Test_ParserGenerator_dump_nfa()
    converted.dfas = {}
    converted.startsymbol = "S"
    converted.make_dfa = ParserGenerator.make_dfa.__get__(converted)
    try:
        converted.dump_nfa = ParserGenerator.dump_nfa.__get__(converted)
    except AttributeError:
        pass
    converted.parse_rhs = ParserGenerator.parse_rhs.__get__(converted)
    converted.parse_alt = ParserGener

# Generated at 2022-06-23 15:54:31.842806
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    import pgen2.grammar as grammar
    import pgen2.pgen  # For testing only
    import pgen2.token  # For testing only

    PG = pgen2.pgen.ParserGenerator(grammar)
    pgen2.token.N_TOKENS = len(grammar.tokens)
    pgen2.token.tok_name = {}
    for name, value in grammar.tokens.items():
        pgen2.token.tok_name[value] = name
    PG.build()
    for name, first in grammar.first.items():
        assert first == PG.first[name], name


test_ParserGenerator_calcfirst()

 
# If this module is run from the command line, it runs all its tests.

# Generated at 2022-06-23 15:54:42.023535
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    """Test method make_grammar of class ParserGenerator."""
    a_ndfa = ParserGenerator()

# Generated at 2022-06-23 15:54:46.446672
# Unit test for function generate_grammar
def test_generate_grammar():
    global grammar
    if grammar:
        # grammar already exist
        return
    else:
        grammar = generate_grammar()

if __name__ == "__main__":
    test_generate_grammar()

# Generated at 2022-06-23 15:54:58.637967
# Unit test for function generate_grammar
def test_generate_grammar():
    g = generate_grammar()
    assert g.p_accept("(a,b),c", 0, [None]) == ("(a,b),c", (1, 5, "[',']"))
    assert g.p_accept("(a,b),c", 0, []) == ("(a,b),c", None)
    assert g.p_accept("(a,b),c", 0, ["'('"]) == ("(a,b),c", (1, 5, "[',']"))
    assert g.p_accept("(a,b),c", 0, ["'('", "'('"]) == ("(a,b),c", None)

# Generated at 2022-06-23 15:55:02.914989
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    import io
    import pprint

    p = ParserGenerator()
    p.dump_nfa("foo", p.parse_rhs()[0], None)
    output = io.StringIO()
    pprint.pprint(p.dfas, output)
    assert len(output.getvalue()) > 0


if __name__ == "__main__":
    main()

# Generated at 2022-06-23 15:55:14.258178
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    import io
    import sys
    import pprint
    import token
    import tokenize

    def reader(
        filename: str,
        buf: io.StringIO,
        encoding: str = "utf-8",
        errors: str = "surrogateescape",
    ) -> Iterator[tokenize.TokenInfo]:
        with open(filename, "r", encoding=encoding, errors=errors) as fp:
            text = fp.read()
        buf.write(text)
        buf.seek(0)
        g = tokenize.tokenize(buf.readline)
        return g

    filename = "Grammar.txt"
    buf = io.StringIO()
    generator = reader(filename, buf)
    p = ParserGenerator(generator, filename)

# Generated at 2022-06-23 15:55:16.699989
# Unit test for constructor of class NFAState
def test_NFAState():
    s = NFAState()
    assert not s.arcs

    s.addarc(s)
    assert s.arcs == [(None, s)]

    s.addarc(s, "x")
    assert s.arcs == [(None, s), ("x", s)]

    s.addarc(s, "y")
    assert s.arcs == [(None, s), ("x", s), ("y", s)]



# Generated at 2022-06-23 15:55:26.047764
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    pg = ParserGenerator()
    pg.parse("a [b | c]")
    pg.parse("a [b | c] d")
    pg.parse("a [b | c] d | e")
    pg.parse("a [b | c] d | e [f | g]")
    pg.parse("a [b | c] d | e [f | g] h")
    pg.parse("a [b | c] d | e [f | g] h | i")
    pg.parse("a [b | c] d | e [f | g] h | i [j | k]")
    pg.parse("a [b | c] d | e [f | g] h | i [j | k] l")
test_ParserGenerator_parse_alt()

# Generated at 2022-06-23 15:55:32.342475
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    pg = ParserGenerator()
    pg.first = {}
    pg.dfas = {
        'NUMBER': [
          DFAState({NFAState(arcs=[(None, NFAState(arcs=[('digit', NFAState())]))])}, False),
          DFAState({NFAState(arcs=[(None, NFAState(arcs=[('digit', NFAState())]))])}, False),
          DFAState({NFAState(arcs=[(None, NFAState(arcs=[('digit', NFAState())]))])}, True),
        ],
    }
    pg.calcfirst('NUMBER')
    assert pg.first['NUMBER'] == {'digit': 1}


# Generated at 2022-06-23 15:55:36.032808
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    from . import pgen
    g = pgen.PgenGrammar()
    assert isinstance(g, PgenGrammar)
    assert isinstance(g, grammar.Grammar)



# Generated at 2022-06-23 15:55:47.201631
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    pg = ParserGenerator()
    pg.add("S", "a")
    pg.make_parser()  # Should not crash


# A parser generator instance.
#
# When called, it is passed the tokens produced by the tokenizer and
# returns an AST (Abstract Syntax Tree) of the parsed input.
#
# Constructor:
#   ParserGenerator()
#
# Methods:
#   add(name, definition)
#   make_parser(debug) -> parser function
#
# The parser is a function created by the make_parser() method.  When
# called, it is passed an iterable of token items (as produced by the
# tokenize module) and returns an abstract syntax tree (AST) of the
# input.  If debugging is enabled, the parsers prints debugging
# information to the standard output stream.
#
#

# Generated at 2022-06-23 15:55:59.002029
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    f = open('2to3/Grammar.txt')
    g = PgenGrammar(f, 'root', '2to3/Grammar3.6.pickle')
    a = g.dfas['file_input']

# Generated at 2022-06-23 15:56:09.034584
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():
    dfa = []

    def addstate(arcdict=None):
        arcs = dict(arcdict or {})
        dfa.append(DFAState({}, None))
        dfa[-1].arcs = arcs
        return len(dfa) - 1

    i = addstate({})
    j = addstate({})
    k = addstate({})
    dfa[i].unifystate(dfa[j], dfa[k])
    assert dfa[i].arcs == dfa[k].arcs
    dfa[j].unifystate(dfa[j], dfa[i])
    assert dfa[j].arcs == dfa[i].arcs
    dfa[i].unifystate(dfa[k], dfa[k])
    assert dfa[i].arcs == dfa

# Generated at 2022-06-23 15:56:12.992660
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    pg = ParserGenerator()
    input = """
    start: rule1 | rule2
    rule1: 'x'
    rule2: 'y' 'y'
    """
    dfa = pg.parse_string(input)
    pg.dump_dfa("start", dfa)


# Generated at 2022-06-23 15:56:23.153802
# Unit test for method addarc of class DFAState
def test_DFAState_addarc():
    state1 = DFAState({"a": 1}, "b")
    state2 = DFAState({"c": 1}, "d")
    state3 = DFAState({"e": 1}, "f")

    result = state1.addarc(state2, "label")
    assert result is None
    assert state1.arcs == {"label": state2}
    result = state1.addarc(state3, "label")
    assert result is None
    assert state1.arcs == {"label": state3}


# Generated at 2022-06-23 15:56:32.714768
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    expect = {"(": 1, "{": 1, "NAME": 1, "NUMBER": 1, "STRING": 1}
    pg = ParserGenerator()
    grammar1 = """
    single_input: NEWLINE | simple_stmt | compound_stmt NEWLINE
    """
    pg.parsestr(grammar1)
    pg.addfirstsets()
    res = pg.make_first(object(), "single_input")
    assert res == expect
    grammar2 = """
    expr_stmt: testlist augassign yield_expr | testlist augassign testlist
              | testlist
    """
    pg.parsestr(grammar2)
    pg.addfirstsets()
    res = pg.make_first(object(), "expr_stmt")
    assert res == expect

# Generated at 2022-06-23 15:56:43.953136
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    import random
    import time
    random.seed(time.time())
    def randname():
        L = []
        for i in range(10):
            L.append(random.choice("abcdef"))
        return "".join(L)
    def makeitem(names: Set[Text], maxalt: int = 5) -> Text:
        result = []
        for i in range(random.randrange(maxalt)):
            if random.choice((0, 1)):
                result.append("(%s)" % makealt(names))
            elif names:
                result.append("[%s]" % makealt(names))
            else:
                result.append("NAME")
        return " ".join(result)
    def makealt(names: Set[Text]) -> Text:
        result = []
        maxitem = random

# Generated at 2022-06-23 15:56:54.472338
# Unit test for function generate_grammar
def test_generate_grammar():
    rules = generate_grammar()
    print(rules.keys())
    print('Printing the non-terminal grammar rules')

# Generated at 2022-06-23 15:56:56.931358
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    a = ParserGenerator()
    b = a.make_first(None, "test")
    assert False, "unimplemented"
test_ParserGenerator_make_first()

# Generated at 2022-06-23 15:57:07.017749
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    print("ParserGenerator.parse_alt()", end="")
    pg = ParserGenerator()
    pg.lexer = Lexer()
    pg.lexer.input("expr_stmt: testlist_star_expr\n")
    pg.lexer.filename = "<string>"
    pg.lexer.line = "<string>"
    pg.gettoken()
    a, z = pg.parse_alt()
    for token in (token.NAME, token.OP, token.NAME):
        assert token == pg.type
    assert z is not a
    assert z in a.arcs
    assert a in z.arcs
    assert not pg.errors
    print(" done")



# Generated at 2022-06-23 15:57:10.122410
# Unit test for constructor of class NFAState
def test_NFAState():
    a = NFAState()
    assert a.arcs == []
    b = NFAState()
    a.addarc(b, 'test label')
    assert a.arcs == [('test label', b)]

DOT_KEYWORDS = frozenset(["digraph", "node", "edge"])


# Generated at 2022-06-23 15:57:17.367407
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():
    d = DFAState({}, None)  # This is a dummy
    s = DFAState({}, None)
    d.addarc(s, 'a')
    d.addarc(s, 'b')
    d.addarc(s, 'c')
    d.unifystate(s, s)
    assert s.arcs == {'a': s, 'c': s, 'b': s}


# ------------------- The following are probably not useful -------------------


# Generated at 2022-06-23 15:57:28.754603
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    pg = ParserGenerator()

# Generated at 2022-06-23 15:57:33.546355
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    pg = ParserGenerator()
    pg.dfas = {"start": [DFAState({}, False)], "x": [DFAState({}, False)]}
    pg.addfirstsets()
    assert pg.first["start"] == {"<x>": 1}
    assert pg.first["x"] == {"<x>": 1}



# Generated at 2022-06-23 15:57:37.158165
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    #        01234567890123456789012345678901234567890123456789012345678901234567890123456789
    dfas = ParserGenerator().parse_rhs()
    assert len(dfas) == 7
    # TODO: Add more tests
    print("test_parse_rhs done")


# Generated at 2022-06-23 15:57:45.200759
# Unit test for function generate_grammar
def test_generate_grammar():
    grammar = generate_grammar('Grammar.txt')
    assert len(grammar.starts) == 1
    pprint(grammar.starts)
    pprint(grammar.dfas)
    pprint(grammar.labels)
    assert len(grammar.dfas) == 12
    assert len(grammar.labels) == 25
    assert len(grammar.first) == 12

if __name__ == "__main__":

    test_generate_grammar()
    # p = ParserGenerator(sys.argv[1])
    # dfa, startsymbol = p.parse()
    # for name, dfa in dfa.items():
    #     print(name, dfa[0].isfinal)

# Generated at 2022-06-23 15:57:46.889012
# Unit test for method addarc of class DFAState
def test_DFAState_addarc():
    s = DFAState({}, None)
    s.addarc(s, "a")
    assert len(s.arcs) == 1



# Generated at 2022-06-23 15:57:58.907885
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    pg = ParserGenerator(["none"], token.N_TOKENS)
    label = pg.make_label(pg, "NAME")
    assert label == token.NAME, label
    label = pg.make_label(pg, "NUMBER")
    assert label == token.NUMBER, label
    label = pg.make_label(pg, "STRING")
    assert label == token.STRING, label
    label = pg.make_label(pg, "if")
    assert pg.labels[label] == (token.NAME, "if"), (label, pg.labels[label])
    label = pg.make_label(pg, "and")
    assert pg.labels[label] == (token.NAME, "and"), (label, pg.labels[label])

# Generated at 2022-06-23 15:58:04.448537
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    parser = ParserGenerator(
        "rules",
        [
            (token.NAME, "foo"),
            (token.OP, "+"),
            (token.NAME, "bar"),
            (token.OP, "+"),
            (token.NAME, "baz"),
            (token.OP, "*"),
            (token.NAME, "quux"),
            (token.ENDMARKER, None),
        ],
    )
    parser.gettoken()
    parser.gettoken()
    try:
        a, z = parser.parse_item()
        assert False, "no SyntaxError"
    except SyntaxError:
        pass

# Generated at 2022-06-23 15:58:16.044736
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    parser = ParserGenerator()
    # parser.parse_items
    # 1: (())
    a, z = parser.parse_alt()
    assert isinstance(a, NFAState)
    assert isinstance(z, NFAState)
    b = a.arcs[0][1]
    c = b.arcs[0][1]
    assert a.arcs == [("", b)]
    assert b.arcs == [("", c)]
    assert c.arcs == [("", z)]
    # 2: (("a", "b"),)
    d, x = parser.parse_alt()
    assert isinstance(d, NFAState)
    assert isinstance(x, NFAState)
    e = d.arcs[0][1]
    f = e.arcs[0][1]

# Generated at 2022-06-23 15:58:26.471835
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    pyfile = pathlib.Path(__file__)
    with open(str(pyfile)) as f:
        pycode = f.read()

    pgen = ParserGenerator(pycode, "f.py")
    # XXX comparison should be more exacting, but it's pretty close

# Generated at 2022-06-23 15:58:33.395904
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    pg = ParserGenerator([])
    state1 = DFAState({}, None)
    state2 = DFAState({}, None)

    state1.addarc(state1, "E")
    state1.addarc(state2, "T")
    state2.addarc(state2, "E")
    state2.addarc(state1, "T")

    dfa = [state1, state2]
    pg.dump_dfa("Example", dfa)

# Generated at 2022-06-23 15:58:38.552540
# Unit test for method __eq__ of class DFAState
def test_DFAState___eq__():
    from pypy.interpreter.pyparser.test.test_pyparser import assert_raises
    from pypy.interpreter.pyparser.test.test_pyparser import raises

    dfa = DFAState({}, None)
    assert not (dfa == None)
    assert not (dfa == [])
    assert dfa == dfa

    dfa2 = DFAState({}, None)
    assert dfa == dfa2

    dfa3 = DFAState({None: object()}, None)
    assert not (dfa == dfa3)

# Generated at 2022-06-23 15:58:50.017935
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    from .pgen2_grammar import PythonGrammar

    G = PythonGrammar()

    pg = ParserGenerator(G.grammar, G.syms, G.terminals)
    pg.build()
    pg.addfirstsets()

    # Check that the table is correct
    assert pg.start == "file_input"
    assert len(pg.labels) == len(pg.first["file_input"])
    assert pg.labels[0] == (token.ENCODING, None)
    assert pg.labels[-1] == (token.ENDMARKER, None)
    assert pg.symbol2label["file_input"] == len(pg.first["file_input"]) - 1

# Generated at 2022-06-23 15:58:57.254445
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    import StringIO
    pg = ParserGenerator()
    g = pg.make_grammar(StringIO.StringIO(r"""
        # Grammar for a toy expression evaluator
        expr: term ('+' term)*
        term: factor ('*' factor)*
        factor: '(' expr ')' | number
        number: /\d+/
    """))
    print(g)
# end unit test



# Generated at 2022-06-23 15:59:08.203493
# Unit test for method simplify_dfa of class ParserGenerator

# Generated at 2022-06-23 15:59:18.927261
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    pg = ParserGenerator()
    next(pg.generator)
    next(pg.generator)
    pg.filename = "dummy.txt"
    pg.end = (23, 45)
    pg.line = '"dummy.txt", line 23\n'
    raises(SyntaxError, pg.raise_error, "dummy error")
    raises(SyntaxError, pg.raise_error, "dummy error %s", "foo")
    raises(SyntaxError, pg.raise_error, "dummy error %d", 23)
    raises(SyntaxError, pg.raise_error, "dummy %s %s %s %s", "error", "foo", "bar", 23)

# Generated at 2022-06-23 15:59:27.740830
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    import io
    import tokenize
    import unittest

    endmarker = tokenize.TokenInfo(token.ENDMARKER, "", (0, 0), (0, 0), "")

    class DFATest(unittest.TestCase):
        def check(self, grammar: str, expected: str) -> None:
            generator = ParserGenerator()
            fake_tokenize_generator = [
                tokenize.TokenInfo(*t) for t in tokenize.generate_tokens(io.StringIO(grammar))
            ]
            fake_tokenize_generator.append(endmarker)
            dfa, startsymbol = generator.parse(fake_tokenize_generator)
            self.assertEqual(startsymbol, "<string>")
            out = io.StringIO()

# Generated at 2022-06-23 15:59:30.682565
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    try:
        ParserGenerator(["foo", "-"]).parse_atom()
    except SyntaxError:
        # expected
        pass
    else:
        raise RuntimeError("expected SyntaxError: (...|NAME|STRING)")

# Generated at 2022-06-23 15:59:41.454051
# Unit test for function generate_grammar
def test_generate_grammar():
    # First, check that the grammar does compile
    p = ParserGenerator()
    grammar = p.make_grammar()

    # Now, a few ad hoc checks
    assert grammar.keywords["False"] == 1
    assert grammar.keywords["None"] == 2
    assert "import" in grammar.keywords
    assert grammar.keywords["import"] == 7
    assert "yield" in grammar.keywords
    assert grammar.keywords["yield"] == 70
    assert grammar.opmap["->"] == 72
    assert "**" in grammar.opmap
    assert grammar.opmap["**"] == 70
    assert "lL" in grammar.opmap
    assert "uU" in grammar.opmap

# Generated at 2022-06-23 15:59:45.906880
# Unit test for method __eq__ of class DFAState
def test_DFAState___eq__():
    import pickle
    dfa_state = DFAState({}, None)
    # The following assert fails when run with python 2.7.0.
    # assert dfa_state == dfa_state
    # assert dfa_state != None
    pickle.dumps(dfa_state)

test_DFAState___eq__()

# Must define a __repr__, otherwise it prints a memory address

# Generated at 2022-06-23 15:59:55.953109
# Unit test for method make_label of class ParserGenerator

# Generated at 2022-06-23 16:00:07.048388
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    from types import SimpleNamespace
    #
    # Initialization
    #

# Generated at 2022-06-23 16:00:18.690414
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    pg = ParserGenerator()
    pg.calclex()
    pg.addfirstsets()
    assert pg.first["file_input"] == {'"""': 1, '"""\n': 1, "'\\n'": 1, '"\\n"': 1,
                                      "ENDMARKER": 1, "import_name": 1, "NAME": 1,
                                      '#': 1, "NEWLINE": 1, "from_name": 1,
                                      "dotted_name": 1, "STRING": 1, "dotted_as_names": 1,
                                      'import': 1, "PASS": 1, "funcdef": 1, "*": 1,
                                      "classdef": 1, "decorated": 1}
    assert pg.first["import_stmt"] == {"import": 1}
    assert pg.first

# Generated at 2022-06-23 16:00:28.721149
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    msg = "test_ParserGenerator_parse_alt"
    import pgen2.pgen
    from pgen2.parse import ParseError
    def checkit(grammar, input):
        parser = pgen2.pgen.ParserGenerator(grammar)
        parser.parse()
        converter = Pgen2Grammar(parser)
        converter.addfirstsets()
        parser = converter.make_pgen_grammar()
        return parser.parse(input), parser.error

    check = unittest.FunctionTestCase(checkit, None, 3)

# Generated at 2022-06-23 16:00:34.826341
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    # XXX This is in a function so that it gets called only when this module is
    # run as a script, not when imported.  There's probably a better way.
    pg = ParserGenerator()
    c = pg.convert([{"file_input": [[]]}])

    def t(label: str, expected: int) -> None:
        result = pg.make_label(c, label)
        assert result == expected, "%s -> %d, not %d" % (label, result, expected)

    t('"import"', 4)
    t('"if"', 1)
    t('"True"', 4)
    t('"def"', 3)
    t('"return"', 5)
    t('"lambda"', 6)
    t('"+"', 9)

# Generated at 2022-06-23 16:00:47.181970
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    from . import token
    from .tokenizer import generate_tokens, untokenize

    def tokenize(s: str) -> Iterator[TokenTuple]:
        return generate_tokens(StringIO(s).readline)

    def plot_nfa(a: "NFAState") -> None:
        numbers = {}
        todo = [a]
        for i, state in enumerate(todo):
            numbers[state] = i
            for label, next in state.arcs:
                if next not in numbers:
                    todo.append(next)
        print("digraph nfa {")
        for state in todo:
            if state.isfinal:
                print("    %d [shape=doublecircle];" % numbers[state])

# Generated at 2022-06-23 16:00:54.733262
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    from . import grammar_compiler
    from . import pytoken
    import io
    import os
    import unittest

    data = io.StringIO(
        """
# xxx: [a]
a: b [b]? | c

b: 'b'
c: 'c'
"""
    )
    generator = ParserGenerator(
        data, "xxx", pytoken, pygram.python_grammar, grammar_compiler.GrammarCompiler
    )
    startsymbol, dfas = generator.make_parser()
    test = unittest.TestCase()
    import sys

    save_stderr = sys.stderr
    sys.stderr = sys.stdout
    try:
        generator.dump_dfa(startsymbol, dfas)
    finally:
        sys

# Generated at 2022-06-23 16:01:06.131794
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    pg = ParserGenerator(requires_unicode=False)
    c = pg.converter()
    assert pg.make_label(c, "NAME") == 0
    assert pg.make_label(c, "NAME") == 0
    assert pg.make_label(c, "STMT") == 1
    assert pg.make_label(c, "STMT") == 1
    assert pg.make_label(c, "'+'") == 2
    assert pg.make_label(c, "'+'") == 2

    assert c.labels == [(token.NAME, None), (0, None), (token.OP, "+")]
    assert c.tokens == {token.NAME: 0, token.OP: 2}



# Generated at 2022-06-23 16:01:10.607799
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
  p = ParserGenerator()
  a = NFAState()
  z = NFAState()
  a.addarc(z, 'a')
  a.addarc(z, 'b')

  states = p.make_dfa(a, z)
  assert len(states) == 1
  assert len(states[0].arcs) == 2



# Generated at 2022-06-23 16:01:19.403167
# Unit test for constructor of class DFAState
def test_DFAState():
    a = DFAState({}, NFAState())
    b = DFAState({}, NFAState())
    c = DFAState({}, NFAState())
    a.arcs["a"] = b
    a.arcs["b"] = c
    b.arcs["c"] = a
    c.arcs["a"] = c
    c.arcs["b"] = b
    a.unifystate(b, c)
    assert a.arcs == {"a": c, "b": c}
    assert b.arcs == {"c": a}
    assert c.arcs == {"a": c, "b": c}
    a.unifystate(c, b)
    assert a.arcs == {"a": b, "b": b}
    assert b.arcs == {"c": a}
   