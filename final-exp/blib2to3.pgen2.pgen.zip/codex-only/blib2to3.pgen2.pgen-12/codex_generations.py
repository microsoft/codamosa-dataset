

# Generated at 2022-06-23 15:51:17.815430
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    x = NFAState()
    y = NFAState()
    z = NFAState()
    a1 = NFAState()
    z1 = NFAState()
    a2 = NFAState()
    z2 = NFAState()
    x.addarc(y, 'a')
    x.addarc(a1)
    y.addarc(z, 'b')
    a1.addarc(z1)
    z1.addarc(a2, 'a')
    a2.addarc(z2, 'b')
    dfa = [DFAState({x: 1, y: 1, a1: 1}, z)]
    ParserGenerator.simplify_dfa(ParserGenerator, dfa)

 

# Generated at 2022-06-23 15:51:29.195913
# Unit test for function generate_grammar
def test_generate_grammar():
    from token import tok_name
    from io import StringIO
    dummy_write_tables = True  # see comments in pgen.py
    gr = generate_grammar()
    g: PgenGrammar
    g = gr[0]  # skip parsing
    assert g.start == 3
    assert g.labels == [(3, None), (3, None), (3, None), (3, None)]
    assert g.states == [(0, [0]), (1, [1]), (2, [2, 3])]
    assert g.dfas == {
        3: [
            (0, [0]),
            (1, [1]),
            (2, [2, 3]),
        ],
    }

# Generated at 2022-06-23 15:51:32.027725
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
  pgen = ParserGenerator()
  dfa = pgen.make_dfa(pgen.parse_rhs()[0],
                      pgen.parse_rhs()[1])
  pgen.simplify_dfa(dfa)



# Generated at 2022-06-23 15:51:39.900121
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    pg = ParserGenerator()
    pg.generator = iter([(token.NAME, "abc", (1, 0), (1, 3), "abc\n")])
    pg.gettoken()
    assert pg.type == token.NAME, pg.type
    assert pg.value == "abc", pg.value
    assert pg.begin == (1, 0), pg.begin
    assert pg.end == (1, 3), pg.end
    assert pg.line == "abc\n", pg.line

# Generated at 2022-06-23 15:51:49.290644
# Unit test for constructor of class ParserGenerator

# Generated at 2022-06-23 15:51:57.965768
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    pg = ParserGenerator()
    pg.generator = tokenize.generate_tokens(io.StringIO("(")
                                            .readline)
    assert pg.parse_atom() == (NFAState(arcs={('(', NFAState())}),
                               NFAState(arcs={('', NFAState())}))
    pg.generator = tokenize.generate_tokens(io.StringIO(" foo")
                                            .readline)
    assert pg.parse_atom() == (NFAState(arcs={('foo', NFAState())}),
                               NFAState(arcs={('', NFAState())}))
    pg.generator = tokenize.generate_tokens(io.StringIO(" 'foo'")
                                            .readline)

# Generated at 2022-06-23 15:52:08.297090
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    class State:
        def __init__(self, label: int, final: bool) -> None:
            self.label = label
            self.final = final
            self.arcs: Dict[str, "State"] = {}

        def __repr__(self) -> str:
            return "%d%s" % (
                self.label,
                self.final and "!" or "",
            )


# Generated at 2022-06-23 15:52:19.817569
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    print("Test make_dfa")
    pg = ParserGenerator()
    dfa = pg.make_dfa(NFAState(), NFAState())
    assert len(dfa) == 1
    assert dfa[0].isfinal
    a = NFAState()
    b = NFAState()
    c = NFAState()
    dfa = pg.make_dfa(a, c)
    assert len(dfa) == 3
    assert a.arcs == []
    assert a.isfinal
    assert b.arcs[0][0] == a
    assert b.arcs[0][1] == None
    assert c.arcs == []



# Generated at 2022-06-23 15:52:24.527932
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    import io, tokenize
    lines = ["name: foo\n"]
    s = io.StringIO("".join(lines))
    p = ParserGenerator()
    p.filename = "test"
    p.generator = tokenize.tokenize(s.readline)
    tok = p.gettoken()
    p.expect(token.NAME)
    p.expect(token.OP, ":")
    p.expect(token.NAME)
    p.expect(token.NEWLINE)
    p.expect(token.ENDMARKER)


# Generated at 2022-06-23 15:52:35.848038
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    # raise_error is implicitly tested by other tests.  Here we test
    # that it works even when a filename, line number, and line text
    # are all provided.
    p = ParserGenerator("test")
    exc_info = None  # type: Optional[Any]
    try:
        p.raise_error("Test error")
    except:
        exc_info = sys.exc_info()
    assert exc_info[0] is SyntaxError
    msg, (filename, lineno, offset, text) = exc_info[1].args
    assert text == "Test error"


if __name__ == "__main__":
    # An example of using ParserGenerator to parse a tiny subset of
    # Backus-Naur Form.
    test_ParserGenerator_raise_error()
    p = ParserGener

# Generated at 2022-06-23 15:52:39.764721
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    P = ParserGenerator()
    P.type=1
    P.value="a"
    P.expect(token.NAME)
    print("success")
test_ParserGenerator_expect()
import unittest

# Generated at 2022-06-23 15:52:51.230845
# Unit test for method addfirstsets of class ParserGenerator

# Generated at 2022-06-23 15:52:54.238998
# Unit test for constructor of class NFAState
def test_NFAState():
    assert NFAState().arcs == []
    s = NFAState()
    s.addarc(None, "0")
    assert s.arcs == [("0", None)]



# Generated at 2022-06-23 15:52:59.620151
# Unit test for method addarc of class DFAState
def test_DFAState_addarc():
    state1 = DFAState({}, None)
    state2 = DFAState({}, None)
    state1.addarc(state2)
    assert state1.arcs == {None: state2}



# Generated at 2022-06-23 15:53:10.175699
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    global token

    class Token:
        def __init__(self, tp: int, val: Text):
            self.type = tp
            self.string = val

        @property
        def value(self):
            return self.string

    token = Token
    pg = ParserGenerator()
    pg.dfas = {
        "a": [DFAState({}, False), DFAState({}, True)],
        "b": [DFAState({}, False), DFAState({}, True)],
        "c": [DFAState({}, False), DFAState({}, True)],
    }
    pg.dfas["a"][0].addarc(pg.dfas["a"][1], "b")

# Generated at 2022-06-23 15:53:19.596630
# Unit test for method parse_atom of class ParserGenerator

# Generated at 2022-06-23 15:53:31.440243
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    r = ParserGenerator(
        [
            ("NAME", "expr"),
            ("OP", ":"),
            ("STRING", "factor"),
            ("STRING", "term"),
            ("OP", "+"),
            ("OP", "|"),
            ("OP", ")"),
            ("NEWLINE", "\n"),
            ("STRING", "expr"),
            ("STRING", "x"),
            ("OP", "*"),
            ("NEWLINE", "\n"),
            ("OP", "["),
            ("NAME", "factor"),
            ("OP", "]"),
            ("OP", "("),
            ("ENDMARKER", ""),
        ],
        "",
        "",
    )
    with pytest.raises(SyntaxError):
        r.parse_atom()

# Generated at 2022-06-23 15:53:37.367762
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    grammar = r"""
    A: 'a'
    """
    pgen = ParserGenerator()
    pgen.parse_grammar(grammar)
    dfa = pgen.dfas["A"][0]
    arcs = list(dfa.arcs.items())
    assert len(arcs) == 1, arcs
    label, next = arcs[0]
    assert label == "a", label



# Generated at 2022-06-23 15:53:49.252193
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    p = ParserGenerator()
    for i in range(2):
        for j in range(2):
            for k in range(2):
                for l in range(2):
                    print(i, j, k, l)
                    p.type, p.value = i, j
                    value = 2*i + j
                    if k == 0:
                        type = 2*i + j
                    else:
                        type = 2*i + 2
                    if l == 0:
                        value = 2*i + 2*j
                    else:
                        value = 2*i + 2*j + 1
                    result = p.expect(type, value)
                    print(result)
                    assert result == value
                    assert p.type == i
                    assert p.value == j


# Generated at 2022-06-23 15:53:54.995620
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():
    a, b, c = DFAState(dict.fromkeys([0]), None), DFAState(dict.fromkeys([1]), None), DFAState(dict.fromkeys([2]), None)
    a.addarc(b, "a")
    a.addarc(c, "a")
    a.unifystate(b, c)
    assert a.arcs["a"] is c



# Generated at 2022-06-23 15:54:06.257115
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    def test(dfas, start, expected):
        pg = ParserGenerator()
        pg.make_dfas(dfas, start)
        pg.addfirstsets()
        # print pg.first
        for name, first in expected.items():
            if pg.first[name] != first:
                print(name, first, pg.first[name])
                assert 0, "test failed"


# Generated at 2022-06-23 15:54:15.367988
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    # Issue #11597
    text = r"""
    # Test grammar for ParserGenerator
    #

    # Comments
    #
    # A comment.
    #
    text = stmt+
    stmt = keyword arg

    keyword = 'JUMP' | 'RUN'

    arg = (NAME '+' NAME
           | NAME '-' NAME
           | NAME)

    NAME = ^[A-Z]+
    """
    ast = compile(text, "<test file>", "exec", ast.PyCF_ONLY_AST)
    code = ParserGenerator().make_grammar(text, ast)
    module = types.ModuleType("_parser")
    exec(code, module.__dict__)
    assert isinstance(module.parser, module._parser)

# Generated at 2022-06-23 15:54:27.802432
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    pg = ParserGenerator()
    # Create the NFA
    A = NFAState()
    Z = NFAState()
    B = NFAState()
    C = NFAState()
    D = NFAState()
    E = NFAState()
    F = NFAState()
    G = NFAState()
    H = NFAState()
    I = NFAState()
    J = NFAState()
    K = NFAState()
    L = NFAState()
    M = NFAState()
    N = NFAState()
    O = NFAState()
    P = NFAState()
    Q = NFAState()
    R = NFAState()
    S = NFAState()
    T = NFAState()
    U = NFAState()
    V = NFAState()

# Generated at 2022-06-23 15:54:31.636390
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    if __name__ == "__main__":
        _test()
        _test("foo")
        _test("foo", {})
        _test("foo", {}, "bar")
        _test("foo", {}, "bar", "baz")


# Generated at 2022-06-23 15:54:41.844413
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():  # unit test code
    class DummyConverter:
        def __init__(self):
            self.labels = []
            self.symbol2label = {}
            self.symbol2number = {}
            self.tokens = {}
            self.keywords = {}
    dummy = DummyConverter()
    pg = ParserGenerator("", "")
    pg.make_label(dummy, '"+"')
    assert dummy.labels == [(token.PLUS, None)]
    pg.make_label(dummy, 'foo')
    assert dummy.labels == [(token.PLUS, None), (4, None)]
    pg.make_label(dummy, '"foo"')

# Generated at 2022-06-23 15:54:54.775607
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    # The grammar files are in the lib/python*/lib directory;
    # they contain the grammars for Python.
    import os
    import sys

    path = os.path.split(os.path.abspath(__file__))[0]
    path = os.path.split(path)[0]
    path = os.path.join(path, "Lib")
    if sys.implementation.name == "cpython":
        fn = os.path.join(path, "parser.txt")
    else:
        fn = os.path.join(path, "cparser.txt")
    f = open(fn)
    s = f.read()
    f.close()
    pg = ParserGenerator()

# Generated at 2022-06-23 15:55:07.057474
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    gen = ParserGenerator()

# Generated at 2022-06-23 15:55:16.389654
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    # XXX this is not a test; it's just a way to generate "standard"
    # output for comparison
    import sys
    import doctest
    from . import driver
    from . import grammar
    from . import pygram
    from . import token

    filename = __file__[:-3] + ".py"
    tokens = token.generate_tokens(open(filename).readline)
    pg = ParserGenerator(tokens, filename)
    dfa = pg.dfas["expr_stmt"]
    pg.dump_dfa("expr_stmt", dfa)
    names = list(pg.dfas.keys())
    names.sort()
    for name in names:
        sys.stdout.write(name + ": ")
        dfa = pg.dfas[name]

# Generated at 2022-06-23 15:55:26.016190
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    pg = ParserGenerator()

# Generated at 2022-06-23 15:55:27.223573
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    pg = PgenGrammar()
    assert pg



# Generated at 2022-06-23 15:55:36.092620
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    import unittest

    class TestParserGenerator(unittest.TestCase):
        def test_expr(self):
            pg = ParserGenerator()
            self.assertEqual(pg.expr(), 0)
            self.assertEqual(pg.expr("1"), 1)
            self.assertEqual(pg.expr("2+3"), 5)

    unittest.main(
        TestParserGenerator, exit=False, verbosity=2, buffer=True
    )



# Generated at 2022-06-23 15:55:39.980838
# Unit test for method addarc of class DFAState
def test_DFAState_addarc():
    a = DFAState({NFAState(): None}, NFAState())
    b = DFAState({NFAState(): None}, NFAState())
    a.addarc(b, "abc")
    assert a.arcs == {"abc": b}
    assert b.arcs == {}
    c = DFAState({NFAState(): None}, NFAState())
    a.addarc(c, "cde")
    assert a.arcs == {"abc": b, "cde": c}
    assert b.arcs == {}
    assert c.arcs == {}



# Generated at 2022-06-23 15:55:47.517352
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    from . import pgen2_grammar
    from . import token
    from . import pgen
    from . import tokenize
    from . import string
    s = string.StringIO(pgen2_grammar.grammar)
    p = pgen.ParserGenerator(pgen2_grammar.syms, pgen2_grammar.terminals, s)
    dfa = p.parse()
    assert dfa is not None
    assert p.startsymbol is not None
    assert isinstance(p.startsymbol, str)
    assert isinstance(dfa, dict)
    assert len(dfa) > 0
    keys = list(dfa.keys())
    assert len(keys) == 39
    assert 'decorator' in keys
    assert len(p.dfas['decorator']) > 0


# Generated at 2022-06-23 15:55:51.719158
# Unit test for method addarc of class DFAState
def test_DFAState_addarc():
    """
    Test the method `addarc` of class `DFAState`.
    """
    state = DFAState({}, None)
    state.addarc(state)
    assert state.arcs == {None: state}
    #
    next = DFAState({}, None)
    state.addarc(next)
    assert len(state.arcs) == 2
    assert state.arcs[None] is state
    assert state.arcs[None] is not next
    assert state.arcs[None].arcs[None] is state
    assert state.arcs[None].arcs[None] is not next
    #
    state.addarc(next, 'name')
    assert len(state.arcs) == 3
    assert state.arcs[None] is state

# Generated at 2022-06-23 15:56:03.348342
# Unit test for method __eq__ of class DFAState
def test_DFAState___eq__():
    def test(a: DFAState, b: DFAState, eq: bool) -> None:
        if (a == b) != eq:
            raise ValueError("expected equality: %r == %r == %r" % (a, b, eq))
    # Dict values are just "1"s, so don't matter
    a = DFAState({NFAState()}, NFAState())
    b = DFAState({NFAState()}, NFAState())
    c = DFAState({NFAState()}, NFAState())

    test(a, a, True)
    test(a, b, True)
    test(a, c, True)

    a.isfinal, b.isfinal = False, True
    test(a, b, False)
    b.isfinal = False


# Generated at 2022-06-23 15:56:08.691384
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    rg = ParserGenerator()
    s = NFAState()
    s.addarc('a', NFAState())
    s.addarc('b', NFAState())
    dfa = rg.make_dfa(s, s)
    assert len(dfa) == 1
    dfa[0].isvalid()


if __name__ == "__main__":
    test_ParserGenerator_make_dfa()

# Generated at 2022-06-23 15:56:15.432710
# Unit test for method addarc of class NFAState
def test_NFAState_addarc():
    s = NFAState()
    t = NFAState()
    s.addarc(t, "a")
    assert len(s.arcs) == 1
    u = s.arcs[0][1]
    assert u == t
    v = NFAState()
    s.addarc(v, "a")
    assert len(s.arcs) == 2
    v = NFAState()
    s.addarc(v)
    assert len(s.arcs) == 3
    assert s.arcs[2][0] is None
    assert s.arcs[2][1] == v


# Generated at 2022-06-23 15:56:27.198693
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    def check(s: str) -> None:
        # type: (str) -> None
        fname = '<unknown>'
        source = s.encode('utf-8')
        generator = tokenize.generate_tokens(io.BytesIO(source).readline)
        p = ParserGenerator(fname, generator)
        try:
            result = p.parse()
        except SyntaxError:
            print(s)
            raise
        dfa = result[0][p.startsymbol]
        s = StringIO()
        for state in dfa:
            s.write('S%d: ' % dfa.index(state))

# Generated at 2022-06-23 15:56:35.179142
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    """Tests method :meth:`ParserGenerator.parse_item`.

    See also :meth:`test_make_parser`.
    """

    def _test(source: str, expected: str) -> None:
        actual = ParserGenerator._parse_item(
            ParserGenerator._tokenize_lines(source)[0][1:]
        )
        assert actual == expected, actual

    _test("'hello'", '(STRING, hello)')
    _test("NAME", '(NAME, None)')
    _test("(NAME 'hello')", "(foo, [('hello', foo)])")
    _test("([NAME 'hello'])", "(bar, [('hello', bar)])")
    _test("([NAME 'hello'] '+')", "(bar, [('hello', bar), ('+', bar)])")

# Generated at 2022-06-23 15:56:38.240504
# Unit test for function generate_grammar
def test_generate_grammar():
    g = generate_grammar(Path("./Grammar.txt"))
    assert g.symbol2label is not None
    assert g.keywords["False"] == 4

# Generated at 2022-06-23 15:56:49.033940
# Unit test for method __eq__ of class DFAState
def test_DFAState___eq__():
    # A bit lame, but at least it tests the code.
    a = DFAState({}, None)
    b = DFAState({}, None)
    assert a == b
    b.isfinal = 1
    assert a != b
    assert b != a
    b.isfinal = 0
    assert a == b
    a.arcs[0] = b
    assert a != b
    b.arcs[0] = a
    assert a == b
    a.arcs[1] = a
    assert a != b
    b.arcs[1] = b
    assert a == b
    #
test_DFAState___eq__()



# Generated at 2022-06-23 15:56:58.584584
# Unit test for constructor of class DFAState
def test_DFAState():
    dfa = [DFAState({"a": 1, "b": 1, "c": 1}, "a")]
    dfa[0].addarc(dfa[0], "c")
    assert dfa[0] == dfa[0]
    dfa.append(DFAState({"a": 1, "b": 1, "c": 1}, "a"))
    dfa[1].addarc(dfa[1], "c")
    assert dfa[0] == dfa[1]
    dfa.append(DFAState({"a": 1, "b": 1, "c": 1}, "c"))
    dfa[2].addarc(dfa[2], "c")
    assert dfa[0] != dfa[2]

# Generated at 2022-06-23 15:57:08.681547
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    pg = ParserGenerator()
    # Initial value
    pg.type == -1
    pg.generator = tokenize.generate_tokens(iter("").__next__)
    pg.gettoken()
    pg.type == token.ENDMARKER
    pg.value == ''
    pg.generator = tokenize.generate_tokens(iter("for").__next__)
    pg.gettoken()
    pg.value == 'for'
    pg.generator = tokenize.generate_tokens(iter("for ").__next__)
    pg.gettoken()
    pg.value == 'for'
    pg.generator = tokenize.generate_tokens(iter("for a").__next__)
    pg.gettoken()
    pg.value == 'for'
    pg

# Generated at 2022-06-23 15:57:20.386118
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    from StringIO import StringIO
    def tokenize(line):
        f = StringIO(line)
        for t in tokenize.generate_tokens(f.readline):
            if t[0] in (token.COMMENT, tokenize.NL):
                continue
            yield t
    tokenize.generate_tokens = tokenize.tokenize
    pg = ParserGenerator()
    pg.generator = tokenize("""[']']']
            """)
    pg.gettoken()
    assert pg.type == token.OP, "Expected OP, got: %s" % pg.type
    assert pg.value == "[", "Expected '[', got: %s" % pg.value
    pg.gettoken()

# Generated at 2022-06-23 15:57:26.885274
# Unit test for function generate_grammar
def test_generate_grammar():
    pgen_grammar = generate_grammar()
    assert isinstance(pgen_grammar, PgenGrammar)
    assert isinstance(pgen_grammar.dfas, dict)
    assert isinstance(pgen_grammar.startsymbol, str)

# Generate grammar only if run as main script
if __name__ == "__main__":
    generate_grammar()

# Generated at 2022-06-23 15:57:36.898535
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    g = ParserGenerator()
    try:
        g.raise_error("test %s %s %s %s", 1,2,3,4)
    except SyntaxError as e:
        assert e.msg == "test 1 2 3 4"
        assert e.args[0] == ("", 2, 0, "\n")
    try:
        g.end = (2,3)
        g.raise_error("test %s %s %s %s", 1,2,3,4)
    except SyntaxError as e:
        assert e.msg == "test 1 2 3 4"
        assert e.args[0] == ("", 2, 3, "\n")

# Generated at 2022-06-23 15:57:46.451591
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    pg = ParserGenerator()
    s = NFAState()
    x = NFAState()
    y = NFAState()
    z = NFAState()
    s.addarc(x, "a")
    s.addarc(y)
    x.addarc(z, "b")
    y.addarc(z, "c")
    dfa = pg.make_dfa(s, z)
    assert len(dfa) == 3
    zz = dfa[0]
    xx = dfa[1]
    yy = dfa[2]
    assert zz.nfaset == {s, y}
    assert xx.nfaset == {x}
    assert yy.nfaset == {y}
    assert zz.arcs[0] is zz and z

# Generated at 2022-06-23 15:57:58.917114
# Unit test for method dump_dfa of class ParserGenerator

# Generated at 2022-06-23 15:58:05.216203
# Unit test for constructor of class DFAState
def test_DFAState():
    a = NFAState()
    b = NFAState()
    c = NFAState()
    d = NFAState()
    dfa_a = DFAState({a: 1}, a)
    dfa_bc = DFAState({b: 1, c: 1}, b)
    dfa_bd = DFAState({b: 1, d: 1}, b)
    dfa_ad = DFAState({a: 1, d: 1}, d)
    assert dfa_a == dfa_a
    assert dfa_a != dfa_bc
    assert dfa_a != dfa_bd
    assert dfa_a != dfa_ad
    assert dfa_bc != dfa_bd
    assert dfa_bc != dfa_ad
    assert dfa_bd != dfa_ad

# Unit

# Generated at 2022-06-23 15:58:12.249913
# Unit test for function generate_grammar
def test_generate_grammar():
    import pickle

    g1 = generate_grammar()
    save = pickle.dumps(g1)
    g2 = pickle.loads(save)
    assert g1 == g2
    assert g1 is not g2
    assert g1.keywords == g2.keywords
    assert g1.dfas == g2.dfas
    assert g1.first == g2.first
    assert g1.start == g2.start
    assert str(g1) == str(g2)
    return g1


# Generated at 2022-06-23 15:58:21.205082
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    import sys
    import io

    samples = [
        ("foo", "foo", None),
        ("'foo'", "foo", None),
        ("( foo )", "( foo )", None),
        ("( foo )*", "( foo )", "+"),
        ("( foo )+", "( foo )", "*"),
        ("[ foo ]", "[ foo ]", None),
    ]
    for sample, expected, expected_star in samples:
        buf = io.BytesIO(b"\n" + (sample + "\n").encode("utf-8"))
        p = ParserGenerator(buf, "<sample>")
        a, z = p.parse_item()
        assert len(a.arcs) == 1 and a.arcs[0][0] == expected

# Generated at 2022-06-23 15:58:25.590061
# Unit test for constructor of class DFAState
def test_DFAState():
    a = NFAState()
    b = NFAState()
    c = NFAState()
    a.addarc(b, 2)
    b.addarc(c)
    d = DFAState({a: 1, b: 2, c: 3}, b)
    assert len(d.arcs) == 1
    assert 2 in d.arcs
    assert d.arcs[2] is d
    e = DFAState({a: 1, b: 2, c: 3}, a)
    assert len(e.arcs) == 0
    assert e.isfinal is False
    f = DFAState({a: 1, b: 2, c: 3}, a)
    assert e == f
    assert not(e != f)

# Generated at 2022-06-23 15:58:34.672915
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    # An NFA can be constructed by hand:
    #    * an NFAState has a list of arcs, each consisting of
    #      a label and a next state.  The label can be None.
    #    * An NFA has an initial state and a final state.
    #    * NFAState.addarc(label, next) creates a new arc and
    #      returns the next state.
    s0 = NFAState()
    s1 = s0.addarc("a", NFAState())
    s2 = s1.addarc("b", NFAState())
    s2.addarc("c", s0)
    s3 = s1.addarc(None, NFAState())
    s4 = s3.addarc("d", NFAState())
    s4.addarc("e", s4)
   

# Generated at 2022-06-23 15:58:43.257945
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    pg = ParserGenerator()
    pg.addproduction("Start", [("Expr", 1, -1)])
    pg.addproduction("Expr", [("Term", 1, -1), ("['+' | '-']", 0, 1)])
    pg.addproduction("Term", [("Factor", 1, -1)])
    pg.addproduction("Factor", [("'('", 0, 1), ("Expr", 1, 1), ("')'", 0, 1)])
    pg.addproduction("Factor", ["NUMBER"])
    pg.compile()
    print("Start symbol =", pg.startsymbol)
    print("Labels =", pg.labels)
    print("States =", pg.states)
    print("First =", pg.first)


# Generated at 2022-06-23 15:58:56.282774
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    import sys, os
    from . import grammar
    from . import parser
    from . import pytokenizer
    from . import symbol
    from . import token
    from . import tokenize

    # A very simple grammar
    pg = ParserGenerator()
    pg.add_production("S", ["a", "S", "S"])
    pg.add_production("S", ["a", "S"])
    pg.add_production("S", ["a"])

    # Make the parser
    p = pg.make_parser()
    assert isinstance(p, Parser)
    assert isinstance(p.grammar, grammar.Grammar)
    assert "_packaged_dir" in p.__dict__

    # Parse a string
    p.parse(pytokenizer.StringTokenizer("aaa"), "single")

    #

# Generated at 2022-06-23 15:59:06.864284
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    from test import support
    import re
    from Grammar import token_map

    def split_tokens(s: str) -> List[Tuple[int, str, Tuple[int, int], Tuple[int, int], str]]:
        for t in tokenize.tokenize(s.encode("utf-8")):
            if t[0] in token_map:
                yield token_map[t[0]], t[1], t[2], t[3], t[4]

    # Unit test for constructor of class ParserGenerator

    # Check grammar extraction and memoization
    pg = ParserGenerator()
    start = pg.extract_grammar(re.compile("").search)
    assert start == pg.extract_grammar(re.compile("").search)
    assert start != pg.ext

# Generated at 2022-06-23 15:59:12.580207
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    try:
        import StringIO
        import tokenize
    except ImportError:
        skip("requires StringIO and tokenize")
    def gengrammar() -> Iterator[tuple]:
        yield (token.NAME, "S", (1, 0), (1, 1), "S : STUFF | '[' stuff ']' ;")
        yield (
            token.OP,
            ":",
            (1, 2),
            (1, 3),
            "S : STUFF | '[' stuff ']' ;",
        )
        yield (
            token.NAME,
            "STUFF",
            (1, 4),
            (1, 9),
            "S : STUFF | '[' stuff ']' ;",
        )

# Generated at 2022-06-23 15:59:18.793313
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    pg = ParserGenerator()
    stream = [" ",
         "( ",
         "NAME",
         " NAME",
         " |",
         " NAME",
         " )",
         ]

    stream_iter = iter(stream)
    pg.readgrammar(stream_iter)
    assert next(stream_iter) == ""
    assert next(stream_iter, None) is None

    # Check
    pg.parse_rhs()

# Generated at 2022-06-23 15:59:27.660079
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    from . import grammar
    pg = ParserGenerator()
    s = ["a", "b", "c", "d"]
    a, b, c, d = [NFAState() for i in s]
    for i, j in [(0, 1), (1, 2), (2, 3), (3, 3)]:
        a[i].addarc(j)
    start, finish = pg.make_dfa(a, d)
    assert len(start.arcs) == 2
    assert start.arcs["a"] is finish.arcs["a"]
    assert start.arcs["b"] is finish.arcs["b"]
    assert len(finish.arcs) == 2
    assert finish.arcs["c"] is finish.arcs["d"]

# Generated at 2022-06-23 15:59:35.057311
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    pyc = b"\x03\xf3\r\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x04\x00\x00\x00\x0b\x00\x00\x00\x00\x00\x00\x00"
    pickle.loads(pyc)


# Generated at 2022-06-23 15:59:40.640702
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    pg = ParserGenerator(grammar.pgen_grammar)
    lines = grammar.pgen_grammar.split("\n")
    pg.parse_grammar(lines)
    rules = pg.dfas
    pg.dump_nfa("type_ignore", rules["type_ignore"][0], rules["type_ignore"][-1])
    pg.dump_nfa("varargslist", rules["varargslist"][0], rules["varargslist"][-1])
    pg.dump_nfa("dotted_as_name", rules["dotted_as_name"][0], rules["dotted_as_name"][-1])



# Generated at 2022-06-23 15:59:46.420910
# Unit test for method addarc of class DFAState
def test_DFAState_addarc():
    a = DFAState({}, NFAState())
    b = DFAState({}, NFAState())
    a.addarc(b, "foo")
    assert a.arcs == {"foo": b}
    a.addarc(b, "bar")
    assert a.arcs == {"foo": b, "bar": b}
    c = DFAState({}, NFAState())
    a.addarc(c, "baz")
    assert a.arcs == {"foo": b, "bar": b, "baz": c}

# Generated at 2022-06-23 15:59:53.567726
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    input = "a |"
    expected = f"""\
    (NFAState)
    (NFAState)
    """
    pg = ParserGenerator()
    pg.setup_generator('from_str', input)
    a, z = pg.parse_alt()
    if str([a, z]) != expected:
        print("%r != %r" % (str([a, z]), expected))
        raise RuntimeError("test failed")
    pg.close_generator("test")

# Generated at 2022-06-23 15:59:55.821130
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    r = ParserGenerator()
    r.make_grammar()

# Generated at 2022-06-23 16:00:06.955771
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    def run(grammar: str, items: str) -> None:
        name2dfa = ParserGenerator(grammar).dfas
        name2dfa = dict(sorted(name2dfa.items()))
        for item in items.split():
            if item in name2dfa:
                dfa = name2dfa[item]
            else:
                assert item[0] != item[-1]
                if item[0] == "'":
                    token = tokenize.STRING
                else:
                    token = tokenize.NAME
                dfa = ParserGenerator.ParserGenerator(item).dfas[item[1:-1]]
            if dfa[0].arcs:
                assert dfa[0].arcs[0][0] is None  # should be empty
            dfa[0].arcs

# Generated at 2022-06-23 16:00:15.163832
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():
    d1 = DFAState({}, None)
    d2 = DFAState({}, None)
    d3 = DFAState({}, None)
    d1.addarc(d2, "a")
    d1.addarc(d2, "b")
    d1.addarc(d3, "c")
    d1.unifystate(d2, d3)
    assert d1.arcs == {"a": d3, "b": d3, "c": d3}



# Generated at 2022-06-23 16:00:24.217896
# Unit test for method addarc of class DFAState
def test_DFAState_addarc():
    st0 = DFAState({NFAState(): 1}, NFAState())
    st1 = DFAState({NFAState(): 1}, NFAState())
    st2 = DFAState({NFAState(): 1}, NFAState())
    st0.addarc(st1, "0")
    assert st0.arcs == {"0": st1}
    st0.addarc(st2, "1")
    assert st0.arcs == {"0": st1, "1": st2}
    try:
        st0.addarc(st1, "1")
        assert False, "should raise ValueError"
    except ValueError:
        pass



# Generated at 2022-06-23 16:00:25.882095
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    parsergen = ParserGenerator()
    parsergen.dump_nfa("foo", None, None)


# Generated at 2022-06-23 16:00:37.626683
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    pg = ParserGenerator()

# Generated at 2022-06-23 16:00:39.896880
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    pgen = ParserGenerator()
    grammar = pgen.parse()

# Generated at 2022-06-23 16:00:47.331902
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():
    s0 = DFAState({}, None)
    s1 = DFAState({}, None)
    s2 = DFAState({}, None)
    s0.addarc(s1, 'label0')
    s0.addarc(s2, 'label1')
    s1.addarc(s0, 'label2')
    s2.addarc(s1, 'label3')
    s0.unifystate(s2, s1)
    assert s0.arcs['label1'] is s1
    assert s1.arcs['label2'] is s0
    assert s1.arcs['label3'] is s1



# Generated at 2022-06-23 16:00:49.057681
# Unit test for constructor of class NFAState
def test_NFAState():
    c = NFAState()
    c.addarc(c)
    return c



# Generated at 2022-06-23 16:00:52.769400
# Unit test for method __eq__ of class DFAState
def test_DFAState___eq__():
    s1 = DFAState({"nfaset": None}, "final")
    s2 = DFAState({"nfaset": None}, "final")
    s3 = DFAState({"nfaset": None}, "final")
    assert s1 != s2 and s2 != s3
    s2.addarc(s3, "label1")
    assert s1 != s2
    s1.addarc(s3, "label1")
    assert s1 == s2
    s1.addarc(s2, "label2")
    assert s1 != s2

test_DFAState___eq__()
test_DFAState___eq__ = None


# Generated at 2022-06-23 16:01:05.766346
# Unit test for method dump_dfa of class ParserGenerator

# Generated at 2022-06-23 16:01:12.510619
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    # Using a specific example
    text = """
expr: xor_expr ('|' xor_expr)*
xor_expr: and_expr ('^' and_expr)*
and_expr: shift_expr ('&' shift_expr)*
shift_expr: arith_expr (('<<'|'>>') arith_expr)*
arith_expr: term (('+'|'-') term)*
term: factor (('*'|'/'|'%') factor)*
factor: ('+'|'-'|'~') factor | power
power: atom trailer* ['**' factor]
atom: ('(' [yield_expr|testlist_comp] ')'
       | '[' [listmaker] ']'
       | '{' [dictorsetmaker] '}'
       | NAME | NUMBER | STRING+)
"""