

# Generated at 2022-06-23 15:51:13.788961
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    pg = ParserGenerator()


# Generated at 2022-06-23 15:51:19.439250
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    pg = ParserGenerator("", "")

# Generated at 2022-06-23 15:51:26.180258
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    pgen = ParserGenerator()
    text = '''\
            S: a
            T: "a"
            '''
    with open(TextIO(), "w") as f:
        f.write(text)
        f.seek(0)
        pgen.parse_grammar(f, "<string>")
    assert pgen.startsymbol == "S"
    pgen.addfirstsets()
    dfa = pgen.make_dfa(pgen.dfas["S"][0], pgen.dfas["S"][0])
    pgen.simplify_dfa(dfa)
    assert dfa == [DFAState({pgen.dfas["S"][0]: 1}, pgen.dfas["S"][0])]

# Generated at 2022-06-23 15:51:29.675132
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    import io
    import pgen2.parse
    import tokenize
    generator = pgen2.parse.ParserGenerator(io.StringIO(""))
    generator.expect(token.NAME)


# Generated at 2022-06-23 15:51:34.026005
# Unit test for function generate_grammar
def test_generate_grammar():
    # Check that the function runs w/o exception (for now)
    import doctest

    doctest.testmod(verbose=False)



# Generated at 2022-06-23 15:51:37.661438
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    pg = ParserGenerator()
    pg.write("file.py", "")

# Constructor for class DFAState

# Generated at 2022-06-23 15:51:43.669669
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():
    new = DFAState({}, NFAState())
    old = DFAState({}, NFAState())
    dfa = [DFAState({}, NFAState())]
    dfa[0].addarc(old, "")
    dfa[0].addarc(new, "")
    dfa[0].unifystate(old, new)
    assert dfa[0].arcs[""] is new



# Generated at 2022-06-23 15:51:49.569418
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    pg = ParserGenerator()
    pg.dfas = {
        "a": [DFAState({NFAState(): 1}, True)],
        "b": [DFAState({NFAState(): 1}, True)],
        "c": [DFAState({NFAState(): 1}, True)],
        "d": [DFAState({NFAState(): 1}, True)],
        "e": [DFAState({NFAState(): 1}, True)],
    }
    pg.first = {}
    pg.calcfirst("foo")

# Generated at 2022-06-23 15:52:00.748536
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    from . import python

    g = ParserGenerator(python.pgen_grammar.split('\n'), python.pgen_tokenize, python.pgen_symbols)

# Generated at 2022-06-23 15:52:10.185615
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():
    n1 = NFAState()
    n2 = NFAState()
    n3 = NFAState()
    s1 = DFAState({n1:1, n2:1}, n1)
    s2 = DFAState({n2:1, n3:1}, n3)
    s1.arcs["x"] = s2
    s1.arcs["y"] = s1
    s2.arcs["z"] = s1
    s1.unifystate(s2, s1)
    assert s1.arcs == {"x": s1, "y": s1, "z": s1}

# Generated at 2022-06-23 15:52:21.486242
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    # NOTE: THIS CODE HAS BEEN MODIFIED FROM ITS ORIGINAL FORM.
    #
    # In its original form (in Lib/py_compile.py), it failed when the
    # Python version was 3.0.  The grammar (in Lib/parser/Python.asdl)
    # has been modified to fix the problem.

    # This is really a unit test of ParserGenerator, not of Parser
    # itself.  But ParserGenerator is a fairly small standalone
    # object, and most of the work is done by the regular expression
    # engine, so this simple test suffices.
    pg = ParserGenerator()
    pg.add("file_input", ["NEWLINE", "stmt", "ENDMARKER"])
    pg.add("file_input", ["stmt", "ENDMARKER"])

# Generated at 2022-06-23 15:52:29.841932
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    # For now, just make sure it doesn't blow up
    import StringIO
    from . import pygram
    pg = ParserGenerator()
    pg.build_grammar(StringIO.StringIO(pygram.grammar))  # type: ignore
    for name, dfa in pg.dfas.items():
        pg.dump_nfa(name, dfa[0], dfa[-1])


# Generated at 2022-06-23 15:52:42.128851
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    print("Testing method make_dfa of class ParserGenerator")
    s0 = NFAState()
    s1 = NFAState()
    s2 = NFAState()
    s3 = NFAState()
    s4 = NFAState()
    s5 = NFAState()
    s6 = NFAState()
    s7 = NFAState()
    s8 = NFAState()
    s9 = NFAState()
    s0.addarc(s1, '(')
    s0.addarc(s7)
    s1.addarc(s2, 'x')
    s1.addarc(s4, 'y')
    s2.addarc(s3, ')')
    s3.addarc(s6)
    s4.addarc(s5, ';')


# Generated at 2022-06-23 15:52:49.967828
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    generator = ParserGenerator()
    generator.type = token.NAME
    generator.value = "a"
    generator.gettoken = lambda : None
    generator.parse_item = lambda : (1, 2)
    a, b = generator.parse_alt()
    assert a == 1 and b == 2
    generator.value = "|"
    generator.parse_item = lambda : (3, 4)
    a, b = generator.parse_alt()
    assert a != 1 and b == 2

# Generated at 2022-06-23 15:52:57.504643
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    '''
    Unit test for method parse of class ParserGenerator.
    '''

    # make a parser generator object
    p = ParserGenerator()

    # make a list of fake tokens
    fl = [
        (token.NAME, 'file_input'),
        (token.OP, ':'),
        (token.NAME, 'single_input'),
        (token.NEWLINE, ''),
        (token.OP, '|'),
        (token.NAME, 'eval_input'),
        (token.NEWLINE, ''),
        (token.ENDMARKER, '')
    ]

    # call the parse method with an appropriate sequence
    # of tokens
    print(p.parse(gettokens=iter(fl).__next__))

# Test the ParserGenerator class

# Generated at 2022-06-23 15:53:01.950338
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    """Method addfirstsets of class ParserGenerator"""
    print()
    # XXX Should instantiate a ParserGenerator and call its method addfirstsets
    print("XXX; test of method addfirstsets not implemented")



# Generated at 2022-06-23 15:53:07.071270
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    # Simple (non-regression) tests
    for code in (
        "1+1",
        "1+\n2",
    ):
        try:
            gen = grammar.ParserGenerator()
            nodes = gen.parse(code)
        except SyntaxError:
            pass
# Function test_ParserGenerator_raise_error


# Generated at 2022-06-23 15:53:12.852864
# Unit test for constructor of class NFAState
def test_NFAState():
    a = NFAState(); assert not a.arcs
    b = NFAState(); assert not b.arcs
    a.addarc(b); assert a.arcs == [("None", b)]
    a.addarc(b, "label"); assert a.arcs == [("None", b), ("label", b)]
    a.addarc(b, "label"); assert a.arcs == [("None", b), ("label", b), ("label", b)]



# Generated at 2022-06-23 15:53:23.044378
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():

    current_dir: Path = os.path.dirname(os.path.abspath(__file__))
    fname_grammar: Path = os.path.join(current_dir, "Grammar")

    pg = PgenGrammar()
    pg.load(fname_grammar)

    assert type(pg) == PgenGrammar
    assert isinstance(pg, grammar.Grammar)
    assert pg.p_accept == pg[0]
    assert pg.p_accept.type == token.ENDMARKER

    assert pg.p_file_input == pg[1]
    assert pg.p_file_input.type == token.NEWLINE

    assert pg.p_eval_input == pg[2]
    assert pg.p_eval_input.type == token.NAME

    assert pg.p

# Generated at 2022-06-23 15:53:34.031478
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    # XXX Should be a unit test, not a function
    p = ParserGenerator()
    p.add_dfa('first', '"a" "b" | "c" "d"')
    a = NFAState()
    b = NFAState()
    c = NFAState()
    d = NFAState()
    a.addarc(b, "a")
    a.addarc(c, "c")
    b.addarc(d, "b")
    c.addarc(d, "d")
    p.dump_nfa("test", a, d)



# Generated at 2022-06-23 15:53:39.900979
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():
    s = DFAState({}, NFAState())
    s.addarc(s)
    s.unifystate(s, s)
    assert s.arcs == {None: s}

NFAState_instances: Dict[int, NFAState] = {}
DFAState_instances: Dict[int, DFAState] = {}

# Code for NFAState and DFAState instances

# Generated at 2022-06-23 15:53:52.382504
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():
    class DFAStateTest(DFAState):
        def __init__(self, nfaset, final):
            super().__init__(nfaset, final)
            self.called = False

        def unifystate(self, old, new):
            self.called = True
            self.old = old
            self.new = new
            super().unifystate(old, new)


# Generated at 2022-06-23 15:54:01.153566
# Unit test for method __eq__ of class DFAState
def test_DFAState___eq__():
    assert DFAState(
        {NFAState(): 1},
        NFAState()
    ) == DFAState({NFAState(): 1}, NFAState())
    assert DFAState(
        {NFAState(): 1},
        NFAState()
    ) != DFAState({NFAState(): 2}, NFAState())
    a, b = NFAState(), NFAState()
    assert DFAState({a: 1}, b) != DFAState({NFAState(): 1}, b)
    assert DFAState({a: 1}, b) != DFAState({a: 1}, NFAState())

# Generated at 2022-06-23 15:54:10.439067
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    lines = """
    expr: x ('+' x)*
    x: '(' expr ')' | NAME
    """.split("\n")

    def lines_iter() -> Iterator[Tuple[str]]:
        for line in lines:
            yield line,

    pg = ParserGenerator()

    # find start symbol
    start = "expr"

    # Build an NFA for each rule.
    pg.dfas = {}  # type: Dict[Text, Any]
    pg.first = {}  # type: Dict[Text, Set[Text]]
    pg.make_parser(start, lines_iter(), "<test>")
    pg.addfirstsets()

    for name, dfa in pg.dfas.items():
        pg.dump_nfa(name, dfa[0], dfa[-1])


# Generated at 2022-06-23 15:54:11.876367
# Unit test for constructor of class NFAState
def test_NFAState():
    s = NFAState()
    assert s.arcs == []



# Generated at 2022-06-23 15:54:19.261913
# Unit test for method parse of class ParserGenerator

# Generated at 2022-06-23 15:54:22.458970
# Unit test for method addarc of class DFAState
def test_DFAState_addarc():
    _: Any = DFAState({}, object())
    _.addarc(object, "")
    _.addarc(object, "")



# Generated at 2022-06-23 15:54:26.679132
# Unit test for constructor of class DFAState
def test_DFAState():
    x = NFAState()
    y = NFAState()
    z = NFAState()
    d = DFAState({x: 1, y: 1}, z)
    assert d.nfaset == {x: 1, y: 1}
    assert d.isfinal == True
    try:
        d.nfaset = {}
    except:
        pass
    else:
        assert 0, "DFAState.nfaset was not read-only"
    d.addarc(d, "a")
    assert d.arcs == {"a": d}
    d.unifystate(d, y)
    assert d.arcs == {"a": y}
    try:
        d.addarc(z, d)
    except:
        pass

# Generated at 2022-06-23 15:54:30.112990
# Unit test for constructor of class NFAState
def test_NFAState():
    a = NFAState()
    b = NFAState()
    c = NFAState()
    assert len(a.arcs) == 0
    a.addarc(b, 'label')
    a.addarc(c)
    assert len(a.arcs) == 2
    assert a.arcs[0] == ('label', b)
    assert a.arcs[1] == (None, c)


# Generated at 2022-06-23 15:54:34.405380
# Unit test for constructor of class DFAState
def test_DFAState():
    # Test construction and basic methods.
    nfa0 = NFAState()
    nfa1 = NFAState()
    nfa2 = NFAState()
    dfa0 = DFAState({nfa0: 1}, nfa1)
    assert not dfa0.isfinal
    dfa1 = DFAState({nfa1: 1}, nfa1)
    assert dfa1.isfinal
    dfa2 = DFAState({nfa2: 1}, nfa2)
    dfa0.addarc(dfa1, "abc")
    assert dfa0.arcs["abc"] is dfa1
    dfa0.addarc(dfa2, "def")
    assert dfa0.arcs["def"] is dfa2
    dfa0.unifystate(dfa2, dfa1)

# Generated at 2022-06-23 15:54:43.092994
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    import re
    import pgen2.tokenize
    import pprint
    import sys
    import os

    def dfa2str(dfa):
        res = []
        for i, state in enumerate(dfa):
            if state.isfinal:
                res.append("State %s (final)" % i)
            else:
                res.append("State %s" % i)
            for label, next in state.arcs.items():
                res.append("  %s -> %s" % (label, dfa.index(next)))
        return "\n".join(res)

    def parse_grammar(src):
        gen = ParserGenerator()
        # TODO: We could use tokenize2.tokenize here, but that
        # currently fails to find all tokens in the grammar (e.g., it


# Generated at 2022-06-23 15:54:55.097283
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    from . import pygram
    from .pgen2 import token

    def make_first(k: Text) -> Text:
        d: Dict[int, Any] = {}
        for i in pygram.dfas[k].first:
            if i is not None:
                d[i] = 1
        return d

    for k, v in pygram.symbol2number.items():
        t = make_first(k)
        assert t == pygram.first[k]
        if t is not None:
            assert len(t) <= len(pygram.dfas[k]), (k, len(t), len(pygram.dfas[k]))
    # Just one totally ad hoc check to guard against a stupid mistake.
    assert token.NAME in pygram.first["atom"]


# Generated at 2022-06-23 15:55:03.682465
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    from pypy.interpreter.pyparser import ParserGenerator
    from pypy.interpreter.pyparser.pythonutil import stderr_write
    pgen = ParserGenerator(stderr_write)

# Generated at 2022-06-23 15:55:14.736779
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    import io
    from tokenize import tokenize as tokenizer
    from typing import Iterator, NamedTuple
    from token import TokenInfo

    class Token(NamedTuple):
        type: int
        value: Text
        begin: Tuple[int, int]
        end: Tuple[int, int]
        line: Text

    def new_tokens(text: Text) -> Iterator[TokenInfo]:
        data = io.StringIO(text)
        gen = tokenizer(data.readline)
        while True:
            try:
                tok = next(gen)
            except StopIteration:
                return
            yield Token(*tok)
    # test 1
    gen = ParserGenerator()
    gen.filename = "test"
    gen.line = "foo"
    gen.generator = new_

# Generated at 2022-06-23 15:55:19.446770
# Unit test for constructor of class NFAState
def test_NFAState():
    n = NFAState()
    assert n.arcs == [], n.arcs
    n.addarc(NFAState())
    n.addarc(NFAState(), 'a')
    n.addarc(NFAState(), 'b')
    assert n.arcs == [(None, NFAState()), ('a', NFAState()), ('b', NFAState())], n.arcs


# Generated at 2022-06-23 15:55:24.990053
# Unit test for function generate_grammar
def test_generate_grammar():
    filename = "Grammar.txt"
    p = ParserGenerator(filename)
    return p.make_grammar()

if __name__ == "__main__":
    print(test_generate_grammar())

# Grammar.txt
# start: rule | rule NEWLINE rule
# rule: NAME ":" RHS
# RHS: RHS "|" ALT | ALT
# ALT: ALT ITEM | ITEM
# ITEM: ATOM ITEM | ATOM
# ATOM: "(" RHS ")" | "[" RHS "]" | NAME | STRING
# NEWLINE: "\n"
# NAME: "[a-zA-Z_][a-zA-Z0-9_]*"
# STRING: '"[^"]+"'
# RULE: "|"

# Generated at 2022-06-23 15:55:31.928442
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    pgen = ParserGenerator()
    pgen.make_label(None, '"for"')
    pgen.make_label(None, 'LBRACE')
    pgen.make_label(None, 'NAME')
    pgen.make_label(None, 'NEWLINE')
    pgen.make_label(None, 'NUMBER')
    pgen.make_label(None, 'RBRACE')
    pgen.make_label(None, 'if')
    pgen.make_label(None, 'import')

# Generated at 2022-06-23 15:55:43.008179
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    from . import literals, symbols
    from .grammar import NONTERMINAL, TERMINAL, OPTIONAL, STAR

    def nt(type: int, str: str) -> Tuple[int, Text]:
        return type, str

    def t(type: int, str: str) -> Tuple[int, Text]:
        return type, str


# Generated at 2022-06-23 15:55:54.867030
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():
    x11 = DFAState({}, None)
    x12 = DFAState({}, None)
    x13 = DFAState({}, None)
    x21 = DFAState({}, None)
    x22 = DFAState({}, None)
    x23 = DFAState({}, None)
    x31 = DFAState({}, None)
    x32 = DFAState({}, None)
    x33 = DFAState({}, None)
    x11.arcs = {1: x21, 2: x22}
    x12.arcs = {1: x22, 2: x23}
    x13.arcs = {1: x22, 2: x23}
    x21.arcs = {3: x31, 4: x32}

# Generated at 2022-06-23 15:56:05.621332
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    def check(source: Text, expected: Any) -> None:
        pg = ParserGenerator()
        result = pg.parse_item(tokenize.generate_tokens(StringIO(source).readline))
        assert result == expected, result
    yield from map(check, ['[foo]', '([a])', '(a|b)*', 'a*'])
    yield from map(check, ['[a]', '([a])', '([a|b])', '(a|b)', '(a|b)*', 'a*'])
    yield from map(check, ['(a|b)', '(a|b)*', 'a*'])

# Driver for module test
if __name__ == '__main__':
    import pytest
    import sys

# Generated at 2022-06-23 15:56:07.804893
# Unit test for method __eq__ of class DFAState
def test_DFAState___eq__():
    dfa1 = DFAState({}, None)
    dfa2 = DFAState({}, None)
    assert dfa1 == dfa2


# Generated at 2022-06-23 15:56:14.898004
# Unit test for function generate_grammar
def test_generate_grammar():
    grammar = generate_grammar()
    def verify(p):
        assert grammar.parse(p)
    verify("1 + 2")
    verify("1 + (2 + 3) + 4")
    verify("(1 + 2) * 3")
    verify("1 * 2 * 3")
    verify("(1 + 2) * (3 + 4)")
    verify("a = 3")
    verify("(a) = 3")
    verify("a = (3)")
    verify("a = (3 + 4)")
    verify("a = b = 3")
    verify("a = b = (c = 3)")
    verify("a, b, c = 1, 2, 3")
    verify("a, = 1")
    verify("a = 1, 2")
    verify("a = 1, 2 = 3, 4")
   

# Generated at 2022-06-23 15:56:26.944807
# Unit test for method make_dfa of class ParserGenerator

# Generated at 2022-06-23 15:56:29.762965
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    """Test the method parse_rhs of class ParserGenerator."""
    pg = ParserGenerator()
    # Does not raise SyntaxError
    pg._ParserGenerator__parse_rhs()

# Generated at 2022-06-23 15:56:35.206171
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():
    A = NFAState()
    B = NFAState()
    C = NFAState()
    a = DFAState({A: 1}, A)
    b = DFAState({B: 1}, B)
    c = DFAState({C: 1}, C)
    a.addarc(b, "a")
    a.addarc(c, "b")
    a.addarc(a, "c")
    a.unifystate(a, c)
    assert a.arcs == {"a": b, "b": c, "c": c}



# Generated at 2022-06-23 15:56:44.771115
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    g = ParserGenerator()

    # Test case 1: parse_item: empty input
    g.value = None
    with pytest.raises(SyntaxError):
        g.parse_item()

    # Test case 2: parse_item: no match for ITEM
    g.value = '"'
    with pytest.raises(SyntaxError):
        g.parse_item()

    # Test case 3: parse_item: match for '[' RHS ']'
    g.value = '['
    g.parse_item()

    # Test case 4: parse_item: match for NAME
    g.value = 'NAME'
    g.parse_item()

    # Test case 5: parse_item: match for STRING
    g.value = 'STRING'
    g.parse_item()


# Generated at 2022-06-23 15:56:55.673092
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    import pytest
    from _ast import Argument, keyword
    from _ast import Module, Expr, Name, Load, Call, Subscript, List, node_classes
    from _ast import parse
    from .tokenize import generate_tokens
    from . import token, cmp_op
    from .grammar import Grammar
    from .pgen2 import grammar, driver

    s = 'def f(x):\n    raise SyntaxError("syntax error", (1, 2, "msg"))'
    tree = parse(s)
    for node in tree.body:
        if isinstance(node, Expr):
            # expr_context, 0, Call
            node = node.value
            # expr_context, 0, Name, Load
            node = node.func
            node = node.id
            # print node, dir(node

# Generated at 2022-06-23 15:57:06.891309
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    import unittest
    import io

    class Tests(unittest.TestCase):
        def test_empty_syntax(self):
            pg = ParserGenerator(("single", "", ""), ("", "", ""), "single")
            # empty start symbol
            with self.assertRaises(SyntaxError):
                pg.make_grammar("", {})
            # empty symbol table
            with self.assertRaises(SyntaxError):
                pg.make_grammar("simple", {})

        def test_simple_syntax(self):
            pg = ParserGenerator(("single", "", ""), ("", "", ""), "single")
            # valid grammar
            g = pg.make_grammar("simple", {"simple": "number"})

# Generated at 2022-06-23 15:57:15.458897
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    pgen = PgenGrammar(None)
    assert type(pgen) == PgenGrammar
    assert pgen.start == None
    assert pgen.dfas == {}
    assert pgen.num_dfas == 0
    assert pgen.states == []
    assert pgen.literals == {}
    assert pgen.keywords == {}
    assert pgen.symbol2label == {}
    assert pgen.tokens == []
    assert pgen.pats == []
    assert pgen.stmt_prefix == {}
    assert pgen.keyword_tokens == {}
    assert pgen.error_funcname == None
    assert pgen.symbol2number == {}
    assert pgen.number2symbol == []
    assert pgen.p_rules == []
    assert pgen.get

# Generated at 2022-06-23 15:57:27.155881
# Unit test for method parse_alt of class ParserGenerator

# Generated at 2022-06-23 15:57:32.025034
# Unit test for constructor of class NFAState
def test_NFAState():
    a = NFAState()
    b = NFAState()
    assert a.arcs == []
    assert b.arcs == []
    a.addarc(a)
    b.addarc(b, "a")
    assert a.arcs == [(None, a)]
    assert b.arcs == [("a", b)]



# Generated at 2022-06-23 15:57:41.101397
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():
    st1 = DFAState({}, NFAState())
    st2 = DFAState({}, NFAState())
    st3 = DFAState({}, NFAState())
    st1.arcs = {'a': st2, 'b': st3}
    st2.arcs = {'c': st2}
    st3.arcs = {'d': st1}
    st1.unifystate(st2, st3)
    assert st1.arcs == {'a': st3, 'b': st3}, st1.arcs
    assert st2.arcs == {'c': st3}, st2.arcs
    assert st3.arcs == {'d': st1, 'c': st2}, st3.arcs



# Generated at 2022-06-23 15:57:48.144529
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    test_grammar = """\
        expr:
            x='(' y=expr ')' {3}
          | x=NAME {1}
          | x=NUMBER {2};

        NAME: "[a-zA-Z][a-zA-Z0-9_]*";
        NUMBER: "[0-9]+";
        """

    pg = ParserGenerator(test_grammar)
    dfas, start = pg.parse()
    assert dfas.keys() == {'expr', 'NAME', 'NUMBER'}
    assert start == 'expr'

    expr = dfas['expr']
    assert {state.isfinal for state in expr} == {False, True}
    nfinal = sum(state.isfinal for state in expr)
    assert nfinal == 2

    assert expr[0].isfinal == False

# Generated at 2022-06-23 15:57:51.145322
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    pg = PgenGrammar(b'', {}, b'', [])
    assert isinstance(pg, grammar.Grammar)


# Generated at 2022-06-23 15:58:01.311947
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    fout = open(StringIO(), 'wb')
    pg = ParserGenerator('file', StringIO(), 'string')
    grammar = pg.make_grammar()


if __name__ == "__main__":
    import sys

    if len(sys.argv) == 1:
        # print __doc__
        sys.exit(2)
    elif len(sys.argv) > 2:
        print("usage: parser.py [FILE]")
        sys.exit(2)
    filename = sys.argv[1]

    if filename == "-":
        fin = sys.stdin
        fout = sys.stdout
        filename = "stdin"
    else:
        fin = open(filename, "rb")
        fout = open(filename + ".pickle", "wb")
        fout.write

# Generated at 2022-06-23 15:58:12.189845
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    from . import tokenize
    from . import grammar
    import types
    import token
    test_ParserGenerator_parse_rhs.__annotations__["return"] = lambda: types.FunctionType
    p = ParserGenerator()
    x = p.parse_rhs()
    x = p.parse_rhs()
    x = p.parse_rhs()
    x = p.parse_rhs()
    x = p.parse_rhs()
    x = p.parse_rhs()
    x = p.parse_rhs()
    x = p.parse_rhs()

# Generated at 2022-06-23 15:58:19.502517
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    pg = ParserGenerator()
    pg.gettoken()
    assert pg.type == token.ENDMARKER, pg.type
    pg.generator = [
        (token.STRING, "foo", (1, 0), (1, 3), "foo"),
        (token.ENDMARKER, "", (2, 0), (2, 0), ""),
    ]
    pg.gettoken()
    assert pg.type == token.STRING, pg.type
    assert pg.value == "foo", pg.value
    pg.gettoken()
    assert pg.type == token.ENDMARKER, pg.type



# Generated at 2022-06-23 15:58:26.992401
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    pg = ParserGenerator()

# Generated at 2022-06-23 15:58:34.291133
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    pgen = ParserGenerator()
    pgen.gettoken = mock.Mock()
    pgen.gettoken.return_value = tokenize.NAME, "foo"
    pgen.raise_error = mock.Mock(side_effect=RuntimeError)
    assert pgen.expect(token.NAME) == "foo"
    pgen.gettoken.assert_called_once_with()
    pgen.gettoken.reset_mock()
    pgen.raise_error.reset_mock()
    assert pgen.expect(token.NAME) == "foo"
    assert pgen.raise_error.call_args


# Generated at 2022-06-23 15:58:37.628151
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    test_dict = {"a": 1, "b": 2}
    assert ParserGenerator.calcfirst(test_dict, "a", "b") == {"b": 2}
    assert test_dict == {"a": 1, "b": 2}


if __name__ == "__main__":
    unittest.main()

# Generated at 2022-06-23 15:58:38.574606
# Unit test for constructor of class NFAState
def test_NFAState():
    s = NFAState()


# Generated at 2022-06-23 15:58:46.087918
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    g = ParserGenerator()
    s = """
# comment
# comment
NAME: 'a'+ 'b'*
NUMBER: '0'+
STRING: '"' (NAME | NUMBER)* '"'
"""
    dfas, startsymbol = g.parse_grammar(s)
    assert startsymbol == "NAME"
    assert set(dfas.keys()) == set(["NAME", "NUMBER", "STRING"])



# Generated at 2022-06-23 15:58:50.219638
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    pg = ParserGenerator()
    e = None
    try:
        pg.raise_error('%s/%s', 'foo', 'bar')
    except SyntaxError as e_:
        e = e_
    assert e.args[0] == 'foo/bar'



# Generated at 2022-06-23 15:59:02.003945
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    p = ParserGenerator()
    a = NFAState()
    b = NFAState()
    c = NFAState()
    a.addarc(b, "a")
    a.addarc(c, "a")
    b.addarc(c, "b")
    dfa = p.make_dfa(a, c)

    assert len(dfa[0].arcs) == 1
    assert dfa[0].arcs[{"a": 1}] is dfa[2]
    assert dfa[2].arcs == {"b": dfa[1]}
    assert dfa[1].arcs == {"a": dfa[1]}
    assert dfa[0] == dfa[2]
    assert dfa[0] != dfa[1]



# Generated at 2022-06-23 15:59:06.737905
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    s = ParserGenerator(
        "grammar: rule1 rule2 rule3 ;"
        "rule1: STRING ;"
        "rule2: NAME ;"
        "rule3: STRING | NAME ;"
    )
    assert s.parse_item() == s.parse_item()
    assert s.parse_item() != s.parse_item()


# Generated at 2022-06-23 15:59:15.735957
# Unit test for method addarc of class DFAState
def test_DFAState_addarc():
    state1 = DFAState({None: 1}, None)
    state2 = DFAState({None: 1}, None)
    state1.addarc(state1, '(NAME)')
    assert state1.arcs == {'(NAME)': state1}
    try:
        state1.addarc(state2, '(NAME)')
    except AssertionError:
        pass
    else:
        assert False, "didn't detect duplicate label"
    try:
        state1.addarc(None, '(NAME)')
    except AssertionError:
        pass
    else:
        assert False, "didn't detect wrong type of DFAState instance"

# Generated at 2022-06-23 15:59:25.776851
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():
    a = DFAState({}, None)
    b = DFAState({}, None)
    c = DFAState({}, None)
    d = DFAState({}, None)
    a.addarc(b, "label")
    a.addarc(c, "label")
    a.addarc(d, "label")
    assert a.arcs == {"label": b}
    DFAState.unifystate(a, b, c)
    assert a.arcs == {"label": c}
    DFAState.unifystate(a, c, d)
    assert a.arcs == {"label": d}
    assert a.isfinal is False
    d.isfinal = True
    assert a.isfinal is True


# Generated at 2022-06-23 15:59:38.241804
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    import doctest
    import parser

    doctest.testmod(common.token, optionflags=doctest.IGNORE_EXCEPTION_DETAIL)
    doctest.testmod(parser, optionflags=doctest.IGNORE_EXCEPTION_DETAIL)

    class TestCase(unittest.TestCase):
        def test_parse_item(self):
            import io
            import tokenize

            s = io.StringIO("")
            p = parser.ParserGenerator(tokenize.tokenize(s.readline), '<string>')

            p.type = token.NAME
            p.value = "NAME"
            a, z = p.parse_item()
            self.assertEqual(a, NFAState())
            self.assertEqual(z, NFAState())
            self.assertE

# Generated at 2022-06-23 15:59:43.531081
# Unit test for constructor of class DFAState
def test_DFAState():
    a = NFAState()
    b = NFAState()
    c = NFAState()

    d = DFAState({a: 1, b: 1}, c)
    assert d.nfaset == {a: 1, b: 1}
    assert d.isfinal
    assert d.arcs == {}
    assert hash(d) == hash((a, b, c))



# Generated at 2022-06-23 15:59:54.495087
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    from unittest import mock

    def gettoken(self):
        tup = self.tokens.pop()
        self.type, self.value, self.begin, self.end, self.line = tup
    ParserGenerator.gettoken = gettoken
    pg = ParserGenerator("", "")
    pg.type, pg.value, pg.begin, pg.end, pg.line = (
        token.NAME, "obj", (1, 2), (1, 5), "obj"
    )
    pg.tokens = [(token.NAME, "obj", (1, 2), (1, 5), "obj")]
    pg.expect(token.NAME)

# Generated at 2022-06-23 16:00:01.639111
# Unit test for constructor of class NFAState
def test_NFAState():
    a = NFAState()
    b = NFAState()
    c = NFAState()
    d = NFAState()
    e = NFAState()
    f = NFAState()
    a.addarc(b, 'b')
    b.addarc(e, 'e')
    c.addarc(d, 'd')
    c.addarc(e, 'e')
    f.addarc(a, 'a')
    f.addarc(c, 'c')
    assert a.arcs == [('b', b)]
    assert b.arcs == [('e', e)]
    assert c.arcs == [('d', d), ('e', e)]
    assert d.arcs == []
    assert e.arcs == []

# Generated at 2022-06-23 16:00:09.088717
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    a = NFAState()
    b = NFAState()
    c = NFAState()
    d = NFAState()
    e = NFAState()

    a.addarc(b, '"a"')
    b.addarc(c, '"b"')
    b.addarc(c, 'None')
    c.addarc(d, '"c"')
    c.addarc(d, 'None')
    d.addarc(c, 'None')
    d.addarc(e, '"d"')
    e.addarc(e, 'None')

    pg = ParserGenerator(name2tuple=lambda s: (s, s))
    pg.dfas["test_dfa"] = pg.make_dfa(a, e)

# Generated at 2022-06-23 16:00:20.891095
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    # What we parse, what we should find
    # Right now, we only test the first NFA state
    tests = [
        (
            "a : 'abc'\n",
            # test_ParserGenerator_make_dfa
            {"a": [DFAState({0: 1, 1: 1}, None)]},
        ),
        (
            "a : 'ab' 'c'\n",
            # test_ParserGenerator_make_dfa
            {"a": [DFAState({0: 1, 2: 1}, None)]},
        ),
        (
            "a : 'a' | 'ab'\n",
            # test_ParserGenerator_make_dfa
            {"a": [DFAState({0: 1}, None), DFAState({1: 1}, None)]},
        ),
    ]


# Generated at 2022-06-23 16:00:30.103531
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    states = [
        DFAState({"a", "b"}, False),
        DFAState({"c", "d"}, False),
        DFAState({"a", "b"}, False),
        DFAState({"c", "d"}, True),
        DFAState({"a", "b"}, False),
        DFAState({"c", "d"}, False),
    ]
    states[0].addarc(states[1], "x")
    states[0].addarc(states[2], "y")
    states[2].addarc(states[3], "x")
    states[2].addarc(states[4], "y")
    states[4].addarc(states[5], "x")
    states[4].addarc(states[1], "y")

# Generated at 2022-06-23 16:00:39.642840
# Unit test for function generate_grammar

# Generated at 2022-06-23 16:00:49.479200
# Unit test for method __eq__ of class DFAState
def test_DFAState___eq__():
    import pickle
    s1 = DFAState({1:'a'}, 2)
    s2 = DFAState({}, 2)
    s3 = DFAState({1:'a'}, 2)
    s4 = DFAState({1:'a'}, 3)
    s5 = DFAState({1:'a', 2:'b'}, 2)
    s6 = DFAState({1:'a'}, 2)
    s6.isfinal = False
    s7 = DFAState({1:'a'}, 2)
    assert not (s1 == s2)
    assert s1 == s3
    assert not (s1 == s4)
    assert not (s1 == s5)
    assert not (s1 == s6)
    assert not (s6 == s7)

# Generated at 2022-06-23 16:00:55.522280
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    a = NFAState()
    b = NFAState()
    c = NFAState()
    d = NFAState()
    a.addarc(b, "a")
    a.addarc(c, "a")
    b.addarc(d, "b")
    c.addarc(d, "c")

    dfa = ParserGenerator([]).make_dfa(a, d)
    assert len(dfa) == 5
    bb = dfa[0].arcs["a"][0]
    dd = dfa[1].arcs["b"][0]
    cc = dfa[3].arcs["a"][0].arcs["c"][0]
    assert bb is dd
    assert dd is cc

# Generated at 2022-06-23 16:01:07.453404
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    # setup
    pg = ParserGenerator()
    # act
    pg.make_grammar('''
    start: "a" dict[start] NEWLINE
    dict[start]: "[" dict_item[start] ("," dict_item[start]) * "]"
    dict_item[start]: str_or_id ":" sum
    sum : product (("+"|"-") product)*
    product: power (("*"|"/") power)*
    power: atom ("**" power)?
    atom: "(" sum ")" | name | number | str | "None" | "True" | "False"
    ''')
    # assert

# Generated at 2022-06-23 16:01:19.937106
# Unit test for method parse_alt of class ParserGenerator