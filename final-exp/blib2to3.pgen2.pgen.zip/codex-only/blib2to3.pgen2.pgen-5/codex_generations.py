

# Generated at 2022-06-23 15:51:18.167787
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    # XXX Could use better test cases
    pg = ParserGenerator({})

# Generated at 2022-06-23 15:51:22.852534
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    import sys
    import pytest
    from io import StringIO
    from test.test_grammar import get_parser_generator
    expected_msg = '''expected (...), got (1, 42)'''
    parent = get_parser_generator('test1')
    pg = parent._parser_generator
    fake_tokens = [(1, '', (0, 0), (1, 42), '')]
    pg.generator = iter(fake_tokens)
    pg.type = pg.value = 1
    pg.begin = (0, 0)
    pg.end = (1, 42)
    pg.line = ''
    sio = StringIO()
    actual_msg = ''

# Generated at 2022-06-23 15:51:29.753977
# Unit test for method __eq__ of class DFAState
def test_DFAState___eq__():
    for _ in range(100):
        s1 = DFAState({}, None)
        s2 = DFAState({}, None)
        assert s1 == s2
        s1.isfinal = True
        assert s1 != s2
        s1.isfinal = False
        s1.arcs["q"] = s1
        assert s1 != s2
        s2.arcs["q"] = s2
        assert s1 == s2



# Generated at 2022-06-23 15:51:32.252241
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    pg = ParserGenerator()
    pg.make_parser()
    pg.dump_nfa("single_input", pg.dfas["single_input"][0], pg.dfas["single_input"][-1])


# Generated at 2022-06-23 15:51:39.852140
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    import io
    import tokenize
    pg = ParserGenerator()
    with open("Parser/Grammar.txt") as fd:
        pg.setup_input(fd, "Parser/Grammar.txt")
        pg.gettoken()
        rhs_root = pg.parse_rhs()
        pg.expect(token.ENDMARKER)
    pg.dump_nfa("File_input", rhs_root[0], rhs_root[1])


# Generated at 2022-06-23 15:51:45.275311
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    pg = ParserGenerator()
    try:
        pg.raise_error("Error")
    except SyntaxError as e:
        assert e.args[0] == "Error"
        # line number starts with 1.
        assert e.args[1] == (None, 1, 0, "")
    else:
        raise RuntimeError("Did not raise")

# Generated at 2022-06-23 15:51:48.108779
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    # ParserGenerator.dump_dfa(self: ParserGenerator, name: Text, dfa: Sequence[DFAState]) -> None
    # Dump of DFA for single_input
    assert 1 == 1


# Generated at 2022-06-23 15:51:52.050346
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():

    import io
    import tokenize

    testcase = r"""
x: 'x'
"""

    pgen = ParserGenerator()
    tokens = list(tokenize.generate_tokens(io.StringIO(testcase).readline))
    pgen.setup(tokens)
    dfas, startsymbol = pgen.parse()
    for k in dfas:
        pgen.dump_dfa(k, dfas[k])


# Generated at 2022-06-23 15:52:04.400893
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    import io
    import tokenize
    instring = "    pass # comment\n"
    buf = io.StringIO(instring)
    parser = ParserGenerator()
    parser.generator = tokenize.generate_tokens(buf.readline)
    assert parser.gettoken() == None
    assert parser.gettoken() == None
    assert parser.gettoken() == None
    assert parser.gettoken() == None
    assert parser.type == token.ENDMARKER
    assert parser.value == ""


# Small test to show how it works

test1 = """
expr: term ('+'|'-') expr | term
term: factor ('*'|'/') term | factor
factor: '(' expr ')' | NAME | NUMBER | '-' factor
"""


# Generated at 2022-06-23 15:52:14.600735
# Unit test for method __eq__ of class DFAState
def test_DFAState___eq__():
    s1 = DFAState({1:1}, 2)
    s1.arcs = {'a': s1, 'b': s1}
    s2 = DFAState({1:1}, 2)
    s2.arcs = {'b': s2, 'a': s2}
    assert s1 == s2  # __eq__ not recursive
    s2.arcs = {'b': s2, 'a': s1}  # different
    assert s1 != s2  # __eq__ compares values of instance variables


##  Parser:
##

# Generated at 2022-06-23 15:52:15.631015
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    PgenGrammar()



# Generated at 2022-06-23 15:52:20.216170
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    r = ParserGenerator().make_first(
        PgenGrammar([], [], {}, {}, {}, 0, "", {}), "expr"
    )
    assert r == {3: 1, 4: 1, 5: 1, 6: 1, 7: 1, 32: 1}



# Generated at 2022-06-23 15:52:23.576675
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    pg = grammar.get_generator("Grammar")
    for k in ('dfas', 'first', 'startsymbol'):
        print("Generator attribute %s: %s" % (k, getattr(pg, k)))



# Generated at 2022-06-23 15:52:31.028721
# Unit test for method __eq__ of class DFAState
def test_DFAState___eq__():

    class Test(object):

        def __init__(self, arcs: Set[Tuple["DFAState", Any]]) -> None:
            self.arcs = arcs

        def __eq__(self, other: Any) -> bool:
            assert isinstance(other, Test)
            return self.arcs == other.arcs

    d_1_1 = DFAState({}, None)
    d_1_2 = DFAState({}, None)
    d_1_3 = DFAState({}, None)

    d_2_1 = DFAState({}, None)
    d_2_2 = DFAState({}, None)
    d_2_3 = DFAState({}, None)

    d_1_1.isfinal = True


# Generated at 2022-06-23 15:52:42.756249
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():
    one = DFAState({}, None)
    two = DFAState({}, None)
    one.addarc(one, "a")
    one.addarc(two, "b")
    one.addarc(two, "c")
    one.addarc(one, "d")
    one.unifystate(two, one)
    assert one.arcs == {"a": one, "b": one, "c": one, "d": one}


if __name__ == "__main__":
    test_DFAState_unifystate()


# print '\n'.join(['%s = %d' % sym for sym in c.labels])

# To test the parser, run it as a script on one or more grammar
# files.  The file name should be passed in a command line argument.
# If no

# Generated at 2022-06-23 15:52:47.703928
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():
    # This also tests __eq__ but can't call that method directly.

    def isequal(a: "DFAState", b: "DFAState") -> bool:
        return a == b

    assert not isequal(DFAState({1: 1}, 1), DFAState({2: None}, 2))
    assert not isequal(DFAState({1: 1}, 2), DFAState({1: 1}, 3))
    a = DFAState({1: 1}, 2)
    b = DFAState({2: None}, 3)
    a.addarc(b, "a")
    b.addarc(a, "b")
    assert not isequal(a, b)
    a.unifystate(b, a)
    assert isequal(a, a)
    assert len(a.arcs) == 2

# Generated at 2022-06-23 15:52:57.577693
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    """Test case for method make_dfa of class ParserGenerator."""
    pg = ParserGenerator()
    a, z = pg.parse_rhs()
    dfa = pg.make_dfa(a, z)
    assert isinstance(dfa, list)
    assert len(dfa) > 0
    for state in dfa:
        assert isinstance(state, DFAState)
        if state.nfaset == dfa[0].nfaset:
            assert state is dfa[0]
        assert isinstance(state.nfaset, dict)
        assert len(state.nfaset) > 0
        for nfastate in state.nfaset:
            assert isinstance(nfastate, NFAState)

# Generated at 2022-06-23 15:53:08.070926
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    if __debug__:
        pg = ParserGenerator("test", "single_input")
        assert pg.startsymbol == "single_input"
        assert len(pg.dfas) == 27
        assert len(pg.dfas["single_input"]) == 7
        assert len(pg.dfas["stmt"]) == 8
        assert len(pg.dfas["small_stmt"]) == 6

# Generated at 2022-06-23 15:53:12.754126
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    pg = ParserGenerator()
    it = iter([(token.OP, "["), (token.NAME, "expr"), (token.OP, "]")])
    pg.generator = it
    pg.gettoken()
    pg.parse_item()
    assert 0, "TODO"

# Generated at 2022-06-23 15:53:23.008765
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    # Verify that an exception of the correct type is raised.
    b = ParserGenerator("foo")
    from _ast import SyntaxError

    with pytest.raises(SyntaxError):
        b.raise_error("expected %s/%s, got %s/%s", "a", "b", "c", "d")
    with pytest.raises(SyntaxError) as e:
        b.raise_error("expected %s/%s, got %s/%s", "a", "b", "c", "d")

    assert e.match('expected a/b, got c/d')

# Generated at 2022-06-23 15:53:30.662233
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    import io
    import tokenize
    source = io.StringIO("""\
factor: atom ('*' atom)* ;
atom:   NAME
     |  NUMBER
     | '(' expr ')'
     ;
""")
    parser = ParserGenerator()
    parser.parse(tokenize.generate_tokens(source.readline))



# Generated at 2022-06-23 15:53:41.137222
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    def fmt(c):
        return (
            list(map(c.make_label, c.labels)),
            c.symbol2number,
            c.dfas,
            c.start,
        )

    c = ParserGenerator()
    c.symbol2number["NAME"] = 1
    c.symbol2number["NUMBER"] = 2
    c.symbol2number["STRING"] = 3
    c.symbol2number["LPAR"] = 4
    c.symbol2number["RPAR"] = 5
    c.symbol2number["value"] = 6
    c.symbol2number["atom"] = 7
    c.symbol2number["s"] = 8
    c.dfas["atom"] = [DFAState({}, False), DFAState({})]
    c.dfas

# Generated at 2022-06-23 15:53:54.108130
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    def check(s: str, expect: Tuple["NFAState", "NFAState"]) -> None:
        p = ParserGenerator(BytesIO(s.encode("utf-8")))
        result = p.parse_item()
        assert result == expect, (result, expect)

    check("(a)", (NFAState({NFAState([(None, NFAState())], 0)}, 0), NFAState()))
    check("(a)a", (NFAState({NFAState([(None, NFAState())], 0)}, 0), NFAState()))
    check("a", (NFAState(), NFAState([("a", NFAState())], 0)))
    check("a+", (NFAState(), NFAState([("a", NFAState())], 0)))

# Generated at 2022-06-23 15:54:05.687528
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    from tokenize import tokenize, untokenize
    from io import BytesIO

    def test(test_string):
        test_string = test_string.strip()
        f = BytesIO(test_string.encode("utf-8"))
        g = tokenize(f.readline)
        pg = ParserGenerator()
        pg.generator = g
        while True:
            try:
                pg.gettoken()
                if pg.type == token.ENDMARKER:
                    break
                print(
                    token.tok_name[pg.type], repr(pg.value), pg.begin, pg.end, repr(pg.line)
                )
            except:
                print("-" * 20)
                raise


# Generated at 2022-06-23 15:54:06.637299
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    pass


# Generated at 2022-06-23 15:54:10.512940
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    g = PgenGrammar()
    assert g._symbol2number == {}
    assert g._number2symbol == {}
    assert g._symbol2label == {}
    assert g._number2label == {}
    assert g._symbol2count == {}


# Generated at 2022-06-23 15:54:18.655882
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    pgen = ParserGenerator()
    nfa: List[NFAState] = []
    nfa.append(NFAState())
    nfa.append(NFAState())
    nfa.append(NFAState())
    nfa.append(NFAState())
    nfa.append(NFAState())
    nfa[0].addarc(nfa[1], "a")
    nfa[0].addarc(nfa[2], "b")
    nfa[2].addarc(nfa[3], "c")
    nfa[1].addarc(nfa[4])
    nfa[2].addarc(nfa[4])
    nfa[3].addarc(nfa[4])
    nfa[4].finish = True
    dfa = pgen.make_dfa

# Generated at 2022-06-23 15:54:29.700317
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    r"""Exhaustive unit test for method parse of class ParserGenerator
    (test all valid input, no invalid input).

    Written by Lib/test/test_grammar.py.
    """
    sg = ParserGenerator({"S": (("A", "B"), ("A", "B", "C"))}, "S")
    assert sg.states == [[[(1, 4), (2, 4)], [(1, 5), (2, 3)]], [[(1, 4)]], [[(2, 3)]]]
    assert sg.dfas == {0: ({0: 1, 1: 1, 2: 1}, {0: 1, 1: 1, 2: 1})}
    assert sg.start == 0


# Generated at 2022-06-23 15:54:41.050421
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    pg = ParserGenerator(debug=0)

    dfa = [
        DFAState({}, 0),
        DFAState({}, 0),
        DFAState({}, 1),
        DFAState({}, 0),
        DFAState({}, 1),
        DFAState({}, 1),
    ]
    dfa[0].addarc(dfa[1], "a")
    dfa[0].addarc(dfa[2], "b")
    dfa[0].addarc(dfa[3], "c")
    dfa[1].addarc(dfa[4], "d")
    dfa[1].addarc(dfa[5], "e")
    dfa[2].addarc(dfa[4], "d")

# Generated at 2022-06-23 15:54:49.002598
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    alta = NFAState()
    altz = NFAState()
    alta.addarc(NFAState(), "a")
    altz.addarc(NFAState(), "z")
    start = NFAState()
    finish = NFAState()
    start.addarc(alta)
    altz.addarc(finish)
    pg = ParserGenerator()
    dfa = pg.make_dfa(start, finish)
    assert not dfa[0].arcs
    assert not dfa[1].arcs
    assert not dfa[2].arcs
    assert dfa[2].isfinal
    assert dfa[3].arcs == {"a": [dfa[1]], "z": [dfa[2]]}
    assert dfa[3].isfinal

# Generated at 2022-06-23 15:54:55.121320
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    # Build a test parser
    pgen = ParserGenerator()

    a = pgen.make_state("a")
    b = pgen.make_state("b")
    c = pgen.make_state("c")
    d = pgen.make_state("d")
    e = pgen.make_state("e")
    f = pgen.make_state("f")
    g = pgen.make_state("g")

    # A -> B C
    a.addarc(b, "b")
    a.addarc(c, "c")

    # B -> e
    b.addarc(e, "e")

    # C -> d | f
    c.addarc(d, "d")
    c.addarc(f, "f")

    # D -> e | g
    d

# Generated at 2022-06-23 15:55:07.956605
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    c = ParserGenerator().convert()
    name2symbol = {}
    for symbol_number, (label_number, arrow) in enumerate(c.labels):
        if arrow is None:
            name = token.tok_name[label_number]
            name2symbol[name] = symbol_number
    # Check that the NAMES are all in the same order
    names = sorted(name2symbol)
    assert names == c.symbol_names, names
    for i, name in enumerate(names):
        assert name2symbol[name] == i, (name, name2symbol[name])
    # Check that the OPERATORS are all in the same order
    ops = sorted(c.keywords)
    assert ops == c.keyword_names, ops

# Generated at 2022-06-23 15:55:16.135333
# Unit test for function generate_grammar
def test_generate_grammar():
    g = generate_grammar()
    assert g.start is not None
    assert g.labels[g.start] == ("file_input", None)
    assert g.keywords["lambda"] == g.keywords["None"]
    assert g.keywords["None"] == g.keywords["True"]
    assert "True" in g.keywords
    assert "False" in g.keywords
    assert g.keywords["False"] == g.keywords["class"]
    assert g.keywords["class"] == g.keywords["except"]
    assert "lambda" in g.keywords
    assert len(g.dfas)
    # print(g.dfas.keys())
# For testing only -- generate python_parser.py.

# Generated at 2022-06-23 15:55:20.787889
# Unit test for method addarc of class NFAState
def test_NFAState_addarc():
    a = NFAState()
    b = NFAState()
    c = NFAState()
    a.addarc(b)
    a.addarc(b, c)
    assert a.arcs == [(None, b), (c, b)]

# Generated at 2022-06-23 15:55:21.740937
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    pg = ParserGenerator();

    pg.parse();
    return

# Generated at 2022-06-23 15:55:31.906116
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    pg = ParserGenerator()
    pg.dfas = {
        "foo": [DFAState(None, False), DFAState(None, True)],
        "bar": [DFAState(None, False), DFAState(None, True)],
        "baz": [DFAState(None, False), DFAState(None, True)],
    }
    pg.first = {"foo": {"a": 1, "b": 1, "c": 1}, "bar": {"a": 1, "c": 1}}
    c = pg.make_converter()
    assert c.symbol2number["foo"] == 0
    assert c.symbol2number["bar"] == 1
    assert c.symbol2number["baz"] == 2

# Generated at 2022-06-23 15:55:35.310297
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    """
    >>> g = PgenGrammar("grammar.txt")
    >>> g.start()
    'file_input'
    """
    pass



# Generated at 2022-06-23 15:55:42.514836
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    g = ParserGenerator(grammar, grammar.symbol2number, grammar.number2symbol)
    try:
        g.simplify_dfa([DFAState({1: 1}, 1), DFAState({0: 0, 1: 1}, 0), DFAState({0: 0}, 0)])
    except ValueError:
        pass
    else:
        assert False
    g.simplify_dfa([DFAState({1: 1}, 1), DFAState({0: 0}, 0)])


# Generated at 2022-06-23 15:55:51.609916
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    global ParserGenerator, NFAState

    pg = ParserGenerator()

    pg.type = 1
    pg.value = "("
    pg.gettoken = lambda: None
    assert pg.parse_atom() == (NFAState(), NFAState())

    pg.type = 1
    pg.value = "("
    pg.gettoken = lambda: None
    assert pg.parse_atom() == (NFAState(), NFAState())

    pg.type = token.NAME
    pg.value = "NAME"
    pg.gettoken = lambda: None
    assert pg.parse_atom() == (NFAState(), NFAState())

    pg.type = token.STRING
    pg.value = "STRING"
    pg.gettoken = lambda: None

# Generated at 2022-06-23 15:55:59.321758
# Unit test for constructor of class DFAState
def test_DFAState():
    a = NFAState()
    b = NFAState()
    c = NFAState()
    d = NFAState()
    a.addarc(b, "x")
    b.addarc(b, "y")
    b.addarc(c, None)
    d.addarc(a, None)
    assert a in d.nfaset
    assert b in d.nfaset
    assert c in d.nfaset
    assert d.isfinal


# Generated at 2022-06-23 15:56:01.329571
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    import tokenize, io
    g = ParserGenerator()
    g.parse_atom()



# Generated at 2022-06-23 15:56:11.792320
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    filename = os.path.join(os.path.dirname(__file__), "Grammar.txt")
    pg = ParserGenerator()
    pg.parse_file(filename)
    if __debug__:
        pg.dump_grammar()
    c = pg.convert()

# Generated at 2022-06-23 15:56:14.731698
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    # Instance of class PgenGrammar
    g = PgenGrammar()



# Generated at 2022-06-23 15:56:26.775280
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    pg = ParserGenerator()
    pg.first = {
        "test": {
            "NAME": 1,
            "STRING": 1,
            "NUMBER": 1,
            "break": 1,
            "continue": 1,
            "def": 1,
            "from": 1,
            "import": 1,
            "nonlocal": 1,
            "print": 1,
            "raise": 1,
            "return": 1,
            "yield": 1,
        }
    }
    c = pg.make_converter()
    assert isinstance(c, PgenGrammar)
    first = pg.make_first(c, "test")
    assert isinstance(first, dict)
    assert first[pg.make_label(c, "NAME")] == 1

# Generated at 2022-06-23 15:56:38.037872
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    import unittest

    class PGTest(unittest.TestCase):
        def setUp(self) -> None:
            # XXX verify that self.__class__.__name__ starts with 'test'
            self.maxDiff = None

        def check(self, pg: ParserGenerator) -> None:
            pg.addfirstsets()
            self.assertEqual(pg.dfas, pg.expected_dfas)
            self.assertEqual(pg.first, pg.expected_first)


# Generated at 2022-06-23 15:56:41.711510
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    pg = ParserGenerator()
    assert pg.filename == "<nothing>"
    pg = ParserGenerator(filename="output")
    assert pg.filename == "output"


# Generated at 2022-06-23 15:56:52.747001
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    p = ParserGenerator()
    p.filename, p.text = "<test_ParserGenerator_parse_item>", "[]"
    p.generator = tokenize.generate_tokens(io.StringIO(p.text).readline)
    p.gettoken()
    a, z = p.parse_item()
    assert a.arcs[0][0] is None and a.arcs[0][1] is z
    assert z.arcs == []
    p.filename, p.text = "<test_ParserGenerator_parse_item>", "[hello]"
    p.generator = tokenize.generate_tokens(io.StringIO(p.text).readline)
    p.gettoken()
    a, z = p.parse_item()

# Generated at 2022-06-23 15:56:54.487155
# Unit test for constructor of class NFAState
def test_NFAState():
    nfa_state = NFAState()
    assert nfa_state.arcs == []


# Generated at 2022-06-23 15:57:02.297533
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    pgen = ParserGenerator()

    ## The tokenizer doesn't seem to have a public API to get it to
    # report the beginning and ending offsets of each token, so we
    # have to reconstruct them from the line number and column number,
    # which is painful.
    def gen_tokens(code: Text) -> Iterable[Any]:
        old = pgen.generator
        pgen.generator = tokenize.tokenize(io.StringIO(code).readline)
        result = []
        tup = next(pgen.generator)
        source = tup[4] + '\n'
        lineno = tup[2][0]
        while tup[0] in (tokenize.COMMENT, tokenize.NL):
            tup = next(pgen.generator)
            source += t

# Generated at 2022-06-23 15:57:10.649049
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    # Check for ambiguity between NAME/KEYWORD
    pgen = ParserGenerator()
    pgen.tokens[token.NAME] = 4
    pgen.labels.append((token.NAME, None))
    pgen.keywords['KEYWORD'] = 5
    pgen.labels.append((token.NAME, 'KEYWORD'))
    # Check for ambiguity between NAME/opmap
    pgen.tokens[token.PLUS] = 6
    pgen.labels.append((token.PLUS, None))
    # Check for NAME that isn't a token
    pgen.labels.append((0, None))
    # Check for token that's not an NAME
    pgen.tokens[token.STRING] = 9
    pgen.labels.append((token.STRING, None))

# Generated at 2022-06-23 15:57:14.077882
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    pg = PgenGrammar(grammar.Grammar())
    assert isinstance(pg, grammar.Grammar)
    assert isinstance(pg, PgenGrammar)
    assert hasattr(pg, 'start')
    assert hasattr(pg, 'symbol2number')


# Generated at 2022-06-23 15:57:23.994352
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    rg = ParserGenerator(
        {
            "a": [
                [[None, "a"], [None, "b"], [None, "c"]],
                [[None, "d"], [None, "e"], [None, "f"]],
            ],
            "b": [[[None, "e"], [None, "g"]]],
            "c": [[[None, "b"], [None, "c"]]],
        },
        "a",
    )
    rg.addfirstsets()
    assert rg.first == {
        "a": {"a": 1, "d": 1},
        "b": {"e": 1, "g": 1},
        "c": {"b": 1},
    }



# Generated at 2022-06-23 15:57:34.042269
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    import sys
    import pickle


# Generated at 2022-06-23 15:57:39.971517
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    pg = ParserGenerator(test_data_1)
    pg.gettoken() # 'name of first definition'
    name = pg.expect(token.NAME)
    pg.expect(token.OP, ":")
    rhs = pg.parse_rhs()
    pg.expect(token.NEWLINE)
    assert name == 'expr'
    

# Generated at 2022-06-23 15:57:46.542158
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():

  class _TestParserGenerator_dump_nfa:
    "Test ParserGenerator.dump_nfa"

    class _Parser:
      "Parser for function test_ParserGenerator_dump_nfa"
      grammar = r"""
        start:
          | start a
        a:
          | 'a'
      """

    def run(self):
      "Run the test."
      gen = ParserGenerator(self._Parser, "start")
      gen.dump_nfa("start", gen.dfas["start"][0], gen.dfas["start"][-1])
  _TestParserGenerator_dump_nfa().run()

# Generated at 2022-06-23 15:57:58.908318
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    filename = os.path.join(
        os.path.dirname(os.path.abspath(__file__)), "ParserGenerator_dump_nfa.txt"
    )
    with open(filename, "rb") as f:
        pg = ParserGenerator(f.readline)
        dfas, startsymbol = pg.parse()

    print("Start symbol:", startsymbol)
    for name, dfa in sorted(dfas.items()):
        print(name)
        for state in dfa:
            print(" ", state.isfinal and "final" or "notfinal", state.arcs)

    print("LALR item sets:")
    states = LALRGenerator(dfas, startsymbol).make_parse_table()
    for state in states:
        state.show()

   

# Generated at 2022-06-23 15:58:05.238413
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    from . import nfa

    nfa.test_nfa()


if __name__ == "__main__":
    import doctest

    doctest.testmod()


#   The following classes are used to create the DFA out of an NFA
#   and to do the simulation of the DFA to reduce states.  The big
#   idea here is that a DFA state corresponds to a set of NFA states,
#   and each arc in the DFA is labeled with a symbol set (strings
#   that can follow that arc).  Since there is only a finite number
#   of NFA states, there are only a finite number of DFA states, but
#   since that number may be very large, we want to combine states
#   that are equivalent.  We do this by the standard algorithm of
#   creating the DFA, then trying to combine states

# Generated at 2022-06-23 15:58:09.589385
# Unit test for method addarc of class DFAState
def test_DFAState_addarc():
    state1 = DFAState({}, None)
    state2 = DFAState({}, None)
    state1.addarc(state2, None)
    assert state1.arcs == {None: state2}



# Generated at 2022-06-23 15:58:18.709784
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    import pgen.pgen

    generator = pgen.pgen.ParserGenerator()
    parser = ParserGenerator(generator)

    # Each test case is a list of tokens, the last one must be newline.
    testcases = [
        ((token.STRING, "a"),),
        ((token.NAME, "a"),),
        ((token.OP, "(", "(", "[", "*", "Rule", "|", "a", "]", ")", ")"),),
        ((token.OP, "[", "Rule", "|", "a", "]",),),
        ((token.OP, "(", "*", "Rule", ")",),),
    ]

    for tokens in testcases:
        parser.filename = "testcases.txt"
        parser.generator = iter(tokens)
        parser.get

# Generated at 2022-06-23 15:58:26.444573
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    from io import StringIO
    from tokenize import generate_tokens

    def parse_generator(text: str) -> Generator[Tuple[int, Text, Text, Text], None, None]:
        # Parse an operator -- designed for use with a generator
        for tup in generate_tokens(StringIO(text).readline):
            if tup[0] not in (tokenize.NEWLINE, tokenize.COMMENT):
                yield tup
        yield (tokenize.ENDMARKER, "", (0, 0), (1, 0), "")  # end of input

    def check_token(expected: Tuple[int, Text], text: str) -> None:
        pg = ParserGenerator(parse_generator(text))
        tup = (pg.type, pg.value)

# Generated at 2022-06-23 15:58:27.646080
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    pg = ParserGenerator()
    pg.raise_error("msg")

# Generated at 2022-06-23 15:58:32.157799
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    import sys
    filename = sys.argv[1]
    with open(filename) as f:
        pg = ParserGenerator(f.read())
    pg.addfirstsets()
    for name, first in sorted(pg.first.items()):
        print("%-20s = %s" % (name, " ".join(first.keys())))

# Generated at 2022-06-23 15:58:39.817554
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    test_grammar = PgenGrammar(
        grammar.DEFAULT_GRAMMAR_NAME,
        grammar.DEFAULT_GRAMMAR_EX,
        grammar.DEFAULT_GRAMMAR_EX_FILE,
    )
    assert test_grammar.name == grammar.DEFAULT_GRAMMAR_NAME
    assert test_grammar.start == grammar.DEFAULT_GRAMMAR_EX
    assert test_grammar.grammar == grammar.DEFAULT_GRAMMAR_EX_FILE
    assert test_grammar.symbols == {}
    assert test_grammar.keywords == {}



# Generated at 2022-06-23 15:58:52.118701
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    import unittest

    class ParserGenerator_dump_nfaTests(unittest.TestCase):
        def test_empty(self) -> None:
            # Verify that the empty tuple gets printed correctly
            try:
                self.stdout.truncate(0)
                self.stdout.seek(0)
                self.parser.dump_nfa("", (), ())
            except Exception:
                self.fail("Unknown exception raised when running test")
            else:
                self.assertEqual(self.stdout.getvalue(), "Dump of NFA for \n")
                self.stdout.truncate(0)
                self.stdout.seek(0)


# Generated at 2022-06-23 15:59:03.085835
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():
    class Node(object):
        pass
    dfa: Any = []
    for i in range(5):
        dfa.append(DFAState({}, Node()))
    for i in range(4):
        dfa[i].addarc(dfa[i + 1], str(i))
    assert dfa[2].arcs == {'0': dfa[3], '1': dfa[4], '2': dfa[4], '3': dfa[4]}
    dfa[4].addarc(dfa[0], "foo")
    assert dfa[2].arcs == {'0': dfa[3], '1': dfa[4], '2': dfa[4], '3': dfa[4]}
    dfa[0].unifystate(dfa[4], dfa[1])


# Generated at 2022-06-23 15:59:09.580697
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    import io
    import token
    import difflib
    import test.support
    from unittest import TestCase
    from . import ast

    class ParserGeneratorTestCase(TestCase):
        def helper(self, pg, text, startsymbol, wanted):
            with test.support.captured_stdout() as output:
                pg.make_grammar(text, startsymbol)
                got = output.getvalue()
            diff = difflib.unified_diff(wanted.splitlines(1), got.splitlines(1),
                                        "wanted", "got")
            diff = "".join(diff)
            if diff:
                fail("Unexpected diff:\n" + diff)

        def test_op(self):
            # "op" is a dotted name
            pg = ParserGenerator()
            pg

# Generated at 2022-06-23 15:59:17.733927
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    pgen = ParserGenerator()
    def test(name: Text, dfa: List["DFAState"]) -> None:
        pgen.dump_dfa(name, dfa)
    dfa = [
        DFAState({NFAState(): 1, NFAState(): 1}, NFAState()),
        DFAState({NFAState(): 1}, NFAState()),
    ]
    dfa[0].arcs[None] = dfa[1]
    dfa[0].arcs["a"] = dfa[1]
    test("test1", dfa)
    dfa = [
        DFAState({NFAState(): 1}, NFAState()),
        DFAState({NFAState(): 1, NFAState(): 1}, NFAState()),
    ]
    dfa[0].arcs

# Generated at 2022-06-23 15:59:27.124312
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    # Simplest case: two states, same arcs
    dfa = [DFAState({1: 1}, False), DFAState({2: 1}, False)]
    dfa[0].addarc(dfa[1], "a")
    dfa[0].addarc(dfa[0], "b")
    dfa[1].addarc(dfa[0], "c")
    ParserGenerator.simplify_dfa(dfa)
    assert len(dfa) == 1
    assert dfa[0].arcs == {"a": dfa[0], "b": dfa[0], "c": dfa[0]}
    assert not dfa[0].isfinal
    # States with different arcs shouldn't be unified

# Generated at 2022-06-23 15:59:31.600598
# Unit test for constructor of class DFAState
def test_DFAState():
    x = DFAState({}, None)
    x.nfaset = {NFAState(): 1}
    x.isfinal = True
    y = DFAState({NFAState(): 1}, None)
    y.isfinal = True
    assert x == y



# Generated at 2022-06-23 15:59:40.720931
# Unit test for method __eq__ of class DFAState
def test_DFAState___eq__():
    dfa1 = DFAState({"": ""}, "")
    dfa2 = DFAState({"": ""}, "")
    dfa3 = DFAState({"": "", "": "", "": "", "": ""}, "")
    dfa1.addarc(dfa2, "")
    dfa1.addarc(dfa3, "")
    dfa2.addarc(dfa1, "")
    dfa2.addarc(dfa3, "")
    assert dfa1 == dfa2
    assert dfa1 != dfa3



# Generated at 2022-06-23 15:59:44.709492
# Unit test for constructor of class DFAState
def test_DFAState():
    states = {}
    for i in range(6):
        states[i] = DFAState(dict((i, 1)), i)
    for i in range(6):
        for j in range(6):
            if i == j:
                expected = True
            else:
                expected = False
            assert (states[i] == states[j]) == expected

# Generated at 2022-06-23 15:59:55.166541
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    pg = ParserGenerator()
    g = """
    single: "a"
    """
    g = g.splitlines()
    g = [line + "\n" for line in g]
    pg.parse_grammar(g)
    pg.dump_nfa("g", pg.dfas["single"][0], pg.dfas["single"][-1])
"""
Dump of NFA for single
  State 0
    'a' -> 1
  State 1 (final)
    -> 0
"""

    # Test the complete example in the docs

# Generated at 2022-06-23 16:00:06.599595
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    pgen = ParserGenerator(["hello"])

# Generated at 2022-06-23 16:00:18.332441
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    p = ParserGenerator()
    def get():
        # Fake tokenizer -- just return one token at a time
        for tok in [
            (token.NAME, "foo"),
            (token.OP, "+"),
            (token.STRING, "bar"),
            (token.OP, "*"),
        ]:
            yield tok

    p=ParserGenerator(get())
    assert p.parse_atom()==(NFAState(arcs=((None, NFAState(arcs={('foo', None): {}})),)), NFAState(arcs={(None, NFAState(arcs={('foo', None): {}})): {}}))

# Generated at 2022-06-23 16:00:28.493617
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    from . import token, tokenize, grammar

    assert isinstance(PgenGrammar.__abstractmethods__, frozenset)
    assert PgenGrammar.__abstractmethods__ == frozenset()
    assert PgenGrammar.__base__ == grammar.Grammar
    assert PgenGrammar.__bases__ == (grammar.Grammar,)
    assert PgenGrammar.__dict__['_PgenGrammar__find_nonterminal'].__name__ == '_PgenGrammar__find_nonterminal'
    assert PgenGrammar.__dict__['_PgenGrammar__find_nonterminal'].__qualname__ == 'PgenGrammar._PgenGrammar__find_nonterminal'
    assert PgenGrammar.__

# Generated at 2022-06-23 16:00:38.851493
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    pg = ParserGenerator()
    a = pg.parse_atom()
    assert a == NFAState('a', NFAState())
    a = pg.parse_item()
    assert a == NFAState('a', NFAState())
    a, z = pg.parse_alt()
    assert a == NFAState('a', NFAState())
    assert z == NFAState()
    a, z = pg.parse_rhs()
    assert a == NFAState('a', NFAState())
    assert z == NFAState()
    dfa = pg.make_dfa(a, z)
    assert len(dfa) == 1
    assert dfa[0].nfaset == {a: 1, z: 1}

# Generated at 2022-06-23 16:00:45.676342
# Unit test for method addarc of class NFAState
def test_NFAState_addarc():
    s = NFAState()
    t = NFAState()
    s.addarc(t)
    assert t in s.arcs
    assert (None, t) in s.arcs
    s.addarc(t, "label")
    assert t in s.arcs
    assert ("label", t) in s.arcs
    assert (None, t) in s.arcs



# Generated at 2022-06-23 16:00:53.860349
# Unit test for constructor of class DFAState
def test_DFAState():
    nfa1 = NFAState()
    nfa2 = NFAState()
    dfa1 = DFAState({nfa1: 1}, nfa1)
    dfa2 = DFAState({nfa2: 1}, nfa2)
    assert dfa1 != dfa2
    assert dfa1 == DFAState({nfa1: 1}, nfa1)
    dfa1.addarc(dfa2, "a")
    dfa1.addarc(dfa2, "b")
    assert dfa1 != dfa2
    assert dfa1 == DFAState({nfa1: 1}, nfa1)
    dfa1.unifystate(dfa1, dfa2)
    assert dfa1 == dfa2
    # Check that nfaset is not included in equality checks
    d

# Generated at 2022-06-23 16:00:56.703929
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    assert issubclass(PgenGrammar, grammar.Grammar)
    # class PgenGrammar(grammar.Grammar): pass
    PgenGrammar(token.tok_name)
    PgenGrammar(token.tok_name, "tokens")



# Generated at 2022-06-23 16:01:01.513019
# Unit test for function generate_grammar
def test_generate_grammar():
    # Test with no command line argument
    g = generate_grammar()
    assert isinstance(g, PgenGrammar)
    # Test with command line argument
    g = generate_grammar("Python.grammar")
    assert isinstance(g, PgenGrammar)


# Generated at 2022-06-23 16:01:03.197587
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    PgenGrammar(grammar.Grammar, "")



# Generated at 2022-06-23 16:01:10.689519
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    parser = ParserGenerator()

    l = ast.parse(
        """
    'a' | 'b' | 'c'
    """
    )

    def my_pgen(code: str) -> Tuple["DFAState", "DFAState"]:
        return parser.parse_rhs(python_scanner(code))

    assert my_pgen("a") == (
        NFAState(arcs=[(None, NFAState(arcs=[(NFAState(arcs=[]), NFAState(arcs=[]))]))]),
        NFAState(arcs=[(NFAState(arcs=[(None, NFAState(arcs=[]))]), NFAState(arcs=[]))]),
    )

# Generated at 2022-06-23 16:01:18.037689
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    print("test_Pgen_PgenGrammar")
    temp_grammar = PgenGrammar()
    assert temp_grammar.start is None
    assert temp_grammar.keywords == {}
    assert temp_grammar.tokens == []
    assert temp_grammar.dfas == {}
    assert temp_grammar.pstr == ()
    assert temp_grammar.symbol2label == {}
    assert temp_grammar.labels == []
