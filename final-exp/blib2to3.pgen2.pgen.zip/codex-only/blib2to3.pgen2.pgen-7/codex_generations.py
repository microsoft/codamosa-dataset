

# Generated at 2022-06-23 15:51:22.335739
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    import tokens  # type: ignore
    import pgen.pgen2
    pg = pgen.pgen2.ParserGenerator()
    token_types = {value: key for key, value in tokens.tok_name.items()}
    # print(f'\n{pg}')
    assert pg.type == tokenize.ENDMARKER
    assert pg.value == ''
    # below fails: pg.expect(1)
    # below fails: pg.expect(token_types['NAME'], 'whatever')
    # below fails: pg.expect(token_types['NAME'])
    # below fails: pg.expect(token_types['NAME'], 'whatever')
    # this passes: pg.expect(token_types['OP'], ':')
    # this passes: pg.expect(token_

# Generated at 2022-06-23 15:51:25.827043
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    for input, expected in [
        ("()", ("(0)", 0)),
        ("(1)", ("(1)", 1)),
        ("(2+3)", ("(5)", 5)),
        ("((2+3))", ("((5))", 5)),
    ]:
        print("Testing with %r..." % input)
        result = ParserGenerator(input).parse_item()
        assert result == expected, result
    print("Done.")

# Generated at 2022-06-23 15:51:35.526732
# Unit test for method __eq__ of class DFAState
def test_DFAState___eq__():
    new = DFAState({}, None)
    assert new == new

    old = DFAState({}, None)
    new = DFAState({}, new)
    assert new != old

    old = DFAState({}, None)
    new = DFAState({}, None)
    assert new == old

    old = DFAState({}, None)
    new = DFAState({}, None)
    old.addarc(old, 'x')
    assert new != old

    old = DFAState({}, None)
    new = DFAState({}, None)
    old.addarc(new, 'x')
    assert new != old

    old = DFAState({}, None)
    new = DFAState({}, None)
    new.addarc(old, 'x')
    assert new != old

    old = DFAState

# Generated at 2022-06-23 15:51:46.952624
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    import ast
    import sys

    pg = ParserGenerator()
    parse = pg.parse
    tokenize = ast.tokenize
    module = ast.Module

# Generated at 2022-06-23 15:51:53.939819
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():
    a = DFAState({}, None)
    b = DFAState({}, None)
    c = DFAState({}, None)
    q = DFAState({}, None)
    a.arcs["foo"] = b
    a.arcs["bar"] = c
    b.arcs["baz"] = q
    c.arcs["baz"] = q
    q.arcs["spam"] = a
    assert a.arcs == {"foo": b, "bar": c}
    assert b.arcs == {"baz": q}
    assert c.arcs == {"baz": q}
    assert q.arcs == {"spam": a}

    q.unifystate(a, c)
    assert a.arcs == {"foo": b, "bar": c}

# Generated at 2022-06-23 15:52:05.512433
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    # Test case for method parse_atom of class ParserGenerator
    print('Test method parse_atom of class ParserGenerator')
    from io import StringIO
    from grammar_parser import GrammarParser

    s = '"a" | "b"*'
    dfa = GrammarParser(StringIO(s))
    assert dfa.start == GrammarParser.OPEN, "dfa.OPEN expected"
    assert dfa.dfas["OPEN"][0].arcs[GrammarParser.STRING] == GrammarParser.OPENSTRING, (
        "dfa.OPEN.STRING expected"
    )

# Generated at 2022-06-23 15:52:15.080585
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    pg = ParserGenerator()
    c = PgenGrammar()
    c.symbol2number["x"] = 10
    assert pg.make_label(c, "x") == 10
    assert pg.make_label(c, "y") == 0
    assert c.symbol2number["y"] == 11
    assert c.labels == [(11, None)]
    assert pg.make_label(c, "y") == 0
    assert c.labels == [(11, None)]
    assert pg.make_label(c, "NAME") == 1
    assert c.tokens[token.NAME] == 1
    assert c.labels == [(11, None), (token.NAME, None)]
    assert pg.make_label(c, "'+'") == 2

# Generated at 2022-06-23 15:52:19.693334
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    fn = "../Parser/Grammar"
    g = ParserGenerator(fn)
    g.addfirstsets()
    assert g.first["atom"] == {"(": 1, "'": 1, "[": 1, "NAME": 1, "NUMBER": 1}

test_ParserGenerator_addfirstsets()

# Generated at 2022-06-23 15:52:25.555204
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    gen = ParserGenerator(StringIO('''
        a: "a"
        b: "b"
        c: "c"
        d: "d"
        e: "e"
    '''))
    assert gen.gettoken() is None
    assert gen.type == token.NAME
    assert gen.value == "a"
    assert gen.gettoken() is None
    assert gen.type == token.OP
    assert gen.value == ":"
    assert gen.gettoken() is None
    assert gen.type == token.STRING
    assert gen.value == '"a"'
    assert gen.gettoken() is None
    assert gen.type == token.NEWLINE
    assert gen.value == '\n'
    assert gen.gettoken() is None
    assert gen.type == token.NAME

# Generated at 2022-06-23 15:52:29.623806
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    # Just a simple test
    p = ParserGenerator()
    p.type = token.OP
    p.value = ","
    p.expect(token.OP, ",")
    try:
        p.expect(token.OP, ":")
    except SyntaxError:
        pass
    else:
        assert 0, "DID NOT RAISE"

# Unit tests for module

# Generated at 2022-06-23 15:52:41.903509
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    p = ParserGenerator()
    p.add_dfa("test", [DFAState({}, False), DFAState({}, False)])
    p.addfirstsets()

if __name__ == '__main__':
    from . import grammar
    from . import token
    from . import tokenize
    import sys
    p = ParserGenerator()
    p.add_dfa("test", [DFAState({}, False), DFAState({}, False)])
    p.addfirstsets()
    # p = ParserGenerator(grammar.parsed)
    # p.addfirstsets()
    print('')
    print('')
    # print(p)
    print('')
    # p.tools_converter.show_grammar()
    p.convert()
    print

# Generated at 2022-06-23 15:52:53.552641
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    from . import pytree
    from . import parser
    from . import pygram
    from . import pytoken
    from . import _testcapi
    from .pytokenize import generate_tokens
    from . import token
    from . import symbol
    from .parsetok import untokenize
    # Unit test for method make_grammar of class ParserGenerator

# Generated at 2022-06-23 15:53:06.438608
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    dfa = [
        DFAState({0: 1, 1: 1}, True),
        DFAState({1: 1}, False),
        DFAState({2: 1, 3: 1}, False),
        DFAState({3: 1}, False),
    ]
    dfa[0].addarc(dfa[1], "a")
    dfa[0].addarc(dfa[2], "b")
    dfa[1].addarc(dfa[3], "c")
    dfa[2].addarc(dfa[1], "c")
    dfa[2].addarc(dfa[3], "d")
    dfa[3].addarc(dfa[1], "b")
    pg = ParserGenerator()
    pg.simplify_dfa(dfa)
    assert d

# Generated at 2022-06-23 15:53:11.036695
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    parser = ParserGenerator()
    parser.parse()
    for dfa in parser.dfas.values():
        for state in dfa:
            for label, next in state.arcs.items():
                assert next in dfa
                if label in dfa:
                    assert next is dfa[0]

# Generated at 2022-06-23 15:53:21.264902
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    # From Python 2.4.1 Grammar/Grammar
    pg = ParserGenerator()
    pg.add_rhs("file_input", (
                             "NEWLINE | stmt | stmt NEWLINE",
                             "file_input ENDMARKER"
                            ))
    pg.add_rhs("eval_input", (
                             "testlist NEWLINE* ENDMARKER",
                             "testlist '\\n'* ENDMARKER"
                            ))
    pg.add_rhs("decorator", (
                            "AT dotted_name NEWLINE",
                           ))
    pg.add_rhs("decorators", (
                             "decorator+",
                            ))

# Generated at 2022-06-23 15:53:34.324039
# Unit test for constructor of class DFAState
def test_DFAState():    # type: ignore
    a = NFAState()
    b = NFAState()
    c = NFAState()
    d = NFAState()
    dfa1 = DFAState({a: 1, b: 1}, a)
    dfa2 = DFAState({a: 1, b: 1}, a)
    assert dfa1 == dfa2
    dfa3 = DFAState({c: 1, d: 1}, a)
    assert dfa1 != dfa3
    dfa4 = DFAState({a: 1, b: 1}, b)
    assert dfa1 != dfa4
    dfa5 = DFAState({a: 1, b: 1, c: 1}, a)
    assert dfa1 != dfa5
    dfa1.addarc(dfa2, "x")
    d

# Generated at 2022-06-23 15:53:41.464444
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    with TestOutput() as out:
        p = ParserGenerator()
        p.filename = '<string>'
        p.end = (1, 2)
        p.line = 'hello'
        p.raise_error('%s %d %d %s', 'hi there', 'hello', 'world', 'how are you?')
    assert out.getvalue() == '<string> 1 2 hello\n' + 'SyntaxError: hi there hello world how are you?\n'

# Generated at 2022-06-23 15:53:54.107387
# Unit test for constructor of class ParserGenerator

# Generated at 2022-06-23 15:53:58.425968
# Unit test for constructor of class NFAState
def test_NFAState():
    testn = NFAState()
    assert testn.arcs == []
    testn.addarc(NFAState())
    assert testn.arcs[0][0] is None


# Generated at 2022-06-23 15:54:02.033567
# Unit test for method addarc of class DFAState
def test_DFAState_addarc():
    x = DFAState({3:1, 4:1}, 3)
    y = DFAState({5:1}, 6)
    x.addarc(y, "hi")
    assert x.arcs == {"hi": y}

# Generated at 2022-06-23 15:54:10.841086
# Unit test for method __eq__ of class DFAState
def test_DFAState___eq__():
    dfa1 = DFAState({NFAState(): 1}, NFAState())
    dfa2 = DFAState({NFAState(): 1}, NFAState())
    dfa3 = DFAState({NFAState(): 1}, NFAState())
    assert dfa1 == dfa2
    dfa2.isfinal = not dfa2.isfinal
    assert not dfa1 == dfa2
    dfa2.isfinal = dfa1.isfinal
    dfa1.addarc(dfa3, 'a')
    assert not dfa1 == dfa2
    dfa2.addarc(dfa3, 'a')
    assert dfa1 == dfa2



# Generated at 2022-06-23 15:54:11.786596
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    """PgenGrammar()"""



# Generated at 2022-06-23 15:54:19.484273
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    pg = ParserGenerator()

    pg.parser.column = 0
    pg.parser.filename = "f"
    pg.parser.end = (1, 0)

# Generated at 2022-06-23 15:54:31.797383
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    p = ParserGenerator(tokenize.generate_tokens("a"))
    assert p.expect(token.NAME) == "a"
    #
    p = ParserGenerator(tokenize.generate_tokens("a"))
    pytest.raises(SyntaxError, p.expect, token.STRING)
    #
    p = ParserGenerator(tokenize.generate_tokens("a"))
    pytest.raises(SyntaxError, p.expect, token.NAME, "b")
    #
    p = ParserGenerator(tokenize.generate_tokens(" a"))
    pytest.raises(SyntaxError, p.expect, token.NAME)
    #

# Generated at 2022-06-23 15:54:43.319462
# Unit test for constructor of class DFAState
def test_DFAState():

    a = NFAState()
    b = NFAState()
    c = NFAState()
    d = NFAState()
    e = NFAState()
    f = NFAState()

    # first dfa
    a.addarc(b, "a")
    a.addarc(d)
    b.addarc(a)
    b.addarc(c, "b")
    c.addarc(b)
    c.addarc(f, "c")
    d.addarc(a)
    d.addarc(e, "a")
    e.addarc(d)
    e.addarc(f, "c")
    f.addarc(c)
    f.addarc(e)

    # second dfa
    bb = NFAState()
    cc = NFAState()

# Generated at 2022-06-23 15:54:51.009160
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    pg = ParserGenerator()
    pg.line = "<string>"
    pg.type = token.STRING
    pg.value = "foo"
    pg.gettoken = lambda: None
    pg.raise_error = lambda *args: None
    pg.expect(token.STRING)
    pg.expect(token.STRING, "foo")
    with pytest.raises(SyntaxError) as excinfo:
        pg.expect(token.STRING, "bar")
    assert excinfo.value.lineno == 1



# Generated at 2022-06-23 15:54:54.837140
# Unit test for method addarc of class NFAState
def test_NFAState_addarc():
    nfa0 = NFAState()
    nfa1 = NFAState()
    nfa2 = NFAState()

    nfa0.arcs.append(("a", nfa1))
    nfa1.arcs.append(("b", nfa2))
    nfa2.arcs.append(("c", nfa0))

    assert nfa0.arcs == [("a", nfa1)]
    assert nfa1.arcs == [("b", nfa2)]
    assert nfa2.arcs == [("c", nfa0)]



# Generated at 2022-06-23 15:55:07.101217
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    parser = ParserGenerator()

    # Test the branch that returns a == '('
    parser.value = '('
    parser.type = token.OP
    parser.generator = []
    parser.generator.append(('(', '(', (0, 0), (0, 0), '('))
    parser.generator.append((token.OP, ')', (0, 0), (0, 0), ')'))
    parser.gettoken()
    retval = parser.parse_atom()
    assert retval == None

    # Test the branch that returns a == '['
    parser.value = '['
    parser.type = token.OP
    parser.gettoken()
    retval = parser.parse_atom()
    assert retval == None

    # Test the branch that returns a == self.value

# Generated at 2022-06-23 15:55:17.239085
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    import pprint
    import io

    def do_test(input, expected):
        parser = ParserGenerator()
        d = parser.parsestr(input)
        dfas = d[0]
        startsymbol = d[1]
        s = io.StringIO()
        parser.dump_nfa(startsymbol, dfas[startsymbol][0], dfas[startsymbol][1])
        res = s.getvalue()
        # print(repr(res))
        # print(repr(expected))
        assert res == expected

    do_test("name: a b\n", "Dump of NFA for 'name'\n  State 0 \n    a -> 1\n  State 1 \n    b -> 2\n  State 2 (final)\n")

# Generated at 2022-06-23 15:55:23.616067
# Unit test for constructor of class DFAState
def test_DFAState():
    from collections import OrderedDict  # noqa
    # Build a DFA for a(b|c)*
    a = NFAState()
    z = NFAState()
    b = NFAState()
    c = NFAState()
    a.addarc(z, "a")
    b.addarc(z, "b")
    c.addarc(z, "c")
    a.addarc(b)
    a.addarc(c)
    b.addarc(a)
    c.addarc(a)
    # Convert NFA to DFA
    dfastates = make_dfa(a, z)
    dfa = OrderedDict([(s, s.arcs) for s in dfastates])
    assert len(dfastates) == 3

# Generated at 2022-06-23 15:55:30.889895
# Unit test for method __eq__ of class DFAState
def test_DFAState___eq__():
    def test(self, other, expected) -> None:
        actual = self.__eq__(other)
        assert actual == expected, "want %r, got %r" % (expected, actual)

    n1 = NFAState()
    n2 = NFAState()
    n3 = NFAState()
    n4 = NFAState()
    d1 = DFAState({n1: 1}, n3)
    d2 = DFAState({n2: 1}, n3)
    d3 = DFAState({n1: 1}, n4)
    d4 = DFAState({n1: 1}, n3)
    d4.addarc(d1, "label1")
    d4.addarc(d2, "label2")
    d4.addarc(d3, "label3")
    d

# Generated at 2022-06-23 15:55:41.839336
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    pg = ParserGenerator()
    pg.dfas["start"] = [DFAState({}, isfinal=True)]
    pg.dfas["start"][0].arcs["a"] = pg.dfas["start"][0]
    pg.first["start"] = {"a": 1}
    c = pg.convert()
    assert c.first == {0: {1: 1}}
    assert c.labels == [(2, None)]

    pg = ParserGenerator()
    pg.dfas["start"] = [DFAState({}, isfinal=True)]
    pg.dfas["start"][0].arcs["NAME"] = pg.dfas["start"][0]
    pg.first["start"] = {"NAME": 1}
    c = pg.convert()

# Generated at 2022-06-23 15:55:45.272521
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    pg = ParserGenerator()
    source = """
    a: 'b' c? d
    c: 'c'
    d: 'd'
    """
    pg.parsestring(source)


# Generated at 2022-06-23 15:55:47.460451
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    pg = ParserGenerator()
    # Type signature: raise_error(self: ParserGenerator, msg: str,
    #                             *args: Any) -> NoReturn
    pg.raise_error("msg", "*args")



# Generated at 2022-06-23 15:55:49.142486
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    pg = PgenGrammar(debug=False)



# Generated at 2022-06-23 15:55:51.046977
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    ParsedGrammar = PgenGrammar(DEFAULT_GRAMMAR)


# Generated at 2022-06-23 15:55:54.663971
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    pg = ParserGenerator([load_grammar("Grammar.txt")])
    pg.save_pickle("Grammar.pickle")


# Generated at 2022-06-23 15:56:01.285059
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    py_grammar = grammar.grammar
    pg = ParserGenerator(py_grammar.start, py_grammar.dfa)

    pg.dump_nfa("file_input", pg.dfas['file_input'][0], pg.dfas['file_input'][1])
    pg.dump_nfa("simple_stmt", pg.dfas['simple_stmt'][0], pg.dfas['simple_stmt'][1])


# Generated at 2022-06-23 15:56:10.306598
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    assert ParserGenerator(StringIO("a")).parse_alt() == (NFAState([(None, NFAState([('a', NFAState([]))]))]), NFAState([]))

if __name__ == "__main__":
    import sys

    filename = sys.argv[1]
    f = open(filename)
    data = f.read()
    f.close()
    p = ParserGenerator(StringIO(data))
    p.parse()
    c = p.make_converter()
    c.checklabels()
    c.load_grammar(grammar)
    c.write_grammar(filename)

# Generated at 2022-06-23 15:56:15.789052
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    lines = [
        "foo: bar baz [a]+ bletch\n",
        "bar: NAME\n",
        "baz: NUMBER\n",
        "bletch: [b]+\n",
    ]
    p = ParserGenerator()
    p.add_grammar(lines)
    p.create_nfa()
    p.dump_nfa("foo")
    p.dump_nfa("bar")
    p.dump_nfa("baz")
    p.dump_nfa("bletch")


test_ParserGenerator_dump_nfa()


# Generated at 2022-06-23 15:56:23.627239
# Unit test for method addarc of class DFAState
def test_DFAState_addarc():
    a = DFAState({},None)
    b = DFAState({},None)
    c = DFAState({},None)
    a.addarc(b,"b")
    a.addarc(c,"c")
    assert a.arcs["b"] is b
    assert a.arcs["c"] is c
    with pytest.raises(AssertionError):
        a.addarc(b,"b")


# Generated at 2022-06-23 15:56:29.082219
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    p = ParserGenerator()
    p.addproduction(b'file_input', [b'stmt', b"'''"])
    p.parse()
    try:
        p.addproduction(b'file_input', [b'stmt', b"'''"])
    except ValueError:
        pass
    else:
        print("Should have raised ValueError")

# Generated at 2022-06-23 15:56:34.784764
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():
    a = DFAState({}, NFAState())
    b = DFAState({}, NFAState())
    c = DFAState({}, NFAState())
    a.addarc(a, "A")
    a.addarc(b, "B")
    a.addarc(c, "C")
    assert a.arcs == {'A': a, 'C': c, 'B': b}
    a.unifystate(c, b)
    assert a.arcs == {'A': a, 'C': b, 'B': b}


# Generated at 2022-06-23 15:56:44.483819
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    import tokenize

    filename = "sample.py"

    def gen():
        for tup in tokenize.tokenize(open(filename).readline):
            yield tup

    pg = ParserGenerator()
    pg.setup_generator(filename, gen)
    pg.gettoken()

    # test parse_atom that input is '('
    a, z = pg.parse_atom()
    assert isinstance(a, NFAState)
    assert isinstance(z, NFAState)
    assert a.arcs == ((None, z),)
    assert z.arcs == ()

    # test parse_atom that input is 'NAME'
    a, z = pg.parse_atom()
    assert isinstance(a, NFAState)
    assert isinstance(z, NFAState)

# Generated at 2022-06-23 15:56:47.877136
# Unit test for method addarc of class NFAState
def test_NFAState_addarc():
    s = NFAState()
    t = NFAState()
    s.addarc(t)
    assert s.arcs[0][1] is t


# Generated at 2022-06-23 15:56:57.043394
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    pg = ParserGenerator()
    pg.parse()
    g = pg.make_grammar()
    print("Grammar dump:")
    # XXX This dump is not very informative.
    for name, number in sorted(g.symbol2number.items()):
        print("  Symbol", name, number)
    for value, name in sorted(g.number2symbol.items()):
        print("  Symbol", value, name)
    for value, name in sorted(g.labels):
        if name is not None:
            print("  Token", value, token.tok_name[value], name)
        else:
            print("  Token", value, token.tok_name[value])

# Generated at 2022-06-23 15:57:06.012637
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    pg = ParserGenerator(None)
    for args in [
        (token.NAME, None, token.NAME, "foo"),
        (token.NAME, "foo", token.NAME, "foo"),
        (token.NAME, "foo", token.NAME, "bar"),
    ]:
        try:
            pg.type, pg.value = args[2:]
            pg.expect(args[0], args[1])
        except SyntaxError:
            pass
        else:
            assert False, f"Expected SyntaxError on ({args[0]}, {args[1]})"


# Generated at 2022-06-23 15:57:14.873239
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    pg = ParserGenerator()
    assert pg.symbol2number == {}
    assert pg.dfas == {}
    assert pg.number2symbol == {}
    s = pg.symbol2number["foo"]
    assert pg.symbol2number["foo"] == 0
    assert s == 0
    assert pg.number2symbol[0] == "foo"
    pg.make_start()
    assert pg.symbol2number["START"] == 1
    assert pg.number2symbol[1] == "START"
    assert pg.symbol2number["foo"] == 0
    assert pg.number2symbol[0] == "foo"
    assert pg.symbol2number["bar"] == 2
    assert pg.number2symbol[2] == "bar"


# Generated at 2022-06-23 15:57:18.536915
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    pg = ParserGenerator()
    source = "a: 'a' ; b: 'b' ; c: a | b ; d: c+ ;"
    grammar = pg.parse(source)


# Generated at 2022-06-23 15:57:21.238505
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    g = ParserGenerator(open('Parser/Grammar/Grammar'))
    g.parse_atom() == (NFAState(), NFAState())

# Generated at 2022-06-23 15:57:28.651605
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    from _ast import parse

    pg = ParserGenerator()
    for node in parse(dedent("""\
    foo: '[' baz qux
         | NAME
    baz: 'x' | 'y'
    qux:
    """
                            )
                       ).body:
        if isinstance(node, AugAssign):
            pg.add_production(node.target.id, tuple(node.value.elts))
    pg.build()
    g = pg.build_grammar()
# End unit test



# Generated at 2022-06-23 15:57:36.867309
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    pg = ParserGenerator()
    assert pg.make_dfa([], []) == []

    pg = ParserGenerator()
    p = pg.NFAState()
    q = pg.NFAState()
    p.addarc(q)
    assert pg.make_dfa(p, q) == [pg.DFAState({p: 1, q: 1}, q)]

    pg = ParserGenerator()
    p = pg.NFAState()
    q = pg.NFAState()
    r = pg.NFAState()
    p.addarc(q)
    p.addarc(r)
    dfa = pg.make_dfa(p, q)

# Generated at 2022-06-23 15:57:45.568723
# Unit test for method parse_atom of class ParserGenerator

# Generated at 2022-06-23 15:57:53.180930
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    pg = ParserGenerator()
    # try:
    #     pg.gettoken()
    # except TokenError as e:
    #     print e.args
    # try:
    #     pg.gettoken()
    # except TokenError as e:
    #     print e.args
    pg = ParserGenerator()
    del pg
    import token
    print(token.tok_name[token.NAME])


if __name__ == "__main__":
    import sys

    if len(sys.argv) == 1:
        print("usage: python parser.py source")
        sys.exit(2)
    source = open(sys.argv[1]).read()
    description = parser.pgen(source)
    parser = ParserGenerator()
    p = parser.makeparser(source)
   

# Generated at 2022-06-23 15:58:00.912596
# Unit test for method addarc of class NFAState
def test_NFAState_addarc():
    from dfa import DFAState, NFAState
    nfa1 = NFAState()
    nfa2 = NFAState()
    nfa1.addarc(nfa2)
    assert (None,nfa2) in nfa1.arcs
    nfa3 = NFAState()
    nfa1.addarc(nfa3,'test')
    assert ('test',nfa3) in nfa1.arcs



# Generated at 2022-06-23 15:58:14.288924
# Unit test for method addarc of class DFAState
def test_DFAState_addarc():
    start = DFAState({}, None)
    assert len(start.arcs.keys()) == 0
    next = DFAState({}, None)
    start.addarc(next, "a")
    assert len(start.arcs.keys()) == 1
    assert start.arcs["a"] is next
    # The first argument to addarc() has to be a DFAState
    try:
        start.addarc([])
    except AssertionError:
        pass
    else:
        assert False, "expected AssertionError"
    # The second argument to addarc() has to be a label that hasn't
    # already been used.
    try:
        start.addarc(next, "a")
    except AssertionError:
        pass
    else:
        assert False, "expected AssertionError"




# Generated at 2022-06-23 15:58:17.129982
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    pg = ParserGenerator()
    pg.setup("a: a\n")
    print(pg.parse_rhs())

# Generated at 2022-06-23 15:58:22.590442
# Unit test for method __eq__ of class DFAState
def test_DFAState___eq__():
    dfa = DFAState({"a":1}, "b")
    for other in [DFAState({"a":1}, "b"), DFAState({"a":1}, "c"), DFAState({"a":1, "b":2}, "b")]:
        assert not dfa != other

if __name__ == "__main__":
    test_DFAState___eq__()



# Generated at 2022-06-23 15:58:32.454686
# Unit test for constructor of class DFAState
def test_DFAState():
    import pytest

    nfa_a = NFAState()
    aaa = nfa_a
    aab = NFAState()
    aac = NFAState()
    aad = NFAState()
    aae = NFAState()
    aaf = NFAState()
    aag = NFAState()
    aah = NFAState()
    aai = NFAState()
    nfa_a.addarc(aab)
    nfa_a.addarc(aac)
    nfa_a.addarc(aad)
    nfa_a.addarc(aae)
    nfa_a.addarc(aaf)
    nfa_a.addarc(aag)
    nfa_a.addarc(aah)
    nfa_a.addarc(aai)

# Generated at 2022-06-23 15:58:35.960922
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    s = '+'
    l = lex(s)
    g = ParserGenerator()
    g.gettoken()
    assert g.value == s
    assert g.parse_item() == (None, None)


# Generated at 2022-06-23 15:58:38.837683
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    pgen = ParserGenerator()
    tokens = tokenize.tokenize(StringIO("[a|b]c").readline)
    pgen.parse_item(tokens)

# Generated at 2022-06-23 15:58:40.898339
# Unit test for function generate_grammar
def test_generate_grammar():
    p = ParserGenerator("./Grammar.txt")
    p.make_grammar()


# Generated at 2022-06-23 15:58:53.931779
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    p = ParserGenerator()
    p.dfas = {"file_input": [], "eval_input": [], "single_input": []}
    p.first = {"eval_input": None, "single_input": None, "file_input": None}
    p.calcfirst("file_input")
    assert p.first["file_input"] == {"NEWLINE": 1, "COMMENT": 1, "STRING": 1, "NUMBER": 1, "NAME": 1}
    p.calcfirst("eval_input")
    assert p.first["eval_input"] == {"NEWLINE": 1, "COMMENT": 1, "STRING": 1, "NUMBER": 1, "NAME": 1}
    p.calcfirst("single_input")

# Generated at 2022-06-23 15:59:04.775707
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    ltl = ParserGenerator.make_label
    rtl = getattr(token, "tok_name")

    def check(label: int, rlabel: str) -> None:
        assert isinstance(label, int)
        assert isinstance(rlabel, str)
        ilabel = ltl(None, rlabel)
        assert isinstance(ilabel, int)
        assert ilabel == label

    check(0, "NAME")
    check(1, "NUMBER")
    check(2, "STRING")
    check(3, "'+'")
    check(4, "'-'")
    check(5, "'*'")
    check(6, "'/'")
    check(7, "'|'")
    check(8, "'('")
    check(9, "')'")

# Generated at 2022-06-23 15:59:15.378798
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    pg = ParserGenerator()
    # ATOM: '(' RHS ')' | NAME | STRING
    t = tokenize.generate_tokens(io.BytesIO(b"(expr)").readline)
    # make generator look like iterator
    t = iter(list(t)[:-1])
    pg.init_generator(t)
    a, z = pg.parse_atom()
    assert a.arcs == [(None, z)]
    t = tokenize.generate_tokens(io.BytesIO(b"NAME").readline)
    # make generator look like iterator
    t = iter(list(t)[:-1])
    pg.init_generator(t)
    a, z = pg.parse_atom()
    assert a.arcs == [(pg.value, z)]
    t = token

# Generated at 2022-06-23 15:59:26.411367
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    c: ParserGenerator = ParserGenerator()
    c.type = token.NAME
    c.value = "a"
    c.gettoken = lambda *args: None
    c.parse_atom = lambda *args: (object, object)
    res = c.parse_item()
    assert len(res) == 2
    assert isinstance(res[0], object)
    assert res[0] is res[1]

    c.type = token.OP
    c.value = "("
    res = c.parse_item()
    assert len(res) == 2
    assert isinstance(res[0], object)
    assert res[0] is not res[1]

    c.type = token.NAME
    c.value = "a"
    c.parse_atom = lambda *args: (object, object)

# Generated at 2022-06-23 15:59:33.586781
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    pg = ParserGenerator()
    pg.add_nonterminal('foo', '"bar" "baz"')
    dfa, startsymbol = pg.parse()
    assert startsymbol == 'foo'
    assert dfa['foo'][0].arcs == {('bar', None): dfa['foo'][1]}
    assert dfa['foo'][1].arcs == {('baz', None): dfa['foo'][2]}



# Generated at 2022-06-23 15:59:44.593482
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    pg = ParserGenerator(None)
    text = "[a] [b] [c] x y z"
    pg.setup_input(text.split())
    # print list(pg.generator)
    pg.gettoken()
    assert pg.parse_item() == (
        NFAState({NFAState({NFAState({})}, a=1): 1}, a=1),
        NFAState({}, a=1),
    )
    assert pg.parse_item() == (
        NFAState({NFAState({NFAState({})}, b=1): 1}, b=1),
        NFAState({}, b=1),
    )

# Generated at 2022-06-23 15:59:48.568624
# Unit test for method addarc of class DFAState
def test_DFAState_addarc():
    dfa = DFAState({NFAState(): 1}, nfa_final=NFAState())
    assert dfa.isfinal == False
    assert dfa.arcs == {}
    nfa_next = NFAState()
    dfa.addarc(next=nfa_next, label="test_label")
    assert dfa.arcs == {"test_label": nfa_next}
test_DFAState_addarc()

# Generated at 2022-06-23 15:59:56.107764
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    from typing import cast
    parser = ParserGenerator()
    msg_format = 'test-{}'
    expected_msg = 'test-o'
    result = parser.raise_error(msg_format, 'o')
    assert result is None
    exception = pytest.raises(SyntaxError)
    exception.match(expected_msg)
    parser.raise_error(msg_format, 'o')

# Generated at 2022-06-23 16:00:04.752486
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    import sys
    import _ast
    pgen = ParserGenerator(sys.path)
    pgen.run(sys.argv[1])
    c = pgen.make_converter()
    print(c.labels)
    print([node.__class__.__name__ for node in c.grammar.st2t.values()])
    # print re.sub('(\d{1,2})', lambda m: ast.literal_eval(m.group(1)), c.grammar.str())



# Generated at 2022-06-23 16:00:08.865361
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    """Unit test for method dump_dfa of class ParserGenerator"""
    p = ParserGenerator()
    p.dump_dfa("tests", ["foo"])


# Generated at 2022-06-23 16:00:10.026723
# Unit test for method addarc of class NFAState
def test_NFAState_addarc():
    n = NFAState()
    n.addarc(NFAState(), "l")


# Generated at 2022-06-23 16:00:21.406233
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    import io
    import token
    import tokenize

# Generated at 2022-06-23 16:00:27.063412
# Unit test for method __eq__ of class DFAState
def test_DFAState___eq__():
    a = DFAState({}, None)
    b = DFAState({}, None)
    assert a == b
    a.isfinal = 1
    assert a != b
    b.isfinal = 1
    assert a == b
    a.arcs = {"a": a}
    assert a != b
    b.arcs = {"a": b}
    assert a == b

# Generated at 2022-06-23 16:00:31.485778
# Unit test for method addarc of class DFAState
def test_DFAState_addarc():
    s = DFAState({}, None)
    t = DFAState({}, None)
    s.addarc(t, 'foo')
    assert s.arcs.get('foo') == t



# Generated at 2022-06-23 16:00:32.502059
# Unit test for constructor of class NFAState
def test_NFAState():
    s = NFAState()


# Generated at 2022-06-23 16:00:42.084516
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    from .grammar import grammar_from_file
    from .pgen import PgenGrammar

    grammar = grammar_from_file(
        "Grammar/Grammar",
        convert=ParserGenerator.convert_grammar,
        start="file_input",
        ignore_case=True,
    )
    assert isinstance(grammar, ParserGenerator)

    file_input = grammar.dfas["file_input"]
    file_input_first = grammar.make_first(PgenGrammar(), "file_input")
    assert file_input_first == {0: 1, token.NAME: 1, token.STRING: 1, token.NEWLINE: 1}

    simple_stmt = grammar.dfas["simple_stmt"]

# Generated at 2022-06-23 16:00:52.576955
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    from . import grammar
    from .parser import ParserGenerator

    pg = ParserGenerator()

    for prod in grammar.grammar:
        pg.addProduction(prod)

    dfa = pg.make_dfa(pg.start, pg.finish)
    pg.simplify_dfa(dfa)
    assert len(dfa) == 8
    assert len(dfa[0].arcs) == 2
    assert dfa[0].arcs[1][1] == dfa[0]
    assert len(dfa[1].arcs) == 2
    assert dfa[1].arcs[3][1] == dfa[2]
    assert dfa[1].arcs[1][1] == dfa[0]
    assert len(dfa[2].arcs) == 2
   

# Generated at 2022-06-23 16:01:05.719768
# Unit test for function generate_grammar
def test_generate_grammar():
    test_grammar = generate_grammar()
    assert isinstance(test_grammar, PgenGrammar)
    # The grammar should be in the form of a dictionary with the keys
    # being the name of the rules and the values being their sequence
    # of DFAs.
    assert isinstance(test_grammar.dfas, dict)
    assert all(isinstance(dfa_list, list) for dfa_list in test_grammar.dfas.values())
    assert all(isinstance(dfa, DFAState) for dfa_list
                in test_grammar.dfas.values() for dfa in dfa_list)
    # The grammar should also contain the first sets, in the form of a
    # dictionary with the keys being the name of the rules and the
    # values being the first sets of those rules.

# Generated at 2022-06-23 16:01:12.488672
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    pgen = ParserGenerator()
    pgen.dfas = {
        "start": [
            DFAState({1: 1}, True),
            DFAState({2: 1, 3: 1}, False),
            DFAState({4: 1, 6: 1}, False),
            DFAState({4: 1, 5: 1}, False),
            DFAState({7: 1}, False),
            DFAState({8: 1}, False),
            DFAState({8: 1}, False),
            DFAState({}, False),
            DFAState({}, False),
        ],
    }
    pgen.dfas["start"][0].arcs[None] = pgen.dfas["start"][1]