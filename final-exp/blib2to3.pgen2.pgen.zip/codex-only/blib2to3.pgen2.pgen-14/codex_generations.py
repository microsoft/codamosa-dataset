

# Generated at 2022-06-23 15:51:21.811779
# Unit test for method addarc of class NFAState
def test_NFAState_addarc():
    NFAState().addarc(NFAState())



# Generated at 2022-06-23 15:51:29.485413
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    from io import StringIO
    from .parsertok import tokenize_lines


# Generated at 2022-06-23 15:51:39.852378
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    if not hasattr(unittest, "SkipTest"):
        unittest.SkipTest = type("SkipTest", (Exception,), {})
    try:
        from tokenize import generate_tokens, untokenize
    except ImportError:
        raise unittest.SkipTest()
    import io
    import textwrap

    Grammar = ParserGenerator([])


# Generated at 2022-06-23 15:51:45.148470
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    # Import the module containing the method to test
    import Lib.pgen
    # Create an instance of InputSource
    arg = io.StringIO("foo")
    input_source = Lib.pgen.InputSource("foo", arg, 'utf-8')
    # Create an instance of ParserGenerator
    parser_generator = Lib.pgen.ParserGenerator("foo", input_source)
    # Add the necessary code to set up the test
    parser_generator.gettoken()
    # Invoke the method to test
    result = parser_generator.parse_alt()
    # Add the necessary code to check the result
    nfa_state2 = parser_generator.get_free_state()
    nfa_state3 = parser_generator.get_free_state()

# Generated at 2022-06-23 15:51:53.315318
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    # This test is also in test_grammar.py
    pgen = ParserGenerator()
    with open("Grammar.txt", "rb") as fp:
        encoding = tokenize.detect_encoding(fp.readline)[0]
    with open("Grammar.txt", "rb") as fp:
        pgen.setup(fp, encoding)
    dfas, start = pgen.parse()
    print(dfas)
    print(start)


# The Parser class

NUM_STATES = 12


# Generated at 2022-06-23 15:52:05.830855
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    from . import grammar
    from .grammar import _Grammar
    from .pygram import python_symbols as syms
    from .pygram import python_grammar as pgen
    symbol2number = {
        key: value for key, value in _Grammar._symbol2number.items() if value != syms.empty
    }
    pg = ParserGenerator(symbol2number, pgen)

    def parse(stmt: str) -> Tuple[str, str]:
        pg.setup("<string>", stmt)
        a, b = pg.parse_item()
        return sorted(label for label, next in a.arcs), sorted(label for label, next in b.arcs)

    assert parse("foo") == (["NAME"], [])

# Generated at 2022-06-23 15:52:15.222300
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():
    nfa0 = NFAState()
    nfa1 = NFAState()
    nfa2 = NFAState()
    nfa3 = NFAState()
    nfa4 = NFAState()
    nfa5 = NFAState()
    s0 = DFAState({nfa0, nfa1}, nfa2)
    s1 = DFAState({nfa2, nfa3}, nfa4)
    s2 = DFAState({nfa3}, nfa5)
    s0.addarc(s1, 'a')
    s0.addarc(s2, 'b')
    s1.addarc(s0, 'b')
    s1.addarc(s2, 'a')
    assert s0.arcs == {'a': s1, 'b': s2}

# Generated at 2022-06-23 15:52:23.298821
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    pg = ParserGenerator()
    pg.dfas = {
        "foo": [DFAState({'3': 1, '2': 1, 'b': 1}, False)],
        "bar": [DFAState({'a': 1}, False)],
    }
    pg.calcfirst("foo")
    assert pg.first["foo"] == {'2': 1, '3': 1, 'b': 1}, pg.first["foo"]
    pg.calcfirst("bar")
    assert pg.first["bar"] == {'a': 1}, pg.first["bar"]


# Generated at 2022-06-23 15:52:35.271319
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    pg = ParserGenerator()
    # Start of grammar
    # augassign: '+=' | '-=' | '*=' | '/=' | '%=' | '&=' | '|=' | '^='
    #           | '<<=' | '>>=' | '**=' | '//='
    s0 = pg.make_state()  # Start state
    s1 = pg.make_state()  # '+='
    s2 = pg.make_state()  # '-='
    s3 = pg.make_state()  # '*='
    s4 = pg.make_state()  # '/='
    s5 = pg.make_state()  # '%='
    s6 = pg.make_state()  # '&='
    s7 = pg.make_state()  # '|='
   

# Generated at 2022-06-23 15:52:39.693908
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    try:
        filename = __file__  # pytype: disable=name-error
    except NameError:
        filename = None
    f = open(filename, "r")
    p = ParserGenerator()
    p.parse_grammar(f.read(), filename)



# Generated at 2022-06-23 15:52:45.508219
# Unit test for method __eq__ of class DFAState
def test_DFAState___eq__():
    """Unit test for method __eq__ of class DFAState"""
    # Do not add test methods directly to this function; they will not be run.
    # They must be added as class-level methods to the class that implements
    # this interface.  See the documentation for further details.
    # The 'self' variable is not available in this scope.
    raise NotImplementedError()



# The following class definitions needed to be renamed because the
# parser generator attempts to import them.


# Generated at 2022-06-23 15:52:55.204255
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    from . import parser
    pg = parser.ParserGenerator()
    assert pg.make_first(None, "None") == {0: 1}
    assert pg.make_first(None, "single") == {1: 1}
    assert pg.make_first(None, "any") == {1: 1, 2: 1, 3: 1}
    assert pg.make_first(None, "all") == {1: 1, 2: 1, 3: 1}
    assert pg.make_first(None, "opt") == {1: 1}
    assert pg.make_first(None, "more") == {2: 1}
    assert pg.make_first(None, "many") == {3: 1}
    assert pg.make_first(None, "oneormore") == {1: 1, 2: 1}
   

# Generated at 2022-06-23 15:53:06.991638
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    # No reduction is possible if the DFA has only one state
    pgen = ParserGenerator()
    dfa = [DFAState({NFAState(): 1}, NFAState())]
    pgen.simplify_dfa(dfa)
    assert len(dfa) == 1

    # No reduction is possible if the DFA has no states
    pgen = ParserGenerator()
    dfa = []
    pgen.simplify_dfa(dfa)
    assert len(dfa) == 0

    # Two states can be merged if they have exactly the same arcs

    a = NFAState()
    b = NFAState()
    c = NFAState()
    d = NFAState()
    e = NFAState()


# Generated at 2022-06-23 15:53:09.980127
# Unit test for method addarc of class NFAState
def test_NFAState_addarc():
    a = NFAState()
    b = NFAState()
    a.addarc(b, 'x')
    x, y = a.arcs[0]
    x
    'x'
    y
    b


# Generated at 2022-06-23 15:53:11.082719
# Unit test for constructor of class NFAState
def test_NFAState():
    assert NFAState()



# Generated at 2022-06-23 15:53:19.353029
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    p = ParserGenerator()
    a1, z1 = p.parse_rhs()
    assert not a1.arcs
    assert not z1.arcs
    assert a1 is not z1
    a2, z2 = p.parse_rhs()
    assert not a2.arcs
    assert not z2.arcs
    assert a2 is not z2
    assert a2 is not a1
    assert z2 is not z1
    a1.addarc(a2)
    a2.addarc(z1)
    z2.addarc(a1)


# Generated at 2022-06-23 15:53:27.543230
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    pgen = ParserGenerator(name=None)
    c = pgen.make_grammar()
    #print c.labels

# Generated at 2022-06-23 15:53:37.364548
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    """Test ParserGenerator.make_first"""
    import pgen2.pgen2_test as pgen2_test
    p = ParserGenerator(pgen2_test.test_grammar)
    p.addfirstsets()
    conv = p.convert()
    values = conv.values
    assert len(values) == 10
    assert values[1] == ('a', 1)
    assert values[2] == ('b', 2)
    assert values[3] == ('c', 3)
    assert values[4] == ('d', 4)
    assert values[5] == ('e', 5)
    assert values[6] == ('f', 6)

# Generated at 2022-06-23 15:53:43.302392
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    from .grammar import Grammar
    from .pgen2 import pgen

    g = pgen.make_grammar(Grammar)
    if sys.version_info >= (3, 8):
        # XXX Why does Python 3.7 work?
        assert len(g.keywords) == 8, g.keywords
    else:
        assert len(g.keywords) == 7, g.keywords  # XXX Hard-wired check

# Generated at 2022-06-23 15:53:54.865585
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    pg = ParserGenerator()
    pg.add_module(token)
    pg.add_nonterminal('file_input', [
        ['NEWLINE', 'stmt', 'NEWLINE'],
        ['NEWLINE', 'compound_stmt', 'NEWLINE'],
        ['NEWLINE'],
    ])
    pg.add_nonterminal('stmt', '[simple_stmt | compound_stmt]')
    pg.add_nonterminal('simple_stmt', ['small_stmt', 'SEMI', '[small_stmt', 'SEMI]*', 'NEWLINE'])

# Generated at 2022-06-23 15:54:04.117422
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    x = ParserGenerator()
    x.end = (1,2)
    x.line = "nonsense"
    x.filename = "mytestfile"
    try:
        x.raise_error("Testing: %r %r", 42, 43)
    except SyntaxError as e:
        assert e.msg == "Testing: 42 43"
        assert e.filename == "mytestfile"
        assert e.lineno == 1
        assert e.offset == 2
        assert e.text == "nonsense"
    else:
        assert False, "Expected exception"
# Tests for function generate_grammar

# Generated at 2022-06-23 15:54:14.678832
# Unit test for method addarc of class DFAState
def test_DFAState_addarc():
    f = NFAState()
    g = NFAState()
    a = DFAState({f: 1, g: 1}, g)
    b = DFAState({f: 1}, f)
    assert a.arcs == {}
    a.addarc(b, 'x')
    assert a.arcs == {'x': b}
    # Add a duplicate
    try:
        a.addarc(b, 'x')
        assert False
    except AssertionError:
        pass
    # Add an incompatible one
    try:
        a.addarc(DFAState({}, f), 'x')
        assert False
    except AssertionError:
        pass
    # Add a compatible one
    c = DFAState({g: 1}, g)
    a.addarc(c, 'y')
    assert a

# Generated at 2022-06-23 15:54:19.659724
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    # Test method parse_item of class ParserGenerator.
    pg = ParserGenerator()
    print("Unit test for method parse_item of class ParserGenerator")
    nfa, dfa = pg.start_parse(
        "['hello' | 'howdy']" + " " + "['my' | 'your']" + " " + "'dude'"
    )
    for i, state in enumerate(nfa):
        print(i, state)
        for label, next in state.arcs:
            print(i, label, next)

# Generated at 2022-06-23 15:54:32.029992
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():
    s: DFAState = DFAState({}, None)
    d = DFAState({}, None)
    s.unifystate(d, d)


# RE grammar

# First, construct an NFA for the RE grammar
start = NFAState()
a = NFAState()
z = NFAState()
start.addarc(a)
z.addarc(start)
a.addarc(z, "[")
a.addarc(z, "]")
a.addarc(z, "(")
a.addarc(z, ")")
a.addarc(z, "|")
a.addarc(z, "-")
a.addarc(z, "+")
a.addarc(z, "*")
a.addarc(z, "?")
a.addarc(z, ".")
a

# Generated at 2022-06-23 15:54:39.214295
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():
    A = DFAState({}, None)
    B = DFAState({}, None)
    C = DFAState({}, None)
    A.arcs[None] = B
    A.arcs["x"] = B
    A.arcs["y"] = C
    A.unifystate(B, C)
    assert A.arcs == {None: C, "x": C, "y": C}



# Generated at 2022-06-23 15:54:45.797592
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    pg = ParserGenerator()
    fileobj = io.StringIO(
        """expr: xor_expr ('|' xor_expr)*
xor_expr: and_expr ('^' and_expr)*
and_expr: shift_expr ('&' shift_expr)*
shift_expr: a_expr (('<<'|'>>') a_expr)*
a_expr: m_expr (('+'|'-') m_expr)*
m_expr: atom (('*'|'@'|'/'|'%') atom)*
atom: '(' expr ')' | '~' atom | NAME
"""
    )
    dfas, startsymbol = pg.parse_grammar(fileobj)
    assert startsymbol == "expr"
    assert len(dfas) == 7

# Generated at 2022-06-23 15:54:51.538900
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():
    s = DFAState({}, None)
    a = DFAState({}, None)
    b = DFAState({}, None)
    s.addarc(a, "a")
    s.addarc(b, "b")
    s.unifystate(a, b)
    assert s.arcs["a"] is b
    assert s.arcs["b"] is b



# Generated at 2022-06-23 15:55:04.048228
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    sample = '''abc: "abc"def
abcdef: "abc"|"def"
abc|def: "abc"|"def"
abcdef|ghijk: "abc"|"def"|"ghi"|"jkl"
abcdef|ghijk|mno: "abc"|"def"|"ghi"|"jkl"|"mno"
'''
    pg = ParserGenerator()
    dfas, start = pg.parse_grammar(StringIO(sample), "<testcase>")
    assert start == "abc"
    pg.addfirstsets()
    # pg.dump_dfa('abc', dfas['abc'])
    # pg.dump_dfa('abcdef', dfas['abcdef'])
    # pg.dump_dfa('abc|def', dfas['abc|

# Generated at 2022-06-23 15:55:08.089026
# Unit test for method addarc of class DFAState
def test_DFAState_addarc():
    a = DFAState({}, NFAState())
    b = DFAState({}, NFAState())
    a.addarc(b, 'x')
    assert a.arcs['x'] is b


# Generated at 2022-06-23 15:55:10.150260
# Unit test for method addarc of class DFAState
def test_DFAState_addarc():
    from pprint import pprint
    from tokenize import generate_tokens, tok_name

# Generated at 2022-06-23 15:55:19.641295
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    print("test_ParserGenerator_dump_nfa")
    pg = ParserGenerator()

    class NFAState:
        def __init__(self, i: int) -> None:
            self.arcs = []  # type: List[Tuple[Any, "NFAState"]]
            self.i = i

        def addarc(self, next: "NFAState", label: Any = None) -> None:
            self.arcs.append((label, next))

        def __repr__(self) -> Text:
            return "<NFAState %d>" % self.i

    a = NFAState(0)
    b = NFAState(1)
    c = NFAState(2)
    a.addarc(c, "A")
    a.addarc(a, 1)

# Generated at 2022-06-23 15:55:28.979877
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    pgen = ParserGenerator(grammar, {})
    pgen.addfirstsets()
    assert pgen.first["single_input"] == {None: 1}

# Generated at 2022-06-23 15:55:41.236346
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    pg = ParserGenerator()

    with pytest.raises(SyntaxError):
        pg.parse(b"""foo: 'a' 'b'
bar: [foo]
""")

    with pytest.raises(SyntaxError):
        pg.parse(b"""foo: 'a' 'b'
bar: 'c' [foo]
""")

    pg.parse(b"""foo: 'a' 'b'
baz: 'c' [foo]
bar: 'd' [baz]
""")

    with pytest.raises(SyntaxError):
        pg.parse(b"""foo: 'a' 'b'
bar: 'c' [foo 'd']
""")


# Generated at 2022-06-23 15:55:50.830375
# Unit test for method raise_error of class ParserGenerator

# Generated at 2022-06-23 15:56:02.653163
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    # reg = r"[ab]*a[ab]+"
    # reg = r"[a-zA-Z_][a-zA-Z0-9_]*"
    # reg = r"[a-zA-Z_][a-zA-Z0-9_]*(,[ \t]*[a-zA-Z_][a-zA-Z0-9_]*)*"
    # reg = r"[a-zA-Z_][a-zA-Z0-9_]*([ \t]+[a-zA-Z_][a-zA-Z0-9_]*)*"
    reg = r"int|float|(char([ \t]+[a-zA-Z_][a-zA-Z0-9_]*)*)"
    # reg = r"[a

# Generated at 2022-06-23 15:56:04.172979
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    # No exceptions raised
    PgenGrammar()


# Generated at 2022-06-23 15:56:14.225650
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    x = ParserGenerator()
    #
    # The following has been hand-edited; the original was:
    #   test_grammar = """
    #   foo: bar baz
    #   bar: "a" | "b"
    #   baz: "a" | "b" | "c"
    #   """
    # Namely, it got rid of the trailing whitespace on the last line,
    # and put it on the same line as the line before.
    test_grammar = """
    foo: bar baz
    bar: "a" | "b"
    baz: "a" | "b" | "c"
    """

# Generated at 2022-06-23 15:56:26.400429
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    pg = ParserGenerator()
    start = NFAState()
    a = NFAState()
    b = NFAState()
    c = NFAState()
    finish = NFAState()

    start.addarc(a, 0)  # label 0
    a.addarc(b, 1)  # label 1
    a.addarc(c, 2)  # label 2
    b.addarc(finish)  # empty
    c.addarc(b, 3)  # label 3
    c.addarc(finish)  # empty

    dfa = pg.make_dfa(start, finish)
    assert len(dfa) == 4
    assert len(dfa[0].arcs) == 2
    assert len(dfa[1].arcs) == 1

# Generated at 2022-06-23 15:56:31.191697
# Unit test for method addarc of class DFAState
def test_DFAState_addarc():
    dfs = DFAState({}, None)
    dfs.addarc(None, None)
    assert dfs.arcs == {None: None}

# Generated at 2022-06-23 15:56:39.574907
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    ta_1 = token.NAME
    ta_2 = token.NUMBER
    ta_3 = token.OP
    ta_4 = token.STRING
    ta_5 = token.NEWLINE
    ta_6 = token.NL
    ta_7 = token.ENDMARKER
    #
    s_1 = 's : NAME "+" NAME'
    s_2 = 's : NAME "+" s'
    g = ParserGenerator()
    g.parse_string(s_1)
    c = g.make_grammar()
    # print(c.labels)

# Generated at 2022-06-23 15:56:51.434148
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    from tokenize import tokenize, untokenize, generate_tokens, COMMENT, NL
    from io import BytesIO
    s = 'print(42)\n'
    expect = [
        (token.NAME, 'print'),
        (token.OP, '('),
        (token.NUMBER, '42'),
        (token.OP, ')'),
        (token.NEWLINE, '\n'),
        (token.ENDMARKER, ''),
    ]
    g = generate_tokens(BytesIO(s.encode('utf-8')).readline)
    parser = ParserGenerator(g, "dummy")
    for ex in expect:
        parser.gettoken()

# Generated at 2022-06-23 15:56:57.387704
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    p = ParserGenerator()
    p.dfas = {
        "file_input": [
            DFAState({}, None, {0: [DFAState({}, None, {}), 0]}),
            DFAState({}, None, {}),
        ],
    }
    p.dfas["file_input"][0].addarc(p.dfas["file_input"][1], 0)
    p.dump_dfa("file_input", p.dfas["file_input"])


# Generated at 2022-06-23 15:57:08.047022
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    import tokenize
    from io import BytesIO
    from typing import Iterator, Tuple, TypeVar

    # type alias for the iterator used in the test
    Token = Tuple[int, Text, Tuple[int, int], Tuple[int, int], Text]
    TokenIterator = Iterator[Token]

    def _tokenize(x: Text) -> TokenIterator:
        class T:
            pass

        t = T()
        t.type = token.OP
        t.value = 0
        t.begin = (0, 0)
        t.end = (0, 0)
        t.line = "0\n"
        yield (token.OP, x, (0, 0), (0, 0), "0\n")

# Generated at 2022-06-23 15:57:13.669076
# Unit test for method addarc of class DFAState
def test_DFAState_addarc():
    state = DFAState({}, NFAState())
    next = DFAState({}, NFAState())
    label = "hello"
    state.addarc(next, label)
    assert state.arcs.keys() == [label], state.arcs.keys()
    assert state.arcs[label] is next

# Generated at 2022-06-23 15:57:25.194983
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    parser = ParserGenerator(tokenize.generate_tokens(StringIO("a b").readline))
    DFAState = parser.DFAState
    NFAState = parser.NFAState
    c, d = parser.parse_alt()
    assert (c.arcs, c.isfinal) == ({('a', d): 1}, False)
    assert (d.arcs, d.isfinal) == ({('b', d): 1}, False)
    assert parser.value == '' and parser.type == token.ENDMARKER

    parser = ParserGenerator(tokenize.generate_tokens(StringIO("a | b").readline))
    DFAState = parser.DFAState
    NFAState = parser.NFAState
    c, d = parser.parse_alt()

# Generated at 2022-06-23 15:57:34.899023
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
  """Test case for method simplify_dfa of class ParserGenerator"""
  def makenfa():
    a = NFAState()
    b = NFAState()
    c = NFAState()
    d = NFAState()
    e = NFAState()
    f = NFAState()
    a.addarc(b, 'f')
    a.addarc(c)
    b.addarc(d, 'g')
    c.addarc(d, 'g')
    d.addarc(e, 'h')
    d.addarc(f, 'i')
    return [a, b, c, d, e, f]
  # Example showing why you can't just take the cross product of labels
  # and states, and why you have to unify states that become equal:
  a = NFAState()

# Generated at 2022-06-23 15:57:45.079732
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    data = r"""
            s : x | y z |  #
                a | 'b' | "c" |
                'abcd' | 'ab\ndef' |
                u"abcd" | u"ab\ndef" |
                v"abcd" | v"ab\ndef"
            x : 'a'
            y : 'a'
            z : 'a'
            a : 'a'
            u : 'a'
            v : 'a'
            """
    pg = ParserGenerator()
    dfas, startsymbol = pg.parse_grammar(data)
    assert startsymbol == "s"
    assert len(dfas["s"]) == 5
    assert len(dfas["x"]) == 2
    assert len(dfas["y"]) == 2

# Generated at 2022-06-23 15:57:48.219127
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    import pgen2.grammar as grammar
    pg = ParserGenerator(grammar.grammar)
    pg.first = {}
    assert pg.make_first(None, "mock_name") is None

# Generated at 2022-06-23 15:57:55.185301
# Unit test for constructor of class DFAState
def test_DFAState():
    a = NFAState()
    z = NFAState()
    b = DFAState({a: 1}, z)
    c = DFAState({a: 1}, z)
    assert b == c
    assert hash(b) == hash(c)
    assert b is not c
    assert a is not z
    assert a in b.nfaset
    assert z in b.nfaset

# Generated at 2022-06-23 15:58:06.281361
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    # Make sure the parse_atom method of the ParserGenerator class works correctly.
    # This is tested by making sure the right values are returned
    # by the method when it is passed various tokens.

    # Set up a parser generator
    pg = ParserGenerator()

    # Retrieve a token whose type is NAME
    token = (token.NAME, "spam", (1, 2), (1, 6), "spam\n")
    # Call the parse_atom method with the token as an argument
    assert pg.parse_atom() == (pg.nfa(None, ()), pg.nfa(None, ()))

    # Retrieve a token whose type is STRING
    token = (token.STRING, "spam", (1, 2), (1, 6), "spam\n")
    # Call the parse_atom method with

# Generated at 2022-06-23 15:58:17.237153
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    # Make a trivial DFA with some states that are the same.
    dfa = [
        DFAState({}, None),
        DFAState({}, None),
        DFAState({}, None),
        DFAState({}, None),
        DFAState({}, None),
    ]
    dfa[0].addarc(dfa[1], "a")
    dfa[0].addarc(dfa[2], "b")
    dfa[3].addarc(dfa[4], "a")
    dfa[3].addarc(dfa[4], "b")
    dfa[4].addarc(dfa[1], "a")
    dfa[4].addarc(dfa[2], "b")
    # Sanity check
    assert dfa[0] != dfa[3]
   

# Generated at 2022-06-23 15:58:27.742904
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    import unittest

    class Test_calcfirst(unittest.TestCase):
        def test_simple(self):
            pg = ParserGenerator()
            pg.dfas = {"foo": [DFAState({}, False), DFAState({}, False)]}
            pg.calcfirst("foo")
            self.assertEqual(pg.first["foo"], {})

        def test_disambiguate(self):
            pg = ParserGenerator()
            a, b, c, d, e, f = [DFAState({}, False) for i in range(6)]

# Generated at 2022-06-23 15:58:36.002991
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    with StringIO("a: b c") as f:
        pg = ParserGenerator()
        dfas, startsymbol = pg.parse_grammar(f)
        assert sorted(dfas) == ["a", "b", "c"]
        dfa = pg.make_dfa(dfas["a"][0], dfas["a"][-1])
        assert len(dfa) == 2
        assert sorted(dfa[0].arcs) == ["b"]
        assert dfa[0].arcs["b"][0].label == "c"
        assert dfa[0].arcs["b"][0].next is dfa[1]
        assert dfa[1].arcs == {}
        assert dfa[1].isfinal
        assert dfa[1] is dfas["a"][-1]


# Generated at 2022-06-23 15:58:37.946190
# Unit test for constructor of class DFAState
def test_DFAState():
    class Dummy:
        pass
    a = DFAState({Dummy(): 1}, Dummy())
    a.addarc(Dummy(), "label")


# Generated at 2022-06-23 15:58:41.486214
# Unit test for function generate_grammar
def test_generate_grammar():
    print("Testing %s..." % generate_grammar.__name__)
    grammar = generate_grammar("Grammar.txt")
    print("Test finished")
#
# generator.py ends here

# Generated at 2022-06-23 15:58:49.819429
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    source = """\
expr: expr '+' term
expr: expr '-' term
expr: term
term: '0'
term: '1'
"""
    pgen = ParserGenerator()
    dfas, startsymbol = pgen.parse_grammar(io.StringIO(source))
    print("dfas =", dfas)
    print("startsymbol =", startsymbol)
    dfa = dfas["expr"]
    pgen.dump_dfa("expr", dfa)

# Generated at 2022-06-23 15:58:55.074133
# Unit test for constructor of class NFAState
def test_NFAState():
    a = NFAState()
    b = NFAState()
    c = NFAState()

    a.addarc(b)
    assert a.arcs[0][1] == b
    a.addarc(b, "x")
    assert a.arcs[1][1] == b
    assert a.arcs[1][0] == "x"



# Generated at 2022-06-23 15:59:05.700137
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    pgen_grammar = PgenGrammar()
    assert pgen_grammar.labels == set()
    assert pgen_grammar.keywords == []
    assert pgen_grammar.start == None
    assert pgen_grammar.symbol2number is None
    assert pgen_grammar.number2symbol is None
    assert pgen_grammar.tokens is None
    assert pgen_grammar.states is None
    assert pgen_grammar.dfas is None
    assert pgen_grammar.labels == set()
    assert pgen_grammar.nonterminal2number is None
    assert pgen_grammar.number2nonterminal is None
    assert pgen_grammar.states is None
    assert pgen_grammar.rules is None
    assert pgen_grammar

# Generated at 2022-06-23 15:59:16.422933
# Unit test for method __eq__ of class DFAState
def test_DFAState___eq__():
    for self_args, other_args, expected in [
        (({}, NFAState()), ({}, NFAState()), True),
        (({1: None}, NFAState()), ({}, NFAState()), False),
        (({}, NFAState()), ({1: None}, NFAState()), False),
        (({1: None}, NFAState()), ({1: None}, NFAState()), True),
        (({1: None, 2: None}, NFAState()), ({1: None, 2: None}, NFAState()), True),
        (({1: None}, NFAState()), ({1: None, 2: None}, NFAState()), False),
        (({1: None, 2: None}, NFAState()), ({1: None}, NFAState()), False),
    ]:
        self

# Generated at 2022-06-23 15:59:26.996956
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    def _test(orig, type, value, raises=False):
        generator = ParserGenerator(orig)
        if raises:
            try:
                generator.expect(type, value)
            except SyntaxError:
                pass
            else:
                raise AssertionError("Did not raise expected SyntaxError")
        else:
            assert generator.expect(type, value) == value
            assert (generator.type, generator.value) == (token.ENDMARKER, "")

    _test("# comment\n", token.NEWLINE, None)
    _test("# comment\n", token.ENDMARKER, None)
    _test("# comment\n", token.NAME, None, raises=True)

    _test("test\n", token.NAME, "test")

# Generated at 2022-06-23 15:59:30.965766
# Unit test for constructor of class NFAState
def test_NFAState():
    start = NFAState()
    other = NFAState()
    start.addarc(other, "label")
    assert start.arcs == [("label", other)]
    assert other.arcs == []
    start.addarc(other)
    assert start.arcs == [("label", other), (None, other)]
    assert other.arcs == []


# Generated at 2022-06-23 15:59:37.192914
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    pg = pgen.ParserGenerator()
    assert pg.dfas == {}
    assert pg.labels == []
    assert pg.keywords == {}
    assert pg.tokens == {}
    assert pg.start == 0
    assert pg.states == []
    assert pg.symbol2label == {}
    assert pg.symbol2number == {}
    assert pg.first == {}



# Generated at 2022-06-23 15:59:45.169606
# Unit test for method addarc of class NFAState
def test_NFAState_addarc():
    nfa1 = pygram.NFAState()
    nfa2 = pygram.NFAState()
    nfa3 = pygram.NFAState()
    nfa1.addarc(nfa2, "a")
    assert nfa1.arcs == [(None, nfa2)]
    nfa2.addarc(nfa1)
    assert nfa2.arcs == [(None, nfa1)]
    nfa1.addarc(nfa3, "b")
    assert nfa1.arcs == [(None, nfa2), (None, nfa3)]



# Generated at 2022-06-23 15:59:48.504378
# Unit test for constructor of class NFAState
def test_NFAState():
    f = NFAState()
    g = NFAState()
    f.addarc(g, "a")
    assert f.arcs == [("a", g)], f.arcs



# Generated at 2022-06-23 15:59:57.828303
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    pg = ParserGenerator()

# Generated at 2022-06-23 16:00:04.178090
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    p = ParserGenerator()
    s = """
    a: b c
    b: d | e
    c: d | e
    d: 'd' | 'D'
    e: 'e'
    """
    p.parse_grammar(s)
    d = p.make_dfa(p.dfas["d"], p.dfas["e"])
    p.dump_dfa("d", d)


# Generated at 2022-06-23 16:00:14.584860
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():
    a = DFAState({}, None)
    b = DFAState({}, None)
    c = DFAState({}, None)
    a.addarc(b, 'a')
    a.addarc(c, 'b')
    b.addarc(b, 'a')
    # unify b and c
    a.unifystate(b, c)
    # make sure what's left is a->c->c->c
    assert a.arcs['a'] == c
    assert c.arcs['a'] == c
    assert c.arcs['b'] == c

# Generated at 2022-06-23 16:00:16.468823
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    assert isinstance(PgenGrammar(), PgenGrammar)



# Generated at 2022-06-23 16:00:18.250676
# Unit test for function generate_grammar
def test_generate_grammar():
    assert generate_grammar(Path(__file__).parent.parent / "Grammar.txt") is not None



# Generated at 2022-06-23 16:00:27.360452
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    # RHS: ALT ('|' ALT)*
    p = ParserGenerator()
    p.gettoken = lambda: None
    p.value = "|"
    p.parse_alt()
    p.value = "("
    p.parse_alt()
    p.value = "["
    p.parse_alt()
    p.type = token.NAME
    p.parse_alt()
    p.type = token.STRING
    p.parse_alt()
    p.type = "INVALID"
    try:
        p.parse_alt()
    except SyntaxError:
        pass
    else:
        raise RuntimeError
test_ParserGenerator_parse_alt()


# Generated at 2022-06-23 16:00:32.569285
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    pg = ParserGenerator()
    pg.dfas["NT"] = [DFAState({NFAState(): 1}, NFAState())]
    pg.dfas["NT"][0].addarc(pg.dfas["NT"][0], "x")
    pg.dfas["NT"][0].addarc(pg.dfas["NT"][0], "y")
    pg.dfas["NT"][0].addarc(pg.dfas["NT"][0], None)
    pg.addfirstsets()
    assert pg.first["NT"] == {"x": 1, "y": 1}

# Generated at 2022-06-23 16:00:35.672863
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    pg = ParserGenerator()
    # Currently, only tests that it doesn't crash.  (It gets exceptions
    # from the tokenize module.)
    assert pg.gettoken() is None


# Generated at 2022-06-23 16:00:39.796386
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    if sys.flags.optimize >= 2:
        pytest.skip("Docstrings are omitted with -O2 and above")
    p = ParserGenerator()
    p.parse(ParserGenerator.__doc__)
    assert p.startsymbol == "file_input"


########################################################################
# Grammar validator
#


# Generated at 2022-06-23 16:00:50.513278
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():

    def convert(s):
        return ParserGenerator(s).convert()

    def check_grammar(c, symbols):
        assert list(c.symbol2number.keys()) == symbols
        for i, name in enumerate(symbols):
            assert c.symbol2number[name] == i
            assert c.number2symbol[i] == name

    def check_dfas(c, states, dfas, first):
        for name, (expect_states, expect_first) in sorted(dfas.items()):
            i = c.symbol2number[name]
            assert c.states[i] == expect_states
            assert c.dfas[i][1] == expect_first
        assert c.states == states


# Generated at 2022-06-23 16:01:03.291952
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    def check(pg: ParserGenerator) -> None:
        assert pg.type == token.NAME
        assert pg.value == "abc"
        assert pg.begin == (1, 0)
        assert pg.end == (1, 3)
        # XXX What is expected here?
        assert pg.line == "abcdef\n"

    def gen():
        # yield tokenize.ENCODING, 'utf-8', (1, 0), (1, 0), ''
        yield (token.NAME, "abc", (1, 0), (1, 3), "abcdef\n")
        yield (token.NEWLINE, "\n", (1, 3), (1, 4), "abcdef\n")
        yield (token.NAME, "def", (2, 0), (2, 3), "abcdef\n")

# Generated at 2022-06-23 16:01:10.949295
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    p = ParserGenerator()

# Generated at 2022-06-23 16:01:14.823444
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    pg = ParserGenerator()
    pg.parse()

    print("\nUnit test for method dump_nfa of class ParserGenerator")
    print("-- Expect output to be a human readable form of the NFA")

# Generated at 2022-06-23 16:01:20.651181
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    g = ParserGenerator("grammar.txt")
    assert g.type == token.ENDMARKER
    g.gettoken()  # throws away ENDMARKER
    assert g.parse_rhs() == (
        NFAState(set([NFAState(set([NFAState(set([NFAState({})])), NFAState({})]))])),
        NFAState({}),
    )
    assert g.type == token.ENDMARKER
    print("test_ParserGenerator_parse_rhs ok")