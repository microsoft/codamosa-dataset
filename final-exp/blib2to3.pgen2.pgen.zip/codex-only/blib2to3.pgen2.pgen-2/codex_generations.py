

# Generated at 2022-06-23 15:51:23.246588
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    parser = ParserGenerator("grammar.txt")

# Generated at 2022-06-23 15:51:30.237323
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    """Unit test for method make_first."""
    pg = ParserGenerator()
    g = Grammar(
        startsymbol="file_input",
        symbols=[
            Nonterminal("file_input"),
            Nonterminal("stmt"),
            Nonterminal("compound_stmt"),
            Nonterminal("small_stmt"),
            Nonterminal("expr_stmt"),
            Nonterminal("print_stmt"),
        ],
    )
    grammar.GrammarCodeGenerator(g).write("Grammar.py")
    pg.loadgrammar("Grammar.py")
    pg.parsetable()
    # pg.generate_parser("parser.py", "Grammar.py", 1)


# Generated at 2022-06-23 15:51:31.066312
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    PgenGrammar()



# Generated at 2022-06-23 15:51:39.702033
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    pg = ParserGenerator()

# Generated at 2022-06-23 15:51:45.015901
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    pg = ParserGenerator()
    pg.dfas = {
        "x": [DFAState({NFAState('1'): 1}, NFAState('3'))],
        "y": [DFAState({NFAState('2'): 1}, NFAState('3'))]
    }
    a = NFAState()
    z = NFAState()
    a.addarc(NFAState('1'))
    a.addarc(NFAState('2'))
    z.addarc(NFAState('3'))
    dfa = pg.make_dfa(a, z)
    assert dfa == [DFAState({NFAState('1'): 1, NFAState('2'): 1}, NFAState('3'))]

# Generated at 2022-06-23 15:51:56.369457
# Unit test for constructor of class DFAState
def test_DFAState():
    nfa0 = NFAState()
    nfa1 = NFAState()
    nfa2 = NFAState()
    nfa3 = NFAState()
    nfa0.addarc(nfa1, "a")
    nfa1.addarc(nfa2, "b")
    nfa2.addarc(nfa3, "c")
    dfa0 = DFAState({nfa0: 1, nfa1: 1}, nfa1)
    assert dfa0.nfaset == {nfa0: 1, nfa1: 1}
    assert dfa0.isfinal
    assert dfa0.arcs == {"a": DFAState({nfa1: 1, nfa2: 1}, nfa2)}
    dfa1 = dfa0.arcs["a"]
    assert d

# Generated at 2022-06-23 15:52:08.919980
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():
    a = DFAState({}, None)
    b = DFAState({}, None)
    c = DFAState({}, None)
    a.arcs[0] = b
    a.arcs[1] = c
    b.arcs[0] = c
    a.unifystate(b, c)
    if a.arcs != {0: c, 1: c} or b.arcs != {0: c} or c.arcs != {}:
        print("b", a.arcs, b.arcs, c.arcs)
        assert False
    a.unifystate(c, b)

# Generated at 2022-06-23 15:52:14.600982
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    g = PgenGrammar()
    assert isinstance(g, grammar.Grammar)
    assert isinstance(g, PgenGrammar)

g = PgenGrammar()


# Generated at 2022-06-23 15:52:17.451754
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    import sys
    import tokenize
    from io import StringIO
    pg = ParserGenerator()
    pg.build(StringIO(GRAMMAR))
    pg.check_all()



# Generated at 2022-06-23 15:52:24.573911
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():
    # First, generate a graph with cycles...
    a, b, c, d, e, f, g, h, i, j, k, l, m, n, o, p, q, r, s, t, u, v, w, x, y, z = [
        DFAState({}, None) for _ in range(26)
    ]
    a.addarc(a, "A")
    a.addarc(b, "B")
    b.addarc(c, "C")
    c.addarc(d, "D")
    d.addarc(e, "E")
    e.addarc(f, "F")
    f.addarc(g, "G")
    g.addarc(h, "H")
    h.addarc(i, "I")

# Generated at 2022-06-23 15:52:35.895516
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    def check(text, result):
        p = ParserGenerator()
        p.setup_parser("foo", text)
        a, z = p.parse_item()
        check_NFAState(a, result[0])
        check_NFAState(z, result[1])
    yield check, "([a-z] | [0-9])+", (((("[",), ((("a", "-" "z"),), (("|",), ((("[",), ((("0", "-" "9"),), ("]",)))))), ("]",))), (("+",),))
    yield check, "[a-z]", ((("[",), ((("a", "-" "z"),), ("]",))),)
    yield check, "a", (("a",),)

# Generated at 2022-06-23 15:52:41.851024
# Unit test for constructor of class NFAState
def test_NFAState():
    a = NFAState()
    b = NFAState()
    a.addarc(b)
    assert a.arcs == [(None, b)]
    c = NFAState()
    b.addarc(c, "test")
    assert b.arcs == [("test", c)]
    d = NFAState()
    c.addarc(d)
    assert c.arcs == [(None, d)]



# Generated at 2022-06-23 15:52:53.510387
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    pg = ParserGenerator()
    a = NFAState()
    z = NFAState()
    a.addarc(z, "a")
    a.addarc(z, "b")
    a.addarc(z, "c")

    dfa = pg.make_dfa(a, z)
    assert len(dfa) == 2
    assert len(dfa[0].arcs) == 3
    assert sorted(dfa[0].arcs) == [("a", dfa[1]), ("b", dfa[1]), ("c", dfa[1])]
    assert dfa[0].nfaset == {a: 1, z: 1}
    assert dfa[1].nfaset == {z: 1}

    assert isinstance(dfa[0], DFAState)

# Generated at 2022-06-23 15:53:06.393807
# Unit test for constructor of class DFAState
def test_DFAState():
    # With mypyc, the test below only works if the class checker is disabled.
    # The reason is that in the test below, we create a new DFAState class and
    # call it DFAState2.  This does not work if the class checker is enabled,
    # because the class checker assumes that all class names are globally
    # unique.  In the test, this assumption leads to a type error in
    # "return nfaset".  Note that it is not a problem to disable the class
    # checker, because we only use the new DFAState class in this test function,
    # and we are confident that the original DFAState class behaves correctly.
    # See https://github.com/python/mypy/issues/7879 for details.

    DFAState2 = DFAState

    # Test __eq__
    #

# Generated at 2022-06-23 15:53:10.746981
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    with open("Grammar.txt", "r") as f:
        try:
            p = ParserGenerator()
            dfas, startsymbol = p.parse_grammar(f)
            p.addfirstsets()
            c = p.make_pgen_grammar()
            p.dump_dfa("file_input", dfas["file_input"])
        except Exception as e:
            print("  Error: %s" % e, file=sys.stderr)
            raise

# Generated at 2022-06-23 15:53:21.187789
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    class MyDFAState:
        def __init__(self, nfaset: "Dict[NFAState, int]", isfinal: bool) -> None:
            self.nfaset = nfaset
            self.isfinal = isfinal
            self.arcs: Dict[str, "MyDFAState"] = {}

        def addarc(self, next: "MyDFAState", label: str) -> None:
            self.arcs[label] = next

        def __eq__(self, other: Any) -> bool:
            assert isinstance(other, MyDFAState)
            return self.arcs == other.arcs


# Generated at 2022-06-23 15:53:27.903313
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    p = ParserGenerator()
    p.dfas["foo"] = [DFAState({NFAState(): 1}, False)]
    c = PgenGrammar()
    c.symbol2number["foo"] = 123
    c.symbol2label["foo"] = 234
    assert p.make_first(c, "foo") == {234: 1}


# Generated at 2022-06-23 15:53:35.347129
# Unit test for constructor of class DFAState
def test_DFAState():
    a = NFAState()
    b = NFAState()
    c = NFAState()
    d = NFAState()
    state1 = DFAState({a, b, c}, c)
    state2 = DFAState({d, b, c}, d)
    assert state1 != state2
    assert state1 != object()
    state3 = DFAState({a, b, c}, c)
    assert state1 == state3


# Generated at 2022-06-23 15:53:42.532137
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    # Test constructor
    assert PgenGrammar.__doc__ is None
    assert PgenGrammar.__init__.__doc__ is None
    assert PgenGrammar.__module__ == "blib2to3.pgen2.pgen"
    assert PgenGrammar.__qualname__ == "PgenGrammar"
    assert PgenGrammar.__dict__ == {}
    assert PgenGrammar.__annotations__ == {}
    # Test instance
    PgenGrammar()



# Generated at 2022-06-23 15:53:50.174944
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    pg = ParserGenerator()
    r = pg.adddfa()
    r.addstate(1)
    r.addstate(0)
    r.curstate.addarc(r.states[0], "a")
    r.curstate.addarc(r.states[1], "b")
    s = pg.adddfa()
    s.curstate.isfinal = True
    s.addstate(1)
    s.addstate(0)
    t = pg.adddfa()
    t.curstate.isfinal = True
    s.curstate.addarc(s.states[0], "c")
    s.curstate.addarc(t.states[0], "d")
    t.curstate.addarc(t.states[1], "e")

# Generated at 2022-06-23 15:53:59.892586
# Unit test for method make_grammar of class ParserGenerator

# Generated at 2022-06-23 15:54:05.136185
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    start = time.process_time()
    pg = ParserGenerator()
    pg.make_grammar()
    assert pg.startsymbol is not None
    assert pg.dfas is not None
    assert pg.first is not None
    end = time.process_time()
    print("test_ParserGenerator_make_grammar()",end-start,"seconds")

# Generated at 2022-06-23 15:54:11.205596
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():

    def _raise_error(msg, type, value):
        assert msg == 'expected %s/%s, got %s/%s' % (type, '-', 32, value)

    parser = ParserGenerator()
    parser.type = 32
    parser.value = '-'
    parser._ParserGenerator__raise_error = _raise_error
    assert_raises(SyntaxError, parser.expect, token.OP, '-')

# Generated at 2022-06-23 15:54:18.554764
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    import pgen2.parse
    from pgen2.parse import ParserGenerator
    from pgen2.pgen import PgenGrammar, PgenParser
    from pgen2.convert import Converter
    from pgen2.pgen2 import Grammar
    from pgen2.grammar import pgen_grammar, token
    #
    # Create example ParserGenerator
    #
    pg = ParserGenerator()
    pg.load_grammar(pgen_grammar)
    pg.parse()
    pg.addfirstsets()
    #
    # Create example PgenGrammar
    #
    converter = Converter()
    pgg = converter.make_grammar(pg)
    #
    # Create example PgenParser
    #

# Generated at 2022-06-23 15:54:30.812703
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():
    a = DFAState({}, None)
    assert a.unifystate(a, a) == None, "unifystate  a -> a"
    b = DFAState({}, None)
    a.arcs[42] = b
    assert a.unifystate(b, a) == None, "unifystate b -> a"
    assert a.arcs == {42:a}, "unifystate b -> a"
    c = DFAState({}, None)
    a.arcs[42] = c
    assert a.unifystate(c, b) == None, "unifystate c -> b"
    assert a.arcs == {42:b}, "unifystate c -> b"
    d = DFAState({}, None)
    a.arcs[42] = d
    assert a.unifystate

# Generated at 2022-06-23 15:54:32.792365
# Unit test for constructor of class PgenGrammar

# Generated at 2022-06-23 15:54:44.314819
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    import io
    from tempfile import TemporaryFile

    def check(text: Text, expected: Text) -> None:
        with TemporaryFile() as tf:
            tf.write(text.encode("utf-8"))
            tf.seek(0)
            idx = io.TextIOWrapper(tf)
            gen = Scanner(idx)
            pgen = ParserGenerator(gen, "<test_data>")

            tup = pgen.parse_rhs()
            assert repr(tup) == expected

    check("a", "(NFAState(), NFAState('a'))")
    check("a | b", "(NFAState('a', 'b'), NFAState('a', 'b'))")

# Generated at 2022-06-23 15:54:50.966367
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    import sys
    import io
    import tokenize
    generator = ParserGenerator(io.BytesIO(b"\n"), "f", tokenize.generate_tokens).generator
    token = next(generator)
    assert token == (tokenize.NEWLINE, "\n", (1, 0), (1, 1), "\n")
    token = next(generator)
    assert token == (0, "", (2, 0), (2, 0), "")



# Generated at 2022-06-23 15:55:03.500784
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    s = """
    some code
    # comment
    # another comment
    name : string | string | string
    more code
    """
    p = ParserGenerator(s.split("\n")[1:-1])
    assert p.gettoken() is None
    assert p.type == token.NAME
    assert p.value == "name"
    assert p.gettoken() is None
    assert p.type == token.OP
    assert p.value == ":"
    assert p.gettoken() is None
    assert p.type == token.NAME
    assert p.value == "string"
    assert p.gettoken() is None
    assert p.type == token.OP
    assert p.value == "|"
    assert p.gettoken() is None
    assert p.type == token.NAME
    assert p.value

# Generated at 2022-06-23 15:55:11.554186
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():

    pg = ParserGenerator()
    pg.generator = [(51, 'if', (1, 0), (1, 2), '#if 1\n')]
    pg.type = 51
    pg.value = 'if'
    pg.begin = (1, 0)
    pg.end = (1, 2)
    pg.line = '#if 1\n'

    assert pg.expect(51, 'if') == 'if'


# Generated at 2022-06-23 15:55:18.867900
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    """Assert dump_dfa of ParserGenerator dumps a DFA"""
    import tempfile
    with tempfile.NamedTemporaryFile("w", prefix="grammar") as fd:
        fd.write("""
            test: a | b
            a: 'a'
            b: 'b'
        """)
        fd.flush()
        _, startsymbol = ParserGenerator().parse_grammar_file(fd.name)
        assert startsymbol == "test", startsymbol
        # Construct the NFA of the 'a' production
        aa = NFAState()
        za = NFAState()
        aa.addarc(za, 'a')
        # Construct the NFA of the 'b' production
        ab = NFAState()
        zb = NFAState()
       

# Generated at 2022-06-23 15:55:22.980709
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    p = ParserGenerator()
    p.initdfas()
    p.calcfirst("factor")
    assert p.first["factor"] == {"NAME": 1, "(": 1, "NUMBER": 1}


# End of unit test for method calcfirst of class ParserGenerator

# Generated at 2022-06-23 15:55:33.519422
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    """This is a simple unit test for make_grammar()."""

    def compare_grammars(grammar1: Dict[Text, Dict[Text, List[Tuple[Text, Text]]]],
                         grammar2: Dict[Text, Dict[Text, List[Tuple[Text, Text]]]]) -> bool:
        """Compare two grammars for equality.

        The two grammars are identical, if for each key of 'grammar1' there is a key
        with the same name in 'grammar2' and if the two associated mappings have the
        same keys and the values are equal, when the values are a list, otherwise the
        values are compared by identity."""

        assert len(grammar1) == len(grammar2)
        for key, mapping in grammar1.items():
            assert key in grammar2


# Generated at 2022-06-23 15:55:42.799949
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
  tp = ParserGenerator()
  tp.gettoken = lambda: None
  tp.type = 10
  tp.value = 20
  tp.begin = (30, 40)
  tp.end = (50, 60)
  tp.line = "some_line"
  assert tp.expect(token.NUMBER) == 20
  #raise AssertionError()

  # Testing for exception
  # SyntaxError: expected NUMBER/None, got 10/20 ((<string>, 50, 60, some_line))
  #tp.type = 10
  #tp.value = 20
  #tp.expect(token.NUMBER)



# Generated at 2022-06-23 15:55:51.770159
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    class DFAState:
        def __init__(self) -> None:
            self.nfaset = {}  # type: Dict[NFAState, int]
            self.accept = 0  # 0 for undefined, -1 for no, 1 for yes
            self.arcs = {}  # type: Dict[str, DFAState]

        def addarc(self, next: "DFAState", a: Text) -> None:
            self.arcs[a] = next

        def unifystate(self, oldstate: "DFAState", newstate: "DFAState") -> None:
            # print "unifystate", self, oldstate, newstate
            arcs = []
            for label, next in self.arcs.items():
                if next is oldstate:
                    next = newstate

# Generated at 2022-06-23 15:55:53.106804
# Unit test for function generate_grammar
def test_generate_grammar():
    p = ParserGenerator("grammar.txt")
    p.make_grammar()
    assert p.dfas

# Generated at 2022-06-23 15:56:04.180140
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    pg = ParserGenerator()
    dfa = [
        DFAState({NFAState(): 1}, False),
        DFAState({NFAState(): 1, NFAState(): 1}, True),
        DFAState({NFAState(): 1}, False),
        DFAState({NFAState(): 1}, False),
    ]
    dfa[0].addarc(dfa[2], "a")
    dfa[0].addarc(dfa[3], "b")
    dfa[1].addarc(dfa[2], "b")
    dfa[1].addarc(dfa[3], "a")
    dfa[2].addarc(dfa[0], "c")
    dfa[2].addarc(dfa[0], "d")

# Generated at 2022-06-23 15:56:05.836732
# Unit test for function generate_grammar
def test_generate_grammar():
    p = ParserGenerator("Grammar.txt")
    p.make_grammar()
    #p.dump_grammar()
    #print(p.first, p.dfas)


if __name__ == "__main__":
    generate_grammar()

# Generated at 2022-06-23 15:56:06.688207
# Unit test for function generate_grammar
def test_generate_grammar():
    grammar = generate_grammar()
    assert "funcdef" in grammar.symbol2number

# Generated at 2022-06-23 15:56:16.025211
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    def dump(dfas):
        for i, states in enumerate(dfas):
            print(i, states[0].isfinal)
            for j, state in enumerate(states):
                for label, next in state.arcs.items():
                    print(j, label, states.index(next))

    s = """
    s: '<' t '>'
    t: '<' '>' | NAME
    """
    s = s.replace("\n", " ").replace("\t", " ")
    pg = ParserGenerator()
    dfas, startsymbol = pg.pgen(s)
    print("%r\n%r" % (dfas, startsymbol))
    if 0:
        dump(dfas)

    assert startsymbol == "s"

# Generated at 2022-06-23 15:56:19.643072
# Unit test for function generate_grammar
def test_generate_grammar():
    p = ParserGenerator("Grammar.txt")
    p.make_grammar()
    return True

if __name__ == "__main__":
    generate_grammar()

# Generated at 2022-06-23 15:56:31.656921
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    pg = ParserGenerator()
    pg.filename = "unknown"
    pg.line = ""
    pg.generator = tokenize.generate_tokens(StringIO("").readline)
    pg.gettoken()
    pg.begin = (1, 0)
    pg.end = (1, 0)
    pg.next = None

# Generated at 2022-06-23 15:56:39.615818
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    pg = ParserGenerator()
    c = pg.convert(open("Grammar.txt"))
    assert c.make_first(c, "dotted_name") == {
        2: 1,
        18: 1,
        51: 1,
        53: 1,
        54: 1,
        55: 1,
        56: 1,
        57: 1,
        58: 1,
        59: 1,
        60: 1,
        61: 1,
        62: 1,
        63: 1,
        64: 1,
        65: 1,
        66: 1,
        67: 1,
        68: 1,
        69: 1,
        70: 1,
    }


# Generated at 2022-06-23 15:56:46.261296
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    inp = io.StringIO("'string'")
    t = tokenize.generate_tokens(inp.readline)
    g = ParserGenerator(t, "?")
    a, z = g.parse_atom()
    assert g.value == ""
    assert a.arcs == {("'string'", z)}




# Generated at 2022-06-23 15:56:56.340193
# Unit test for function generate_grammar
def test_generate_grammar():
    p = ParserGenerator("Grammar.txt")
    import collections

    class MyFormatter(collections.OrderedDict):
        def __init__(self) -> None:
            collections.OrderedDict.__init__(self)
            self.lineno = 1

        def dump(self, opener: str, key: str) -> None:
            print("case %d:" % self.lineno, end=" ")
            self.lineno += 1
            if opener:
                print("%s %s ;" % (opener, key), end=" ")
            print("send:", self.get(key, "nil"))

        def finish(self) -> None:
            print("end.")
            print()
            for value, key in self:
                print("%s:" % key, value)


# Generated at 2022-06-23 15:57:03.713983
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    with open(os.path.join(os.path.dirname(__file__), "Grammar")) as f:
        pg = ParserGenerator(f.readline)
    pg.dfas = {
        "file_input": [
            DFAState({NFAState(1, None): 1}, 0),
            DFAState({NFAState(2, None): 1}, 0),
        ],
        "stmt": [
            DFAState({NFAState(3, None): 1}, 0),
            DFAState({NFAState(4, None): 1}, 0),
        ],
        "simple_stmt": [
            DFAState({NFAState(5, None): 1}, 0),
            DFAState({NFAState(6, None): 1}, 0),
        ],
    }
    pgen

# Generated at 2022-06-23 15:57:16.150257
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    import sys
    from collections import ChainMap
    from typing import Tuple, List
    from pgen2.grammar import Grammar
    from pgen2.pgen import PgenGrammar, PgenParser

    name = "1+*2"
    d = {
        "name": name,
        "grammar": """
            # Grammar for simple arithmetic expressions
            expr: term ('+' term)*
            term: factor ('*' factor)*
            factor: NAME | atom('(' expr ')')
            atom: '(' expr ')'
        """,
    }
    g = Grammar(ChainMap(d))
    pg = ParserGenerator(g)
    p = PgenParser(PgenGrammar(pg.convert()))
    startsymbol = pg.startsymbol

# Generated at 2022-06-23 15:57:19.993914
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    pg = ParserGenerator()
    pg.parse("foo: 'bar'  baz 'zip'")
    pg.parse("foo: 'bar' | 'baz' | 'zip'")



# Generated at 2022-06-23 15:57:26.930142
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    pg = ParserGenerator()
    try:
        pg.raise_error("error")
    except SyntaxError as exc:
        assert isinstance(exc.filename, str)
        assert isinstance(exc.lineno, int)
        assert isinstance(exc.offset, int)
        assert isinstance(exc.text, str)
        assert exc.msg == "error"
    else:
        raise AssertionError



# Generated at 2022-06-23 15:57:36.936862
# Unit test for constructor of class NFAState
def test_NFAState():
    a = NFAState()
    b = NFAState()
    a.addarc(b)
    # NFAState(arcs=[])
    # self.assertEqual(str(a), 'NFAState(arcs=[(None, <NFAState at 0x7fb92bb2a5c0>)])')
    # self.assertEqual(str(b), 'NFAState(arcs=[])')
    from types import TracebackType
    import sys


# Generated at 2022-06-23 15:57:46.457853
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    from . import grammar
    from . import token
    import io
    import tokenize

    g = grammar.Grammar(grammar._L)

    def gettokens(astr: str) -> Iterator[tokenize.TokenInfo]:
        tokengen = tokenize.generate_tokens(io.StringIO(astr).readline)
        for tok in tokengen:
            yield tok

    def pgi(x: str) -> Tuple["NFAState", "NFAState"]:
        return ParserGenerator(g.dfas, "xxx", gettokens(x)).parse_item()

    a, z = pgi("(a | b)")

# Generated at 2022-06-23 15:57:50.061347
# Unit test for constructor of class DFAState
def test_DFAState():
    nfa1 = NFAState()
    nfa2 = NFAState()
    nfa3 = NFAState()
    nfa1.addarc(nfa2, "label1")
    nfa1.addarc(nfa3, "label2")
    dfa = DFAState({nfa1: 1, nfa2: 1, nfa3: 1}, nfa3)
    assert dfa.isfinal
    assert dfa.arcs == {"label1": dfa, "label2": dfa}



# Generated at 2022-06-23 15:57:50.893948
# Unit test for constructor of class NFAState
def test_NFAState():
    a = NFAState()  # type: ignore


# Generated at 2022-06-23 15:58:01.156777
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    '''Test case for the ParserGenerator.parse_atom method'''
    pg = ParserGenerator()
    tok_list = pg.tokenize("simple : atom ;")
    tok_iter = iter(tok_list)
    pg.generator = tok_iter
    pg.gettoken() # Discard "simple"
    pg.gettoken() # Discard ":"
    t = "atom"
    pg.type, pg.value = tok_list[-2]
    a, z = pg.parse_atom()
    assert t == pg.value, f"Wrong return value: {pg.value}, expected {t}"
    assert pg.value in a.arcs, "Expected {t} to be in arcs"

# Generated at 2022-06-23 15:58:13.415738
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    p = ParserGenerator(StringIO("a b c"))
    p.gettoken()
    assert p.expect(token.NAME) == "a"
    assert p.expect(token.NAME, "b") == "b"
    assert p.expect(token.NAME, "b") == "b"
    assert p.expect(token.NAME, "b") == "b"
    assert p.expect(token.NAME, "c") == "c"
    with pytest.raises(SyntaxError):
        p.expect(token.NAME)
    with pytest.raises(SyntaxError):
        p.expect(token.NAME, "d")



# Generated at 2022-06-23 15:58:19.964787
# Unit test for method addarc of class DFAState
def test_DFAState_addarc():
    a, b = DFAState({}, None), DFAState({}, None)
    a.addarc(b)  # OK
    pytest.raises(AssertionError, a.addarc, b, 'a') # label is not None
    pytest.raises(AssertionError, a.addarc, 1) # next is not a DFAState


# Generated at 2022-06-23 15:58:27.095561
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    pgen = ParserGenerator()
    pgen.dfas['expr'] = [ DFAState({NFAState([]): 1, NFAState([]): 1}, NFAState([]))]
    # pgen.startsymbol = 'expr'
    pgen.dfas['expr'][0].isfinal = True
    pgen.dfas['expr'][0].addarc(DFAState({NFAState([]): 1, NFAState([]) : 1}, NFAState([])), '+')
    pgen.dfas['expr'][0].addarc(DFAState({NFAState([]): 1, NFAState([]) : 1}, NFAState([])), '-')

# Generated at 2022-06-23 15:58:29.023453
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    assert PgenGrammar is not None

# Parse grammar file and return information needed
# to load parser module.

# Generated at 2022-06-23 15:58:31.024386
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    pg = ParserGenerator()
    pg.addfirstsets()


# Generated at 2022-06-23 15:58:40.817643
# Unit test for constructor of class NFAState
def test_NFAState():
    nfaS = NFAState()
    assert len(nfaS.arcs) == 0
    nfaS.addarc(NFAState())
    assert len(nfaS.arcs) == 1
    assert nfaS.arcs[0] == (None, NFAState())
    nfaS.addarc(NFAState(), 'a')
    assert len(nfaS.arcs) == 2
    assert nfaS.arcs[1] == ('a', NFAState())
    return nfaS

test_NFAState()  # remove this line for better performance

# DFAState represents a state in a DFA.
# .nfaset is the (possibly empty) set of NFA states that it
# represents; .isfinal is true if any of these NFA states is final.
# .arc

# Generated at 2022-06-23 15:58:48.162386
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    """
    test_ParserGenerator_make_grammar is unit test for method make_grammar of class ParserGenerator
    """
    # Input
    pg = ParserGenerator()
    pg.add_symbol(
        "spam",
        [
            ("[", "]", pg.pass_symbol, pg.pass_symbol, "arglist"),
            ("name", pg.pass_symbol, None, None, None),
            ("(", ")", "arglist", pg.pass_symbol, None),
        ],
    )
    pg.add_symbol(
        "arglist",
        [
            ("name", pg.pass_symbol, ",", "arglist", None),
            ("name", pg.pass_symbol, None, None, None),
        ],
    )
    #

# Generated at 2022-06-23 15:58:52.171526
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    p = ParserGenerator()
    p.dfas = {}
    p.value = '('
    p.gettoken = lambda : None
    assert p.parse_alt() == (None, None), "parse_alt() fails"

# Generated at 2022-06-23 15:59:03.120396
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    def check(dfa : List["DFAState"]) -> None:
        ParserGenerator.simplify_dfa(None, dfa)
        # Check it's in canonical form
        arcs = [tuple(sorted(state.arcs.items())) for state in dfa]
        assert len(arcs) == len(set(arcs)), "Not in canonical form"
    check([DFAState({}, None)])
    check([DFAState({}, None), DFAState({}, None)])
    check([DFAState({}, None), DFAState({}, None), DFAState({}, None)])
    check(
        [
            DFAState({}, None),
            DFAState({}, None),
            DFAState({}, None),
            DFAState({}, None),
        ]
    )


# Generated at 2022-06-23 15:59:09.275594
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    pg = ParserGenerator()
    pg.gettoken = lambda : 0
    pg.parse_item = lambda : (1, 2)
    pg.value = '|'
    pg.gettoken = lambda : 0
    assert pg.parse_alt() == (1, 2)
    pg.value = '+'
    assert pg.parse_alt() == (1, 2)
    pg.value = '|'
    assert pg.parse_alt() == (1, 2)

# Generated at 2022-06-23 15:59:19.965022
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    from .parser import DEFAULT_VERSION
    from .parser import Grammar, pickle

    # Start with an empty parse object
    pg = ParserGenerator([], DEFAULT_VERSION)

    # Add a rule that's not a complete bnf rule
    test_bnf1 = """\
    single: NAME | NUMBER
    """
    with pytest.raises(ValueError):
        pg.parse(test_bnf1)

    # Add a rule with an empty alternative
    test_bnf2 = """\
    empty: |
    """
    with pytest.raises(ValueError):
        pg.parse(test_bnf2)

    # Add a grammar that's not a complete bnf rule
    test_bnf3 = """\
    single: NAME
    single: NUMBER
    """

# Generated at 2022-06-23 15:59:28.533243
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    pg = ParserGenerator()
    pg.value = '('
    pg.type = token.OP
    assert pg.expect(token.OP, '(') == '('
    pg.value = None
    pg.type = token.ERRORTOKEN
    try:
        pg.expect(token.OP)
    except SyntaxError as exc:
        assert exc.args[0] == 'expected OP/None, got ERRORTOKEN/None'
        assert exc.args[1] == ('', None, None, '')
    else:
        assert False

# Generated at 2022-06-23 15:59:40.812596
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    s = """\
abc: a b c
"""
    generator = ParserGenerator(s, "filename").generator
    assert next(generator) == (token.NAME, "abc", (0, 0), (0, 3), "abc: a b c\n")
    assert next(generator) == (token.OP, ":", (0, 4), (0, 5), "a b c\n")
    assert next(generator) == (token.NAME, "a", (0, 6), (0, 7), " b c\n")
    assert next(generator) == (token.NAME, "b", (0, 8), (0, 9), "c\n")
    assert next(generator) == (token.NAME, "c", (0, 10), (0, 11), "\n")

# Generated at 2022-06-23 15:59:48.549204
# Unit test for method __eq__ of class DFAState
def test_DFAState___eq__():
    dfa = DFAState({}, None)
    a, b, c, d, e, f, g, h, i, j, k = [DFAState({dfa: 1}, None) for j in range(11)]
    dfa.arcs = {"a": a, "b": b, "c": c}
    a.arcs = {"b": d, "c": e}
    b.arcs = {"a": f, "b": g}
    c.arcs = {"a": h, "b": i, "c": j}
    d.arcs = {"a": k, "c": b}
    e.arcs = {"b": i}
    f.arcs = {"c": h}
    g.arcs = {"c": a, "d": a}

# Generated at 2022-06-23 15:59:58.094536
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():
    a = DFAState({}, ())
    b = DFAState({}, ())
    c = DFAState({}, ())
    a.addarc(b, "a")
    a.addarc(c, "b")
    b.addarc(a, "c")
    a.unifystate(b, c)
    assert a.arcs == {"a": c, "b": c}
    assert b.arcs == {}
    assert c.arcs == {"c": a}



# Generated at 2022-06-23 16:00:07.572447
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    import sys

    def _run_suite(suite, ns):
        ns["__name__"] = suite.name
        exec(suite.code, ns)

    old_argv = sys.argv
    sys.argv = list(old_argv)
    sys.argv.insert(0, "foo")

# Generated at 2022-06-23 16:00:18.618827
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    a = NFAState()
    b = NFAState()
    c = NFAState()
    d = NFAState()
    e = NFAState()
    a.addarc((b, "a"))
    a.addarc((c, "b"))
    b.addarc((c, None))
    c.addarc((d, None))
    d.addarc((a, "c"))
    d.addarc((e, "d"))
    e.addarc((a, "e"))
    e.addarc((e, "f"))
    gen = ParserGenerator()
    gen.dump_nfa("test", a, e)
if __name__ == "__main__":
    test_ParserGenerator_dump_nfa()



# Generated at 2022-06-23 16:00:24.874726
# Unit test for method addarc of class DFAState
def test_DFAState_addarc():
    a = DFAState({}, None)
    b = DFAState({}, None)
    a.addarc(b, "ab")
    assert a.arcs == {"ab" : b}
    c = DFAState({}, None)
    a.addarc(c, "ab")
    assert a.arcs == {"ab" : c}


# Generated at 2022-06-23 16:00:27.365944
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    try:
        grammar = PgenGrammar()
    except Exception as e:
        print(e)
    else:
        assert type(grammar) is PgenGrammar




# Generated at 2022-06-23 16:00:34.103621
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    if __name__ == "__main__":
        pg = ParserGenerator("foo", """
        a : '(' b ')'
        b : '(' b ')' | NAME
        """)
    else:
        import io
        from typing import Union
        from . import test_grammar
        from .pgen_grammar import PgenGrammar
        pg = ParserGenerator(
            io.StringIO(test_grammar.grammar_text), test_grammar.grammar_name,
        )
    assert isinstance(pg, PgenGrammar)
    assert isinstance(pg.filename, (str, type(test_grammar.grammar_name)))
    assert isinstance(pg.startsymbol, str)
    assert pg.startsymbol in pg.dfas

# Generated at 2022-06-23 16:00:46.626723
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    import unittest
    import random

    class Test(unittest.TestCase):
        states = [
            DFAState({}, False),
            DFAState({}, True),
            DFAState({1: 1}, False),
            DFAState({2: 1}, False),
            DFAState({3: 1}, False),
            DFAState({4: 1}, False),
            DFAState({1: 1, 2: 1}, False),
            DFAState({2: 1, 3: 1}, False),
            DFAState({5: 1}, False),
            DFAState({5: 1, 6: 1}, False),
            DFAState({5: 1, 4: 1}, False),
        ]


# Generated at 2022-06-23 16:00:50.152684
# Unit test for constructor of class NFAState
def test_NFAState():
    a = NFAState()
    b = NFAState()
    c = NFAState()
    d = NFAState()
    a.addarc(b, "b")
    b.addarc(c, None)
    c.addarc(d, "d")



# Generated at 2022-06-23 16:00:57.778675
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    import io
    from .tokenizer import generate_tokens
    from .python_grammar import python_grammar, python_grammar_nts, python_grammar_dfas
    from .python_grammar import alt, seq, opt, name

    class DFAState:
        pass

    class NFAState:
        def __init__(self, arcs=None):
            self.arcs = arcs or []

        def addarc(self, next, label=None):
            self.arcs.append((label, next))

        def __repr__(self):
            return "NFAState(%r)" % self.arcs

    def parse(text):
        gen = generate_tokens(io.StringIO(text).readline)
        next(gen)  # skip encoding cookie

# Generated at 2022-06-23 16:01:03.224356
# Unit test for function generate_grammar
def test_generate_grammar():
    grammar = generate_grammar()
    # print repr(grammar)

# Generated at 2022-06-23 16:01:04.559320
# Unit test for method addarc of class DFAState
def test_DFAState_addarc():
    a = DFAState({}, None)
    b = DFAState({}, None)
    a.addarc(b, "label")
    assert a.arcs == {'label': b}

# Generated at 2022-06-23 16:01:11.990568
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    p = ParserGenerator()

# Generated at 2022-06-23 16:01:22.712461
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    c = Converter(grammar)
    names = ["expr", "test", "xor_expr", "and_expr", "shift_expr"]
    c.make_first(c, "expr")
    firsts = c.first["expr"]
    print("FIRSTS")
    for label, value in sorted(firsts.items()):
        ilabel = c.make_label(c, label)
        name = c.labels[ilabel][0]
        if name in c.symbol2number:
            name = c.number2symbol[name]
        else:
            name = token.tok_name[name]
        print("  ", label, name, len(value), list(sorted(value)), value)