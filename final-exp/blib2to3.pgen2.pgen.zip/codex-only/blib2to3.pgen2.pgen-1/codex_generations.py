

# Generated at 2022-06-23 15:51:22.375027
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    pg = ParserGenerator()
    pg.add_nonterminal(
        "atom", [("atom", ("LPAR", "testlist", "RPAR")), ("atom", ("lsquare", "listmaker", "rsquare")), ("NAME",), ("NUMBER",), ("STRING",), ("NAME", "LPAR", "RPAR"), ("NAME", "LPAR", "testlist_gexp", "RPAR")]
    )
    pg.add_nonterminal(
        "testlist_gexp",
        [
            ("test", ("comp_for",)),
            ("lambda_form", ("comp_for",)),
            ("testlist", ("COMMA", "test", ("comp_for",))),
        ],
    )

# Generated at 2022-06-23 15:51:31.897040
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    class Dummy:
        pass

    eof = Dummy()
    eof.type = token.ENDMARKER
    eof.value = ""

    tokens = [
        # FIXME: This sequence is also used in other places,
        #        but is probably not correct
        ("NAME", "ab"),  # must be a valid symbol name
        ("OP", ":"),
        ("NAME", "bc"),
        ("NEWLINE", ""),
        ("NAME", "bc"),
        ("OP", ":"),
        ("NAME", "ab"),
        ("OP", "|"),
        ("NAME", "bc"),
        ("NEWLINE", ""),
        eof
    ]

    generator = (t for t in tokens)
    parser = ParserGenerator("?", generator)
    for t in tokens:
        parser.gettoken()


# Generated at 2022-06-23 15:51:38.309696
# Unit test for function generate_grammar
def test_generate_grammar():
    print("-"*5 + "Start of the testing" + "-"*5)
    test_set = ["(", "[", "]", "|", "+", "*", ":", "name", "string"]
    test_set_with_arg = [
        "(", "[", "]", "|", "+", "*", ":", "name", "string", "argument"
    ]
    grammar = generate_grammar()
    print("\n" + "-"*10 + "Test the terminals" + "-"*10)
    for terminal in test_set:
        assert terminal in grammar.symbol2number
    print("Test passed")
    print("\n" + "-"*10 + "Test the non-terminals" + "-"*10)

# Generated at 2022-06-23 15:51:48.216892
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    import unittest
    import io
    import tokenize
    import pytest
    import sys
    import py

    # Input generator
    def g(s):
        return (t for t in tokenize.tokenize(io.StringIO(s).readline))

    # Dummy implementation of method raise_error
    class Mock:
        def raise_error(self, msg, *args):
            raise AssertionError(msg % args)

    # Test case
    class T(unittest.TestCase):
        def test_expect1(self):
            f = ParserGenerator(g('py3k,\n'), '<string>')
            f.raise_error = Mock.raise_error.__get__(f)
            f.gettoken()

# Generated at 2022-06-23 15:51:56.870267
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():
    x = DFAState({}, None)
    y = DFAState({}, None)
    z = DFAState({}, None)
    one = DFAState({}, None)
    two = DFAState({}, None)
    x.addarc(one, "x")
    x.addarc(two, "y")
    x.addarc(z, "z")
    assert x.arcs == {"x": one, "y": two, "z": z}
    x.unifystate(two, y)
    assert x.arcs == {"x": one, "y": y, "z": z}



# Generated at 2022-06-23 15:52:06.636409
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    """
    >>> s = 'a | b'
    >>> p = ParserGenerator()
    >>> p.make_parser(s)
    """

if __name__ == "__main__":
    import doctest

    doctest.testmod(report=True)


if __name__ == "__main__":
    import sys
    import tokenize

    p = ParserGenerator()

    with open(sys.argv[1], 'rb') as fp:
        s = fp.read()
        for tup in tokenize.tokenize(s.decode().replace('\r\n', '\n').encode()):
            if tup[0] in (token.OP, token.NAME, token.STRING):
                print(tup)
        dfa, startsymbol = p.parse_gram

# Generated at 2022-06-23 15:52:08.252757
# Unit test for function generate_grammar
def test_generate_grammar():
    assert False, "Test not implemented."


# Generated at 2022-06-23 15:52:20.802986
# Unit test for constructor of class DFAState
def test_DFAState():
    ns1 = NFAState()
    ns2 = NFAState()
    ns3 = NFAState()

    dfa1 = DFAState({ns1: None, ns2: None}, ns3)
    dfa2 = DFAState({ns1: None, ns2: None}, ns3)
    assert dfa1 == dfa2

    dfa3 = DFAState({ns1: None, ns2: None}, ns1)
    assert dfa1 != dfa3

    dfa4 = DFAState({ns1: None, ns2: None, ns3: None}, ns3)
    assert dfa1 != dfa4

    dfa5 = DFAState({ns1: None, ns3: None}, ns3)
    assert dfa1 != dfa5



# Generated at 2022-06-23 15:52:29.320969
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():

    # Test attributes
    p = PgenGrammar(grammar.grammar, token.tok_name, token.literals)

    g = p
    # Test type(x)
    assert isinstance(g._grammar, dict)

    assert isinstance(g._rules, list)

    assert isinstance(g._rule_names, list)

    # Test type(x)
    assert isinstance(g._symbol2number, dict)

    # Test type(x)
    assert isinstance(g._number2symbol, dict)

    # Test type(x)
    assert isinstance(g._labels, list)

    # Test type(x)
    assert isinstance(g._states, dict)

    # Test type(x)
    assert isinstance(g._dfas, dict)

    # Test x == y

# Generated at 2022-06-23 15:52:41.262614
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    # pgenform.py (the output of pgen.py) contains a grammar for Python 3.7
    pg = ParserGenerator()
    gram = pg.make_grammar(
        "./pgenform.py"
    )
    # Dump the grammar to a text file for inspection
    open("grammar.txt", "w").write(str(gram))
    gram.check_all()
    # Make sure that we can also use a StringIO object
    import io
    pg = ParserGenerator()
    data = io.StringIO(open("./pgenform.py").read())
    gram = pg.make_grammar(data)
    open("grammar.txt", "w").write(str(gram))
    gram.check_all()

# Generated at 2022-06-23 15:52:51.491471
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    pg = ParserGenerator()
    c = pg.parse_grammar(StringIOTokenizer(
        """
        expr: a+
        a: NAME
        b: [a|"+"]
        """
    ))
    assert c.labels == [
        (token.NAME, None), # label 0 is the value NAME
        (token.OP, "+"),  # label 1 is the value "+"
        (269, "expr"),  # label 2 is the value expr
        (270, "a"),  # label 3 is the value a
        (271, "b"),  # label 4 is the value b
    ]
    assert c.start == 2

# Generated at 2022-06-23 15:53:00.123430
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    import textwrap
    import tokenize
    p = ParserGenerator()

# Generated at 2022-06-23 15:53:06.082668
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    p = ParserGenerator("grammar.txt")
    c = p.make_grammar()
    for i, (name, first) in enumerate(c.first.items()):
        print("-", name, ":", first.keys())
        assert name in grammar.symbol2number
        assert name in grammar.number2symbol

# Generated at 2022-06-23 15:53:14.676242
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    pgen = ParserGenerator()

# Generated at 2022-06-23 15:53:17.571817
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    pg = ParserGenerator()
    pg.dfas = {'foo': [], 'bar': []}
    pg.addfirstsets()
    assert pg.first['foo'] == {}
    assert pg.first['bar'] == {}


# Generated at 2022-06-23 15:53:26.263334
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    # Note: this test was automatically generated.
    test = NFAState()
    assert isinstance(test, NFAState)
    test.addarc(NFAState(), "test")
    # assert hasattr(test, "arcs"), "test should have attribute arcs"
    assert 1 == len(test.arcs), "arcs should have 1 elements"
    assert (
        type(test.arcs[0]) is tuple
    ), "arcs[0] should be of type <class 'tuple'>"
    assert 2 == len(test.arcs[0]), "arcs[0] should have 2 elements"
    assert test.arcs[0][0] == "test", "arcs[0][0] should be 'test'"

# Generated at 2022-06-23 15:53:37.832585
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():
    x = DFAState({}, None)
    y = DFAState({}, None)
    z = DFAState({}, None)
    x.addarc(y)
    x.addarc(z)
    x.unifystate(y, z)
    assert list(x.arcs.values()) == [z, z]
# Test this by running "python1.5 grammar.py".
if __name__ == "__main__":
    if len(sys.argv) > 1:
        sys.argv.pop(0)
        for filename in sys.argv:
            f = open(filename)
            parser = Parser(f.readline, filename)
            dfas, startsymbol = parser.parse()
            parser.addfirstsets()
            f.close()
    else:
        parser = Parser

# Generated at 2022-06-23 15:53:50.137129
# Unit test for method __eq__ of class DFAState
def test_DFAState___eq__():
    dfa = DFAState({10: 1, 20: 1}, 10)
    dfa.addarc(dfa, "a")
    dfa.addarc(dfa, "b")
    dfb = DFAState({10: 1, 20: 1}, 10)
    dfb.addarc(dfb, "a")
    dfb.addarc(dfb, "b")
    assert dfa == dfb
    dfb.addarc(dfa, "c")
    assert not dfa == dfb
    dfb.addarc(dfb, "a")
    assert not dfa == dfb
    dfb.addarc(dfa, "b")
    assert not dfa == dfb
    dfb.addarc(dfb, "b")
    assert not dfa == dfb
    dfb.add

# Generated at 2022-06-23 15:53:51.018474
# Unit test for constructor of class NFAState
def test_NFAState():
    # Test for basic constructor for the class NFAState
    NFAState()


# Generated at 2022-06-23 15:53:53.483671
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    fp = open("Python.asdl", "r")
    a = PgenGrammar(fp)
    fp.close()


# Generated at 2022-06-23 15:53:59.290417
# Unit test for constructor of class NFAState
def test_NFAState():
    state = NFAState()
    assert state.arcs == []
    state.addarc(state)
    assert state.arcs == [(None, state)]
    state.addarc(state, "label")
    assert state.arcs == [(None, state), ("label", state)]



# Generated at 2022-06-23 15:54:08.851315
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    class Dummy:
        def __init__(self, type, token):
            self.type = type
            self.token = token

    def mock_tokenize(readline):
        for line in iter(readline, ''):
            for tup in tokenize.generate_tokens(iter([line]).__next__):
                yield tup

    import io
    # The previous parsing algorithm was wrong and accepted an empty string.
    # Here we test that the new algorithm rejects it.
    with io.StringIO() as f:
        f.write("start: \n")
        f.write("    |\n")
        f.seek(0)
        tokens = mock_tokenize(f.readline)

# Generated at 2022-06-23 15:54:15.506903
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    import io
    import traceback
    try:
        ParserGenerator(io.StringIO(""), None).raise_error("err")
    except SyntaxError as e:
        tb = traceback.extract_tb(e.__traceback__)
    else:
        assert False
    assert len(tb) == 1
    fn, ln, func, text = tb[0]
    assert fn == __file__
    assert ln == 230
    assert func == "raises"
    assert text.startswith("err")



# Generated at 2022-06-23 15:54:27.881198
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    pg = PgenParser(0, auto_newline=True)
    def test_one(text, expected_value):
        tokens = list(tokenize.tokenize(io.BytesIO(text.encode("utf-8")).readline))[1:]
        assert tokens[-1][0] == tokenize.ENDMARKER
        generator = iter(tokens)
        pg.generator = generator
        pg.gettoken()
        a, z = pg.parse_atom()
        assert pg.type == tokenize.ENDMARKER
        assert a.arcs == [(expected_value, z)]
    test_one(r"x", "x")
    test_one(r"\"x\"", "x")
    pg = PgenParser(0, auto_newline=False)

# Generated at 2022-06-23 15:54:34.490167
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    import sys
    import StringIO

    s = StringIO.StringIO("a : b c\n")
    filename = "<string>"
    g = ParserGenerator([], None)
    g.filename = filename
    g.generator = grammar.generate_tokens(s.readline)
    g.gettoken()
    a, z = g.parse_rhs()
    assert a.arcs == [(None, z)]
    assert z.arcs == [("b", None), ("c", None)]

# Generated at 2022-06-23 15:54:38.262741
# Unit test for method addarc of class NFAState
def test_NFAState_addarc():
    nfastate = NFAState()
    nfastate.addarc(nfastate)
    nfastate.addarc(nfastate, '')

# Generated at 2022-06-23 15:54:40.733560
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    assert repr(ParserGenerator(iter([(2,3,"","")])).expect(2,3)) == "3"


# Generated at 2022-06-23 15:54:43.421870
# Unit test for constructor of class NFAState
def test_NFAState():
    a = NFAState()
    b = NFAState()
    a.addarc(b, "x")
    assert a.arcs == [("x", b)]



# Generated at 2022-06-23 15:54:48.501209
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    rdparser = rdparser0.ParserGenerator()
    grmr = rdparser.grammar
    assert grmr.type2name[grmr.number2type[grammar.tokens["<>"][0]]] == "<>"
    rdparser.pgen_file(open("Grammar"))
    rdparser.addfirstsets()


# Generated at 2022-06-23 15:54:55.121291
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    p = ParserGenerator([])
    p.type, p.value = token.NAME, "a"
    p.gettoken = lambda: None
    p.parse_item = lambda: (NFAState(1), NFAState(2))
    p.parse_atom = lambda: (NFAState(3), NFAState(4))
    a, b = p.parse_alt()
    assert a.nfaset == {3}
    assert b.nfaset == {4}
    p.value = "-"
    p.parse_item = lambda: (NFAState(5), NFAState(6))
    p.parse_atom = lambda: (NFAState(7), NFAState(8))
    a, b = p.parse_alt()
    assert a.nfaset == {3}

# Generated at 2022-06-23 15:54:58.665572
# Unit test for method addarc of class NFAState
def test_NFAState_addarc():
    a = NFAState()
    b = NFAState()
    c = NFAState()
    a.addarc(b)
    a.addarc(c)
    a.addarc(b, '+')
    a.addarc(c, '*')
    assert a.arcs[0] == (None, b)
    assert a.arcs[1] == (None, c)
    assert a.arcs[2] == ('+', b)
    assert a.arcs[3] == ('*', c)
    print("test_NFAState_addarc: all OK")
# test_NFAState_addarc()



# Generated at 2022-06-23 15:54:59.403550
# Unit test for constructor of class NFAState
def test_NFAState():
    a = NFAState()
    assert a.arcs == []



# Generated at 2022-06-23 15:55:06.042754
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    pg = ParserGenerator()
    # Trick dump_dfa into thinking it has states it doesn't.
    def dump_dfa(name: str, dfa: List["DFAState"]) -> None:
        assert dfa == [[]]
        assert name == "name"
    pg.dump_dfa = dump_dfa
    pg.dump_dfa("name", [[]])

# Generated at 2022-06-23 15:55:13.065468
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    import sys
    import tokenize
    from io import BytesIO
    pg = ParserGenerator()
    pg.setup(
        "a : 'x'",
        tokenize.tokenize(BytesIO("a : 'x'".encode("utf-8")).readline),
        "<string>",
    )
    d, s = pg.parse()
    pg.dump_dfa(s, d[s])


# Generated at 2022-06-23 15:55:21.632821
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    import sys

    pg = ParserGenerator()

    source = """
    #
    # This is a comment
    #
    # the root rule is called start
    start: (a | b) | c

    a: x y (z | "z")

    b: 'b' | "b"

    c: "c"

    x: "x"

    y: "y"

    z: 'z'
    """
    try:
        g = pg.make_grammar(source, filename="nofile", convert=True)
    except SyntaxError as e:
        sys.stderr.write(
            "There's a bug in %s.make_grammar; here's a test case:\n"
            % pg.__class__.__name__
        )

# Generated at 2022-06-23 15:55:28.914083
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    import pgen
    pygram = pgen.pgen(sys.argv[0])
    pygram.pgen()
    # pgen.ParserGenerator.dump_dfa(pygram.dfas, pygram.startsymbol)
    print()
    # pgen.ParserGenerator.dump_dfa(pygram.dfas, 'import_as_names')
    for name in sorted(pygram.dfas):
        print(name, ":")
        pygram.dump_dfa(name, pygram.dfas[name])
        # print name, pygram.first[name].keys()
        print()


# Generated at 2022-06-23 15:55:36.306977
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    p = ParserGenerator()
    a = NFAState()
    z = NFAState()
    a.addarc(z)
    a.addarc(z, "a")
    a.addarc(z, "b")
    a.addarc(z, "b")
    a.addarc(z, None)
    z.addarc(a)
    p.dump_nfa("test", a, z)


# Generated at 2022-06-23 15:55:45.658567
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    dfa_1 = []
    dfa_1.append(DFAState({0: 1}, False))
    dfa_1.append(DFAState({1: 1}, True))
    dfa_1.append(DFAState({}, False))
    dfa_1[0].addarc(dfa_1[1], '"NAME"')
    dfa_1[1].addarc(dfa_1[2], '"NAME"')

    dfa_2 = []
    dfa_2.append(DFAState({2: 1}, False))
    dfa_2.append(DFAState({1: 1}, True))
    dfa_2.append(DFAState({}, False))
    dfa_2[0].addarc(dfa_2[1], '"LBRACK"')
   

# Generated at 2022-06-23 15:55:58.279061
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    # Dummy objects for class ParserGenerator
    class PgenGrammar:
        token = token
        labels = []
        symbol2number = {}
        symbol2label = {}
        tokens = {}
        keywords = {}

    class NFAState:
        def __init__(self, label=None):
            self.label = label
            self.arcs = []

        def addarc(self, next, label=None):
            self.arcs.append((label, next))

    pgen = ParserGenerator([])
    pgen.dfas = {"a": [], "b": [], "c": [], "d": [], "e": []}

# Generated at 2022-06-23 15:56:09.220296
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    parser = ParserGenerator()
    assert Raises(SyntaxError, parser.parse_atom)
    parser.value = "("
    assert Raises(SyntaxError, parser.parse_atom)
    parser.gettoken()
    assert Raises(SyntaxError, parser.parse_atom)
    parser.value = ")"
    parser.gettoken()
    assert Raises(SyntaxError, parser.parse_atom)
    parser.value = "test"
    parser.gettoken()
    assert Raises(SyntaxError, parser.parse_atom)
    parser.value = "test"
    parser.type = token.NAME
    parser.gettoken()
    assert Raises(SyntaxError, parser.parse_atom)
    parser.value = "test"
    parser.type = token.STRING
    parser.get

# Generated at 2022-06-23 15:56:15.600997
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    class DummyGrammar:
        def handle_UNKNOWN_NAME(self, name: str) -> DFA:
            return DFA(OrderedDict([(0, DFAState(OrderedDict([(0, 0)])))], 0))

    # NOTE: In Python 3.6+, this test will fail because the tokenizer normalizes the string to 'b'
    # and the other tests depend on this normalization.
    pg = ParserGenerator(DummyGrammar(), "foo", b"'a'b")
    pg.parse_rhs()
    # assert False # TODO: implement your test here


# Generated at 2022-06-23 15:56:16.462679
# Unit test for function generate_grammar
def test_generate_grammar():
    p = ParserGenerator()
    gram = p.make_grammar()
    print(gram.keywords)

# Generated at 2022-06-23 15:56:21.059196
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    pg = ParserGenerator()
    start = NFAState()
    finish = NFAState()
    start.addarc(finish)
    dfa = [DFAState({start: 1}, finish)]
    pg.dump_dfa("test", dfa)

# Generated at 2022-06-23 15:56:23.713792
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    g = PgenGrammar(32)



# Generated at 2022-06-23 15:56:33.133497
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    # The following grammar works correctly.
    #
    # expr:
    #     expr '+' term
    #     | expr '-' term
    #     | term
    # term:
    #     term '*' factor
    #     | term '/' factor
    #     | factor
    # factor:
    #     '(' expr ')'
    #     | NAME
    #     | NUMBER
    #
    # 'NAME', 'NUMBER' and '(' are token types;
    # '+', '-', '*', '/' and ')' are token values.

    grammar1 = """
    expr:
        expr '+' term | expr '-' term | term
    term:
        term '*' factor | term '/' factor | factor
    factor:
        '(' expr ')' | NAME | NUMBER
    """


# Generated at 2022-06-23 15:56:43.985141
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    tp = ParserGenerator("file.txt", """
        # An imaginary grammar for a programming language.
        stmt: if_stmt | for_stmt | ...
        if_stmt: NAME '=' NAME 'then' block
        block: 'begin' (NEWLINE | RULE)* 'end'
    """)
    pg = ParserGenerator("file.txt", tp.splitlines(True))
    assert pg.symbol2number == {
        "if_stmt": 0,
        "block": 1,
        "stmt": 2,
    }
    assert pg.number2symbol == {
        0: "if_stmt",
        1: "block",
        2: "stmt",
    }

# Generated at 2022-06-23 15:56:48.831839
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    g = ParserGenerator()
    g.dfas = {
        "a": [[State({'b': ..., 'c': ..., 'd': ...}), State()]],
        "b": [[State(), State({'a': ...})], [State(), State()]],
        "c": [[State(), State()]],
        'd': [[State({'a': ..., 'c': ...}), State()]],
    }
    g.addfirstsets()
    assert g.first == {
        "a": {'b': 1, 'c': 1, 'd': 1},
        "b": {'a': 1},
        "c": {},
        "d": {'a': 1, 'c': 1},
    }


# Generated at 2022-06-23 15:56:58.367826
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    class MockParserGenerator(ParserGenerator):
        def __init__(self,
                     type: int = -1,
                     value: Any = -1,
                     begin: Tuple[int, int] = (-1, -1),
                     end: Tuple[int, int] = (-1, -1),
                     line: str = -1
                     ) -> None:
            super().__init__("testing...")
            self.type = type
            self.value = value
            self.begin = begin
            self.end = end
            self.line = line

        def gettoken(self) -> None:
            return

        def raise_error(self, *args: Any) -> NoReturn:
            assert False

    mg = MockParserGenerizer()
    assert mg.parse_atom() == (None, None)



# Generated at 2022-06-23 15:57:02.674783
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    pg = PgenGrammar()
    # 'nullable' should be an empty set
    assert pg.nullable == set()
    # 'nonterms' should be an empty set
    assert pg.nonterms == set()


# Generated at 2022-06-23 15:57:15.723463
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    pg = ParserGenerator()
    nstart = NFAState()
    nz = NFAState()
    nstart.addarc(nz, "a")
    pg.dump_nfa('xyz', nstart, nz)
    print()
    nstart = NFAState()
    nz = NFAState()
    n1 = NFAState()
    n2 = NFAState()
    n3 = NFAState()
    nstart.addarc(n3, "c")
    nstart.addarc(n1)
    n3.addarc(n2)
    n2.addarc(n1)
    n1.addarc(nz, "b")
    pg.dump_nfa('xyz', nstart, nz)



# Generated at 2022-06-23 15:57:27.550650
# Unit test for method __eq__ of class DFAState
def test_DFAState___eq__():
    import unittest
    from test.support import captured_stdout
    from test.support import run_unittest
    import io
    import pprint


    class DFAStateTestCase(unittest.TestCase):
        def test___eq__(self):
            # Catch all test case for DFAState.__eq__
            a0 = DFAState({}, None)
            a1 = DFAState({}, None)
            self.assertEqual(a0, a1)

            a = DFAState({}, None)
            self.assertEqual(a, a)

            b = DFAState({}, None)
            b.addarc(b, "label")
            self.assertEqual(b, b)

            b2 = DFAState({}, None)

# Generated at 2022-06-23 15:57:31.183373
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    pgen = PgenGrammar("S", "foo", "bar")
    assert pgen.start == "S"
    assert pgen.dfas == "foo"
    assert pgen.labels == "bar"


# Generated at 2022-06-23 15:57:42.330481
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    parser = ParserGenerator()
    assert parser.parse_item() == (NFAState(arcs=[(None, NFAState(arcs=[(None, NFAState())]))]), NFAState())
    assert parser.parse_item() == (NFAState(arcs=[(None, NFAState(arcs=[(None, NFAState())]))]), NFAState())
    assert parser.parse_item() == (NFAState(arcs=[(None, NFAState(arcs=[(None, NFAState())]))]), NFAState())
    assert parser.parse_item() == (NFAState(arcs=[(None, NFAState(arcs=[(None, NFAState())]))]), NFAState())

# Generated at 2022-06-23 15:57:47.454420
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    input = """
    #!./ping
    a: 'a'; b: 'b'; c: 'c'
    """
    pg = ParserGenerator()
    pg.tokens["test"] = "test"
    g = pg.make_grammar(tokenize.StringIO(input).readline, "ping")
    assert g.type == "file_input"
    assert g.children[0].type == "stmt"
    assert g.children[1].type == "stmt"
    assert g.children[2].type == "stmt"

# Generated at 2022-06-23 15:57:58.978707
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    pg = ParserGenerator()
    dfa = DFA()
    state0 = DFAState({}, 0)
    state1 = DFAState({}, 0)
    state2 = DFAState({}, 0)
    state3 = DFAState({}, 0)
    state4 = DFAState({}, 0)
    state5 = DFAState({}, 0)
    state6 = DFAState({}, 0)
    state7 = DFAState({}, 0)
    dfa.append(state0)
    dfa.append(state1)
    dfa.append(state2)
    dfa.append(state3)
    dfa.append(state4)
    dfa.append(state5)
    dfa.append(state6)
    dfa.append(state7)
    state0.addarc

# Generated at 2022-06-23 15:58:08.344506
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    import pgen2.parse
    pgen = pgen2.parse.ParserGenerator(grammar, "pgen2_grammar")
    pgen.addfirstsets()
    assert pgen.first["atom"] == {"(": 1, "NAME": 1, "STRING": 1}
    assert pgen.first["alt"] == {"NAME": 1, "STRING": 1, "(": 1, "[": 1}
    assert pgen.first["rhs"] == {"NAME": 1, "STRING": 1, "(": 1, "[": 1}
    assert pgen.first["item"] == {"NAME": 1, "STRING": 1, "(": 1, "[": 1}
    assert pgen.first["atom_or_atomlist"] == {"NAME": 1, "STRING": 1, "(": 1}

# Generated at 2022-06-23 15:58:10.486572
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():
    a = DFAState({'x': 1}, 'x')
    b = DFAState({'y': 1}, 'x')
    a.addarc(b, 'x')
    b.addarc(a, 'y')
    a.unifystate(b, a)
    assert a.arcs == {'x': a, 'y': a}



# Generated at 2022-06-23 15:58:15.320214
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    # Test that the internal variables are initialised correctly
    p = PgenGrammar()
    assert p._symbol2number == {}
    assert p._number2symbol == []
    assert p._dfas == {}
    assert p._start == None
    assert p._tokens == {}
    assert p._error_func == None



# Generated at 2022-06-23 15:58:25.932514
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    import pickle
    import io

    def fwrite(grammar, filename):
        with open(filename + ".py", "wb") as f:
            pickle.dump(grammar, f)

    def fread(filename):
        with open(filename + ".py", "rb") as f:
            return pickle.load(f)

    pg = ParserGenerator()
    pg.add_production("file_input", [("NEWLINE", 0), ("stmt", 1), ("NEWLINE", 0)])
    pg.add_production("file_input", [("NEWLINE", 0)])
    pg.add_production("stmt", [("simple_stmt", 1)])
    pg.add_production("stmt", [("compound_stmt", 1)])

# Generated at 2022-06-23 15:58:32.474876
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    """
    >>> p = pgen.ParserGenerator()
    >>> p.filename = "file"
    >>> p.end = (10, 20)
    >>> p.line = "Hi."
    >>> try:
    ...     p.raise_error("Hi")
    ... except SyntaxError as e:
    ...     print(e)
    file:10:20: Hi.
    """


# Create a DFAGenerator instance using the given grammar.

# Generated at 2022-06-23 15:58:38.963231
# Unit test for constructor of class DFAState
def test_DFAState():
    a = NFAState()
    b = NFAState()
    c = NFAState()
    d = NFAState()
    a.addarc(b, "a")
    b.addarc(c, "b")
    c.addarc(d, "c")
    d.addarc(a, "d")
    # make an NFA with one cycle
    aa = DFAState({a: 1}, c)
    # another NFA with one cycle but different
    bb = DFAState({c: 1}, a)
    # make a third cycle
    cc = DFAState({b: 1, d: 1}, b)
    assert aa != bb
    assert aa != cc
    assert bb != cc

# Generated at 2022-06-23 15:58:51.316778
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    ok = 0
    fail = 0
    def test(name, dfa, expect):
        global ok, fail
        out = StringIO()
        save_stdout = sys.stdout
        try:
            sys.stdout = out
            pgen.dump_dfa(name, dfa)
        finally:
            sys.stdout = save_stdout
        actual = out.getvalue()
        if actual == expect:
            ok += 1
        else:
            fail += 1
            print("test failed: output for %s does not match expectation" % name)
            print("=== expected ===")
            print(expect.rstrip())
            print("=== got ===")
            print(actual.rstrip())
    # Build a small pgen instance
    pgen = ParserGenerator()
    pgen.add_dfa

# Generated at 2022-06-23 15:58:59.046717
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    test_table = (
        ("'a'", "(257, 'a')"),
        ('"a"', "(256, 'a')"),
        ("NAME", "1"),
        ("NUMBER", "2"),
        ("STRING", "3"),
        ("('a'|NAME)", "(1, None)"),
        ("('a'|'b')", "(257, 'a')"),
        ("('a'|'b'|NAME)", "(1, None)"),
        ("('a'|'b'|'c')", "(257, 'a')"),
        ("('a'|'b'|NAME|NUMBER)", "(1, None)"),
    )
    pg = ParserGenerator()
    c = pg.convert()

# Generated at 2022-06-23 15:59:10.325313
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    import sys
    import token
    import tokenize
    parsergenerator = ParserGenerator()
    grammar = """
    start: items
        | NEWLINE items
    items: item items
        | item
    item: NAME '=' NAME
        | NAME
    """
    parsergenerator.grammar = grammar
    with open(parsergenerator.filename, 'w') as f:
        f.write(parsergenerator.grammar)
    with open(parsergenerator.filename, 'rb') as f:
        g = parsergenerator.parse()
    try:
        import pickle
    except ImportError:
        pass
    else:
        s = pickle.dumps(g)
        h = pickle.loads(s)
        assert g == h


if __name__ == "__main__":
    test_Parser

# Generated at 2022-06-23 15:59:14.192917
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    p = ParserGenerator(io.StringIO(""))
    converter = p.make_converter()
    d = {1: 1, 2: 1}
    converter.make_first(None, d)


# Generated at 2022-06-23 15:59:17.018435
# Unit test for function generate_grammar
def test_generate_grammar():
    with open("Grammar.txt") as f:
        g = f.read()
    grammar = generate_grammar()
    assert g == str(grammar)

# Generated at 2022-06-23 15:59:20.440299
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    # XXX Tests not written yet
    with pytest.raises(NotImplementedError):
        ParserGenerator._testfunc()

# Generated at 2022-06-23 15:59:28.289341
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    class DFAState:
        __slots__ = ("isfinal", "arcs")

        def __init__(self, isfinal: bool, arcs: List[Tuple[Text, "DFAState"]]) -> None:
            self.isfinal = isfinal
            self.arcs = arcs

        def __eq__(self, other: object) -> bool:
            if isinstance(other, DFAState):
                return self.isfinal == other.isfinal and self.arcs == other.arcs
            else:
                return NotImplemented

    class NFAState:
        __slots__ = ("arcs",)

        def __init__(self, arcs: List[Tuple[Text, "NFAState"]]) -> None:
            self.arcs = arcs


# Generated at 2022-06-23 15:59:34.170100
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    import io
    f = io.StringIO("\n")
    words = "a b c d e f g h i j k".split()

    def make_state(name):
        state = parser.NFAState()
        state.name = name
        state.arcs = []
        return state

    a = make_state("a")
    b = make_state("b")
    c = make_state("c")
    d = make_state("d")
    e = make_state("e")
    f = make_state("f")
    g = make_state("g")
    h = make_state("h")
    i = make_state("i")
    j = make_state("j")
    k = make_state("k")

# Generated at 2022-06-23 15:59:41.032054
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    from rply.parsergenerator import ParserGenerator
    from rply.parsergenerator import DFAState
    p = ParserGenerator(["a", "b", "c"])
    s = DFAState({"a"}, "b")
    t = DFAState({"a"}, "b")
    s.addarc(t, "c")
    t.addarc(s, "c")
    u = DFAState({"a"}, "b")
    v = DFAState({"a"}, "b")
    u.addarc(v, "c")
    v.addarc(u, "c")
    w = DFAState({"a"}, "b")
    x = DFAState({"a"}, "b")
    w.addarc(x, "c")
    x.addarc

# Generated at 2022-06-23 15:59:51.830558
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    text1 = "a b c"
    tokens1 = [
        (token.OP, 'a'),
        (token.OP, 'b'),
        (token.OP, 'c'),
    ]

    generator1 = gen_tokens(tokens1)
    pg = ParserGenerator(generator1, "")

    a, z = pg.parse_alt()
    assert a._arcs == [(('a',), None),]
    assert z._arcs == [(('c',), None),]
    b = a._arcs[0][1]
    assert b._arcs == [(('b',), None),]



# Generated at 2022-06-23 16:00:02.360275
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    p = ParserGenerator()
    p.dfas = {"a": []}
    p.startsymbol = "a"
    p.first = {"a": {"b": 1, "c": 1}}
    p.symbol2number = {"a": 1}
    p.keywords = {"b": 1, "c": 2}
    c = p.make_converter()
    assert c.first[1] == {1: 1, 2: 1}
    assert c.labels == [(token.NAME, "b"), (token.NAME, "c")]



# Generated at 2022-06-23 16:00:15.973883
# Unit test for constructor of class ParserGenerator

# Generated at 2022-06-23 16:00:26.894203
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    p = ParserGenerator()
    a = NFAState()
    z = NFAState()
    a.addarc(z, "a")
    dfa = p.make_dfa(a, z)
    assert isinstance(dfa, list) and len(dfa) == 2
    assert isinstance(dfa[0], DFAState)
    assert len(dfa[0].arcs) == 1 and len(dfa[0].nfaset) == 1 and not dfa[0].isfinal
    assert len(dfa[1].arcs) == 0 and len(dfa[1].nfaset) == 1 and dfa[1].isfinal
    assert ("a", dfa[1]) in dfa[0].arcs.items()


# Generated at 2022-06-23 16:00:31.486914
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    g = PgenGrammar()
    assert g.symbol2number == {}
    assert g.symbol2label == {}
    assert g.start == None
    assert g.tokens == {}


# Generated at 2022-06-23 16:00:34.495805
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    def _parse_item(string):
        parser_gen = ParserGenerator()
        return parser_gen.parse_item()
    a, z = _parse_item("[")
    a, z = _parse_item("(")
    a, z = _parse_item("A")
    a, z = _parse_item("\"abc\"")
    a, z = _parse_item("B")

# Generated at 2022-06-23 16:00:46.903729
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    def gen():
        yield 0, '', (1, 1), (1, 1), ''
        yield 1, '', (1, 1), (1, 1), ''
        yield 2, '', (1, 1), (1, 1), ''
        yield 3, '', (1, 1), (1, 1), ''
        yield 4, '', (1, 1), (1, 1), ''
        yield 5, '', (1, 1), (1, 1), ''
        yield 6, '', (1, 1), (1, 1), ''
        yield 7, '', (1, 1), (1, 1), ''
        yield 8, '', (1, 1), (1, 1), ''
        yield 9, '', (1, 1), (1, 1), ''

    p = ParserGenerator()
    p.generator

# Generated at 2022-06-23 16:00:54.216228
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    pg = ParserGenerator()
    pg.type = None
    pg.value = None
    pg.begin = None
    pg.end = None
    pg.line = None
    pg.filename = None
    pg.generator = (t for t in [('a', 'b', 'c', 'd', 'e')])
    pg.gettoken = lambda: None
    pg.raise_error = lambda *args, **kwds: None
    pg.expect = lambda *args: None
    pg.parse_item = lambda: ("x", "y")
    pg.parse_rhs = lambda: ("x", "y")
    pg.parse_atom = lambda: ("x", "y")
    pg.parse_alt()


# Generated at 2022-06-23 16:01:00.383714
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    pg = ParserGenerator()
    try:
        pg.raise_error("expected %s", "foo")
    except SyntaxError as e:
        assert str(e) == "expected foo"
        filename, lineno, offset, line = e.args
        assert filename is None
        assert lineno == 0
        assert offset == 0
        assert line is None
    else:
        assert False

# Generated at 2022-06-23 16:01:01.890710
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    PgenGrammar()



# Generated at 2022-06-23 16:01:08.429038
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    pg = ParserGenerator()
    pg.initdfas()
    pg.addfirstsets()
    assert pg.first['SYNC'] == {None: 1}
    assert pg.first['file_input'] == {
        "'def'": 1, "'class'": 1, "'if'": 1, "'while'": 1, "'with'": 1,
        'ASYNC': 1, None: 1, "'for'": 1, 'AT': 1}



# Generated at 2022-06-23 16:01:14.985788
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    pg = PgenGrammar()
    assert type(pg) is PgenGrammar
    assert pg.states == {}
    assert pg.tokens == {}
    assert pg.symbol2number == {}
    assert pg.number2symbol == []
    assert pg.start is None
    assert pg.dfas == {}
    assert pg.states == {}

