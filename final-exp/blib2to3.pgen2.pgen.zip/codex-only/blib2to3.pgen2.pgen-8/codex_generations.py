

# Generated at 2022-06-23 15:51:17.614080
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    PgenGrammar()


# Used by PgenParser.add_production.  This should be treated as
# an opaque class by external users.

# Generated at 2022-06-23 15:51:25.168719
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    class MockParserGenerator(ParserGenerator):
        def __init__(self) -> None:
            self.values = []
            self.pairs = [
                (token.NAME, "foo"),
                (token.STRING, "foo"),
                (token.NAME, "bar"),
                (token.NAME, "baz"),
                (token.OP, "|"),
                (token.NAME, "spam"),
                (token.NAME, "ham"),
                (token.STRING, "bacon"),
            ]
            self.tokens = list(map(lambda x: x, self.pairs))
            self.gettoken()

        def gettoken(self) -> None:
            assert self.type, self.value == self.tokens[0]

# Generated at 2022-06-23 15:51:35.067638
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    from . import token
    from . import grammar
    from . import grammar_nt  # for testing only
    from . import pgen_main

    def check(s: Text, expected: List[Tuple[Optional[Text], Optional[bool]]]) -> None:
        parser = ParserGenerator()
        parser.states = [[[("a", 1), ("b", 2)], [("a", 3), ("b", 4)]]]
        parser.dfas = {
            "x": (parser.states[0], {"a": 1, "b": 2})
        }  # type: Dict[Text, Tuple[List[List[Tuple[Optional[Text], Optional[int]]]], Dict[Optional[Text], int]]]
        parser.pgen_rules_by_prec = {}

# Generated at 2022-06-23 15:51:40.683042
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    from . import ParserGenerator
    pg = ParserGenerator()
    s = 'hello"world"'
    with support.captured_stdout() as stdout:
        print(pg.parse_atom(s))
        s = '"hello world"'
        print(pg.parse_atom(s))


# Generated at 2022-06-23 15:51:49.815966
# Unit test for method addarc of class DFAState
def test_DFAState_addarc():

	def check(state, expected):
		result = state.arcs
		if result != expected:
			raise Exception("arcs is %s, should be %s" % (repr(result), repr(expected)))

	s = DFAState({}, NFAState())
	check(s, {})

	s.addarc(s, 'a')
	check(s, {'a': s})

	try:
		s.addarc(s, 'a')
		raise Exception("s.addarc(s, 'a') should raise an exception")
	except ValueError:
		pass

	t = DFAState({}, NFAState())
	s.addarc(t, 'b')
	check(s, {'a': s, 'b': t})


# Generated at 2022-06-23 15:52:01.069840
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    P = ParserGenerator()

# Generated at 2022-06-23 15:52:12.516223
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    parser = ParserGenerator()
    parser.startsource()
    parser.send(token.NAME, 'foo')
    parser.send(token.OP, ':')
    parser.send(token.NAME, 'bar')
    parser.send(token.OP, '|')
    parser.send(token.NAME, 'baz')
    parser.send(token.NEWLINE)
    dfas, startsymbol = parser.getdfas()
    assert startsymbol == 'foo'
    foo = dfas['foo']
    assert len(foo) == 2
    assert not foo[0].isfinal
    assert foo[0].arcs[('bar', 0)] == foo[1]
    assert foo[0].arcs[('baz', 0)] == foo[1]
    assert foo[1].isfinal


#

# Generated at 2022-06-23 15:52:20.756198
# Unit test for constructor of class DFAState
def test_DFAState():
    a = NFAState()
    b = NFAState()
    c = NFAState()
    d = NFAState()
    a.addarc(b, "a")
    a.addarc(c)
    b.addarc(d, "b")
    c.addarc(c)
    d.addarc(a, "a")
    d.addarc(d, "b")
    start = DFAState({a:1, b:1, c:1, d:1}, d)
    assert len(start.arcs) == 4
    assert start.arcs == {
        "a": DFAState({b:1, d:1}, d),
        "b": DFAState({d:1}, d),
        None: DFAState({c:1}, d),
    }
    assert len

# Generated at 2022-06-23 15:52:29.046663
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    import lib2to3.pygram

    pygram.python_grammar = ParserGenerator.make_grammar(lib2to3.pygram.python_grammar)
    assert isinstance(pygram.python_grammar, type(lib2to3.pygram.python_grammar))
    assert isinstance(pygram.python_grammar.start, int)



# Generated at 2022-06-23 15:52:39.508195
# Unit test for constructor of class NFAState
def test_NFAState():
    state = NFAState()
    # first, check that the new object does not have any arcs
    assert not state.arcs
    # now add a couple of arcs
    next = NFAState()
    state.addarc(next)
    next2 = NFAState()
    state.addarc(next2)
    # check that the length of the arcs list is still 2
    assert len(state.arcs) == 2
    # check that the actual  
    assert state.arcs[0][0] is None
    assert state.arcs[0][1] is next
    assert state.arcs[1][0] is None
    assert state.arcs[1][1] is next2
    # try one more, using the label parameter
    next3 = NFAState()
    state.addarc(next3, "label")

# Generated at 2022-06-23 15:52:43.746635
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():
    state1 = DFAState({}, None)
    state2 = DFAState({}, None)
    state3 = DFAState({}, None)
    state1.addarc(state2, "a")
    state1.addarc(state2, "b")
    state1.addarc(state3, "c")
    state1.addarc(state3, "d")
    state1.unifystate(state2, state3)
    assert state1.arcs == {
        "a": state3,
        "b": state3,
        "c": state3,
        "d": state3
    }



# Generated at 2022-06-23 15:52:53.853908
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():
    a = DFAState({}, None)
    b = DFAState({}, None)
    c = DFAState({}, None)
    a.addarc(a, "a")
    a.addarc(b, "b")
    b.addarc(a, "c")
    b.addarc(c, "d")
    c.addarc(a, "e")
    c.addarc(b, "f")
    # a->a, b->b, c->a, d->c, e->a, f->b
    # Unify b and c
    b.unifystate(c, b)
    assert a.arcs["b"] is b
    # a->a, b->b, c->b, d->b, e->a, f->b

# Generated at 2022-06-23 15:53:06.437272
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():
    for a in range(4):
        for b in range(4):
            for c in range(4):
                for d in range(4):
                    A = DFAState({}, None)
                    B = DFAState({}, None)
                    C = DFAState({}, None)
                    D = DFAState({}, None)
                    if a:
                        A.addarc(B, "a")
                    if b:
                        A.addarc(D, "b")
                    if c:
                        B.addarc(C, "c")
                    if d:
                        C.addarc(D, "d")
                    A.unifystate(B, C)
                    if a and c and not (b or d):
                        assert A.arcs == {"a": C, "b": D}

# Generated at 2022-06-23 15:53:12.598064
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    gen = ParserGenerator()
    gen.type = token.OP
    gen.value = "**"
    gen.expect(token.OP, "**")
    print(gen.type, gen.value)
    gen.type = token.OP
    gen.value = ":"
    try:
        gen.expect(token.OP, "**")
    except SyntaxError:
        print("SyntaxError caught.")
    else:
        print("no SyntaxError!")

# Generated at 2022-06-23 15:53:20.097646
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():
    a = DFAState({}, NFAState())
    b = DFAState({}, NFAState())
    c = DFAState({}, NFAState())
    a.addarc(b, 'a')
    a.addarc(c, 'a')
    a.addarc(b, 'b')
    assert a.arcs == {'a': b, 'b': b}
    a.unifystate(b, c)
    assert a.arcs == {'a': c, 'b': c}


# Generated at 2022-06-23 15:53:32.440129
# Unit test for method __eq__ of class DFAState
def test_DFAState___eq__():
    from dfa import DFAState
    from nfa import NFAState
    a = DFAState({}, NFAState())
    b = DFAState({}, NFAState())
    assert a == b
    a.isfinal = True
    assert not a == b
    a.isfinal = False
    a.arcs["a"] = a
    a.arcs["b"] = b
    assert not a == b
    b.arcs["b"] = a
    b.arcs["a"] = b
    assert not a == b
    b.arcs["a"] = a
    b.arcs["b"] = b
    assert a == b
    b.arcs["c"] = a
    assert not a == b
    a.arcs["c"] = a
    assert a == b


# Generated at 2022-06-23 15:53:40.313827
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    import io
    pg = ParserGenerator()
    pg.add_file("Grammar.txt")
    pg.addfirstsets()
    print("parsing")
    dfas, startsymbol = pg.parse()
    print("start symbol", startsymbol)
    c = pg.convert(dfas, startsymbol)
    pg.write_grammar(io.StringIO())
    print("converting")
    c.write_grammar(io.StringIO())


# Generated at 2022-06-23 15:53:45.768073
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    pg = ParserGenerator()
    it = iter([('NAME', 'NAME', (1, 1), (1, 4), 'NAME\n')])

    def gettoken(self):
        tup = next(it)
        while tup[0] in (tokenize.COMMENT, tokenize.NL):
            tup = next(it)
    pg.gettoken = gettoken
    pg.parse_atom()



# Generated at 2022-06-23 15:53:53.083572
# Unit test for constructor of class DFAState
def test_DFAState():
    start = NFAState()
    a = NFAState()
    b = NFAState()
    c = NFAState()
    start.addarc(a); start.addarc(b)
    b.addarc(b); b.addarc(c)
    a.addarc(c); a.addarc(a)
    c.addarc(a); c.addarc(c)
    dfastate = DFAState({start: 1}, c)


# For testing

# Generated at 2022-06-23 15:53:58.884865
# Unit test for constructor of class NFAState
def test_NFAState():
    a = NFAState()
    b = NFAState()
    a.addarc(b)
    assert a.arcs == [(None, b)]
    a.addarc(b, "label")
    assert a.arcs == [(None, b), ("label", b)]



# Generated at 2022-06-23 15:54:04.804337
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    pg = ParserGenerator()
    pg.add_dfa('A', [('A', '(', '(', 'A')])
    pg.add_dfa('B', [('B', ')', ')', 'B')])
    pg.startsymbol = 'A'
    pg.addfirstsets()
    pg.first['A'] == {'(': 1}
    pg.first['B'] == {')': 1}



# Generated at 2022-06-23 15:54:09.165298
# Unit test for method addarc of class NFAState
def test_NFAState_addarc():
    next = NFAState()
    t = NFAState()
    t.addarc(next)
    assert t.arcs == [(None, next)]
    t.addarc(next, "[")
    assert t.arcs == [(None, next), ["[", next]]



# Generated at 2022-06-23 15:54:14.261230
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    pg = ParserGenerator()
    assert pg.expect(token.STRING, "'a'") == "'a'"
    # ``expect`` raises a SyntaxError if the type or value is unexpected.
    with pytest.raises(SyntaxError) as excinfo:
        pg.expect(token.STRING, "'b'")
    assert excinfo.match('expected NAME')



# Generated at 2022-06-23 15:54:20.786326
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    pg = ParserGenerator()
    c = pg.as_converter()
    c.labels = [(1, None), (2, None), (1, "a"), (2, "b")]
    c.symbol2number = {"c": 3, "d": 4}
    c.symbol2label = {
        "c": 5,
        "d": 6,
    }
    c.tokens = {
        3: 7,
        4: 8,
    }
    c.keywords = {
        "a": 9,
        "b": 10,
    }
    assert c.make_first(c, "c") == {7: 1}
    assert c.make_first(c, "d") == {8: 1}
 

# Generated at 2022-06-23 15:54:28.126661
# Unit test for constructor of class DFAState
def test_DFAState():
    s = DFAState({}, None)
    assert not s.isfinal
    assert s.arcs == {}
    s = DFAState({}, NFAState())
    assert s.isfinal
    assert s.arcs == {}
    s = DFAState({NFAState(), NFAState()}, NFAState())
    assert s.isfinal
    assert s.arcs == {}



# Generated at 2022-06-23 15:54:33.482999
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():
    a = DFAState({}, None)
    b = DFAState({}, None)
    a.addarc(b, "x")
    a.addarc(b, "y")
    a.addarc(b, "z")
    a.unifystate(b, a)
    assert a.arcs["x"] is a
    assert a.arcs["y"] is a
    assert a.arcs["z"] is a

# Generated at 2022-06-23 15:54:40.366697
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():
    a, b = DFAState({}, None), DFAState({}, None)
    a.arcs["A"] = a
    a.arcs["B"] = b
    b.arcs["B"] = a
    b.arcs["C"] = b
    a.unifystate(a, b)
    assert a.arcs == {"B": a, "C": b}


# Generated at 2022-06-23 15:54:47.465883
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    import unittest
    from unittest import TestCase, main
    from textwrap import dedent

    class TestCase(TestCase):

        def setUp(self):
            self.testcase = ParserGenerator(
                "parser.txt",
                dedent(
                    """\
                test: a
                a: 'x'
                """
                ).encode(),
                "test",
            )

        def tearDown(self):
            pass

        def test_parse_rhs(self):
            self.testcase.parse_rhs()

    main()
# Unit tests for methods of class ParserGenerator

# Generated at 2022-06-23 15:54:51.095403
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    pg = ParserGenerator()
    pg.parse_rhs()
    pg.parse_rhs()



# Generated at 2022-06-23 15:54:55.097720
# Unit test for method addarc of class DFAState
def test_DFAState_addarc():
    s = DFAState({}, None)
    t = DFAState({}, None)
    s.addarc(t, 'a')
    assert s.arcs == {'a': t}



# Generated at 2022-06-23 15:54:58.779490
# Unit test for function generate_grammar
def test_generate_grammar():
    g = generate_grammar()


# Function for parsing grammar and outputing a pdivs and pdata file
# Input: filename: path to pgen grammar file
# Output:
#     pdivs and pdata files

# Generated at 2022-06-23 15:55:01.369986
# Unit test for constructor of class NFAState
def test_NFAState():
    state_1 = NFAState()
    state_2 = NFAState()
    # add an arc from state_1 to state_2 labelled 'a'
    state_1.addarc(next=state_2, label='a')
    # add an arc from state_1 to state_2 labelled None
    state_1.addarc(next=state_2, label=None)
    assert len(state_1.arcs) == 2


# Generated at 2022-06-23 15:55:05.252047
# Unit test for constructor of class NFAState
def test_NFAState():
    a = NFAState()
    b = NFAState()
    c = NFAState()
    a.addarc(b)
    a.addarc(c, "a")
    b.addarc(c, "b")
    assert a.arcs == [(None, b), ("a", c)]
    assert b.arcs == [("b", c)]
    assert c.arcs == []
    return a, b, c


# Generated at 2022-06-23 15:55:13.811243
# Unit test for constructor of class NFAState
def test_NFAState():
    a = NFAState()
    b = NFAState()
    c = NFAState()
    a.addarc(b)
    a.addarc(c)
    assert a.arcs == [(None, b), (None, c)]
    a.addarc(b, "foo")
    assert a.arcs == [(None, b), (None, c), ("foo", b)]


# State of a DFA.
DFAState = namedtuple("DFAState", ["nfaset", "isfinal"])


# Generated at 2022-06-23 15:55:24.534271
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    from ._pgen import ParserGenerator
    from ._pgen_grammar import PgenGrammar
    import pickle
    
    generator = ParserGenerator()
    generator.parse(open(os.path.join(__all__[0], "Grammar.txt")))
    grammar = generator.make_grammar(["start", "stmt", "expr_stmt", "print_stmt"])
    g = pickle.loads(pickle.dumps(grammar))
    
    assert type(grammar) is PgenGrammar
    assert len(g.states) == len(grammar.states) == 4

# Generated at 2022-06-23 15:55:35.103404
# Unit test for function generate_grammar
def test_generate_grammar():
    g = generate_grammar()
    assert isinstance(g, PgenGrammar)

# Generated at 2022-06-23 15:55:44.808835
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    import io
    import tokenize
    # Test data come from Lib/test/test_tokenize.py
    test_data = '''\
x = "\\""; y = '\\''; z = '''
    s = tokenize.detect_encoding(
        io.BytesIO(test_data.encode("utf-8")).readline
    )[0]
    generator = tokenize.tokenize(io.BytesIO(test_data.encode(s)).readline)
    pg = ParserGenerator()
    a, z = pg.parse_rhs()
    pg.expect(token.ENDMARKER)
    dfa = pg.make_dfa(a, z)
    pg.simplify_dfa(dfa)
    # print dfa[0].arcs
    # pg.

# Generated at 2022-06-23 15:55:57.511163
# Unit test for constructor of class DFAState
def test_DFAState():
    a = NFAState()
    b = NFAState()
    c = NFAState()
    d = NFAState()
    e = NFAState()
    a.addarc(b)
    a.addarc(b)
    a.addarc(c, "x")
    a.addarc(d, "y")
    d.addarc(a)
    a.addarc(e, None)

# Generated at 2022-06-23 15:56:06.716241
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    p = ParserGenerator()
    dfa = []
    for i in range(20):
        dfa.append(DFAState({}, 0))
    for i in range(10):
        dfa[2 * i].addarc(dfa[2 * i + 1], 'a')
        dfa[2 * i + 1].addarc(dfa[2 * i], 'b')
        dfa[2 * i].addarc(dfa[2 * i], 'c')
        dfa[2 * i + 1].addarc(dfa[2 * i + 1], 'd')
    p.simplify_dfa(dfa)
    assert len(dfa) == 10



# Generated at 2022-06-23 15:56:16.060612
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    pg = ParserGenerator()
    def f():
        end = ""
        yield token.NAME, "n", (1, 0), (1, 1), end
        yield token.OP, "=", (1, 2), (1, 3), end
        yield token.OP, "+", (1, 3), (1, 4), end
        yield token.OP, "+", (1, 4), (1, 5), end
        yield token.NAME, "n", (1, 5), (1, 6), end
        yield tokenize.ENDMARKER, "", (2, 0), (2, 0), end
    with pytest.raises(ValueError) as e:
        pg.make_grammar(f)

# Generated at 2022-06-23 15:56:25.915462
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    pg = ParserGenerator()
    aa = NFAState()
    ab = NFAState()
    ac = NFAState()
    aa.addarc(ab, None)
    ab.addarc(ac, "foo")
    ab.addarc(ac, "bar")
    ac.addarc(ac, "baz")
    aa.addarc(ab, "frob")
    pg.dump_nfa("foo", aa, ac)
    pg.dump_nfa("bar", aa, None)

if __name__ == "__main__":
    test_ParserGenerator_dump_nfa()

# Generated at 2022-06-23 15:56:27.950222
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    g = PgenGrammar()
    g.parsed()
# End unit test for constructor of class PgenGrammar



# Generated at 2022-06-23 15:56:31.072383
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    with open("Grammar.txt") as f:
        g = PgenGrammar(f)
        print(g)



# Generated at 2022-06-23 15:56:38.232580
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():
    a = DFAState({}, None)
    b = DFAState({}, None)
    c = DFAState({}, None)
    d = DFAState({}, None)
    a.addarc(b, "1")
    a.addarc(c, "2")
    c.addarc(d, "3")
    c.addarc(b, "4")
    c.unifystate(b, d)
    assert a.arcs == {'1': b, '2': d}
    assert c.arcs == {'3': d, '4': d}
test_DFAState_unifystate()


# Generated at 2022-06-23 15:56:50.562603
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    parser = ParserGenerator()
    a = NFAState()
    b = NFAState()
    c = NFAState()
    d = NFAState()
    e = NFAState()
    f = NFAState()
    g = NFAState()
    a.addarc(b)
    a.addarc(c)
    b.addarc(d, 'm')
    b.addarc(e, 'n')
    c.addarc(f, 'm')
    c.addarc(g, 'n')
    d.addarc(g)
    e.addarc(f)
    f.addarc(b)
    f.addarc(d)
    f.addarc(e)
    g.addarc(a)

# Generated at 2022-06-23 15:57:02.675593
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    p = ParserGenerator()
    a = NFAState()
    b = NFAState()
    c = NFAState()
    d = NFAState()
    e = NFAState()
    a.addarc(b, "abc")
    b.addarc(c, "def")
    c.addarc(d)
    d.addarc(e)
    e.addarc(c)
    dfa = p.make_dfa(a, e)
    assert len(dfa) == 5
    assert dfa[0].arcs["abc"] is dfa[1]
    assert dfa[1].arcs["def"] is dfa[2]
    assert dfa[2].arcs[None] is dfa[3]

# Generated at 2022-06-23 15:57:10.478160
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    pgen = ParserGenerator()
    pgen.parse("ceil[x]")
    dfa = pgen.dfas["ceil"][0]
    s = io.StringIO()
    pgen.dump_dfa("ceil", dfa, out=s)
    assert '"ceil"' in s.getvalue()
    assert '"x"' in s.getvalue()

# Generated at 2022-06-23 15:57:16.258095
# Unit test for function generate_grammar
def test_generate_grammar():
    def verify_grammar(p: ParserGenerator) -> None:
        # This is a minimal test.
        assert p.start == "file_input"
        assert len(p.dfas) == 48
        assert len(p.labels) == 365
        assert len(p.tokens) == 197  # special token START added
        assert len(p.keywords) == 95  # special keyword START added
        assert len(p.first) == 48

    for filename in ["Grammar", "Grammar.txt"]:
        try:
            verify_grammar(ParserGenerator(filename))
        except FileNotFoundError:
            continue
        else:
            break
    else:
        assert False, "Can't find Grammar file"
    verify_grammar(ParserGenerator("Grammar", True))
test

# Generated at 2022-06-23 15:57:27.948335
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    a = DFAState({}, None)
    b = DFAState({}, None)
    a.addarc(b, 'label1')
    a.addarc(b, 'label2')
    a.addarc(b, 'label3')
    a.addarc(b, 'label4')
    b.addarc(a, 'label1')
    b.addarc(a, 'label2')
    b.addarc(a, 'label3')
    b.addarc(a, 'label4')
    a.addarc(a, 'label1')
    a.addarc(a, 'label2')
    a.addarc(a, 'label3')
    a.addarc(a, 'label4')
    b.addarc(b, 'label1')

# Generated at 2022-06-23 15:57:33.105337
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():
    sa = DFAState({}, None)
    sb = DFAState({}, None)
    sc = DFAState({}, None)
    sa.addarc(sb, "a")
    sa.addarc(sc, "b")
    sa.unifystate(sb, sc)
    assert sa.arcs == {"a": sc, "b": sc}



# Generated at 2022-06-23 15:57:37.290635
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    source = """# Hello, world!
"""
    filename = "<string>"
    generator = tokenize.generate_tokens(io.StringIO(source).readline)
    parser = ParserGenerator(filename, generator)
    parser.gettoken()
    try:
        parser.raise_error("The answer is %d", 42)
    except SyntaxError as e:
        assert str(e) == "The answer is 42", e



# Generated at 2022-06-23 15:57:43.308410
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():
    a = DFAState({}, None)
    b = DFAState({}, None)
    c = DFAState({}, None)
    a.addarc(a)
    a.addarc(c)
    a.addarc(b)
    assert a.arcs == {"": a, "": c, "": b}
    a.unifystate(b, c)
    assert a.arcs == {"": a, "": c, "": c}


# For debugging

# Generated at 2022-06-23 15:57:49.894453
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    from . import grammar
    from . import dfa

    g = grammar.Grammar()
    g.add_terminal("'a'", 0)
    g.add_nonterminal("S")
    g.add_production("S1", "S", ["'a'"])
    g.start = "S"

    start, dfa = dfa.make_dfa(g.start, g)
    assert isinstance(start, dfa.DFAState)
    assert isinstance(dfa, dfa.DFAMap)

    p = ParserGenerator([start], dfa, g.start)
    p.addfirstsets()
    f = p.make_first(None, "S")
    assert f == {0: 1}



# Generated at 2022-06-23 15:57:54.243573
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    import tokenize
    import io
    input = io.StringIO("a")
    tokens = tokenize.generate_tokens(input.readline)
    pg = ParserGenerator()
    pg.grammar = """
        file_input: (NEWLINE | RULE)* ENDMARKER
        RULE: NAME ':' RHS NEWLINE
        RHS: ALT ('|' ALT)*
        ALT: ITEM+
        ITEM: '[' RHS ']' | ATOM ['+' | '*']
        ATOM: '(' RHS ')' | NAME | STRING
    """
    # test 1, no exceptions should be raised
    pg.parse_rhs()


# Generated at 2022-06-23 15:58:06.058687
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    pg = ParserGenerator()

# Generated at 2022-06-23 15:58:17.100318
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    import textwrap
    pg = ParserGenerator()
    pg.add_rule("foo", ["bar"])
    pg.add_rule("bar", ["foo"])
    pg.add_rule("bar", ["baz", "baz"])
    pg.add_rule("bar", ["baz", "+", "baz"])
    pg.add_rule("bar", ["baz", "+"])
    pg.add_rule("bar", ['"a"', "|", '"b"', "|", '"c"'])
    pg.add_rule("bar", ['"a"', "|", "'b'", "|", '"c"'])
    pg.add_rule("bar", ['"a"', "|", "'b'", "|", "'c'"])

# Generated at 2022-06-23 15:58:25.369381
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    from . import token
    from .parser import ParserGenerator, ParserGeneratorGrammar
    filename = "<test>"
    text = "NAME STRING ('+' | '*')"
    tupgenerator = tokenize.generate_tokens(StringIO(text).readline)
    tokens = list(tupgenerator)
    assert tokens[0] == (tokenize.NAME, 'NAME', (1, 0), (1, 4), 'NAME STRING (\'+\' | \'*\')\n')
    assert tokens[1] == (tokenize.NAME, 'STRING', (1, 5), (1, 11), 'NAME STRING (\'+\' | \'*\')\n')

# Generated at 2022-06-23 15:58:34.638897
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    import io
    import token
    import tokenize
    from tokenize import untokenize
    from tokenize import tokenize as tokenize_
    from typing import Iterable, Tuple

    def _tokenize(text: str) -> Iterable[Tuple[int, str, Tuple[int, int], Tuple[int, int], str]]:
        return tokenize_(io.BytesIO(bytes(text, "utf-8")).readline)

    def _untokenize(tokens: Iterable[Tuple[int, str, Tuple[int, int], Tuple[int, int], str]]) -> str:
        return "".join(untokenize(tokens))


# Generated at 2022-06-23 15:58:43.501436
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    try:
        import StringIO
    except ImportError:
        import io as StringIO

    def test(expected, code):
        out = StringIO.StringIO()
        pg = ParserGenerator()
        pg.dump_dfa("test", code)
        got = out.getvalue()
        assert got == expected

    test(
        """\
Dump of DFA for test
  State 0
    b -> 2
    d -> 1
  State 1 (final)
    d -> 1
  State 2 (final)
    """,
        [
            DFAState({}, False),
            DFAState({}, True, {"d": 2}),
            DFAState({}, True, ),
        ],
    )

# Generated at 2022-06-23 15:58:49.107928
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
  r = re.compile(r"\n  File \"([^\"]+)\", line (\d+)\n.*\n *(\^)\nSyntaxError: (.*)")
  def match(e):
    m = r.match(e.msg)
    return [m.group(1), int(m.group(2)), m.group(4), m.group(3)]
  p = ParserGenerator()
  # NOTE: the second argument is a tuple that is the target of this test.
  # The first and third arguments are always supplied automatically by the
  # test driver.

# Generated at 2022-06-23 15:59:01.030247
# Unit test for function generate_grammar
def test_generate_grammar():
    p = ParserGenerator()
    p.make_grammar()
    # The next step is to compile a parse table into a new file and then
    # read it into memory.  To compile the file, call the function
    # generate_grammar(), which will create Grammar.pickle.
    # The next step is to read this file and use it to create a Grammar
    # instance.  In the main Python interpreter, call:
    #     >>> from pgen2 import driver
    #     >>> driver.load_grammar("Grammar.pickle")
    # Once that's done, you should have a Grammar instance, g, which
    # you can use to parse other files:
    #     >>> driver.parse_tokens(tokens, g, debug=False)
    # You can also use the Grammar instance to recreate the

# Generated at 2022-06-23 15:59:06.863436
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    p = ParserGenerator()
    try:
        p.expect(token.NAME, "foo")
    except SyntaxError as e:
        assert e.args[0] == "expected NAME/foo, got OP/|"
    try:
        p.expect(token.OP, "]")
    except SyntaxError as e:
        assert e.args[0] == "expected OP/], got ENDMARKER/None"


# Generated at 2022-06-23 15:59:16.505786
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    def my_parse_item(generator, value):
        print("Testing", value)
        generator.value=value
        return generator.parse_item()
    pg = ParserGenerator()
    a,z = my_parse_item(pg, "(")
    a,z = my_parse_item(pg, ")")
    a,z = my_parse_item(pg, "[")
    a,z = my_parse_item(pg, "]")
    a,z = my_parse_item(pg, "NAME")
    a,z = my_parse_item(pg, "STRING")
    a,z = my_parse_item(pg, "+")
    a,z = my_parse_item(pg, "*")


# Generated at 2022-06-23 15:59:26.997863
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    p = ParserGenerator()

# Generated at 2022-06-23 15:59:39.599980
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    pg = ParserGenerator()
    pg.add_dfa(
        "foo",
        [(2, "bar"), (3, "a")],
        [(1, "b"), (5, "c")],
        [(-1, "d"), (4, "e")],
        [(4, "f"), (4, "g")],
    )
    pg.add_dfa(
        "bar",
        [(2, "a"), (3, "b"), (0, "c")],
        [(1, "d"), (5, "e")],
        [(-1, "f"), (4, "g")],
        [(4, "h"), (4, "i")],
    )
    pg.assemble_dfas("foo")
    pg.set_start("foo")
    pg.add_df

# Generated at 2022-06-23 15:59:51.878240
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    # Issue #6520
    dfa = [DFAState({0: 1, 1: 1}, None), DFAState({1: 1, 2: 1}, None)]
    dfa[0].addarc(dfa[0], "a")
    dfa[0].addarc(dfa[1], "b")
    dfa[1].addarc(dfa[0], "a")
    dfa[1].addarc(dfa[1], "b")
    ParserGenerator().simplify_dfa(dfa)
    assert len(dfa) == 2
    assert dfa[0].arcs == dfa[1].arcs
#@-others

#@-node:ekr.20100126082632.5393: * @file leo/core/leoParser.py
#@@

# Generated at 2022-06-23 15:59:59.440508
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    pg = ParserGenerator()
    pg.add_dfa("end_of_file", pg.start_state().add_arc(None, 0))
    assert_equal(
        pg.dump_dfa("end_of_file", pg.dfas["end_of_file"]), 1
    )
    return



# Generated at 2022-06-23 16:00:06.389679
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():
    s1 = DFAState({}, NFAState())
    s2 = DFAState({}, NFAState())
    s1.addarc(s2, "label")
    s1.unifystate(s2, s1)
    assert s1.arcs == {'label': s1}
    s2.addarc(s1, "label")
    s1.unifystate(s1, s2)
    assert s1.arcs == {'label': s2}
    assert s2.arcs == {'label': s2}


# Generated at 2022-06-23 16:00:14.529334
# Unit test for function generate_grammar
def test_generate_grammar():
    p = ParserGenerator(BytesIO(b"foo: bar\n"))
    p.make_grammar()
    p.dfas = {
        "foo": [DFAState({}, NFAState())],
        "bar": [DFAState({}, NFAState())],
    }
    p.first = {"foo": {}, "bar": {}}
    p.startsymbol = "foo"
    p.make_parsing_table()
    p.write_grammar_pickle(BytesIO())

# Generated at 2022-06-23 16:00:18.653502
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    assert isinstance(PgenGrammar(), grammar.Grammar)
    assert isinstance(PgenGrammar("string", "name", "start"), grammar.Grammar)
    assert isinstance(PgenGrammar("string", "name", "start", True), grammar.Grammar)


# Generated at 2022-06-23 16:00:29.253140
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():
    import py
    dfa1 = DFAState({}, NFAState())
    dfa2 = DFAState({}, NFAState())
    dfa3 = DFAState({}, NFAState())
    dfa4 = DFAState({}, NFAState())
    dfa1.addarc(dfa2, "a")
    dfa2.addarc(dfa3, "b")
    dfa3.addarc(dfa4, "c")
    dfa4.addarc(dfa2, "a")
    dfa1.addarc(dfa3, "d")
    dfa1.addarc(dfa1, "e")
    dfa1.unifystate(dfa2, dfa3)
    assert dfa1.arcs["a"] is dfa3

# Generated at 2022-06-23 16:00:38.871580
# Unit test for function generate_grammar
def test_generate_grammar():
    p = ParserGenerator("Grammar.txt")
    g = p.make_grammar()
    assert g is not None
    assert isinstance(g, PgenGrammar)
    assert not g.keywords
    assert not g.tokens
    assert not g.literals
    assert not g.start
    assert not g.labels
    assert g.states is not None
    assert isinstance(g.states, list)
    assert g.dfa is not None
    assert isinstance(g.dfa, list)
    assert g.errors is not None
    assert isinstance(g.errors, list)
    assert g.states == []
    assert g.dfa == []
    assert g.errors == []



# Generated at 2022-06-23 16:00:50.114782
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    import sys
    import io
    import tokenize
    import token
    import pytoken
    pytoken.add_filename("ParserGenerator_raise_error")
    pytoken.add_token("NAME", token.NAME)
    text = '''
# this is a comment

foo : bar baz
'''
    fp = io.StringIO(text)
    tokengen = tokenize.generate_tokens(fp.readline)
    generator = pytoken.generate_tokens(tokengen)
    g = ParserGenerator('', '', generator)
    g.gettoken()

# Generated at 2022-06-23 16:00:57.756021
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    import StringIO
    import traceback
    import tokenize
    import unittest

    class GeneratorTest(unittest.TestCase):

        source = '''
# test_ParserGenerator_gettoken()
x = ''' + repr('hi there') + '''
y = r''' + repr('hi there') + '''
z = "hi" 'there'
'''

# Generated at 2022-06-23 16:01:09.037894
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    pg = ParserGenerator()

# Generated at 2022-06-23 16:01:15.882106
# Unit test for method addarc of class DFAState
def test_DFAState_addarc():
    d = DFAState({}, NFAState())
    a = DFAState({}, NFAState())
    d.addarc(a, '"foo"')
    assert d.arcs == {'"foo"': a}
    d.addarc(a, '"bar"')
    assert d.arcs == {'"foo"': a, '"bar"': a}
    aa = DFAState({}, NFAState())
    d.addarc(aa, '"foo"')
    assert d.arcs == {'"foo"': aa, '"bar"': a}
