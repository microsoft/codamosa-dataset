

# Generated at 2022-06-23 15:51:19.358807
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    tmpdir = tempfile.mkdtemp()
    try:
        filename = os.path.join(tmpdir, 'testfile')
        f = open(filename, 'w')
        try:
            f.write('# This is a comment.\n')
            f.write('x : x\n')
        finally:
            f.close()

        g = PgenGrammar(filename)
    finally:
        os.remove(filename)
        os.rmdir(tmpdir)



# Generated at 2022-06-23 15:51:28.839458
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    grammar_string = """
    # The grammar for an arithmetic expression
    #
    # Use the '|' operator to identify multiple alternatives.
    # Repeat a pattern using '+', and make it optional using '[ ... ]'.
    # Use '( ... )' for grouping.
    expr    : sum
    sum     : prod ('+' prod)*
    prod    : value ('*' value)*
    value   : NUMBER | '(' expr ')'
    """
    grammar_lines = grammar_string.split("\n")
    pgen = ParserGenerator(grammar_lines)
    pg = pgen.make_grammar()
    assert isinstance(pg, PgenGrammar)
    assert pg.pgen_grammar == grammar_lines
    assert pg.start == 0

# Generated at 2022-06-23 15:51:38.924239
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    from . import tokens, grammar
    from .pgen2 import driver
    from . import token
    from . import tokenize
    from . import symbol as sym
    from .pgen2.pgen import ParserGenerator
    from .pgen2.convert import Converter
    from .pgen2.parse import ParseError
    import io
    import os
    import sys
    import unittest
    import warnings

    # Global objects
    tok_name = token.tok_name

    class MockFile(io.StringIO):
        def close(self) -> None:
            pass

    class MockTokenizer(tokenize.StringIO):
        def __init__(self, readline: str) -> None:
            tokenize.StringIO.__init__(self, readline)
            self.filename = readline

       

# Generated at 2022-06-23 15:51:46.235279
# Unit test for method __eq__ of class DFAState
def test_DFAState___eq__():
    state = DFAState({}, None)
    assert state == state
    assert state != None
    assert state != DFAState({}, None)
    other = DFAState({}, None)
    other.isfinal = True
    assert state != other
    other.isfinal = False
    assert state != other
    other.addarc(other, 'e')
    assert state != other
    state.addarc(state, 'e')
    assert state == other
    assert state != None
    assert state != 1
    assert not (state != state)


# Generated at 2022-06-23 15:51:48.878060
# Unit test for method addarc of class DFAState
def test_DFAState_addarc():
    s0 = DFAState({}, NFAState())
    s1 = DFAState({}, NFAState())
    s1.addarc(s0, "a")
    assert s1.arcs["a"] is s0


# Generated at 2022-06-23 15:51:57.965138
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    pg = ParserGenerator()

# Generated at 2022-06-23 15:52:05.181362
# Unit test for method __eq__ of class DFAState
def test_DFAState___eq__():
    a = DFAState({}, None)
    b = DFAState({}, None)
    assert a == b
    b.isfinal = True
    assert a != b
    a.isfinal = True
    assert a == b
    a.arcs["foo"] = a
    assert a != b
    b.arcs["foo"] = a
    assert a == b
    b.arcs["foo"] = b
    assert a != b
    assert a != 1
    assert a != None

# Generated at 2022-06-23 15:52:18.057473
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    c = ParserGenerator().make_converter()
    # Test NAME/NAME
    assert c.make_label(c, "foo") == c.make_label(c, "foo")
    assert c.make_label(c, "foo") == len(c.labels) - 1
    # Test NAME/NUMBER
    assert c.make_label(c, "foo") == c.make_label(c, "NUMBER")
    assert c.make_label(c, "foo") == len(c.labels) - 1
    # Test NAME/NAME
    assert c.make_label(c, "foo") == c.make_label(c, "foo")
    assert c.make_label(c, "foo") == len(c.labels) - 1
    # Test NUMBER/NAME
    assert c

# Generated at 2022-06-23 15:52:27.431543
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    # This method tests the functionality of calcfirst
    # as a standalone unit, without going through the parser
    from . import grammar
    pg = ParserGenerator()

# Generated at 2022-06-23 15:52:30.644214
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    pg = ParserGenerator()
    pg.dfas.update(grammar.dfas)
    pg.first.update(grammar.first)
    pg.addfirstsets()
    pg.make_parser()

# Generated at 2022-06-23 15:52:42.667637
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    import sys
    from . import pytree

    def remove_comments_and_pseudo_python(grammar: Text) -> Text:
        # Remove comments and pseudo-Python tokens, which we don't know
        # how to parse otherwise
        import tokenize

        result: List[Text] = []
        for type, value, begin, end, line in tokenize.generate_tokens(
            io.StringIO(grammar).readline
        ):
            if type == tokenize.COMMENT:
                continue
            if type == tokenize.OP and value in "+=|.":
                continue
            if type in (token.NAME, token.STRING) and (" " in value or "\t" in value):
                print("Don't know how to tokenize %r" % value, file=sys.stderr)
                continue
           

# Generated at 2022-06-23 15:52:47.600763
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():
    class TestDFAState(DFAState):
        def addarc(self, next, label):
            self.arcs[label] = next

    a = TestDFAState({}, None)
    b = TestDFAState({}, None)
    c = TestDFAState({}, None)
    d = TestDFAState({}, None)
    a.addarc(a, "a")
    a.addarc(b, "b")
    a.addarc(c, "c")
    b.addarc(d, "d")
    b.addarc(c, "c")
    d.addarc(c, "c")
    d.addarc(b, "b")
    a.unifystate(b, c)

# Generated at 2022-06-23 15:52:56.438386
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    conv = Converter(
        {
            "start": [
                DFAState(
                    {0: 1, 1: 1, 2: 1},
                    {
                        frozenset(): 0,
                        frozenset({1}): 1,
                        frozenset({0}): 2,
                        frozenset({0, 1}): 3,
                        frozenset({1, 2}): 4,
                        frozenset({0, 2}): 5,
                        frozenset({0, 1, 2}): 6,
                    },
                )
            ],
            "x": [
                DFAState({1: 1}, {frozenset({1}): 1}),
                DFAState({1: 1, 2: 1}, frozenset({0: 2})),
            ],
        },
        "start",
    )
   

# Generated at 2022-06-23 15:53:06.784702
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    pg = ParserGenerator()
    test_rhs = "AAA | BBB | CCC"
    pg.setup(test_rhs)
    expected = """
    0
    1 BBB -> 0
    1 CCC -> 0
    2 -> 0
    3 -> 1
    4 -> 2"""
    pg.expect(token.NAME, "AAA")
    pg.expect(token.OP, "|")
    pg.expect(token.NAME, "BBB")
    pg.expect(token.OP, "|")
    pg.expect(token.NAME, "CCC")
    pg.expect(token.ENDMARKER)
    result = pg.output_nfa()
    assert result == expected



# Generated at 2022-06-23 15:53:17.638484
# Unit test for method addarc of class DFAState
def test_DFAState_addarc():
    a = DFAState(None, None)
    b = DFAState(None, None)
    a.addarc(b, "label")
    assert a.arcs["label"] is b
    try:
        a.addarc(b, "label")
    except KeyError:
        pass
    else:
        raise ValueError("expected KeyError with duplicate label")


if __name__ == "__main__":
    import sys, getopt


# Generated at 2022-06-23 15:53:20.770781
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    try:
        raise SyntaxError("Bad token", ("File", 1, 1, "Line"))
    except SyntaxError as ex:
        assert ex.args == ("Bad token", ("File", 1, 1, "Line")), ex.args



# Generated at 2022-06-23 15:53:24.159858
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    parser = ParserGenerator()
    parser.generator = tokenize.generate_tokens(io.StringIO('a b+').readline)
    parser.gettoken()
    parser.parse_alt()



# Generated at 2022-06-23 15:53:36.748354
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    from . import token
    from . import grammar

    pg = ParserGenerator()

# Generated at 2022-06-23 15:53:46.529673
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    from . import parsetok
    from .tokenizer import Untokenizer
    from .token import token_map
    from . import pytoken
    from . import symbol
    from .pygram import PythonGrammar
    c = ParserGenerator(PythonGrammar, "graminit.c")
    c.addfirstsets()
    for name, first in sorted(c.first.items()):
        print(name, repr(first.keys()))
    # f = open("graminit.c", "r")
    # ut = Untokenizer(f.readline)
    # while True:
    #     try:
    #         type, value, begin, end, line = next(ut)
    #     except StopIteration:
    #         break
    #     type = token_map[type]
    #     if type ==

# Generated at 2022-06-23 15:53:57.300299
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    import cStringIO as io
    import pgen2.driver

    r = ParserGenerator()
    print("reading")
    file = io.StringIO(pgen2.driver.grammar)
    r.read_grammar(file, "grammar")
    print("adding first sets")
    r.addfirstsets()
    print("converting")
    c = r.make_converter(False)
    print("writing")
    file = io.StringIO()
    c.write(file)
    file.seek(0)

# Generated at 2022-06-23 15:54:07.267633
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    pg = ParserGenerator()
    dfa = [DFAState({'a': 1, 'b': 1, 'c': 1}, 'is_final'), DFAState({'d': 1, 'e': 1, 'f': 1}, 'is_final'), DFAState({'g': 1, 'h': 1, 'i': 1}, 'is_final')]
    dfas = [DFAState(dfa[0].nfaset, dfa[0].isfinal), DFAState(dfa[1].nfaset, dfa[1].isfinal), DFAState(dfa[2].nfaset, dfa[2].isfinal)]
    dfas[0].addarc(dfas[1], 'z')
    dfas[0].addarc(dfas[1], 'j')
    dfas

# Generated at 2022-06-23 15:54:08.741230
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    pg = ParserGenerator()
    pg.parse_item()

# Generated at 2022-06-23 15:54:13.286198
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():
    a = DFAState({}, None)
    b = DFAState({}, None)
    c = DFAState({}, None)
    a.addarc(b)
    a.addarc(c)
    a.unifystate(b, c)
    assert a.arcs[0] is a.arcs[1]



# Generated at 2022-06-23 15:54:16.372123
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    pg = ParserGenerator()
    pg.input = "''"
    pg.gettoken()
    a, z = pg.parse_atom()
    assert z.arcs == [(None, pg.NFAState())]
    assert a.arcs == [("''", z)]

# Generated at 2022-06-23 15:54:26.651530
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    # Parse the string, construct a ParserGenerator,
    # and invoke the method under test
    string = """
[
  '(' RHS ')' | NAME | STRING
]
"""
    pgen = ParserGenerator(string, "test_ParserGenerator_parse_atom")
    actual = pgen.parse_item()
    # Build an expected result
    start = NFAState()
    end = NFAState()
    start.addarc(start, "[")
    start.addarc(end, "]")
    # Compare the actual result to the expected result
    assert actual == (start, end)

# Generated at 2022-06-23 15:54:37.089916
# Unit test for constructor of class DFAState
def test_DFAState():  # pragma: no cover
    from pprint import pprint

    d1 = DFAState({1: 1}, 2)
    d2 = DFAState({1: 1}, 3)
    d3 = DFAState({1: 1}, 3)

    print(d1 == d1)
    print(d1 == d2)
    print(d2 == d3)
    d2.arcs = {1: d2, 2: d2}
    d3.arcs = {1: d3, 2: d3}
    print(d2 == d3)
    d3.arcs = {1: d3, 2: d2}
    print(d2 == d3)
    d3.arcs = {1: d3, 2: d3}
    d3.isfinal = not d3.isfinal

# Generated at 2022-06-23 15:54:45.970412
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    global token
    token = __import__("token", globals(), level=1)
    # NFAState, DFAState, NFADump
    nfa = NFAState()
    p = ParserGenerator(
        [
            (token.NAME, "expr1"),
            (token.NEWLINE, "\n"),
            (token.NAME, "expr2"),
            (token.OP, ":"),
            (token.STRING, "expr3"),
            (token.NAME, "expr4"),
            (token.NEWLINE, "\n"),
        ],
        None,
        nfa,
    )
    p.parse_item()



# Generated at 2022-06-23 15:54:47.038154
# Unit test for constructor of class NFAState
def test_NFAState():
    assert isinstance(NFAState(), NFAState)



# Generated at 2022-06-23 15:54:51.300227
# Unit test for method __eq__ of class DFAState
def test_DFAState___eq__():
    a = DFAState({}, None)
    b = DFAState({}, None)
    a.isfinal = True
    a.arcs = {0: a}
    b.isfinal = True
    b.arcs = {0: b}
    assert a == b



# Generated at 2022-06-23 15:54:54.932955
# Unit test for method addarc of class NFAState
def test_NFAState_addarc():
    a1 = NFAState()
    a2 = NFAState()
    a1.addarc(a2)
    assert [("", a2)] == a1.arcs
    assert 0 == len(a2.arcs)
    a3 = NFAState()
    a1.addarc(a3, "a")
    assert [("", a2), ("a", a3)] == a1.arcs
    assert 0 == len(a2.arcs)
    assert 0 == len(a3.arcs)



# Generated at 2022-06-23 15:54:56.740173
# Unit test for constructor of class NFAState
def test_NFAState():
    nfastate0 = NFAState()
    nfastate1 = NFAState()
    nfastate0.addarc(nfastate1, "label")
    print("NFAState.addarc()", nfastate0.arcs)



# Generated at 2022-06-23 15:55:09.402433
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    pg = ParserGenerator()

# Generated at 2022-06-23 15:55:17.376303
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    import tokenize


# Generated at 2022-06-23 15:55:26.656728
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    # testing function ParserGenerator.simplify_dfa
    pg = ParserGenerator()
    dfa = [DFAState(set([NFAState]))]
    pg.simplify_dfa(dfa)
    assert dfa == [DFAState(set([NFAState]))]
    s = NFAState()
    dfa = [DFAState(set([s])), DFAState(set([s]))]
    pg.simplify_dfa(dfa)
    assert dfa == [DFAState(set([s]))], repr(dfa)
    s0 = NFAState()
    s1 = NFAState()
    s2 = NFAState()

# Generated at 2022-06-23 15:55:29.911999
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    pg = ParserGenerator()
    grammar = r"""
    start: ('a' | 'b')+ '\n'
    """
    pg.parse(grammar)
    assert isinstance(pg.dfas, dict)

# Generated at 2022-06-23 15:55:35.349451
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    """
    >>> p = ParserGenerator()
    >>> p.dump_nfa('foo', NFAState(), NFAState())
    Dump of NFA for foo
      State 0
        None -> 1
      State 1
    """

# Generated at 2022-06-23 15:55:44.964437
# Unit test for method parse_item of class ParserGenerator

# Generated at 2022-06-23 15:55:46.451518
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    """Test the constructor of PgenGrammar (indirect)."""
    _test_PgenGrammar_helper('Python.grammar')


# Generated at 2022-06-23 15:55:58.436518
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    pg = ParserGenerator()
    c = pg.make_converter()

    simple_grammar = [
        ("a", ["1"]),
        ("b", ["2"]),
        ("c", ["3"]),
        ("d", ["4"]),
        ("e", ["5"]),
        ("f", ["6"]),
        ("S", ["a", "b", "c", "d", "e", "f"]),
    ]
    for lhs, rhs in simple_grammar:
        pg.addproduction(lhs, rhs)
    pg.addfirstsets()

    assert c.make_first(c, "S") == {
        1: 1,
        2: 1,
        3: 1,
        4: 1,
        5: 1,
        6: 1,
    }

# Generated at 2022-06-23 15:56:09.349449
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    pg = ParserGenerator()
    # s+
    pg.addtoken(token.OP, "+")
    pg.addtoken(token.NAME, "s")
    pg.make_parse_table()
    # Table has just one state with one rule:
    #   s: NAME '+' | NAME
    dfa = pg.dfas["s"][0]
    assert len(dfa.arcs) == 2
    for state, (label, next) in zip(pg.dfas["s"], dfa.arcs.items()):
        assert label == (token.NAME, "s")
        assert next is state
    assert dfa.isfinal
    # Hm, this is tricky to test as it depends on knowledge
    # of the implementation of ParserGenerator, plus the
    # implementation might change...
    # assert

# Generated at 2022-06-23 15:56:16.797389
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    import io
    import contextlib
    from typing import Sequence

    class ParserGenerator(ParserGeneratorBase):
        def __init__(self, *args: Any, **kwargs: Any) -> None:
            super().__init__(*args, **kwargs)

        def dump_nfa(self, name: Text, start: "NFAState", finish: "NFAState") -> None:
            self.nfas.append((name, start, finish))

        def parse(self) -> Tuple[Dict[Text, List["DFAState"]], Text]:
            self.nfas: List[Tuple[Text, "NFAState", "NFAState"]] = []
            ret = super().parse()
            return ret + (self.nfas,)


# Generated at 2022-06-23 15:56:26.911064
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    '''This method is called by the file-level unit test code.'''
    pgen = ParserGenerator()
    code = '''expr: a="(" [expr] ")" | b=NAME | c=STRING
a: b="(" [a] ")" | c=NAME | d=NAME | d=STRING
b: z=STRING | z="[" a "]"
'''
    dfas, start = pgen.parse(io.StringIO(code))
    assert start == "expr"
    assert len(dfas) == 3
    assert len(dfas["expr"]) == 5
    assert len(dfas["a"]) == 4
    assert len(dfas["b"]) == 2

# Generated at 2022-06-23 15:56:37.970410
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():

    filename = __file__[:-2] + "grammar"
    m = PgenGrammar(filename)
    assert m.start == 57
    assert len(m.symbol2number) == 169

# Generated at 2022-06-23 15:56:47.060225
# Unit test for method addarc of class NFAState
def test_NFAState_addarc():
    a = NFAState()
    b = NFAState()
    c = NFAState()
    a.addarc(b, "a")
    b.addarc(c)

    assert len(a.arcs) == 1
    assert a.arcs[0][0] == "a"
    assert a.arcs[0][1] is b

    assert len(b.arcs) == 1
    assert b.arcs[0][0] is None
    assert b.arcs[0][1] is c



# Generated at 2022-06-23 15:56:53.335333
# Unit test for method addarc of class NFAState
def test_NFAState_addarc():
    n1 = NFAState()
    n2 = NFAState()
    n1.addarc(n2)
    assert n1.arcs[0] == (None, n2)
    n1.addarc(n2, 'x')
    assert n1.arcs[1] == ('x', n2)



# Generated at 2022-06-23 15:57:05.242638
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():

    # Create an instance of class ParserGenerator
    pgen = ParserGenerator()

    # Add some attributes for testing
    pgen.first = {}

# Generated at 2022-06-23 15:57:14.478667
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    gen = ParserGenerator()
    s = DFAState({}, False)
    dfa = [s]
    gen.simplify_dfa(dfa)
    assert dfa == [s]
    p = DFAState({}, False)
    s.addarc(p, "a")
    gen.simplify_dfa(dfa)
    assert dfa == [s]
    q = DFAState({}, False)
    q.addarc(p, "a")
    gen.simplify_dfa(dfa)
    assert dfa == [s, q]


# Generated at 2022-06-23 15:57:19.811570
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():  # Type ignore
    pgen = ParserGenerator()
    code = textwrap.dedent(
        """
        x : 'x'
        y : 'y'
        z : 'z'
        """
    )
    dfas, startsymbol = pgen.parse_grammar(code, "<test>")
    dfa = dfas["x"]
    assert len(dfa) == 2
    assert dfa[0].arcs == {"x": [dfa[1]]}
    assert dfa[1].arcs == {}
    pgen.dump_dfa("x", dfa)



# Generated at 2022-06-23 15:57:28.294691
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    """Generating the grammar's grammar"""
    pg = ParserGenerator()
    pg.make_grammar()
    pg.make_pgen_grammar()
    #pg.addfirstsets()
    #print(pg.first)
    #print()
    #assert len(pg.dfas) == len(pg.first) == 9
    #assert pg.startsymbol == "file_input"
    #assert len(pg.first["exprlist"]) == 1
    #print()
    #pg.make_pgen_grammar()



# Generated at 2022-06-23 15:57:36.547326
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    p = ParserGenerator()
    p.gettoken = lambda: None  # type: ignore
    p.type = token.OP
    p.value = "("
    # p.filename = ...
    p.begin = (1, 2)
    p.end = (2, 3)
    p.line = "zork"
    raises(SyntaxError, p.raise_error, "x")
    raises(SyntaxError, p.raise_error, "x%s", 42)
    raises(SyntaxError, p.raise_error, "x%s", 42, 43)
    try:
        p.raise_error("x")
    except SyntaxError as e:
        s = str(e)
        assert s == "x (zork, line 2)"

# Generated at 2022-06-23 15:57:45.303146
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    import sys
    import unittest
    import Grammar

    class TestCase(unittest.TestCase):
        def assertEqual(self, first, second, msg=None) -> None:
            if first != second:
                super().assertEqual(first, second, msg)

    class ParserGeneratorTest(TestCase):
        def test_make_grammar(self):
            def check(rules, startsymbol, expected):
                pgen = ParserGenerator()
                actual = pgen.make_grammar(rules, startsymbol)
                self.assertEqual(actual, expected, pgen.error_leader())

            def t(*args, **kwds):
                return grammar.Token(*args, **kwds)


# Generated at 2022-06-23 15:57:53.060891
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    from _testcapi import getargs_b
    import unittest

    class ParserGeneratorTestCase(unittest.TestCase):
        def test_raise_error(self):
            # parser = ParserGenerator()
            foo = ParserGenerator()
            with self.assertRaises(Exception) as cm:
                foo.raise_error("expected %s/%s, got %s/%s", 'foo', 'bar', 'spam', 'eggs')
            self.assertEqual(
                str(cm.exception), 'expected foo/bar, got spam/eggs'
            )

        def test_raise_error_Message(self):
            # parser = ParserGenerator()
            foo = ParserGenerator()
            with self.assertRaises(Exception) as cm:
                foo.raise_error

# Generated at 2022-06-23 15:58:01.877881
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():
    B = DFAState({}, None)
    N = DFAState({}, None)
    A1 = DFAState({}, None)
    A2 = DFAState({}, None)
    A1.addarc(B, "a")
    A1.addarc(N, "b")
    A2.addarc(B, "a")
    A2.addarc(N, "b")
    A3 = DFAState({}, None)
    A3.addarc(B, "a")
    A3.addarc(N, "b")
    A3.addarc(B, "c")
    A3.unifystate(B, N)
    assert A1 == A2
    assert A1 == A3
    A3.unifystate(N, B)
    assert A1 == A3



# Generated at 2022-06-23 15:58:12.723685
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    from pprint import pprint
    import sys
    import traceback
    import unittest
    from io import StringIO

    class TestCase(unittest.TestCase):
        def test_parse_item_1(self):
            try:
                pg = ParserGenerator(StringIO("a"))
                pg.gettoken()
                pg.parse_item()
            except:
                typ, val, tb = sys.exc_info()
                traceback.print_exception(typ, val, tb, file=sys.stdout)
                self.assertFalse(True)

    unittest.main()



# Generated at 2022-06-23 15:58:24.484785
# Unit test for constructor of class DFAState
def test_DFAState():
    import pickle
    a = NFAState()
    b = NFAState()
    c = NFAState()
    d = NFAState()
    a.addarc(b, "1")
    a.addarc(c, "2")
    c.addarc(d, "3")
    assert DFAState({a: 1, b: 1, c: 1}, d) == DFAState({a: 1, b: 1, c: 1}, d)
    assert DFAState({a: 1, b: 1, c: 1}, d) != DFAState({a: 1, b: 1, c: 1}, c)
    assert DFAState({a: 1, b: 1, c: 1}, d) != DFAState({a: 1, b: 1, c: 1}, b)

# Generated at 2022-06-23 15:58:31.421537
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    nfa1 = [NFAState(), NFAState(), NFAState()]
    nfa1[0].addarc(nfa1[1], "a")
    nfa1[1].addarc(nfa1[2])
    dfa1 = ParserGenerator().make_dfa(nfa1[0], nfa1[2])
    assert len(dfa1) == 2
    assert len(dfa1[0].arcs) == 1
    assert dfa1[0].arcs == {nfa1[1]: "a"}
    assert dfa1[0].nfaset == {nfa1[0], nfa1[1]}
    assert len(dfa1[1].arcs) == 2

# Generated at 2022-06-23 15:58:32.908582
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    p = ParserGenerator()
    p.parse_atom()

# Generated at 2022-06-23 15:58:39.519885
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    # Note: this test is copied from pgen2.py
    pg = ParserGenerator()
    gram = pg.parse_grammar(
        """
    start: start start
    x: 'x'
    """
    )
    c = pg.make_grammar(gram)
    assert c.symbol2number == {'x': 0, 'start': 1}
    assert c.first == {'start': {'x': 1}, 'x': {'x': 1}}

# Generated at 2022-06-23 15:58:52.015423
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
  # The faulty expression is "17 *"
  import io
  from typing import TextIO, List, Tuple
  from tokenize import TokenInfo
  from token import NUMBER, OP, COMMENT
  f: TextIO = io.StringIO("17 *\n")
  tokens: List[TokenInfo] = []
  while True:
    token: TokenInfo = tokenize.tokenize(f.readline)
    tokens.append(token)
    if token[0] == tokenize.ENDMARKER:
      break
  p: ParserGenerator = ParserGenerator(tokens, "Test file")
  p.gettoken() # Ignoring the first token ('17')
  t, v, b, e, l = tokens[2]
  assert t == OP
  assert v == '*'
  p.type = t

# Generated at 2022-06-23 15:59:03.084697
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    from . import grammar

    def t(s: Text, expected: Text) -> None:
        pgen = ParserGenerator(grammar.syms, s)
        a, z = pgen.parse_rhs()
        assert pgen.value == "", repr(pgen.value)
        got = pgen.dump_graphviz(a, z)
        assert expected == got, repr((expected, got))

    t("'a'", 'digraph { A0 -> A1 [label="a"]; A1 [peripheries=2]; }')
    t("'a'*", 'digraph { A0 -> A2 [label="epsilon"]; A2 -> A3 [label="a"]; A3 -> A2 [label="epsilon"]; A3 [peripheries=2]; }')

# Generated at 2022-06-23 15:59:08.065822
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():
    s1 = DFAState({}, None)
    s2 = DFAState({}, None)
    s3 = DFAState({}, None)
    s1.addarc(s2)
    s1.addarc(s3)
    s1.unifystate(s2, s3)
    assert s1.arcs == {None: s3, None: s3}

# Generated at 2022-06-23 15:59:12.876425
# Unit test for constructor of class DFAState
def test_DFAState():
    a = NFAState()
    b = NFAState()
    c = NFAState()
    d = NFAState()
    A = DFAState({a: 1, b: 1}, c)
    B = DFAState({a: 1, b: 1}, c)
    C = DFAState({a: 1, b: 1}, d)

# Generated at 2022-06-23 15:59:15.325980
# Unit test for method addarc of class DFAState
def test_DFAState_addarc():
    ds = pyparse.DFAState({}, None)
    ds.addarc(None, "a")


# Generated at 2022-06-23 15:59:26.306243
# Unit test for method addarc of class DFAState
def test_DFAState_addarc():
    a, b, c, d, e, f, g, h, i = [DFAState({}, None) for _ in range(9)]
    a.addarc(b, "a")
    a.addarc(c, "b")
    d.addarc(g, "c")
    d.addarc(h, "d")
    e.addarc(i, "e")
    assert a.arcs == {"a": b, "b": c}
    assert d.arcs == {"c": g, "d": h}
    assert e.arcs == {"e": i}
    a.unifystate(b, e)
    d.unifystate(h, e)
    assert a.arcs == {"a": e, "b": c}

# Generated at 2022-06-23 15:59:29.854578
# Unit test for method __eq__ of class DFAState
def test_DFAState___eq__():
    # Check if exactly the same state has the same hash.
    a = DFAState({1: 'w'}, 1)
    b = DFAState({1: 'w'}, 1)
    assert a == b



# Generated at 2022-06-23 15:59:41.900225
# Unit test for method addfirstsets of class ParserGenerator

# Generated at 2022-06-23 15:59:54.066045
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    # Setup
    from collections import namedtuple
    from types import FunctionType
    from typing import Type

    class Token:
        def __init__(self, type: int, value: Text) -> None:
            self.type = type
            self.value = value

        def __repr__(self) -> Text:
            return "Token({!r}, {!r})".format(self.type, self.value)

    class Generator:
        def __init__(self, tokens: List[Token]) -> None:
            self.tokens = tokens

        def __iter__(self) -> "Generator":
            return self

        def __next__(self) -> Token:
            return self.next()

        def next(self) -> Token:
            return self.tokens.pop(0)


# Generated at 2022-06-23 15:59:57.748726
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    g = PgenGrammar(PgenGrammar)
    assert g is not None


# Generated at 2022-06-23 16:00:03.996648
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    pg = ParserGenerator()
    pg.add_dfa('a', [
        ('<', 2),
        (None, 1),
        (None, 3),
    ])
    pg.add_dfa('b', [
        ('>', 2),
        (None, 1),
        (None, 4),
    ])
    pg.add_dfa('c', [
        ('=', 2),
        (None, 1),
        (None, 5),
    ])
    pg.add_dfa('d', [
        ('<', 2),
        (None, 1),
        (None, 6),
    ])
    pg.add_dfa('e', [
        ('>', 2),
        (None, 1),
        (None, 7),
    ])

# Generated at 2022-06-23 16:00:15.380989
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():
    a = DFAState({}, None)
    b = DFAState({}, None)
    c = DFAState({}, None)
    a.arcs = {'b': b}
    a.unifystate(b, c)
    assert a.arcs == {'b': c}
    assert b.arcs == {}
    assert c.arcs == {}
    a.arcs = {'b': b, 'c': c}
    a.unifystate(b, c)
    assert a.arcs == {'b': c, 'c': c}
    assert b.arcs == {}
    assert c.arcs == {}



# Generated at 2022-06-23 16:00:26.785750
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    # The following is a simple test for the parser generator, which
    # creates an NFA, a DFA, and a parse() function, and then uses
    # them to parse a tiny sample of Python source code
    pg = ParserGenerator()
    pg.add("stmts", r"""
        IF expr ':' suite
            (ELIF expr ':' suite)*
            [ELSE ':' suite]
        END
    """)
    pg.add("suite", r"""
        stmt+ NEWLINE
    """)
    pg.add("stmt", r"""
        (expr NEWLINE | simple_stmt)
    """)
    pg.add("simple_stmt", r"""
        small_stmt (';' small_stmt)* [';'] NEWLINE
    """)

# Generated at 2022-06-23 16:00:32.182272
# Unit test for method addarc of class NFAState
def test_NFAState_addarc():
    a = NFAState()
    b = NFAState()
    a.addarc(b, 'x')
    a.addarc(b, 'y')
    assert a.arcs == [('x', b), ('y', b)]


# Generated at 2022-06-23 16:00:38.213740
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    pg = ParserGenerator("")
    from_dfa = pg.make_dfa(
        NFAState([("a", NFAState()), (None, NFAState())]), NFAState()
    )
    a_set = {"a": 1}
    assert pg.make_first(PgenGrammar(""), a_set) == {1: 1}
    assert pg.make_first(PgenGrammar(""), {}) == {}

# Generated at 2022-06-23 16:00:47.373343
# Unit test for method addarc of class NFAState
def test_NFAState_addarc():
    for label in ['', 'abc', '123', '_xyz']:
        # Test with a 'good' label (like those used in parser.addarc)
        nfaState = NFAState()
        nfaState.addarc('next', label)
        expected = [(label, 'next')]
        assert nfaState.arcs == expected
    
    # Test exceptions
    nfaState = NFAState()
    with pytest.raises(AssertionError):
        nfaState.addarc(None, None)
    with pytest.raises(AssertionError):
        nfaState.addarc('next', '**')
    with pytest.raises(AssertionError):
        nfaState.addarc(None, 'label')

# Generated at 2022-06-23 16:00:55.193900
# Unit test for function generate_grammar
def test_generate_grammar():
    import unittest

    class TestGenerateGrammar(unittest.TestCase):
        def test_generate_grammar(self):
            p = ParserGenerator("Grammar.txt")
            p.make_grammar()

    unittest.main(
        None, None, [unittest.__file__, TestGenerateGrammar.__name__]
    )  # type: ignore
if __name__ == "__main__":
    import sys

    if len(sys.argv) == 1:
        generate_grammar()
    else:
        p = ParserGenerator(sys.argv[1])
        p.make_grammar()

# Generated at 2022-06-23 16:01:04.514000
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    from pgen2.grammar import Tokenizer
    from pprint import pprint

    def dump(tokenizer, tp, value, begin, end, line):
        print("%10s, %10s, %10s, %10s, %10s" % (tp, value, begin, end, line))

    pg = ParserGenerator()
    s = "  abc  def\n"
    tp = pg.gettoken()
    while tp != None:
        pprint(tp)
        tp = pg.gettoken()


# parser_generator.py ends here

# Generated at 2022-06-23 16:01:06.435876
# Unit test for method addarc of class NFAState
def test_NFAState_addarc():
    nfa_state = NFAState()
    next_nfa_state = NFAState()
    nfa_state.addarc(next_nfa_state, 'foo')
    assert nfa_state.arcs == [('foo', next_nfa_state)]


# Generated at 2022-06-23 16:01:13.254593
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    pg = ParserGenerator()
    pg.lexer = lexer = ParserGeneratorLexer(
        "1", 'a = "a" STRING | NAME\n'
    )
    result = pg.parse_item()

    assert result == (NFAState(arcs=[(None, NFAState(arcs=[('a', NFAState())])),
                                      (token.STRING, NFAState()),
                                      (token.NAME, NFAState())]),
                      NFAState(arcs=[(None, NFAState())]))
    assert lexer.type == token.STRING
