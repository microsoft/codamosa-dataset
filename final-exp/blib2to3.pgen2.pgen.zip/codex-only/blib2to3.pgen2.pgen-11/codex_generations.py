

# Generated at 2022-06-23 15:51:22.051894
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    s = """
    """
    global_specs = [
        '"""\nUnit test for method raise_error of class ParserGenerator" " "\n" "def test_ParserGenerator_raise_error():\n    s = """\n    """"',
        '',
        '\n',
        '"""',
        '\n',
        '\n',
        '',
        '\n',
        '\n',
    ]
    # source: PyPy
    pgen = ParserGenerator(s)
    generator = pgen.make_grammar_generator()
    pgen.generator = generator
    pgen.init_dfas()
    pgen.parse()
    pgen.addfirstsets()
    c = pgen.make_converter()
    dfa = c.df

# Generated at 2022-06-23 15:51:26.563613
# Unit test for constructor of class DFAState
def test_DFAState():
    #    a -- [b] -> c -- b -> d -- [a] -> e
    a = NFAState()
    b = NFAState()
    c = NFAState()
    d = NFAState()
    e = NFAState()
    a.addarc(b, None)
    a.addarc(c, "[")
    c.addarc(d, "b")
    d.addarc(e, None)
    d.addarc(a, "]")
    dfa = DFABuilder().make_dfa(a, e)
    DFABuilder().simplify_dfa(dfa)


# Generated at 2022-06-23 15:51:32.474171
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    f = open(os.devnull, "w")
    try:
        PgenGrammar(
            "test",
            [],
            PgenGrammar._tokens,
            {},
            {},
            "",
            "",
            "",
            "",
            "",
            "",
            f,
            {},
            {},
            {},
            {},
            {},
            (),
            None,
            {},
            {},
        )
    finally:
        f.close()



# Generated at 2022-06-23 15:51:44.615200
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    def check_ok(s: str, a: str, z: str) -> None:
        o = ParserGenerator()
        o.input(s)
        oa, oz = o.parse_alt()
        assert a == str(oa)
        assert z == str(oz)
    check_ok('"a"',
        'NFAState()',
        'NFAState()',
    )
    check_ok('"a" | "b"',
        'NFAState()',
        'NFAState()',
    )
    check_ok('"a" | "b" "c"',
        'NFAState()',
        'NFAState()',
    )

# Generated at 2022-06-23 15:51:55.815360
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    pg = ParserGenerator(StringIO(""))
    c = PgenGrammar()
    c.symbol2number = {"foo": 3}
    c.symbol2label = {}
    c.tokens = {token.NUMBER: 5}
    c.keywords = {"bar": 7}
    c.labels = [(0, ""), (1, None), (token.INDENT, None), (token.NEWLINE, ""),
                (token.DEDENT, None), (token.ENDMARKER, None),
                (token.NAME, "baz"), (5, None), (token.NAME, "bar"), (7, None)]
    for token in token.tok_name:
        print(pg.make_label(c, token))
    assert pg.make_label(c, "foo") == 3

# Generated at 2022-06-23 15:51:57.683904
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    lr = ParserGenerator()


# Generated at 2022-06-23 15:52:10.141025
# Unit test for method __eq__ of class DFAState
def test_DFAState___eq__():
    from pickle import dumps
    assert DFAState({"a": 1}, "a") == DFAState({"a": 1}, "a")
    assert DFAState({"a": 1}, "a") != DFAState({"a": 1}, "b")
    assert DFAState({"a": 1}, "a") != DFAState({"b": 1}, "a")
    dfa1 = DFAState({"a": 1}, "b")
    dfa2 = DFAState({"a": 1}, "b")
    dfa1.addarc(dfa2, "x")
    dfa2.addarc(dfa1, "y")
    assert dfa1 == dfa2
    assert dfa1.__eq__(dfa2)
    assert dfa2.__eq__(dfa1)


# Generated at 2022-06-23 15:52:17.147555
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    # This used to fail -- PyPy issue 1745
    import io

    f = io.StringIO("a")
    pg = ParserGenerator()
    pg.filename = "test_xxx"
    pg.generator = tokenize.generate_tokens(f.readline)
    pg.gettoken()
    assert pg.type == token.NAME
    assert pg.value == "a"



# Generated at 2022-06-23 15:52:25.728682
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():
    a = DFAState({object():True}, object())
    b = DFAState({object():True}, object())
    c = DFAState({object():True}, object())
    d = DFAState({object():True}, object())
    a.addarc(b, '0')
    d.addarc(a, '1')
    d.addarc(c, '2')
    a.unifystate(c, b)
    assert a.arcs == {'0':b, '1':a}
    assert b.arcs == {}
    assert c.arcs == {}
    assert d.arcs == {'1':a, '2':b}



# Generated at 2022-06-23 15:52:36.499316
# Unit test for method gettoken of class ParserGenerator

# Generated at 2022-06-23 15:52:46.300315
# Unit test for method __eq__ of class DFAState
def test_DFAState___eq__():
    a = DFAState({}, None)
    b = DFAState({}, None)
    assert a == b
    assert not a != b
    b.arcs = {'b': b}
    assert not a == b
    assert a != b
    a.arcs = {'a': a}
    assert not a == b
    assert a != b
    a.arcs = b.arcs
    assert a == b
    assert not a != b
    a.isfinal = True
    assert not a == b
    assert a != b
    b.isfinal = True
    assert a == b
    assert not a != b
    a.isfinal = False
    assert not a == b
    assert a != b

# Generated at 2022-06-23 15:52:55.609217
# Unit test for function generate_grammar
def test_generate_grammar():
    filename = Path(__file__).parent / "Grammar.txt"
    p = ParserGenerator(filename)
    grammar = p.make_grammar()
    assert grammar.keywords["False"] == 1
    assert grammar.keywords["None"] == 2
    assert grammar.keywords["True"] == 3
    assert grammar.start == "file_input"
    assert grammar.grammar[0] == "file_input", grammar.grammar[0]
    assert grammar.grammar[-1] == "return"
    assert grammar.symbol2number["file_input"] == 0
    assert grammar.symbol2number["return"] == 1
    assert grammar.symbol2label[0] == "file_input"
    assert grammar.symbol2label[1] == "return"
    assert grammar.symbol2label

# Generated at 2022-06-23 15:53:07.153744
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    pg = ParserGenerator()

    pg.dfas = {
        "a": [DFAState({})],
        "b": [DFAState({})],
        "c": [DFAState({})],
        "d": [DFAState({})],
        "e": [DFAState({})],
        "f": [DFAState({})],
        "g": [DFAState({})],
    }

    pg.dfas["a"][0].addarc(pg.dfas["b"][0], "1")
    pg.dfas["a"][0].addarc(pg.dfas["c"][0], "2")
    pg.dfas["a"][0].addarc(pg.dfas["d"][0], "3")

# Generated at 2022-06-23 15:53:16.852412
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    import tokenize
    from io import StringIO
    from pgen.parsetok import ParserGenerator
    # Method parse_atom has a docstring: parse_atom(self) -> Tuple[NFAState, NFAState]:
    # Type information:
        # Arguments:
            #   self: ParserGenerator
        # Return type: Tuple[NFAState, NFAState]
    # No example provided

    # Make an instance of ParserGenerator:
    pg = ParserGenerator()
    # Check the docstring:
    assert pg.parse_atom.__doc__ == 'parse_atom(self) -> Tuple[NFAState, NFAState]:\n'
    # Try calling parse_atom with a bad argument count:

# Generated at 2022-06-23 15:53:25.630035
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    pg = ParserGenerator()
    l = tokenize.generate_tokens(io.StringIO("test").readline)
    l.send(None)
    pg.generator = l

    pg.type = token.NAME
    pg.value = "test"
    pg.gettoken = lambda: None
    assert pg.expect(token.NAME) == "test"
    pg.gettoken = lambda: None
    assert pg.expect(token.NAME, "test") == "test"

    def token(type: int, value: Text) -> Iterator[Tuple[int, Text, Tuple[int, int],
                                                   Tuple[int, int], Text]]:
        yield type, value, (0, 0), (0, 0), ""
    pg.type = token.NAME

# Generated at 2022-06-23 15:53:37.449096
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    pg = ParserGenerator()
    pg.add_rhs("rhs", ["foo", "bar", "baz"])
    assert pg.dfas == {
        "rhs": [
            DFAState(
                {NFAState(0, "foo"): 1, NFAState(0, "bar"): 1, NFAState(0, "baz"): 1,},
                NFAState(1, None),
            ),
            DFAState({NFAState(1, None): 1}, NFAState(1, None)),
        ]
    }
    assert pg.symbol2number == {"rhs": 0}

    # Test a rule with |
    pg.add_rhs("foo", ["a", "b"], ["c", "d"])

# Generated at 2022-06-23 15:53:46.949173
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    pg = ParserGenerator()
    pg.gettoken = lambda *args, **kw: None
    name = ''

# Generated at 2022-06-23 15:53:57.907413
# Unit test for method addarc of class DFAState
def test_DFAState_addarc():
    a = DFAState({}, NFAState())
    b = DFAState({}, NFAState())
    a.addarc(b, "foo")
    if a.arcs != {"foo": b}:
        raise AssertionError("addarc 1")
    a.addarc(b, "bar")
    if a.arcs != {"foo": b, "bar": b}:
        raise AssertionError("addarc 2")
    try:
        a.addarc(b, "foo")
    except ValueError:
        pass
    else:
        raise AssertionError("addarc 3")
    try:
        a.addarc(b, "bar")
    except ValueError:
        pass
    else:
        raise AssertionError("addarc 4")

# Generated at 2022-06-23 15:54:07.226794
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():
    a = DFAState({}, object())
    a.addarc(a, '')

    b = DFAState({}, object())
    b.addarc(b, '')
    b.addarc(a, '')

    c = DFAState({}, object())
    c.addarc(c, '')
    c.addarc(b, '')

    d = DFAState({}, object())
    d.addarc(d, '')
    d.addarc(a, '')
    d.addarc(c, '')

    a.unifystate(b, a)
    assert a == d


if __name__ == "__main__":
    test_DFAState_unifystate()

# Generated at 2022-06-23 15:54:08.656988
# Unit test for constructor of class NFAState
def test_NFAState():
    st = NFAState()
    assert st is not None


# Generated at 2022-06-23 15:54:11.961844
# Unit test for constructor of class NFAState
def test_NFAState():
    s = NFAState()
    s.addarc(s)
    assert len(s.arcs) == 1
    assert s.arcs[0][0] is None
    assert s.arcs[0][1] == s



# Generated at 2022-06-23 15:54:12.923427
# Unit test for function generate_grammar
def test_generate_grammar():
    print(generate_grammar())

# Generated at 2022-06-23 15:54:20.220781
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    import io

    # Test for the expect method of class ParserGenerator
    pg = ParserGenerator()
    pg.generator = iter(
        [
            (token.STRING, "'abc'", ('', 1, 0), ('', 1, 4), "abc"),
            (token.NAME, "abc", ('', 1, 0), ('', 1, 3), "abc"),
            (token.NAME, "def", ('', 1, 0), ('', 1, 3), "def"),
        ]
    )
    pg.gettoken()
    assert pg.type == token.STRING
    assert pg.value == "'abc'"
    pg.expect(token.STRING, "'abc'")
    assert pg.type == token.NAME
    assert pg.value == "abc"
    pg.expect(token.NAME)

# Generated at 2022-06-23 15:54:24.006682
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    # __init__()
    pg = PgenGrammar()
    assert isinstance(pg, grammar.Grammar)
    assert pg.names == []


# Pgen parser class



# Generated at 2022-06-23 15:54:35.321781
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    pg = ParserGenerator()
    class DummyDfaState:
        def __init__(self, arcs: Dict[str, int]) -> None:
            self.arcs = arcs
            self.__hash = None
        def __eq__(self, other: object) -> bool:
            return self.arcs == other.arcs
        def __hash__(self) -> int:
            if self.__hash is None:
                # XXX This hashing algorithm is flawed, but
                # sufficient for this unit test.
                self.__hash = hash(frozenset(self.arcs.items()))
            return self.__hash
        def unifystate(self, old: "DummyDfaState", new: "DummyDfaState") -> None:
            assert old is not new

# Generated at 2022-06-23 15:54:43.949248
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    parser = ParserGenerator()
    dfa = parser.make_dfa(
        NFAState(arcs=[(None, NFAState(arcs=[(None, NFAState(arcs=[]))]))]),
        NFAState([(None, NFAState(arcs=[(None, NFAState(arcs=[]))]))]),
    )
    parser.simplify_dfa(dfa)
    assert dfa == [DFAState({parser.nfastates[0]: 1}, parser.nfastates[2])]



# Generated at 2022-06-23 15:54:51.401598
# Unit test for method addarc of class DFAState
def test_DFAState_addarc():
    def do_test(label: Text) -> None:
        # don't test '+' or '*'
        a = DFAState({}, object())
        b = DFAState({}, object())
        a.addarc(b, label)
        assert a.arcs[label] is b

    do_test("abc")
    do_test(" ")
    do_test("")
    do_test("\t")
    do_test("$")
    do_test(".")
    do_test("-")



# Generated at 2022-06-23 15:55:03.943951
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    class DFAState:
        pass
    n1 = DFAState()
    n2 = DFAState()
    n3 = DFAState()
    n4 = DFAState()
    n5 = DFAState()
    n6 = DFAState()

    n1.arcs = {'a': n2, 'b': n3}
    n2.arcs = {'a': n4, 'b': n5}
    n3.arcs = {'a': n5, 'b': n5}
    n4.arcs = {'a': n2, 'b': n6}
    n5.arcs = {'a': n3, 'b': n6}
    n6.arcs = {'a': n6, 'b': n6}

# Generated at 2022-06-23 15:55:11.904096
# Unit test for method __eq__ of class DFAState
def test_DFAState___eq__():
    r1 = DFAState({}, None)
    r2 = DFAState({}, None)
    r1.addarc(r1, None)
    r2.addarc(r2, None)
    r1.addarc(r2, None)
    r2.addarc(r1, None)
    r1.addarc(r2, "x")
    r2.addarc(r1, "x")
    assert r1 != r2



# Generated at 2022-06-23 15:55:23.666749
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    pg = ParserGenerator()
    grammar = """\
        S: C C
        C: c C | d
    """
    dfa, startsymbol = pg.parse_grammar(grammar)

# Generated at 2022-06-23 15:55:28.777474
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():
    a = DFAState({}, NFAState())
    b = DFAState({}, NFAState())
    c = DFAState({}, NFAState())
    a.addarc(a, 'x')
    a.addarc(b, 'y')
    b.addarc(c, 'z')
    a.unifystate(b, c)
    assert a.arcs == {'x': a, 'y': c}
    assert b.arcs == {'z': c}
    assert c.arcs == {}

# Generated at 2022-06-23 15:55:41.019781
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    #
    # ParserGenerator.make_label
    #
    # See test_use_grammar.py for a bigger test

    class MockConverter:
        def __init__(self) -> None:
            self.labels = []  # List of (token number, value) tuples
            self.tokens: Dict[int, int] = {}  # Map token number to text
            self.keywords: Dict[Text, int] = {}  # Map token text to label index
            self.symbol2label: Dict[Text, int] = {}  # Map symbol name to label index

    c = MockConverter()

    x = ParserGenerator()

    # A keyword
    label = x.make_label(c, "for")

# Generated at 2022-06-23 15:55:42.368420
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    raise NotImplementedError


# Generated at 2022-06-23 15:55:50.727989
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    o = ParserGenerator()
    o.filename = 'file'
    o.begin = (1,1)
    o.end = (1,1)
    o.line = 'line'
    o.gettoken()
    try:
        o.raise_error('message %s %s', 'format', 'args')
    except SyntaxError as e:
        assert e.msg == 'message format args'
        assert e.filename == o.filename
        assert e.lineno == o.end[0]
        assert e.offset == o.end[1]
        assert e.text == o.line
    else:
        assert False, 'Expected SyntaxError not raised'


# Generated at 2022-06-23 15:55:53.406533
# Unit test for constructor of class NFAState
def test_NFAState():
    a = NFAState()
    assert a.arcs == []
    b = NFAState()
    assert b.arcs == []
    c = NFAState()
    assert c.arcs == []
    a.addarc(b, "foo")
    assert a.arcs == [("foo", b)]
    a.addarc(c)
    assert a.arcs == [("foo", b), (None, c)]



# Generated at 2022-06-23 15:56:04.558122
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    class Fix(ParserGenerator):
        def gettoken(self):
            pass
    pg = Fix()

    # ITEM: '[' RHS ']' | ATOM ['+' | '*']
    def call_parse_item():
        pg.parse_item()

    # ITEM: '[' RHS ']' | ATOM ['+' | '*']
    pg.expect = lambda type, value: None
    pg.value = '['
    pg.parse_rhs = lambda: (1, 2)
    assert pg.parse_item() == (1, 2)

    # ITEM: '[' RHS ']' | ATOM ['+' | '*']
    pg.expect = lambda type, value: None
    pg.value = '['
    pg.parse_rhs = lambda: (1, 2)
   

# Generated at 2022-06-23 15:56:09.765600
# Unit test for constructor of class DFAState
def test_DFAState():
    a = NFAState()
    b = NFAState()
    c = NFAState()
    d = NFAState()
    s1 = DFAState({a: 1, b: 1}, c)
    s2 = DFAState({a: 1, b: 1, c: 1}, c)
    assert s1 == s2
    s2.addarc(d, "a")
    assert s1 != s2


# Generated at 2022-06-23 15:56:14.955384
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    grammar_src = """
        g: 'a' b
        b: 'b'
    """

    from . import parsers

    parser = parsers.GeneratedParser("g", grammar_src)
    pgen = ParserGenerator("g", parser.grammar_src)
    pgen.parse()
    pgen.addfirstsets()
    assert pgen.first["b"] == {"b": 1}
    assert pgen.first["g"] == {"a": 1, "b": 1}



# Generated at 2022-06-23 15:56:16.707911
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    pg = ParserGenerator()


# Generated at 2022-06-23 15:56:27.611921
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    from .nfa import NFAState, DFAState
    from .pgen import ParserGenerator

    pg = ParserGenerator()
    a = NFAState()
    b = NFAState()
    c = NFAState()
    b.addarc(None, a)
    b.addarc(None, c)
    b.addarc("x", a)
    a.addarc("y", c)
    c.addarc("z", b)
    pg.dump_nfa("foo", b, c)

    b = DFAState({a: 1}, c)
    c = DFAState({}, c)
    b.addarc(c, None)
    b.addarc(c, "x")
    c.addarc(b, "y")
    b.addarc(c, "z")

# Generated at 2022-06-23 15:56:29.523673
# Unit test for function generate_grammar
def test_generate_grammar():
    p = ParserGenerator('Grammar.txt')
    x = p.make_grammar()
    assert x.__class__ is PgenGrammar
    assert type(x._states) is set
    assert type(x._labels) is set

# Test for main

# Generated at 2022-06-23 15:56:35.552052
# Unit test for method __eq__ of class DFAState
def test_DFAState___eq__():
    a = DFAState({}, None)
    b = DFAState({}, None)
    assert a == b
    a.isfinal = True
    assert not (a == b)
    b.isfinal = True
    assert a == b
    exit = DFAState({}, None)
    a.addarc(exit, "label")
    assert not (a == b)
    b.addarc(exit, "label")
    assert a == b



# Generated at 2022-06-23 15:56:39.263470
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
  Grammar = ParserGenerator().build_grammar()
  assert Grammar.raise_error.__name__ == "raise_error"
test_ParserGenerator_raise_error()

ParserGenerator = ParserGenerator


# Generated at 2022-06-23 15:56:51.107943
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    input = """
    start: a
    a: "a"
    """
    nfa, startsymbol = ParserGenerator(input).parse()
    dfa, newstartsymbol = nfa.make_grammar()
    names = sorted(dfa.dfas.keys())
    assert names == [startsymbol]
    assert startsymbol == newstartsymbol
    assert 0 == len(dfa.states)
    assert 1 == len(dfa.dfas[startsymbol][0])
    assert 0 == len(dfa.dfas[startsymbol][0][0])
    assert {0: 1} == dfa.dfas[startsymbol][1]
    assert 1 == len(dfa.labels)
    assert ("a", None) == dfa.labels[0]

# Generated at 2022-06-23 15:56:54.291397
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    """Unit test for constructor of class PgenGrammar"""
    pgen_grammar = PgenGrammar(r'blib2to3\pgen2\pgen.grammar')



# Generated at 2022-06-23 15:57:01.499909
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    grammar = """
    start:
        expr $
    ;
    expr:
        expr "+" factor
        | expr "-" factor
        | factor
    ;
    factor:
        factor "*" term
        | factor "/" term
        | "-" factor
        | term
    ;
    term:
        NAME | NUMBER
    ;
    """
    pg = ParserGenerator(grammar)
    pg.make_grammar()



# Generated at 2022-06-23 15:57:09.633586
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    pg = ParserGenerator()
    c = PgenGrammar()
    method = pg.make_label
    for n in token.tok_name:
        if n.startswith("NT_"):
            continue
        i = getattr(token, n)
        assert method(c, n) == i
        assert method(c, repr(i)) == i
    method = pg.make_first
    c.labels = [(token.OP, "and"), (token.OP, "or")]
    c.symbol2number = {'a': 0, 'b': 1}
    c.symbol2label = {'a': 2, 'b': 3}
    assert method(c, 'a') == {token.OP: 1}
    c.labels.append((token.OP, "not"))
   

# Generated at 2022-06-23 15:57:21.285078
# Unit test for method __eq__ of class DFAState
def test_DFAState___eq__():
    # Test __eq__ of DFAState
    # DFAState.__eq__(s1, s2) ==> s1 == s2
    state1 = DFAState({}, None)
    state2 = DFAState({}, None)
    assert state1 == state2
    s = DFAState({}, None)
    state1 = DFAState({s: 1}, None)
    state2 = DFAState({s: 1}, None)
    assert state1 == state2
    state1 = DFAState({s: 1}, s)
    state2 = DFAState({s: 1}, s)
    assert state1 == state2
    state1 = DFAState({s: 1}, s)
    state2 = DFAState({s: 1}, None)
    assert not (state1 == state2)

# Generated at 2022-06-23 15:57:27.154598
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    import dfas
    p = ParserGenerator(dfas.__dict__)
    p.calcfirst('foo')
    assert p.first['foo'] is not None
    p.calcfirst('expr')
    assert p.first['expr'] is not None
    p.calcfirst('expr_stmt')
    assert p.first['expr_stmt'] is not None

# Generated at 2022-06-23 15:57:37.865864
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    pg = ParserGenerator()
    pg.dfas = {
        "a": [DFAState({}, 0)],
        "b": [DFAState({}, 0)],
        "c": [DFAState({}, 0)],
        "d": [DFAState({}, 0)],
        "e": [DFAState({}, 0)],
        "f": [DFAState({}, 0)],
    }
    pg.calcfirst("a")
    assert pg.first["a"] == {}
    pg.dfas["a"][0].addarc(pg.dfas["b"], "NAME")
    pg.calcfirst("a")
    assert pg.first["a"] == {"NAME": 1}
    pg.dfas["a"][0].addarc(pg.dfas["b"])
   

# Generated at 2022-06-23 15:57:43.582718
# Unit test for method addarc of class NFAState
def test_NFAState_addarc():
    start = NFAState()
    finish = NFAState()
    start.addarc(finish, 'a')
    assert start.arcs == [('a', finish)], start.arcs
    start.addarc(finish, 'a')
    assert start.arcs == [('a', finish), ('a', finish)], start.arcs
    start.addarc(finish)
    assert start.arcs == [('a', finish), ('a', finish), (None, finish)], start.arcs



# Generated at 2022-06-23 15:57:44.745178
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    pg = ParserGenerator()
    return True


# Generated at 2022-06-23 15:57:52.845292
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    from Grammar import Grammar
    from . import token, tokenize
    from . import parser

    g = Grammar()
    g.load_grammar(parser.__doc__)
    p = ParserGenerator(g)
    assert p.parse_atom() == (NFAState(), NFAState())
    p.gettoken()
    assert p.parse_atom(), (NFAState([], [(None, NFAState([], [(None, NFAState())],
                                                       True))]),
                            NFAState([], [(None, NFAState())], True))
    p.gettoken()

# Generated at 2022-06-23 15:58:01.422641
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    pg = ParserGenerator()
    pg.first, pg.dfas = {}, {}
    pg.calcfirst("expr")
    assert pg.first["expr"] == {"'(': 1, 'NAME': 1, 'NUMBER': 1"}
    pg.calcfirst("testlist_gexp")

# Generated at 2022-06-23 15:58:08.074590
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    s = textwrap.dedent(
        """\
        a: b
        b: "b"
        """
    )
    p = ParserGenerator()
    p.parse_grammar(s)
    p.addfirstsets()
    p.make_parser()

# Generated at 2022-06-23 15:58:11.644483
# Unit test for method addarc of class NFAState
def test_NFAState_addarc():
    p = NFAState.addarc
    a, b = NFAState(), NFAState()
    p(a, b)
    assert a.arcs == [(None, b)]


# Generated at 2022-06-23 15:58:20.685394
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    class DFAState:
        def __init__(self):
            self.arcs = {}
            self.isfinal = False

        def addarc(self, label, next):
            assert label not in self.arcs, "Label already exists"
            self.arcs[label] = next

        def __eq__(self, other):
            return (
                self.isfinal == other.isfinal
                and self.arcs == other.arcs
            )

        def __repr__(self):
            return (
                "<DFAState %s %s>"
                % (self.isfinal and "final" or "nonfinal", self.arcs)
            )

    class NFAState:
        def __init__(self):
            self.arcs = []  # List of pairs (label, next)


# Generated at 2022-06-23 15:58:29.587808
# Unit test for constructor of class DFAState
def test_DFAState():
    a = DFAState({}, None)
    assert a.nfaset == {}
    assert a.isfinal == 0
    assert a.arcs == {}
    a.addarc(a, "a")
    assert a.arcs == {"a": a}
    a.unifystate(a, a)
    assert a.arcs == {"a": a}
    b = DFAState({a: 1}, None)
    assert b.nfaset == {a: 1}
    assert b.isfinal == 0
    assert b.arcs == {}
    b.unifystate(a, a)
    assert b.arcs == {}


# Construct an NFA for a single character

# Generated at 2022-06-23 15:58:38.984461
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    import converter

    def check(pgen: ParserGenerator, label: Text, expected: int) -> None:
        grammar = pgen.make_ebnf_grammar(converter.EBNFConverter())
        ilabel = pgen.make_label(grammar, label)
        assert ilabel == expected

    pgen = ParserGenerator()
    pgen.dfas["expr"] = [DFAState({}, False)]
    pgen.dfas["term"] = [DFAState({}, False)]
    pgen.dfas["factor"] = [DFAState({}, False)]
    pgen.dfas["addop"] = [DFAState({}, False)]
    check(pgen, "expr", 0)
    check(pgen, "term", 1)

# Generated at 2022-06-23 15:58:45.643547
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():
    s = DFAState({}, NFAState())
    r1 = DFAState({}, NFAState())
    s.arcs = {'foo': r1}
    r2 = DFAState({}, NFAState())
    s.unifystate(r1, r2)
    assert s.arcs == {'foo': r2}, s.arcs
test_DFAState_unifystate()

# Generated at 2022-06-23 15:58:57.972223
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    global token
    token = grammar.token
    global tokenize
    tokenize = importlib.import_module("tokenize")
    pg = ParserGenerator()
    pg.parse_grammar(textwrap.dedent('''\
    START: '+' value NEWLINE
    value: NAME
          | value '*' value
          | '(' value ')'
    '''), '<test>')
    dfa, startsymbol = pg.dfas, pg.startsymbol
    for state in dfa['START']: assert not state.label, 'START'
    for state in dfa['value']: assert not state.label, 'VALUE'
    assert pg.first['START'] == pg.first['value'] == {'(': 1, 'NAME': 1}, 'FIRST'


# Generated at 2022-06-23 15:59:08.353985
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    dfa = [
        DFAState({}, None),
        DFAState({None: 1}, None),
        DFAState({None: 1, None: 1}, None),
        DFAState({None: 1, None: 1, None: 1}, None),
    ]
    dfa[0].addarc(dfa[1], None)
    dfa[2].addarc(dfa[3], None)
    dfa[3].addarc(dfa[2], None)
    pg = ParserGenerator()
    pg.simplify_dfa(dfa)
    assert len(dfa) == 1
    assert dfa[0].nfaset is not None
    assert dfa[0].nfaset == {None: 1, None: 1, None: 1}



# Generated at 2022-06-23 15:59:17.512735
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    import unittest

    class TestException(Exception):
        pass

    class UnitTest(unittest.TestCase):
        def helper(
            self, type: int, value: Optional[Any], iter: Iterator[TokenTuple]
        ) -> NoReturn:
            pg = ParserGenerator("<test>")
            pg.generator = iter
            pg.gettoken()
            if value is None:
                pg.expect(type)
            else:
                pg.expect(type, value)

        def assertRaises(self, type, value, iter) -> None:
            import traceback

            try:
                self.helper(type, value, iter)
            except TestException:
                return
            except:
                traceback.print_exc()
                raise
            raise Exception("fail")


# Generated at 2022-06-23 15:59:20.948349
# Unit test for constructor of class NFAState
def test_NFAState():
    n = NFAState()
    n.addarc(n, "a")
    n.addarc(n, "b")
    assert n.arcs == [(None, n), ("a", n), ("b", n)]



# Generated at 2022-06-23 15:59:25.644640
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    start = NFAState()
    finish = NFAState()
    start.addarc(finish, "a")
    pg = ParserGenerator([], start, finish)
    dfa = pg.make_dfa(start, finish)
    # print "DFA:"
    # for i, state in enumerate(dfa):
    #    print "%d:" % i, state.arcs


# Generated at 2022-06-23 15:59:37.723325
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    from test.support.script_helper import assert_python_ok, assert_python_failure
    from test.support import temp_dir, unlink
    from test.script_helper import assert_python, assert_python_failure, temp_dir
    import os
    import shutil

    def make_source(text: str) -> str:
        return "import %s; %s.ParserGenerator().dump_nfa('name', 'start', 'finish')" % (
            __name__,
            __name__,
        )

    with temp_dir() as tmpdir:
        tmpdir = os.path.realpath(tmpdir)
        tmpname = os.path.join(tmpdir, "test_parser.py")

# Generated at 2022-06-23 15:59:46.878511
# Unit test for constructor of class NFAState
def test_NFAState():
    nfa = NFAState()
    nfa.addarc(nfa)
    nfa.addarc(nfa, "b")
    nfa.addarc(nfa, None)
    nfa.addarc(nfa, 0)
    nfa.addarc(nfa, True)
    nfa.addarc(nfa, False)
    nfa.addarc(nfa, -2)
    nfa.addarc(nfa, -4.5)
    nfa.addarc(nfa, "--test--")

# Generated at 2022-06-23 15:59:49.566669
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    grammar = ParserGenerator()
    file = None
    g = grammar.convert(file)
    assert g is not None

# Generated at 2022-06-23 15:59:53.888084
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    pg = ParserGenerator()
    def t():
        yield (tokenize.NL, '\n', (0, 0), (0, 0), '')
    pg.generator = t()
    pg.gettoken()
    pg.expect(tokenize.NL, '\n')


# Generated at 2022-06-23 16:00:04.870077
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    rv = """
        Dump of DFA for 'a'
          State 0
          State 1 (final)
            'a' -> 1
    """
    pg = ParserGenerator()
    pg.states = [DFAState({NFAState(): 1}, NFAState()), DFAState({NFAState(): 1}, NFAState())]
    pg.labels = [('a', None)]
    s = io.StringIO()
    oldstdout = sys.stdout
    sys.stdout = s
    pg.dump_dfa('a', pg.states)
    sys.stdout = oldstdout
    assert s.getvalue() == rv


# Generated at 2022-06-23 16:00:16.160872
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    from _testcapi import raise_exception

    expected = SyntaxError("expected [], got NAME/'bar'",
                           ('test', 5, 1, "from __future__ import bar"))
    try:
        raise_exception(expected)
    except SyntaxError as raised:
        assert isinstance(raised, SyntaxError)
        assert expected.msg == raised.msg
        assert expected.filename == raised.filename
        assert expected.lineno == raised.lineno
        assert expected.offset == raised.offset
        assert expected.text == raised.text
        assert str(expected) == str(raised)
    else:
        assert False, "SyntaxError not raised"


# Generated at 2022-06-23 16:00:25.069020
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    import tokenize
    VG = ParserGenerator()
    VG.filename = "<string>"
    VG.line = '"<string>"'
    VG.type = -1
    VG.generator = iter([(tokenize.NAME, "hi", (1, 1), (1, 3), '"<string>"'),
                         (tokenize.NEWLINE, "\n", (2, 0), (2, 1), '"<string>"')])
    VG.gettoken()
    assert VG.type == token.NAME
    assert VG.value == "hi"


# Generated at 2022-06-23 16:00:26.675347
# Unit test for function generate_grammar
def test_generate_grammar():
    grammar = generate_grammar()
    assert grammar.start == "file_input"



# Generated at 2022-06-23 16:00:37.116658
# Unit test for function generate_grammar
def test_generate_grammar():
    from .. import python_grammar

    p = ParserGenerator("Grammar.txt")
    if hasattr(python_grammar, "python_grammar"):
        new_grammar = p.make_grammar()
        old_grammar = python_grammar.python_grammar
        assert new_grammar == old_grammar, (
            "Python and Parser/pgen2 grammars have drifted. "
            "Run Tools/parser/regrtest.py -ug and check in new "
            "Parser/python.gram."
        )
        print("OK")


if __name__ == "__main__":
    print(generate_grammar().grammar())

# Generated at 2022-06-23 16:00:46.165610
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    # Parse the grammar file and build the lexer and parser
    pgen = ParserGenerator()
    pgen.make_grammar(grammar.grammar)
    # Check the nfa
    assert len(pgen.dfas) == len(grammar.symbol2number)
    for name in grammar.number2symbol.values():
        dfa = pgen.dfas[name]
        assert len(dfa) == 1
        state = dfa[0]
        assert state.isfinal
        assert len(state.arcs) == 0
    # Check the first set of nfa
    assert len(pgen.first) == len(grammar.symbol2number)
    assert set(pgen.first.keys()) == set(grammar.number2symbol.values())

# Generated at 2022-06-23 16:00:55.127271
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    from . import grammar
    from .pgen2 import token
    from .pytoken import generate_tokens
    from .token import untokenize

    def test_case(testno: int, grammar: Text) -> None:
        g = ParserGenerator(grammar)
        g.make_pgen_grammar(g.get_grammar())
        c = g.make_grammar()
        g = c.make_grammar()
        g.check_all()

    def compare(testno: int, grammar: Text, new_grammar: Text) -> None:
        g = ParserGenerator(grammar)
        old_grammar = g.get_grammar()
        g = ParserGenerator(new_grammar)
        new_grammar = g.get_grammar()

# Generated at 2022-06-23 16:01:02.109817
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    gen = ParserGenerator()
    gen.filename = "name"
    gen.type = token.ENDMARKER
    gen.value = "value"
    gen.begin = (1, 2)
    gen.end = (3, 4)
    gen.line = "line"
    gen.expect(token.ENDMARKER, "value")
    gen.expect(token.OP, "value")

# Generated at 2022-06-23 16:01:09.135677
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    pg = ParserGenerator()
    pg.filename = "<string>"
    pg.lines = ["abc : b [c]"]
    pg.gettoken()
    a, z = pg.parse_rhs()
    assert isinstance(a, NFAState)
    assert isinstance(a.arcs[0], tuple)
    assert isinstance(a.arcs[0][0], str)
    assert isinstance(a.arcs[0][1], NFAState)
    assert isinstance(z, NFAState)


# Generated at 2022-06-23 16:01:10.646977
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    assert isinstance(PgenGrammar, type), "grammar.PgenGrammar must be a class"


# Generated at 2022-06-23 16:01:12.452388
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    """Unit test for constructor of class PgenGrammar"""
    PgenGrammar()
    # Output expected:
    # Nothing


# Generated at 2022-06-23 16:01:23.802159
# Unit test for method make_grammar of class ParserGenerator