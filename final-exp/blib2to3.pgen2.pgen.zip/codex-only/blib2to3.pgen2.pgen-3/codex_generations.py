

# Generated at 2022-06-23 15:51:27.747087
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    pg = ParserGenerator()
    a, z = pg.parse_alt()
    assert a is None and z is None
    pg.raise_error = lambda *args: None
    pg.value = "'a'"
    pg.type = token.STRING
    a, z = pg.parse_alt()
    assert a is not None and z is not None
    pg.value = "'b'"
    pg.type = token.STRING
    b, y = pg.parse_alt()
    assert z is y
    print(a.arcs)
    print(z.arcs)
    print(b.arcs)
    print(y.arcs)


# Generated at 2022-06-23 15:51:37.575082
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    # Test case for parse_rhs:
    pg = ParserGenerator()
    def test(input, expected):
        pg.setup("<string>", input)
        got = pg.parse_rhs()
        if got != tuple(expected):
            print("input =", repr(input))
            print("expected =", repr(expected))
            print("got =", repr(got))
        assert got == tuple(expected)
    test("a", [0, 1])
    test("a b", [0, 1, 1, 2])
    test("a | b", [0, 2, 0, 1, 1, 2])
    test("a b | c d", [0, 1, 1, 2, 0, 3, 0, 4, 1, 5])

# Generated at 2022-06-23 15:51:47.637399
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    s = "while 1:\n    pass"
    generator = tokenize.generate_tokens(io.StringIO(s).readline)
    pg = ParserGenerator()
    tup = next(generator)
    while tup[0] == tokenize.NL:
        tup = next(generator)
    pg.type, pg.value, pg.begin, pg.end, pg.line = tup
    assert pg.type == token.NAME
    pg.gettoken()
    assert pg.type == token.NUMBER
    pg.gettoken()
    assert pg.type == token.OP
    pg.gettoken()
    assert pg.type == token.NEWLINE
    pg.gettoken()
    assert pg.type == token.INDENT
    pg.gettoken()

# Generated at 2022-06-23 15:51:52.448775
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    P = ParserGenerator('grammar.txt')
    from . import parser
    assert P.dump_dfa(parser.dfas)



# Generated at 2022-06-23 15:51:54.582359
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    pg = ParserGenerator()
    pg.pgen()


# Create the grammar from the specification in a .py file.

# Generated at 2022-06-23 15:52:07.180445
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    from .tokens import PseudoToken as PT
    from .pgen_grammar import PgenGrammar as Grammar
    from .pytokenizer_test import tokenizer_tests
    from .pygram_test import grammar_tests
    from .codestmts import upper_stmts
    # Create sample grammar and parse input

# Generated at 2022-06-23 15:52:20.634734
# Unit test for function generate_grammar
def test_generate_grammar():
    grammar = generate_grammar()
    assert len(grammar._grammar) == 2
    keys = list(grammar._grammar.keys())
    keys.sort()
    assert keys == ['file_input', 'eval_input']
    rules = grammar._grammar['file_input']
    assert len(rules) == 7
    assert [l[0][0] for l in rules] == [0, 22, 22, 22, 22, 22, 22]
    rules = grammar._grammar['eval_input']
    assert len(rules) == 5
    assert [l[0][0] for l in rules] == [0, 22, 22, 22, 22]
    rules = grammar._grammar['atom']
    assert len(rules) == 10

# Generated at 2022-06-23 15:52:29.228424
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    p = ParserGenerator()

    # This is a minimal alphabet
    p.make_dfa(NFAState.parse("ab"), NFAState(isfinal=True))

    p.make_dfa(NFAState.parse("aa"), NFAState(isfinal=True))

    p.make_dfa(NFAState.parse("a1"), NFAState(isfinal=True))

    p.make_dfa(NFAState.parse("1a"), NFAState(isfinal=True))

    p.make_dfa(NFAState.parse("1"), NFAState(isfinal=True))

    p.make_dfa(NFAState.parse("1|1"), NFAState(isfinal=True))

    p.addfirstsets()


# Generated at 2022-06-23 15:52:32.319130
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    pg = ParserGenerator()
    assert pg.parse_rhs() == (pg.parse_alt(), pg.parse_alt())

# Generated at 2022-06-23 15:52:41.172093
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    global token, tokenize
    import token, tokenize
    source = """\
name
"string"
(a | b)
"""
    test_parser = ParserGenerator(source)
    type, value, begin, end, line = test_parser.gettoken()
    test_parser.parse_atom()
    type, value, begin, end, line = test_parser.gettoken()
    test_parser.parse_atom()
    type, value, begin, end, line = test_parser.gettoken()
    test_parser.parse_atom()


# Generated at 2022-06-23 15:52:46.882359
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    states: List[DFAState] = [DFAState({}, None)]
    states[0].addarc(states[0], "common")
    states.append(DFAState({}, None))
    states[1].addarc(states[0], "common")

    ParserGenerator.simplify_dfa(states)
    assert len(states) == 1
    assert len(states[0].arcs) == 1


# Generated at 2022-06-23 15:52:52.737773
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    # set up program text
    data = '("(" RHS ")") | NAME | STRING'
    program = Program("test", data)
    pg = ParserGenerator(program.program.split("\n"))
    # set up expected results
    expected = (NFAState(), NFAState())
    # call method to be tested
    actual = pg.parse_atom()
    # check results
    assert actual == expected

# Generated at 2022-06-23 15:53:05.816575
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    pg = ParserGenerator()
    pg.setup()
    def expect(spec: str, expected: Tuple["NFAState", "NFAState"]) -> None:
        start, finish = expected
        tokens = pg.tokenize(spec)
        generator = iter(tokens)
        pg.generator = generator
        pg.gettoken()
        a, z = pg.parse_item()
        assert (a, z) == expected
        assert pg.type == token.ENDMARKER, pg.type
    expect("a", (pg.nfair(1, "a"), pg.nfair(2)))
    expect("x+", (pg.nfair(1, "x"), pg.nfair(4)))
    expect("x+", (pg.nfair(1, "x"), pg.nfair(4)))
   

# Generated at 2022-06-23 15:53:13.877929
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    m = ParserGenerator().make_dfa
    a, b = m(NFAState(), NFAState())
    assert repr(a) == repr(b)
    assert repr(a) == "[<start>]"
    a, b = m(NFAState(), NFAState())
    a.addarc(b, "foo")
    assert repr(a) == "[<start>]"
    assert repr(b) == "[<final>]"
    a, b = m(NFAState(), NFAState())
    a.addarc(b, "foo")
    a.addarc(b, "bar")
    assert repr(a) == "[<start>]"
    assert repr(b) == "[<final>]"
    a, b = m(NFAState(), NFAState())

# Generated at 2022-06-23 15:53:23.590023
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    from test_parser import make_tokenizer
    from pgen2.parse import ParserGenerator
    p = ParserGenerator()
    tokenize = make_tokenizer()
    for (
        input,
        expected_label,
        expected_is_iterative,
        expected_type,
        expected_value,
    ) in [
        ("(", None, False, "("),
        ("[", None, False, "["),
        ("NAME", "NAME", False, None),
        ("\"NAME\"", "NAME", False, None),
        ("\"NAME\"+", "NAME", True, None),
        ("\"NAME\"*", "NAME", True, None),
    ]:
        lines = input.splitlines(keepends=True)
        p.setup()

# Generated at 2022-06-23 15:53:32.777138
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    p = ParserGenerator()
    c = p._PgenParserGenerator__make_converter()
    assert c.make_label(c, "fpdef") == 0
    assert c.make_label(c, "NAME") == 0
    assert c.make_label(c, "'+'") == 0
    assert c.make_label(c, '"if"') == 0
    assert c.make_label(c, '"\\n"') == 0


# Generated at 2022-06-23 15:53:38.695591
# Unit test for method addarc of class NFAState
def test_NFAState_addarc():
    a1 = NFAState()
    a2 = NFAState()
    a1.addarc(a2)
    assert a1.arcs == [(None, a2)]
    a1.addarc(a2, "a")
    assert a1.arcs == [(None, a2), ("a", a2)]



# Generated at 2022-06-23 15:53:43.347544
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    """Test for method dump_dfa of class ParserGenerator."""

    gen = ParserGenerator()
    start = NFAState()
    finish = NFAState()
    start.addarc(finish)
    dfa = gen.make_dfa(start, finish)
    gen.dump_dfa("test", dfa)

# Generated at 2022-06-23 15:53:48.458643
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():
    a: DFAState = DFAState({}, None)
    b: DFAState = DFAState({}, None)
    c: DFAState = DFAState({}, None)
    a.arcs = {"B": b, "C": c}
    c.arcs = {"A": a}
    c.unifystate(b, c)
    assert a.arcs == {"B": c, "C": c}
    assert c.arcs == {"A": a, "B": c}



# Generated at 2022-06-23 15:53:58.803693
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    pg = ParserGenerator()
    # The following is the content of the Parser/test_grammar
    # module, with a few unnecessary lines omitted

# Generated at 2022-06-23 15:54:07.268356
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():
    """Unit test for method unifystate of class DFAState."""

    state1 = DFAState({}, None)
    state2 = DFAState({}, None)
    state3 = DFAState({}, None)

    state1.arcs["foo"] = state2
    state1.arcs["bar"] = state3

    state4 = DFAState({}, None)
    state4.arcs["foo"] = state2
    state4.arcs["bar"] = state3

    state4.unifystate(state2, state1)
    assert state4.arcs["foo"] is state1

test_DFAState_unifystate()



# Generated at 2022-06-23 15:54:16.122260
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    pg = ParserGenerator()
    c = pg.make_converter(["test"], "test")
    assert c.labels == [(1, "a"), (2, "b"), (3, None)]
    assert c.dfas[1] == ([[(1, 1), (2, 1), (3, 1)], [(2, 2), (3, 1)]], {1: 1})
    assert c.dfas[2] == ([[(3, 2)]], {})
    assert c.dfas[3] == ([[(3, 3)]], {})
    assert c.start == 1
    assert c.symbol2number["test"] == 1
    assert c.symbol2number["test1"] == 2
    assert c.symbol2number["test2"] == 3
    assert c.symbol2label

# Generated at 2022-06-23 15:54:19.070949
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    pg = ParserGenerator(None)
    # Smoke test
    pg.raise_error("")


# Generated at 2022-06-23 15:54:28.232242
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():
    a = DFAState({}, None)
    b = DFAState({}, None)
    c = DFAState({}, None)
    a.addarc(b, "a")
    a.addarc(c, "b")
    d = DFAState({}, None)
    d.addarc(b, "a")
    d.addarc(c, "b")
    assert a != d
    a.unifystate(c, b)
    assert a == d


# Generated at 2022-06-23 15:54:39.491120
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    from .python import grammar as pgen_grammar
    from .python import token as pgen_token
    from .python import symbols as pgen_symbols

    # Make sure _is_gperf is defined
    assert pgen_grammar._is_gperf is True

    c = ParserGenerator().make_grammar(
        pgen_grammar, pgen_token, pgen_symbols, __file__, __name__
    )
    assert c.start == 256
    assert c.dfas == {}

    import _testcapi

    states = []
    for name in c.number2symbol:
        dfa, first = _testcapi.make_dfa(states, c.dfas[name])
        assert c.dfas[name] == (dfa, first)

# Generated at 2022-06-23 15:54:48.100387
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    pg = ParserGenerator("")
    pg.type = token.NAME
    pg.value = "abc"
    pg.expect(token.NAME)
    pg.type = token.NEWLINE
    with pytest.raises(SyntaxError) as excinfo:
        pg.expect(token.NAME)
    assert (
        str(excinfo.value)
        == "expected NAME, got 54/'NEWLINE' on line 1 column 1:\nNEWLINE"
    )
    pg.expect(token.NAME, "abc")
    with pytest.raises(SyntaxError) as excinfo:
        pg.expect(token.NAME, "abcde")

# Generated at 2022-06-23 15:54:52.803706
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    pg = ParserGenerator([])
    a = NFAState()
    z = NFAState()
    a.addarc(z, "a")
    a.addarc(z, "b")
    a.addarc(z, "c")
    dfa = pg.make_dfa(a, z)
    assert len(dfa) == 2, dfa



# Generated at 2022-06-23 15:55:05.985797
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    # Test case contributed by Anders Chrigstrom
    pg = ParserGenerator()
    dfa = [
        DFAState({1: 1}, False),
        DFAState({2: 1}, True),
        DFAState({3: 1}, True),
        DFAState({4: 1}, False),
        DFAState({5: 1}, True)
    ]
    dfa[0].addarc(dfa[1], "a")
    dfa[1].addarc(dfa[0], "b")
    dfa[0].addarc(dfa[3], "c")
    dfa[3].addarc(dfa[4], "d")
    dfa[4].addarc(dfa[0], "e")
    dfa[1].addarc(dfa[2], "d")
    d

# Generated at 2022-06-23 15:55:11.204878
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    """Unit test for constructor of class PgenGrammar"""

    pgen = PgenGrammar()
    assert isinstance(pgen, PgenGrammar)
    assert pgen.symbol2number == {}
    assert pgen.number2symbol == {}
    assert pgen.start is None


# Generated at 2022-06-23 15:55:20.382202
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    import io
    import unittest
    import unittest.mock

    class MockTokenizer:
        def __init__(self, tokens: Iterable[Token]) -> None:
            self.tokens = tokens
            self.tokens_iter = iter(tokens)

        def __iter__(self) -> "MockTokenizer":
            return self

        def __next__(self) -> Token:
            return next(self.tokens_iter)

    class MockToken:
        def __init__(self, type: int, string: str, start: Tuple[int, int]) -> None:
            self.type = type
            self.string = string
            self.start = start
            self.end = start


# Generated at 2022-06-23 15:55:23.379985
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    pg = ParserGenerator()
    pg.add("a", [("b", "*")])
    pg.add("b", [("b", "*"), ("a", "+")])

# Unit tests for class ParserGenerator and for class Parser

# Generated at 2022-06-23 15:55:34.599036
# Unit test for function generate_grammar
def test_generate_grammar():
    result = generate_grammar()
    assert_equal(result.start, "file_input")
    assert_equal(result.keywords["False"], 4)
    assert_equal(result.keywords["None"], 5)
    assert_equal(result.keywords["True"], 3)
    assert_equal(result.keywords["and"], 6)
    assert_equal(result.keywords["as"], 7)
    assert_equal(result.keywords["assert"], 8)
    assert_equal(result.keywords["break"], 9)
    assert_equal(result.keywords["class"], 10)
    assert_equal(result.keywords["continue"], 11)
    assert_equal(result.keywords["def"], 12)
    assert_equal(result.keywords["del"], 13)

# Generated at 2022-06-23 15:55:39.639829
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    p = ParserGenerator()
    p.filename = "testfile"
    p.generator = tokenize.generate_tokens(io.StringIO('[ "A" | "B" ]').__iter__)
    p.gettoken()
    return p.parse_item()

# Generated at 2022-06-23 15:55:50.226425
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    # Pickling for tests with PyPy3 requires that the callables can be
    # imported.  Weird, but we can live with that.
    """
    from .grammar import ParserGenerator
    from .nfa import NFAState, DFAState
    """

    pg = ParserGenerator()
    pg.generator = tokenize.generate_tokens(pg.gettokens("a"))
    pg.gettoken()
    a, z = pg.parse_item()
    assert isinstance(a, NFAState)
    assert isinstance(z, NFAState)
    assert a.arcs == [(("a",), z)]
    assert z.arcs == []
    assert a.arcs == [(("a",), z)]


# Generated at 2022-06-23 15:55:58.863007
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    pgen = ParserGenerator("")
    # For method make_first, the most complex case is to handle a token
    # with multiple possible values
    pgen.first = {"NAME": {"NAME": 1, "ELLIPSIS": 1}}
    c = pgen.convert()
    assert c.labels == [(token.NAME, "NAME"), (token.NAME, "ELLIPSIS")]
    assert c.tokens == {token.NAME: 0, token.ELLIPSIS: 1}
    assert c.keywords == {}
    assert c.dfas == {}



# Generated at 2022-06-23 15:56:05.416247
# Unit test for constructor of class DFAState
def test_DFAState():
    nfa0 = NFAState()
    nfa1 = NFAState()
    dfa0 = DFAState({nfa0: 1}, nfa0)
    dfa1 = DFAState({nfa1: 1}, nfa1)
    dfa2 = DFAState({nfa0: 1}, nfa0)
    assert dfa0 == dfa2
    assert dfa0 != dfa1
    assert dfa0 != 42
    assert dfa0 != None



# Generated at 2022-06-23 15:56:08.517179
# Unit test for method addarc of class DFAState
def test_DFAState_addarc():
    a = DFAState({}, NFAState())
    b = DFAState({}, NFAState())
    a.addarc(b, 42)
    assert a.arcs == {42: b}, a.arcs


# Generated at 2022-06-23 15:56:16.988047
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():

    import pgen2_grammar
    import pgen2_converter
    import pgen2_pgen
    import pgen2_parse

    basename = os.path.join(os.path.dirname(__file__), "Grammar.txt")
    basename = os.path.abspath(basename)
    f = open(basename)
    c = pgen2_converter.Converter()
    c.convert(f, "Grammar.txt")
    f.close()
    p = pgen2_pgen.Pgen(c.grammar)
    p.save(basename + "c")
    import pgen_Grammar_txtc
    p = pgen_Grammar_txtc.driver

# Generated at 2022-06-23 15:56:27.727623
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    def test_check(msg, *args):
        try:
            raise SyntaxError
        except SyntaxError as e:
            assert e.msg == " ".join([msg] + list(map(str, args)))
            assert e.filename == 'file'
            assert e.lineno == 2
            assert e.offset == 3
            assert e.text == 'line'

    g = ParserGenerator()
    g.filename = 'file'
    g.end = (2,3)
    g.line = 'line'
    yield test_check, "msg 1 2 3", 1, 2, 3
    yield test_check, "msg 1 2", 1, 2
    yield test_check, "msg 1", 1
    yield test_check, "msg %d %s", 1, "a"


# Generated at 2022-06-23 15:56:30.496344
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    pg = ParserGenerator()
    grammar_text = """
    start: "a"
    """
    pg.create_grammar(grammar_text)
    pg.create_pgen_grammar()

# Generated at 2022-06-23 15:56:39.616644
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    n0, n1, n2, n3, n4, n5 = [NFAState() for i in range(6)]
    n0.addarc(n1, "a")
    n0.addarc(n3, "b")
    n1.addarc(n2)
    n2.addarc(n1)
    n3.addarc(n4, "c")
    n4.addarc(n5)
    n5.addarc(n3)
    dfa = make_ParserGenerator().make_dfa(n0, n1)

# Generated at 2022-06-23 15:56:43.467852
# Unit test for constructor of class DFAState
def test_DFAState():
    dict(DFAState({1: 2}, 5))
    dict(DFAState({NFAState(): 2}, 5))
    dict(DFAState({NFAState(): 2}, NFAState()))


# Generated at 2022-06-23 15:56:54.284710
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    pg = ParserGenerator()
    pg.gettoken = unittest.mock.Mock()

    def side_effect():
        pg.value = '('
        pg.type = token.OP
        return 3, 4

    pg.gettoken.side_effect = side_effect
    pg.parse_rhs = unittest.mock.Mock()
    pg.parse_rhs.return_value = mock.sentinel.a, mock.sentinel.z
    pg.parse_atom = unittest.mock.Mock()
    pg.parse_atom.return_value = mock.sentinel.x, mock.sentinel.y

    # Call the method under test
    retval = pg.parse_item()

    # Ensure that the method under test returned correctly

# Generated at 2022-06-23 15:57:02.036185
# Unit test for constructor of class DFAState
def test_DFAState():
    dfa = [
        DFAState({0: 1, 1: 1}, 1),
        DFAState({2: 1, 3: 1}, 3),
    ]
    assert dfa[0].nfaset == {0: 1, 1: 1}
    assert dfa[0].isfinal
    assert dfa[1].nfaset == {2: 1, 3: 1}
    assert not dfa[1].isfinal
    dfa[0].addarc(dfa[1], "x")
    dfa[0].addarc(dfa[1], "y")
    assert dfa[0].arcs == {"x": dfa[1], "y": dfa[1]}
    assert dfa[1].arcs == {}


# Generated at 2022-06-23 15:57:07.787761
# Unit test for method addarc of class DFAState
def test_DFAState_addarc():
    s = DFAState({}, None)
    t = DFAState({}, None)
    s.addarc(t, 'foo')
    assert s.arcs == {'foo': t}
    raises(ValueError, s.addarc, t, 'foo')


# Generated at 2022-06-23 15:57:16.100899
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    def assertRaisesMsg(exception, msg):

        def f(x, y):
            raise exception(msg)

        with pytest.raises(exception) as excinfo:
            f(1, 2)
            assert excinfo.value.args[0] == msg

    pg = ParserGenerator()
    pg.type = pg.value = 0
    pg.begin = pg.end = (0, 0)
    pg.line = ''
    # test valid type and value pairs
    pg.expect(0, 0)
    pg.expect(1, '')
    pg.expect(token.NAME, 'a')
    pg.expect(token.STRING, 'a')
    pg.expect(token.OP, 'a')
    pg.expect(token.ENDMARKER, 'a')

# Generated at 2022-06-23 15:57:27.904216
# Unit test for constructor of class DFAState
def test_DFAState():
    one = NFAState()
    two = NFAState()
    three = NFAState()
    four = NFAState()
    five = NFAState()

    st = DFAState({one: 1, two: 1, three: 1}, four)
    assert st.nfaset == {one: 1, two: 1, three: 1}
    assert st.isfinal
    assert st.arcs == {}

    other = DFAState({one: 1, two: 1, three: 1}, five)
    assert other.nfaset == {one: 1, two: 1, three: 1}
    assert not other.isfinal

    assert st != other

    st.addarc(st, 'a')
    st.addarc(other, 'b')
    st.addarc(st, 'c')

# Generated at 2022-06-23 15:57:36.545411
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    dfa = [
        DFAState({0: 1}, True),
        DFAState({1: 1}, True),
        DFAState({2: 1}, True),
        DFAState({3: 1}, True),
        DFAState({4: 1, 5: 1}, True),
        DFAState({5: 1}, True),
    ]
    dfa[0].addarc(dfa[0], "#")
    dfa[0].addarc(dfa[1], "a")
    dfa[1].addarc(dfa[1], "%")
    dfa[1].addarc(dfa[2], "a")
    dfa[2].addarc(dfa[2], "a")
    dfa[2].addarc(dfa[3], "b")
    dfa[3].addarc

# Generated at 2022-06-23 15:57:46.168753
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():
    a = DFAState({}, None)
    b = DFAState({}, None)
    c = DFAState({}, None)
    a.addarc(b, "label1")
    a.addarc(c, "label2")
    a.addarc(b, "label3")
    assert list(a.arcs.items()) == [("label1", b), ("label2", c), ("label3", b)]
    b.unifystate(b, c)
    assert list(a.arcs.items()) == [("label1", c), ("label2", c), ("label3", c)]
    c.unifystate(b, a)
    assert list(a.arcs.items()) == [("label1", c), ("label2", c), ("label3", c)]

# Generated at 2022-06-23 15:57:55.361383
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    import py
    import sys
    import io
    f = io.StringIO()
    try:
        sys.stderr = f
        pg = ParserGenerator(_tokenize)
        pg.raise_error("hello: %s", "world")
    finally:
        sys.stderr = sys.__stderr__
    assert py.builtin._totext(f.getvalue(), "utf-8") == "hello: world\n"


# Generated at 2022-06-23 15:58:00.497699
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    pg = ParserGenerator([])
    pg.type = token.NAME
    pg.value = "value1"
    pg.gettoken = lambda : None
    assert pg.expect(token.NAME, "value1") == "value1"

# Generated at 2022-06-23 15:58:08.553787
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    pg = ParserGenerator(StringIO(''))
    try:
        # The method should raise SyntaxError with the message
        # "expected token/value, got token/value"
        pg.expect(token.NAME, 'None')
        assert False
    except SyntaxError as e:
        assert e.args[0] == "expected NAME/None, got ENDMARKER/None"
    try:
        # The method should raise SyntaxError with the message
        # "expected token, got token/value"
        pg.expect(token.NAME)
        assert False
    except SyntaxError as e:
        assert e.args[0] == "expected NAME, got ENDMARKER/None"


# Generated at 2022-06-23 15:58:18.261909
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    sg = ParserGenerator()

    def nfa(
        arcs: List[Tuple[Optional[Text], "NFAState"]]
    ) -> Tuple["NFAState", "NFAState"]:
        a = b = NFAState()
        for label, next in arcs:
            b.addarc(label, next)
            b = next
        return a, b

    ab_dfa = sg.make_dfa(*nfa([(None, NFAState()), ("a", NFAState()), ("b", NFAState())]))
    assert len(ab_dfa) == 3
    assert ab_dfa[0].arcs == {"a": ab_dfa[1], "b": ab_dfa[2]}
    assert ab_dfa[1].arcs == {}
    assert ab_

# Generated at 2022-06-23 15:58:28.772416
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    def check_dfa(pgen, dfas_name, start, finish, check_dfa_state):
        dfas = pgen.make_dfa(start, finish)
        assert len(dfas) == 1
        dfa = dfas[0]
        assert dfa.isfinal
        assert len(dfa.arcs) == 0
        check_dfa_state(dfa.nfaset)

    def check_dfa_state(nfa_set):
        assert len(nfa_set) == 1
        nfa = next(iter(nfa_set))
        assert len(nfa.arcs) == 1
        assert nfa.arcs[0] == (None, nfa)

    a = NFAState()
    z = NFAState()
    a.addarc(z)


# Generated at 2022-06-23 15:58:39.307289
# Unit test for method simplify_dfa of class ParserGenerator

# Generated at 2022-06-23 15:58:44.187700
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    p = ParserGenerator()
    assert p.filename is None
    assert p.type is None
    assert p.value is None
    assert p.begin == (0, 0)
    assert p.end == (0, 0)
    assert p.line == ""


# Generated at 2022-06-23 15:58:55.004173
# Unit test for method __eq__ of class DFAState
def test_DFAState___eq__():
    a, b, c = DFAState({}, 0), DFAState({}, 0), DFAState({}, 0)
    a.arcs = {1: b, 2: c}
    assert a != b
    b.arcs = {1: b, 2: c}
    assert a == b
    assert hash(a) == hash(b)
    assert hash(a) != hash(c)
    b.arcs = {1: b}
    assert a != b
    b.arcs = {3: b}
    assert a != b
    b.arcs = {1: c}
    assert a != b

# Generated at 2022-06-23 15:59:05.752756
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    import unittest
    from collections import namedtuple

    Token = namedtuple("Token", ["type", "string", "start", "end", "line"])

    class Tests(unittest.TestCase):
        def setUp(self):
            self.pg = ParserGenerator()

        def p_alt(self, t):
            return self.pg.parse_alt()

        def test_no_rules(self):
            self.assertRaises(
                SyntaxError, self.p_alt, [Token(tokenize.ENDMARKER, "", (0, 0), (0, 0), "")]
            )


# Generated at 2022-06-23 15:59:12.119802
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    s = "a"
    expected = (
        NFAState(arcs=[(None, NFAState(arcs=[("a", NFAState())]))]),
        NFAState(arcs=[(None, NFAState()), ("a", NFAState())]),
    )
    pg = ParserGenerator()
    pg.gettoken()
    actual = pg.parse_atom()
    assert actual == expected, "%r != %r" % (actual, expected)

# Generated at 2022-06-23 15:59:22.443852
# Unit test for constructor of class DFAState

# Generated at 2022-06-23 15:59:29.257512
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    from .pgen2 import token
    from .pgen2 import grammar
    g = ParserGenerator(token, grammar)
    c = g.convert()
    assert c.make_first(c, "xor_expr") == {
        token.VBAR: 1,
        token.CIRCUMFLEX: 1,
        token.AMPER: 1,
        token.LEFTSHIFT: 1,
        token.RIGHTSHIFT: 1,
        token.PLUS: 1,
        token.MINUS: 1,
        token.STAR: 1,
        token.SLASH: 1,
        token.PERCENT: 1,
        token.DOUBLESLASH: 1,
        token.NAME: 1,
        token.NUMBER: 1,
        token.STRING: 1,
    }


# Generated at 2022-06-23 15:59:41.393252
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    import doctest
    import tokenize
    import types

    parser_generator = ParserGenerator()
    parser_generator.filename = "filename"
    parser_generator.end = (0, 0)
    parser_generator.line = "line"

    def checksyntaxerror(msg: str, *args: Any) -> NoReturn:
        try:
            parser_generator.raise_error(msg, *args)
        except SyntaxError as e:
            assert e.args == (
                "expected %s/%s, got %s/%s",
                tokenize.STRING,
                "|",
                tokenize.NAME,
                "foo",
            ), e.args
        else:
            raise AssertionError("No SyntaxError raised")


# Generated at 2022-06-23 15:59:53.888966
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    # Test empty grammar
    for grammar in [
        {},
        {"foo": []},  # Empty rule
        {"foo": [("bar", 0)]},  # Empty rule with precedence
        {"foo": [], "bar": [("levelbar", 0)]},  # Empty rule with precedence
    ]:
        pg = ParserGenerator(grammar)
        try:
            pg.make_grammar()
        except ValueError:
            print(
                "Exception raised when converting empty grammar to Parser/Driver"
            )
        else:
            pass

    # Test grammar with a single rule
    pg = ParserGenerator({"stmt": [("small_stmt", 0)]})

# Generated at 2022-06-23 16:00:03.822837
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():
    s = DFAState({}, None)
    t = DFAState({}, None)
    s.addarc(t, "a")
    s.addarc(t, "b")
    t.addarc(s, "c")
    assert s.arcs == {'b': t, 'a': t}
    assert t.arcs == {'c': s}
    s.unifystate(t, s)
    assert s.arcs == {'b': s, 'a': s, 'c': s}
    assert t.arcs == {'c': s}

# Generated at 2022-06-23 16:00:16.812352
# Unit test for method calcfirst of class ParserGenerator

# Generated at 2022-06-23 16:00:27.563150
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    import ParserGenerator
    pg = ParserGenerator.ParserGenerator()
    pg.dfas = {}
    pg.first = {}
    pg.dfas["bob"] = [ ParserGenerator.DFAState({}, None), ParserGenerator.DFAState({}, None) ]
    pg.dfas["sue"] = [ ParserGenerator.DFAState({}, None), ParserGenerator.DFAState({}, None) ]
    pg.dfas["bob"][0].arcs = { "sue" : pg.dfas["bob"][1] }
    pg.dfas["sue"][0].arcs = { "a" : pg.dfas["sue"][1], "b" : pg.dfas["sue"][1] }

# Generated at 2022-06-23 16:00:34.285171
# Unit test for function generate_grammar
def test_generate_grammar():
    grammar = generate_grammar()
    # Test that some keys and values are present
    assert grammar.symbol2number["classdef"] == 8
    assert grammar.symbol2label[1] == "and_expr"
    assert grammar.keywords["True"] == 69
    assert grammar.states[1][2][4] == 3
    assert grammar.tokens == grammar.keywords


if __name__ == "__main__":
    # If run as a script, generate the grammar file
    with open(Path("Grammar.txt"), "w") as fp:
        print(GRAMMAR_FILE % {"version": sys.version[:3]}, file=fp)
    generate_grammar()

# Generated at 2022-06-23 16:00:36.083607
# Unit test for constructor of class NFAState
def test_NFAState():
    nfa_state_instance = NFAState()
    assert nfa_state_instance.arcs == []
    nfa_state_instance.addarc(nfa_state_instance, "self")
    assert nfa_state_instance.arcs == [("self", nfa_state_instance)]



# Generated at 2022-06-23 16:00:48.335960
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    pg = ParserGenerator()
    pg.filename = "test_file"
    pg.line = "the line we are testing"
    pg.generator = iter([(token.OP, "+", (0, 0), (0, 1), "the line we are testing")])
    pg.gettoken()
    assert pg.type == token.OP
    assert pg.value == "+"
    assert pg.begin == (0, 0)
    assert pg.end == (0, 1)
    assert pg.line == "the line we are testing"

    pg.generator = iter(
        [
            (token.NL, "\n", (0, 1), (0, 2), "the line we are testing"),
            (token.OP, "+", (1, 0), (1, 1), "next line"),
        ]
    )


# Generated at 2022-06-23 16:00:54.733599
# Unit test for method __eq__ of class DFAState
def test_DFAState___eq__():
    # The first state
    a = DFAState({}, NFAState())
    z = DFAState({}, NFAState())
    a.addarc(z, 'a')
    a.isfinal = True
    # The second state
    b = DFAState({}, NFAState())
    b.addarc(z, 'b')
    b.isfinal = False
    # The third state
    c = DFAState({}, NFAState())
    c.addarc(z, 'c')
    c.isfinal = True
    assert a != b
    assert a == c
    # A cycle
    a.addarc(a, 'd')
    assert a == a


# Generated at 2022-06-23 16:01:06.868563
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    pg = ParserGenerator(StringIO('''
        a: 'a'
        b: 'b'
        c: 'c'
        d: 'd'
        e: 'e'
    '''))
    pg.make()
    assert pg.startsymbol == 'a'
    assert list(pg.dfas.keys()) == ['a', 'b', 'c', 'd', 'e']
    for i in range(5):
        for j in range(5):
            assert len(pg.dfas[chr(ord('a') + i)][j].arcs) == 1
    assert pg.symbol2number['a'] == 0
    assert pg.symbol2number['b'] == 1
    assert pg.symbol2number['c'] == 2
    assert pg.symbol2number['d']

# Generated at 2022-06-23 16:01:19.300720
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    pg = ParserGenerator()
    a = NFAState()
    b = NFAState()
    c = NFAState()
    d = NFAState()
    z = NFAState()
    a.addarc(b, "a")
    b.addarc(c, "b")
    c.addarc(d, "c")
    c.addarc(c, None)
    d.addarc(z, None)
    # pg.dump_nfa("test", a, z)
    dfa = pg.make_dfa(a, z)
    # pg.dump_dfa("test", dfa)