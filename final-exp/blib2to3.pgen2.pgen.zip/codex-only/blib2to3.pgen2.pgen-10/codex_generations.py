

# Generated at 2022-06-23 15:51:22.220770
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    parser = ParserGenerator()
    parser.addtoken("a")
    parser.addtoken("b")
    parser.addtoken("c")
    parser.addtoken("d")
    parser.addtoken("e")
    parser.addtoken("f")
    parser.addtoken("g")
    parser.addtoken("h")
    parser.addtoken("i")
    parser.addtoken("j")
    parser.addtoken("k")
    parser.addtoken("l")
    parser.addtoken("m")
    parser.addtoken("n")
    def mkstate(name):
        state = DFAState({name: 1}, None)
        state.nfaset = {name: 1}
        return state
    parser.start = mkstate("s0")
    s0 = parser.start

# Generated at 2022-06-23 15:51:30.964914
# Unit test for function generate_grammar
def test_generate_grammar():
    grammar = generate_grammar()
    assert grammar.keywords["False"] == 3
    assert grammar.keywords["None"] == 4
    assert grammar.keywords["True"] == 5
    assert grammar.tokens[grammar.opmap["("]] == 6
    assert grammar.labels[grammar.tokens[grammar.opmap["("]]] == (40, "(")
    assert grammar.labels[grammar.tokens[grammar.opmap[")"]]] == (41, ")")
    assert grammar.labels[grammar.tokens[grammar.opmap["*"]]] == (42, "*")
    assert grammar.labels[grammar.tokens[grammar.opmap["+"]]] == (43, "+")

# Generated at 2022-06-23 15:51:39.603076
# Unit test for method __eq__ of class DFAState
def test_DFAState___eq__():
    class Dummy:
        x = 5
    dfa_states = []
    for i in range(6):
        dummy = Dummy()
        dfa = DFAState({"x": "y", i: dummy}, dummy)
        dfa_states.append(dfa)
    for i in range(6):
        for j in range(i + 1, 6):
            eq_i_j = (i == j)
            ret_value = dfa_states[i].__eq__(dfa_states[j])
            assert ret_value == eq_i_j, "The return value was not as expected"
    # In Py3 version of Python, the method __eq__ is not implemented, and
    # returns None. The __eq__ method should then return NotImplemented:

# Generated at 2022-06-23 15:51:41.754798
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    pg = ParserGenerator('', '')
    pg.gettoken()
    # assert {key: value} == {key: value}

# Generated at 2022-06-23 15:51:43.887397
# Unit test for constructor of class NFAState
def test_NFAState():
    s = NFAState()
    assert s.arcs == []


# Generated at 2022-06-23 15:51:46.390363
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    try:
        PgenGrammar()
    except Exception:
        # Fail the test
        assert False

    # Pass the test
    assert True


# Generated at 2022-06-23 15:51:54.146412
# Unit test for method addarc of class NFAState
def test_NFAState_addarc():
    # Very simple test for the method addarc of class NFAState
    S1 = NFAState()
    S2 = NFAState()
    assert S1.arcs == []
    S1.addarc(S2, label="abc")
    assert S1.arcs == [("abc", S2)]



# Generated at 2022-06-23 15:51:59.673518
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    import io

    f = io.StringIO()
    parser = ParserGenerator()
    parser.dump_dfa("test", [DFAState({}, {})])
    assert f.getvalue() == "Dump of DFA for test\n  State 0 \n"
    f = io.StringIO()
    parser = ParserGenerator()
    parser.dump_dfa("test", [DFAState({}, {}, True)])
    assert f.getvalue() == "Dump of DFA for test\n  State 0 (final)\n"
    f = io.StringIO()
    parser = ParserGenerator()
    parser.dump_dfa("test", [DFAState({}, {"label": 1})])

# Generated at 2022-06-23 15:52:11.299047
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    pg = ParserGenerator()

# Generated at 2022-06-23 15:52:21.730929
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    pg = ParserGenerator()
    pg.dfas = {
        "x": [DFAState({}, 0), DFAState({}, 0)],
        "y": [DFAState({}, 0), DFAState({}, 0)],
        "z": [DFAState({}, 0), DFAState({}, 0)],
    }
    pg.dfas["x"][0].addarc(pg.dfas["x"][1], "x")
    pg.dfas["y"][0].addarc(pg.dfas["y"][1], "y")
    pg.dfas["z"][0].addarc(pg.dfas["z"][1], "z")
    pg.dfas["x"][1].addarc(pg.dfas["x"][1], "x")
    pg.df

# Generated at 2022-06-23 15:52:24.939299
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    try:
        raise SyntaxError("this is an error with %s %d %f", "some", 42, 3.14159)
    except SyntaxError as exc:
        print(exc.args)




# Generated at 2022-06-23 15:52:31.486561
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    def test(pg, tok, val, typ, expval):
        pg.type = tok
        pg.value = val
        pg.expect(typ, expval)

    pg = ParserGenerator(b"<file>", tokenize.tokenize(b"42\n"), None)
    pg.gettoken()  # Start things off
    test(pg, token.NUMBER, "42", token.NUMBER, None)

# Generated at 2022-06-23 15:52:42.971335
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    from _ast import TryExcept, TryFinally
    pg = ParserGenerator()
    pg.startsymbol = "root"

# Generated at 2022-06-23 15:52:46.654583
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():
    s0 = DFAState({}, None)
    s1 = DFAState({}, None)
    s2 = DFAState({}, None)
    s0.addarc(s0, "a")
    s0.addarc(s1, "b")
    s0.addarc(s2, "c")
    s0.unifystate(s1, s2)
    assert s0.arcs["a"] is s0
    assert s0.arcs["b"] is s2
    assert s0.arcs["c"] is s2

# Generated at 2022-06-23 15:52:55.825698
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    class DummyParserGenerator(ParserGenerator):
        def __init__(self) -> None:
            self.dfas = {} # type: Dict[str, List[DFAState]]

    parser = DummyParserGenerator()
    # Start building an NFA for power
        # power: atom ('**' factor)*
    a = NFAState()
    z = NFAState()
    b = NFAState()
    a.addarc(b)
    b.addarc(z, "|")
    c = NFAState()
    z.addarc(c)
    d = NFAState()
    d.addarc(z, "|")
    c.addarc(d, "|")
    parser.dump_nfa("power", a, z)


# Generated at 2022-06-23 15:53:07.191951
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    from typing import List, Tuple, Union
    from _ast import mod as Mod
    import grammar
    import token

    _sym2tok = dict(
        [
            (k, v)
            for k, v in sorted(grammar.sym_name.items())
            if isinstance(v, int)
        ]
    )
    _tok2sym = dict([(v, k) for k, v in _sym2tok.items()])

    def sym(tok: int) -> str:
        return _tok2sym[tok]


# Generated at 2022-06-23 15:53:16.890597
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    # Using a tiny part of Python grammar
    g = Grammar()
    g.add_rule("expr_stmt", "testlist_star_expr", "augassign", "yield_expr", "testlist")
    g.add_rule("testlist_star_expr", "testlist", "star_expr")
    g.add_rule("testlist", "test", "list_for")
    g.add_rule("test", "or_test", "lambdef")
    p = g.parser()
    assert p.gettoken() == token.NAME
    assert p.value == "expr_stmt"
    assert (p.begin, p.end) == (0, 5)

# Generated at 2022-06-23 15:53:23.725598
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    pg = ParserGenerator()
    pg.dfas = {
        "x": [DFAState({}, None)],
        "y": [DFAState({}, None)],
        "a": [DFAState({}, None)],
        "b": [DFAState({}, None)],
        "c": [DFAState({}, None)],
        "d": [DFAState({}, None)],
        "e": [DFAState({}, None)],
        "f": [DFAState({}, None)],
    }
    pg.addfirstsets()
    assert pg.first["x"] == {"a": 1, "b": 1, "c": 1, "d": 1}
    assert pg.first["y"] == {"e": 1, "f": 1}



# Generated at 2022-06-23 15:53:33.199470
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():
    class fakeDFAState:
        def __init__(self, label) -> None:
            self.arcs = {label: 1}
        def __eq__(self, other) -> bool:
            return self.arcs == other.arcs
    state1=DFAState(None, None)
    state2=DFAState(None, None)
    state1.unifystate(fakeDFAState(0), fakeDFAState(1))
    assert state1.arcs == {0: 1}



# Generated at 2022-06-23 15:53:44.229283
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    p = ParserGenerator()

    class DFAState:
        def __init__(self, nfaset, isfinal):
            self.nfaset = nfaset
            self.isfinal = isfinal
            self.arcs = {}

        def unifystate(self, old, new):
            for label, next in self.arcs.items():
                if next is old:
                    next = new

        def addarc(self, target, label=None):
            self.arcs[label] = target

        def __eq__(self, other):
            return self.nfaset == other.nfaset and self.arcs == other.arcs

        def __repr__(self):
            return "<DFAState %r %r>" % (self.nfaset, self.arcs)

# Generated at 2022-06-23 15:53:47.999787
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    # Zero tests so far
    print("Tests for method parse_item of class ParserGenerator:")
    p = ParserGenerator(None)
    assert p.parse_item() == NotImplemented

# Generated at 2022-06-23 15:53:58.512996
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    from . import grammar
    from .pgen import ParserGenerator
    from .tokenize import generate_tokens, untokenize, INDENT
    from io import StringIO
    from textwrap import dedent

    def test(source):
        f = StringIO(source)
        toks = list(generate_tokens(f.readline))
        for i in range(len(toks) - 2, -1, -1):
            if toks[i][0] == tokenize.OP and toks[i][1] == "::=" and toks[i + 1][
                0
            ] == tokenize.NAME:
                toks[i] = (tokenize.OP, "\n:")
        source = untokenize(toks).rstrip()
        source = dedent(source) + "\n"


# Generated at 2022-06-23 15:54:08.262262
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():

    pgen = ParserGenerator()

    filename = "pgen.txt"

# Generated at 2022-06-23 15:54:17.057702
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    lines = '''
123*
456+
#abc
'''.strip().split("\n")
    tokens = tokenize.generate_tokens(lambda: lines)
    gen = ParserGenerator(tokens, "<test>")
    gen.gettoken()
    while gen.type != token.ENDMARKER:
        a, z = gen.parse_alt()
        print("Name: ", a.name)
        print("Ic: ", a.ic)
        print("Done: ", a.done)
        print("Arcs: ", a.arcs)
        print("Name: ", z.name)
        print("Ic: ", z.ic)
        print("Done: ", z.done)
        print("Arcs: ", z.arcs)
        print()

# Generated at 2022-06-23 15:54:23.541851
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    g = ParserGenerator("Test", "test", [])
    g.token("foo", "foo")
    g.token("bar", "bar")
    g.rule("test", ["[", "test", "|", "foo", "]"])
    g.rule("test", ["[", "test", "|", "bar", "]"])



# Generated at 2022-06-23 15:54:35.024944
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    class DFAState:
        def __init__(self, nfaset, final) -> None:
            self.nfaset = nfaset
            self.isfinal = final
        def __hash__(self) -> int:
            return hash(tuple(sorted(self.nfaset)))
        def __eq__(self, other: object) -> bool:
            if not isinstance(other, DFAState):
                return NotImplemented
            return self.nfaset == other.nfaset
        def unifystate(self, old: "DFAState", new: "DFAState") -> None:
            assert self.nfaset == old.nfaset
            self.nfaset = new.nfaset
            self.isfinal = new.isfinal

    d

# Generated at 2022-06-23 15:54:36.547174
# Unit test for constructor of class NFAState
def test_NFAState():
    state = NFAState()
    assert state.arcs == []



# Generated at 2022-06-23 15:54:39.210643
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    pg = ParserGenerator() # Default constructor


# Generated at 2022-06-23 15:54:46.943582
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    pg = ParserGenerator()
    a = NFAState()
    z = NFAState()
    a.addarc(z, "x")
    assert pg.make_dfa(a, z) == [DFAState({a: 1, z: 1}, z, False, {"x": [z]})], pg.make_dfa(a, z)
    a.addarc(z, "y")
    assert pg.make_dfa(a, z) == [DFAState({a: 1, z: 1}, z, False, {"x": [z], "y": [z]})], pg.make_dfa(a, z)



# Generated at 2022-06-23 15:54:59.233034
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    init_grammar()
    pg = ParserGenerator(grammar)
    pg.addfirstsets()
    dfas = pg.dfas
    pg.dump_nfa("stmt", *dfas["stmt"][0].nfa_start_final())

# Generated at 2022-06-23 15:55:08.793873
# Unit test for method addarc of class DFAState
def test_DFAState_addarc():
    def check(label: str, s: str, t: str):
        a = DFAState({}, None)
        a.arcs = {label: s}
        a.addarc(t, label)
        assert a.arcs == {label: t}

    check('a', 's', 't')
    check('a', 's', 'u')
    check('a', 's', 'v')
    check('b', 's', 'u')
    check('b', 's', 'v')
    check('b', 's', 't')



# Generated at 2022-06-23 15:55:18.355438
# Unit test for method __eq__ of class DFAState
def test_DFAState___eq__():
    A = DFAState({}, NFAState())
    B = DFAState({}, NFAState())
    C = DFAState({}, NFAState())
    A.addarc(C, "a")
    B.addarc(C, "a")
    assert A == B
    B.addarc(C, "b")
    assert A != B
    A.addarc(C, "b")
    assert B == A


# A DFA is represented as a list of DFAState instances, and the
# starting state is always dfa[0].
#
# Each DFAState holds a set of NFAStates (the NFA states that
# correspond to this DFA state), and a dictionary mapping input
# symbols to DFAStates.

# The first phase of the parser builds an NFA for each rule.  This
# is

# Generated at 2022-06-23 15:55:20.395833
# Unit test for constructor of class NFAState
def test_NFAState():
    s = NFAState()
    s.addarc(s)
    assert s.arcs == [(None, s)], s.arcs



# Generated at 2022-06-23 15:55:29.472854
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    filename = "fixtures/parser/test_grammars/all_grammars.txt"
    # not in grammar:
    # skip_grammars = ['py3_grammar', 'pypy_grammar', 'pypy_parse']
    # grammar is too big:
    skip_grammars = ["grammar"]
    grammar_name = "grammar"
    with open(filename, encoding="utf-8") as f:
        p = ParserGenerator()
        p.parse_file(f, grammar_name)
        for name in [
            "python_grammar",
            "python_grammar_with_print",
            "python_grammar_no_print_statement",
        ]:
            if name in skip_grammars:
                continue
            dfa = p.make_dfa

# Generated at 2022-06-23 15:55:41.802858
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    import io
    import tokenize

    def untokenize(tokens: List[tokenize.TokenInfo]) -> str:
        # Roughly the inverse of tokenize.generate_tokens()
        line = []  # type: List[str]
        last_row = 0
        last_col = 0
        for t in tokens:
            # print(t)
            if last_row + last_col > 0:
                row_offset = t.start[0] - last_row
                if row_offset:
                    line.append("\n" * row_offset)
                    last_row += row_offset
                    last_col = 0
                col_offset = t.start[1] - last_col
                if col_offset:
                    line.append(" " * col_offset)
                    last_col += col_offset

# Generated at 2022-06-23 15:55:44.540427
# Unit test for method addarc of class DFAState
def test_DFAState_addarc():
    a = DFAState({NFAState():1}, NFAState())
    b = DFAState({NFAState():1}, NFAState())
    assert a.arcs == {}
    a.addarc(b, 'label')
    assert a.arcs == {'label': b}
    assert b.arcs == {}



# Generated at 2022-06-23 15:55:48.725391
# Unit test for method addarc of class DFAState
def test_DFAState_addarc():
    state = DFAState({}, None)
    assert state.arcs == {}
    state.addarc("next", "label")
    assert state.arcs == {"label": "next"}
    #raise


# Generated at 2022-06-23 15:55:53.003084
# Unit test for function generate_grammar
def test_generate_grammar():
    p = generate_grammar()
    assert p.keywords["None"] == "NAME"
    assert p.tokens["fat-arrow"] == "OP"
    assert p.opmap["="] == "EQUAL"
    assert p.start == "file_input"
# TODO: I don't know how to unit test this function
# def generate_grammar2(filename: Path = "Grammar.txt") -> PgenGrammar:

# Generated at 2022-06-23 15:55:58.134863
# Unit test for function generate_grammar
def test_generate_grammar():
    global grammar
    grammar = generate_grammar()
    assert isinstance(grammar, PgenGrammar)

# Generated at 2022-06-23 15:56:09.063499
# Unit test for constructor of class NFAState
def test_NFAState():
    x = NFAState()
    y = NFAState()
    z = NFAState()
    x.addarc(y)
    x.addarc(z, 'a')


# Generated at 2022-06-23 15:56:17.327533
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    def _make_label(c, label):
        return c.make_label(c, label)
    c = ParserGenerator.convert(grammar.grammar)
    for type, value, _, _, _ in tokenize.generate_tokens(io.StringIO("").readline):
        if type == tokenize.NAME or type == tokenize.STRING and value[0] in "\"'" and value[-1] == value[0]:
            assert _make_label(c, value) == c.labels.index((type, value))


if __name__ == "__main__":
    test_ParserGenerator_make_label()
    pgen = ParserGenerator()
    pgen.generate(sys.argv[1])
    PgenGrammar(pgen).write_grammar

# Generated at 2022-06-23 15:56:29.445489
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    class tseq(object):
        def __init__(self):
            self.seq = []
        def append(self, tup):
            self.seq.append(tup)
        def __iter__(self):
            return iter(self.seq)

    tokens = tseq()
    tokens.append((token.OP, "("))
    tokens.append((token.NAME, "d"))
    tokens.append((token.OP, ")"))
    tokens.append((token.NAME, "c"))
    tokens.append((token.NEWLINE, "\n"))
    pg = ParserGenerator()
    pg.tokens = tokens
    pg.gettoken()
    a, z = pg.parse_alt()
    assert pg.type == token.NEWLINE



# Generated at 2022-06-23 15:56:38.360507
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    pg = ParserGenerator()
    pg.dfas = {
        "a": [DFAState({NFAState(): 1})],
        "b": [DFAState({NFAState(): 1})],
        "c": [DFAState({NFAState(): 1})],
    }
    pg.calcfirst("c")
    assert pg.first == {"c": {}}
    pg.dfas["c"][0].addarc("d")
    pg.dfas["c"][0].addarc("e")
    pg.calcfirst("c")
    assert pg.first == {"c": {"d": 1, "e": 1}}
    pg.dfas["a"][0].addarc("g")
    pg.dfas["b"][0].addarc("g")

# Generated at 2022-06-23 15:56:44.886490
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    pg = ParserGenerator()
    pg.type = token.NAME
    pg.value = "foo"
    pg.filename = "test"
    pg.end = (1, 2)
    pg.line = "bar"
    pg.generator = iter([(token.NUMBER, "1")])
    pg.expect(token.NUMBER)


# Generated at 2022-06-23 15:56:55.715353
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    pg = ParserGenerator()

# Generated at 2022-06-23 15:56:58.079788
# Unit test for method __eq__ of class DFAState
def test_DFAState___eq__():
    DFAState({"a": None}, "a") == DFAState({"a": None}, "a")


# Generated at 2022-06-23 15:57:08.488033
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    pg = ParserGenerator()
    dfa = [
        DFAState({"a": 1, "b": 1}, False),
        DFAState({"a": 3, "c": 2}, False),
        DFAState({"a": 2, "b": 1}, False),
        DFAState({"a": 3, "c": 2}, False),
    ]
    pg.simplify_dfa(dfa)
    assert len(dfa) == 3
    assert dfa[0].arcs == {"a": dfa[1], "b": dfa[2]}
    assert dfa[1].arcs == {"a": dfa[2], "c": dfa[1]}
    assert dfa[2].arcs == {"a": dfa[1], "b": dfa[2]}
    # Test that

# Generated at 2022-06-23 15:57:16.754448
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    pg = ParserGenerator()
    for name in "a b c d e f g h i j k l m n o p q r s t u v w x y z".split():
        pg.addtoken(name)
    pg.addtoken("foo")
    pg.addtoken("bar")
    pg.addtoken("baz")

    def check(input, exp, names="asdfqwer"):
        # print input
        it = iter(input.split())
        it = zip(it, it, it)
        pg.setinput(it, names)
        a, z = pg.parse_rhs()
        pg.expect(token.ENDMARKER)
        got = pg.make_postfix(a, z)
        # print got
        assert got == exp


# Generated at 2022-06-23 15:57:28.424790
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    from tokenize import tokenize, untokenize, NAME, OP, STRING, ENDMARKER, NL, COMMENT

    def tokenize_str(string):
        f = io.StringIO(string)
        for tup in tokenize(f.readline):
            yield tup

    pg = ParserGenerator()
    pg.generator = tokenize_str('NAME : "STRING"\n')
    pg.gettoken()
    pg.expect(NAME)
    pg.expect(OP, ":")
    pg.expect(STRING)
    pg.expect(ENDMARKER)
    pg.gettoken()

    # test error handling
    with pytest.raises(SyntaxError) as excinfo:
        pg.expect(NAME)

# Generated at 2022-06-23 15:57:36.639891
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    filename = os.path.join(os.path.dirname(__file__), "Grammar.txt")
    with open(filename, "rb") as f:
        pg_grammar_source = f.read()
    generator = ParserGenerator(pg_grammar_source, filename)
    pgen_grammar = generator.convert()
    if sys.flags.optimize:
        print("test_ParserGenerator: skipping verification (optimized)")
        return
    pgen_grammar_data = pgen_grammar.data
    pgen_grammar_names = pgen_grammar.names

# Generated at 2022-06-23 15:57:41.601894
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    for name in ("python", "pgen"):
        parser = ParserGenerator(name)
        for name in parser.dfas.keys():
            dfa = parser.dfas[name]
            parser.dump_nfa(name, dfa[0].nfaset, parser.nfastates[name])



# Generated at 2022-06-23 15:57:48.258607
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    import unittest

    class TestCase(unittest.TestCase):
        def test_one(self):
            a = DFAState({}, None)
            b = DFAState({}, None)
            a.addarc(b, 'label')
            dfa = [a, b]
            ParserGenerator.simplify_dfa(None, dfa)
            self.assertEqual(dfa, [a])
            self.assertEqual(a.arcs, {'label': b})

    unittest.main()


# Generated at 2022-06-23 15:57:59.297955
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    pg = ParserGenerator()
    PG = pg

    def s(tokentype, string):
        return (tokentype, string, (0, 0), (1, 1), string)

    def tok(tokentype, string):
        pg.type, pg.value = tokentype, string
        pg.gettoken()

    tok(token.NAME, "foo")
    tok(token.OP, ":")
    tok(token.NAME, "bar")
    tok(token.OP, "|")
    tok(token.NAME, "baz")
    tok(token.NEWLINE, "\n")
    tok(token.NAME, "bar")
    tok(token.OP, ":")
    tok(token.NAME, "baz")
    tok

# Generated at 2022-06-23 15:58:08.190960
# Unit test for constructor of class NFAState
def test_NFAState():
    a = NFAState()
    b = NFAState()
    c = NFAState()
    a.addarc(b)
    a.addarc(b)
    a.addarc(c)

    # Check, if addarc() never adds duplicate NFAStates
    assert a.arcs[0][1] is a.arcs[1][1]
    assert a.arcs[0][1] is not a.arcs[2][1]
    assert a.arcs[1][1] is not a.arcs[2][1]



# Generated at 2022-06-23 15:58:17.271800
# Unit test for constructor of class DFAState
def test_DFAState():
    # check that hashable DFAStates compare equal; not equal otherwise
    for isfinal in (0, 1):
        x1 = DFAState(dict.fromkeys((1,), 1), 1)
        x2 = DFAState(dict.fromkeys((2,), 1), 1)
        x1.isfinal = x2.isfinal = isfinal
        x1.arcs = {'label': x1}
        x2.arcs = {'label': x2}
        d = {x1: 1}
        d[x2] = 2
        if isfinal:
            assert d == {x1: 2}
        else:
            assert d == {x1: 1, x2: 2}

# Generated at 2022-06-23 15:58:25.507191
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    from . import driver

    g = driver.ParserGenerator()
    g.add_dottedrule("stmts", "stmt", "NEWLINE")
    g.add_dottedrule("stmt", "expr", "NEWLINE")
    g.add_dottedrule("expr", "expr", "PLUS")
    g.add_dottedrule("expr", "expr", "TIMES")
    g.add_dottedrule("expr", "expr", "LPAR", "expr", "RPAR")
    g.add_dottedrule("expr", "factor")
    g.add_dottedrule("factor", "NUMBER")
    g.add_dottedrule("factor", "NAME")

    g.calcfirst("stmts")

# Generated at 2022-06-23 15:58:30.359058
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():
    #   A --a--> B --b--> C
    #     |     /|        |
    #     |    / |        |
    #     |   /  |        |
    #     +-/--- |        |
    #     | x    |        |
    #     |      |        |
    #     V      V        V
    #   A'--a-->B'--b-->C'
    # Create the states, and a mapping from them to their copies.
    a = DFAState({}, None)
    a2 = DFAState({}, None)
    b = DFAState({}, None)
    b2 = DFAState({}, None)
    c = DFAState({}, None)
    c2 = DFAState({}, None)
    s = set([a, b, c])
    s2

# Generated at 2022-06-23 15:58:35.596451
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    p = ParserGenerator(StringIO("foobar"))
    try:
        p.raise_error("%s %s %s %s", 1, 2, "3", "4")
        assert False, "Exception expected"
    except SyntaxError as e:
        assert e.args == ("1 2 3 4", ("<string>", 0, 0, "foobar\n"))

# Generated at 2022-06-23 15:58:42.850174
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    pg = ParserGenerator("parser.out")
    nfastart = NFAState()
    nfafinish = NFAState()
    nfastart.addarc(nfafinish, "a")
    nfafinish.addarc(nfastart, "a")
    nfafinish.addarc(nfafinish, "a")
    dfa = pg.make_dfa(nfastart, nfafinish)
    assert len(dfa) == 2
    assert len(dfa[0].arcs) == 2
    assert len(dfa[1].arcs) == 1



# Generated at 2022-06-23 15:58:47.307592
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    pg = ParserGenerator()
    assert len(pg.dfas.keys()) == 1
    assert pg.startsymbol == "file_input"
    assert pg.dfas["file_input"] is not None


# Generated at 2022-06-23 15:58:59.203848
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    with StringIO("a : b") as f:
        g = ParserGenerator().make_grammar(f, "foo")

# Generated at 2022-06-23 15:59:07.924003
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():
    s = DFAState({}, None)
    t = DFAState({}, None)
    u = DFAState({}, None)
    s.addarc(t, "a")
    s.addarc(u, "b")
    s.addarc(u, "c")
    u.addarc(t, "d")
    assert s.arcs == {"a": t, "b": u, "c": u}
    assert u.arcs == {"d": t}
    s.unifystate(u, t)
    assert s.arcs == {"a": t, "b": t, "c": t}
    assert u.arcs == {"d": t}

# Generated at 2022-06-23 15:59:18.698984
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    pg = ParserGenerator(None)
    pg.labels = []
    pg.symbol2number = {"foo": 69}
    pg.symbol2label = {"foo": 42}
    pg.tokens = {token.NUMBER: 88}
    pg.keywords = {"if": 77}
    assert pg.make_label(None, "foo") == 42
    assert pg.make_label(None, "NUMBER") == 88
    assert pg.make_label(None, "'if'") == 77
    assert pg.make_label(None, "'<'") == len(pg.labels)
    assert pg.labels[-1] == (token.LESS, None)
    assert pg.make_label(None, "'>'") == len(pg.labels) - 1


# Generated at 2022-06-23 15:59:30.154945
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    import io
    import tokenize
    import pgen2.pgen
    pg = pgen2.pgen.ParserGenerator()

    pg.dfas = {
        "foo": [
            DFAState(
                {0: 1},
                0,
                {
                    "bar": [DFAState({1: 1}, 1)],
                    "baz": [DFAState({2: 1}, 1)],
                },
            ),
            DFAState({1: 1}, 1, {}, True),  # final state
            DFAState({2: 1}, 2, {"quux": [DFAState({2: 1}, 2)]}),
            DFAState({3: 1}, 3, {"bar": [DFAState({3: 1}, 3)]}),
        ]
    }


# Generated at 2022-06-23 15:59:42.129010
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    from GrammarTests import test_grammars
    from GrammarTests import no_python_version

    for name in sorted(test_grammars):
        if name in no_python_version:
            continue
        if (
            name == "func_arglist"
        ):  # func_arglist is only in py38+ ... wait until we support py38
            continue
        for version_info in test_grammars[name]:
            grammar = test_grammars[name][version_info]
            nfa = ParserGenerator(grammar, name, version_info)
            dfa = nfa.dfas
            fset = nfa.first

    # Add your test cases here.
    # Here are some examples.
    #
    # The following will probably print "SyntaxError: EOL while scanning string literal

# Generated at 2022-06-23 15:59:54.326824
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    pg = ParserGenerator("test", "a")
    import re

# Generated at 2022-06-23 16:00:05.412956
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    p = ParserGenerator()
    try:
        p.raise_error(msg="foo")
    except SyntaxError as e:
        assert e.args == ("foo", (None, 0, 0, ""))
    else:
        fail("did not raise")

    try:
        p.raise_error(msg="foo %s", args=('bar',))
    except SyntaxError as e:
        assert e.args == ("foo bar", (None, 0, 0, ""))
    else:
        fail("did not raise")

    try:
        p.raise_error(msg="foo")
    except ValueError:
        pass
    else:
        fail("did not raise")

# Generated at 2022-06-23 16:00:11.433831
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    pg = ParserGenerator()
    start = NFAState()
    z = NFAState()
    start.addarc(z, "a")
    dfa = pg.make_dfa(start, z)
    assert dfa[0].arcs == {"a": dfa[1]}


# Generated at 2022-06-23 16:00:14.084901
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    parser = ParserGenerator()
    parser.dump_dfa('test_name', ['test_dfa'])

# Generated at 2022-06-23 16:00:25.317928
# Unit test for constructor of class ParserGenerator

# Generated at 2022-06-23 16:00:32.769308
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    import io

    s = "a = a|b"
    pg = ParserGenerator(io.StringIO(s))
    assert pg.expect(token.NAME) == "a"
    assert pg.expect(token.OP, "=") == "="
    assert pg.expect(token.NAME) == "a"
    assert pg.expect(token.OP, "|") == "|"
    assert pg.expect(token.NAME) == "b"
    assert pg.expect(token.ENDMARKER) is None

    s = "a 'b'"
    pg = ParserGenerator(io.StringIO(s))
    assert pg.expect(token.NAME) == "a"
    assert pg.expect(token.STRING) == "b"

    s = "[a]"
   

# Generated at 2022-06-23 16:00:42.323214
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    nfa1 = NFAState()
    nfa2 = NFAState()
    nfa1.addarc(nfa2, "a")
    nfa1.addarc(nfa2, "b")
    nfa1.addarc(nfa2, "c")
    nfa3 = NFAState()
    nfa2.addarc(nfa3, "d")
    nfa4 = NFAState()
    nfa2.addarc(nfa4, "e")
    nfa5 = NFAState()
    nfa2.addarc(nfa5, "f")
    nfa6 = NFAState()
    nfa1.addarc(nfa6, "g")
    nfa7 = NFAState()
    nfa1.addarc(nfa7, "h")
   

# Generated at 2022-06-23 16:00:51.539077
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    class TestParserGenerator(ParserGenerator):
        def p_error(self, token: Any) -> None:
            pgen_error(self, token)

        def p_start(self, args: List[Any]) -> None:
            self.addstate(args[0], '')

        def p_start_end(self, args: List[Any]) -> None:
            self.addstate(args[0], '')
            self.addstate(args[1], '')

    # pylint: disable=missing-function-docstring
    def pgen_error(parser: ParserGenerator, token: Any) -> NoReturn:
        print("Syntax error at '%s' on line %s" % (token.value, token.lineno))
        raise SystemExit

    tpg = TestParserGenerator()
    t

# Generated at 2022-06-23 16:01:00.272611
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    grammar = """
    start: a
    a: "a"
    """
    parser = ParserGenerator(grammar)
    dfa = parser.dfas["a"]
    assert len(dfa) == 2
    start = dfa[0]
    assert len(start.arcs) == 1
    assert "a" in start.arcs
    assert start.arcs["a"] is dfa[1]
    final = dfa[1]
    assert len(final.arcs) == 0


# Generated at 2022-06-23 16:01:09.558859
# Unit test for constructor of class PgenGrammar
def test_PgenGrammar():
    # Just enough methods to get through the constructor.
    class MockToken:
        def __init__(self, type, string):
            self.type = type
            self.string = string
    class MockGrammar:
        def __init__(self):
            self.tokens = {}
            self.dfas = {}
            self.start = None
    g = MockGrammar()
    g.tokens["STUFF"] = MockToken("STUFF", "STUFF")
    g.dfas["STUFF"] = []
    g.start = "STUFF"
    pg = PgenGrammar(g, None, {})
    assert isinstance(pg, PgenGrammar)



# Generated at 2022-06-23 16:01:15.882813
# Unit test for method addarc of class NFAState
def test_NFAState_addarc():
    # addarc - check that it doesn't already exist
    s = NFAState()
    label = 'label'
    next = NFAState()
    s.addarc(next, label)
    s.addarc(next, label)
    s.addarc(NFAState(), label)
    s.addarc(NFAState(), label)
    s.addarc(next, label)

