

# Generated at 2022-06-23 15:51:22.386106
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():
    def check(expected: List["DFAState"], dfa: List["DFAState"]) -> None:
        if len(expected) != len(dfa):
            print(
                "expected {0!r} have different length than dfa {1!r}".format(
                    expected, dfa
                )
            )
        for i, e in enumerate(expected):
            s = dfa[i]
            if e.nfaset != s.nfaset:
                print(
                    "expected {0!r} (nfaset: {1!r}) at pos {2} has different nfaset than dfa {3!r} (nfaset: {4!r})".format(
                        e, e.nfaset, i, s, s.nfaset
                    )
                )

# Generated at 2022-06-23 15:51:31.897131
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    import pgen
    gparser = pgen.ParserGenerator()
    gparser.dump_dfa("test", [(NFAState(), NFAState())])
    gparser.dump_dfa("test", [(NFAState({1, 2}, True), NFAState())])
    gparser.dump_dfa("test", [(NFAState(), NFAState({1, 2}, True))])
    #def __init__(self, nfaset: Set[NFAState], finish: NFAState, isfinal: bool = False) -> None: # type: ignore
    #def __init__(self) -> None: # type: ignore
    #def __init__(self, *nodes: NFAState, isfinal: bool = False) -> None: # type: ignore

# Generated at 2022-06-23 15:51:43.796425
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    pg = ParserGenerator()
    pg.gettoken = mock.Mock(
        side_effect=[
            (token.NAME, "foo", (0, 0), (1, 2), "foo"),
            (token.NAME, "bar", (1, 2), (1, 5), "bar"),
        ]
    )
    assert pg.expect(token.NAME) == "foo"
    pg.gettoken.assert_called_once_with()
    assert pg.expect(token.NAME) == "bar"
    pg.gettoken.assert_called_with()
    with pytest.raises(SyntaxError):
        pg.expect(token.NUMBER)

if __name__ == "__main__":
    import sys

    data = open(sys.argv[1]).read()
    pg = Pars

# Generated at 2022-06-23 15:51:51.260824
# Unit test for method make_grammar of class ParserGenerator

# Generated at 2022-06-23 15:52:03.648366
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    pg = ParserGenerator()
    pg.dfas = {'a': '', 'b': '', 'c': ''}
    pg.symbol2number = {}
    pg.first = {'a': {'1': 1, '2': 1, '3': 1}, 'b': {'4': 1}, 'c': {'5': 1}}
    pg.labels = []
    pg.tokens = {}
    pg.keywords = {}
    pg.symbol2label = {}
    pg.make_first(pg, 'a')


#class ExtendedParserGenerator(ParserGenerator):
#    @classmethod
#    def convert(cls, grammar: grammar.Grammar, start: str) -> PgenGrammar:
#        return super().convert(grammar, start)

## this does

# Generated at 2022-06-23 15:52:11.881360
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    a = NFAState()
    b = NFAState()
    c = NFAState()
    d = NFAState()
    e = NFAState()
    f = NFAState()
    a.addarc(c, "a")
    a.addarc(b, "a")
    b.addarc(d, "b")
    c.addarc(d, "b")
    c.addarc(c, None)
    d.addarc(e, None)
    e.addarc(f, "c")
    dfa = ParserGenerator.make_dfa(None, a, f)
    assert isinstance(dfa, list)



# Generated at 2022-06-23 15:52:17.364729
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    class ParserGeneratorTest(ParserGenerator):
        def dump_nfa(self, *args: object) -> None:
            print(repr(args))
            ParserGenerator.dump_nfa(self, *args)

    pg = ParserGeneratorTest()
    pg.setup_parser()
    pg.make_parser(lines, "dummy")

# Generated at 2022-06-23 15:52:27.085437
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    import pytest
    from .parser import ParserGenerator
    from .dfas import DFAState, NFAState

    class FakeParser(ParserGenerator):
        def __init__(self, src: str, line: int) -> None:
            self.src = src
            self.line = line
            self.tokens = [(token.NAME, "abra"), (token.STRING, "cadabra")]
            self.ntokens = len(self.tokens)

        def gettoken(self) -> None:
            if self.ntokens:
                self.type, self.value = self.tokens.pop(0)
                self.ntokens -= 1
            else:
                self.type, self.value = token.ENDMARKER, ""

# Generated at 2022-06-23 15:52:31.038306
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    ParserGenerator("a").parse_item()
    ParserGenerator("a+").parse_item()
    ParserGenerator("a*").parse_item()
    ParserGenerator("[abc]").parse_item()
    return



# Generated at 2022-06-23 15:52:41.296581
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    s = """
        # A simple grammar
        expr: sum
        sum:
            sum '+' term
        |   sum '-' term
        |   term
        term:
            term '*' factor
        |   term '/' factor
        |   factor
        factor:
            '(' expr ')'
        |   NAME
        |   NUMBER
        %ignore ' '
        """
    dfas, startsymbol = ParserGenerator().parse_string(s)
    pprint(dfas)
    print(startsymbol)

    # Convert to a pgen-grammar
    c = ParserGenerator().make_grammar(dfas, startsymbol)
    pprint(c.states)
    pprint(c.labels)



# Generated at 2022-06-23 15:52:51.537704
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    source = """
a: 'a'
b: 'b'
c: 'c'
d: 'd'
e: 'e'
f: 'f'
"""
    generator = ParserGenerator()
    results = generator.parse_string(source)
    assert len(results) == 6
    # Each result is (start, final), where start is a NFAState and
    # final is a NFAState
    for name, (start, z) in results.items():
        if name == "a":
            assert z.arcs == [(None, start)]
            assert start.arcs == [("a", z)]
        elif name == "d":
            assert z.arcs == [(None, start)]
            assert start.arcs == [("d", z)]
        elif name == "f":
            assert z

# Generated at 2022-06-23 15:53:03.415517
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    pg = ParserGenerator()
    def getter(lines: List[Tuple[int, Text]]) -> List[Tuple[int, Text]]:
        nonlocal pg
        # Convert the source lines to tokens
        lines = list(tokenize.generate_tokens(iter(lines).__next__))
        tok_gen = TokenGenerator(lines)
        pg.generator = tok_gen
        pg.gettoken()
        return lines


# Generated at 2022-06-23 15:53:12.930152
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    pg = ParserGenerator()
    pg.filename = "?"
    pg.line = ""
    pg.type = token.NAME
    pg.value = "a"

    def gettokens(*tup: Tuple[int, str, int, int, str], **kwargs: Any) -> None:
        while True:
            try:
                tup = next(tup)
            except StopIteration:
                pg.type = token.ENDMARKER
                return
            pg.type, pg.value, *pg.begin = tup
            if kwargs and kwargs[pg.value]:
                return
            yield


# Generated at 2022-06-23 15:53:23.150075
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    # Create a dummy converter object
    converter = ParserGenerator()
    converter.labels = []
    converter.tokens = {}
    converter.keywords = {}
    converter.symbol2label = {}
    converter.symbol2number = {"foo": 3}
    # Run the method
    import token
    ilabel = converter.make_label(
        '"bar"',
    )
    # Test the result
    assert ilabel == 0
    assert converter.labels == [(token.STRING, "bar")]
    assert converter.tokens == {}
    assert converter.keywords == {}
    assert converter.symbol2label == {}
    # Test the result for a named token
    ilabel = converter.make_label(
        'NAME',
    )
    # Test the result
    assert ilabel == 0

# Generated at 2022-06-23 15:53:36.379790
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    import unittest
    unittest.TestCase.maxDiff = None  # type: ignore
    test = TestCase('test_ParserGenerator_addfirstsets')
    # Example from the docstring
    pgen = ParserGenerator()
    test.assertEqual(pgen.addfirstsets(), None)

# Generated at 2022-06-23 15:53:46.295317
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    from .parser import ParserGenerator
    pg = ParserGenerator()
    # (p1, line) = pg.parse_rhs('abc123|xyz')
    a, z = pg.parse_rhs('abc123|"def"|xyz')
    # p2 = pg.make_dfa(a, z)
    assert a.arcs[0][1] != a.arcs[1][1]
    assert a.arcs[0][1] != a.arcs[2][1]
    assert a.arcs[1][1] != a.arcs[2][1]
    assert len(a.arcs) == 3

    a, z = pg.parse_rhs('abc | "def"')

# Generated at 2022-06-23 15:53:48.740493
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    p = ParserGenerator()
    p.gettoken()
    #
    # End of unit test
    #

# Generated at 2022-06-23 15:53:59.006070
# Unit test for method __eq__ of class DFAState
def test_DFAState___eq__():
    print("test_DFAState___eq__")
    a = DFAState({}, None)
    b = DFAState({}, None)
    a.addarc(a)
    # a.addarc(a)
    b.addarc(b)
    assert a != b
    b.addarc(a)
    assert a == b
    b.addarc(a)
    assert a == b
    a.addarc(a)
    assert a == b
    b.addarc(b)
    assert a == b
    b.addarc(b)
    assert a == b
    a.addarc(b)
    assert a != b
    b.addarc(a)
    assert a == b
    a.addarc(a)
    b.addarc(b)

# Generated at 2022-06-23 15:54:04.996440
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    test_string = '''
    """
    A unit test of gettoken()
    """

    #
    # Parser Generator for Unit Test:
    #
    pg = ParserGenerator(
        "*",
        """
        S : A B
        A : 'a'
        B : 'b'
        """
    )
    '''
    pg = ParserGenerator("*", test_string)


# Generated at 2022-06-23 15:54:14.678508
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    myPG = ParserGenerator()

    # Fill in some dummies
    myPG.labels = [(g,v) for g,v in enumerate(('a','b','c','d','e','f', ))]
    myPG.tokens = { g:v for v,g in enumerate(('a','b','c','d','e','f', ))}
    myPG.keywords = {
        'a': 0, 'b': 1, 'c': 2, 'd': 3, 'e': 4, 'f': 5
    }
    myPG.symbol2number = {
        'a': 0, 'b': 1, 'c': 2, 'd': 3, 'e': 4, 'f': 5
    }

# Generated at 2022-06-23 15:54:27.720482
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    class State:
        def addarc(self, *args):
            pass
    from io import StringIO
    from tokenize import tokenize
    from token import NAME, STRING, OP
    from types import GeneratorType
    from typing import Tuple
    pg = ParserGenerator()
    def gettoken(tup):
        return tup
    pg.gettoken = gettoken
    def helper(input: str, res: Tuple[State, State], begin=0, end=1) -> None:
        assert pg.parse_atom() == res
        assert pg.begin == begin
        assert pg.end == end
    # Test failure modes
    pg.type = STRING
    pg.raise_error = lambda *args, **kwargs: None
    pg.parse_atom()

# Generated at 2022-06-23 15:54:31.570938
# Unit test for constructor of class NFAState
def test_NFAState():
    n = NFAState()
    m = NFAState()
    assert n.arcs == []
    n.addarc(m)
    assert n.arcs == [(None,m)]
    exception_raised = 0
    try:
        n.addarc(5)
    except Exception as e:
        exception_raised = str(e)
        assert isinstance(exception_raised, str)
    assert exception_raised.startswith("Argument must be NFAState")
    try:
        n.addarc("a")
    except Exception as e:
        exception_raised = str(e)
    assert exception_raised.startswith("Argument must be NFAState")

# End unit tests



# Generated at 2022-06-23 15:54:43.093880
# Unit test for method __eq__ of class DFAState
def test_DFAState___eq__():
    assert DFAState({}, None) == DFAState({}, None)
    assert DFAState({}, None) != DFAState({None: None}, None)
    assert DFAState({None: None}, None) == DFAState({None: None}, None)
    assert DFAState({None: None}, None) != DFAState({None: None}, MSTART)
    assert DFAState({None: None}, MSTART) == DFAState({None: None}, MSTART)
    assert DFAState({None: None}, MSTART) != DFAState({None: None, "foo": None}, MSTART)
    assert DFAState({1: None, 2: None}, MSTART) == DFAState({1: None, 2: None}, MSTART)

# Generated at 2022-06-23 15:54:55.099084
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    import io
    import unittest
    import builtins

    class GrammarTestCase(unittest.TestCase):

        def test_make_first(self):
            input = io.StringIO(
                """\
                foo: bar baz
                bar: NAME | NUMBER
                baz: '+' bar | '-' bar | STRING
            """
            )
            gen = ParserGenerator()
            gen.parse_grammar(input)
            gen.addfirstsets()
            self.assertEqual(gen.first["foo"], {"NAME": 1, "NUMBER": 1, "'+'": 1, "'-'": 1})
            self.assertEqual(gen.first["bar"], {"NAME": 1, "NUMBER": 1})

# Generated at 2022-06-23 15:55:03.697983
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    with open("Python/graminit.c") as f:
        pg = ParserGenerator()
        c = pg.make_grammar(f)
    assert isinstance(c, PgenGrammar)
    assert c.start == 16
    for state_i, state in enumerate(c.states):
        for label_i, (token, next) in enumerate(state):
            label = c.labels[label_i]
            if isinstance(token, int):
                assert token in token.tok_name
                assert token >= 0 and token < 256
            else:
                assert isinstance(token, str)
            assert isinstance(next, int)
            assert next >= 0 and next < len(c.states)
    assert len(c.dfas) == 16
    assert len(c.symbol2label)

# Generated at 2022-06-23 15:55:14.751149
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    p = ParserGenerator()
    p.setup()
    p.input = [('NAME', 'start', (1, 0), (1, 5), ''),
               ('OP', ':', (1, 5), (1, 6), ''),
               ('NAME', 'expr', (1, 6), (1, 10), ''), ('OP', '|', (1, 10), (1, 11), ''),
               ('NAME', 'expr', (1, 11), (1, 15), ''), ('NEWLINE', '', (1, 15), (1, 16), ''),
               ('ENDMARKER', '', (2, 0), (2, 0), '')]
    p.type, p.value = p.input[0]
    a, z = p.parse_rhs()
    assert a.arcs == [(None, z)]

# Generated at 2022-06-23 15:55:23.926036
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    c = ParserGenerator()._make_converter()
    c.symbol2number["foo"] = 1
    assert c.make_label(c, "foo") == 1
    # Symbol not in the grammar
    try:
        c.make_label(c, "bar")
        assert not "Expected exception"
    except ValueError:
        pass
    # A named token (NAME, NUMBER, STRING)
    assert c.make_label(c, "NAME") == 1
    # A keyword
    assert c.make_label(c, "'while'") == 2
    # An operator (any non-numeric token)
    assert c.make_label(c, "'>>'") == 53

# Generated at 2022-06-23 15:55:31.139027
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    def test_input(expect: Any, *inputs: Any, **kwargs: Any) -> Any:
        kwargs.setdefault("read_only", False)
        if type(expect) is type and issubclass(expect, Exception):
            with pytest.raises(expect):
                return ParserGenerator(*inputs, **kwargs)
        else:
            return ParserGenerator(*inputs, **kwargs)

# Generated at 2022-06-23 15:55:42.474648
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    class DFA:
        def __init__(self, isfinal: bool, arcs: Dict[int, int]) -> None:
            self.isfinal = isfinal
            self.arcs = arcs

        def __eq__(self, other: object) -> bool:
            assert isinstance(other, DFA)
            return (
                self.isfinal == other.isfinal
                and self.arcs == other.arcs
            )

        def __repr__(self) -> str:
            return "%s(%r, %r)" % (self.__class__.__name__, self.isfinal, sorted(self.arcs.items()))

    p = ParserGenerator()
    # a single state; both final and nonfinal
    a = NFAState()

# Generated at 2022-06-23 15:55:46.066209
# Unit test for method addarc of class NFAState
def test_NFAState_addarc():
    start = NFAState()
    finish = NFAState()
    start.addarc(finish, 'a')
    assert start.arcs == [('a', finish)],'TEST FAILED' # Note: cannot use assertEquals on lists



# Generated at 2022-06-23 15:55:52.912860
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    from . import pgen2_grammar

    p = ParserGenerator(pgen2_grammar)
    assert p.startsymbol
    for name, dfa in p.dfas.items():
        for state in dfa:
            for label, next in state.arcs.items():
                assert isinstance(label, str)
                assert dfa[label] is next



# Generated at 2022-06-23 15:56:03.788126
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    pg = ParserGenerator('a = "A"')
    tok, value, start, end, line = pg.gettoken()
    assert tok == token.NAME
    assert value == 'a'
    assert start == (1, 0)
    assert end == (1, 1)
    assert line == 'a = "A"\n'
    tok, value, start, end, line = pg.gettoken()
    assert tok == token.OP
    assert value == '='
    assert start == (1, 1)
    assert end == (1, 2)
    assert line == 'a = "A"\n'
    tok, value, start, end, line = pg.gettoken()
    assert tok == token.STRING
    assert value == 'A'
    assert start == (1, 4)
   

# Generated at 2022-06-23 15:56:13.902885
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    # test_grammar.txt is a file generated from Lib/test/tokenize_tests.txt, which
    # contains a number of test cases and is shipped with Python.
    filename = os.path.join(os.path.dirname(__file__), "test_grammar.txt")
    pg = ParserGenerator()
    pg.parse_grammar(open(filename))
    pg.addfirstsets()
    pg.make_grammar()
    assert pg.startsymbol == "file_input"
    assert len(pg.dfas) == 35
    assert list(pg.first["file_input"].keys()) == list(
        pg.first["eval_input"].keys()
    ) == list(pg.first["single_input"].keys())
    assert list(pg.first["file_input"].keys())

# Generated at 2022-06-23 15:56:26.372953
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    from collections import namedtuple
    from typing import List
    import unittest

    class NFAState:
        """Placeholder for the real NFAState class.

        `arcs` is a list of (label, next) tuples.
        """

        def __init__(self, arcs=None, isfinal=0):
            if arcs is None:
                arcs = []
            self.arcs = arcs
            self.isfinal = isfinal

    class DFAState:
        """Placeholder for the real DFAState class.

        `arcs` is a map from labels to the next state.
        """

        def __init__(self, nfaset, finish):
            self.nfaset = nfaset
            self.arcs = {}
            self.isfinal = finish in nfaset


# Generated at 2022-06-23 15:56:34.659755
# Unit test for method gettoken of class ParserGenerator
def test_ParserGenerator_gettoken():
    import io
    import tokenize
    from token import ENCODING
    from typed_ast import ast3
    from typed_ast import ast27
    grammar27 = ast27.__dict__["_Grammar_27"]  # type: ignore
    grammar3 = ast3.__dict__["_Grammar_3"]  # type: ignore
    input_stream = tokenize.StringIO(
        "while True: do_something()\n"
        "def foo(): return None\n"
    )
    tokenizer = tokenize.tokenize(input_stream.readline)
    tokenizer.__next__()
    tokenizer = [(t[0], t[1]) for t in tokenizer]  # Drop start token
    parser = ParserGenerator(grammar3)
    parser.generator = iter(tokenizer)

# Generated at 2022-06-23 15:56:44.173800
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    from typing import NoReturn
    from . import pgen
    import builtins
    line = None 
    try:
        line = "assert False"
        pgen.ParserGenerator(builtins.compile(line, '', 'exec')).raise_error
    except Exception as e:
        assert type(e) is SyntaxError

# Generated at 2022-06-23 15:56:55.236983
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    # Token type:              INT
    pystate.token = tokenize.TokenInfo(tokenize.INT)
    # ParserGenerator instance
    pystate.value = 0
    pystate.filename = 'input'
    pystate.end = (0, 0)
    pystate.line = ''
    try:
        pystate.msg = 'expected %s/%s, got %s/%s'
        pystate.args = (tokenize.COMMENT, 'hello', tokenize.INT, 0)
    except:
        pystate.msg = ' '.join(['expected %s/%s, got %s/%s'] + list(map(str, (tokenize.COMMENT, 'hello', tokenize.INT, 0))))
    pystate.msg = str(pystate.msg)

# Generated at 2022-06-23 15:57:01.491521
# Unit test for method unifystate of class DFAState
def test_DFAState_unifystate():
    old = DFAState({}, None)
    new = DFAState({}, None)
    old.addarc(old)
    old.addarc(new)
    old.addarc(new)
    new.addarc(old)
    new.addarc(new)
    state = DFAState({}, None)
    state.addarc(old)
    state.addarc(old)
    state.addarc(new)
    state.unifystate(old, new)
    assert state.arcs == {None: new, None: new, None: new}, state.arcs



# Generated at 2022-06-23 15:57:10.067074
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    """Unit test for method simplify_dfa of class ParserGenerator"""
    import unittest
    from unittest.mock import Mock

    unittest.util._MAX_LENGTH = 2000
    ParserGenerator.stats = Mock()

    def test(expr, expect):
        p = ParserGenerator(expr)
        dfas = p.dfas
        p.simplify_dfa(dfas['s'])
        assert dfas['s'] == expect

    test(
        "s: 'a'\n",
        [
            DFAState(set([NFAState(0, None)]), NFAState()),
            DFAState(set([NFAState(1, [('a', NFAState())]), NFAState()]), NFAState())],
    )


# Generated at 2022-06-23 15:57:13.960980
# Unit test for method expect of class ParserGenerator
def test_ParserGenerator_expect():
    import io
    import tokenize
    input = io.StringIO("1")
    gen = tokenize.generate_tokens(input.readline)

    generator = test_ParserGenerator()
    generator.generator = gen
    generator.gettoken()
    generator.expect(token.NUMBER, "1")

# Generated at 2022-06-23 15:57:20.669224
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    # XXX This should go into a new test module.
    def make_converter() -> PgenGrammar:
        # Construct a "make_converter()" function that has state
        # similar to what ParserGenerator's constructor does.
        c = PgenGrammar()
        for label in token.tok_name:  # token.tok_name are the labels
            label = label.lower()
            assert label not in c.tokens
            itoken = getattr(token, label, None)
            assert isinstance(itoken, int)
            assert itoken not in c.labels
            c.tokens[itoken] = len(c.labels)
            c.labels.append((itoken, None))
        return c

# Generated at 2022-06-23 15:57:30.727609
# Unit test for method raise_error of class ParserGenerator
def test_ParserGenerator_raise_error():
    generator = tokenize.generate_tokens(io.BytesIO(b"""\
# Comment
1 + 2
""").readline)
    pg = ParserGenerator(generator, "<file name>")
    pg.gettoken()
    pg.gettoken()
    #
    try:
        pg.raise_error("%d %s", 1, "argument")
    except SyntaxError as e:
        assert (
            str(e) == "expected 1 argument, got 3/2" and
            e.filename == "<file name>" and
            e.lineno == 2 and
            e.offset == 4 and
            e.text == "\n1 + 2\n   ^\n"
        )
    else:
        assert 0, "Should raise SyntaxError"



# Generated at 2022-06-23 15:57:41.793931
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    input0_lines = [
        "# my test grammar",
        "start: 'start' base_rule",
        "base_rule: NAME",
        "",
    ]
    scanner = Scanner(StringIO(os.linesep.join(input0_lines)), "<string>")
    gen = ParserGenerator()
    gen.scanner = scanner
    gen.gettoken()  # Get first token
    astart, aend = gen.parse_rhs()
    bstart, bend = gen.parse_rhs()
    cstart, cend = gen.parse_rhs()
    gen.dump_nfa("start", astart, aend)
    gen.dump_nfa("base_rule", bstart, bend)
    gen.dump_nfa("base_rule2", cstart, cend)
    #

# Generated at 2022-06-23 15:57:48.529723
# Unit test for function generate_grammar
def test_generate_grammar():
    from . import token
    from . import grammar
    grammar = generate_grammar()
    assert grammar.dfas
    assert grammar.first
    assert grammar.tokens
    assert grammar.keywords
    assert grammar.start == "file_input"
    assert "file_input" in grammar.dfas
    assert "atom" in grammar.dfas
    assert "term" in grammar.dfas
    assert "or_test" in grammar.dfas
    assert grammar.dfas["file_input"][0].isfinal
    assert not grammar.dfas["or_test"][0].isfinal
    assert token.NAME in grammar.first["dotted_name"]
    assert token.LPAR in grammar.first["testlist_comp"]
    assert grammar.first["testlist_comp"][token.LPAR] == 3

# Generated at 2022-06-23 15:57:59.499569
# Unit test for method make_grammar of class ParserGenerator
def test_ParserGenerator_make_grammar():
    from . import ast as astmod
    from . import python_grammar
    # build a Python grammar
    pg = ParserGenerator(python_grammar.token_list)
    grammar_ast = astmod.parse(python_grammar.grammar, mode='exec')
    pg.add_rules(grammar_ast)
    pg.make_grammar()

    # build a C++ grammar

# Generated at 2022-06-23 15:58:08.477765
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
    parser = ParserGenerator()

# Generated at 2022-06-23 15:58:15.321800
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    s = "a b c"
    t = iter(tokenize.generate_tokens(io.StringIO(s).readline))
    gen = ParserGenerator(t)
    gen.filename = "<test>"
    gen.gettoken()
    a, b = gen.parse_alt()
    assert b.arcs == {("b", None): set([a])}
    assert a.arcs == [(("c", None), None)]



# Generated at 2022-06-23 15:58:18.629291
# Unit test for method addarc of class DFAState
def test_DFAState_addarc():
    # Function test_DFAState_addarc
    state = DFAState({}, 0)
    state.addarc(0, '')
    state.addarc(1, '')


# Generated at 2022-06-23 15:58:26.412512
# Unit test for method simplify_dfa of class ParserGenerator
def test_ParserGenerator_simplify_dfa():
    import os
    import warnings
    import textwrap
    # Disable ResourceWarning because the test creates a lot of temporary
    # files and it is difficult (impossible?) to avoid triggering it
    warnings.filterwarnings("ignore", category=ResourceWarning)
    filename = os.path.join(os.path.dirname(__file__), "..", "Grammar.txt")
    with open(filename, "r") as f:
        data = f.read()

# Generated at 2022-06-23 15:58:32.374056
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    ins = io.StringIO("""\
script: (statement NEWLINE)+
statement: NAME '+' NAME
""")
    gen = ParserGenerator()
    dfas, startsymbol = gen.parse_grammar(ins)
    gen.addfirstsets()
    states = dfas["statement"]
    gen._ParserGenerator__dump_nfa("statement", states[0], states[1])
ParserGenerator().__dict__

 


# Generated at 2022-06-23 15:58:36.425083
# Unit test for method addarc of class NFAState
def test_NFAState_addarc():
    nfa1 = NFAState()
    nfa2 = NFAState()
    nfa1.addarc(nfa2, 'x')
    assert nfa1.arcs == [('x', nfa2)]
test_NFAState_addarc()



# Generated at 2022-06-23 15:58:40.893015
# Unit test for constructor of class ParserGenerator
def test_ParserGenerator():
    import io
    import pgen2.grammar as pg
    buf = io.StringIO("""\
    start: expr $end
    expr: '1+1'

    # This is a comment
    """)
    pg = pg.ParserGenerator("expr", buf)
    assert pg.dfas
    assert pg.startsymbol == "start"


# Generated at 2022-06-23 15:58:48.471688
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    print("test_ParserGenerator_make_first")
    # copied from test_convert
    pg = ParserGenerator(grammar, optimize=False)
    pg.startsymbol = "<start>"

# Generated at 2022-06-23 15:59:00.395449
# Unit test for method parse_rhs of class ParserGenerator
def test_ParserGenerator_parse_rhs():
  a_object = ParserGenerator()

# Generated at 2022-06-23 15:59:07.794814
# Unit test for method __eq__ of class DFAState
def test_DFAState___eq__():
    import collections, random

    class dictlike(collections.Mapping):
        def __init__(self, it):
            self.data = dict(it)

        def __len__(self):
            return len(self.data)

        def __getitem__(self, k):
            return self.data[k]

        def __iter__(self):
            return iter(self.data)

    d1 = DFAState(dictlike([(1,2)]), 3)
    d2 = DFAState(dictlike([(1,2)]), 3)
    d3 = DFAState(dictlike([(1,3)]), 3)
    d4 = DFAState(dictlike([(2,3)]), 3)
    d5 = DFAState(dictlike([(1,2)]), 4)
    d6

# Generated at 2022-06-23 15:59:18.548135
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    # PgenGrammar.dump_dfa
    pg = ParserGenerator()
    # This is a contrived example, the result of parsing a small
    # subset of the Python grammar.
    states = [
        DFAState({0: 1}, True),
        DFAState({1: 1}, True),
        DFAState({2: 1}, True),
        DFAState({3: 1}, True),
        DFAState({4: 1}, True),
        DFAState({5: 1}, True),
        DFAState({6: 1}, True),
        DFAState({7: 1}, False),
        DFAState({8: 1}, False),
        DFAState({9: 1}, False),
    ]
    states[0].addarc(states[1], "NAME")

# Generated at 2022-06-23 15:59:27.491283
# Unit test for method parse_alt of class ParserGenerator
def test_ParserGenerator_parse_alt():
    import io
    import tokenize
    s = "a b | c d"
    g = ParserGenerator.ParserGenerator(io.StringIO(s))
    a, z = g.parse_alt()
    assert a.arcs == {(None, a.arcs[None][0][1])}
    assert list(a.arcs[None][0]) == [None, 'a']
    assert a.arcs[None][0][1].arcs == {(None, a.arcs[None][0][1].arcs[None][0][1])}
    assert list(a.arcs[None][0][1].arcs[None][0]) == [None, 'b']
    assert z.arcs == {(None, z.arcs[None][0][1])}

# Generated at 2022-06-23 15:59:40.052873
# Unit test for method make_label of class ParserGenerator
def test_ParserGenerator_make_label():
    G = ParserGenerator()
    G.keywords = {}
    G.tokens = {}
    G.labels = []
    G.symbol2label = {}
    G.symbol2number = {'unquoted_string': 1, 'expr': 3, 'file_input': 2}
    c = G.make_converter()
    assert G.make_label(c, 'expr') == 3
    assert G.make_label(c, '(') == 0
    assert G.make_label(c, "'('") == 0
    assert G.make_label(c, 'STRING') == 0
    assert G.make_label(c, '"silly"') == 1
    assert G.make_label(c, 'unquoted_string') == 1

# Generated at 2022-06-23 15:59:45.726244
# Unit test for method parse_atom of class ParserGenerator
def test_ParserGenerator_parse_atom():
    p = ParserGenerator()
    test_input = "a"
    generator = p.tokenize(test_input)
    p.generator = generator
    p.gettoken()
    a, z = p.parse_atom()
    nfa_arcs = a.arcs
    assert len(nfa_arcs) == 1
    assert nfa_arcs[0][0] == 'a'
    assert nfa_arcs[0][1] is z


# Generated at 2022-06-23 15:59:55.862581
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    pg = ParserGenerator()
    dfas, startsymbol = pg.parse(StringIO(PGEN_GRAMMAR))
    dfas = pg.as_converter().dfas
    # print startsymbol
    # for name, dfa in dfas.items():
    #     pg.dump_dfa(name, dfa)

# Generated at 2022-06-23 16:00:06.986194
# Unit test for method parse of class ParserGenerator
def test_ParserGenerator_parse():
    r"""
    >>> gen = ParserGenerator()
    >>> print(gen.parse("""

# Generated at 2022-06-23 16:00:18.616661
# Unit test for method make_dfa of class ParserGenerator
def test_ParserGenerator_make_dfa():
    dfa = ParserGenerator(io.StringIO("S: F\nF:word word| word")).make_dfa(*ParserGenerator(io.StringIO("S: F\nF:word word| word")).dfas["S"])[0]

# Generated at 2022-06-23 16:00:23.492333
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    pg = ParserGenerator(
        """
        S: 'o' X
        X: 'x' | 'y'
        """
    )
    pg.addfirstsets()
    assert pg.first["S"] == {"'x'": 1, "'o'": 1, "'y'": 1}



# Generated at 2022-06-23 16:00:31.530221
# Unit test for method parse_item of class ParserGenerator
def test_ParserGenerator_parse_item():
    import unittest
    import io
    with unittest.mock.patch('tokenize.generate_tokens',
                             return_value=((1, '('), (1, ')'), (1, None))):
        # open mock for reading
        mock_open = unittest.mock.mock_open(read_data='()')
        with unittest.mock.patch('builtins.open', mock_open, create=True):
            pg = ParserGenerator()
            state = pg.parse_item()
            assert state == NFAState(arcs=[(None, NFAState(arcs=[]))], endtoken=True)
test_ParserGenerator_parse_item()


# Generated at 2022-06-23 16:00:33.809201
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    pg = ParserGenerator()
    pg.addfirstsets()
    assert isinstance(pg.first, dict)



# Generated at 2022-06-23 16:00:43.315982
# Unit test for method calcfirst of class ParserGenerator
def test_ParserGenerator_calcfirst():
    import collections
    import unittest

    class Test(unittest.TestCase):
        def test_calcfirst(self) -> None:
            # The following example is taken from the docstring of method calcfirst.
            pg = ParserGenerator()
            # Set up the NFA for rule a: "ab" c | "xyz"

            def newnfastate() -> NFAState:
                return NFAState()

            a = newnfastate()
            aa = newnfastate()
            ab = newnfastate()
            aa.addarc(ab, "a")
            abc = newnfastate()
            ab.addarc(abc, "b")
            ac = newnfastate()
            a.addarc(ac, "a")
            ay = newnfastate()

# Generated at 2022-06-23 16:00:53.228076
# Unit test for method make_first of class ParserGenerator
def test_ParserGenerator_make_first():
    from . import grammar

    pg = ParserGenerator()
    pg.build()

# Generated at 2022-06-23 16:00:57.015277
# Unit test for method dump_nfa of class ParserGenerator
def test_ParserGenerator_dump_nfa():
    class G:
        def __init__(self):
            self.dfas  # type: Dict[str, List[DFAState]]
            pass
    pg = ParserGenerator(G(), 1)
    # XXX missing body of test

# Generated at 2022-06-23 16:01:08.653669
# Unit test for method addfirstsets of class ParserGenerator
def test_ParserGenerator_addfirstsets():
    pgen = ParserGenerator()
    pgen.dfas = {'nt': [
        DFAState({}, 0),
        DFAState({}, 0)],
        'other': [
        DFAState({}, 0),
        DFAState({}, 0)]}
    pgen.dfas['nt'][0].arcs[None] = pgen.dfas['nt'][1]
    pgen.dfas['nt'][1].arcs['nt'] = pgen.dfas['nt'][1]
    pgen.dfas['nt'][1].arcs['other'] = pgen.dfas['nt'][1]
    pgen.dfas['other'][0].arcs['nt'] = pgen.dfas['other'][1]

# Generated at 2022-06-23 16:01:20.781692
# Unit test for method dump_dfa of class ParserGenerator
def test_ParserGenerator_dump_dfa():
    print("\n*** Unit test ***")
    print("%s" % ParserGenerator.dump_dfa.__doc__)
    pg = ParserGenerator()
    dfa = [DFAState({NFAState():1}, NFAState()), DFAState({NFAState():1, NFAState():1}, NFAState())]
    pg.dump_dfa("dfa", dfa)
    #
    pg = ParserGenerator()
    dfa = [DFAState({NFAState():1}, NFAState()), DFAState({NFAState():1}, NFAState())]
    pg.dump_dfa("dfa", dfa)
    #
    pg = ParserGenerator()