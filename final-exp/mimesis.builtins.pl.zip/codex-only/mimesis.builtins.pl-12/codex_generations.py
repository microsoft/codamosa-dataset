

# Generated at 2022-06-23 20:37:07.468563
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()

    result = provider.nip()
    assert type(result) is str
    assert len(result) == 10


# Generated at 2022-06-23 20:37:10.064418
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    ps = PolandSpecProvider()
    ps.pesel(1940)
    # Randomly test again get pesel
    ps.pesel(2018)


# Generated at 2022-06-23 20:37:11.742432
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    assert PolandSpecProvider().__class__.__name__ == 'PolandSpecProvider'


# Generated at 2022-06-23 20:37:14.235301
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    PL = PolandSpecProvider()
    print(PL.nip())
    print(PL.pesel())
    print(PL.regon())

# Generated at 2022-06-23 20:37:24.441592
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Test that nip() return valid 10-digit NIP."""
    from random import seed
    from re import match, M
    from datetime import datetime
    from mimesis import Random
    from mimesis.builtins import PolandSpecProvider
    from mimesis.enums import Gender

    random = Random()
    nip_provider = PolandSpecProvider(seed=random.seed)

    nip_01 = nip_provider.nip()
    nip_02 = nip_provider.nip(seed=random.seed)

    assert match(r'(?:[0-9]{3}-?[0-9]{3}-?[0-9]{2}-?[0-9]{2})', nip_01, M)
    assert nip_01 == nip_02

# Generated at 2022-06-23 20:37:34.432709
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # Create object of class PolandSpecProvider
    pl = PolandSpecProvider()

    # Set list of tuples representing test inputs and expected outputs
    # Each tuple contains three elements:
    # gender, birth date and expected PESEL

# Generated at 2022-06-23 20:37:39.671076
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    gen = PolandSpecProvider()
    pesel_list = []
    for i in range(100):
        pesel = gen.pesel()
        pesel_list.append(pesel)
    check_list = list(set(pesel_list))
    print(check_list)
    assert len(check_list) == 100


# Generated at 2022-06-23 20:37:42.193151
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    nip = provider.nip()
    assert len(nip) == 10
    for digit in nip:
        assert int(digit) >= 0 and int(digit) <= 9


# Generated at 2022-06-23 20:37:51.564893
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    seed = 'test_PolandSpecProvider'
    provider = PolandSpecProvider(seed=seed)
    provider = PolandSpecProvider()

    assert provider
    # Unit test for method "nip"
    for x in range(10):
        assert provider.nip()
        assert len(provider.nip()) == 10
    # Unit test for method "pesel"
    for x in range(10):
        assert provider.pesel(gender=Gender.MALE)
        assert len(provider.pesel(gender=Gender.MALE)) == 11

    assert provider.pesel(gender='male')
    assert provider.pesel(gender='female')
    # Unit test for method "regon"
    assert len(provider.regon()) == 9

# Generated at 2022-06-23 20:37:56.451980
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Test method regon of class PolandSpecProvider."""
    # Test 1
    prov = PolandSpecProvider()
    regon_digits = prov.regon()
    assert len(regon_digits) == 9
    # Test 2
    prov = PolandSpecProvider()
    regon14_digits = prov.regon()
    assert len(regon14_digits) == 9

# Generated at 2022-06-23 20:37:58.007392
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    result = PolandSpecProvider().nip()
    assert len(result) == 10


# Generated at 2022-06-23 20:38:04.399967
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    nip = PolandSpecProvider().nip()
    assert len(nip) == 10
    assert nip.isdigit()
    assert int(nip[-1]) == PolandSpecProvider().checksum(
        nip[:9], (6, 5, 7, 2, 3, 4, 5, 6, 7))


# Generated at 2022-06-23 20:38:07.650253
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Test PolandSpecProvider_nip method."""
    provider = PolandSpecProvider()
    nip = provider.nip()
    assert isinstance(nip, str)
    assert len(nip) == 10
    assert provider.validate_nip(nip)


# Generated at 2022-06-23 20:38:09.078998
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    assert PolandSpecProvider(seed=123)


# Generated at 2022-06-23 20:38:11.560963
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Test that method nip returns a string."""
    from mimesis.providers import PolandSpecProvider
    sp = PolandSpecProvider()
    assert isinstance(sp.nip(), str)


# Generated at 2022-06-23 20:38:13.887261
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    p1 = PolandSpecProvider(seed=1234)
    p2 = PolandSpecProvider(seed=1234)
    assert p1 is not p2
    assert p1.random is not p2.random


# Generated at 2022-06-23 20:38:17.615185
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Method nip of class PolandSpecProvider."""
    psp = PolandSpecProvider(seed=42)
    nip_1 = psp._nip()
    nip_2 = psp._nip()
    assert nip_1 == "9431498182"
    assert nip_2 == "9536581944"


# Generated at 2022-06-23 20:38:24.751902
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Unit test for method regon of class PolandSpecProvider."""
    from mimesis.enums import Speciality
    provider = PolandSpecProvider()
    re = str(provider.random.randint(0, 9))
    # generates a REGON and decodes it with the
    # method check_regon and then compares the result
    # with the previous value, in case they are equal
    # it means that the generated REGON is correct
    for _ in range(200):
        re2 = (provider.check_regon(provider.regon()))
        assert re == re2



# Generated at 2022-06-23 20:38:26.318065
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    p = PolandSpecProvider()
    print(p.nip())

# Generated at 2022-06-23 20:38:31.884654
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    checked_results = {
        '047747014': True,
        '047747015': False,
        '123456789': False,
    }
    provider = PolandSpecProvider()
    for regon, is_valid in checked_results.items():
        assert provider.validate_regon(regon) is is_valid
test_PolandSpecProvider_regon()
#
# # Print 100 random regons
# for _ in range(100):
#    print(PolandSpecProvider().regon())

# Generated at 2022-06-23 20:38:35.793699
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    nip_generator = PolandSpecProvider()
    nip_number = nip_generator.nip()
    print(nip_number)
    assert len(nip_number) == 10


# Generated at 2022-06-23 20:38:37.508377
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    assert provider.nip() == "8223418053"
    assert provider.pesel() == "81205563122"
    assert provider.regon() == "295726032"

# Generated at 2022-06-23 20:38:38.453433
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    provider.pesel()

# Generated at 2022-06-23 20:38:39.515273
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    assert PolandSpecProvider().nip() == '5192015985'


# Generated at 2022-06-23 20:38:41.285730
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    assert len(PolandSpecProvider().nip()) == 10


# Generated at 2022-06-23 20:38:42.684843
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    p = PolandSpecProvider()
    print(p.nip())


# Generated at 2022-06-23 20:38:43.316457
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    PolandSpecProvider()

# Generated at 2022-06-23 20:38:44.960911
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    obj = PolandSpecProvider()
    pesel = obj.pesel()
    assert len(pesel) == 11

# Generated at 2022-06-23 20:38:48.179136
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Unit test: Test regon method of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    regon = provider.regon()
    assert int(regon) == int(regon)

# Generated at 2022-06-23 20:38:51.787770
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Test for method nip of class PolandSpecProvider"""
    provider = PolandSpecProvider()
    nip = provider.nip()
    assert len(nip) == 10 and type(nip) == str


# Generated at 2022-06-23 20:38:54.695037
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    pl = PolandSpecProvider()
    regon = pl.regon()
    assert (len(regon) == 9)
    regon = int(regon)
    assert (regon <= 999999999)
    assert (regon >= 100000000)



# Generated at 2022-06-23 20:38:56.526205
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    p = PolandSpecProvider()
    x = p.regon()
    assert len(x) == 9

# Generated at 2022-06-23 20:38:57.920809
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    assert provider is not None

# Generated at 2022-06-23 20:39:00.585352
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    value = provider.nip()
    assert value is not None


# Generated at 2022-06-23 20:39:04.030576
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Unit test for method regon of class PolandSpecProvider."""
    p = PolandSpecProvider()
    value = p.regon()
    assert isinstance(value, str)
    assert len(value) == 9


# Generated at 2022-06-23 20:39:05.847363
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pl_provider = PolandSpecProvider()
    pesel = pl_provider.pesel()
    assert len(str(pesel)) == 11


# Generated at 2022-06-23 20:39:08.569178
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    assert provider.nip()
    assert provider.pesel()
    assert provider.regon()

# Generated at 2022-06-23 20:39:11.338235
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    pl = PolandSpecProvider()
    assert pl.nip() != "1111111111" and pl.nip() != "2222222222"



# Generated at 2022-06-23 20:39:19.817571
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    seed = 'mimesis'
    pr = PolandSpecProvider(seed)
    # Assert that the returned object is of type str
    assert isinstance(pr.pesel(), str)
    # Assert that the returned object is of len 11
    assert len(pr.pesel()) == 11
    # Assert that the checksum digit is correct
    assert pr.pesel().endswith('0')
    # Check that the returned object is an int
    assert pr.pesel().isdigit()
    # TODO: Add more tests


# Generated at 2022-06-23 20:39:22.028331
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    p = PolandSpecProvider()
    assert len(p.nip()) == 10
    assert all([int(d) for d in p.nip()])


# Generated at 2022-06-23 20:39:24.981434
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
	"""Test pesel method of PolandSpecProvider class"""
	provider = PolandSpecProvider()
	pesel = provider.pesel(gender=Gender.FEMALE)
	print(pesel)
	pesel = provider.pesel(gender=Gender.MALE)
	print(pesel)

# Generated at 2022-06-23 20:39:27.562661
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    # GIVEN: Instantiation of class PolandSpecProvider
    psp = PolandSpecProvider()

    # WHEN: Invocation of method nip
    nip = psp.nip()

    # THEN: Length of generated string equals 10
    assert len(nip) == 10


# Generated at 2022-06-23 20:39:28.760699
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    with pytest.raises(TypeError):
        PolandSpecProvider.__init__()


# Generated at 2022-06-23 20:39:32.543873
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    values = [
        ('1945080210406', Gender.MALE),
        ('1985060210403', Gender.FEMALE),
        ('1980010210003', Gender.MALE)
    ]

    provider = PolandSpecProvider()
    for value in values:
        assert len(value[0]) == 11
        assert value[0] == provider.pesel(value[1])



# Generated at 2022-06-23 20:39:34.767173
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    print(p.pesel())
    pass

# Generated at 2022-06-23 20:39:37.682660
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Test method nip of class PolandSpecProvider"""
    poland = PolandSpecProvider()
    nip = poland.nip()
    assert len(nip) == len('1234987654')


# Generated at 2022-06-23 20:39:40.389126
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.FEMALE)
    assert len(pesel) == 11

# Generated at 2022-06-23 20:39:47.556362
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    # Create new PolandSpecProvider object
    poland = PolandSpecProvider()
    # Generate random nip
    nip = poland.nip()
    # Check that nip is valid
    assert(len(nip) == 10)
    # If nip is invalid (error message indicate it), generate new nip
    # and check that length is 10
    if not poland.is_valid_nip(nip):
        nip = poland.nip()
        assert(len(nip) == 10)


# Generated at 2022-06-23 20:39:48.168071
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    PolandSpecProvider()

# Generated at 2022-06-23 20:39:53.042415
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Unit test for regon method of class PolandSpecProvider."""
    poland_provider = PolandSpecProvider()

    def test_random_regon():
        """Test random REGON generation."""
        for i in range(0, 20):
            regon = poland_provider.regon()
            assert len(regon) == 9
            assert regon.isdigit()

        for i in range(0, 20):
            regon = poland_provider.regon()
            assert len(regon) == 9
            assert regon.isdigit()

        # test a few fixed examples
        regon_1 = poland_provider.regon(seed=12345)
        assert regon_1 == '400244841'
        regon_2 = poland_provider.regon(seed=123456)
        assert regon

# Generated at 2022-06-23 20:39:53.721608
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    pol = PolandSpecProvider()
    #print(pol.nip())


# Generated at 2022-06-23 20:39:54.559606
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    assert len(provider.nip()) == 10


# Generated at 2022-06-23 20:40:04.379442
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider(seed='test')
    assert (p.pesel(birth_date=p.datetime(1970, 1, 1), gender=Gender.MALE) ==
            '70010109678')
    assert (p.pesel(birth_date=p.datetime(1970, 1, 1), gender=Gender.FEMALE) ==
            '70011111276')
    assert (p.pesel(birth_date=p.datetime(1970, 1, 1)) == '70011111276')
    assert (p.pesel(gender=Gender.FEMALE) == '91110317501')
    assert (p.pesel() == '07122914166')


# Generated at 2022-06-23 20:40:11.964363
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    pl_provider = PolandSpecProvider()
    nip = pl_provider.nip()

    assert len(nip) == 10

    pl_provider_nip = PolandSpecProvider(seed=1)
    nip_1 = pl_provider_nip.nip()
    nip_2 = pl_provider_nip.nip()
    assert nip_1 == nip_2


# Generated at 2022-06-23 20:40:14.312797
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel(birth_date = '1990-01-01', gender = Gender.MALE)
    print(pesel)
    assert len(pesel) == 11
    assert type(pesel) == str
    assert pesel.isdigit() == True


# Generated at 2022-06-23 20:40:15.764982
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    print(PolandSpecProvider().nip())


# Generated at 2022-06-23 20:40:24.233239
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Unit test for method nip of class PolandSpecProvider."""
    provider = PolandSpecProvider(seed=6)
    nip1 = provider.nip()
    nip2 = provider.nip()
    nip3 = provider.nip()
    nip4 = provider.nip()
    nip5 = provider.nip()
    assert nip1 == "6621054545"
    assert nip2 == "6877714002"
    assert nip3 == "6884375023"
    assert nip4 == "6766690424"
    assert nip5 == "6426503429"


# Generated at 2022-06-23 20:40:34.118249
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    assert PolandSpecProvider(seed=1).pesel(Datetime().datetime(2018,2018), Gender.MALE) == '18010800305'
    assert PolandSpecProvider(seed=2).pesel(Datetime().datetime(2018,2018), Gender.FEMALE) == '18021200744'
    assert PolandSpecProvider(seed=3).pesel(Datetime().datetime(2018,2018)) == '18031500294'
    assert PolandSpecProvider(seed=4).pesel(Datetime().datetime(2018,2018), Gender.MALE) == '18042600648'
    assert PolandSpecProvider(seed=5).pesel(Datetime().datetime(2018,2018), Gender.FEMALE) == '18052100032'


# Generated at 2022-06-23 20:40:36.846433
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    poland_spec_provider = PolandSpecProvider()
    assert len(poland_spec_provider.regon()) == 9
    assert poland_spec_provider.regon() is not None

# Generated at 2022-06-23 20:40:39.165317
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    assert len((PolandSpecProvider().regon())) == 9


# Generated at 2022-06-23 20:40:40.500209
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    pol = PolandSpecProvider()
    assert len(pol.regon()) == 9


# Generated at 2022-06-23 20:40:41.081864
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    PolandSpecProvider()

# Generated at 2022-06-23 20:40:45.442311
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pl = PolandSpecProvider()
    assert pl.pesel(birth_date="2010-03-03")[:6] == '100303'
    assert pl.pesel(birth_date="2010-03-03")[-2:] == '90' or '10' or \
           '30' or '50' or '70'



# Generated at 2022-06-23 20:40:49.354424
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    p = PolandSpecProvider()
    for _ in range(100):
        # print(p.regon())
        assert len(p.regon()) == 9


# Generated at 2022-06-23 20:40:51.296385
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    object = PolandSpecProvider()
    assert len(object.nip()) == 10


# Generated at 2022-06-23 20:40:55.325987
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_provider = PolandSpecProvider()
    pesel_number = poland_provider.pesel()

    print(pesel_number)
    assert len(pesel_number) == 11
    assert pesel_number.isnumeric()


# Generated at 2022-06-23 20:41:03.248792
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    p = PolandSpecProvider()

    # Test 1, check the first NIP digit
    nip = p.nip()
    first_digit = nip[0]
    expected_digit = '1'
    assert first_digit == expected_digit

    # Test 2, check the length of the NIP
    nip_length = len(p.nip())
    expected_nip_length = 10
    assert nip_length == expected_nip_length

    # Test 3, check if the method is determinstic (passing the same seed)
    p1 = PolandSpecProvider(seed=42)
    p2 = PolandSpecProvider(seed=42)
    nip1 = p1.nip()
    nip2 = p2.nip()
    assert nip1 == nip2

    # Test 4, check if the

# Generated at 2022-06-23 20:41:06.657196
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    g = PolandSpecProvider()
    print(g.regon())
    assert len(g.regon()) == 9


# Generated at 2022-06-23 20:41:09.115437
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    print(PolandSpecProvider().__doc__)
    print(PolandSpecProvider().__init__.__doc__)

# Generated at 2022-06-23 20:41:11.486722
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    print('NIP:', provider.nip())
    # NIP: 2418175021


# Generated at 2022-06-23 20:41:13.400655
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pl = PolandSpecProvider()
    #print(pl.pesel())
    assert len(pl.pesel()) == 11

# Generated at 2022-06-23 20:41:15.327942
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    peselGen = PolandSpecProvider().pesel()
    assert len(peselGen) == 11

# Generated at 2022-06-23 20:41:18.557771
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Unit test for method regon of class PolandSpecProvider."""
    pesel = PolandSpecProvider.regon(PolandSpecProvider)
    assert len(pesel) == 9


# Generated at 2022-06-23 20:41:20.416389
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    assert PolandSpecProvider().pesel(datetime(2000, 9, 16)) == '00091686376'

# Generated at 2022-06-23 20:41:22.098008
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    pol = PolandSpecProvider()
    assert pol.regon() == '771733748'

# Generated at 2022-06-23 20:41:23.979453
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Unit test for constructor of class PolandSpecProvider."""
    assert PolandSpecProvider.Meta.name == "poland_provider"


# Generated at 2022-06-23 20:41:27.518115
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    print(PolandSpecProvider().nip())
    print(PolandSpecProvider().nip())
    print(PolandSpecProvider().nip())
    print(PolandSpecProvider().nip())


# Generated at 2022-06-23 20:41:30.247319
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    PL = PolandSpecProvider()
    for i in range(100):
        assert PL.nip() != PL.nip()


# Generated at 2022-06-23 20:41:31.157245
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    poland = PolandSpecProvider()
    assert len(poland.regon()) == 9

# Generated at 2022-06-23 20:41:41.439562
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    for number in range(100):
        regon = PolandSpecProvider().regon()
        regon_coeffs = (8, 9, 2, 3, 4, 5, 6, 7)
        o_regon_digits = [int(d) for d in str(regon)]
        sum_v = sum([nc * nd for nc, nd in
                     zip(regon_coeffs, o_regon_digits)])
        checksum_digit = sum_v % 11
        if checksum_digit > 9:
            checksum_digit = 0
        o_regon_digits.append(checksum_digit)
        assert o_regon_digits == [int(d) for d in str(regon)]


# Generated at 2022-06-23 20:41:43.850274
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():

    psp = PolandSpecProvider()
    assert psp

    assert psp.spec.__name__ == 'PolandSpecProvider'
    assert psp.spec.__qualname__ == 'PolandSpecProvider'



# Generated at 2022-06-23 20:41:45.533937
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider.pesel()
    assert PolandSpecProvider.pesel() == pesel


# Generated at 2022-06-23 20:41:48.349994
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    dut = PolandSpecProvider(seed=12345)
    print(dut.nip())
    # print(dut.pesel(gender=Gender.MALE))
    # print(dut.regon())

# Generated at 2022-06-23 20:41:50.393180
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    for _ in range(10):
        print(p.pesel())


# Generated at 2022-06-23 20:41:52.655545
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    nip = provider.nip()
    assert provider.validate_nip(nip) == True


# Generated at 2022-06-23 20:42:01.580776
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # Arrange
    from mimesis.builtins import PolandSpecProvider
    from mimesis.enums import Gender
    from mimesis.typing import DateTime

    year = 1988
    month = 5
    day = 16
    gender = Gender.MALE
    dt = DateTime(year, month, day)

    ps = PolandSpecProvider()

    # Act
    result = ps.pesel(dt, gender)

    # Assert
    assert (len(result)), 11
    assert (result[6] == '5'), "Month is incorrect"
    assert (result[7] == '1'), "Day is incorrect"
    assert (int(result[9]) % 2 != 0), "Gender is incorrect"

# Generated at 2022-06-23 20:42:05.273183
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    p = PolandSpecProvider()
    nip = p.nip()
    assert len(nip) == 10
    assert p.nip.regex() == '^[1-9]\d{8}$'

# Generated at 2022-06-23 20:42:06.320981
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    PolandSpecProvider()


# Generated at 2022-06-23 20:42:12.101507
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Test the correctness of regon generated by PolandSpecProvider"""
    from mimesis.providers.pl import PolandSpecProvider

    s = PolandSpecProvider()
    regon = s.regon()
    print("regon =", regon)

    # Assert length of regon
    assert len(regon) == 9

    # Assert that first 7 digits is a number
    assert regon[0:7].isdigit()

    # Assert that the last digit is a number
    assert regon[8].isdigit()


# Generated at 2022-06-23 20:42:21.883866
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider.

    :return: None
    """
    from datetime import datetime
    from mimesis.enums import Gender
    provider = PolandSpecProvider()
    pesel = provider.pesel(birth_date=datetime(1997, 9, 23), gender=Gender.MALE)
    assert len(pesel) == 11
    assert pesel == '97092333594'
    pesel = provider.pesel(birth_date=datetime(2016, 5, 17), gender=Gender.FEMALE)
    assert len(pesel) == 11
    assert pesel == '16051747146'

# Generated at 2022-06-23 20:42:23.694852
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Test for method regon of class PolandSpecProvider"""
    assert len(PolandSpecProvider().regon()) == 9


# Generated at 2022-06-23 20:42:33.160457
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel(birth_date="20190404", gender=Gender.MALE)
    ch = (int(pesel[0]) +
          3 * int(pesel[1]) +
          7 * int(pesel[2]) +
          9 * int(pesel[3]) +
          int(pesel[4]) +
          3 * int(pesel[5]) +
          7 * int(pesel[6]) +
          9 * int(pesel[7]) +
          int(pesel[8]) +
          3 * int(pesel[9]) +
          int(pesel[10])) % 10

    assert ch == 0


# Generated at 2022-06-23 20:42:35.141919
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    p = PolandSpecProvider()
    for i in range(100):
        assert len(p.regon()) == 9
        assert p.regon().isdigit()


# Generated at 2022-06-23 20:42:36.581626
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    assert(len(provider.nip()) == 10)


# Generated at 2022-06-23 20:42:37.596186
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    print(provider)


# Generated at 2022-06-23 20:42:39.691057
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    assert PolandSpecProvider().regon() in '987654321'
    assert PolandSpecProvider(seed=123).regon() in '987654321'

# Generated at 2022-06-23 20:42:44.421276
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Unit test for method regon of class PolandSpecProvider."""
    import scipy.stats

    from mimesis.providers.poland import PolandSpecProvider
    from mimesis.enums import Gender

    pol = PolandSpecProvider()

    p = pol.regon()
    assert isinstance(p, str)
    assert len(p) == 9
    assert p.isdigit()

    n = 10000
    obs = [pol.regon() for _ in range(n)]
    counts = scipy.stats.itemfreq(obs)

    for i in range(10):
        assert counts[i][1] > 0


# Generated at 2022-06-23 20:42:46.677198
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    test = PolandSpecProvider()
    assert test is not None


# Generated at 2022-06-23 20:42:49.364975
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    PESEL = PolandSpecProvider()
    assert re.match('[0-9]{11}', PESEL.pesel())

# Generated at 2022-06-23 20:42:55.593517
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    import unittest

    class PolandSpecProviderTestCase(unittest.TestCase):
        def setUp(self):
            self.polandSpecProvider = PolandSpecProvider(seed=4)

        def test_pesel(self):
            self.assertEqual(self.polandSpecProvider.pesel(birth_date=Datetime().datetime(1962, 1, 1), gender=Gender.MALE),
                             '6201013365')

    unittest.main()

# Generated at 2022-06-23 20:42:59.750194
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider()
    c = provider.regon()
    # print(c)
    assert c != None
    assert len(c) == 9
    assert c.isnumeric() # Check if all characters in the string are digits


# Generated at 2022-06-23 20:43:00.318707
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    PolandSpecProvider()

# Generated at 2022-06-23 20:43:11.667384
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Unit test of method regon of class PolandSpecProvider"""

    provider = PolandSpecProvider(seed = 1234)
    #Checking given set of values
    assert provider.regon(seed = 4321) == '086625010'
    assert provider.regon(seed = 54321) == '038620604'
    assert provider.regon(seed = 654321) == '021210811'
    assert provider.regon(seed = 7654321) == '094830075'
    assert provider.regon(seed = 87654321) == '016581123'
    assert provider.regon(seed = 987654321) == '069860746'
    assert provider.regon(seed = 1987654321) == '059770839'

# Generated at 2022-06-23 20:43:12.564438
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    assert PolandSpecProvider().nip() == '1234567890'


# Generated at 2022-06-23 20:43:19.385629
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pl_provider = PolandSpecProvider()

    assert pl_provider.pesel(birth_date="1982-03-03", gender=Gender.MALE) == "82032962967"
    assert pl_provider.pesel(birth_date="1982-03-03", gender=Gender.FEMALE) == "82032962968"
    assert pl_provider.pesel(birth_date="1982-03-03") == "82032962967"

    assert pl_provider.pesel(gender=Gender.MALE) != pl_provider.pesel(gender=Gender.FEMALE)
    assert pl_provider.pesel() != pl_provider.pesel()


# Generated at 2022-06-23 20:43:21.698037
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    assert provider.nip()
    assert provider.regon()
    assert provider.pesel() is not None

# Generated at 2022-06-23 20:43:22.695451
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    instance = PolandSpecProvider()



# Generated at 2022-06-23 20:43:26.434719
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Unit test for method nip of class PolandSpecProvider."""
    from mimesis import PolandSpecProvider

    poland_provider = PolandSpecProvider()

    nip = poland_provider.nip()
    # print(nip)


# Generated at 2022-06-23 20:43:29.147417
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    #print(provider.nip())
    assert len(provider.nip()) == 10


# Generated at 2022-06-23 20:43:29.745903
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    PolandSpecProvider()

# Generated at 2022-06-23 20:43:40.418965
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Test method nip of class PolandSpecProvider."""
    from mimesis.builtins import PolandSpecProvider
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.providers.datetime import Datetime
    import datetime
    import random

    seed = random.randint(0, 500)
    random.seed(seed)
    print('seed:', seed)

    pl_provider = PolandSpecProvider(seed=seed)

    nip = pl_provider.nip()
    assert len(nip) == 10
    assert nip.isdigit()

    # https://www.gov.pl/web/krs/informacje-o-nip
    # https://www.gov.pl/web/krs/warunki-i-

# Generated at 2022-06-23 20:43:45.982825
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    psp = PolandSpecProvider()
    nip1 = psp.nip()
    nip2 = psp.nip()
    print(nip1)
    print(nip2)
    print(len(nip1))
    assert len(nip1) == len(nip2)


# Generated at 2022-06-23 20:43:48.608075
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # It is known that the generated PESEL number is valid
    obj = PolandSpecProvider()
    pesel = obj.pesel()
    assert(len(pesel) == 11)

# Generated at 2022-06-23 20:43:55.507171
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    r = PolandSpecProvider()
    print(r.pesel())
    r.seed(53212)
    print(r.pesel())
    r.seed(53212)
    print(r.pesel())
    r.seed(53212)
    print(r.pesel())
    r.seed(1)
    print(r.pesel())
    r.seed(1)
    print(r.pesel())
    r.seed(1)
    print(r.pesel())



# Generated at 2022-06-23 20:43:57.088395
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    locale = PolandSpecProvider()
    assert locale.nip() != locale.nip()


# Generated at 2022-06-23 20:43:57.946332
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    PolandSpecProvider()

# Generated at 2022-06-23 20:43:58.789590
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    a = PolandSpecProvider()
    assert a is not None

# Generated at 2022-06-23 20:44:02.420257
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel(gender=Gender.FEMALE)
    assert len(pesel) == 11
    assert pesel[9] in ['0', '2', '4', '6', '8']



# Generated at 2022-06-23 20:44:13.794434
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Test method regon of class PolandSpecProvider."""
    import re
    from mimesis.enums import Gender

    from mimesis.providers.address import Address

    from .poland_provider import PolandSpecProvider

    poland_provider = PolandSpecProvider()
    poland_provider.seed(1001)
    a = Address(poland_provider)
    regexp = re.compile(r'\d{9}')
    assert regexp.match(poland_provider.regon())
    assert regexp.match(poland_provider.regon())
    assert regexp.match(a.regon())

    poland_provider.seed(1001)
    assert poland_provider.regon() == '760407025'

# Generated at 2022-06-23 20:44:16.519638
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    pl = PolandSpecProvider()
    assert len(pl.regon()) == 9

# Generated at 2022-06-23 20:44:25.180092
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Test acceptation and rejection of REGON."""
    test_regon1 = '66124254'
    test_regon2 = '66124255'
    test_regon3 = '66124253'
    test_regon4 = '6612425'

    assert PolandSpecProvider().validate_regon(test_regon1)
    assert not PolandSpecProvider().validate_regon(test_regon2)
    assert PolandSpecProvider().validate_regon(test_regon3)
    assert not PolandSpecProvider().validate_regon(test_regon4)


# Generated at 2022-06-23 20:44:27.306447
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel_test = PolandSpecProvider()
    pesel = pesel_test.pesel()
    print(pesel)

test_PolandSpecProvider_pesel()

# Generated at 2022-06-23 20:44:33.906832
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    psp = PolandSpecProvider()
    pesel = psp.pesel()

    assert len(pesel) == 11

    psp = PolandSpecProvider()
    d = psp.datetime()

    assert len(psp.pesel(d)) == 11

# Generated at 2022-06-23 20:44:38.266793
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Unit test for method regon of class PolandSpecProvider."""
    # Create object of class PolandSpecProvider
    polandSpecProvider = PolandSpecProvider()
    # Testing method regon of class PolandSpecProvider
    assert(len(polandSpecProvider.regon()) == 9)


# Generated at 2022-06-23 20:44:40.980837
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    pesel = PolandSpecProvider().regon()
    assert len(pesel) == 9



# Generated at 2022-06-23 20:44:44.351216
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    class_ = PolandSpecProvider()
    assert class_.__class__.__name__ == 'PolandSpecProvider'
    assert class_.Meta.name == 'poland_provider'


# Generated at 2022-06-23 20:44:46.269473
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    assert len(PolandSpecProvider().regon()) == 9

# Generated at 2022-06-23 20:44:47.743341
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    assert PolandSpecProvider().regon() == '335708031'

# Generated at 2022-06-23 20:44:50.882476
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test generation of the PESEL number."""
    ps = PolandSpecProvider(seed=1)
    pesel = ps.pesel()
    assert pesel == '36001279092'



# Generated at 2022-06-23 20:44:57.584983
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """
    Test method regon of class PolandSpecProvider
    """
    print("Start of test_PolandSpecProvider_regon")
    pl_provider = PolandSpecProvider(seed=123)
    regon_01 = pl_provider.regon()
    regon_02 = pl_provider.regon()
    print("Generated regon_01 : ", regon_01)
    assert len(regon_01) == 9
    assert regon_01 != regon_02
    print("Generated regon_02 : ", regon_02)
    print("End of test_PolandSpecProvider_regon")


# Generated at 2022-06-23 20:45:00.734179
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """
    Create instance of PolandSpecProvider class and generate REGON
    """
    psp = PolandSpecProvider()
    print(psp.regon())

# Generated at 2022-06-23 20:45:02.086071
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    a = PolandSpecProvider()
    print(a)


# Generated at 2022-06-23 20:45:04.517671
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    assert provider.__class__.__bases__[0].__name__ == 'BaseSpecProvider'

# Generated at 2022-06-23 20:45:14.211425
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Test method regon of class PolandSpecProvider."""
    from mimesis.builtins import PolandSpecProvider as plsp
    from mimesis.enums import Gender
    data = ['123456780', '123456781', '123456782', '123456783', '123456784',
            '123456785', '123456786', '123456787', '123456788', '123456789']

    provider = plsp()
    
    for _ in range(1000):
        regon = provider.regon()
        assert regon in data, '{} is not valid REGON'.format(regon)



# Generated at 2022-06-23 20:45:20.038172
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Test method nip of class PolandSpecProvider."""
    test_poland_provider = PolandSpecProvider()
    nip = test_poland_provider.nip()
    assert len(nip) == 10
    try:
        int(nip)
    except ValueError:
        assert False
    assert int(nip[:-1]) > 100


# Generated at 2022-06-23 20:45:24.294545
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    print ("Testing constructor PolandSpecProvider()")
    print ("object_p should be an object of class PolandSpecProvider")

    object_p = PolandSpecProvider()
    print (object_p)


# Generated at 2022-06-23 20:45:33.419477
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    from mimesis.enums import Gender
    p = PolandSpecProvider()

    pesel = p.pesel(gender = Gender.FEMALE)
    assert len(pesel) == 11 and (pesel[9] == '0' or pesel[9] == '2' or pesel[9] == '4' or pesel[9] == '6' or pesel[9] == '8')
    pesel = p.pesel(gender = Gender.MALE)
    assert len(pesel) == 11 and (pesel[9] == '1' or pesel[9] == '3' or pesel[9] == '5' or pesel[9] == '7' or pesel[9] == '9')
    pesel = p.pesel()
    assert len(pesel) == 11

# Generated at 2022-06-23 20:45:36.424240
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    pl = PolandSpecProvider()
    print(pl.nip())
    print(pl.pesel('1999-10-13', Gender.MALE))
    print(pl.regon())

test_PolandSpecProvider()

# Generated at 2022-06-23 20:45:38.456837
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Unit test for method regon of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    assert len(provider.regon()) == 9

# Generated at 2022-06-23 20:45:47.211907
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    p1 = PolandSpecProvider()
    p2 = PolandSpecProvider(12345)
    p3 = PolandSpecProvider(seed=12345)
    p4 = PolandSpecProvider(seed='12345')
    assert p1 is not p2
    assert p1 is not p3
    assert p2 is not p3
    assert p1 is not p4
    assert p3 is not p4
    assert p2 is not p4
    assert isinstance(PolandSpecProvider(), PolandSpecProvider)
    assert isinstance(PolandSpecProvider(seed=12345), PolandSpecProvider)
    assert isinstance(PolandSpecProvider(seed='12345'), PolandSpecProvider)


# Generated at 2022-06-23 20:45:50.613987
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    gen1 = PolandSpecProvider()
    nip1 = gen1.nip()

    gen2 = PolandSpecProvider()
    nip2 = gen2.nip()

    assert nip1 != nip2


# Generated at 2022-06-23 20:45:52.319133
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    p = PolandSpecProvider()
    assert p is not None

# Generated at 2022-06-23 20:45:59.274671
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
        nip_code = PolandSpecProvider().nip()
        assert nip_code[:3] in ['101', '908', '999']
        assert nip_code[3] != '0'
        assert nip_code[4] != '0'
        assert nip_code[5] != '0'
        assert nip_code[6] != '0'
        assert nip_code[7] != '0'
        assert nip_code[8] != '0'
        assert nip_code[9] != '0'
        assert nip_code[-1] != '0'
        assert len(nip_code) == 10


# Generated at 2022-06-23 20:46:02.033412
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Test regon method of PolandSpecProvider."""
    pl = PolandSpecProvider()
    result = pl.regon()
    assert isinstance(result, str)
    assert len(result) == 9

# Generated at 2022-06-23 20:46:05.420528
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    f1 = PolandSpecProvider.pesel()
    print(f1, type(f1))

test_PolandSpecProvider_pesel()


# Generated at 2022-06-23 20:46:07.165652
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    assert provider
    assert provider.__init__

# Generated at 2022-06-23 20:46:14.172602
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    import datetime
    provider = PolandSpecProvider(seed=0)
    assert provider.pesel() == '49040241168'
    assert provider.pesel(birth_date=datetime.datetime(1993, 11, 24, 2, 12, 22), gender=Gender.MALE) == '93112411957'
    assert provider.pesel(birth_date=datetime.datetime(2018, 12, 22), gender=Gender.FEMALE) == '18122253936'
    assert provider.pesel() == '94082790786'
    assert provider.pesel(birth_date=datetime.datetime(1977, 1, 31)) == '77013185849'

# Generated at 2022-06-23 20:46:15.663869
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    print("======Testing method regon of class PolandSpecProvider======")
    a = PolandSpecProvider()
    print("REGON: ", a.regon())


# Generated at 2022-06-23 20:46:19.078886
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Returns the result of function regon"""
    poland_provider = PolandSpecProvider()
    regon_digits = poland_provider.regon()
    assert len(regon_digits) == 9, "Error of class PolandSpecProvider method regon!"

# Generated at 2022-06-23 20:46:19.596529
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    PolandSpecProvider()

# Generated at 2022-06-23 20:46:20.823390
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    # create instance of class PolandSpecProvider
    pol = PolandSpecProvider()
    assert pol


# Generated at 2022-06-23 20:46:22.330228
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    n = PolandSpecProvider(seed=42)
    assert n.regon() == '823617163'

# Generated at 2022-06-23 20:46:25.590306
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    for _ in range(100):
        print(PolandSpecProvider().nip())


# Generated at 2022-06-23 20:46:29.770517
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Ensure that a random 9-digit REGON is returned."""
    provider = PolandSpecProvider()
    regon1 = provider.regon()
    regon2 = provider.regon()
    assert regon1 != regon2
    assert len(regon1) == 9
    assert regon1.isdigit()

# Generated at 2022-06-23 20:46:32.464564
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():    
    for i in range(10000):
        regon = PolandSpecProvider().regon()
        assert len(regon) == 9
        assert all(int(d) in set(range(10)) for d in regon)


# Generated at 2022-06-23 20:46:35.279949
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Test for method nip of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    result = provider.nip()
    assert isinstance(result, str)


# Generated at 2022-06-23 20:46:39.315464
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    result = provider.pesel()
    assert result in ("44052401458", "84112901465", "06031401456", "01100401453", "88100401452")


# Generated at 2022-06-23 20:46:40.402725
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    PolandSpecProvider.nip()


# Generated at 2022-06-23 20:46:43.302212
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    # Test for method nip of class PolandSpecProvider
    for _ in range(1000):
        assert len(PolandSpecProvider().nip()) == 10

    for _ in range(1000):
        try:
            int(PolandSpecProvider().nip())
        except ValueError:
            assert True
        assert True


# Generated at 2022-06-23 20:46:46.345694
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Проверка генератора данных pesel."""
    assert PolandSpecProvider().pesel(gender=Gender.MALE) == '63122950932'


# Generated at 2022-06-23 20:46:53.032220
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Unit test for constructor of class PolandSpecProvider"""
    pl = PolandSpecProvider()
    # check nip
    nip = pl.nip()
    assert len(nip) == 10

    # check pesel
    pesel = pl.pesel()
    assert len(pesel) == 11

    # check regon
    regon = pl.regon()
    assert len(regon) == 9

# Generated at 2022-06-23 20:46:56.048974
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Test method regon of class PolandSpecProvider"""
    instance = PolandSpecProvider()
    regon = instance.regon()
    assert len(regon) == 9
    assert isinstance(regon, str)


# Generated at 2022-06-23 20:46:57.369656
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    pr = PolandSpecProvider()
    assert 8 == len(pr.regon())

# Generated at 2022-06-23 20:46:59.383672
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
	provider = PolandSpecProvider()
	nip = provider.nip()
	assert len(nip) == 10



# Generated at 2022-06-23 20:47:00.283077
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():

    p = PolandSpecProvider()
    assert true

# Generated at 2022-06-23 20:47:02.942808
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    # Prepare test data
    # Execute method
    # Check result
    assert True



# Generated at 2022-06-23 20:47:09.848186
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    # Checking one valid cases
    assert PolandSpecProvider().nip() == "716-09-64-545"
    assert PolandSpecProvider().pesel(birth_date="2000-2-2") == "00-12-02-400-01"
    assert PolandSpecProvider().regon() == "90567328"
    assert PolandSpecProvider().plate() == "WOW-44-44"