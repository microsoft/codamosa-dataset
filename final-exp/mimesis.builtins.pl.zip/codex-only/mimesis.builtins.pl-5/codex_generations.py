

# Generated at 2022-06-23 20:37:10.535627
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    p = PolandSpecProvider()
    print(p.nip())
    print(p.pesel())
    print(p.regon())


# Generated at 2022-06-23 20:37:12.175503
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    for i in range(10):
        print(p.pesel())


# Generated at 2022-06-23 20:37:16.166294
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test pesel method of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert isinstance(pesel, str)
    assert len(pesel) == 11

# Generated at 2022-06-23 20:37:18.829602
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel == provider.pesel()


# Generated at 2022-06-23 20:37:21.079167
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    # Create instance of PolandSpecProvider
    obj = PolandSpecProvider()
    assert obj is not None

# Generated at 2022-06-23 20:37:23.799784
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    pesel = p.pesel()
    assert len(pesel) == 11
    assert pesel.isdecimal()


# Generated at 2022-06-23 20:37:26.817818
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    _plpoland_spec = PolandSpecProvider()
    assert _plpoland_spec
    assert _plpoland_spec.random
    assert _plpoland_spec.seed

# Unit tests for class PolandSpecProvider method nip

# Generated at 2022-06-23 20:37:28.924320
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    pl = PolandSpecProvider()
    assert pl.nip()
    assert pl.pesel()
    assert pl.regon()

# Generated at 2022-06-23 20:37:39.668672
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    class GenderStub(Gender):
        """Class for stubbing enums.Gender class."""

        @classmethod
        def get_random_gender(cls):
            """Random gender generator method."""
            return cls.MALE if random.randint(0, 1) else cls.FEMALE
    gender = GenderStub.get_random_gender()
    pesel = PolandSpecProvider().pesel(gender=gender)
    pesel_digits = [int(d) for d in pesel]
    pesel_coeffs = (9, 7, 3, 1, 9, 7, 3, 1, 9, 7)

# Generated at 2022-06-23 20:37:44.752935
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    # First test
    provider = PolandSpecProvider()
    regon = provider.regon()
    assert len(regon) == 9
    assert regon.isdigit()
    # Second test
    provider = PolandSpecProvider(seed=42)
    regon = provider.regon()
    assert regon == '515683094'
    # Third test
    provider = PolandSpecProvider()
    regons = [provider.regon() for i in range(1000)]
    assert len(set(regons)) == len(regons)


# Generated at 2022-06-23 20:37:50.201136
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    local_spec_provider = PolandSpecProvider(seed=None)
    local_nip = local_spec_provider.nip()
    checksum = int(local_nip[-1])
    for i in range(len(local_nip) - 1):
        checksum += ((i + 1) % 6 + 1) * int(local_nip[i])

    assert checksum % 11 == 0



# Generated at 2022-06-23 20:37:51.640689
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()
    print(pesel)
    return True


# Generated at 2022-06-23 20:37:55.016146
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Unit test for method nip of class PolandSpecProvider.

    :return: None
    """
    import re
    provider = PolandSpecProvider()
    nip = provider.nip()
    pattern = r'[0-9]{10}'
    assert re.fullmatch(pattern, nip)

    # Unit test for method pesel of class PolandSpecProvider

# Generated at 2022-06-23 20:37:58.337666
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    print('Test method pesel: ', end='', flush=True)
    from datetime import date
    from mimesis.enums import Gender
    from mimesis.providers.pl import PolandSpecProvider
    PESEL = '94121921144'
    pl_provider = PolandSpecProvider()
    bd = date(1994, 12, 19)
    assert PESEL == pl_provider.pesel(bd, Gender.MALE)

    print('OK')


# Generated at 2022-06-23 20:38:04.346780
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    print("test constructor of class PolandSpecProvider")
    obj = PolandSpecProvider()
    class_name = "PolandSpecProvider"
    module_name = "mimesis.builtins.pl"
    assert(obj is not None)
    assert(isinstance(obj, PolandSpecProvider))
    assert(hasattr(obj, 'random'))
    assert(hasattr(obj, 'Meta'))
    assert(hasattr(obj, 'provider_name'))
    assert(hasattr(obj, 'seed_class'))
    assert(hasattr(obj, '__class__'))
    assert(obj.Meta.name == "poland_provider")
    assert(obj.provider_name == "PolandProvider")
    assert(obj.seed_class == "mimesis.providers.base.BaseSeed")


# Generated at 2022-06-23 20:38:11.187415
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # Example
    pesel = PolandSpecProvider().pesel()
    print(pesel)
    assert len(pesel) == 11
    # PESEL numbers(11-digit)
    # https://pl.wikipedia.org/wiki/PESEL
    assert (pesel == '62020317230' or
            pesel == '84101333223' or
            pesel == '84031822163' or
            pesel == '79101694812' or
            pesel == '85011599453')


# Generated at 2022-06-23 20:38:13.852943
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Test method nip from class PolandSpecProvider"""
    # given
    provider = PolandSpecProvider()

    # when
    result = provider.nip()

    # then
    assert len(result) == 10


# Generated at 2022-06-23 20:38:15.211213
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    p = PolandSpecProvider()
    x = p.nip()
    assert x == "1234"


# Generated at 2022-06-23 20:38:16.221324
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # TODO: Implement a unit test for method pesel of class PolandSpecProvider
    pass

# Generated at 2022-06-23 20:38:18.473086
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    assert provider.__class__.__name__ == "PolandSpecProvider"
    print("Class: ", provider.__class__.__name__, " - Ok")


# Generated at 2022-06-23 20:38:20.066271
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
  assert len(PolandSpecProvider().nip()) == 10


# Generated at 2022-06-23 20:38:21.842262
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = Pesel()
    assert len(pesel.pesel()) == 11


# Generated at 2022-06-23 20:38:26.895737
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    plsp = PolandSpecProvider()
    regon_part_1 = '192767682'
    regon_part_2 = '011817086'
    assert str(plsp.regon())[0:8] in [regon_part_1, regon_part_2]


# Generated at 2022-06-23 20:38:28.991719
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Test regon of class PolandSpecProvider."""

    provider = PolandSpecProvider(seed=1)
    regon_number = provider.regon()
    assert regon_number == '402413528'

# Generated at 2022-06-23 20:38:36.426318
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider(seed=12345)
    pesel = provider.pesel(birth_date=Datetime().datetime(2010, 1, 1),
                           gender=Gender.FEMALE)
    assert pesel == '10101478388'
    # Test another gender.
    pesel = provider.pesel(birth_date=Datetime().datetime(2010, 1, 1),
                           gender=Gender.MALE)
    assert pesel == '10101472597'
    # Test another date.
    pesel = provider.pesel(birth_date=Datetime().datetime(1980, 1, 1),
                           gender=Gender.MALE)
    assert pesel == '80010154564'
    # Test another date by adding time.

# Generated at 2022-06-23 20:38:45.729840
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    obj1 = PolandSpecProvider()
    string = obj1.regon()
    list1 = []
    for i in range(9):
        list1.append(string[i])
    list3 = [int(list1[p]) for p in range(9)]
    regon_coeffs = (8, 9, 2, 3, 4, 5, 6, 7)
    list2 = [a * b for a, b in zip(regon_coeffs, list3)]
    sum = 0
    for y in list2:
        sum += y
    value = sum % 11
    if value > 9:
        value = 0
    assert int(string[8]) == value
    return string


# Generated at 2022-06-23 20:38:47.407957
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    instance = PolandSpecProvider()
    regon = instance.regon()
    assert len(regon) == 9


# Generated at 2022-06-23 20:38:49.534379
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    poland_provider = PolandSpecProvider()
    assert len(poland_provider.nip()) == 10


# Generated at 2022-06-23 20:38:51.981661
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    NIP = provider.nip()
    assert len(NIP) == 10


# Generated at 2022-06-23 20:38:56.209157
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    nip = provider.nip()
    assert isinstance(nip, str)
    assert len(nip) == 10
    pesel = provider.pesel()
    assert isinstance(pesel, str)
    assert len(pesel) == 11
    regon = provider.regon()
    assert isinstance(regon, str)
    assert len(regon) == 9

# Generated at 2022-06-23 20:38:58.064414
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Unit test for method regon of class PolandSpecProvider."""

    value = PolandSpecProvider().regon()
    assert_equal(len(value), 9, 'Value should be 9-digit REGON')
    assert_true(value.isdigit(), 'Value should be a number')



# Generated at 2022-06-23 20:39:01.487559
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    if __name__ == '__main__':
        provider = PolandSpecProvider()
        print('NIP: {}'.format(provider.nip()))


# Generated at 2022-06-23 20:39:03.457113
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    nip = PolandSpecProvider().nip()
    print(nip)


# Generated at 2022-06-23 20:39:04.271566
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    p = PolandSpecProvider()
    assert len(p.regon()) is 9


# Generated at 2022-06-23 20:39:05.588326
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    p = PolandSpecProvider()
    result = p.regon()
    assert len(result) == 9



# Generated at 2022-06-23 20:39:07.995739
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    pl = PolandSpecProvider()
    assert pl.provider.seed == 'PolandSpecProvider'

    pl2 = PolandSpecProvider('Test')
    assert pl2.provider.seed == 'Test'


# Generated at 2022-06-23 20:39:09.752899
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    assert provider is not None


# Generated at 2022-06-23 20:39:12.539234
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """
    Test method regon of class PolandSpecProvider
    :return: None
    """
    provider = PolandSpecProvider()
    assert (provider.regon() == '123456785')


# Generated at 2022-06-23 20:39:14.761567
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    p = PolandSpecProvider()
#    print(p.regon())


# Generated at 2022-06-23 20:39:23.073117
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    from datetime import datetime

    x = PolandSpecProvider()

    # Test case 1
    result1 = x.pesel()
    correct1 = len(result1) == 11
    assert correct1

    # Test case 2
    result2 = x.pesel(datetime.now())
    correct2 = len(result2) == 11
    assert correct2

    # Test case 3
    result3 = x.pesel(gender=Gender.FEMALE)
    correct3 = len(result3) == 11
    assert correct3

    # Test case 4
    result4 = x.pesel(datetime.now(), Gender.FEMALE)
    correct4 = len(result4) == 11
    assert correct4

# Generated at 2022-06-23 20:39:29.450293
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    assert p.pesel() == "78121895162"
    assert p.pesel(p.datetime(1940, 2018), p.random.choice([0, 1])) == "98010687759"
    assert p.pesel(p.datetime(1940, 2018), p.random.choice([0, 1])) == "80020144018"
    assert p.pesel(p.datetime(1940, 2018), p.random.choice([0, 1])) == "94024606620"
    assert p.pesel(p.datetime(1940, 2018), p.random.choice([0, 1])) == "97122186975"


# Generated at 2022-06-23 20:39:32.599796
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # Create a new instance of PolandSpecProvider
    poland_spec_provider = PolandSpecProvider()
    # Get the pesel method
    pesel = poland_spec_provider.pesel(birth_date="1980-01-01", gender=Gender.MALE)
    assert (pesel == '80001012345')


# Generated at 2022-06-23 20:39:38.228112
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    pl_provider = PolandSpecProvider()
    assert len(pl_provider.nip()) == 10
    assert pl_provider.nip() == pl_provider.nip()
    assert pl_provider.nip()[0:3] == '101'
    assert pl_provider.nip()[0:3] == '998'


# Generated at 2022-06-23 20:39:41.733891
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    nip = PolandSpecProvider().nip()
    assert len(str(nip)) == 10
    assert isinstance(nip, str)


# Generated at 2022-06-23 20:39:43.385963
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    pl = PolandSpecProvider()
    assert pl.nip() == '7310238455'


# Generated at 2022-06-23 20:39:45.809157
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    valid_regon = "070832295"
    provider = PolandSpecProvider()
    regon = provider.regon()
    assert regon == valid_regon


# Generated at 2022-06-23 20:39:55.606554
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pl_provider = PolandSpecProvider()
    pesel1 = pl_provider.pesel(birth_date="1985-01-01", gender=Gender.MALE)
    pesel2 = pl_provider.pesel(birth_date="1985-01-01", gender=Gender.FEMALE)
    pesel3 = pl_provider.pesel(birth_date="2059-05-15", gender=Gender.MALE)
    pesel4 = pl_provider.pesel()
    
    print(f"MALE PESEL: {pesel1}, FEMALE PESEL: {pesel2}, \nMALE PESEL: {pesel3}, RANDOM PESEL: {pesel4}")


# Generated at 2022-06-23 20:39:59.790612
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    from mimesis.enums import Gender
    from mimesis.providers.poland import PolandSpecProvider
    obj = PolandSpecProvider()
    assert obj.nip()
    assert obj.pesel(Gender.MALE)
    assert obj.regon()

# Generated at 2022-06-23 20:40:01.803753
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    from mimesis.providers.poland import PolandSpecProvider
    poland_provider = PolandSpecProvider()
    assert len(poland_provider.regon()) == 9


# Generated at 2022-06-23 20:40:03.228316
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pl = PolandSpecProvider()
    assert len(pl.pesel()) == 11
    # print(pl.pesel())


# Generated at 2022-06-23 20:40:05.725002
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    poland = PolandSpecProvider()
    nip_list = []
    for i in range(100):
        nip = poland.nip()
        assert ((len(nip)==10) and (nip not in nip_list))
        nip_list.append(nip)


# Generated at 2022-06-23 20:40:10.295565
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    pl = PolandSpecProvider()
    res = pl.nip()
    assert type(res) == str
    assert len(res) == 10


# Generated at 2022-06-23 20:40:11.571048
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pl = PolandSpecProvider()
    assert pl.pesel(gender=Gender.MALE) == '91011711274'
    assert pl.pesel(gender=Gender.FEMALE) == '68031414395'


# Generated at 2022-06-23 20:40:13.203387
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    pesel = PolandSpecProvider().pesel(birth_date = "1996-03-15", gender = 1)
    assert "96" in pesel,"Pesel should contain characters '96'"


# Generated at 2022-06-23 20:40:16.152559
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    psp = PolandSpecProvider()
    assert psp.nip() is not None
    assert psp.pesel() is not None
    assert psp.regon() is not None

# Generated at 2022-06-23 20:40:19.321505
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    n = 100
    results_list = []
    for i in range(n):
        results_list.append(provider.pesel())
    assert len(set(results_list)) == n

# Generated at 2022-06-23 20:40:30.055596
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    nip = provider.nip()
    nip_coefficients = (6, 5, 7, 2, 3, 4, 5, 6, 7)
    nip_digits = [int(d) for d in nip]
    nip_tail = nip_digits[-1]
    nip_head = nip_digits[:-1]
    sum_v = sum([nc * nd for nc, nd in
                 zip(nip_coefficients, nip_head)])
    checksum_digit = sum_v % 11
    if checksum_digit > 9:
        checksum_digit = 0
    assert nip_tail == checksum_digit
#

# Generated at 2022-06-23 20:40:33.045159
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    poland = PolandSpecProvider()
    assert poland.nip() == '0123456789'
    assert len(poland.nip()) == 10
    assert poland.nip().isdigit()

# Generated at 2022-06-23 20:40:35.038600
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()

    assert len(provider.nip()) == 10


# Generated at 2022-06-23 20:40:35.666365
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    a = PolandSpecProvider()
    assert len(a.regon()) == 9

# Generated at 2022-06-23 20:40:38.250509
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    assert len(PolandSpecProvider().regon()) == 9

# Generated at 2022-06-23 20:40:40.434085
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Function to test the regon method of PolandSpecProvider class."""
    # Case 1: 0
    result = PolandSpecProvider().regon()

    # Case 2: 1
    assert len(result) == 9

# Generated at 2022-06-23 20:40:51.871685
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    from mimesis.enums import Gender
    from mimesis.enums import Locale
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.person import Person

    dt = Datetime(locale=Locale.POLAND)
    adr = Address(locale=Locale.POLAND)
    per = Person(locale=Locale.POLAND)
    per.gender = Gender.MALE
    per.generate_age = 15
    print(per.full_name())
    print(dt.date())
    print(dt.datetime())
    print(per.age())
    print(adr.postal_code())
    print(adr.street_name())
    print(adr.street_suffix())


# Generated at 2022-06-23 20:40:57.112456
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    locale = PolandSpecProvider()
    birthdate = Datetime().datetime(1945, 2020)
    pesel = locale.pesel(birthdate)
    assert int(pesel[0:2]) in range(40, 100)
    assert int(pesel[2:4]) in range(1, 13)
    assert int(pesel[4:6]) in range(1, 32)

# Generated at 2022-06-23 20:41:00.566629
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Check if there is any PESEL generated by
    method pesel of class PolandSpecProvider that
    doesn't have proper number of digits (11).
    """
    p = PolandSpecProvider()
    pesels = set()
    while len(pesels) < 10000:
        pesels.add(p.pesel())
    for pesel in pesels:
        assert len(pesel) == 11


# Generated at 2022-06-23 20:41:01.621164
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    assert len(PolandSpecProvider().regon()) == 9

# Generated at 2022-06-23 20:41:02.446092
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider()
    assert provider.regon() == '976062378'

# Generated at 2022-06-23 20:41:14.471941
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    obj = PolandSpecProvider()
    # Test 1
    assert obj.regon() == "554451487"
    # Test 2
    assert obj.regon() == "436827888"
    # Test 3
    assert obj.regon() == "830362128"
    # Test 4
    assert obj.regon() == "958125764"
    # Test 5
    assert obj.regon() == "481489071"
    # Test 6
    assert obj.regon() == "395351366"
    # Test 7
    assert obj.regon() == "932747116"
    # Test 8
    assert obj.regon() == "115726523"
    # Test 9
    assert obj.regon() == "389395046"
    # Test 10
    assert obj.regon() == "751965843"


# Generated at 2022-06-23 20:41:24.262315
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    # Checking if method nip returns a valid value
    poland_nip = PolandSpecProvider().nip()
    nip_coefficients = (6, 5, 7, 2, 3, 4, 5, 6, 7)
    nip_digits = [int(d) for d in poland_nip]
    if len(poland_nip) != 10 :
        raise ValueError('Length of generated nip is not correct')
    sum_v = sum([nc * nd for nc, nd in zip(nip_coefficients, nip_digits)])
    checksum_digit = sum_v % 11

    assert checksum_digit == nip_digits[-1]


# Generated at 2022-06-23 20:41:34.761767
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    pol = PolandSpecProvider()
    assert pol.nip() == pol.nip()
    assert pol.nip() != pol.nip()
    assert pol.pesel(gender=Gender.MALE) == pol.pesel(gender=Gender.MALE)
    assert pol.pesel(gender=Gender.FEMALE) == pol.pesel(gender=Gender.FEMALE)
    assert pol.pesel(gender=Gender.MALE) != pol.pesel(gender=Gender.MALE)
    assert pol.pesel(gender=Gender.FEMALE) != pol.pesel(gender=Gender.FEMALE)
    assert pol.regon() == pol.regon()
    assert pol.regon() != pol.regon()
    assert len(pol.nip()) == 10
    assert len(pol.pesel()) == 11

# Generated at 2022-06-23 20:41:43.879111
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    gender = Gender(int(pesel[9]))
    assert gender == Gender.MALE or gender == Gender.FEMALE
    pesel = provider.pesel(birth_date=provider.datetime(1940, 2018),
                           gender=gender)
    digits = [int(d) for d in pesel]
    assert len(pesel) == 11
    year = digits[0] * 10 + digits[1]
    month = digits[2] * 10 + digits[3]
    day = digits[4] * 10 + digits[5]
    assert month > 0
    assert day > 0

# Generated at 2022-06-23 20:41:45.973768
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    psp = PolandSpecProvider()
    regon = psp.regon()
    assert len(regon) == 9
    print(regon)


# Generated at 2022-06-23 20:41:54.070155
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    nip = PolandSpecProvider().nip()
    nip_list = [int(x) for x in nip]
    nip_coefficients = (6, 5, 7, 2, 3, 4, 5, 6, 7)
    sum_v = sum([nc * nd for nc, nd in zip(nip_coefficients, nip_list)])

    checksum_digit = sum_v % 11
    if checksum_digit > 9:
        return 0
    nip_list.append(checksum_digit)
    nip_str = ''.join(str(d) for d in nip_list)

    if nip == nip_str:
        print("OK")
    else:
        print("Not OK")



# Generated at 2022-06-23 20:41:56.353318
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    spec = PolandSpecProvider()
    assert spec.regon() in ["917238743", "819181107"]


# Generated at 2022-06-23 20:41:59.049084
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    assert provider.__class__.__name__ == "PolandSpecProvider"

# Unit tests for methods of class PolandSpecProvider

# Generated at 2022-06-23 20:42:02.018486
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider(seed=None)
    regexp = re.compile(r'^\d{9}$')
    regon = provider.regon()
    assert regexp.match(regon) is not None

# Generated at 2022-06-23 20:42:06.474650
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    pl_provider = PolandSpecProvider()
    result = pl_provider.nip()
    assert len(result) == 10
    assert '0' not in result
    new_result = pl_provider.nip()
    assert result != new_result


# Generated at 2022-06-23 20:42:08.112851
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider()
    regon = provider.regon()
    assert len(regon) == 9


# Generated at 2022-06-23 20:42:11.048126
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Unit test for method nip of class PolandSpecProvider."""
    assert(PolandSpecProvider().nip() == '1234567891')
    assert(PolandSpecProvider().nip() == '2201011704')


# Generated at 2022-06-23 20:42:14.580269
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    assert test_PolandSpecProvider_pesel("04123112446")
    assert test_PolandSpecProvider_pesel("04123112446", Gender.MALE)
    assert test_PolandSpecProvider_pesel("07111107637", Gender.FEMALE)


# Generated at 2022-06-23 20:42:24.590449
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()
    checksum_count = [int(digit) for digit in pesel]
    # The number of checksums is 11
    assert len(pesel) == 11
    # Checksum verification

# Generated at 2022-06-23 20:42:27.428862
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider('random')
    assert provider.nip() == {'nip': '301602'}  # put here the correct nip


# Generated at 2022-06-23 20:42:32.200508
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    # Create PolandSpecProvider
    provider = PolandSpecProvider()
    print("Test PolandSpecProvider")
    print("Method nip")
    print("\tType of result: %s" % type(provider.nip()))
    print("\tLength of result: %d" % len(provider.nip()))


# Generated at 2022-06-23 20:42:33.852453
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    assert provider.pesel() != provider.pesel()


# Generated at 2022-06-23 20:42:34.386759
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    pass

# Generated at 2022-06-23 20:42:38.251295
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    print('*********PESEL*********')
    seed = 'Seed'
    pesel = PolandSpecProvider(seed=seed)
    pesel_list = []
    i = 0
    while i < 10:
        pesel_gen = pesel.pesel()
        print(pesel_gen)
        pesel_list.append(pesel_gen)
        i += 1


# Generated at 2022-06-23 20:42:41.722438
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    from mimesis.enums import Gender
    from mimesis.builtins import PolandSpecProvider
    provider = PolandSpecProvider()
    assert provider.nip()
    assert provider.nip() != provider.nip()


# Generated at 2022-06-23 20:42:44.851667
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    # Check returns regon with given number of length
    # Given
    p = PolandSpecProvider()
    # When
    result = p.regon()
    # Then
    assert len(result) == 9


# Generated at 2022-06-23 20:42:50.345017
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    poland_provider = PolandSpecProvider()

    assert poland_provider.nip() == poland_provider.nip()
    assert poland_provider.pesel() == poland_provider.pesel()
    assert poland_provider.regon() == poland_provider.regon()

# Generated at 2022-06-23 20:42:56.235566
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    p = PolandSpecProvider()
    pesel = p.pesel()
    assert len(pesel) == 11
    assert int(pesel[2:4]) in range(0, 13)
    assert int(pesel[4:6]) in range(0, 32)
    assert int(pesel[9]) in range(0, 10)

# Generated at 2022-06-23 20:42:56.864922
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    assert PolandSpecProvider()

# Generated at 2022-06-23 20:42:59.754205
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    pl = PolandSpecProvider()
    regon = pl.regon()
    assert len(regon) == 9
    assert regon.isdigit()

# Generated at 2022-06-23 20:43:01.531267
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel(gender=Gender.MALE)
    assert len(pesel) == 11

# Generated at 2022-06-23 20:43:04.063449
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    pl = PolandSpecProvider()
    assert len(pl.nip()) == 10


# Generated at 2022-06-23 20:43:06.661692
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    nip = provider.nip()
    assert len(nip) == 10
    assert isinstance(nip, str)


# Generated at 2022-06-23 20:43:09.372416
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    poland = PolandSpecProvider()
    assert type(poland.nip()) is str
    assert type(poland.pesel()) is str
    assert type(poland.regon()) is str

# Generated at 2022-06-23 20:43:11.024180
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider(seed=1)
    assert provider.regon() == '93418605'


# Generated at 2022-06-23 20:43:15.669956
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    for _ in range(10):
        nip = provider.nip()
        assert (int(nip[0]) == 1 or int(nip[0]) == 2)
        assert int(nip[-1]) != 8
        assert provider.validate_nip(nip) == True



# Generated at 2022-06-23 20:43:17.174946
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Test for constructor."""
    provider = PolandSpecProvider()
    assert provider.locale == 'pl'

# Generated at 2022-06-23 20:43:20.483692
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    r = p.pesel()
    assert len(r) == 11
    assert r.isdecimal() is True

# Generated at 2022-06-23 20:43:25.165819
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    p = PolandSpecProvider() # po osobnych importach jest bardziej czytelne żeby wiedzieć z jaka klasa się komunikujemy
    assertion = '1234567890'
    p.seed(assertion)
    assert p.nip() == assertion


# Generated at 2022-06-23 20:43:31.395164
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Unit test for method nip of class PolandSpecProvider."""
    # Test first example.
    obj = PolandSpecProvider()
    result = obj.nip()
    assert result == '2728477663'
    # Test second example.
    result = obj.nip()
    assert result == '8925152234'
    # Test third example.
    result = obj.nip()
    assert result == '5508670462'


# Generated at 2022-06-23 20:43:34.902505
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    regon_list = []
    for _ in range(100):
        regon_list.append(PolandSpecProvider().regon())

    assert len(regon_list) == 100


# Generated at 2022-06-23 20:43:36.707092
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    p = PolandSpecProvider(1234)
    regon = p.regon()
    assert regon == '834883626'

# Generated at 2022-06-23 20:43:38.746036
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    polandSpecProvider = PolandSpecProvider()
    assert len(polandSpecProvider.pesel()) == 11

# Generated at 2022-06-23 20:43:40.844056
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    assert provider.pesel() == '30081715025'
    assert provider.pesel(1200) == '30081715025'



# Generated at 2022-06-23 20:43:43.576484
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    seed = 4
    poland = PolandSpecProvider(seed)
    regon = poland.regon()
    assert regon == '223395984'
        


# Generated at 2022-06-23 20:43:44.936305
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    psp = PolandSpecProvider()
    assert psp.nip()
    assert psp.pesel()
    assert psp.regon()

# Generated at 2022-06-23 20:43:45.806667
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    # Show the result
    print(PolandSpecProvider(seed=1234).regon())

# Generated at 2022-06-23 20:43:49.889277
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    # Create a PolandSpecProvider instance
    pl_provider = PolandSpecProvider()
    # Generate a random NIP
    nip = pl_provider.nip()
    # Print NIP
    print(nip)
    # Assert length of NIP
    assert len(nip) == 10


# Generated at 2022-06-23 20:43:51.764560
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()
    assert len(pesel) == 11


# Generated at 2022-06-23 20:43:52.992407
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    assert PolandSpecProvider().nip()

# Generated at 2022-06-23 20:43:58.865203
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    from mimesis.enums import Gender
    poland_provider = PolandSpecProvider()
    pesel1 = poland_provider.pesel(birth_date=poland_provider.datetime(year=1952), gender=Gender.MALE)
    pesel2 = poland_provider.pesel(gender=Gender.FEMALE)
    assert len(pesel1) == 11 and len(pesel2) == 11


# Generated at 2022-06-23 20:44:00.880782
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Unit test for class PolandSpecProvider method nip."""
    provider = PolandSpecProvider()
    nip_number = provider.nip()
    assert(len(nip_number) == 10)


# Generated at 2022-06-23 20:44:02.742581
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    poland_provider = PolandSpecProvider()
    assert poland_provider, "Constructor of class PolandSpecProvider does not work"


# Generated at 2022-06-23 20:44:04.513307
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    nip_inst = PolandSpecProvider().nip()  # NIP should be valid
    assert len(nip_inst) == 10


# Generated at 2022-06-23 20:44:12.414183
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():

    # original function
    def pesel_original(birth_date=None, gender=None):
        date_object = birth_date
        if not date_object:
            date_object = self.datetime(1940, 2018)

        year = date_object.date().year
        month = date_object.date().month
        day = date_object.date().day
        pesel_digits = [int(d) for d in str(year)][-2:]

        if 1800 <= year <= 1899:
            month += 80
        elif 2000 <= year <= 2099:
            month += 20
        elif 2100 <= year <= 2199:
            month += 40
        elif 2200 <= year <= 2299:
            month += 60


# Generated at 2022-06-23 20:44:17.996952
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    # test 1
    provider = PolandSpecProvider()
    assert provider.nip() == '7922140073'
    # test 2
    provider = PolandSpecProvider(seed = 42)
    assert provider.nip() == '6729082026'
    # test 3
    provider = PolandSpecProvider()
    assert provider.nip() == '4959347048'
    # test 4
    provider = PolandSpecProvider()
    assert provider.nip() == '2301297037'
    # test 5
    provider = PolandSpecProvider(seed = 42)
    assert provider.nip() == '6729082026'
    # test 6
    provider = PolandSpecProvider(seed = 42)
    assert provider.nip() == '6729082026'
    # test 7
    provider = PolandSpecProvider()


# Generated at 2022-06-23 20:44:22.468995
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    assert len(PolandSpecProvider().pesel()) == 11
    assert PolandSpecProvider().pesel(Datetime().datetime(1986, 1, 1), Gender.FEMALE)[-1] == "8"

# Generated at 2022-06-23 20:44:26.104684
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    # initialize the provider
    provider = PolandSpecProvider()

    # generate a NIP
    nip = provider.nip()

    # check if it is in the expected format
    assert len(nip) == 10 and nip.isdigit()


# Generated at 2022-06-23 20:44:32.197693
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Test for method nip of class PolandSpecProvider"""

    provider = PolandSpecProvider()
    nip = provider.nip()

    # 10-digit NIP
    assert len(nip) == 10

    sum_v = 6 * int(nip[0]) + 5 * int(nip[1]) + 7 * int(nip[2]) + 2 * int(nip[3]) + 3 * int(nip[4]) + 4 * int(nip[5]) + 5 * int(nip[6]) + 6 * int(nip[7]) + 7 * int(nip[8])
    checksum_digit = sum_v % 11
    if checksum_digit > 9:
        checksum_digit = 0

    assert checksum_digit == int(nip[9])



# Generated at 2022-06-23 20:44:36.664469
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Unit tests for method nip of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    assert isinstance(provider.nip(), str)
    assert len(provider.nip()) == 10


# Generated at 2022-06-23 20:44:38.517944
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    d = PolandSpecProvider()
    assert d.provider_name == 'poland_provider'

# Generated at 2022-06-23 20:44:41.438323
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    x = PolandSpecProvider()
    assert x.__class__.__name__ == 'PolandSpecProvider'
    del x



# Generated at 2022-06-23 20:44:42.978226
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    assert PolandSpecProvider().nip() in str('7510001034')


# Generated at 2022-06-23 20:44:45.377733
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    assert len(provider.pesel()) == 11

# Generated at 2022-06-23 20:44:46.879266
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    ps = PolandSpecProvider()
    assert ps is not None
    assert ps.nip() is not None
    assert ps.pesel() is not None
    assert ps.regon() is not None

# Generated at 2022-06-23 20:44:50.080957
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    custom_seed = '1234567890'
    expected_result = '11080066175'
    pesel = PolandSpecProvider(seed=custom_seed).pesel()
    assert pesel == expected_result

# Generated at 2022-06-23 20:44:53.744699
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    p = PolandSpecProvider()
    # test_nip
    assert isinstance(p.nip(), str)
    # test_pesel
    assert isinstance(p.pesel(), str)
    # test_regon
    assert isinstance(p.regon(), str)

# Generated at 2022-06-23 20:44:58.169603
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    pesel = p.pesel()
    digit_list = list(pesel)
    for i in range(0, 10):
        assert i in digit_list, "PESEL musi składać się z 11 cyfr"
    assert len(pesel) == 11, "PESEL musi mieć 11 cyfr"


# Generated at 2022-06-23 20:45:01.349347
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    assert provider.__class__.__name__ == 'PolandSpecProvider'


# Generated at 2022-06-23 20:45:05.533035
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    import datetime
    pl_provider = PolandSpecProvider(seed=1533129735)
    pesel = pl_provider.pesel(birth_date=datetime.datetime(2018, 7, 15, 12, 12))
    assert pesel == '18071512395'

# Generated at 2022-06-23 20:45:07.975407
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    a = PolandSpecProvider(seed=666)
    for _ in range(100):
        assert len(a.nip()) == 10
test_PolandSpecProvider_nip()


# Generated at 2022-06-23 20:45:10.529618
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():

    test_object = PolandSpecProvider()

    assert len(test_object.pesel()) == 11

# Generated at 2022-06-23 20:45:14.511093
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    gender = provider.random.choice([Gender.MALE, Gender.FEMALE])
    pesel = provider.pesel(gender=gender)
    assert len(pesel) == 11


# Generated at 2022-06-23 20:45:22.800329
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    male_pesel = PolandSpecProvider().pesel(gender=Gender.MALE)
    assert male_pesel[9] in {'1', '3', '5', '7', '9'}
    female_pesel = PolandSpecProvider().pesel(gender=Gender.FEMALE)
    assert female_pesel[9] in {'0', '2', '4', '6', '8'}
    neutral_pesel = PolandSpecProvider().pesel(gender=Gender.NEUTRAL)
    assert neutral_pesel[9] not in {'', '1', '3', '5', '7', '9', '0', '2', '4', '6', '8'}

# Generated at 2022-06-23 20:45:27.519432
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test pesel method."""
    pl_provider = PolandSpecProvider(seed='262693927')
    pesel = pl_provider.pesel(birth_date = Datetime().datetime(2000, 2000), gender = None)
    assert pesel == '00120432380'


# Generated at 2022-06-23 20:45:29.906210
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    poland = PolandSpecProvider()
    assert poland.regon() == '677522610'



# Generated at 2022-06-23 20:45:30.776816
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    PolandSpecProvider.pesel()

# Generated at 2022-06-23 20:45:32.387086
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    b = PolandSpecProvider()
    r = b.regon()
    assert len(r) == 9

# Generated at 2022-06-23 20:45:34.587684
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    if PolandSpecProvider().nip() == PolandSpecProvider().nip():
        return True
    else:
        return False


# Generated at 2022-06-23 20:45:37.000444
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Unit test method nip of class PolandSpecProvider.

    :return:
    """
    PolandSpecProvider().nip()


# Generated at 2022-06-23 20:45:40.926924
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    print("Test constructor of class PolandSpecProvider")
    provider = PolandSpecProvider(seed=3)
    assert provider.add_formats('region', ['{{region_pl.name}}'])
    assert provider.add_formats('address', ['{{address.region}}'])
    print("Done.\n")


# Generated at 2022-06-23 20:45:42.563899
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pl = PolandSpecProvider.__new__(PolandSpecProvider)
    pesel = pl.pesel()
    assert len(pesel) == 11


# Generated at 2022-06-23 20:45:50.912652
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Unit test for method nip of class PolandSpecProvider"""
    prov = PolandSpecProvider()

    assert len(prov.nip()) == 10
    assert prov.nip()[0] in '123456789'
    assert prov.nip()[1] == '0'
    assert prov.nip()[2] in '0123456789'
    assert prov.nip()[3] in '0123456789'
    assert prov.nip()[4] in '0123456789'
    assert prov.nip()[5] in '0123456789'
    assert prov.nip()[6] in '0123456789'
    assert prov.nip()[7] in '0123456789'

# Generated at 2022-06-23 20:45:56.113997
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    obj = PolandSpecProvider()

    for i in range(10):
        result = obj.nip()
        print(result, len(str(result)))

    obj = PolandSpecProvider(seed=123)

    for i in range(10):
        result = obj.nip()
        print(result, len(str(result)))


# Generated at 2022-06-23 20:46:04.878651
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """
        Unit test for method regon of class PolandSpecProvider.
    """
    provider = PolandSpecProvider()
    regon = provider.regon()
    assert len(regon) == 9
    regon_int = int(regon)
    assert 0 < regon_int < 10**9
    regon_coeffs = (8, 9, 2, 3, 4, 5, 6, 7)
    regon_digits = [int(regon_int // (10 ** i) % 10) for i in range(9)]
    sum_v = sum([nc * nd for nc, nd in zip(regon_coeffs, regon_digits)])
    checksum_digit = sum_v % 11
    if checksum_digit > 9:
        checksum_digit = 0

# Generated at 2022-06-23 20:46:13.547610
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Test function nip of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    test_nip = provider.nip()
    print(test_nip)
    nip_digits = [int(d) for d in test_nip]
    nip_coefficients = (6, 5, 7, 2, 3, 4, 5, 6, 7)
    sum_v = sum([nc * nd for nc, nd in zip(nip_coefficients, nip_digits)])
    checksum_digit = sum_v % 11
    print(checksum_digit)
    assert str(checksum_digit) == test_nip[-1]


# Generated at 2022-06-23 20:46:22.954629
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Testing function regon and nip"""

    a = PolandSpecProvider()
    b = PolandSpecProvider()
    c = PolandSpecProvider()
    d = PolandSpecProvider()
    e = PolandSpecProvider()
    test_cases = [a.regon(), b.regon(), c.regon(), d.regon(), e.regon()]
    assert len(test_cases[0]) == 9
    assert len(test_cases[1]) == 9
    assert len(test_cases[2]) == 9
    assert len(test_cases[3]) == 9
    assert len(test_cases[4]) == 9

    test_cases_1 = [a.nip(), b.nip(), c.nip(), d.nip(), e.nip()]
    assert len(test_cases_1[0]) == 10

# Generated at 2022-06-23 20:46:23.891622
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    assert provider.locale == 'pl'


# Generated at 2022-06-23 20:46:25.309846
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    nip = provider.nip()
    assert len(nip) == 10



# Generated at 2022-06-23 20:46:27.273707
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Unit test for constructor of class PolandSpecProvider."""
    assert PolandSpecProvider()



# Generated at 2022-06-23 20:46:31.896291
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    '''
    Function that tests regon method of PolandSpecProvider class.
    '''

    pl = PolandSpecProvider()
    # We create a list in which we store the number of characters that will
    # be tested, so as to increase the coverage of the code.
    list_of_chars_tested = [9]
    for i in range(list_of_chars_tested[0]):
        assert len(pl.regon()) == i + 1

# Generated at 2022-06-23 20:46:41.447352
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    p = PolandSpecProvider()
    for _ in range(100):
        n = p.nip()
        assert len(n) == 10
        assert all(x.isdigit() for x in n)
        nip_coeffs = (6, 5, 7, 2, 3, 4, 5, 6, 7)
        n_digits = [int(x) for x in n]
        sum_v = sum([x * y for x, y in zip(nip_coeffs, n_digits)]) % 11
        assert n_digits[9] == sum_v or n_digits[9] == sum_v % 10
        

# Generated at 2022-06-23 20:46:48.965942
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    pl = PolandSpecProvider(seed=123)

    assert pl.nip() == '9461547256'
    assert pl.nip() == '6874697020'
    assert pl.nip() == '9234567315'
    assert pl.nip() == '3255820675'
    assert pl.nip() == '9484040609'
    assert pl.nip() == '2972130673'
    assert pl.nip() == '2708645032'
    assert pl.nip() == '1698800298'
    assert pl.nip() == '9395570950'
    assert pl.nip() == '4114188522'


# Generated at 2022-06-23 20:46:51.494754
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    a = PolandSpecProvider(seed=1)
    x = a.regon()
    assert len(x) == 9


# Generated at 2022-06-23 20:46:55.290277
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    nip1 = PolandSpecProvider().nip()
    assert nip1
    assert isinstance(nip1, str)
    assert len(nip1) == 10

# pylint: disable=unused-argument

# Generated at 2022-06-23 20:46:58.815599
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    test_data = provider.nip()
    assert len(test_data) == 10
    assert test_data.isdigit()
    assert provider.pesel().isdigit()
    assert provider.regon().isdigit()

# Generated at 2022-06-23 20:46:59.697356
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    assert bool(PolandSpecProvider) == True


# Generated at 2022-06-23 20:47:04.462512
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """
    Test for constructor of PolandSpecProvider class
    """
    my_PolandSpecProvider = PolandSpecProvider(seed=10)

    assert(
        my_PolandSpecProvider.nip() == '3885963200'
    ), 'test_PolandSpecProvider has a mistake'
    assert(
        my_PolandSpecProvider.pesel(birth_date='2000-01-01 00:00:00',
                                    gender='MALE') == '00022763723'
    ), 'test_PolandSpecProvider has a mistake'
    assert(
        my_PolandSpecProvider.regon() == '342809190'
    ), 'test_PolandSpecProvider has a mistake'


# Generated at 2022-06-23 20:47:06.372521
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    seed = "1234"
    assert PolandSpecProvider(seed=seed) is not None

# Generated at 2022-06-23 20:47:11.582980
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    obj = PolandSpecProvider()
    assert obj.pesel() != obj.pesel()
    assert obj.pesel(birth_date = '2000-01-01')[:6] == '000101'
    assert obj.pesel(gender = Gender.MALE)[-1] == '1'
    assert obj.pesel(gender = Gender.FEMALE)[-1] == '0'