

# Generated at 2022-06-23 20:37:11.117125
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    p = PolandSpecProvider(seed=12345)
    assert p.nip() == '8498013721'


# Generated at 2022-06-23 20:37:13.450352
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    for i in range(10):
        assert len(provider.nip()) == 10


# Generated at 2022-06-23 20:37:15.751167
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    regon = PolandSpecProvider().regon()
    assert len(regon) == 9


# Generated at 2022-06-23 20:37:17.183896
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    PolandSpecProvider.regon()

# Generated at 2022-06-23 20:37:18.151533
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    assert len(PolandSpecProvider().pesel()) == 11

# Generated at 2022-06-23 20:37:19.580338
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    result = PolandSpecProvider().pesel()
    assert len(result) == 11
    assert result.isdigit()

# Generated at 2022-06-23 20:37:22.556028
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    import random
    r = random.seed(42)
    print(PolandSpecProvider().regon())


# Generated at 2022-06-23 20:37:24.683561
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    from mimesis.builtins import PolandSpecProvider
    ps = PolandSpecProvider()
    print(ps.nip())
    print(ps.nip())
    

# Generated at 2022-06-23 20:37:26.741009
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Test class PolandSpecProvider."""
    provider = PolandSpecProvider()
    assert provider

# Unit tests for methods of class PolandSpecProvider

# Generated at 2022-06-23 20:37:31.202543
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    poland_spec_provider = PolandSpecProvider(seed=11)
    assert poland_spec_provider.nip() == "1970726681"
    assert poland_spec_provider.pesel() == "88513211007"
    assert poland_spec_provider.regon() == "56374266"

# Generated at 2022-06-23 20:37:38.932570
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    # regon
    regon_num = provider.regon()
    assert isinstance(regon_num, str)
    assert len(regon_num) == 9
    # pesel
    pesel_num = provider.pesel()
    assert isinstance(pesel_num, str)
    assert len(pesel_num) == 11
    # nip
    nip_num = provider.nip()
    assert isinstance(nip_num, str)
    assert len(nip_num) == 10

# Generated at 2022-06-23 20:37:40.138472
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    pesel = p.pesel()
    assert len(pesel) == 11

# Generated at 2022-06-23 20:37:41.535246
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    nip = PolandSpecProvider().nip()
    print(nip)


# Generated at 2022-06-23 20:37:42.924849
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    P = PolandSpecProvider()
    assert len(P.pesel()) == 11 # Pesel should be exactly 11 digits

# Generated at 2022-06-23 20:37:44.246467
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    p = PolandSpecProvider()
    regon = p.regon()
    assert regon == "845968687"

# Generated at 2022-06-23 20:37:47.371723
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    # GIVEN: Instance of provider
    provider = PolandSpecProvider()

    # WHEN: We get pesel
    pesel = provider.pesel()

    # THEN: Length is correct
    try:
        assert len(pesel) == 11
    except AssertionError:
        print(pesel)
        raise

# Generated at 2022-06-23 20:37:54.833739
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel(birth_date = '1995-03-18 08:00', gender=Gender.MALE)
    print(pesel)
    assert int(pesel[0:2]) == 1995, 'Pesel year is wrong'
    assert int(pesel[2:4]) == 3, 'Pesel month is wrong'
    assert int(pesel[4:6]) == 18, 'Pesel day is wrong'
    assert int(pesel[6:9]) >= 0, 'Pesel individual number is wrong'
    assert int(pesel[9:10]) == 1, 'Pesel gender is wrong'
    assert int(pesel[10:11]) >= 0, 'Pesel check sum is wrong'

# Generated at 2022-06-23 20:37:56.371053
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Test if generator generates correct regon."""
    assert PolandSpecProvider().regon() == '366113026'

# Generated at 2022-06-23 20:37:57.599176
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    assert PolandSpecProvider().regon() == "990156391"

# Generated at 2022-06-23 20:38:03.953526
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    import random

    seed = random.randrange(1, 101)

    psp0 = PolandSpecProvider(seed)
    psp = PolandSpecProvider()

    pesel_M = psp0.pesel(gender = Gender.MALE)
    pesel_F = psp0.pesel(gender = Gender.FEMALE)

    r_pesel_M = psp.pesel(gender = Gender.MALE)
    r_pesel_F = psp.pesel(gender = Gender.FEMALE)

    assert (len(pesel_M) == 11 and len(pesel_F) == 11)
    assert (len(r_pesel_M) == 11 and len(r_pesel_F) == 11)

    assert pesel_M == r_pesel_M

# Generated at 2022-06-23 20:38:13.900724
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    from mimesis.enums import Gender
    from mimesis.providers import PolandSpecProvider
    from mimesis.providers._utils import set_seed

    set_seed(2)
    pl_provider = PolandSpecProvider()
    assert(pl_provider.nip()) == "8281698956"
    assert(pl_provider.pesel(birth_date=pl_provider.datetime(2000, 2000))) == "00170651352"
    assert(pl_provider.pesel(gender=Gender.MALE)) == "78608622839"
    assert(pl_provider.pesel(gender=Gender.FEMALE)) == "24106989457"
    assert(pl_provider.pesel()) == "15100825465"
    assert(pl_provider.regon())

# Generated at 2022-06-23 20:38:19.717305
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    # Testing method pesel of class PolandSpecProvider
    pesel = p.pesel()
    assert pesel == p.pesel()
    assert isinstance(pesel, str)
    assert len(pesel) == 11
    assert pesel == p.pesel(birth_date=p.datetime())
    assert pesel == p.pesel(birth_date=p.datetime, gender=Gender.MALE)
    assert pesel == p.pesel(birth_date=p.datetime, gender=Gender.FEMALE)

test_PolandSpecProvider_pesel()


# Generated at 2022-06-23 20:38:21.511781
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    polishprovider = PolandSpecProvider()
    assert len(polishprovider.regon()) == 9

# Generated at 2022-06-23 20:38:28.681972
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # PESEL of Barack Obama
    pesel_of_barack_obama = '19401101723'
    # PESEL of Angela Merkel
    pesel_of_angela_merkel = '19541218056'

    # Generate data for Barack Obama
    provider = PolandSpecProvider()
    gender = Gender.MALE

# Generated at 2022-06-23 20:38:30.360212
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    pl = PolandSpecProvider()
    assert pl.nip() != pl.nip()
    assert pl.pesel() != pl.pesel()
    assert pl.regon() != pl.regon()

# Generated at 2022-06-23 20:38:31.653549
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    result = PolandSpecProvider().nip()
    assert len(result) == 10
    assert result == '5511540064'


# Generated at 2022-06-23 20:38:33.611082
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    from mimesis.enums import Gender

    poland = PolandSpecProvider()
    print(poland.regon())


# Generated at 2022-06-23 20:38:43.692185
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    import random
    for i in range(1000):
        a = PolandSpecProvider(random.random())
        regon = a.regon()
        assert(regon is not None)
        assert(regon[0].isdigit())
        assert(regon[1].isdigit())
        assert(regon[2].isdigit())
        assert(regon[3].isdigit())
        assert(regon[4].isdigit())
        assert(regon[5].isdigit())
        assert(regon[6].isdigit())
        assert(regon[7].isdigit())
        assert(regon[8].isdigit())
        assert(regon[9].isdigit())


# Generated at 2022-06-23 20:38:45.926162
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    loc = PolandSpecProvider()
    regon_expected = '430537994'
    assert regon_expected == loc.regon()


# Generated at 2022-06-23 20:38:48.800183
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider(seed=123)
    pesel = provider.pesel(birth_date='2010-01-02', gender=Gender.MALE)
    assert pesel == '10012301388'

# Generated at 2022-06-23 20:38:50.245909
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    assert len(PolandSpecProvider().nip()) == 10


# Generated at 2022-06-23 20:38:52.462717
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    pesel=PolandSpecProvider()
    assert pesel.nip()
    assert pesel.pesel()
    assert pesel.regon()

# Generated at 2022-06-23 20:38:54.627118
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    nip1 = PolandSpecProvider().nip()
    print('NIP: {}'.format(nip1))
    # NIP: 5911235888


# Generated at 2022-06-23 20:38:55.404921
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    _ = PolandSpecProvider()

# Generated at 2022-06-23 20:39:00.060775
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()
    assert len(pesel) == 11
    assert int(pesel[2]) >= 4
    assert int(pesel[2]) <= 3
    assert int(pesel[4]) <= 2
    assert int(pesel[4]) >= 1


# Generated at 2022-06-23 20:39:02.378994
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    regon = PolandSpecProvider().regon()
    assert isinstance(regon, str)
    assert len(regon) == 9


# Generated at 2022-06-23 20:39:04.065581
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Unit test for method regon of class PolandSpecProvider"""

    provider = PolandSpecProvider(seed=1)
    result = provider.regon()
    assert result == '211026294'

# Generated at 2022-06-23 20:39:10.962887
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """
    Check nip method of class PolandSpecProvider
    """
    provider = PolandSpecProvider(seed=12345)
    assert provider.nip() == '9242615093'
    assert provider.nip() == '9509826131'
    assert provider.nip() == '9672434308'
    assert provider.nip() == '6450249984'
    assert provider.nip() == '5471358299'
    assert provider.nip() == '6337739476'
    assert provider.nip() == '9672434308'
    assert provider.nip() == '6450249984'
    assert provider.nip() == '5471358299'
    assert provider.nip() == '6337739476'


# Generated at 2022-06-23 20:39:12.853016
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    p = PolandSpecProvider()
    assert len(p.nip()) == 10, "The length of NIP should be equal to 10"


# Generated at 2022-06-23 20:39:17.390601
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    from . import poland_provider
    pl = poland_provider(seed=123456)
    pesel = pl.pesel()
    assert pesel == '98100443963'

# Generated at 2022-06-23 20:39:20.155232
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()
    assert len(pesel)==11
    assert ''.join('34567890123456789012')[:11] == pesel
    
    

# Generated at 2022-06-23 20:39:21.031227
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    assert len(PolandSpecProvider().regon()) == 9

# Generated at 2022-06-23 20:39:22.882019
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    import doctest
    doctest.testmod(name='PolandSpecProvider_pesel', verbose=True)



# Generated at 2022-06-23 20:39:25.148312
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Unit test for method nip of class PolandSpecProvider."""

    p = PolandSpecProvider(seed=1)
    assert p.nip() == '7972165467'


# Generated at 2022-06-23 20:39:26.420507
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider('1')
    provider.nip()
    pass

# Generated at 2022-06-23 20:39:31.005090
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    from mimesis import PolandSpecProvider
    from datetime import datetime
    poland = PolandSpecProvider()
    assert len(poland.pesel()) == 11
    assert len(poland.pesel(gender=poland.gender.female())) == 11
    assert poland.pesel() != poland.pesel(gender=poland.gender.female())
    assert len(poland.pesel(poland.datetime.datetime())) == 11
    assert len(poland.pesel(poland.datetime.datetime(gender=poland.gender.female()))) == 11

# Generated at 2022-06-23 20:39:35.599221
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    assert provider.nip() == "6371594687"
    assert provider.pesel() == "56122839296"
    assert provider.regon() == "319014995"


# Generated at 2022-06-23 20:39:41.116034
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Checking the correctness of method regon of PolandSpecProvider."""
    from mimesis.enums import Gender
    from mimesis.providers.poland import PolandSpecProvider

    f = PolandSpecProvider(seed=12345)
    assert f.regon() == '856123376'
    assert f.regon() == '859759561'
    assert f.regon() == '858741223'
    assert f.regon() == '856120936'
    assert f.regon() == '859759420'



# Generated at 2022-06-23 20:39:49.499909
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    from random import seed
    from datetime import date
    from mimesis.enums import Gender

    seed(123)
    p1 = PolandSpecProvider()
    p2 = PolandSpecProvider()
    p2.seed(123)

    assert (len(p1.pesel()) == 11)
    assert (p1.pesel(date(1996, 4, 20), Gender.MALE) == '96042033302')
    assert (p1.pesel(date(1996, 4, 20), Gender.FEMALE) == '96042025905')
    assert (p1.pesel(date(1996, 4, 20), Gender.NOT_SPECIFIED) == '96042048107')

# Generated at 2022-06-23 20:39:53.923277
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    tests = [
        {
            "locale": 'pl',
            "seed": None,
        }
    ]

    for test_case in tests:
        p = PolandSpecProvider(seed=test_case["seed"])
        assert p.locale == test_case["locale"]
        # assert p.seed


# Generated at 2022-06-23 20:39:56.923712
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    test_pesel = provider.pesel(birth_date=provider.datetime(2020, 12),gender=Gender.FEMALE)
    assert test_pesel == '2044121944'

# Generated at 2022-06-23 20:39:58.036205
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    assert isinstance(PolandSpecProvider().regon(), str)

# Generated at 2022-06-23 20:40:05.107427
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Unit test for method regon of class PolandSpecProvider."""
    from unittest import TestCase
    from random import seed

    from mimesis.providers.pl import PolandSpecProvider

    seed(0xDEADBEEF)
    regon_1 = PolandSpecProvider().regon()
    # '893850365'
    seed(0xDEADBEEF)
    regon_2 = PolandSpecProvider().regon()
    # '893850365'

    test_case = TestCase()
    test_case.assertEqual(regon_1, regon_2)



# Generated at 2022-06-23 20:40:09.888100
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Test method regon of class PolandSpecProvider."""
    test_regon = PolandSpecProvider().regon()
    assert type(test_regon) == str
    assert len(test_regon) == 9


# Generated at 2022-06-23 20:40:11.741342
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    regon = PolandSpecProvider().regon()
    assert len(regon) == 9
    assert list(map(lambda x: str(x).isdigit(), regon)) == 9 * [True]


# Generated at 2022-06-23 20:40:12.802863
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    test = PolandSpecProvider()
    assert test.nip() != None
    assert test.pesel() != None
    assert test.regon() != None

# Generated at 2022-06-23 20:40:14.498217
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    obj = PolandSpecProvider()



# Generated at 2022-06-23 20:40:17.086676
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    for _ in range(5):
        assert PolandSpecProvider().pesel().isdigit()
        assert 6 <= len(PolandSpecProvider().pesel()) <= 10


# Generated at 2022-06-23 20:40:19.155250
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Unit test for constructor of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    assert hasattr(provider, 'random')

# Generated at 2022-06-23 20:40:28.508859
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    pl = PolandSpecProvider()
    nip = pl.nip()
    nip_digits = [int(d) for d in nip]
    nip_coefficients = (6, 5, 7, 2, 3, 4, 5, 6, 7)
    sum_v = sum([nc * nd for nc, nd in zip(nip_coefficients, nip_digits[:9])])
    checksum_digit = sum_v % 11
    if checksum_digit > 9:
        return False
    if checksum_digit == nip_digits[-1]:
        return True
    return False


# Generated at 2022-06-23 20:40:31.898320
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test the method pesel of class PolandSpecProvider."""
    seed = "2d737d65-00e9-11ea-bb37-0242ac130002"
    expected = "75150717074"

    provider = PolandSpecProvider(seed=seed)
    result = provider.pesel(birth_date=Datetime().datetime(1975, 1, 1))

    assert result == expected

# Generated at 2022-06-23 20:40:33.464743
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    assert len(provider.nip()) == 10


# Generated at 2022-06-23 20:40:43.549596
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Test for method regon of class PolandSpecProvider in file poland_provider.py.
    This test is skipped, because of randomness """

    print('\ntest_PolandSpecProvider_regon')
    # Check regon method for 5 times
    for i in range(5):
        # Get one REGON from the regon method
        regon1 = PolandSpecProvider().regon()
        # Get another REGON from the regon method
        regon2 = PolandSpecProvider().regon()
        # Check REGONs are different
        assert regon1 != regon2
        # Check REGON has length nine
        assert len(regon1) == 9
        # Check REGON has length nine
        assert len(regon2) == 9
    print('Passed test for method regon')


# Generated at 2022-06-23 20:40:46.216103
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    psp = PolandSpecProvider(seed=1)
    regon = psp.regon()
    assert regon == '507938150'


# Generated at 2022-06-23 20:40:54.246647
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    from mimesis.enums import Gender
    from mimesis.providers import PolandSpecProvider
    from mimesis.typing import Seed
    seed = Seed(1)
    poland_spec_provider = PolandSpecProvider(seed=seed)
    s_default = poland_spec_provider.regon()
    assert(s_default == "80006691")

    s_default = poland_spec_provider.regon()
    assert(s_default == "85030355")



# Generated at 2022-06-23 20:40:55.669315
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    assert type(PolandSpecProvider()) == PolandSpecProvider


# Generated at 2022-06-23 20:40:57.125844
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    test = PolandSpecProvider()
    test.create_dummy()
    assert test.__doc__

# Generated at 2022-06-23 20:40:59.032359
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    p = PolandSpecProvider()
    regon = p.regon()
    # print(regon)
    assert len(regon) == 9

# Generated at 2022-06-23 20:41:01.558278
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    from mimesis.enums import Gender
    from mimesis.providers.datetime import Datetime

    a = PolandSpecProvider(seed=1234)
    for _ in range(10):
        print(a.regon())
    a.seed(1234)
    print(a.regon())

# Generated at 2022-06-23 20:41:07.931345
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_provider = PolandSpecProvider()
    pesel_1 = poland_provider.pesel(gender=Gender.MALE)
    pesel_2 = poland_provider.pesel()

    assert (len(pesel_1) == len(pesel_2) == 11)
    assert (pesel_1 != pesel_2)


# Generated at 2022-06-23 20:41:11.574455
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    p = provider.pesel()
    assert p == provider.pesel()
    assert p == provider.pesel()

# Generated at 2022-06-23 20:41:14.176723
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pl = PolandSpecProvider()
    check = str(pl.pesel())

    assert(check is not None)
    assert(len(check) == 11)


# Generated at 2022-06-23 20:41:16.317890
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    params = PolandSpecProvider()
    assert params.nip() is not None
    assert params.regon() is not None
    assert params.pesel() is not None

# Generated at 2022-06-23 20:41:25.110399
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Check if the regon method of PolandSpecProvider returns the expected value."""
    provider = PolandSpecProvider()
    for i in range(0, 100):
        if i % 10 == 0:
            print('i = ' + str(i))
        regon = provider.regon()
        assert 9 == len(regon)
        product = 0
        for j in range(0, len(regon)):
            x = int(regon[j])
            if j < 7:
                y = 8 - j
            else:
                y = 9
            product += x*y
        result = product % 11
        if result > 9:
            result = 0
        assert result == int(regon[8])


# Generated at 2022-06-23 20:41:35.408970
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    pr = PolandSpecProvider()
    regon = pr.regon()
    regon_list = []
    for i in range(9):
        regon_list.append(regon[i])
    regon_int = [int(i) for i in regon_list]
    regon_coeffs = (8, 9, 2, 3, 4, 5, 6, 7)
    regon_sum_v = sum([nc * nd for nc, nd in zip(regon_coeffs, regon_int)])
    regon_checksum_digit = regon_sum_v % 11
    if regon_checksum_digit > 9:
        regon_checksum_digit = 0
    regon_int.append(regon_checksum_digit)

# Generated at 2022-06-23 20:41:36.890415
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    assert PolandSpecProvider.Meta.name == 'poland_provider'


# Generated at 2022-06-23 20:41:38.971216
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    assert provider.nip() == "8782032719"


# Generated at 2022-06-23 20:41:41.514534
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Test if regon method returns a valid 9-digit REGON."""
    provider = PolandSpecProvider()
    regon = provider.regon()
    assert len(regon) == 9, "The REGON returned is not valid."

# Generated at 2022-06-23 20:41:43.663939
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    p = PolandSpecProvider()
    print(p.nip())
    print(p.pesel())
    print(p.regon())

if __name__ == '__main__':
    test_PolandSpecProvider()

# Generated at 2022-06-23 20:41:46.120819
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pl_provider = PolandSpecProvider(seed=4)
    pesel = pl_provider.pesel()
    assert "6810053891" == pesel


# Generated at 2022-06-23 20:41:47.657141
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    p = PolandSpecProvider(seed=42)
    assert p.seed == 42
    

# Generated at 2022-06-23 20:41:52.924595
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Test docstring example of method nip of class PolandSpecProvider."""
    poland = PolandSpecProvider()
    nip = poland.nip()
    assert len(nip) == 10
    assert int(nip[:3]) >= 100 and int(nip[:3]) <= 998


# Generated at 2022-06-23 20:41:58.324743
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider()
    result = provider.regon()
    assert len(result) == 9

    all_numbers_in_range = True
    for number in result:
        if int(number) < 0 or int(number) > 9:
            all_numbers_in_range = False
    assert all_numbers_in_range == True



# Generated at 2022-06-23 20:41:58.765589
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    PolandSpecProvider()

# Generated at 2022-06-23 20:42:04.956247
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():

    from mimesis import PolandSpecProvider, Person
    import datetime
    pl = PolandSpecProvider()
    person = Person('pl')
    birth_date = datetime.datetime(1998,9,4)
    pesel = pl.pesel(birth_date, Gender.MALE)
    print(pesel)
    assert len(pesel) == 11
    assert person.gender()=='male'
    assert pl.birth_date()=='1998-09-04'
    assert pl.month()=='09'
    assert pl.year()=='1998'
    assert pl.day()=='04'
    assert pl.phone_number()=='+48 789 822-766'
    assert pl.postal_code()=='500-79'
    assert pl.city()=='Kraków'


# Generated at 2022-06-23 20:42:06.756749
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()

    assert len(provider.nip()) == 10


# Generated at 2022-06-23 20:42:13.239015
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    from mimesis.enums import Gender
    from mimesis.typing import Seed

    p = PolandSpecProvider(seed=Seed(314159))
    pesel_male = p.pesel(gender=Gender.MALE)
    isinstance(pesel_male, str)
    assert len(pesel_male) == 11

    pesel_female = p.pesel(gender=Gender.FEMALE)
    isinstance(pesel_female, str)
    assert len(pesel_female) == 11

    pesel = p.pesel()
    isinstance(pesel, str)
    assert len(pesel) == 11



# Generated at 2022-06-23 20:42:16.662089
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Unit test for constructor of class PolandSpecProvider."""
    pl = PolandSpecProvider(seed=4321)
    assert pl.__class__.__name__ == 'PolandSpecProvider'

# Generated at 2022-06-23 20:42:20.134945
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    poland_spec = PolandSpecProvider()
    nip = poland_spec.nip()
    assert nip == '1234567890'


# Generated at 2022-06-23 20:42:20.968135
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider()
    regon = provider.regon()
    assert len(regon) == 9


# Generated at 2022-06-23 20:42:21.646572
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    p = PolandSpecProvider()
    assert p is not None


# Generated at 2022-06-23 20:42:25.344213
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    # Polish standard REGON codes are 9 digit numbers
    # Output value should be a string with lenght 9
    for i in range(100):
        code = PolandSpecProvider().regon()
        assert len(code) == 9, 'Code: %s, lenght: %d' % (code, len(code))
        assert code.isdigit(), 'Code: %s is not a number' % code


# Generated at 2022-06-23 20:42:27.731731
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Unit test for class PolandSpecProvider."""
    obj = PolandSpecProvider()
    assert obj._locales == ['pl']


# Generated at 2022-06-23 20:42:31.382801
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    p = PolandSpecProvider()
    assert len(p.nip()) == 10



# Generated at 2022-06-23 20:42:34.413019
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    # Initialization of PolandSpecProvider
    provider = PolandSpecProvider()

    # nip()
    assert len(provider.nip()) == 10
    assert provider._validate_nip(provider.nip())


# Generated at 2022-06-23 20:42:36.798655
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()
    assert isinstance(pesel, str)
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-23 20:42:39.536451
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    p = PolandSpecProvider()
    assert p != None
    # Unit test for nip
    nip = p.nip()
    assert nip != None
    # Unit test for pesel
    p.pesel()
    assert p != None
    # Unit test for regon
    p.regon()
    assert p != None

# Generated at 2022-06-23 20:42:46.592886
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    from mimesis.providers.person import Person
    from mimesis.builtins.pl import PolandSpecProvider
    from mimesis.enums import Gender

    p = Person('pl')
    pl = PolandSpecProvider()

    male_pesel = ''.join(map(str, pl.pesel(gender=Gender.MALE)))
    assert p.gender(male_pesel) == 'Male'

    female_pesel = ''.join(map(str, pl.pesel(gender=Gender.FEMALE)))
    assert p.gender(female_pesel) == 'Female'

# Generated at 2022-06-23 20:42:57.261991
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel_1 = PolandSpecProvider().pesel()
    if len(pesel_1) != 11:
        raise EnvironmentError("Pesel should be 11-digits long")

    pesel_2 = PolandSpecProvider().pesel(gender=Gender.MALE)
    if not pesel_2[10] in ["1", "3", "5", "7", "9"]:
        raise EnvironmentError("Last digit of Pesel should be set to [1, 3, 5, 7, 9] for males")

    pesel_3 = PolandSpecProvider().pesel(gender=Gender.FEMALE)

# Generated at 2022-06-23 20:43:00.907615
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Test Regon function in PolandSpecProvider class."""
    p = PolandSpecProvider()
    assert len(p.regon()) == 9
    # TODO: assert if it is a valid regon
    # print(p.regon())


# Generated at 2022-06-23 20:43:11.735799
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    regon = PolandSpecProvider().regon()
    print(regon)
    if (len(regon) != 9):
        return -1
    if (not regon.isdigit()):
        return -2
    regon_digits = [int(d) for d in str(regon)]
    regon_coeffs = (8, 9, 2, 3, 4, 5, 6, 7)
    sum_v = sum([nc * nd for nc, nd in
                 zip(regon_coeffs, regon_digits)])
    checksum_digit = sum_v % 11
    if checksum_digit > 9:
        checksum_digit = 0
    if (checksum_digit != regon_digits[8]):
        return -3;
    

# Generated at 2022-06-23 20:43:13.016234
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider()
    regon = provider.regon()
    print(regon)
    assert len(regon) == 9


# Generated at 2022-06-23 20:43:14.970018
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    a = PolandSpecProvider()
    b = a.pesel(birth_date=None,gender=None)
    print(b)


# Generated at 2022-06-23 20:43:17.045706
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    import pytest

    @pytest.mark.parametrize('expected', [
        '0123456789',
        '0123456785',
        '0123456781',
        '0123456786',
        '0123456782'
        ])
    def test(expected):
        assert PolandSpecProvider().nip() == expected



# Generated at 2022-06-23 20:43:18.671924
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    PolandSpecProvider()

# Generated at 2022-06-23 20:43:20.694480
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider()
    assert len(provider.regon()) == 9



# Generated at 2022-06-23 20:43:23.407975
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    import pytest
    result = PolandSpecProvider(seed=0).pesel(birth_date= None, gender= None)
    assert result == '23060746839'

# Generated at 2022-06-23 20:43:26.271378
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    print(pesel)

if __name__ == '__main__':
    test_PolandSpecProvider_pesel()

# Generated at 2022-06-23 20:43:31.344298
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    provider = PolandSpecProvider(seed = '123456789')
    #print(provider.nip())
    #print(provider.pesel(gender=Gender.FEMALE))
    print(provider.regon())


if __name__ == '__main__':
    test_PolandSpecProvider()

# Generated at 2022-06-23 20:43:37.062532
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    test_nip = provider.nip()
    test_regon = provider.regon()
    test_pesel = provider.pesel()
    assert test_nip == '7531243380'
    assert test_regon == '172968563'
    assert test_pesel == '66010911215'

# Generated at 2022-06-23 20:43:41.403182
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel in class PolandSpecProvider"""

    provider = PolandSpecProvider()
    assert provider.pesel() == provider.pesel()
    assert provider.pesel(gender=Gender.MALE) != provider.pesel(gender=Gender.FEMALE)
    assert provider.pesel(gender=Gender.MALE).index(str(1)) == 9
    assert provider.pesel(gender=Gender.FEMALE).index(str(0)) == 9
    assert len(provider.pesel()) == 11


# Generated at 2022-06-23 20:43:42.327536
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    val = PolandSpecProvider().pesel()
    assert val != None


# Generated at 2022-06-23 20:43:45.728111
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider(seed=68)
    pesel = provider.pesel(gender=Gender.MALE)
    assert pesel == '05121982330'


# Generated at 2022-06-23 20:43:55.222938
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Test method nip of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    random_nip = provider.nip()
    random_nip_list = [int(n) for n in str(random_nip)]

    assert len(random_nip) == 10

    nip_coefficients = (6, 5, 7, 2, 3, 4, 5, 6, 7)
    check_sum = sum([nc * nd for nc, nd in
                     zip(nip_coefficients, random_nip_list[:9])])
    check_sum %= 11
    if check_sum > 9:
        check_sum = 0
    assert check_sum == random_nip_list[9]


# Generated at 2022-06-23 20:43:57.129088
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    poland = PolandSpecProvider()
    poland.seed(1)
    assert poland.nip() == '5557767005'


# Generated at 2022-06-23 20:43:58.298417
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    psp = PolandSpecProvider()
    print(psp.regon())


# Generated at 2022-06-23 20:44:00.024340
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Testing regon"""
    if __name__ == '__main__':
        print(PolandSpecProvider().regon())


# Generated at 2022-06-23 20:44:01.474375
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    p = PolandSpecProvider()
    assert p.nip() != p.nip()


# Generated at 2022-06-23 20:44:04.731619
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    # Execute method pesel of class PolandSpecProvider
    result = provider.pesel()
    # Check if result is a string
    assert isinstance(result, str)
    # Check if result has 11 characters
    assert len(result) == 11
    # Check if result is a valid PESEL

#Unit test for method nip of class PolandSpecProvider

# Generated at 2022-06-23 20:44:12.620639
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider(seed=42)
    assert provider.__class__.__name__ == 'PolandSpecProvider'

# Generated at 2022-06-23 20:44:16.412174
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider('2012101611084').pesel()
    assert pesel == '12101611084'


# Generated at 2022-06-23 20:44:22.561897
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel_provider = PolandSpecProvider()
    pesel_provider.seed = 548963
    assert pesel_provider.pesel() == '95102702551'
    assert pesel_provider.pesel(gender=Gender.MALE) == '76030946484'


# Generated at 2022-06-23 20:44:25.814369
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
	"""
	Verify that method pesel of class PolandSpecProvider returns 11 digits.
	:return: True if result == 11 else False.
	"""
	assert len(PolandSpecProvider().pesel()) == 11


# Generated at 2022-06-23 20:44:27.535299
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    poland_provider = PolandSpecProvider(seed=123)
    value = poland_provider.nip()
    assert value == '4040201539'


# Generated at 2022-06-23 20:44:32.256746
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    # Implementation of unit test.
    provider = PolandSpecProvider()    
    regon = provider.regon()
    print(regon)
    #assert provider.validate_regon(regon)
    #print("OK")


# Generated at 2022-06-23 20:44:41.974740
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    women = []
    men = []

    # Unit test for method pesel of class PolandSpecProvider with gender FEMALE
    for _ in range(1, 1000):
        sut = PolandSpecProvider()
        pesel_number_female = sut.pesel(gender=Gender.FEMALE)
        last_digit_female = int(pesel_number_female[-1])
        women.append(last_digit_female)

        assert len(pesel_number_female) == 11
        assert last_digit_female % 2 == 0

    # Unit test for method pesel of class PolandSpecProvider with gender MALE
    for _ in range(1, 1000):
        sut = PolandSpecProvider()
        pesel_number_male = sut.pesel(gender=Gender.MALE)

# Generated at 2022-06-23 20:44:46.746560
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    assert(len(p.pesel()) == 11)

# Generated at 2022-06-23 20:44:48.543100
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
	nip = PolandSpecProvider().nip()
	assert len(nip) == 10


# Generated at 2022-06-23 20:44:51.747221
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    spec_provider = PolandSpecProvider()
    assert spec_provider._meta == PolandSpecProvider.Meta
    assert spec_provider.__class__.__name__ == PolandSpecProvider.Meta.name


# Generated at 2022-06-23 20:44:54.148956
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    # GIVEN
    provider = PolandSpecProvider()
    # WHEN
    result = provider
    # THEN
    assert isinstance(result, PolandSpecProvider)


# Generated at 2022-06-23 20:44:55.868415
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    nip_provider = PolandSpecProvider.nip()
    assert nip_provider == '4451526307'


# Generated at 2022-06-23 20:45:00.198898
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Creates PolandSpecProvider object, generates PESEL using pesel method,
    checks if the PESEL is correct.
    """
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert isinstance(pesel, str)
    assert '18' in pesel or '20' in pesel
    assert '19' not in pesel
    assert '{:02d}'.format(provider.random.randint(10, 99)) in pesel



# Generated at 2022-06-23 20:45:07.174883
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider()
    regon = provider.regon()
    assert len(regon) == 9
    assert regon[8] == str(((8*int(regon[0])) + (9*int(regon[1])) + (2*int(regon[2])) + (3*int(regon[3])) + (4*int(regon[4])) + (5*int(regon[5])) + (6*int(regon[6])) + (7*int(regon[7])))%11)[-1]


# Generated at 2022-06-23 20:45:10.218224
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    p = PolandSpecProvider()
    regon = p.regon()
    print(regon)



# Generated at 2022-06-23 20:45:12.862837
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    pl = PolandSpecProvider()
    assert(len(pl.regon()) == 9 and pl.regon().isdigit())


# Generated at 2022-06-23 20:45:14.425301
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    tester =  PolandSpecProvider()
    print(tester.regon())

# Generated at 2022-06-23 20:45:16.167625
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    print("PolandSpecProvider constructor test")
    PolandSpecProvider()


# Generated at 2022-06-23 20:45:20.577525
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    nip = provider.nip()
    nip_int = int(nip)
    nip_str = str(nip_int)
    nip_str_len = len(nip_str)
    assert nip_str_len == 10


# Generated at 2022-06-23 20:45:24.599329
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    pesel_generator = PolandSpecProvider()
    regon = pesel_generator.regon()
    assert len(regon) == 9, len(regon)


# Generated at 2022-06-23 20:45:29.228633
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from datetime import date
    from mimesis.builtins import PolandSpecProvider

    poland_provider = PolandSpecProvider()
    pesel = poland_provider.pesel(date(1953, 6, 17))
    assert pesel == '53061709859'


# Generated at 2022-06-23 20:45:30.736897
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    test = PolandSpecProvider()
    assert isinstance(test, PolandSpecProvider)


# Generated at 2022-06-23 20:45:32.343210
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    test_object = PolandSpecProvider(seed=0)
    assert test_object.regon() == '89123456'

# Generated at 2022-06-23 20:45:33.099233
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pl = PolandSpecProvider()
    pl.pesel()


# Generated at 2022-06-23 20:45:36.835205
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Unit test for constructor of class PolandSpecProvider."""
    
    p = PolandSpecProvider()

    # test for __init__() of PolandSpecProvider
    def test_constructor():
        """Test for constructor of PolandSpecProvider."""

        assert p is not None

# Generated at 2022-06-23 20:45:38.498061
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider(seed=0)
    assert provider.regon() == "01365577"

# Generated at 2022-06-23 20:45:40.962536
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Test if the result of method nip is correct."""
    assert isinstance(PolandSpecProvider().nip(), str) and len(PolandSpecProvider().nip()) == 10


# Generated at 2022-06-23 20:45:44.535264
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """
    Check if pesel is printed with length exactly 11.
    """
    from mimesis.providers.person.pl import PolandSpecProvider
    p = PolandSpecProvider()
    assert len(p.pesel()) == 11

# Generated at 2022-06-23 20:45:46.863213
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    dd = p.pesel()
    print(dd)

if __name__ == '__main__':
    test_PolandSpecProvider_pesel()

# Generated at 2022-06-23 20:45:53.357816
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Test method nip of class PolandSpecProvider"""
    obj = PolandSpecProvider(seed = 1337)
    assert obj.nip() == '8103032342'
    assert obj.nip() ==  '8110134732'
    assert obj.nip() == '8108281402'
    assert obj.nip() == '8102155073'
    assert obj.nip() == '8105232909'
    assert obj.nip() == '8115109159'
    assert obj.nip() == '8107202783'
    assert obj.nip() == '8115058578'
    assert obj.nip() == '8121256728'
    assert obj.nip() == '8103294374'
    assert obj.nip() == '8124290649'

# Generated at 2022-06-23 20:45:56.504906
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    p = PolandSpecProvider()
    assert p.regon() == '929836902' or p.regon() == '318345640' or p.regon() == '547201072'

# Generated at 2022-06-23 20:46:01.519545
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    # Create an instance of class PolandSpecProvider
    provider = PolandSpecProvider()
    # Get random value generated by method nip
    random_number = provider.nip()
    # Check the type of random value
    assert isinstance(random_number, str)
    # Check the long of random value
    expected_long = 10
    assert len(random_number) == expected_long


# Generated at 2022-06-23 20:46:05.420000
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel(Datetime().datetime(1982, 1, 1),Gender.MALE)
    assert pesel == "82010103564"

# Generated at 2022-06-23 20:46:07.193781
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    assert PolandSpecProvider().nip() == '7732207310'


# Generated at 2022-06-23 20:46:10.282977
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    '''
    Test method nip of class PolandSpecProvider
    '''
    poland_provider = PolandSpecProvider()
    nip = poland_provider.nip()
    assert len(nip) == 10
    for i in nip:
        assert int(i) >= 0 and int(i) <= 9


# Generated at 2022-06-23 20:46:15.058894
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """
    Test method PolandSpecProvider.nip.
    """
    print('test_PolandSpecProvider_nip...')
    psp = PolandSpecProvider()
    assert psp.nip() == '5281384697'



# Generated at 2022-06-23 20:46:21.367971
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    # Test value 1 - count digits
    expected = 9
    result = len(PolandSpecProvider().regon())
    assert result == expected
    # Test value 2 - count digits after save in file and read
    file_name = 'names.txt'
    PolandSpecProvider()._write_in_file(PolandSpecProvider().regon(), file_name)
    expected = 9
    result = len(PolandSpecProvider()._read_from_file(file_name))
    assert result == expected


# Generated at 2022-06-23 20:46:32.781090
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    testCase = PolandSpecProvider()
    
    pesel = testCase.pesel()
    intro = 'Pesel: '
    print(intro + pesel)
    check = int(pesel[-1])
    remainder = ((9 * int(pesel[0])) + (7 * int(pesel[1])) + (3 * int(pesel[2])) +
                (1 * int(pesel[3])) + (9 * int(pesel[4])) + (7 * int(pesel[5])) +
                (3 * int(pesel[6])) + (1 * int(pesel[7])) + (9 * int(pesel[8])) +
                (7 * int(pesel[9]))) % 10
    

# Generated at 2022-06-23 20:46:37.900160
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider()
    regon_digits = provider.regon()
    regon_digits_int = int(regon_digits)
    assert provider.regon() in regon_digits
    assert isinstance(regon_digits, str)
    assert isinstance(regon_digits_int, int)


# Generated at 2022-06-23 20:46:40.502447
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Tests the correctness of the method regon of class PolandSpecProvider."""
    assert len(PolandSpecProvider().regon()) == 9

# Generated at 2022-06-23 20:46:43.119991
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Function test_PolandSpecProvider_regon test method regon of
    class PolandSpecProvider.
    """
    my_polish_provider = PolandSpecProvider(seed=0)
    regon = my_polish_provider.regon()
    assert regon == '937788353'

# Generated at 2022-06-23 20:46:46.076839
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Unit test for method regon of class PolandSpecProvider."""
    p = PolandSpecProvider()
    regon = p.regon()
    assert (len(regon) == 9)
    assert (regon.isdigit())



# Generated at 2022-06-23 20:46:50.126342
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    poland = PolandSpecProvider()
    assert poland.nip() == '9831001040'
    assert poland.pesel() == '78103011524'
    assert poland.regon() == '435099277'

# Generated at 2022-06-23 20:46:51.870306
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    pp = PolandSpecProvider()
    assert pp.random is not None

# Generated at 2022-06-23 20:46:58.082583
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    nip = PolandSpecProvider().nip()
    nip_coefficients = (6, 5, 7, 2, 3, 4, 5, 6, 7)
    nip_digits = [int(d) for d in str(nip)]
    sum_v = sum([nc * nd for nc, nd in zip(nip_coefficients, nip_digits)])
    assert sum_v % 11 == nip_digits[-1]


# Generated at 2022-06-23 20:47:01.334984
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():

	Seed(0)

	print("\nTesting PolandSpecProvider constructor...")
	# Start method test

	provider = PolandSpecProvider()

	print("provider initialized: ", provider.__init__())

	# End method test
	print("Done.")


# Generated at 2022-06-23 20:47:04.506535
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    assert provider.nip()
    assert provider.pesel()
    assert provider.regon()

# Generated at 2022-06-23 20:47:05.809634
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    print('test_PolandSpecProvider_pesel...')
    provider = PolandSpecProvider()
    provider.pesel()

# Generated at 2022-06-23 20:47:07.973132
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    assert isinstance(provider, PolandSpecProvider)


# Generated at 2022-06-23 20:47:11.186950
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    print('Test method pesel of PolandSpecProvider')
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    print('Test passed for method pesel of PolandSpecProvider')

