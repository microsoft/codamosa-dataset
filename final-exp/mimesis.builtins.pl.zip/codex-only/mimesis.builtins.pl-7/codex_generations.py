

# Generated at 2022-06-23 20:37:11.478439
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider(seed = 'test')
    assert provider.regon() == '841199234'


# Generated at 2022-06-23 20:37:17.970333
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider(seed=12345)
    nip_1 = provider.nip()
    nip_2 = provider.nip()
    assert nip_1 != nip_2
    assert type(nip_1) == str
    assert len(nip_1) == 10
    assert type(nip_2) == str
    assert len(nip_2) == 10



# Generated at 2022-06-23 20:37:19.260388
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    assert len(PolandSpecProvider().nip()) == 10



# Generated at 2022-06-23 20:37:21.719570
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    obj = PolandSpecProvider()
    assert len(obj.nip()) == 10


# Generated at 2022-06-23 20:37:23.628902
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pl_provider = PolandSpecProvider()
    pesel_1 = pl_provider.pesel()
    pesel_2 = pl_provider.pesel()
    assert pesel_1 != pesel_2


# Generated at 2022-06-23 20:37:27.267114
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    result = provider.nip()
    # Check if lenght = 10
    assert len(result) == 10
    # Check if type is string
    assert isinstance(result, str)
    # Check if value is number
    assert result.isdigit()


# Generated at 2022-06-23 20:37:32.618143
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel(birth_date=dtm.datetime(1940, 2018),
                           gender=Gender.MALE)
    assert len(pesel) == 11
    assert isinstance(pesel, str)
    assert pesel[6:7] in ('0', '2', '4', '6', '8')


test_PolandSpecProvider_pesel()

# Generated at 2022-06-23 20:37:34.474669
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider()
    assert len(str(provider.regon())) == 9


# Generated at 2022-06-23 20:37:39.020674
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    # test for method nip of class PolandSpecProvider
    from mimesis.builtins.pl import PolandSpecProvider as pl
    from pprint import pprint

    test_nip = pl.nip()
    pprint(test_nip)


# Generated at 2022-06-23 20:37:40.807686
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    value = p.pesel()
    assert len(value) == 11
    assert int(value[:2]) in range(40, 100)

# Generated at 2022-06-23 20:37:42.230125
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    assert provider.nip() == '0810776027'


# Generated at 2022-06-23 20:37:52.183699
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():

    import unittest
    import datetime

    class TestPesel(unittest.TestCase):

        def setUp(self):
            seed = "b7fbb5c5f5e14a5454d2c23e2848c710"
            self.poland_provider = PolandSpecProvider(seed=seed)

        def test_pesel(self):
            self.assertEqual(self.poland_provider.pesel(), '86011202450')
            self.assertEqual(self.poland_provider.pesel(datetime.datetime(2018, 1, 12, 0, 0, 0)), '18011206285')

# Generated at 2022-06-23 20:38:01.083050
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """
    Unit test for method regon of class PolandSpecProvider
    """
    random_seed = random.randint(1000, 10000)
    random.seed(random_seed)
    
    # Test case 1
    result = PolandSpecProvider().regon()
    assert result in ['730381243', '721329513', '947156812', '029207542'], 'unit test failed.'
    assert len(result) == 9, 'unit test failed.'
    
    # Test case 2
    result = PolandSpecProvider().regon()
    assert result in ['061781330', '547689681', '957189799', '433789611'], 'unit test failed.'
    assert len(result) == 9, 'unit test failed.'   
    
    # Test case 3

# Generated at 2022-06-23 20:38:06.817250
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    try:
        # unit test for method regon of class PolandSpecProvider
        regon = PolandSpecProvider().regon()
        regon_length = len(regon)
        if not regon_length == 9:
            raise Exception("\nError: \nExpected length: 9\nResult: " + str(regon))
        print("\n\nTest regon (PolandSpecProvider) : OK\n")

    except Exception as exception:
        print(exception)


# Generated at 2022-06-23 20:38:09.917531
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """
    Test method regon of class PolandSpecProvider
    """
    polandSpecProvider = PolandSpecProvider()
    print("Test PolandSpecProvider_regon: " + str(polandSpecProvider.regon()))


# Generated at 2022-06-23 20:38:11.094863
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    x = PolandSpecProvider()
    assert x


# Generated at 2022-06-23 20:38:12.845815
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    test1 = PolandSpecProvider()
    regon = test1.regon()
    assert len(regon) == 9

# Generated at 2022-06-23 20:38:17.614735
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    nip = PolandSpecProvider().nip()
    assert isinstance(nip, str)

    import re
    patter = re.compile(r'(\d{3}-\d{3}-\d{2}-\d{2})')
    result = patter.match(nip)
    if result is None:
        raise Exception("The generated NIP has a wrong syntax")
    return True


# Generated at 2022-06-23 20:38:19.378320
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    assert len(PolandSpecProvider().nip()) == 10


# Generated at 2022-06-23 20:38:23.587560
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    no_of_test = 0
    for _ in range(10):
        no_of_test += 1
        regon = PolandSpecProvider().regon()
        # Checks for the length of REGON
        assert(len(regon) == 9)
        # Checks for the type of return value
        assert(type(regon) == str)


# Generated at 2022-06-23 20:38:28.664761
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test PolandSpecProvider.pesel method."""
    import datetime
    provider = PolandSpecProvider()
    pesel = provider.pesel(datetime.datetime(1992, 1, 1))
    assert len(pesel) == 11
    assert pesel.startswith('9201')
    assert pesel.endswith('8') # odd for male, even for female


# Generated at 2022-06-23 20:38:32.144761
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Unit test for method nip of class PolandSpecProvider"""
    nip_gen = PolandSpecProvider()
    nip_number = nip_gen.nip()
    assert nip_number, 'Fail to generate NIP'
    print('Generated NIP: ' + nip_number)


# Generated at 2022-06-23 20:38:43.506050
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel1 = PolandSpecProvider().pesel()
    pesel2 = PolandSpecProvider().pesel()
    assert pesel1 != pesel2

    pesel3 = PolandSpecProvider().pesel(datetime.datetime(1961, 12, 21), Gender.FEMALE)
    assert pesel3[0:2] == "61"
    assert pesel3[2:4] == "12"
    assert pesel3[4:6] == "21"
    assert pesel3[-1] in ("0", "2", "4", "6", "8")
    assert len(pesel3) == 11

    pesel4 = PolandSpecProvider().pesel(datetime.datetime(1965, 4, 9), Gender.MALE)
    assert pesel4[0:2] == "65"
    assert pesel

# Generated at 2022-06-23 20:38:51.180264
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    from mimesis.schema import Field

    field = Field('poland_provider.nip')
    nip1 = field.create(seed=12345) # nip1 == '8567771505'
    nip2 = field.create(seed=12345) # nip2 == '8567771505'
    nip3 = field.create(seed=54321) # nip3 == '1544271350'

    assert nip1 == nip2
    assert nip2 != nip3


# Generated at 2022-06-23 20:38:56.497038
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():

    from mimesis.providers.poland import PolandSpecProvider
    poland_provider = PolandSpecProvider()
    nip1 = poland_provider.nip()
    print('NIP1: ', nip1)
    assert len(nip1) == 10
    assert isinstance(nip1, str)
    nip2 = poland_provider.nip()
    print('NIP2: ', nip2)
    assert len(nip2) == 10
    assert isinstance(nip2, str)


# Generated at 2022-06-23 20:38:59.640582
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    strTest = "Nip: "
    prov = PolandSpecProvider()
    strTest += prov.nip()
    print(strTest)
    return


# Generated at 2022-06-23 20:39:01.689161
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider()

    assert provider.regon() in '0123456789'


# Generated at 2022-06-23 20:39:03.363448
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Unit test for method regon of class PolandSpecProvider."""
    plsp = PolandSpecProvider()
    x = plsp.regon()
    assert x



# Generated at 2022-06-23 20:39:11.027487
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()

    # Test 1
    # Default case
    pesel_1 = provider.pesel()
    if not isinstance(pesel_1, str):
        raise AssertionError
    else:
        if not len(pesel_1) == 11:
            raise AssertionError
        else:
            if not pesel_1.isdigit():
                raise AssertionError
            else:
                sum_1 = 0
                coeffs_1 = (9, 7, 3, 1, 9, 7, 3, 1, 9, 7)
                for nc, nd in zip(coeffs_1, pesel_1[:-1]):
                    sum_1 += nc * int(nd)

# Generated at 2022-06-23 20:39:16.102865
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    import random
    import datetime
    pl = PolandSpecProvider(random.seed())
    assert isinstance(pl, PolandSpecProvider)
    assert len(pl.pesel(birth_date=datetime.datetime(1997, 4, 5))) == 11
    assert len(pl.pesel(birth_date=datetime.datetime(1997, 4, 5), gender=Gender.MALE)) == 11

# Generated at 2022-06-23 20:39:18.116552
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()

    print("Test for constructor")
    assert isinstance(provider, PolandSpecProvider)


# Generated at 2022-06-23 20:39:19.816014
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    obj = PolandSpecProvider()
    for _ in range(100):
        print(obj.nip())


# Generated at 2022-06-23 20:39:22.171502
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Testing method nip of class PolandSpecProvider."""
    number = PolandSpecProvider().nip()
    length = 10
    assert str(number).isdigit() == True
    assert len(str(number)) == length
    assert number == '7182694273'


# Generated at 2022-06-23 20:39:26.582360
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    assert PolandSpecProvider().regon() == '300232613'
    orgin_seed = None
    orgin_seed = PolandSpecProvider(seed=orgin_seed).regon()
    assert PolandSpecProvider(seed=orgin_seed).regon() == '300232613'


# Generated at 2022-06-23 20:39:32.625497
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider(seed=0)
    assert provider.nip() == '5286046008'
    assert provider.pesel(gender='female') == '94012513058'
    assert provider.pesel(gender='male') == '99072958018'
    assert provider.pesel(datetime(1994, 1, 25, 13, 5, 8)) == '94012513058'
    assert provider.pesel(datetime(1999, 7, 29, 13, 5, 8)) == '99072958018'
    assert provider.regon() == '70357157'

# Generated at 2022-06-23 20:39:37.600935
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test if pesel return valid PESEL"""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert provider.validate_pesel(pesel) is True


# Generated at 2022-06-23 20:39:41.932779
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    from random import Random
    from mimesis import seed
    from mimesis import PolandSpecProvider
    provider = PolandSpecProvider(Random(seed()))
    result = provider.regon()
    print(result)


# Generated at 2022-06-23 20:39:49.947717
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Test for method nip."""
    nip_values = []
    for i in range(10000):
        nip_values.append(PolandSpecProvider().nip())
    assert len(nip_values) == len(set(nip_values)), 'Non repeatable values'
    for nip in nip_values:
        assert len(nip) == 10
        assert len(set(nip[:-1])) == 9, 'Too much repeatable digits'
        for c in nip:
            assert c in str(range(10))


# Generated at 2022-06-23 20:39:50.543781
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    PolandSpecProvider()

# Generated at 2022-06-23 20:39:55.695298
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    Pesel = PolandSpecProvider(seed=None)
    X = Pesel.pesel()
    Y = Pesel.pesel(birth_date=Datetime().datetime(1940, 2018))
    Z = Pesel.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.MALE)
    # print("{} {} {}".format(X, Y, Z))


# Generated at 2022-06-23 20:39:58.170255
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    pl = PolandSpecProvider()
    assert pl.nip()
    assert pl.pesel()
    assert pl.regon()

# Generated at 2022-06-23 20:40:07.060140
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Tests for pesel method of class PolandSpecProvider."""

    import datetime

    print("\n")
    print("Starting tests for pesel method of class PolandSpecProvider.")
    print("\n")
    print("Testing random PESEL number generated by PESEL method.")
    provider = PolandSpecProvider("612780555")
    pesel_1 = provider.pesel()
    print("PESEL number 1 is: " + pesel_1)
    assert isinstance(pesel_1, str)
    assert len(pesel_1) == 11
    pesel_2 = provider.pesel()
    print("PESEL number 2 is: " + pesel_2)
    assert isinstance(pesel_2, str)
    assert len(pesel_2) == 11
    assert pesel_1 != pes

# Generated at 2022-06-23 20:40:09.025827
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider

    for i in range(0, 10):
        result = provider.nip(provider)

        assert len(result) == 10



# Generated at 2022-06-23 20:40:11.661105
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    # Arrange
    provider = PolandSpecProvider()

    # Act
    result = provider.nip()
    result2 = provider.nip()

    # Assert
    assert isinstance(result, str)
    assert len(result) == 10
    assert result != result2


# Generated at 2022-06-23 20:40:15.468208
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pl_test = PolandSpecProvider()
    test_pesel = pl_test.pesel()

    pesel_coeffs = (9, 7, 3, 1, 9, 7, 3, 1, 9, 7)
    pesel_digits = [int(d) for d in test_pesel[:-1]]
    sum_v = sum([nc * nd for nc, nd in zip(pesel_coeffs, pesel_digits)])
    checksum_digit = sum_v % 10
    assert checksum_digit == int(test_pesel[-1])


# Generated at 2022-06-23 20:40:26.283967
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Unit test for method regon of class PolandSpecProvider"""
    # Initialise PolandSpecProvider
    polandSpecProvider = PolandSpecProvider()
    # Sample data
    regonList = ['534985766', '228431670', '716383430', '725474022', '634803601', '261114853', 
    '209474201', '696651513', '719154651', '806438991', '883638532', '643714491', '470897924', 
    '087958358', '736855139', '850066267', '768004957', '674624285', '728761727', '039344823']
    # Compare calculated and sampled data
    for i in range(20):
        assert polandSpecProvider.regon

# Generated at 2022-06-23 20:40:28.926371
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    assert provider.provider == 'poland_provider'
    assert provider.field == 'pl'


# Generated at 2022-06-23 20:40:30.483294
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider(seed=None)
    regon = provider.regon()
    assert len(regon) == 9
    assert int(regon) > 1.0e8



# Generated at 2022-06-23 20:40:35.527985
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    pl = PolandSpecProvider()
    print(pl.nip())
    print(pl.nip())
    print(pl.nip())
    print(pl.nip())
    print(pl.nip())
    print(pl.nip())
    print(pl.nip())
    print(pl.nip())
    print(pl.nip())
    print(pl.nip())


# Generated at 2022-06-23 20:40:39.393762
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    random = PolandSpecProvider()
    print(random.nip())
    print(random.pesel())
    print(random.regon())

# Generated at 2022-06-23 20:40:41.903818
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Check if method regon of class PolandSpecProvider works correctly."""
    data = ''.join(PolandSpecProvider().regon())
    assert len(data) == 9


# Generated at 2022-06-23 20:40:44.401108
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    p = PolandSpecProvider()
    assert p.nip() is not None
    assert p.pesel() is not None
    assert p.regon() is not None

# Generated at 2022-06-23 20:40:49.412109
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    polish_provider = PolandSpecProvider()
    assert polish_provider.nip() == '7375261000'
    assert polish_provider.pesel() == '62478954817'
    assert polish_provider.regon() == '74977704'

# Generated at 2022-06-23 20:40:58.562381
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    import unittest
    import datetime

    class TestPolandSpecProvider_pesel(unittest.TestCase):
        def setUp(self):
            self.poland_spec_provider = PolandSpecProvider()

        def test_pesel(self):
            self.assertTrue(self.poland_spec_provider.pesel().isdigit())
            self.assertTrue(self.poland_spec_provider.pesel(
                datetime.datetime(2000,10,10)).isdigit())
            self.assertTrue(self.poland_spec_provider.pesel(
                datetime.datetime(2000,10,10), Gender.FEMALE).isdigit())

    unittest.main()


# Generated at 2022-06-23 20:41:01.000754
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    pl = PolandSpecProvider()
    print(pl.regon())
    print(pl.regon())
    print(pl.regon())
    print(pl.regon())
    print(pl.regon())


# Generated at 2022-06-23 20:41:12.335016
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    nip_generator = PolandSpecProvider()
    nip_result_one = nip_generator.nip()
    nip_result_two = nip_generator.nip()
    nip_result_three = nip_generator.nip()
    # The last digit should be equal to the value modulo 11 of the sum of the other digits taken in pairs
    # multiplied by their weights according to the table below:

# Generated at 2022-06-23 20:41:19.790308
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    p = PolandSpecProvider()
    assert (p.nip() == '9487685407')
    assert (p.pesel() == '85061917279')
    assert (p.regon() == '473399662')
    assert (p.pesel('female') == '78040434098')
    assert (p.pesel('male') == '84050228086')
    assert (p.pesel('2002-02-02', 'male') == '02020428011')

# Generated at 2022-06-23 20:41:22.696610
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    pl_provider = PolandSpecProvider()
    print(pl_provider.nip())
    print(type(pl_provider.nip()))


# Generated at 2022-06-23 20:41:25.275918
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    mimesis_pesel = PolandSpecProvider().pesel()
    assert len(mimesis_pesel) == 11



# Generated at 2022-06-23 20:41:33.728413
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    print("\n== PESEL ==")
    print(provider.pesel())
    print(provider.pesel())
    print(provider.pesel())
    print("\n== NIP ==")
    print(provider.nip())
    print(provider.nip())
    print(provider.nip())
    print("\n== REGON ==")
    print(provider.regon())
    print(provider.regon())
    print(provider.regon())

test_PolandSpecProvider()

# Generated at 2022-06-23 20:41:38.663409
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    obj = PolandSpecProvider()
    assert obj.nip() == '4339144760'
    assert obj.nip() == '6967172557'
    assert obj.nip() == '4339144760'
    assert obj.nip() == '6967172557'


# Generated at 2022-06-23 20:41:40.635665
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    for i in range(100):
        regon_len = len(PolandSpecProvider().regon())
        assert regon_len == 9

# Generated at 2022-06-23 20:41:50.839725
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """
    For verifying the correctness of PolandSpecProvider.pesel method.
    """
    seed = "Mimesis"
    provider = PolandSpecProvider(seed)

    for i in range(1000):
        pesel = provider.pesel()
        assert len(pesel) == 11
        assert int(pesel[0]) in range(0, 2)
        assert int(pesel[1]) in range(0, 10)
        assert int(pesel[2]) in range(0, 10)
        assert int(pesel[3]) in range(0, 10)
        assert int(pesel[4]) in range(0, 10)
        assert pesel[5] == "0"
        assert int(pesel[6]) in range(1, 10)
        assert int(pesel[7]) in range(0, 10)

# Generated at 2022-06-23 20:41:59.095485
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    # First test
    gen = PolandSpecProvider()
    assert len(gen.nip()) == 10, "NIP must have 10 digits"
    assert len(gen.pesel()) == 11, "PESEL must have 11 digits"
    assert len(gen.regon()) == 9, "REGON must have 9 digits"

    # Second test
    gen = PolandSpecProvider(seed=12345)
    assert len(gen.nip()) == 10, "NIP must have 10 digits"
    assert len(gen.pesel()) == 11, "PESEL must have 11 digits"
    assert len(gen.regon()) == 9, "REGON must have 9 digits"

# Generated at 2022-06-23 20:42:03.012752
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    # Default
    pl = PolandSpecProvider()
    regon = pl.regon()
    # Check if it is a string
    assert isinstance(regon, str)
    # Check if it is the right length
    assert len(regon) == 9
    # Check if it has the right format
    assert regon == '774717704'

# Generated at 2022-06-23 20:42:06.713792
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    str(provider.nip())
    # It should return the string with 10 digits
    assert len(str(provider.nip())) == 10


# Generated at 2022-06-23 20:42:11.958683
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    p = PolandSpecProvider(seed=42)
    assert p.nip().isdigit() == True
    assert len(p.nip()) == 10
    assert p.nip()[0] != "0"
    assert p.nip() == "8311233354"


# Generated at 2022-06-23 20:42:12.508001
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    PolandSpecProvider()

# Generated at 2022-06-23 20:42:16.147575
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    ps = PolandSpecProvider()
    assert ps.nip() is not None
    assert ps.pesel() is not None
    assert ps.regon() is not None

# Generated at 2022-06-23 20:42:19.990622
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    nip = PolandSpecProvider().nip()
    assert len(nip) == 10
    assert isinstance(nip, str)
    assert isinstance(int(nip), int)


# Generated at 2022-06-23 20:42:21.702169
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    for i in range(1000):
        assert len(PolandSpecProvider().nip()) == 10


# Generated at 2022-06-23 20:42:24.974924
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Generate random valid NIP for Poland.
    :return: Valid 10-digit NIP
    """
    provider = PolandSpecProvider()
    print(provider.nip())


# Generated at 2022-06-23 20:42:27.376598
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider
    # Sample run
    result = provider(seed=1).nip()
    assert result == "1811538459"

# Generated at 2022-06-23 20:42:29.925429
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    poland = PolandSpecProvider()
    n = poland.regon()
    assert len(n) == 9


# Generated at 2022-06-23 20:42:32.714206
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Unit test for method nip of class PolandSpecProvider."""
    provider = PolandSpecProvider(seed=42)
    assert provider.nip() == '4602708740'



# Generated at 2022-06-23 20:42:39.639861
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    # test with defalut arguments
    polandSpecProvider = PolandSpecProvider()
    nip = polandSpecProvider.nip()
    assert len(nip) == 10
    assert type(nip) == str

    # test with custom seed
    polandSpecProvider = PolandSpecProvider(seed="seed")
    nip = polandSpecProvider.nip()
    assert len(nip) == 10
    assert type(nip) == str


# Generated at 2022-06-23 20:42:41.901242
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():

    # Creating instance of PolandSpecProvider
    provider = PolandSpecProvider()

    # Generating pesel with random birthdate and gender
    pesel = provider.pesel()

    # Checking whether generated pesel is 11 characters long
    assert len(pesel) == 11

# Generated at 2022-06-23 20:42:43.846865
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider()
    assert len(provider.regon()) == 9


# Generated at 2022-06-23 20:42:50.415199
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # przykładowa data urodzenia: 23 stycznia 1989 roku
    birth_date = Datetime().datetime(1989, 1, 23)
    # płeć: mężczyzna
    gender = Gender.MALE

    # tworzymy obiekt klasy PolandSpecProvider
    poland_spec_provider = PolandSpecProvider()
    # generujemy PESEL
    pesel = poland_spec_provider.pesel(birth_date, gender)
    # wyświetlamy zgenerowany PESEL
    print('PESEL:', pesel)

    # sprawdzamy, czy zgenerowany PESEL jest prawidłowy

# Generated at 2022-06-23 20:42:53.136532
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    # Create object with seed = 42
    psp = PolandSpecProvider(42)

    assert psp.regon() == '740542595'


# Generated at 2022-06-23 20:42:56.135197
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    a = PolandSpecProvider()
    assert a.regon()[-1] == a.regon()[-1]

# Generated at 2022-06-23 20:43:02.367273
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel_generator = PolandSpecProvider()
    pesel_1 = pesel_generator.pesel(gender=Gender.MALE)
    pesel_2 = pesel_generator.pesel(gender=Gender.FEMALE)
    assert len(pesel_1) == 11
    assert len(pesel_2) == 11
    assert int(pesel_1[9]) % 2 != 0
    assert int(pesel_2[9]) % 2 == 0


# Generated at 2022-06-23 20:43:12.455196
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    from mimesis.enums import Gender

# Generated at 2022-06-23 20:43:13.344375
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    pl = PolandSpecProvider()
    assert pl is not None

# Generated at 2022-06-23 20:43:15.412692
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    #Setup
    provider = PolandSpecProvider()
    #Exercise
    result = provider.regon()
    #Verify
    assert result.isnumeric()
    assert len(result) == 9
    #Cleanup - none necessary


# Generated at 2022-06-23 20:43:15.973225
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    PolandSpecProvider()

# Generated at 2022-06-23 20:43:19.795113
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    nip = provider.nip()
    print(nip)
    assert(type(nip) is str)
    assert(len(nip) == 10)


# Generated at 2022-06-23 20:43:21.992411
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    assert len(PolandSpecProvider.PolandSpecProvider().regon()) == 9

#Unit test for method pesel of class PolandSpecProvider

# Generated at 2022-06-23 20:43:25.838989
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()
    assert len(pesel) == 11
    birth_date = PolandSpecProvider().pesel(birth_date = Datetime().datetime(1990, 1990), gender = Gender.MALE)
    assert len(birth_date) == 11

# Generated at 2022-06-23 20:43:34.109179
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""

    provider = PolandSpecProvider()
    pesel_number = provider.pesel(gender=Gender.MALE)
    assert len(pesel_number) == 11
    assert pesel_number[9] in ("1", "3", "5", "7", "9")

    pesel_number = provider.pesel(gender=Gender.FEMALE)
    assert len(pesel_number) == 11
    assert pesel_number[9] in ("0", "2", "4", "6", "8")


# Generated at 2022-06-23 20:43:36.481315
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """
    This method are unit test for method nip of class PolandSpecProvider in the package localization
    """
    assert len(PolandSpecProvider().nip()) == 10


# Generated at 2022-06-23 20:43:39.962839
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Test pesel() method of PolandSpecProvider."""
    provider = PolandSpecProvider()
    assert len(provider.nip()) == 10
    assert len(provider.regon()) == 9
    assert len(provider.pesel()) == 11

# Generated at 2022-06-23 20:43:41.776265
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    assert len(PolandSpecProvider().regon())==9


# Generated at 2022-06-23 20:43:43.531816
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Test method to verify that Poland provider is initialised ok."""
    provider = PolandSpecProvider()
    assert provider is not None

# Generated at 2022-06-23 20:43:51.000893
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()

    # Generate random 11-digit PESEL
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()

    # Generate 11-digit PESEL using specific birth date and gender
    birth_date = Datetime().datetime(1990, 1990)
    gender = Gender.MALE
    pesel = provider.pesel(birth_date, gender)
    assert len(pesel) == 11
    assert pesel.isdigit()



# Generated at 2022-06-23 20:43:54.686667
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    poland_provider = PolandSpecProvider()
    print(poland_provider.nip())
    print(poland_provider.pesel())
    print(poland_provider.regon())

# test_PolandSpecProvider()

# Generated at 2022-06-23 20:43:56.031511
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    assert provider is not None


# Generated at 2022-06-23 20:44:03.648240
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider(seed=1)
    assert provider.pesel(birth_date=provider.datetime(1970, 1, 1), gender=Gender.MALE) == "79092411214"
    assert provider.pesel(birth_date=provider.datetime(1980, 1, 1), gender=Gender.MALE) == "80092411214"
    assert provider.pesel(birth_date=provider.datetime(1980, 1, 1), gender=Gender.FEMALE) == "80092411227"
    assert provider.pesel(birth_date=provider.datetime(1990, 1, 1), gender=Gender.MALE) == "90092411214"

# Generated at 2022-06-23 20:44:06.062056
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    assert PolandSpecProvider().regon() in [str(x) for x in range(100000000, 999999999)]


# Generated at 2022-06-23 20:44:18.943032
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    instance = PolandSpecProvider()
    response = instance.regon()
    assert isinstance(response, str) and len(response) == 9,\
        f'Return value {response} not with expected type "str" or not with expected length "9".'
test_PolandSpecProvider_regon()



# Generated at 2022-06-23 20:44:20.345737
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():

    assert PolandSpecProvider().pesel() == '96071679254'

# Generated at 2022-06-23 20:44:24.295621
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    x = PolandSpecProvider() # Ensure no errors are thrown
    print(x.nip(), x.pesel(), x.regon())


# Generated at 2022-06-23 20:44:27.549667
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    p = PolandSpecProvider()
    assert len(p.regon()) == 9


# Generated at 2022-06-23 20:44:31.315951
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    from mimesis import PolandSpecProvider
    poland_provider = PolandSpecProvider()
    print(poland_provider.pesel())


# Generated at 2022-06-23 20:44:34.369044
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider(seed=42)
    assert provider.nip() == '2109559506'


# Generated at 2022-06-23 20:44:36.701856
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    r = PolandSpecProvider().regon()
    assert len(r) == 9


# Generated at 2022-06-23 20:44:39.402000
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    PolandSpecProvider().pesel()

# Generated at 2022-06-23 20:44:40.929440
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider(seed=None)
    assert len(provider.nip()) == 10


# Generated at 2022-06-23 20:44:42.098825
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    # TODO
    pass


# Generated at 2022-06-23 20:44:45.763492
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    pol = PolandSpecProvider()
    assert pol.provider.__class__.__name__ == 'Fake'


# Generated at 2022-06-23 20:44:56.800403
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test generate valid random PESEL."""
    birth_date = Datetime().datetime(2000, 2005)
    pesel = PolandSpecProvider().pesel(birth_date)
    year = birth_date.year
    month = birth_date.month
    day = birth_date.day
    pesel_digits = [int(d) for d in str(pesel)]
    pesel_date_digits = [int(i) for i in str(year)][-2:] + [int(i) for i in '{:02d}'.format(month)] + [int(i) for i in '{:02d}'.format(day)]
    pesel_date_digits.append(0)
    pesel_date_digits.append(0)
    pesel_date_digits.append(0)

# Generated at 2022-06-23 20:45:00.724669
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    result = provider.nip()
    assert isinstance(result, str)
    assert result
    assert len(result) == 10
    assert result.isdigit()


# Generated at 2022-06-23 20:45:04.460651
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    test_provider = PolandSpecProvider()
    
    regon = test_provider.regon()
    print(regon)

    assert str(regon).isdigit()
    assert len(regon) == 9


# Generated at 2022-06-23 20:45:14.666036
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    from mimesis.enums import Gender
    from mimesis.providers import Person
    from mimesis.providers.date_time import Datetime
    pesel = PolandSpecProvider()
    person = Person('pl', seed=94778)
    assert pesel.nip() == '4590787314'
    assert person.nip() == '590787314'
    assert person.nip(gender=Gender.FEMALE) == '921322650'
    assert person.nip(gender=Gender.MALE) == '246280902'
    assert person.nip() == '590787314'



# Generated at 2022-06-23 20:45:19.083988
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider()
    random_regon = provider.regon()
    assert len(random_regon) == 9

test_PolandSpecProvider_regon() # Unit test for method regon of class PolandSpecProvider


# Generated at 2022-06-23 20:45:19.656161
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    assert PolandSpecProvider()

# Generated at 2022-06-23 20:45:24.329972
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    # Test NIP
    assert len(PolandSpecProvider().nip()) == 10
    # Test Pesel
    assert len(PolandSpecProvider().pesel()) == 11
    # Test Regon
    assert len(PolandSpecProvider().regon()) == 9

# Generated at 2022-06-23 20:45:26.491085
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Tests for PolandSpecProvider"""
    # Unit test for constructor
    provider = PolandSpecProvider()
    assert provider.nip()
    assert provider.pesel()
    assert provider.regon()

# Generated at 2022-06-23 20:45:35.843359
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    from datetime import datetime
    poland_provider = PolandSpecProvider()
    pesel = poland_provider.pesel(datetime(1996,4,23), Gender.MALE)
    for i in range(0, 11):
        if i in [0, 1, 2, 10]:
            assert pesel[i] in [str(x) for x in range(0, 10)]
        elif i in [3, 4]:
            assert pesel[i] in [str(x) for x in range(0, 4)]
        elif i in [5, 6]:
            assert pesel[i] in [str(x) for x in range(0, 31)]
        elif i in [7, 8, 9]:
            assert pesel[i] in [str(x) for x in range(0, 999)]

# Generated at 2022-06-23 20:45:38.395274
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    pesel = PolandSpecProvider().pesel()
    assert len(pesel) == 11
    assert PolandSpecProvider.Meta.name == 'poland_provider'

# Generated at 2022-06-23 20:45:42.002887
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    assert len(provider.pesel(1940, Gender.FEMALE)) == 11
    assert len(provider.pesel(1990, Gender.MALE)) == 11
    assert provider.pesel(1940, Gender.FEMALE) != provider.pesel(1990, Gender.MALE)

# Generated at 2022-06-23 20:45:44.197124
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-23 20:45:46.125251
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    for i in range(100):
        pesel = PolandSpecProvider().regon()
        assert len(pesel) == 9

# Generated at 2022-06-23 20:45:46.437998
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    PolandSpecProvider()

# Generated at 2022-06-23 20:45:49.833258
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Unit test for method regon of class PolandSpecProvider."""
    provider = PolandSpecProvider(seed=42)
    print(provider.regon())
    # 464183187


# Generated at 2022-06-23 20:45:53.502919
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    print("provider.nip() = " + str(provider.nip()))
    assert len(str(provider.nip())) == 10


# Generated at 2022-06-23 20:46:02.763548
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    poland_provider = PolandSpecProvider()
    for x in range(0, 100):
        nip = poland_provider.nip()
        assert len(nip) == 10
        assert nip.isdigit()
        assert (int(nip[9]) == int(nip[0]) * 6 + int(nip[1]) * 5 + \
            int(nip[2]) * 7 + int(nip[3]) * 2 + int(nip[4]) * 3 + \
            int(nip[5]) * 4 + int(nip[6]) * 5 + int(nip[7]) * 6 + \
            int(nip[8]) * 7) % 11 % 10 == 0


# Generated at 2022-06-23 20:46:04.776996
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    p = PolandSpecProvider()

    assert p is not None


# Generated at 2022-06-23 20:46:08.173841
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    nip = provider.nip()
    assert provider.validate_nip(nip)


# Generated at 2022-06-23 20:46:09.215225
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    assert provider is not None

# Generated at 2022-06-23 20:46:11.244910
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    assert PolandSpecProvider().regon() == '4444444444'


# Generated at 2022-06-23 20:46:14.407287
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    assert provider.Meta.name == 'poland_provider'


# Generated at 2022-06-23 20:46:16.647438
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    p = PolandSpecProvider()
    for i in range(100):
        print(p.nip(), end=' ')
    print()


# Generated at 2022-06-23 20:46:24.550835
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Test for constructor of class PolandSpecProvider"""
    data = ('PolandSpecProvider', 'nip()', 'pesel()', 'regon()')
    asserter = Asserter(data)

    asserter.assert_object(PolandSpecProvider)
    asserter.assert_object(PolandSpecProvider().nip)
    asserter.assert_callable(PolandSpecProvider().nip)
    asserter.assert_object(PolandSpecProvider().pesel)
    asserter.assert_callable(PolandSpecProvider().pesel)
    asserter.assert_object(PolandSpecProvider().regon)
    asserter.assert_callable(PolandSpecProvider().regon)


# Generated at 2022-06-23 20:46:27.471028
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    pesel = p.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit() == True


# Generated at 2022-06-23 20:46:28.519245
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    assert PolandSpecProvider() is not None

# Generated at 2022-06-23 20:46:29.868252
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider()
    len(provider.regon()) == 9

# Generated at 2022-06-23 20:46:31.031198
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    assert len(PolandSpecProvider().nip()) == 10


# Generated at 2022-06-23 20:46:34.865028
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    print("test_PolandSpecProvider_regon")
    pol = PolandSpecProvider()
    #print(pol.regon())
    assert len(pol.regon()) == 9
    assert type(pol.regon()) == str

# Generated at 2022-06-23 20:46:37.405878
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    assert provider.pesel(birth_date=Datetime().datetime(2000, 2002), gender=Gender.MALE)

# Generated at 2022-06-23 20:46:41.638451
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Unit testing for constructor of class PolandSpecProvider"""
    print("Unit testing for constructor of class PolandSpecProvider")
    poland_provider = PolandSpecProvider()
    assert poland_provider is not None
    print("Class PolandSpecProvider: constructor - Ok!")


# Generated at 2022-06-23 20:46:51.691804
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Test for constructor of class PolandSpecProvider."""
    from mimesis.enums import Gender
    from mimesis.typing import DateTime

    pl_provider = PolandSpecProvider()

    for i in range(50):
        nip = pl_provider.nip()
        assert len(nip) == 10
        assert nip.isdigit()

    for i in range(50):
        pesel = pl_provider.pesel()
        assert len(pesel) == 11
        assert pesel.isdigit()

        pesel = pl_provider.pesel(birth_date=DateTime().datetime(1940, 2018))
        assert pesel.isdigit()

        pesel = pl_provider.pesel(gender=Gender.MALE)
        assert pesel.isdigit()



# Generated at 2022-06-23 20:46:52.583774
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    PolandSpecProvider()

# Generated at 2022-06-23 20:46:55.194160
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    print("Test: pesel")
    poland = PolandSpecProvider().pesel()
    print(poland)
    assert len(poland) == 11


# Generated at 2022-06-23 20:46:56.558988
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    print(p.pesel())

# Generated at 2022-06-23 20:46:58.402361
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    result = provider.pesel()
    assert result is not None
    assert len(result) == 11
    assert result.isdigit() is True
    assert 1800 <= int(result[:2]) <= 2299


# Generated at 2022-06-23 20:47:01.597680
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    from datetime import date

    pesel_from_date = PolandSpecProvider().pesel(birth_date=date(2020, 1, 1))
    assert len(pesel_from_date) == 11
    assert pesel_from_date.isdigit()



# Generated at 2022-06-23 20:47:06.942917
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel(gender=Gender.MALE)
    provider = PolandSpecProvider(seed=pesel)
    assert provider.pesel(gender=Gender.FEMALE) == pesel



# Generated at 2022-06-23 20:47:11.701134
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    data = provider.__dict__
    keys = [
        '_random_special', '_seed', '_random_generator', '_locale',
        '_datetime', 'A_VOWELS', 'A_CONSONANTS', 'G_ISO_639_1'
    ]
    assert sorted(data.keys()) == sorted(keys)