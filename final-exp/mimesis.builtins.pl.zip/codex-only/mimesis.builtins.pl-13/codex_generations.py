

# Generated at 2022-06-23 20:37:13.308935
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    date = Datetime().datetime(year=1997, month=9, day=16)
    gen = Datetime().datetime(year=1997, month=9, day=16)
    pesel = PolandSpecProvider().pesel(date,gen)
    assert len(pesel) == 11


# Generated at 2022-06-23 20:37:16.349791
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider(seed=0)
    pesel = p.pesel()
    assert(pesel == "72091706495")

# Generated at 2022-06-23 20:37:24.042552
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    poland_spec_provider = PolandSpecProvider()

    # test constructor of class PolandSpecProvider
    assert poland_spec_provider != None

    # test method nip() of class PolandSpecProvider
    nip = poland_spec_provider.nip()
    assert len(nip) == 10

    # test method pesel() of class PolandSpecProvider
    pesel = poland_spec_provider.pesel()
    assert len(pesel) == 11

    # test method regon() of class PolandSpecProvider
    regon = poland_spec_provider.regon()
    assert len(regon) == 9


# Generated at 2022-06-23 20:37:25.660761
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    assert provider.nip() == '6921340368'


# Generated at 2022-06-23 20:37:27.968600
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider(seed = 'test')
    print(provider.regon())


# Generated at 2022-06-23 20:37:30.365160
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_provider = PolandSpecProvider()
    assert poland_provider.pesel() == poland_provider.pesel()


# Generated at 2022-06-23 20:37:32.056462
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider(seed=None)
    assert provider.locale == 'pl'



# Generated at 2022-06-23 20:37:37.070520
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pr = PolandSpecProvider()
    pesel = pr.pesel(birth_date=Datetime().datetime(year=1984, month=9, day=13))
    print(pesel)
    assert len(pesel) == 11
    assert pesel.startswith("84")



# Generated at 2022-06-23 20:37:39.526770
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    for i in range(10):
        regon = PolandSpecProvider().regon()
        assert len(regon) == 9, "length of regon must be 9 characters"

# Generated at 2022-06-23 20:37:40.557283
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    unit = PolandSpecProvider()
    assert unit is not None


# Generated at 2022-06-23 20:37:45.052052
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Unit test for constructor of class PolandSpecProvider."""
    # Test constructor of class PolandSpecProvider
    provider = PolandSpecProvider()
    assert provider.__class__.__name__ == 'PolandSpecProvider'
    assert provider.locale == 'pl'
    assert provider.code == 'PL'
    assert provider.seed is not None
    assert provider.provider_name == 'poland_provider'


# Unit tests for methods of class PolandSpecProvider

# Generated at 2022-06-23 20:37:46.669171
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    from mimesis.providers.poland_provider import PolandSpecProvider
    provider = PolandSpecProvider()
    result = provider.regon()
    assert result


# Generated at 2022-06-23 20:37:48.314904
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Test generation of NIP"""
    nip = PolandSpecProvider().nip()
    assert(len(nip) == 10)
    # Assert that it is possible to generate the same NIP
    nip1 = PolandSpecProvider(seed=nip).nip()
    assert(nip == nip1)


# Generated at 2022-06-23 20:37:50.668723
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    PolandSpecProvider(seed=None)

# Generated at 2022-06-23 20:37:52.452794
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    from mimesis.providers.person.Poland import PolandSpecProvider
    provider = PolandSpecProvider()
    assert len(provider.regon()) == 9

# Generated at 2022-06-23 20:37:55.152469
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    a = PolandSpecProvider()
    # Check length of returned value
    assert len(a.regon()) == 9
    # Check return type of returned value
    assert type(a.regon()) is str

# Generated at 2022-06-23 20:38:02.650211
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    test_PolandSpecProvider = PolandSpecProvider()
    nip1 = test_PolandSpecProvider.nip()
    nip2 = test_PolandSpecProvider.nip()
    nip3 = test_PolandSpecProvider.nip()
    nip4 = test_PolandSpecProvider.nip()
    nip5 = test_PolandSpecProvider.nip()
    print("nip1 = " + nip1)
    print("nip2 = " + nip2)
    print("nip3 = " + nip3)
    print("nip4 = " + nip4)
    print("nip5 = " + nip5)
    print("")

# Generated at 2022-06-23 20:38:03.728497
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    assert PolandSpecProvider(seed=12345)

# Generated at 2022-06-23 20:38:04.667979
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    p = PolandSpecProvider()
    assert p is not None

# Generated at 2022-06-23 20:38:08.412504
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    poland_spec_provider = PolandSpecProvider()
    assert poland_spec_provider.nip()
    assert poland_spec_provider.pesel()
    assert poland_spec_provider.regon()

# Generated at 2022-06-23 20:38:15.869550
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    # method nip
    nip = provider.nip()
    assert str(nip).isdigit()
    assert '9999999' not in str(nip)
    assert len(str(nip)) == 10
    # method pesel
    pesel = provider.pesel()
    assert str(pesel).isdigit()
    assert len(str(pesel)) == 11
    # method regon
    regon = provider.regon()
    assert str(regon).isdigit()
    assert len(str(regon)) == 9

# Generated at 2022-06-23 20:38:19.893456
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    timestamp = time.time()
    n_nip_tests = 100
    for i in range(n_nip_tests):
        nip = PolandSpecProvider().nip()
        assert len(nip) == 10
        assert isinstance(nip, str)

    elapsed_time = time.time() - timestamp
    print('Test method "nip" of class "PolandSpecProvider", elapsed time = {:.3f} sec'.format(elapsed_time))


# Generated at 2022-06-23 20:38:22.314603
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    for i in range(20):
        method = provider.nip()
        assert len(str(method)) == 10


# Generated at 2022-06-23 20:38:25.709073
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    print("Test for method nip of class PolandSpecProvider")
    provider = PolandSpecProvider()
    print("provider.nip() = ", provider.nip())


# Generated at 2022-06-23 20:38:31.651403
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Assert Seed"""
    from mimesis.providers.address import Address
    from mimesis.providers.payment import Payment
    from mimesis.providers.person import Person
    from mimesis.enums import Gender

    pol = PolandSpecProvider()
    assert pol._seed is not None
    assert pol._formatter is not None
    assert pol.provider is not None
    assert pol.datetime is not None
    assert pol.address is not None
    assert pol.payment is not None
    assert pol.person is not None

    assert isinstance(pol.datetime, Datetime)
    assert isinstance(pol.address, Address)
    assert isinstance(pol.payment, Payment)
    assert isinstance(pol.person, Person)


# Generated at 2022-06-23 20:38:34.358709
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    p = PolandSpecProvider(seed=123456789)
    for _ in range (1,10):
        print(p.regon(), end='\n')


# Generated at 2022-06-23 20:38:37.502418
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()

# Generated at 2022-06-23 20:38:39.428218
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    # Test for 10-digit NIP
    assert len(PolandSpecProvider().nip()) == 10


# Generated at 2022-06-23 20:38:42.731154
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    pl = PolandSpecProvider()
    result = pl.nip()
    assert type(result) == str
    assert len(result) == 10
    assert result.isdigit() == True


# Generated at 2022-06-23 20:38:46.390596
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """
    Test method regon of class PolandSpecProvider.
    """
    provider = PolandSpecProvider()
    regon = provider.regon()
    assert len(regon) == 9
    assert all(map(lambda x: x.isdigit(), regon))


# Generated at 2022-06-23 20:38:48.095002
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    for _ in range(10):
        assert PolandSpecProvider().nip() == '4242545357'


# Generated at 2022-06-23 20:38:52.584379
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Test method nip of class PolandSpecProvider"""
    # Preparation
    provider_pl = PolandSpecProvider()

    # Exercise
    nip = provider_pl.nip()

    print("\n"+nip)
    
    # Assert
    assert nip != None
    assert len(nip) == 10


# Generated at 2022-06-23 20:38:55.616042
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    ps = PolandSpecProvider()
    ps.pesel(birth_date=datetime(1981, 2, 20))
    # Returns: '81022023405'
    print(ps.pesel(gender=Gender.MALE))
    # Returns: '96082435268'

# Generated at 2022-06-23 20:38:57.772944
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Test nip function."""
    pop = PolandSpecProvider()
    assert len(pop.nip()) == 10


# Generated at 2022-06-23 20:39:01.186313
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test function."""
    test_object = PolandSpecProvider()
    print(test_object.pesel(gender = Gender.FEMALE))


# Generated at 2022-06-23 20:39:03.857736
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Testing 'PESEL' generation"""
    actual = PolandSpecProvider().pesel()
    print('PESEL: ', actual)
    assert len(actual) == 11


# Generated at 2022-06-23 20:39:07.388340
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Unit test for method nip of class PolandSpecProvider."""
    pl = PolandSpecProvider()
    for i in range(1, 10):
        nip = pl.nip()
        nip_sum = sum([int(n) * int(c) for n, c in zip(nip, '67914728')])
        assert int(nip[-1]) == nip_sum % 11


# Generated at 2022-06-23 20:39:09.358228
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Unit test method regon of class PolandSpecProvider"""
    polandProvider = PolandSpecProvider()
    assert polandProvider.regon() != ''

# Generated at 2022-06-23 20:39:15.764786
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    from mimesis.enums import Gender

    provider = PolandSpecProvider()
    nip1 = provider.nip()
    assert nip1 == '8730061833'

    provider = PolandSpecProvider(seed=0)
    nip2 = provider.nip()
    assert nip2 == '1084273366'

    provider = PolandSpecProvider(seed=1)
    nip3 = provider.nip()
    assert nip3 == '2658010925'


# Generated at 2022-06-23 20:39:19.724044
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Unit test for method regon of class PolandSpecProvider

    :return: True if the function works correctly, False if not
    """
    provider = PolandSpecProvider()
    regon = provider.regon()
    assert isinstance(regon, str)
    assert len(regon) == 9


# Generated at 2022-06-23 20:39:21.183175
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Method test_PolandSpecProvider_regon"""
    regon = PolandSpecProvider().regon()
    assert len(regon) == 9
    assert int(regon)

# Generated at 2022-06-23 20:39:21.833263
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    _ = PolandSpecProvider(seed="Test")

# Generated at 2022-06-23 20:39:23.003783
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    assert len(PolandSpecProvider().nip()) == 10


# Generated at 2022-06-23 20:39:24.455943
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    PolandSpecProvider(seed=11).nip()  # Result: 2604366038


# Generated at 2022-06-23 20:39:29.737990
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # Create class
    from mimesis.providers.poland import PolandSpecProvider
    PESEL_provider = PolandSpecProvider()
    # Test pesel method
    pesel = PESEL_provider.pesel(gender=None)
    result = True
    if len(pesel) != 11:
        result = False
    print(pesel)
    return result


# Generated at 2022-06-23 20:39:32.121627
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Unit tests for PolandSpecProvider class."""
    spec_provider = PolandSpecProvider()


# Generated at 2022-06-23 20:39:38.151717
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    from mimesis import PolandSpecProvider
    from datetime import datetime

    pol_spec = PolandSpecProvider()
    pesel = pol_spec.pesel(
        datetime(1991,1,1), 
        Gender.FEMALE
    )
    assert pesel in ['91010110436', '91010116438', '91010120432', '91010130430', '91010138434']

# Generated at 2022-06-23 20:39:42.078060
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel(birth_date=Datetime().datetime(1960, 2018), gender=Gender.FEMALE)
    assert pesel == '60102998195'

# Generated at 2022-06-23 20:39:43.805114
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    p = PolandSpecProvider()
    assert p.seed == None
    assert p.random == None


# Generated at 2022-06-23 20:39:49.312950
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Unit test for method nip of class PolandSpecProvider."""
    from mimesis.enums import Gender
    from mimesis.builtins import PolandSpecProvider
    p = PolandSpecProvider()
    print(p.nip())
    print(p.pesel())
    print(p.regon()) 

test_PolandSpecProvider_nip()

# Generated at 2022-06-23 20:39:51.813754
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    pl_spec_provider = PolandSpecProvider()
    assert len(pl_spec_provider.pesel()) == 11

# Generated at 2022-06-23 20:39:53.638845
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    assert isinstance(provider, PolandSpecProvider)


# Generated at 2022-06-23 20:39:55.343256
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    seed = "tests"
    obj = PolandSpecProvider(seed)
    assert obj is not None


# Generated at 2022-06-23 20:39:58.127987
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    # Unit test for method regon of class PolandSpecProvider.
    assert PolandSpecProvider().regon() == '012345678'

# Generated at 2022-06-23 20:40:01.787016
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
	#Create object of class PolandSpecProvider
	provider = PolandSpecProvider()
	#Check if the NIP is string and have 10 digits
	assert isinstance(provider.nip(), str)
	assert len(provider.nip()) == 10


# Generated at 2022-06-23 20:40:04.420441
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Check if output of regon method is a non-empty string"""
    provider = PolandSpecProvider(seed = 123)
    assert isinstance(provider.regon(), str) and provider.regon() != ""


# Generated at 2022-06-23 20:40:11.585398
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider"""

    # Initialization
    cnt = 0
    provider = PolandSpecProvider()
    val = provider.pesel()
    year = int(val[0:2]) + 1900 if int(val[0:2]) < 19 else int(val[0:2]) + 2000
    month = int(val[2:4])
    day = int(val[4:6])
    gender = val[9]

    # Check 1: pesel is 11-digit long
    assert(len(val) == 11)

    # Check 2: pesel is numeric
    assert(val.isdigit())

    # Check 3: month and day range is valid
    assert(month > 0)
    assert(month <= 12)
    assert(day > 0)
    assert(day <= 31)

    #

# Generated at 2022-06-23 20:40:15.013578
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    poland_spec_provider = PolandSpecProvider()
    assert poland_spec_provider is not None
    assert poland_spec_provider.nip() is not None
    assert poland_spec_provider.pesel() is not None
    assert poland_spec_provider.pesel(Gender.MALE) is not None
    assert poland_spec_provider.pesel(Gender.FEMALE) is not None
    assert poland_spec_provider.regon() is not None

# Generated at 2022-06-23 20:40:22.690480
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test for method pesel of class PolandSpecProvider."""
    b1 = Datetime().datetime(1940, 1, 1)
    provider = PolandSpecProvider()
    pesel = provider.pesel(b1, Gender.MALE)
    assert len(pesel) == 11, f"{pesel} is {len(pesel)} character long"
    assert int(pesel[2]) in (0, 2, 4, 6, 8), f"{pesel} -- 2nd digit is not even"
    assert int(pesel[10]) % 2 != 0, f"{pesel} -- 11th digit is even"

# Generated at 2022-06-23 20:40:33.423411
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    datetime = Datetime()
    nip_val1 = PolandSpecProvider().nip()
    nip_val2 = datetime.poland_provider.nip()
    pesel_val1 = PolandSpecProvider().pesel()
    pesel_val2 = datetime.poland_provider.pesel()
    pesel_val3 = datetime.poland_provider.pesel(datetime.datetime(), Gender.FEMALE)
    regon_val1 = PolandSpecProvider().regon()
    regon_val2 = datetime.poland_provider.regon()
    print(f"NIP is: {nip_val1}, {nip_val2}")

# Generated at 2022-06-23 20:40:36.513542
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Method unit test using assert (with mimesis 0.3.3)"""
    regon = PolandSpecProvider().regon()
    assert isinstance(regon, str) and len(regon) == 9


# Generated at 2022-06-23 20:40:42.048165
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    # Test for method nip of class PolandSpecProvider
    provider_pl = PolandSpecProvider()
    # Positive test
    print("Test for method nip of class PolandSpecProvider, first call: ")
    print("NIP: ", provider_pl.nip())
    print("\n")
    print("Test for method nip of class PolandSpecProvider, second call: ")
    print("NIP: ", provider_pl.nip())
    print("\n")
    print("Test for method nip of class PolandSpecProvider, third call: ")
    print("NIP: ", provider_pl.nip())
    print("\n")


# Generated at 2022-06-23 20:40:45.199410
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Test regon method of class PolandSpecProvider."""
    poland_provider = PolandSpecProvider()

    regon_1 = poland_provider.regon()
    assert len(regon_1) == 9
    assert regon_1.isdigit()

    regon_2 = poland_provider.regon()
    assert len(regon_2) == 9
    assert regon_2.isdigit()

    assert regon_1 != regon_2

    # Unit test for method pesel of class PolandSpecProvider


# Generated at 2022-06-23 20:40:46.790217
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider()
    print(provider.regon())

# Generated at 2022-06-23 20:40:53.904336
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    import random
    import time
    random.seed(int(time.time()))
    provider = PolandSpecProvider()
    nip = provider.nip()
    lenght = len(str(nip))
    assert lenght == 10, "NIP must by 10 digits long"
    provider.seed(str(nip))
    assert provider.nip() == nip, "Pesels are differents"


# Generated at 2022-06-23 20:40:57.111443
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    p = PolandSpecProvider(seed=12345)
    assert p.nip() == "2531562481"
    assert p.pesel() == "92014246561"
    assert p.regon() == "008932324"

# Generated at 2022-06-23 20:41:04.371036
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    assert provider.pesel() == provider.pesel(gender=None)
    assert provider.pesel(gender=Gender.MALE) != provider.pesel(gender=Gender.FEMALE)
    provider.set_seed(1)
    assert provider.pesel(gender=Gender.MALE) == '95012707839'
    provider.set_seed(1)
    assert provider.pesel(gender=Gender.FEMALE) == '95012707832'
    provider.set_seed(2)
    assert provider.pesel(gender=Gender.MALE) == '95022770967'
    provider.set_seed(2)
    assert provider.pesel(gender=Gender.FEMALE) == '95022770970'
    provider.set_seed(3)


# Generated at 2022-06-23 20:41:10.131607
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Testing regon method of class PolandSpecProvider"""
    from mimesis.providers.poland_provider import PolandSpecProvider
    print("Testing regon method of class PolandSpecProvider")
    random_pson_povider = PolandSpecProvider()
    test_data = random_pson_povider.regon()
    print("REGON: {0}".format(test_data))


# Generated at 2022-06-23 20:41:13.016733
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p1 = PolandSpecProvider()
    pesel = p1.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-23 20:41:15.749739
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    poland_spec_provider = PolandSpecProvider()
    assert poland_spec_provider.__class__.__name__ == 'PolandSpecProvider'


# Generated at 2022-06-23 20:41:24.935441
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # random.seed(0)
    # random.random()
    obj = PolandSpecProvider()
    ret = obj.pesel(birth_date=None, gender=None)
    assert ret != None
    assert ret == "00122728798"
    # ret = obj.pesel(birth_date=datetime.date(1985, 6, 13), gender=Gender.MALE)
    # assert ret != None
    # assert ret == "85061348839"
    # ret = obj.pesel(birth_date=datetime.date(1985, 6, 13), gender=Gender.FEMALE)
    # assert ret != None
    # assert ret == "85061348830"
    

# Generated at 2022-06-23 20:41:28.414621
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    nip = provider.nip()
    assert nip.isdigit() == True
    assert len(nip) == 10



# Generated at 2022-06-23 20:41:30.828601
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    PolandSpecProvider_object = PolandSpecProvider()
    assert len(PolandSpecProvider_object.nip()) == 10


# Generated at 2022-06-23 20:41:41.676192
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # given
    params = []
    valid_pesel = set()
    invalid_pesel = set()
    provider = PolandSpecProvider()
    # when
    params.append((False, Gender.FEMALE))
    params.append((True, Gender.FEMALE))
    params.append((False, Gender.MALE))
    params.append((True, Gender.MALE))
    for p in params:
        data = provider.pesel(p[0], p[1])
        if (len(data) == 11) and (data[-1] == str(int(data[:-1]) % 10)):
            valid_pesel.add(data)
        else:
            invalid_pesel.add(data)
    # then
    assert len(valid_pesel) == 4

# Generated at 2022-06-23 20:41:43.008243
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    prov = PolandSpecProvider()
    assert len(prov.nip()) == 10


# Generated at 2022-06-23 20:41:45.101705
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    for _ in range(10):
        provider = PolandSpecProvider()
        assert len(provider.nip()) == 10


# Generated at 2022-06-23 20:41:49.223148
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    pl = PolandSpecProvider()
    print("nip: " + pl.nip())
    print("nip: " + pl.nip())
    print("nip: " + pl.nip())
    print("nip: " + pl.nip())
    print("nip: " + pl.nip())
    return


# Generated at 2022-06-23 20:41:51.811123
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    pesel = PolandSpecProvider()
    regon = pesel.regon()
    assert int(regon[:7])
    assert int(regon[7:])

# Generated at 2022-06-23 20:41:54.507713
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Test the constructor of PolandSpecProvider."""
    obj = PolandSpecProvider()
    assert obj.random is not None


# Unit tests for the functions of class PolandSpecProvider

# Generated at 2022-06-23 20:41:57.692003
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """
    Test the constructor of class PolandSpecProvider
    """
    z = PolandSpecProvider()
    test = z._PolandSpecProvider__random.randint(0, 9)
    print("Test: ", test)

# Generated at 2022-06-23 20:42:03.929941
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    from mimesis.enums import Gender
    pesel_obj = PolandSpecProvider()
    pesel = pesel_obj.pesel()

    # strip 10-digits year
    year = [int(i) for i in pesel[0:2]]
    assert all([int(i) in range(0,10) for i in year])

    # strip 2-digits month
    month = [int(i) for i in pesel[2:4]]
    assert all([int(i) in range(0,13) for i in month])

    # strip 2-digits day
    day = [int(i) for i in pesel[4:6]]
    assert all([int(i) in range(0,32) for i in day])

    # strip 3-digits series number

# Generated at 2022-06-23 20:42:06.081888
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Test for method nip of class PolandSpecProvider."""
    psp = PolandSpecProvider()
    nip = psp.nip()
    assert len(nip) == 10
    assert nip.isdigit() == True


# Generated at 2022-06-23 20:42:10.590222
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Test nip() of class PolandSpecProvider."""
    nip_provider = PolandSpecProvider()
    nip_number = nip_provider.nip()
    assert len(nip_number) == 10
    assert nip_number[0:2] in "01"
    assert nip_number[2] != "0"


# Generated at 2022-06-23 20:42:17.558114
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    def pesel():
        return PolandSpecProvider().pesel()

    assert len(pesel()) == 11

    assert pesel().startswith(('8', '0', '1', '2', '3', '4', '5', '6'))
    assert pesel().startswith(('7', '8', '9')) and (int(pesel()[2:4]) <= 12)


# Generated at 2022-06-23 20:42:19.755395
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    p = PolandSpecProvider()
    assert(p.nip()) == '7350171776'


# Generated at 2022-06-23 20:42:21.094103
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider()
    assert len(pesel.pesel()) == 11

# Generated at 2022-06-23 20:42:24.698230
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """
    Test for method regon of class PolandSpecProvider
    """
    # Input object
    pl_provider = PolandSpecProvider()

    # Startup 
    random_regon = pl_provider.regon()

    # Check
    assert len(random_regon) == 9, "Error in method regon of class PolandSpecProvider"




# Generated at 2022-06-23 20:42:27.936680
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    assert p.pesel()
    assert p.pesel(gender=p.gender())
    assert p.pesel(birth_date=p.date_time())


# Generated at 2022-06-23 20:42:37.004309
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit tests for method pesel.

    :return:
    """
    # case 1:
    # date_object = date(1988, 10, 2)
    # gender = Gender.MALE
    assert PolandSpecProvider().pesel(Datetime().datetime(1988, 10, 2, 0, 0, 0), Gender.MALE) == '88102812337'
    # case 2:
    # date_object = date(1988, 10, 2)
    # gender = Gender.FEMALE
    assert PolandSpecProvider().pesel(Datetime().datetime(1988, 10, 2, 0, 0, 0), Gender.FEMALE) == '88102802517'
    # case 3:
    # date_object = date(1710, 10, 3)
    # gender = Gender.FEMALE
    assert PolandSpecProvider

# Generated at 2022-06-23 20:42:41.241547
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Test for nip method of class PolandSpecProvider"""
    from mimesis.providers.poland import PolandSpecProvider
    poland_provider_object = PolandSpecProvider()
    nip_value = poland_provider_object.nip()
    assert len(nip_value) == 10


# Generated at 2022-06-23 20:42:42.720051
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    assert PolandSpecProvider() == PolandSpecProvider()


# Generated at 2022-06-23 20:42:44.418721
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    instance = PolandSpecProvider()
    instance.nip()
    instance.pesel()
    instance.regon()
    assert instance is not None

# Generated at 2022-06-23 20:42:55.932838
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    pesel = p.pesel()

    assert len(pesel) == 11
    assert int(pesel[:2]) > 19 or int(pesel[:2]) < 0
    assert int(pesel[2:4]) > 12 or int(pesel[2:4]) < 0
    assert int(pesel[4:6]) > 31 or int(pesel[4:6]) < 0

# Generated at 2022-06-23 20:43:04.276999
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    from mimesis import PolandSpecProvider
    from mimesis.seed import Seed

    # Test if the generated values are always the same if a seed is used
    with Seed.set_random(seed=1234):
        poland = PolandSpecProvider()
        regon_1 = poland.regon()
    with Seed.set_random(seed=1234):
        poland_2 = PolandSpecProvider()
        regon_2 = poland_2.regon()
    assert regon_1 == regon_2
    # Test if the length of the generated regon is always 9 digits
    assert len(regon_1) == 9

    # Test if the generated values are always different if a different seed is used
    with Seed.set_random(seed=1):
        poland = PolandSpecProvider()
        regon_1 = poland.regon

# Generated at 2022-06-23 20:43:06.920224
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Unit test - test_PolandSpecProvider_regon."""
    p = PolandSpecProvider()
    s = p.regon()
    assert len(s) == 9


# Generated at 2022-06-23 20:43:09.618867
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    poland_provider = PolandSpecProvider()
    assert poland_provider.locale == 'pl'
    assert poland_provider.seed is None


# Generated at 2022-06-23 20:43:11.116621
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    PolandSpecProvider(seed=4242).nip()


# Generated at 2022-06-23 20:43:13.284541
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    from mimesis import PolandSpecProvider
    poland_spec_provider = PolandSpecProvider()

    # Test that NIP constructed by method nip has format of NIP
    assert (len(poland_spec_provider.nip()) == 10)


# Generated at 2022-06-23 20:43:14.540839
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    assert PolandSpecProvider().nip() != PolandSpecProvider().nip()


# Generated at 2022-06-23 20:43:15.448134
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    assert PolandSpecProvider().__class__.__name__ == 'PolandSpecProvider'


# Generated at 2022-06-23 20:43:17.289871
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    p = PolandSpecProvider()
    pesel = p.nip()
    assert pesel, "Pesel value is not valid"


# Generated at 2022-06-23 20:43:28.171429
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test the method pesel of class PolandSpecProvider
    """
    from datetime import datetime
    from mimesis.enums import Gender
    import pytest

    # test pesel with birth_date and gender
    pesel_ = PolandSpecProvider()
    birth_date = datetime(1998, 10, 16)
    assert pesel_.pesel(birth_date, gender=Gender.MALE).startswith('981016')
    assert pesel_.pesel(birth_date, gender=Gender.FEMALE).startswith('981016')

    # test pesel birth_date without gender
    assert pesel_.pesel(birth_date).startswith('981016')

    # test pesel without birth_date and gender
    assert pesel_.pesel().__len__() == 11

    # test if pesel with wrong birth

# Generated at 2022-06-23 20:43:30.492354
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    poland_spec_provider = PolandSpecProvider(seed=1234)
    assert(poland_spec_provider.gender)


# Generated at 2022-06-23 20:43:34.272371
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test pesel method for PolandSpecProvider class."""
    provider = PolandSpecProvider()
    result = provider.pesel(birth_date=Datetime().datetime(1947, 3, 21), gender=Gender.MALE)
    assert result == '67032119032'



# Generated at 2022-06-23 20:43:37.235288
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    nip = PolandSpecProvider().nip()
    assert isinstance(nip, str)
    assert len(nip) == 10
    assert nip[0] == '5'
    assert nip[1] == '3'


# Generated at 2022-06-23 20:43:40.782823
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Unit test for method nip of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    func = provider.nip
    result = func()
    assert len(result) == 10
    assert all(d.isnumeric() for d in result)



# Generated at 2022-06-23 20:43:42.424535
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
   poland = PolandSpecProvider()

   assert len(poland.nip()) > 0

# Generated at 2022-06-23 20:43:43.397760
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    assert PolandSpecProvider()


# Generated at 2022-06-23 20:43:48.676248
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    # Required
    provider = PolandSpecProvider()
    assert isinstance(provider.nip(), str) == True
    assert provider.nip() == "8392150525"
    assert isinstance(provider.pesel(), str) == True
    assert provider.pesel() == "67081418223"
    assert isinstance(provider.regon(), str) == True
    assert provider.regon() == "778601145"

# Generated at 2022-06-23 20:43:57.331901
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider(seed=9)
    assert provider.nip() == '2512102018'
    assert provider.nip() == '0851977918'
    assert provider.nip() == '7610647636'
    assert provider.nip() == '9456097643'
    assert provider.nip() == '6382466356'
    assert provider.nip() == '5501970394'
    assert provider.nip() == '4205882173'
    assert provider.nip() == '5049792024'
    assert provider.nip() == '6196656122'
    assert provider.nip() == '4306606341'


# Generated at 2022-06-23 20:44:00.024399
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider(seed=42)
    assert provider.nip() == '2908508742'
    assert provider.regon() == '551267862'
    assert provider.pesel() == '44102828992'

# Generated at 2022-06-23 20:44:01.803430
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    assert provider.provider.locale == "pl"



# Generated at 2022-06-23 20:44:03.303003
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    assert str(PolandSpecProvider().nip()) == '4871224521'


# Generated at 2022-06-23 20:44:05.656958
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    result = True
    for i in range(0,5):
        provider = PolandSpecProvider()
        regon = provider.regon()
        if (len(regon) != 9):
            result = False
    assert result

# Generated at 2022-06-23 20:44:09.769039
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    p = PolandSpecProvider()
    print(p.nip())
    print(p.pesel())
    print(p.regon())
    print(p.pesel(birth_date = '05-10-1994'))
    print(p.pesel(birth_date = '05-10-1994', gender = 'male'))
    print(p.pesel(birth_date = '05-10-1994', gender = 'female'))

test_PolandSpecProvider()

# Generated at 2022-06-23 20:44:13.710600
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
   print("test_PolandSpecProvider")
   pl = PolandSpecProvider()
   assert pl.nip()
   assert pl.pesel()
   assert pl.regon()
   
if __name__ == "__main__":
   test_PolandSpecProvider()


# Generated at 2022-06-23 20:44:17.692967
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    print(provider.pesel())

if __name__ == "__main__":
    test_PolandSpecProvider_pesel()

# Generated at 2022-06-23 20:44:26.976057
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    poland_provider = PolandSpecProvider(seed=42)
    assert poland_provider.nip() == '366942'
    assert poland_provider.pesel() == '8412200'
    assert poland_provider.pesel(birth_date=Datetime().datetime(1940, 2018)) == '8209239'
    assert poland_provider.pesel(gender=Gender.MALE) == '9652214'
    assert poland_provider.pesel(gender=Gender.FEMALE) == '1538212'
    assert poland_provider.regon() == '078087'

# Generated at 2022-06-23 20:44:28.157414
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    obj = PolandSpecProvider()
    assert(obj.pesel() == "32091025722")


# Generated at 2022-06-23 20:44:31.885617
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    p = PolandSpecProvider()
    assert p.nip() is not None
    assert p.pesel() is not None
    assert p.regon() is not None

# Generated at 2022-06-23 20:44:41.774574
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel."""
    import random

    seed = random.randint(1, 99)
    person = PolandSpecProvider(seed)
    pesel = person.pesel()
    assert repr(pesel) == repr(person.pesel(gender=Gender.FEMALE))
    assert repr(pesel) == repr(person.pesel(gender=Gender.MALE))

    pesel = person.pesel(birth_date='1990.01.01')
    assert len(pesel) == 11
    assert pesel.startswith('900') or pesel.startswith('900')

# Generated at 2022-06-23 20:44:48.498028
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    # Test in length of NIP
    psp = PolandSpecProvider()
    for i in range(1000):
        nip = psp.nip()
        assert len(nip) == 10, 'The length of NIP is not equal to 10'
        for i in range(10):
            char = int(nip[i])
            assert char in range(10), 'Not correct NIP'


# Generated at 2022-06-23 20:44:51.702520
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    seed = 'TestPolandSpecProvider.test_PolandSpecProvider_regon'
    provider = PolandSpecProvider(seed=seed)
    assert provider.regon() == '977864145'


# Generated at 2022-06-23 20:44:54.419330
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    # Arrange
    provider = PolandSpecProvider(seed=3)

    # Act
    result = provider.regon()

    # Assert
    assert result == '822318735'


# Generated at 2022-06-23 20:44:56.128893
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    assert len(PolandSpecProvider().nip()) == 10
    assert PolandSpecProvider().nip().isdigit()


# Generated at 2022-06-23 20:44:57.450593
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    p = PolandSpecProvider(seed=None)
    assert len(p.nip()) == 10


# Generated at 2022-06-23 20:45:08.146150
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test a method pesel of a class PolandSpecProvider."""
    # Test data
    # The period in which the person could be born
    bd = Datetime().datetime(1960, 2018)
    # The sex of a person
    g = Gender.MALE

    # Execute the method pesel
    test_res = PolandSpecProvider().pesel(birth_date=bd, gender=g)

    # Test execution results
    # Check the length of the returned value
    assert len(test_res) == 11

    # Get a list of the elements of the result
    res_list = list(test_res)

    # Extract the second element of the list - the month
    assert 60 <= int(res_list[1]) <= 69

    # Extract the third element of the list - the day

# Generated at 2022-06-23 20:45:18.376482
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    assert provider.pesel(birth_date=date(1995, 1, 1), gender=Gender.MALE) == '95010111156'
    assert provider.pesel(birth_date=date(1995, 1, 1), gender=Gender.FEMALE) == '95010121264'
    assert provider.pesel(birth_date=date(1940, 1, 1), gender=Gender.MALE) == '94010111029'
    assert provider.pesel(birth_date=date(1940, 1, 1), gender=Gender.FEMALE) == '94010121221'
    assert provider.pesel(birth_date=date(2020, 1, 1), gender=Gender.MALE) == '20010111571'

# Generated at 2022-06-23 20:45:24.038637
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider(seed=123)
    assert provider.pesel(gender=Gender.MALE) == '96071493709'
    # assert provider.pesel(gender=Gender.FEMALE) == '89012757503'
    # assert provider.pesel(birth_date=datetime(1997, 8, 19)) == '97081989401'
    # assert provider.pesel(birth_date=date(1997, 8, 19)) == '97081989401'
    # assert provider.pesel(birth_date=time(22, 7)) == '85082294503'

# Generated at 2022-06-23 20:45:25.827140
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    p = PolandSpecProvider()
    regon = p.regon()
    assert len(regon) == 9


# Generated at 2022-06-23 20:45:29.607453
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    import random
    poland = PolandSpecProvider(random.random())
    assert poland.nip()
    assert poland.pesel(birth_date=poland.datetime(1940, 2018))
    assert poland.regno()
    assert poland.pesel(gender=poland.gender())

# Generated at 2022-06-23 20:45:31.383906
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Methods for testing method regon of class PolandSpecProvider"""
    provider = PolandSpecProvider()
    regon = provider.regon()
    assert len(regon) == 9


# Generated at 2022-06-23 20:45:35.862289
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    seed = "test"
    seed_input = Seed(seed)
    gender = "Gender.MALE"
    gender_input = Gender(gender)
    pesel_output = PolandSpecProvider(seed_input).pesel(birth_date=None, gender=gender_input)
    assert pesel_output == "05012792580"

# Generated at 2022-06-23 20:45:38.236688
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    #Arrange
    expected_result = "155479408"
    # Act
    actual_result = PolandSpecProvider().nip()

    # Assert
    assert actual_result == expected_result


# Generated at 2022-06-23 20:45:42.488000
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    p = PolandSpecProvider()
    # The number of tests
    tests = 10000
    # Define the range of the data to be generated
    length = 10

    for _ in range(tests):
        # Generate a random length
        # length = self.random.randint(1, self.max_length)
        # Generate NIPs and check if their length is equal to the given length
        assert len(p.nip()) == length


# Generated at 2022-06-23 20:45:50.599383
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    print("Test for method pesel of class PolandSpecProvider")
    polandProvider = PolandSpecProvider()
    pesel = polandProvider.pesel()
    print(pesel)
    assert len(pesel) == 11
    pesel = polandProvider.pesel(gender=Gender.MALE)
    print(pesel)
    assert len(pesel) == 11
    pesel = polandProvider.pesel(gender=Gender.FEMALE)
    print(pesel)
    assert len(pesel) == 11
    pesel = polandProvider.pesel(gender=Gender.FEMALE, birth_date="2010-10-10T10:10:10")
    print(pesel)
    assert len(pesel) == 11


# Generated at 2022-06-23 20:45:53.459727
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    nip = provider.nip()
    assert len(nip) == 10


# Generated at 2022-06-23 20:45:55.824080
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    poland_provider = PolandSpecProvider()
    assert poland_provider.regon() == '00000000000000000'

# Generated at 2022-06-23 20:45:56.886991
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    poland_provider = PolandSpecProvider()


# Generated at 2022-06-23 20:46:00.590549
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    prov = PolandSpecProvider(seed=3)
    print("test_PolandSpecProvider: ")
    print("  NIP: ", prov.nip())
    #  NIP:  735-19-39-566
    print("  PESEL: ", prov.pesel())
    #  PESEL:  53250811563
    print("  REGON: ", prov.regon())
    #  REGON:  029781933

# Generated at 2022-06-23 20:46:03.763241
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Test for method nip of class PolandSpecProvider."""
    nip_length = 10
    nip_provider = PolandSpecProvider()

    nip_number = nip_provider.nip()
    assert len(nip_number) == nip_length



# Generated at 2022-06-23 20:46:08.076220
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Unit test for method nip of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    assert provider.nip() == "1940779"

# Generated at 2022-06-23 20:46:11.656936
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Unit test for method regon of class PolandSpecProvider."""
    p = PolandSpecProvider()
    for _ in range(1000):
        assert len(p.regon()) == 9
        assert p.is_valid_regon(p.regon()) is True

# Generated at 2022-06-23 20:46:15.201645
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    # There are no forbidden digit in NIP, so test is passed
    assert provider.nip()



# Generated at 2022-06-23 20:46:17.450064
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    # test if nip is 10-digit
    nip = PolandSpecProvider().nip()
    assert len(nip) == 10


# Generated at 2022-06-23 20:46:19.038016
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()

    assert isinstance(pesel, str)
    assert len(pesel) == 11


# Generated at 2022-06-23 20:46:22.330879
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    polandSpecProvider = PolandSpecProvider()
    print(polandSpecProvider.nip())
    print(polandSpecProvider.pesel())
    print(polandSpecProvider.regon())
    
    
if __name__ == "__main__":
    test_PolandSpecProvider()

# Generated at 2022-06-23 20:46:26.481641
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pl_provider = PolandSpecProvider(seed=313)
    result = pl_provider.pesel()
    assert result == '04501139809'


# Generated at 2022-06-23 20:46:27.917204
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    p = PolandSpecProvider()
    assert p.nip()



# Generated at 2022-06-23 20:46:30.144593
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Unit test for method nip of class PolandSpecProvider."""
    pl = PolandSpecProvider(seed=12345)
    NIP = "8024071852"
    assert pl.nip() == NIP


# Generated at 2022-06-23 20:46:41.845465
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    p = PolandSpecProvider()

# Generated at 2022-06-23 20:46:45.529234
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    prov = provider.nip()
    assert (len(prov) == 10)
    assert prov.isdigit()
    assert (prov[:3] == "101")
    assert (prov[:3] in ["101", "102", "103"])


# Generated at 2022-06-23 20:46:46.376242
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    pl_provider = PolandSpecProvider()

# Generated at 2022-06-23 20:46:53.886472
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Test PolandSpecProvider class."""
    provider = PolandSpecProvider(seed=5)
    result = provider.nip()
    assert result == '1931979638'
    result = provider.pesel(gender=Gender.MALE)
    assert result == '94070631738'
    result = provider.pesel(gender=Gender.FEMALE)
    assert result == '98072379077'
    result = provider.regon()
    assert result == '255813919'

# Generated at 2022-06-23 20:46:56.097027
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Unit test for method nip of class PolandSpecProvider."""
    assert PolandSpecProvider().nip() == "1010500672"


# Generated at 2022-06-23 20:46:59.553252
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """PolandSpecProvider has regon method that always return 9-digit string"""
    p = PolandSpecProvider()
    for i in range(100):
        assert isinstance(p.regon(), str)
        assert len(p.regon()) == 9


# Generated at 2022-06-23 20:47:04.820814
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    print("\nTest dla konstruktora klasy PolandSpecProvider")
    prov = PolandSpecProvider(seed=None)
    assert prov.__class__.__name__ == 'PolandSpecProvider'
    assert prov.__doc__ == 'Class that provides special data for Poland (pl).'
    assert prov._meta.name == 'poland_provider'
    assert prov._meta.author == 'Igor Okounkov'
    assert prov._meta.get('name') == 'poland_provider'
    assert prov.seed is None


# Generated at 2022-06-23 20:47:07.536185
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    assert provider.__class__.__name__ == 'PolandSpecProvider'


# Generated at 2022-06-23 20:47:12.678235
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    # Creating PolandSpecProvider object
    polandSpecProvider = PolandSpecProvider()

    # Calling methots
    polandSpecProvider.nip()
    polandSpecProvider.pesel()
    polandSpecProvider.regon()

    # Checking if result is not None
    assert polandSpecProvider.nip() is not None
    assert polandSpecProvider.pesel() is not None
    assert polandSpecProvider.regon() is not None
