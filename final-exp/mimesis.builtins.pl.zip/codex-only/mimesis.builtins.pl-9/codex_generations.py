

# Generated at 2022-06-23 20:37:09.244595
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    assert PolandSpecProvider(seed=42).nip() == "8410200359"

# Generated at 2022-06-23 20:37:18.785933
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Testing the regon method of class PolandSpecProvider
    by generating 10 random numbers using this method and
    then checking if these numbers are valid ones by using the
    validate_regon function written by Marek Gachowski.
    """

    # Importing validate_regon function written by Marek Gachowski
    from mimesis.poland import validate_regon
    
    # Creating an object f the class PolandSpecProvider
    polish_provider = PolandSpecProvider()
    
    # Generating 10 random numbers with the method regon
    for i in range(10):
        regon = polish_provider.regon()
        print(regon, validate_regon(regon))

    

# Generated at 2022-06-23 20:37:20.886062
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    assert len(PolandSpecProvider().regon()) == 9, 'Length of REGON should be 9 digits'

# Generated at 2022-06-23 20:37:22.940773
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    assert len(provider.pesel()) == 11



# Generated at 2022-06-23 20:37:24.801645
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
  pl_provider = PolandSpecProvider()
  assert pl_provider.__str__() == "LocalProvider : pl"


# Generated at 2022-06-23 20:37:25.417121
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    pass
# End unit test for method regon of class PolandSpecProvider

# Generated at 2022-06-23 20:37:29.859799
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    start_range = 101
    end_range = 998
    digits = list(str(range_))
    for digit in digits:
        start_range.append(int(digit))
        end_range.append(int(digit))
        if len(str(start_range)) == 3 and len(str(end_range)) == 3:
            for i in range(6):
                index = random.randint(0, 9)
                start_range.append(index)
                end_range.apppend(index)
            digit_range = start_range, end_range
            nip_coefficients = (6, 5, 7, 2, 3, 4, 5, 6, 7)
            sum_v = sum([nc * nd for nc, nd in
                         zip(nip_coefficients, digit_range)])



# Generated at 2022-06-23 20:37:31.925000
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider(seed=42)
    assert provider.nip() == '7581354207'


# Generated at 2022-06-23 20:37:41.721704
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # Example
    # >>> from mimesis.enums import Gender
    # >>> from mimesis.providers import PolandSpecProvider
    # >>> oso = PolandSpecProvider()
    # >>> oso.pesel(birth_date=Datetime().datetime(1947, 10, 30), gender=Gender.MALE)
    # '47103000529'

    test_pesel = PolandSpecProvider().pesel(birth_date=Datetime().datetime(1947, 10, 30), gender=Gender.MALE)

    assert isinstance(test_pesel, str)
    assert len(test_pesel) == 11
    assert int(test_pesel[:2]) in range(40, 51)


# Generated at 2022-06-23 20:37:43.595922
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    pl_provider = PolandSpecProvider()
    digit_regon = pl_provider.regon()
    assert len(digit_regon) == 9

# Generated at 2022-06-23 20:37:47.973998
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    from mimesis.providers.poland_provider import PolandSpecProvider
    poland = PolandSpecProvider()
    regon = poland.regon()
    assert regon.isdigit() and len(regon) == 9


# Generated at 2022-06-23 20:37:52.268677
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    # GIVEN
    pol = PolandSpecProvider()
    # WHEN
    regon = pol.regon()
    # THEN
    assert isinstance(regon, str)
    assert len(regon) == 9
    regon_coeffs = (8, 9, 2, 3, 4, 5, 6, 7)
    regon_digits = [int(d) for d in regon]
    sum_v = sum([nc * nd for nc, nd in zip(regon_coeffs, regon_digits)])
    checksum_digit = sum_v % 11
    assert checksum_digit == regon_digits[-1]



# Generated at 2022-06-23 20:37:53.156220
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    PolandSpecProvider()

# Generated at 2022-06-23 20:37:59.833220
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    p = PolandSpecProvider()
    for _ in range(1000):
        regon = p.regon()
        assert len(regon) == 9
        regon_coeffs = (8, 9, 2, 3, 4, 5, 6, 7)
        regon_digits = [int(d) for d in regon]
        sum_v = sum([nc * nd for nc, nd in
                     zip(regon_coeffs, regon_digits)])
        checksum_digit = sum_v % 11
        assert regon_digits[8] == checksum_digit


# Generated at 2022-06-23 20:38:02.899189
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    my_poland_provider = PolandSpecProvider()
    d = my_poland_provider.regon()
    assert len(d) == 9
    assert d.isdigit()

# Generated at 2022-06-23 20:38:06.504694
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider()
    regon = provider.regon()
    assert 8 < len(regon) < 10, 'Regon should be at least 8 digits long'
    for digit in regon:
        assert digit.isdigit(), 'Regon should only contain digits'


# Generated at 2022-06-23 20:38:14.202006
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    from datetime import datetime
    from mimesis.enums import Gender
    polandSpecProvider = PolandSpecProvider()
    assert len(str(polandSpecProvider.pesel())) == 11
    assert len(str(polandSpecProvider.pesel(datetime(1990, 9, 9)))) == 11
    assert len(str(polandSpecProvider.pesel(gender=Gender.FEMALE))) == 11
    assert len(str(polandSpecProvider.pesel(datetime(1990, 9, 9), Gender.MALE))) == 11
#unit test for method regon of class PolandSpecProvider

# Generated at 2022-06-23 20:38:19.016237
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    from mimesis.providers.date import Date
    date_object = Date().date(year=2018, month=1, day=1)
    poland = PolandSpecProvider()
    # REGON must consist of 9 digits
    assert len(poland.regon()) == 9
    # REGON must contain only digits
    assert poland.regon().isdigit()
    # REGON must be different for different dates
    assert poland.regon(date_object) != poland.regon(date_object)


# Generated at 2022-06-23 20:38:20.818015
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider(seed=42)
    assert repr(provider) == '<PolandSpecProvider>'

# Generated at 2022-06-23 20:38:24.070926
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    # Create an object of class PolandSpecProvider
    test_poland_provider = PolandSpecProvider(seed = 10)

    # Test the name of provider
    assert test_poland_provider.Meta.name == 'poland_provider'


# Generated at 2022-06-23 20:38:26.711486
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    assert provider.__class__.__name__ == 'PolandSpecProvider'
    assert provider._seed == None # default value


# Generated at 2022-06-23 20:38:28.297027
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    assert 9 == len(provider.nip())



# Generated at 2022-06-23 20:38:30.008968
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    pl = PolandSpecProvider()
    assert pl.nip()
    assert pl.pesel()
    assert pl.regon()
    assert pl.random.seed(12345) == PolandSpecProvider(seed=12345)

# Generated at 2022-06-23 20:38:34.109284
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Test for method regon of class PolandSpecProvider."""
    from mimesis.providers.poland import PolandSpecProvider
    public = PolandSpecProvider()
    regon = public.regon()

    assert isinstance(regon, str)
    assert len(regon) == 9
    assert regon.isdigit()
    print("Unit test PolandSpecProvider, method regon: Success")


# Generated at 2022-06-23 20:38:43.881109
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Test nip() for class PolandSpecProvider.

    :return: Returns nothing
    """
    nip = PolandSpecProvider().nip()
    assert (len(nip) == 10)

    nip_digits = [int(d) for d in nip]

    nip_coefficients = (6, 5, 7, 2, 3, 4, 5, 6, 7)
    sum_v = sum([nc * nd for nc, nd in
            zip(nip_coefficients, nip_digits)])
    checksum_digit = sum_v % 11
    assert (checksum_digit == nip_digits[-1])



# Generated at 2022-06-23 20:38:54.100092
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    assert provider.nip() == '1234567890' and \
           provider.nip() == '1234567890' and \
           provider.nip() == '1234567890' and \
           provider.nip() == '1234567890' and \
           provider.nip() == '1234567890' and \
           provider.nip() == '1234567890' and \
           provider.nip() == '1234567890' and \
           provider.nip() == '1234567890' and \
           provider.nip() == '1234567890' and \
           provider.nip() == '1234567890'
    assert provider.pesel() == '97091462881' and \
           provider.pesel() == '97091462881'

# Generated at 2022-06-23 20:38:55.478155
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11

# Generated at 2022-06-23 20:39:02.335127
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    assert p.pesel() in ['77051918657', '54061027581', '20070406641']
    assert p.pesel(gender=Gender.MALE) in ['17012104561', '18050124296', '80040104577']
    assert p.pesel(gender=Gender.FEMALE) in ['32030126750', '39090417516', '98081826289']


# Generated at 2022-06-23 20:39:05.213051
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    assert isinstance(provider.nip(), str)
    assert isinstance(provider.pesel(), str)
    assert isinstance(provider.regon(), str)

# Generated at 2022-06-23 20:39:09.795907
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    nip_list = []
    for i in range(10):
        nip = PolandSpecProvider().nip()
        if nip not in nip_list:
            nip_list.append(nip)

    assert len(nip_list) == 10


# Generated at 2022-06-23 20:39:15.025815
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # Unit tests for pesel method
    poland_spec = PolandSpecProvider()
    test_cases = [
        (Gender.MALE, "89030972219"),
        (Gender.FEMALE, "28021978180")
    ]
    for gender, pesel in test_cases:
        assert poland_spec.pesel(gender=gender) == pesel



# Generated at 2022-06-23 20:39:16.459255
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    pol = PolandSpecProvider()
    wynik = pol.regon()
    print(wynik)


# Generated at 2022-06-23 20:39:20.281336
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    print(">> run unit test for method 'pesel' of class PolandSpecProvider")
    provider = PolandSpecProvider()
    for i in range(10):
        print(provider.pesel())
    print("<< unit test for method 'pesel' of class PolandSpecProvider finished")


# Generated at 2022-06-23 20:39:23.719767
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    assert PolandSpecProvider().pesel(gender=Gender.FEMALE) == '50100430618'
    assert PolandSpecProvider().pesel(gender=Gender.MALE) == '59020231645'
    assert PolandSpecProvider().pesel(gender=None) == '98062872904'


# Generated at 2022-06-23 20:39:32.406332
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    # Test 1
    # Expected result: regon_digits = [0, 0, 0, 0, 0, 0, 0, 0, 0]
    # Real result: regon_digits = [0, 0, 0, 0, 0, 0, 0, 0, 0]
    assert PolandSpecProvider.regon(PolandSpecProvider("")) == \
        "00000000"
    # Test 2
    # Expected result: regon_digits = [0, 0, 0, 0, 0, 0, 0, 0, 0]
    # Real result: regon_digits = [0, 0, 0, 0, 0, 0, 0, 0, 0]
    assert PolandSpecProvider.regon(PolandSpecProvider("12345")) == \
        "00000000"
    # Test 3
    # Expected result: regon_digits =

# Generated at 2022-06-23 20:39:39.520429
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    obj = PolandSpecProvider()
    for i in range(1000):
        assert len(obj.pesel()) == 11
        assert obj.pesel()[:2] == '45'
        assert obj.pesel(birth_date=Datetime().datetime(1940, 2018))[:2] == '45'
        assert obj.pesel(birth_date=Datetime().datetime(2000, 2018), gender=Gender.MALE)[-1] in ['1', '3', '5', '7', '9']


# Generated at 2022-06-23 20:39:42.031393
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    obj = PolandSpecProvider()
    assert len(obj.nip()) == 10


# Generated at 2022-06-23 20:39:44.347323
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    random_regon = PolandSpecProvider().regon()
    print(random_regon)
    print(type(random_regon))


# Generated at 2022-06-23 20:39:48.469776
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider(seed=0)
    gender= Gender.FEMALE
    pesel=provider.pesel(gender=gender)
    assert pesel=="68072804499"

# Generated at 2022-06-23 20:39:50.908779
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    result = provider.nip()
    assert len(result) == 10
    assert isinstance(result, str)


# Generated at 2022-06-23 20:39:54.245779
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Unit test for constructor of class PolandSpecProvider."""
    obj = PolandSpecProvider()
    assert obj is not None
    assert obj._meta.name == 'poland_provider'
    assert obj._meta.locale == 'pl'


# Generated at 2022-06-23 20:39:57.193775
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    nip = provider.nip()
    print(nip)
    pesel = provider.pesel()
    print(pesel)
    regon = provider.regon()
    print(regon)


# Generated at 2022-06-23 20:40:00.932005
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    nip_1 = provider.nip()
    nip_2 = provider.nip("seed")
    assert nip_1 != nip_2
    assert len(nip_1) == len(nip_2) == 10


# Generated at 2022-06-23 20:40:01.901903
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    assert PolandSpecProvider().pesel() == '74081406802'

# Generated at 2022-06-23 20:40:03.551296
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    # Generate random valid 10-digit NIP
    print(PolandSpecProvider().nip())


# Generated at 2022-06-23 20:40:06.014898
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """
    Assert that a string is returned by
    the method nip of class PolandSpecProvider
    """
    result = PolandSpecProvider().nip()
    assert isinstance(result, str)


# Generated at 2022-06-23 20:40:08.740395
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():

    polishSpecProvider = PolandSpecProvider()
    assert polishSpecProvider is not None

# Generated at 2022-06-23 20:40:10.689588
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    inp = []
    res = []
    prov = PolandSpecProvider()
    for i in range(100):
        inp.append(i)
        res.append(prov.regon())


# Generated at 2022-06-23 20:40:12.907378
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    pesel = p.pesel()
    assert len(str(pesel)) == 11
    assert str(pesel).isdigit()


# Generated at 2022-06-23 20:40:15.369869
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    instance = PolandSpecProvider()
    result = instance.nip()
    assert len(result) == 10


# Generated at 2022-06-23 20:40:20.687137
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    polish_provider = PolandSpecProvider()
    counts = [0] * 10
    numbers = list()
    for i in range(10000):
        n = [int(d) for d in polish_provider.nip()]
        for j in range(10):
            counts[j] += n[j]
        numbers.append(n)
    print(numbers)
    print(counts)


# Generated at 2022-06-23 20:40:31.794212
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Test for method nip of class PolandSpecProvider."""
    pl = PolandSpecProvider()
    
    # create lists of test NIP's for all possible coefficients of NIP
    test_nips = []
    for i in range(2,10):
        test_nips.append(str(i) + '0'*8 + str(i))

    # create lists of NIP's returned by method nip of class PolandSpecProvider
    nips = []
    for i in range(1000):
        nips.append(pl.nip())

    # check if any of test NIP's is an element of the list of nips
    is_test_nips_in_nips = False
    for nip in test_nips:
        is_test_nips_in_nips = is_test_nips_in_

# Generated at 2022-06-23 20:40:35.124257
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Check if PESEL is valid and has good structure."""
    pesel = PolandSpecProvider().pesel()
    assert len(pesel) == 11
    assert all(x.isdigit() for x in pesel)



# Generated at 2022-06-23 20:40:36.422335
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    assert provider.__dict__ != {}

# Generated at 2022-06-23 20:40:45.125879
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    nip_generator = PolandSpecProvider()
    nip_generator.nip()
    assert nip_generator.nip() is not None, 'PolandSpecProvider.nip() missing'

    pesel_generator = PolandSpecProvider()
    pesel_generator.pesel()
    assert pesel_generator.pesel() is not None, 'PolandSpecProvider.pesel() missing'

    regon_generator = PolandSpecProvider()
    regon_generator.regon()
    assert regon_generator.regon() is not None, 'PolandSpecProvider.regon() missing'

# Generated at 2022-06-23 20:40:48.271679
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    unique_nip = {provider.nip() for _ in range(1000)}
    assert len(unique_nip) == 1000


# Generated at 2022-06-23 20:40:50.997907
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    nip = PolandSpecProvider().nip()
    assert len(nip) == 10



# Generated at 2022-06-23 20:40:54.198027
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert isinstance(pesel, str)
    assert pesel


# Generated at 2022-06-23 20:40:55.629380
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    PolandSpecProvider.nip() == '7231693092'

# Generated at 2022-06-23 20:40:59.895590
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    import random
    import unittest
    random.seed(111111)

    p = PolandSpecProvider(seed=111111)
    for i in range(100):
        bd = p.datetime(1940,2018)
        g = p.gender()
        psl = p.pesel(bd,g)
        assert(len(psl)==11)



# Generated at 2022-06-23 20:41:00.970879
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    p = PolandSpecProvider()
    print(p.nip())



# Generated at 2022-06-23 20:41:02.057979
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    result = PolandSpecProvider(seed=1).regon()
    assert result == '68005251'


# Generated at 2022-06-23 20:41:04.804878
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    seed()
    assert nip() == '7172647195'


# Generated at 2022-06-23 20:41:09.307612
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    from mimesis.builtins.pl.poland_provider import PolandSpecProvider
    spec = PolandSpecProvider()
    regon = spec.regon()
    assert len(regon) == 9
    assert not any(r not in str(i) for i, r in enumerate(regon))
    print(regon)

# Generated at 2022-06-23 20:41:12.481986
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Test PolandSpecProvider license plate method."""
    provider = PolandSpecProvider(seed=42)
    result = provider.nip()
    assert result == '4710204903'


# Generated at 2022-06-23 20:41:14.908719
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Unit test for method nip of class PolandSpecProvider."""
    nip = PolandSpecProvider().nip()
    assert len(nip) == 10


# Generated at 2022-06-23 20:41:16.944603
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Unit test for method nip of class PolandSpecProvider."""
    p = PolandSpecProvider()
    assert p.nip() == '8654637894'


# Generated at 2022-06-23 20:41:20.229440
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Unit test for method regon of class PolandSpecProvider."""
    print("method regon of class PolandSpecProvider")
    assert len(PolandSpecProvider().regon()) == 9
    print('PASSED')


# Generated at 2022-06-23 20:41:23.713894
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider.pesel(PolandSpecProvider)
    assert len(pesel) == 11, "Lenght of pesel is not 11 characters."
    assert bool(int(pesel)), "Pesel contains not numeric characters."

# Generated at 2022-06-23 20:41:26.695932
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():

    myPolandSpecProvider = PolandSpecProvider()

    assert myPolandSpecProvider.nip()
    assert myPolandSpecProvider.pesel()
    assert myPolandSpecProvider.regon()

# Generated at 2022-06-23 20:41:30.110250
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """
    Testing constructor of class PolandSpecProvider.
    """
    obj = PolandSpecProvider()
    assert obj.random.getstate() == obj.random.getstate()

# Generated at 2022-06-23 20:41:32.825056
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Unit test for method regon of class PolandSpecProvider"""
    test_provider = PolandSpecProvider()
    assert(test_provider.regon() == '001008789')


# Generated at 2022-06-23 20:41:35.067996
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    nip=PolandSpecProvider().nip()

# Generated at 2022-06-23 20:41:39.511025
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Tests of method 'regon' of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    assert len(provider.regon()) == 9
    assert provider.regon()[-1] == str(int(provider.regon()[:-1]) % 11)

# Generated at 2022-06-23 20:41:40.623169
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    assert len(PolandSpecProvider().nip()) == 10


# Generated at 2022-06-23 20:41:50.840146
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    from hypothesis import given
    from hypothesis.strategies import text
    from hypothesis.strategies import integers

    p_spec = PolandSpecProvider()

    p_spec.random.seed(5)

    @given(text())
    def test_nip_length(s):
        result = p_spec.nip()
        assert len(result) == 10

    test_nip_length()

    p_spec.random.seed(0)

    @given(integers(min_value=100, max_value=999))
    def test_nip_len_digit_logical_error(s):
        result = p_spec.nip()
        assert result[0] == '7'
        assert result[1] == '8'
        assert result[2] == '9'

# Generated at 2022-06-23 20:41:52.924186
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    if __name__ == '__main__':
        pl_pesel_provider = PolandSpecProvider()
        print(pl_pesel_provider.pesel())


# Generated at 2022-06-23 20:41:55.458002
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Test that constructor of PolandSpecProvider class works as expected.
    """
    PolandSpecProvider(seed=12345)
    assert True


# Generated at 2022-06-23 20:42:01.072669
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    import random
    seed = random.randint(0, 10000)
    obj = PolandSpecProvider(seed=seed)
    birth_date = Datetime().datetime(1940, 2018)
    gender = Gender.MALE

    ob1 = obj.pesel(birth_date=birth_date, gender=gender)
    ob2 = obj.pesel(birth_date=birth_date, gender=gender)
    assert ob1 != ob2

# Generated at 2022-06-23 20:42:03.626612
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    for _ in range(15):
        pl = PolandSpecProvider()
        regon = pl.regon()
        assert len(regon) == 9

# Generated at 2022-06-23 20:42:12.459764
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    print('\n', '#' * 10, 'Unit test for constructor of class PolandSpecProvider', '#' * 10)
    print('\n', '1. Test everything\n')
    pl_test = PolandSpecProvider()
    from pprint import pprint
    print(pl_test.nip())
    pprint(pl_test.regon())
    pprint(pl_test.pesel())
    pprint(pl_test.pesel(gender=Gender.MALE))
    pprint(pl_test.pesel(gender=Gender.FEMALE))
    pprint(pl_test.pesel(birth_date=Datetime().datetime(1960, 2019)))


if __name__ == '__main__':
    test_PolandSpecProvider()

# Generated at 2022-06-23 20:42:16.104015
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    regon = PolandSpecProvider().regon()
    assert len(regon) == 9
    assert PolandSpecProvider().validate('regon', regon)
    

# Generated at 2022-06-23 20:42:18.384010
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland = PolandSpecProvider()
    assert poland.pesel() == poland.pesel()

# Generated at 2022-06-23 20:42:20.129286
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    obj = PolandSpecProvider()
    assert obj is not None


# Generated at 2022-06-23 20:42:22.537192
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    obj = PolandSpecProvider()
    res = obj.nip()
    assert len(res) == 10
    assert res.isdigit()


# Generated at 2022-06-23 20:42:32.546474
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    import math
    provider = PolandSpecProvider()
    assert provider.__class__.__name__ == 'PolandSpecProvider'
    assert provider.random.__class__.__name__ == 'Random'
    # Check for random NIP function
    nip = provider.nip()
    assert len(nip) == 10
    assert int(nip[:2]) >= 1 and int(nip[:2]) <= 99
    # Check for PESEL function
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert int(pesel[:2]) >= 40 and int(pesel[:2]) <= 99
    # Check for REGON function
    regon = provider.regon()
    

# Generated at 2022-06-23 20:42:34.149483
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    for i in range(0, 20):
        assert 1 == len(PolandSpecProvider().nip())


# Generated at 2022-06-23 20:42:35.946740
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider(seed=5)
    response = provider.nip()
    assert response == "4151740815"


# Generated at 2022-06-23 20:42:37.786711
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Unit test for method regon of class PolandSpecProvider"""
    provider = PolandSpecProvider(seed=123)
    assert provider.regon() == "012508182"


# Generated at 2022-06-23 20:42:40.064650
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    pl_provider = PolandSpecProvider()
    assert pl_provider.nip() == '8111601840'


# Generated at 2022-06-23 20:42:41.099542
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    PolandSpecProvider()


# Generated at 2022-06-23 20:42:43.103771
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    p = PolandSpecProvider()
    assert len(p.nip()) == 10
    

# Generated at 2022-06-23 20:42:44.851239
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_data = PolandSpecProvider()
    assert poland_data.pesel()


# Generated at 2022-06-23 20:42:47.201814
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Unit test for method regon of class PolandSpecProvider."""
    data = PolandSpecProvider().regon()
    assert data == '414141414'


# Generated at 2022-06-23 20:42:57.678140
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    #Test 1
    a = PolandSpecProvider()
    assert a.nip() in ('2184725017', '3180468480', '7259187853', '6137609129',
                       '9773450244', '3257721823', '7196600002', '0548124948',
                       '9748047987', '1902974390', '0903507455', '3984707791',
                       '6632053636', '2080459332', '2855791306', '5698876055',
                       '1836604185', '7659385662', '9384694361', '8786768863')
    #Test 2
    a = PolandSpecProvider(seed=2)
    assert a.nip() == '5083633998'
    #Test 3

# Generated at 2022-06-23 20:42:59.335415
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    assert len(PolandSpecProvider().nip()) == 10



# Generated at 2022-06-23 20:43:00.789465
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """This method checks if method nip of class PolandSpecProvider works properly."""
    assert len(PolandSpecProvider().nip()) == 10


# Generated at 2022-06-23 20:43:03.638292
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    pl = PolandSpecProvider(seed=1234)
    assert pl.regon() == '114440444'

# Generated at 2022-06-23 20:43:12.496140
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    from mimesis.builtins.pl import PolandSpecProvider
    from mimesis.enums import Gender
    from mimesis.typing import DateTime
    from datetime import datetime

    pl = PolandSpecProvider()
    gender = Gender.MALE
    birth_date = datetime(2000, 1, 1)

    assert pl.regon() == '00PMWK8JF'
    assert pl.pesel(gender) == '79030115291'
    assert pl.pesel(gender=gender) == '79030115292'
    assert pl.pesel(birth_date=birth_date, gender=gender) == '80010115312'
    assert pl.nip() == '078-111-48-54'

# Generated at 2022-06-23 20:43:15.758135
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    poland_provider = PolandSpecProvider()
    assert len(poland_provider.nip()) == 10
    assert int(poland_provider.nip()[0:3]) > 100 or int(poland_provider.nip()[0:3]) < 999

# Generated at 2022-06-23 20:43:26.554043
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test grammar of method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel_number = provider.pesel(birth_date=datetime(1985, 1, 1))
    if len(pesel_number) != 11:
        print("PESEL number has wrong length.")
        return False

    try:
        int(pesel_number)
    except ValueError:
        print("PESEL number is not an integer.")
        return False

    year = int(pesel_number[0:2])
    month = int(pesel_number[2:4])
    day = int(pesel_number[4:6])
    gender = int(pesel_number[9:10])

    if gender % 2 == 0:
        sex = "Female"

# Generated at 2022-06-23 20:43:30.630966
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    a = PolandSpecProvider()
    nip_returned = a.nip()

# Generated at 2022-06-23 20:43:36.046858
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    p = PolandSpecProvider()
    assert p.nip() != p.nip()
    assert p.pesel() != p.pesel()
    assert p.regon() != p.regon()
    assert len(p.nip()) == 10
    assert len(p.pesel()) == 11
    assert len(p.regon()) == 9

# Generated at 2022-06-23 20:43:39.266351
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    x = PolandSpecProvider()
    for _ in range(100):
        pesel = x.pesel()
        assert len(pesel) == 11
test_PolandSpecProvider_pesel()

# Generated at 2022-06-23 20:43:41.101292
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    PolandSpecProvider(seed=324).nip()


# Generated at 2022-06-23 20:43:43.023476
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    assert len(provider.nip()) == 10


# Generated at 2022-06-23 20:43:44.372808
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    print("Create instance of PolandSpecProvider(seed = 12345).")
    obj = PolandSpecProvider(seed = 12345)
    assert obj != None


# Generated at 2022-06-23 20:43:45.227132
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    PolandSpecProvider()

# Generated at 2022-06-23 20:43:46.584942
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    p = PolandSpecProvider()
    assert len(p.nip()) == 10


# Generated at 2022-06-23 20:43:51.087800
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """ Test class PolandSpecProvider and its constructor."""
    P = PolandSpecProvider()
    print("Testing class PolandSpecProvider... ", end = "")
    assert P.nip() == "0123456789"
    assert P.pesel() == "01234567891"
    assert P.regon() == "012345678"
    print("Done.")


# Generated at 2022-06-23 20:43:53.085619
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    result = provider.nip()
    assert type(result) == str


# Generated at 2022-06-23 20:43:56.110573
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    pl = PolandSpecProvider()
    result = pl.regon()
    assert isinstance(result, str)
    assert len(result) == 9
    assert result.isdigit()


# Generated at 2022-06-23 20:43:58.827764
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    print(provider.nip())
    print(provider.regon())
    print(provider.pesel())

if __name__ == '__main__':
    test_PolandSpecProvider()

# Generated at 2022-06-23 20:44:00.546805
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    p1 = PolandSpecProvider()
    for i in range(10):
        print(p1.regon())


# Generated at 2022-06-23 20:44:02.267212
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Unit test for constructor of class PolandSpecProvider."""
    a = PolandSpecProvider()
    assert isinstance(a, PolandSpecProvider)



# Generated at 2022-06-23 20:44:03.766543
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    seed = "abcdef"
    provider = PolandSpecProvider(seed)
    assert provider.nip() == "114283345"


# Generated at 2022-06-23 20:44:11.955274
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    # localization
    provider = PolandSpecProvider()
    lorem_ipsum = provider.text.word()

    # execute
    data = provider.regon()

    # verify
    assert len(data) == 9
    # check data type
    assert isinstance(data, str)
    # check type of function
    assert hasattr(provider.regon, "__call__")
    # check attribute
    assert hasattr(provider, 'text')
    assert hasattr(provider.text, "word")
    # check value
    assert data != lorem_ipsum

# Generated at 2022-06-23 20:44:15.161535
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Unit test for method regon of class PolandSpecProvider.

    """
    pl = PolandSpecProvider()
    result = pl.regon()

    assert len(result) == 9
    assert type(result) is str


# Generated at 2022-06-23 20:44:18.018889
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider_regon = PolandSpecProvider()
    assert len(provider_regon.regon()) == 9
    assert provider_regon.regon().isdigit() == True


# Generated at 2022-06-23 20:44:23.278985
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    def _test_PolandSpecProvider_regon():
        """Test method."""
        return PolandSpecProvider().regon()
    regon1 = _test_PolandSpecProvider_regon()
    assert isinstance(regon1, str)
    assert len(regon1) == 9


# Generated at 2022-06-23 20:44:30.319114
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    import random
    from mimesis.builtins.pl import PolandSpecProvider

    obj = PolandSpecProvider(random.Random())

    regon = obj.regon()
    assert len(regon) == 9
    assert type(regon) == str
    assert regon.isdigit()

    regon = obj.regon(mask='####.###.###')
    assert len(regon) == 13
    assert type(regon) == str
    assert regon[4] == '.'
    assert regon[8] == '.'

    regon = obj.regon(mask='###-###-###')
    assert len(regon) == 12
    assert type(regon) == str
    assert regon[3] == '-'
    assert regon[7] == '-'



# Generated at 2022-06-23 20:44:32.198210
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    pl = PolandSpecProvider()
    assert pl is not None


# Generated at 2022-06-23 20:44:34.225383
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    assert PolandSpecProvider().regon() == '862188807'

# Generated at 2022-06-23 20:44:38.475802
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    pesel_test_list = []
    for i in range(100000):
        pesel_test_list.append(p.pesel())
    assert len(pesel_test_list) == 100000, "pesel worked wrong"


# Generated at 2022-06-23 20:44:43.465920
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    no_of_tests = 10
    NIP = PolandSpecProvider()
    for i in range(no_of_tests):
        if len(NIP.nip()) == 10:
            print("NIP generated successfully.")
        else:
            print("Could not generate NIP.")


# Generated at 2022-06-23 20:44:48.607714
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    a = PolandSpecProvider()
    nip1 = a.nip()
    nip2 = a.nip()
    pesel1 = a.pesel()
    pesel2 = a.pesel()
    regon1 = a.regon()
    regon2 = a.regon()
    regon3 = a.regon()
    regon4 = a.regon()
    pesel3 = a.pesel(birth_date=a.datetime(2005, 2006, 1, 12, 0,0))
    pesel4 = a.pesel(birth_date=a.datetime(2005, 2006, 1, 12, 0,0))
    pesel5 = a.pesel(birth_date=a.datetime(2005, 2006, 1, 12, 0,0))

# Generated at 2022-06-23 20:44:49.182253
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    PolandSpecProvider()

# Generated at 2022-06-23 20:44:53.534530
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    p = PolandSpecProvider()
    result = p.regon()
    assert len(result) == 9
    assert set(list(result)).issubset({"0", "1", "2", "3", "4", "5", "6", "7", "8", "9"})

# Generated at 2022-06-23 20:44:54.826766
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    print(provider.nip())


# Generated at 2022-06-23 20:44:57.272860
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    pol = PolandSpecProvider()
    assert pol.nip() != None
    assert pol.pesel() != None
    assert pol.regon() != None


# Generated at 2022-06-23 20:45:01.509279
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Test regon."""
    value = PolandSpecProvider().regon()
    assert all([len(value) == 9,
                value.isdigit(),
                all([int(digit) in range(10)
                     for digit in value])])

# Generated at 2022-06-23 20:45:10.028893
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    psp = PolandSpecProvider(seed=123456)
    assert psp.nip() == "7246913654"
    assert psp.vat() == "PL7541588218"
    assert psp.regon() == "884601802"
    assert psp.personal_identity_number(gender=Gender.MALE) == "75111420553"
    assert psp.id_card_number(gender=Gender.MALE) == "751114205534055"
    assert psp.drivers_license_number(gender=Gender.MALE) == "NOB/D49/43751114205534055"
    assert psp.passport_number(gender=Gender.MALE) == "KZ751114205534055"

# Generated at 2022-06-23 20:45:13.097089
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider()
    number = provider.regon()
    assert len(number) == 9
    assert provider.validate_regon(number) == True

# Generated at 2022-06-23 20:45:17.492604
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Test class PolandSpecProvider."""
    p = PolandSpecProvider()
    assert p is not None
    assert p.regon() is not None
    assert p.nip() is not None
    assert p.pesel() is not None

# Generated at 2022-06-23 20:45:19.053959
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    assert type(PolandSpecProvider()) == PolandSpecProvider

# Generated at 2022-06-23 20:45:21.898877
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    p = PolandSpecProvider()
    assert p.nip() == '2531931348'
    assert p.pesel() == '96051712034'
    assert p.regon() == '326981513'



# Generated at 2022-06-23 20:45:25.407672
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    pesel = PolandSpecProvider().pesel()
    assert len(pesel) == 11
    
test_PolandSpecProvider()

# Generated at 2022-06-23 20:45:31.383359
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    assert PolandSpecProvider().pesel(birth_date=Datetime().datetime(1990, 1, 1), gender=Gender.MALE) == '90011131836'
    assert PolandSpecProvider().pesel(birth_date=Datetime().datetime(1990, 1, 1),gender=Gender.FEMALE) == '90011137463'
    assert PolandSpecProvider().pesel(birth_date=Datetime().datetime(1990, 1, 1), gender=None) != '90011137463'


# Generated at 2022-06-23 20:45:33.266306
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    prov = PolandSpecProvider()
    regon = prov.regon()
    print(regon)
    assert len(regon) == 9
    assert regon.isdigit() == True


# Generated at 2022-06-23 20:45:36.241233
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    nip = provider.nip()
    print(nip)
    print(len(nip))
    assert len(nip) == 10


# Generated at 2022-06-23 20:45:40.892001
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test for method pesel of class PolandSpecProvider."""

    p = PolandSpecProvider()
    peselM = p.pesel(gender='M')
    peselF = p.pesel(gender='F')
    pesel = p.pesel()

    assert len(peselM) == 11
    assert len(peselF) == 11
    assert len(pesel) == 11


# Generated at 2022-06-23 20:45:43.361326
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Test for constructor of class PolandSpecProvider."""
    obj = PolandSpecProvider(seed=5)
    assert obj


# Generated at 2022-06-23 20:45:47.234605
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """
    Test for method regon of class PolandSpecProvider
    """

    pl = PolandSpecProvider(seed=123456)
    assert pl.regon() == "936520720"

# Generated at 2022-06-23 20:45:49.843069
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    expected_result = '80349086949'
    generated_result = PolandSpecProvider().pesel(Datetime().datetime(1980, 4, 9), Gender.MALE)
    assert generated_result == expected_result
    print("test OK")


# Generated at 2022-06-23 20:45:54.137519
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    pesel = PolandSpecProvider().pesel()
    nip = PolandSpecProvider().nip()
    regon = PolandSpecProvider().regon()
    assert len(pesel) == 11
    assert len(nip) == 10
    assert len(regon) == 9

# Generated at 2022-06-23 20:45:56.828089
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    pl = PolandSpecProvider()

    vat = pl.nip()
    assert len(vat) == 10


# Generated at 2022-06-23 20:46:01.552657
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Unit test for constructor of class PolandSpecProvider."""
    # pylint: disable=W0612
      # pylint: disable=W0612
    plsp = PolandSpecProvider(seed=42)
    nip = plsp.nip()
    assert nip == '8927688374'
    pesel = plsp.pesel()
    assert pesel == '92111900070'
    regon = plsp.regon()
    assert regon == '958467024'
    assert plsp.provider == 'poland_provider'
    assert plsp.locale == 'pl'

# Generated at 2022-06-23 20:46:03.205602
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    assert len(PolandSpecProvider().nip()) == 10

# Generated at 2022-06-23 20:46:09.567792
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    print('#1 test_PolandSpecProvider_nip')
    poland = PolandSpecProvider()

    nip_list = []
    for _ in range(20):
        nip_list.append(poland.nip())
    for expect_num in range(10):
        assert expect_num in nip_list


# Generated at 2022-06-23 20:46:15.798662
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    assert provider.__repr__()
    assert provider.__str__()
    assert provider.__dict__
    assert provider.Meta.locales == 'pl'
    assert provider.Meta.name == 'poland_provider'
    assert provider.nip()
    assert provider.pesel()
    assert provider.regon()

# Generated at 2022-06-23 20:46:17.665456
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    nip = provider.nip()
    print(nip)



# Generated at 2022-06-23 20:46:18.631340
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    assert len(PolandSpecProvider().regon()) == 9

# Generated at 2022-06-23 20:46:24.044575
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    from mimesis import PolandSpecProvider

    pl = PolandSpecProvider()
    assert len(pl.pesel()) == 11
    assert 1983 < int(pl.pesel()[0:2]) < 96
    assert 0 <= int(pl.pesel()[2:4]) <= 12
    assert 0 < int(pl.pesel()[4:6]) < 31
    assert 0 <= int(pl.pesel()[6:9]) <= 999
    assert 0 <= int(pl.pesel()[9]) <= 9

# Generated at 2022-06-23 20:46:27.614149
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    pol = PolandSpecProvider()
    assert pol.nip() == '8402838602'
    assert pol.pesel() == '82010111143'
    assert pol.regon() == '74192188'

# Generated at 2022-06-23 20:46:28.993393
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    p = PolandSpecProvider()
    print(p.regon())
    print(p.regon())


# Generated at 2022-06-23 20:46:31.259607
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    instance = PolandSpecProvider()
    NIP = instance.nip()
    assert len(NIP) == 10
    assert NIP.isnumeric() == True


# Generated at 2022-06-23 20:46:35.332162
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    assert provider
    assert isinstance(provider, PolandSpecProvider)
    provider = PolandSpecProvider(seed=12345)
    assert provider
    assert isinstance(provider, PolandSpecProvider)


# Generated at 2022-06-23 20:46:40.652795
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # Arrange
    date_object = Datetime().datetime(2010, 2018)
    gender = Gender.MALE
    psp = PolandSpecProvider()
    # Act
    actual = psp.pesel(date_object, gender)
    # Assert
    assert actual == '12180423320'


# Generated at 2022-06-23 20:46:42.439410
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    PolandSpecProvider(seed=42)
    PolandSpecProvider(seed='42')



# Generated at 2022-06-23 20:46:45.360483
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    poland_spec_provider = PolandSpecProvider()
    assert poland_spec_provider.regon() == '123456785'
    assert len(poland_spec_provider.regon()) == 9


# Generated at 2022-06-23 20:46:50.475960
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_provider = PolandSpecProvider()
    assert len(poland_provider.pesel()) == 11
    assert len(poland_provider.pesel(gender=Gender.MALE)) == 11
    assert len(poland_provider.pesel(gender=Gender.FEMALE)) == 11


# Generated at 2022-06-23 20:46:53.328472
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    print("Unit test of method regon of class PolandSpecProvider")
    assert PolandSpecProvider().regon() == '367725791'


# Generated at 2022-06-23 20:46:55.194064
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider()
    regon = provider.regon()
    assert len(regon) == 9


# Generated at 2022-06-23 20:46:57.280423
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    assert p.pesel(gender=None) == "65120127583"


# Generated at 2022-06-23 20:46:58.940583
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    assert PolandSpecProvider().regon()
    assert len(PolandSpecProvider().regon()) == 9


# Generated at 2022-06-23 20:47:05.106459
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Test NIP, PESEL, REGON methods."""
    prov = PolandSpecProvider()
    assert prov.__class__.__name__ == 'PolandSpecProvider'
    nip = prov.nip()
    assert nip.__class__.__name__ == 'str'
    assert len(nip) == 10
    assert prov.nip().__class__.__name__ == 'str'
    assert prov.pesel().__class__.__name__ == 'str'
    assert prov.pesel(gender=Gender.FEMALE).__class__.__name__ == 'str'
    assert prov.regon().__class__.__name__ == 'str'

# Generated at 2022-06-23 20:47:09.347264
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Unit test for method regon of class PolandSpecProvider"""
    p = PolandSpecProvider()
    result = p.regon()
    assert len(result) == 9
    assert not result.startswith('0')
