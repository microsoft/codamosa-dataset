

# Generated at 2022-06-23 20:37:08.946106
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    assert str(provider) == 'PolandSpecProvider()'

# Generated at 2022-06-23 20:37:15.051956
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider(seed=42)
    for _ in range(100):
        assert provider.pesel() == '99121367383'
        assert provider.pesel(birth_date=Datetime().datetime(2000, 2020), gender=Gender.MALE) == '19110608789'
        assert provider.pesel(birth_date=Datetime().datetime(2000, 2020), gender=Gender.FEMALE) == '20122238070'

# Generated at 2022-06-23 20:37:17.325014
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    print(provider.nip())

# Generated at 2022-06-23 20:37:25.815150
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    nip = provider.nip()
    assert len(nip) == 10
    assert all(ch.isdecimal() for ch in nip)

# Generated at 2022-06-23 20:37:28.532324
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel_object = PolandSpecProvider()
    pesel_test = pesel_object.pesel(datetime(2019, 6, 21), Gender.MALE)
    print('PESEL:', pesel_test)

    # assert pesel_test

# Generated at 2022-06-23 20:37:30.271907
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    result = provider.nip()
    assert result == '2868386949'

# Generated at 2022-06-23 20:37:34.059576
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel."""
    p = PolandSpecProvider()
    assert p.pesel(gender=Gender.MALE)[9] in '13579'
    assert p.pesel(gender=Gender.FEMALE)[9] in '02468'

# Generated at 2022-06-23 20:37:37.447263
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel(birth_date="1980-01-01")
    print(pesel)
    assert len(str(pesel)) == 11


# Generated at 2022-06-23 20:37:42.001264
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # Initialize PolandSpecProvider instance
    pl = PolandSpecProvider()

    # Generate a PESEL
    pesel = pl.pesel()

    # Print a PESEL
    print(pesel)

    # Expected result
    pesel_sample = '94011311715'
    assert pesel_sample == pesel

# Generated at 2022-06-23 20:37:43.520289
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Test a constructor of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    assert provider is not None

# Generated at 2022-06-23 20:37:48.607443
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    m = PolandSpecProvider()
    d = m.datetime
    # create datetime in period 1940-2018
    bdt = d.datetime(1940, 2018)
    # m is object of PolandSpecProvider class
    p = m.pesel()
    assert len(p) == 11
    

# Generated at 2022-06-23 20:37:55.692869
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """
    Test method pesel of class PolandSpecProvider.
    """
    random_poland_provider = PolandSpecProvider()
    pesel = random_poland_provider.pesel()
    assert len(pesel) == 11
    int(pesel)
    if int(pesel[2]) % 2 == 0:
        assert int(pesel[10]) % 2 == 1
    else:
        assert int(pesel[10]) % 2 == 0
    pesel_coeffs = (9, 7, 3, 1, 9, 7, 3, 1, 9, 7)
    sum_v = 0
    for i in range(0, 10):
        sum_v += pesel_coeffs[i] * int(pesel[i])
    checksum = sum_v % 10
    assert checksum == int

# Generated at 2022-06-23 20:37:57.273831
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    result = PolandSpecProvider.pesel()
    assert isinstance(result, str)
    assert len(result) == 11

# Generated at 2022-06-23 20:37:59.305162
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    regon = []
    for i in range (0,10):
        regon.append(PolandSpecProvider().regon())
    assert regon[0] != regon[1] != regon[2] != regon[3] != regon[4] != regon[5] != regon[6] != regon[7] != regon[8] != regon[9]



# Generated at 2022-06-23 20:38:00.981109
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    assert PolandSpecProvider().nip() is not None
    assert PolandSpecProvider().pesel() is not None
    assert PolandSpecProvider().regon() is not None

# Generated at 2022-06-23 20:38:10.878187
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Unit test for method nip of class PolandSpecProvider."""
    import doctest
    from mimesis.providers.geography import PolandSpecProvider
    from mimesis.enums import Gender
    from mimesis.typing import DateTime
    provider = PolandSpecProvider()
    assert provider.nip() == '9481253401'
    assert provider.nip() == '8971213549'
    assert provider.nip() == '9582257492'
    assert provider.birthday_date('1960/1/1',
                                  '2005/12/31',
                                  gender=Gender.FEMALE) == DateTime('2003/1/12')

# Generated at 2022-06-23 20:38:16.169537
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()

    pesel = provider.pesel()
    assert len(pesel) == 11

    pesel = provider.pesel(gender=Gender.MALE)
    assert len(pesel) == 11
    assert pesel[9] % 2 == 1

    pesel = provider.pesel(gender=Gender.FEMALE)
    assert len(pesel) == 11
    assert pesel[9] % 2 == 0

# Generated at 2022-06-23 20:38:24.270585
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    for i in range(10**5):
        regon = PolandSpecProvider(seed=i).regon()
        # Check length
        assert len(regon) == 9

        # Check checksum
        regon_coeffs = (8, 9, 2, 3, 4, 5, 6, 7)
        regon_digits = [int(d) for d in regon]
        sum_v = sum([nc*nd for nc, nd in zip(regon_coeffs, regon_digits)])
        checksum_digit = sum_v % 11
        if checksum_digit > 9:
            checksum_digit = 0
        assert regon_digits[-1] == checksum_digit


# Generated at 2022-06-23 20:38:33.070916
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # test gender
    gender_male = PolandSpecProvider(seed=1).pesel(gender=Gender.MALE)
    gender_female = PolandSpecProvider(seed=2).pesel(gender=Gender.FEMALE)
    assert gender_male[-1] in ("1", "3", "5", "7", "9")
    assert gender_female[-1] in ("0", "2", "4", "6", "8")
    # test BD
    bd_m = PolandSpecProvider(seed=1).pesel(birth_date=Datetime().datetime(2000, 1, 1))
    bd_f = PolandSpecProvider(seed=2).pesel(birth_date=Datetime().datetime(2000, 1, 1))
    assert bd_m[:4] == "0019"
    assert bd

# Generated at 2022-06-23 20:38:36.650188
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider(seed=4).pesel(birth_date=Datetime().datetime(1970, 1970), gender=Gender.MALE)
    assert pesel == '90812011422'

# Generated at 2022-06-23 20:38:39.515227
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11


# Generated at 2022-06-23 20:38:40.865930
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    p = PolandSpecProvider()
    x = p.regon()
    assert type(x) == str
    assert len(x) == 9
    print(x)


# Generated at 2022-06-23 20:38:45.763000
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider"""
    import datetime


# Generated at 2022-06-23 20:38:47.332098
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    assert provider.nip() == '1234567890'



# Generated at 2022-06-23 20:38:56.199796
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    plProvider = PolandSpecProvider()
    nip = plProvider.nip()
    assert len(nip) == 10
    arr = []
    for i, num in enumerate(nip):
        arr.append(num)
        if i == 0:
            assert int(num) > 0
        assert int(num) >= 0 and int(num) <= 9
    sum_ = 6 * int(arr[0]) + 5 * int(arr[1]) + 7 * int(arr[2]) + 2 * int(arr[3]) + 3 * int(arr[4]) + 4 * int(arr[5]) + 5 * int(arr[6]) + 6 * int(arr[7]) + 7 * int(arr[8])
    checksum_digit = sum_ % 11
    assert checksum_digit == int(arr[9])



# Generated at 2022-06-23 20:38:57.162344
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    x = PolandSpecProvider()


# Generated at 2022-06-23 20:39:00.983883
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    pl = PolandSpecProvider()
    for _ in range(100):
        assert len(pl.nip()) == 10
        assert len(pl.pesel()) == 11
        assert len(pl.regon()) == 9

# Generated at 2022-06-23 20:39:01.646183
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    PolandSpecProvider()

# Generated at 2022-06-23 20:39:07.832809
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    # Test constructor works
    provider = PolandSpecProvider()
    assert provider

    # Test that constructor raises error when parameter is invalid
    try:
        PolandSpecProvider(seed='')
    except TypeError:
        pass

    # Test that constructor raises error when parameter is invalid
    try:
        PolandSpecProvider(locale='en')
    except ValueError:
        pass

    # Test that constructor raises error when parameter is invalid
    try:
        PolandSpecProvider(seed=None, locale='en')
    except ValueError:
        pass


# Generated at 2022-06-23 20:39:11.626612
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    p = PolandSpecProvider()
    assert p.pesel(birth_date=None, gender=Gender.MALE) == p.pesel(birth_date=None, gender=Gender.MALE)
    assert p.pesel(birth_date=None, gender=Gender.MALE) != p.pesel(birth_date=None, gender=Gender.FEMALE)

# Generated at 2022-06-23 20:39:14.503530
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    assert len(PolandSpecProvider().pesel()) == 11


# Generated at 2022-06-23 20:39:17.301152
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    assert hasattr(PolandSpecProvider, 'Meta')
    assert (PolandSpecProvider(seed = 3).Meta.name == 'poland_provider')


# Generated at 2022-06-23 20:39:20.072300
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    # given
    generator = PolandSpecProvider()
    # execute
    random_regon = generator.regon()
    # expect
    assert len(random_regon) == 9
    assert random_regon.isdigit()

# Generated at 2022-06-23 20:39:21.945189
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    p = PolandSpecProvider(seed = 0)
    assert p.nip() == '4189058584'


# Generated at 2022-06-23 20:39:24.103190
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    ps = PolandSpecProvider()
    assert ps is not None
    assert ps.nip() is not None
    assert ps.pesel() is not None
    assert ps.regon() is not None

# Generated at 2022-06-23 20:39:25.792694
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider()
    assert len(provider.regon()) == 9




# Generated at 2022-06-23 20:39:31.421876
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    from mimesis.enums import Gender
    provider = PolandSpecProvider()
    
    # checking if pesel is 11-digit
    pesel = provider.pesel()
    assert(len(pesel) == 11)

    # checking if pesel is correct for certain gender and date of birth
    date = provider.datetime(1900, 1900)
    pesel = provider.pesel(date, Gender.MALE)
    assert(len(pesel) == 11)

# Generated at 2022-06-23 20:39:40.800476
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel(birth_date=Datetime().datetime(2016,2016), gender=Gender.MALE)
    assert type(pesel) == str
    assert len(pesel) == 11
    assert pesel[6:8] == '20'
    assert int(pesel[9])%2 == 1
    assert PolandSpecProvider().pesel(birth_date=Datetime().datetime(1804,1804), gender=Gender.MALE)[6:8] == '84'
    assert PolandSpecProvider().pesel(birth_date=Datetime().datetime(2000,2000), gender=Gender.MALE)[6:8] == '20'

# Generated at 2022-06-23 20:39:45.060924
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    from mimesis.providers.poland_provider import PolandSpecProvider
    import re
    provider = PolandSpecProvider()
    regon = provider.regon()
    # assert that the lenght of the string is 9
    assert len(regon) == 9
    # check if the string contains only digits
    assert re.match('[0-9]*$', regon) != None


# Generated at 2022-06-23 20:39:47.344534
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    print(PolandSpecProvider())


# Generated at 2022-06-23 20:39:50.953105
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test PESEL generated by PolandSpecProvider class."""
    p = PolandSpecProvider(seed=12345)
    pesel = p.pesel(birth_date=PolandSpecProvider.datetime(2006, 2007))
    assert pesel == '0603012345'

# Generated at 2022-06-23 20:39:53.172660
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    c = PolandSpecProvider()
    assert c.seed is None
    assert c.locale == 'pl'
    pass



# Generated at 2022-06-23 20:39:54.275353
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Method that test regon method of PolandSpecProvider."""
    assert PolandSpecProvider().regon() == '518933207'
    return True


# Generated at 2022-06-23 20:39:55.584734
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Tests the constructor of the PolandSpecProvider class."""
    provider = PolandSpecProvider(seed=48527)
    assert provider is not None
    assert type(provider) == PolandSpecProvider



# Generated at 2022-06-23 20:40:00.846087
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Unit test for constructor of class PolandSpecProvider."""
    spec_provider = PolandSpecProvider()
    expected_locale = 'pl'
    locale = spec_provider.locale
    msg = "Locale should be '{}'.".format(expected_locale)
    assert locale == expected_locale, msg


# Generated at 2022-06-23 20:40:02.492970
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
	poland = PolandSpecProvider(seed=42)
	# Should return '96111156538'
	assert poland.pesel() == '96111156538'

# Generated at 2022-06-23 20:40:05.066364
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    seed = 'test_PolandSpecProvider_regon'
    pl_provider = PolandSpecProvider(seed)
    result = pl_provider.regon()
    assert result == '603683845'

# Generated at 2022-06-23 20:40:06.559332
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider()
    assert len(provider.regon()) == 9

# Generated at 2022-06-23 20:40:10.036889
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    assert PolandSpecProvider.regon(PolandSpecProvider()) == '713211105'


# Generated at 2022-06-23 20:40:15.759461
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()
    assert pesel[0:2] in ['17', '18', '20', '21', '22', '23', '24', '25', '26']
    assert len(pesel) == 11
    assert int(pesel[2:4]) in list(range(1, 13))
    assert int(pesel[4:6]) in list(range(1, 32))
    assert int(pesel[6:9]) in list(range(0, 1000))
    assert int(pesel[9]) in list(range(10))

# Generated at 2022-06-23 20:40:18.661654
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    provider.pesel()
    # Checksum digit of all PESEL numbers is 2
    assert (provider.pesel()[-1]) == '2'


# Generated at 2022-06-23 20:40:20.600345
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    assert PolandSpecProvider().nip()
    assert len(PolandSpecProvider().nip()) == 10


# Generated at 2022-06-23 20:40:24.338030
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    assert p.pesel().isdigit()
    assert p.pesel(gender=Gender.FEMALE)
    assert p.pesel(gender=Gender.MALE)
    assert p.pesel(birth_date=Datetime().datetime(1900, 1999))
    assert p.pesel(birth_date=Datetime().datetime(2000, 2099))
    assert p.pesel(birth_date=Datetime().datetime(2100, 2199))
    assert p.pesel(birth_date=Datetime().datetime(2200, 2299))



# Generated at 2022-06-23 20:40:26.190410
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    pesel = PolandSpecProvider().regon()
    print(pesel)


# Generated at 2022-06-23 20:40:31.263025
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    # Test for method nip
    nip1 = PolandSpecProvider().nip()
    assert len(nip1) == 10
    # Test for method nip
    nip2 = PolandSpecProvider().nip()
    assert len(nip2) == 10
    # Test for method nip
    nip3 = PolandSpecProvider().nip()
    assert len(nip3) == 10
    # Test for method nip
    nip4 = PolandSpecProvider().nip()
    assert len(nip4) == 10
    # Test for method nip
    nip5 = PolandSpecProvider().nip()
    assert len(nip5) == 10
    # Test for method nip
    nip6 = PolandSpecProvider().nip()
    assert len(nip6) == 10


# Generated at 2022-06-23 20:40:35.462578
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel(birth_date="1999-03-03", gender=Gender.MALE)
    # if gender is female, the last digit of PESEL should be even
    if pesel[:6] == "750303" and pesel[-1] == "0":
        # the pesel generated is correct
        return True
    else:
        return False

# Generated at 2022-06-23 20:40:38.730997
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    generated_nip = PolandSpecProvider().nip()
    assert generated_nip is not None


# Generated at 2022-06-23 20:40:39.701909
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider()
    assert provider.regon()

# Generated at 2022-06-23 20:40:41.351394
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Check if random nip function returns string with length 10."""
    nip = PolandSpecProvider(seed=1).regon()
    assert len(nip) == 9, 'Wrong nip length returned.'


# Generated at 2022-06-23 20:40:52.849958
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # Test method pesel of class PolandSpecProvider with preset gender
    pl = PolandSpecProvider()
    assert len(pl.pesel(gender=Gender.FEMALE)) == 11
    assert pl.pesel(gender=Gender.FEMALE)[-2] in ['0', '2', '4', '6', '8']
    assert pl.pesel(gender=Gender.MALE)[-2] in ['1', '3', '5', '7', '9']
    # Test method pesel of class PolandSpecProvider with preset birth date
    assert len(pl.pesel(birth_date=Datetime().datetime(1234, 4321))) == 11
    # Test method pesel of class PolandSpecProvider with preset gender and birth date

# Generated at 2022-06-23 20:40:53.953645
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    PolandSpecProvider()

# Generated at 2022-06-23 20:41:02.347460
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method ``pesel`` of class ``PolandSpecProvider``"""
    ps = PolandSpecProvider()
    pesel = ps.pesel()
    assert len(pesel) == 11
    assert pesel[-1] != ''
    if int(pesel[0]) == 0:
        assert int(pesel[2]) in range(0, 2)
    elif int(pesel[0]) == 1:
        assert int(pesel[2]) in range(0, 2)
    elif int(pesel[0]) == 2:
        assert int(pesel[2]) in range(2, 4)
    elif int(pesel[0]) == 3:
        assert int(pesel[2]) in range(4, 6)
    elif int(pesel[0]) == 4:
        assert int

# Generated at 2022-06-23 20:41:03.693923
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    nip = provider.nip()
    assert (type(int(nip)) == int)
    assert len(nip) == 10



# Generated at 2022-06-23 20:41:05.867802
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    p = PolandSpecProvider()
    assert len(p.regon()) == 9

# Generated at 2022-06-23 20:41:09.848470
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    # Create an instance of PolandSpecProvider and call method nip
    pl = PolandSpecProvider()
    n = pl.nip()
    print(n)
    assert(len(n) == 10)
    assert(n[0] != 0)
    int(n)


# Generated at 2022-06-23 20:41:11.038364
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    test = PolandSpecProvider()
    assert test is not None

# Generated at 2022-06-23 20:41:14.749533
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    p = PolandSpecProvider()
    assert len(p.national_identification_number()) == 11
    assert len(p.taxpayer_identification_number()) == 10
    assert (len(p.registration_identification_number_of_economic_operators())
            == 9)

# Generated at 2022-06-23 20:41:16.094156
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    assert provider is not None

# Generated at 2022-06-23 20:41:20.069872
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider=PolandSpecProvider()
    result = provider.nip()
    assert(type(result) is str)
    assert(len(result) == 10)
    assert(str(result).isnumeric())
# Test class PolandSpecProvider

# Generated at 2022-06-23 20:41:21.081133
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider(seed=12345)
    assert provider.nip() == "9405075657"


# Generated at 2022-06-23 20:41:23.130784
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    legal = set()
    for _ in range(99_999):
        ipn = PolandSpecProvider().nip()
        assert len(ipn) == 10
        assert ipn not in legal, "Generated repeated ipn " + ipn
        legal.add(ipn)
    print("All generated ipns were correct")



# Generated at 2022-06-23 20:41:26.220026
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Test method regon of class PolandSpecProvider."""
    polandSpecProvider_instance = PolandSpecProvider()
    assert (len(polandSpecProvider_instance.regon()) == 9)


# Generated at 2022-06-23 20:41:30.247956
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    pl = PolandSpecProvider()
    regon = pl.regon()
    # Check if first digit is 8 or 9
    assert int(regon[0]) in [8,9]


# Generated at 2022-06-23 20:41:37.772611
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    # 生成随机出生日期，再把这个生成的日期作为参数传给PESEL
    pesel = provider.pesel(birth_date=provider.datetime(), gender=provider.gender())
    assert len(pesel) == 11
    # 这个时间是性别是？
    year = int(pesel[0:2])
    month = int(pesel[2:4])
    if year >= 40 and year <= 99:
        year = 1900 + year
    else:
        year = 2000 + year
    if month > 80:
        month = month - 80
    elif month > 20:
        month

# Generated at 2022-06-23 20:41:40.457408
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    obj = PolandSpecProvider()
    assert isinstance(obj, PolandSpecProvider)
    assert hasattr(obj, 'random')
    assert hasattr(obj, 'datetime')
    assert hasattr(obj, 'seed')
    assert hasattr(obj, 'Meta')
    assert hasattr(obj, 'nip')
    assert hasattr(obj, 'pesel')
    assert hasattr(obj, 'regon')



# Generated at 2022-06-23 20:41:44.068905
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    # Application testing
    from mimesis import PolandSpecProvider
    PolandSpecProvider().regon()
    # Unit test
    PolandSpecProvider(seed=166).regon()
    # 943203028


# Generated at 2022-06-23 20:41:48.667587
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    p = PolandSpecProvider()
    print(p.nip())
    print(p.nip())
    print(p.nip())
    print(p.nip())
    print(p.nip())
    print(p.nip())
    print(p.nip())
    print(p.nip())
    print(p.nip())



# Generated at 2022-06-23 20:41:52.030912
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Test method regon of class PolandSpecProvider."""
    p = PolandSpecProvider()
    regon = p.regon()
    assert len(regon) == 9
    assert isinstance(regon,str)


# Generated at 2022-06-23 20:41:55.212913
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    p = PolandSpecProvider()
    assert p is not None
    assert p.__class__.__name__ == 'PolandSpecProvider'
    assert p.provider == "poland_provider"


# Generated at 2022-06-23 20:42:04.373005
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    result = provider.nip()
    assert(len(result) is 10)
    assert(int(result[0]) is 1)
    assert(int(result[1]) in range(0,10))
    assert(int(result[2]) in range(0,10))
    assert(int(result[3]) in range(0,10))
    assert(int(result[4]) in range(0,10))
    assert(int(result[5]) in range(0,10))
    assert(int(result[6]) in range(0,10))
    assert(int(result[7]) in range(0,10))
    assert(int(result[8]) in range(0,10))
    assert(int(result[9]) in range(0,10))


# Generated at 2022-06-23 20:42:05.132446
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    pass

# Test 'nip()' function

# Generated at 2022-06-23 20:42:09.220453
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    nip = PolandSpecProvider().nip()
    assert len(nip) == 10

    nip_coefficients = (6, 5, 7, 2, 3, 4, 5, 6, 7)
    nip_digits = [int(d) for d in str(nip)]
    sum_v = sum([nc * nd for nc, nd in zip(nip_coefficients, nip_digits)])
    checksum_digit = sum_v % 11

    assert checksum_digit == nip_digits[9]


# Generated at 2022-06-23 20:42:16.295688
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    seed = "kfjgffjkfhkfjhfjkfhfjkfhjfjkfhjkfhkfjhfjkfhjfkdgjfdjfdgfdgfdjfdjfdjfd"
    provider = PolandSpecProvider(seed)
    assert provider.pesel(gender=Gender.MALE, birth_date="2007-01-01") == "07010117211"
    assert provider.pesel(gender=Gender.FEMALE, birth_date="1999-01-01") == "99010199925"

# Generated at 2022-06-23 20:42:25.386888
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    import datetime
    from mimesis.enums import Gender
    from mimesis.providers import Person
    # Get a random person object
    pesel_provider = PolandSpecProvider(seed=12345)
    # Set the gender.
    gender = Gender.MALE
    # Set the birth date.
    birth_date = datetime.datetime(1998, 12, 12)
    pesel_number = pesel_provider.pesel(birth_date=birth_date, gender=gender)
    # Get the current date to compute the age.
    today = datetime.date.today()
    years_difference = today.year - birth_date.year
    is_before_birthday = (today.month, today.day) < (birth_date.month, birth_date.day)
    age = years_difference

# Generated at 2022-06-23 20:42:29.732178
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    # Given
    provider = PolandSpecProvider()

    # When
    regon = provider.regon()

    # Then
    assert regon != ""
    assert len(regon) == 9
    assert int(regon) > 0
    #print(regon)



# Generated at 2022-06-23 20:42:32.503416
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider('12345')
    print (provider.nip())
    #print (provider.nip(),provider.nip(),provider.nip(),provider.nip())


# Generated at 2022-06-23 20:42:34.908770
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    from mimesis import PolandSpecProvider
    gen = PolandSpecProvider()
    result = gen.nip()
    assert len(result) == 10
    assert result.isdigit() == True


# Generated at 2022-06-23 20:42:39.244122
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    '''
    Checks if method returns 9-digit string.
    '''
    provider = PolandSpecProvider()
    regon = provider.regon()
    assert type(regon) == str
    assert len(regon) == 9

# Generated at 2022-06-23 20:42:47.802078
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider= PolandSpecProvider()
    assert provider.nip()[0]=='1'
    assert provider.regon()[0]=='0' or provider.regon()[0]=='1' or provider.regon()[0]=='2' or provider.regon()[0]=='3' or provider.regon()[0]=='4' or provider.regon()[0]=='5' or provider.regon()[0]=='6' or provider.regon()[0]=='7' or provider.regon()[0]=='8' or provider.regon()[0]=='9'
    assert len(provider.regon())==9
    assert len(provider.nip())==10

# Generated at 2022-06-23 20:42:52.243108
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    from mimesis import PolandSpecProvider
    seed = "TEST"
    PolandProvider = PolandSpecProvider(seed=seed)
    pesel = PolandProvider.pesel(gender="MALE")
    assert pesel == "42016853638"


# Generated at 2022-06-23 20:42:54.570299
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    nip = provider.nip()
    print(nip)


# Generated at 2022-06-23 20:42:57.619697
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    temp = PolandSpecProvider(seed=1)
    assert temp.nip() == '3837741144'


# Generated at 2022-06-23 20:43:01.973934
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    # Returns a valid 11-digit PESEL
    print(p.pesel(Datetime().datetime(2000,2000), Gender.MALE))
    # Returns a valid 11-digit PESEL
    print(p.pesel(Datetime().datetime(2000,2000), Gender.FEMALE))


# Generated at 2022-06-23 20:43:04.113392
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    assert len(PolandSpecProvider().nip()) == 10


# Generated at 2022-06-23 20:43:05.956970
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    pl = PolandSpecProvider()
    ip = pl.nip()
    assert len(ip) == 10

# Generated at 2022-06-23 20:43:08.777568
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    # Arrange
    p = PolandSpecProvider()
    # Act
    wynik = p.nip()
    # Assert
    assert(wynik)


# Generated at 2022-06-23 20:43:10.274833
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Unit test for constructor of class PolandSpecProvider.
    """
    PolandSpecProvider(seed=42)


# Generated at 2022-06-23 20:43:16.376571
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    print('== Testing method nip of class PolandSpecProvider ==')
    print('Load package mimesis and class PolandSpecProvider')
    from mimesis import PolandSpecProvider
    from mimesis.enums import Gender
    from mimesis.typing import DateTime
    print('Create PolandSpecProvider instance')
    poland_provider = PolandSpecProvider()
    print('NIP: ' + poland_provider.nip())
    print()


# Generated at 2022-06-23 20:43:20.044023
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    for i in range(10):
        provider = PolandSpecProvider()
        regon = provider.regon()
        print ('REGON:', regon)
        

# Generated at 2022-06-23 20:43:24.755228
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Test for PolandSpecProvider.nip."""
    from mimesis.providers import PolandSpecProvider
    poland_provider = PolandSpecProvider()
    for _ in range(10):
        nip = poland_provider.nip()
        assert len(nip) == 10
        assert nip.isnumeric()


# Generated at 2022-06-23 20:43:27.592007
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    poland_provider = PolandSpecProvider()
    nip = poland_provider.nip()
    assert len(nip) == 10
    assert nip.isdecimal() == True

# Generated at 2022-06-23 20:43:31.388531
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    nip_list = []
    nip_set = set()
    for i in range(1000):
        nip_list.append(PolandSpecProvider().nip())
    for i in nip_list:
        nip_set.add(i)
    asser

# Generated at 2022-06-23 20:43:36.291605
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Test constructor of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    assert provider.nip() == '819-62-79-963'
    assert provider.regon() == '091905501'
    assert provider.pesel() == '99052502905'

# Generated at 2022-06-23 20:43:40.420292
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Test method."""
    provider = PolandSpecProvider()
    nip = provider.nip()
    pesel = provider.pesel()
    regon = provider.regon()
    assert len(nip) == 10
    assert len(pesel) == 11
    assert len(regon) == 9

# Generated at 2022-06-23 20:43:47.477091
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    expected = '6093442079'
    rand = PolandSpecProvider()
    test_result = rand.nip()
    try:
        assert test_result == expected
    except AssertionError:
        print('AssertionError: expected result:\n', expected, '\nbut got:\n', test_result)
    except:
        print('Unexpected error:', sys.exc_info()[0])
        raise
    else:
        print('Test: expected result == test result: OK')


# Generated at 2022-06-23 20:43:49.133899
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel().__str__()
    assert len(pesel) == 11
    assert isinstance(pesel, str)

# Generated at 2022-06-23 20:43:58.786839
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
  # Test if the generated PESEL is valid.
  pesel = PolandSpecProvider().pesel(birth_date=Datetime().datetime(1950, 2019), gender=Gender.MALE)
  assert len(pesel) == 11
  pesel_int_list = [int(c) for c in pesel]
  year = pesel_int_list[0] * 10 + pesel_int_list[1]
  month = pesel_int_list[2] * 10 + pesel_int_list[3]
  day = pesel_int_list[4] * 10 + pesel_int_list[5]
  assert (year >= 50 and year <= 99) or (year >= 0 and year <= 49) and month >= 1 and month <= 12 and day >= 1 and day <= 31

  # Test if the generated PESEL is

# Generated at 2022-06-23 20:44:07.555051
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    pl = PolandSpecProvider(seed=123)
    regon = pl.regon()
    assert regon == '143452559'
    regon = pl.regon()
    assert regon == '920361312'
    regon = pl.regon()
    assert regon == '570659215'
    regon = pl.regon()
    assert regon == '671457264'
    regon = pl.regon()
    assert regon == '838304205'
    regon = pl.regon()
    assert regon == '061211607'
    regon = pl.regon()
    assert regon == '801433086'
    regon = pl.regon()
    assert regon == '817284864'
    regon = pl.regon()

# Generated at 2022-06-23 20:44:15.924285
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unittest"""
    provider = PolandSpecProvider()
    assert provider.pesel() == '49018111222'
    assert provider.pesel(gender=Gender.FEMALE) == '49018111324'
    assert provider.pesel(gender=Gender.MALE) == '49018111226'
    # values for random day and month for year 1986
    assert provider.pesel(gender=Gender.MALE, birth_date=1986) == '86122111323'
    assert provider.pesel(gender=Gender.FEMALE, birth_date=1986) == '86122111674'


# Generated at 2022-06-23 20:44:18.329198
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel_sample = PolandSpecProvider(seed=1234).pesel()
    assert pesel_sample == '00010112345'

# Generated at 2022-06-23 20:44:28.669899
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider()
    regex = re.compile("[0-9]")
    
    # Test 1
    regon = PolandSpecProvider.regon(provider)
    assert len(regon) == 9
    assert regex.findall(regon) == list(regon)
    
    # Test 2
    regon = PolandSpecProvider.regon(provider)
    assert len(regon) == 9
    assert regex.findall(regon) == list(regon)
    
    # Test 3
    regon = PolandSpecProvider.regon(provider)
    assert len(regon) == 9
    assert regex.findall(regon) == list(regon)
    
    # Test 4
    regon = PolandSpecProvider.regon(provider)
    assert len(regon) == 9
    assert regex.findall(regon) == list

# Generated at 2022-06-23 20:44:31.778881
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test if pesel method works properly."""
    pesel = PolandSpecProvider().pesel()
    assert len(pesel) == 11

# Generated at 2022-06-23 20:44:35.850091
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Unit test for method nip of class PolandSpecProvider."""
    expected_result = '32123456789'
    assert expected_result == PolandSpecProvider().nip()



# Generated at 2022-06-23 20:44:41.170447
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()

    nip = provider.nip()
    assert isinstance(nip, str)
    assert len(nip) == 10

    pesel = provider.pesel(birth_date=provider.datetime(2001, 2003))
    assert isinstance(pesel, str)
    assert len(pesel) == 11

    regon = provider.regon()
    assert isinstance(regon, str)
    assert len(regon) == 9


# Generated at 2022-06-23 20:44:49.354535
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Test method nip of class PolandSpecProvider."""
    # Test seed
    N = 10
    seed = 'test'
    pl_provider_seed = PolandSpecProvider(seed=seed)
    result_1 = [pl_provider_seed.nip() for _ in range(N)]

    # Test not seed
    pl_provider_not_seed = PolandSpecProvider()
    result_2 = [pl_provider_not_seed.nip() for _ in range(N)]

    assert result_1 != result_2


# Generated at 2022-06-23 20:44:52.990362
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    PolandSpecProvider_nip_obj = PolandSpecProvider()
    nip_value = PolandSpecProvider_nip_obj.nip()
    print(nip_value)
    assert len(nip_value) == 10


# Generated at 2022-06-23 20:44:56.634534
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider_name = PolandSpecProvider
    random_regon = provider_name.regon(provider_name)

    assert isinstance(random_regon, str)
    assert len(random_regon) == 9
    assert random_regon.isdigit()


# Generated at 2022-06-23 20:45:00.593780
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    pl = PolandSpecProvider()
    nip = pl.nip()
    nip_is_valid = False
    nip_coefficients = [6, 5, 7, 2, 3, 4, 5, 6, 7, 2, 3, 4, 5, 6, 7]
    nip_digits = list(map(int, nip))
    sum_v = sum([nc * nd for nc, nd in
                 zip(nip_coefficients, nip_digits)])
    checksum = sum_v % 11

    if checksum == 10:
        nip_is_valid = False
    else:
        if checksum != nip_digits[-1]:
            nip_is_valid = False
        else:
            nip_is_valid = True

    assert nip_is_valid

# Generated at 2022-06-23 20:45:01.944331
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    assert provider is not None


# Generated at 2022-06-23 20:45:03.248946
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    assert PolandSpecProvider().pesel()

# Generated at 2022-06-23 20:45:06.987544
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    ID = PolandSpecProvider()
    nip = ID.nip()
    assert len(nip) == 10
    assert nip.isdigit()
    assert int(nip[:3]) > 100
    assert int(nip[:3]) < 999


# Generated at 2022-06-23 20:45:08.814560
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    PolandSpecProvider()


# Generated at 2022-06-23 20:45:10.956195
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    obj = PolandSpecProvider()
    result = obj.regon()
    assert result == '816621832'

# Generated at 2022-06-23 20:45:18.929650
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    pesel = PolandSpecProvider().regon()
    regon_coeffs = (8, 9, 2, 3, 4, 5, 6, 7)
    regon_digits = [int(d) for d in str(pesel)]
    sum_v = sum([nc * nd for nc, nd in
                 zip(regon_coeffs, regon_digits)])
    checksum_digit = sum_v % 11
    if checksum_digit > 9:
        checksum_digit = 0

    assert(regon_digits[-1] == checksum_digit)
    assert(len(pesel)==9) # REGON składa się z 9 cyfr


# Generated at 2022-06-23 20:45:29.319071
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Test method nip of class PolandSpecProvider
    should returns valid 10-digit nip."""
    poland_provider = PolandSpecProvider()
    nip_number = poland_provider.nip()

    # Check length of generated number
    expected_length = 10
    actual_length = len(nip_number)
    assert actual_length == expected_length

    # Check format number
    actual_format = all([str(digit).isdigit() for digit in nip_number])
    assert actual_format

    # Check the control number
    nip_coefficients = (6, 5, 7, 2, 3, 4, 5, 6, 7)
    nip_digits = [int(nip_number[i]) for i in range(9)]

# Generated at 2022-06-23 20:45:30.424425
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    pl = PolandSpecProvider()
    assert pl is not None


# Generated at 2022-06-23 20:45:35.461588
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    assert provider.pesel(birth_date=Datetime().datetime(1980, 2018)) == '00073008620'
    assert provider.pesel(gender=Gender.MALE) == '92070146768'
    assert provider.pesel(birth_date=Datetime().datetime(1980, 2018), gender=Gender.MALE) == '80022142784'


# Generated at 2022-06-23 20:45:37.195520
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    result = provider.nip()
    assert result


# Generated at 2022-06-23 20:45:38.149783
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    assert len(PolandSpecProvider().regon()) == 9

# Generated at 2022-06-23 20:45:44.990841
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    from hypothesis import given
    from hypothesis.strategies import integers
    from hypothesis.strategies import text
    from mimesis.enums import Gender
    from mimesis.providers.date_time import Datetime

    class UnitTestPolandSpecProvider(PolandSpecProvider):
        """Class to test PolandSpecProvider."""

        def __init__(self, seed=None):
            """Initialize attributes."""
            super().__init__(seed=seed)


# Generated at 2022-06-23 20:45:47.571474
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider()
    list_regon = list(map(provider.regon, range(100)))
    for regon in list_regon:
        assert len(regon) == 9


# Generated at 2022-06-23 20:45:50.568313
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Test method regon of class PolandSpecProvider."""
    pes = PolandSpecProvider()
    print(pes.regon())
    print(pes.regon())
    print(pes.regon())

# Generated at 2022-06-23 20:45:59.571832
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """
    Tests for correct implementation of method pesel for class PolandSpecProvider
    """
    pl = PolandSpecProvider()
    assert type(pl.pesel()) == str
    assert len(pl.pesel()) == 11

    pl = PolandSpecProvider(seed=112)
    assert pl.pesel() == '00012090336'

    year, month, day = 1990, 12, 3
    pl = PolandSpecProvider(seed=112)
    assert pl.pesel(birth_date=pl.datetime(year, year, month, month, day, day)) == '00012090336'

    pl = PolandSpecProvider(seed=112)
    assert pl.pesel(gender=Gender.MALE) == '64067698800'

    pl = PolandSpecProvider(seed=112)

# Generated at 2022-06-23 20:46:02.328946
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    pl_provider = PolandSpecProvider()
    print('Testing method nip of class PolandSpecProvider.')
    print('Generated NIP:', pl_provider.nip())



# Generated at 2022-06-23 20:46:09.684421
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Unit test for constructor of class PolandSpecProvider"""

    poland_provider = PolandSpecProvider()

    assert poland_provider._data == {
        'nip': {'prefix': 'PL', 'mask': '##########'},
        'pesel': {'prefix': '', 'mask': '###########'},
        'regon': {'prefix': '', 'mask': '########'}
    }

# Generated at 2022-06-23 20:46:13.259763
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    # Validate NIP by length
    assert len(provider.nip()) == 10


# Generated at 2022-06-23 20:46:16.748496
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    from mimesis.providers.poland import PolandSpecProvider
    polandSpecProvider = PolandSpecProvider()
    regon = polandSpecProvider.regon()
    assert len(regon) == 9
    assert type(regon) == str


# Generated at 2022-06-23 20:46:19.741106
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Unit test for constructor of class PolandSpecProvider."""
    p = PolandSpecProvider(seed=0)
    assert str(p.locales) == "<Locales ['pl']>"


# Generated at 2022-06-23 20:46:25.701642
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    p = PolandSpecProvider()
    pesel_x = p.pesel()
    pesel_y = p.pesel(birth_date=p.datetime(2010, 2020), gender=Gender.MALE)
    assert len(pesel_x) == len(pesel_y) == 11


# Generated at 2022-06-23 20:46:32.680846
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    import random
    import unittest

    class PolandSpecProviderTestCase(unittest.TestCase):
        def setUp(self):
            self.regony = []
            self.poland_provider = PolandSpecProvider(seed=random.randint(0, 100000))

        def test_regon(self):
            for i in range(5000):
                regon = self.poland_provider.regon()
                if regon in self.regony:
                    self.assertTrue(False, regon)
                else:
                    self.regony.append(regon)

    unittest.main()

# Generated at 2022-06-23 20:46:34.632633
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider=PolandSpecProvider()
    assert provider.nip() is not ''


# Generated at 2022-06-23 20:46:36.693547
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pp = PolandSpecProvider()
    result = pp.pesel()
    assert len(result) == 11


# Generated at 2022-06-23 20:46:38.885899
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    p = PolandSpecProvider()
    assert isinstance(p, PolandSpecProvider)


# Generated at 2022-06-23 20:46:45.447950
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    import datetime as dt
    pl = PolandSpecProvider()
    # Get expected result
    expected_result = "97062219989"
    # Execute function pesel of class PolandSpecProvider
    # with arguments birth_date=dt.datetime(1997,6,22), gender="FEMALE"
    result = pl.pesel(birth_date=dt.datetime(1997,6,22), gender="FEMALE")
    # Compare expected result with result
    assert expected_result == result

# Generated at 2022-06-23 20:46:47.854942
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    # GIVEN
    poland_spec_provider = PolandSpecProvider()
    # WHEN
    regon = poland_spec_provider.regon()
    # THEN
    assert len(regon) == 9

# Generated at 2022-06-23 20:46:51.288928
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    print("Running test_PolandSpecProvider_pesel...")
    provider = PolandSpecProvider()
    for i in range(100):
        provider.pesel()


# Generated at 2022-06-23 20:46:53.428884
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    ps_provider = PolandSpecProvider()
    assert ps_provider is not None


# Generated at 2022-06-23 20:46:55.289280
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    pl = PolandSpecProvider()
    assert pl.random.randint(0, 10)


# Generated at 2022-06-23 20:46:57.369883
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider()
    regon = provider.regon()
    assert len(regon) == 9 and regon.isdigit()


# Generated at 2022-06-23 20:46:59.842689
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    p = PolandSpecProvider()
    results = []
    for i in range(10):
        result = p.regon()
        if result not in results:
            results.append(result)
    assert len(results) == 10


# Generated at 2022-06-23 20:47:01.597655
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()
    assert str.isdigit(pesel) == True
    assert len(pesel) == 11

# Generated at 2022-06-23 20:47:07.388213
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    # Provide a valid 9-digit REGON string
    generatedDigits = PolandSpecProvider().regon()
    # Check if the string has 9 digits
    assert len(generatedDigits) == 9
    # Check if the string is valid
    assert PolandSpecProvider().is_regon(generatedDigits)