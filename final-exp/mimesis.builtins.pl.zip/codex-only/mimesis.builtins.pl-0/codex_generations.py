

# Generated at 2022-06-23 20:37:11.041114
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()
    pesel2 = PolandSpecProvider(seed=pesel).pesel()
    assert pesel == pesel2

# Generated at 2022-06-23 20:37:13.739819
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Test for method nip of class PolandSpecProvider."""
    pl = PolandSpecProvider()
    assert pl.nip() == '7111012374'


# Generated at 2022-06-23 20:37:17.736205
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Unit test for method regon of class PolandSpecProvider."""

    test = PolandSpecProvider()
    result = test.regon()
    assert len(result) == 9 and result.isdigit() == True


# Generated at 2022-06-23 20:37:19.387101
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
	a = PolandSpecProvider()
	assert a.locale == 'pl'


# Generated at 2022-06-23 20:37:21.121702
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    PolandSpecProvider(seed=None)



# Generated at 2022-06-23 20:37:23.470571
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    poland_spec_provider = PolandSpecProvider()
    assert len(poland_spec_provider.nip()) == 10


# Generated at 2022-06-23 20:37:25.410808
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Test method regon in class PolandSpecProvider."""
    x = PolandSpecProvider()
    result = x.regon()
    print(result)

# Generated at 2022-06-23 20:37:27.007325
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    result = provider.nip()
    assert len(result) == 10, "Length of NIP must be 10"
    try:
        int(result)
    except ValueError:
        assert False, "NIP must contain only digits"



# Generated at 2022-06-23 20:37:28.965724
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    assert provider.nip() == "8983616437"


# Generated at 2022-06-23 20:37:29.993674
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    assert len(PolandSpecProvider().regon()) == 9

# Generated at 2022-06-23 20:37:32.911282
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    pl = PolandSpecProvider()
    assert len(pl.nip()) == 10
    assert len(pl.pesel()) == 11
    assert len(pl.regon()) == 9


# Generated at 2022-06-23 20:37:34.334644
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    assert PolandSpecProvider().pesel() == '91062610793'

# Generated at 2022-06-23 20:37:40.481544
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    unit = PolandSpecProvider()
    # Unit test for method nip of class PolandSpecProvider
    assert len(unit.nip()) == 10
    # Unit test for method pesel of class PolandSpecProvider
    assert len(unit.pesel()) == 11
    # Unit test for method regon of class PolandSpecProvider
    assert len(unit.regon()) == 9

    return None

# Unit test

# Generated at 2022-06-23 20:37:47.371976
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    nip_of_person = provider.nip()
    assert type(nip_of_person) is str
    assert len(nip_of_person) == 10

    pesel_of_person = provider.pesel()
    assert type(pesel_of_person) is str
    assert len(pesel_of_person) == 11
    assert pesel_of_person.isdigit() is True

    pesel_of_person = provider.pesel(gender=Gender.MALE)
    assert type(pesel_of_person) is str
    assert len(pesel_of_person) == 11
    assert pesel_of_person.isdigit() is True
    pesel_last_number = int(pesel_of_person[10])
    assert pesel_last

# Generated at 2022-06-23 20:37:48.113688
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    x = PolandSpecProvider()
    y = x.regon()
    # print(y)


# Generated at 2022-06-23 20:37:55.465416
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    from random import seed
    p = PolandSpecProvider()
    value_list = []
    for _ in range(100):
        t = p.nip()
        value = int(t)
        value_list.append(value)

    seed(17)
    assert p.nip() == '0005273338'
    value_list = []
    for _ in range(100):
        t = p.nip()
        value = int(t)
        value_list.append(value)

    seed(17)

# Generated at 2022-06-23 20:37:57.356593
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    data = PolandSpecProvider()
    regon = data.regon()
    assert len(regon) == 9
    assert type(regon) == str

# Generated at 2022-06-23 20:38:00.910668
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    assert provider.pesel(None, Gender.MALE) == provider.pesel(None, Gender.MALE)
    assert provider.pesel(None, Gender.FEMALE) == provider.pesel(None, Gender.FEMALE)
    assert provider.pesel(None) == provider.pesel(None)

# Generated at 2022-06-23 20:38:08.346038
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():

    # Test various different genders
    assert PolandSpecProvider().pesel(gender=Gender.MALE)[-1] in ['1', '3', '5', '7', '9']
    assert PolandSpecProvider().pesel(gender=Gender.FEMALE)[-1] in ['0', '2', '4', '6', '8']

    # Test if pesel format is valid
    assert len(PolandSpecProvider().pesel()) == 11
    assert len(PolandSpecProvider().pesel(gender=Gender.MALE)) == 11
    assert len(PolandSpecProvider().pesel(gender=Gender.FEMALE)) == 11


# Generated at 2022-06-23 20:38:11.329511
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Unit test for method nip of class PolandSpecProvider."""
    plsp = PolandSpecProvider()
    nip = plsp.nip()
    assert len(nip) == 10 and nip.isdigit()


# Generated at 2022-06-23 20:38:13.672201
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    # When I create PolandSpecProvider object
    pl_spec_provider = PolandSpecProvider()
    # Then it is PolandSpecProvider
    assert isinstance(pl_spec_provider, PolandSpecProvider)



# Generated at 2022-06-23 20:38:15.831250
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Test for regon."""
    poland_provider = PolandSpecProvider(seed=56)
    result = poland_provider.regon()
    assert result == '435665342'

# Generated at 2022-06-23 20:38:17.281335
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Test for constructor."""
    provider = PolandSpecProvider()
    assert provider.country == 'Poland'

# Generated at 2022-06-23 20:38:23.009358
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    p = PolandSpecProvider(seed=12345)

    output = p.nip()
    assert output == '8905391963'

    p = PolandSpecProvider(seed=12345)
    output = p.nip()
    assert output == '8905391963'

    p = PolandSpecProvider(seed=12345)
    output = p.nip()
    assert output == '8905391963'


# Generated at 2022-06-23 20:38:30.994533
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Test method nip of class PolandSpecProvider."""
    from mimesis.providers.address import Address

    provider = Address('pl')
    nip = provider.nip()
    nip_coefficients = (6, 5, 7, 2, 3, 4, 5, 6, 7)
    nip_digits = [int(d) for d in nip]
    sum_v = sum([nc * nd for nc, nd in
                 zip(nip_coefficients, nip_digits)])
    checksum_digit = sum_v % 11
    assert str(checksum_digit) == nip[-1]


# Generated at 2022-06-23 20:38:32.486240
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    assert len(PolandSpecProvider.pesel()) == 11

# Generated at 2022-06-23 20:38:35.672432
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    from mimesis.builtins.pl import PolandSpecProvider
    pl = PolandSpecProvider()
    list_of_regon = []
    for i in range(1000):
        list_of_regon.append(pl.regon())
    assert all([True if len(str(nr)) == 9 else False for nr in list_of_regon])


# Generated at 2022-06-23 20:38:36.570991
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    polandSpecProvider = PolandSpecProvider()
    polandSpecProvider.pesel()

# Generated at 2022-06-23 20:38:41.518566
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    pl = PolandSpecProvider()
    nip = pl.nip()
    assert type(nip) == str
    assert len(nip) == 10
    assert type(pl.pesel()) == str
    assert len(pl.pesel()) == 11
    assert type(pl.regon()) == str
    assert len(pl.regon()) == 9

# Generated at 2022-06-23 20:38:44.406686
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    a = PolandSpecProvider()
    assert a.pesel() == '29111701156'
    assert a.pesel(gender=Gender.MALE) == '08121581012'



# Generated at 2022-06-23 20:38:48.350665
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    assert len(provider.nip()) == 10
    assert provider.nip().isdigit()
    assert provider.nip()[0] == '1'


# Generated at 2022-06-23 20:38:51.418436
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    psp = PolandSpecProvider()
    nip = psp.nip()
    assert nip
    assert len(nip) == 10
    assert int(nip[-1]) % 10 == 0


# Generated at 2022-06-23 20:38:56.670372
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_provider = PolandSpecProvider()
    print(poland_provider.pesel())
    # print(poland_provider.pesel(birth_date=datetime.datetime(1984,3,3,3,3,3), gender=Gender.MALE))
    # print(poland_provider.pesel(birth_date=datetime.datetime(1984,3,3,3,3,3), gender=Gender.FEMALE))
    print("Finish: test_PolandSpecProvider_pesel")



# Generated at 2022-06-23 20:38:57.665700
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    assert PolandSpecProvider()


# Generated at 2022-06-23 20:39:04.965010
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Unit test for method regon of class PolandSpecProvider"""
    provider = PolandSpecProvider()
    regon = provider.regon()
    assert isinstance(regon, str)
    assert len(regon) == 9

    # call regon multiple times with the same seed
    provider = PolandSpecProvider(seed=0)
    regon1 = provider.regon()
    regon2 = provider.regon()
    assert regon1 == '033501504'
    assert regon2 == '674252546'


# Generated at 2022-06-23 20:39:11.576631
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Generating and validating random 10-digit NIP"""
    for _ in range(10):
        provider = PolandSpecProvider()
        generated_nip = provider.nip()
        assert len(generated_nip) == 10
        assert generated_nip[0] in ('1','2','3','5','6','7','8','9')
        assert generated_nip[1] in ('0','1','2','3','4','5','6','7','8','9')
        assert generated_nip[2] in ('0','1','2','3','4','5','6','7','8','9')
        assert generated_nip[3] in ('0','1','2','3','4','5','6','7','8','9')

# Generated at 2022-06-23 20:39:16.361458
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    # Given
    polandProvider = PolandSpecProvider()
    # When
    nip = polandProvider.nip()
    # Then
    assert len(nip) == 10


# Generated at 2022-06-23 20:39:18.026803
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    data = PolandSpecProvider()
    assert data['pl_provider'].nip() == '1'

# Generated at 2022-06-23 20:39:19.724507
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider()
    regon = provider.regon()
    assert len(regon) == 9

# Generated at 2022-06-23 20:39:20.947592
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    pl = PolandSpecProvider()
    for _ in range(100):
        assert len(pl.nip()) == 10


# Generated at 2022-06-23 20:39:28.330556
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Unit test for method regon of class PolandSpecProvider."""
    p = PolandSpecProvider()
    regon = p.regon()
    assert len(regon) == 9
    regon_int = int(regon)
    regon_digits = [int(d) for d in str(regon_int)]
    regon_coeffs = (8, 9, 2, 3, 4, 5, 6, 7)
    sum_v = sum([nc * nd for nc, nd in
                 zip(regon_coeffs, regon_digits)])
    checksum_digit = sum_v % 11
    if checksum_digit > 9:
        checksum_digit = 0
    assert (checksum_digit == regon_digits[8])
    print("test_PolandSpecProvider_regon() finished successfully.")

# Generated at 2022-06-23 20:39:30.087266
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    from mimesis.providers.poland import PolandSpecProvider
    assert len(PolandSpecProvider().nip()) == 10


# Generated at 2022-06-23 20:39:36.209456
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    poland_provider = PolandSpecProvider()
    nip = poland_provider.nip()
    pesel = poland_provider.pesel()
    regon = poland_provider.regon()
    print(nip)
    print(pesel)
    print(regon)


import unittest


# Generated at 2022-06-23 20:39:39.580995
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # GIVEN
    provider = PolandSpecProvider()

    # WHEN
    pesel1 = provider.pesel()
    pesel2 = provider.pesel()

    # THEN
    assert len(pesel1) == len(pesel2) == 11
    assert pesel1 != pesel2


# Generated at 2022-06-23 20:39:40.718372
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    assert PolandSpecProvider().nip()


# Generated at 2022-06-23 20:39:44.701505
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Test method regon of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    regon = provider.regon()
    assert len(regon) == 9
    assert int(regon) % 11 == int(regon[-1])


# Generated at 2022-06-23 20:39:48.610838
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    expected_result = '727175158'
    actual_result = PolandSpecProvider(seed=203).regon()
    assert expected_result == actual_result



# Generated at 2022-06-23 20:39:52.612504
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    def is_valid_pesel(pesel):
        return len(pesel) == 11 and pesel.isnumeric()
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert is_valid_pesel(pesel)

test_PolandSpecProvider_pesel()


# Generated at 2022-06-23 20:40:00.840092
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    assert PolandSpecProvider().nip()[:3] == "101"
    assert PolandSpecProvider().nip()[:3] == "102"
    assert PolandSpecProvider().nip()[:3] == "103"
    assert PolandSpecProvider().nip()[:3] == "104"
    assert PolandSpecProvider().nip()[:3] == "105"
    assert PolandSpecProvider().nip()[:3] == "106"
    assert PolandSpecProvider().nip()[:3] == "107"
    assert PolandSpecProvider().nip()[:3] == "108"
    assert PolandSpecProvider().nip()[:3] == "109"
    assert PolandSpecProvider().nip()[:3] == "110"
    assert PolandSpecProvider().nip()[:3] == "111"
   

# Generated at 2022-06-23 20:40:02.495569
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    print("pesel test, result:", PolandSpecProvider().pesel())
    return


# Generated at 2022-06-23 20:40:03.399236
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    p = PolandSpecProvider()
    assert p.regon() in p._regon_18

# Generated at 2022-06-23 20:40:10.293356
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """
    This method is intended to be used as a unit test of
    the method regon of class PolandSpecProvider.

    Example output:
    >>> test_PolandSpecProvider_regon()
    837117767

    """

    from mimesis.providers.poland import PolandSpecProvider

    provider = PolandSpecProvider()
    print(provider.regon())

# Generated at 2022-06-23 20:40:17.396952
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Test method regon of class PolandSpecProvider"""
    failed_tests = []
    failed_test_cases = []

    # Test case 1
    pesel = '28301191850'
    expected_result = "471378605"

    result = PolandSpecProvider().regon()
    if result != expected_result:
        failed_tests.append(result)
        failed_test_cases.append(1)

    # Test case 2
    pesel = '28301191850'
    expected_result = "471378605"

    result = PolandSpecProvider(28301191850).regon()
    if result != expected_result:
        failed_tests.append(result)
        failed_test_cases.append(2)

    print(f"Test cases failed: {failed_test_cases}")

# Generated at 2022-06-23 20:40:19.321903
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    pesel = PolandSpecProvider().regon()
    assert isinstance(pesel, str) and len(pesel) == 9


# Generated at 2022-06-23 20:40:21.748516
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test function"""
    obj = PolandSpecProvider()
    pesel = obj.pesel()
    assert len(pesel) == 11


# Generated at 2022-06-23 20:40:26.328619
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider.
    """
    pesel = PolandSpecProvider().pesel()
    assert len(pesel) == 11
    assert int(pesel) > 10000000000
    assert int(pesel) < 99999999999

# Generated at 2022-06-23 20:40:32.190148
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    nip_test = PolandSpecProvider().nip()
    pesel_test = PolandSpecProvider().pesel()
    regon_test = PolandSpecProvider().regon()

    pesel_res = len(pesel_test)
    regon_res = len(regon_test)
    nip_res = len(nip_test)

    assert pesel_res == 11
    assert regon_res == 9
    assert nip_res == 10

# Generated at 2022-06-23 20:40:34.076942
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    pl = PolandSpecProvider()
    # print(pl.nip())
    assert len(pl.nip()) == 10


# Generated at 2022-06-23 20:40:37.130185
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    a=PolandSpecProvider()

    assert isinstance(a,BaseSpecProvider)
    assert a.get("locale")=="pl"
    assert a.get("seed")==a.random.seed



# Generated at 2022-06-23 20:40:40.259258
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test if pesel method of PolandSpecProvider works correctly."""
    provider = PolandSpecProvider()
    result = provider.pesel(gender=Gender.MALE)
    assert len(result) == 11
    assert result[9] in ('1', '3', '5', '7', '9')



# Generated at 2022-06-23 20:40:41.211443
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    assert len(PolandSpecProvider().regon()) == 9

# Generated at 2022-06-23 20:40:48.115674
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    pl = PolandSpecProvider()
    nip = pl.nip();
    assert len(nip) == 10
    assert '-' not in nip
    assert nip.isdigit()
    pesel = pl.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert '-' not in pesel
    regon = pl.regon()
    assert len(regon) == 9
    assert regon.isdigit()
    assert '-' not in regon

# Generated at 2022-06-23 20:40:51.199137
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Unit test for method nip of class PolandSpecProvider"""

    provider = PolandSpecProvider()
    provider.nip()



# Generated at 2022-06-23 20:40:54.390146
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    # Arrange
    provider = PolandSpecProvider(seed=987654321)

    # Act
    result = provider.regon()

    # Assert
    assert result == '500361860'

# Generated at 2022-06-23 20:40:55.311476
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    return PolandSpecProvider().regon()


# Generated at 2022-06-23 20:41:03.221113
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # Test with no param
    assert len(PolandSpecProvider().pesel()) == 11
    assert PolandSpecProvider().pesel()[:2] in ("19","20")
    assert PolandSpecProvider().pesel()[2:4] in ("01","02","03","04","05","06","07","08","09","10","11","12")
    assert PolandSpecProvider().pesel()[4:6] in ("01","02","03","04","05","06","07","08","09","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30","31")

# Generated at 2022-06-23 20:41:06.657731
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    poland_provider = PolandSpecProvider()
    assert poland_provider.locale == 'pl'



# Generated at 2022-06-23 20:41:07.931024
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    PolandSpecProvider()

# Generated at 2022-06-23 20:41:13.868580
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    assert provider.pesel() in provider.gen_pesel()
    assert provider.pesel(gender=Gender.MALE) in provider.gen_pesel()
    assert provider.pesel(gender=Gender.FEMALE) in provider.gen_pesel()
    assert provider.pesel(birth_date=Datetime(provider).datetime(1995, 1997)) in provider.gen_pesel()


# Generated at 2022-06-23 20:41:16.877662
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    '''
        Method nip of class PolandSpecProvider
    '''
    po_provider = PolandSpecProvider()
    print("Unit test for method nip of class PolandSpecProvider")
    print("NIP: %s" % po_provider.nip())


# Generated at 2022-06-23 20:41:19.008599
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider()
    assert len(provider.regon()) == 9


# Generated at 2022-06-23 20:41:20.472698
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    assert len(PolandSpecProvider().nip()) == 10


# Generated at 2022-06-23 20:41:23.561684
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    p = PolandSpecProvider()
    reg = p.regon()
    assert len(str(reg)) == 9
    assert 0 <= int(reg) <= 999999999, "REGON should be between 0 and 999999999"

# Generated at 2022-06-23 20:41:24.667489
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    obj = PolandSpecProvider()
    assert obj != None

# Generated at 2022-06-23 20:41:27.862783
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    pesel = PolandSpecProvider().pesel()
    print(pesel)


# Generated at 2022-06-23 20:41:30.109424
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    from mimesis.builtins.poland import PolandSpecProvider
    PolandSpecProvider(seed=123321)

# Generated at 2022-06-23 20:41:31.246243
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider(seed=1)
    assert provider.regon() == '423962532'


# Generated at 2022-06-23 20:41:37.431958
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Test lorem.text().
    """

    poland_spec_provider = PolandSpecProvider()
    NIP = poland_spec_provider.nip()
    print(NIP)
    assert len(NIP) == 10 and \
           int(NIP[:3]) > 0 and \
           int(NIP[:3]) <= 998


# Generated at 2022-06-23 20:41:38.311251
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
  PolandSpecProvider()

# Generated at 2022-06-23 20:41:42.040871
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Check if method nip return the expected value."""
    provider = PolandSpecProvider()
    assert provider.nip() == provider.nip()


# Generated at 2022-06-23 20:41:44.782526
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Unit test for constructor of class PolandSpecProvider."""
    poland_provider = PolandSpecProvider()

    assert  poland_provider.__class__.__name__ == 'PolandSpecProvider'


# Generated at 2022-06-23 20:41:46.168165
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    try:
        PolandSpecProvider()
        assert True
    except Exception:
        assert False

# Generated at 2022-06-23 20:41:48.780503
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Test PolandSpecProvider."""
    poland = PolandSpecProvider()
    assert poland.nip() == '637-17-34-053'
    assert poland.pesel() == '00010714015'
    assert poland.regon() == '094525357'

# Generated at 2022-06-23 20:41:59.452502
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # TESTS
    # Note: 4 tests was created to check if random pesel is valid.
    #       There is no any guarantee choice is always the same.

    #  1st test
    #  check if pesel contains 11 characters
    test_pesel = PolandSpecProvider(seed=12345).pesel()
    assert len(test_pesel) == 11

    #  2nd test
    #  check if pesel was generated for correct gender
    #  (input gender == MALE)
    test_pesel = PolandSpecProvider(seed=98765).pesel(gender=Gender.MALE)
    last_pesel_digit = int(test_pesel[-1])
    assert last_pesel_digit in (1, 3, 5, 7, 9)

    #  3rd test
    #  check if pesel

# Generated at 2022-06-23 20:42:01.000061
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Unit test for method regon of class PolandSpecProvider"""
    a = PolandSpecProvider().regon()
    assert a == str(a)

# Generated at 2022-06-23 20:42:02.598985
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pl_provider = PolandSpecProvider()
    expected = "89080417183"
    actual = pl_provider.pesel(gender=Gender.MALE)
    assert actual == expected

# Generated at 2022-06-23 20:42:05.863313
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    out = PolandSpecProvider().regon()
    assert len(out) == 9
    assert type(out) == str
    assert not out.startswith("0")


# Generated at 2022-06-23 20:42:06.881162
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    a = PolandSpecProvider()
    str(a)

# Generated at 2022-06-23 20:42:15.111238
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    p = PolandSpecProvider()
    for x in range(100):
        nip = p.nip()
        assert len(nip) == 10
        assert nip.isdigit()

        nip_digits = [int(d) for d in nip]
        nip_coefficients = (6, 5, 7, 2, 3, 4, 5, 6, 7)
        sum_v = sum([nc * nd for nc, nd in zip(nip_coefficients, nip_digits)])
        checksum_digit = sum_v % 11

        assert checksum_digit == nip_digits[-1]

# Generated at 2022-06-23 20:42:18.141831
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    pl = PolandSpecProvider()
    regon = pl.regon()
    assert len(regon) == 9
    assert regon.isdigit()
    assert int(regon) > 0

# Generated at 2022-06-23 20:42:20.674041
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Test constructor of class PolandSpecProvider."""
    p = PolandSpecProvider()
    assert p is not None


# Generated at 2022-06-23 20:42:24.882153
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert isinstance(pesel, str)
    assert len(pesel) == 11
    nip = provider.nip()
    assert isinstance(nip, str)
    assert len(nip) == 10
    regon = provider.regon()
    assert isinstance(regon, str)
    assert len(regon) == 9

# Generated at 2022-06-23 20:42:28.558024
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    p = PolandSpecProvider()
    assert (p.nip() == '1136134782')
    assert (p.pesel() == '57120256288')
    assert (p.regon() == '943247894')
# END

# Generated at 2022-06-23 20:42:37.435547
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    from mimesis.enums import Gender
    import re
    poland_spec_provider = PolandSpecProvider()
    # test pesel
    pesel = poland_spec_provider.pesel().rstrip()
    assert len(pesel) == 11
    assert re.match(r'^\d+$', pesel) is not None
    # test pesel according too gender
    pesel_male = poland_spec_provider.pesel(gender=Gender.MALE).rstrip()
    assert len(pesel_male) == 11
    assert re.match(r'^\d+$', pesel_male) is not None
    pesel_male_last_digit = int(pesel_male[10])

# Generated at 2022-06-23 20:42:38.806511
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    poland = PolandSpecProvider()
    return poland


# Generated at 2022-06-23 20:42:40.407989
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    c = PolandSpecProvider
    assert c.Meta.name == 'poland_provider'

# Generated at 2022-06-23 20:42:42.143890
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    nip = provider.nip()
    assert isinstance(nip, str)
    assert len(nip) == 10


# Generated at 2022-06-23 20:42:42.777608
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    PolandSpecProvider()

# Generated at 2022-06-23 20:42:53.136313
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # test for PESEL example from Wikipedia
    sut = PolandSpecProvider(seed=1)
    pesel = sut.pesel(birth_date=Datetime().datetime(1926, 1, 1))
    assert pesel == '26010176113'
    # test with random birth date and gender
    pesel = sut.pesel(birth_date=Datetime().datetime(), gender=Gender.FEMALE)
    assert len(pesel) == 11
    assert int(pesel[6]) % 2 == 0
    # test with constant gender
    pesel = sut.pesel(gender=Gender.MALE)
    assert len(pesel) == 11
    assert int(pesel[6]) % 2 == 1


# Generated at 2022-06-23 20:42:56.943910
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    pl = PolandSpecProvider()
    assert pl.__class__.__name__ == 'PolandSpecProvider'

# Unit tests for method nip() of class PolandSpecProvider

# Generated at 2022-06-23 20:43:00.114860
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    regon = PolandSpecProvider().regon()
    assert isinstance(regon, str)
    assert len(regon) == 9
    print("regon = ", regon)


# Generated at 2022-06-23 20:43:03.536183
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    assert len(provider.nip()) == 10



# Generated at 2022-06-23 20:43:09.494763
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    # Set the random seed
    seed = 13579

    # Create a new instance of PolandSpecProvider
    poland_provider = PolandSpecProvider(seed)

    # Generate a valid 10-digit NIP
    nip = poland_provider.nip()

    # Check the length
    assert len(nip) == 10

    # Check the NIP
    assert nip == '5391006713'


# Generated at 2022-06-23 20:43:16.496477
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider(seed=151213)
    assert (p.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.MALE)) == '63011792171'
    assert (p.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.FEMALE)) == '93011792172'
    assert (p.pesel(birth_date=Datetime().datetime(1940, 2018))) == '93011792172'



# Generated at 2022-06-23 20:43:20.628639
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    poland = PolandSpecProvider()
    assert poland.nip() == '9385795425'
    assert len(poland.pesel()) == 11
    assert poland.regon() == '951151199'

# Generated at 2022-06-23 20:43:23.358096
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()
    assert (len(pesel) == 11 and pesel.isdigit()
            and int(pesel[9]) % 2 == 0)

# Generated at 2022-06-23 20:43:25.164862
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    assert isinstance(provider, PolandSpecProvider)


# Generated at 2022-06-23 20:43:27.629852
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    result = PolandSpecProvider().pesel()
    assert isinstance(result, str)
    assert len(result) == 11
    assert result == '92090274345'


# Generated at 2022-06-23 20:43:33.688746
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Test function regon of class PolandSpecProvider."""
    regon_list = []
    PolandSpecProvider().regon()

    # Test with default
    regon = PolandSpecProvider().regon()
    assert len(regon) == 9

    # Test with a good REGON
    regon_list.append('731455250')
    for regon in regon_list:
        assert PolandSpecProvider(seed=regon).regon() == regon



# Generated at 2022-06-23 20:43:36.705887
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Test method regon of class PolandSpecProvider."""
    p = PolandSpecProvider()
    r = p.regon()
    assert len(r) == 9
    assert r == '665282352' or r == '827107566'

# Generated at 2022-06-23 20:43:39.134628
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Tests for method nip of class PolandSpecProvider."""
    
    PolandSpecProvider().nip()


# Generated at 2022-06-23 20:43:42.425314
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    x = PolandSpecProvider()
    assert x.nip() is not None
    assert x.pesel() is not None
    assert x.regon() is not None

# Generated at 2022-06-23 20:43:47.377126
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
	provider = PolandSpecProvider()
	assert provider.pesel() != None 
	assert len(provider.pesel()) == 11
	assert type(provider.pesel()) == str
	assert provider.pesel().isdigit() == True
	for i in range(1000):
		assert provider.pesel()[0] != 0

# Generated at 2022-06-23 20:43:51.980976
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    instance = PolandSpecProvider()
    instance.seed(1)

    # nip should be valid (checksum digit correspond to the rest of nip numbers)
    assert instance.nip() == '7899214632'
    assert instance.nip() == '8872803666'
    assert instance.nip() == '3868553095'


# Generated at 2022-06-23 20:44:01.804097
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    psp = PolandSpecProvider()
    pesel = psp.pesel(birth_date=Datetime().datetime(1993,1,1), gender=Gender.FEMALE)
    assert len(pesel) == 11
    assert int(pesel[0]) == 9
    assert int(pesel[1]) == 3
    assert int(pesel[2]) == 0
    assert int(pesel[3]) == 1
    assert int(pesel[4]) == 0
    assert int(pesel[5]) == 1
    assert int(pesel[10]) == 0
    assert int(pesel[9]) in (0,2,4,6,8)

# Generated at 2022-06-23 20:44:07.931703
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    import datetime
    provider = PolandSpecProvider()
    results = []
    for ind in range(10):
        results.append(provider.pesel(
            birth_date=datetime.datetime(1993, 9, 14, 12, 30,
                                         tzinfo=datetime.timezone.utc)))
    assert all('93' in result for result in results)
    assert all('09' in result for result in results)
    assert all('14' in result for result in results)
    assert all('12' in result for result in results)
    assert all('30' in result for result in results)


# Generated at 2022-06-23 20:44:10.396081
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()
    assert isinstance(pesel, str)


# Generated at 2022-06-23 20:44:13.135011
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    # GIVEN
    provider = PolandSpecProvider(seed=123)
    # WHEN
    result = provider.__init__(seed=1)
    # THEN
    assert result is None

# Generated at 2022-06-23 20:44:20.168376
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """test_PolandSpecProvider_nip function."""
    # Initialize a PolandSpecProvider object
    poland_spec_provider = PolandSpecProvider()
    # Get the nip
    nip = poland_spec_provider.nip()
    # assert the nip is 10-digit
    assert(len(nip) == 10)


# Generated at 2022-06-23 20:44:22.026116
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    p = PolandSpecProvider()
    print(p.nip())


# Generated at 2022-06-23 20:44:25.783522
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    test_PolandSpecProvider = PolandSpecProvider()
    print(test_PolandSpecProvider.nip())
    print(test_PolandSpecProvider.nip())
    print(test_PolandSpecProvider.pesel())
    print(test_PolandSpecProvider.pesel())
    print(test_PolandSpecProvider.regon())
    print(test_PolandSpecProvider.regon())
    print(test_PolandSpecProvider.registration_plate())

test_PolandSpecProvider()

# Generated at 2022-06-23 20:44:27.848057
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    assert PolandSpecProvider().nip() == '6362272548'
    assert PolandSpecProvider().pesel()
    assert PolandSpecProvider().regon() == '596845802'

# Generated at 2022-06-23 20:44:32.043717
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    from mimesis.enums import Gender
    from mimesis.providers import PolandSpecProvider
    x = PolandSpecProvider()
    p = x.nip()
    assert len(p) == 10


# Generated at 2022-06-23 20:44:34.934631
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    p = PolandSpecProvider()
    print(p.nip())
    print(p.pesel())
    print(p.regon())

# Generated at 2022-06-23 20:44:42.928597
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    import bisect
    import itertools
    import random

    class Random(random.Random):
        def choice(self, seq):
            return seq[int(self.random() * len(seq))]

        def shuffle(self, x, random=None):
            if random is None:
                random = self.random
            for i in reversed(range(1, len(x))):
                j = int(random() * (i + 1))
                x[i], x[j] = x[j], x[i]

        def randrange(self, start, stop=None, step=1):
            istart = int(start)
            if istart != start:
                raise ValueError("non-integer arg 1 for randrange()")
            if stop is None:
                if istart > 0:
                    return self._

# Generated at 2022-06-23 20:44:54.226660
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    result_1 = p.pesel()
    # result_2 = p.pesel('12/08/1977', Gender.MALE)
    result_3 = p.pesel('12/08/1977', Gender.FEMALE)
    result_4 = p.pesel('12/08/1977')
    result_5 = p.pesel(birth_date='12/08/1977', gender=Gender.FEMALE)
    print(result_1, result_1[-1])
    # print(result_2, result_2[-1])
    print(result_3, result_3[-1])
    print(result_4, result_4[-1])
    print(result_5, result_5[-1])

# test_PolandSpecProvider_pesel()

# Generated at 2022-06-23 20:44:55.884839
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():

    provider = PolandSpecProvider()
    assert provider.nip() != provider.nip()



# Generated at 2022-06-23 20:45:00.779969
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Unit test for constructor of class PolandSpecProvider"""
    seeds = [4, 5, 6]
    for item in seeds:
        first = PolandSpecProvider(item)
        second = PolandSpecProvider(item)
        assert first.seed == second.seed
    assert PolandSpecProvider().seed is None


# Generated at 2022-06-23 20:45:09.657801
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    poland = PolandSpecProvider(seed=19820211)

    assert poland.nip() == '5141025273'
    assert poland.nip(seed=111) == '5163137889'
    assert poland.nip(seed=222) == '5168590227'
    assert poland.nip(seed=333) == '5162102142'
    assert poland.nip(seed=444) == '5159041013'
    assert poland.nip(seed=555) == '5167154036'
    assert poland.nip(seed=666) == '5166274363'
    assert poland.nip(seed=777) == '5166422971'
    assert poland.nip(seed=888) == '5166422971'
    assert poland.n

# Generated at 2022-06-23 20:45:12.388045
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    assert provider is not None, "The constructor of PolandSpecProvider do not work, the provider is None."


# Generated at 2022-06-23 20:45:16.311406
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Test for constructor of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    assert provider.__class__.__name__ == 'PolandSpecProvider'
    assert provider._meta.name == 'poland_provider'
    assert provider._meta.localized == True


# Generated at 2022-06-23 20:45:19.419415
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for PolandSpecProvider.pesel method."""
    p = PolandSpecProvider()
    assert len(p.pesel()) == 11



# Generated at 2022-06-23 20:45:20.493991
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    assert PolandSpecProvider().pesel(birth_date=None, gender=None) != None

# Generated at 2022-06-23 20:45:24.444972
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    nip_provider = PolandSpecProvider()
    nip_code = nip_provider.nip()
    assert len(nip_code) == 10


# Generated at 2022-06-23 20:45:26.642220
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    nip = provider.nip()
    assert len(nip) == 10



# Generated at 2022-06-23 20:45:28.657686
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    test = PolandSpecProvider()
    assert(test.__class__.__name__ == "PolandSpecProvider")


# Generated at 2022-06-23 20:45:30.165982
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    instance1 = PolandSpecProvider()
    assert(len(instance1.pesel()) == 11)


# Generated at 2022-06-23 20:45:32.776527
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    regon = PolandSpecProvider().regon()
    assert len(regon) == 9
    assert all(v.isdigit() for v in list(regon))

# cmd: python -m test.test_pl

# Generated at 2022-06-23 20:45:35.409729
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    # GIVEN
    provider = PolandSpecProvider()

    # WHEN
    result = provider.nip()

    # THEN
    assert len(result) == 10


# Generated at 2022-06-23 20:45:37.473627
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    poland = PolandSpecProvider()
    result = poland.regon()
    right_result = '1234567890'
    assert result == right_result

# Generated at 2022-06-23 20:45:42.000692
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """
    Checks if pesel function generates correct string.
    """
    data = [
        (None, None),
        (Datetime().datetime(1991, 9, 15), Gender.MALE),
        (Datetime().datetime(2001, 12, 5), Gender.FEMALE)
    ]
    provider = PolandSpecProvider()
    for record in data:
        assert provider.pesel(record[0], record[1]).isdigit() is True

# Generated at 2022-06-23 20:45:43.050202
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    assert len(PolandSpecProvider().pesel()) == 11

# Generated at 2022-06-23 20:45:43.696091
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    PolandSpecProvider()

# Generated at 2022-06-23 20:45:45.675986
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    PolandSpecProvider().regon()  # doctest: +ELLIPSIS
    '02173745\n'


# Generated at 2022-06-23 20:45:53.197529
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    poland = PolandSpecProvider()
    assert poland.nip() != None
    assert poland.nip() != ''
    assert len(poland.nip()) == 10
    assert poland.pesel() != None
    assert poland.pesel() != ''
    assert len(poland.pesel()) == 11
    assert poland.regon() != None
    assert poland.regon() != ''
    assert len(poland.regon()) == 9

# Generated at 2022-06-23 20:45:55.925531
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider(seed=1)
    assert provider.nip() == '842-22-31-065'


# Generated at 2022-06-23 20:45:58.400472
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """ Unit test for method regon of class PolandSpecProvider """
    provider = PolandSpecProvider()
    regon = provider.regon()
    assert len(regon) == 9



# Generated at 2022-06-23 20:46:03.500646
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test the method pesel."""
    # Test with no parameter
    assert len(PolandSpecProvider().pesel()) == 11
    # Test with a birth date
    assert len(PolandSpecProvider().pesel(birth_date='2017-10-22')) == 11
    # Test with a birth date and a gender
    assert len(PolandSpecProvider().pesel(birth_date='2017-10-22', gender='M')) == 11

# Generated at 2022-06-23 20:46:04.170105
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    pass

# Generated at 2022-06-23 20:46:09.567211
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland = PolandSpecProvider()
    for i in range(1, 10):
        print(poland.pesel(genere = Gender.MALE))
        # print(poland.pesel())
    return
test_PolandSpecProvider_pesel()


# Generated at 2022-06-23 20:46:21.124653
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    assert PolandSpecProvider().nip() == '1747916507'
    assert PolandSpecProvider().nip() == '1384354945'
    assert PolandSpecProvider().nip() == '1596325880'
    assert PolandSpecProvider().nip() == '1922383598'
    assert PolandSpecProvider().nip() == '1880354134'
    assert PolandSpecProvider().nip() == '1769185657'
    assert PolandSpecProvider().nip() == '1749368986'
    assert PolandSpecProvider().nip() == '1448725382'
    assert PolandSpecProvider().nip() == '1496457376'
    assert PolandSpecProvider().nip() == '1706946231'
    assert PolandSpecProvider().nip() == '1126568923'
    assert PolandSpecProvider().nip

# Generated at 2022-06-23 20:46:22.805346
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    nip = provider.nip()
    assert len(nip) == 10


# Generated at 2022-06-23 20:46:25.661091
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    psp = PolandSpecProvider()
    assert len(psp.regon()) == 9



# Generated at 2022-06-23 20:46:29.861697
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = pesel()
    assert len(pesel) == 11
    # Check if sum of digits is divisible by 10.
    assert sum(int(digit) for digit in pesel) % 10 == 0
    assert (int(pesel) > 10000000000 and int(pesel) <= 99999999999)

# Generated at 2022-06-23 20:46:30.729137
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    assert PolandSpecProvider()


# Generated at 2022-06-23 20:46:34.405059
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel(birth_date=datetime(1980, 4, 10), gender=Gender.MALE)
    assert pesel == '80041014019'

# Generated at 2022-06-23 20:46:36.907934
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    assert provider.__class__.__name__ == 'PolandSpecProvider'


# Generated at 2022-06-23 20:46:39.573900
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    regon = PolandSpecProvider().regon()
    assert len(regon) == 9
    assert regon.isdigit()

# Generated at 2022-06-23 20:46:46.945459
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    print('Running test for method pesel of class PolandSpecProvider')

    from mimesis.enums import Gender
    from datetime import datetime, date

    # Create provider for Poland
    poland_provider = PolandSpecProvider()

    # Generate PESEL
    test_pesel = poland_provider.pesel()
    print('101: ' + test_pesel)
    test_pesel_in = ''.join([test_pesel[0:6], '', '', test_pesel[9:11]])
    assert len(test_pesel) == 11
    assert int(test_pesel_in) > 0

    # Generate PESEL with given birth date

# Generated at 2022-06-23 20:46:51.025346
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    spp = PolandSpecProvider()
    pesel = spp.pesel(birth_date=Datetime().datetime(1983, 4, 4))
    assert pesel == '03041983002'



# Generated at 2022-06-23 20:46:52.494281
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    print("This is test function of nip method")
    provider = PolandSpecProvider()
    nip = provider.nip()
    print(f"NIP: {nip}")


# Generated at 2022-06-23 20:46:54.333539
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Test function for regon."""
    assert len(PolandSpecProvider().regon()) == 9

# Generated at 2022-06-23 20:46:58.272161
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    def ta1():
        """Test for method pesel of class PolandSpecProvider."""
        provider = PolandSpecProvider()
        pesel = provider.pesel()
        print(pesel)

    ta1()
    # Output:
    # 62052299552 (random sample)



# Generated at 2022-06-23 20:47:02.342297
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    # Test for constructor of class PolandSpecProvider that gets a random seed
    poland_provider = PolandSpecProvider()
    assert poland_provider.seed is not None
    # Test for constructor of class PolandSpecProvider that gets a specific seed
    seed = 124
    poland_provider = PolandSpecProvider(seed=seed)
    assert poland_provider.seed == seed


# Generated at 2022-06-23 20:47:06.426881
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Convert a number in a base X to an integer."""
    provider = PolandSpecProvider()
    regon = provider.regon()
    assert len(regon) == 9


# Generated at 2022-06-23 20:47:08.746654
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    poland = PolandSpecProvider()
    name = poland.name()
    address = poland.address()
    pesel = poland.pesel()
    print('Name: ', name, '\nAddress: ', address, '\npesel: ', pesel)
