

# Generated at 2022-06-23 20:37:10.205835
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    print(PolandSpecProvider(seed = 20180906))

# Generated at 2022-06-23 20:37:15.339014
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    from mimesis.builtins import PolandSpecProvider
    ps = PolandSpecProvider()

    result = ps.nip()
    assert type(result) is str and len(result) == 10

    result = ps.pesel()
    assert type(result) is str and len(result) == 11

    result = ps.regon()
    assert type(result) is str and len(result) == 9

# Generated at 2022-06-23 20:37:19.955973
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    # Initialise PolandSpecProvider object
    poland_provider = PolandSpecProvider()

    # Check if instance of PolandSpecProvider
    assert isinstance(poland_provider, PolandSpecProvider)

    # Check if correct name
    assert poland_provider.Meta.name == 'poland_provider'


# Generated at 2022-06-23 20:37:23.839456
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider()
    regon = provider.regon()

    # assert len(regon) == 9
    assert all(c in "0123456789" for c in regon)



# Generated at 2022-06-23 20:37:31.286256
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # Test with gender parameter
    provider1 = PolandSpecProvider(seed=1)
    pesel_female = provider1.pesel(gender=Gender.FEMALE)
    assert isinstance(pesel_female, str)
    assert len(pesel_female) == 11
    assert pesel_female == '89012005967'

    pesel_male = provider1.pesel(gender=Gender.MALE)
    assert isinstance(pesel_male, str)
    assert len(pesel_male) == 11
    assert pesel_male == '74022301681'

    # Test without gender parameter
    provider2 = PolandSpecProvider(seed=2)
    pesel_unknown = provider2.pesel()
    assert isinstance(pesel_unknown, str)
    assert len(pesel_unknown) == 11
   

# Generated at 2022-06-23 20:37:33.112377
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    assert PolandSpecProvider().pesel('1992-02-21', 0) == '92022112457'

# Generated at 2022-06-23 20:37:40.442488
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel(gender='male')
    assert len(pesel) == 11
    assert pesel.isdigit()
    pesel1 = provider.pesel(gender='female')
    assert len(pesel1) == 11
    assert pesel1.isdigit()
    pesel2 = provider.pesel(gender=None)
    assert len(pesel2) == 11
    assert pesel2.isdigit()


# Generated at 2022-06-23 20:37:46.936673
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Check PolandSpecProvider class regon method."""
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.providers.internet import Internet
    generator = PolandSpecProvider()
    for x in range(1000):
        regon = generator.regon()
        print(regon)
        assert ''.join(regon).isdigit()
        assert len(regon) == 9


# Generated at 2022-06-23 20:37:48.607221
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Unit test for constructor of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    assert provider is not None

# Generated at 2022-06-23 20:37:51.991513
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Unit test for constructor of class PolandSpecProvider."""
    provider = PolandSpecProvider()


# Generated at 2022-06-23 20:37:52.865917
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    poland = PolandSpecProvider()


# Generated at 2022-06-23 20:37:58.362589
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    assert len(p.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.MALE)) == 11
    assert len(p.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.FEMALE)) == 11
    assert len(p.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.NOT_SPECIFIED)) == 11

# Generated at 2022-06-23 20:38:02.215955
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    p = PolandSpecProvider()
    assert p.nip() != p.nip()
    assert p.nip().isnumeric()


# Generated at 2022-06-23 20:38:12.037520
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    import unittest
    import re
    import datetime
    class PolandSpecProvider_test(unittest.TestCase):
        def test_PolandSpecProvider(self):
            """Test method regon of class PolandSpecProvider."""
            test_object = PolandSpecProvider()
            test_pattern = re.compile("^[0-9]{9}$") # any 9-digit STRING
            self.assertTrue(test_pattern.match(test_object.regon()))
        #def test_PolandSpecProvider_gexp(self):
        #    """Test method gender_expression of class PolandSpecProvider."""
        #    test_object = PolandSpecProvider()
        #    test_pattern = re.compile("^[male|female]$") # male or female
        #    self.assertTrue(test_pattern.match

# Generated at 2022-06-23 20:38:17.393373
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    data = PolandSpecProvider()
    assert len(data.pesel()) == 11
    assert len(data.pesel(birth_date=data.datetime(1990, 2018),gender=Gender.MALE)) == 11
    assert len(data.pesel(birth_date=data.datetime(1990, 2018),gender=Gender.FEMALE)) == 11
    assert len(data.pesel(birth_date=data.datetime(1900, 1999))) == 11


# Generated at 2022-06-23 20:38:19.475589
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    psp = PolandSpecProvider()
    # Constructor with no parameters
    assert psp.nip() is not None

# Generated at 2022-06-23 20:38:21.635788
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    pl = PolandSpecProvider()
    for i in range(1, 10):
        assert len(pl.nip()) == 10



# Generated at 2022-06-23 20:38:24.140633
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    p = PolandSpecProvider()
    assert len(p.regon()) == 9 , 'Length of regon should be 9'
    assert p.regon().isnumeric(), 'regon should be numeric'


# Generated at 2022-06-23 20:38:27.792894
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    print("-------------------------")
    print("---Test pesel function---")
    print("-------------------------")
    pesel_test = PolandSpecProvider().pesel()
    print("pesel: " + str(pesel_test))
    assert len(str(pesel_test)) == 11

# Generated at 2022-06-23 20:38:29.312976
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    print('nip():')
    print(PolandSpecProvider().nip())
    print()


# Generated at 2022-06-23 20:38:31.234030
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Test PolandSpecProvider.regon() returns a string with 9 digits."""
    p = PolandSpecProvider()
    assert len(p.regon()) == 9

# Generated at 2022-06-23 20:38:38.227811
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    from mimesis.enums import Gender
    from mimesis.providers.datetime import Datetime
    p = PolandSpecProvider()
    nip1 = p.nip()
    assert len(nip1) == 10

    nip2 = p.nip(birth_date=Datetime().datetime(2010, 2016), gender=Gender.MALE)
    assert len(nip2) == 10


# Generated at 2022-06-23 20:38:39.194756
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    p = PolandSpecProvider()
    assert p.nip() == '1012815663'



# Generated at 2022-06-23 20:38:44.719151
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    p = PolandSpecProvider()
    nip = p.nip()
    nip_len = len(nip)
    nip_base = sum([int(d) for d in nip[:nip_len - 1]])
    nip_checksum = nip_base % 11
    assert(nip_checksum == int(nip[-1]))


# Generated at 2022-06-23 20:38:47.593544
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""

    r = PolandSpecProvider()
    p = r.pesel()

    assert len(p) == 11
    assert (isinstance(p, str))

# Generated at 2022-06-23 20:38:51.535125
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    result = provider.pesel(gender=Gender.MALE, birth_date=Datetime.datetime(1994, 4, 15))
    assert result == '94041501446'

# Generated at 2022-06-23 20:38:55.066700
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    seed = "1234"
    reproductive = PolandSpecProvider(seed=seed)
    pesel_1 = reproductive.pesel()
    pesel_2 = reproductive.pesel()
    assert pesel_1 == "1501092"
    assert pesel_2 == "3312182"


# Generated at 2022-06-23 20:38:57.822409
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()

    assert len(provider.nip()) == 10

    provider = PolandSpecProvider(seed=0)
    assert provider.nip() == '6260155782'


# Generated at 2022-06-23 20:39:04.423536
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    result = provider.nip()
    print(f"Result nip : {result}")
    pesel_result = provider.pesel()
    print(f"pesel : {pesel_result}")
    regon_result = provider.regon()
    print(f"regon : {regon_result}")

if __name__ == "__main__":
    test_PolandSpecProvider()

# Generated at 2022-06-23 20:39:05.208833
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    assert provider is not None

# Generated at 2022-06-23 20:39:06.407259
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    assert len(PolandSpecProvider().nip()) == 10


# Generated at 2022-06-23 20:39:09.243962
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    
    print(PolandSpecProvider().__class__.__name__)
    pesel = PolandSpecProvider().pesel()
    print(pesel)

    assert(len(pesel)==11)
    assert(pesel[0]!='0')



# Generated at 2022-06-23 20:39:12.102160
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    a = PolandSpecProvider()
    print(a.nip())
    print(a.pesel(datetime(1994, 4, 10), Gender.FEMALE))
    print(a.regon())


# Generated at 2022-06-23 20:39:18.026768
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    pl = PolandSpecProvider()
    nip_list = []

    # Generate 10 nip numbers
    for x in range(0, 10):
        nip_list.append(pl.nip())

    # Check if all numbers are different
    assert len(nip_list) == len(set(nip_list))


# Generated at 2022-06-23 20:39:19.724444
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    assert len(provider.nip()) == 10


# Generated at 2022-06-23 20:39:21.620648
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    p = PolandSpecProvider()
    regon = p.regon()
    assert len(regon) == 9
    assert regon.isdigit()

# Generated at 2022-06-23 20:39:23.417197
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    result = p.pesel()
    print(result)
    assert len(result) == 11


# Generated at 2022-06-23 20:39:32.180524
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    # instance of class PolandSpecProvider
    pl = PolandSpecProvider()
    # calling the method nip()
    x = pl.nip()
    # checking if lenght of generated number is 10
    assert len(x) == 10
    # checking if generated number is valid
    assert pl.validate_nip(x) is True
    # calling the method pesel()
    y = pl.pesel()
    # checking if lenght of generated number is 11
    assert len(y) == 11
    # checking if generated number is valid
    assert pl.validate_pesel(y) is True
    # calling the method regon()
    z = pl.regon()
    # checking if lenght of generated number is 9
    assert len(z) == 9
    # checking if generated number is valid
    assert pl.validate

# Generated at 2022-06-23 20:39:34.825751
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    pesel = PolandSpecProvider()
    nip = pesel.nip()
    assert nip



# Generated at 2022-06-23 20:39:37.392651
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    assert len(PolandSpecProvider().nip()) == 10
    assert len(PolandSpecProvider().pesel()) == 11
    assert len(PolandSpecProvider().regon()) == 9

# Generated at 2022-06-23 20:39:47.854127
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    from mimesis import polish
    from mimesis.enums import Gender
    from datetime import date

    dates = [date(year, month, day) for year in range(1960, 2018) for month in range(1, 12) for day in range(1, 30)]
    gender = [Gender.MALE, Gender.FEMALE]
    
    for d in dates:
        for g in gender:
            pesel = polish.PolandSpecProvider().pesel(d, g)
            assert len(pesel) == 11
            assert int(pesel[0:2]) in range(20, 99)
            assert int(pesel[2:4]) in range(1, 12)
            assert int(pesel[4:6]) in range(1, 30)

# Generated at 2022-06-23 20:39:50.311698
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
        string = "123456783"
        regon = PolandSpecProvider().regon()
        if regon == string:
            return True
        else:
            return False


# Generated at 2022-06-23 20:39:57.118408
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    NIP = provider.nip()

    # Test 1: checksum digit should be valid
    actual_result = NIP[-1]
    expected_result = PolandSpecProvider().nip()[-1]
    assert actual_result == expected_result, 'NIP checksum test failing'


    # Test 2: nip should be valid
    actual_result = PolandSpecProvider().nip()[0]
    expected_result = 1
    assert actual_result == expected_result, 'NIP starting from 1 test failing'



# Generated at 2022-06-23 20:39:59.834900
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    p = PolandSpecProvider()
    print(p.nip())
    print(p.pesel())
    print(p.regon())

test_PolandSpecProvider()

# Generated at 2022-06-23 20:40:08.275729
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    # First test: check if the class is created
    try:
        PolandSpecProvider()
    except NameError:
        print("The class PolandSpecProvider() is not created yet")
    else:
        print("The class PolandSpecProvider() is ready")
    # Second test: check if the class constructor is created
    try:
        PolandSpecProvider.__init__()
    except NameError:
        print("The class constructor is not created yet")
    else:
        print("The class constructor is ready")
    # Third test: check if the class properties are created
    try:
        PolandSpecProvider.Meta
    except NameError:
        print("The class property 'Meta' is not created yet")
    else:
        print("The class property 'Meta' is ready")

# Generated at 2022-06-23 20:40:16.618893
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    from mimesis import PolandSpecProvider
    from mimesis.providers import Person
    from mimesis.enums import Gender

    p = PolandSpecProvider()
    street_name = p.street_name()
    person = Person(p)
    person.name(gender=Gender.FEMALE)
    all_ok = True
    all_ok = True
    for i in range(100):
        empl = person.full_name(gender=Gender.MALE)
        regon = p.regon()
        if (int(regon[0]) == 0):
            all_ok = False
        if (int(regon[1]) == 0):
            all_ok = False            
        if (int(regon[2]) == 1):
            all_ok = False

# Generated at 2022-06-23 20:40:18.177484
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    result = provider.pesel()
    print(result)

test_PolandSpecProvider()

# Generated at 2022-06-23 20:40:20.781645
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    p = PolandSpecProvider()
    res = p.nip()
    assert len(res) == 10, "There is not 10 digits NIP - {}".format(res)


# Generated at 2022-06-23 20:40:24.531853
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
	seed(1)
	p = PolandSpecProvider()
	print("PolandSpecProvider: " + p.nip())
	print("PolandSpecProvider: " + p.pesel())
	print("PolandSpecProvider: " + p.regon())

# Generated at 2022-06-23 20:40:29.578883
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pl = PolandSpecProvider()
    pesel = pl.pesel()
    assert(int(pesel[-2]) % 2 == 0 and int(pesel[10]) % 2 == 1) or (int(pesel[-2]) % 2 == 1 and int(pesel[10]) % 2 == 0)

# Generated at 2022-06-23 20:40:33.944775
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel_provided = PolandSpecProvider().pesel()
    pesel_provided_2 = PolandSpecProvider().pesel(gender=Gender.MALE)
    assert type(pesel_provided) is str and len(pesel_provided) is 11
    assert type(pesel_provided_2) is str and len(pesel_provided_2) is 11


# Generated at 2022-06-23 20:40:39.120534
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    import pytest
    from mimesis.builtins.pl import PolandSpecProvider
    from mimesis.enums import Gender

    pl = PolandSpecProvider()
    test_nip = pl.nip()
    assert test_nip.isnumeric() == True
    assert len(test_nip) == 10
    with pytest.raises(AssertionError):
        assert test_nip.isalpha() == True


# Generated at 2022-06-23 20:40:40.708637
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = '39102506850'
    dp = PolandSpecProvider()
    assert dp.pesel() == pesel

# Generated at 2022-06-23 20:40:52.123226
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    import pytest
    from mimesis.enums import Gender

    a = PolandSpecProvider()

    # Must have parameters
    # First name and second name of person
    def test_fail_pesel_1():
        with pytest.raises(TypeError):
            a.pesel()

    # Randoming
    # Test with GENDER
    def test_fail_pesel_2():
        # Must have Gender
        with pytest.raises(TypeError):
            a.pesel(gender=None)
    # Test with Birth date
    def test_fail_pesel_3():
        # Must have Birth date
        with pytest.raises(TypeError):
            a.pesel(birth_date=None)
    # Test without parameters

# Generated at 2022-06-23 20:40:56.598189
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    #unit test to test if constructor of class PolandSpecProvider is working properly
    print("Testing __init__ method of PolandSpecProvider")
    provider = PolandSpecProvider()

    #test to check instance of subclass PolandSpecProvider
    assert isinstance(provider, BaseSpecProvider)

    #test to check locale
    assert provider.locale == "pl"


# Generated at 2022-06-23 20:40:57.466917
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    pl = PolandSpecProvider()
    assert pl



# Generated at 2022-06-23 20:40:59.201456
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Unit test for method nip of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    result = provider.nip()
    assert len(result) == 10


# Generated at 2022-06-23 20:41:02.878985
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    p = PolandSpecProvider()

    # Return random
    assert isinstance(p.random, type(PolandSpecProvider.random))

    # Return a valid NIP
    assert len(p.nip()) == 10

    # Return a valid PESEL
    assert len(p.pesel()) == 11

    # Return a valid REGON
    assert len(p.regon()) == 9

# Generated at 2022-06-23 20:41:06.610304
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    print(PolandSpecProvider().pesel(birth_date=Datetime().datetime(2000, 2018), gender=Gender.MALE))

# Generated at 2022-06-23 20:41:09.443537
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    # Given
    poland_provider = PolandSpecProvider()

    # When
    result = poland_provider.regon()

    # Then
    assert len(result) == 9

# Generated at 2022-06-23 20:41:12.627541
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """ Testing method nip of class PolandSpecProvider """
    c = PolandSpecProvider()
    c.nip()
    print('Unit test for method nip of class PolandSpecProvider is OK.')



# Generated at 2022-06-23 20:41:14.749355
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """ Unit test for method regon of class PolandSpecProvider """
    p = PolandSpecProvider();
    assert len(p.regon()) == 9;

# Generated at 2022-06-23 20:41:16.729834
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    assert len(PolandSpecProvider().nip()) == 10


# Generated at 2022-06-23 20:41:17.525883
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
	PolandSpecProvider().nip()



# Generated at 2022-06-23 20:41:26.243029
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Unit test for method regon of class PolandSpecProvider.

    :return: no return value
    """
    for test_no in range(0, 100):
        pesel = PolandSpecProvider().regon()
        if len(pesel) != 9:
            print("test_PolandSpecProvider_regon(): ERROR (1)")
        digits = []
        for digit in pesel:
            digits.append(int(digit))
        coefficients = [8, 9, 2, 3, 4, 5, 6, 7]
        sum_v = 0
        for i in range(0, 8):
            sum_v += coefficients[i] * digits[i]
        check_digit = sum_v % 11
        if check_digit > 9:
            check_digit = 0

# Generated at 2022-06-23 20:41:29.872766
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel_list=[]
    for i in range(100):
        pesel_list.append(PolandSpecProvider().pesel())
    print(pesel_list)
    return

# Generated at 2022-06-23 20:41:36.262507
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Check if method regon generates valid REGON."""
    provider = PolandSpecProvider()
    regon = provider.regon()
    assert len(regon) == 9

    regon_digits = [int(d) for d in str(regon)]
    regon_coeffs = (8, 9, 2, 3, 4, 5, 6, 7)
    sum_v = sum([nc * nd for nc, nd in zip(regon_coeffs, regon_digits)])
    checksum_digit = sum_v % 11
    assert checksum_digit <= 9


# Generated at 2022-06-23 20:41:43.697321
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    class_instance = PolandSpecProvider()
    pesel = class_instance.pesel()
    assert len(pesel) == 11
    sum_v = sum([int(p) * int(c) for p, c in zip(pesel[:10], '9 7 3 1 9 7 3 1 9 7'.split())])
    assert int(pesel[10]) == sum_v % 10
    if int(pesel[2]) in [0, 1]:
        assert int(pesel[4:6]) <= 31
    else:
        assert int(pesel[4:6]) <= 30
    assert int(pesel[6:8]) <= 31



# Generated at 2022-06-23 20:41:46.168358
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
   class_name = "PolandSpecProvider"
   assert class_name == "PolandSpecProvider"
   print("test passed")
   
test_PolandSpecProvider()


# Generated at 2022-06-23 20:41:51.914129
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    pl_provider = PolandSpecProvider()

    nipGenerated = pl_provider.nip()
    print('NIP: ' + nipGenerated)

    peselGenerated = pl_provider.pesel(birth_date=Datetime().datetime(1980, 2000), gender=Gender.MALE)
    print('PESEL: ' + peselGenerated)

    regonGenerated = pl_provider.regon()
    print('REGON: ' + regonGenerated)


# Generated at 2022-06-23 20:41:56.650672
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    fr = PolandSpecProvider()
    print(fr.address.address())
    print(fr.code.ean())
    print(fr.internet.email())
    print(fr.personal.full_name(gender=Gender.MALE))
    print(fr.phone_number.telephone())
    print(fr.code.vat())


# Generated at 2022-06-23 20:42:00.409015
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    n = PolandSpecProvider()
    is_ok = True
    for i in range(100):
        test_regon = n.regon()
        is_ok = is_ok and len(test_regon) == 9
    assert(is_ok)


# Generated at 2022-06-23 20:42:01.087042
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    pass

# Generated at 2022-06-23 20:42:03.145427
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    pl_provider = PolandSpecProvider()
    print(pl_provider.nip())


# Generated at 2022-06-23 20:42:06.474468
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    poland_spec_provider = PolandSpecProvider(seed=123)
    assert poland_spec_provider.nip() == "9211090709"


# Generated at 2022-06-23 20:42:11.500970
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    assert provider.pesel()
    assert provider.pesel(gender=Gender.MALE)
    assert provider.pesel(gender=Gender.FEMALE)
    assert provider.pesel(birth_date='2018-01-01 01:01')


# Generated at 2022-06-23 20:42:15.498035
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    a = PolandSpecProvider()
    output = a.regon()
    print("Output is " + output)

if __name__ == "__main__":
    test_PolandSpecProvider_regon()

# Generated at 2022-06-23 20:42:17.737555
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    # case 1
    assert len(PolandSpecProvider().nip()) == 10


# Generated at 2022-06-23 20:42:18.627135
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    p = PolandSpecProvider()
    assert p.nip() != p.nip()


# Generated at 2022-06-23 20:42:22.872785
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    test_args = [None]
    obj = PolandSpecProvider()

    for arg in test_args:
        result = obj.nip()
        assert result is not None
        assert type(result) is str
        assert len(result) == 10
        int(result)  # should not fail


# Generated at 2022-06-23 20:42:28.656206
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    with open("regons_test.txt", "a") as f:
        for i in range(100):
            print(PolandSpecProvider(seed=i).regon())
            f.write(PolandSpecProvider(seed=i).regon() + '\n')

#test_PolandSpecProvider_regon()



# Generated at 2022-06-23 20:42:31.542891
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    assert provider.nip() is not None
    assert provider.pesel() is not None
    assert provider.regon() is not None


# Generated at 2022-06-23 20:42:35.675996
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Unit test for method nip of class PolandSpecProvider."""
    provider = PolandSpecProvider(seed=4040404040404040404)
    result = provider.nip()
    assert result == '5408796037'
    assert len(result) == 10
    result = provider.nip()
    assert result == '4976809338'
    assert len(result) == 10

# Generated at 2022-06-23 20:42:39.644344
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Testing the PolandSpecProvider method nip."""
    provider = PolandSpecProvider()
    assert PolandSpecProvider.nip(provider) == '1234567890', 'Wrong NIP'


# Generated at 2022-06-23 20:42:40.411804
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    return PolandSpecProvider()

# Generated at 2022-06-23 20:42:42.265101
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    regon = PolandSpecProvider().regon()
    assert len(regon) == 9


# Generated at 2022-06-23 20:42:44.161789
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    result = provider.nip()
    assert len(result) == 10


# Generated at 2022-06-23 20:42:45.432602
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    assert len(PolandSpecProvider().regon()) == 9



# Generated at 2022-06-23 20:42:56.153691
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p1 = PolandSpecProvider(seed=12)
    p2 = PolandSpecProvider(seed=12)
    assert p1.pesel(birth_date=Datetime().datetime(1940, 2018),
                    gender=Gender.MALE) == p2.pesel(birth_date=Datetime().datetime(1940, 2018),
                    gender=Gender.MALE)
    assert p1.pesel(birth_date=Datetime().datetime(1940, 2018),
                    gender=Gender.FEMALE) == p2.pesel(birth_date=Datetime().datetime(1940, 2018),
                    gender=Gender.FEMALE)

# Generated at 2022-06-23 20:42:58.347012
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    psp = PolandSpecProvider()
    # Check if instance is created correctly
    assert psp._locale == 'pl'

# Generated at 2022-06-23 20:42:59.164033
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()
    assert len(pesel) == 11


# Generated at 2022-06-23 20:43:04.713745
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Test PolandSpecProvider.nip."""
    pl_nip = PolandSpecProvider().nip()
    check_pl_nip = int(pl_nip[-1])
    final_result = int(
        (6 * int(pl_nip[0]) + 5 * int(pl_nip[1]) + 
        7 * int(pl_nip[2]) + 2 * int(pl_nip[3]) + 
        3 * int(pl_nip[4]) + 4 * int(pl_nip[5]) + 
        5 * int(pl_nip[6]) + 6 * int(pl_nip[7]) + 
        7 * int(pl_nip[8])) % 11)

    if final_result > 9:
        final_result = final_result % 10


# Generated at 2022-06-23 20:43:06.188154
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    assert PolandSpecProvider().regon() == "730922181"


# Generated at 2022-06-23 20:43:11.067746
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    # Initialize instance of PolandSpecProvider class
    poland_provider = PolandSpecProvider()
    # Generate 10-digit NIP
    nip = poland_provider.nip()
    print("NIP:", nip)
    # Check NIP length
    assert len(nip) == 10


# Generated at 2022-06-23 20:43:13.007023
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    assert isinstance(PolandSpecProvider().nip(), str)


# Generated at 2022-06-23 20:43:15.583493
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Test method regon of class PolandSpecProvider"""
    expected = '924251884'
    actual = PolandSpecProvider(seed=str('998877665')).regon()
    assert actual == expected


# Generated at 2022-06-23 20:43:17.403324
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()
    print('PESEL:', pesel)
    assert len(pesel) == 11


# Generated at 2022-06-23 20:43:22.079936
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    birth_date = dt(2002, 9, 13)
    gender = Gender.FEMALE
    assert provider.pesel(birth_date=birth_date, gender=gender) == '02091301829'

# Generated at 2022-06-23 20:43:25.210571
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    assert provider is not None
    assert provider.provider is not None
    assert provider.locale == 'pl'
    assert provider.seed is not None


# Generated at 2022-06-23 20:43:28.233726
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():

    pl = PolandSpecProvider()
    
    # If a call does not return None, this function is correctly implemented 
    assert pl.nip() is not None 
    assert pl.pesel() is not None 
    assert pl.regon() is not None

# Generated at 2022-06-23 20:43:30.897918
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Test for constructor of class PolandSpecProvider"""
    x = PolandSpecProvider()
    assert x.nip() == x.nip() # check that function nip() is deterministic

# Generated at 2022-06-23 20:43:35.559403
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    polandSpecProvider = PolandSpecProvider()
    pesel_value = polandSpecProvider.pesel(birth_date=polandSpecProvider.datetime(1980, 1, 1))
    pesel_value = int(pesel_value)
    assert pesel_value > 0


# Generated at 2022-06-23 20:43:42.356657
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider(seed=42)
    pesel = provider.pesel(birth_date='2001-01-01', gender=Gender.MALE)
    assert pesel == '01010112345'

    provider = PolandSpecProvider()
    assert provider.pesel(birth_date='1910-01-01', gender=Gender.MALE) == '10101197374'
    assert provider.pesel(birth_date='1910-01-01', gender=Gender.FEMALE) == '10101092200'
    assert provider.pesel(birth_date='1910-01-01') == '10101454492'
    assert provider.pesel(birth_date='2010-01-01', gender=Gender.MALE) == '10101594551'

# Generated at 2022-06-23 20:43:43.308095
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    PolandSpecProvider()


# Generated at 2022-06-23 20:43:47.476192
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    # Unit test for methhod nip of class PolandSpecProvider
    # Generate 5 valid nip numbers
    pl_provider = PolandSpecProvider()
    for i in range(5):
        assert(len(pl_provider.nip()) == 10)


# Generated at 2022-06-23 20:43:49.134194
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    pesel = PolandSpecProvider().pesel()
    assert isinstance(pesel, str)
    assert len(pesel) == 11


# Generated at 2022-06-23 20:43:52.246541
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    assert provider.provider == "poland_provider"
    assert provider.locale == "pl"
    assert provider.seed == "1"


# Generated at 2022-06-23 20:43:53.874727
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Verifying the correctness of the regon method."""

    p = PolandSpecProvider()
    assert len(p.regon()) == 9

# Generated at 2022-06-23 20:43:55.826975
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    assert isinstance(provider, PolandSpecProvider)


# Generated at 2022-06-23 20:44:03.492971
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    import random
    import datetime
    pl = PolandSpecProvider(random.seed())
    date_1 = datetime.date(year=2007, month=4, day=10)
    date_2 = datetime.date(year=2012, month=1, day=27)
    date_3 = datetime.date(year=2010, month=5, day=12)
    g1 = Gender.MALE
    g2 = Gender.FEMALE
    pesel1 = pl.pesel(birth_date=date_1, gender=g1)
    pesel2 = pl.pesel(birth_date=date_2, gender=g2)
    pesel3 = pl.pesel(birth_date=date_3, gender=g1)
    print("Pesel: ", pesel1)

# Generated at 2022-06-23 20:44:05.801044
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    p = PolandSpecProvider()
    assert(len(p.nip()) == 10)


# Generated at 2022-06-23 20:44:06.781150
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    assert len(PolandSpecProvider().nip()) == 10


# Generated at 2022-06-23 20:44:08.736210
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    poland = PolandSpecProvider()
    NIPofPoland = poland.nip()
    assert len(NIPofPoland) == 10

# Generated at 2022-06-23 20:44:09.928408
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """
    Unit test.
    """

    assert len(PolandSpecProvider().regon()) == 9

# Generated at 2022-06-23 20:44:12.579479
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    print(provider.pesel())
    for i in range(1, 10):
        print(provider.pesel())


# Generated at 2022-06-23 20:44:13.817638
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    assert PolandSpecProvider().__init__() is None

# Generated at 2022-06-23 20:44:26.514927
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider(seed=42)

    # Unit test for method nip
    nip_tests = [provider.nip() for _ in range(10)]
    assert nip_tests == ['2242547697', '8186173325', '3513948838', '2530846040',
                         '6665864559', '9172073834', '4607108790', '2859162084',
                         '5511975219', '6881211839']

    # Unit test for method pesel
    pesel_tests = [provider.pesel(gender=Gender.MALE) for _ in range(10)]

# Generated at 2022-06-23 20:44:30.717537
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():

    import pytest
    from hypothesis import given, settings
    from hypothesis.strategies import integers

    # unit test for constructor
    with pytest.raises(TypeError):
        PolandSpecProvider("string")

    with pytest.raises(TypeError):
        PolandSpecProvider(None)

    with pytest.raises(TypeError):
        PolandSpecProvider(12345)

    with pytest.raises(TypeError):
        PolandSpecProvider(True)

    with pytest.raises(TypeError):
        PolandSpecProvider(1.2)

    with pytest.raises(TypeError):
        PolandSpecProvider({"dict": "dict"})

    with pytest.raises(TypeError):
        PolandSpecProvider(["string", "string"])

    with pytest.raises(TypeError):
        PolandSpecProvider

# Generated at 2022-06-23 20:44:33.547520
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    pl_regon = PolandSpecProvider()
    regon = pl_regon.regon()
    assert len(regon) == 9
    assert int(regon) > 0

# Generated at 2022-06-23 20:44:37.994866
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider()
    regon = provider.regon()
    assert 7 < len(regon) < 10
    regon_int = int(regon)
    regon_coeffs = (8, 9, 2, 3, 4, 5, 6, 7)
    sum_v = sum([nc * nd for nc, nd in zip(regon_coeffs, list(map(int, str(regon_int)[:-1])))])
    checksum_digit = sum_v % 11
    if checksum_digit > 9:
        checksum_digit = 0
    assert int(regon[-1]) == checksum_digit

# Generated at 2022-06-23 20:44:42.494442
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Unit test for constructor of class PolandSpecProvider."""
    pl_provider = PolandSpecProvider()
    assert pl_provider.np() == "Numer PESEL"


# Unit tests of methods of class PolandSpecProvider


# Generated at 2022-06-23 20:44:43.559610
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    PolandSpecProvider().regon()

# Generated at 2022-06-23 20:44:44.636508
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    p = PolandSpecProvider()
    assert p.seed != None


# Generated at 2022-06-23 20:44:47.623440
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider('123456')
    assert provider.pesel() == '39122009984'


# Generated at 2022-06-23 20:44:55.000320
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    poland_spec_provider = PolandSpecProvider()
    # Test method nip()
    nip = poland_spec_provider.nip()
    assert len(nip) == 10
    assert str.isdigit(nip)

    # Test method pesel()
    pesel = poland_spec_provider.pesel()
    assert len(pesel) == 11
    assert str.isdigit(pesel)

    # Test method regon()
    regon = poland_spec_provider.regon()
    assert len(regon) == 9
    assert str.isdigit(regon)

# Generated at 2022-06-23 20:44:57.813097
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    psp = PolandSpecProvider()
    regon = psp.regon()
    print(regon)
    assert len(regon) == 9
    assert int(regon[0]) != 0


# Generated at 2022-06-23 20:45:03.151352
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Test method regon."""
    from mimesis.exceptions import NonEnumerableError
    p = PolandSpecProvider()
    result = p.regon()
    assert len(result) == 9
    assert result.isdigit()
    with NonEnumerableError():
        p.regon(None)

# Generated at 2022-06-23 20:45:05.072977
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider()
    assert len(provider.regon()) == 9


# Generated at 2022-06-23 20:45:06.758842
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    p = PolandSpecProvider()
    # first line in exercise
    assert p.nip() == '7770005579'

# Generated at 2022-06-23 20:45:11.503407
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Unit test for method nip of class PolandSpecProvider."""
    print("Testing method nip of class PolandSpecProvider")
    assert re.match(r'\d{10}', PolandSpecProvider().nip())



# Generated at 2022-06-23 20:45:14.425740
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    print(provider.pesel())
    print(provider.nip())
    print(provider.regon())


# Generated at 2022-06-23 20:45:19.800809
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    # test n times
    n = 200
    prov = PolandSpecProvider()

    i = 1
    while i <= n:
        regon = prov.regon()
        print("{} regon = {}".format(i, regon))
        i += 1

if __name__ == "__main__":
    test_PolandSpecProvider_regon()

# Generated at 2022-06-23 20:45:23.310677
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test pesel() method of class PolandSpecProvider."""
    provider_object = PolandSpecProvider()
    assert len(provider_object.pesel()) == 11

# Generated at 2022-06-23 20:45:24.928302
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    pl = PolandSpecProvider()
    print(pl.nip())


# Generated at 2022-06-23 20:45:26.689046
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    # 569080037
    result = PolandSpecProvider().regon()
    print(result)


# Generated at 2022-06-23 20:45:28.034819
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
   assert PolandSpecProvider().regon() is not None


# Generated at 2022-06-23 20:45:28.900602
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    assert PolandSpecProvider()


# Generated at 2022-06-23 20:45:30.087377
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    assert provider.provider == 'poland_provider'

# Generated at 2022-06-23 20:45:32.344254
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    poland = PolandSpecProvider()
    assert len(poland.nip()) == 10

    assert len(poland.pesel()) == 11


# Generated at 2022-06-23 20:45:33.265585
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    a = PolandSpecProvider()
    assert len(a.nip())==10



# Generated at 2022-06-23 20:45:38.411389
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    # given
    pl_spec_provider = PolandSpecProvider()
    # when
    pesel = pl_spec_provider.pesel()
    # then
    assert (pesel.isdigit()
            and len(pesel) == 11
            and int(pesel[-1]) % 2 == 0)


# Generated at 2022-06-23 20:45:39.134403
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    PolandSpecProvider().regon()



# Generated at 2022-06-23 20:45:42.386728
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    assert(len(PolandSpecProvider().regon()) == 9)

    assert(PolandSpecProvider().regon() != PolandSpecProvider().regon())


# Generated at 2022-06-23 20:45:45.602265
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    p = PolandSpecProvider()
    assert p.__class__.__name__ == 'PolandSpecProvider'
    assert p._validate_locale() == 'pl'
    assert p._validate_seed() is not None


# Generated at 2022-06-23 20:45:48.853589
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Function to test regon method of PolandSpecProvider class."""
    provider = PolandSpecProvider()
    assert len(provider.regon()) == 9

# Generated at 2022-06-23 20:45:50.796205
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    assert len(PolandSpecProvider().regon()) == 9
    assert PolandSpecProvider().regon().isnumeric() == True

# Generated at 2022-06-23 20:45:53.943717
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    for _ in range(10):
        nip = provider.nip()
        assert len(nip) == 10


# Generated at 2022-06-23 20:45:56.278201
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Unit test for method regon of class PolandSpecProvider"""
    assert PolandSpecProvider().regon() == str(9)

# Generated at 2022-06-23 20:45:56.878774
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    pass

# Generated at 2022-06-23 20:45:58.217007
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():

    for value in PolandSpecProvider().regon():
        assert value is not None


# Generated at 2022-06-23 20:45:59.557825
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    assert provider is not None


# Generated at 2022-06-23 20:46:00.528010
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    PolandSpecProvider()


# Generated at 2022-06-23 20:46:07.561570
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    nip = provider.nip()
    nip_digits = [int(d) for d in nip]
    nip_coefficients = (6, 5, 7, 2, 3, 4, 5, 6, 7)
    sum_v = sum([nc * nd for nc, nd in zip(nip_coefficients, nip_digits)])

    checksum_digit = sum_v % 11
    if checksum_digit > 9:
        checksum_digit = 0
    # assert condition
    assert checksum_digit == nip_digits[9]


# Generated at 2022-06-23 20:46:09.725374
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider()
    regon = provider.regon()
    assert len(regon) == 9

# Generated at 2022-06-23 20:46:10.930352
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()


# Generated at 2022-06-23 20:46:16.449065
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    pe = PolandSpecProvider()
    if pe != None:
        print('Test: Constructor of class PolandSpecProvider')
        print('Result: Passed')
    else:
        print('Test: Constructor of class PolandSpecProvider')
        print('Result: Failed')
    pe = None
    return


# Generated at 2022-06-23 20:46:24.958154
# Unit test for method pesel of class PolandSpecProvider

# Generated at 2022-06-23 20:46:33.704899
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    Poland = PolandSpecProvider()
    pesel = Poland.pesel(gender = Gender.MALE, birth_date = '1974-03-03T00:00')
    assert len(pesel) == 11
    assert pesel[0] == '7'
    assert pesel[1] == '4'
    assert pesel[2] == '0'
    assert pesel[3] == '3'
    assert pesel[4] == '0'
    assert pesel[5] == '3'
    assert pesel[6] in ['1', '2', '3', '4', '5', '6', '7', '8', '9', '0']
    assert pesel[7] in ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']

# Generated at 2022-06-23 20:46:38.365030
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pol = PolandSpecProvider()
    assert pol.pesel(birth_date='1960-09-22') == '60092201358'
    assert pol.pesel() in ['63092201358', '68092275358', '61092201358',
                           '68092235358', '60092201358']

# Generated at 2022-06-23 20:46:42.810009
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    # test function nip from class PolandSpecProvider
    from mimesis.enums import Gender
    from mimesis.providers import PolandSpecProvider
    s = PolandSpecProvider()
    assert len(s.nip()) == 10
    assert s.nip().isdigit()


# Generated at 2022-06-23 20:46:47.801187
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    poland_provider = PolandSpecProvider(seed=82)
    r1 = poland_provider.nip()
    r2 = poland_provider.pesel()
    r3 = poland_provider.regon()

    assert r1 == '3567364903'
    assert r2 == '97012708521'
    assert r3 == '254505396'

# Generated at 2022-06-23 20:46:52.776881
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Unit test for constructor of class PolandSpecProvider."""
    plsp = PolandSpecProvider()
    print(plsp)
    assert plsp is not None

    plsp = PolandSpecProvider(seed=1989)
    print(plsp)
    assert plsp is not None


# Generated at 2022-06-23 20:46:54.650729
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    frm = PolandSpecProvider(seed=None)
    print(frm)
    assert  frm != None

# Generated at 2022-06-23 20:46:56.422959
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider()
    assert pesel.pesel().__len__() == 11


# Generated at 2022-06-23 20:46:58.808842
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    assert (provider.pesel(birth_date=provider.datetime(),
                           gender=provider.gender.gender) in provider.pesel())

# Generated at 2022-06-23 20:47:01.029377
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    try:
        PolandSpecProvider()
        print('Test PolandSpecProvider() has passed')
    except Exception:
        print('Test PolandSpecProvider() has failed')


# Generated at 2022-06-23 20:47:12.750878
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test of class PolandSpecProvider method pesel."""
    # Unit test for method pesel of class PolandSpecProvider with empty values
    pr = PolandSpecProvider()
    pesel = pr.pesel()
    pesel_gender = pesel[-1]
    pesel_month = int(pesel[2:4])
    pesel_day = int(pesel[4:6])
    assert len(pesel) == 11
    assert pesel_gender in [str(x) for x in range(10)]
    assert pesel_month in [x for x in range(1, 13)]
    assert pesel_day in [x for x in range(1, 32)]
    # Unit test for method pesel of class PolandSpecProvider with gender
    pesel_male = pr.pesel(gender=Gender.MALE)
   