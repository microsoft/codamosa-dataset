

# Generated at 2022-06-23 20:37:11.991796
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Test method nip of class PolandSpecProvider."""
    s = PolandSpecProvider('12345')
    nip_test = s.nip()
    assert len(nip_test) == 10


# Generated at 2022-06-23 20:37:14.136639
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    regon = PolandSpecProvider(seed=123).regon()
    assert regon == str(241506904)

# Generated at 2022-06-23 20:37:14.772414
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    return PolandSpecProvider()

# Generated at 2022-06-23 20:37:19.302656
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """
    Test method regon of class PolandSpecProvider.
    """
    random_provider = PolandSpecProvider()
    regon_variable = random_provider.regon()
    print(regon_variable)
    print(type(regon_variable))


# Generated at 2022-06-23 20:37:22.555929
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Testing method nip of class PolandSpecProvider."""
    gen = PolandSpecProvider()
    # print(gen.nip())


# Generated at 2022-06-23 20:37:30.177327
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    p = PolandSpecProvider()
    for i in range(100):
        regon = p.regon()
        assert len(regon) == 9
        regon_coef = (8, 9, 2, 3, 4, 5, 6, 7)
        regon_digits = [int(d) for d in regon]
        sum_v = sum([nc * nd for nc, nd in zip(regon_coef, regon_digits)])
        checksum_digit = sum_v % 11
        if checksum_digit > 9:
            checksum_digit = 0
        assert checksum_digit == regon_digits[-1]

# Generated at 2022-06-23 20:37:40.592340
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
  # Tested method
  pl_spec_provider = PolandSpecProvider()

  # Get regon method from tested class
  regon_from_poland_spec_provider = pl_spec_provider.regon

  #  Create empty list for results
  results = []

  # Fill list with 100 results
  for _ in range(100):
    regon = regon_from_poland_spec_provider()
    results.append(regon)

  # Check if all results are equal to 9-digit
  for regon in results:
    if len(regon) == 9:
      continue
    else:
      print("REGON number is not 9-digit!")

if __name__ == '__main__':
  test_PolandSpecProvider_regon()

# Generated at 2022-06-23 20:37:42.594217
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Test the constructor of class PolandSpecProvider."""
    try:
        PolandSpecProvider()
    except Exception as e:
        print(e)


# Generated at 2022-06-23 20:37:43.908961
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    p = PolandSpecProvider()
    assert p is not None


# Unit tests for function nip of class PolandSpecProvider

# Generated at 2022-06-23 20:37:46.878166
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    assert provider.nip() is not None
    assert provider.pesel() is not None
    assert isinstance(provider.pesel(DateTime(), Gender.MALE), str)
    assert isinstance(provider.pesel(DateTime(), Gender.FEMALE), str)
    assert provider.reg

# Generated at 2022-06-23 20:37:48.100024
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    assert provider.__class__.__name__ == 'PolandSpecProvider'


# Generated at 2022-06-23 20:37:55.466410
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test function for pesel method of class PolandSpecProvider"""

    from mimesis import PolandSpecProvider
    from datetime import datetime


    spec = PolandSpecProvider()
    pesel = spec.pesel()

    assert len(pesel) == 11

# Generated at 2022-06-23 20:37:58.006980
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Unit test for method nip of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    nip = provider.nip()
    assert len(nip) == 10


# Generated at 2022-06-23 20:38:01.688552
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    pesel = PolandSpecProvider()
    print(pesel.pesel())
    print(pesel.pesel(birth_date=Datetime.datetime(year=2000, month=1, day=1)))
    print(pesel.pesel(gender=Gender.MALE))
    print(pesel.pesel(gender=Gender.FEMALE))



# Generated at 2022-06-23 20:38:02.987277
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    obj = PolandSpecProvider()
    assert obj is not None


# Generated at 2022-06-23 20:38:04.644522
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider(seed=12345)
    provider2 = PolandSpecProvider(seed=12345)
    assert provider.nip() == provider2.nip()
    assert provider.pesel() == provider2.pesel()
    assert provider.regon() == provider2.regon()

# Generated at 2022-06-23 20:38:07.625559
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    random = PolandSpecProvider(seed=1)
    assert random.nip() == '7206193876'


# Generated at 2022-06-23 20:38:09.355779
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Test the function constructor of class PolandSpecProvider."""
    provider = PolandSpecProvider()

    assert provider is not None

# Generated at 2022-06-23 20:38:13.672497
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Test for method regon of class PolandSpecProvider"""
    assert len(PolandSpecProvider().regon()) == 9
    assert PolandSpecProvider().regon() in ['00230022', '64113336', '15257727', '60938809', '37949963', '01883543']
    assert PolandSpecProvider(seed=42).regon() == '72352115'



# Generated at 2022-06-23 20:38:15.309049
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # Arrange
    PESEL = PolandSpecProvider()
    # Assert
    assert len(PESEL.pesel()) == 11



# Generated at 2022-06-23 20:38:16.333117
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    assert provider is not None


# Generated at 2022-06-23 20:38:17.725312
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    my_PolandSpecProvider = PolandSpecProvider()
    print(my_PolandSpecProvider.nip())


# Generated at 2022-06-23 20:38:20.400771
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    data = PolandSpecProvider()
    # The length of NIP should be equal to 10
    assert len(data.nip()) == 10


# Generated at 2022-06-23 20:38:22.044237
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    p = PolandSpecProvider()
    assert p.nip() == '0123456789'


# Generated at 2022-06-23 20:38:25.933254
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    # GIVEN
    # WHEN
    result = PolandSpecProvider().nip()
    # SHOULD
    assert isinstance(result, str)
    assert len(result) == 10


# Generated at 2022-06-23 20:38:27.212154
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    assert len(p.pesel()) == 11

# Generated at 2022-06-23 20:38:30.199340
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    nip = provider.nip()
    assert len(nip) == 10
    assert int(nip[:3]) >= 101 and int(nip[:3]) <= 998
    assert int(nip) >= 101000000 and int(nip) <= 998999999


# Generated at 2022-06-23 20:38:32.552458
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    # Arrange
    provider = PolandSpecProvider()

    # Act
    result = provider.regon()

    # Assert
    assert result.isdigit()
    assert len(result) == 9


# Generated at 2022-06-23 20:38:38.051806
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """
    Test method regon in class PolandSpecProvider
    """
    PolandSpecProvider_instance = PolandSpecProvider()
    assert len(PolandSpecProvider_instance.regon()) == 9
    PolandSpecProvider_instance.seed(1)
    assert PolandSpecProvider_instance.regon() == "937210791"


# Generated at 2022-06-23 20:38:40.785657
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider(seed=85827076)
    for i in range(0, 10):
        print(provider.nip())


# Generated at 2022-06-23 20:38:43.265480
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    regon = PolandSpecProvider().regon()
    assert len(regon) == 9
    assert regon.isdigit()


# Generated at 2022-06-23 20:38:45.249627
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    seed = None
    provider = PolandSpecProvider(seed)
    regon = provider.regon()
    assert len(regon) == 9


# Generated at 2022-06-23 20:38:47.631912
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    p = PolandSpecProvider(seed=1)
    print(p.regon())
    print(p.regon())
    print(p.regon())



# Generated at 2022-06-23 20:38:49.614277
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    assert PolandSpecProvider().nip() in list(
        map(str, range(100000000, 999999999)))



# Generated at 2022-06-23 20:38:54.191940
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider()
    regon_list = []
    for i in range(200):
        regon_list.append(provider.regon())
    print(regon_list)
    assert len(regon_list) == len(set(regon_list))

test_PolandSpecProvider_regon()


# Generated at 2022-06-23 20:38:56.118416
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    with PolandSpecProvider() as p:
        x = p.nip()
        assert isinstance(x, str)
        assert len(x) == 10



# Generated at 2022-06-23 20:39:01.487842
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    # Get the PolandSpecProvider instance
    poland_provider = PolandSpecProvider()
    # Set a seed
    poland_provider.seed(42)
    # Check that nip method return a string of 10 digits
    assert poland_provider.nip().isdigit() and len(poland_provider.nip()) == 10

# Generated at 2022-06-23 20:39:03.405209
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider()
    regon = provider.regon()
    assert len(regon) == 9

# Generated at 2022-06-23 20:39:04.876353
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert (
        len(pesel) == 11
    )

# Generated at 2022-06-23 20:39:11.994645
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Test to see if output from PolandSpecProvider is correct."""
    from mimesis.providers.base import BaseSpecProvider
    from mimesis.providers.person import Person
    x = PolandSpecProvider(seed=1)
    assert str(x.nip()) == '1013635671'
    assert str(x.nip()) == '1013635671'
    assert str(x.pesel()) == '82031618464'
    assert str(x.pesel(gender=Gender.MALE)) == '64091010592'
    assert str(x.regon()) == '244567327'
    assert str(x.regon()) == '244567327'
    assert issubclass(type(x), BaseSpecProvider)
    assert issubclass(type(x), Person)

# Generated at 2022-06-23 20:39:14.671919
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    instance = PolandSpecProvider()
    print(instance.nip())


# Generated at 2022-06-23 20:39:17.117860
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon(): 
    assert len(PolandSpecProvider().regon()) == 9
    assert PolandSpecProvider().regon().isdigit()


# Generated at 2022-06-23 20:39:21.246770
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    pl = PolandSpecProvider()
    nip = pl.nip()
    print(nip)
    flag = True
    if len(nip) != 10:
        flag = False
    if flag is True:
        print('nip is correct')
    else:
        print('nip is incorrect')


# Generated at 2022-06-23 20:39:22.770355
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    p = PolandSpecProvider()
    assert p.regon() == '09123456'


# Generated at 2022-06-23 20:39:25.379425
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()
    assert len(pesel) == 11
    assert PolandSpecProvider.pesel_validator(pesel)


# Generated at 2022-06-23 20:39:26.583599
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    test = PolandSpecProvider()
    test = str(test)
    assert test is not None

# Generated at 2022-06-23 20:39:29.699457
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    from mimesis.providers.poland import PolandSpecProvider

    nip = PolandSpecProvider().nip()
    assert len(nip) == 10
    assert type(nip) is str


# Generated at 2022-06-23 20:39:30.971714
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    # Test when a valid nip is generated
    assert len(provider.nip()) == 10



# Generated at 2022-06-23 20:39:38.706106
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    # init & call
    polspecpr = PolandSpecProvider()
    regon_number = polspecpr.regon()

    # verify
    regon_sum = 0
    for i in range(8):
        regon_sum += int(regon_number[i]) * (8 - i)
        print(regon_sum)
    regon_sum = regon_sum % 11
    if regon_sum == 10:
        regon_sum = 0
    assert int(regon_number[-1]) == regon_sum


# Generated at 2022-06-23 20:39:42.499349
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_provider = PolandSpecProvider()
    result = poland_provider.pesel()
    required_len = 11
    assert (len(result) == required_len)


# Generated at 2022-06-23 20:39:45.114967
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider_instance = PolandSpecProvider()
    assert isinstance(provider_instance.nip(), str)
    assert len(provider_instance.nip()) == 10


# Generated at 2022-06-23 20:39:47.396570
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    assert PolandSpecProvider() != None


# Generated at 2022-06-23 20:39:49.588391
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider(seed=12)
    assert provider.nip() == '562383307'



# Generated at 2022-06-23 20:39:56.801499
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():

    polish_provider = PolandSpecProvider()
    g = Gender.MALE

    assert polish_provider.nip() != ''
    assert polish_provider.nip() != '00'
    assert len(polish_provider.nip()) == 10
    assert polish_provider.pesel() != ''
    assert polish_provider.pesel() != '00'
    assert len(polish_provider.pesel()) == 11
    assert polish_provider.regon() != ''
    assert polish_provider.regon() != '00'
    assert len(polish_provider.regon()) == 9

# Generated at 2022-06-23 20:39:59.188054
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    p = PolandSpecProvider()
    p.seed(0)
    assert p.nip() == '3348286774'


# Generated at 2022-06-23 20:40:07.775877
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    import random
    import re
    from mimesis.enums import Gender
    from mimesis.providers.datetime import Datetime
    from mimesis.specifiers import PolandSpecProvider

    seed = random.random()
    pl = PolandSpecProvider(seed=seed)
    control_value = '46122519101'  # pesel of "author"
    more_control_values = ['{:011d}'.format(pl.random.randint(10000000000, 99999999999))]

    # noinspection PyUnresolvedReferences
    assert re.search(r'^\d{11}$', pl.pesel())

    year_as_int = int(control_value[:2])
    month_as_int = int(control_value[2:4])

# Generated at 2022-06-23 20:40:16.565130
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test the method pesel of class PolandSpecProvider."""
    date_object = Datetime().datetime(1940, 2018)
    gender = Gender.MALE
    p = PolandSpecProvider()
    pesel = p.pesel(date_object, gender)
    assert isinstance(pesel, str)
    assert len(pesel) == 11
    year = date_object.date().year
    month = date_object.date().month
    day = date_object.date().day
    if 1800 <= year <= 1899:
        month += 80
    elif 2000 <= year <= 2099:
        month += 20
    elif 2100 <= year <= 2199:
        month += 40
    elif 2200 <= year <= 2299:
        month += 60
    assert int(pesel[0:2]) == year % 100

# Generated at 2022-06-23 20:40:18.792856
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider(seed=42)
    assert provider.pesel() == "85062039348"
    assert provider.pesel(birth_date={2018, 10, 26}, gender="male") == "38102601199"


# Generated at 2022-06-23 20:40:22.278238
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Unit-test for method regon of class PolandSpecProvider"""
    provider = PolandSpecProvider()
    regon = provider.regon()

    assert isinstance(regon, str)
    assert len(regon) == 9
    assert regon != '00000000'

# Generated at 2022-06-23 20:40:24.080153
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    pr = PolandSpecProvider()
    assert pr.regon() == pr.regon()

# Generated at 2022-06-23 20:40:31.302060
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    regon_all_digits = [str(i) for i in range(0,10)]
    regon_all_digits.append('X')
    for i in range(1,10):
        regon_digits = [str(i)] + ['X' for _ in range(7)] + regon_all_digits
        print("REGON:", ''.join(regon_digits), PolandSpecProvider.regon())
        assert PolandSpecProvider.regon() in ''.join(regon_digits)

# Generated at 2022-06-23 20:40:32.710347
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    PolandSpecProvider.pesel()


# Generated at 2022-06-23 20:40:41.076930
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    
    # Creating PolandSpecProvider object
    poland = PolandSpecProvider()
    
    # Checking if the NIP generated is valid
    for _ in range(100):
        nip_number =poland.nip()
        nip_number_list = list(nip_number)
        nip_number_list = list( map(int, list(nip_number)))
        nip_check_list = [6, 5, 7, 2, 3, 4, 5, 6, 7]
        nip_multiplied_list = []
        for i in range(9):
            nip_multiplied_list.append(nip_check_list[i] * nip_number_list[i])
        sum_nip = sum(nip_multiplied_list)

# Generated at 2022-06-23 20:40:42.087045
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    a = PolandSpecProvider()

# Generated at 2022-06-23 20:40:47.609635
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    data = {
        'birth_date': datetime(year=2000, month=1, day=1),
        'gender': Gender.MALE,
        'result': '00010112345',
    }
    test_obj = PolandSpecProvider(seed=300)
    assert test_obj.pesel(birth_date=data['birth_date'], gender=data['gender']) == data['result']


# Generated at 2022-06-23 20:40:49.641573
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    poland = PolandSpecProvider()
    for _ in range(10):
        print(poland.nip())
        print(poland.pesel())
        print(poland.regon())

# Generated at 2022-06-23 20:40:54.147068
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """
    Unit test for method regon of class PolandSpecProvider
    """
    pol = PolandSpecProvider()
    for i in range(20):
        regon = pol.regon()
        assert len(regon) == 9
        for char in regon:
            assert char.isdigit()


# Generated at 2022-06-23 20:41:02.480337
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Tests if output of nip is valid.

    :return: None
    """
    def first_three_digits(nip: str) -> str:
        """Gets first three digits of given NIP.

        :param nip: 10-digit NIP
        :return: First three digits of given NIP
        """
        return nip[:3]

    def checksum(nip: str) -> int:
        """Gets checksum digit of given NIP.

        :param nip: 10-digit NIP
        :return: Checksum digit of given NIP
        """
        nip_coefficients = (6, 5, 7, 2, 3, 4, 5, 6, 7)
        nip_digits = [int(d) for d in nip]

# Generated at 2022-06-23 20:41:12.185013
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Unit test for method regon of class PolandSpecProvider"""
    poland_provider = PolandSpecProvider()
    regon = poland_provider.regon()
    assert isinstance(regon, str)
    assert len(regon) == 9
    assert regon[-1] == str(sum([int(digit) * int(coeff) \
                                 for digit, coeff \
                                 in zip(regon[:-1], ('8', '9', '2', '3', '4', '5', '6', '7'))]) % 11)

test_PolandSpecProvider_regon()


# Generated at 2022-06-23 20:41:23.085727
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method for pesel"""
    pl = PolandSpecProvider()

    # Pesel for man born in 1960
    pesel = pl.pesel(birth_date=1960, gender=Gender.MALE)
    assert len(pesel) == 11
    assert pesel[-2] in ['0', '2', '4', '6', '8']
    assert 1960 <= int(pesel[:2]) <= 99

    # Pesel for woman born in 1959
    pesel = pl.pesel(birth_date=1959, gender=Gender.FEMALE)
    assert len(pesel) == 11
    assert pesel[-2] in ['1', '3', '5', '7', '9']
    assert 1959 <= int(pesel[:2]) <= 99


# Generated at 2022-06-23 20:41:25.758511
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Test method nip of class PolandSpecProvider"""
    polspecprovider = PolandSpecProvider()
    assert polspecprovider.nip() == '657161761'

# Generated at 2022-06-23 20:41:28.985192
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    print("\nUnit test for constructor of class PolandSpecProvider:")
    p = PolandSpecProvider()
    print(p)


# Generated at 2022-06-23 20:41:31.445589
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    newPolandSpecProvider = PolandSpecProvider()
    testNip = newPolandSpecProvider.nip()
    print(testNip)


# Generated at 2022-06-23 20:41:34.127363
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    f = PolandSpecProvider()
    assert len(f.pesel(gender=Gender.MALE)) == 11
    assert len(f.pesel(gender=Gender.FEMALE)) == 11


# Generated at 2022-06-23 20:41:37.473388
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Unit tests method nip of class PolandSpecProvider
    Module pylama=pep8,pylint"""
    test = PolandSpecProvider()
    assert len(test.nip()) == 10


# Generated at 2022-06-23 20:41:40.210253
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider(seed=0)
    regon_result = provider.regon()
    assert regon_result == '274271476'


# Generated at 2022-06-23 20:41:42.577927
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    assert provider.nip() == provider.nip()


# Generated at 2022-06-23 20:41:45.057407
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    poland_provider = PolandSpecProvider()
    print(poland_provider.regon())
    # 516272310
    # 51627235X


# Generated at 2022-06-23 20:41:48.264012
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    poland_spec_provider = PolandSpecProvider()
    for _ in range(10):
        regon_1 = poland_spec_provider.regon()
        assert regon_1 != poland_spec_provider.regon()



# Generated at 2022-06-23 20:41:57.835699
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    # Initialize
    p = PolandSpecProvider(seed=123456789)

    # Execute and verify
    assert p.regon() == '750017202'
    assert p.regon() == '889660838'
    assert p.regon() == '890314086'
    assert p.regon() == '132734238'
    assert p.regon() == '287724891'
    assert p.regon() == '648238583'
    assert p.regon() == '636988791'
    assert p.regon() == '170298781'
    assert p.regon() == '852737363'
    assert p.regon() == '602339667'


# Generated at 2022-06-23 20:42:04.443396
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider()
    regon = provider.regon()

    checksum_digit = regon[-1]
    digit_list = [int(d) for d in regon[:-1]]

    regon_coeffs = (8, 9, 2, 3, 4, 5, 6, 7)
    sum_v = sum([nc * nd for nc, nd in zip(regon_coeffs, digit_list)])
    calculated_checksum = sum_v % 11

    assert((0 <= calculated_checksum <= 9) and (calculated_checksum == checksum_digit))


# Generated at 2022-06-23 20:42:07.671978
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    class PolandProvider(PolandSpecProvider):
        class Meta:
            name = "pl_provider"

    poland_provider = PolandProvider()
    assert isinstance(poland_provider, PolandSpecProvider)
    assert poland_provider.locale == "pl"
    assert poland_provider.Meta.name == "pl_provider"


# Generated at 2022-06-23 20:42:10.114942
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    from mimesis.providers.poland import PolandSpecProvider
    provider = PolandSpecProvider()

    for _ in range(10):
        regon = provider.regon()
        regon_int = int(regon)
        assert len(regon) == 9
        assert regon_int >= 10000000
        assert regon_int <= 999999999



# Generated at 2022-06-23 20:42:17.715545
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    input_json = {
    "gender": "female",
    "birth_date": {
      "date": {
        "year": 1999,
        "month": 10,
        "day": 10
      },
      "time": {
        "hour": 10,
        "minute": 30,
        "second": 50
      },
      "timezone": "+0100",
      "timestamp": 927653850
    }
  }

    gender = Gender[input_json["gender"].upper()]
    date_time = Datetime().datetime(year=input_json["birth_date"]["date"]["year"],
                                    month=input_json["birth_date"]["date"]["month"],
                                    day=input_json["birth_date"]["date"]["day"]
                                    )



# Generated at 2022-06-23 20:42:18.788665
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    assert isinstance(PolandSpecProvider().regon(), str)
    assert len(PolandSpecProvider().regon()) == 9


# Generated at 2022-06-23 20:42:23.331226
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider(seed = 666)
    assert provider.nip() == '4444444444'
    assert provider.nip() == '4444444444'
    assert provider.nip() == '4444444444'
    assert provider.nip() == '4444444444'


# Generated at 2022-06-23 20:42:26.179965
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider()
    regon = provider.regon()
    assert len(regon) == 9

# Generated at 2022-06-23 20:42:28.458015
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    result = provider.pesel(gender = Gender.MALE)
    # print(result)
    assert result is not None

# Generated at 2022-06-23 20:42:35.908423
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Unit test for PolandSpecProvider_nip method."""
    psp = PolandSpecProvider()
    nip = psp.nip()
    assert len(nip) == 10
    nip_digits = [int(d) for d in nip]

    nip_coefficients = (6, 5, 7, 2, 3, 4, 5, 6, 7)
    sum_v = sum([nc * nd for nc, nd in
                 zip(nip_coefficients, nip_digits)])
    # Check if sum modulo 11 is correct
    assert sum_v % 11 == nip_digits[9]

# Generated at 2022-06-23 20:42:38.891851
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    pl = PolandSpecProvider()
    assert pl.regon() in ['1','2','3','4','5','6','7','8','9','0']

# Generated at 2022-06-23 20:42:45.592778
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()

    # generate pesel with default parameters
    pesel = provider.pesel()
    assert isinstance(pesel, str)
    assert len(pesel) == 11

    # generate pesel with custom parameters
    birth_date = provider.datetime(2000, 2010).datetime()
    pesel = provider.pesel(birth_date=birth_date, gender=Gender.MALE)
    assert isinstance(pesel, str)
    assert len(pesel) == 11


# Generated at 2022-06-23 20:42:49.194291
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Verify regon method of PolandSpecProvider."""
    provider = PolandSpecProvider()
    regon = provider.regon()
    assert len(regon) == 9
    assert provider.validate_regon(regon)

# Generated at 2022-06-23 20:42:55.555316
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():

    provider = PolandSpecProvider()
    nip = provider.nip()
    nip_coefficients = (6, 5, 7, 2, 3, 4, 5, 6, 7)

    assert len(nip) == 10
    sum_v = sum([nc * int(d) for nc, d in
                 zip(nip_coefficients, nip)])
    checksum_digit = sum_v % 11
    assert checksum_digit <= 9



# Generated at 2022-06-23 20:42:58.576041
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    # Testing class constructor
    pl = PolandSpecProvider()
    assert isinstance(pl, PolandSpecProvider)
    assert pl._locale == 'pl'


# Generated at 2022-06-23 20:43:00.273846
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    p = PolandSpecProvider()
    assert p.nip()

# Generated at 2022-06-23 20:43:04.803846
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """
    Test for method regon of class PolandSpecProvider
    """
    p = PolandSpecProvider()
    for i in range(100):
        assert len(p.regon()) == 9



# Generated at 2022-06-23 20:43:08.472899
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    for _ in range(1000):
        p = PolandSpecProvider()
        pesel = p.pesel(gender=Gender.MALE)
        assert len(pesel) == 11
        assert pesel in p._pesel_male

# Generated at 2022-06-23 20:43:13.927946
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Test method nip of class PolandSpecProvider.
    Test for three values."""

    p = PolandSpecProvider()
    nip1 = p.nip()

    assert nip1 != ''
    assert nip1 != None
    assert nip1 != 'NIP'


# Generated at 2022-06-23 20:43:16.813305
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    seed = "0123456789"
    t = PolandSpecProvider(seed=seed)
    result = t.nip()
    assert result == "1222552277", "incorrect result for '1222552277'"


# Generated at 2022-06-23 20:43:19.745169
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    assert provider.nip()
    assert provider.pesel()
    assert provider.regon()

# Generated at 2022-06-23 20:43:29.027921
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # Assert that the method pesel of class PolandSpecProvider generates a
    # 11-digit number
    pesel = PolandSpecProvider().pesel()
    assert len(pesel) == 11
    assert isinstance(pesel, str)

    # Assert that the method pesel of class PolandSpecProvider generates a
    # 11-digit number if a Datetime object is given
    pesel_birth_date = PolandSpecProvider().pesel(Datetime().datetime(1991, 1, 1))
    assert len(pesel_birth_date) == 11
    assert isinstance(pesel_birth_date, str)

    # Assert that the method pesel of class PolandSpecProvider generates a
    # 11-digit number if a Datetime object and gender are given

# Generated at 2022-06-23 20:43:33.607546
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    # Create provider
    instance = PolandSpecProvider()
    
    # Create some values
    for _ in range(10):
        value = instance.regon()
        assert value
        
    # While I am at it, I may as well test the other functions at the same time
    for _ in range(10):
        assert instance.nip()
        assert instance.pesel()

# Generated at 2022-06-23 20:43:35.388736
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider(seed=100)
    assert provider.regon() == '018343652'

# Generated at 2022-06-23 20:43:39.962929
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    test_pesel_list = []
    pesel_list = [p.pesel() for i in range(100)]
    for i in range(100):
        test_pesel_list.append(pesel_list[i])
    assert test_pesel_list == pesel_list

# Generated at 2022-06-23 20:43:49.265222
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # Setting seed to obtain the same results
    import random
    import mimesis.random
    random.seed("")
    mimesis.random.seed("")

    # Testing method pesel
    import mimesis.enums
    import mimesis.datetime
    poland_provider_pesel = PolandSpecProvider().pesel(
        mimesis.datetime.Datetime().datetime(1940, 2018),
        mimesis.enums.Gender.FEMALE)

    # Checking if the result is a string
    assert isinstance(poland_provider_pesel, str)

    # Checking if the result is a valid PESEL, which has 11 digits
    assert len(poland_provider_pesel) == 11

    # Checking the validity of PESEL
    poland_provider_pesel_

# Generated at 2022-06-23 20:43:51.045516
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider()
    regon = provider.regon()
    assert len(regon) == 9


# Generated at 2022-06-23 20:43:53.741961
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Unit test for constructor of class PolandSpecProvider."""
    p = PolandSpecProvider()
    assert p.__class__.__name__ == "PolandSpecProvider"


# Generated at 2022-06-23 20:43:57.662327
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test unit for method pesel of class PolandSpecProvider"""
    pl_spec_provider = PolandSpecProvider(seed=12345)
    pesel = pl_spec_provider.pesel()
    print(pesel)
    assert pesel == '64061122023'


# Generated at 2022-06-23 20:44:02.983257
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    test_provider = PolandSpecProvider()
    assert test_provider.__class__.__name__ == 'PolandSpecProvider'
    assert isinstance(test_provider, BaseSpecProvider)
    assert test_provider._meta.name == 'poland_provider'
    assert test_provider._meta.locale == 'pl'


# Generated at 2022-06-23 20:44:07.182685
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Test constructor of PolandSpecProvider."""
    o = PolandSpecProvider()
    assert o.seed is not None
    assert o._raw_data != {}
    assert o.locale == 'pl'
    assert o._validate_locale() is True


# Generated at 2022-06-23 20:44:10.513106
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Test method nip of class PolandSpecProvider."""
    from mimesis import PolandSpecProvider
    from mimesis.enums import Gender

    p = PolandSpecProvider()
    nip = p.nip()
    print(nip)
    # 526-13-39-15


# Generated at 2022-06-23 20:44:12.417622
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    regon = PolandSpecProvider().regon()
    assert len(regon) == 9


# Generated at 2022-06-23 20:44:13.813779
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    from mimesis.providers import PolandSpecProvider
    p = PolandSpecProvider('pl')
    print(p.regon())


# Generated at 2022-06-23 20:44:16.531466
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    p = PolandSpecProvider()
    print("PASS")


# Generated at 2022-06-23 20:44:19.193886
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    print("Testing constructor of PolandSpecProvider class...")
    provider = PolandSpecProvider()
    print("No errors detected!")


# Generated at 2022-06-23 20:44:25.856345
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    from mimesis import Person
    from mimesis.providers.datetime import Datetime

    gender = Person().gender()
    date_object = Datetime().datetime(1940, 2018)
    print("Generated PESEL: ", PolandSpecProvider(seed=1).pesel(birth_date=date_object, gender=gender))

if __name__ == '__main__':
    test_PolandSpecProvider_pesel()

# Generated at 2022-06-23 20:44:28.306863
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    nip_tester = PolandSpecProvider(seed=123456)
    for i in range(0, 10):
        nip = nip_tester.nip()
        print(nip)
        assert len(nip) == 10



# Generated at 2022-06-23 20:44:32.043864
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
	nip_provider = PolandSpecProvider()
	for i in range(5):
		print(nip_provider.nip())


# Generated at 2022-06-23 20:44:33.216126
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    assert provider is not None

# Generated at 2022-06-23 20:44:39.949730
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_gender_male = Gender.MALE
    poland_gender_female = Gender.FEMALE
    poland_gender_none = None

    assert len(PolandSpecProvider().pesel(gender=poland_gender_male)) == 11
    assert len(PolandSpecProvider().pesel(gender=poland_gender_female)) == 11
    assert len(PolandSpecProvider().pesel(gender=poland_gender_none)) == 11


# Generated at 2022-06-23 20:44:51.747835
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Unit tests for constructor of class PolandSpecProvider."""
    data_generator = PolandSpecProvider(seed=1234)
    assert data_generator.nip() == '7853855559'
    assert data_generator.nip() == '2432947183'
    assert data_generator.pesel(birth_date='1991-01-01') == '91000199117'
    assert data_generator.pesel(birth_date='1991-01-01', gender=Gender.MALE) == '91000199157'
    assert data_generator.pesel(birth_date='1991-01-01', gender=Gender.FEMALE) == '91000199108'
    assert data_generator.regon() == '224805972'

# Generated at 2022-06-23 20:45:02.083381
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Unit test for method regon of class PolandSpecProvider."""
    positions = [0, 1, 2, 3, 4, 5, 6, 7]
    weights = [8, 9, 2, 3, 4, 5, 6, 7]
    controlnums = [1, 4, 0, 6, 1, 7, 2, 6, 8]
    provider = PolandSpecProvider()
    regon = provider.regon()
    weightsum = sum([w * int(regon[pos]) for pos, w in zip(positions, weights)])
    controlnum = int(weightsum) % 11
    if controlnum > 9:
        controlnum = 0
    return controlnum == int(controlnums[int(regon)])

# Generated at 2022-06-23 20:45:06.218213
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Test nip method of class PolandSpecProvider."""
    actual_result = PolandSpecProvider().regon()
    assert len(actual_result) == 9
    assert all(
        [str.isdigit(n) for n in actual_result])


# Generated at 2022-06-23 20:45:06.925946
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    PolandSpecProvider()

# Generated at 2022-06-23 20:45:07.457489
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    PolandSpecProvider()

# Generated at 2022-06-23 20:45:13.893322
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    # prepare
    from mimesis.providers.poland import PolandSpecProvider

    # test
    data_provider = PolandSpecProvider()
    result = data_provider.nip()

    # verify
    assert str(result).startswith('1')
    assert len(str(result)) == 10



# Generated at 2022-06-23 20:45:21.069441
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Unit test for method regon of class PolandSpecProvider.
    """
    poland_provider = PolandSpecProvider()

    # Generate a random valid 9-digit REGON
    regon = poland_provider.regon()

    # Test if generated REGON is correct
    regon_checksum_coeffs = (8, 9, 2, 3, 4, 5, 6, 7)
    regon_digits = [int(digit) for digit in str(regon)]
    regon_checksum = sum([nc * nd for nc, nd in
        zip(regon_checksum_coeffs, regon_digits)]) % 11

    assert regon_checksum == regon_digits[-1]

# Generated at 2022-06-23 20:45:24.454901
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    assert provider.meta == {'name': 'poland_provider'}


# Generated at 2022-06-23 20:45:25.986788
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    k2 = PolandSpecProvider()
    k3 = PolandSpecProvider()
    assert k2.regon() != k3.regon()

# Generated at 2022-06-23 20:45:27.737789
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    pl_provider = PolandSpecProvider()
    assert pl_provider.locale == 'pl'



# Generated at 2022-06-23 20:45:30.962570
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    # Test for non-negative random output
    provider = PolandSpecProvider("random seed")
    assert provider.nip() >= 0

    # Test for the length of the output
    assert len(provider.nip()) == 10


# Generated at 2022-06-23 20:45:33.761407
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    import datetime
    p = PolandSpecProvider()
    p.pesel(datetime.datetime(1993, 1, 20), Gender.MALE) == '93012012832'


# Generated at 2022-06-23 20:45:34.393354
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    pass

# Generated at 2022-06-23 20:45:38.411031
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""

    poland_provider = PolandSpecProvider(seed=123)
    dt = Datetime().datetime(1940, 2018)
    assert poland_provider.pesel(dt, Gender.MALE) == '99031317301'
    

# Generated at 2022-06-23 20:45:39.645616
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    assert PolandSpecProvider().regon() == '992233644'

# Generated at 2022-06-23 20:45:48.245715
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    import datetime
    p = PolandSpecProvider()
    pesel_list = []
    pesel_list_gender = []
    for i in range(0, 1000):
        pesel_list.append(p.pesel())
        pesel_list_gender.append(p.pesel(datetime.datetime.now(),
                                         Gender.FEMALE))
        pesel_list_gender.append(p.pesel(datetime.datetime.now(),
                                         Gender.MALE))
    assert len(set(pesel_list)) == 1000
    assert len(set(pesel_list_gender)) == 2000


# Generated at 2022-06-23 20:45:53.517704
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    nip_regex = re.compile(r'^(\d{3}-\d{3}-\d{2}-\d{2})$')
    test_nip = PolandSpecProvider().nip()
    result = re.match(nip_regex, test_nip)
    assert result is not None


# Generated at 2022-06-23 20:46:03.382799
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    from mimesis.data import DATA_DIR

    from mimesis.builtins.pl import PolandSpecProvider

    # tests pesel method

    seed = 'abcdefghijklmnopqrstuvwxyz'
    gender = (Gender.MALE, Gender.FEMALE)
    with open(DATA_DIR + '/polen/pl_pesel_male.txt', 'r') as f:
        pesel_male = f.read().splitlines()
    with open(DATA_DIR + '/polen/pl_pesel_female.txt', 'r') as f:
        pesel_female = f.read().splitlines()
    with open(DATA_DIR + '/polen/pl_pesel_invalid.txt', 'r') as f:
        pesel_invalid = f.read().splitlines()

   

# Generated at 2022-06-23 20:46:05.847072
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    p = PolandSpecProvider()
    assert p.locale == 'pl'


# Generated at 2022-06-23 20:46:09.225762
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    from mimesis.enums import Gender
    poland_spec_provider = PolandSpecProvider()
    pesel_list = [poland_spec_provider.nip() for _ in range(1000)]
    assert len(pesel_list) == len(set(pesel_list))


# Generated at 2022-06-23 20:46:21.084344
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    pr = PolandSpecProvider()
    print(pr)
    print('Список дополнительных функций для Польши:')
    print('Генерация NIP, Numer Identyfikacji Podatkowej: {}'.format(pr.nip()))
    print('Генерация PESEL, Регистрационный номер гражданина: {}'.format(pr.pesel()))
    #print('Генерация REGON, Рег

# Generated at 2022-06-23 20:46:23.865287
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    # GIVEN
    provider = PolandSpecProvider()

    # WHEN
    generated_nip = provider.nip()

    # THEN
    assert len(generated_nip) == 10
    assert generated_nip.isdigit()
    assert generated_nip[:3] == "101"
    assert generated_nip[:3] == "998"


# Generated at 2022-06-23 20:46:28.657478
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """The test of the regon method of class PolandSpecProvider."""
    psp = PolandSpecProvider()
    regon = psp.regon()
    assert regon is not None
    assert isinstance(regon, str)
    assert len(regon) == 9
    assert regon.isdigit()


# Generated at 2022-06-23 20:46:30.354856
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    Poland = PolandSpecProvider()
    assert isinstance(Poland, PolandSpecProvider)


# Generated at 2022-06-23 20:46:34.805610
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    psp = PolandSpecProvider()
    for _ in range(100):
        nip = psp.nip()
        assert nip.isdigit() and len(nip) == 10
        assert nip == "294-24-74-876"


# Generated at 2022-06-23 20:46:36.408132
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    assert (len(PolandSpecProvider().nip()) == 10)


# Generated at 2022-06-23 20:46:40.347232
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    node = Provider(PolandSpecProvider())
    assert len(node.nip()) == 10
    assert len(node.nip(seed=1)) == 10
    assert len(node.nip(seed=10)) == 10


# Generated at 2022-06-23 20:46:46.257719
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    gender = Gender.MALE
    result = PolandSpecProvider().pesel(birth_date=Datetime().datetime('2000', '2000'), gender=gender)
    gender_digit = int(result[-1])
    if gender == Gender.MALE:
        assert gender_digit in (1, 3, 5, 7, 9)
    elif gender == Gender.FEMALE:
        assert gender_digit in (0, 2, 4, 6, 8)
    else:
        assert gender_digit in range(10)

# Generated at 2022-06-23 20:46:50.925456
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    assert provider.provider('poland_provider') is not None
    assert provider.nip() is not None
    assert provider.pesel(birth_date=None, gender=Gender.FEMALE) is not None
    assert provider.regon() is not None

# Generated at 2022-06-23 20:46:53.131873
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    polandSpecProvider = PolandSpecProvider()
    assert isinstance(polandSpecProvider, PolandSpecProvider)


# Generated at 2022-06-23 20:46:54.997504
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    nip = PolandSpecProvider().nip()
    assert len(nip) == 10


# Generated at 2022-06-23 20:46:56.741913
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    a = PolandSpecProvider()
    assert a.nip()
    assert a.pesel()
    assert a.regon()

# Generated at 2022-06-23 20:46:58.642549
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    assert len(PolandSpecProvider().nip()) == 10

# Generated at 2022-06-23 20:46:59.748394
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    assert PolandSpecProvider().__class__.__name__ == 'PolandSpecProvider'


# Generated at 2022-06-23 20:47:04.749597
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    print("*** Test pesel method of PolandSpecProvider class")
    pesel = PolandSpecProvider().pesel()
    print("    pesel =", pesel)
    print("*** Test pesel method of PolandSpecProvider class - Done")
    return


# Generated at 2022-06-23 20:47:05.901030
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    assert "".join(set(PolandSpecProvider().regon())) == "0123456789"



# Generated at 2022-06-23 20:47:07.488383
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    assert PolandSpecProvider().__class__ == PolandSpecProvider


# Generated at 2022-06-23 20:47:09.635287
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Unit test for constructor of class PolandSpecProvider."""
    pl = PolandSpecProvider()
    assert pl is not None

# Generated at 2022-06-23 20:47:15.129369
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    pesel = PolandSpecProvider().pesel()
    nip = PolandSpecProvider().nip()
    regon = PolandSpecProvider().regon()

    assert nip.count('-') == 0 and nip.count('.') == 0
    assert regon.count('-') == 0 and regon.count('.') == 0
    assert pesel.count('-') == 0 and pesel.count('.') == 0