

# Generated at 2022-06-23 20:37:10.984965
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    import re
    s = PolandSpecProvider()
    nip1 = s.nip()
    assert(len(nip1) == 10)
    nip2 = s.nip()
    assert(len(nip2) == 10)
    assert(nip1 != nip2)
    nip_regex = re.compile(r'\d{10}')
    assert(nip_regex.fullmatch(nip1))
    assert(nip_regex.fullmatch(nip2))


# Generated at 2022-06-23 20:37:12.928330
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Test method nip of class PolandSpecProvider."""

    result = PolandSpecProvider().nip()

    assert result is not None

    # check length
    assert len(result) == 10


# Generated at 2022-06-23 20:37:23.536671
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    psp = PolandSpecProvider()
    assert psp.nip() == '1284871108'
    assert psp.pesel() == '60080504084'
    assert psp.regon() == '177030049'
    assert psp.nip() == '8921474255'
    assert psp.pesel() == '32120702972'
    assert psp.regon() == '895083508'
    assert psp.nip() == '8828119120'
    assert psp.pesel() == '33020808811'
    assert psp.regon() == '285664613'
    assert psp.nip() == '3025648041'
    assert psp.pesel() == '87091309219'

# Generated at 2022-06-23 20:37:24.430629
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    assert PolandSpecProvider() is not None


# Generated at 2022-06-23 20:37:27.967288
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    assert PolandSpecProvider(seed=32423).nip() == '6101234567'
    assert PolandSpecProvider(seed=32423).pesel() == '88051207044'
    assert PolandSpecProvider(seed=32423).regon() == '936192227'


# Generated at 2022-06-23 20:37:31.512704
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()

    assert provider.__class__.__name__ == 'PolandSpecProvider'
    assert provider._data['name']['surname']['male'][0] == 'Nowak'


# Generated at 2022-06-23 20:37:32.480824
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
   poland = PolandSpecProvider()




# Generated at 2022-06-23 20:37:36.114582
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    p = PolandSpecProvider()
    assert p.nip() == '107011007'
    assert p.pesel() == '98061205099'
    assert p.regon() == '225777958'

# Generated at 2022-06-23 20:37:47.169489
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    UPPER_BOUND = 998
    LOWER_BOUND = 101
    multiplier = 1000000
    INITIAL_BOUND = 101000000
    COEFF_RANGE = (1, 8)

    nip_provider = PolandSpecProvider()
    # Testing the range of the first two digits
    for _ in range(10000):
        assert LOWER_BOUND <= int(nip_provider.nip()[:2]) <= UPPER_BOUND
    # Testing the range of the whole NIP
    for _ in range(10000):
        assert INITIAL_BOUND <= int(nip_provider.nip()) <= INITIAL_BOUND + multiplier
    # Testing coefficients for NIP

# Generated at 2022-06-23 20:37:49.203372
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel(gender=Gender.MALE)
    assert len(pesel) == 11


# Generated at 2022-06-23 20:37:53.892729
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    p = PolandSpecProvider(seed=1234)
    assert p.random.get_state() == (1234,)
    assert p.seed == 1234
    assert p.name == 'poland_provider'

# Generated at 2022-06-23 20:38:01.982485
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    pesel_provider = PolandSpecProvider()
    # Generate PESEL for men
    for men in range (10):
        men_pesel = pesel_provider.pesel(gender = Gender.MALE)
        # Gender digit of first man's PESEL must be equal to one of
        # [1, 3, 5, 7]
        if men == 0:
            assert int(men_pesel[-1]) in [1, 3, 5, 7, 9]
        # All gender digits of PESEL numbers generated for men
        # must be equal to one of [1, 3, 5, 7]
        else:
            assert int(men_pesel[-1]) in [1, 3, 5, 7, 9]
    # Generate PESEL for

# Generated at 2022-06-23 20:38:04.493005
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    assert len(PolandSpecProvider().regon()) == 9
"""
assert False if len(PolandSpecProvider().regon()) != 9
sys.exit(1)
"""


# Generated at 2022-06-23 20:38:06.856464
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    s = PolandSpecProvider()
    assert s.nip() is not None
    assert s.regon() is not None
    assert s.pesel() is not None

# Generated at 2022-06-23 20:38:10.912462
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    spec_provider = PolandSpecProvider()
    print("spec_provider.nip(): " + spec_provider.nip())
    print("spec_provider.pesel(): " + spec_provider.pesel())
    print("spec_provider.regon(): " + spec_provider.regon())

test_PolandSpecProvider()

# Generated at 2022-06-23 20:38:12.995901
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider_1 = PolandSpecProvider()
    assert (len(provider_1.nip()) == 10) # test if length of NIP is 10
    

# Generated at 2022-06-23 20:38:21.260646
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """
    Unit test for method pesel of class PolandSpecProvider
    """
    from datetime import datetime
    from mimesis.enums import Gender

    p = PolandSpecProvider()
    # Generate random pesel for male with initial date
    pesel = p.pesel(birth_date = datetime(2004, 9, 17), gender = Gender.MALE)

    assert pesel[:2] == str(2004)[2:]
    assert pesel[2:4] == "09"
    assert pesel[4:6] == "17"
    assert pesel[6:9] in [str(x).zfill(3) for x in range(1000)]
    assert int(pesel[9]) in [1, 3, 5, 7, 9]

# Generated at 2022-06-23 20:38:23.512473
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    seed = 347474
    expected = '978310032'
    pl = PolandSpecProvider(seed)
    actual = pl.regon()
    assert expected == actual



# Generated at 2022-06-23 20:38:25.844628
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider(seed=1)
    regon = provider.regon()
    assert regon == "738176839"


# Generated at 2022-06-23 20:38:27.452671
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()
    print(pesel)


# Generated at 2022-06-23 20:38:29.601568
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Test for method regon of class PolandSpecProvider."""
    from mimesis.providers.poland import PolandSpecProvider
    x = PolandSpecProvider()
    x.regon()


# Generated at 2022-06-23 20:38:33.611356
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    # Assert result
    assert provider.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.MALE) == '9212350689'
    assert provider.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.FEMALE) == '8212358575'

# Generated at 2022-06-23 20:38:41.759854
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    class IDataProvider(PolandSpecProvider):
        def __init__(self, seed = None):
            super().__init__(seed = seed)

        def get_next_seed(self):
            seed = self.random.getrandbits(128)
            return seed

    provider = IDataProvider()
    pesel = provider.pesel(birth_date = provider.birth_date(), gender = provider.gender())
    assert(isinstance(pesel, str))
    assert(len(pesel) == 11)


# Generated at 2022-06-23 20:38:43.207501
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    seed = "3f3ee"
    provider = PolandSpecProvider(seed)
    assert provider.nip() == "7968086462"


# Generated at 2022-06-23 20:38:46.735062
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Unit test for PolandSpecProvider"""
    from mimesis.enums import Gender
    sp = PolandSpecProvider()
    assert sp.nip()
    assert sp.pesel(birth_date=Datetime().datetime(), gender=Gender.MALE)
    assert sp.regon()

# Generated at 2022-06-23 20:38:55.034027
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    import random
    import re

    NIP = '\d{10}'
    NUMBERS = [str(i) for i in list(range(0, 10))]
    for seed in [random.randint(0, 1000000)]:
        random.seed(seed)
        pl_provider = PolandSpecProvider(seed)
        nip = pl_provider.nip()
        assert re.match(NIP, nip)
        assert nip[0:3] in NUMBERS
        assert nip[3] != '0'
        assert nip[4:9] in NUMBERS
        assert nip[9] not in ['0', '1']


# Generated at 2022-06-23 20:38:56.615482
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    polish_spec_provider = PolandSpecProvider()
    assert polish_spec_provider is not None


# Generated at 2022-06-23 20:39:02.008674
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    # create object
    x = PolandSpecProvider()

    # NIP
    nip = x.nip()
    assert len(nip) == 10

    # PESEL
    pesel = x.pesel()
    assert len(pesel) == 11

    # REGON
    regon = x.regon()
    assert len(regon) == 9

# Generated at 2022-06-23 20:39:03.619432
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    pass
# the class for generate random valid 10-digit NIP

# Generated at 2022-06-23 20:39:04.882954
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    assert len(PolandSpecProvider().nip()) == 10


# Generated at 2022-06-23 20:39:08.140596
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    from datetime import date
    from mimesis.typing import Gender

    date_object = date(1986, 4, 23)
    print(PolandSpecProvider().pesel(birth_date=date_object, gender=Gender.FEMALE))

if __name__ == '__main__':
    test_PolandSpecProvider_pesel()

# Generated at 2022-06-23 20:39:15.177167
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """ Test code for method pesel of class PolandSpecProvider."""
    gender = Gender.MALE
    birth_date = Datetime().datetime(1970, 2005)
    pesel = PolandSpecProvider().pesel(birth_date, gender)
    pesel_date = pesel[0:2] + pesel[2:4] + "19" + pesel[4:6]
    date = Datetime().date(1970, 2005)
    date_str = date.strftime("%d%m%Y")
    assert pesel_date == date_str

# Generated at 2022-06-23 20:39:19.227098
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    assert provider.pesel( Datetime().datetime(2000, 2000, 29, 11, 1, 2) ) == "00291101029"
    assert provider.pesel( Datetime().datetime(2018, 2018, 14, 12, 1, 1) ) == "18120101149"
    assert provider.pesel( Datetime().datetime(2099, 2099, 1, 1, 1, 1) ) == "99010101119"
    assert provider.pesel( Datetime().datetime(2199, 2199, 29, 2, 1, 1) ) == "99020101057"
    assert provider.pesel( Datetime().datetime(2299, 2299, 1, 2, 1, 1) ) == "99020101065"
    assert provider.pesel() != provider.pesel

# Generated at 2022-06-23 20:39:22.846702
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    print("\nTesting method nip() for class PolandSpecProvider")
    pw = PolandSpecProvider()
    nip = pw.nip()
    print("\nVerifying the generated NIP: " + nip)
    assert(len(nip) == 10)


# Generated at 2022-06-23 20:39:26.922877
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    assert provider.nip()
    assert provider.pesel()
    assert provider.regon()
    assert provider.nip() == "9320039155"
    assert provider.pesel() == "90071810155"
    assert provider.regon() == "259546489"

# Generated at 2022-06-23 20:39:28.965829
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    assert provider.provider == 'poland_provider'


# Generated at 2022-06-23 20:39:30.677292
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()
    assert isinstance(pesel, str)
    assert len(pesel) == 11


# Generated at 2022-06-23 20:39:32.551023
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    ps = PolandSpecProvider()
    print(ps.nip())

# Generated at 2022-06-23 20:39:37.559741
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pl_provider = PolandSpecProvider()
    pesel_test = pl_provider.pesel()
    assert len(pesel_test) == 11, "Wrong length of pesel"
    assert pesel_test.isdigit(), "pesel is not a number"


# Generated at 2022-06-23 20:39:43.715366
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    with PolandSpecProvider(seed=123) as poland_provider:
        assert poland_provider.nip() == '9589059734'
        assert poland_provider.pesel() == '51051126471'
        assert poland_provider.regon() == '84738891'

if __name__ == '__main__':
    test_PolandSpecProvider()

# Generated at 2022-06-23 20:39:45.504820
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    assert PolandSpecProvider().regon() is not None
test_PolandSpecProvider_regon()


# Generated at 2022-06-23 20:39:48.749262
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    pol = PolandSpecProvider() # PolandSpecProvider object created
    assert len(pol.regon()) == 9 # if the returned string is of length 9


# Generated at 2022-06-23 20:39:51.998778
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider(seed=4)
    pesel = provider.pesel(birth_date=provider.datetime(1940, 2018), gender=Gender.MALE)
    assert pesel == '93062736272'


# Generated at 2022-06-23 20:39:54.896064
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    pl = PolandSpecProvider(seed = "bloomberg")
    print(pl.nip())
    print(pl.pesel())
    print(pl.regon())

#test_PolandSpecProvider()

# Generated at 2022-06-23 20:40:00.674525
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    seed = "The quick brown fox jumps over the lazy dog"
    s = PolandSpecProvider(seed)

    assert s.datetime().rand_datetime()
    assert s.nip() == '181917039'
    assert s.pesel() == '88031407898'
    assert s.regon() == '94647469'

# Generated at 2022-06-23 20:40:03.358223
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_provider = PolandSpecProvider()
    assert len(poland_provider.pesel()) == 11
    assert isinstance(poland_provider.pesel(), str)


# Generated at 2022-06-23 20:40:06.694275
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()
    check_digit = int(pesel[-1])
    assert len(pesel) == 11

    coeffs = (9, 7, 3, 1, 9, 7, 3, 1, 9, 7)
    suma = 0
    for i in range(10):
        suma += int(pesel[i]) * coeffs[i]
    assert suma % 10 == check_digit

# Generated at 2022-06-23 20:40:14.126286
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider(seed=42)

    # test pesel
    assert p.pesel(birth_date=Datetime().datetime(1900, 2018),
                gender=Gender.MALE) == '76121300300'
    assert p.pesel(gender=Gender.MALE) == '59041230571'
    assert p.pesel(gender=Gender.FEMALE) == '76071827772'
    assert p.pesel(gender=None) == '42092122082'

# Generated at 2022-06-23 20:40:20.687679
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider"""
    p = PolandSpecProvider()
    assert len(p.pesel()) == 11
    assert p.pesel(birth_date=Datetime(seed=3).datetime(1940, 2018), gender=Gender.MALE) == '23207591012'
    assert p.pesel(birth_date=Datetime(seed=3).datetime(1940, 2018), gender=Gender.FEMALE) == '23207591022'


# Generated at 2022-06-23 20:40:25.683313
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    p = PolandSpecProvider()
    regon = p.regon()
    regon2 = p.regon()

    assert len(regon) == 9
    assert len(regon2) == 9

    assert isinstance(regon, str)
    assert isinstance(regon2, str)


# Generated at 2022-06-23 20:40:29.117033
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    assert provider.pesel(gender=Gender.MALE) == "93022711768"
    assert provider.pesel(gender=Gender.FEMALE) == "27042480350"

# Generated at 2022-06-23 20:40:30.108429
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    PolandSpecProvider().pesel()

# Generated at 2022-06-23 20:40:32.049545
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    obj = PolandSpecProvider(seed=1234567890)
    assert obj.regon() == '904250504'


# Generated at 2022-06-23 20:40:35.394692
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    # First, set a seed and get an instance of PolandSpecProvider
    p = PolandSpecProvider(seed=42)
    # Get a REGON
    regon = p.regon()
    assert regon.isdigit() is True

# Generated at 2022-06-23 20:40:37.667044
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    nip = provider.nip()
    assert isinstance(nip, str)
    assert len(nip) == 10


# Generated at 2022-06-23 20:40:39.025572
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    p = PolandSpecProvider()
    assert p is not None

# Generated at 2022-06-23 20:40:41.127459
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    XX = PolandSpecProvider()

    #print(XX.nip())
    #print(XX.pesel()) 
    #print(XX.regon())

# Generated at 2022-06-23 20:40:47.017969
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    from mimesis.enums import Gender

    print("Testing method nip of class PolandSpecProvider")

    pl = PolandSpecProvider()
    for i in range(100):
        assert (pl.nip()[0] == '1')
        assert (len(pl.nip()) == 10)
        # print("Generated NIP: " + p.nip())

    print("Test method nip of class PolandSpecProvider: OK")


# Generated at 2022-06-23 20:40:50.638285
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    psp = PolandSpecProvider()
    regon = psp.regon()
    assert len(regon) > 1
    assert regon[0] != '0'


# Generated at 2022-06-23 20:40:51.693200
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    PolandSpecProvider().pesel()

# Generated at 2022-06-23 20:40:55.543261
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Test the constructor of PolandSpecProvider class."""
    provider = PolandSpecProvider()
    assert provider is not None

    assert provider.nip() is not None
    assert provider.pesel(birth_date = "09/10/1998") is not None
    assert provider.regon() is not None

# Generated at 2022-06-23 20:40:57.824829
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provincial_number = PolandSpecProvider().regon()
    assert len(provincial_number) == 9
    assert provincial_number.isdigit()


# Generated at 2022-06-23 20:41:01.031983
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Test for constructor of class PolandSpecProvider."""
    # Without seed
    provider = PolandSpecProvider()
    assert provider is not None
    # With seed
    provider = PolandSpecProvider(seed=12345)
    assert provider is not None


# Generated at 2022-06-23 20:41:07.316677
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_provider = PolandSpecProvider(seed=123123)
    assert poland_provider.pesel(gender=Gender.MALE) == '19011720304'
    assert poland_provider.pesel(gender=Gender.FEMALE) == '03011930020'
    assert poland_provider.pesel(gender=Gender.FEMALE) == '19401404035'

# Generated at 2022-06-23 20:41:08.147923
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    p = PolandSpecProvider()
    assert p.regon() == '907446884'



# Generated at 2022-06-23 20:41:12.084341
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    from mimesis.providers import PolandSpecProvider
    from mimesis.enums import Gender
    p = PolandSpecProvider()
    assert p.pesel(Gender.MALE).startswith('4')
    assert p.pesel(Gender.FEMALE).startswith('5')

# Generated at 2022-06-23 20:41:16.094993
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider(seed=12345)
    nip_1 = provider.nip()
    assert nip_1 == '1015151006'
    nip_2 = provider.nip()
    assert nip_2 == '1057195862'


# Generated at 2022-06-23 20:41:20.470513
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    text_of_pesel = PolandSpecProvider().pesel()
    assert len(text_of_pesel) == 11
    assert text_of_pesel.isdigit()
    assert int(text_of_pesel) > 10000000000


# Generated at 2022-06-23 20:41:22.152468
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    uut = PolandSpecProvider()
    assert len(uut.regon()) == 9

# Generated at 2022-06-23 20:41:24.798387
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    instance = PolandSpecProvider()
    assert isinstance(instance.nip(), str)


# Generated at 2022-06-23 20:41:30.109345
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    mimesis.seed(123)
    ps = PolandSpecProvider()
    ps.pesel()


if __name__ == '__main__':
    test_PolandSpecProvider_pesel()
import mimesis
import mimesis.providers.person as mimesis_person

# Generated at 2022-06-23 20:41:31.709540
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider(seed=4545)
    expected_result = '85635312'
    actual_result = provider.regon()

    assert(expected_result == actual_result)

# Generated at 2022-06-23 20:41:33.400361
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    return pesel


# Generated at 2022-06-23 20:41:38.307734
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    poland_provider = PolandSpecProvider(seed=0)
    assert poland_provider.nip() == '8852683870'
    poland_provider = PolandSpecProvider(seed=0)
    assert poland_provider.nip() == '8852683870'


# Generated at 2022-06-23 20:41:39.603007
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():

    # Arrange
    provider = PolandSpecProvider()

    # Act
    result = provider.nip()

    # Assert
    assert len(result) == 10


# Generated at 2022-06-23 20:41:42.058558
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    print("Testing the method nip from class PolandSpecProvider")
    provider = PolandSpecProvider()
    print("The valid 10-digit NIP is: " + provider.nip())
    print()

# Generated at 2022-06-23 20:41:43.756466
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    pad = PolandSpecProvider()
    assert pad.provider.name == 'poland_provider'



# Generated at 2022-06-23 20:41:47.317997
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    with open('../../../../statapp/conftest.py') as f:
        class_ = f.readlines()

    class_ = ''.join(class_)
    assert class_.find('PolandSpecProvider') != -1


# Generated at 2022-06-23 20:41:51.387924
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test for method pesel of class PolandSpecProvider"""
    provider = PolandSpecProvider(seed=10)
    result = provider.pesel()
    expected = '38112402758'
    assert result == expected


# Generated at 2022-06-23 20:41:55.260218
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    PolandSpecProvider()
    assert PolandSpecProvider().nip().isdigit()
    assert len(PolandSpecProvider().nip())==10
    assert PolandSpecProvider().pesel().isdigit()
    assert len(PolandSpecProvider().pesel())==11

# Generated at 2022-06-23 20:41:57.994451
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    # 
    provider = PolandSpecProvider(seed=4)
    result = provider.nip()
    assert result == '1013473908'


# Generated at 2022-06-23 20:42:01.459786
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    assert PolandSpecProvider().pesel(birth_date='1999-07-12', gender='f')
    assert PolandSpecProvider().pesel(birth_date='1999-07-12', gender='F')
    assert PolandSpecProvider().pesel  # return check



# Generated at 2022-06-23 20:42:02.934584
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    result = provider.pesel()
    assert len(result) == 11

# Generated at 2022-06-23 20:42:12.406251
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    # first unit test
    number_of_test_cases = 100

    for i in range(number_of_test_cases):
        # establish instance of class PolandSpecProvider
        obj = PolandSpecProvider()
        # generate a random REGON
        random_regon = obj.regon()
        # split REGON into individual digits, convert digits to integers and place them in a list
        random_regon_int_list = []
        for digit in random_regon:
            random_regon_int_list.append(int(digit))
        # establish REGON coefficients - a list of int
        regon_coeffs = (8, 9, 2, 3, 4, 5, 6, 7)
        # sum the products of corresponding digits and coefficients

# Generated at 2022-06-23 20:42:18.094436
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    # object of class PolandSpecProvider
    psp = PolandSpecProvider()
    # testing method pesel
    assert len(psp.pesel()) == 11
    # testing method regon
    assert len(psp.regon()) == 9
    # testing method nip
    assert len(psp.nip()) == 10

# Generated at 2022-06-23 20:42:19.899693
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    polandSpecProvider = PolandSpecProvider()
    assert polandSpecProvider


# Generated at 2022-06-23 20:42:22.664335
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    data = PolandSpecProvider()
    pesel = data.pesel(gender=Gender.MALE)
    num = int(pesel[9])
    assert num in [0, 2, 4, 6, 8]

# Generated at 2022-06-23 20:42:27.068965
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    data_provider = PolandSpecProvider(seed=432)
    nip1 = data_provider.nip()
    nip2 = data_provider.nip()
    print(nip1, nip2)


# Generated at 2022-06-23 20:42:30.254228
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    import datetime
    a = PolandSpecProvider(111111111)
    assert a.regon() == "717013281", "Incorrect regon"
    assert len(a.regon()) == 9, "Incorrect regon length"
    regon = a.regon(datetime.datetime.now(datetime.timezone.utc))
    assert len(regon) == 9, "Incorrect regon length"
    assert type(regon) == str, "Incorrect type"
    assert type(a.regon()) == str, "Incorrect type"



# Generated at 2022-06-23 20:42:32.791424
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()
    assert type(pesel) is str
    assert len(pesel) == 11



# Generated at 2022-06-23 20:42:36.957730
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    # Create PolandSpecProvider object
    provider = PolandSpecProvider(seed=None)
    # Call method nip
    assert len(provider.nip()) == 10
    assert type(provider.nip()) == str


# Generated at 2022-06-23 20:42:37.329700
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    assert PolandSpecProvider()

# Generated at 2022-06-23 20:42:40.059290
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Unit test for constructor of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    assert provider.__class__.__name__ == 'PolandSpecProvider'


# Generated at 2022-06-23 20:42:41.234947
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    assert PolandSpecProvider().nip() == "6666638487" 


# Generated at 2022-06-23 20:42:45.066173
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    pl_provider = PolandSpecProvider()
    regon = pl_provider.regon()
    assert 9 == len(regon)
    for digit in regon:
        assert isinstance(digit, int)
        assert digit >= 0
        assert digit <= 9


# Generated at 2022-06-23 20:42:48.788996
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider()
    for i in range(10):
        regon = provider.regon()
        assert len(regon) == 9

# Unit tests for method nip of class PolandSpecProvider

# Generated at 2022-06-23 20:42:53.517933
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """
    This test checks if NIP generated by the method nip is actually a valid NIP.
    """
    pl_provider = PolandSpecProvider()
    nip = pl_provider.nip()
    assert len(nip) == 10 and int(nip[0]) != 0


# Generated at 2022-06-23 20:42:56.043896
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    import re
    pattern = re.compile('^[0-9]{10}$')
    p = PolandSpecProvider()

    s = p.nip()
    assert pattern.match(s)


# Generated at 2022-06-23 20:43:00.469632
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel(birth_date=Datetime().datetime(1992, 4, 19), gender=Gender.MALE)
    print(pesel)
    assert len(pesel) == 11
    assert pesel == "92041979514"

# Generated at 2022-06-23 20:43:09.372155
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    m=PolandSpecProvider()
    regon=m.regon()
    assert regon[-1]=='0' or regon[-1]=='1' or regon[-1]=='2' or regon[-1]=='3' or regon[-1]=='4' or \
           regon[-1]=='5' or regon[-1]=='6' or regon[-1]=='7' or regon[-1]=='8' or regon[-1]=='9'

# Generated at 2022-06-23 20:43:13.069871
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Test the generation of a random valid 9-digit REGON."""
    poland_provider = PolandSpecProvider()
    regon = poland_provider.regon()
    print(regon)
    regon = poland_provider.regon()
    print(regon)
    regon = poland_provider.regon()
    print(regon)


# Generated at 2022-06-23 20:43:14.326806
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    assert len(PolandSpecProvider().regon()) == 9


# Generated at 2022-06-23 20:43:16.989671
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    from mimesis.providers import poland
    check=poland.PolandSpecProvider()
    assert len(check.nip())==10
    assert str(check.nip()[0])!="0"
    assert check.nip().isdigit()
    assert int(check.nip()[0])>1
    assert int(check.nip()[0])<=9
    assert int(check.nip()[1])==0


# Generated at 2022-06-23 20:43:21.157491
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    '''
    test_PolandSpecProvider_pesel()
    '''
    p = PolandSpecProvider()
    pesel = p.pesel()
    print(pesel)
    assert len(pesel) == 11

# Generated at 2022-06-23 20:43:25.440343
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()
    print('PESEL:', pesel)
    print('PESEL length:', len(pesel))

if __name__ == "__main__":
    print("Testing pesel...")
    test_PolandSpecProvider_pesel()

# Generated at 2022-06-23 20:43:35.138147
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    p = PolandSpecProvider()
    for i in range(0,100):
        result = p.regon()
        sum_v = 0
        regon_coeffs = (8, 9, 2, 3, 4, 5, 6, 7)
        regon_digits = [int(d) for d in str(result)]
        for i in range(0,8):
            sum_v += regon_coeffs[i]*regon_digits[i]
        checksum_digit = sum_v % 11
        if checksum_digit > 9:
            checksum_digit = 0
        assert regon_digits[-1] == checksum_digit
        assert len(result) == 9
        print(result)


# Generated at 2022-06-23 20:43:36.293438
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    p = PolandSpecProvider()
    assert len(p.regon()) == 9

# Generated at 2022-06-23 20:43:42.879929
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    from mimesis.builtins.pl import PolandSpecProvider
    from mimesis.enums import Gender
    from mimesis.typing import DateTime

    pesel_date_1 = DateTime('2018-03-03')
    pesel_date_2 = DateTime('1890-03-03')
    pesel_date_3 = DateTime('2000-03-03')
    pesel_date_4 = DateTime('2200-03-03')
    pesel_date_5 = DateTime('2099-01-01')
    poland_spec = PolandSpecProvider()

    # Check if pesel was created successfully
    assert poland_spec.pesel()
    assert poland_spec.pesel(birth_date=pesel_date_1)

# Generated at 2022-06-23 20:43:49.177575
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Test for class PolandSpecProvider"""
    provider = PolandSpecProvider()

    assert isinstance(provider.nip(), str)
    assert provider.__class__.__name__ == "PolandSpecProvider"


if __name__ == "__main__":
    provider = PolandSpecProvider()
    provider1 = PolandSpecProvider()
    print(provider.nip())
    print(provider.pesel())
    print(provider.regon())

    print(provider1.nip())
    print(provider1.pesel())
    print(provider1.regon())

# Generated at 2022-06-23 20:43:52.052540
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    pl = PolandSpecProvider(seed=5)

    expected = '3522242014'
    actual = pl.nip()
    assert expected == actual


# Generated at 2022-06-23 20:43:52.905979
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    PolandSpecProvider()

# Generated at 2022-06-23 20:44:01.543843
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Unit tests for  PolandSpecProvider.regon()."""
    regex = r'^\d{9}$'
    # Verify that first digit is not equal 0
    first_digit = PolandSpecProvider().regon()[0]
    assert first_digit != '0'
    # Verify that the function always returns the same string for the same seed
    for i in range(1, 100):
        regon = PolandSpecProvider(seed=i).regon()
        assert regon == PolandSpecProvider(seed=i).regon()
        assert regon != PolandSpecProvider(seed=i+1).regon()
    # Verify that the function returns different strings for different seed
    regon_set = set()
    for i in range(1, 100):
        regon = PolandSpecProvider(seed=i).regon()
        assert regon not in regon_set

# Generated at 2022-06-23 20:44:05.130513
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    test = PolandSpecProvider(seed=1)
    print("Generated NIP: " + test.nip())
    print("Generated PESEL: " + test.pesel())
    print("Generated REGON: " + test.regon())

if __name__ == '__main__':
    print("Running Unit Test for PolandSpecProvider...")
    test_PolandSpecProvider()

# Generated at 2022-06-23 20:44:12.210078
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    psi_regon = PolandSpecProvider().regon()
    psi_regon_int = int(psi_regon)
    # print('\n', psi_regon)

    regon_digit_check = lambda: psi_regon_int % 11
    regon_digit_control = lambda: psi_regon_int % 10

    if regon_digit_check() > 9:
        regon_digit_check() == regon_digit_control()
    else:
        regon_digit_check() == psi_regon_int % 11

    assert (True in (regon_digit_check() == psi_regon_int % 11) or
            True in (regon_digit_check() == regon_digit_control()))


# Generated at 2022-06-23 20:44:13.643039
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    d=PolandSpecProvider()
    for i in range(20):
        print(d.pesel())


# Generated at 2022-06-23 20:44:17.979274
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    assert PolandSpecProvider.Meta.name == "poland_provider"
    assert PolandSpecProvider(seed=1).seed == 1
    
# Unit tests for nip() method of class PolandSpecProvider

# Generated at 2022-06-23 20:44:23.280687
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    from mimesis.providers import PolandSpecProvider
    from mimesis.enums import Gender

    p = PolandSpecProvider()
    for _ in range(10):
        print(p.regon())
        assert len(p.regon()) == 9


# Generated at 2022-06-23 20:44:26.355251
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    pl = PolandSpecProvider()
    nip = pl.nip()
    assert len(nip) == 10
    nip_int = int(nip)
    nip_digits = [int(d) for d in str(nip_int)]
    assert 0 < nip_digits[0] < 10


# Generated at 2022-06-23 20:44:27.867791
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    nip = provider.nip()
    assert len(nip) == 10


# Generated at 2022-06-23 20:44:39.949313
# Unit test for method nip of class PolandSpecProvider

# Generated at 2022-06-23 20:44:41.240505
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    result = provider.nip()
    assert len(result) == 10



# Generated at 2022-06-23 20:44:46.411510
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """
        Testing method pesel of class PolandSpecProvider
    """
    pl = PolandSpecProvider()
    pesel_value = pl.pesel()
    assert type(pesel_value) == str
    assert len(pesel_value) == 11


# Generated at 2022-06-23 20:44:52.396611
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    nip = provider.nip()
    nip_int = int(nip)
    nip_int_str = str(nip_int)
    assert isinstance(nip, str)
    assert nip_int >= 101000000 and nip_int <= 998999999
    assert len(nip) == 10
    assert len(nip_int_str) == 9


# Generated at 2022-06-23 20:44:58.368627
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    pl = PolandSpecProvider()
    nip = pl.nip()
    nip_coefficients = (6, 5, 7, 2, 3, 4, 5, 6, 7)
    assert(len(nip) == 10)
    nip_digits = [int(d) for d in nip]
    assert(len(nip_digits) == 10)
    sum_v = sum([nc * nd for nc, nd in zip(nip_coefficients, nip_digits[:9])])
    assert(sum_v % 11 == nip_digits[9])


# Generated at 2022-06-23 20:45:08.689669
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Test if the method PolandSpecProvider.regon returns a valid regon."""
    import random
    import re

    for i in range(1, 1000):
        random.seed()
        regon = PolandSpecProvider().regon()
        regon_coeffs = (8, 9, 2, 3, 4, 5, 6, 7)
        regon_digits = [int(d) for d in regon]

        sum_v = sum([nc * nd for nc, nd in zip(regon_coeffs, regon_digits)])
        if sum_v % 11 > 9:
            checksum_digit = 0
        else:
            checksum_digit = sum_v % 11
        assert regon_digits[len(regon_digits) - 1] == checksum_digit

# Generated at 2022-06-23 20:45:12.586199
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
	pl = PolandSpecProvider()
	assert pl.nip() == '1122334455'
	assert pl.pesel() == '01923938662'
	assert pl.regon() == '112233445'

# Generated at 2022-06-23 20:45:15.184557
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    psp = PolandSpecProvider()
    # Initialize NIP variable
    nip = psp.nip()
    assert nip.__len__() == 10



# Generated at 2022-06-23 20:45:16.887207
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    assert len(PolandSpecProvider().nip()) == 10


# Generated at 2022-06-23 20:45:24.693489
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    pesel_provider = PolandSpecProvider()
    nip_count = 0
    successful_nip_count = 0
    while nip_count < 1000:
        nip = pesel_provider.nip()
        nip_count += 1
        nip_digits = [int(d) for d in str(nip)]
        nip_coefficients = (6, 5, 7, 2, 3, 4, 5, 6, 7)
        sum_v = sum([nc * nd for nc, nd in
                     zip(nip_coefficients, nip_digits)])

        checksum_digit = sum_v % 11
        if checksum_digit > 9:
            if nip[9] == '0':
                successful_nip_count += 1
            continue

# Generated at 2022-06-23 20:45:27.270249
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Unit test for constructor of class PolandSpecProvider."""
    pesel =  PolandSpecProvider.pesel(birth_date, gender)
    assert pesel == '76012208143'

# Generated at 2022-06-23 20:45:29.487910
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider()
    assert provider.regon() == "716862806"

# Generated at 2022-06-23 20:45:32.520493
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel_test_date = PolandSpecProvider().pesel(birth_date=Datetime().datetime(2000,2000), \
        gender=Gender.FEMALE)

    assert len(pesel_test_date) == 11
    assert pesel_test_date.isdigit()


# Generated at 2022-06-23 20:45:33.916899
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    assert provider is not None


# Generated at 2022-06-23 20:45:36.145455
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    nip = provider.nip()
    assert len(nip) == 10



# Generated at 2022-06-23 20:45:43.921902
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel_1 = provider.pesel(birth_date="2005-05-15", gender=Gender.MALE)
    pesel_2 = provider.pesel(birth_date="2005-05-15", gender=Gender.FEMALE)
    pesel_3 = provider.pesel(birth_date="2005-05-15")
    pesel_4 = provider.pesel(gender=Gender.MALE)
    pesel_5 = provider.pesel(gender=Gender.FEMALE)
    pesel_6 = provider.pesel()
    assert len(pesel_1)==11 and int(pesel_1[0])==0 and int(pesel_1[1])==5 and int(pesel_1[2])==0 and int(pesel_1[3])==5

# Generated at 2022-06-23 20:45:48.796063
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    print("[+] Running Unit Test for Constructor of Class PolandSpecProvider")
    
    # Create PolandSpecProvider Object
    ob = PolandSpecProvider()

    # Checks the data type of object
    if isinstance(ob, BaseSpecProvider):
        print("[+] Constructor of Class PolandSpecProvider is working")
    else:
        print("[-] Constructor of Class PolandSpecProvider is not working")


# Unit tests for methods of class PolandSpecProvider

# Generated at 2022-06-23 20:45:58.250168
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    nip_digits = [int(d) for d in str(716)]
    nip_digits += [random.randint(0, 9) for _ in range(6)]
    nip_coefficients = (6, 5, 7, 2, 3, 4, 5, 6, 7)
    sum_v = sum([nc * nd for nc, nd in zip(nip_coefficients, nip_digits)])

    checksum_digit = sum_v % 11
    if checksum_digit > 9:
        return self.nip()
    nip_digits.append(checksum_digit)
    return ''.join(str(d) for d in nip_digits)  # wypisz wynik


# Generated at 2022-06-23 20:46:07.241117
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Unit test for method regon of class PolandSpecProvider."""
    from mimesis import PolandSpecProvider

    data = [
        '201880114',
        '232307474',
        '753716319',
        '383396523',
        '832911434',
        '955154715',
        '938683021',
        '956172852',
        '767429836',
        '795783967',
        '923444447',
        '783828662',
        '102099078',
        '222448341',
        '849306448',
        '969974226',
        '911540000',
        '966652227',
        '959194692',
        '637047332',
    ]

   

# Generated at 2022-06-23 20:46:09.889339
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Test method regon of class PolandSpecProvider.

    :return: True if test is passed
    """
    p = PolandSpecProvider()
    print("Test result method regon of class PolandSpecProvider: " + p.regon())
    return True


# Generated at 2022-06-23 20:46:11.934551
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    c = PolandSpecProvider()
    c.polish.nip()
    c.polish.pesel()

# Generated at 2022-06-23 20:46:19.723699
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    zeros = [0, 0, 0, 0, 0, 0, 0, 0, 0]
    ones = [1, 1, 1, 1, 1, 1, 1, 1, 1]
    specific = PolandSpecProvider(seed=zeros)
    assert specific.regon() == '000000001'
    specific = PolandSpecProvider(seed=ones)
    assert specific.regon() == '111111111'
    specific = PolandSpecProvider(seed=zeros)
    assert specific.regon() == '000000001'


# Generated at 2022-06-23 20:46:21.300836
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    pl = PolandSpecProvider()
    test1 = '8071527101'
    assert(pl.nip() == '8071527101')


# Generated at 2022-06-23 20:46:27.662648
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    poland_provider = PolandSpecProvider()
    regon_value = poland_provider.regon()
    assert len(regon_value) == 9
    try:
        int(regon_value)
    except ValueError:
        assert False, "regon should contain only digits"


# Generated at 2022-06-23 20:46:29.962977
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    for i in range(100):
        pesel = provider.pesel()
        assert len(pesel) == 11
        assert all(d.isnumeric() for d in pesel)

# Generated at 2022-06-23 20:46:33.107089
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    pl_provider = PolandSpecProvider()
    result = pl_provider.nip()
    assert len(result) == 10
    assert result.isdigit()
    

# Generated at 2022-06-23 20:46:36.851605
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    poland_spec_provider = PolandSpecProvider()
    assert poland_spec_provider.provider == 'poland_provider'
    assert poland_spec_provider.locale == 'pl'


# Generated at 2022-06-23 20:46:39.524306
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Test the constructor of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    assert provider.locale == 'pl'

# Generated at 2022-06-23 20:46:42.172162
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    l = PolandSpecProvider()
    assert re.fullmatch(r'\d{10}', l.nip()) and len(l.nip()) == 10


# Generated at 2022-06-23 20:46:43.825990
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    temp = PolandSpecProvider()
    result = temp.nip()
    print(result)



# Generated at 2022-06-23 20:46:46.503393
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    c = PolandSpecProvider('123')
    assert c.nip() == "4709547980"
    assert c.pesel() == "92510223841"
    assert c.regon() == "056853281"

# Generated at 2022-06-23 20:46:50.225454
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    data = provider.nip()
    print("provider.nip(): {}.".format(data))

#Unit test for method pesel of class PolandSpecProvider

# Generated at 2022-06-23 20:46:55.107470
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    ps = PolandSpecProvider(seed=1)
    #pesel
    print(ps.pesel())
    #nip
    print(ps.nip())
    #regon
    print(ps.regon())

if __name__ == '__main__':
    test_PolandSpecProvider()

# Generated at 2022-06-23 20:46:57.901662
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    p = PolandSpecProvider()
    regon = p.regon()
    assert len(regon) == 9

if __name__ == "__main__":
    test_PolandSpecProvider_regon()

# Generated at 2022-06-23 20:47:02.072353
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    poland_provider_seed = PolandSpecProvider(seed=31337)
    poland_provider_seed_2 = PolandSpecProvider(seed=31337)
    poland_provider = PolandSpecProvider()
    assert poland_provider_seed.regon() == poland_provider_seed_2.regon() != poland_provider.regon()



# Generated at 2022-06-23 20:47:08.172248
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # Create class object
    PolandSpecProvider = mimesis.PolandSpecProvider()
    pesel = PolandSpecProvider.pesel(birth_date=datetime.datetime(1996, 9, 10), gender=0)
    assert len(pesel) == 11
    assert pesel == '96910851154'