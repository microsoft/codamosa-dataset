

# Generated at 2022-06-23 20:37:06.904819
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    instance = PolandSpecProvider()
    assert instance is not None


# Generated at 2022-06-23 20:37:10.767121
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    poland_spec_provider = PolandSpecProvider()
    print("Locale: ", poland_spec_provider.locale)
    print("Provider: ", poland_spec_provider.__provider__)
    print("\n")

# Generated at 2022-06-23 20:37:13.000701
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    psp = PolandSpecProvider()
    nip = psp.nip()
    assert len(nip) == 10


# Generated at 2022-06-23 20:37:23.576781
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    print("test_PolandSpecProvider_pesel start")

    po = PolandSpecProvider(seed=42)

    pesel_1 = po.pesel(birth_date=Datetime().datetime(1984, 4, 24),
                       gender=Gender.MALE)
    assert pesel_1 == '84042245277'
    pesel_2 = po.pesel(birth_date=Datetime().datetime(1992, 5, 10),
                       gender=Gender.FEMALE)
    assert pesel_2 == '92051078726'
    pesel_3 = po.pesel(birth_date=Datetime().datetime(1990, 12, 30),
                       gender=None)
    assert pesel_3 == '90123017969'

# Generated at 2022-06-23 20:37:29.481544
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider()

    digits = []

    for i in range(len(provider.regon())):
        digits.append(int(provider.regon()[i]))

    sum_v = digits[0] * 8 + digits[1] * 9 + digits[2] * 2 + digits[
        3] * 3 + digits[4] * 4 + digits[5] * 5 + digits[6] * 6 + \
             digits[7] * 7

    checksum_digit = sum_v % 11

    assert checksum_digit == digits[8]



# Generated at 2022-06-23 20:37:32.617796
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    assert provider.pesel(gender=Gender.MALE) == '82032302374'
    assert provider.pesel(gender=Gender.FEMALE) == '82080108041'



# Generated at 2022-06-23 20:37:33.723163
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    for i in range(10):
        nip_number = provider.nip()
        print(nip_number)



# Generated at 2022-06-23 20:37:34.339674
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    PolandSpecProvider()

# Generated at 2022-06-23 20:37:37.447256
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pl = PolandSpecProvider()
    assert len(str(pl.pesel())) == 11
    assert len(str(pl.pesel(gender=Gender.MALE))) == 11
    assert len(str(pl.pesel(gender=Gender.FEMALE))) == 11

# Generated at 2022-06-23 20:37:39.531712
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    assert len(PolandSpecProvider().regon()) == 9
    assert PolandSpecProvider().regon() == PolandSpecProvider('1').regon()


# Generated at 2022-06-23 20:37:41.121370
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    for i in range(100):
        reg = PolandSpecProvider()
        assert len(reg.regon()) == 9


# Generated at 2022-06-23 20:37:43.632303
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel(gender=Gender.FEMALE)
    assert len(pesel) == 11
    assert pesel[9] in ('2', '4', '6', '8')

# Generated at 2022-06-23 20:37:46.063020
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    print(provider.nip())


# Generated at 2022-06-23 20:37:48.186386
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()

    assert provider
    assert provider.locale == "pl"
    assert provider.seed is not None


# Generated at 2022-06-23 20:37:50.480734
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    pesel = PolandSpecProvider().pesel()
    assert len(pesel) == 11
    assert any(c.isdigit() for c in pesel)


# Generated at 2022-06-23 20:37:51.594742
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    PolandSpecProvider()

# Generated at 2022-06-23 20:37:53.047014
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    pesel = PolandSpecProvider().regon()
    assert len(str(pesel)) == 9


# Generated at 2022-06-23 20:37:55.201183
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    assert (str(PolandSpecProvider(seed=123456789).pesel(gender=Gender.FEMALE)) == '99021156641')

# Generated at 2022-06-23 20:38:02.671826
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Test function for PolandSpecProvider"""
    provider = PolandSpecProvider()
    assert provider
    assert provider.nip() != 0
    assert provider.pesel() != 0
    assert provider.regon() != 0
    assert provider.pesel(birth_date = datetime.datetime(2017, 6, 30)) == '1706302340235'
    assert provider.pesel(birth_date = datetime.datetime(2017, 6, 30), gender = "Male") == '1706302340235'
    assert provider.pesel(birth_date = datetime.datetime(2017, 6, 30), gender = Gender.MALE) == '1706302340235'

# Generated at 2022-06-23 20:38:06.934421
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
# test method regon from PolandSpecProvider
    from mimesis.providers import PolandSpecProvider
    from mimesis.enums import Gender
    pl = PolandSpecProvider()
    regon = pl.regon()
    assert len(regon) == 9
    assert isinstance(regon, str)
    assert regon.isdecimal()


# Generated at 2022-06-23 20:38:07.784872
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    _ = PolandSpecProvider()

# Generated at 2022-06-23 20:38:09.879592
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    import mimesis
    poland = mimesis.Poland()
    assert(len(poland.regon()) == 9)


# Generated at 2022-06-23 20:38:11.682079
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    x = PolandSpecProvider()
    y = x.regon()
    assert y.isdigit() and (len(y) == 9)


# Generated at 2022-06-23 20:38:14.874614
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    nip_generator = PolandSpecProvider()
    nip = nip_generator.nip()
    assert isinstance(nip, str)
    assert len(nip) == 10


# Generated at 2022-06-23 20:38:15.618620
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    PolandSpecProvider().regon()

# Generated at 2022-06-23 20:38:19.709862
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider(seed=42)
    data = provider.pesel(birth_date=provider.datetime(1940, 2018),
                          gender=provider.gender(male_first=0.5))
    assert data == '4601170000'
    assert type(data) is str
    assert len(data) == 11


# Generated at 2022-06-23 20:38:26.497312
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():

    # Initialize PolandSpecProvider
    psp = PolandSpecProvider()

    # Generate random valid 11-digit PESEL
    pesel = psp.pesel()

    # 11-digit PESEL should be a string
    assert type(pesel) == str

    # 11-digit PESEL should have a length of 11
    assert len(pesel) == 11

    # 11-digit PESEL should be a valid number
    assert pesel.isdigit() == True

    # Check for value error when gender is invalid
    try:
        psp.pesel(gender='test')
    except ValueError:
        assert True
    else:
        assert False


# Generated at 2022-06-23 20:38:29.067080
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider(seed=1).pesel()
    assert type(pesel) is str and len(pesel) == 11
    assert pesel == '96100902580'



# Generated at 2022-06-23 20:38:31.441744
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    # when
    provider = PolandSpecProvider()

    # then
    assert isinstance(provider.random, object)
    assert isinstance(provider.datetime, object)
    assert isinstance(provider._data, dict)
    assert isinstance(provider._validators, dict)


# Generated at 2022-06-23 20:38:33.440592
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    a=PolandSpecProvider()
    assert a.nip()=="087-101-29-39" ,"test_PolandSpecProvider_nip"


# Generated at 2022-06-23 20:38:37.184631
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    print('test_PolandSpecProvider_nip')
    pl = PolandSpecProvider()
    assert len(pl.nip()) == 10
    assert pl.nip().isdecimal()


# Generated at 2022-06-23 20:38:42.899603
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Constructor of class PolandSpecProvider"""

    provider = PolandSpecProvider(seed=12345678)
    assert provider.pesel() == '96092357012'

    provider = PolandSpecProvider(seed=87654321)
    assert provider.pesel() == '96092357012'

    provider = PolandSpecProvider(seed=12345679)
    assert provider.pesel() == '92115155981'

# Generated at 2022-06-23 20:38:44.496536
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    
    for _ in range(10):
        nip = PolandSpecProvider().nip()
        assert len(nip) == 10
        assert nip.isdigit()


# Generated at 2022-06-23 20:38:46.593924
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    assert len(PolandSpecProvider().pesel()) == 11

# Generated at 2022-06-23 20:38:48.992348
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    print("Testing PolandSpecProvider.regon")
    assert len(PolandSpecProvider().regon()) == 9
# end of function test_PolandSpecProvider_regon


# Generated at 2022-06-23 20:38:51.027214
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    # Testing a constructor of class PolandSpecProvider
    assert(PolandSpecProvider())


# Generated at 2022-06-23 20:38:52.664995
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    assert type(provider) == PolandSpecProvider

# Provider provides regon

# Generated at 2022-06-23 20:38:53.217189
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    pass

# Generated at 2022-06-23 20:38:56.087351
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():  
    poland_spec_provider = PolandSpecProvider()
    assert poland_spec_provider is not None
    poland_spec_provider = PolandSpecProvider(seed=1)
    assert poland_spec_provider is not None



# Generated at 2022-06-23 20:38:57.448050
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    from mimesis.providers.poland import PolandSpecProvider
    poland = PolandSpecProvider()
    poland.nip()
    poland.pesel()
    poland.regon()

# Generated at 2022-06-23 20:39:07.723164
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    seed = 1
    p = PolandSpecProvider(seed)
    assert p.pesel(birth_date=p.datetime(2000), gender=Gender.MALE) == '02050803619'
    assert p.pesel(birth_date=p.datetime(2000), gender=Gender.FEMALE) == '02050801615'
    assert p.pesel(birth_date=p.datetime(1991), gender='male') == '91011411614'
    assert p.pesel(birth_date=p.datetime(1991), gender='female') == '91011402617'
    assert p.pesel(birth_date=p.datetime(1991)) == '91011404617'

# Generated at 2022-06-23 20:39:17.015894
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test for PESEL."""
    spec_provider = PolandSpecProvider('123')
    pesel = spec_provider.pesel(birth_date=(2000, 5, 1), gender=Gender.MALE)
    assert len(pesel) == 11
    assert pesel[9] in ['1', '3', '5', '7', '9']
    pesel = spec_provider.pesel(birth_date=(2000, 5, 1), gender=Gender.FEMALE)
    assert len(pesel) == 11
    assert pesel[9] in ['0', '2', '4', '6', '8']
    pesel = spec_provider.pesel(birth_date=(2000, 5, 1))
    assert len(pesel) == 11

# Generated at 2022-06-23 20:39:19.415772
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    PolandP = PolandSpecProvider()
    nipTest = PolandP.nip()
    print(nipTest)
    print(len(nipTest))

# Generated at 2022-06-23 20:39:21.940543
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    assert PolandSpecProvider().pesel()
    assert PolandSpecProvider().pesel(datetime.datetime(1994, 3, 16))
    assert PolandSpecProvider().pesel(gender=Gender.MALE)
    assert PolandSpecProvider().pesel(datetime.datetime(1994, 3, 16), Gender.MALE)


# Generated at 2022-06-23 20:39:29.062265
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Test regon method of class PolandSpecProvider."""
    # generate 3 kolejne regon-y
    regon1 = PolandSpecProvider().regon()
    regon2 = PolandSpecProvider().regon()
    regon3 = PolandSpecProvider().regon()
    assert (regon1 != regon2 != regon3 != regon1)
    # assert every regon is a string
    assert (isinstance(regon1, str) and
            isinstance(regon2, str) and
            isinstance(regon3, str))
    # assert every regon length is exactly 9
    assert (len(regon1) == len(regon2) ==
            len(regon3) == 9)
    # assert every regon's last digit is a checksum

# Generated at 2022-06-23 20:39:34.784917
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test class PolandSpecProvider, method pesel."""
    from datetime import datetime
    from mimesis.enums import Gender

    pl = PolandSpecProvider()
    pesel = pl.pesel(datetime(1993, 3, 5), Gender.FEMALE)
    assert int(pesel[4:6]) in (21, 41, 61)
    assert pesel[6] == '3'
    assert pesel[6] == '3'
    assert pesel[6] == '3'

    pesel = pl.pesel(gender=Gender.MALE)
    assert int(pesel[4:6]) in (20, 40, 60)

# Generated at 2022-06-23 20:39:37.723715
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Test method nip of class PolandSpecProvider."""
    provider = PolandSpecProvider()

    assert isinstance(provider.nip(), str)
    assert len(provider.nip()) == 10


# Generated at 2022-06-23 20:39:42.403329
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    assert 11 == len(p.pesel(gender=Gender.MALE))
    assert 11 == len(p.pesel(gender=Gender.FEMALE))
    assert 11 == len(p.pesel(gender=Gender.FEMALE))

# Generated at 2022-06-23 20:39:43.759619
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pl = PolandSpecProvider()
    print(pl.pesel())


# Generated at 2022-06-23 20:39:45.232603
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    assert PolandSpecProvider().nip() == '7338159548'


# Generated at 2022-06-23 20:39:49.718604
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    from mimesis.enums import Gender
    poland_provider = PolandSpecProvider(seed=452534)
    regon = poland_provider.regon()
    assert len(regon) == 9


# Generated at 2022-06-23 20:39:51.488012
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    assert len(provider.nip()) == 10


# Generated at 2022-06-23 20:39:56.154554
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Unit test for method regon of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    value = provider.regon()
    success = True

    if 9 != len(value):
        success = False

    if int(value) > 999999999:
        success = False

    if len(value) != len(set(value)):
        success = False

    assert success

# Generated at 2022-06-23 20:40:00.007805
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Unit test for method regon of class PolandSpecProvider."""
    # Create object that provides special data for Poland
    p = PolandSpecProvider()
    # Call method regon of object p
    print("REGON: " + p.regon())

# Generated at 2022-06-23 20:40:03.257678
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Test method regon of class PolandSpecProvider.
    :return: None
    """
    pl = PolandSpecProvider()
    assert(len(pl.regon()) == 9)
    assert(PolandSpecProvider.Meta.name == 'poland_provider')
    assert(pl.get_locale() == 'pl')


# Test method nip of class PolandSpecProvider

# Generated at 2022-06-23 20:40:10.806320
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Function to unit test method pesel of class PolandSpecProvider"""
    from mimesis.enums import Gender
    poland_provider = PolandSpecProvider('en')
    print("Pesel number for date 01-01-2000 check digit 0 gender 0\n")
    for i in range(10):
        print(poland_provider.pesel(birth_date = poland_provider.datetime(2000,2000),gender = Gender.FEMALE))
        print(poland_provider.pesel(birth_date = poland_provider.datetime(2000,2000),gender = Gender.MALE))
    print("Pesel number for date 01-01-1990 check digit 0 gender 0\n")

# Generated at 2022-06-23 20:40:12.103708
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Test for constructor of class PolandSpecProvider."""
    assert PolandSpecProvider().name == 'poland_provider'


# Generated at 2022-06-23 20:40:23.090178
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    from mimesis.providers.person import Person

    person = Person('pl')
    pe = person.pesel()
    assert type(pe) == str
    assert len(pe) == 11
    assert pe[0] in ('0', '1')
    assert pe[2] in ('0', '1', '2', '3')
    assert pe[3] in ('0', '1', '2')
    assert pe[4] in ('0', '1', '2', '3', '4', '5', '6', '7', '8', '9')
    assert pe[5] in ('0', '1', '2', '3', '4', '5', '6', '7', '8', '9')

# Generated at 2022-06-23 20:40:25.522740
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
  provider = PolandSpecProvider()
  assert (provider.pesel()!=provider.pesel())

# Generated at 2022-06-23 20:40:30.634409
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Check uniqueness of method 'regon' of class PolandSpecProvider."""
    polish_provider = PolandSpecProvider()
    N = 100
    M = 1000
    random_regon = []
    random_regon2 = []
    for _ in range(N):
        regon_list = []
        for _ in range(M):
            regon_list.append(polish_provider.regon())
        random_regon.append(regon_list)

    for i in range(N):
        random_regon2 = random_regon[0:i] + random_regon[i + 1:N]
        regon_list = random_regon[i]
        assert len(set(regon_list)) == M

# Generated at 2022-06-23 20:40:39.471263
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider(seed=1234)
    assert provider.nip() == '1271797888'
    assert provider.pesel(gender=Gender.MALE) == '95041760314'
    assert provider.pesel(birth_date=Datetime().datetime(1991, 1991, 4, 17)) == '91041760315'
    assert provider.pesel(gender=Gender.FEMALE) == '82040950992'
    #assert provider.pesel(gender=Gender.MALE) == '86041389739'
    assert provider.regon() == '056622632'
    poland_provider = PolandSpecProvider(seed=1234)
    assert poland_provider.nip() == '1271797888'

# Generated at 2022-06-23 20:40:41.584736
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    polandSpecProvider = PolandSpecProvider()

    assert [polandSpecProvider.nip(), polandSpecProvider.pesel(), polandSpecProvider.regon()]

# Generated at 2022-06-23 20:40:46.160374
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert type(pesel) == str
    assert len(pesel) == 11
    for digit in pesel:
        assert type(digit) == str
        assert digit.isdigit()


# Generated at 2022-06-23 20:40:55.413376
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()
    print(pesel)
    assert len(pesel) == 11, 'This is not 11 digit Pesel'
    assert type(pesel) == str, 'This is not string'
    pesel = PolandSpecProvider().pesel(gender=Gender.FEMALE)
    print(pesel)
    assert type(pesel) == str, 'This is not string'
    assert len(pesel) == 11, 'This is not 11 digit Pesel'
    assert pesel[-1] in str(range(0,9)), "This is not number"



# Generated at 2022-06-23 20:40:59.018708
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    from pytest import raises
    from mimesis.exceptions import NonEnumerableError

    pl = PolandSpecProvider()
    for _ in range(100):
        assert len(pl.nip()) == 10
    with raises(NonEnumerableError):
        pl.nip(mask='***')


# Generated at 2022-06-23 20:41:00.856335
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    gender = Gender.MALE
    date_object = Datetime().datetime(1995, 1998)
    provider = PolandSpecProvider()
    print(provider.pesel(date_object, gender))

# Generated at 2022-06-23 20:41:02.986258
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    assert PolandSpecProvider().pesel(birth_date=Datetime().datetime(1970, 2000), gender=0) == '75041315783'
    assert PolandSpecProvider().pesel(birth_date=Datetime().datetime(1970, 2000), gender=1) == '75041340056'

# Generated at 2022-06-23 20:41:14.830757
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    # Create object
    poland = PolandSpecProvider()
    # Get data from object
    nip = poland.nip()
    pesel = poland.pesel()
    regon = poland.regon()

    # Test if nip is correct
    nip_coefficients = (6, 5, 7, 2, 3, 4, 5, 6, 7)
    nip_digits = [int(d) for d in str(nip)]
    nip_sum_v = sum([nc * nd for nc, nd in zip(nip_coefficients, nip_digits[0:9])])
    nip_checksum_digit = nip_sum_v % 11
    if nip_checksum_digit > 9:
        nip_checksum_digit = 0

    # Test if pesel

# Generated at 2022-06-23 20:41:18.369273
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """
    pesel should generate 11-digit code
    """
    provider = PolandSpecProvider()
    code = provider.pesel()
    assert len(code) == 11


# Generated at 2022-06-23 20:41:20.263480
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Unit Test function."""
    p = PolandSpecProvider()
    assert bool(p.nip())


# Generated at 2022-06-23 20:41:21.561348
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    provider.pesel()

# Generated at 2022-06-23 20:41:25.452859
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()
    assert isinstance(pesel, str), "pesel method of PolandSpecProvider class should return string!"
    assert len(pesel) == 11, "pesel method of PolandSpecProvider class should return 11 digits string!"
    assert pesel.isnumeric(), "pesel method of PolandSpecProvider class should return string consisting only of digits!"

# Generated at 2022-06-23 20:41:28.513362
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Unit test for PolandSpecProvider"""
    provider = PolandSpecProvider()
    assert isinstance(provider, PolandSpecProvider)


# Generated at 2022-06-23 20:41:32.648579
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """ Test that PolandSpecProvider has correct attributes"""
    Poland = PolandSpecProvider()
    assert Poland.__class__.__name__ == "PolandSpecProvider"
    assert Poland._meta.name == "poland_provider"
    assert Poland._meta.locales == ["pl"]

# Unit tests for NIP

# Generated at 2022-06-23 20:41:35.103502
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    seed = 'TestPolandSpecProvider'
    provider = PolandSpecProvider(seed=seed)
    result = provider.nip()
    assert result == '1124455678'


# Generated at 2022-06-23 20:41:36.339098
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    assert PolandSpecProvider().regon() is not None

# Generated at 2022-06-23 20:41:39.191028
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    nip = provider.nip()

    print("NIP: " + nip)
    assert len(nip) == 10



# Generated at 2022-06-23 20:41:44.132823
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unittest for pesel method."""
    a = PolandSpecProvider(seed=30)
    assert a.pesel() == '74030625870'

    import datetime
    d = datetime.date(1990, 4, 11)
    assert a.pesel(birth_date=d, gender=Gender.MALE) == '90040731072'
    assert a.pesel(birth_date=d, gender=Gender.FEMALE) == '90040731070'



# Generated at 2022-06-23 20:41:45.434840
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    n = p.pesel()
    assert n == n

# Generated at 2022-06-23 20:41:47.517848
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    test = PolandSpecProvider()
    print(test.nip())
    print(test.pesel())
    print(test.regon())

# Generated at 2022-06-23 20:41:51.512502
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider()
    x = pesel.pesel(birth_date='1997-04-15', gender=Gender.FEMALE)
    assert x == '97041509084'

# Generated at 2022-06-23 20:41:56.599223
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pl = PolandSpecProvider(seed=42)
    assert pl.pesel() == '90302125553'
    assert pl.pesel(datetime(1990, 3, 21)) == '90302125553'
    assert pl.pesel(datetime(1990, 3, 21), Gender.FEMALE) == '90302143351'


# Generated at 2022-06-23 20:42:00.666312
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Test function for method nip of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    for _ in range(10):
        nip = provider.nip()
        assert len(nip) == 10
        assert all(c.isnumeric() for c in nip)


# Generated at 2022-06-23 20:42:04.374763
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    nip_1 = PolandSpecProvider().nip()
    nip_2 = PolandSpecProvider().nip()
    print(nip_1)
    print(nip_2)

    assert len(nip_1) == 10
    assert len(nip_2) == 10
    assert nip_1 != nip_2


# Generated at 2022-06-23 20:42:06.614679
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Main function."""
    # Initialize the object
    pl_provider = PolandSpecProvider()

    # Generate REGON
    for _ in range(0, 10):
        print('REGON:', pl_provider.regon())



# Generated at 2022-06-23 20:42:08.571044
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    seed = "hello!"
    provider = PolandSpecProvider(seed)

    assert provider.__init__(seed) == "hello!"


# Generated at 2022-06-23 20:42:16.207388
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    pl = PolandSpecProvider()
    lines = []
    with open("pl_regon.txt", 'r') as file:
        lines = file.readlines()
    i = 0
    for line in lines:
        regon = pl.regon()
        if line != regon + '\n':
            print("REGON not matching (pl.regon_test) : " + line + " vs " + regon)
            i += 1
    print("REGON test successful : " + str(len(lines) - i) + " vs " + str(len(lines)))
    assert i == 0


# Generated at 2022-06-23 20:42:22.233633
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    p = PolandSpecProvider()
    pesel_digits = [5, 0, 1, 0, 3, 1, 5, 1, 6, 3, 5]
    assert str(p.pesel(birth_date=Datetime().datetime(1950, 3, 15, 13, 37))) == \
           str(pesel_digits)

# Generated at 2022-06-23 20:42:24.685420
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    for _ in range(100):
        print(PolandSpecProvider().nip())


# Generated at 2022-06-23 20:42:27.068470
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """A unit test for method pesel of class PolandSpecProvider."""
    assert len(PolandSpecProvider().pesel()) == 11


# Generated at 2022-06-23 20:42:36.100191
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():

    pesel = PolandSpecProvider().pesel(birth_date=None,gender=Gender.MALE)
    #print("pesel: " + pesel + "\n")
    assert int(pesel[9]) in (1,3,5,7,9)

    pesel = PolandSpecProvider().pesel(birth_date=None, gender=Gender.FEMALE)
    #print("pesel: " + pesel + "\n")
    assert int(pesel[9]) in (0,2,4,6,8)

    pesel = PolandSpecProvider().pesel(birth_date=None, gender=None)
    #print("pesel: " + pesel + "\n")
    assert int(pesel[9]) in range(10)



# Generated at 2022-06-23 20:42:36.747505
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    assert PolandSpecProvider().regon() == "596364173"

# Generated at 2022-06-23 20:42:37.756089
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    c = PolandSpecProvider()
    assert c.locale == 'pl'

# Generated at 2022-06-23 20:42:41.591198
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # given
    x = PolandSpecProvider()

    # when
    r1 = x.pesel(gender=Gender.MALE)
    print(r1)
    r2 = x.pesel(gender=Gender.FEMALE)
    print(r2)

# Generated at 2022-06-23 20:42:47.202021
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Test for PolandSpecProvider.regon method."""
    A_REGON_VALID_STRING = "367531165"
    a_regon = PolandSpecProvider().regon()
    assert len(a_regon) == 9
    assert a_regon.isdigit()
    # None of the generated REGON numbers should be the same as the
    # REGON number of the author of this library
    assert A_REGON_VALID_STRING != a_regon

# Generated at 2022-06-23 20:42:51.890979
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel_list = []
    for i in range(10000):
        pesel = PolandSpecProvider().pesel()
        if pesel not in pesel_list:
            pesel_list.append(pesel)

    print(len(pesel_list))


# Generated at 2022-06-23 20:42:54.107800
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    op = PolandSpecProvider()
    print(op.nip())
    print(op.pesel())
    print(op.regon())

# Generated at 2022-06-23 20:42:57.669152
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    for i in range(0, 10):
        nip = provider.nip()
        assert len(nip) == 10


# Generated at 2022-06-23 20:43:00.022025
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    # p = PolandSpecProvider()
    # print(p.nip(12))
    return True

# Generated at 2022-06-23 20:43:04.413374
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Test for method regon of class PolandSpecProvider."""
    peselProvider = PolandSpecProvider()
    assert len(peselProvider.regon()) == 9


# Generated at 2022-06-23 20:43:09.206027
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    import re
    p = PolandSpecProvider()
    for _ in range(20):
        regon = p.regon()
        assert len(regon) == 9
        assert re.fullmatch(r'\d{9}', regon) is not None
    print("test_PolandSpecProvider_regon: ok")


# Generated at 2022-06-23 20:43:13.388991
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    n = provider.nip()
    assert len(n) == 10

    n = provider.nip(seed=1)
    assert n == "5278676046"


# Generated at 2022-06-23 20:43:15.966250
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider.pesel()

    assert(type(pesel)==str)
    assert(len(pesel)==11)
    assert(int(pesel)//10>0)


# Generated at 2022-06-23 20:43:20.195699
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    # create an instance of class PolandSpecProvider
    poland_provider = PolandSpecProvider()

    # call method nip and assign it to variable x
    x = poland_provider.nip()

    # check if the returned string starts with digits 101-998
    assert x[0:3].isnumeric()
    assert 101 <= int(x[0:3]) <= 998

    # check if the returned string is 10 digits long
    assert x.isnumeric()
    assert len(x) == 10


# Generated at 2022-06-23 20:43:29.318551
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    import pytest
    from mimesis.enums import Gender

    # Instantiate PolandSpecProvider
    poland_provider = PolandSpecProvider()

    # Birthdate = 0
    pesel_person = poland_provider.pesel(birth_date=0)
    assert len(pesel_person) == 11

    # Define a birthdate in the past
    birth_date = poland_provider.datetime(1940, 2018) # Returns a datetime object
    pesel_person = poland_provider.pesel(birth_date=birth_date)
    assert len(pesel_person) == 11

    # Define a birthdate in the future
    birth_date = poland_provider.datetime(2020, 2021) # Returns a datetime object

# Generated at 2022-06-23 20:43:32.460305
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    polandspecprovider = PolandSpecProvider()
    #print(polandspecprovider.nip())
    #print(polandspecprovider.regon())
    #print(polandspecprovider.pesel())
    assert True

# Generated at 2022-06-23 20:43:34.362561
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    assert provider.nip()
    assert provider.pesel()

# Generated at 2022-06-23 20:43:41.645013
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # test with birth_date before 1999
    p1 = PolandSpecProvider()
    pesel = p1.pesel(birth_date="1993-04-09", gender=Gender.MALE)
    assert pesel[:6] == "930409"
    assert pesel[-1] != "0"

    # test with birth_date after 1999
    p2 = PolandSpecProvider()
    pesel = p2.pesel(birth_date="2000-04-09", gender=Gender.MALE)
    assert pesel[:6] == "000409"
    assert pesel[-1] != "0"

    # test with random birth_date and gender
    p3 = PolandSpecProvider()
    pesel = p3.pesel(birth_date="2000-04-09", gender=Gender.MALE)
    assert pes

# Generated at 2022-06-23 20:43:49.703830
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert isinstance(pesel, str)
    assert len(pesel) == 11

# Generated at 2022-06-23 20:43:55.826325
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():

    pesel = PolandSpecProvider().pesel()
    assert len(pesel) == 11

    pesel = PolandSpecProvider().pesel(gender=Gender.MALE)
    assert len(pesel) == 11
    assert int(pesel[9]) % 2 != 0

    pesel = PolandSpecProvider().pesel(gender=Gender.FEMALE)
    assert len(pesel) == 11
    assert int(pesel[9]) % 2 == 0

# Generated at 2022-06-23 20:44:04.979058
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    from mimesis.enums import Gender
    from mimesis.providers.datetime import Datetime
    
    pl_provider = PolandSpecProvider()
    dt = Datetime()
    today = dt.datetime()
    # today.year
    # today.month
    # today.day
    # today.hour
    # today.minute
    # today.second
    # today.weekday()
    
    
    #pl_provider.birth_date(minimum=1930, maximum=today)
    #pl_provider.birth_date(minimum=1930, maximum=today)
    #pl_provider.birth_date(minimum=1930, maximum=today)
    #pl_provider.birth_date(minimum=1930, maximum=today)
    #pl_provider.birth_date

# Generated at 2022-06-23 20:44:09.540819
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    test_nip = PolandSpecProvider()
    test_nip2 = PolandSpecProvider().nip()
    test_pesel = PolandSpecProvider().pesel()
    test_regon = PolandSpecProvider().regon()

    assert isinstance(test_nip, PolandSpecProvider)
    assert(len(test_nip2) == 10)
    assert(len(test_pesel) == 11)
    assert(len(test_regon) == 9)

# Generated at 2022-06-23 20:44:11.422459
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Test of nip method."""
    a = str(PolandSpecProvider().nip())
    assert len(a) == 10


# Generated at 2022-06-23 20:44:18.321503
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Unit test for method regon of class PolandSpecProvider."""
    for i in range(0, 100):
        regon = PolandSpecProvider().regon()
        assert regon

        regon_coeffs = (8, 9, 2, 3, 4, 5, 6, 7)
        regon_digits = [int(d) for d in regon]
        sum_v = sum([nc * nd for nc, nd in
                     zip(regon_coeffs, regon_digits)])
        checksum_digit = sum_v % 11
        if checksum_digit > 9:
            checksum_digit = 0
        if checksum_digit != regon_digits[-1]:
            assert False
    return True


# Generated at 2022-06-23 20:44:23.455857
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    ps = PolandSpecProvider()
    d = ps.__dict__
    exp={'_locale': 'pl', '_seed': None}
    for i in exp.keys():
        assert d[i] == exp[i]
        
# Test for NIP method

# Generated at 2022-06-23 20:44:24.684386
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    PolandSpecProvider().nip() == '6302642800'

# Generated at 2022-06-23 20:44:27.312613
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    nip_set = set()
    for i in range(1000):
        nip_set.add(PolandSpecProvider().nip())
    assert len(nip_set) == 1000


# Generated at 2022-06-23 20:44:30.546850
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    pt = PolandSpecProvider()
    # Positive test
    for _ in range(100):
        assert len(pt.nip()) == 10


# Generated at 2022-06-23 20:44:34.681593
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Test the function that generates 10 digit NIP number"""
    polish_provider = PolandSpecProvider()
    nip = polish_provider.nip()
    assert len(nip) == 10


# Generated at 2022-06-23 20:44:35.499408
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    p = PolandSpecProvider()
    assert len(p.regon()) == 9

# Generated at 2022-06-23 20:44:37.880960
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    assert provider.__class__.__name__ == 'PolandSpecProvider'


# Generated at 2022-06-23 20:44:46.652768
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    from mimesis import PolandSpecProvider
    from mimesis.enums import Gender
    person = PolandSpecProvider()
    person_5 = PolandSpecProvider()
    assert person.pesel(gender=Gender.MALE)[9] in ('1','3','5','7','9')
    assert person.pesel(gender=Gender.FEMALE)[9] in ('0','2','4','6','8')
    assert len(person_5.pesel()) == 11

# Generated at 2022-06-23 20:44:51.792978
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """
    Function that tests method nip of class PolandSpecProvider.
    """
    provider = PolandSpecProvider()
    # test method nip
    result = provider.nip()
    assert isinstance(result, str)
    assert len(result) == 10
    array = result.split("")
    assert array[-1] != array[-2]



# Generated at 2022-06-23 20:44:53.869840
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()
    assert len(pesel) == 11 and Pesel.validate(pesel)


# Generated at 2022-06-23 20:44:55.904569
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Test for method regon(self)"""
    regon = PolandSpecProvider().regon()
    assert isinstance(regon, str) and len(regon) == 9


# Generated at 2022-06-23 20:44:56.774809
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    assert provider.nip() == "6542539646"


# Generated at 2022-06-23 20:44:58.628901
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    for i in range(10):
        print(PolandSpecProvider().regon())
if __name__ == '__main__':
    test_PolandSpecProvider_regon()

# Generated at 2022-06-23 20:45:00.375224
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
   assert len(PolandSpecProvider().pesel()) == 11

# Generated at 2022-06-23 20:45:02.087526
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider()
    regon = provider.regon()
    assert len(regon) == 9


# Generated at 2022-06-23 20:45:04.517380
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    assert provider.__class__.__name__ == "PolandSpecProvider"


# Generated at 2022-06-23 20:45:06.396080
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    male_pesel = PolandSpecProvider().pesel(birth_date=None, gender=Gender.MALE)
    assert len(male_pesel)==11

    female_pesel = PolandSpecProvider().pesel(birth_date=None, gender=Gender.FEMALE)
    assert len(female_pesel)==11


# Generated at 2022-06-23 20:45:13.009363
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    pl = PolandSpecProvider()
    assert len(pl.nip()) == 10
    assert len(pl.pesel()) == 11
    assert len(pl.regon()) == 9
    assert pl.age(18, 25) >= 18 and pl.age(18, 25) <= 25
    assert pl.age(45, 110) >= 45 and pl.age(45, 110) <= 110

# Generated at 2022-06-23 20:45:16.230447
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    assert provider
    assert provider.nip()
    assert provider.pesel()
    assert provider.regon()

# Generated at 2022-06-23 20:45:19.005056
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    p = PolandSpecProvider()
    result = p.regon()
    assert int(result) >= 100000000
    assert int(result) <= 999999999

# Generated at 2022-06-23 20:45:28.452610
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    for _ in range(10):
        nip = provider.nip()
        nip_digits = [int(d) for d in nip]
        nip_coefficients = (6, 5, 7, 2, 3, 4, 5, 6, 7)
        sum_v = sum([nc * nd for nc, nd in zip(nip_coefficients, nip_digits)])
        checksum_digit = sum_v % 11
        if checksum_digit > 9:
            print(f'NIP {nip} is not valid!')
        else:
            print(f'NIP {nip} is valid!')



# Generated at 2022-06-23 20:45:31.270361
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """
    Generate random nip.
    :return: nip number
    """
    nip = PolandSpecProvider().nip()
    print(nip)
    assert len(nip) == 10



# Generated at 2022-06-23 20:45:32.250960
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    assert len(PolandSpecProvider().regon()) == 9

# Generated at 2022-06-23 20:45:35.213541
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    PESEL = PolandSpecProvider().pesel()
    assert PESEL is not None
    print(PESEL)


# Generated at 2022-06-23 20:45:39.449034
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Test class PolandSpecProvider."""
    poland=PolandSpecProvider()
    assert poland.nip() == '1922357588', 'Should be valid!'
    assert poland.pesel() == '98081001861', 'Should be valid!'
    assert poland.regon() == '073581803', 'Should be valid!'

# Generated at 2022-06-23 20:45:42.898228
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    pl = PolandSpecProvider(seed=1337)
    assert(pl.nip()) == '4235948123'


# Generated at 2022-06-23 20:45:44.935848
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    poland = PolandSpecProvider()
    regon_test = poland.regon()

    assert len(regon_test) == 9


# Generated at 2022-06-23 20:45:47.528813
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    p = PolandSpecProvider()
    nip_value = p.nip()
    assert nip_value
    assert len(nip_value) == 10
    print(nip_value)


# Generated at 2022-06-23 20:45:49.296696
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    pesel = p.pesel()
    assert len(pesel) == 11

# Generated at 2022-06-23 20:45:54.616836
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Method to test function pesel (from class PolandSpecProvider)."""
    p1 = PolandSpecProvider()
    p2 = PolandSpecProvider()
    assert p1.pesel(birth_date=p2.datetime(1940, 2018)) !=\
        p1.pesel(birth_date=p2.datetime(1940, 2018))


# Generated at 2022-06-23 20:45:55.828315
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    pass

# Generated at 2022-06-23 20:46:00.527439
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    # Create instance of PolandSpecProvider
    plsp = PolandSpecProvider()

    # Testing nip method
    print(plsp.nip())

    # Testing pesel method
    print(plsp.pesel())

    # Testing regon method
    print(plsp.regon())

if __name__ == "__main__":
     test_PolandSpecProvider()

# Generated at 2022-06-23 20:46:01.758697
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    assert (PolandSpecProvider().regon() != None)

# Generated at 2022-06-23 20:46:02.840805
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    assert callable(PolandSpecProvider)

# Generated at 2022-06-23 20:46:04.518363
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    assert provider
    assert provider.nip()
    assert provider.pesel()
    assert provider.regon()

# Generated at 2022-06-23 20:46:12.048413
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    time_now = datetime.now()
    provider = PolandSpecProvider()
    pesel = provider.pesel(time_now, Gender.FEMALE)
    assert pesel[:6] == '{:02}{:02}{:04}'.format(time_now.year % 100, time_now.month, time_now.day)
    assert pesel[10] == '2' or pesel[10] == '4' or pesel[10] == '6' or pesel[10] == '8'

# Generated at 2022-06-23 20:46:15.395741
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    tmp = PolandSpecProvider()
    result = tmp.regon()
    assert result.isdigit() and len(result) == 9

# Generated at 2022-06-23 20:46:19.953929
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    nip1 = PolandSpecProvider(seed=123123123123).nip()
    nip2 = PolandSpecProvider(seed=123123123123).nip()
    assert nip1 == nip2
    assert len(nip1) == 10
    assert 0 < int(nip1) <= 9999999999


# Generated at 2022-06-23 20:46:22.175058
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    assert isinstance(provider.nip(), str)
    assert len(provider.nip()) == 10


# Generated at 2022-06-23 20:46:32.965136
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    assert len(provider.pesel()) == 11
    assert provider.pesel() == '77020349210'
    assert len(provider.pesel("1990-11-28 13:14:15")) == 11
    assert provider.pesel("1990-11-28 13:14:15") == '90012885210'
    assert len(provider.pesel("1990-11-28 13:14:15", Gender.MALE)) == 11
    assert provider.pesel("1990-11-28 13:14:15", Gender.MALE) == '90012889210'
    assert len(provider.pesel("1990-11-28 13:14:15", Gender.FEMALE)) == 11

# Generated at 2022-06-23 20:46:35.741171
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    nip = provider.nip()
    assert len(nip) == 10
    assert nip.isnumeric()


# Generated at 2022-06-23 20:46:36.961811
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    _ = PolandSpecProvider()


# Generated at 2022-06-23 20:46:39.622029
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    assert hasattr(provider, '_meta')
    assert hasattr(provider, 'locale')


# Generated at 2022-06-23 20:46:42.216533
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    obj1 = PolandSpecProvider()
    tmp = obj1.pesel()
    obj2 = PolandSpecProvider(seed=tmp)
    assert tmp == obj2.pesel()

# Generated at 2022-06-23 20:46:44.198754
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider(seed=100)
    assert provider.nip() == '9341738336'



# Generated at 2022-06-23 20:46:46.252148
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    obj = PolandSpecProvider()
    print(obj.nip())
    print(obj.nip())
    print(obj.nip())


# Generated at 2022-06-23 20:46:49.696763
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Function for testing method regon of class PolandSpecProvider."""
    PESEL_REGEX = re.compile(r"^\d{9}$")
    pesel = PolandSpecProvider().regon()
    print(pesel)
    match = re.search(PESEL_REGEX, pesel)
    assert match != None

# Generated at 2022-06-23 20:46:51.391491
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    regon = PolandSpecProvider().regon()
    print(regon)


# Generated at 2022-06-23 20:46:53.936275
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider(seed=0)
    result = provider.nip()
    assert result == '8184959897'


# Generated at 2022-06-23 20:47:02.694699
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
   """Test constructor of class PolandSpecProvider."""
    # When run this class for first time, it will generate seed

# Generated at 2022-06-23 20:47:06.009400
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    gen = PolandSpecProvider()
    x = gen.nip()
    assert x == "5442401131"
