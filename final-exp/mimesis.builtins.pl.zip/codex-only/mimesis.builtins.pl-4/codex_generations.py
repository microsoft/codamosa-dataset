

# Generated at 2022-06-23 20:37:11.876602
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    poland_sp = PolandSpecProvider()
    assert poland_sp.nip()
    poland_sp.pesel(birth_date=None, gender=Gender.FEMALE)
    assert poland_sp.pesel(birth_date=None, gender=Gender.FEMALE)
    assert poland_sp.regon()

# Generated at 2022-06-23 20:37:13.880799
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Test method constructor of class PolandSpecProvider."""
    PolandSpecProvider()



# Generated at 2022-06-23 20:37:17.061177
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    print("*" * 100)
    regon = PolandSpecProvider().regon()
    print("*** regon: " + regon)



# Generated at 2022-06-23 20:37:19.417981
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pl = PolandSpecProvider()
    gd = Gender.MALE
    ret = pl.pesel(gender=gd)
    # print(ret)
    assert len(str(ret)) == 11

# Generated at 2022-06-23 20:37:23.022073
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    ppl = PolandSpecProvider()
    result_1 = ppl.nip()
    assert result_1.__sizeof__() == 10


# Generated at 2022-06-23 20:37:25.618766
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    assert p.pesel(birth_date=PolandSpecProvider.datetime(2014, 10, 10), gender=Gender.MALE) == '14101041450'

# Generated at 2022-06-23 20:37:32.330292
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    from mimesis.enums import Gender
    from mimesis.providers import PolandSpecProvider
    from mimesis.providers.person import Person
    
    p = PolandSpecProvider()
    person = Person()

    psec = p.pesel(Gender.FEMALE)
    assert len(psec) == 11

    pesel = psec

    # https://pl.wikipedia.org/wiki/PESEL_(system_identyfikacji_os%C3%B3b)
    # 1) miesiąc urodzenia, wynik modulo 20
    # 2) dzień urodzenia, wynik modulo 10
    # 3) ostatnia cyfra kolejności numeru PESEL w danym miesiącu urodzenia

# Generated at 2022-06-23 20:37:39.668041
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    male_pesel = provider.pesel(gender=Gender.MALE)
    last_digit = int(male_pesel[-1])
    assert last_digit % 2 != 0, 'Last digit of pesel should be odd'
    female_pesel = provider.pesel(gender=Gender.FEMALE)
    last_digit = int(female_pesel[-1])
    assert last_digit % 2 == 0, 'Last digit of pesel should be even'


# Generated at 2022-06-23 20:37:43.349099
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    print("\n" + __file__)

    poland = PolandSpecProvider()

    regon = poland.regon()
    print("regon:", regon)
    assert len(regon) == 9

    regon = poland.regon(seed=123)
    print("regon:", regon)
    assert regon == "10301149"

    return



# Generated at 2022-06-23 20:37:48.822214
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    s = PolandSpecProvider()
    assert (s.regon() == '184719482' or s.regon() == '751463122' or s.regon() == '772297496'
            or s.regon() == '420055104' or s.regon() == '977668830' or s.regon() == '159087303')

# Generated at 2022-06-23 20:37:53.531254
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """ Test regon."""
    result = PolandSpecProvider().regon()
    assert len(result) == 9
    second_digit = int(result[1])
    assert second_digit in range(11)


# Generated at 2022-06-23 20:38:01.752505
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    from mimesis.providers import PolandSpecProvider
    from mimesis.enums import Gender

    # test case for gender
    def gender_test():
        provider = PolandSpecProvider()

        # test case for method pesel of class PolandSpecProvider (female)
        def female_test():
            for i in range(0, 100):
                result = provider.pesel(gender=Gender.FEMALE)
                assert int(result[-1]) % 2 == 0

        # test case for method pesel of class PolandSpecProvider (male)
        def male_test():
            for i in range(0, 100):
                result = provider.pesel(gender=Gender.MALE)
                assert int(result[-1]) % 2 == 1

        female_test()
        male_test()

    # test case for non gender

# Generated at 2022-06-23 20:38:04.223178
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel(birth_date=Datetime().datetime(1996,1999), gender=Gender.MALE)
    assert int(pesel[2:4]) < 20

# Generated at 2022-06-23 20:38:08.794231
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    _gexec = PolandSpecProvider().pesel(birth_date='7/23/1998',gender=Gender.MALE)
    assert _gexec == '98072308925'

# Generated at 2022-06-23 20:38:10.641428
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    person_data = PolandSpecProvider().pesel()
    assert person_data is not None
    assert person_data != 0



# Generated at 2022-06-23 20:38:11.828869
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    assert PolandSpecProvider().nip() == '7010238001'


# Generated at 2022-06-23 20:38:16.131928
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Unit test for constructor of class PolandSpecProvider"""
    provider = PolandSpecProvider()
    result = provider.nip()
    print(f"NIP: {result}")
    result = provider.pesel()
    print(f"PESEL: {result}")
    result = provider.regon()
    print(f"REGON: {result}")

if __name__ == "__main__":
    test_PolandSpecProvider()

# Generated at 2022-06-23 20:38:17.762425
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    print("test_PolandSpecProvider_nip")
    obj = PolandSpecProvider()
    for _ in range(10):
        print(obj.nip())


# Generated at 2022-06-23 20:38:21.882335
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    # Scenario 1: default NIP
    provider = PolandSpecProvider()
    assert provider.nip() == '8082751778'
    # Scenario 2: default NIP
    provider = PolandSpecProvider()
    assert provider.nip() == '4961244033'


# Generated at 2022-06-23 20:38:24.155152
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    assert PolandSpecProvider().regon() == '71366290'


# Generated at 2022-06-23 20:38:27.155269
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Test for PolandSpecProvider method regon."""
    provider = PolandSpecProvider()
    assert len(provider.regon()) == 9
    assert isinstance(provider.regon(), str)


# Generated at 2022-06-23 20:38:30.118942
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider() 
    regon = provider.regon()
    assert len(regon) == 9, "Length of regon should be 9"
    assert regon.isdigit(), "regon should be digit"

# Generated at 2022-06-23 20:38:31.414291
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider(seed='123')
    assert provider.regon() == '099097183'


# Generated at 2022-06-23 20:38:33.974824
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
	print("Unit test for method pesel of class PolandSpecProvider")
	obj=PolandSpecProvider(seed = "Jan Kowalski")
	print("Pesel: ",obj.pesel())

# test_PolandSpecProvider_pesel()

# Generated at 2022-06-23 20:38:45.133182
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    import datetime
    provider = PolandSpecProvider(base_path='./')
    date_time = datetime.datetime(2019, 4, 4)

    result = provider.pesel(birth_date=date_time, gender=Gender.MALE)
    assert result == '19041500002'

    result = provider.pesel(birth_date=date_time, gender=Gender.FEMALE)
    assert result == '19041500004'

    result = provider.pesel(birth_date=date_time, gender=None)
    assert result == '19041500002' or result == '19041500004'

    result = provider.pesel(birth_date=None, gender=Gender.MALE)
    assert len(result) == 11


# Generated at 2022-06-23 20:38:48.865616
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    p = PolandSpecProvider()
    regon_result = p.regon()
    assert len(regon_result) == 9
    assert all(x in "0123456789" for x in regon_result)


# Generated at 2022-06-23 20:38:52.335146
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    p = PolandSpecProvider()
    regon = p.regon()
    assert(regon != None)
    assert(isinstance(regon, str))
    assert(len(regon) == 9)
    assert(regon.isdigit())



# Generated at 2022-06-23 20:38:53.895764
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    pesel = PolandSpecProvider().nip()
    assert len(pesel) == 10


# Generated at 2022-06-23 20:38:55.858677
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    a = PolandSpecProvider()
    assert a.random is not None
    assert a.seed is not None
    assert a.random.seed == a.seed


# Generated at 2022-06-23 20:38:56.838541
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    obj = PolandSpecProvider()
    assert obj is not None

# Generated at 2022-06-23 20:39:00.682384
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Unit test for constructor of class PolandSpecProvider."""

    local_language = PolandSpecProvider(seed=12345)
    assert local_language.__repr__(), "PolandSpecProvider('pl')"

# Generated at 2022-06-23 20:39:03.043245
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    from mimesis.builtins import PolandSpecProvider
    new = PolandSpecProvider()
    assert new.nip() != None


# Generated at 2022-06-23 20:39:05.670200
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    plp = PolandSpecProvider()
    assert plp.pesel(birth_date=plp.datetime(year=2018, month=5, day=5)) == '18051628005'

# Generated at 2022-06-23 20:39:08.526607
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    p = PolandSpecProvider(None)
    assert p.regon() == "773020583"


# Generated at 2022-06-23 20:39:12.302417
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    print("*************** Pesel testing *****************")
    for i in range(0,10):
        pesel =  PolandSpecProvider().pesel(birth_date=Datetime().datetime(1998,2020),gender=Gender.MALE)
        print(pesel)

# Generated at 2022-06-23 20:39:14.399997
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    result = provider.nip()
    print(result)


# Generated at 2022-06-23 20:39:17.928877
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    result = provider.nip()
    print("NIP number: " + result)
    assert len(result) == 10

    # Check if NIP is valid
    assert provider.validate_nip(result)


# Generated at 2022-06-23 20:39:19.988420
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    pl = PolandSpecProvider(seed=123)
    nip = pl.nip()
    assert(nip == "7941331496")

# Generated at 2022-06-23 20:39:23.757095
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    from pprint import pprint
    seed = 'jnU2F6UjnPjKbYHcTydTd2W8eXDnIl'
    x = PolandSpecProvider(seed=seed)
    pprint(x.nip())
    assert x.nip() == '1926146022'


# Generated at 2022-06-23 20:39:25.420705
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    assert provider.nip()
    assert provider.pesel()
    assert provider.regon()

# Generated at 2022-06-23 20:39:29.005664
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel(gender=Gender.MALE)
    assert len(pesel) == 11
    assert int(pesel[9]) in (1, 3, 5, 7, 9)

# Generated at 2022-06-23 20:39:32.698868
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    from mimesis.typing import Seed

    poland_provider = PolandSpecProvider(seed=Seed(1))
    print(poland_provider)
    expected_nip = '8900025256'
    nip = poland_provider.nip()
    assert nip == expected_nip, "Provided NIP is not valid"
test_PolandSpecProvider_nip()



# Generated at 2022-06-23 20:39:35.445951
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():

    provider = PolandSpecProvider()
    regon = provider.regon()
    assert len(regon) == 9



# Generated at 2022-06-23 20:39:36.453873
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    PolandSpecProvider()

# Generated at 2022-06-23 20:39:42.764300
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # test for gender
    p = PolandSpecProvider()
    for _ in range(50):
        pesel = p.pesel(gender=Gender.MALE)
        assert pesel[9] in {'1', '3', '5', '7', '9'}
        assert pesel[9] not in {'0', '2', '4', '6', '8'}
        pesel = p.pesel(gender=Gender.FEMALE)
        assert pesel[9] not in {'1', '3', '5', '7', '9'}
        assert pesel[9] in {'0', '2', '4', '6', '8'}
    # test for year
    p = PolandSpecProvider()

# Generated at 2022-06-23 20:39:48.149049
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    _plsp = PolandSpecProvider()
    pesel_value = _plsp.pesel()
    assert len(pesel_value) == 11
    assert (pesel_value[-2] == '0' or
            pesel_value[-2] == '2' or
            pesel_value[-2] == '4' or
            pesel_value[-2] == '6' or
            pesel_value[-2] == '8')

# Generated at 2022-06-23 20:39:49.494547
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    assert len(p.pesel()) == 11

# Generated at 2022-06-23 20:39:53.546554
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    seed = 'Tyrion Lannister'
    psp = PolandSpecProvider(seed)
    assert psp.pesel(birth_date=Datetime().datetime(1940, 2018),
                     gender=Gender.MALE) == '79110700001'

# Generated at 2022-06-23 20:40:00.937782
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    obj = PolandSpecProvider(seed=12345)
    print(obj.pesel(birth_date=obj.datetime(1940, 2018), gender=Gender.MALE))
    print(obj.pesel(birth_date=obj.datetime(), gender=Gender.MALE))
    print(obj.pesel(birth_date=obj.datetime(1940, 2018), gender=Gender.FEMALE))

    obj = PolandSpecProvider(seed=12345)
    number = obj.pesel(birth_date=obj.datetime(1940, 2018), gender=Gender.FEMALE)
    number2 = obj.pesel(birth_date=obj.datetime(1940, 2018), gender=Gender.FEMALE)
    assert number == number2

# Generated at 2022-06-23 20:40:11.100345
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    p = PolandSpecProvider()

# Generated at 2022-06-23 20:40:12.985322
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    sut = PolandSpecProvider()
    for i in range(100):
        assert len(sut.nip()) == 10


# Generated at 2022-06-23 20:40:15.764719
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider(seed=12345)
    expected = "54178697"
    actual = provider.regon()
    assert expected == actual

# Generated at 2022-06-23 20:40:26.651866
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # Unit test:
    #   method: pesel
    #   class: PolandSpecProvider
    pe = PolandSpecProvider()
    pesel = pe.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.MALE)  # noqa: E501
    assert len(pesel) == 11
    assert 0 <= int(pesel[0]) <= 2
    assert 0 <= int(pesel[1]) <= 9
    assert 0 <= int(pesel[2]) <= 9
    assert 0 <= int(pesel[3]) <= 1
    assert 1 <= int(pesel[4]) <= 2
    assert 0 <= int(pesel[5]) <= 9
    assert 0 <= int(pesel[6]) <= 9
    assert 0 <= int(pesel[7]) <= 9

# Generated at 2022-06-23 20:40:28.926991
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider(seed=None)
    assert provider.pesel() == '79051411118'

# Generated at 2022-06-23 20:40:30.243920
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    instance = PolandSpecProvider()
    assert instance.nip()


# Generated at 2022-06-23 20:40:39.156603
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """"Test method regon of class PolandSpecProvider.
    (Test case: 9-digit REGON)"
    """
    pl = PolandSpecProvider(seed=42)
    regon = pl.regon()
    assert regon == "190612758"
    pl = PolandSpecProvider(seed=43)
    regon = pl.regon()
    assert regon == "243065301"
    pl = PolandSpecProvider(seed=44)
    regon = pl.regon()
    assert regon == "293090235"
    pl = PolandSpecProvider(seed=45)
    regon = pl.regon()
    assert regon == "243746409"
    pl = PolandSpecProvider(seed=46)
    regon = pl.regon()
    assert regon == "190438858"
    pl = PolandSpec

# Generated at 2022-06-23 20:40:42.041402
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    poland_provider = PolandSpecProvider()
    regon = poland_provider.regon()
    print(regon)
    assert regon is not None
    assert len(regon) == 9


# Generated at 2022-06-23 20:40:43.224860
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    assert PolandSpecProvider(seed=123456).__class__.__name__ == 'PolandSpecProvider', 'Should be PolandSpecProvider'


# Generated at 2022-06-23 20:40:46.260808
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    poland = PolandSpecProvider()
    assert callable(poland.nip) is True
    assert callable(poland.pesel) is True
    assert callable(poland.regon) is True

# Generated at 2022-06-23 20:40:48.472238
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    seed = '1'

    obj = PolandSpecProvider(seed)
    assert obj.seed == seed


# Generated at 2022-06-23 20:40:49.968374
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel1 = PolandSpecProvider().pesel()
    pesel2 = PolandSpecProvider().pesel()
    assert pesel1 != pesel2


# Generated at 2022-06-23 20:40:55.634593
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():

    PolandSpecProvider(seed=1).pesel(birth_date=None) == "84040353350"
    PolandSpecProvider(seed=1).pesel(birth_date=None, gender=Gender.MALE) == "84040353350"
    PolandSpecProvider(seed=1).pesel(birth_date=None, gender=Gender.FEMALE) == "25100444473"


# Generated at 2022-06-23 20:40:57.577126
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Check if method pesel return 9-digit PESEL."""
    assert len(PolandSpecProvider().pesel()) == 11


# Generated at 2022-06-23 20:41:04.642889
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    NIP = PolandSpecProvider().nip()
    print(NIP)
    nip_digits = [int(d) for d in str(NIP)]
    if (len(nip_digits) != 10):
        print("\nKod NIP nie ma 10 cyfr")
    else:
        print("\nKod NIP ma 10 cyfr")
    nip_coefficients = (6, 5, 7, 2, 3, 4, 5, 6, 7)
    sum_v = sum([nc * nd for nc, nd in zip(nip_coefficients, nip_digits)])
    checksum_digit = sum_v % 11
    if (checksum_digit == nip_digits[9]):
        print("\nKod NIP jest poprawny")
   

# Generated at 2022-06-23 20:41:15.394204
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    pl_provider = PolandSpecProvider()

    # NIP without conrtrol digit
    nip_without_control_digit = ''.join(str(pl_provider.random.randint(1, 9)) for _ in range(9))
    # Define control digit
    nip_digits = [int(d) for d in nip_without_control_digit]
    nip_coefficients = (6, 5, 7, 2, 3, 4, 5, 6, 7)
    sum_v = sum([nc * nd for nc, nd in zip(nip_coefficients, nip_digits)])
    control_digit = sum_v % 11

    if control_digit > 9:
        control_digit = int(pl_provider.nip()[-1])

    nip_with_control

# Generated at 2022-06-23 20:41:17.212953
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    assert provider.country == 'pl'


# Generated at 2022-06-23 20:41:20.070068
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider(seed=12345)
    nip = provider.nip()
    assert nip == "5021209240"


# Generated at 2022-06-23 20:41:20.723319
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    PolandSpecProvider()

# Generated at 2022-06-23 20:41:25.311691
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    assert PolandSpecProvider().pesel() == '78100111613'
    assert PolandSpecProvider().pesel(birth_date='2 28 2000') == '02020281423'
    assert PolandSpecProvider().pesel(gender=Gender.MALE) == '92031724343'
    assert PolandSpecProvider().pesel(gender=Gender.FEMALE) == '78100111613'


# Generated at 2022-06-23 20:41:29.824349
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test pesel method of class PolandSpecProvider."""
    poland_spec_provider = PolandSpecProvider()
    pesel = poland_spec_provider.pesel()
    assert len(pesel) == 11


# Generated at 2022-06-23 20:41:31.362683
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    pl = PolandSpecProvider()
    print(pl.nip())
    print(pl.pesel())
    print(pl.regon())

test_PolandSpecProvider()

# Generated at 2022-06-23 20:41:38.435864
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """tests for method regon of class PolandSpecProvider."""
    from mimesis.enums import Gender
    from mimesis.providers.date_time import DateTime
    from mimesis.providers.person import Person
    from mimesis.providers.poland import PolandSpecProvider
    from mimesis.typing import DateTimeFormat
    p = PolandSpecProvider()
    assert len(p.regon()) == 9
    assert p.regon() != p.regon()
    assert p.pesel(gender=Gender.MALE) != p.pesel(gender=Gender.FEMALE)
    assert p.pesel(DateTime().datetime()) != p.pesel()
    assert len(p.pesel()) == 11
    assert p.nip() != p.nip()
    assert len(p.nip())

# Generated at 2022-06-23 20:41:45.618030
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    Provider = PolandSpecProvider()
    nip = Provider.nip()
    array = [int(d) for d in nip]
    print("nip: ", nip)
    nip_coefficients = (6, 5, 7, 2, 3, 4, 5, 6, 7)
    sum_v = sum([nc * nd for nc, nd in zip(nip_coefficients, array)])
    checksum_digit = sum_v % 11
    array2 = list(nip_coefficients)
    array2.append(checksum_digit)
    print("NIP numer wygenerowany przez generator: ", array)
    print("Kontrolna suma modulo 11: ", checksum_digit)

# Generated at 2022-06-23 20:41:47.258568
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    polandSpecProvider_regon_test = PolandSpecProvider(seed=50)
    print(polandSpecProvider_regon_test.regon())


# Generated at 2022-06-23 20:41:50.694624
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    assert(len(provider.nip()) == 10)
    assert(provider.nip()[:3] == '101')
    assert(provider.nip()[:3] == '998')


# Generated at 2022-06-23 20:41:53.864775
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    nip_provider = PolandSpecProvider()
    nip_0 = nip_provider.nip()
    assert len(nip_0) == 10
    nip_1 = nip_provider.nip()
    assert nip_0 != nip_1


# Generated at 2022-06-23 20:41:55.457793
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
  poland = PolandSpecProvider()
  print(poland.regon())

# Generated at 2022-06-23 20:41:57.788106
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider()
    regon = provider.regon()

    print(regon)
    print(type(regon))


# Generated at 2022-06-23 20:42:00.916847
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel
    result = '00000000000'
    for i in range(100):
        assert(len(pesel()) == 11)
        result == pesel()
        print(result)
    return 0


# Generated at 2022-06-23 20:42:05.599609
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    # First test - nip
    nip1 = PolandSpecProvider().nip()
    print(nip1)
    print(len(nip1))
    print(type(nip1))
    # Second test - nip
    nip2 = PolandSpecProvider().nip()
    print(nip2)
    print(len(nip2))
    print(type(nip2))
    # Third test - nip
    nip3 = PolandSpecProvider().nip()
    print(nip3)
    print(len(nip3))
    print(type(nip3))


# Generated at 2022-06-23 20:42:09.917601
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    obj = PolandSpecProvider()
    assert len(obj.pesel()) == 11
    assert obj.pesel(gender=Gender.MALE)[-1] in (1, 3, 5, 7, 9)
    assert obj.pesel(gender=Gender.FEMALE)[-1] in (0, 2, 4, 6, 8)

# Generated at 2022-06-23 20:42:14.384819
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    p = PolandSpecProvider(seed=12345)
    for _ in range(10):
        rand_nip = p.nip()
        print("NIP - ", rand_nip)
        assert len(rand_nip) == 10
        assert rand_nip.startswith("10")
        assert not rand_nip.endswith("00")


# Generated at 2022-06-23 20:42:21.703603
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    pl = PolandSpecProvider()
    test_nip = pl.nip()
    assert len(test_nip) == 10
    assert pl.NIP().full() == test_nip
    test_pesel = pl.pesel()
    assert len(test_pesel) == 11
    assert pl.PESEL().full() == test_pesel
    test_regon = pl.regon()
    assert len(test_regon) == 9
    assert pl.REGON().full() == test_regon

# Generated at 2022-06-23 20:42:23.275448
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel."""
    poland_provider = PolandSpecProvider()
    assert poland_provider.pesel()

# Generated at 2022-06-23 20:42:28.357941
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider(seed=42)
    assert provider.nip() == '9482427042'
    assert provider.nip() == '6729073723'
    assert provider.nip() == '3214994722'


# Generated at 2022-06-23 20:42:32.288335
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    pl_provider = PolandSpecProvider()
    nip = pl_provider.nip()
    assert len(nip) == 10
    assert nip not in nip_list
    nip_list.append(nip)


nip_list = []


# Generated at 2022-06-23 20:42:40.951246
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # Test with date object
    date_object = Datetime().datetime(1990, 2018)
    gender = Gender.MALE
    pesel = PolandSpecProvider().pesel(birth_date=date_object, gender=gender)
    # Test with gender
    gender = Gender.MALE
    pesel = PolandSpecProvider().pesel(gender=gender)
    # Test with gender and date object
    gender = Gender.MALE
    pesel = PolandSpecProvider().pesel(gender=gender, birth_date=date_object)
    # Test without parameters
    pesel = PolandSpecProvider().pesel()


# Generated at 2022-06-23 20:42:45.188408
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    psp = PolandSpecProvider()
    nip = psp.nip()
    assert nip is not None
    assert isinstance(nip, str)
    assert nip.startswith('1')
    assert nip.endswith('7')
    assert len(nip) == 10


# Generated at 2022-06-23 20:42:52.095272
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    prvdr = PolandSpecProvider(seed=1)
    assert prvdr.nip() == '7114908313'
    assert prvdr.nip() == '7093639072'
    assert prvdr.nip() == '6193826717'
    assert prvdr.nip() == '6171411132'
    assert prvdr.nip() == '8095954724'


# Generated at 2022-06-23 20:42:54.677402
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Unit test for method nip of class PolandSpecProvider."""
    g = PolandSpecProvider()
    for i in range(50):
        print(g.nip())



# Generated at 2022-06-23 20:42:57.610841
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    poland_spec_provider = PolandSpecProvider()
    nip = poland_spec_provider.nip()
    assert isinstance(nip, str)
    assert len(nip) == 10



# Generated at 2022-06-23 20:43:01.444740
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    PolandSpecProvider().seed(1)
    assert PolandSpecProvider().nip() == '1361582857'
    assert PolandSpecProvider().pesel() == '1605237864'
    assert PolandSpecProvider().regon() == '78976181'



# Generated at 2022-06-23 20:43:05.270841
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    psp = PolandSpecProvider()
    assert (isinstance(psp.nip(), str))
    assert (isinstance(psp.pesel(), str))
    assert (isinstance(psp.regon(), str))

# Generated at 2022-06-23 20:43:07.206004
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    nip = provider.nip()
    assert len(nip) == 10 and nip.isdigit()


# Generated at 2022-06-23 20:43:09.534475
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    assert isinstance(provider, PolandSpecProvider)
    assert isinstance(provider, BaseSpecProvider)


# Generated at 2022-06-23 20:43:11.735437
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    nip = provider.nip()

    assert len(nip) == 10
    assert int(nip)



# Generated at 2022-06-23 20:43:15.435766
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider()
    for _ in range(100):
        regon = provider.regon()
        assert isinstance(regon, str)
        assert len(regon) == 9
        digits = [int(d) for d in regon]
        regon_coeffs = (8, 9, 2, 3, 4, 5, 6, 7)
        sum_v = sum([nc * nd for nc, nd in zip(regon_coeffs, digits[:-1])])
        checksum_digit = sum_v % 11
        assert digits[-1] == checksum_digit or checksum_digit == 0


# Generated at 2022-06-23 20:43:24.708934
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # GIVEN
    from mimesis.providers import PolandSpecProvider
    from mimesis.enums import Gender

    p = PolandSpecProvider()
    # WHEN
    actual = p.pesel(gender=Gender.FEMALE)
    # THEN
    assert len(actual) == 11
    assert actual[-1] in ['0', '2', '4', '6', '8']
    # WHEN
    actual = p.pesel(gender=Gender.MALE)
    # THEN
    assert len(actual) == 11
    assert actual[-1] in ['1', '3', '5', '7', '9']

# Generated at 2022-06-23 20:43:26.019075
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider()
    assert len(provider.regon()) == 9

# Generated at 2022-06-23 20:43:36.291614
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    a = PolandSpecProvider() #a is an instance of class PolandSpecProvider
    print(a.pesel(birth_date=a.datetime(1940, 1981, 0, 0, 0), gender=Gender.FEMALE))
    print(a.pesel(birth_date=a.datetime(1940, 1981, 0, 0, 0), gender=Gender.MALE))
    print(a.pesel(birth_date=a.datetime(1940, 1981, 0, 0, 0), gender=None))
    print(a.pesel(birth_date=None, gender=Gender.FEMALE))
    print(a.pesel(birth_date=None, gender=Gender.MALE))
    print(a.pesel(birth_date=None, gender=None))


# Generated at 2022-06-23 20:43:40.689316
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    from mimesis.enums import Gender
    from mimesis.typing import Seed

    seed = Seed.random()
    p = PolandSpecProvider(seed)

    d = p.datetime().datetime()
    pesel = p.pesel(birth_date=d, gender=Gender.MALE)
    assert len(pesel) == 11

# Generated at 2022-06-23 20:43:45.173996
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider()
    regon = provider.regon()
    assert isinstance(regon, str)
    assert len(regon) == 9
    assert all(c.isdigit() for c in regon)


# Generated at 2022-06-23 20:43:46.698679
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    plst = PolandSpecProvider()
    assert plst.pesel().__len__() == 11

# Generated at 2022-06-23 20:43:48.685434
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    pl = PolandSpecProvider()
    assert pl.nip() != None
    assert pl.pesel() != None
    assert pl.regon() != None

# Generated at 2022-06-23 20:43:53.571772
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    poland_provider = PolandSpecProvider(seed=123)
    assert poland_provider.nip() == "2422148435"
    assert poland_provider.pesel(birth_date=0, gender=Gender.MALE) == "79032910966"
    assert poland_provider.regon() == "539284768"


# Generated at 2022-06-23 20:43:54.873766
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    PolandSpecProvider().regon()

# Generated at 2022-06-23 20:43:57.446821
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    seed = '9a9f5836fe8b2d0ae0e464e48de13b0d'
    obj = PolandSpecProvider(seed)
    assert obj is not None


# Generated at 2022-06-23 20:44:00.688956
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Test that all methods of PolandSpecProvider works fine."""
    P = PolandSpecProvider(seed = 0)
    assert P.nip() == '6920990801'
    assert P.pesel() == '59100810049'
    assert P.regon() == '907979115'

# Generated at 2022-06-23 20:44:03.496396
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Method for checking pesel of class PolandSpecProvider."""
    obj_provider = PolandSpecProvider(seed=42)
    assert obj_provider.pesel(birth_date='1996-11-03', gender='male') == '96112893668'

# Generated at 2022-06-23 20:44:10.220887
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()

    # Test 1
    pesel = provider.pesel()
    assert len(pesel) == 11

    # Test 2
    dt = Datetime().datetime(1990, 2000)
    pesel = provider.pesel(birth_date=dt)
    assert len(pesel) == 11

    # Test 3
    dt = Datetime().datetime(1990, 2000)
    pesel = provider.pesel(birth_date=dt, gender=Gender.MALE)
    assert len(pesel) == 11

    # Test 4
    dt = Datetime().datetime(1990, 2000)
    pesel = provider.pesel(birth_date=dt, gender=Gender.FEMALE)
    assert len(pesel) == 11
    return True

# Generated at 2022-06-23 20:44:12.517011
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    # for _ in range(10):
    #     print(PolandSpecProvider().nip())
    assert PolandSpecProvider().nip() != ''
    assert PolandSpecProvider().nip() != None


# Generated at 2022-06-23 20:44:17.077610
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Unit test for method regon of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    regon = provider.regon()
    print(regon)
    assert len(regon) == 9


# Generated at 2022-06-23 20:44:20.024973
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    psp = PolandSpecProvider()
    assert psp.__class__.__name__ == 'PolandSpecProvider'


# Generated at 2022-06-23 20:44:23.412401
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    ppp = PolandSpecProvider()
    assert isinstance(ppp.nip(), str)
    assert (len(ppp.nip()) == 10)


# Generated at 2022-06-23 20:44:25.185483
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    print('Random PESEL: {}'.format(pesel))
    assert len(pesel) == 11


# Generated at 2022-06-23 20:44:27.196772
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    p = PolandSpecProvider()
    assert p.__class__.__name__ == 'PolandSpecProvider'



# Generated at 2022-06-23 20:44:29.552554
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    assert len(PolandSpecProvider().nip()) == 10


# Generated at 2022-06-23 20:44:38.954094
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    pl = PolandSpecProvider()

    # Test for function nip
    assert len(pl.nip()) == 10
    assert pl.nip().isnumeric() == True
    assert pl.nip() != pl.nip()

    # Test for function pesel
    assert len(pl.pesel()) == 11
    assert pl.pesel().isnumeric() == True
    assert pl.pesel() != pl.pesel()

    # Test for function regon
    assert len(pl.regon()) == 9
    assert pl.regon().isnumeric() == True
    assert pl.regon() != pl.regon()

# Generated at 2022-06-23 20:44:41.292656
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    p = PolandSpecProvider()
    r = p.regon()
    print(r)


# Generated at 2022-06-23 20:44:44.303938
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Test method regon."""
    poland = PolandSpecProvider()
    regon = poland.regon()
    assert len(regon) == 9


# Generated at 2022-06-23 20:44:55.039982
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel_list_1 = list()
    pesel_list_2 = list()
    a = PolandSpecProvider()
    for i in range(10):
        pesel_1 = a.pesel()
        pesel_2 = a.pesel(gender=Gender.FEMALE)
        pesel_list_1.append(pesel_1)
        pesel_list_2.append(pesel_2)
    assert len(pesel_1) == 11
    assert len(pesel_2) == 11
    assert pesel_1[9] == '1' or pesel_1[9] == '3' or pesel_1[9] == '5' or pesel_1[9] == '7' or pesel_1[9] == '9'

# Generated at 2022-06-23 20:45:00.422248
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    pl_spec_provider = PolandSpecProvider()
    assert pl_spec_provider.__class__.__name__ == 'PolandSpecProvider'
    result = pl_spec_provider.__str__()
    expected_result = 'PolandSpecProvider(seed=None)'
    assert result == expected_result


# Generated at 2022-06-23 20:45:04.920409
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Unit test for method regon of class PolandSpecProvider"""
    import re

    provider = PolandSpecProvider()
    regon = provider.regon()
    assert re.match(r"^[0-9]{9}$", regon)
    assert len(regon) == 9



# Generated at 2022-06-23 20:45:11.488837
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Test the method nip of class PolandSpecProvider
    In the method, the possible values of the first character of NIP are 101-998,
    and the rest of the digits are random, but the last one is calculated on the basis of
    the remaining part of the NIP, with the coefficients of the product in order from left to right.
    When the sum is greater than 9, the result of the division by modulo 11 is taken
    (if the result is 10, then NIP is calculated again).
    """
    nip = PolandSpecProvider().nip()
    first_digit = int(nip[0])
    for i in [0, 1, 2, 3, 4, 5, 6, 7, 8]:
        assert len(nip) == 10, "Wrong length of NIP"

# Generated at 2022-06-23 20:45:14.756575
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesels = list()
    for i in range(10):
        pesels.append(PolandSpecProvider().pesel(Datetime().datetime(), Gender.MALE))
    print(pesels)

# Generated at 2022-06-23 20:45:18.656631
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    # Create object
    provider = PolandSpecProvider(seed=12345)
    # Run the method
    actual = provider.regon()
    # Check the result
    expected = '051040536'
    assert expected == actual

# Generated at 2022-06-23 20:45:19.528367
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    pl = PolandSpecProvider()
    assert type(pl) == PolandSpecProvider

# Generated at 2022-06-23 20:45:26.689398
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    from utils import assert_output
    from mimesis.enums import Gender
    from mimesis import PolandSpecProvider
    polandSpecProvider = PolandSpecProvider()
    assert_output(polandSpecProvider.nip(), '8091451064')
    assert_output(polandSpecProvider.nip(Gender.MALE), '8091451064')
    assert_output(polandSpecProvider.nip(Gender.FEMALE), '7937470051')

# Generated at 2022-06-23 20:45:31.086076
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """ Test for method regon of class PolandSpecProvider. """
    from mimesis.enums import Gender
    from mimesis.providers.poland import PolandSpecProvider
    provider = PolandSpecProvider()
    print(provider.regon())
    #print(provider.pesel(gender= Gender.MALE))

# Generated at 2022-06-23 20:45:40.454392
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    from mimesis.builtins import PolandSpecProvider
    from mimesis.enums import Gender
    from mimesis.typing import DateTime

    p = PolandSpecProvider()

    # Method "nip"
    nip = p.nip()
    nip == str
    nip != None

    # Method "pesel"
    pesel = p.pesel()
    pesel == str
    pesel != None
    pesel_with_gender = p.pesel(gender = Gender.MALE)
    pesel_with_gender == str
    pesel_with_gender != None
    pesel_with_birth_date = p.pesel(birth_date = DateTime())
    pesel_with_birth_date == str
    pesel_with_birth_date != None

    # Method "regon"


# Generated at 2022-06-23 20:45:48.167992
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    from mimesis.providers.person import Person
    from mimesis.enums import Gender

    p = PolandSpecProvider()
    pesel = p.regon()
    print(pesel)

    #assert len(pesel) == 11
    #assert int(pesel[:2]) in range(10,20)
    #assert int(pesel[2:4]) in Person(gender=Gender.MALE).get_month()
    #assert int(pesel[4:6]) in Person(gender=Gender.MALE).get_day()
    #assert int(pesel[6:9]) > 0

# Generated at 2022-06-23 20:45:54.398978
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    psp = PolandSpecProvider()
    nip1 = psp.nip()
    nip2 = psp.nip()
    assert nip1 != nip2
    pesel1 = psp.pesel()
    pesel2 = psp.pesel()
    assert pesel1 != pesel2
    regon1 = psp.regon()
    regon2 = psp.regon()
    assert regon1 != regon2

# Generated at 2022-06-23 20:45:56.739104
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    poland_provider = PolandSpecProvider()
    assert isinstance(poland_provider, PolandSpecProvider)


# Generated at 2022-06-23 20:45:58.808071
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    nip = provider.nip()
    assert nip == '1383770237'



# Generated at 2022-06-23 20:46:02.919208
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test case for generating pesel of class PolandSpecProvider."""
    from datetime import datetime
    poland_provider = PolandSpecProvider()
    pesel_code = poland_provider.pesel(datetime(1995, 3, 11))
    assert pesel_code == '95031139490'


# Generated at 2022-06-23 20:46:05.350686
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    for i in range(10):
        print(PolandSpecProvider().nip())



# Generated at 2022-06-23 20:46:09.911231
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    nip1 = PolandSpecProvider().nip()
    nip2 = PolandSpecProvider().nip()

    print('nip1={}, nip2={}'.format(nip1, nip2))


# Generated at 2022-06-23 20:46:15.250065
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    nip_list = []
    for i in range(100):
        nip_list.append(PolandSpecProvider().nip())
    print(nip_list, len(nip_list), len(set(nip_list)))


# Generated at 2022-06-23 20:46:17.906824
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    pl = PolandSpecProvider()
    res = pl.nip()
    assert len(res) == 10
    assert res.isdigit()


# Generated at 2022-06-23 20:46:19.676665
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    expected_output = '98080105829'
    assert PolandSpecProvider().pesel() == expected_output

# Generated at 2022-06-23 20:46:23.130739
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    test_pesel = PolandSpecProvider()
    assert test_pesel.pesel() == test_pesel.pesel()
    assert len(test_pesel.pesel()) == 11
    assert isinstance(test_pesel.pesel(), str)

test_PolandSpecProvider_pesel()



# Generated at 2022-06-23 20:46:26.190637
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    for i in range(0, 100):
        assert len(p.pesel()) == 11


# Generated at 2022-06-23 20:46:28.016826
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    try:
        PolandSpecProvider()
    except:
        assert False
    else:
        assert True


# Generated at 2022-06-23 20:46:35.248397
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Проверка на возвращение методом случайного песеля."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11 and pesel.isdigit()
    birth_date = provider.datetime().date(1940, 2018)
    gender = provider.gender()
    pesel = provider.pesel(birth_date, gender)
    assert len(pesel) == 11 and pesel.isdigit()
    year = birth_date.year
    month = birth_date.month
    day = birth_date.day
    year_part = str(year)[2:]

# Generated at 2022-06-23 20:46:38.885416
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    a = PolandSpecProvider()
    b = a.regon()
    assert len(b) == 9
    for i in range(9):
        assert type(b[i]) == str



# Generated at 2022-06-23 20:46:41.247820
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    # Create a PolandSpecProvider instance
    pl_sp = PolandSpecProvider()
    # Create a set
    my_set = set()
    # Add 10 random nip numbers to the set
    for _ in range(10):
        my_set.add(pl_sp.nip())
    # Check if the set has 10 elements
    assert len(my_set) == 10



# Generated at 2022-06-23 20:46:46.017885
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # Given
    pesel_provider = PolandSpecProvider()

    # When
    PESEL_1 = pesel_provider.pesel()
    PESEL_2 = pesel_provider.pesel()

    # Then
    assert len(PESEL_1) == len(PESEL_2) == 11

    # Clean Up
    del pesel_provider


# Generated at 2022-06-23 20:46:48.889024
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    test_obj = PolandSpecProvider()
    for i in range(100):
        assert len(test_obj.regon()) == 9


# Generated at 2022-06-23 20:46:52.579941
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Unit test for method regon of class PolandSpecProvider."""
    ppl = PolandSpecProvider()
    regon = ppl.regon()
    assert len(regon) == 9


# Generated at 2022-06-23 20:46:53.641788
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    assert not provider.__init__(None)


# Generated at 2022-06-23 20:47:02.539770
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Test method regon of class PolandSpecProvider."""
    class PolandSpecProvider(BaseSpecProvider):
        """Class that provides special data for Poland (pl)."""

        def __init__(self, seed: Seed = None):
            """Initialize attributes."""
            super().__init__(locale='pl', seed=seed)

        class Meta:
            """The name of the provider."""

            name = 'poland_provider'

        def regon(self) -> str:
            """Generate random valid 9-digit REGON.

            :return: Valid 9-digit REGON
            """
            regon_coeffs = (8, 9, 2, 3, 4, 5, 6, 7)
            regon_digits = [self.random.randint(0, 9) for _ in range(8)]
            sum_

# Generated at 2022-06-23 20:47:04.743275
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    assert PolandSpecProvider.Meta.name == 'poland_provider'


# Generated at 2022-06-23 20:47:07.886223
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Test for loading gender dict with NIP, REGON, PESEL """
    from mimesis.providers.poland import PolandSpecProvider
    spec = PolandSpecProvider(seed=100)
    nip = spec.nip()
    regon = spec.regon()
    pesel = spec.pesel()
    assert nip == '9924043244'
    assert regon == '548680916'
    assert pesel == '92051605339'