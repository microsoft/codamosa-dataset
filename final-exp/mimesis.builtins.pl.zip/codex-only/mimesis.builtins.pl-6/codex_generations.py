

# Generated at 2022-06-23 20:37:12.689053
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """PolandSpecProvider_pesel."""

    from mimesis.enums import Gender
    from mimesis.typing import DateTime
    
    my_PolandSpecProvider = PolandSpecProvider()

    my_PolandSpecProvider.pesel()
    my_PolandSpecProvider.pesel(birth_date=DateTime().datetime(1900, 2020), gender=Gender.MALE)

# Generated at 2022-06-23 20:37:21.247391
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    poland_spec_provider = PolandSpecProvider()
    print(poland_spec_provider.nip())
    print(poland_spec_provider.pesel())
    print(poland_spec_provider.regon())
    assert poland_spec_provider.nip().isdigit() and len(poland_spec_provider.nip()) == 10
    assert poland_spec_provider.pesel().isdigit() and len(poland_spec_provider.pesel()) == 11
    assert poland_spec_provider.regon().isdigit() and len(poland_spec_provider.regon()) == 9

# Generated at 2022-06-23 20:37:30.932783
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
   list_results=[]
   length_nip = 10
   while len(list_results)<1000:
      pl_provider = PolandSpecProvider()
      nip = pl_provider.nip()
      if len(nip) == length_nip and nip not in list_results:
         list_results.append(nip)

# Generated at 2022-06-23 20:37:32.255422
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    assert len(PolandSpecProvider().nip()) == 10


# Generated at 2022-06-23 20:37:35.677551
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    ps = PolandSpecProvider()
    regon = ps.regon()
    print('REGON: ', regon)
    assert len(regon) == 9
    assert regon.isdigit()



# Generated at 2022-06-23 20:37:38.658346
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    p = PolandSpecProvider()
    nip = p.nip()
    assert len(nip) == 10
    assert nip.isdigit() == True



# Generated at 2022-06-23 20:37:40.693125
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Unit test for constructor of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    assert provider.__class__.__name__ == 'PolandSpecProvider', 'Failure'


# Generated at 2022-06-23 20:37:41.790615
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    assert len(PolandSpecProvider().nip()) == 10


# Generated at 2022-06-23 20:37:43.330746
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
	polandSpecProvider = PolandSpecProvider()
	assert len(polandSpecProvider.regon()) == 9


# Generated at 2022-06-23 20:37:47.068489
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    a = PolandSpecProvider()
    assert(len(a.pesel()) == 11)
    assert(a.pesel().isdigit())
    assert(a.pesel(birth_date='01.02.2002') != a.pesel(birth_date='01.02.2003'))
    assert(a.pesel(gender=Gender.MALE) != a.pesel(gender=Gender.FEMALE))


# Generated at 2022-06-23 20:37:53.772826
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():

    pol = PolandSpecProvider(seed = 123)
    for i in range(100) :
        regon = pol.regon()
        print(regon)

    """
    #test frequencies 
    from collections import Counter
    from mimesis import PolandSpecProvider

    pol = PolandSpecProvider()
    regon_dict = {}
    for i in range(1000000):
        regon = pol.regon()
        if regon in regon_dict:
            regon_dict[regon] += 1
        else:
            regon_dict[regon] = 1
    print(Counter(regon_dict))
    """
    
    
    

# Generated at 2022-06-23 20:37:56.813980
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    assert provider.nip() == '5043417881'
    assert provider.pesel() == '00050277717'
    assert provider.regon() == '254013999'


# Generated at 2022-06-23 20:37:58.979470
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    data = PolandSpecProvider().regon()
    data = [int(d) for d in str(data)]

    assert 2 <= len(data) <= 14


# Generated at 2022-06-23 20:38:02.393954
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    for _ in range(10000):
        assert provider.nip().isnumeric()
        assert len(provider.nip()) == 10

        assert provider.pesel().isnumeric()
        assert len(provider.pesel()) == 11

        assert provider.regon().isnumeric()
        assert len(provider.regon()) == 9

# Generated at 2022-06-23 20:38:11.485880
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    nip_generator = PolandSpecProvider()
    nip_value = nip_generator.nip()
    nip_digits = [int(d) for d in nip_value]
    nip_coefficients = (6, 5, 7, 2, 3, 4, 5, 6, 7)
    sum_v = sum([nc * nd for nc, nd in zip(nip_coefficients, nip_digits)])
    checksum_digit = sum_v % 11
    if checksum_digit > 9:
        checksum_digit = 0
    if checksum_digit == nip_digits[-1]:
        print("OK")
    else:
        print("Bad")


# Generated at 2022-06-23 20:38:15.001388
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    p = PolandSpecProvider()
    p.pesel(birth_date=Datetime().datetime(2010, 2020, gender=Gender.FEMALE))
    p.pesel(gender=Gender.FEMALE)
    p.pesel(gender=Gender.MALE)
    p.pesel()
    p.nip()
    p.regon()

# Generated at 2022-06-23 20:38:20.096096
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel."""
    from mimesis.builtins.poland import PolandSpecProvider
    from mimesis.enums import Gender
    import datetime
    provider = PolandSpecProvider()
    birth = datetime.datetime(1994, 1, 3)
    assert provider.pesel(birth_date=birth, gender=Gender.FEMALE) == '94010300043'
    assert provider.pesel(birth_date=birth, gender=Gender.MALE) == '94010300077'
    assert len(provider.pesel(birth_date=birth)) == 11


# Generated at 2022-06-23 20:38:23.842892
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    p = PolandSpecProvider()
    print(p.nip())
    print(p.pesel())
    print(p.pesel(birth_date='1920-10-10', gender='F'))
    print(p.regon())

if __name__ == "__main__":
    test_PolandSpecProvider()

# Generated at 2022-06-23 20:38:29.518015
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    mimesis_pl_provider = PolandSpecProvider()
    # check if method returns correct type of data
    assert isinstance(mimesis_pl_provider.pesel(), str)
    # check if method returns correct data
    birth_date = (2009, 11, 17, 0, 0, 0, 0)
    gender = Gender.MALE
    assert mimesis_pl_provider.pesel(birth_date, gender) == '09111700382'

# Generated at 2022-06-23 20:38:31.117720
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    _regon = PolandSpecProvider().regon()
    assert len(_regon) == 9



# Generated at 2022-06-23 20:38:32.514178
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    nip = PolandSpecProvider().nip()
    assert(len(nip) == 10)


# Generated at 2022-06-23 20:38:40.562179
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Unit test for constructor of class PolandSpecProvider."""
    provider = PolandSpecProvider()

    assert provider.__class__.__name__ == 'PolandSpecProvider'
    assert provider._meta.name == 'poland_provider'
    assert provider._meta.provider_name == 'poland_provider'
    assert provider._meta.locale == 'pl'
    assert provider._meta.language == 'pl'
    assert provider._meta.seed is None
    assert provider._meta.seed_type is None


# Generated at 2022-06-23 20:38:42.305331
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    assert len(provider.pesel()) == 11

# Generated at 2022-06-23 20:38:44.399618
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    # Test with default value of argument, should return string of length 10
    assert len(PolandSpecProvider().nip()) == 10


# Generated at 2022-06-23 20:38:46.514514
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    PolandSpecProvider(seed=699)

# Generated at 2022-06-23 20:38:55.584748
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider"""

    provider1 = PolandSpecProvider()
    print(provider1.pesel())
    print(provider1.pesel(birth_date='2000-12-01', gender=Gender.FEMALE))
    print(provider1.pesel(birth_date='2000-01-01', gender=Gender.MALE))

    provider2 = PolandSpecProvider('12345')
    print(provider2.pesel())
    print(provider2.pesel(birth_date='2000-12-01', gender=Gender.FEMALE))
    print(provider2.pesel(birth_date='2000-01-01', gender=Gender.MALE))
    print(provider2.pesel(birth_date='2000-02-01', gender=Gender.MALE))

# Generated at 2022-06-23 20:39:05.838117
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Unit test for method regon of class PolandSpecProvider."""
    p = PolandSpecProvider()
    regon = p.regon()
    assert len(regon) == 9
    regon = p.random.shuffle(list(regon))
    assert len(regon) == 9
    regon = ''.join(regon)
    assert len(regon) == 9
    # Check regon with length of 9
    regon = p.regon(length=9)
    assert len(regon) == 9
    # Check regon with length of 14
    regon = p.regon(length=14)
    assert len(regon) == 14
    # Check regon with length of 9 when wrong length is passed
    regon = p.regon(length=0)
    assert len(regon) == 9

# Generated at 2022-06-23 20:39:14.913588
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    poland_provider = PolandSpecProvider()
    regon_digits = [int(d) for d in poland_provider.regon()]
    regon_coeffs = (8, 9, 2, 3, 4, 5, 6, 7)
    sum_v = sum([nc * nd for nc, nd in zip(regon_coeffs, regon_digits[0:8])])
    checksum_digit = sum_v % 11
    if checksum_digit > 9:
        checksum_digit = 0
    assert regon_digits[-1] == checksum_digit


# Generated at 2022-06-23 20:39:16.680097
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    p = PolandSpecProvider()
    print(p.nip())


# Generated at 2022-06-23 20:39:18.691445
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    p = PolandSpecProvider()
    print(p.regon())  # --> Should return: 994223950


# Generated at 2022-06-23 20:39:21.032899
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    pl = PolandSpecProvider()
    regon = pl.regon()
    assert  len(regon) == 9
    assert regon.isdigit() is True


# Generated at 2022-06-23 20:39:22.911191
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    pesel_list = set()
    for i in range(10):
        p1 = PolandSpecProvider().pesel()
        print(p1)
        pesel_list.add(p1)
    print(pesel_list)

# Generated at 2022-06-23 20:39:26.790758
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Unit test for method regon of class PolandSpecProvider."""
    poland_spec_provider = PolandSpecProvider('seed')

    assert poland_spec_provider.regon() == '645347551'
    assert poland_spec_provider.regon() == '362962831'
    assert poland_spec_provider.regon() == '305936985'



# Generated at 2022-06-23 20:39:28.543485
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    p = PolandSpecProvider()
    print(p.regon())


# Generated at 2022-06-23 20:39:29.558923
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    nip = PolandSpecProvider().nip()
    assert len(nip) == 10


# Generated at 2022-06-23 20:39:30.964677
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider()
    result = provider.regon()
    assert len(result) == 9

# Generated at 2022-06-23 20:39:35.548797
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    p = PolandSpecProvider()
    x = p.nip()
    assert x[0] == '1' or x[0] == '2' or x[0] == '3'
    assert len(x) == 10


# Generated at 2022-06-23 20:39:37.999509
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Unit test for method regon of class PolandSpecProvider"""
    psp = PolandSpecProvider()
    assert len(psp.regon()) == 9


# Generated at 2022-06-23 20:39:44.702449
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    # GIVEN
    testee = PolandSpecProvider()

    # WHEN
    output = testee.regon()

    # THEN
    # See documentation of the method regon()
    assert len(output) == 9
    sum_v = 0
    for n, nd in enumerate(output):
        if n < 8:
            sum_v += (n + 8) * int(nd)

    assert sum_v % 11 == int(output[8])

# Generated at 2022-06-23 20:39:48.981362
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Tests for method 'nip' of class 'PolandSpecProvider'."""
    spe = PolandSpecProvider()
    pes = spe.nip()
    print(pes)



# Generated at 2022-06-23 20:39:53.032465
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    a = provider.pesel()
    b = provider.pesel(birth_date={'year': 2019, 'month': 6, 'day': 9}, gender={'gender': 'M'})
    assert len(a) == 11
    assert len(b) == 11

# Generated at 2022-06-23 20:39:55.119049
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    PolSpec = PolandSpecProvider()
    regon = PolSpec.regon()
    assert len(regon) == 9


# Generated at 2022-06-23 20:39:58.959225
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    instance = PolandSpecProvider()
    instance2 = PolandSpecProvider()
    for i in range(10):
        assert isinstance(instance.pesel(), str)
    for i in range(10):
        assert isinstance(instance2.pesel(gender=Gender.MALE), str)


# Generated at 2022-06-23 20:40:07.591597
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    seeds = [0, 1, 2, 3, 4]
    gender_values = [None, Gender.MALE, Gender.FEMALE]

# Generated at 2022-06-23 20:40:10.735126
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    seed = '123456789'
    test_object = PolandSpecProvider(seed)
    assert test_object.seed == seed


# Generated at 2022-06-23 20:40:16.478300
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider(seed=1)
    random_regon = provider.regon()
    assert len(random_regon) == 9
    assert int(random_regon[0]) + int(random_regon[1]) + int(random_regon[2]) + int(random_regon[3]) + int(random_regon[4]) + int(random_regon[5]) + int(random_regon[6]) + int(random_regon[7]) + int(random_regon[8]) == 29
    for i in range(9):
        print(random_regon[i], end=" ")
    print()


# Generated at 2022-06-23 20:40:22.095886
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider=PolandSpecProvider()

    pesel_female=provider.pesel(gender=Gender.FEMALE)
    pesel_male=provider.pesel(gender=Gender.MALE)
    pesel_neutral=provider.pesel(gender=Gender.NEUTRAL)
    print(pesel_female, pesel_male, pesel_neutral)

    pesel_female2=provider.pesel(gender=Gender.FEMALE)
    pesel_male2=provider.pesel(gender=Gender.MALE)
    pesel_neutral2=provider.pesel(gender=Gender.NEUTRAL)
    print(pesel_female2, pesel_male2, pesel_neutral2)

test_PolandSpecProvider_pesel()

# Generated at 2022-06-23 20:40:25.891322
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    from pprint import pprint
    print('\n\n\nUnit test for the method nip of class PolandSpecProvider')
    provider = PolandSpecProvider()
    pprint(provider.nip())


# Generated at 2022-06-23 20:40:35.613506
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # Call Pesel method with gender parameter
    m = PolandSpecProvider().pesel(gender=Gender.MALE)
    f = PolandSpecProvider().pesel(gender=Gender.FEMALE)
    assert m[9] in [str(i) for i in range(1, 10, 2)]
    assert f[9] in [str(i) for i in range(0, 10, 2)]

    # Call pesel method with birth_date parameter
    m = PolandSpecProvider().pesel(
        birth_date=Datetime().datetime(1960))
    f = PolandSpecProvider().pesel(
        birth_date=Datetime().datetime(1990))
    assert m[0:2] == '60'
    assert f[0:2] == '90'



# Generated at 2022-06-23 20:40:41.395044
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    pesel1 = PolandSpecProvider()
    pesel2 = PolandSpecProvider()
    regon1 = PolandSpecProvider()


    list.append(pesel1.pesel())
    list.append(pesel2.pesel())
    list.append(regon1.regon())


    print(list)

# Generated at 2022-06-23 20:40:45.035169
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    pesel = PolandSpecProvider().pesel()
    # Method pesel should return a string containing 11 digits.
    assert len(pesel) == 11
    assert pesel.isdigit() == True


# Generated at 2022-06-23 20:40:53.131387
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Все возможные значения для ключей, присутствующих в
       классе PolandSpecProvider: pesel, nip, regon"""

    polandProvider = PolandSpecProvider()
    for _ in range(100):
        pesel = polandProvider.pesel()
        print(pesel)

# Generated at 2022-06-23 20:40:56.916510
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    for _ in range(50):
        assert(len(provider.pesel())==11)
        assert(provider.pesel()!=provider.pesel())


# Generated at 2022-06-23 20:40:58.696231
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider(10)
    assert provider.pesel() == '33211841639'
    # Unit test for method nip of class PolandSpecProvider



# Generated at 2022-06-23 20:41:00.148932
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    assert PolandSpecProvider()

# Unit tests for method nip() of class PolandSpecProvider

# Generated at 2022-06-23 20:41:03.836232
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    instance = PolandSpecProvider(seed=1)
    assert instance.pesel(birth_date=None,gender=Gender.MALE) == '00910104429'
    assert instance.pesel(birth_date=None,gender=Gender.FEMALE) == '02602037277'
    assert instance.pesel(birth_date=None,gender=None) == '77211048442'

# Generated at 2022-06-23 20:41:07.114787
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    print("Create PolandSpecProvider")
    pol = PolandSpecProvider()
    assert pol._data is not None
    assert pol._locale is not None



# Generated at 2022-06-23 20:41:09.115369
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    # Setup
    provider = PolandSpecProvider()
    assert(type(provider.regon()) == str)

# Generated at 2022-06-23 20:41:13.793212
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """PolandSpecProvider - method: nip
    Check if method generate correct data."""
    sample = PolandSpecProvider()
    result = sample.nip()
    assert len(result) == 10
    assert result[0:3] == '101'
    assert result[3:10].isdigit()


# Generated at 2022-06-23 20:41:15.360806
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    for i in range(10):
        assert len(PolandSpecProvider().regon()) == 9


# Generated at 2022-06-23 20:41:19.444630
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method PolandSpecProvider.pesel."""
    p = PolandSpecProvider()
    assert p.pesel() == '80120500330'
    assert p.pesel(None, Gender.MALE) == '80120500329'

# Generated at 2022-06-23 20:41:20.520674
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    PolandSpecProvider().regon()


# Generated at 2022-06-23 20:41:22.960846
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    nip = PolandSpecProvider().nip()
    assert len(nip) == 10
    assert nip.isdigit()


# Generated at 2022-06-23 20:41:29.579506
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    from mimesis.providers.person import Person
    from mimesis.enums import Gender
    import PyPESEL
    from datetime import date
    pesel = PolandSpecProvider().pesel(Person().birth_date(1900, 1980, date_format='%Y-%m-%d'), Gender.MALE)
    print(pesel)
    print(PyPESEL.validate(pesel))

# Generated at 2022-06-23 20:41:31.539544
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    pol = PolandSpecProvider(seed = "Beata")
    x = pol.nip()
    if x in ['1234567891', '6543213456']:
        assert True
    else:
        assert False


# Generated at 2022-06-23 20:41:38.533504
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    isValid = True
    for i in range(1000):
        regon = PolandSpecProvider.regon()
        for i in range(len(regon)):
            try:
                regon[i] = int(regon[i])
            except:
                isValid = False
                break

        regon_coeffs = (8, 9, 2, 3, 4, 5, 6, 7)
        sum_v = sum([nc * nd for nc, nd in zip(regon_coeffs, regon[:8])])
        checksum_digit = sum_v % 11
        if checksum_digit > 9:
            checksum_digit = 0

        if int(regon[8]) != checksum_digit:
            isValid = False
            break

    assert isValid


# Generated at 2022-06-23 20:41:40.834164
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    regon = PolandSpecProvider().regon()
    assert len(regon) == 9
    assert isinstance(regon, str)
    assert regon.isdigit()


# Generated at 2022-06-23 20:41:43.631721
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    psp = PolandSpecProvider()
    psp.seed(0)
    assert psp.regon() == "656085095"

# Generated at 2022-06-23 20:41:47.174085
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    p = PolandSpecProvider()
    for _ in range(10):
        assert len(p.nip()) == 10
        assert p.nip()[0] in ['1', '2', '3', '5', '6', '7', '8', '9']


# Generated at 2022-06-23 20:41:52.370541
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    a = PolandSpecProvider()
    assert len(a.pesel()) == 11
    assert a.pesel()[-1] in ('0', '1', '2', '3', '4', '5', '6', '7', '8', '9')
    for i in range(100):
        assert len(a.pesel(gender=Gender.MALE)) == 11
        assert len(a.pesel(gender=Gender.FEMALE)) == 11


# Generated at 2022-06-23 20:41:55.167021
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    nip = provider.nip()
    print(nip)
    assert len(nip) == 10
    

# Generated at 2022-06-23 20:41:57.500071
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    nip = provider.nip()
    assert len(nip) == 10


# Generated at 2022-06-23 20:41:59.510284
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    assert isinstance(provider, PolandSpecProvider)
    assert provider.__class__.__name__ == 'PolandSpecProvider'



# Generated at 2022-06-23 20:42:08.113137
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    '''
    Test for method nip for class PolandSpecProvider
    '''
    nip_str = PolandSpecProvider().nip()
    nip_list = [int(d) for d in str(nip_str)]
    print(nip_str)
    nip_coefficients = (6, 5, 7, 2, 3, 4, 5, 6, 7)
    sum_v = sum([nc * nd for nc, nd in zip(nip_coefficients, nip_list)])
    checksum_digit = sum_v % 11
    print(checksum_digit)
    assert nip_list[-1] == checksum_digit


# Generated at 2022-06-23 20:42:09.788256
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel(birth_date=Datetime().datetime(1988,11,1),gender=Gender.MALE)
    assert len(pesel)==11

test_PolandSpecProvider_pesel()

# Generated at 2022-06-23 20:42:14.060817
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    # 1. GIVEN a provider of Poland
    provider = PolandSpecProvider()

    # 2. WHEN the method nip is called
    nip = provider.nip()

    # 3. THEN the result is a ten-digit number
    assert len(nip) == 10
    assert nip.isdigit()


# Generated at 2022-06-23 20:42:16.519503
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    for i in range(100):
        seed = 42 + i
        provider = PolandSpecProvider(seed=seed)
        print(provider.pesel())

# Generated at 2022-06-23 20:42:19.208900
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    x = PolandSpecProvider()
    print(x.regon())
    print(x.nip())
    print(x.pesel())

# Generated at 2022-06-23 20:42:24.181649
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pl = PolandSpecProvider(seed="a")
    assert pl.pesel() == "89072211121"
    assert pl.pesel(DateTime(2020, 1, 1), Gender.MALE) == "20021211121"
    assert pl.pesel(DateTime(2020, 1, 1), Gender.FEMALE) == "20021211121"
    assert pl.pesel(DateTime(2020, 1, 1), Gender.OTHER) == "20021211121"
    assert pl.pesel(Datetime.datetime(2019, 12, 31), Gender.MALE) == "20021211121"
    assert pl.pesel(DateTime(2019, 12, 31), Gender.FEMALE) == "20021211121"

# Generated at 2022-06-23 20:42:34.457753
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    pesel = provider.pesel(date(2015, 9, 5), Gender.MALE)
    assert len(pesel) == 11
    assert pesel.startswith('150905')
    assert int(pesel[-2]) % 2 == 1
    assert pesel[-1] == '1'
    pesel = provider.pesel(date(2015, 9, 5), Gender.FEMALE)
    assert len(pesel) == 11
    assert pesel.startswith('150905')
    assert int(pesel[-2]) % 2 != 1
    assert pesel[-1] == '7'

# Generated at 2022-06-23 20:42:36.836026
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    # GIVEN
    locale = 'pl'
    seed = 1234
    data_provider = PolandSpecProvider(locale, seed)

    # THEN
    assert data_provider is not None

# Generated at 2022-06-23 20:42:38.673688
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    psp = PolandSpecProvider()
    assert len(str(psp.regon())) == 9

# Generated at 2022-06-23 20:42:39.463863
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    assert provider is not None


# Generated at 2022-06-23 20:42:41.811181
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    p = PolandSpecProvider()
    assert p.__class__.__name__ == 'PolandSpecProvider'


# Generated at 2022-06-23 20:42:46.186442
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    plspec = PolandSpecProvider(seed=0)
    pesel = plspec.pesel(birth_date=Datetime(seed=0).datetime(1940, 2018), gender=Gender.MALE)
    assert pesel.endswith('1')


# Generated at 2022-06-23 20:42:51.336634
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider()
    regon = provider.regon()
    assert len(regon) == 9
    assert int(regon[8]) == sum([int(r) * w for r, w in zip(regon, (8,9,2,3,4,5,6,7))]) % 11
    

# Generated at 2022-06-23 20:42:53.663638
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    p1 = PolandSpecProvider()
    nip = p1.nip()
    assert nip != None


# Generated at 2022-06-23 20:42:57.644818
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    poland_spec_provider = PolandSpecProvider()
    assert poland_spec_provider.__class__.__name__ == "PolandSpecProvider"
    assert poland_spec_provider._meta.name == "poland_provider"
    assert poland_spec_provider._meta.locale == "pl"


# Generated at 2022-06-23 20:42:59.973533
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    result = provider.nip()
    assert type(result) == str


# Generated at 2022-06-23 20:43:03.975243
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # Given
    random = PolandSpecProvider()

    # When
    m = random.pesel(birth_date=None, gender=Gender.MALE)
    f = random.pesel(birth_date=None, gender=Gender.FEMALE)
    a = random.pesel(birth_date=None, gender=None)
    assert m[len(m)-1] in ('1', '3', '5', '7', '9')
    assert f[len(f)-1] in ('0', '2', '4', '6', '8')


# Generated at 2022-06-23 20:43:05.131159
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    PolandSpecProvider().nip()


# Generated at 2022-06-23 20:43:07.244629
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    pl_provider = PolandSpecProvider()
    pesel = pl_provider.regon()
    print(pesel)


# Generated at 2022-06-23 20:43:10.197132
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    assert isinstance(provider.nip(), str)
    assert isinstance(provider.pesel(), str)
    assert isinstance(provider.regon(), str)

# Generated at 2022-06-23 20:43:12.955529
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    poland_provider = PolandSpecProvider()
    assert poland_provider.nip() == '5212303010'

# Generated at 2022-06-23 20:43:15.543606
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
  poland = PolandSpecProvider()

  assert poland.provider.__class__.__name__ == 'PolandProvider'
  assert poland.__dict__ == poland.provider.__dict__


# Generated at 2022-06-23 20:43:17.944580
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    global regon
    
    def regon():
        P = PolandSpecProvider()
        return P.regon()

    poland_regon = regon()
    assert len(poland_regon) == 9


# Generated at 2022-06-23 20:43:20.583382
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()

# Generated at 2022-06-23 20:43:23.008722
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    print(PolandSpecProvider().nip())
    print(PolandSpecProvider().pesel())
    print(PolandSpecProvider().regon())

# Generated at 2022-06-23 20:43:24.893042
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Test for constructor of class PolandSpecProvider."""
    PolandSpecProvider()



# Generated at 2022-06-23 20:43:34.474578
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pol = PolandSpecProvider(seed=0)
    pesel = pol.pesel(datetime.datetime.now(), Gender.MALE)
    assert isinstance(pesel, str)
    assert len(pesel) == 11
    assert pesel == '87101804380'
    pesel = pol.pesel(datetime.datetime.now(), Gender.FEMALE)
    assert isinstance(pesel, str)
    assert len(pesel) == 11
    assert pesel == '04121657308'
    pesel = pol.pesel(datetime.datetime.now())
    assert isinstance(pesel, str)
    assert len(pesel) == 11
    assert pesel == '67022213125'


# Generated at 2022-06-23 20:43:36.520623
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    print(provider.nip())
    print(provider.pesel())
    print(provider.regon())

# Generated at 2022-06-23 20:43:38.946073
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pl_provider = PolandSpecProvider()
    pesel = pl_provider.pesel()
    assert len(str(pesel)) == 11

# Generated at 2022-06-23 20:43:42.424416
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel(birth_date=Datetime().datetime(1980, 1959))
    assert len(pesel) == 11


# Generated at 2022-06-23 20:43:46.190340
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    # Setup PolandSpecProvider
    poland_provider = PolandSpecProvider()

    # Test regon method of PolandSpecProvider
    assert len(poland_provider.regon()) == 9


# Generated at 2022-06-23 20:43:47.971792
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    assert (len(PolandSpecProvider().nip()) == 10)
    assert (PolandSpecProvider(seed=0).nip() == "17331104")


# Generated at 2022-06-23 20:43:51.218797
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test nip."""
    provider = PolandSpecProvider()
    res = provider.nip()
#    print("NIP:"+res)
    assert len(res) == 10


# Generated at 2022-06-23 20:43:53.572041
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    poland = PolandSpecProvider()
    assert poland.nip()
    assert poland.regon()
    assert poland.pesel()

# Generated at 2022-06-23 20:43:55.466560
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    assert provider.nip()
    assert provider.pesel()
    assert provider.regon()

# Generated at 2022-06-23 20:44:02.772561
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    obj = PolandSpecProvider()
    assert obj._locale == 'pl', "Should be 'pl'"
    assert obj.nip() == '8441148662', "Should be '8441148662'"
    assert obj.nip() != '8441148662', "Should not be '8441148662'"
    assert obj.pesel() == '47113010426', "Should be '47113010426'"
    assert obj.pesel() != '47113010426', "Should not be '47113010426'"
    assert obj.regon() == '123456784', "Should be '123456784'"
    assert obj.regon() != '123456784', "Should not be '123456784'"

# Generated at 2022-06-23 20:44:06.688222
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider(seed=123)
    assert provider.NIP() == "8369844137"
    assert provider.PESEL() == "88122272120"
    assert provider.REGON() == "381121076"
    assert provider.nip() == "8369844137"
    assert provider.pesel() == "88122272120"
    assert provider.regon() == "381121076"

# Generated at 2022-06-23 20:44:09.540928
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    provider.seed(seed=1)
    assert provider.pesel() == "80051401358"
    assert provider.pesel(const.GENDER_MALE) == "71061301465"

# Generated at 2022-06-23 20:44:12.272185
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Unit test for PolandSpecProvider - method nip"""
    
    p = PolandSpecProvider()
    assert p.nip() != p.nip()


# Generated at 2022-06-23 20:44:13.902246
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    result = provider.nip()
    assert(type(result) == str)
    assert(len(result) == 10)


# Generated at 2022-06-23 20:44:16.519335
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    x = PolandSpecProvider()
    a = x.pesel()
    print(a)

# Generated at 2022-06-23 20:44:21.152369
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Unit test for method regon of class PolandSpecProvider"""
    psp = PolandSpecProvider()
    regon = psp.regon()
    assert regon.isdigit()
    assert len(regon) == 9


# Generated at 2022-06-23 20:44:24.934707
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    # check length
    assert len(PolandSpecProvider().nip()) == 10
    # check value
    assert PolandSpecProvider().nip() != '111111111'
    assert PolandSpecProvider().nip() != '0000000000'


# Generated at 2022-06-23 20:44:26.316135
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    print(provider.pesel())


# Generated at 2022-06-23 20:44:30.533186
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    nip = provider.nip()
    assert len(nip) == 10, f'Length of nip was {len(nip)}'
    pesel = provider.pesel()
    assert len(pesel) == 11, f'Length of pesel was {len(pesel)}'
    regon = provider.regon()
    assert len(regon) == 9, f'Length of regon was {len(regon)}'
    # TODO: Add test to check the checksum of nip, pesel and regon

# Generated at 2022-06-23 20:44:32.958787
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    for i in range(100):
        print(PolandSpecProvider().pesel())


# Generated at 2022-06-23 20:44:36.049353
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    provider.seed(13)
    assert provider.nip() == '7663737276'



# Generated at 2022-06-23 20:44:38.307823
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel_object = PolandSpecProvider()
    pesel = pesel_object.pesel()
    assert len(pesel) == 11


# Generated at 2022-06-23 20:44:40.981395
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    c = PolandSpecProvider();
    c.nip();
    c.pesel();
    c.regon();

# Generated at 2022-06-23 20:44:42.354027
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    assert len(PolandSpecProvider().nip()) == 10


# Generated at 2022-06-23 20:44:46.368875
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    ob = PolandSpecProvider()
    assert ob.nip()
    assert ob.pesel()
    assert ob.regon()
    assert ob.name
    assert ob.__dict__

# Generated at 2022-06-23 20:44:48.244859
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Unit test for constructor of class PolandSpecProvider."""
    ps = PolandSpecProvider()
    assert ps
    

# Generated at 2022-06-23 20:44:51.792831
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Test PolandSpecProvider class method nip."""
    assert all(int(d) < 10 for d in PolandSpecProvider().nip())
    assert all(int(d) < 10 for d in PolandSpecProvider().nip())


# Generated at 2022-06-23 20:44:57.694225
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider(seed=0)
    result = provider.pesel(birth_date=provider.datetime(1940, 2018), gender=0)
    result2 = provider.pesel(birth_date=provider.datetime(1940, 2018), gender=1)
    assert result == '02030207172'
    assert result2 == '01180823002'


# Generated at 2022-06-23 20:45:01.227681
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    nip = provider.nip()
    assert nip.isnumeric() and len(nip) == 10


# Generated at 2022-06-23 20:45:03.249129
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider()
    regon = provider.regon()
    assert len(regon) == 9

# Generated at 2022-06-23 20:45:08.658649
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    from datetime import datetime
    from mimesis.enums import Gender
    # Without input arguments
    pesel = PolandSpecProvider().pesel()
    assert len(pesel) == 11 and pesel.isnumeric()
    # With input arguments
    pesel = PolandSpecProvider().pesel(birth_date=datetime(1999, 12, 12), gender=Gender.MALE)
    assert len(pesel) == 11 and pesel.isnumeric()
  

 

# Generated at 2022-06-23 20:45:16.792422
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    assert provider.nip() == '282-97-45-265'
    assert provider.nip() == '765-78-74-879'
    assert provider.nip() != '765-78-74-878'

    assert provider.pesel() == '84130482977'
    assert provider.pesel() != '84130482978'

    assert provider.regon() == '476499358'
    assert provider.regon() == '819163210'
    assert provider.regon() != '819163211'


# Generated at 2022-06-23 20:45:24.656976
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    seed = 1
    provider = PolandSpecProvider(seed)
    result = provider.pesel(gender=Gender.MALE)
    assert result == '91070111177'

    seed = 1
    provider = PolandSpecProvider(seed)
    result = provider.pesel(gender=Gender.MALE)
    assert result == '77051716548'

    seed = 1
    provider = PolandSpecProvider(seed)
    result = provider.pesel(gender=Gender.MALE)
    assert result == '90012315515'

    seed = 1
    provider = PolandSpecProvider(seed)
    result = provider.pesel(gender=Gender.MALE)
    assert result == '79120475172'

    seed = 1
    provider = PolandSpecProvider(seed)

# Generated at 2022-06-23 20:45:32.962829
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    from datetime import datetime
    from mimesis.enums import Gender
    import random
    x = PolandSpecProvider()
    pesel_1 = x.pesel(birth_date=datetime(2000,11,30), gender=Gender.FEMALE)

# Generated at 2022-06-23 20:45:34.398811
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    print(PolandSpecProvider().pesel())


# Generated at 2022-06-23 20:45:35.862827
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    result = PolandSpecProvider().pesel()
    assert result



# Generated at 2022-06-23 20:45:37.926224
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pl = PolandSpecProvider(seed=4)
    pesel = pl.pesel()
    assert pesel == '51060115808'


# Generated at 2022-06-23 20:45:39.525675
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pl = PolandSpecProvider()
    a = pl.pesel()
    b = pl.pesel()
    assert a != b


# Generated at 2022-06-23 20:45:43.361683
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Test regon method."""
    provider = PolandSpecProvider()
    regon = provider.regon()
    assert len(regon) is 9
    assert regon.isdigit() is True

# Generated at 2022-06-23 20:45:44.700822
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    assert PolandSpecProvider().nip() == '2021003311'


# Generated at 2022-06-23 20:45:46.693084
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    p = PolandSpecProvider()
    assert int(p.regon()) > 0 and int(p.regon()) < 1000000000


# Generated at 2022-06-23 20:45:50.749289
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    S = PolandSpecProvider()
    pesel = S.pesel()
    nip = S.nip()
    regon = S.regon()
    assert len(pesel) == 11
    assert len(nip) == 10
    assert len(regon) == 9

# Generated at 2022-06-23 20:45:54.213758
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Test for PolandSpecProvider class."""
    x = PolandSpecProvider(seed="Hello")
    assert x is not None
    assert x._meta.name == 'poland_provider'


# Generated at 2022-06-23 20:45:56.186256
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    obj = PolandSpecProvider()
    assert type(obj.regon()) == str

# Generated at 2022-06-23 20:46:01.907543
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    res = p.pesel(birth_date = Datetime().datetime(), gender = Gender.MALE)
    print(res)
    res1 = p.pesel(birth_date = Datetime().datetime(), gender = Gender.FEMALE)
    print(res1)
    res2 = p.pesel(birth_date = Datetime().datetime(), gender = Gender.NOT_KNOWN)
    print(res2)


# Generated at 2022-06-23 20:46:13.016730
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Unit test for method nip of class PolandSpecProvider."""
    print("Testing PolandSpecProvider.nip()...")
    # Initialize PolandSpecProvider and Datetime
    pl = PolandSpecProvider()
    dt = Datetime()

    print("  Testing 8 random NIPs...")
    print("(Call this test again if any of them are wrong)")
    for i in range(8):
        nip = pl.nip()
        assert len(nip) == 10, \
            "Result nip has length {}, should be 10".format(len(nip))
        assert nip.isnumeric(), "Result nip has non-numeric characters"
        print("  NIP #{}: {}".format(i+1, nip))

    print("  Testing NIP of myself...")

# Generated at 2022-06-23 20:46:14.853390
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    o = PolandSpecProvider()
    assert o.__class__.__name__ == 'PolandSpecProvider'
    assert o.provider == 'poland_provider'


# Generated at 2022-06-23 20:46:22.738769
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    from mimesis.providers import PolandSpecProvider
    from mimesis.providers.utils import calc_luhn_checksum
    from mimesis.providers.utils import calculate_luhn
    
    print("\nPrinting function nip of class PolandSpecProvider")
    pol = PolandSpecProvider()
    nip = pol.nip()
    print("\n NIP: ", nip)
    print("\n Validation: ",calc_luhn_checksum(nip,9))
    print("\n Validation: ", calculate_luhn(nip, 9))
    
test_PolandSpecProvider_nip()


# Generated at 2022-06-23 20:46:28.150822
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    for _ in range(100):
        provider = PolandSpecProvider()
        provider.nip()

    # Check if method nip of class PolandSpecProvider is working properly with seed value
    provider = PolandSpecProvider(seed=1000)
    assert provider.nip() == '1871836260'


# Generated at 2022-06-23 20:46:30.219057
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Test method nip of class PolandSpecProvider."""
    assert PolandSpecProvider().nip() == "3553865416"


# Generated at 2022-06-23 20:46:37.458863
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Unit test for constructor of class PolandSpecProvider."""
    seed = '3d11b4ee4c79a4bcec0b9d945d64cbc7'
    p = PolandSpecProvider(seed=seed)
    assert p.nip() == '1722027894'
    assert p.regon() == '04462417'
    assert p.pesel(birth_date = Datetime().datetime(2005, 2018)) == '05051991608'

# Generated at 2022-06-23 20:46:41.299720
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Unit test for method nip of class PolandSpecProvider."""
    polish_provider = PolandSpecProvider()
    result = polish_provider.nip()
    assert len(result) == 10
    assert int(result)


# Generated at 2022-06-23 20:46:42.794611
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    print('Testing constructor of class PolandSpecProvider')
    assert PolandSpecProvider() is not None
    print('Passed test')


# Generated at 2022-06-23 20:46:48.861557
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    pl = PolandSpecProvider()
    regon = pl.regon()
    nums = [int(d) for d in str(regon)]
    regon_coeffs = (8, 9, 2, 3, 4, 5, 6, 7)
    sum = sum([nc * nd for nc, nd in zip(regon_coeffs, nums[0:8])])
    checksum = sum % 11
    if checksum > 9:
        checksum = 0
    print(regon)
    assert nums[8] == checksum


# Generated at 2022-06-23 20:46:51.391880
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    nip = PolandSpecProvider().nip()
    print(nip)
    assert len(nip) == 10


# Generated at 2022-06-23 20:46:54.750514
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Test the validity of the regon method in the PolandSpecProvider class."""
    pl = PolandSpecProvider()
    regon = pl.regon()
    assert len(regon) == 9
    assert regon.isdigit()

# Generated at 2022-06-23 20:46:59.730708
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    regon_list = []
    for i in range(1, 10):
        regon_list.append(i)
    psp = PolandSpecProvider()
    for i in range(1000):
        regon = int(psp.regon())
        if regon in regon_list:
            regon_list.remove(regon)
    assert (len(regon_list) == 0)


# Generated at 2022-06-23 20:47:01.041607
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider()
    regon_result = provider.regon()
    assert not int(regon_result[8]) == 7

# Generated at 2022-06-23 20:47:03.003436
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    obj = PolandSpecProvider()
    assert obj is not None

# Generated at 2022-06-23 20:47:12.605552
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider(seed=4839)
    result = provider.pesel()
    assert result == '10050234444'
    args = '1990-05-02',
    result = provider.pesel(*args)
    assert result == '90050234444'
    args = '1990-05-02',
    kwargs = {'gender': Gender.MALE}
    result = provider.pesel(*args, **kwargs)
    assert result == '90050231414'
    args = '1990-05-02',
    kwargs = {'gender': Gender.FEMALE}
    result = provider.pesel(*args, **kwargs)
    assert result == '90050236464'