

# Generated at 2022-06-23 20:37:09.463176
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    ppl = PolandSpecProvider()
    pesel = ppl.pesel()
    assert len(pesel) == 11


# Generated at 2022-06-23 20:37:13.406573
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
	regon = PolandSpecProvider().regon()
	assert len(regon) == 9
	assert regon[8] == str(sum([int(digit) * pow(2, idx % 8)
		for idx, digit in enumerate(regon)]) % 11 % 10)


# Generated at 2022-06-23 20:37:17.419184
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    s = PolandSpecProvider(seed=123456)
    assert s.regon() == '96713171'
    s = PolandSpecProvider(seed=654321)
    assert s.regon() == '03012792'

# Generated at 2022-06-23 20:37:23.494785
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    p = PolandSpecProvider()
    N = 10000
    for _ in range(N):
        nip = p.nip()
        assert len(nip) == 10
        assert type(nip) == str
    for _ in range(N):
        pesel = p.pesel()
        assert len(pesel) == 11
        assert type(pesel) == str
    for _ in range(N):
        regon = p.regon()
        assert len(regon) == 9
        assert type(regon) == str

# Generated at 2022-06-23 20:37:25.124216
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    p = PolandSpecProvider(seed=2)
    assert p.regon() == 31481639


# Generated at 2022-06-23 20:37:28.216937
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider(seed=987654321)
    assert provider.pesel() == '96122649393'


if __name__ == '__main__':
    pesel = PolandSpecProvider.pesel()
    print(type(pesel))

# Generated at 2022-06-23 20:37:30.080516
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    p = PolandSpecProvider()
    pesel = p.nip()
    print(pesel)


# Generated at 2022-06-23 20:37:37.737474
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider"""
    from mimesis.providers import PolandSpecProvider
    from mimesis.enums import Gender
    pl = PolandSpecProvider()
    pesel_1 = pl.pesel(gender=Gender.MALE)
    pesel_2 = pl.pesel(gender=Gender.FEMALE)
    print(pesel_1)
    print(pesel_2)
    assert len(pesel_1) == 11
    assert len(pesel_2) == 11


# Generated at 2022-06-23 20:37:40.420174
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Unit test for method regon of class PolandSpecProvider."""
    from rstr import rstr
    provider = PolandSpecProvider(seed=12345)
    regon = provider.regon()
    assert len(regon) == 9 and regon == rstr('[0-9]', 9, seed=12345)

# Generated at 2022-06-23 20:37:42.415733
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    p = PolandSpecProvider()
    nip = p.nip()
    assert (type(nip) == str) and (len(nip) == 10)


# Generated at 2022-06-23 20:37:43.774872
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    p = PolandSpecProvider()
    assert p is not None, "PolandSpecProvider is not None"


# Generated at 2022-06-23 20:37:45.692347
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    PolandSpecProvider().pesel()

# Generated at 2022-06-23 20:37:51.215622
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    pl_provider = PolandSpecProvider()
    assert pl_provider.nip()
    assert pl_provider.pesel()
    assert pl_provider.regon()
#print(PolandSpecProvider.__init__.__doc__)
#print(PolandSpecProvider.nip.__doc__)
#print(PolandSpecProvider.pesel.__doc__)
#print(PolandSpecProvider.regon.__doc__)
test_PolandSpecProvider()

# Generated at 2022-06-23 20:37:55.283569
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Test PolandSpecProvider class."""
    p = PolandSpecProvider()
    assert p.nip() == "8871788402"
    assert p.pesel() ==  "13081240473"
    assert p.regon() == "169005750"

# Generated at 2022-06-23 20:38:01.870082
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    pesel = PolandSpecProvider().regon()
    assert len(pesel) == 9
    assert pesel.isdigit()
    assert 0 <= int(pesel[0]) <= 9
    assert 0 <= int(pesel[1]) <= 9
    assert 0 <= int(pesel[2]) <= 9
    assert 0 <= int(pesel[3]) <= 9
    assert 0 <= int(pesel[4]) <= 9
    assert 0 <= int(pesel[5]) <= 9
    assert 0 <= int(pesel[6]) <= 9
    assert 0 <= int(pesel[7]) <= 9
    assert 0 <= int(pesel[8]) <= 9

# Generated at 2022-06-23 20:38:03.997011
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():

    provider = PolandSpecProvider()
    regon = provider.regon()
    should_be = "484465285"
    assert regon == should_be

# Generated at 2022-06-23 20:38:05.747973
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel1= PolandSpecProvider().pesel()
    assert len(pesel1)==11


# Generated at 2022-06-23 20:38:07.785409
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    assert provider.__class__.__name__ == 'PolandSpecProvider'


# Generated at 2022-06-23 20:38:09.563359
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
  assert type(poland_spec_provider) is PolandSpecProvider

# Unit tests for the method nip

# Generated at 2022-06-23 20:38:18.567035
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Test that the REGON checksum digit is calculated correctly."""
    # Example of a valid REGON
    regon = PolandSpecProvider().regon()
    regon_digits = [int(d) for d in regon]
    regon_coeffs = (8, 9, 2, 3, 4, 5, 6, 7)
    # Checksum digit should be the last digit of regon_check_sum
    regon_check_sum = sum([nc * nd for nc, nd in zip(regon_coeffs, regon_digits)])
    checksum_digit = regon_check_sum % 11
    if checksum_digit > 9:
        checksum_digit = 0

    assert regon_digits[8] == checksum_digit


# Generated at 2022-06-23 20:38:21.717663
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test for pesel method of PolandSpecProvider class."""
    poland_provider = PolandSpecProvider()
    assert len(poland_provider.pesel()) == 11



# Generated at 2022-06-23 20:38:23.323965
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    psp = PolandSpecProvider()
    assert str(psp) == 'Poland Spec Provider'


# Generated at 2022-06-23 20:38:25.259230
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Unit test for constructor of class PolandSpecProvider"""
    PolandSpecProvider()


# Generated at 2022-06-23 20:38:27.596200
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    assert provider.get_formatter() is None
    assert provider.get_locale() == 'pl'
    assert provider.get_seed() is not None

# Generated at 2022-06-23 20:38:29.105950
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    p = PolandSpecProvider()
    assert len(p.nip()) == 10


# Generated at 2022-06-23 20:38:33.731297
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # Initializing the PolandSpecProvider
    polandProvider = PolandSpecProvider(seed=1)
    
    #Testing the method pesel, with gender male
    assert polandProvider.pesel(gender = Gender.MALE) == '85032404772'

    #Testing the method pesel, with gender female
    assert polandProvider.pesel(gender = Gender.FEMALE) == '85032404784'


# Generated at 2022-06-23 20:38:36.797678
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    for i in range(10):
        result = provider.nip()
        print(result)


# Generated at 2022-06-23 20:38:39.774457
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    assert PolandSpecProvider().pesel() == '59091914198'
    assert PolandSpecProvider().pesel(gender=Gender.MALE) == '67111815446'
    

# Generated at 2022-06-23 20:38:41.563499
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    assert bool(PolandSpecProvider())
    PolandSpecProvider(seed=42)

# Generated at 2022-06-23 20:38:42.899923
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    pol = PolandSpecProvider()
    print(pol.regon())

# Generated at 2022-06-23 20:38:48.212939
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    d = PolandSpecProvider()

    assert d.locale == 'pl'

    assert d.datetime() != d.datetime()
    assert d.datetime(datetime_format='%d.%m.%Y %H:%M:%S') != d.datetime(datetime_format='%d.%m.%Y %H:%M:%S')


# Generated at 2022-06-23 20:38:49.768617
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    poland= PolandSpecProvider()
    result = poland.regon()
    print(result)


# Generated at 2022-06-23 20:38:57.414789
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    print("Testing method nip of class PolandSpecProvider")

# Generated at 2022-06-23 20:39:04.423193
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    for i in range(10):
        nip = provider.nip()
        assert len(nip) == 10
        assert int(nip[:3]) >= 101 and int(nip[:3]) <= 998
        assert int(nip[3:9]) >= 0 and int(nip[3:9]) <= 999999
        assert int(nip[9]) >= 0 and int(nip[9]) <= 9


# Generated at 2022-06-23 20:39:05.752114
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    regon = PolandSpecProvider().regon()
    assert len(regon) == 9


# Generated at 2022-06-23 20:39:07.870170
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    result = provider.nip()
    assert len(result) == 10
    assert result.isdigit()


# Generated at 2022-06-23 20:39:09.430193
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    try:
        PolandSpecProvider()
    except Exception as e:
        assert False, e

#Unit test for pesel()

# Generated at 2022-06-23 20:39:10.882478
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    assert len(PolandSpecProvider().nip()) == 10



# Generated at 2022-06-23 20:39:15.294422
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Test."""
    provider = PolandSpecProvider()
    provider.seed(4)
    for _ in range(20):
        regon = provider.regon()
        assert regon == '679315751'
    for _ in range(20):
        regon = provider.regon()
        assert regon == '636987756'

# Generated at 2022-06-23 20:39:17.118374
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    print("NIP: " + provider.nip())


# Generated at 2022-06-23 20:39:18.424147
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    assert PolandSpecProvider().nip().isdigit()


# Generated at 2022-06-23 20:39:20.779339
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    assert str == type(PolandSpecProvider().pesel(gender=Gender.FEMALE))
    assert len(PolandSpecProvider().pesel(gender=Gender.MALE)) == 11

# Generated at 2022-06-23 20:39:22.324396
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    poland_spec_provider = PolandSpecProvider()
    assert poland_spec_provider

# Generated at 2022-06-23 20:39:29.662700
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Test method 'nip' of class PolandSpecProvider.

        Args:
            None.
        Returns:
            None.
        """
    result1 = PolandSpecProvider(seed=123).nip()
    assert len(result1) == 10

    result2 = PolandSpecProvider(seed=123).nip()
    result3 = PolandSpecProvider(seed=123).nip()
    assert result2 == result3

    result4 = PolandSpecProvider(seed=456).nip()
    assert result4 != result3



# Generated at 2022-06-23 20:39:32.721983
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    pl = PolandSpecProvider()
    assert pl.pesel(gender=Gender.MALE)
    assert pl.pesel(gender=Gender.FEMALE)
    assert pl.pesel(birth_date=Datetime().datetime(1950, 2000))


# Generated at 2022-06-23 20:39:34.397064
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    assert len(PolandSpecProvider().regon()) == 9

# Generated at 2022-06-23 20:39:36.061455
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    assert provider.nip()



# Generated at 2022-06-23 20:39:42.619586
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    pesel_int = int(pesel)
    year = pesel_int // 10000000
    if year < 18:
        year += 2000
    else:
        year += 1900
    month = (pesel_int // 1000000) % 100
    if month > 80:
        month -= 80
    if month > 20:
        month -= 20
    if month > 40:
        month -= 40
    if month > 60:
        month -= 60
    day = (pesel_int // 10000) % 100
    assert 1 <= day <= 31
    assert 1 <= month <= 12
    datetime_provider = Datetime()

# Generated at 2022-06-23 20:39:45.808513
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()



# Generated at 2022-06-23 20:39:50.312154
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel(birth_date=datetime.datetime(1987, 6, 21), gender=Gender.MALE)
    assert pesel == '87062161496'

test_PolandSpecProvider_pesel()



# Generated at 2022-06-23 20:39:54.756771
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    assert PolandSpecProvider().pesel() == '37042923985'
    assert PolandSpecProvider().pesel(birth_date='1.5.1945', gender='Male') == '45050100866'
    assert PolandSpecProvider().pesel(birth_date='1.5.1945', gender='Female') == '45050111066'


# Generated at 2022-06-23 20:40:02.260852
# Unit test for method nip of class PolandSpecProvider

# Generated at 2022-06-23 20:40:04.174959
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    temp = PolandSpecProvider(seed=0)
    assert temp.nip() == '5410148368'


# Generated at 2022-06-23 20:40:07.733871
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    test_poland_date = Datetime.from_timestamp(1318781876)
    test_poland_pesel = PolandSpecProvider().pesel(test_poland_date, Gender.MALE)
    if test_poland_pesel == "44071401358":
        # print("OK")
        pass
    else:
        print("ERROR")
        print("Expected: 44071401358")
        print("Actual: {}".format(test_poland_pesel))


# Generated at 2022-06-23 20:40:10.735272
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    gen = PolandSpecProvider()
    s = gen.regon()
    assert type(s) == str and len(s) == 9

# Generated at 2022-06-23 20:40:11.997985
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Test for PolandSpecProvider method - regon."""
    assert isinstance(PolandSpecProvider().regon(), str) and PolandSpecProvider().regon().isnumeric()


# Generated at 2022-06-23 20:40:14.947178
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    import datetime
    from mimesis.enums import Gender
    provider = PolandSpecProvider()
    date_time = datetime.datetime(1970, 12, 12)
    provider.pesel(birth_date=date_time, gender=Gender.MALE)

# Generated at 2022-06-23 20:40:25.785874
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    '''
    1. Generate 10^4 examples of 9-digit REGON
    2. Check whether the generated REGON matches the REGON generation algorithm
    3. Check how many examples are not repeatable
    '''
    from mimesis.providers import PolandSpecProvider
    from mimesis.enums import Gender
    from random import randint
    from random import seed

    example_number = 10000
    counter = 0
    test_result = [0] * example_number

    for x in range(example_number):
        poland_provider = PolandSpecProvider(seed=x)
        regon = poland_provider.regon()
        regon_coeffs = (8, 9, 2, 3, 4, 5, 6, 7)
        regon_digits = [regon[i] for i in range(8)]

# Generated at 2022-06-23 20:40:26.394419
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    PolandSpecProvider()

# Generated at 2022-06-23 20:40:30.515473
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    class PolandSpecProvider1(PolandSpecProvider):
        def __init__(self):
            super().__init__()
    a = PolandSpecProvider1()
    result = a.pesel()
    print(result)
    assert(len(result) == 11)


# Generated at 2022-06-23 20:40:34.628326
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    PESEL = PolandSpecProvider(seed=100)
    pesel = PESEL.pesel(birth_date=PESEL.datetime(1940, 2018), gender = Gender.MALE)
    print(pesel)
    assert pesel == '08012700639'


# Generated at 2022-06-23 20:40:36.466879
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    pesel = PolandSpecProvider()
    assert len(pesel.nip()) == 10



# Generated at 2022-06-23 20:40:39.120705
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    x = PolandSpecProvider()
    y = x.regon()
    assert len(y) == 9
    assert x.validate('regon', y)
    assert not x.validate('regon', '12345')


# Generated at 2022-06-23 20:40:39.593835
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    obj = PolandSpecProvider()



# Generated at 2022-06-23 20:40:41.299131
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    p = PolandSpecProvider()
    regon = p.regon()
    assert len(regon) == 9


# Generated at 2022-06-23 20:40:43.454080
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    ass=PolandSpecProvider()
    assert ass.nip()
    assert ass.pesel(None,None)
    assert ass.regon()

# Generated at 2022-06-23 20:40:45.170824
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    pesel = PolandSpecProvider()
    r = pesel.regon()
    assert r == str(987654321)

# Generated at 2022-06-23 20:40:48.322535
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider()
    regon = provider.regon()
    assert isinstance(regon, str)
    assert len(regon) == 9


# Generated at 2022-06-23 20:40:50.083629
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    assert PolandSpecProvider()


# Generated at 2022-06-23 20:40:50.691663
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    PolandSpecProvider()

# Generated at 2022-06-23 20:40:56.511741
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # date_object = Datetime().datetime(1940, 2018)
    # year = date_object.date().year
    # month = date_object.date().month
    # day = date_object.date().day
    provider = PolandSpecProvider()

    for i in range(10):
        for g in (Gender.FEMALE, Gender.MALE, None):
            print(i, g, provider.pesel(gender=g))

# Generated at 2022-06-23 20:40:58.724007
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Test valid regon number."""
    ps = PolandSpecProvider(seed=1)
    assert ps.regon() == '924204084'


# Generated at 2022-06-23 20:41:00.596860
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    pl_provider = PolandSpecProvider()

    print("test_PolandSpecProvider_nip()")
    for i in range(0, 100):
        print(pl_provider.nip())



# Generated at 2022-06-23 20:41:01.698073
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    assert len(provider.nip()) == 10


# Generated at 2022-06-23 20:41:02.766006
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    assert provider.pesel() == '91510207463'

# Generated at 2022-06-23 20:41:07.415113
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    nipGenerator = PolandSpecProvider()
    nip = nipGenerator.nip()
    print(nip)
    assert nipGenerator.validate_nip(nip)


# Generated at 2022-06-23 20:41:08.548665
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider()
    regon = provider.regon()
    assert len(regon) == 9
    assert 9 + 2 == 11  # for readibility


# Generated at 2022-06-23 20:41:10.889114
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    p = PolandSpecProvider(seed=655321)
    for _ in range(100):
        print(p.regon())



# Generated at 2022-06-23 20:41:14.265161
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    from mimesis.enums import Gender
    p = PolandSpecProvider()
    for i in range(10):
        pesel = p.pesel(gender=Gender.MALE)
        assert len(pesel) == 11


# Generated at 2022-06-23 20:41:20.064905
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    import re
    p = PolandSpecProvider(seed = 0)
    regon = p.regon()
    print('regon: ',regon)
    sum = 0
    # Check if regon has 9 digits
    assert re.match(r'[0-9]{9}$', str(regon))
    for i in range(len(str(regon))-1):
        product = int(str(regon)[i]) * (8-i)
        sum = sum + product
    sum = sum % 11
    # check whether last digit is equal to the sum
    assert sum == int(str(regon)[-1])


# Generated at 2022-06-23 20:41:25.424653
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Run unitest for class PolandSpecProvider and method regon."""
    print('test_PolandSpecProvider.regon')
    data = {}
    provider = PolandSpecProvider()
    for i in range(100):
        regon = provider.regon()
        if regon in data:
            data[regon] += 1
        else:
            data[regon] = 1
    for key, value in data.items():
        print(key, value)
        assert value == 1


# Generated at 2022-06-23 20:41:29.529731
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    p = PolandSpecProvider()
    a = p.nip()
    b = p.pesel()
    c = p.regon()
    print(a, b, c)



# Generated at 2022-06-23 20:41:34.048992
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    testee = PolandSpecProvider()

    result = testee.pesel(gender = Gender.MALE)
    assert len(result) == 11

    result = testee.pesel(gender = Gender.FEMALE)
    assert len(result) == 11

    result = testee.pesel(gender = None)
    assert len(result) == 11


# Generated at 2022-06-23 20:41:36.682484
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    pola = PolandSpecProvider()
    assert pola.nip()
    assert pola.pesel()
    assert pola.regon()

# Generated at 2022-06-23 20:41:38.264669
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    assert provider.provider == 'pl'

# Generated at 2022-06-23 20:41:40.636165
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    "Test if the pesel returned is right"
    s = PolandSpecProvider("1234")
    assert s.pesel() == "981201340"

# Generated at 2022-06-23 20:41:44.647427
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Test for nip function."""
    pl_spec_provider = PolandSpecProvider()
    nip = pl_spec_provider.nip()
    assert len(nip) == 10
    assert nip.isdigit()


# Generated at 2022-06-23 20:41:51.913201
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider()
    regon = provider.regon()
    regon_digits = [int(d) for d in regon]
    regon_coeffs = (8, 9, 2, 3, 4, 5, 6, 7)
    sum_v = sum([nc * nd for nc, nd in zip(regon_coeffs, regon_digits)])
    checksum_digit = sum_v % 11
    if checksum_digit > 9:
        checksum_digit = 0
    assert regon_digits[8] == checksum_digit
    print(regon)


# Generated at 2022-06-23 20:41:59.848908
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Testing method regon of class PolandSpecProvider
    :return:
    """

    # Test 1
    pl = PolandSpecProvider()
    regon1 = pl.regon()
    assert type(regon1) == str

    # Test 2
    pl = PolandSpecProvider()
    regon2 = pl.regon()
    assert type(regon2) == str
    assert regon1 != regon2

    # Test 3
    pl = PolandSpecProvider()
    regon3 = pl.regon()
    assert type(regon3) == str
    assert regon2 != regon3


# Generated at 2022-06-23 20:42:01.095788
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    assert isinstance(provider, PolandSpecProvider)


# Generated at 2022-06-23 20:42:02.022032
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    sp = PolandSpecProvider()
    assert isinstance(sp, PolandSpecProvider)

# Generated at 2022-06-23 20:42:10.697956
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider()
    for _ in range(10000):
        regon = provider.regon()
        regon_int = int(regon)
        assert (len(regon) == 9)
        assert (regon_int in range(10000000, 100000000))
        if regon_int <= 10000000: # 1-9
            assert regon_int in range(10000000, 100000000)
        elif regon_int <= 20000000: # 10-99
            assert regon_int in range(10000000, 100000000)
        elif regon_int <= 100000000: # 100-999
            assert regon_int in range(10000000, 100000000)


# Generated at 2022-06-23 20:42:12.543408
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    pesel = PolandSpecProvider()

    result = pesel.regon()

    assert len(str(result)) == 9

# Generated at 2022-06-23 20:42:15.067665
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    p = PolandSpecProvider()
    assert p.regon() == '874288318'

# Generated at 2022-06-23 20:42:24.806686
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Unit test for method regon of class PolandSpecProvider."""
    from mimesis.providers.poland import PolandSpecProvider
    poland_provider = PolandSpecProvider()
    # First 8 digits in the pattern are the sum of products of the
    # coefficients (8, 9, 2, 3, 4, 5, 6, 7) and the first 8 digits of the regon
    # The last digit is the checksum, and it's the sum of products of
    # coefficients  (8, 9, 2, 3, 4, 5, 6, 7) and the first 8 digits of the regon
    # The division of the result by the control digit gives the rest of the
    # division. If the rest is greater than 9, the control digit is 0.
    assert poland_provider.regon() == '033852140'

# Generated at 2022-06-23 20:42:34.838184
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    from mimesis.enums import Gender
    from mimesis.providers import Datetime
    from mimesis.builtins import PolandSpecProvider
    from mimesis import Seed
    import random

    class TestSeed(Seed):
        def get_seed(self, value: int = None) -> int:
            return random.randint(0, 999999999)

    seed = TestSeed()
    provider = PolandSpecProvider(seed=seed)
    datetime = Datetime(seed=seed)

    gender_male = Gender.MALE
    gender_female = Gender.FEMALE
    gender_none = Gender.NONE

    pesel_b1 = provider.pesel(birth_date=datetime.datetime(1960, 1970),
                              gender=gender_male)
    pesel_b2 = provider.pes

# Generated at 2022-06-23 20:42:39.158031
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    my_PolandSpecProvider = PolandSpecProvider(seed=None)
    assert my_PolandSpecProvider.locale == 'pl'
    assert my_PolandSpecProvider.seed is None


# Generated at 2022-06-23 20:42:45.824346
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    import random
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.builtins.pl import PolandSpecProvider
    person = Person("pl")
    list = []
    pl = PolandSpecProvider("PolandSpecProvider")
    for i in range(0, 100):
        # print(person.pesel())
        list.append(pl.regon())
        if i < 5:
            print(list[i])

    print(list)

# Generated at 2022-06-23 20:42:50.191223
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    nip_provider = PolandSpecProvider()
    nip_number = nip_provider.nip()
    assert len(nip_number) == 10
    assert type(nip_number) == str


# Generated at 2022-06-23 20:42:54.107223
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Test if Polish NIP is valid."""
    print("If test_PolandSpecProvider_nip() is successful,\n",
          "then the result is a valid 10-digit NIP.")
    pl = PolandSpecProvider()
    print(pl.nip())



# Generated at 2022-06-23 20:42:56.696345
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    pl = PolandSpecProvider()
    assert pl.__class__.__name__ == 'PolandSpecProvider'


# Generated at 2022-06-23 20:42:59.430284
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    pl_provider = PolandSpecProvider()
    nip_number = pl_provider.nip()
    assert nip_number.isdigit() and len(nip_number) == 10
    pesel_number = pl_provider.pesel()
    assert pesel_number.isdigit() and len(pesel_number) == 11
    regon_number = pl_provider.regon()
    assert regon_number.isdigit() and len(regon_number) == 9

# Generated at 2022-06-23 20:43:00.877092
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    pl = PolandSpecProvider()
    print(pl.nip())
    print(pl.pesel())
    print(pl.regon())

# Generated at 2022-06-23 20:43:04.509506
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Test for method regon."""
    actual = PolandSpecProvider().regon()
    assert len(actual) == 9
    assert actual.isdigit()


# Generated at 2022-06-23 20:43:06.372439
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    assert PolandSpecProvider().provider_name == 'poland_provider'


# Generated at 2022-06-23 20:43:07.750484
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()

    result = provider.nip()

    assert len(result) == 10


# Generated at 2022-06-23 20:43:15.164047
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel(): 
    pesel1 = PolandSpecProvider().pesel(Gender.MALE)
    pesel2 = PolandSpecProvider().pesel(Gender.FEMALE)
    pesel3 = PolandSpecProvider().pesel(Gender.UNKNOWN)
    pesel4 = PolandSpecProvider().pesel(birth_date="1999-01-01",gender=Gender.MALE)
    pesel5 = PolandSpecProvider().pesel(birth_date="1999-01-01",gender=Gender.FEMALE)
    pesel6 = PolandSpecProvider().pesel(birth_date="1999-01-01",gender=Gender.UNKNOWN)

    assert len(pesel1) == 11
    assert len(pesel2) == 11
    assert len(pesel3) == 11
    assert len(pesel4) == 11
    assert len(pesel5)

# Generated at 2022-06-23 20:43:15.549443
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    PolandSpecProvider()

# Generated at 2022-06-23 20:43:18.959672
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider()

    regon = provider.regon()
    assert len(regon) == 9
    assert regon == '881035657'


# Generated at 2022-06-23 20:43:21.355811
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider()
    assert len(provider.regon()) == 9, 'Unexpected length of regon'



# Generated at 2022-06-23 20:43:23.697104
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    _pesel_ret = PolandSpecProvider().pesel()
    assert len(_pesel_ret) == 11
    assert type(_pesel_ret) == str

# Generated at 2022-06-23 20:43:25.794856
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider(seed=4).pesel()
    assert (pesel == "36011812763")


# Generated at 2022-06-23 20:43:28.041723
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    # Test for an empty method
    assert PolandSpecProvider().nip()


# Generated at 2022-06-23 20:43:31.813450
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    assert PolandSpecProvider(seed=5) is not None


if __name__ == "__main__":
    pl = PolandSpecProvider(seed=5)
    print(pl.nip())
    print(pl.pesel())
    print(pl.regon())

# Generated at 2022-06-23 20:43:34.473342
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    poland_provider = PolandSpecProvider()
    items = poland_provider.nip()
    assert poland_provider.validate_nip(items) is True


# Generated at 2022-06-23 20:43:36.213718
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    test = PolandSpecProvider()
    assert len(test.regon()) == 9


# Generated at 2022-06-23 20:43:40.621297
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    from mimesis.builtins import PolandSpecProvider
    poland = PolandSpecProvider()
    test_regon = poland.regon()
    assert type(test_regon) == str
    assert len(test_regon) == 9
    assert test_regon.isdigit() # Check if test_regon consists only of digits 


# Generated at 2022-06-23 20:43:45.066837
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    pol = PolandSpecProvider(seed=4324)
    print(pol.nip())
    print(pol.pesel())
    print(pol.regon())


if __name__ == '__main__':
    test_PolandSpecProvider()

# Generated at 2022-06-23 20:43:48.032571
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Test the correctness of the method nip of class
    PolandSpecProvider"""
    assert len(PolandSpecProvider().nip()) == 10, 'The nip length should be 10'
    assert PolandSpecProvider().nip() != PolandSpecProvider().nip(), 'All nips should be unique'


# Generated at 2022-06-23 20:43:53.800901
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    test_data = (
        (9, '842365861'),
        (0, '810863834')
    )

    poland_provider = PolandSpecProvider()

    for test in test_data:
        provider_seed = test[0]
        expected_result = test[1]
        poland_provider.set_seed(provider_seed)
        generated_result = poland_provider.regon()
        assert generated_result == expected_result


# Generated at 2022-06-23 20:43:59.615224
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # tests if method pesel returns a string and a proper pesel
    pesel = PolandSpecProvider().pesel()
    assert type(pesel) == str
    assert len(pesel) == 11
    assert int(pesel[0]) in range(1, 3)
    for i in range(1, 10):
        assert int(pesel[i]) in range(10)
    assert int(pesel[10]) in range(10)

# test for method nip of class PolandSpecProvider

# Generated at 2022-06-23 20:44:02.379038
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    from mimesis import PolandSpecProvider
    poland_provider = PolandSpecProvider()
    assert isinstance(poland_provider.regon(), str)
    assert len(poland_provider.regon()) == 9

# Generated at 2022-06-23 20:44:04.838227
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Test the method regon of class PolandSpecProvider."""
    p = PolandSpecProvider()
    regon = p.regon()
    expected = 9
    assert len(regon) == expected



# Generated at 2022-06-23 20:44:06.836797
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """
    Test method nip of class PolandSpecProvider.
    """
    p = PolandSpecProvider()
    print(p.nip())


# Generated at 2022-06-23 20:44:09.069378
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    result = provider.nip()
    assert result.isdigit() == True
    assert len(result) == 10


# Generated at 2022-06-23 20:44:10.918166
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    assert isinstance(PolandSpecProvider().regon(), str)
    assert PolandSpecProvider().regon() == '00000000'


# Generated at 2022-06-23 20:44:12.918400
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
	provider = PolandSpecProvider()
	person = provider.pesel()
	return person


# Generated at 2022-06-23 20:44:16.088963
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    np = PolandSpecProvider()
    assert len(np.nip()) == 10


# Generated at 2022-06-23 20:44:17.175218
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    assert PolandSpecProvider().pesel()


# Generated at 2022-06-23 20:44:28.019935
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    # Generate random valid 10-digit NIP
    nip = provider.nip()
    assert isinstance(nip, str)
    assert len(nip) == 10
    # Check if nip is valid
    nip_digits = [int(d) for d in nip]
    nip_coefficients = (6, 5, 7, 2, 3, 4, 5, 6, 7)
    sum_v = sum([nc * nd for nc, nd in zip(nip_coefficients, nip_digits)])
    checksum_digit = sum_v % 11
    if checksum_digit > 9:
        checksum_digit = 0
    assert nip_digits[-1] == checksum_digit


# Generated at 2022-06-23 20:44:32.573654
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel(gender="male")
    assert len(pesel) == 11
    assert(int(pesel[-1]) % 2 == 1)
    #assert(pesel.count("3") == 2)

# Generated at 2022-06-23 20:44:35.741205
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    prov = PolandSpecProvider()
    assert prov.pesel()

# Generated at 2022-06-23 20:44:37.328386
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()

    assert provider.pesel()

# Generated at 2022-06-23 20:44:43.334663
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    assert provider.__class__.__name__ == 'PolandSpecProvider'
    assert provider.country_code == 'PL'
    assert provider.location == 'pl_PL'
    assert provider.provider_name == 'poland_provider'


# Generated at 2022-06-23 20:44:47.322120
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    v = provider.nip()
    print(v)

    assert type(v) == str
    assert len(v) == 10


# Generated at 2022-06-23 20:44:48.632716
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    assert len(PolandSpecProvider().nip()) == 10


# Generated at 2022-06-23 20:44:51.836524
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()
    assert len(get_code(pesel)) == 11
    assert get_code(pesel)[9] == checksum(pesel)


# Generated at 2022-06-23 20:44:53.960467
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    pl_provider = PolandSpecProvider()
    for i in range(0, 15):
        print(pl_provider.regon())


# Generated at 2022-06-23 20:44:57.079827
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test of pesel method.

    :return:
    """
    pesel = PolandSpecProvider().pesel()
    assert len(pesel) == 11
    assert PolandSpecProvider().pesel() != PolandSpecProvider().pesel()

# Generated at 2022-06-23 20:44:57.987523
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    for i in range(1, 1000):
        print(PolandSpecProvider().regon())


# Generated at 2022-06-23 20:45:01.223917
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    ps = PolandSpecProvider()
    assert ps.regon() in ['123456789', '432109876']


# Generated at 2022-06-23 20:45:05.387955
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    p = PolandSpecProvider()
    assert(isinstance(p.nip(), str))
    assert(isinstance(p.pesel(birth_date=Datetime().datetime(),
                              gender=Gender.MALE), str))
    assert(isinstance(p.regon(), str))

# Generated at 2022-06-23 20:45:09.798117
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    from mimesis.enums import Gender
    pesel1 = PolandSpecProvider().pesel(gender=Gender.MALE)
    pesel2 = PolandSpecProvider().pesel(gender=Gender.FEMALE)

    assert len(pesel1) == 11
    assert len(pesel2) == 11
    assert pesel1[-1] in '135790'
    assert pesel2[-1] in '02468'
test_PolandSpecProvider_pesel()

# Generated at 2022-06-23 20:45:11.857603
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Tests for function."""
    psp = PolandSpecProvider()
    assert psp is not None

# Generated at 2022-06-23 20:45:15.340242
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    assert len(provider.nip()) == 10
    assert provider.nip() != provider.nip()
    for i in range(100):
        assert provider.nip() != provider.nip()


# Generated at 2022-06-23 20:45:18.654188
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Test of the nip method."""
    test_object = PolandSpecProvider(seed=42)
    assert len(test_object.nip()) == 10


# Generated at 2022-06-23 20:45:19.527406
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    pl_provider = PolandSpecProvider()
    assert(pl_provider)

# Generated at 2022-06-23 20:45:30.127008
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test pesel method of class PolandSpecProvider."""
    import pytest
    from mimesis.enums import Gender
    from mimesis.providers.datetime import Datetime
    data = [
        (Gender.MALE,),
        (Gender.FEMALE,)
    ]

    seed = 1337
    gender = Gender.MALE
    date_object = Datetime().datetime(1940, 2018)

    for d in data:
        g = d[0]
        p = PolandSpecProvider()
        p.seed(seed)
        pesel = p.pesel(birth_date=date_object, gender=g)
        assert len(pesel) == 11

        # validate pesel
        digits = [int(d) for d in pesel]
        offset = digits[2] - 1
        assert digits

# Generated at 2022-06-23 20:45:34.672252
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    assert provider.__class__.__name__ == 'PolandSpecProvider'
    assert provider._meta.name == 'poland_provider'
    assert provider._meta.local == 'pl'
    assert isinstance(provider.random, Seed)
    assert isinstance(provider.datetime, Datetime)


# Generated at 2022-06-23 20:45:38.624494
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    pl = PolandSpecProvider()
    assert len(pl.pesel()) == 11
    assert len(pl.pesel(gender=Gender.MALE)) == 11
    assert len(pl.pesel(gender=Gender.FEMALE)) == 11

# Generated at 2022-06-23 20:45:41.585987
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    from mimesis import PolandSpecProvider
    p=PolandSpecProvider()
    pesel=p.pesel()
    print(pesel)

# Generated at 2022-06-23 20:45:44.535950
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    n = PolandSpecProvider()
    num = n.regon()
    assert len(num) == 9
    for i in num:
        assert int(i) < 10
        assert int(i) >= 0


# Generated at 2022-06-23 20:45:50.973702
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert isinstance(pesel, str)
    assert len(pesel) == 11
    assert provider.validate_pesel(pesel)
    assert provider.validate_pesel(provider.pesel())


# Generated at 2022-06-23 20:45:53.459358
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    for i in range(10):
        assert len(PolandSpecProvider().nip()) == 10



# Generated at 2022-06-23 20:45:57.352723
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Test if the constructor of class PolandSpecProvider works without parameters."""
    test_object = PolandSpecProvider()
    assert test_object is not None

if __name__ == '__main__':
    test_PolandSpecProvider()

# Generated at 2022-06-23 20:45:59.151098
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    result = provider.pesel()
    assert isinstance(result, str)
    assert len(result) == 11


# Generated at 2022-06-23 20:46:08.140821
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Unit test for method regon of class PolandSpecProvider."""
    # NIPtests
    # https://pl.wikipedia.org/wiki/REGON#Algorytm_sprawdzaj.C4.85cy
    # 0  8  9  2  3  4  5  6  7  7
    # 184265601 7
    # 1842656022
    # 1842656023
    # 1842656024
    # 1842656025
    # 1842656026
    # 1842656027
    # 1842656028
    # 1842656029
    # 1842656011
    # 1842656012
    # 1842656013
    # 1842656014
    # 1842656015
    # 1842656016
    # 1842656017
    # 1842656018
    # 184

# Generated at 2022-06-23 20:46:11.395187
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pl_spec_provider = PolandSpecProvider()
    pesel = pl_spec_provider.pesel()
    assert(len(pesel) == 11)
    assert(pesel.isdigit())



# Generated at 2022-06-23 20:46:14.148935
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    assert PolandSpecProvider().nip() == '178429024'



# Generated at 2022-06-23 20:46:15.603397
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    assert len(PolandSpecProvider().nip()) == 10


# Generated at 2022-06-23 20:46:17.863132
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Sample for method nip of class PolandSpecProvider"""
    provider = PolandSpecProvider()
    print(provider.nip())


# Generated at 2022-06-23 20:46:19.632528
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    assert PolandSpecProvider().pesel(birth_date=None, gender=None) == '88080600451'

# Generated at 2022-06-23 20:46:26.438042
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Unit test for method nip of class PolandSpecProvider."""
    # Creating PolandSpecProvider object
    polandSpecProvider = PolandSpecProvider()

    # Calls the method nip of class PolandSpecProvider
    nip = polandSpecProvider.nip()

    # Assertions
    # nip should be a string
    assert isinstance(nip, str)
    # nip should have 10 digits
    assert len(nip) == 10



# Generated at 2022-06-23 20:46:31.105719
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider()
    regon = provider.regon()
    assert regon in ['732633761', '375245189', '165962992', '288679994',
                     '914592281', '546550304', '814929251', '108699982',
                     '859571232', '972337164']


# Generated at 2022-06-23 20:46:41.249236
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test function for method pesel of class PolandSpecProvider."""
    from mimesis.providers import PolandSpecProvider
    from mimesis.enums import Gender

    pol_prov = PolandSpecProvider()
    for i in range(10):
        pesel = pol_prov.pesel()
        print(pesel)
        assert len(pesel) == 11
        pesel = pol_prov.pesel(Gender.MALE)
        print(pesel)
        assert len(pesel) == 11
        pesel = pol_prov.pesel(Gender.FEMALE)
        print(pesel)
        assert len(pesel) == 11


# Generated at 2022-06-23 20:46:44.281758
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider"""
    pl_provider = PolandSpecProvider()
    pesel = pl_provider.pesel()
    assert len(pesel) == 11
    assert type(pesel) == str


# Generated at 2022-06-23 20:46:46.345478
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    result = provider.nip()
    assert result
    assert isinstance(result, str)
    assert len(result) == 10


# Generated at 2022-06-23 20:46:51.024640
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    a = provider.pesel()
    assert len(a) == 11
    assert a.isdigit() == True
    for digit in a:
        assert int(digit) >= 0
        assert int(digit) <= 9


# Generated at 2022-06-23 20:46:51.486353
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    PolandSpecProvider()

# Generated at 2022-06-23 20:46:56.377213
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    nip_list = []
    p = PolandSpecProvider()
    nip_list.append(p.nip())
    nip_list.append(p.nip())
    assert len(nip_list[0]) == 10 and len(nip_list[1]) == 10  # length of NIP is 10


# Generated at 2022-06-23 20:46:59.657150
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    nip_generator = PolandSpecProvider()
    nip_list = [nip_generator.nip() for _ in range(10)]
    assert nip_list == ['4272916869', '4365459156', '6331535120', '5701032943',
                        '1672192258', '1303593875', '1796145597', '2948581665',
                        '2948581665', '2849672664']


# Generated at 2022-06-23 20:47:01.745134
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    p = PolandSpecProvider()
    assert p.nip() is not None
    assert p.pesel() is not None
    assert p.regon() is not None

# Generated at 2022-06-23 20:47:07.587764
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    # Setup the class PolandSpecProvider
    PolandSpecProvider = PolandSpecProvider()
    # Get the result of calling method nip of class PolandSpecProvider
    result = PolandSpecProvider.nip()
    # Test that dict result is a string
    assert type(result) == str
