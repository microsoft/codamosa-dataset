

# Generated at 2022-06-12 00:59:05.985337
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    seed = 42
    provider = PolandSpecProvider(seed=seed)
    assert provider.pesel(birth_date=Datetime(seed=seed).datetime(1980, 1980)) == "81111272295"
    assert provider.pesel(birth_date=Datetime(seed=seed + 1).datetime(1980, 1980)) == "80771265132"
    assert provider.pesel(birth_date=Datetime(seed=seed + 2).datetime(1980, 1980)) == "80151180446"
    assert provider.pesel(birth_date=Datetime(seed=seed + 3).datetime(1980, 1980)) == "80551207665"
    assert provider.pesel(birth_date=Datetime(seed=seed + 4).datetime(1980, 1980)) == "80801282682"
    assert provider

# Generated at 2022-06-12 00:59:09.464368
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    import os
    import sys
    import datetime

    item = PolandSpecProvider()
    pesel = item.pesel(datetime.datetime(1990, 9, 24), Gender.MALE)
    print(pesel)


# Generated at 2022-06-12 00:59:12.218747
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    assert p.pesel() == '90080409645'
    # ...

if __name__ == '__main__':
    test_PolandSpecProvider_pesel()

# Generated at 2022-06-12 00:59:24.001439
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():

    peselList = []
    peselList.append('test')
    peselList.append('test')
    peselList.append('test')
    peselList.append('test')
    peselList.append('test')

    i = 0
    while i < len(peselList):
        peselList[i] = PolandSpecProvider(seed=10).pesel(birth_date=1, gender=1)
        i = i + 1

    # check if all PESELs are unique
    isUnique = True
    i = 0
    while i < len(peselList):
        j = i + 1
        while j < len(peselList):
            if peselList[i] == peselList[j]:
                isUnique = False
            j = j + 1
        i = i + 1

   

# Generated at 2022-06-12 00:59:29.007985
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pol = PolandSpecProvider()
    p = pol.pesel()
    assert len(p) == 11
    assert isinstance(p, str)
    assert p.isdigit()


# Generated at 2022-06-12 00:59:35.829456
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    m = provider.pesel(gender=Gender.MALE)
    f = provider.pesel(gender=Gender.FEMALE)
    any = provider.pesel()

    assert len(m) == len(f) == len(any) == 11
    assert str(m)[9] != str(f)[9]
    assert str(m)[9] != str(any)[9]
    assert str(f)[9] != str(any)[9]



# Generated at 2022-06-12 00:59:47.631826
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """PolandSpecProvider: test method pesel

    :return: 
    """
    import datetime
    import re
    assert re.match(r'\d{11}', PolandSpecProvider().pesel())
    assert re.match(r'\d{11}', PolandSpecProvider(
    ).pesel(birth_date=datetime.date(2001, 1, 1)))
    assert re.match(r'[2368]{1,11}', PolandSpecProvider().pesel(
        birth_date=datetime.date(2001, 1, 1), gender=Gender.FEMALE))
    assert re.match(r'[13579]{1,11}', PolandSpecProvider().pesel(
        birth_date=datetime.date(2001, 1, 1), gender=Gender.MALE))

# Generated at 2022-06-12 00:59:49.342691
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    assert PolandSpecProvider().pesel() == '84041314618'


# Generated at 2022-06-12 00:59:52.897268
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    # Test if PESEL is valid and contains only numbers
    result_pesel = provider.pesel()
    assert all(c.isdigit() for c in result_pesel)



# Generated at 2022-06-12 01:00:03.695706
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test the random generation of 11-digit PESEL."""
    spec_pl = PolandSpecProvider()
    result = spec_pl.pesel()
    assert len(result) == 11
    assert result.isdigit()
    assert int(result[-1]) == sum([int(d) * int(c) for d, c in
                                   zip(result[:-1],
                                       [9, 7, 3, 1, 9, 7, 3, 1, 9, 7])]) % 10
    m_pesel = spec_pl.pesel(gender=Gender.MALE)
    assert int(m_pesel[-1]) in [0, 2, 4, 6, 8]
    f_pesel = spec_pl.pesel(gender=Gender.FEMALE)
    assert int(f_pesel[-1])

# Generated at 2022-06-12 01:00:40.117550
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider()
    print(pesel.pesel())

# Generated at 2022-06-12 01:00:41.094390
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    assert PolandSpecProvider().pesel().isdigit()

# Generated at 2022-06-12 01:00:45.337431
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test for creating of the PESEL number (correctnes of the number)."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    print(pesel)
    assert len(pesel) == 11
    assert pesel[-1] == str(sum([int(pesel[i]) * (9-i) for i in range(10)]) % 10)


# Generated at 2022-06-12 01:00:54.151251
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pl_provider = PolandSpecProvider()
    gender = Gender.FEMALE
    birth_date = Datetime().datetime(1990, 2018)
    pesel = pl_provider.pesel(birth_date, gender)
    print(pesel)
    print(birth_date.date().year)
    print(birth_date.date().month)
    print(birth_date.date().day)
    digit_args = [int(d) for d in pesel]
    pesel_first_4_digits = digit_args[:4]
    print(pesel_first_4_digits)
    pesel_first_2_digits = pesel_first_4_digits[:2]
    print(pesel_first_2_digits)

# Generated at 2022-06-12 01:00:54.812654
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pass

# Generated at 2022-06-12 01:01:02.550143
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    random = PolandSpecProvider(seed=0)
    list_of_pesels = []
    list_of_dates = []
    list_of_genders = []
    date = Datetime().datetime(1940, 2018)
    date = date.date()
    gender = Gender.MALE
    for i in range(100):
        list_of_pesels.append(random.pesel(date, gender))
        list_of_genders.append(gender)
        list_of_dates.append(date)

# Generated at 2022-06-12 01:01:04.597861
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    pesel = p.pesel()
    assert len(pesel) == 11


# Generated at 2022-06-12 01:01:13.390821
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # Set-up
    pesel_to_check = '96013121779'
    # Assumption
    assert(PolandSpecProvider().pesel(DateTime().datetime(1996, 1, 31), Gender.MALE) == pesel_to_check)
    # Checking for any date of birth
    for i in range(10):
        assert(int(PolandSpecProvider().pesel()[9]) % 2 == 0)
    # Checking for men
    for i in range(10):
        assert(int(PolandSpecProvider().pesel(gender=Gender.MALE)[9]) % 2 == 1)
    # Checking for women
    for i in range(10):
        assert(int(PolandSpecProvider().pesel(gender=Gender.FEMALE)[9]) % 2 == 0)

# Generated at 2022-06-12 01:01:15.166403
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()

    assert len(provider.pesel()) == 11
    assert len(provider.pesel(gender=Gender.FEMALE)) == 11
    assert len(provider.pesel(gender=Gender.MALE)) == 11


# Generated at 2022-06-12 01:01:16.628841
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    assert provider.pesel() != provider.pesel()


# Generated at 2022-06-12 01:01:36.073174
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    print(PolandSpecProvider().pesel())
    assert PolandSpecProvider().pesel() == '01082018014'



# Generated at 2022-06-12 01:01:44.132465
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel_1 = (PolandSpecProvider.pesel(Gender.MALE))
    pesel_2 = (PolandSpecProvider.pesel(Gender.FEMALE))
    pesel_3 = (PolandSpecProvider.pesel(None))

    gender_1 = (pesel_1[-1] % 2 == 0)
    gender_2 = (pesel_2[-1] % 2 == 0)
    gender_3 = (pesel_3[-1] % 2 == 0)

    gender_check_1 = (gender_1, Gender.FEMALE)
    gender_check_2 = (gender_2, Gender.FEMALE)
    gender_check_3 = (gender_3, Gender.FEMALE)

    print(f"pesel_1 = {pesel_1}")

# Generated at 2022-06-12 01:01:54.524778
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider

# Generated at 2022-06-12 01:01:56.127952
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    assert(len(provider.pesel()) == 11)


# Generated at 2022-06-12 01:02:02.879713
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()

    # Birth date = 2010-01-01, gender = Male
    # pesel = '10' + last 2 digits of year + '01' + '01' + 3-digit serial no. + '1' + checksum digit
    # = '10' + '10' + '01' + '01' + '001' + '1' + '9' = 1001010019

    pesel = provider.pesel(birth_date=Datetime().datetime(2010, 2010), gender=Gender.MALE)

    assert pesel == '1001010019'



# Generated at 2022-06-12 01:02:08.158425
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_provider = PolandSpecProvider()
    assert poland_provider.pesel(birth_date=PolandSpecProvider.datetime(1940, 2018), gender=Gender.MALE) == '93122329025'
    assert poland_provider.pesel(birth_date=PolandSpecProvider.datetime(1940, 2018), gender=Gender.FEMALE) == '93122325034'
    assert poland_provider.pesel(birth_date=PolandSpecProvider.datetime(1940, 2018)) == '93122323069'
    assert poland_provider.pesel(birth_date=PolandSpecProvider.datetime(1940, 2018)) != '93122323068'


# Generated at 2022-06-12 01:02:12.708939
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    gender = Gender.FEMALE
    pesel = provider.pesel(gender=gender)
    year = int(pesel[0:2])
    month = int(pesel[2:4])
    day = int(pesel[4:6])
    series_number = int(pesel[6:9])
    gender_digit = int(pesel[9:10])
    checksum_digit = int(pesel[10:11])

    assert 0 <= gender_digit <= 9
    assert 0 <= series_number <= 999
    assert 0 <= day <= 31
    assert 0 <= month <= 99
    assert 0 <= year <= 99
    assert 0 <= checksum_digit <= 9
    assert len(pesel) == 11



# Generated at 2022-06-12 01:02:16.118597
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    test_obj = PolandSpecProvider()

    pesel1 = test_obj.pesel()
    pesel2 = test_obj.pesel()

    assert len(pesel1) == 11
    assert len(pesel2) == 11
    assert pesel1 != pesel2


# Generated at 2022-06-12 01:02:21.352089
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider(seed=42)
    assert p.pesel(birth_date=Datetime().datetime(
        year=2016, month=1, day=1), gender=Gender.MALE) == '160101091149'
    assert p.pesel(birth_date=Datetime().datetime(
        year=2016, month=1, day=1), gender=Gender.FEMALE) == '160101094632'
    assert p.pesel(birth_date=Datetime().datetime(
        year=2016, month=1, day=1)) == '160101094632'

# Generated at 2022-06-12 01:02:23.007164
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test PolandSpecProvider's pesel method"""
    sample_pesel = PolandSpecProvider().pesel()
    assert isinstance(sample_pesel, str)
    assert len(sample_pesel) == 11
    assert PolandSpecProvider().validate_pesel(sample_pesel)


# Generated at 2022-06-12 01:02:48.154766
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test pesel method."""
    pl = PolandSpecProvider()

    pesel = pl.pesel()
    assert isinstance(pesel, str)
    assert len(pesel) == 11

    pesel = pl.pesel(gender=Gender.MALE)
    assert pesel.endswith('4') or pesel.endswith('6') or pesel.endswith('8')

    pesel = pl.pesel(gender=Gender.FEMALE)
    assert pesel.endswith('3') or pesel.endswith('5') or pesel.endswith('7') \
           or pesel.endswith('9')


# Generated at 2022-06-12 01:02:50.989467
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()
    assert isinstance(pesel, (str,))
    assert len(pesel) == 11
    assert pesel != PolandSpecProvider().pesel()


# Generated at 2022-06-12 01:02:55.067343
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    from pprint import pprint
    from mimesis.enums import Gender
    from datetime import datetime

    for i in range(25):
        pesel = PolandSpecProvider().pesel(birth_date=datetime(1990, 1, 1), gender=Gender.MALE)
        pprint(pesel)

# Generated at 2022-06-12 01:03:01.950330
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    gen_pesel = provider.pesel()
    _pesel_date = int(gen_pesel[0:2])
    print(_pesel_date)

    # 1900 <= year <= 1999
    if int(gen_pesel[0:2]) in list(range(0, 99)):
        assert int(gen_pesel[2:4]) <= 12 and int(gen_pesel[2:4]) > 0
        assert int(gen_pesel[4:6]) <= 31 and int(gen_pesel[4:6]) > 0
    # 2000 <= year <= 2099

# Generated at 2022-06-12 01:03:09.002552
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test pesel

    Example:
        pesel('2000-01-01') -> '0107001053'
        pesel('2000-01-01', Gender.MALE) -> '0114001050'
        pesel('2000-01-01', Gender.FEMALE) -> '0104001062'
    """
    expected_result = '0107001053'
    actual_result = PolandSpecProvider().pesel('2000-01-01')
    assert expected_result == actual_result

# Generated at 2022-06-12 01:03:10.351967
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider(seed=200).pesel()
    assert pesel == '53030149669'

# Generated at 2022-06-12 01:03:15.260904
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test pesel method of class PolandSpecProvider.
    """
    import datetime
    from mimesis.enums import Gender
    pl = PolandSpecProvider()
    pesel = pl.pesel()
    assert len(pesel) == 11
    pesel = pl.pesel(birth_date=datetime.datetime(1990, 10, 25), 
            gender=Gender.MALE)
    assert len(pesel) == 11


# Generated at 2022-06-12 01:03:17.701271
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test pesel method."""
    result = PolandSpecProvider().pesel()
    print(result)
    assert result == '12345678901'

print(PolandSpecProvider().pesel())

# Generated at 2022-06-12 01:03:27.267633
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    PESEL = provider.pesel()
    assert int(PESEL[0:2]) >= 40
    assert int(PESEL[0:2]) <= 99
    assert int(PESEL[2:4]) >= 1
    assert int(PESEL[2:4]) <= 12
    assert int(PESEL[4:6]) >= 1
    assert int(PESEL[4:6]) <= 31
    assert int(PESEL[6:9]) >= 0
    assert int(PESEL[6:9]) <= 999
    assert int(PESEL[9]) <= 9


# Generated at 2022-06-12 01:03:30.046548
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    from mimesis.enums import Gender
    provider = PolandSpecProvider()
    assert len(provider.pesel()) == 11
    assert provider.pesel(gender=Gender.MALE)[9] % 2
    assert not provider.pesel(gender=Gender.FEMALE)[9] % 2
    assert provider.pesel()[9] in [0, 2, 4, 6, 8]
