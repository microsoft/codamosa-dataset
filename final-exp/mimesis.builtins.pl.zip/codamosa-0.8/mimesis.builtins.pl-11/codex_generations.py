

# Generated at 2022-06-12 00:58:51.738863
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Tests that pesel method generates proper data
        and raises TypeError if it receives bad argument type.
    """
    provider = PolandSpecProvider()
    assert type(provider.pesel(birth_date=provider.datetime(2016, 2019))) == str
    assert type(provider.pesel(birth_date=provider.datetime())) == str
    assert type(provider.pesel()) == str
    assert type(provider.pesel(birth_date=provider.datetime(), gender=Gender.FEMALE)) == str
    assert type(provider.pesel(birth_date=provider.datetime(), gender=Gender.MALE)) == str
    assert type(provider.pesel(gender=Gender.MALE)) == str
    assert type(provider.pesel(gender=Gender.FEMALE))

# Generated at 2022-06-12 00:58:53.440904
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    assert PolandSpecProvider().pesel(birth_date=None, gender=None).__len__() == 11


# Generated at 2022-06-12 00:58:57.168827
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
	p = PolandSpecProvider()
	pesel = p.pesel(birth_date=None, gender=Gender.MALE)
	print(pesel)


# Generated at 2022-06-12 00:58:58.514733
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()
    assert len(pesel) == 11

# Generated at 2022-06-12 00:59:02.502142
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """
    Test method pesel of class PolandSpecProvider.
    """
    import datetime
    pesel = PolandSpecProvider().pesel(datetime.datetime(1998, 6, 23), Gender.MALE)
    assert pesel == '98062306917'


# Generated at 2022-06-12 00:59:05.074455
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pl = PolandSpecProvider()
    print(pl.pesel(pl.datetime(), Gender.FEMALE))

# Generated at 2022-06-12 00:59:07.550952
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    print("-----------------")
    print("PolandSpecProvider.pesel()")
    print("-----------------")

    providers = PolandSpecProvider()
    print("pesel(Gender.MALE): ", providers.pesel(gender=Gender.MALE))
    print("pesel(Gender.FEMALE): ", providers.pesel(gender=Gender.FEMALE))
    print("pesel(Gender.NOT_SPECIFIED): ", providers.pesel())


# Generated at 2022-06-12 00:59:15.635742
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel_provider = PolandSpecProvider()
    assert len(pesel_provider.pesel()) == 11
    assert pesel_provider.pesel(gender=Gender.MALE)[-1] in (1, 3, 5, 7, 9)
    assert pesel_provider.pesel(gender=Gender.FEMALE)[-1] in (0, 2, 4, 6, 8)
    year = str(pesel_provider.random.randint(1940, 2018))
    month = str(pesel_provider.random.randint(1, 12))
    day = str(pesel_provider.random.randint(1, 28))
    m, d, y = month.zfill(2), day.zfill(2), year[-2:]

# Generated at 2022-06-12 00:59:17.969548
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pl = PolandSpecProvider()
    tmp = pl.pesel()
    assert len(tmp) == 11


# Generated at 2022-06-12 00:59:21.817765
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    result = provider.pesel()
    result = provider.pesel(birth_date=provider.timestamp(1970, 2017), gender=Gender.MALE)
    assert result is not None

# Generated at 2022-06-12 00:59:27.070257
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    PolandSpecProvider().pesel()

# Generated at 2022-06-12 00:59:37.438869
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider()
    persona = pesel.pesel(birth_date=pesel.datetime(2000, 2010),
                          gender=Gender.MALE)

# Generated at 2022-06-12 00:59:42.072733
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel_number = provider.pesel(birth_date=Datetime().datetime(1994, 1994), gender=Gender.MALE)
    assert len(pesel_number) == 11


# Generated at 2022-06-12 00:59:46.544459
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider"""
    czech_provider = PolandSpecProvider()
    pesel = czech_provider.pesel()
    print(pesel)
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-12 00:59:48.279935
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test pesel method."""
    assert PolandSpecProvider().pesel()


# Generated at 2022-06-12 00:59:50.881373
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """docstring"""
    print(PolandSpecProvider().pesel())


test_PolandSpecProvider_pesel()

# Generated at 2022-06-12 01:00:01.147344
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    class PolandSpecProvider(BaseSpecProvider):
        """Class that provides special data for Poland (pl)."""

        def __init__(self, seed: Seed = None):
            """Initialize attributes."""
            super().__init__(locale='pl', seed=seed)

        class Meta:
            """The name of the provider."""

            name = 'poland_provider'

        def nip(self) -> str:
            """Generate random valid 10-digit NIP.

            :return: Valid 10-digit NIP
            """
            nip_digits = [int(d) for d in str(self.random.randint(101, 998))]
            nip_digits += [self.random.randint(0, 9) for _ in range(6)]

# Generated at 2022-06-12 01:00:08.159950
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    assert p.pesel(birth_date=None, gender=None) == '73062043196'
    assert p.pesel(birth_date=None, gender=Gender.MALE) == '38012448398'
    assert p.pesel(birth_date=None, gender=Gender.FEMALE) == '06116458611'
    assert p.pesel(birth_date=Datetime().datetime(2019, 2019), gender=Gender.FEMALE) == '19050476621'

# Generated at 2022-06-12 01:00:17.025471
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    
    def test_pesel_without_params_returns_correct_pesel():
        pesel = PolandSpecProvider().pesel()
        assert len(pesel) == 11
        assert isinstance(pesel, str)
        assert pesel.isdigit()

    def test_pesel_with_correct_parameters_returns_correct_pesel():
        pesel = PolandSpecProvider().pesel(Datetime().datetime(1900, 2000), Gender.FEMALE)
        assert len(pesel) == 11
        assert isinstance(pesel, str)
        assert pesel.isdigit()
        pesel1 = PolandSpecProvider().pesel(Datetime().datetime(1900, 2000), Gender.MALE)
        assert len(pesel1) == 11
        assert isinstance(pesel1, str)
       

# Generated at 2022-06-12 01:00:20.045294
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    t = PolandSpecProvider()
    assert len(t.pesel()) == 11
    assert len(t.pesel(gender="F")) == 11
    assert len(t.pesel(gender="M")) == 11



# Generated at 2022-06-12 01:01:20.076972
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pl = PolandSpecProvider()
    assert len(pl.pesel()) == 11

# Generated at 2022-06-12 01:01:21.337620
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit tests for method pesel of class PolandSpecProvider"""
    #TODO
    pass


# Generated at 2022-06-12 01:01:28.258900
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    year = 1985
    month = 1
    day = 1
    pesel = PolandSpecProvider().pesel(birth_date=Datetime().datetime(year, year, day, day, month, month))
    assert pesel[0:2] == str(year)[2:4]
    assert pesel[2:4] == '{:02d}'.format(month)
    assert pesel[4:6] == '{:02d}'.format(day)
    assert pesel[6:9] == '{:03d}'.format(0)


# Generated at 2022-06-12 01:01:29.608150
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test for PolandSpecProvider.pesel()."""
    print(PolandSpecProvider().pesel())


# Generated at 2022-06-12 01:01:33.358452
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    poland_provider = PolandSpecProvider()

    assert poland_provider.pesel() == "96043063983"

# Generated at 2022-06-12 01:01:34.845467
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    x = PolandSpecProvider()
    assert x.pesel() == "79112804940"

# Generated at 2022-06-12 01:01:36.641754
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    assert len(p.pesel()) == 11


# Generated at 2022-06-12 01:01:38.060083
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11

# Generated at 2022-06-12 01:01:45.078576
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    sp = PolandSpecProvider()
    gender = sp.random.choice(Gender)
    birth_date = sp.datetime(1940, 2018)
    pesel = sp.pesel(birth_date, gender)
    assert (pesel[-2] == '0' if gender == Gender.MALE else '1'
            or pesel[-2] == '2' if gender == Gender.FEMALE
            else pesel[-2] == '3' or pesel[-2] == '4'
            or pesel[-2] == '5' or pesel[-2] == '6'
            or pesel[-2] == '7' or pesel[-2] == '8'
            or pesel[-2] == '9')

# Generated at 2022-06-12 01:01:49.784185
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    pesel = p.pesel(birth_date="1995-12-20", gender=Gender.MALE)
    assert pesel is not None
    assert type(pesel) == str
    assert len(pesel) == 11
