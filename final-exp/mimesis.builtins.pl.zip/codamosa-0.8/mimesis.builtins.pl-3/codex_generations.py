

# Generated at 2022-06-12 00:59:03.383779
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test for method pesel of class PolandSpecProvider."""
    from mimesis.providers import Datetime
    from mimesis.providers.poland import PolandSpecProvider
    pesel = PolandSpecProvider().pesel()
    expected_len = 11
    assert len(pesel) == expected_len
    year = int(pesel[0:2])
    month = int(pesel[2:4])
    day = int(pesel[4:6])
    gender = int(pesel[9])
    if gender % 2 == 1:
        gender = 'M'
    else:
        gender = 'F'
    if (month > 20 and month < 33) or (month > 60 and month < 73):
        year += 1800

# Generated at 2022-06-12 00:59:06.599771
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    pesel = p.pesel()
    assert type(pesel) == str
    assert len(pesel) == 11


# Generated at 2022-06-12 00:59:15.209305
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    class PolandSpecProvider_test(PolandSpecProvider):
        """A class that inherits from PolandSpecProvider."""
        def __init__(self):
            """Initialize attributes."""
            self.random = RandomMockUp()
            super().__init__()

    poland_provider_test = PolandSpecProvider_test()
    assert poland_provider_test.pesel(
        Datetime().datetime(year=1989, month=1, day=1), Gender.MALE
    ) == '8901071236'
    assert poland_provider_test.pesel(
        Datetime().datetime(year=1989, month=1, day=1), Gender.FEMALE
    ) == '8901077027'

# Generated at 2022-06-12 00:59:16.738658
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()
    assert len(pesel) == 11


# Generated at 2022-06-12 00:59:27.156587
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider"""

    plsp = PolandSpecProvider()
    pesel = plsp.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert isinstance(pesel, str)

    # Test date
    date = plsp.datetime().date(1950, 2010)
    pesel = plsp.pesel(birth_date=date)
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert isinstance(pesel, str)

    # Test Gender
    gender = Gender.FEMALE
    pesel = plsp.pesel(gender=gender)
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert isinstance(pesel, str)
    # Test Gender

# Generated at 2022-06-12 00:59:30.360831
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # provider = PolandSpecProvider()
    # pesel = provider.pesel()
    # print(pesel)
    assert (pesel in [])



# Generated at 2022-06-12 00:59:32.694914
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # Test with False
    assert len(PolandSpecProvider().pesel()) == 11


# Generated at 2022-06-12 00:59:35.473605
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    PESELs = []
    for _ in range(1000000):
        PESELs.append(PolandSpecProvider().pesel())

    assert not None in PESELs


# Generated at 2022-06-12 00:59:37.203337
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pl = PolandSpecProvider()
    pesel = pl.pesel()
    assert len(pesel) == 11


# Generated at 2022-06-12 00:59:43.986363
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    pl = PolandSpecProvider()
    print(pl.pesel(birth_date='2000-01-01', gender=Gender.MALE))
    print(pl.pesel(birth_date='2000-01-01'))
    print(pl.pesel(gender=Gender.MALE))
    print(pl.pesel())


# Generated at 2022-06-12 01:00:04.707740
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """
    Unit test for method pesel() of PolandSpecProvider class
    """
    assert PolandSpecProvider(seed=1).pesel(
            birth_date=DateTime().datetime(1940, 2018), gender=Gender.MALE) == '94062904582'
    assert PolandSpecProvider(seed=2).pesel(
            birth_date=DateTime().datetime(1940, 2018), gender=Gender.MALE) == '85030702221'
    assert PolandSpecProvider(seed=3).pesel(
            birth_date=DateTime().datetime(1940, 2018), gender=Gender.FEMALE) == '94092707944'

# Generated at 2022-06-12 01:00:08.082052
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pl = PolandSpecProvider(seed = 42)
    birth_date = pl.datetime(1900, 2000)
    pesel = pl.pesel(birth_date, Gender.MALE)
    assert pesel == '92051208502'

# Generated at 2022-06-12 01:00:12.615854
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel"""
    print("Start unit test for method pesel of class PolandSpecProvider")
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert (pesel) != None
    
    print("End unit test for method pesel of class PolandSpecProvider")


# Generated at 2022-06-12 01:00:14.988823
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider"""
    pesel = PolandSpecProvider().pesel()
    assert isinstance(pesel, str)
    assert len(pesel) == 11


# Generated at 2022-06-12 01:00:16.871581
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()
    assert len(pesel) == 11
    # test_PolandSpecProvider_pesel
    

# Generated at 2022-06-12 01:00:21.878308
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel."""
    from mimesis.providers.datetime import Datetime
    from mimesis.enums import Gender
    reference_date = Datetime().datetime(1940, 2099)
    print(PolandSpecProvider().pesel(reference_date, Gender.FEMALE))
    print(PolandSpecProvider().pesel(reference_date, Gender.MALE))



# Generated at 2022-06-12 01:00:24.984839
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    p.pesel(birth_date = Datetime().datetime(1940, 2018), gender = Gender.FEMALE)
    assert p.pesel() == "61017111737"

# Generated at 2022-06-12 01:00:26.540927
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()
    print(pesel)
    # assert(1==2)


# Generated at 2022-06-12 01:00:27.606366
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()

    assert provider.pesel() is not None


# Generated at 2022-06-12 01:00:31.584175
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    PolandSpecProvider_instance = PolandSpecProvider()
    assert len(PolandSpecProvider_instance.pesel()) == 11
    assert PolandSpecProvider_instance.pesel()[-1] == str(int(sum(array([int(n)*m for n, m in zip(PolandSpecProvider_instance.pesel()[:-1], (9, 7, 3, 1, 9, 7, 3, 1, 9, 7) )])%10))%10)
 


# Generated at 2022-06-12 01:02:46.290427
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider(seed=42)
    generated_pesels = {}
    for i in range(10000):
        generated_pesel = provider.pesel()
        assert generated_pesel not in generated_pesels
        generated_pesels[generated_pesel] = None
    print("test_PolandSpecProvider_pesel() - passed")

# Generated at 2022-06-12 01:02:49.278264
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    i = 0
    while i < 1000:
        pesel_number = PolandSpecProvider().pesel()
        assert len(pesel_number) == 11
        i = i + 1


# Generated at 2022-06-12 01:02:51.473462
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel(Datetime().datetime(), Gender.MALE)
    assert len(pesel) == 11, 'pesel is invalid'
    print(pesel)

# Generated at 2022-06-12 01:02:55.092630
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    from mimesis import PolandSpecProvider
    pesel_generator = PolandSpecProvider()
    pesel = pesel_generator.pesel()
    assert (pesel.isdigit() and len(pesel) == 11)

# Generated at 2022-06-12 01:02:56.319954
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()
    assert len(pesel) == 11