

# Generated at 2022-06-12 00:58:55.988405
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    import unittest
    from mimesis.builtins.pl import PolandSpecProvider

    # Start
    pl = PolandSpecProvider()

    # Test if pesel number is valid
    pesel_number = pl.pesel()
    correct_pesel_number = True
    assert correct_pesel_number == is_pesel_correct(pesel_number)

    # Test if pesel number is correct
    pesel_number = pl.pesel(
        birth_date=Datetime().datetime(
            year=1995,
            month=3,
            day=17),
        gender=Gender.MALE)
    correct_pesel_number = True
    assert correct_pesel_number == is_pesel_correct(pesel_number)

    # End
    pl.close()

# Function for checking if PESEL

# Generated at 2022-06-12 00:58:58.318713
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()
    assert len(pesel) == 11
    #assert pesel[-1] == gender


# Generated at 2022-06-12 00:59:09.464995
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    assert PolandSpecProvider().pesel(gender=Gender.MALE) in ('94012713784', 
                                                              '97112452859',
                                                              '95100184499',
                                                              '96123074209',
                                                              '94060283659')
    assert PolandSpecProvider().pesel(gender=Gender.FEMALE) in ('94121118365', 
                                                                '97102934795',
                                                                '95122482950',
                                                                '97103184578',
                                                                '94120907066')

# Generated at 2022-06-12 00:59:12.218614
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    pesel = p.pesel(birth_date=Datetime().datetime(1980, 1990), gender=Gender.MALE)
    print(pesel)


# Generated at 2022-06-12 00:59:15.179660
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()
    assert len(pesel) == 11 and pesel.isdigit()


# Generated at 2022-06-12 00:59:16.700583
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    result = PolandSpecProvider().pesel(gender=Gender.MALE)
    assert(len(result) == 11)

# Generated at 2022-06-12 00:59:22.791535
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test PolandSpecProvider.pesel(None, Gender.FEMALE)."""
    pesel = PolandSpecProvider().pesel(None, Gender.FEMALE)
    assert len(pesel) == 11
    for digit in pesel:
        assert digit.isnumeric()
    assert int(pesel[4:6]) % 2 == 0

# Generated at 2022-06-12 00:59:25.739154
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    provider.seed(45)
    result = provider.pesel()
    assert result == '97110400907'

    provider.seed(45)
    result = provider.pesel(gender=Gender.MALE)
    assert result == '97110400907'

    provider.seed(45)
    result = provider.pesel(gender=Gender.FEMALE)
    assert result == '98110400910'

    provider.seed(45)
    result = provider.pesel(birth_date=provider.datetime(1995, 2017))
    assert result == '97110400907'

# Generated at 2022-06-12 00:59:30.096512
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    arg1 = '1991-12-09'
    arg2 = 'FEMALE'
    a = PolandSpecProvider().pesel(arg1, arg2)
    assert(a == '92032906533' or a == '92051213370')

# Generated at 2022-06-12 00:59:36.000466
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """
    Test pesel method from PolandSpecProvider.
    """
    from mimesis.enums import Gender
    from datetime import datetime
    provider = PolandSpecProvider()
    # Format birth date
    birth_date = datetime(1973, 12, 23, 12, 34, 56)
    pesel = provider.pesel(birth_date, Gender.MALE)
    assert isinstance(pesel, str)
    assert len(pesel) == 11

# Generated at 2022-06-12 00:59:49.943060
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider"""
    random.seed(1)
    expected_pesels = ["83252311093", "96634010585", "75283509110", "33153809788", "72407490011", "62982308020", "85743109344", "23105709054", "11652850473", "91956200814"]
    for i in range(len(expected_pesels)):
        pesel = PolandSpecProvider().pesel()
        expected_pesel = expected_pesels[i]
        assert pesel == expected_pesel, "Expected: " + expected_pesel + ", but got " + pesel + " instead"
    random.seed(1)


# Generated at 2022-06-12 00:59:50.713376
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pass

# Generated at 2022-06-12 00:59:53.054077
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    polish_pesel_provider = PolandSpecProvider()
    pesel = polish_pesel_provider.pesel()
    assert len(pesel) == 11


# Generated at 2022-06-12 01:00:00.271737
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    rng = random.Random(42)
    bdate = date(1965, 3, 2)
    provider = PolandSpecProvider(seed=rng)
    assert provider.pesel(birth_date=bdate, gender=Gender.FEMALE) == '65030212344'
    assert provider.pesel(birth_date=bdate, gender=Gender.MALE)   == '65030213397'
    assert provider.pesel(birth_date=bdate)                       == '65030212124'
    assert provider.pesel()                                       == '84010820670'

# Generated at 2022-06-12 01:00:04.336681
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_provider = PolandSpecProvider()
    pesel = poland_provider.pesel(birth_date="1995-02-20", gender=Gender.FEMALE)
    assert pesel == '95022082262'

# Generated at 2022-06-12 01:00:14.184952
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()

    assert len(p.pesel(birth_date='2017-01-01', gender=Gender.MALE)) == 11
    assert len(p.pesel(birth_date='2017-01-01', gender=Gender.FEMALE)) == 11
    assert len(p.pesel(birth_date='2017-01-01', gender=Gender.UNKNOWN)) == 11
    assert len(p.pesel()) == 11

    # Test for pesel with birth date and gender
    pesel = p.pesel(birth_date='2017-01-01', gender=Gender.MALE)
    date_part = pesel[0:2]
    assert date_part == '17'

    gender_part = pesel[9:10]

# Generated at 2022-06-12 01:00:19.342468
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pp = PolandSpecProvider()
    test_values = [12002012345, 13503112348, 13602012346, 13702012347, 13802012348,
                   13902012340, 14002012341, 14102012342, 14202012343, 14302012344,
                   14902012345, 15002012346, 15902012347, 16802012348, 17702012349,
                   18902012345, 19812012346, 19111012347, 19209021348]
    for element in test_values:
        assert pp.pesel(element) == str(element)

# Generated at 2022-06-12 01:00:21.250172
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    print(provider.pesel())


# Generated at 2022-06-12 01:00:25.732946
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    seed(1000)

    instance = PolandSpecProvider(seed = 1000)
    assert instance.pesel(gender = Gender.MALE) == "90121209307"
    assert instance.pesel(gender = Gender.FEMALE) == "66062800304"
    assert instance.pesel() == "09031709807"

# Generated at 2022-06-12 01:00:29.472066
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_provider = PolandSpecProvider()
    assert poland_provider.pesel(birth_date='1940-01-01', gender=Gender.MALE) == "40001010532"
    assert poland_provider.pesel(birth_date='2000-01-02', gender=Gender.FEMALE) == "03010200913"


# Generated at 2022-06-12 01:00:41.055223
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # Test for fixed seed
    for _ in range(1000):
        x = PolandSpecProvider(seed=100).pesel()
        assert x == '860824203464'
    # Test for random seed
    for _ in range(1000):
        x = PolandSpecProvider().pesel()
        assert len(x) == 11
        assert x.isdigit()

# Generated at 2022-06-12 01:00:44.133853
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    print(provider.pesel())
    print(provider.pesel(None, Gender.FEMALE))
    print(provider.pesel(None, Gender.MALE))

# Generated at 2022-06-12 01:00:52.626857
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    tested_object = PolandSpecProvider()
    # test case when gender is set
    result = tested_object.pesel(gender = Gender.MALE)
    assert (result[9] == '1') or (result[9] == '3') or (result[9] == '5') or (result[9] == '7') or (result[9] == '9')
    result = tested_object.pesel(gender = Gender.FEMALE)
    assert (result[9] == '0') or (result[9] == '2') or (result[9] == '4') or (result[9] == '6') or (result[9] == '8')
    # test case when gender is not set
    result = tested_object.pesel()

# Generated at 2022-06-12 01:00:59.856116
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    case1 = PolandSpecProvider()
    case2 = PolandSpecProvider()
    case3 = PolandSpecProvider()
    case4 = PolandSpecProvider()
    assert len(case1.pesel()) == 11
    assert len(case2.pesel()) == 11
    assert len(case3.pesel()) == 11
    assert len(case4.pesel(birth_date=case4._datetime.datetime(2012, 12, 12))) == 11
    assert len(case1.pesel(gender=Gender.MALE)) == 11
    assert len(case2.pesel(gender=Gender.FEMALE)) == 11
    assert len(case3.pesel(gender=Gender.NOT_SPECIFIED)) == 11


# Generated at 2022-06-12 01:01:08.209538
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    locale = 'pl'
    provider = PolandSpecProvider(seed=42)

    # Check correct birth date (format YYYY-MM-DD)
    assert provider.pesel(birth_date='2000-11-08', gender=Gender.MALE) == '0011123378'

    # Check incorrect birth date
    try:
        provider.pesel(birth_date='2000-13-08', gender=Gender.MALE)
        assert False
    except ValueError:
        assert True

    # Check incorrect birth date 2
    try:
        provider.pesel(birth_date='2000-11-32', gender=Gender.MALE)
        assert False
    except ValueError:
        assert True

    # Check incorrect gender

# Generated at 2022-06-12 01:01:11.000758
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    from mimesis.providers import PolandSpecProvider
    p = PolandSpecProvider()
    pesel = p.pesel(birth_date='2015-01-28', gender=Gender.MALE)
    assert pesel == '15012851940'

# Generated at 2022-06-12 01:01:14.016481
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    a = provider.pesel(gender=Gender.MALE)
    print(a)

if __name__ == "__main__":
    test_PolandSpecProvider_pesel()

# Generated at 2022-06-12 01:01:17.293131
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider(seed=42)
    assert provider.pesel() == '58012084689'
    assert provider.pesel(gender=Gender.FEMALE) == '99091569790'
    assert provider.pesel(gender=Gender.MALE) == '72042624393'

# Generated at 2022-06-12 01:01:19.045780
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    assert PolandSpecProvider().pesel() == '87072218205'

# Generated at 2022-06-12 01:01:20.904386
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    random_provider = PolandSpecProvider(seed = 42)
    pesel = random_provider.pesel()
    assert(pesel == "86062626589")
