

# Generated at 2022-06-12 00:58:53.777946
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pass
    '''
    from mimesis.providers import PolandSpecProvider
    from mimesis.enums import Gender
    pesel = PolandSpecProvider()
    assert len(pesel.pesel())  == 11
    assert len(pesel.pesel(gender=Gender.MALE)) == 11
    assert len(pesel.pesel(gender=Gender.FEMALE)) == 11
    assert len(pesel.pesel(birth_date=pesel.datetime(1940, 2018))) == 11
    '''

# Generated at 2022-06-12 00:59:05.551073
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel_male = []
    pesel_female = []
    for i in range(1000):
        ppl = PolandSpecProvider()
        gender = Gender.MALE
        pesel_male.append(ppl.pesel(gender=gender))
    for i in range(1000):
        ppl = PolandSpecProvider()
        gender = Gender.FEMALE
        pesel_female.append(ppl.pesel(gender=gender))
    pesel_male = set(pesel_male)
    pesel_female = set(pesel_female)
    assert (len(pesel_male) == 1000)
    assert (len(pesel_female) == 1000)
    assert (len(pesel_male.intersection(pesel_female)) == 0)


# Generated at 2022-06-12 00:59:08.045930
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():

    p = PolandSpecProvider()
    pesel_result = p.pesel()
    print(pesel_result)
    assert len(pesel_result) == 11


# Generated at 2022-06-12 00:59:09.612394
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    assert PolandSpecProvider.pesel()=="10010010496"

# Generated at 2022-06-12 00:59:16.506598
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    test1_date = Datetime().datetime(1990, 1, 1)
    test2_date = Datetime().datetime(2000, 1, 1)
    test3_date = Datetime().datetime(1940, 1, 1)
    test4_date = Datetime().datetime(2090, 1, 1)
    test5_date = Datetime().datetime(2200, 1, 1)
    pesel_ = PolandSpecProvider().pesel(test1_date, Gender.MALE)
    pesel_2 = PolandSpecProvider().pesel(test2_date, Gender.FEMALE)
    pesel_3 = PolandSpecProvider().pesel(test3_date, Gender.FEMALE)
    pesel_4 = PolandSpecProvider().pesel(test4_date, Gender.MALE)
    pesel_5

# Generated at 2022-06-12 00:59:27.040206
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    
    # Unit test for case when birth date is a parameter
    date_object = Datetime().datetime(1900)
    pesel = provider.pesel(date_object)
    
    year = date_object.date().year
    month = date_object.date().month
    day = date_object.date().day
    
    first_two_digits = int(str(year)[-2:])
    
    if 1800 <= year <= 1899:
        month += 80
    elif 2000 <= year <= 2099:
        month += 20
    elif 2100 <= year <= 2199:
        month += 40
    elif 2200 <= year <= 2299:
        month += 60
    
    second_two_digits = int(month)
    third_two_digits = int(day)

# Generated at 2022-06-12 00:59:33.898389
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pr = PolandSpecProvider()
    pesel_code = pr.pesel()
    pesel_code_2 = pr.pesel(None, Gender.MALE)
    pesel_code_3 = pr.pesel(None, Gender.FEMALE)

    assert isinstance(pesel_code, str)
    assert isinstance(pesel_code_2, str)
    assert isinstance(pesel_code_3, str)


# Generated at 2022-06-12 00:59:37.301844
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    providerPesel = PolandSpecProvider()
    pesel = providerPesel.pesel(None, Gender.MALE)
    assert pesel is not None
    assert pesel.isdigit()
    assert len(pesel) == 11
    assert int(pesel[9]) % 2 != 0


# Generated at 2022-06-12 00:59:44.663702
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel(birth_date=Datetime().datetime(1960, 2000), gender=Gender.FEMALE)
    print(pesel)
    pesel = PolandSpecProvider().pesel(birth_date=Datetime().datetime(1960, 2000), gender=Gender.MALE)
    print(pesel)
    pesel = PolandSpecProvider().pesel()
    print(pesel)
    # Unit test for method nip of class PolandSpecProvider


# Generated at 2022-06-12 00:59:47.385449
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider"""
    # TODO: write unit test for method pesel of class PolandSpecProvider
    raise NotImplementedError


# Generated at 2022-06-12 01:00:11.398758
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():

    # Print pesel for given birthdate
    test_instance = PolandSpecProvider()
    print(test_instance.pesel(Datetime().datetime(2000, 2018)))

    # Print 10 pesels for birthdays from 2000 to 2018
    test_instance = PolandSpecProvider()
    for i in range(0,10):
        print(test_instance.pesel(Datetime().datetime(2000, 2018)))

    # Print 10 pesels for females and 10 for males,
    # with birthdays from 2000 to 2018
    test_instance = PolandSpecProvider()
    for i in range(0,10):
        print(test_instance.pesel(Datetime().datetime(2000, 2018), Gender.FEMALE))

# Generated at 2022-06-12 01:00:15.949188
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    assert PolandSpecProvider().pesel() != PolandSpecProvider().pesel()
    assert PolandSpecProvider().pesel(gender= Gender.FEMALE) != PolandSpecProvider().pesel(gender= Gender.MALE)
    assert PolandSpecProvider().pesel(birth_date=Datetime.datetime(2007, 9, 23)) != PolandSpecProvider().pesel(birth_date=Datetime.datetime(2007, 9, 24))


# Generated at 2022-06-12 01:00:19.472089
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
	# Initialization of variables
	obj = PolandSpecProvider()
	# Expected value
	expected = '01011901075'
	result = obj.pesel(birth_date = Datetime().datetime(1900, 2001),gender = Gender.MALE)
	assert result == expected


# Generated at 2022-06-12 01:00:22.576715
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland = PolandSpecProvider()
    assert len(poland.pesel(birth_date='2000-01-01', gender=Gender.MALE)) == 11



# Generated at 2022-06-12 01:00:24.748081
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider(seed=123456789)
    pesel = provider.pesel()
    assert pesel == '95582468182'

# Generated at 2022-06-12 01:00:27.778012
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    polish_provider = PolandSpecProvider()
    assert len(polish_provider.pesel()) == 11, 'PESEL length is not equal to 11'

    assert polish_provider.pesel().isdigit(), 'PESEL contains non-digit characters'

# Generated at 2022-06-12 01:00:32.491266
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test the method pesel of class PolandSpecProvider."""
    # pylint: disable=unused-argument
    rp = PolandSpecProvider()
    rp.seed(12345)
    assert rp.pesel() == '95021212020'
    assert rp.pesel(birth_date=datetime(1992, 12, 3),
                    gender=Gender.MALE) == '92120314140'
    assert rp.pesel(birth_date=datetime(1992, 12, 3),
                    gender=Gender.FEMALE) == '92120317014'


# Generated at 2022-06-12 01:00:40.681225
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    assert PolandSpecProvider().pesel(birth_date=Datetime().datetime(1992, 1, 9)) == '92153000023'
    assert PolandSpecProvider().pesel(birth_date=Datetime().datetime(1990, 12, 28)) == '90104000073'
    assert PolandSpecProvider().pesel(birth_date=Datetime().datetime(1995, 3, 14)) == '95460000136'
    assert PolandSpecProvider().pesel(birth_date=Datetime().datetime(1982, 12, 20)) == '82123000139'
    assert PolandSpecProvider().pesel(birth_date=Datetime().datetime(2004, 8, 14)) == '04630000861'

# Generated at 2022-06-12 01:00:42.143276
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    x = PolandSpecProvider().pesel(birth_date= DateTime(), gender= Gender)
    assert len(x) == 11

# Generated at 2022-06-12 01:00:50.828807
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel1 = PolandSpecProvider(seed=0).pesel(birth_date=999, gender=Gender.MALE)
    assert pesel1 == "39336340200"
    pesel2 = PolandSpecProvider(seed=0).pesel(birth_date=999, gender=Gender.FEMALE)
    assert pesel2 == "39336340206"
    pesel3 = PolandSpecProvider(seed=0).pesel(birth_date=999, gender=None)
    assert pesel3 == "39336340207"
    pesel4 = PolandSpecProvider(seed=1).pesel(birth_date=999, gender=Gender.MALE)
    assert pesel4 == "39336340202"

# Generated at 2022-06-12 01:01:04.552711
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel_provider = PolandSpecProvider()
    pesel_1 = pesel_provider.pesel(birth_date=Datetime().datetime(1998, 7, 4))
    pesel_2 = pesel_provider.pesel(birth_date=Datetime().datetime(1998, 7, 4))
    pesel_3 = pesel_provider.pesel(birth_date=Datetime().datetime(1998, 7, 4))
    assert pesel_1 != pesel_2
    assert pesel_1 != pesel_3
    assert pesel_2 != pesel_3
    assert isinstance(pesel_1, str)


# Generated at 2022-06-12 01:01:05.707978
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    assert len(provider.pesel()) == 11

# Generated at 2022-06-12 01:01:08.245228
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method of class PolandSpecProvider - pesel"""
    pesel = PolandSpecProvider().pesel()
    assert isinstance(pesel, str)
    assert len(pesel) == 11


# Generated at 2022-06-12 01:01:10.412885
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider(seed=1)
    result = provider.pesel(gender=Gender.MALE)
    assert result == '87102506923'

# Generated at 2022-06-12 01:01:13.391673
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert isinstance(pesel,str) == True
    assert len(pesel) == 11


# Generated at 2022-06-12 01:01:14.895329
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    from datetime import datetime
    assert PolandSpecProvider().pesel(datetime(1994, 10, 7),
                                      Gender.MALE) == '94107211545'


# Generated at 2022-06-12 01:01:22.147243
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """
    This test checks correctness of the response to the method pesel of class PolandSpecProvider
    """

    '''
    Function pesel() will return a random valid 11-digit PESEL.
    Method pesel of class PolandSpecProvider should return a valid PESEL, so this function will
    generate 100 valid PESEL response and check the correctness of the response with class PolandSpecProvider

    '''

    # get the seed
    SEED = 12345
    # initialize the class PolandSpecProvider
    poland_spec_provider = PolandSpecProvider(SEED)
    # setup the test class
    test_class = PolandSpecProvider(SEED)

    # generate 100 valid PESEL

# Generated at 2022-06-12 01:01:24.484416
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    test_pesel = PolandSpecProvider().pesel()
    assert len(test_pesel) == 11

# Generated at 2022-06-12 01:01:27.965202
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method."""
    import pytest
    from mimesis.enums import Gender
    from mimesis.providers.locales.pl import (
        _Poland,
    )

    p = PolandSpecProvider()
    p.pesel()
    p.pesel(birth_date=p.datetime())
    p.pesel(gender=Gender.MALE)


# Generated at 2022-06-12 01:01:31.265817
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    list_ = []
    list_2 = []
    for i in range(1000):
        list_.append(PolandSpecProvider().pesel())
    for i in range(1000):
        list_2.append(PolandSpecProvider().pesel())
    for i in range(1000):
        if list_[i] == list_2[i]:
            raise ValueError(msg)
