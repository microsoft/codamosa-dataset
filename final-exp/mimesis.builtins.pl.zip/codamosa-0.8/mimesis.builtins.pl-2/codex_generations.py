

# Generated at 2022-06-12 00:58:53.043031
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert ''.join(map(str, [int(d) for d in pesel[:9]])).isdigit()
    assert int(pesel[10]) in range(0,10)


# Generated at 2022-06-12 00:58:55.841659
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pl = PolandSpecProvider()
    assert len(pl.pesel()) == 11



# Generated at 2022-06-12 00:59:00.526136
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test PESEL method."""
    pl = PolandSpecProvider()
    assert len(pl.pesel(birth_date='1981-01-14', gender=Gender.MALE)) == 11
    assert len(pl.pesel(birth_date='1981-01-14', gender=Gender.FEMALE)) == 11

# Generated at 2022-06-12 00:59:05.362201
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pol = PolandSpecProvider(seed=12345)
    assert pol.pesel(birth_date="1980-09-28", gender=0) == "80092834329"
    assert pol.pesel(birth_date="1980-09-28", gender=1) == "80092875408"

# Generated at 2022-06-12 00:59:06.523707
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider(seed=42)
    assert provider.pesel(gender=Gender.MALE) == '90092709093'


# Generated at 2022-06-12 00:59:09.315169
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()
    wynik = False
    if len(pesel) == 11:
        wynik = True

    assert wynik

# Generated at 2022-06-12 00:59:13.046985
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # Test the output of PolandSpecProvider.pesel method
    test_provider = PolandSpecProvider()
    assert test_provider.pesel(gender=Gender.MALE) == "68042913963"
    assert test_provider.pesel(gender=Gender.FEMALE) == "67042375663"

# Generated at 2022-06-12 00:59:16.858279
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel_object = PolandSpecProvider()
    pesel_object.seed(12345)
    print(pesel_object.pesel(birth_date='1951-11-28', gender=Gender.MALE))
    # 85308772948



# Generated at 2022-06-12 00:59:21.907386
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """
    Test method pesel() of PolandSpecProvider class
    """
    pesel = PolandSpecProvider.pesel(PolandSpecProvider())
    print(pesel)
    assert len(pesel) == 11 and pesel.isdigit()

# Generated at 2022-06-12 00:59:24.073660
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""

    provider = PolandSpecProvider(seed=125)
    assert provider.pesel() == '94052268527'

# Generated at 2022-06-12 00:59:33.152720
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    sample_pesel = PolandSpecProvider().pesel()
    print(sample_pesel)

# Generated at 2022-06-12 00:59:36.689816
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Tests if pesel method of PolandSpecProvider generates correct PESELs."""
    provider = PolandSpecProvider()

# Generated at 2022-06-12 00:59:41.212448
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel(birth_date=Datetime().datetime(1992, 2000))
    assert len(pesel) == 11

# Generated at 2022-06-12 00:59:42.851720
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pl = PolandSpecProvider()
    assert len(pl.pesel()) == 11


# Generated at 2022-06-12 00:59:47.659051
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    female = PolandSpecProvider()
    assert female.pesel(gender=Gender.FEMALE) in ['44090801169', '37011501360', '37011501360']

    male = PolandSpecProvider()
    assert male.pesel(gender=Gender.MALE) in ['41020100429', '37042800197', '37042800197']

# Generated at 2022-06-12 00:59:50.839300
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel_user= provider.pesel(birth_date=None, gender=None)
    assert len(pesel_user)==11

# Generated at 2022-06-12 00:59:54.741267
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    date = Datetime().datetime(1940, 2018)
    gender = Gender.FEMALE
    res = p.pesel(date, gender)
    assert res == res.isdigit()
    print(res)


# Generated at 2022-06-12 01:00:04.978312
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    year = Datetime('pl').datetime(1940, 2018).year
    gender = Gender.MALE

    # Generate random 11-digit PESEL
    pesel_number = PolandSpecProvider().pesel(birth_date=Datetime('pl').datetime(1940, 2018), gender=gender)
    assert int(pesel_number[0:2]) in (year - 2000, year - 1900, year - 1800, year - 2100, year - 2200)
    assert int(pesel_number[2:4]) >= 1
    assert int(pesel_number[2:4]) <= 12
    assert int(pesel_number[4:6]) >= 1
    assert int(pesel_number[4:6]) <= 31
    assert int(pesel_number[6:9]) <= 999

# Generated at 2022-06-12 01:00:14.433796
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    import unittest
    pesel_object = PolandSpecProvider(seed=100)
    assert pesel_object.pesel(date_object, Gender.MALE) == '85101075027'
    assert pesel_object.pesel(date_object, Gender.FEMALE) == '83101075021'
    assert pesel_object.pesel(birth_date, gender) == '85101075027'
    assert pesel_object.pesel(birth_date, gender) == '85101075027'
    assert pesel_object.pesel(birth_date, gender) == '83101075021'
    assert pesel_object.pesel(birth_date, gender) == '83101075021'

# Generated at 2022-06-12 01:00:16.454929
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    print(p.pesel(gender=Gender.MALE))
    print(p.pesel(gender=Gender.FEMALE))

# Generated at 2022-06-12 01:00:43.274871
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test pesel of class PolandSpecProvider"""
    provider = PolandSpecProvider()
    assert provider.pesel() != provider.pesel(gender=Gender.MALE)
    assert provider.pesel() == provider.pesel()
    assert provider.pesel(gender=Gender.FEMALE) != provider.pesel(gender=Gender.MALE)

# Generated at 2022-06-12 01:00:51.906753
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    old_pesel=PolandSpecProvider().pesel(birth_date=DateTime().datetime(1900, 1940), gender=Gender.MALE)
    young_pesel=PolandSpecProvider().pesel(birth_date=DateTime().datetime(2000, 2018), gender=Gender.MALE)
    old_pesel_check=PolandSpecProvider().pesel(birth_date=DateTime().datetime(1900, 1940), gender=Gender.FEMALE)
    young_pesel_check=PolandSpecProvider().pesel(birth_date=DateTime().datetime(2000, 2018), gender=Gender.FEMALE)
    if old_pesel==old_pesel_check or young_pesel==young_pesel_check:
        print("Pesel of class PolandSpecProvider is wrong!")
        return False
    print

# Generated at 2022-06-12 01:00:57.032266
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    a = PolandSpecProvider().pesel(birth_date='2000-03-03', gender=Gender.MALE)
    if not (a[0:4] == '0003' and int(a[4:6]) in range(81, 93) and a[6:8] == '03' and int(a[8:11]) in range(0, 999)):
        raise KeyError('Wrong birthday people')


# Generated at 2022-06-12 01:00:58.346674
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    result = provider.pesel(gender=Gender.MALE)

    assert result is not None

# Generated at 2022-06-12 01:01:00.147678
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel1 = PolandSpecProvider().pesel()
    pesel2 = PolandSpecProvider().pesel()
    assert len(pesel1) == 11 and len(pesel2) == 11

# Generated at 2022-06-12 01:01:01.910409
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    assert PolandSpecProvider().pesel(gender=Gender.MALE)\
        == '62051111859'


# Generated at 2022-06-12 01:01:04.507670
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    print("\n", 'Test for method pesel of class PolandSpecProvider')
    provider = PolandSpecProvider()
    print(provider.pesel())
    print(provider.pesel())


# Generated at 2022-06-12 01:01:07.155296
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel_str = provider.pesel(birth_date=None, gender=None)
    assert len(pesel_str) == 11
    assert pesel_str == "26120354641"


# Generated at 2022-06-12 01:01:08.510637
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pl = PolandSpecProvider()
    assert pl.pesel()

# Generated at 2022-06-12 01:01:12.914028
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    assert provider.pesel(gender=Gender.FEMALE)[-1] in ['0', '2', '4', '6', '8']
    assert provider.pesel(gender=Gender.MALE)[-1] in ['1', '3', '5', '7', '9']