

# Generated at 2022-06-12 00:59:00.989652
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    p = PolandSpecProvider()
    pesel = p.pesel()
    pesel_int = int(pesel)
    assert len(str(pesel_int)) == 11
    print('pesel:', pesel)
    assert p.pesel(gender=Gender.MALE).endswith(('1', '3', '5', '7', '9'))
    assert p.pesel(gender=Gender.FEMALE).endswith(('0', '2', '4', '6', '8'))

# Generated at 2022-06-12 00:59:11.303127
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_provider_1 = PolandSpecProvider(123)
    print(poland_provider_1.pesel(birth_date="1957-02-13", gender="Female"))

    poland_provider_2 = PolandSpecProvider(123)
    print(poland_provider_2.pesel(birth_date="1957-02-13", gender="Male"))

    poland_provider_3 = PolandSpecProvider(123)
    print(poland_provider_3.pesel(birth_date="2000-01-01", gender="Female"))

    poland_provider_4 = PolandSpecProvider(123)
    print(poland_provider_4.pesel(birth_date="2000-01-01", gender="Male"))


# Generated at 2022-06-12 00:59:13.686925
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    obj = PolandSpecProvider()
    r = obj.pesel()
    assert len(r) == 11
    for char in r:
        assert int(char) in range(10)


# Generated at 2022-06-12 00:59:18.187039
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    from datetime import date
    provider_test = PolandSpecProvider(seed=1)
    pesel_test = provider_test.pesel(birth_date=date(1994, 3, 18), gender=Gender.MALE)
    assert type(pesel_test)
    assert len(pesel_test) == 11

# Generated at 2022-06-12 00:59:24.617812
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pol = PolandSpecProvider()
    for _ in range(1000):
        assert len(pol.pesel()) == 11
        # assert pesel[0:2].isdigit() == True
        # assert pesel[2:4].isdigit() == True
        # assert pesel[4:6].isdigit() == True
        # assert pesel[6:9].isdigit() == True
        # assert pesel[9:11].isdigit() == True



# Generated at 2022-06-12 00:59:27.429864
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    for i in range(10):
        provider.pesel()

# Generated at 2022-06-12 00:59:35.632394
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():

    pesel = PolandSpecProvider().pesel(Datetime().datetime(2000, 2001), Gender.MALE)
    assert len(pesel) == 11
    assert pesel[0] == '0' or pesel[0] == '2' or pesel[0] == '4' or pesel[0] == '6' or pesel[0] == '8', "Tested wrong gender value of pesel"
    assert pesel[2] == '0' or pesel[2] == '1', "Tested wrong month value of pesel"


# Generated at 2022-06-12 00:59:37.336913
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    peselTest = PolandSpecProvider()
    pesel = peselTest.pesel(None)
    assert(len(pesel) == 11)

# Generated at 2022-06-12 00:59:42.079581
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel(gender=Gender.MALE)
    assert len(pesel) == 11
    assert int(pesel[9]) in (0, 2, 4, 6, 8)


# Generated at 2022-06-12 00:59:49.649856
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """
    Generate pesel and compare it with values from Wikipedia
    """
    from mimesis.providers.person import Person
    person = Person('pl')
    i = 0
    while i < 5:
        i += 1
        pesel = person.pesel()
        print(pesel)
        if pesel == '02070803628':
            assert True
            break
        elif pesel == '74091603571':
            assert True
            break
        elif pesel == '94041503475':
            assert True
            break
        elif pesel == '76021003600':
            assert True
            break
        elif pesel == '72080703599':
            assert True
            break
        else:
            assert False

# Generated at 2022-06-12 01:00:04.191117
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test for method pesel of class PolandSpecProvider"""
    p = PolandSpecProvider()
    pesel = p.pesel
    assert len(pesel()) == 11

# Method test_PolandSpecProvider_nip of class PolandSpecProvider

# Generated at 2022-06-12 01:00:14.076348
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel(gender=Gender.MALE)
    assert pesel[-1] == '1' or pesel[-1] == '3' or pesel[-1] == '5' or pesel[-1] == '7' or pesel[-1] == '9'

    pesel = PolandSpecProvider().pesel(gender=Gender.FEMALE)
    assert pesel[-1] == '0' or pesel[-1] == '2' or pesel[-1] == '4' or pesel[-1] == '6' or pesel[-1] == '8'

    pesel = PolandSpecProvider().pesel(gender=None)
    assert '0' <= pesel[-1] <= '9'

    pesel = PolandSpecProvider().pesel()
   

# Generated at 2022-06-12 01:00:16.355210
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider.

    Tests pesel for correct behavior for dates.
    """
    assert len(PolandSpecProvider().pesel(Datetime().datetime(1940, 2018))) == 11

# Generated at 2022-06-12 01:00:26.099357
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    import datetime
    from mimesis.enums import Gender

    p = PolandSpecProvider()
    # when we don't pass any parameter we get a random pesel number
    pes = p.pesel()
    assert len(pes) == 11
    # when we provide (birth_date=datetime.datetime(1965, 1, 1), gender=Gender.MALE)
    # or (Gender.FEMALE) we get a pesel number related to it
    pes = p.pesel(birth_date=datetime.datetime(1965, 1, 1), gender=Gender.MALE)
    assert pes == '65010112345'
    pes = p.pesel(birth_date=datetime.datetime(1965, 1, 1), gender=Gender.FEMALE)
    assert pes == '65010112350'
   

# Generated at 2022-06-12 01:00:27.502295
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    assert len(provider.pesel()) == 11

# Generated at 2022-06-12 01:00:31.297893
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test whether the method pesel works correctly."""
    assert PolandSpecProvider().pesel()
    assert PolandSpecProvider().pesel(
        Datetime.datetime(1940, 2018), Gender.FEMALE)
    assert PolandSpecProvider().pesel(
        Datetime.datetime(1940, 2018), Gender.MALE)
    assert PolandSpecProvider().pesel(
        Datetime.datetime(1940, 2018))


# Generated at 2022-06-12 01:00:34.340500
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Validate the correct work of method pesel of class PolandSpecProvider"""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    pesel_len = len(pesel)
    assert pesel_len == 11


# Generated at 2022-06-12 01:00:43.418848
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pl = PolandSpecProvider(seed=12345)
    assert pl.pesel(birth_date=Datetime().datetime(1997, 1998)) == '97120547862'
    assert pl.pesel(birth_date=Datetime().datetime(1997, 1998), gender=Gender.MALE) == '97120547862'
    assert pl.pesel(birth_date=Datetime().datetime(1997, 1998), gender=Gender.FEMALE) == '97120547873'

    assert pl.pesel(birth_date=Datetime().datetime(2008, 2018)) == '18011100051'
    assert pl.pesel(birth_date=Datetime().datetime(2008, 2018), gender=Gender.MALE) == '18011100051'

# Generated at 2022-06-12 01:00:46.070288
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel(birth_date=Datetime().datetime(1980, 1998), gender=Gender.MALE)
    assert len(pesel) == 11
    print(f"pesel: {pesel}")



# Generated at 2022-06-12 01:00:51.159689
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit tests for method pesel of class PolandSpecProvider

    Test Conditions:
        1. Check that the pesel is a string.
        2. Check that the pesel's length is 11.
    """
    poland_provider = PolandSpecProvider()
    assert isinstance(poland_provider.pesel(), str)
    assert len(poland_provider.pesel()) == 11
