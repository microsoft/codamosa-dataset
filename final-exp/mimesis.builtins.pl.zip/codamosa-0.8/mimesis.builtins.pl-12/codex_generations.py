

# Generated at 2022-06-12 00:58:51.542388
# Unit test for method pesel of class PolandSpecProvider

# Generated at 2022-06-12 00:58:53.516794
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    testGenerator = PolandSpecProvider()
    returnedValue = testGenerator.pesel()
    assert len(returnedValue) is 11


# Generated at 2022-06-12 00:59:01.082137
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test it returns a valid PESEL number."""
    from mimesis.enums import Gender
    from mimesis.providers import Datetime
    from mimesis.providers.person import Person

    bd = Datetime().datetime(1990, 2018)
    gender = Person().gender()
    pesel = PolandSpecProvider().pesel(birth_date=bd, gender=gender)
    assert len(pesel) == 11
    assert pesel.isdigit()

# Generated at 2022-06-12 00:59:06.519018
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    gen = PolandSpecProvider()
    date_object = Datetime().datetime(1940, 2018)
    value = gen.pesel(date_object, Gender.MALE)
    assert len(value) == 11
    value_2 = gen.pesel(date_object, Gender.FEMALE)
    assert len(value_2) == 11


# Generated at 2022-06-12 00:59:12.898189
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    print('\n \n \n \n \n \n \n \n')
    print(PolandSpecProvider().pesel())
    list_test_pesels = ['{}'.format(PolandSpecProvider().pesel())]
    for i in range(0, 9):
        list_test_pesels.append('{}'.format(PolandSpecProvider().pesel()))
    for i in range(0, 10):
        print('{}'.format(list_test_pesels[i]))



# Generated at 2022-06-12 00:59:19.278181
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test generation of PESEL numbers."""
    from mimesis.providers.datetime import Datetime
    poland_provider = PolandSpecProvider()
    date = Datetime().datetime(1940, 2018)
    assert len(poland_provider.pesel(date)) == 11
    assert not poland_provider.pesel(date).endswith('0')


# Generated at 2022-06-12 00:59:27.880210
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """
    Unit test for method pesel of class PolandSpecProvider
    The method pesel generates valid 11-digit PESEL identifier
    using information about birth date and gender of a person.
    The test consists of creating 100 PESEL identifiers
    using the method pesel and checking if they are valid.
    :return:
    """
    pesel_list = []

    for i in range(100):
        pesel_list.append(PolandSpecProvider().pesel())

    for i in range(100):
        pesel = pesel_list[i]
        wagi = (1, 3, 7, 9, 1, 3, 7, 9, 1, 3)
        suma = 0
        j = 0
        while (j < 10):
            suma += int(pesel[j]) * wagi[j]

# Generated at 2022-06-12 00:59:30.407714
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert pesel == '12121212345'


# Generated at 2022-06-12 00:59:36.277557
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_provider = PolandSpecProvider()
    pesel_male = poland_provider.pesel(gender=Gender.MALE)
    pesel_female = poland_provider.pesel(gender=Gender.FEMALE)
    assert len(pesel_male) == len(pesel_female)
    assert len(pesel_male) == 11
    assert pesel_male != pesel_female

# Generated at 2022-06-12 00:59:39.567942
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    psp = PolandSpecProvider()
    pesel = psp.pesel()


# Generated at 2022-06-12 00:59:53.013007
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method 'pesel' of class PolandSpecProvider."""
    pesel = PolandSpecProvider().pesel(birth_date=Datetime().datetime(1900, 1, 1), gender=Gender.MALE)
    assert(len(pesel) == 11)
    assert(int(pesel[2:4]) == 1)

# Generated at 2022-06-12 00:59:58.415603
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_provider = PolandSpecProvider()
    pesel1 = poland_provider.pesel(birth_date=DateTime.datetime(2000, 5, 12))
    assert(pesel1 == '00512700340')
    pesel2 = poland_provider.pesel(gender=Gender.FEMALE)
    assert(pesel2 == '72101107788')

# Generated at 2022-06-12 00:59:59.580092
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    assert(len(p.pesel()) == 11)

# Generated at 2022-06-12 01:00:02.515553
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    assert PolandSpecProvider.__dict__['pesel'] != BaseSpecProvider.__dict__['pesel']

# Generated at 2022-06-12 01:00:05.496767
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    fake_gen = PolandSpecProvider()
    assert type(fake_gen.pesel()) is str
    assert len(fake_gen.pesel()) == 11


# Generated at 2022-06-12 01:00:07.851632
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    assert PolandSpecProvider().pesel(birth_date=Datetime().datetime(2000, 2018)) == '0202181234567'


# Generated at 2022-06-12 01:00:13.246335
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pl = PolandSpecProvider()
    pesel = pl.pesel(gender=Gender.FEMALE)
    assert len(pesel) == 11
    for i in [0, 2, 4, 6, 8, 10]:
        assert int(pesel[i]) % 2 == 0
    for i in [1, 3, 5, 7, 9]:
        assert int(pesel[i]) % 2 == 1



# Generated at 2022-06-12 01:00:14.677551
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    prov = PolandSpecProvider(seed=123)
    result = prov.pesel()
    print(result)

# Generated at 2022-06-12 01:00:16.062353
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()
    assert len(pesel) == 11


# Generated at 2022-06-12 01:00:23.166990
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    polandProvider = PolandSpecProvider()
    pesel = polandProvider.pesel(birth_date='1980-01-01', gender=Gender.FEMALE)
    if pesel == '80000101961':
        print('Unit test for method pesel of class PolandSpecProvider - passed')
        return True
    else:
        print('Unit test for method pesel of class PolandSpecProvider - failed')
        return False
print(test_PolandSpecProvider_pesel())
print(test_PolandSpecProvider_pesel())
print(test_PolandSpecProvider_pesel())

# Generated at 2022-06-12 01:00:35.822995
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # Arrange
    from datetime import datetime

    p = PolandSpecProvider()
    expected_birth_date = datetime(1977, 6, 18, 0, 0)
    expected_pesel = "77861898241"

    # Act
    actual_pesel = p.pesel(birth_date=expected_birth_date)

    # Assert
    assert expected_pesel == actual_pesel

# Generated at 2022-06-12 01:00:41.014429
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider"""
    provider = PolandSpecProvider()
    pesel = provider.pesel(birth_date=None, gender=Gender.MALE)
    assert len(pesel) == 11
    assert int(pesel[-2:]) % 2 == 1
    assert pesel == provider.pesel(birth_date=None, gender=Gender.FEMALE)

# Generated at 2022-06-12 01:00:42.760352
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-12 01:00:44.915111
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()

    # Codice PESEL a 11 cifre valido
    assert len(provider.pesel()) == 11


# Generated at 2022-06-12 01:00:46.433535
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    test_object_PolandSpecProvider = PolandSpecProvider()
    assert len(test_object_PolandSpecProvider.pesel()) == 11

# Generated at 2022-06-12 01:00:50.829699
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    assert provider.pesel(None, Gender.MALE) == '42131910108'
    assert provider.pesel(None, Gender.FEMALE) == '51082000041'
    assert provider.pesel(None) == '79081700147'
    


# Generated at 2022-06-12 01:00:59.049109
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    d = p.datetime(1940, 2018)
    res_pesel = p.pesel(d, Gender.MALE)
    assert len(res_pesel) == 11
    assert res_pesel[2] == str(d.strftime('%y'))[0]
    assert res_pesel[3] == str(d.strftime('%y'))[1]
    assert res_pesel[4] == str(d.strftime('%m'))[0]
    assert res_pesel[5] == str(d.strftime('%m'))[1]
    assert res_pesel[6] == str(d.strftime('%d'))[0]
    assert res_pesel[7] == str(d.strftime('%d'))

# Generated at 2022-06-12 01:01:00.026004
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()
    assert len(pesel) == 11

# Generated at 2022-06-12 01:01:05.776356
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    P = PolandSpecProvider()
    assert len(P.pesel()) == 11 # Funkcja zwraca łańcuch znaków, który ma 11 znaków.
    assert P.pesel(birth_date='1992-01-01 02:00:00', gender=Gender.MALE) == "92010100029"
    assert P.pesel(birth_date='1992-01-01 02:00:00', gender=Gender.FEMALE) == "92010100039"


# Generated at 2022-06-12 01:01:13.844070
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test the correct behavior of method pesel in class PolandSpecProvider.
    """
    from datetime import datetime
    test_pesel = PolandSpecProvider().pesel(
        birth_date = datetime(2004,10,20),
        gender = Gender.FEMALE
    )
    # The output of this method is only a up to a certain degree.
    # I was using it to debug an error raised by the test_a of this method.
    # It is commented now.
    #print(test_pesel)
    assert test_pesel is not None
    assert 0 <= int(test_pesel[-1]) <= 9
    assert 0 <= int(test_pesel[-2]) <= 9


# Generated at 2022-06-12 01:05:01.341013
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pl = PolandSpecProvider()
    result = pl.pesel(Datetime().datetime(1990,1,1), Gender.MALE)
    assert isinstance(result, str)
    assert len(result) == 11
    assert result.startswith("90")
    assert result.find("0101", 2, 6) == 2
    assert result.find("69", 6, 9) == 6


# Generated at 2022-06-12 01:05:08.744437
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    assert len(p.pesel()) == 11
    assert p.pesel().isdigit()
    assert len(p.pesel(Gender.MALE)) == 11
    assert p.pesel(Gender.MALE).isdigit()
    assert len(p.pesel(Gender.FEMALE)) == 11
    assert p.pesel(Gender.FEMALE).isdigit()


# Generated at 2022-06-12 01:05:11.001069
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel(birth_date=Datetime().datetime(1990,1993,29),gender=Gender.MALE)
    assert len(pesel) == 11


# Generated at 2022-06-12 01:05:16.339174
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    # print(p.pesel())
    assert '43092802678' == p.pesel()
    assert '43092802678' == p.pesel(gender=Gender.MALE)
    # result = p.pesel(gender=Gender.MALE)
    # print(result)
    # result = p.pesel(gender=Gender.FEMALE)
    # print(result)


# Generated at 2022-06-12 01:05:26.467176
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider"""

    assert int(PolandSpecProvider().pesel()[:2]) >= 40, "pesel() not lower than 1975"
    assert int(PolandSpecProvider().pesel()[:2]) <= 19, "pesel() not higher than 2019"

    assert int(PolandSpecProvider().pesel(birth_date=Datetime().datetime(1990, 1, 1))[:2]) == 90, "pesel() not equal to 1990"
    assert int(PolandSpecProvider().pesel(birth_date=Datetime().datetime(1990, 1, 1))[2:4]) == 1, "pesel() not equal to January"

# Generated at 2022-06-12 01:05:27.913873
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    for i in range(10):
        pesel = PolandSpecProvider().pesel()
        assert len(pesel) is 11

# Generated at 2022-06-12 01:05:30.677656
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    assert PolandSpecProvider(seed=5).pesel() == '92061604942'



# Generated at 2022-06-12 01:05:32.064510
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()
    assert len(pesel) == 11
    assert type(pesel) == str


# Generated at 2022-06-12 01:05:34.439271
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pl = PolandSpecProvider()
    assert len(pl.pesel()) == 11

# Generated at 2022-06-12 01:05:38.606818
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    curr_seed = 0
    provider = PolandSpecProvider(seed=curr_seed)
    pesel_male_1 = provider.pesel(gender=Gender.MALE)
    assert pesel_male_1 == '37122712138'
