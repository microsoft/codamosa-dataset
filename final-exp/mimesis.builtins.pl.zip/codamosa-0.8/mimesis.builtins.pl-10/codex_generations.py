

# Generated at 2022-06-12 00:58:55.839423
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():

    from mimesis.enums import Gender

    p = PolandSpecProvider()

    # test for checking if pesel is correct (correct length, correct checksum digit)
    for _ in range(1000):
        pesel = p.pesel()
        assert len(pesel) == 11
        assert int(pesel[-1]) == int(pesel[:-1]) % 10

    # check if month and day are valid
    p.datetime = lambda: Datetime().datetime(1960, 2018)
    pesel = p.pesel(Gender.MALE)
    month = int(pesel[2:4])
    day = int(pesel[4:6])
    assert 1 <= month <= 12
    assert 1 <= day <= 31

    # check if year is valid
    pesel = p.pesel(Gender.MALE)


# Generated at 2022-06-12 00:58:59.307215
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider(seed=10)
    result = provider.pesel(birth_date=provider.datetime(1940, 2018))
    assert result == '94051110633'

# Generated at 2022-06-12 00:59:05.731392
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel."""
    p = PolandSpecProvider()
    age = p.random.randint(20, 35)
    datetime = p.datetime()
    birth_date = datetime.date(1940, 2018)
    p = PolandSpecProvider(seed=birth_date)
    gender = p.random.randint(0, 1)
    print(birth_date)
    print(p.pesel(birth_date, gender))

# Generated at 2022-06-12 00:59:13.374962
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel1 = PolandSpecProvider()
    pesel2 = PolandSpecProvider()
    pesel3 = PolandSpecProvider()
    assert len(pesel1.pesel(birth_date = '1996-09-10', gender = Gender.MALE)) == 11
    assert pesel1.pesel(birth_date = '1996-09-10', gender = Gender.MALE)[0] in '159'
    assert pesel2.pesel(birth_date = '2002-06-25', gender = Gender.FEMALE)[0] in '02468'
    assert pesel3.pesel()[0] in '0123456789'

# Generated at 2022-06-12 00:59:15.600366
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    for i in range(10):
        print(provider.pesel())



# Generated at 2022-06-12 00:59:19.565103
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    assert PolandSpecProvider(1).pesel(Datetime().datetime(2010, 2010)) == "10042100884" or PolandSpecProvider(1).pesel(Datetime().datetime(2010, 2010)) == "10040610709"

# Generated at 2022-06-12 00:59:25.857325
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for test method pesel of class PolandSpecProvider."""
    obj = PolandSpecProvider()
    pesel = obj.pesel(birth_date=(1993, 7, 18), gender=Gender.FEMALE)
    assert isinstance(pesel, str)
    obj_pesel = '93' + '7' + '18' + '872' + '4' + '0'
    assert pesel == obj_pesel

# Generated at 2022-06-12 00:59:27.528086
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pl = PolandSpecProvider()
    assert pl.pesel()


# Generated at 2022-06-12 00:59:34.002927
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    assert provider.pesel() # Inicial date
    assert provider.pesel() # Inicial date and gender
    assert provider.pesel(birth_date=Datetime().datetime(1960, 2018), gender=Gender.MALE)
    assert provider.pesel(birth_date=Datetime().datetime(1960, 2018), gender=Gender.FEMALE)


# Generated at 2022-06-12 00:59:39.376413
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()
    # PESEL is valid if:
    #   - The first digit is not 0,
    #   - The month number is has values from 1 to 12,
    #   - The day number has values from 0 to 31,
    #   - The number of the series can be from 0 to 999
    assert str(pesel)[:2] != '00' or int(str(pesel)[2:4]) <= 12 or int(str(pesel)[4:6]) <= 31 or\
        0 <= int(str(pesel)[6:9]) <= 999


# Generated at 2022-06-12 00:59:53.393665
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # Given
    seed = 1
    gender = Gender.MALE
    # When
    pesel = PolandSpecProvider(seed=seed).pesel(gender=gender)
    # Then
    assert pesel == "87011201331"



# Generated at 2022-06-12 01:00:04.265238
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test pesel method of PolandSpecProvider."""
    # test for Pesel with random gender
    data = PolandSpecProvider().pesel()
    assert len(data) == 11
    # test for male gender
    data = PolandSpecProvider().pesel(gender=Gender.MALE)
    assert data.endswith('1') or data.endswith('3') or data.endswith('5')\
        or data.endswith('7') or data.endswith('9')
    # test for female gender
    data = PolandSpecProvider().pesel(gender=Gender.FEMALE)
    assert data.endswith('0') or data.endswith('2') or data.endswith('4')\
        or data.endswith('6') or data.endswith('8')
    # test for specific

# Generated at 2022-06-12 01:00:09.233236
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    random.seed(0)
    provider = PolandSpecProvider(seed=0)

    assert provider.pesel(birth_date=datetime.datetime(2000, 1, 1)) == "00120200001"
    assert provider.pesel(gender=Gender.MALE) == '09012440855'
    assert provider.pesel(gender=Gender.FEMALE) == '31181082368'

# Generated at 2022-06-12 01:00:12.381557
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    val = provider.pesel()
    assert isinstance(val, str)
    assert len(val) == 11


# Generated at 2022-06-12 01:00:13.469252
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    print(provider.pesel())


# Generated at 2022-06-12 01:00:19.819423
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    from mimesis.providers.poland import PolandSpecProvider
    poland_spec_provider = PolandSpecProvider()
    below_year = poland_spec_provider.time.datetime(1960, 1970)
    a = poland_spec_provider.pesel(below_year, Gender.MALE)
    b = poland_spec_provider.pesel(below_year, Gender.FEMALE)
    c = poland_spec_provider.pesel(None, Gender.MALE)
    d = poland_spec_provider.pesel(None, Gender.FEMALE)
    assert a[:2] == '60' and len(a) == 11 and a[10] in '13579'
    assert b[:2] == '60' and len(b) == 11 and b[10]

# Generated at 2022-06-12 01:00:27.571781
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test for method pesel"""
    pl_provider = PolandSpecProvider(seed=1)
    result_1 = pl_provider.pesel()
    result_2 = pl_provider.pesel()
    result_3 = pl_provider.pesel(gender=Gender.MALE)
    result_4 = pl_provider.pesel(gender=Gender.FEMALE)
    assert result_1 == '82080781134'
    assert result_2 == '85092433396'
    assert result_3 == '68010229924'
    assert result_4 == '85092929746'


# Generated at 2022-06-12 01:00:29.005460
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    result = PolandSpecProvider().pesel()
    assert result.isdigit()
    assert len(result) == 11

# Generated at 2022-06-12 01:00:36.758930
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()
    assert type(pesel) == str
    assert len(pesel) == 11
    assert pesel.isdigit()

    pesel = PolandSpecProvider().pesel(gender=Gender.MALE)
    assert pesel[-1] in ['1', '3', '5', '7', '9']

    pesel = PolandSpecProvider().pesel(gender=Gender.FEMALE)
    assert pesel[-1] in ['0', '2', '4', '6', '8']

    pesel = PolandSpecProvider().pesel(Datetime().datetime(1940, 2018))
    assert 1940 <= int(pesel[:2]) <= 2099


# Generated at 2022-06-12 01:00:45.506180
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    result = PolandSpecProvider().pesel()
    assert result is not None
    assert len(result) == 11
    assert result.isdigit()
    assert PolandSpecProvider().pesel(Datetime().datetime(), Gender.MALE).endswith('2')
    assert PolandSpecProvider().pesel(Datetime().datetime(), Gender.FEMALE).endswith('1')
    all_valid = True
    for _ in range(10):
        result = PolandSpecProvider().pesel(Datetime().datetime(), Gender.MALE)
        all_valid = all_valid and result.endswith('2')
        result = PolandSpecProvider().pesel(Datetime().datetime(), Gender.FEMALE)
        all_valid = all_valid and result.endsw