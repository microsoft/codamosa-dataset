

# Generated at 2022-06-12 00:58:51.777448
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pl_pesel = provider.pesel()
    assert len(pl_pesel) == 11
    assert int(pl_pesel)

# Generated at 2022-06-12 00:58:55.255049
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    seed(12345)
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert pesel == "78091588811"


# Generated at 2022-06-12 00:59:01.861699
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    from mimesis.enums import Gender
    provider = PolandSpecProvider()
    pesel_male = provider.pesel(gender=Gender.MALE)
    pesel_female = provider.pesel(gender=Gender.FEMALE)
    is_male = True if int(pesel_male[9])%2 else False
    is_female = True if not int(pesel_female[9])%2 else False
    assert(is_male)
    assert(is_female)

# Generated at 2022-06-12 00:59:11.776601
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test the PESEL."""
    provider = PolandSpecProvider(seed=12345)
    assert provider.pesel(gender=Gender.MALE) == '57101246213'
    assert provider.pesel(gender=Gender.FEMALE) == '78121443537'
    assert provider.pesel() == '51112262652'
    assert provider.pesel(Datetime().datetime(1982, 1, 1), Gender.MALE) == '82010040112'
    assert provider.pesel(Datetime().datetime(1982, 1, 1), Gender.FEMALE) == '82010088590'
    assert provider.pesel(Datetime().datetime(1982, 1, 1)) == '82010087109'

# Generated at 2022-06-12 00:59:19.523832
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    for _ in range(100):
        gender = None
        birth_date = None
        pesel = PolandSpecProvider().pesel(birth_date, gender)
        gender = Gender.FEMALE
        birth_date = None
        pesel = PolandSpecProvider().pesel(birth_date, gender)
        gender = Gender.MALE
        birth_date = None
        pesel = PolandSpecProvider().pesel(birth_date, gender)

if __name__ == '__main__':
    test_PolandSpecProvider_pesel()

# Generated at 2022-06-12 00:59:24.691236
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    assert len(provider.pesel()) == 11
    assert provider.pesel() != provider.pesel()
    assert provider.pesel(birth_date=provider.datetime('1990-12-12')) != provider.pesel(birth_date=provider.datetime('1990-12-12'))


# Generated at 2022-06-12 00:59:28.368902
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    assert p.pesel() is not None
    # TODO : real tests


# Generated at 2022-06-12 00:59:34.212246
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    PolandSpecProvider(seed=1)
    assert PolandSpecProvider().pesel(gender='m')=="10123147771"
    #assert PolandSpecProvider().pesel(gender='f') == "05123147772"
    assert PolandSpecProvider().pesel(gender='f') == "70123147779"
    assert PolandSpecProvider().pesel() == "17123147775"


# Generated at 2022-06-12 00:59:38.055579
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test the method pesel of class PolandSpecProvider."""
    gender = Gender.MALE
    p_pesel = PolandSpecProvider().pesel(gender=gender)
    assert p_pesel[-1] in ['1', '3', '5', '7', '9']
    assert p_pesel[:2] in ['40', '42', '44', '46', '48']

# Generated at 2022-06-12 00:59:41.453316
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pl_provider = PolandSpecProvider()
    assert len(pl_provider.pesel(gender=Gender.MALE)) == 11



# Generated at 2022-06-12 00:59:50.221843
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    pesel = p.pesel()
    assert len(pesel) == 11
    assert int(pesel[0:2]) >= 40


# Generated at 2022-06-12 00:59:55.987730
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    test_value = provider.pesel(gender=Gender.MALE) # "first" call for gender
    assert test_value == provider.pesel() # should be the same

    next_value = provider.pesel(gender=Gender.MALE) # "second" call for gender
    assert test_value != next_value
    # because second call is producing "new" value

# Generated at 2022-06-12 01:00:05.771006
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    global pesel_digits
    global year
    global month
    global day

    try:
        assert(len(pesel_digits) == 11)
        while month in range(13):
            assert(month in range(1, 13))
            while day in range(32):
                assert(day in range(1, 32))
                while year in range(2100, 2299):
                    assert(year in range(2100, 2299))
                    if month == 2:
                        assert(day < 30)
                    if month in (4, 6, 9, 11):
                        assert(day < 31)
                    else:
                        assert(day <= 31)
    except NameError:
        print("Please run the program first. The variable you are trying to access has not been defined yet.")

# Generated at 2022-06-12 01:00:15.493611
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.enums import Gender
    import datetime

    tester = PolandSpecProvider()
    person = Person()
    address = Address()

    # checks the correctness of the returned value
    assert len(tester.pesel()) == 11
    assert len(tester.pesel(birth_date=datetime.datetime(2001, 2, 5))) == 11
    assert len(tester.pesel(gender=Gender.MALE)) == 11
    assert len(tester.pesel(gender=Gender.FEMALE)) == 11
    assert len(tester.pesel(gender=Gender.MALE,
                            birth_date=datetime.datetime(2001, 2, 5))) == 11

# Generated at 2022-06-12 01:00:20.893654
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    pesel = p.pesel()

    b = list(str(pesel))
    c = list(str(pesel))

    for i in range(1,10):
        c[i] = str(i)
        if ((int(c[0])+3*int(c[1])+7*int(c[2])+9*int(c[3])+int(c[4])+3*int(c[5])+7*int(c[6])+9*int(c[7])) + 10*int(c[8]) + int(c[9])) % 10 == 0 and (int(c[2]) <= 2 or int(c[2]) >= 5) and (int(c[3]) >= 7 or int(c[3]) <= 8):
            return True


# Generated at 2022-06-12 01:00:26.134326
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    test_gender = Gender.FEMALE
    test_pesel = PolandSpecProvider().pesel(gender=test_gender)
    assert test_pesel[-1] == "0" or test_pesel[-1] == "2" or test_pesel[-1] == "4" or test_pesel[-1] == "6" or test_pesel[-1] == "8"

# Generated at 2022-06-12 01:00:27.777118
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test for method pesel of class PolandSpecProvider."""
    
    p = PolandSpecProvider()

    assert(len(p.pesel()) == 11)

# Generated at 2022-06-12 01:00:29.209183
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()
    assert len(pesel) == 11



# Generated at 2022-06-12 01:00:38.059368
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider(seed=444)
    pesel_list = []
    for _ in range(100):
        pesel = provider.pesel()
        pesel_list.append(pesel)
    people = []
    for p in pesel_list:
        pesel_year = int(p[:2])
        pesel_month_symbol = p[2:4][0]
        pesel_month_symbol_n = int(p[2:4][1])
        pesel_month = int(p[2:4])
        pesel_day = int(p[4:6])
        pesel_serial_no = int(p[6:9])

# Generated at 2022-06-12 01:00:41.251164
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    birth_date =  Datetime().datetime(1940, 2018)
    gender = "MALE"
    pesel = p.pesel(birth_date, gender)
    print(pesel)

# Generated at 2022-06-12 01:00:54.562666
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # Create PolandSpecProvider provider
    provider = PolandSpecProvider()
    # Get pesel
    pesel = provider.pesel()
    # Create PolandSpecProvider provider with seed
    seed_provider = PolandSpecProvider(seed=42)
    # Get pesel
    seed_pesel = seed_provider.pesel()
    # Check that pesels are the same
    assert pesel == seed_pesel == '73041800047'

# Generated at 2022-06-12 01:01:02.374179
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """
    :return: None
    """
    from datetime import datetime
    from mimesis.enums import Gender

    Poland = PolandSpecProvider()
    # Test with gender and birth date
    pesel = Poland.pesel(birth_date=datetime(1980, 1, 1), gender=Gender.MALE)
    assert pesel == '80011102382'
    # Test with gender and without birth date
    pesel = Poland.pesel(gender=Gender.MALE)
    assert len(pesel) == 11
    # Test without gender and with birth date
    pesel = Poland.pesel(birth_date=datetime(1980, 1, 1))
    assert len(pesel) == 11
    # Test without gender and birth date
    pesel = Poland.pesel()
    assert len(pesel) == 11

# Generated at 2022-06-12 01:01:10.592592
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    # Before version 4.0
    provider = PolandSpecProvider(seed=42)
    pesel1 = provider.pesel()
    assert(pesel1  == "56071598500")
    pesel2 = provider.pesel(birth_date=provider.datetime(1980, 1990))
    assert(pesel2 == "80071587400")
    pesel3 = provider.pesel(gender=Gender.MALE)
    assert(pesel3 == "54071588700")
    pesel4 = provider.pesel(birth_date=provider.datetime(1980, 1990),
                            gender=Gender.MALE)
    assert(pesel4 == "80071588100")


# Generated at 2022-06-12 01:01:15.860444
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # Random
    print(PolandSpecProvider().pesel())
    # Custom
    print(PolandSpecProvider().pesel(
        Datetime().datetime(1950, 2000),
        Gender.MALE))
    # Custom
    print(PolandSpecProvider().pesel(
        Datetime().datetime(1950, 2000),
        Gender.FEMALE))

# Unit Test for method regon of class PolandSpecProvider

# Generated at 2022-06-12 01:01:25.858058
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel() of class PolandSpecProvider."""
    pl_provider = PolandSpecProvider()

    # test 1 pesel por correct birth date and gender
    birth_date = Datetime().datetime(2000, 1, 1, seed=5).date()
    print("Test 1. Pesel por correct birth date and gender")
    print("Input: birth date: {}".format(birth_date))
    pesel = pl_provider.pesel(birth_date, gender='male')
    print("Output: {}".format(pesel))
    assert len(pesel) == 11
    assert pesel[4:6] == '01'
    assert pesel[6:8] == '01'
    assert pesel[8] in ['1', '3', '5', '7', '9']

    # test 2 pesel por

# Generated at 2022-06-12 01:01:29.981049
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    assert PolandSpecProvider().pesel(birth_date=Datetime().datetime(2000, 2018), gender=Gender.MALE) == '00121817171'
    assert PolandSpecProvider().pesel(birth_date=Datetime().datetime(2000, 2018), gender=Gender.FEMALE) == '00121817172'
    assert PolandSpecProvider().pesel() != PolandSpecProvider().pesel()

# Generated at 2022-06-12 01:01:31.616929
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pass



# Generated at 2022-06-12 01:01:33.464736
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-12 01:01:36.921503
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    import mimesis.builtins.poland
    psp = mimesis.builtins.poland.PolandSpecProvider()
    # psp.pesel(birth_date = DateTime(), gender = Gender.MALE, seed = None)
    print(psp.pesel())



# Generated at 2022-06-12 01:01:40.862780
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel(gender=Gender.MALE)
    print(pesel)
    assert len(pesel) == 11
    assert pesel[6] == '6' or pesel[6] == '8'

# Generated at 2022-06-12 01:01:50.716640
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():

    pesel = PolandSpecProvider().pesel(birth_date=Datetime().datetime(1986, 11, 4), gender='MALE')

    print(pesel)


test_PolandSpecProvider_pesel()

# Generated at 2022-06-12 01:01:54.497559
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    person = PolandSpecProvider()
    pesel = person.pesel(gender= Gender.MALE)
    pesel = pesel.replace(pesel[-1], str((int(pesel[-1]) + 1) % 10))
    assert str(''.join(str(pesel)))

# Generated at 2022-06-12 01:01:56.796959
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    p.pesel(birth_date=DateTime.current_datetime(), gender=Gender.FEMALE)
    

# Generated at 2022-06-12 01:02:02.154587
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    from mimesis.enums import Gender

    provider = PolandSpecProvider(seed=12345)
    pesel = provider.pesel(gender=Gender.MALE)
    assert pesel == '85122909567'

    provider = PolandSpecProvider(seed=12345)
    pesel = provider.pesel(gender=Gender.FEMALE)
    assert pesel == '85522909567'


# Generated at 2022-06-12 01:02:03.867274
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()
    assert isinstance(pesel, str)
    assert len(pesel) == 11


# Generated at 2022-06-12 01:02:06.302660
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
	mimesis_poland = PolandSpecProvider()
	for i in range(5):
		pesel = mimesis_poland.pesel()
		assert type(pesel) == str
		assert pesel.isdigit()
		assert len(pesel) == 11



# Generated at 2022-06-12 01:02:11.380853
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    pesel_int = int(pesel)
    year = int(pesel[0:2])
    month = int(pesel[2:4])
    day = int(pesel[4:6])
    serie = int(pesel[6:9])
    pesel_digit = int(pesel[10:11])
    pesel_coeffs = (9, 7, 3, 1, 9, 7, 3, 1, 9, 7)
    pesel_sum = 0
    for i in range(10):
        pesel_sum += pesel_coeffs[i] * int(pesel[i])
    checksum_digit = pesel_sum % 10
    assert checksum_digit

# Generated at 2022-06-12 01:02:14.343416
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    from mimesis.enums import Gender
    from datetime import date
    pesel = PolandSpecProvider().pesel(birth_date=date(1989, 11, 13), gender=Gender.MALE)
    print(pesel)


# Generated at 2022-06-12 01:02:17.365195
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    

# Generated at 2022-06-12 01:02:22.669069
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    assert provider.pesel(birth_date=Datetime().datetime(2015, 2016), gender=Gender.MALE).isnumeric()
    assert provider.pesel(birth_date=Datetime().datetime(2015, 2016), gender=Gender.FEMALE).isnumeric()
    assert provider.pesel(birth_date=Datetime().datetime(2015, 2016)).isnumeric()
    assert provider.pesel().isnumeric()
    assert provider.pesel(birth_date=Datetime().datetime(1900, 2000)).isnumeric()


# Generated at 2022-06-12 01:02:34.309254
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    import pytest
    from mimesis.enums import Gender
    result = PolandSpecProvider().pesel(
        birth_date=Datetime().datetime(1950, 1950),
        gender=Gender.MALE)
    assert len(result) == 11
    result = PolandSpecProvider().pesel(
        birth_date=Datetime().datetime(2050, 2050),
        gender=Gender.FEMALE)
    assert len(result) == 11

# Generated at 2022-06-12 01:02:35.781957
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    assert len(p.pesel()) == 11
    assert p.pesel() != p.pesel()


# Generated at 2022-06-12 01:02:38.276724
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    my_PolandSpecProvider = PolandSpecProvider()
    pesel = my_PolandSpecProvider.pesel(birth_date = Datetime().datetime(1950, 2018),
              gender = Gender.FEMALE)
    assert len(pesel) == 11


# Generated at 2022-06-12 01:02:43.653628
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    a = PolandSpecProvider(0)
    print(a.pesel())
    a = PolandSpecProvider(1)
    print(a.pesel(gender=Gender.MALE))
    a = PolandSpecProvider(2)
    print(a.pesel(gender=Gender.FEMALE))
    a = PolandSpecProvider(3)
    print(a.pesel(birth_date=Datetime().datetime(1940, 2018)))
    a = PolandSpecProvider(4)
    print(a.pesel(birth_date=Datetime().datetime(1940, 2018),
                  gender=Gender.MALE))
    a = PolandSpecProvider(5)
    print(a.pesel(birth_date=Datetime().datetime(1940, 2018),
                  gender=Gender.FEMALE))


# Generated at 2022-06-12 01:02:50.994042
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    import datetime
    p = PolandSpecProvider()
    p.pesel(birth_date=datetime.datetime(1992, 7, 24),
            gender=Gender.MALE)
    assert p.pesel(birth_date=datetime.datetime(1992, 7, 24),
                   gender=Gender.MALE) == '92072443175'
    assert p.pesel(birth_date=datetime.datetime(1992, 7, 24),
                   gender=Gender.FEMALE) == '92072483175'


# Generated at 2022-06-12 01:03:00.584461
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    #1. Code should not fail
    provider = PolandSpecProvider()
    provider.pesel(birth_date=Datetime().datetime(1970, 1, 1, 12, 0, 0), gender=Gender.MALE)
    provider.pesel(birth_date=Datetime().datetime(1970, 1, 1, 12, 0, 0), gender=Gender.FEMALE)
    provider.pesel(birth_date=Datetime().datetime(1970, 1, 1, 12, 0, 0), gender=None)

    #2. All numbers have to have 11 digits
    for i in range(100):
        assert len(provider.pesel(birth_date=Datetime().datetime(1970, 1, 1, 12, 0, 0), gender=Gender.MALE)) == 11
    
    #3. All numbers have to be equal


# Generated at 2022-06-12 01:03:06.392738
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider(seed=1)
    # Unit test for method pesel of class PolandSpecProvider
    assert provider.pesel(
        birth_date=Datetime(seed=1).datetime(1950, 2000),
        gender=Gender.MALE) == '95121544900'



# Generated at 2022-06-12 01:03:15.354306
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    assert p.pesel(birth_date=Datetime().datetime(), gender=Gender.MALE) == '000001011149' 
    assert p.pesel(birth_date=Datetime().datetime(), gender=Gender.FEMALE) == '000002021149' 
    assert p.pesel(birth_date=Datetime().datetime(1920,2018), gender=Gender.MALE) == '000001020649' 
    assert p.pesel(birth_date=Datetime().datetime(1918,2018), gender=Gender.MALE) == '000001020449'  
    assert p.pesel(birth_date=Datetime().datetime(2020,2090), gender=Gender.MALE) == '000001011149' 

# Generated at 2022-06-12 01:03:17.274940
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    assert PolandSpecProvider().pesel() == '96810315473'


# Generated at 2022-06-12 01:03:28.781188
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    instance1 = PolandSpecProvider()
    pesel = instance1.pesel(gender=Gender.MALE)
    assert type(pesel) is str
    assert len(pesel) == 11
    year = int(pesel[0:2])
    assert year in range(0, 99)
    month = int(pesel[2:4])
    assert month in range(0, 99) or month in range(80, 99)
    day = int(pesel[4:6])
    assert day in range(0,99)
    series_number = int(pesel[6:9])
    assert series_number in range(0,999)
    gender = int(pesel[9])
    assert gender % 2 == 1
    checksum_digit = int(pesel[10])

# Generated at 2022-06-12 01:03:44.624885
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()

    # Check probability: gender == MALE
    sample = [p.pesel(gender=Gender.MALE) for _ in range(100)]
    gender_digit = [int(s[10]) for s in sample]
    male_counts = gender_digit.count(1) + gender_digit.count(3) + gender_digit.count(5) + gender_digit.count(7) + gender_digit.count(9)

# Generated at 2022-06-12 01:03:52.128668
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():

    # Create PolandSpecProvider provider
    poland_provider = PolandSpecProvider()

    # Create DataTime provider
    datetime_provider = Datetime()

    # Get random date
    date = datetime_provider.date(1940, 2018)

    # Get year from date
    year = date.year

    # Get month from date
    month = date.month

    # Get day from date
    day = date.day

    # Try to get pesel for male
    pesel = poland_provider.pesel(date, Gender.MALE)

    # Convert pesel to list
    pesel_array = [int(d) for d in pesel]

    # Check year in pesel

# Generated at 2022-06-12 01:03:57.019382
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    t = provider.pesel()
    print(t)
    t = provider.pesel(birth_date=datetime(2000, 3, 7, 13, 20, 30))
    print(t)
    t = provider.pesel(datetime(2000, 3, 7, 13, 20, 30), Gender.FEMALE)
    print(t)


# Generated at 2022-06-12 01:03:57.898655
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    PolandSpecProvider().pesel()

# Generated at 2022-06-12 01:04:00.789909
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    assert(PolandSpecProvider.pesel.__annotations__['return'] == str)
    assert(PolandSpecProvider().pesel() != PolandSpecProvider().pesel())
    assert(len(PolandSpecProvider().pesel()) == 11)


# Generated at 2022-06-12 01:04:06.074463
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    import pytest
    from mimesis.enums import Gender
    from mimesis.providers import Datetime
    provider = PolandSpecProvider()
    date = Datetime().datetime(1940, 2018)
    result = provider.pesel(birth_date=date, gender=Gender.MALE)
    # print(result)
    assert len(result) == 11

# Generated at 2022-06-12 01:04:08.036667
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    expected = '92010215204'
    actual = provider.pesel()
    assert actual == expected, (actual, expected)


# Generated at 2022-06-12 01:04:11.672063
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pl = PolandSpecProvider()
    for _ in range(10):
        print(pl.pesel())


# Generated at 2022-06-12 01:04:14.201294
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    g = PolandSpecProvider()
    res = g.pesel(Gender.FEMALE)
    assert res == '98041113183'


# Generated at 2022-06-12 01:04:16.259505
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11

# Generated at 2022-06-12 01:04:27.041545
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    wr = PolandSpecProvider()
    pesel_result = wr.pesel()
    assert len(pesel_result) == 11
    assert isinstance(pesel_result, str)


# Generated at 2022-06-12 01:04:30.107418
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    pl_provider = PolandSpecProvider()
    pesel = pl_provider.pesel()
    assert len(pesel) == 11
    assert pl_provider.validate_pesel(pesel) is True



# Generated at 2022-06-12 01:04:33.165242
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p1 = PolandSpecProvider()
    a = p1.pesel()
    b = p1.pesel()
    if (a==b):
        print(a)
        print(b)


# Generated at 2022-06-12 01:04:35.122011
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    test_pesel = provider.pesel()
    assert isinstance(test_pesel, str)
    assert len(test_pesel) == 11


# Generated at 2022-06-12 01:04:38.992515
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test pesel function"""
    provider = PolandSpecProvider()
    assert provider.pesel()[0] == '0' or provider.pesel()[0] == '1'
    assert len(provider.pesel()) == 11


# Generated at 2022-06-12 01:04:40.678925
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel(birth_date=Datetime().datetime(1930, 2029))
    assert len(pesel) == 11


# Generated at 2022-06-12 01:04:50.176943
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # Given
    def format_pesel(pesel):
        return "".join([str(int(i) + 1) for i in str(pesel)])
    # When
    p1 = PolandSpecProvider(seed=123456).pesel()
    p2 = PolandSpecProvider(seed=123456).pesel()
    p3 = PolandSpecProvider(seed=123456).pesel(gender=Gender.FEMALE)
    p4 = PolandSpecProvider(seed=123456).pesel(gender=Gender.MALE)
    p5 = PolandSpecProvider(seed=123456).pesel(birth_date=Datetime().datetime(year=2003, month=3, day=3))

    # Then
    assert format_pesel(p1)=="80380105015"
    assert p1==p2

# Generated at 2022-06-12 01:04:52.136453
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # Create object of class PolandSpecProvider
    obj = PolandSpecProvider()
    # Validate method pesel of class PolandSpecProvider
    assert(obj.pesel() == '80100353628')

# Generated at 2022-06-12 01:05:01.661804
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    genderList = [Gender.FEMALE, Gender.MALE]
    gender = genderList[random.randint(0,2)]
    dateBirth = Datetime().datetime(1940, 2018)
    peselNumber = PolandSpecProvider(seed=random.randint(0, 1000)).pesel(birth_date=dateBirth, gender=gender)

    peselNumberList = [int(d) for d in str(peselNumber)]
    year = 2000 + int(''.join(str(d) for d in peselNumberList[:2]))
    month = int(''.join(str(d) for d in peselNumberList[2:4]))
    day = int(''.join(str(d) for d in peselNumberList[4:6]))

# Generated at 2022-06-12 01:05:05.200179
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pl = PolandSpecProvider()
    assert pl.pesel() == '99101702791'
