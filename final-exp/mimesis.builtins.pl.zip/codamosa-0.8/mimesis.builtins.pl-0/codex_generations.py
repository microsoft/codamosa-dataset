

# Generated at 2022-06-12 00:58:53.553482
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # Checks if pesel is 11 digits long:
    # For example: '83051605360'
    result = PolandSpecProvider().pesel()
    assert len(result) == 11


# Generated at 2022-06-12 00:58:56.323560
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    PolandSpecProvider.pesel()


# Generated at 2022-06-12 00:58:59.354041
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    pl = PolandSpecProvider()
    pesel = pl.pesel()
    assert len(pesel) == 11

# Generated at 2022-06-12 00:59:02.684916
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # GIVEN
    prv = PolandSpecProvider(seed=48)
    # WHEN
    result = prv.pesel(gender=Gender.MALE)
    # THEN
    assert result == '82103002208'

# Generated at 2022-06-12 00:59:13.121258
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
  """docstring"""
  # Create an instance of PolandSpecProvider
  poland_spec_provider = PolandSpecProvider()
  # Create an instance of Datetime
  datetime = Datetime()
  # Return a datetime object with the year = 1990, month = 1 and day = 1
  date_object = datetime.datetime(1990, 1, 1)
  # Assert that the pesel of a female with a birth date of 01/01/1990 is
  # generated correctly
  assert poland_spec_provider.pesel(birth_date=date_object, gender=Gender.FEMALE) == "90101012354"
  # Assert that the pesel of a male with a birth date of 01/01/1990 is
  # generated correctly

# Generated at 2022-06-12 00:59:16.542006
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    print(p.pesel(birth_date=Datetime().datetime(1990, 1, 1)))


if __name__ == '__main__':
    test_PolandSpecProvider_pesel()

# Generated at 2022-06-12 00:59:22.298938
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    plprovider = PolandSpecProvider()
    for i in range(100):
        pesel = plprovider.pesel()
        print(pesel)
        assert pesel != None


if __name__ == '__main__':
    print('------------')
    test_PolandSpecProvider_pesel()

# Generated at 2022-06-12 00:59:28.586044
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Create a PolandSpecProvider object and test the pesel method."""
    poland_provider = PolandSpecProvider()
    pesel = poland_provider.pesel()
    assert len(pesel) == 11 and isinstance(pesel, str)
    pesel = poland_provider.pesel(gender=Gender.MALE)
    assert len(pesel) == 11 and isinstance(pesel, str)
    pesel = poland_provider.pesel(gender=Gender.MALE)
    assert len(pesel) == 11 and isinstance(pesel, str)
    pesel = poland_provider.pesel(gender=Gender.FEMALE)
    assert len(pesel) == 11 and isinstance(pesel, str)


# Generated at 2022-06-12 00:59:33.736410
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    assert p.pesel(gender=Gender.FEMALE).endswith("0248")
    assert p.pesel(gender=Gender.MALE).endswith("1248")
    assert p.pesel(gender=Gender.UNKNOWN).endswith("2248")


# Generated at 2022-06-12 00:59:36.912109
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    assert provider.pesel(gender=Gender.MALE) == provider.pesel(gender=Gender.MALE)
    assert provider.pesel(gender=Gender.FEMALE) == provider.pesel(gender=Gender.FEMALE)



# Generated at 2022-06-12 00:59:49.781418
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # Create object PolandSpecProvider
    obj = PolandSpecProvider()
    # Create variables
    birth_date = Datetime().datetime(1940, 2018)
    gender = Gender.MALE
    # Assign value to pesel_number
    pesel_number = obj.pesel(birth_date=birth_date, gender=gender)
    # Check if value of pesel_number is string
    assert isinstance(pesel_number, str)
    # Check if length of pesel_number is equal to 11
    assert len(pesel_number) == 11
    # Check if value of pesel_number is integer
    assert pesel_number.isdigit()


# Generated at 2022-06-12 00:59:59.628824
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    MyDate = Datetime(2010,2018)
    birth_date = MyDate.datetime()
    gender = Gender.MALE
    pesel = provider.pesel(birth_date,gender)
    print(pesel)
    print(gender)
    print()

    MyDate1 = Datetime(2010,2018)
    birth_date1 = MyDate1.datetime()
    gender1 = Gender.FEMALE
    pesel1 = provider.pesel(birth_date1,gender1)
    print(pesel1)
    print(gender1)
    print()
    for i in range(4):
        random_gender = Gender.MALE
        pesel_M = provider.pesel(gender = random_gender)
        print(pesel_M)

# Generated at 2022-06-12 01:00:10.927103
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    testData = [
        {
            'in' : {
                'birth_date' : datetime(1980,2,1),
                'gender' : Gender.MALE
            },
            'out' : ['80021116732']
        },
        {
            'in' : {
                'birth_date' : datetime(1880,2,1),
                'gender' : Gender.FEMALE
            },
            'out' : ['80211736136']
        }
    ]
    for test in testData:
        result = PolandSpecProvider().pesel(test["in"]["birth_date"], test["in"]["gender"])
        if result not in test["out"]:
            raise Exception("Wrong pesel, got " + result + ", expected one from " + str(test["out"]))
   

# Generated at 2022-06-12 01:00:14.148971
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    seed = 'Test pl'
    gender = Gender.MALE
    pesel_pl = PolandSpecProvider(seed)
    expected = '53082707549'
    result = pesel_pl.pesel(gender=gender)
    assert result == expected

# Generated at 2022-06-12 01:00:15.844042
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pl = PolandSpecProvider()
    assert isinstance(pl.pesel(), str)
    assert len(pl.pesel()) == 11


# Generated at 2022-06-12 01:00:17.809301
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_provider = PolandSpecProvider()
    return poland_provider.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.MALE)


# Generated at 2022-06-12 01:00:27.431680
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    my_datetime = Datetime()
    my_date = my_datetime.datetime(1940, 2018)
    my_date_year = my_date.date().year
    my_date_month = my_date.date().month
    my_date_day = my_date.date().day
    test_pesel = PolandSpecProvider().pesel(my_date, Gender.MALE)
    assert len(test_pesel) == 11
    assert int(test_pesel[0:2]) == my_date_year%100
    assert int(test_pesel[2:4]) == my_date_month
    assert int(test_pesel[4:6]) == my_date_day
    assert int(test_pesel[10]) in (1,3,5,7,9)

# Generated at 2022-06-12 01:00:33.277126
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    P = 'PolandSpecProvider'
    assert PolandSpecProvider().pesel().isnumeric()
    assert PolandSpecProvider().pesel().__len__() == 11
    assert PolandSpecProvider().pesel(birth_date='05-06-1998').startswith('98')
    assert PolandSpecProvider().pesel(birth_date='05-06-1998', gender=Gender.MALE).endswith('5')
    assert PolandSpecProvider().pesel(birth_date='05-06-1998', gender=Gender.FEMALE).endswith('6')
    # 'pesel-validator' library 100% sure that Pesel number '12345678910' is a valid, but probably it isn't

# Generated at 2022-06-12 01:00:40.240858
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # for gender in Gender:
    #     print(gender.name, PolandSpecProvider().pesel(gender=gender))
    print(PolandSpecProvider().pesel())
    print(PolandSpecProvider().pesel())
    print(PolandSpecProvider().pesel())
    print(PolandSpecProvider().pesel())
    print(PolandSpecProvider().pesel())
    print(PolandSpecProvider().pesel())
    print(PolandSpecProvider().pesel())

if __name__ == '__main__':
    test_PolandSpecProvider_pesel()

# Generated at 2022-06-12 01:00:44.042538
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    polandSpecProvider = PolandSpecProvider(seed=None)
    assert len(polandSpecProvider.pesel(None, Gender.FEMALE)) == 11
    assert len(polandSpecProvider.pesel(None, Gender.MALE)) == 11
    assert len(polandSpecProvider.pesel(None)) == 11


# Generated at 2022-06-12 01:01:27.685911
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    a = PolandSpecProvider()
    assert a.pesel(gender=Gender.MALE) in ('98031717234', '98031717234',
                                           '98031717234', '98031717234',
                                           '98031717234')
    assert a.pesel(gender=Gender.FEMALE) in ('98031722423', '98031722423',
                                             '98031722423', '98031722423',
                                             '98031722423')
    assert len(a.pesel()) == 11


# Generated at 2022-06-12 01:01:29.820948
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():

    for _ in range(100):
        p=PolandSpecProvider()
        pesel=p.pesel()
        print(pesel)
        assert(len(pesel) == 11)


# Generated at 2022-06-12 01:01:32.396837
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    a = PolandSpecProvider()
    assert a.pesel() != a.pesel()



# Generated at 2022-06-12 01:01:40.385010
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():

    #Test 1
    pesel = PolandSpecProvider().pesel()

    #check 1
    #assert pesel == '96040100234'
    print(pesel)

    #Test 2
    pesel = PolandSpecProvider().pesel(Datetime().datetime(1985, 2010), Gender.FEMALE)

    #check 2
    #assert pesel == '85040402394'
    print(pesel)

    #Test 3
    pesel = PolandSpecProvider().pesel(Datetime().datetime(1815, 1900), Gender.MALE)

    #check 3
    #assert pesel == '96010314582'
    print(pesel)


# Generated at 2022-06-12 01:01:44.420263
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    assert provider.pesel()
    assert provider.pesel(gender=Gender.MALE)
    assert provider.pesel(gender=Gender.FEMALE)
    assert provider.pesel(birth_date=Datetime().datetime(2017, 2017))
    assert provider.pesel(birth_date=Datetime().datetime(2017, 2017), gender=Gender.MALE)
    assert provider.pesel(birth_date=Datetime().datetime(2017, 2017), gender=Gender.FEMALE)

# Generated at 2022-06-12 01:01:51.860654
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():

    polandSpecProvider = PolandSpecProvider()

    pesel = polandSpecProvider.pesel()
    pesel_coeff = [9,7,3,1,9,7,3,1,9,7]
    pesel_digits = [int(d) for d in pesel]
    sum_v = sum([nc * nd for nc, nd in zip(pesel_coeff, pesel_digits)])

    valid_pesel = sum_v % 10

    assert(valid_pesel == int(pesel[-1]))



# Generated at 2022-06-12 01:02:01.799232
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    class Test:
        def test_pesel(self, gender, pesel_number, pesel_year, pesel_month, pesel_day):
            provider = PolandSpecProvider()
            pesel = provider.pesel(gender)
            assert pesel == pesel_number
            assert str(pesel[0:2]) == pesel_year
            assert str(pesel[2:4]) == pesel_month
            assert str(pesel[4:6]) == pesel_day

# Generated at 2022-06-12 01:02:04.699305
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    assert p.pesel() == '44081715253'
    assert p.pesel() == '74121601214'
    assert p.pesel() == '54042701467'
    assert p.pesel() == '68010401192'
    assert p.pesel() == '60082901571'

# Generated at 2022-06-12 01:02:06.536952
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider(seed=12345).pesel(birth_date=Datetime(seed=12345).datetime(1940, 2018), gender='m')
    assert pesel == '87031502660'

# Generated at 2022-06-12 01:02:07.772577
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    testa = PolandSpecProvider()
    assert len(testa.pesel()) == 11
    assert testa.pesel().isdigit()