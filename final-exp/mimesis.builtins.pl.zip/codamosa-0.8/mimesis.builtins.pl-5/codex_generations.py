

# Generated at 2022-06-12 00:58:49.554411
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    temp = PolandSpecProvider()
    assert len(temp.pesel()) == 11



# Generated at 2022-06-12 00:58:51.180374
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()

    assert len(pesel) == 11
    assert pesel[-1] == str(int(pesel[:-1]) % 10)

# Generated at 2022-06-12 00:58:57.391302
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    assert len(PolandSpecProvider().pesel()) == 11
    assert PolandSpecProvider().pesel().isdigit()
    assert len(PolandSpecProvider().pesel(birth_date='2002-06-29', gender=Gender.MALE)) == 11
    assert PolandSpecProvider().pesel(birth_date='2002-06-29', gender=Gender.MALE).isdigit()


# Generated at 2022-06-12 00:59:04.587288
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from datetime import datetime

    provider = PolandSpecProvider()
    assert isinstance(provider, PolandSpecProvider)
    provider.seed(23)
    # my pesel
    pesel = provider.pesel(
        datetime(1994, 11, 9), Gender.MALE
    )
    print(pesel)
    assert len(provider.pesel()), 11
    assert str(pesel) == "94110908201"

# Generated at 2022-06-12 00:59:14.052511
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    test = PolandSpecProvider()
    assert(len(test.pesel()) == 11)
    assert(test.pesel(birth_date=test.datetime(2000, 2018), gender=1)[-1] == '1' or test.pesel(birth_date=test.datetime(2000, 2018), gender=1)[-1] == '3'  \
           or test.pesel(birth_date=test.datetime(2000, 2018), gender=1)[-1] == '5' or test.pesel(birth_date=test.datetime(2000, 2018), gender=1)[-1] == '7' \
           or test.pesel(birth_date=test.datetime(2000, 2018), gender=1)[-1] == '9')

# Generated at 2022-06-12 00:59:15.629527
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_provider = PolandSpecProvider()
    x = poland_provider.pesel()
    print(x)

# Generated at 2022-06-12 00:59:26.220543
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """
    Test for method pesel of class PolandSpecProvider
    """
    from mimesis.builtins import PolandSpecProvider
    import random
    random.seed(42)
    poland_pesel = PolandSpecProvider()
    assert poland_pesel.pesel(birth_date=poland_pesel.datetime(1940,2018), gender=Gender.MALE) == '93052521670'
    assert poland_pesel.pesel(birth_date=poland_pesel.datetime(1940,2018),gender=Gender.FEMALE) == '18012010769'
    assert poland_pesel.pesel(birth_date=poland_pesel.datetime(1940,2018)) == '72020908931'
    

# Generated at 2022-06-12 00:59:36.985410
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    print("---- test_PolandSpecProvider_pesel ----")
    print("Expected values:")
    psp = PolandSpecProvider(123)
    print("PESEL = {}".format(psp.pesel()))
    print("PESEL = {}".format(psp.pesel()))
    print("PESEL = {}".format(psp.pesel()))
    print("PESEL = {}".format(psp.pesel()))
    print("PESEL = {}".format(psp.pesel()))
    print("PESEL = {}".format(psp.pesel()))
    print("PESEL = {}".format(psp.pesel()))
    print("PESEL = {}".format(psp.pesel()))

# Generated at 2022-06-12 00:59:45.557215
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    female_pesel = provider.pesel(gender=Gender.FEMALE)
    male_pesel = provider.pesel(gender=Gender.MALE)
    print("\nPesel number for female: " + female_pesel )
    print("Pesel number for male: " + male_pesel)

if __name__ == '__main__':
    import doctest

    doctest.testmod()
    test_PolandSpecProvider_pesel()

# Generated at 2022-06-12 00:59:46.611592
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()
    assert isinstance(pesel, str)
    assert len(pesel) == 11


# Generated at 2022-06-12 00:59:53.552529
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11

# Generated at 2022-06-12 01:00:01.378354
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    import mimesis.enums
    pesel = PolandSpecProvider().pesel(gender=mimesis.enums.Gender.MALE)
    print(pesel)
    assert len(pesel) == 11
    listOfPesels = []
    for i in range(5000):
        listOfPesels.append(PolandSpecProvider().pesel(gender=mimesis.enums.Gender.MALE))
    for pesel in listOfPesels:
        print(pesel)
        assert len(pesel) == 11


# Generated at 2022-06-12 01:00:03.385426
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    print(pesel)


# Generated at 2022-06-12 01:00:13.362135
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pl_provider = PolandSpecProvider()
    genders = [
        Gender.MALE,
        Gender.FEMALE,
        None
    ]
    for gender in genders: 
        pesel = pl_provider.pesel(gender=gender)
        assert len(pesel) == 11

# Generated at 2022-06-12 01:00:16.288406
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider"""
    pr = PolandSpecProvider()
    pesel = pr.pesel(birth_date = pr.datetime(1940, 2018))
    assert type(pesel) == str and len(pesel) == 11


# Generated at 2022-06-12 01:00:26.062088
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    a = p.pesel(birth_date=Datetime().datetime(2000, 1, 1), gender=Gender.MALE)
    b = p.pesel(birth_date=Datetime().datetime(2000, 1, 1), gender=Gender.FEMALE)
    c = p.pesel(birth_date=Datetime().datetime(1950, 1, 1), gender=Gender.MALE)
    d = p.pesel(birth_date=Datetime().datetime(1950, 1, 1), gender=Gender.FEMALE)
    e = p.pesel(birth_date=Datetime().datetime(2000, 1, 1))

    assert len(a) == 11
    assert int(a[0:2]) == 20
    assert int(a[2:4]) == 1
   

# Generated at 2022-06-12 01:00:32.515022
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test pesel of class PolandSpecProvider."""
    # tests for correct functionality
    provider = PolandSpecProvider(seed=12345)
    pesel = provider.pesel(birth_date=provider.datetime(1990, 2018),
                           gender=Gender.MALE)
    pesel2 = provider.pesel(birth_date=provider.datetime(1990, 2018),
                            gender=Gender.MALE)
    assert pesel == '90210609867'
    assert pesel2 == '90210609867'
    pesel = provider.pesel(birth_date=provider.datetime(1990, 2018),
                           gender=Gender.FEMALE)

# Generated at 2022-06-12 01:00:41.054928
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    import datetime
    provider = PolandSpecProvider()
    date_obj = datetime.datetime.strptime("20-09-2000", "%d-%m-%Y")
    gender = Gender.MALE
    result = provider.pesel(birth_date=date_obj, gender=gender)
    assert result[2:4] == "09"
    assert result[4:6] == "20"
    assert result[0:2] == "20"
    assert result[6:8] in ["21", "22", "23", "24", "25", "26", "27", "28", "29", "30"]
    assert result[9] in "13579"
    assert len(result) == 11

# Generated at 2022-06-12 01:00:49.616932
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Tests PolandSpecProvider.pesel() for several values"""
    pl_provider_male = PolandSpecProvider(seed=1)
    assert pl_provider_male.pesel(gender=Gender.MALE) == '53082766002'
    assert pl_provider_male.pesel(gender=Gender.MALE) == '19471714252'
    assert pl_provider_male.pesel(gender=Gender.MALE) == '52051553190'
    pl_provider_female = PolandSpecProvider(seed=2)
    assert pl_provider_female.pesel(gender=Gender.FEMALE) == '67100208417'
    assert pl_provider_female.pesel(gender=Gender.FEMALE) == '89032593107'
    assert pl_provider_

# Generated at 2022-06-12 01:00:51.976163
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    from mimesis import PolandSpecProvider
    obj = PolandSpecProvider()
    assert len( obj.pesel()) == 11
    assert '-' not in obj.pesel()

test_PolandSpecProvider_pesel()