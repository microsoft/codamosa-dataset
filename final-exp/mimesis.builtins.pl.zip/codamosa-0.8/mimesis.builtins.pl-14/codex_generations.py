

# Generated at 2022-06-12 00:59:03.425294
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_provider = PolandSpecProvider()
    pesel = poland_provider.pesel()
    #print(f"pesel = {pesel}")
    assert len(pesel) == 11


# Generated at 2022-06-12 00:59:07.542931
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    tester = PolandSpecProvider()
    test_pesel = tester.pesel(birth_date='2000-1-1',gender=Gender.MALE)
    assert test_pesel == '0009017000', "Incorrect PESEL"

# Generated at 2022-06-12 00:59:10.245576
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    p = PolandSpecProvider(seed=6)
    assert p.pesel() == "95030246223"

# Generated at 2022-06-12 00:59:13.756738
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Tests whether the method pesel generates a Pesel
    with the appropriate length."""
    for i in range(100):
        pl = PolandSpecProvider()
        pesel = pl.pesel()
        assert len(pesel) == 11, 'The length of the generated pesel is inappropriate'



# Generated at 2022-06-12 00:59:14.689459
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    PolandSpecProvider().pesel()


# Generated at 2022-06-12 00:59:23.100097
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    assert provider.pesel(birth_date=Datetime().datetime(1999, 1, 1)) == "99011123456"
    assert provider.pesel(birth_date=Datetime().datetime(1999, 1, 1), gender=Gender.MALE) == "99011123476"
    assert provider.pesel(birth_date=Datetime().datetime(1999, 1, 1), gender=Gender.FEMALE) == "99011123406"
    assert provider.pesel() != "00111123400"


# Generated at 2022-06-12 00:59:23.863479
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():

    pol = PolandSpecProvider()
    assert pol.pesel().__len__() == 11


# Generated at 2022-06-12 00:59:28.962513
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # GIVEN
    provider = PolandSpecProvider()
    # WHEN
    myPesel = provider.pesel()
    # THEN
    assert(len(myPesel) == 11)

# Generated at 2022-06-12 00:59:30.096249
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    assert len(PolandSpecProvider().pesel()) == 11

# Generated at 2022-06-12 00:59:38.200169
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    from mimesis.enums import Gender
    from mimesis.providers import PolandSpecProvider
    from datetime import date
    p = PolandSpecProvider()
    birth_date = date(1977, 1, 1)
    pesel = p.pesel(birth_date)
    assert len(pesel) == 11
    assert pesel[0] == '9'

    birth_date = date(1940, 1, 1)
    pesel = p.pesel(birth_date)
    assert pesel[0] == '3'

    birth_date = date(2018, 1, 1)
    pesel = p.pesel(birth_date)
    assert pesel[0] == '8'



# Generated at 2022-06-12 00:59:53.319605
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    assert PolandSpecProvider(region='pl').pesel() == '81091633305'
    assert PolandSpecProvider(region='pl').pesel(birth_date='1998-12-14', gender=Gender.FEMALE) == '98121422305'

# Generated at 2022-06-12 00:59:55.128055
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()
    assert len(pesel) == 11

# Generated at 2022-06-12 01:00:03.426376
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    import datetime
    # Test 1
    print('**** Test 1 ****')
    gender = Gender.MALE
    birth_date = datetime.datetime.now()
    result = PolandSpecProvider().pesel(birth_date, gender)
    print(result)
    print()
    # Test 2
    print('**** Test 2 ****')
    birth_date = datetime.datetime.now()
    result = PolandSpecProvider().pesel(birth_date)
    print(result)
    print()
    # Test 3
    print('**** Test 3 ****')
    result = PolandSpecProvider().pesel()
    print(result)


# Generated at 2022-06-12 01:00:04.709257
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    assert PolandSpecProvider().pesel().__len__() == 11

# Generated at 2022-06-12 01:00:14.467475
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_provider = PolandSpecProvider()
    pesel = poland_provider.pesel(birth_date=poland_provider.datetime(1940, 2018, '%Y-%m-%d'), gender=Gender.MALE)
    assert str.isdigit(pesel)
    assert len(pesel) == 11
    print(pesel)

    poland_provider = PolandSpecProvider()
    pesel = poland_provider.pesel(birth_date=poland_provider.datetime(1940, 2018, '%Y-%m-%d'), gender=Gender.FEMALE)
    assert str.isdigit(pesel)
    assert len(pesel) == 11
    print(pesel)

    poland_provider = PolandSpecProvider()
    pesel = poland

# Generated at 2022-06-12 01:00:16.817131
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """
    Method verifies if pesel returns 11-digit number
    """
    tmp_provider = PolandSpecProvider()
    result = tmp_provider.pesel()
    assert True if (len(result) == 11) else False

# Generated at 2022-06-12 01:00:21.524933
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test pesel()."""
    pesel = PolandSpecProvider().pesel(gender=Gender.MALE)
    assert len(pesel) == 11
    assert int(pesel[9]) % 2 == 1
    assert PolandSpecProvider.pesel(PolandSpecProvider(seed=42),
                                    gender=Gender.FEMALE) == '93040112556'

# Generated at 2022-06-12 01:00:30.032933
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    list_of_pesels = []
    for i in range(10000):
        pesel = p.pesel()
        weight = [1, 3, 7, 9, 1, 3, 7, 9, 1, 3, 1]
        control = sum([w * int(n) for w, n in zip(weight, pesel)]) % 10
        if control != 0:
            raise AssertionError("Pesel shouldn't be broken")
        for elem in list_of_pesels:
            if elem == pesel:
                raise AssertionError("Pesel shouldn't repeat")
        list_of_pesels.append(pesel)

    list_of_pesels = []
    for i in range(10000):
        pesel = p.pesel(gender = "Female")


# Generated at 2022-06-12 01:00:32.674162
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    gender = Gender.MALE
    assert provider.pesel(gender=gender)
    assert provider.pesel(gender=Gender.FEMALE)
    assert provider.pesel()


# Generated at 2022-06-12 01:00:40.932823
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    import datetime
    myspec = PolandSpecProvider()
    pesel1 = myspec.pesel()
    pesel2 = myspec.pesel(datetime.datetime(1940, 1, 1))
    pesel3 = myspec.pesel(datetime.datetime(1940, 1, 1), Gender.MALE)
    pesel4 = myspec.pesel(datetime.datetime(1940, 1, 1), Gender.FEMALE)
    assert isinstance(pesel1, str)
    assert isinstance(pesel2, str)
    assert isinstance(pesel3, str)
    assert isinstance(pesel4, str)