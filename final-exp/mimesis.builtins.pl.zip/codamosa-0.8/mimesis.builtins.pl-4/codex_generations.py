

# Generated at 2022-06-12 00:58:55.359686
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
   from mimesis.enums import Gender as G
   from mimesis.enums import Locale as L
   from mimesis.providers import PolandSpecProvider as P
   from mimesis.providers.person import Person as P
   from mimesis.locales.pl.person import Person as P
   from mimesis.typing import DateTime as D
   from datetime import datetime as D
   p = P(seed=42)

   assert p.nip() == '1009594444'
   assert p.nip() == '1454697660'
   assert p.nip() == '2089719789'
   assert p.nip() == '2366885070'
   assert p.nip() == '2977036142'

# Generated at 2022-06-12 00:59:06.437083
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test pesel"""
    from datetime import datetime
    from mimesis.enums import Gender
    from mimesis.providers.poland import PolandSpecProvider

    pl = PolandSpecProvider()
    for _ in range(10):
        pesel = pl.pesel(datetime(1993, 7, 20), Gender.FEMALE)
        assert len(pesel) == 11
        assert 930720 in pesel
        assert pesel[-1] in ('2', '4', '6', '8')

        pesel = pl.pesel(datetime(1993, 7, 20), Gender.MALE)
        assert len(pesel) == 11
        assert 930720 in pesel
        assert pesel[-1] in ('1', '3', '5', '7', '9')


# Generated at 2022-06-12 00:59:15.106013
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from datetime import datetime
    from random import seed
    from mimesis.enums import Gender
    from mimesis.providers.poland import PolandSpecProvider

    seed(1000)
    poland_provider = PolandSpecProvider()

    print(poland_provider.pesel(
        birth_date=datetime(year=1970, month=1, day=1)
    ))
    print(poland_provider.pesel(gender=Gender.MALE))
    print(poland_provider.pesel())
    print(poland_provider.pesel())
    print(poland_provider.pesel())
    print(poland_provider.pesel())
    print(poland_provider.pesel())

# Generated at 2022-06-12 00:59:19.731433
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """
    :return:
    """
    import mimesis
    random_object = mimesis.Random()
    random_object.seed(1)
    pesel_result = PolandSpecProvider(seed=random_object).pesel()
    assert pesel_result == "97021900179"

# Generated at 2022-06-12 00:59:25.681929
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    test_PESEL = provider.pesel(birth_date='1985-04-02',gender='male')
    if test_PESEL[2] == '4' and test_PESEL[0] == '8':
        correct = True
    else:
        correct = False
    print(test_PESEL)
    assert correct == True


# Generated at 2022-06-12 00:59:29.709862
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel_generator = PolandSpecProvider()
    pesel = pesel_generator.pesel(datetime(1997, 10, 31))
    assert pesel == '97110311935'


# Generated at 2022-06-12 00:59:34.611843
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    seed = "my seed"
    a = PolandSpecProvider(seed)
    assert a.pesel(birth_date="1988-01-08", gender="MALE") == "88010839804"
    assert a.pesel(birth_date="1988-01-08", gender="FEMALE") == "88010839805"

# Generated at 2022-06-12 00:59:36.463866
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    dt = provider.pesel()
    assert len(dt) == 11



# Generated at 2022-06-12 00:59:47.137645
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    poland_provider = PolandSpecProvider(seed=1234567890)
    assert poland_provider.pesel(birth_date=poland_provider.datetime(1940, 2018), gender='MALE') == '94120821406'
    assert poland_provider.pesel(birth_date=poland_provider.datetime(1940, 2018), gender='FEMALE') == '97120656074'
    assert poland_provider.pesel(birth_date=poland_provider.datetime(1940, 2018)) == '97120656074'


# Generated at 2022-06-12 00:59:49.265666
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    assert len(provider.pesel()) == 11


# Generated at 2022-06-12 01:00:04.708085
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    seed = 42
    pl = PolandSpecProvider(seed = seed)
    date = Datetime(seed = seed).datetime(1940, 2018)
    gender = pl.random.choice([Gender.MALE, Gender.FEMALE])
    print("Gender: " + gender.value)
    print("Date: " + str(date))
    print("PESEL: " + str(pl.pesel(birth_date = date, gender = gender)))


# Generated at 2022-06-12 01:00:05.884249
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland = PolandSpecProvider()
    print(poland.pesel())

# Generated at 2022-06-12 01:00:11.048794
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_provider = PolandSpecProvider(seed=13)

    pesel_output = poland_provider.pesel()
    print(pesel_output)
    assert pesel_output == '64120633456', "Failed: Actual: {} Expected: 64120633456".format(pesel_output)


# Generated at 2022-06-12 01:00:14.536861
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    from mimesis.providers.poland import PolandSpecProvider
    from datetime import datetime
    pesel = PolandSpecProvider().pesel(datetime.now(), Gender.FEMALE)
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-12 01:00:16.487333
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel(birth_date="1995-07-15", gender=Gender.MALE)
    print(pesel)


# Generated at 2022-06-12 01:00:26.098780
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # generate random PESEL
    random_PESEL = PolandSpecProvider().pesel()

    # check if the number of digits equals 11
    assert len(random_PESEL) == 11

    # check if the generated PESEL is valid
    PESEL_weight = [1, 3, 7, 9, 1, 3, 7, 9, 1, 3]
    PESEL_digits = [int(digit) for digit in random_PESEL]
    PESEL_sum = 0
    for i in range(len(PESEL_weight)):
        PESEL_sum += PESEL_weight[i] * PESEL_digits[i]
    PESEL_check_digit = 10 - (PESEL_sum % 10)

    #check if check digit is correct
    assert PESEL_check

# Generated at 2022-06-12 01:00:28.412597
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    from mimesis.builtins import poland_provider
    expected_pesel = "83102900108"
    assert poland_provider.PolandSpecProvider().pesel() == expected_pesel

# Generated at 2022-06-12 01:00:29.699147
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    pesel = p.pesel()
    print(pesel)

# Generated at 2022-06-12 01:00:32.269425
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    a1 = PolandSpecProvider()
    assert a1.pesel()
    assert a1.pesel(gender=Gender.FEMALE)
    assert a1.pesel(gender=Gender.MALE)


# Generated at 2022-06-12 01:00:34.959937
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    result = provider.pesel(gender=Gender.MALE, birth_date=Datetime().datetime(1994, 1, 1))
    assert result == '94101617271'

# Generated at 2022-06-12 01:00:56.453347
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel(gender=Gender.FEMALE)

    def digit_to_int(ds: str) -> int:
        return list(map(int, ds))

    def int_to_digit(ds: int) -> str:
        return list(map(str, ds))

    a = digit_to_int(pesel)
    to_check = a[:10]

    if (
            (to_check[0] == 0) or
            (to_check[0] == 1)):
        month = to_check[2] + to_check[3]

# Generated at 2022-06-12 01:01:00.662621
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    from mimesis.enums import Gender
    from datetime import datetime
    from mimesis.providers import PolandSpecProvider
    from mimesis.providers.person import Person
    person = Person(locale='pl')
    pesel = PolandSpecProvider()
    pesel.pesel(birth_date=datetime(1900, 1, 1), gender=Gender.MALE)
    person.pesel()

# Generated at 2022-06-12 01:01:03.104379
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    from mimesis.enums import Gender
    pol = PolandSpecProvider()
    pesel = pol.pesel(gender=Gender.MALE)
    assert len(pesel) == 11
    assert pesel.isnumeric() == True


# Generated at 2022-06-12 01:01:05.478131
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    result = PolandSpecProvider().pesel()
    assert isinstance(result, str) and len(result) == 11, "The result is incorrect"


# Generated at 2022-06-12 01:01:10.546744
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test for method pesel of class PolandSpecProvider."""
    from mimesis import PolandSpecProvider
    provider = PolandSpecProvider()
    pesel = '74050306402'

    assert provider.pesel(birth_date='1954-05-03', gender=Gender.MALE) == pesel
    assert provider.pesel(birth_date=Datetime().datetime(1954, 5, 3), gender=Gender.MALE) == pesel



# Generated at 2022-06-12 01:01:18.892317
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    pesel = PolandSpecProvider().pesel(gender=Gender.MALE)
    assert (pesel[-1] == "1") or (pesel[-1] == "3") or (pesel[-1] == "5") or (pesel[-1] == "7") or (pesel[-1] == "9")
    pesel = PolandSpecProvider().pesel(gender=Gender.FEMALE)
    assert (pesel[-1] == "0") or (pesel[-1] == "2") or (pesel[-1] == "4") or (pesel[-1] == "6") or (pesel[-1] == "8")



# Generated at 2022-06-12 01:01:21.409435
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel(gender=Gender.MALE)
    assert len(pesel) == 11
    assert isinstance(pesel, str)
    assert pesel[9] in [1, 3, 5, 7, 9]


# Generated at 2022-06-12 01:01:28.027831
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test for method pesel of class PolandSpecProvider."""
    print ("Test for method pesel of class PolandSpecProvider")
    gender = Gender.MALE
    provider = PolandSpecProvider()
    pesel = provider.pesel(gender=gender)
    print ("PESEL: " + pesel)
    if (int(pesel[10]) % 2 == 0 and gender == Gender.MALE) or \
       (int(pesel[10]) % 2 == 1 and gender == Gender.FEMALE):
        print ("PESEL generated correctly.")
    else:
        print ("Error while PESEL generation.")


# Generated at 2022-06-12 01:01:29.902025
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    assert len(provider.pesel()) == 11
    assert provider.pesel(birth_date=1986) == '99910314644'


# Generated at 2022-06-12 01:01:31.991890
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    instance = PolandSpecProvider()
    assert len(instance.pesel())==11

# Generated at 2022-06-12 01:01:45.405545
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider(seed='1234567890')
    assert provider.pesel() == '00072409910'
    assert provider.pesel() == '00072409910'



# Generated at 2022-06-12 01:01:46.584279
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    t = PolandSpecProvider()
    assert t.pesel() != None

# Generated at 2022-06-12 01:01:50.785147
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    gender = Gender.FEMALE
    provider = PolandSpecProvider()
    pesel = provider.pesel(gender=gender)
    assert pesel[9] in [str(i) for i in range(0, 10, 2)]

# Generated at 2022-06-12 01:01:57.961431
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    for i in range (0, 3):
        pesel = p.pesel()
        assert len(pesel) == 11
        assert int(pesel[-1]) == ((9 * int(pesel[0]) + 7 * int(pesel[1]) + 3 * int(pesel[2]) + 1 * int(pesel[3]) + 9 * int(pesel[4]) + 7 * int(pesel[5]) + 3 * int(pesel[6]) + 1 * int(pesel[7]) + 9 * int(pesel[8])) % 10)

# Generated at 2022-06-12 01:02:02.184704
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    date_object = Datetime().datetime(1940, 2018)
    assert provider.pesel(date_object, Gender.MALE) == provider.pesel(date_object)
    assert provider.pesel(date_object, Gender.FEMALE) == provider.pesel(date_object)

# Generated at 2022-06-12 01:02:05.574763
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_provider = PolandSpecProvider()
    birth_date = Datetime().datetime(1940, 2018)
    birth_date_str = birth_date.strftime("%Y-%m-%d %H:%M:%S")
    pesel = poland_provider.pesel(birth_date)
    assert len(birth_date_str) == len(pesel)


# Generated at 2022-06-12 01:02:08.185092
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    assert p.pesel(birth_date=Datetime().datetime(year=1900), gender=Gender.MALE) == "99123157584"
    assert p.pesel(birth_date=Datetime().datetime(year=2001), gender=Gender.FEMALE) == "01212017573"

# Generated at 2022-06-12 01:02:10.141277
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    dt = Datetime()
    pl = PolandSpecProvider()
    pesel = pl.pesel(dt, gender=Gender.MALE)
    pesel_check = pl.pesel(dt, gender=Gender.FEMALE)

    assert(pesel != pesel_check)

# Generated at 2022-06-12 01:02:13.592483
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    results = []
    for _ in range(1000):
        pesel = provider.pesel()
        results.append(pesel)
        assert len(pesel) == 11
    print(results)


# Generated at 2022-06-12 01:02:19.019264
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    p.pesel(birth_date=Datetime().datetime(1900, 2000), gender=Gender.MALE)
    assert len(p.pesel(birth_date=Datetime().datetime(1900, 2000), gender=Gender.MALE)) == 11
    assert isinstance(p.pesel(birth_date=Datetime().datetime(1900, 2000), gender=Gender.MALE), str)


# Generated at 2022-06-12 01:02:47.316479
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test case"""
    polprov = PolandSpecProvider(seed=0)
    print(polprov.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.FEMALE))
    print(polprov.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.MALE))

test_PolandSpecProvider_pesel()

# Generated at 2022-06-12 01:02:50.511978
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    assert len(provider.pesel()) == 11
    assert len(provider.pesel(gender=Gender.MALE)) == 11
    assert len(provider.pesel(gender=Gender.FEMALE)) == 11

# Generated at 2022-06-12 01:02:52.375230
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    assert type(provider.pesel()) == str
    assert len(provider.pesel()) == 11

# Generated at 2022-06-12 01:02:58.336105
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    pnd = PolandSpecProvider(0)
    assert pnd.pesel(birth_date=Datetime().datetime(1985, 1985), gender=Gender.FEMALE) == '85032464081'
    assert pnd.pesel(birth_date=Datetime().datetime(1985, 1985), gender=Gender.MALE) == '85032491045'

# Generated at 2022-06-12 01:03:01.858372
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pl = PolandSpecProvider()
    assert Pesel.validate_pesel(pl.pesel(gender=Gender.MALE))
    assert Pesel.validate_pesel(pl.pesel(gender=Gender.FEMALE))
    assert Pesel.validate_pesel(pl.pesel())

# Generated at 2022-06-12 01:03:08.671081
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    assert isinstance(provider.pesel(), str)
    assert provider.pesel(gender=Gender.MALE)[-1] == '1'
    assert provider.pesel(gender=Gender.FEMALE)[-1] == '2'
    assert provider.pesel() in list(map(provider.pesel, range(100)))
test_PolandSpecProvider_pesel()


# Generated at 2022-06-12 01:03:10.278802
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11


# Generated at 2022-06-12 01:03:14.560323
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    psv = PolandSpecProvider()
    a = psv.pesel(gender=Gender.FEMALE)
    assert len(a) == 11
    assert a[0] == '0' or a[0] == '1' or a[0] == '2' or a[0] == '8' or a[0] == '9'

# Generated at 2022-06-12 01:03:23.501162
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    from mimesis.enums import Gender
    from mimesis.typing import DateTime
    from datetime import date
    pesel = PolandSpecProvider().pesel(birth_date=DateTime().datetime(1970, 1980), gender=Gender.MALE)
    date_pesel = [int(d) for d in pesel[0:2]]
    month = ['01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21', '22', '23', '24']
    if pesel[0] == '9':
        date_pesel[0] = date_pesel[0]+1900

# Generated at 2022-06-12 01:03:29.111728
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    psc = PolandSpecProvider(seed=123)
    print(psc.pesel())
    print(psc.pesel(gender=Gender.FEMALE))
    print(psc.pesel(birth_date=psc.datetime(1940, 2018)))
    print(psc.pesel(birth_date=psc.datetime(1940, 2018), gender=Gender.FEMALE))
