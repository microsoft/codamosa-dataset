

# Generated at 2022-06-12 00:58:56.227769
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test for method pesel of class PolandSpecProvider."""
    poland = PolandSpecProvider()
    pesel = poland.pesel(Datetime().datetime(1990, 1, 1), Gender.MALE)
    assert len(pesel) == 11



# Generated at 2022-06-12 00:58:59.259437
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    try:
        x = PolandSpecProvider().pesel()
        assert len(x) == 11
    except:
        print('Exception in pesel')

# Generated at 2022-06-12 00:59:10.052910
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
  polandSpecProvider = PolandSpecProvider(seed=42)
  # PESEL number examples:
  # 01020801715
  # 48022709635
  # 85120713536
  # 31082316098
  # 79060504484
  # 83051009253
  # 62031809365
  # 93111607424
  # 15082314054
  # 29122506236

# Generated at 2022-06-12 00:59:15.130473
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_provider = PolandSpecProvider()
    pesel_one = poland_provider.pesel()
    pesel_two = poland_provider.pesel(gender=Gender.MALE)
    pesel_three = poland_provider.pesel(gender=Gender.FEMALE)
    print(pesel_one)
    print(pesel_two)
    print(pesel_three)


# Generated at 2022-06-12 00:59:21.817782
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    result = provider.pesel()
    assert len(result) == 11
    assert int(result) % 10 == int(result[-1])
    assert int(result) % 10 == (
            sum(int(result[i]) * int(provider.PESEL_COEFFICIENTS[i])
                for i in range(10)) % 10)


# Generated at 2022-06-12 00:59:26.713182
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    import datetime
    from mimesis.enums import Gender

    pesel_provider = PolandSpecProvider()

    pesel_provider.pesel(birth_date=datetime.datetime(1940, 2018), gender=Gender.MALE)

    # result = pesel_provider.pesel(birth_date=datetime.datetime(1940, 2018), gender=Gender.MALE)
    # print(result)
# end of test

# Generated at 2022-06-12 00:59:29.616447
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    print(poland_spec_provider.pesel())
    return None


# Generated at 2022-06-12 00:59:38.567614
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider(seed=123)

    # test pesel with gender parameter
    pesel_gender_male_1 = provider.pesel(gender=Gender.MALE)
    pesel_gender_male_2 = provider.pesel(gender=Gender.MALE)

    pesel_gender_female_1 = provider.pesel(gender=Gender.FEMALE)
    pesel_gender_female_2 = provider.pesel(gender=Gender.FEMALE)

    assert pesel_gender_male_1 != pesel_gender_male_2
    assert pesel_gender_female_1 != pesel_gender_female_2

    # test pesel with gender parameter && with initial birth date
    initial_date_1 = Datetime().datetime(1940, 2018)
    initial_date_2 = Datetime().dat

# Generated at 2022-06-12 00:59:42.208194
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel_number = PolandSpecProvider().pesel()
    assert len(pesel_number) == 11
    assert all(c in '0123456789' for c in pesel_number)


# Generated at 2022-06-12 00:59:43.350356
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    assert PolandSpecProvider().pesel()

