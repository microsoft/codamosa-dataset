

# Generated at 2022-06-12 00:58:50.012695
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    assert PolandSpecProvider().pesel() == '69040137891'


# Generated at 2022-06-12 00:58:53.175566
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    gender_digit = int(pesel[-1])
    print('PESEL: ' + str(pesel))
    print('Gender: ' + provider.random.choice(gender_digit) )


# Generated at 2022-06-12 00:58:57.283909
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel(gender=Gender.FEMALE)
    index = int(pesel[9])
    assert index % 2 == 0



# Generated at 2022-06-12 00:59:01.724127
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    from mimesis.enums import Gender
    from mimesis.providers.person.pl_PL import PolandSpecProvider
    import datetime
    p = PolandSpecProvider()
    p.pesel(gender=Gender.MALE, birth_date=datetime.datetime(1942, 1, 1))



# Generated at 2022-06-12 00:59:03.771461
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider(seed=12345)
    pesel = provider.pesel()
    assert len(pesel) == 11


# Generated at 2022-06-12 00:59:11.777272
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Generate random 11-digit PESEL."""
    from mimesis import PolandSpecProvider
    pl_provider = PolandSpecProvider()
    print(pl_provider.pesel()) # 94040404040
    print(pl_provider.pesel(gender=Gender.MALE)) # 52060111333
    print(pl_provider.pesel(gender=Gender.FEMALE)) # 98080891502
    print(pl_provider.pesel(birth_date=Datetime().datetime(2018, 2019))) # 18060697961
    

# Generated at 2022-06-12 00:59:16.341244
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
#     n = PolandSpecProvider()
#     for i in range(50):
#         print(n.pesel())

    n = PolandSpecProvider()
    pesels = []
    for i in range(1000):
        pesels.append(n.pesel())
    print(len(set(pesels)))

#     n = PolandSpecProvider()
#     for i in range(50):
#         print(n.nip())

#     n = PolandSpecProvider()
#     for i in range(50):
#         print(n.regon())

# Generated at 2022-06-12 00:59:26.916086
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    assert len(PolandSpecProvider().pesel()) == 11
    assert PolandSpecProvider().pesel(birth_date='2018-11-04', gender=Gender.MALE).startswith('18')
    assert PolandSpecProvider().pesel(birth_date='2018-11-04', gender=Gender.FEMALE).startswith('18')
    assert PolandSpecProvider().pesel(birth_date='2018-11-04', gender=Gender.NOT_SPECIFIED).startswith('18')
    assert PolandSpecProvider().pesel(birth_date='2018-11-04', gender=Gender.MALE).endswith('0')
    assert PolandSpecProvider().pesel(birth_date='2018-11-04', gender=Gender.FEMALE).endswith('9')

# Generated at 2022-06-12 00:59:37.337126
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel."""
    import time
    import copy
    import numpy as np
    import pytest
    from mimesis.enums import Gender
    from mimesis.typing import DateTime
    from datetime import datetime
    from mimesis.providers import PolandSpecProvider

    from utils import unit_test_data_provider, unit_tester_for_providers
    from utils import get_format, get_gender_enum, get_pattern, get_time_zone

    # Create an object of PolandSpecProvider
    poland_spec_provider = PolandSpecProvider()
    # Create a copy of object
    poland_spec_provider_copy = copy.deepcopy(poland_spec_provider)
    # Create a timestamp
    timestamp = time.time()

    # Store the

# Generated at 2022-06-12 00:59:41.356899
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()
    assert (len(str(pesel)) == 11) and (type(pesel) == str)


# Generated at 2022-06-12 00:59:52.465413
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Checking method pesel of class PolandSpecProvider."""
    assert re.match('^\d{11}$', PolandSpecProvider().pesel()) is not None


# Generated at 2022-06-12 01:00:01.248302
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()

    pesel_1 = provider.pesel()
    pesel_1_data = provider.pesel_info(pesel_1)

    assert (pesel_1_data != None)
    assert (pesel_1_data.get('pesel') == pesel_1)

    pesel_2 = provider.pesel(DateTime().datetime(1960, 1970), Gender.MALE)
    pesel_2_data = provider.pesel_info(pesel_2)

    assert (pesel_2_data != None)
    assert (pesel_2_data.get('pesel') == pesel_2)


# Generated at 2022-06-12 01:00:02.701056
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    assert len(p.pesel()) == 11


# Generated at 2022-06-12 01:00:04.586074
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    print("pesel: ", p.pesel())

# Generated at 2022-06-12 01:00:14.360644
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    province_number = ['02', '04', '06', '08', '10', '12', '14', '16', '18',
                       '20', '22', '24', '26', '28', '30', '32', '34', '36',
                       '38', '40', '42', '44', '46', '48', '50', '52', '54',
                       '56', '58', '60', '62', '64', '66', '68', '70', '72',
                       '74', '76', '78', '80', '82', '84', '86', '88', '90',
                       '92', '94', '96']
    provider = PolandSpecProvider()
    assert len(provider.pesel()) == 11
    assert provider.pesel()[:2] in province_number

# Generated at 2022-06-12 01:00:19.991297
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel(gender='male')
    assert len(pesel) == 11
    assert pesel[9] in ['1', '3', '5', '7', '9']

    pesel = provider.pesel(gender='female')
    assert len(pesel) == 11
    assert pesel[9] in ['0', '2', '4', '6', '8']

    pesel = provider.pesel(gender=Gender.FEMALE)
    assert len(pesel) == 11
    assert pesel[9] in ['0', '2', '4', '6', '8']

    pesel = provider.pesel()
    assert len(pesel) == 11


# Generated at 2022-06-12 01:00:24.827842
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # 1.Setup
    # 2.Execution
    result = PolandSpecProvider().pesel(birth_date=Datetime().datetime(2000, 1, 2), gender=Gender.FEMALE)
    # 3.Verification
    print(result)
    assert result == "00020119813"
    assert len(result) == 11

# Generated at 2022-06-12 01:00:26.391692
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    from mimesis import PolandSpecProvider
    provider = PolandSpecProvider()

    assert len(provider.pesel()) == 11

# Generated at 2022-06-12 01:00:32.692273
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # Checking the output is correct
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11, "Wrong pesel length"
    pesel = provider.pesel(Datetime().datetime(year=1995, month=6, day=15))
    assert len(pesel) == 11, "Wrong pesel length"
    pesel = provider.pesel(Datetime().datetime(year=1995, month=6, day=15), Gender.MALE)
    assert len(pesel) == 11, "Wrong pesel length"
    pesel = provider.pesel(Datetime().datetime(year=1995, month=6, day=15), Gender.FEMALE)
    assert len(pesel) == 11, "Wrong pesel length"


# Generated at 2022-06-12 01:00:35.539317
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    obj = PolandSpecProvider()
    result = obj.pesel(birth_date=obj.datetime(), gender=obj.gender())
    assert len(str(result)) == 11


# Generated at 2022-06-12 01:00:48.165634
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    assert len(p.pesel()) == 11

# Generated at 2022-06-12 01:00:51.906972
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    birth_date = Datetime(seed=4).datetime(1940, 2018)
    gender = None
    out = provider.pesel(birth_date, gender)
    assert out == '82060798351'


# Generated at 2022-06-12 01:00:54.218506
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    PolishPesel = PolandSpecProvider()
    pesel = PolishPesel.pesel()
    assert int(pesel[-2]) % 2 == 0


# Generated at 2022-06-12 01:00:56.380938
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel(birth_date="1944-06-22")
    assert pesel == "44062245267"

# Generated at 2022-06-12 01:00:58.011838
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    x = PolandSpecProvider().pesel()
    #print(x)
    assert x is not None


# Generated at 2022-06-12 01:00:59.844580
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland = PolandSpecProvider()
    pesel = poland.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-12 01:01:01.654575
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    pesel = PolandSpecProvider.pesel(p,None,None)

    assert (pesel != None)

# Generated at 2022-06-12 01:01:06.077780
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    seed_numbers = [2, 3, 4, 5, 6, 7, 8, 9]
    class_ = PolandSpecProvider(seed=seed_numbers)
    birth_date = Datetime().datetime(1940, 2018)
    gender = Gender.MALE
    result = class_.pesel(birth_date, gender)
    expect = '60040403071'
    assert result == expect



# Generated at 2022-06-12 01:01:10.877950
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pass
#     my_provider = PolandSpecProvider()
#     male_pesel = my_provider.pesel(gender=Gender.MALE)
#     female_pesel = my_provider.pesel(gender=Gender.FEMALE)
#     print("PESEL number for male person: {}".format(male_pesel))
#     print("PESEL number for female person: {}".format(female_pesel))

# Generated at 2022-06-12 01:01:13.516499
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pl_provider = PolandSpecProvider()
    pesel = pl_provider.pesel()
    assert len(pesel) == 11


# Generated at 2022-06-12 01:01:21.044077
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    string = provider.pesel()
    assert len(string) == 11


# Generated at 2022-06-12 01:01:27.017806
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    assert PolandSpecProvider().pesel(birth_date = Datetime().datetime(1960, 1, 1), gender = Gender.MALE) == '60010118019'
    assert PolandSpecProvider().pesel(birth_date = Datetime().datetime(1960, 1, 1), gender = Gender.FEMALE) == '60010118036'
    assert PolandSpecProvider().pesel() != PolandSpecProvider().pesel()


# Generated at 2022-06-12 01:01:29.330285
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider(seed=1000011)
    pesel = p.pesel(birth_date="3.3.1994", gender=Gender.FEMALE)
    assert pesel == "94033032214"

# Generated at 2022-06-12 01:01:34.238711
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # Test with/without gender
    p1 = PolandSpecProvider()
    p1.pesel()
    p1.pesel(gender=p1.gender())
    # Test with/without birth date
    p2 = PolandSpecProvider()
    p2.pesel()
    p2.pesel(birth_date=p2.datetime())

# Generated at 2022-06-12 01:01:42.605148
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # Input
    gender = Gender.MALE
    birth_date = Datetime().datetime(1980, 1990)
    # Output
    output = PolandSpecProvider().pesel(birth_date, gender)
    # Expected result
    expected_result_1 = '8'
    expected_result_2 = str(birth_date.date().month + 20)
    expected_result_4 = str(birth_date.date().year)[2:]
    expected_result = expected_result_1 + expected_result_2 + expected_result_4 + 'X'
    # Check
    assert len(output) == 11
    assert output[0:5] == expected_result
    assert int(output[9]) % 2 == 0 # Even parity

# Generated at 2022-06-12 01:01:45.235497
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    spec = PolandSpecProvider()
    pesel = spec.pesel(birth_date='1970-01-01', gender=Gender.FEMALE)
    assert len(pesel) == 11, 'pesel has incorrect length'



# Generated at 2022-06-12 01:01:48.382944
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pid = PolandSpecProvider()
    pid.pesel(gender=Gender.FEMALE) # Check with given gender
    pid.pesel() # Check without given gender

# Generated at 2022-06-12 01:01:57.116976
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test pesel()."""
    # Initialize seed with fixed seed
    prov = PolandSpecProvider(seed=123)
    
    # Test for different genders
    for gender in Gender:
        # Test for 10 different dates
        for i in range(1, 11):
            data=prov.pesel(gender=gender)
            assert len(data)==11
            assert data[9]==str(gender.value)[0]
    
            # Test for the same date multiple times and check if the result changes 
            for j in range (1, 5):
                data=prov.pesel(gender=gender)
                assert data[9]==str(gender.value)[0]
    return "test_PolandSpecProvider_pesel passed successfully"


# Generated at 2022-06-12 01:02:00.157152
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    obj = PolandSpecProvider()
    n = set()
    for _ in range(1000):
        n.add(obj.pesel())
    assert len(n) == 1000

# Generated at 2022-06-12 01:02:02.907413
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    dt = Datetime().datetime(1899, 2100)
    pesel = PolandSpecProvider().pesel(dt)
    print(dt.strftime('%Y-%m-%d %H-%M-%S'))
    print(pesel)


# Generated at 2022-06-12 01:02:12.959473
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_provider = PolandSpecProvider()
    test_pesel = poland_provider.pesel()
    assert len(test_pesel) == 11


# Generated at 2022-06-12 01:02:20.508702
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    import datetime
    dt = datetime.datetime(2019, 1, 1, 15, 30, 10)
    pesel = PolandSpecProvider().pesel(dt)
    assert (datetime.datetime(int(pesel[0:2]) + 1900, int(pesel[2:4]), int(pesel[4:6])) == dt)
    pesel = PolandSpecProvider().pesel(dt, Gender.FEMALE)
    assert (datetime.datetime(int(pesel[0:2]) + 1900, int(pesel[2:4]), int(pesel[4:6])) == dt)
    pesel = PolandSpecProvider().pesel(dt, Gender.MALE)

# Generated at 2022-06-12 01:02:21.999099
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_provider = PolandSpecProvider()
    assert poland_provider.pesel()


# Generated at 2022-06-12 01:02:23.944770
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    x = PolandSpecProvider()
    res = x.pesel()
    assert len(res) == 11
    assert ''.join(str(d) for d in res if res.isdigit()) == res


# Generated at 2022-06-12 01:02:25.135266
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    date_object = '01.04.2017'
    gender = Gender.MALE


# Generated at 2022-06-12 01:02:27.534859
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pl_provider = PolandSpecProvider(seed=7)
    assert pl_provider.pesel() == '33112603982'
    assert pl_provider.pesel(DateTime().datetime(1950, 1990),
                             Gender.MALE) == '51101504786'

# Generated at 2022-06-12 01:02:30.013169
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    seed = "Mimesis"
    pesel = PolandSpecProvider(seed).pesel()
    assert pesel == "92409196331"


# Generated at 2022-06-12 01:02:35.528573
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    assert len(provider.pesel()) == 11
    date_object = Datetime().datetime(1940, 2018)
    assert len(provider.pesel(date_object)) == 11
    assert len(provider.pesel(DateTime().datetime(1940, 2018))) == 11
    assert len(provider.pesel(date_object, Gender.MALE)) == 11
    assert provider.pesel(date_object, Gender.MALE) != provider.pesel(date_object, Gender.FEMALE)

# Generated at 2022-06-12 01:02:41.095026
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    from mimesis.providers.poland import PolandSpecProvider
    p = PolandSpecProvider()
    print(p.pesel())
    assert isinstance(p.pesel(), str)
    assert len(p.pesel()) == 11
    assert isinstance(p.pesel(birth_date='01.01.2000'), str)
    assert isinstance(p.pesel(birth_date='01.01.2000', gender=Gender.MALE),
        str)
    p.gen_pesel_digit = lambda: 'a'
    assert p.pesel() == ''


# Generated at 2022-06-12 01:02:45.762685
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():

    provider = PolandSpecProvider()
    pesel = provider.pesel()
    print("peseł: " + pesel)
    if "-" in pesel:
        print("Pesel has '-'")
    elif len(pesel) != 11:
        print("Pesel has more than 11 digits")
