

# Generated at 2022-06-25 19:55:11.355318
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert re.match('[0-9]{11}', poland_spec_provider_0.pesel())
    assert re.match('[0-9]{11}', poland_spec_provider_0.pesel(datetime.datetime(2017, 12, 12, 21, 7, 45), Gender.FEMALE))
    assert re.match('[0-9]{11}', poland_spec_provider_0.pesel(datetime.datetime(2017, 12, 12, 21, 7, 45), Gender.MALE))
    assert re.match('[0-9]{11}', poland_spec_provider_0.pesel(None, None))


# Generated at 2022-06-25 19:55:14.661258
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    gender_1 = poland_spec_provider_0.gender()
    assert len(poland_spec_provider_0.pesel(
        gender=gender_1)) == 11

# Generated at 2022-06-25 19:55:17.389338
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_1 = PolandSpecProvider()
    assert len(poland_spec_provider_1.pesel()) == 11


# Generated at 2022-06-25 19:55:20.206975
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert poland_spec_provider_0.pesel() == '03011000077' 


# Generated at 2022-06-25 19:55:24.938312
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel_1 = poland_spec_provider_0.pesel(gender=Gender.MALE)
    pesel_2 = poland_spec_provider_0.pesel(gender=Gender.FEMALE)
    pesel_3 = poland_spec_provider_0.pesel(gender=None)


# Generated at 2022-06-25 19:55:32.553639
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()

# Generated at 2022-06-25 19:55:33.825437
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    assert len(PolandSpecProvider().pesel()) == 11


# Generated at 2022-06-25 19:55:35.879837
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert len(poland_spec_provider_0.pesel()) == 11

# Generated at 2022-06-25 19:55:37.715019
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    poland_spec_provider.pesel()


# Generated at 2022-06-25 19:55:39.423823
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    pesel = poland_spec_provider_0.pesel()


# Generated at 2022-06-25 19:55:47.731974
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()

    pesel = p.pesel(birth_date=None, gender=None)
    assert len(pesel) == 11
    assert pesel.isdigit()



# Generated at 2022-06-25 19:55:49.960935
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert poland_spec_provider_0.pesel() == '84940303942'

# Generated at 2022-06-25 19:55:52.194834
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
  poland_spec_provider_0 = PolandSpecProvider()
  birth_date = poland_spec_provider_0.date(start=1940, end=2018)
  gender = poland_spec_provider_0.gender()
  # Call method
  pesel = PolandSpecProvider.pesel(poland_spec_provider_0, birth_date=birth_date, gender=gender)
  print(pesel)



# Generated at 2022-06-25 19:55:57.963524
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    str_0 = poland_spec_provider_0.pesel(gender='MALE')
    str_1 = poland_spec_provider_0.pesel(gender='FEMALE')
    str_2 = poland_spec_provider_0.pesel()
    str_3 = poland_spec_provider_0.pesel()
    str_4 = poland_spec_provider_0.pesel(gender='FEMALE')

if __name__ == '__main__':
    test_PolandSpecProvider_pesel()

# Generated at 2022-06-25 19:56:01.083535
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    result_0 = poland_spec_provider_0.pesel()
    assert 11 == len(result_0)


# Generated at 2022-06-25 19:56:05.442939
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    gender = Gender.MALE
    assert (len(poland_spec_provider_0.pesel(gender)) == 11)



# Generated at 2022-06-25 19:56:10.810385
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_1 = PolandSpecProvider()
    data_1 = poland_spec_provider_1.pesel()
    assert (type(data_1) == str)
    assert (len(data_1) == 11)
    assert (type(data_1) == str)
    assert (len(data_1) == 11)


# Generated at 2022-06-25 19:56:13.717251
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert poland_spec_provider_0.pesel() == '03081476266'


# Generated at 2022-06-25 19:56:19.475101
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    pesel = poland_spec_provider.pesel(birth_date=poland_spec_provider._datetime.datetime(1940, 2018))
    assert isinstance(pesel, str)
    assert len(pesel) == 11


# Generated at 2022-06-25 19:56:22.152608
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_provider_0 = PolandSpecProvider()
    assert poland_provider_0.pesel() == '06070605826'


# Generated at 2022-06-25 19:56:37.389362
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel_1 = provider.pesel(provider.datetime(1900, 1999))
    assert len(pesel_1) == 11
    assert pesel_1[2:4] in ('80', '81', '82', '83', '84', '85', '86', '87',
                            '88', '89')

    pesel_2 = provider.pesel(provider.datetime(2000, 2099))
    assert len(pesel_2) == 11
    assert pesel_2[2:4] in ('20', '21', '22', '23', '24', '25', '26', '27',
                            '28', '29')

    pesel_3 = provider.pesel(provider.datetime(2100, 2199))

# Generated at 2022-06-25 19:56:42.072399
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider_0 = PolandSpecProvider()
    assert provider_0.pesel()[0] == '8'
    assert provider_0.pesel()[1] == '8'
    assert provider_0.pesel()[2] == '1'

# Generated at 2022-06-25 19:56:48.982697
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    datetime_0 = Datetime().datetime(1940, 2018)
    poland_spec_provider_0.pesel(birth_date=datetime_0, gender=Gender.MALE)
    poland_spec_provider_0.pesel()
    poland_spec_provider_0.pesel(birth_date=datetime_0, gender=Gender.MALE)
    poland_spec_provider_0.pesel(gender=Gender.MALE)
    poland_spec_provider_0 = PolandSpecProvider()
    poland_spec_provider_0.pesel()
    poland_spec_provider_0.pesel(gender=Gender.FEMALE)
    poland_spec_provider_0.pes

# Generated at 2022-06-25 19:56:52.168041
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    print("Testing pesel of PolandSpecProvider")
    poland_spec_provider = PolandSpecProvider()
    pesel = poland_spec_provider.pesel()
    assert len(pesel) == 11
    assert isinstance(pesel, str)
    print("PASSED")

# Generated at 2022-06-25 19:56:55.640711
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    a = poland_spec_provider.pesel(birth_date=None, gender=Gender.MALE)
    print(a)
    assert type(a) is str
    assert len(a)==11


# Generated at 2022-06-25 19:56:57.641643
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert len(poland_spec_provider_0.pesel()) == 11


# Generated at 2022-06-25 19:57:00.780785
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    birthdate = poland_spec_provider_0.datetime(1940, 2018)
    assert len(poland_spec_provider_0.pesel(birthdate, Gender.MALE)) == 11


# Generated at 2022-06-25 19:57:02.325135
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_1 = PolandSpecProvider()
    poland_spec_provider_1.pesel()


# Generated at 2022-06-25 19:57:04.358690
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    assert len(PolandSpecProvider().pesel()) == 11


# Generated at 2022-06-25 19:57:08.485827
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_1 = PolandSpecProvider()
    poland_spec_provider_1.pesel()
    res = poland_spec_provider_1.pesel('2014-08-02', 'F')
    assert res == '14088271100'


# Generated at 2022-06-25 19:57:24.882980
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    pesel_0 = poland_spec_provider.pesel()
    print("pesel(0)=", pesel_0)
    assert len(pesel_0) == 11
    assert pesel_0.isdigit()


# Generated at 2022-06-25 19:57:33.573912
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    from mimesis.typing import DateTime
    from dateutil.parser import parse
    from dateutil.tz import tzutc
    from datetime import datetime
    # Create PolandSpecProvider instance
    _p_s_p = PolandSpecProvider()
    assert _p_s_p.pesel(birth_date=parse("2018-12-15 12:11:08.176943+00:00", tzinfos=tzutc)) == '18121547900'
    assert _p_s_p.pesel(birth_date=parse("2013-10-19 01:36:42.290585+00:00", tzinfos=tzutc)) == '1310193666'

# Generated at 2022-06-25 19:57:36.148946
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    
    poland_spec_provider_0 = PolandSpecProvider()
    pesel = poland_spec_provider_0.pesel()
    assert type(pesel) == str
    assert len(pesel) == 11


# Generated at 2022-06-25 19:57:38.681696
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    try:
        poland_spec_provider_0 = PolandSpecProvider()
        assert len(poland_spec_provider_0.pesel()) == 11
    except:
        assert False, "PESEL should be 11 digits long"


# Generated at 2022-06-25 19:57:40.303829
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    assert PolandSpecProvider().pesel(birth_date=DateTime().datetime(1940, 2018), gender=Gender.MALE) == '83071103814'


# Generated at 2022-06-25 19:57:51.246610
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert poland_spec_provider_0.pesel(None, None) == '94112203023'
    assert poland_spec_provider_0.pesel(None, None) == '94112203023'
    assert poland_spec_provider_0.pesel(None, None) == '94112203023'
    assert poland_spec_provider_0.pesel(None, None) == '94112203023'
    assert poland_spec_provider_0.pesel(None, None) == '94112203023'
    assert poland_spec_provider_0.pesel(None, None) == '94112203023'
    assert poland_spec_provider

# Generated at 2022-06-25 19:57:53.817746
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert len(poland_spec_provider_0.pesel()) == 11


# Generated at 2022-06-25 19:57:57.102868
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    from random import randrange
    poland_spec_provider_0 = PolandSpecProvider()
    gender = Gender.get_random(randrange(0, 2, 1))
    assert len(poland_spec_provider_0.pesel(gender)) == 11


# Generated at 2022-06-25 19:57:59.939507
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert len(poland_spec_provider_0.pesel()) == 11


# Generated at 2022-06-25 19:58:05.584739
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()

    pesel = poland_spec_provider.pesel()
    assert isinstance(pesel, str)
    assert len(pesel) == 11
    assert pesel[-1] == str(sum([(9 - i) * int(d) for i, d in enumerate(pesel[:-1])]) % 10)
