

# Generated at 2022-06-25 19:55:02.797926
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    assert len(poland_spec_provider.pesel()) == 11


# Generated at 2022-06-25 19:55:05.780192
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test for method pesel of class PolandSpecProvider"""
    poland_spec_provider = PolandSpecProvider()
    assert poland_spec_provider.pesel(gender='M') == '80011774445'


# Generated at 2022-06-25 19:55:07.848248
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()

    assert len(poland_spec_provider.pesel(Gender.MALE)) == 11



# Generated at 2022-06-25 19:55:08.778319
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    poland_spec_provider_0.pesel()


# Generated at 2022-06-25 19:55:14.663638
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    assert len(poland_spec_provider.pesel()) == 11
    assert poland_spec_provider.pesel(gender=Gender.MALE).endswith(('1', '3', '5', '7', '9'))
    assert poland_spec_provider.pesel(gender=Gender.FEMALE).endswith(('0', '2', '4', '6', '8'))


# Generated at 2022-06-25 19:55:17.789412
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    assert PolandSpecProvider().pesel(gender=Gender.MALE) == '91081701227'
    assert PolandSpecProvider().pesel(gender=Gender.FEMALE) == '71090701982'

# Generated at 2022-06-25 19:55:21.098635
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()
    assert isinstance(pesel, str)
    assert len(pesel) == 11
    assert pesel[-2].isdigit()


# Generated at 2022-06-25 19:55:22.566848
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    result = poland_spec_provider.pesel()
    assert len(result) == 11


# Generated at 2022-06-25 19:55:23.725761
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_1 = PolandSpecProvider()
    assert len(poland_spec_provider_1.pesel()) == 11


# Generated at 2022-06-25 19:55:26.271481
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert isinstance(poland_spec_provider_0.pesel(), str)


# Generated at 2022-06-25 19:55:36.239909
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    for _ in range(10):
        assert re.findall('[0-9]{11}', PolandSpecProvider().pesel(
            birth_date=datetime.datetime(year=2018, month=12, day=12),
            gender=Gender.MALE))
        


# Generated at 2022-06-25 19:55:38.665582
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel_0 = PolandSpecProvider().pesel()
    assert any([c.isalnum() for c in pesel_0]) == True
    assert len(pesel_0) == 11


# Generated at 2022-06-25 19:55:44.442861
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    result = poland_spec_provider.pesel()
    assert len(result) == 11 and result[:2] in ['40','41','42','43','44','45','46','47','48','49','50','51','52','53','54','55','56','57','58','59','60','61','62','63','64','65','66','67','68','69','70','71','72','73','74','75','76','77','78','79']


# Generated at 2022-06-25 19:55:48.141515
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # Set up random state
    poland_spec_provider_1 = PolandSpecProvider(seed=0.36459)
    poland_spec_provider_1.seed = 0.36459

    assert poland_spec_provider_1.pesel() == '64040512137'


# Generated at 2022-06-25 19:55:50.351251
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert len(poland_spec_provider_0.pesel()) == 11


# Generated at 2022-06-25 19:55:57.757049
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    pesel_1 = poland_spec_provider_0.pesel()
    print(pesel_1)
    assert len(pesel_1) == 11
    pesel_2 = poland_spec_provider_0.pesel(datetime.datetime(1992, 1, 1), Gender.MALE)
    print(pesel_2)
    assert len(pesel_2) == 11
    pesel_3 = poland_spec_provider_0.pesel(datetime.datetime(1992, 1, 1))
    print(pesel_3)
    assert len(pesel_3) == 11

# Generated at 2022-06-25 19:56:10.097619
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():

    # Initialization of variables
    poland_spec_provider_0 = PolandSpecProvider()

    # Method call
    # Test from check-manual.sh on 10-02-2020
    assert poland_spec_provider_0.pesel(birth_date=poland_spec_provider_0.datetime(1980, 1990), gender=Gender.MALE) == '83129693101'
    # Test from check-manual.sh on 10-02-2020
    assert poland_spec_provider_0.pesel(birth_date=poland_spec_provider_0.datetime(1900, 1910), gender=Gender.FEMALE) == '83021511801'
    # Test from check-manual.sh on 10-02-2020

# Generated at 2022-06-25 19:56:13.342659
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    pesel_0 = poland_spec_provider_0.pesel()
    assert len(pesel_0) == 11


# Generated at 2022-06-25 19:56:15.831237
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert poland_spec_provider_0.pesel(birth_date=None, gender=None) in '0123456789'


# Generated at 2022-06-25 19:56:23.036587
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider(seed=1234)
    if poland_spec_provider_0.pesel(gender=None) != '76110420572':
        raise AssertionError('"76110420572" expected')
    if poland_spec_provider_0.pesel(gender=Gender.FEMALE) != '15120720702':
        raise AssertionError('"15120720702" expected')


# Generated at 2022-06-25 19:56:39.695590
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    str_arg_0 = poland_spec_provider_0.pesel()
    assert len(str_arg_0) == 11, '"pesel()" returned "{}"'.format(str_arg_0)

test_PolandSpecProvider_pesel()

# Generated at 2022-06-25 19:56:42.256205
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    assert len(poland_spec_provider.pesel()) == 11


# Generated at 2022-06-25 19:56:46.851781
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_1 = PolandSpecProvider()
    birthday_0 = poland_spec_provider_1.datetime(start=1940, end=2018)
    gender_0 = None
    result_0 =  poland_spec_provider_1.pesel(birthday_0,gender_0)
    assert  poland_spec_provider_1.validate_pesel(result_0) == True


# Generated at 2022-06-25 19:56:55.603417
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_provider = PolandSpecProvider()
    assert poland_provider.pesel(1960, 7, 1, 'M') == '60070199641'
    assert poland_provider.pesel(1920, 4, 30, 'F') == '80703040914'
    assert poland_provider.pesel(2017, 8, 2, 'F') == '73172101194'
    assert poland_provider.pesel(2014, 1, 9, 'M') == '26090612073'

# Generated at 2022-06-25 19:56:56.378257
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    obj = PolandSpecProvider()
    assert obj.pesel()



# Generated at 2022-06-25 19:56:57.528336
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    assert 11 == len(poland_spec_provider.pesel())


# Generated at 2022-06-25 19:57:01.236155
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    birth_date = None
    gender = None
    poland_spec_provider_0_pesel_result = poland_spec_provider_0.pesel(birth_date, gender)
    print(poland_spec_provider_0_pesel_result)


# Generated at 2022-06-25 19:57:04.360284
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # Create an object of class PolandSpecProvider
    poland_spec_provider = PolandSpecProvider()

    # Call method pesel of class PolandSpecProvider
    poland_spec_provider.pesel()


# Generated at 2022-06-25 19:57:14.333007
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    # Instantiate a PolandSpecProvider object.
    poland_spec_provider = PolandSpecProvider()

    # Generate random valid PESEL.
    pesel = poland_spec_provider.pesel()

    assert isinstance(pesel, str)
    assert len(pesel) == 11

    # Generate random valid PESEL using a custom gender.
    pesel = poland_spec_provider.pesel(gender=Gender.MALE)

    assert isinstance(pesel, str)
    assert len(pesel) == 11
    assert int(pesel[9]) % 2 != 0

    # Generate random valid PESEL using a custom birth_date.
    birth_date = poland_spec_provider.datetime(year=1900)
   

# Generated at 2022-06-25 19:57:20.214916
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    gender_0 = poland_spec_provider_0.pesel(gender=Gender.MALE)
    gender_1 = poland_spec_provider_0.pesel(gender=Gender.FEMALE)
    assert len(gender_0) == 11
    assert len(gender_1) == 11
    assert gender_0[9] in ('1', '3', '5', '7', '9')
    assert gender_1[9] in ('0', '2', '4', '6', '8')

test_case_0()
test_PolandSpecProvider_pesel()

# Generated at 2022-06-25 19:57:34.556485
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    print("Testing method pesel of class PolandSpecProvider")
    spec_provider = PolandSpecProvider()
    pesel = spec_provider.pesel(gender=Gender.MALE)
    assert len(pesel) == 11


# Generated at 2022-06-25 19:57:35.687602
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel_0 = PolandSpecProvider.pesel()


# Generated at 2022-06-25 19:57:47.207780
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_1 = PolandSpecProvider(seed=0)
    assert poland_spec_provider_1.pesel() == '96120105266'
    assert poland_spec_provider_1.pesel(birth_date='2003-06-01') == '03063126557'
    assert poland_spec_provider_1.pesel(birth_date='2003-12-31') == '03124034444'
    assert poland_spec_provider_1.pesel(birth_date='2003-02-28') == '03021621650'
    assert poland_spec_provider_1.pesel(birth_date='2011-02-28') == '11025204311'

# Generated at 2022-06-25 19:57:56.294064
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test if method pesel of class PolandSpecProvider returns valid
    PESEL number."""

    poland_spec_provider_0 = PolandSpecProvider()
    pesel = poland_spec_provider_0.pesel(Datetime().datetime(), Gender.MALE)
    assert len(pesel) == 11
    assert int(pesel[0:2]) <= 38
    assert int(pesel[2:4]) <= 12 and int(pesel[2:4]) > 0
    assert int(pesel[4:6]) <= 31 and int(pesel[4:6]) > 0
    assert int(pesel[6:9]) <= 999 and int(pesel[6:9]) >= 0
    assert int(pesel[9]) % 2 == 1

    pesel = poland_spec_provider_0.pes

# Generated at 2022-06-25 19:58:06.673646
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():

    # Parameterized test with specified seeds
    seed_arg_values = [0, 1, 2, 3]
    @given(seed=seed_arg_values)
    def test_PolandSpecProvider_pesel_seed(seed):
        poland_spec_provider_0 = PolandSpecProvider(seed=seed)
        assert type(poland_spec_provider_0.pesel()) is str
        assert len(poland_spec_provider_0.pesel()) == 11
        assert poland_spec_provider_0.pesel().isdigit() is True

# Generated at 2022-06-25 19:58:08.675323
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    pesel = poland_spec_provider_0.pesel()
    assert len(pesel) == 11
    

# Generated at 2022-06-25 19:58:09.654805
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()


# Generated at 2022-06-25 19:58:11.336220
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert len(poland_spec_provider_0.pesel()) == 11


# Generated at 2022-06-25 19:58:13.855395
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert isinstance(pesel, str)



# Generated at 2022-06-25 19:58:16.019906
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_1 = PolandSpecProvider()
    poland_spec_provider_1.pesel()
