

# Generated at 2022-06-25 19:55:04.761064
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # Test case for method pesel of class PolandSpecProvider
    poland_spec_provider_0 = PolandSpecProvider()
    assert(len(poland_spec_provider_0.pesel(birth_date = None, gender = Gender.FEMALE)) == 11)


# Generated at 2022-06-25 19:55:06.889253
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert poland_spec_provider_0.pesel() == '08122900392'


# Generated at 2022-06-25 19:55:08.910807
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    poland_spec_provider_0.pesel()


# Generated at 2022-06-25 19:55:11.688774
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    pesel = poland_spec_provider.pesel()
    assert len(pesel) == 11

# Generated at 2022-06-25 19:55:18.022603
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider(seed=481003)

    assert len(poland_spec_provider.pesel()) == 11, \
        "Length of pesel() should be 11."

    assert poland_spec_provider.pesel(datetime.datetime(1941, 1, 25)) == \
           "41252364665", \
        "pesel(datetime.datetime(1941, 1, 25)) returned wrong data."
    result_gender = poland_spec_provider.pesel(
        datetime.datetime(1986, 3, 31), Gender.MALE)[9]

# Generated at 2022-06-25 19:55:20.809954
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()


# Generated at 2022-06-25 19:55:22.454071
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    import pytest
    pesel = PolandSpecProvider().pesel(birth_date=DateTime().datetime(2000, 2000), gender=Gender.MALE)
    assert len(str(pesel)) == 11

# Generated at 2022-06-25 19:55:25.035549
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    pesel = poland_spec_provider.pesel()
    assert len(pesel) == 11


# Generated at 2022-06-25 19:55:27.471110
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    assert len(poland_spec_provider.pesel()) == 11, "Length of pesel must be 11"


# Generated at 2022-06-25 19:55:29.576498
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_1 = PolandSpecProvider()
    assert isinstance(poland_spec_provider_1.pesel(), str)


# Generated at 2022-06-25 19:55:40.074836
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # This test verifies that the pesel method returns a PESEL of the
    # appropriate length for the locale.
    poland_spec_provider_1 = PolandSpecProvider()
    assert type(poland_spec_provider_1.pesel()) == str and len(poland_spec_provider_1.pesel()) == 11


# Generated at 2022-06-25 19:55:45.563745
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_1 = PolandSpecProvider()
    assert len(poland_spec_provider_1.pesel()) == 11
    assert len(poland_spec_provider_1.pesel(gender=Gender.MALE)) == 11
    assert len(poland_spec_provider_1.pesel(gender=Gender.FEMALE)) == 11
    assert len(poland_spec_provider_1.pesel(datetime(1986, 11, 7))) == 11


# Generated at 2022-06-25 19:55:54.038366
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    import random
    import string
    random.seed(0)
    s = string.printable

# Generated at 2022-06-25 19:55:55.876347
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert len(poland_spec_provider_0.pesel()) == 11 


# Generated at 2022-06-25 19:55:57.568865
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel_0 = PolandSpecProvider().pesel()
    assert len(pesel_0) == 11


# Generated at 2022-06-25 19:56:05.405317
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()

    with pytest.raises(TypeError):
        poland_spec_provider_0.pesel(birth_date=0, gender=0)

    with pytest.raises(TypeError):
        poland_spec_provider_0.pesel(birth_date=0)

    assert len(poland_spec_provider_0.pesel(gender=0)) == 11



# Generated at 2022-06-25 19:56:09.189821
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    string_0 = poland_spec_provider_0.pesel()
    return (string_0, string_0 == '71163011558')



# Generated at 2022-06-25 19:56:13.384307
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test of method pesel of class PolandSpecProvider."""
    poland_spec_provider_0 = PolandSpecProvider()
    assert len(poland_spec_provider_0.pesel()) == 11
"""Test of method nip of class PolandSpecProvider."""

# Generated at 2022-06-25 19:56:17.402790
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_1 = PolandSpecProvider()
    # Random sample of a valid PESEL
    assert len(poland_spec_provider_1.pesel(Gender.MALE)) == 11


# Generated at 2022-06-25 19:56:24.159125
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # 1. Arrange
    poland_spec_provider = PolandSpecProvider()
    # 2. Act
    result0 = poland_spec_provider.pesel()
    # 3. Assert
    # Note:
    # 1. The result of method pesel is a string.
    # 2. The length of the string is 11.
    assert isinstance(result0, str)
    assert len(result0) == 11
    print(result0)




# Generated at 2022-06-25 19:56:39.791970
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider(seed=0)
    assert poland_spec_provider.pesel(birth_date=None) == "94050306435"
    assert poland_spec_provider.pesel(birth_date=None) == "90071906480"
    assert poland_spec_provider.pesel(birth_date=None) == "87091802447"
    assert poland_spec_provider.pesel(birth_date=None) == "94080701459"
    assert poland_spec_provider.pesel(birth_date=None) == "78052801406"
    assert poland_spec_provider.pesel(birth_date=None) == "59110404415"

# Generated at 2022-06-25 19:56:43.989106
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert poland_spec_provider_0.pesel() == '90020604344'
    assert poland_spec_provider_0.pesel(gender=Gender.FEMALE) == '90021403713'


# Generated at 2022-06-25 19:56:46.288549
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    assert PolandSpecProvider(
    ).pesel(
        birth_date=Datetime().datetime(1940, 2018),
        gender=Gender.MALE,
    ) == '63010108698'

# Generated at 2022-06-25 19:56:57.716944
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert poland_spec_provider_0.pesel(gender=Gender.MALE) == '95012804724'
    assert poland_spec_provider_0.pesel(gender=Gender.MALE) == '57010128797'
    assert poland_spec_provider_0.pesel(gender=Gender.MALE) == '81011029961'
    assert poland_spec_provider_0.pesel(gender=Gender.MALE) == '88012827107'
    assert poland_spec_provider_0.pesel(gender=Gender.MALE) == '90012381161'

# Generated at 2022-06-25 19:57:04.116413
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    print()

    poland_spec_provider_0 = PolandSpecProvider()
    print("pesel(birth_date=None, gender=None)")
    print("pesel(birth_date=poland_spec_provider_0.datetime(1991, 2001), gender=Gender.MALE)")
    print("pesel(birth_date=poland_spec_provider_0.datetime(1991, 2001), gender=Gender.FEMALE)")
    print()
    pesel_0_0 = poland_spec_provider_0.pesel(birth_date=poland_spec_provider_0.datetime(1981, 2021), gender=Gender.MALE)

# Generated at 2022-06-25 19:57:08.278277
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    pesel = poland_spec_provider.pesel()
    assert len(pesel) == 11
    assert int(pesel[2]) % 2 == 0
    assert int(pesel[4]) % 2 == 1



# Generated at 2022-06-25 19:57:10.593455
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    n = poland_spec_provider.pesel()
    assert n == '96121306850'


# Generated at 2022-06-25 19:57:17.709357
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # Test with the default values of all arguments
    poland_spec_provider_1 = PolandSpecProvider()
    result_1 = poland_spec_provider_1.pesel()
    expected_1 = "75010327508"
    assert result_1 == expected_1

    # Test with alternatives for all arguments
    poland_spec_provider_2 = PolandSpecProvider()
    result_2 = poland_spec_provider_2.pesel("1958-09-12", "male")
    expected_2 = "58091209005"
    assert result_2 == expected_2



# Generated at 2022-06-25 19:57:21.619099
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    gender = Gender.MALE
    poland_spec_provider_1 = PolandSpecProvider()
    assert poland_spec_provider_1.pesel(gender=gender) == '55010977677'


# Generated at 2022-06-25 19:57:31.010272
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    male_pesel = poland_spec_provider.pesel(birth_date=Datetime().datetime(1900, 1940),gender=Gender.MALE)
    female_pesel = poland_spec_provider.pesel(birth_date=Datetime().datetime(1900, 1940),gender=Gender.FEMALE)
    random_gender_pesel = poland_spec_provider.pesel(birth_date=Datetime().datetime(1900, 1940))
    assert len(male_pesel) == 11
    assert len(female_pesel) == 11
    assert len(random_gender_pesel) == 11
    assert int(male_pesel[9]) % 2 == 1
    assert int(female_pesel[9]) % 2 == 0

#

# Generated at 2022-06-25 19:57:44.909043
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    ext_val_1 = poland_spec_provider_0.pesel()
    assert ext_val_1 is not None
    assert len(ext_val_1) == 11
    assert type(ext_val_1) is str


# Generated at 2022-06-25 19:57:53.202927
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    seed = 314
    poland_spec_provider_0 = PolandSpecProvider(seed=seed)
    assert poland_spec_provider_0._random.get_state() == seed
    assert poland_spec_provider_0.pesel() == "17021860745"
    assert poland_spec_provider_0.pesel() == "78122618521"
    assert poland_spec_provider_0.pesel(gender=Gender.MALE) == "31293182627"
    assert poland_spec_provider_0.pesel(gender=Gender.FEMALE) == "70292661071"
    poland_spec_provider_0 = PolandSpecProvider(seed=seed)


# Generated at 2022-06-25 19:57:55.722153
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_1 = PolandSpecProvider()
    assert len(poland_spec_provider_1.pesel()) == 11


# Generated at 2022-06-25 19:58:06.110920
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    poland_spec_provider_0.seed(0)
    res_0 = poland_spec_provider_0.pesel()
    poland_spec_provider_0.seed(0)
    res_1 = poland_spec_provider_0.pesel()
    assert res_0 == res_1
    assert len(res_0) == 11
    poland_spec_provider_0.seed(0)
    res_0 = poland_spec_provider_0.pesel(datetime.datetime.now(), Gender.MALE)
    poland_spec_provider_0.seed(0)

# Generated at 2022-06-25 19:58:07.973884
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_1 = PolandSpecProvider()
    poland_spec_provider_1.pesel(birth_date=None, gender=None)


# Generated at 2022-06-25 19:58:14.804550
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():

    # Test all possible gender values
    gender_list = (Gender.MALE, Gender.FEMALE, Gender.ALL)

    # Check if Random class generates random values
    poland_spec_provider_0 = PolandSpecProvider()

    for gender in gender_list:
        pesel_value = poland_spec_provider_0.pesel(gender=gender)
        assert(pesel_value[10] == ('0', '2', '4', '6', '8') or pesel_value[10] == ('1', '3', '5', '7', '9'))



# Generated at 2022-06-25 19:58:15.422379
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pass


# Generated at 2022-06-25 19:58:19.464355
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():

    poland_spec_provider_0 = PolandSpecProvider()
    assert len(poland_spec_provider_0.pesel()) == 11


# Generated at 2022-06-25 19:58:23.896586
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    from inspect import signature
    from mimesis.enums import Gender
    from mimesis.typing import DateTime
    poland_spec_provider = PolandSpecProvider()
    assert len(signature(poland_spec_provider.pesel).parameters) == 2
    pesel = poland_spec_provider.pesel()
    assert len(pesel) == 11
    assert poland_spec_provider.validate_pesel(pesel) == True
    pesel = poland_spec_provider.pesel(DateTime(2020, 1, 1))
    assert len(pesel) == 11
    assert poland_spec_provider.validate_pesel(pesel) == True
    pesel = poland_spec_provider.pesel(Gender.MALE)

# Generated at 2022-06-25 19:58:34.719862
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    check_values = {
        # check if two generated PESELs are the same
        'expected': [
            '68081828129',
            '55122414245',
            '54101113147',
            '92110514230',
            '57062813200',
            '96120610348',
            '52101115461',
            '90040710233',
            '84010219427',
            '76050310222',
            '96071211031',
            '57071419453',
            '60082411227',
            '58071211615',
            '92091402564',
            '95052911193',
            '58061912520',
            '94110209812',
        ]
    }

    poland_spec_

# Generated at 2022-06-25 19:58:42.872783
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    pesel = poland_spec_provider.pesel()
    assert len(pesel) == 11, 'The length of PESEL is not 11'
    assert pesel.isdigit(), 'PESEL contains not only digits'


# Generated at 2022-06-25 19:58:44.689773
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    result = PolandSpecProvider().pesel()
    assert type(result) is str
    assert (len(result) == 11)


# Generated at 2022-06-25 19:58:48.034159
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel(
        birth_date=Datetime().datetime(1900, 2018))
    assert isinstance(pesel, str)
    assert len(pesel) == 11


# Generated at 2022-06-25 19:58:51.578557
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    for i in range(50):
        poland_spec_provider_0 = PolandSpecProvider()
        result = poland_spec_provider_0.pesel()
        assert isinstance(result, str)
        assert result.isdigit()
        assert len(result) == 11


# Generated at 2022-06-25 19:58:59.974350
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    instance0 = PolandSpecProvider()
    instance0.set_seed(4473305356194901897)
    str0 = instance0.pesel()
    assert str0 == '93101013944'
    str0 = instance0.pesel(gender=Gender.FEMALE)
    assert str0 == '94101398247'
    assert len(str0) == 11
    instance0.set_seed(6427351961086962678)
    instance0.set_seed(-7494296107900406257)
    str0 = instance0.pesel()
    assert str0 == '75112531718'
    instance0.set_seed(1133391046823810173)
    str0 = instance0.pesel(gender=Gender.FEMALE)

# Generated at 2022-06-25 19:59:02.797274
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    poland_spec_provider = PolandSpecProvider()
    assert poland_spec_provider.pesel() != poland_spec_provider.pesel()
    assert isinstance(poland_spec_provider.pesel(), str)


# Generated at 2022-06-25 19:59:09.839390
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_1 = PolandSpecProvider(seed=8)
    poland_spec_provider_2 = PolandSpecProvider(seed=8)
    poland_spec_provider_3 = PolandSpecProvider(seed=8)
    poland_spec_provider_4 = PolandSpecProvider(seed=8)
    poland_spec_provider_5 = PolandSpecProvider(seed=8)
    poland_spec_provider_6 = PolandSpecProvider(seed=8)
    poland_spec_provider_7 = PolandSpecProvider(seed=8)
    poland_spec_provider_8 = PolandSpecProvider(seed=8)
    poland_spec_provider_9 = PolandSpecProvider(seed=8)
    poland_spec_provider_10 = PolandSpecProvider(seed=8)

# Generated at 2022-06-25 19:59:11.427336
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    args = [None, None]
    rv = PolandSpecProvider().pesel(*args)
    assert type(rv) is str


# Generated at 2022-06-25 19:59:14.381627
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    poland_spec_provider_0.pesel()  # ValueError: year is out of range


# Generated at 2022-06-25 19:59:17.558992
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    try:
        poland_spec_provider.pesel(birth_date=None, gender=None)
    except Exception as e:
        raise AssertionError("Exception is thrown: '{}'".format(e))


# Generated at 2022-06-25 19:59:38.880838
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    assert poland_spec_provider.pesel() == '73070503880'
    assert poland_spec_provider.pesel() == '50030603328'
    assert poland_spec_provider.pesel() == '95110813247'
    assert poland_spec_provider.pesel() == '55011202803'
    assert poland_spec_provider.pesel(gender=Gender.FEMALE) == '44091711101'
    assert poland_spec_provider.pesel() == '65052907625'
    assert poland_spec_provider.pesel() == '61070851321'
    assert poland_spec_provider.pesel() == '84110609089'

# Generated at 2022-06-25 19:59:40.919393
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_1 = PolandSpecProvider()
    print(poland_spec_provider_1.pesel(gender="female"))



# Generated at 2022-06-25 19:59:43.937124
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert poland_spec_provider_0.pesel() == '69111801435'


# Generated at 2022-06-25 19:59:49.026826
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    test_cases = [Gender.MALE, Gender.FEMALE, None]
    for i in range(5):
        first_pesel = poland_spec_provider.pesel(gender=test_cases[i])
        second_pesel = poland_spec_provider.pesel(gender=test_cases[i])
        assert(first_pesel != second_pesel)


# Generated at 2022-06-25 19:59:54.520757
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_1 = PolandSpecProvider()
    # 1 test
    pesel_0 = poland_spec_provider_1.pesel(gender=0)
    assert len(pesel_0) == 11
    assert (pesel_0[-2]) in ("0", "1", "2", "3", "4", "5", "6", "7", "8", "9")
    assert (pesel_0[-2]) in ("0", "1", "2", "3", "4", "5", "6", "7", "8", "9")
    # 2 test
    pesel_1 = poland_spec_provider_1.pesel(gender=1)
    assert len(pesel_1) == 11

# Generated at 2022-06-25 19:59:58.505948
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    str_0 = poland_spec_provider_0.pesel()
    re_0 = re.compile(r'^\d{11}$')
    assert re_0.search(str_0) is not None



# Generated at 2022-06-25 20:00:00.535280
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    pesel = poland_spec_provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-25 20:00:03.993966
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()
    print(pesel)


# Generated at 2022-06-25 20:00:09.641051
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    poland_spec_provider_1 = PolandSpecProvider()
    assert len(poland_spec_provider_0.pesel()) == 11
    assert len(poland_spec_provider_0.pesel()) == 11
    assert len(poland_spec_provider_1.pesel()) == 11


# Generated at 2022-06-25 20:00:15.796668
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert poland_spec_provider_0.pesel() == '98070561723'
    assert poland_spec_provider_0.pesel() == '33121485853'
    assert poland_spec_provider_0.pesel() == '29042766758'
    assert poland_spec_provider_0.pesel() == '75072420697'
    assert poland_spec_provider_0.pesel() == '96061575059'
    assert poland_spec_provider_0.pesel() == '42012448350'
    assert poland_spec_provider_0.pesel() == '84022047764'