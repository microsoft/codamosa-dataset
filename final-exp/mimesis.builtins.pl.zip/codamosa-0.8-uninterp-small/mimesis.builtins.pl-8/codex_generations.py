

# Generated at 2022-06-25 19:55:05.820196
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider('abc')
    poland_spec_provider_0.pesel(birth_date=None, gender='M')


# Generated at 2022-06-25 19:55:08.344939
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
   poland_spec_provider_1 = PolandSpecProvider()
   assert poland_spec_provider_1.pesel().__len__() == 11, " Pesel must be 11-digit"

# Generated at 2022-06-25 19:55:10.698989
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    assert len(poland_spec_provider.pesel()) == 11


# Generated at 2022-06-25 19:55:14.244070
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    pesel_0 = poland_spec_provider_0.pesel(birth_date=(Datetime(seed=28)).datetime(2010, 2010), gender=Gender.MALE)
    assert isinstance(pesel_0, str)


# Generated at 2022-06-25 19:55:24.794610
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """PESEL checksum generation test"""

# Generated at 2022-06-25 19:55:27.563321
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    print("Running unit test for method pesel of class PolandSpecProvider")
    print("Testing pesel(self)...")
    assert len(PolandSpecProvider().pesel()) == 11


# Generated at 2022-06-25 19:55:28.703552
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert len(poland_spec_provider_0.pesel()) == 11


# Generated at 2022-06-25 19:55:37.520913
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert poland_spec_provider_0.pesel(
        Datetime(
            seed=702539602).datetime(
            1970, 1, 1, 0, 0)) == '70011300209'
    assert poland_spec_provider_0.pesel(
        Datetime(
            seed=702539603).datetime(
            1970, 1, 1, 0, 0)) == '70011200024'
    assert poland_spec_provider_0.pesel(
        Datetime(
            seed=702539604).datetime(
            1970, 1, 1, 0, 0)) == '70011400137'

# Generated at 2022-06-25 19:55:45.104569
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    with_0 = poland_spec_provider_0.pesel()
    with_1 = poland_spec_provider_0.pesel(Gender.FEMALE)
    with_2 = poland_spec_provider_0.pesel(birth_date=poland_spec_provider_0.datetime(2000,2020))
    with_3 = poland_spec_provider_0.pesel(Gender.FEMALE,
                                          birth_date=poland_spec_provider_0.datetime(2000,2020))
    assert with_0
    assert with_1
    assert with_2
    assert with_3


# Generated at 2022-06-25 19:55:47.564204
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert len(poland_spec_provider_0.pesel()) == 11


# Generated at 2022-06-25 19:56:08.952632
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel_0 = poland_spec_provider_0.pesel(
        birth_date=datetime.datetime(year=2018, month=11, day=11),
        gender=mimesis.enums.Gender.MALE,
    )
    pesel_1 = poland_spec_provider_0.pesel(
        birth_date=datetime.datetime(year=2018, month=11, day=11),
        gender=mimesis.enums.Gender.FEMALE,
    )
    pesel_2 = poland_spec_provider_0.pesel(
        birth_date=datetime.datetime(year=2018, month=11, day=11),
        gender=mimesis.enums.Gender.MALE,
    )
    pesel_3 = poland_

# Generated at 2022-06-25 19:56:17.734090
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # (self, birth_date: DateTime = None, gender: Gender = None) -> str:
    poland_spec_provider_0 = PolandSpecProvider()
    poland_spec_provider_0.seed(0)
    assert poland_spec_provider_0.pesel() == '78011606518'
    assert poland_spec_provider_0.pesel() == '78020508800'
    assert poland_spec_provider_0.pesel() == '78032507875'
    assert poland_spec_provider_0.pesel() == '78050205919'
    assert poland_spec_provider_0.pesel() == '78050503923'
    poland_spec_provider_0.reset_seed()


# Generated at 2022-06-25 19:56:21.619880
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    pesel_0 = poland_spec_provider_0.pesel()
    assert len(pesel_0) == 11


# Generated at 2022-06-25 19:56:24.044115
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert len(poland_spec_provider_0.pesel(birth_date=False)) == 11


# Generated at 2022-06-25 19:56:28.909690
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider(seed=124)
    assert poland_spec_provider_0.pesel() == '97021357033'


# Generated at 2022-06-25 19:56:31.734961
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel(birth_date=Datetime().datetime(2002, 7, 29), gender=Gender.MALE)
    assert len(pesel) == 11


# Generated at 2022-06-25 19:56:40.519264
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    # with assert raises
    with pytest.raises(AssertionError):
        poland_spec_provider_0.pesel(
            gender=Gender.FEMALE,
            birth_date=datetime.datetime(
                year=1990, month=3, day=3, hour=0, minute=0,
                second=0, microsecond=0, tzinfo=datetime.timezone.utc))

# Generated at 2022-06-25 19:56:43.948255
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert poland_spec_provider_0.pesel(birth_date=poland_spec_provider_0.datetime(2000, 2020), gender=Gender.MALE)


# Generated at 2022-06-25 19:56:46.538229
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    assert isinstance(poland_spec_provider.pesel(),
                      str)
    assert len(poland_spec_provider.pesel()) == 11


# Generated at 2022-06-25 19:56:51.888220
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # Create PolandSpecProvider
    poland_spec_provider_0 = PolandSpecProvider()
    # Call method pesel of class PolandSpecProvider
    poland_spec_provider_0.pesel()


# Generated at 2022-06-25 19:57:07.731546
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert len(poland_spec_provider_0.pesel())== 11


# Generated at 2022-06-25 19:57:11.488747
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    pesel = poland_spec_provider_0.pesel()
    assert len(pesel) == 11 and pesel.isdigit(), "Pesel is not 11-digit"
    



# Generated at 2022-06-25 19:57:19.555039
# Unit test for method pesel of class PolandSpecProvider

# Generated at 2022-06-25 19:57:24.098746
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_1 = PolandSpecProvider()
    poland_spec_provider_1.pesel(birth_date=Datetime(seed=0).datetime(1940, 2018),
                                 gender=Gender.MALE)


# Generated at 2022-06-25 19:57:26.731202
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert poland_spec_provider_0.pesel() == '93100234426'


# Generated at 2022-06-25 19:57:29.644871
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # Variables initialization
    poland_spec_provider_0 = PolandSpecProvider()  # Default object declaration
    assert poland_spec_provider_0.pesel() != None, "Pesel is invalid"


# Generated at 2022-06-25 19:57:33.765262
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    data_for_test = [(0, '73072923538'), (1, '90040402668')]

    poland_spec_provider_1 = PolandSpecProvider()
    for v, expected in data_for_test:
        data = poland_spec_provider_1.pesel(gender=Gender(v))
        assert data == expected


# Generated at 2022-06-25 19:57:37.420976
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert poland_spec_provider_0.pesel() in ['69011585107', '24031686168', '94021900117', '78070818173', '92004635670', '48102220672', '11010580897', '52021863137']


# Generated at 2022-06-25 19:57:41.466724
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel_0 = None
    pesel_1 = None

    # Test 0: Use default arguments
    poland_spec_provider_0 = PolandSpecProvider()
    pesel_0 = poland_spec_provider_0.pesel()
    assert len(pesel_0) == 11
    pesel_1 = poland_spec_provider_0.pesel(birth_date = "1973-07-09", gender = Gender.MALE)
    assert len(pesel_1) == 11


# Generated at 2022-06-25 19:57:44.442121
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_1 = PolandSpecProvider()
    assert poland_spec_provider_1.pesel() == '18042420093'

# Generated at 2022-06-25 19:58:09.278067
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    poland_spec_provider.seed(3)
    assert poland_spec_provider.pesel(birth_date=DateTime(1995, 12, 17), gender=Gender.MALE) == '95121735135'
    assert poland_spec_provider.pesel(birth_date=DateTime(2003, 5, 27), gender=Gender.FEMALE) == '03052790362'
    poland_spec_provider.seed(0)
    assert poland_spec_provider.pesel(birth_date=DateTime(2003, 5, 27), gender=Gender.FEMALE) == '03052790362'


# Generated at 2022-06-25 19:58:14.888342
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    assert PolandSpecProvider().pesel(birth_date = '2001-12-23', gender = Gender.MALE) == '011223193'
    assert PolandSpecProvider().pesel(birth_date = '2009-11-10', gender = Gender.FEMALE) == '091110164'
    assert PolandSpecProvider().pesel(birth_date = '1941-05-24', gender = Gender.FEMALE) == '810524082'
    assert PolandSpecProvider().pesel(birth_date = '1995-03-03', gender = Gender.MALE) == '950303021'
    assert PolandSpecProvider().pesel(birth_date = '1962-04-17', gender = Gender.MALE) == '620417817'

# Generated at 2022-06-25 19:58:18.525705
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel_num = PolandSpecProvider().pesel()
    assert len(pesel_num) == 11
    assert int(pesel_num[0]) in range(1, 3)


# Generated at 2022-06-25 19:58:23.189632
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider(seed=0)
    gender = poland_spec_provider_0.random.choice(Gender)
    poland_spec_provider_0.random = poland_spec_provider_0.random.new_seed(
        seed=0)
    datetime = Datetime(seed=1)
    for i in range(4):
        datetime.random = datetime.random.new_seed(seed=0)
        year = datetime.year()
        datetime.random = datetime.random.new_seed(seed=1)
        month = datetime.month()
        datetime.random = datetime.random.new_seed(seed=2)
        day = datetime.day()

# Generated at 2022-06-25 19:58:30.957978
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    test_data = [
        ("198802202434",),
        ("199109230205",),
        ("200302070368",),
        ("197705301722",),
        ("199503060130",),
        ("201002090461",),
    ]
    for each_set in test_data:
        if not PolandSpecProvider.pesel(each_set) == True:
            print(PolandSpecProvider.pesel(each_set))
            return False
    return True


# Generated at 2022-06-25 19:58:34.132655
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert (len(poland_spec_provider_0.pesel()) == 11)


# Generated at 2022-06-25 19:58:37.586559
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    assert (len(poland_spec_provider.pesel()) == 11)
    # assert (poland_spec_provider.pesel(datetime.datetime(1981, 3, 9), Gender.FEMALE) == "81309002300")


# Generated at 2022-06-25 19:58:42.732961
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    actual_pesel_0 = poland_spec_provider_0.pesel(birth_date=None, gender=Gender.FEMALE)
    expected_pesel_0 = '32701073060'
    assert actual_pesel_0 == expected_pesel_0

# Generated at 2022-06-25 19:58:51.929352
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    test_case = 0
    # test_case = 1
    # test_case = 2

    if test_case == 0:
        poland_spec_provider_0 = PolandSpecProvider()
        for i in range(5):
            a_pesel = poland_spec_provider_0.pesel()
            print(a_pesel)
        # a_pesel = poland_spec_provider_0.pesel()
        # print(a_pesel)

    if test_case == 1:
        import datetime
        poland_spec_provider_1 = PolandSpecProvider()
        birth_date_1 = datetime.datetime(year=1994, month=1, day=1, hour=0, minute=0)
        gender_1 = Gender.MALE
        a_pesel = poland

# Generated at 2022-06-25 19:58:53.738170
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    assert PolandSpecProvider().pesel() in ['', '0', '4', '8']


# Generated at 2022-06-25 19:59:49.242988
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """
    Test case for method pesel of class PolandSpecProvider
    """
    expected_result_0 = '84450406558'
    instance_0 = PolandSpecProvider()
    call_0 = instance_0.pesel()
    assert call_0 == expected_result_0, 'pesel returned unexpected value'


# Generated at 2022-06-25 19:59:51.307437
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert len(poland_spec_provider_0.pesel()) == 11


# Generated at 2022-06-25 19:59:52.647337
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    _ = PolandSpecProvider().pesel()


# Generated at 2022-06-25 19:59:59.162109
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert len(poland_spec_provider_0.pesel()) == 11
    assert len(poland_spec_provider_0.pesel(
        gender=Gender.MALE)) == 11
    assert len(poland_spec_provider_0.pesel(
        gender=Gender.FEMALE)) == 11


# Generated at 2022-06-25 20:00:08.319546
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    # Provide gender M
    poland_spec_provider_0.pesel(gender=Gender.MALE)
    # Provide gender F
    poland_spec_provider_0.pesel(gender=Gender.FEMALE)
    # Provide gender U
    poland_spec_provider_0.pesel(gender=None)
    # Provide gender = something random
    import random
    poland_spec_provider_0.pesel(gender=random.randint(1, 100))

# Generated at 2022-06-25 20:00:13.139624
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    pesel = poland_spec_provider.pesel(datetime.datetime(year=1880, month=1, day=1))
    parts = [pesel[0:2], pesel[2:4], pesel[4:6], pesel[6:9], pesel[9:11]]
    assert parts[0] == '80'
    assert parts[1] == '01'
    assert parts[2] == '01'

# Generated at 2022-06-25 20:00:17.510063
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    pesel = poland_spec_provider.pesel()
    assert isinstance(pesel, str)
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-25 20:00:23.577406
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    assert PolandSpecProvider().pesel(birth_date=None, gender=None) == '73022238499', 'Failed test_PolandSpecProvider_pesel_0'
    assert PolandSpecProvider().pesel(birth_date=None, gender=None) == '04031867400', 'Failed test_PolandSpecProvider_pesel_1'
    assert PolandSpecProvider().pesel(birth_date=None, gender=None) == '78082503500', 'Failed test_PolandSpecProvider_pesel_2'
    assert PolandSpecProvider().pesel(birth_date=None, gender=None) == '74080304399', 'Failed test_PolandSpecProvider_pesel_3'

# Generated at 2022-06-25 20:00:31.020972
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    poland_spec_provider_0.gender = Gender.FEMALE
    assert len(poland_spec_provider_0.pesel()) == 11

    poland_spec_provider_1 = PolandSpecProvider()
    poland_spec_provider_1.gender = Gender.MALE
    assert len(poland_spec_provider_1.pesel()) == 11


# Generated at 2022-06-25 20:00:32.517667
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel_0 = PolandSpecProvider().pesel()
    assert len(pesel_0) == 11


# Generated at 2022-06-25 20:02:37.490339
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_1 = PolandSpecProvider()


# Generated at 2022-06-25 20:02:42.057221
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_1 = PolandSpecProvider(locale='pl')
    assert poland_spec_provider_1.pesel() == '90122609921'


# Generated at 2022-06-25 20:02:48.404326
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    gender = Gender.FEMALE
    dt = Datetime().datetime(1940, 2018)
    assert (poland_spec_provider_0.pesel(gender=gender, birth_date=dt) ==
            poland_spec_provider_0.pesel(gender=gender, birth_date=dt))



# Generated at 2022-06-25 20:02:50.301789
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_1 = PolandSpecProvider()
    assert len(poland_spec_provider_1.pesel()) == 11

# Unit tests for method pesel of class PolandSpecProvider

# Generated at 2022-06-25 20:02:53.062720
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    pesel = poland_spec_provider_0.pesel()
    assert len(pesel) == 11
    assert pesel.isnumeric() == True


# Generated at 2022-06-25 20:02:57.644669
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert poland_spec_provider_0.pesel(birth_date=None, gender=None) == '0105273845'


# Generated at 2022-06-25 20:03:00.784767
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()

    # Call method under test
    result_0 = poland_spec_provider_0.pesel()
    assert result_0 is not None
    assert type(result_0) is str
    assert len(result_0) == 11


# Generated at 2022-06-25 20:03:08.400022
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():

    poland_spec_provider_1 = PolandSpecProvider(seed=0)
    assert poland_spec_provider_1.pesel(birth_date=datetime(year=2015, month=9, day=28, hour=23, minute=12, second=33, microsecond=709299)) == '1512282393'
    assert poland_spec_provider_1.pesel(birth_date=datetime(year=1965, month=7, day=9, hour=7, minute=19, second=7, microsecond=47529)) == '6507090799'

# Generated at 2022-06-25 20:03:12.433607
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    pesel = poland_spec_provider_0.pesel(gender=Gender.MALE)
    assert type(pesel) == str
    assert len(pesel) == 11


# Generated at 2022-06-25 20:03:14.914439
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert poland_spec_provider_0.pesel(Gender.FEMALE)
