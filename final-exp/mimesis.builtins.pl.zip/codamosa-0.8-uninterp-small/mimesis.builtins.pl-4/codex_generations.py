

# Generated at 2022-06-25 19:55:04.895149
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()

    assert len(poland_spec_provider.pesel()) == 11


# Generated at 2022-06-25 19:55:07.784648
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()

    assert len(poland_spec_provider.pesel()) == 11
    assert poland_spec_provider.pesel(
        Datetime().datetime(1940, 2018)).isdigit()
    assert len(poland_spec_provider.pesel(
        Datetime().datetime(1940, 2018))) == 11


# Generated at 2022-06-25 19:55:10.610036
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    pesel = poland_spec_provider.pesel()
    assert isinstance(pesel, str)



# Generated at 2022-06-25 19:55:17.531798
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert (poland_spec_provider_0.pesel() != poland_spec_provider_0.pesel())
    assert poland_spec_provider_0.pesel(birth_date=Datetime().datetime(2010, 2010), gender=Gender.MALE) == '10011012519'
    assert poland_spec_provider_0.pesel(birth_date=Datetime().datetime(2010, 2010), gender=Gender.FEMALE) == '10111012515'
    assert poland_spec_provider_0.pesel(birth_date=Datetime().datetime(2010, 2010)) == '10111012522'

# Generated at 2022-06-25 19:55:23.324772
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    pesel_0 = poland_spec_provider.pesel()
    pesel_1 = poland_spec_provider.pesel(birth_date="08/11/1996", gender=Gender.MALE)
    assert len(pesel_0) == 11
    assert len(pesel_1) == 11


# Generated at 2022-06-25 19:55:26.995663
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    polandProvider_0 = PolandSpecProvider()
    assert (polandProvider_0.pesel(DateTime().datetime(), Gender.MALE) and
            polandProvider_0.pesel(DateTime().datetime(), Gender.FEMALE))


# Generated at 2022-06-25 19:55:28.864508
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    assert len(poland_spec_provider.pesel()) == 11


# Generated at 2022-06-25 19:55:33.365815
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    assert poland_spec_provider.pesel(birth_date=DateTime(2018, 7, 18), gender=Gender.MALE) == '1807181533689'
    assert poland_spec_provider.pesel(birth_date=DateTime(2018, 7, 18), gender=Gender.FEMALE) == '1807181833685'

# Generated at 2022-06-25 19:55:36.524497
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    assert isinstance(poland_spec_provider.pesel(birth_date=datetime.datetime(2003, 10, 10), gender=Gender.FEMALE), str)


# Generated at 2022-06-25 19:55:38.656552
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert len(poland_spec_provider_0.pesel()) == 11


# Generated at 2022-06-25 19:55:52.099120
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    actual = poland_spec_provider_0.pesel() # 11-digit PESEL


# Generated at 2022-06-25 19:56:00.336106
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test: PolandSpecProvider=>pesel."""
    p = PolandSpecProvider()
    reference = "75082824956"
    result = p.pesel()
    assert result == reference, "Failed: Should return '{}' but get '{}'".format(
        reference, result)

    reference = "77030123456"
    p = PolandSpecProvider(seed=50)
    result = p.pesel()
    assert result == reference, "Failed: Should return '{}' but get '{}'".format(
        reference, result)

    reference = "76040202729"
    p = PolandSpecProvider(seed=100)
    result = p.pesel()
    assert result == reference, "Failed: Should return '{}' but get '{}'".format(
        reference, result)

# Generated at 2022-06-25 19:56:02.452517
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    pesel = p.pesel()
    assert isinstance(pesel, str)


# Generated at 2022-06-25 19:56:07.350657
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()

    assert re.match(r'\d{11}', poland_spec_provider.pesel()) is not None


# Generated at 2022-06-25 19:56:12.796451
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    gender_0 = Gender.MALE
    pesel_0 = PolandSpecProvider().pesel(gender=gender_0)
    gender_1 = Gender.FEMALE
    pesel_1 = PolandSpecProvider().pesel(gender=gender_1)
    gender_2 = Gender.UNKNOWN
    pesel_2 = PolandSpecProvider().pesel(gender=gender_2)

# Generated at 2022-06-25 19:56:19.833629
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Get PESEL for the specified parameters.

    :return: Valid 11-digit PESEL
    """
    date_object = poland_spec_provider_0.datetime(1940, 2018)
    pesel = poland_spec_provider_0.pesel(date_object)
    assert isinstance(pesel, str)
    assert len(pesel) == 11
    assert pesel[0] in ('1', '2', '3', '4', '5', '6', '7', '8', '9', '0')
    assert pesel[1] in ('2', '3', '4', '5', '6', '7', '8', '9')

# Generated at 2022-06-25 19:56:25.339316
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    date_time_0 = poland_spec_provider_0.datetime()
    pesel = poland_spec_provider_0.pesel(date_time_0, None)
    assert isinstance(pesel, str)
    assert len(pesel) == 11
    assert int(pesel[0]) in range(2)
    assert int(pesel[9]) in range(10)


# Generated at 2022-06-25 19:56:35.420063
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # Initial seed
    seed = 123456
    # Initialization of an PolandSpecProvider object with a given seed
    poland_spec_provider_0 = PolandSpecProvider(seed=seed)
    # Generate a PESEL number
    assert poland_spec_provider_0.pesel() == '70420481267'
    # Generate a PESEL number for males
    assert poland_spec_provider_0.pesel(gender=Gender.MALE) == '91201170575'
    # Generate a PESEL number for females
    assert poland_spec_provider_0.pesel(gender=Gender.FEMALE) == '93011070381'
    # Generate a PESEL number with a given birth date

# Generated at 2022-06-25 19:56:38.308961
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_1 = PolandSpecProvider()
    assert len(poland_spec_provider_1.pesel()) == 11


# Generated at 2022-06-25 19:56:44.684693
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    # Test case 0
    assert poland_spec_provider_0.pesel(None, None) in ['85121335280', '59081036064', '54032960776', '59042058140', '96081766751', '63082453492', '93040962109', '76090830168', '86061801157', '67100477025', ]
