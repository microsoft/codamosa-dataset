

# Generated at 2022-06-25 19:55:14.141245
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert poland_spec_provider_0.pesel() == '65122415471'
    assert poland_spec_provider_0.pesel() == '50070993782'
    assert poland_spec_provider_0.pesel() == '79062200444'
    assert poland_spec_provider_0.pesel() == '46080698214'
    assert poland_spec_provider_0.pesel() == '85123028038'
    assert poland_spec_provider_0.pesel() == '48120439108'
    assert poland_spec_provider_0.pesel() == '38111018466'

# Generated at 2022-06-25 19:55:19.390441
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    # result = poland_spec_provider.pesel(gender = Gender.FEMALE)
    result = poland_spec_provider.pesel(birth_date = "19-09-1998", gender = Gender.FEMALE)
    assert len(result) == 11, "result is not correct"

# Generated at 2022-06-25 19:55:24.551766
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    children_birth_date = Datetime().datetime(1940, 2018)
    PESEL = PolandSpecProvider().pesel(children_birth_date)
    assert len(PESEL) == 11
    try:
        PESEL = int(PESEL)
        assert (0 <= PESEL <= 99999999999)
    except:
        assert False


# Generated at 2022-06-25 19:55:26.686874
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_ = PolandSpecProvider()
    assert len(poland_spec_provider_.pesel()) == 11


# Generated at 2022-06-25 19:55:30.628895
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    data = [
            '98041210320',
            '96063120659',
            '96070700054',
            '96052402196',
            '96033108081',
            '96020700426',
            '96010902854',
            ]
    for item in data:
        assert PolandSpecProvider().pesel() == item
# ----------------------------------------------------------------------------


# Generated at 2022-06-25 19:55:34.147559
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Generate a random valid 11-digit PESEL.

    :return: Valid 11-digit PESEL
    :rtype: str
    """
    poland_spec_provider_0 = PolandSpecProvider()
    assert poland_spec_provider_0.pesel() is not None

# Generated at 2022-06-25 19:55:36.748659
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # Case 0.
    # Test with empty arguments
    poland_spec_provider_0 = PolandSpecProvider()
    pesel = poland_spec_provider_0.pesel()


# Generated at 2022-06-25 19:55:38.544419
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    assert len(poland_spec_provider.pesel()) == 11


# Generated at 2022-06-25 19:55:44.589242
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # 1st test
    poland_spec_provider_1 = PolandSpecProvider()
    poland_spec_provider_1.pesel(birth_date=DateTime(),
                                 gender=Gender.FEMALE)
    # 2nd test
    poland_spec_provider_2 = PolandSpecProvider()
    poland_spec_provider_2.pesel(birth_date=DateTime())
    # 3rd test
    poland_spec_provider_3 = PolandSpecProvider()
    poland_spec_provider_3.pesel()

# Generated at 2022-06-25 19:55:47.988182
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert poland_spec_provider_0.pesel() < '99999999999'
    assert poland_spec_provider_0.pesel() >= '11111111111'


# Generated at 2022-06-25 19:56:13.232639
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_1 = PolandSpecProvider()
    mock_gender_0 = Gender.FEMALE
    result_0 = poland_spec_provider_1.pesel(gender=mock_gender_0)
    assert isinstance(result_0, str)
    assert len(result_0) == 11
    mock_gender_1 = Gender.FEMALE
    result_1 = poland_spec_provider_1.pesel(gender=mock_gender_1)
    assert isinstance(result_1, str)
    assert len(result_1) == 11
    mock_gender_2 = Gender.MALE
    result_2 = poland_spec_provider_1.pesel(gender=mock_gender_2)
    assert isinstance(result_2, str)
    assert len

# Generated at 2022-06-25 19:56:15.729089
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider(seed=0)
    assert poland_spec_provider_0.pesel() == '80071512211'


# Generated at 2022-06-25 19:56:21.886451
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_1 = PolandSpecProvider()
    poland_spec_provider_2 = PolandSpecProvider(seed=1234567890)
    assert poland_spec_provider_1.pesel() == '48011113180'
    assert poland_spec_provider_2.pesel() == '48011113180'


# Generated at 2022-06-25 19:56:23.158950
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()

    assert(provider.pesel())

# Generated at 2022-06-25 19:56:25.242198
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert len(str(poland_spec_provider_0.pesel())) == 11


# Generated at 2022-06-25 19:56:28.606784
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider(seed=0)
    assert len(poland_spec_provider_0.pesel()) == 11


# Generated at 2022-06-25 19:56:37.978464
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    filter_pesel = ['pesel']
    poland_spec_provider_0 = PolandSpecProvider()
    assert poland_spec_provider_0.pesel() in filter_pesel
    assert poland_spec_provider_0.pesel(birth_date=Datetime().datetime()) in filter_pesel
    assert poland_spec_provider_0.pesel(gender=Gender.MALE) in filter_pesel
    assert poland_spec_provider_0.pesel(birth_date=Datetime().datetime(),gender=Gender.MALE) in filter_pesel
    assert poland_spec_provider_0.pesel(birth_date=Datetime().datetime(),gender=Gender.FEMALE) in filter_pesel


# Generated at 2022-06-25 19:56:41.900888
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert re.match(r'\d{11}', poland_spec_provider_0.pesel())


# Generated at 2022-06-25 19:56:46.214838
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
# PESEL

    birth_date_0 = Datetime().datetime(1970, 1, 1)
    gender_0 = Gender.MALE
    result_0 = poland_spec_provider.pesel(birth_date=birth_date_0,
                                         gender=gender_0)
    assert len(result_0) == 11


# Generated at 2022-06-25 19:56:56.793015
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert len(poland_spec_provider_0.pesel()) == 11
    assert '{:02d}'.format(1) == '01'
    assert '{:02d}'.format(11) == '11'
    assert len(poland_spec_provider_0.pesel(birth_date=poland_spec_provider_0.datetime(2017, 2017))) == 11
    assert len(poland_spec_provider_0.pesel(gender=Gender.FEMALE)) == 11
    assert len(poland_spec_provider_0.pesel(gender=Gender.MALE)) == 11



# Generated at 2022-06-25 19:57:19.589444
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert len(poland_spec_provider_0.pesel()) == 11


# Generated at 2022-06-25 19:57:29.920401
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    # unit-test defined entity pesel
    assert len(poland_spec_provider.pesel()) == 11
    assert poland_spec_provider.pesel()[-2] != '.'
    assert poland_spec_provider.pesel()[-1] != '.'
    # unit-test for entity pesel with param(s)
    assert len(poland_spec_provider.pesel(Datetime().datetime(1991,1991),Gender.FEMALE)) == 11
    # unit-test for entity pesel with param(s)
    assert poland_spec_provider.pesel(Datetime().datetime(1991,1991),Gender.FEMALE)[-2] != '.'

# Generated at 2022-06-25 19:57:37.786386
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    arg0 = poland_spec_provider_0.datetime()
    arg1 = poland_spec_provider_0.gender()
    ret_0 = poland_spec_provider_0.pesel(arg0, arg1)
    arg0 = poland_spec_provider_0.datetime()
    arg1 = poland_spec_provider_0.gender()
    ret_1 = poland_spec_provider_0.pesel(arg0, arg1)
    arg0 = poland_spec_provider_0.datetime()
    arg1 = poland_spec_provider_0.gender()
    ret_2 = poland_spec_provider_0.pesel(arg0, arg1)
    assert ret

# Generated at 2022-06-25 19:57:42.376082
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    p = poland_spec_provider_0.pesel()
    assert len(p) == 11


# Generated at 2022-06-25 19:57:45.527432
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_1 = PolandSpecProvider()
    result_0 = poland_spec_provider_1.pesel()
    assert re.match('^\d{11}$', result_0)


# Generated at 2022-06-25 19:57:50.042454
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    test_case_0()  # dummy call to prevent IDEs from throwing errors
    poland_spec_provider_0 = PolandSpecProvider()
    gender_0 = Gender.FEMALE
    result_0 = poland_spec_provider_0.pesel(gender=gender_0)
    assert isinstance(result_0, str)


# Generated at 2022-06-25 19:57:53.119515
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    poland_spec_provider.seed(1234)
    result = poland_spec_provider.pesel(gender=Gender.MALE)
    assert result == "66061538772"

# Generated at 2022-06-25 19:57:55.979479
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    pesel_0 = poland_spec_provider.pesel()
    assert len(pesel_0) == 11


# Generated at 2022-06-25 19:57:57.067742
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_1 = PolandSpecProvider()
    poland_spec_provider_1.pesel()

# Generated at 2022-06-25 19:58:01.643619
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    poland_spec_provider_0.pesel()
    assert poland_spec_provider_0.pesel() != poland_spec_provider_0.pesel()
