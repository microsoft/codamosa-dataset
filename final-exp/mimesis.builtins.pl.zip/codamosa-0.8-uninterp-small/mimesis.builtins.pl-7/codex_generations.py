

# Generated at 2022-06-25 19:55:13.111441
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_1 = PolandSpecProvider()
    poland_spec_provider_1.seed(1)
    assert poland_spec_provider_1.pesel(birth_date=None, gender=Gender.MALE) == '48012004056'
    assert poland_spec_provider_1.pesel(birth_date=None, gender=Gender.FEMALE) == '74011018020'
    poland_spec_provider_1.seed(2)
    assert poland_spec_provider_1.pesel(birth_date=None, gender=Gender.MALE) == '57100407270'
    assert poland_spec_provider_1.pesel(birth_date=None, gender=Gender.FEMALE) == '05090812053'
   

# Generated at 2022-06-25 19:55:15.927612
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    instance = PolandSpecProvider()
    from datetime import datetime
    birth_date = datetime(1995, 1, 1)
    gender = Gender.MALE
    result = instance.pesel(birth_date, gender)
    assert isinstance(result, str)
    assert len(result) == 11


# Generated at 2022-06-25 19:55:19.147505
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()

    assert 11 == len(poland_spec_provider_0.pesel())


# Generated at 2022-06-25 19:55:21.946769
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    result = poland_spec_provider.pesel()
    assert len(result) == 11


# Generated at 2022-06-25 19:55:22.929877
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    assert PolandSpecProvider().pesel()


# Generated at 2022-06-25 19:55:31.495560
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    assert PolandSpecProvider().pesel() == '96022300453'
    assert PolandSpecProvider().pesel() == '97012900487'
    assert PolandSpecProvider().pesel() == '89102100518'
    assert PolandSpecProvider().pesel() == '89022800070'
    assert PolandSpecProvider().pesel() == '93121200639'
    assert PolandSpecProvider().pesel() == '65120100198'
    assert PolandSpecProvider().pesel() == '95120700273'
    assert PolandSpecProvider().pesel() == '80122900055'
    assert PolandSpecProvider().pesel() == '90921500123'
    assert PolandSpecProvider().pesel() == '70072602546'
    assert PolandSpecProvider().pesel() == '73020700818'
    assert PolandSpecProvider

# Generated at 2022-06-25 19:55:33.744098
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_pesel = PolandSpecProvider()
    assert len(poland_spec_provider_pesel.pesel()) == 11


# Generated at 2022-06-25 19:55:38.972121
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
#    print(poland_spec_provider_0.pesel(birth_date=datetime(1998, 1, 2, 0, 0), gender=Gender.FEMALE))
    assert len(poland_spec_provider_0.pesel(birth_date=datetime(1998, 1, 2, 0, 0), gender=Gender.FEMALE)) == 11, "This assertion has not been implemented yet."


# Generated at 2022-06-25 19:55:41.372809
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    psp = PolandSpecProvider()
   
    # Execute functionality
    p = psp.pesel()

    assert isinstance(p, str)
    assert len(p) == 11


# Generated at 2022-06-25 19:55:44.254486
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    str_0 = poland_spec_provider_0.pesel()
    assert len(str_0) == 11 and str_0 != None


# Generated at 2022-06-25 19:55:56.417358
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_1 = PolandSpecProvider()
    pesel = poland_spec_provider_1.pesel(birth_date=None, gender=None)
    assert len(pesel) == 11, "assertion failure"
    assert len(str(pesel)) == 11, "assertion failure"
    assert isinstance(pesel, str), "assertion failure"


# Generated at 2022-06-25 19:55:58.970394
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    res = poland_spec_provider.pesel()
    assert res == '85081412795'



# Generated at 2022-06-25 19:56:05.723173
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_1 = PolandSpecProvider()
    assert len(poland_spec_provider_1.pesel()) == 11
    assert len(poland_spec_provider_1.pesel(gender=Gender.MALE)) == 11
    assert len(poland_spec_provider_1.pesel(gender=Gender.FEMALE)) == 11


# Generated at 2022-06-25 19:56:09.164096
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    str_1 = poland_spec_provider_0.pesel()
    assert str_1 is not None



# Generated at 2022-06-25 19:56:10.988617
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel_0 = PolandSpecProvider().pesel()
    assert len(pesel_0) == 11


# Generated at 2022-06-25 19:56:15.766564
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    the_date = "2019-01-11T16:54:39.000+01:00"
    poland_spec_provider = PolandSpecProvider()
    the_pesel = poland_spec_provider.pesel(the_date, Gender.MALE)
    print(the_pesel)
    assert(len(the_pesel) == 11)


# Generated at 2022-06-25 19:56:19.844291
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    expected = '19100100100'
    actual = poland_spec_provider.pesel()
    assert actual == expected


# Generated at 2022-06-25 19:56:21.353268
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    assert (PolandSpecProvider().pesel() == '02090690807') or \
        (PolandSpecProvider().pesel() == '02090690808')


# Generated at 2022-06-25 19:56:23.339127
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()

    poland_spec_provider_0.pesel()


# Generated at 2022-06-25 19:56:27.936560
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel_0 = poland_spec_provider_0.pesel()
    assert type(pesel_0) is str


# Generated at 2022-06-25 19:56:45.886382
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    pesel = poland_spec_provider.pesel(gender=Gender.MALE)
    gender_digit = int(pesel[9])
    assert gender_digit in (1, 3, 5, 7, 9)
    pesel = poland_spec_provider.pesel(gender=Gender.FEMALE)
    gender_digit = int(pesel[9])
    assert gender_digit in (0, 2, 4, 6, 8)
    pesel = poland_spec_provider.pesel(gender=Gender.NOT_SPECIFIED)
    gender_digit = int(pesel[9])
    assert gender_digit in (range(10))


# Generated at 2022-06-25 19:56:48.031556
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # Arrange
    poland_spec_provider_0 = PolandSpecProvider()

    # Act
    result = poland_spec_provider_0.pesel()

    # Assert
    assert len(result) == 11


# Generated at 2022-06-25 19:56:50.946569
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    assert PolandSpecProvider().pesel() == '98061408415'

# Generated at 2022-06-25 19:56:55.301083
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    print("pesel")
    gender = Gender.FEMALE
    birth_date = Datetime().datetime(2008, 2008)
    poland_spec_provider_0 = PolandSpecProvider()
    poland_spec_provider_0.pesel(birth_date, gender)
    print("Test case 0")


# Generated at 2022-06-25 19:56:57.015365
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    instance_0 = PolandSpecProvider()
    assert re.match('^\\d+$', instance_0.pesel()) is not None


# Generated at 2022-06-25 19:56:59.427566
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pl_pesel_0 = PolandSpecProvider().pesel()
    assert len(pl_pesel_0) == 11
    assert '0' <= pl_pesel_0[0] <= '2'


# Generated at 2022-06-25 19:57:02.437621
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    date_object_0 = Datetime().datetime(1940, 2018)
    gender_0 = Gender.FEMALE
    str_0 = poland_spec_provider_0.pesel(date_object_0, gender_0)


# Generated at 2022-06-25 19:57:05.444235
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    for _ in range(10):
        assert len(PolandSpecProvider().pesel()) == 11, \
            'incorrect number of digits in PESEL'



# Generated at 2022-06-25 19:57:11.834150
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    _birth_date = Datetime().datetime(1985, 1995)
    _gender = Gender.MALE
    assert len(poland_spec_provider_0.pesel(_birth_date, _gender)) == 11, "Method length failed"
    assert isinstance(poland_spec_provider_0.pesel(_birth_date, _gender), str), "Return value is not a string"


# Generated at 2022-06-25 19:57:13.837339
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    gender_0 = Gender.FEMALE
        
    got = poland_spec_provider_0.pesel(gender=gender_0)

    assert len(got) == 11
    assert got != poland_spec_provider_0.pesel(gender=gender_0)


# Generated at 2022-06-25 19:57:35.582277
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert len(poland_spec_provider_0.pesel('1995-02-13')) == 11
    assert len(poland_spec_provider_0.pesel('1995-02-13','MALE')) == 11
    assert len(poland_spec_provider_0.pesel('1995-02-13','FEMALE')) == 11
    assert poland_spec_provider_0.pesel(birth_date='1995-02-13') == '95021323395'
    assert poland_spec_provider_0.pesel(birth_date='1995-02-13',gender='MALE') == '95021323395'

# Generated at 2022-06-25 19:57:41.739948
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_1 = PolandSpecProvider()
    result_1 = poland_spec_provider_1.pesel()
    correct_answer_1 = True
    assert result_1 != 'None', 'The result returned by the funcPolandSpecProvider_pesel() is wrong'
    assert result_1 != None, 'The result returned by the funcPolandSpecProvider_pesel() is wrong'
    assert result_1 != '', 'The result returned by the funcPolandSpecProvider_pesel() is wrong'
    assert result_1 != ' ', 'The result returned by the funcPolandSpecProvider_pesel() is wrong'
    assert result_1 != '.', 'The result returned by the funcPolandSpecProvider_pesel() is wrong'

# Generated at 2022-06-25 19:57:42.527856
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    assert(len(PolandSpecProvider().pesel())==11)
    

# Generated at 2022-06-25 19:57:44.274687
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    ret_0 = poland_spec_provider_0.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.FEMALE)
    assert ret_0 is not None


# Generated at 2022-06-25 19:57:48.175709
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    poland_spec_provider.seed(0)
    assert poland_spec_provider.pesel() == '97081227602'
    assert poland_spec_provider.pesel() == '85030629530'


# Generated at 2022-06-25 19:57:50.503517
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert len(poland_spec_provider_0.pesel()) == 11


# Generated at 2022-06-25 19:57:54.633284
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    import pytest
    poland_spec_provider_0 = PolandSpecProvider()
    assert len(poland_spec_provider_0.pesel()) == 11
    assert poland_spec_provider_0.pesel() == pytest.approx('90690617111')
    


# Generated at 2022-06-25 19:57:55.759826
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    assert provider.pesel()



# Generated at 2022-06-25 19:57:59.277425
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    ret_value_0 = poland_spec_provider_0.pesel()
    assert re.search(r'\d{11}', ret_value_0)


# Generated at 2022-06-25 19:58:01.988777
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    assert len(poland_spec_provider.pesel()) == 11


# Generated at 2022-06-25 19:58:36.511177
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    gender_0 = Gender.FEMALE
    assert len(poland_spec_provider_0.pesel(gender=gender_0)) == 11


# Generated at 2022-06-25 19:58:37.988590
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    poland_spec_provider_0.pesel()


# Generated at 2022-06-25 19:58:41.664924
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert len(poland_spec_provider_0.pesel()) == 11


# Generated at 2022-06-25 19:58:43.945136
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()
    assert len(pesel) == 11


# Generated at 2022-06-25 19:58:45.936947
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    result = len(poland_spec_provider_0.pesel())
    assert result == 11



# Generated at 2022-06-25 19:58:49.149622
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # Given
    poland_spec_provider = PolandSpecProvider()
    # When
    result = poland_spec_provider.pesel()
    # Then
    assert len(result) == 11

# Generated at 2022-06-25 19:58:52.628679
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_1 = PolandSpecProvider()
    pesel_1 = poland_spec_provider_1.pesel(gender=Gender.MALE)
    assert len(pesel_1) == 11
    assert 'M' in pesel_1

# Generated at 2022-06-25 19:58:55.414716
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # Test if method pesel of class PolandSpecProvider works
    assert PolandSpecProvider().pesel().isdigit()
    assert len(PolandSpecProvider().pesel()) == 11


# Generated at 2022-06-25 19:59:02.478353
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    # Case 0
    gender = Gender.FEMALE
    actual_value_0 = poland_spec_provider_0.pesel(gender)
    expected_value_0 = '0'
    assert expected_value_0 == actual_value_0
    # Case 1
    gender = Gender.MALE
    actual_value_1 = poland_spec_provider_0.pesel(gender)
    expected_value_1 = '1'
    assert expected_value_1 == actual_value_1
    # Case 2
    gender = Gender.OTHER
    actual_value_2 = poland_spec_provider_0.pesel(gender)
    expected_value_2 = '2'
    assert expected_value_2 == actual_value_2


# Generated at 2022-06-25 19:59:05.018260
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    datetime_0 = Datetime()
    datetime_0.datetime(1940, 2018)
    pesel_0 = poland_spec_provider_0.pesel(datetime_0, Gender.MALE)
    assert len(pesel_0) == 11