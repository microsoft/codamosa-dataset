

# Generated at 2022-06-25 19:55:06.424080
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    poland_spec_provider_1 = PolandSpecProvider()
    assert poland_spec_provider_0.pesel(gender=Gender.MALE) == poland_spec_provider_1.pesel(gender=Gender.MALE)


# Generated at 2022-06-25 19:55:08.107246
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # Test if pesel method of PolandSpecProvider gets proper value
    assert PolandSpecProvider().pesel(birth_date="[1985,8,20]") == "85082000012"

# Generated at 2022-06-25 19:55:10.472920
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel_0 = PolandSpecProvider.pesel(PolandSpecProvider())
    assert isinstance(pesel_0, str)


# Generated at 2022-06-25 19:55:12.504264
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert poland_spec_provider_0.pesel()


# Generated at 2022-06-25 19:55:14.244027
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    assert len(poland_spec_provider.pesel()) == 11


# Generated at 2022-06-25 19:55:22.046303
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert poland_spec_provider_0.pesel() == '65082901639'
    assert poland_spec_provider_0.pesel() == '51061490484'
    poland_spec_provider_1 = PolandSpecProvider(seed=700)
    assert poland_spec_provider_1.pesel() == '55101010396'
    assert poland_spec_provider_1.pesel() == '82080704444'


# Generated at 2022-06-25 19:55:25.417863
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    expected_pesel = '97080336999'
    poland_spec_provider_1 = PolandSpecProvider()
    generated_pesel = poland_spec_provider_1.pesel()
    assert generated_pesel == expected_pesel

# Generated at 2022-06-25 19:55:29.323690
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    print("**********************")
    print("Test:\tPESEL generator")
    print("**********************")
    poland_spec_provider_0 = PolandSpecProvider()
    assert poland_spec_provider_0.pesel() == "88030100752"
    assert poland_spec_provider_0.pesel() == "80021581362"
    assert poland_spec_provider_0.pesel() == "83032988560"
    assert poland_spec_provider_0.pesel() == "87032141637"
    assert poland_spec_provider_0.pesel() == "83032687815"
    assert poland_spec_provider_0.pesel() == "83033008843"

# Generated at 2022-06-25 19:55:31.489701
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel_provider = PolandSpecProvider()
    pesel_test = pesel_provider.pesel(
        gender=Gender.MALE)
    print(pesel_test)

# Generated at 2022-06-25 19:55:33.744263
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_1 = PolandSpecProvider()
    pesel_0 = poland_spec_provider_1.pesel()


# Generated at 2022-06-25 19:55:43.612003
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    instance_0 = PolandSpecProvider()
    # Test for method pesel of class PolandSpecProvider
    assert instance_0.pesel() == '98063005603'


# Generated at 2022-06-25 19:55:47.924143
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():

    poland_spec_provider_0 = PolandSpecProvider(seed=1)
    date_object_0 = Datetime().datetime(year=1940, maximum=(Datetime()).datetime(year=2018))
    for x_0 in range(1):
        assert poland_spec_provider_0.pesel() == "91112012468"


# Generated at 2022-06-25 19:55:50.469459
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_provider = PolandSpecProvider()
    res = poland_provider.pesel()
    assert len(res) == 11
    assert type(res) == str


# Generated at 2022-06-25 19:55:53.780187
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # fmt: off
    expected_result_0 = '86051320297'
    # fmt: on
    result = PolandSpecProvider().pesel()
    if isinstance(result, str):
        result = result.encode('utf-8')
    assert result == expected_result_0


# Generated at 2022-06-25 19:55:54.941898
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel_0 = poland_spec_provider_0.pesel()


# Generated at 2022-06-25 19:55:55.802998
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pass


# Generated at 2022-06-25 19:55:57.755810
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    assert PolandSpecProvider(seed=1).pesel(birth_date=None, gender=None) == '56091600437'


# Generated at 2022-06-25 19:56:08.791277
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel_len = 11
    poland_spec_provider_0 = PolandSpecProvider()
    pesel = poland_spec_provider_0.pesel(gender='male')
    assert len(pesel) == pesel_len
    pesel = poland_spec_provider_0.pesel(gender='female')
    assert len(pesel) == pesel_len
    pesel = poland_spec_provider_0.pesel(gender='male')
    assert len(pesel) == pesel_len
    pesel = poland_spec_provider_0.pesel(gender='female')
    assert len(pesel) == pesel_len


# Generated at 2022-06-25 19:56:14.421533
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_16 = PolandSpecProvider()
    poland_spec_provider_17 = PolandSpecProvider()
    poland_spec_provider_17.random.seed(0)
    assert poland_spec_provider_16.pesel() == '01060302969'
    assert poland_spec_provider_17.pesel() == '66103021859'


# Generated at 2022-06-25 19:56:18.774416
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    arg_0 = poland_spec_provider_0.pesel()
    assert len(arg_0) == 11


# Generated at 2022-06-25 19:56:29.162271
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():

    pass



# Generated at 2022-06-25 19:56:30.652870
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    assert PolandSpecProvider().pesel() == '01010112131'


# Generated at 2022-06-25 19:56:35.018657
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Tests for the method pesel"""
    poland_spec_provider_0 = PolandSpecProvider()
    for _ in range(1000):
        pesel_0 = poland_spec_provider_0.pesel()
        assert len(pesel_0) == 11
        assert len(str(int(pesel_0))) == 11


# Generated at 2022-06-25 19:56:38.210276
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    print('Testing method pesel...')
    for i in range(100):
        assert(len(PolandSpecProvider().pesel()) == 11)
    print('Testing method pesel passed successfully!')


# Generated at 2022-06-25 19:56:40.466388
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    r = PolandSpecProvider().pesel()
    assert r == '69030321786'

# Generated at 2022-06-25 19:56:42.871944
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert poland_spec_provider_0.pesel() == "88082000111"


# Generated at 2022-06-25 19:56:49.357634
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider('seed')
    poland_spec_provider_1 = PolandSpecProvider('seed')
    poland_spec_provider_2 = PolandSpecProvider('seed')
    poland_spec_provider_3 = PolandSpecProvider('seed')
    poland_spec_provider_4 = PolandSpecProvider('seed')
    poland_spec_provider_5 = PolandSpecProvider('seed')
    poland_spec_provider_6 = PolandSpecProvider('seed')
    poland_spec_provider_7 = PolandSpecProvider('seed')
    poland_spec_provider_8 = PolandSpecProvider('seed')
    poland_spec_provider_9 = PolandSpecProvider('seed')
    poland_spec_provider_10 = PolandSpecProvider('seed')

   

# Generated at 2022-06-25 19:56:56.275164
# Unit test for method pesel of class PolandSpecProvider

# Generated at 2022-06-25 19:57:03.223242
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert re.match("^[0-9]{11}$", poland_spec_provider_0.pesel())
    assert len(poland_spec_provider_0.pesel()) == 11
    assert re.match("^[0-9]{11}$", poland_spec_provider_0.pesel())
    assert len(poland_spec_provider_0.pesel()) == 11
    assert re.match("^[0-9]{11}$", poland_spec_provider_0.pesel(datetime.datetime(2009, 12, 3), Gender.FEMALE))

# Generated at 2022-06-25 19:57:05.624423
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert len(poland_spec_provider_0.pesel()) == 11


# Generated at 2022-06-25 19:57:24.640569
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert type(poland_spec_provider_0.pesel()) in [str, int]


# Generated at 2022-06-25 19:57:27.056506
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert poland_spec_provider_0.pesel() == '66032518567'


# Generated at 2022-06-25 19:57:32.968189
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    print("Test method pesel of class PolandSpecProvider")
    start_time = time.time()
    poland_spec_provider_0 = PolandSpecProvider()
    res_0 = poland_spec_provider_0.pesel(birth_date=None,gender=None)
    print(res_0)
    end_time = time.time()
    print("total time: ", end_time - start_time)
    
if __name__== "__main__":
    test_PolandSpecProvider_pesel()

# Generated at 2022-06-25 19:57:34.706693
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    pesel = poland_spec_provider_0.pesel()



# Generated at 2022-06-25 19:57:38.814535
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_1 = PolandSpecProvider()
    poland_spec_provider_1_pesel_expected = poland_spec_provider_1.pesel(
        birth_date=None, gender=None)
    assert poland_spec_provider_1_pesel_expected is not None


# Generated at 2022-06-25 19:57:47.282075
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    for i in range(1000):
        pesel = p.pesel()
        assert len(pesel) == 11
        assert int(pesel[2:4]) < 20
        assert int(pesel[4:6]) <= 12
        assert int(pesel[4:6]) > 0
        assert int(pesel[6:8]) <= 31
        assert int(pesel[6:8]) > 0
        assert int(pesel[9]) < 10


# Generated at 2022-06-25 19:57:50.990833
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    regex_0 = re.compile(r'^\d{11}$')
    poland_spec_provider_0 = PolandSpecProvider()
    pesel_0 = poland_spec_provider_0.pesel()
    assert regex_0.match(pesel_0)


# Generated at 2022-06-25 19:57:53.920519
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    result = poland_spec_provider.pesel(
        birth_date=Datetime().datetime(1940, 2018))
    assert len(result) == 11

# Generated at 2022-06-25 19:57:57.203292
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    pesel = poland_spec_provider_0.pesel(1, 1)
    assert isinstance(pesel, str)
    assert len(pesel) == 11


# Generated at 2022-06-25 19:58:07.347885
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider(seed=5)
    poland_spec_provider_1 = PolandSpecProvider(seed=5)
    poland_spec_provider_2 = PolandSpecProvider(seed=5)
    poland_spec_provider_3 = PolandSpecProvider(seed=5)
    poland_spec_provider_4 = PolandSpecProvider(seed=5)
    poland_spec_provider_5 = PolandSpecProvider(seed=5)
    assert poland_spec_provider_0.pesel(birth_date=Datetime().datetime(1980, 1982)) == '65611666678'