

# Generated at 2022-06-25 19:55:07.986550
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    from datetime import datetime
    poland_spec_provider_1 = PolandSpecProvider()
    pesel_0 = poland_spec_provider_1.pesel(datetime(2004, 12, 4), Gender.FEMALE)
    assert len(pesel_0) == 11
    assert pesel_0[10] == str(3)

# Generated at 2022-06-25 19:55:10.699268
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_1 = PolandSpecProvider()
    str_1 = poland_spec_provider_1.pesel()


# Generated at 2022-06-25 19:55:12.020683
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    datetime_0 = Datetime().datetime()
    str_0 = poland_spec_provider_0.pesel(datetime_0)


# Generated at 2022-06-25 19:55:22.398339
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    datetime_0 = Datetime()
    poland_spec_provider_0 = PolandSpecProvider()
    datetime_1 = datetime_0.datetime()
    str_0 = poland_spec_provider_0.pesel(datetime_1)
    assert len(str_0) == 11, \
        "Failed to generate random pesel, expected length: 11, actual: {}, type: {}\
        ".format(len(str_0), type(str_0))
    str_1 = poland_spec_provider_0.pesel(birth_date=None, gender=None)

# Generated at 2022-06-25 19:55:24.989560
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_1 = PolandSpecProvider()
    str_0 = poland_spec_provider_1.pesel()


# Generated at 2022-06-25 19:55:29.056852
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider(773)
    assert poland_spec_provider_0.pesel(gender=Gender.MALE) == '67010675598'
    assert poland_spec_provider_0.pesel(gender=Gender.FEMALE) == '72020819305'


# Generated at 2022-06-25 19:55:32.548779
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # Setup
    poland_spec_provider = PolandSpecProvider()
    birth_date = '1993-10-05'

    # Exercise
    result = poland_spec_provider.pesel(birth_date)

    # Verify
    expected = '931005'
    assert result == expected


# Generated at 2022-06-25 19:55:35.024978
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    str_0 = poland_spec_provider_0.pesel()
    assert str_0


# Generated at 2022-06-25 19:55:37.827968
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    str_0 = poland_spec_provider.pesel() # TODO: [DK] Ideally would be good to assert this is a string, but how??


# Generated at 2022-06-25 19:55:39.824318
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    str_0 = poland_spec_provider_0.pesel()


# Generated at 2022-06-25 19:55:51.765871
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    pesel_0 = poland_spec_provider_0.pesel()
    print(pesel_0)


# Generated at 2022-06-25 19:55:58.731860
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    import random # pylint: disable=import-outside-toplevel
    poland_spec_provider_0 = PolandSpecProvider()
    assert "pesel" in dir(poland_spec_provider_0)
    assert isinstance(poland_spec_provider_0.pesel(), str)
    assert len(poland_spec_provider_0.pesel()) == 11
    random.seed(12345)
    assert poland_spec_provider_0.pesel(birth_date=Datetime().datetime(2000, 2010)) == "09111612345"
    random.seed(12345)
    assert poland_spec_provider_0.pesel(birth_date=Datetime().datetime(2000, 2010), gender=Gender.MALE) == "09111612345"

# Generated at 2022-06-25 19:56:02.198495
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    pesel = poland_spec_provider_0.pesel(birth_date=None, gender=Gender.FEMALE)
    assert len(pesel) == 11


# Generated at 2022-06-25 19:56:08.321680
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    seed = 641728691
    instance = PolandSpecProvider(seed)
    assert (instance.pesel(gender=Gender.FEMALE) == '60506862465')
    assert (instance.pesel(gender=Gender.MALE) == '42504119106')


# Generated at 2022-06-25 19:56:10.619940
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    assert len(poland_spec_provider.pesel()) == 11


# Generated at 2022-06-25 19:56:12.502794
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    assert len(PolandSpecProvider().pesel()) == 11


# Generated at 2022-06-25 19:56:14.409982
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert len(poland_spec_provider_0.pesel()) == 11

# Generated at 2022-06-25 19:56:22.951947
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert len(poland_spec_provider_0.pesel()) == 11
    assert len(poland_spec_provider_0.pesel(
        birth_date=poland_spec_provider_0.datetime(
            start_year=2007, end_year=2018, use_timezone=False),
        gender=Gender.FEMALE)) == 11
    assert poland_spec_provider_0.pesel().isdigit()


# Generated at 2022-06-25 19:56:29.063680
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    poland_spec_provider_1 = PolandSpecProvider()
    assert all(poland_spec_provider.pesel() == poland_spec_provider_1.pesel()
               for _ in range(100))

# Generated at 2022-06-25 19:56:33.124116
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    assert type(poland_spec_provider_0.pesel()) is str

# Testing class PolandSpecProvider
if __name__ == '__main__':
    poland_spec_provider_0 = PolandSpecProvider()
    test_case_0()
    test_PolandSpecProvider_pesel()

# Generated at 2022-06-25 19:56:43.520973
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert len(poland_spec_provider_0.pesel()) == 11


# Generated at 2022-06-25 19:56:45.594136
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert len(poland_spec_provider_0.pesel()) == 11


# Generated at 2022-06-25 19:56:47.098311
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    for _ in range(10):
        assert len(poland_spec_provider.pesel()) == 11


# Generated at 2022-06-25 19:56:52.531200
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    _pesel_ = ''
    _pesel_ = PolandSpecProvider().pesel(Datetime().datetime(1970, 1970),
                                         Gender.FEMALE)
    assert len(_pesel_) == 11


# Generated at 2022-06-25 19:56:59.071472
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    result = poland_spec_provider.pesel()
    assert type(result) is str
    assert len(result) == 11
    assert int(result[:2]) >= 40 and int(result[:2]) <= 99
    assert int(result[2:4]) >= 0 and int(result[2:4]) <= 12
    assert int(result[4:6]) >= 1 and int(result[4:6]) <= 31
    assert int(result[6:]) >= 0 and int(result[6:]) <= 999


# Generated at 2022-06-25 19:57:05.481689
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert poland_spec_provider_0.pesel(birth_date=Datetime().datetime()) == '54112306745'
    assert poland_spec_provider_0.pesel(birth_date=Datetime().datetime(),
        gender=Gender.MALE) == '61072791650'
    assert poland_spec_provider_0.pesel(birth_date=Datetime().datetime(),
        gender=Gender.FEMALE) == '63033112038'


# Generated at 2022-06-25 19:57:08.644844
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    pesel_string_0 = poland_spec_provider.pesel()
    assert len(pesel_string_0) == 11


# Generated at 2022-06-25 19:57:10.365823
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    ## Unit test for method pesel of class PolandSpecProvider
    assert False is False



# Generated at 2022-06-25 19:57:13.927467
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel(birth_date=Datetime().datetime(2019, 1, 1), gender=Gender.MALE)
    assert isinstance(pesel, str)
    assert len(pesel) == 11


# Generated at 2022-06-25 19:57:16.279872
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert type(poland_spec_provider_0.pesel()) == str


# Generated at 2022-06-25 19:57:27.901742
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_1 = PolandSpecProvider()
    pesel_result = poland_spec_provider_1.pesel()
    assert valid_pesel(pesel_result)



# Generated at 2022-06-25 19:57:31.918630
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    from datetime import datetime
    poland_spec_provider = PolandSpecProvider()
    pesel_0 = poland_spec_provider.pesel(birth_date = datetime(1993, 1, 2),
                                        gender = Gender.MALE)
    assert len(pesel_0) == 11


# Generated at 2022-06-25 19:57:33.686813
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    poland_spec_provider_0.pesel()


# Generated at 2022-06-25 19:57:36.258006
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test for method pesel of class PolandSpecProvider"""

    poland_spec_provider = PolandSpecProvider()

    assert poland_spec_provider.pesel() == poland_spec_provider.pesel()


# Generated at 2022-06-25 19:57:47.752145
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert poland_spec_provider_0.pesel() == '840112000193'
    assert poland_spec_provider_0.pesel(birth_date=Datetime().datetime(1980, 1, 12), gender=Gender.MALE) == '840112000193'
    assert poland_spec_provider_0.pesel() == '430302704320'
    assert poland_spec_provider_0.pesel(birth_date=Datetime().datetime(2010, 11, 18), gender=Gender.FEMALE) == '420311804302'
    assert poland_spec_provider_0.pesel() == '840424013133'

# Generated at 2022-06-25 19:57:51.162403
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test the method of class PolandSpecProvider pesel."""
    poland_spec_provider_0 = PolandSpecProvider()
    result_bool = isinstance(poland_spec_provider_0.pesel(), str)
    assert result_bool


# Generated at 2022-06-25 19:57:53.708676
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert len(poland_spec_provider_0.pesel()) == 11


# Generated at 2022-06-25 19:57:56.608852
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel_0 = PolandSpecProvider().pesel()
    assert len(pesel_0) == 11 # Check length of PESEL
    assert type(pesel_0) == str # Check return type of PESEL


# Generated at 2022-06-25 19:57:59.076903
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    assert(len(poland_spec_provider.pesel()) == 11)


# Generated at 2022-06-25 19:58:07.109587
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    # Test case 0
    assert poland_spec_provider_0.pesel() == '98110312345'
    # Test case 1
    assert poland_spec_provider_0.pesel(None, Gender.MALE) == '68112912345'
    # Test case 2
    assert poland_spec_provider_0.pesel(None, Gender.FEMALE) == '75112412345'
    # Test case 3
    assert poland_spec_provider_0.pesel(None) == '62110312345'

# Generated at 2022-06-25 19:59:44.718141
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    pesel = poland_spec_provider.pesel(None,Gender.FEMALE)
    assert len(pesel) == 11
    assert pesel.isdigit() == True
    assert pesel.startswith('1') == True


# Generated at 2022-06-25 19:59:47.397210
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_1 = PolandSpecProvider()
    assert len(poland_spec_provider_1.pesel()) == 11


# Generated at 2022-06-25 19:59:49.952169
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    gr = Gender.M
    poland_spec_provider_0 = PolandSpecProvider()
    assert len(poland_spec_provider_0.pesel(gr)) == 11

# Test case for method pesel of class PolandSpecProvider

# Generated at 2022-06-25 19:59:51.376488
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    poland_spec_provider_0.pesel()


# Generated at 2022-06-25 19:59:55.367121
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    PESEL = PolandSpecProvider().pesel()
    assert len(PESEL) == 11
    assert PESEL.isdigit()


# Generated at 2022-06-25 19:59:59.097236
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    poland_spec_provider_1 = PolandSpecProvider()
    return poland_spec_provider_0.pesel() == poland_spec_provider_1.pesel()


# Generated at 2022-06-25 20:00:10.612641
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    # This is the only seed that produces valid PESELs
    poland_spec_provider.seed(0)
    assert poland_spec_provider.pesel(
        gender=Gender.MALE,
        birth_date=Datetime().datetime(2018, 1, 1, 0, 0, 0)) == '18010100200'
    assert poland_spec_provider.pesel(
        gender=Gender.MALE,
        birth_date=Datetime().datetime(2018, 2, 1, 0, 0, 0)) == '18020100100'

# Generated at 2022-06-25 20:00:14.071638
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    gender = poland_spec_provider_0.random.choice([Gender.MALE, Gender.FEMALE])
    birth_date = poland_spec_provider_0.random.date(1940, 2018, cls=DateTime)
    pesel_ = poland_spec_provider_0.pesel(birth_date, gender)
    assert isinstance(pesel_, str)


# Generated at 2022-06-25 20:00:17.943125
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isnumeric()
    assert provider.validate_pesel(pesel) == True


# Generated at 2022-06-25 20:00:19.623114
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    assert len(poland_spec_provider.pesel())==11

