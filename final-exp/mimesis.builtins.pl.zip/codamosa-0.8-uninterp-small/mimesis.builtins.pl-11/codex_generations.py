

# Generated at 2022-06-25 19:55:07.806720
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    pesel = poland_spec_provider_0.pesel(birth_date=None, gender='foo')
    print(pesel)
    assert len(pesel) == 11
    assert pesel is not None


# Generated at 2022-06-25 19:55:13.383411
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider(seed=0)
    assert poland_spec_provider_0.pesel() == '5206215039'
    assert poland_spec_provider_0.pesel(gender=Gender.MALE) == '6508179720'
    assert poland_spec_provider_0.pesel(gender=Gender.FEMALE) == '5802150655'


# Generated at 2022-06-25 19:55:18.241529
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    pesel = poland_spec_provider.pesel()
    e = int(pesel[0]) * 1 + int(pesel[1]) * 3 + int(pesel[2]) * 7
    e += int(pesel[3]) * 9 + int(pesel[4]) * 1 + int(pesel[5]) * 3
    e += int(pesel[6]) * 7 + int(pesel[7]) * 9 + int(pesel[8]) * 1
    e += int(pesel[9]) * 3 + int(pesel[10]) * 1
    assert int(pesel[-1]) == e % 10

# Generated at 2022-06-25 19:55:21.337980
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_1 = PolandSpecProvider()
    pesel = poland_spec_provider_1.pesel()
    assert isinstance(pesel, str) == True


# Generated at 2022-06-25 19:55:25.514654
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test for pesel method of class PolandSpecProvider."""
    poland_spec_provider = PolandSpecProvider()
    pesel_0 = poland_spec_provider.pesel()
    assert str(pesel_0).isalnum()
    assert len(str(pesel_0)) == 11


# Generated at 2022-06-25 19:55:27.899725
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert len(poland_spec_provider_0.pesel()) == 11


# Generated at 2022-06-25 19:55:36.954870
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    poland_spec_provider_0.seed(0)
    assert poland_spec_provider_0.pesel() == '90030805099'
    poland_spec_provider_0.seed(0)
    assert poland_spec_provider_0.pesel(gender=Gender.MALE) == '90092122066'
    poland_spec_provider_0.seed(0)
    assert poland_spec_provider_0.pesel(gender=Gender.FEMALE) == '90101014683'
    poland_spec_provider_0.seed(0)
    assert poland_spec_provider_0.pesel(Datetime().datetime(year=1992, month=10, day=1))

# Generated at 2022-06-25 19:55:42.068973
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_1 = PolandSpecProvider()
    assert(len(poland_spec_provider_1.pesel(1959-11-14, Gender.MALE)) == 11)

# Generated at 2022-06-25 19:55:47.327571
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pol_prov = PolandSpecProvider()
    s = pol_prov.pesel()
    assert len(s) == 11
    s = pol_prov.pesel(gender=Gender.FEMALE, birth_date=Datetime().datetime(1900, 1999))
    assert len(s) == 11
    s = pol_prov.pesel(gender=Gender.MALE, birth_date=Datetime().datetime(1900, 1999))
    assert len(s) == 11


# Generated at 2022-06-25 19:55:52.062679
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    poland_birth_date = poland_spec_provider.datetime(start=1940)
    poland_gender = poland_spec_provider.gender()
    poland_pesel = poland_spec_provider.pesel(birth_date=poland_birth_date,gender=poland_gender)
    assert len(poland_pesel) == 11


# Generated at 2022-06-25 19:56:11.229946
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider_0 = PolandSpecProvider()
    assert len(provider_0.pesel()) == 11
    assert provider_0.pesel()[0] in '0123456789'
    assert provider_0.pesel()[1] in '0123456789'
    assert provider_0.pesel()[2] in '0123456789'
    assert provider_0.pesel()[3] in '0123456789'
    assert provider_0.pesel()[4] in '0123456789'
    assert provider_0.pesel()[5] in '0123456789'
    assert provider_0.pesel()[6] in '0123456789'
    assert provider_0.pesel()[7] in '0123456789'

# Generated at 2022-06-25 19:56:18.760460
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0_1 = PolandSpecProvider()
    assert poland_spec_provider_0_1.pesel() == 'NAYXIHWET4'
    poland_spec_provider_0_2 = PolandSpecProvider(seed=PolandSpecProvider.pesel.field_format)
    assert poland_spec_provider_0_2.pesel() == 'YX7VYJGROP'
    poland_spec_provider_0_3 = PolandSpecProvider(seed=PolandSpecProvider.pesel.field_format)
    assert poland_spec_provider_0_3.pesel() == 'WYJYX7VYJG'

# Generated at 2022-06-25 19:56:20.591949
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel_0 = PolandSpecProvider().pesel()
    assert isinstance(pesel_0, str)
    assert len(pesel_0) == 11


# Generated at 2022-06-25 19:56:27.941909
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    poland_spec_provider_0 = PolandSpecProvider(seed=32113)
    poland_spec_provider_1 = PolandSpecProvider(seed=32113)
    poland_spec_provider_2 = PolandSpecProvider(seed=32113)
    assert poland_spec_provider.pesel() is not poland_spec_provider_0.pesel()
    assert poland_spec_provider_0.pesel() == poland_spec_provider_1.pesel()
    assert poland_spec_provider_1.pesel() != poland_spec_provider_2.pesel()
    assert poland_spec_provider_2.pesel() is not poland_spec_provider.pesel()

# Unit test

# Generated at 2022-06-25 19:56:31.287414
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_1 = PolandSpecProvider()
    print(poland_spec_provider_1.pesel())
    assert len(poland_spec_provider_1.pesel()) == 11


# Generated at 2022-06-25 19:56:33.759969
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_1 = PolandSpecProvider()
    assert len(poland_spec_provider_1.pesel()) == 11


# Generated at 2022-06-25 19:56:35.778141
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    result = poland_spec_provider_0.pesel()
    assert len(result) == 11


# Generated at 2022-06-25 19:56:41.777396
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider(seed=0)
    assert len(poland_spec_provider_0.pesel()) == 11
    assert poland_spec_provider_0.pesel(Gender.FEMALE) == '71082405347'



# Generated at 2022-06-25 19:56:47.405648
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    assert len(PolandSpecProvider().pesel()) == 11
    assert PolandSpecProvider().pesel(gender=Gender.MALE)[9] in ['1', '3', '5', '7', '9']
    assert PolandSpecProvider().pesel(gender=Gender.FEMALE)[9] in ['0', '2', '4', '6', '8']
    birth_date = Datetime().datetime(1940, 2018)
    assert PolandSpecProvider().pesel(birth_date=birth_date).startswith(birth_date.strftime('%y'))



# Generated at 2022-06-25 19:56:58.571229
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert poland_spec_provider_0.pesel() == '15010811195'
    assert poland_spec_provider_0.pesel() == '18010314520'
    assert poland_spec_provider_0.pesel() == '17080708059'
    assert poland_spec_provider_0.pesel() == '17050509359'
    assert poland_spec_provider_0.pesel() == '14090415399'
    assert poland_spec_provider_0.pesel() == '19122407345'
    assert poland_spec_provider_0.pesel() == '17061105887'

# Generated at 2022-06-25 19:57:16.555156
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert poland_spec_provider_0.pesel() in ['23009914564', '62052758054', '74060663668', '97101177833', '96022461102', '73022456371', '37123037643', '96100458686', '32111263862', '83101565702'] or poland_spec_provider_0.pesel() in ['23009914564', '62052758054', '74060663668', '97101177833', '96022461102', '73022456371', '37123037643', '96100458686', '32111263862', '83101565702']



# Generated at 2022-06-25 19:57:18.692960
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    str_0 = poland_spec_provider_0.pesel()
    assert str_0 == "76111305988"


# Generated at 2022-06-25 19:57:22.273663
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    pesel_0 = poland_spec_provider_0.pesel()
    assert len(pesel_0) == 11


# Generated at 2022-06-25 19:57:24.676023
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_1 = PolandSpecProvider()
    poland_spec_provider_1.pesel()



# Generated at 2022-06-25 19:57:33.432131
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # Case 0:
    poland_spec_provider_0 = PolandSpecProvider()
    pesel = poland_spec_provider_0.pesel()
    assert (len(pesel) == 11)
    assert (pesel == '17032912651')
    assert (type(pesel) == str)

    # Case 1:
    poland_spec_provider_1 = PolandSpecProvider('1234')
    pesel = poland_spec_provider_1.pesel()
    assert (len(pesel) == 11)
    assert (pesel == '72042598204')
    assert (type(pesel) == str)

    # Case 2:
    poland_spec_provider_2 = PolandSpecProvider()

# Generated at 2022-06-25 19:57:35.472536
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert len(str(poland_spec_provider_0.pesel())) == 11


# Generated at 2022-06-25 19:57:37.320975
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert isinstance(poland_spec_provider_0.pesel(), str)


# Generated at 2022-06-25 19:57:38.739932
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    assert poland_spec_provider_0.pesel(None, None) == '95122975245'


# Generated at 2022-06-25 19:57:40.582141
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    expected = '20020495080'
    date = datetime.datetime(2002, 4, 9)
    assert PolandSpecProvider().pesel(date, Gender.MALE) == expected


# Generated at 2022-06-25 19:57:50.138146
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    birth_date = poland_spec_provider_0.datetime.date().replace
    assert len(poland_spec_provider_0.pesel(birth_date)) == 11, \
        "AssertionError: False is not true"
    assert len(poland_spec_provider_0.pesel(birth_date, Gender.FEMALE)) == 11, \
        "AssertionError: False is not true"
    assert len(poland_spec_provider_0.pesel(birth_date, Gender.MALE)) == 11, \
        "AssertionError: False is not true"


# Generated at 2022-06-25 19:58:11.689048
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    pesel = poland_spec_provider.pesel()
    assert len(pesel) == 11
    if int(pesel[2]) % 2 == 1:
        assert int(pesel[9]) % 2 == 1
    else:
        assert int(pesel[9]) % 2 == 0


# Generated at 2022-06-25 19:58:14.925231
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    seed_arg: Seed = None
    poland_spec_provider_0 = PolandSpecProvider(seed=seed_arg)

    # Call method:
    method_result_0 = poland_spec_provider_0.pesel()


# Generated at 2022-06-25 19:58:18.537548
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    # Pass
    assert poland_spec_provider_0.pesel(birth_date=None, gender=None) != None


# Generated at 2022-06-25 19:58:22.329247
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    print('Testing pid method of class PolandSpecProvider:')
    poland_spec_provider = PolandSpecProvider()
    for i in range(10):
        print(poland_spec_provider.pesel())


# Generated at 2022-06-25 19:58:24.004894
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    pesel_0 = poland_spec_provider.pesel()


# Generated at 2022-06-25 19:58:30.358708
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    poland_spec_provider_0_pesel = poland_spec_provider_0.pesel(
        birth_date=(1940, 2018), gender=Gender.MALE)
    assert poland_spec_provider_0_pesel is not None
    assert type(poland_spec_provider_0_pesel) is str


# Generated at 2022-06-25 19:58:38.757652
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    print(poland_spec_provider.pesel(birth_date=Datetime().datetime(1900, 1, 1), gender=Gender.MALE))
    print(poland_spec_provider.pesel(birth_date=Datetime().datetime(1900, 1, 1), gender=Gender.FEMALE))
    print(poland_spec_provider.pesel(birth_date=Datetime().datetime(1901, 1, 1), gender=Gender.MALE))
    print(poland_spec_provider.pesel(birth_date=Datetime().datetime(1901, 1, 1), gender=Gender.FEMALE))

# Generated at 2022-06-25 19:58:45.313154
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    poland_spec_provider_1 = PolandSpecProvider()
    poland_spec_provider_2 = PolandSpecProvider()
    poland_spec_provider_3 = PolandSpecProvider()
    poland_spec_provider_4 = PolandSpecProvider()
    poland_spec_provider_5 = PolandSpecProvider()

    # Default
    #pesel_0 = poland_spec_provider_0.pesel()
    pesel_0 = poland_spec_provider_0.pesel(birth_date=poland_spec_provider_0.datetime(1940, 2018),
                                                 gender=poland_spec_provider_0.gender())

    pesel_1 = poland_spec_provider_1.pesel

# Generated at 2022-06-25 19:58:54.975206
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_1 = PolandSpecProvider()
    poland_spec_provider_1.pesel()
    poland_spec_provider_1.pesel(birth_date=None, gender=None)
    poland_spec_provider_1.pesel(birth_date=poland_spec_provider_1.datetime(1940, 2018), gender='male')
    poland_spec_provider_1.pesel(birth_date=poland_spec_provider_1.datetime(1940, 2018), gender='female')
    poland_spec_provider_1.pesel(birth_date=poland_spec_provider_1.datetime(1940, 2018), gender=poland_spec_provider_1.enums.Gender.FEMALE)
    poland

# Generated at 2022-06-25 19:58:59.236361
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    # Testing the case where gender is not specified

    pesel_0_0 = poland_spec_provider_0.pesel()

    assert len(pesel_0_0) == 11
    assert pesel_0_0.isdigit()
    assert len(str(int(pesel_0_0))) == 10
