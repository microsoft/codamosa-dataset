

# Generated at 2022-06-25 19:54:59.838082
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # Case 1
    assert PolandSpecProvider().pesel() != None


# Generated at 2022-06-25 19:55:05.458460
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    bytearray_0 = None
    poland_spec_provider_0 = PolandSpecProvider(bytearray_0)
    gender_0 = Gender.MALE
    try:
        str_0 = poland_spec_provider_0.pesel(gender=gender_0)
    except NotImplementedError:
        raise NotImplementedError('Method not implemented!')


# Generated at 2022-06-25 19:55:10.073710
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    bytearray_0 = None
    poland_spec_provider_0 = PolandSpecProvider(bytearray_0)
    gender_0 = None
    date_time_0 = None
    str_0 = poland_spec_provider_0.pesel(date_time_0, gender_0)
    assert len(str_0) == 11


# Generated at 2022-06-25 19:55:10.714257
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    assert PolandSpecProvider().pesel() == 0 # Sample output: 0



# Generated at 2022-06-25 19:55:12.057615
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    nip_0 = poland_spec_provider_0.nip()
    assert len(nip_0) == 10, "Unit test for method nip of class " \
        "PolandSpecProvider failed"


# Generated at 2022-06-25 19:55:14.701166
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # Create a PolandSpecProvider object
    poland_spec_provider_0 = PolandSpecProvider()

    # Execute method pesel
    poland_spec_provider_0.pesel()


# Generated at 2022-06-25 19:55:19.695734
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel"""

    # Arrange
    poland_spec_provider_0 = PolandSpecProvider()

    # Act
    actual_result = poland_spec_provider_0.pesel()

    # Assert
    expected_result = str

    assert type(actual_result) == expected_result


# Generated at 2022-06-25 19:55:29.356993
# Unit test for method pesel of class PolandSpecProvider

# Generated at 2022-06-25 19:55:38.020752
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    import datetime
    poland_spec_provider_0 = PolandSpecProvider()
    # Test if the metho pesel of class PolandSpecProvider return a valid 11-digit PESEL.
    assert len(poland_spec_provider_0.pesel()) == 11
    # Test if the metho pesel of class PolandSpecProvider return a valid 11-digit PESEL for men.
    assert poland_spec_provider_0.pesel(gender=Gender.MALE)[10] in ['1', '3', '5', '7', '9']
    # Test if the metho pesel of class PolandSpecProvider return a valid 11-digit PESEL for women.

# Generated at 2022-06-25 19:55:40.289358
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    gender = Gender.FEMALE
    poland_spec_provider_0 = PolandSpecProvider()
    assert isinstance(poland_spec_provider_0.pesel(gender), str)

# Generated at 2022-06-25 19:55:48.100829
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    birth_date = Datetime().datetime(1940, 2018)
    poland_spec_provider_0 = PolandSpecProvider()
    assert len(poland_spec_provider_0.pesel(birth_date, Gender.MALE)) == 11


# Generated at 2022-06-25 19:55:50.312455
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_1 = PolandSpecProvider()
    assert len(poland_spec_provider_1.pesel()) == 11


# Generated at 2022-06-25 19:55:57.006941
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    pesel_0 = poland_spec_provider_0.pesel()
    # Check that result is in correct type
    assert isinstance(pesel_0, str)
    # Check that result is valid PESEL
    assert int(pesel_0[:2]) in range(18, 22)
    assert int(pesel_0[2:4]) in range(1, 13)
    assert int(pesel_0[4:6]) in range(1, 32)
    assert int(pesel_0[6:9]) in range(0, 1000)
    assert int(pesel_0[9]) in range(0, 10)



# Generated at 2022-06-25 19:56:09.112566
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # Test case for non-empty list and empty list
    poland_spec_provider = PolandSpecProvider()

# Generated at 2022-06-25 19:56:10.619122
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    assert PolandSpecProvider().pesel() == '92032844382'

# Generated at 2022-06-25 19:56:18.519998
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel_0 = PolandSpecProvider().pesel(
        DateTime(2014, 6, 13, 20, 41, 48, 955135).datetime(), Gender.NOT_APPLICABLE
    )
    assert pesel_0 == '14061320147'
    pesel_1 = PolandSpecProvider().pesel(
        DateTime(1981, 8, 28, 7, 54, 8, 449767).datetime(), Gender.FEMALE
    )
    assert pesel_1 == '81082820239'
    pesel_2 = PolandSpecProvider().pesel(
        DateTime(1948, 8, 18, 6, 9, 14, 104040).datetime(), Gender.MALE
    )
    assert pesel_2 == '48081303406'

# Generated at 2022-06-25 19:56:21.562669
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    pesel = poland_spec_provider.pesel()
    assert pesel != 'None'


# Generated at 2022-06-25 19:56:24.060481
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider(seed=1949092678)
    assert poland_spec_provider_0.pesel() == "80012209788"



# Generated at 2022-06-25 19:56:32.480995
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    gender_0 = poland_spec_provider_0.Gender.FEMALE
    date_time_0 = poland_spec_provider_0.datetime(2040, 2040)
    pesel_0 = poland_spec_provider_0.pesel(date_time_0, gender_0) # Do something
    assert re.search('^\d{11}$', pesel_0)


# Generated at 2022-06-25 19:56:35.524650
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = '74080502274'
    poland_spec_provider_0 = PolandSpecProvider(seed=4742)
    for i in range(2):
        assert poland_spec_provider_0.pesel() == pesel


# Generated at 2022-06-25 19:56:58.354651
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    peesel_tests = [
        ('1995-09-08', Gender.FEMALE, '09098952477'),
        ('1997-03-29', Gender.MALE, '29097956241')
    ]

    for birth_date, gender, expected in peesel_tests:
        ob_poland_spec_provider = PolandSpecProvider()
        ob_datetime = Datetime()
        ob_datetime.datetime(year=int(birth_date.split('-')[0]),
                             month=int(birth_date.split('-')[1]),
                             day=int(birth_date.split('-')[2]))
        actual = ob_poland_spec_provider.pesel(birth_date=ob_datetime,
                                               gender=gender)

# Generated at 2022-06-25 19:57:01.770743
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test for method pesel of class PolandSpecProvider"""
    poland_spec_provider_0 = PolandSpecProvider()
    v = poland_spec_provider_0.pesel()
    assert isinstance(v, str)
    assert len(v) == 11
    for i in v:
        assert i in '0123456789'


# Generated at 2022-06-25 19:57:04.709517
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    from mimesis.enums import Gender
    poland_spec_provider = PolandSpecProvider()
    assert poland_spec_provider.pesel() == 11


# Generated at 2022-06-25 19:57:10.327596
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert poland_spec_provider_0.pesel() == '24011777731' # test_0
    assert poland_spec_provider_0.pesel() == '26011777731' # test_1
    assert poland_spec_provider_0.pesel() == '27011777731' # test_2


# Generated at 2022-06-25 19:57:12.129642
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    assert PolandSpecProvider().pesel() is not None


# Generated at 2022-06-25 19:57:14.920605
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec = PolandSpecProvider()
    poland_spec_pesel_0 = poland_spec.pesel()
    return poland_spec_pesel_0


# Generated at 2022-06-25 19:57:17.069634
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert poland_spec_provider_0.pesel() == '89092405345'


# Generated at 2022-06-25 19:57:18.113326
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel(): 
    pass 


# Generated at 2022-06-25 19:57:20.956337
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert poland_spec_provider_0.pesel() == '85072675391'


# Generated at 2022-06-25 19:57:24.628199
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_1 = PolandSpecProvider()
    result = poland_spec_provider_1.pesel()
    assert (len(result) == 11)
    assert (result == "88041107914")


# Generated at 2022-06-25 19:57:37.889599
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert len(poland_spec_provider_0.pesel()) == 11


# Generated at 2022-06-25 19:57:42.519772
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    pesel_0 = poland_spec_provider_0.pesel()


# Generated at 2022-06-25 19:57:45.600883
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_1 = PolandSpecProvider()
    # Case 0
    # Expected Value

    assert poland_spec_provider_1.pesel() in '0123456789'


# Generated at 2022-06-25 19:57:47.125422
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    assert PolandSpecProvider().pesel(gender=Gender.FEMALE)


# Generated at 2022-06-25 19:57:50.362489
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # Initialization of variables
    birth_date_0 = DateTime()
    gender_0 = Gender.FEMALE
    # Exercise the method under test
    result_0 = PolandSpecProvider.pesel(birth_date_0, gender_0)


# Generated at 2022-06-25 19:57:53.709474
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    pesel = poland_spec_provider.pesel()
    assert bool(pesel) == True
    assert len(str(pesel)) == 11


# Generated at 2022-06-25 19:57:56.609801
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    str_1 = poland_spec_provider_0.pesel()
    assert str_1.isdigit()
    assert 11 == len(str_1)


# Generated at 2022-06-25 19:57:59.394181
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    pesel = poland_spec_provider.pesel()
    assert type(pesel) == str

# Generated at 2022-06-25 19:58:02.389755
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert len(poland_spec_provider_0.pesel()) == 11


# Generated at 2022-06-25 19:58:05.708826
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    pesel_str_0 = poland_spec_provider_0.pesel()
    assert len(pesel_str_0) == 11


# Generated at 2022-06-25 20:00:39.492372
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert len(poland_spec_provider_0.pesel(birth_date=None, gender=None)) == 11


# Generated at 2022-06-25 20:00:43.713534
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()
    if len(pesel) is 11:
        print("Test case passed: pesel()")
    else:
        print("Test case failed: pesel()")


# Generated at 2022-06-25 20:00:46.045599
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    driver = PolandSpecProvider()
    print("A random PESEL generated by the provider is", driver.pesel())
    return 0


# Generated at 2022-06-25 20:00:49.148365
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    seed = 0
    poland_spec_provider = PolandSpecProvider(seed=seed)
    result = poland_spec_provider.pesel(gender=Gender.FEMALE)
    assert result == '97111923333'
    result = poland_spec_provider.pesel(gender=Gender.MALE)
    assert result == '56050913074'


# Generated at 2022-06-25 20:00:57.974159
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider(seed=12345678)
    assert poland_spec_provider_0.pesel() == '36020904608'
    assert poland_spec_provider_0.pesel() == '44051707137'
    assert poland_spec_provider_0.pesel() == '93110637824'
    assert poland_spec_provider_0.pesel() == '90022846298'
    assert poland_spec_provider_0.pesel() == '67051728957'
    assert poland_spec_provider_0.pesel() == '58120634293'
    assert poland_spec_provider_0.pesel() == '23072214654'

# Generated at 2022-06-25 20:01:00.694357
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    expected = poland_spec_provider.pesel()
    print(expected)
    assert len(expected) == 11
    print("test_PolandSpecProvider_pesel finished")


# Generated at 2022-06-25 20:01:02.645036
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert len(poland_spec_provider_0.pesel()) == 11


# Generated at 2022-06-25 20:01:05.024688
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_1 = PolandSpecProvider()
    pesel = poland_spec_provider_1.pesel(birth_date=None, gender=None)
    assert len(pesel) == 11


# Generated at 2022-06-25 20:01:06.961407
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    result = poland_spec_provider_0.pesel()
    assert len(result) == 11


# Generated at 2022-06-25 20:01:10.726022
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert poland_spec_provider_0.pesel() is not None
