

# Generated at 2022-06-25 19:55:04.229718
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    value = poland_spec_provider.pesel()
    assert isinstance(value, str), 'expected a string type'
    assert len(value) == 11, 'expected string length of 11 for value'
    assert value.isdigit(), 'expected value to contain only digits'


# Generated at 2022-06-25 19:55:06.724191
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    gender_0 = Gender.FEMALE
    birth_date_0 = None
    poland_spec_provider_0 = PolandSpecProvider()
    poland_spec_provider_0_str = poland_spec_provider_0.pesel(birth_date=birth_date_0, gender=gender_0)


# Generated at 2022-06-25 19:55:11.936387
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    from mimesis.datetime import Datetime
    test_datetime = Datetime()
    seed = 1
    for _ in range(100):
        seed += 1
        instance = PolandSpecProvider(seed=seed)
        assert len (instance.pesel(birth_date=test_datetime.datetime(1940, 2018))) == 11, "Length of PESEL number is incorrect"


# Generated at 2022-06-25 19:55:13.728065
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    datetime_0 = Datetime().datetime(1980, 2000)
    assert poland

# Generated at 2022-06-25 19:55:24.217684
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    from mimesis.providers.utils import calculate_checksum
    from mimesis.providers import Datetime
    from mimesis.enums import Gender

    datetime_0 = Datetime('pl')
    poland_spec_provider_0 = PolandSpecProvider(seed=1337)

    year = datetime_0.datetime(2000, 2018).year
    month = datetime_0.datetime(2000, 2018).month
    day = datetime_0.datetime(2000, 2018).day
    pesel_digits = [int(d) for d in str(year)][-2:]

    if 1800 <= year <= 1899:
        month += 80
    elif 2000 <= year <= 2099:
        month += 20
    elif 2100 <= year <= 2199:
        month += 40

# Generated at 2022-06-25 19:55:28.438434
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    datetime_0 = None
    gender_0 = Gender(0)
    str_1 = poland_spec_provider_0.pesel(datetime_0, gender_0)
    assert str_1 == '99011015143'


# Generated at 2022-06-25 19:55:31.208514
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    date_time_0 = None
    gender_0 = None
    str_0 = poland_spec_provider_0.pesel(date_time_0, gender_0)


# Generated at 2022-06-25 19:55:39.751226
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert poland_spec_provider_0.pesel() == '97100427914'
    assert poland_spec_provider_0.pesel() == '53092070899'
    assert poland_spec_provider_0.pesel() == '80120248062'
    assert poland_spec_provider_0.pesel() == '06111972097'
    assert poland_spec_provider_0.pesel() == '76120785584'
    assert poland_spec_provider_0.pesel() == '56090280171'
    assert poland_spec_provider_0.pesel() == '45032935985'

# Generated at 2022-06-25 19:55:44.928815
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    datetime_0 = None
    gender_1 = None
    try:
        str_0 = poland_spec_provider_0.pesel(datetime_0, gender_1)
        str_1 = poland_spec_provider_0.pesel(datetime_0, gender_1)
        assert str_0 != str_1
    except AssertionError:
        raise


# Generated at 2022-06-25 19:55:49.381743
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    datetime_0 = Datetime().datetime(1940, 2018)
    gender_0 = Gender()
    poland_spec_provider_0 = PolandSpecProvider()
    result_0 = poland_spec_provider_0.pesel(datetime_0, gender_0)
    assert str(result_0) == '1803684505'


# Generated at 2022-06-25 19:55:57.121113
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    poland_spec_provider_0.seed(24)
    assert len(poland_spec_provider_0.pesel()) == 11


# Generated at 2022-06-25 19:56:00.776100
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # poland_spec_provider_1 = PolandSpecProvider()
    # assert poland_spec_provider_0.pesel() == poland_spec_provider_0.pesel()
    return True

# test_case_0()

# Generated at 2022-06-25 19:56:12.060130
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()

# Generated at 2022-06-25 19:56:15.486338
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    pesel_1 = poland_spec_provider_0.pesel()
    assert(len(pesel_1) == 11)
    assert(type(pesel_1) == str)


# Generated at 2022-06-25 19:56:19.632271
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    class_0 = PolandSpecProvider()
    func_0 = class_0.pesel()
    assert (len(func_0) == 11 and func_0[0] in '123456789')



# Generated at 2022-06-25 19:56:24.380561
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider('6')
    assert poland_spec_provider.pesel(gender='FEMALE') == '95100532301'
    assert poland_spec_provider.pesel(gender='MALE') == '52060544493'
    assert len(poland_spec_provider.pesel()) == 11


# Generated at 2022-06-25 19:56:34.164430
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    res = poland_spec_provider_0.pesel()
    assert res == '64011702039' or \
        res == '71022603057' or \
        res == '75073207024' or \
        res == '42080607072' or \
        res == '81061301038' or \
        res == '69030807044' or \
        res == '83060702027' or \
        res == '65062702061' or \
        res == '55051507045' or \
        res == '87012201050'


# Generated at 2022-06-25 19:56:43.549712
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # Test 1
    # Test of full functionality
    poland_spec_provider_0 = PolandSpecProvider()
    pesel_0 = poland_spec_provider_0.pesel()
    print("pesel_0 is:", pesel_0)
    # Test 2
    # Test with the birth date as argument and gender as argument
    poland_spec_provider_1 = PolandSpecProvider()
    pesel_1 = poland_spec_provider_1.pesel(Datetime().datetime(), Gender.MALE)
    print("pesel_1 is:", pesel_1)
    # Test 3
    # Test with the birth date as argument and with gender as argument
    poland_spec_provider_2 = PolandSpecProvider()
    pesel_2 = poland_spec_provider_2.pes

# Generated at 2022-06-25 19:56:45.922560
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    str_0 = poland_spec_provider_0.pesel()
    assert len(str_0) == 11


# Generated at 2022-06-25 19:56:50.786721
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    assert len(poland_spec_provider.pesel()) == 11


# Generated at 2022-06-25 19:56:57.355996
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert poland_spec_provider_0.pesel(gender=poland_spec_provider_0.random.choice(list(Gender)))

# Generated at 2022-06-25 19:56:59.464644
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert len(str(poland_spec_provider_0.pesel())) == 11


# Generated at 2022-06-25 19:57:02.690357
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_1 = PolandSpecProvider()
    birthday_datetime = poland_spec_provider_1.datetime(start=1940, stop=2018)
    pesel_0 = poland_spec_provider_1.pesel(birthday_datetime)
    assert isinstance(pesel_0, str)


# Generated at 2022-06-25 19:57:09.290475
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider(seed=5)
    poland_spec_provider_1 = PolandSpecProvider(seed=5)
    assert poland_spec_provider_0.pesel(birth_date=poland_spec_provider_1.datetime(end=(1992, 5, 18, 22, 8, 5)), gender=Gender.FEMALE) == '92051850888', 'Assertion Error'


# Generated at 2022-06-25 19:57:13.550711
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():

    poland_spec_provider = PolandSpecProvider()
    pesel = poland_spec_provider.pesel()
    assert pesel is not None
    assert isinstance(pesel, str)
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-25 19:57:17.144311
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # Initialize a PolandSpecProvider
    poland_spec_provider_0 = PolandSpecProvider(seed=28475)
    str_0 = poland_spec_provider_0.pesel(birth_date=20180213)
    assert str_0 == "38021414223"



# Generated at 2022-06-25 19:57:20.902551
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    if poland_spec_provider_0.pesel() == '86051118379':
        assert True
    else:
        assert False


# Generated at 2022-06-25 19:57:30.546198
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_1 = PolandSpecProvider()

# Generated at 2022-06-25 19:57:33.115926
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert poland_spec_provider_0.pesel(birth_date=None, gender=None) is not None


# Generated at 2022-06-25 19:57:34.218317
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pl = PolandSpecProvider()
    assert pl.pesel()


# Generated at 2022-06-25 19:59:08.671558
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    assert PolandSpecProvider().pesel() != PolandSpecProvider().pesel()



# Generated at 2022-06-25 19:59:11.090533
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    birthday = poland_spec_provider.datetime(1940, 2018)
    poland_spec_provider.pesel(birthday)

# Generated at 2022-06-25 19:59:20.667292
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    pesel = poland_spec_provider.pesel()
    assert isinstance(pesel,str)
    assert len(pesel) == 11
    assert (pesel == '73500906720') or (pesel == '76602511811') or (pesel == '55030140060') or (pesel == '44030112070') or (pesel == '68112506070')
    assert poland_spec_provider.pesel() == '69012301510' or poland_spec_provider.pesel() == '75050215240' or poland_spec_provider.pesel() == '54033013050' or poland_spec_provider.pesel() == '64072905280' or poland_spec_prov

# Generated at 2022-06-25 19:59:22.447986
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_1 = PolandSpecProvider()
    assert len(poland_spec_provider_1.pesel()) == 11

# Generated at 2022-06-25 19:59:25.876862
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    assert len(poland_spec_provider.pesel()) == 11
    assert len(poland_spec_provider.pesel(None, Gender.MALE)) == 11
    assert len(poland_spec_provider.pesel(None, Gender.FEMALE)) == 11


# Generated at 2022-06-25 19:59:28.822769
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_1 = PolandSpecProvider(seed='123')
    pesel = poland_spec_provider_1.pesel()
    assert isinstance(pesel, str)
    assert len(pesel) == 11


# Generated at 2022-06-25 19:59:31.792131
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert poland_spec_provider_0.pesel() == '16020250815'


# Generated at 2022-06-25 19:59:39.013819
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # Creating an object of class PolandSpecProvider
    poland_spec_provider_1 = PolandSpecProvider()
    # Calling the method pesel of the object
    result = poland_spec_provider_1.pesel(Gender.MALE)
    assert isinstance(result, str)
    result = poland_spec_provider_1.pesel(Gender.FEMALE)
    assert isinstance(result, str)
    result = poland_spec_provider_1.pesel()
    assert isinstance(result, str)


# Generated at 2022-06-25 19:59:42.955362
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    import datetime
    assert PolandSpecProvider().pesel(birth_date = datetime.datetime(year = 1993, month = 12, day = 1), gender = Gender.MALE) == '93120105306'


# Generated at 2022-06-25 19:59:47.490595
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    PESEL = '44051401358'
    poland_spec_provider_0 = PolandSpecProvider()
    assert poland_spec_provider_0.pesel(Datetime(seed=440514).datetime(), Gender.MALE) == PESEL
