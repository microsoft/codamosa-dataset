

# Generated at 2022-06-25 19:55:10.665141
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():

    poland_spec_provider_0 = PolandSpecProvider()
    assert poland_spec_provider_0.pesel() == '94120341451'
    assert poland_spec_provider_0.pesel() == '89080814862'
    assert poland_spec_provider_0.pesel() == '89031737105'
    assert poland_spec_provider_0.pesel() == '89040444463'
    poland_spec_provider_1 = PolandSpecProvider(seed=15)
    assert poland_spec_provider_1.pesel() == '80051613243'
    poland_spec_provider_1 = PolandSpecProvider(seed=87)

# Generated at 2022-06-25 19:55:14.762593
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    poland_spec_provider_0.seed(0)
    assert poland_spec_provider_0.pesel() == '68060421478'


if __name__ == '__main__':
    test_case_0()
    test_PolandSpecProvider_pesel()

# Generated at 2022-06-25 19:55:19.002137
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    poland_spec_provider_0.gender = Gender.MALE
    pesel_0 = poland_spec_provider_0.pesel()
    assert (True) or (False)


# Generated at 2022-06-25 19:55:20.455495
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    assert len(PolandSpecProvider().pesel()) == 11


# Generated at 2022-06-25 19:55:23.968543
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert len(poland_spec_provider_0.pesel()) == 11
    assert len(poland_spec_provider_0.pesel()) == 11



# Generated at 2022-06-25 19:55:31.366521
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test for pesel of PolandSpecProvider"""
    poland_spec_provider_0 = PolandSpecProvider(seed=0)
    assert poland_spec_provider_0.pesel() == '83022807515'
    assert poland_spec_provider_0.pesel(gender=Gender.MALE) == '92040403066'
    assert poland_spec_provider_0.pesel(gender=Gender.FEMALE) == '09042405965'
    poland_spec_provider_1 = PolandSpecProvider(seed=1)
    assert poland_spec_provider_1.pesel() == '53011104243'


# Generated at 2022-06-25 19:55:33.984642
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert len(poland_spec_provider_0.pesel(gender=Gender.FEMALE)) == 11


# Generated at 2022-06-25 19:55:35.392447
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    tnr = PolandSpecProvider()
    tnr.pesel()


# Generated at 2022-06-25 19:55:36.895030
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # Test for method 'pesel'
    PolandSpecProvider.pesel()



# Generated at 2022-06-25 19:55:40.430429
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    gender = Gender.MALE
    birth_date = Datetime().datetime(1940, 2018)
    pesel = poland_spec_provider_0.pesel(birth_date, gender)
    assert len(pesel) == 11


# Generated at 2022-06-25 19:56:07.784542
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert len(poland_spec_provider_0.pesel(gender=Gender.MALE)) == 11
    assert len(poland_spec_provider_0.pesel(gender=Gender.FEMALE)) == 11
    assert len(poland_spec_provider_0.pesel()) == 11
    assert len(poland_spec_provider_0.pesel(gender=Gender.FEMALE)) == 11
    assert len(poland_spec_provider_0.pesel(gender=Gender.MALE)) == 11


# Generated at 2022-06-25 19:56:15.457183
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    expected_pesel_formats = ["[0-9]{11}", "[0-9]{11}", "[0-9]{11}", "[0-9]{11}", "[0-9]{11}", "[0-9]{11}", "[0-9]{11}", "[0-9]{11}", "[0-9]{11}", "[0-9]{11}"]
    for expected_pesel in expected_pesel_formats:
        assert re.search(expected_pesel, provider.pesel())


# Generated at 2022-06-25 19:56:20.604288
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    gender = Gender.MALE
    pesel_0 = poland_spec_provider_0.pesel(gender=gender)
    assert len(pesel_0) == 11


# Generated at 2022-06-25 19:56:23.822950
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    assert poland_spec_provider.pesel(datetime("2018-05-22 04:05:31.423911"), Gender.MALE) == "180522010"

# Generated at 2022-06-25 19:56:29.259121
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    expected = '99071702384'
    actual = poland_spec_provider.pesel()
    assert actual in expected
    assert isinstance(actual, str)


# Generated at 2022-06-25 19:56:37.578621
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert len(poland_spec_provider_0.pesel()) <= 11
    assert len(poland_spec_provider_0.pesel(birth_date=None)) <= 11
    assert len(poland_spec_provider_0.pesel(birth_date=None, gender=None)) <= 11
    assert len(poland_spec_provider_0.pesel(birth_date=None, gender=Gender.MALE)) <= 11
    assert len(poland_spec_provider_0.pesel(birth_date=None, gender=Gender.FEMALE)) <= 11


# Generated at 2022-06-25 19:56:42.218566
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    assert '11111111111' == PolandSpecProvider().pesel(
            birth_date=Datetime().datetime(1900, 1900))
    assert '11111111111' == PolandSpecProvider().pesel(
            birth_date=Datetime().datetime(1999, 1999))


# Generated at 2022-06-25 19:56:44.461915
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert len(poland_spec_provider_0.pesel()) == 11


# Generated at 2022-06-25 19:56:46.749890
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert poland_spec_provider_0.pesel(gender=Gender.FEMALE) == '06061195605'


# Generated at 2022-06-25 19:56:52.344856
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    for i in range(100):
        sut = PolandSpecProvider()
        string = sut.pesel()
        assert (len(string) == 11 and string.isdigit()), "Invalid pesel. %s" % string


# Generated at 2022-06-25 19:59:22.460831
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert isinstance(poland_spec_provider_0.pesel(Gender.FEMALE), str)


# Generated at 2022-06-25 19:59:27.109479
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_3 = PolandSpecProvider(seed=1)
    poland_spec_provider_4 = PolandSpecProvider(seed=2)
    poland_spec_provider_5 = PolandSpecProvider(seed=3)
    assert poland_spec_provider_3.pesel() == '92010159345'
    assert poland_spec_provider_4.pesel() == '85090264444'
    assert poland_spec_provider_5.pesel() == '82091841471'


# Generated at 2022-06-25 19:59:29.032522
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    assert poland_spec_provider_0.pesel(birth_date=None,
                                        gender=None) == '84012736861'


# Generated at 2022-06-25 19:59:38.498711
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    poland_spec_provider_1 = PolandSpecProvider(seed=4)
    poland_spec_provider_2 = PolandSpecProvider(seed=4)

    assert len(poland_spec_provider_0.pesel()) == 11
    assert poland_spec_provider_0.pesel(gender=Gender.MALE)[9] in (1, 3, 5, 7, 9)
    assert poland_spec_provider_0.pesel(gender=Gender.FEMALE)[9] in (0, 2, 4, 6, 8)
    assert poland_spec_provider_1.pesel(birth_date=Datetime().datetime(1940, 2018)) == '54052300700'
    assert poland_spec_provider