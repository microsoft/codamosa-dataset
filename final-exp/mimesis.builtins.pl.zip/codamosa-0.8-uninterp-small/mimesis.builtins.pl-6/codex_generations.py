

# Generated at 2022-06-25 19:55:06.930435
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    poland_spec_provider_0.seed(int(0))
    assert poland_spec_provider_0.pesel() == '92122703316'


# Generated at 2022-06-25 19:55:08.910466
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    polandSpecProvider = PolandSpecProvider()
    pesel = polandSpecProvider.pesel()
    assert len(pesel) == 11



# Generated at 2022-06-25 19:55:11.688805
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert len(poland_spec_provider_0.pesel()) == 11


# Generated at 2022-06-25 19:55:14.173953
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert len(poland_spec_provider_0.pesel()) == 11


# Generated at 2022-06-25 19:55:16.008613
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    assert len(poland_spec_provider.pesel()) == 11


# Generated at 2022-06-25 19:55:19.147563
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert len(poland_spec_provider_0.pesel()) == 11


# Generated at 2022-06-25 19:55:28.902985
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    assert len(poland_spec_provider._PolandSpecProvider__pesel(datetime.datetime(1900, 1, 1, 0, 0), mimesis.enums.Gender.FEMALE)) == 11
    assert poland_spec_provider._PolandSpecProvider__pesel(datetime.datetime(2000, 1, 1, 0, 0), mimesis.enums.Gender.MALE) == '19000101000000'
    assert type(poland_spec_provider._PolandSpecProvider__pesel(datetime.datetime(2000, 1, 1, 0, 0), mimesis.enums.Gender.MALE)) == str

# Generated at 2022-06-25 19:55:31.826440
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """ Test pesel method from PolandSpecProvider."""
    poland_spec_provider_0 = PolandSpecProvider()
    assert len(str(poland_spec_provider_0.pesel())) == 11


# Generated at 2022-06-25 19:55:35.551845
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    temp = poland_spec_provider.pesel(birth_date=Datetime().datetime(1980, 2010), gender=Gender.MALE)
    if len(temp) != 11:
        return False
    return True

# Generated at 2022-06-25 19:55:39.823636
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    gender_0 = Gender.MALE
    birth_date_0 = '1985-05-27T20:47:21.801836'
    assert poland_spec_provider_0.pesel(birth_date = birth_date_0, gender = gender_0) == '85052780198'


# Generated at 2022-06-25 19:55:52.698507
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert len(poland_spec_provider_0.pesel()) == 11
    assert len(poland_spec_provider_0.pesel(gender=Gender.MALE)) == 11
    assert len(poland_spec_provider_0.pesel(gender=Gender.FEMALE)) == 11


# Generated at 2022-06-25 19:56:01.426267
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    random_locale = ['pl']
    local_provider_0 = PolandSpecProvider(random_locale[0])
    testcase_date_0 = date(year=1940, month=1, day=1)
    testcase_date_1 = date(year=2018, month=12, day=31)
    testcase_date_2 = date(year=1900, month=1, day=1)
    testcase_date_3 = date(year=2099, month=12, day=31)
    testcase_date_4 = date(year=2100, month=1, day=1)
    testcase_date_5 = date(year=2199, month=12, day=31)
    testcase_date_6 = date(year=2200, month=1, day=1)
    testcase_

# Generated at 2022-06-25 19:56:04.338815
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    inst = PolandSpecProvider()
    assert inst.pesel() != inst.pesel()

# Generated at 2022-06-25 19:56:08.624320
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    pesel_0 = poland_spec_provider_0.pesel()
    assert (len(pesel_0) == 11 and isinstance(pesel_0, str))


# Generated at 2022-06-25 19:56:12.924292
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert poland_spec_provider_0.pesel() == '42315301347'
    assert poland_spec_provider_0.pesel() == '76975521623'



# Generated at 2022-06-25 19:56:15.420197
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_1 = PolandSpecProvider()
    pesel_0 = poland_spec_provider_1.pesel()

    assert (len(pesel_0) == 11)


# Generated at 2022-06-25 19:56:19.632301
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    result = poland_spec_provider_0.pesel()
    assert isinstance(result, str)


# Generated at 2022-06-25 19:56:24.938127
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    assert len(poland_spec_provider.pesel()) == 11
    assert len(poland_spec_provider.pesel(gender=Gender.MALE)) == 11
    assert len(poland_spec_provider.pesel(gender=Gender.FEMALE)) == 11
    print("Unit test method pesel of class PolandSpecProvider successful.")


# Generated at 2022-06-25 19:56:28.165175
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel(birth_date=None, gender=None)
    assert isinstance(pesel, str)


# Generated at 2022-06-25 19:56:33.043869
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    birth_date = DateTime(2019, 8, 5, 9, 46, 47, 814000)
    gender = Gender.FEMALE
    expected = '69080530225'

    poland_spec_provider = PolandSpecProvider()
    actual = poland_spec_provider.pesel(birth_date, gender)

    assert actual == expected



# Generated at 2022-06-25 19:57:16.577647
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # Checks if pesel method return good format
    assert PolandSpecProvider().pesel().isdigit()
    # Checks if every value of pesel is between 0 - 9 
    assert all(0 <= int(char) <= 9 for char in PolandSpecProvider().pesel())
    # Checks if pesel is 11 digits long
    assert len(PolandSpecProvider().pesel()) == 11


# Generated at 2022-06-25 19:57:18.472652
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    result = poland_spec_provider.pesel()
    assert len(str(result)) == 11


# Generated at 2022-06-25 19:57:22.736946
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel_documented = '92010107906'
    poland_spec_provider_0 = PolandSpecProvider()
    pesel_eval = poland_spec_provider_0.pesel()
    assert pesel_eval == pesel_documented


# Generated at 2022-06-25 19:57:28.888124
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    args_0_gender = Gender.FEMALE
    args_0_birth_date = Datetime().datetime(1940, 2018)
    kwargs_1 = {'birth_date': args_0_birth_date, 'gender': args_0_gender}
    value_0 = poland_spec_provider_0.pesel(**kwargs_1)
    assert (value_0 == '24031290672')


# Generated at 2022-06-25 19:57:32.592846
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    pesel_generator = [poland_spec_provider.pesel() for _ in range(100)]
    assert len(pesel_generator) == 100
    assert len(pesel_generator[0]) == 11


# Generated at 2022-06-25 19:57:35.556399
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    assert len(PolandSpecProvider().pesel(Gender.FEMALE)) == 11, "Length of pesel should be 11"
    assert len(PolandSpecProvider().pesel(Gender.MALE)) == 11, "Length of pesel should be 11"


# Generated at 2022-06-25 19:57:37.693539
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert len(poland_spec_provider_0.pesel(BirthDate=None,Gender=None)) == 11


# Generated at 2022-06-25 19:57:42.645589
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()

    # Test with gender as a parameter
    pesel = poland_spec_provider.pesel(gender=Gender.MALE)
    assert len(pesel) == 11
    assert pesel[-1] in "13579"
    pesel = poland_spec_provider.pesel(gender=Gender.FEMALE)
    assert len(pesel) == 11
    assert pesel[-1] in "02468"

    # Test without gender as a parameter
    pesel = poland_spec_provider.pesel()
    assert len(pesel) == 11
    assert pesel[-1] in "0246813579"



# Generated at 2022-06-25 19:57:51.757965
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # Get instance for class PolandSpecProvider
    poland_spec_provider_1 = PolandSpecProvider()
    # Call method pesel of class PolandSpecProvider with the arguments
    assert poland_spec_provider_1.pesel() == '63010407957'
    # Call method pesel of class PolandSpecProvider with the arguments
    assert poland_spec_provider_1.pesel(birth_date=datetime.datetime(2008, 10, 10, 1, 1)) == '08110104202'
    # Call method pesel of class PolandSpecProvider with the arguments
    assert poland_spec_provider_1.pesel(birth_date=datetime.datetime(1943, 3, 23, 1, 1)) == '43030942131'
    # Call method pesel of class PolandSpecProvider with the arguments
   

# Generated at 2022-06-25 19:57:57.148810
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    pesel = poland_spec_provider_0.pesel(birth_date=None, gender=None)
    if len(pesel) != 11:
        raise AssertionError()
    if len(pesel) != 11:
        raise AssertionError()
    if len(pesel) != 11:
        raise AssertionError()