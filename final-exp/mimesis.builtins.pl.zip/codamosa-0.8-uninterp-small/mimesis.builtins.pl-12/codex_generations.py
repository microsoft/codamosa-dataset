

# Generated at 2022-06-25 19:55:03.415015
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    # []
    str_0 = poland_spec_provider_0.pesel()
    assert str_0 is not None
    # [None]
    str_1 = poland_spec_provider_0.pesel(None)
    assert str_1 is not None


# Generated at 2022-06-25 19:55:04.637856
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()
    assert len(pesel) == 11

# Generated at 2022-06-25 19:55:07.082461
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_1 = PolandSpecProvider()
    regex = r'\d{11}'
    assert re.match(regex, poland_spec_provider_1.pesel())


# Generated at 2022-06-25 19:55:10.120139
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    try:
        import datetime
        poland_spec_provider = PolandSpecProvider()
        assert len(poland_spec_provider.pesel()) == 11
    except ImportError:
        pass


# Generated at 2022-06-25 19:55:13.148284
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    print(poland_spec_provider_0.pesel())

if __name__ == '__main__':
    test_PolandSpecProvider_pesel()

# Generated at 2022-06-25 19:55:16.742415
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel(
        Datetime().datetime(1993, 1, 1),
        Gender.MALE,
    )
    assert type(pesel) == str
    assert len(pesel) == 11
    assert pesel == "93010112758"


# Generated at 2022-06-25 19:55:19.432159
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    assert len(poland_spec_provider.pesel()) == 11


# Generated at 2022-06-25 19:55:29.179897
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider(seed=42)
    result = poland_spec_provider_0.pesel(birth_date=None)
    expected = '53092701951'
    assert result == expected
    result = poland_spec_provider_0.pesel(birth_date=None)
    expected = '45082801342'
    assert result == expected
    result = poland_spec_provider_0.pesel(birth_date=None)
    expected = '51123005044'
    assert result == expected
    result = poland_spec_provider_0.pesel(birth_date=None)
    expected = '74122907941'
    assert result == expected

# Generated at 2022-06-25 19:55:32.049991
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    print(poland_spec_provider_0.pesel())
    assert len(poland_spec_provider_0.pesel()) == 11


# Generated at 2022-06-25 19:55:35.148803
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_1 = PolandSpecProvider()
    pesel = poland_spec_provider_1.pesel()
    assert len(pesel) == 11
    assert type(pesel) == str


# Generated at 2022-06-25 19:55:47.834963
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()
    assert pesel is not None


# Generated at 2022-06-25 19:55:52.256116
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    pesel = poland_spec_provider_0.pesel(birth_date = Datetime().datetime(2000, 1, 1), gender = Gender.MALE)
    assert len(pesel) == 11
    assert pesel[0] == '0'
    assert pesel[1] == '2'


# Generated at 2022-06-25 19:55:54.668686
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    str_pesel = poland_spec_provider_0.pesel(birth_date=None, gender=Gender.FEMALE)
    assert str_pesel == str('03709013171')


# Generated at 2022-06-25 19:55:56.855086
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert len(poland_spec_provider_0.pesel()) == 11


# Generated at 2022-06-25 19:55:58.774393
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    assert PolandSpecProvider().pesel(birth_date=None, gender=None)


# Generated at 2022-06-25 19:56:10.739549
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()

    # Test 0
    assert isinstance(PolandSpecProvider.pesel(poland_spec_provider_0), str)
    assert poland_spec_provider_0.pesel(BirthDate=DateTime("1976-04-08T07:31:02"), Gender=Gender.MALE) == "76041557130"
    assert poland_spec_provider_0.pesel(Gender=Gender.FEMALE) == "45112300836"
    assert poland_spec_provider_0.pesel(Gender=Gender.FEMALE) == "45112300836"
    assert poland_spec_provider_0.pesel() == "59091464748"

# Generated at 2022-06-25 19:56:13.635184
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert len(poland_spec_provider_0.pesel()) == 11


# Generated at 2022-06-25 19:56:15.756238
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert len(poland_spec_provider_0.pesel()) == 11


# Generated at 2022-06-25 19:56:19.423728
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert len(poland_spec_provider_0.pesel()) == 11


# Generated at 2022-06-25 19:56:22.143147
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert poland_spec_provider_0.pesel() == '86112716880'


# Generated at 2022-06-25 19:56:39.105594
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider(seed=1234567890)
    assert poland_spec_provider_0.pesel() == '91082770245'


# Generated at 2022-06-25 19:56:42.798746
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert poland_spec_provider_0.pesel(datetime.datetime(1940, 1, 1)) == '40010177690'


# Generated at 2022-06-25 19:56:45.556063
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()

    pesel = poland_spec_provider.pesel()
    assert len(pesel) == 11
    assert isinstance(pesel, str)



# Generated at 2022-06-25 19:56:47.799876
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_provider = PolandSpecProvider()
    for _ in range(20):
        pesel = poland_provider.pesel()
        assert isinstance(pesel, str)
        assert len(pesel) == 11


# Generated at 2022-06-25 19:56:52.119466
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    assert len(poland_spec_provider.pesel()) == 11

# Generated at 2022-06-25 19:56:55.581401
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # PESEL in range of (1940101, 20181231)
    pesel_0 = PolandSpecProvider().pesel(birth_date=0, gender=Gender.MALE)
    assert (
        pesel_0 == '84103150459'
    ), 'assertion error: {} != 84103150459'.format(pesel_0)



# Generated at 2022-06-25 19:57:01.358561
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_1 = PolandSpecProvider()
    # Valid return
    gender_0 = Gender.MALE
    date_time_0 = Datetime().date_time(1940, 2018)
    pesel_0 = poland_spec_provider_1.pesel(date_time_0, gender_0)
    # Valid return
    gender_1 = Gender.MALE
    date_time_1 = Datetime().date_time(1940, 2018)
    pesel_1 = poland_spec_provider_1.pesel(date_time_1, gender_1)


# Generated at 2022-06-25 19:57:06.979667
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_1 = PolandSpecProvider()
    assert len(poland_spec_provider_1.pesel()) == 11
    assert len(poland_spec_provider_1.pesel(gender=Gender.MALE)) == 11
    assert len(poland_spec_provider_1.pesel(gender=Gender.FEMALE)) == 11


# Generated at 2022-06-25 19:57:12.416172
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    provider.set_seed("a")
    result = provider.pesel()
    # Result should be 99092885137
    assert result == "99092885137"
    # Test with gender
    result = provider.pesel(gender=Gender.FEMALE)
    # Result should be 99092885137
    assert result == "99092885137"


# Generated at 2022-06-25 19:57:15.523199
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    poland_spec_provider_0.seed(0)
    assert poland_spec_provider_0.pesel() == '85310421116'
