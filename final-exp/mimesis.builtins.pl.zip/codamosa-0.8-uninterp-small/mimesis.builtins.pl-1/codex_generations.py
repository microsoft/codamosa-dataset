

# Generated at 2022-06-25 19:55:13.189009
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    johndoe = PolandSpecProvider(seed=1337)
    assert johndoe.pesel() == '32531209121'
    assert johndoe.pesel(birth_date=johndoe.datetime(2000, 2005)) == '02222704027'
    assert johndoe.pesel(birth_date=johndoe.datetime(1990, 1995), gender=Gender.MALE) == '90201091383'
    assert johndoe.pesel(birth_date=johndoe.datetime(1990, 1995), gender=Gender.FEMALE) == '90203172310'

# Generated at 2022-06-25 19:55:15.571025
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_2 = PolandSpecProvider()
    pesel = poland_spec_provider_2.pesel()
    assert len(str(pesel)) == 11


# Generated at 2022-06-25 19:55:18.812250
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert (len(poland_spec_provider_0.pesel()) == 11)


# Generated at 2022-06-25 19:55:20.207697
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    assert PolandSpecProvider().pesel() == '99010410307'


# Generated at 2022-06-25 19:55:24.171244
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test for pesel method of class PolandSpecProvider"""
    pesel = PolandSpecProvider().pesel()
    assert len(pesel) == 11
    assert type(pesel) is str
    assert all(c.isdigit() for c in pesel)


# Generated at 2022-06-25 19:55:30.188261
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    # Generate valid PESEL for female
    assert type(poland_spec_provider_0.pesel(gender = Gender.FEMALE)) is str
    # Generate valid PESEL for male
    assert type(poland_spec_provider_0.pesel(gender = Gender.MALE)) is str
    # Generate valid PESEL for unspecified gender
    assert type(poland_spec_provider_0.pesel()) is str


# Generated at 2022-06-25 19:55:33.744288
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test for method pesel of class PolandSpecProvider."""

    poland_spec_provider_0 = PolandSpecProvider()
    pesel_1 = poland_spec_provider_0.pesel(birth_date=None, gender=None)
    assert len(pesel_1) == 11



# Generated at 2022-06-25 19:55:35.799347
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert poland_spec_provider_0.pesel()


# Generated at 2022-06-25 19:55:44.106657
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    pesel = poland_spec_provider_0.pesel()

# Generated at 2022-06-25 19:55:46.454764
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert len(poland_spec_provider_0.pesel()) == 11



# Generated at 2022-06-25 19:55:58.806569
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    arg_0 = poland_spec_provider_0.datetime(1940, 2018)
    arg_1 = Gender.FEMALE
    expected = '47011216243'
    actual = poland_spec_provider_0.pesel(arg_0, arg_1)
    assert expected == actual


# Generated at 2022-06-25 19:56:00.373881
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()
    assert len(pesel) == 11

# Generated at 2022-06-25 19:56:02.488901
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    print(poland_spec_provider_0.pesel())

# Generated at 2022-06-25 19:56:06.063107
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    assert len(poland_spec_provider.pesel()) == 11

# Generated at 2022-06-25 19:56:11.797342
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    pesel = p.pesel()
    assert len(pesel) == 11
    assert len(p.pesel(birth_date='2007-12-02')) == 11
    assert len(p.pesel(gender=Gender.FEMALE)) == 11
    assert len(p.pesel(birth_date='2007-12-02', gender=Gender.MALE)) == 11


# Generated at 2022-06-25 19:56:13.556578
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    poland_spec_provider_0.pesel()


# Generated at 2022-06-25 19:56:15.693043
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    first_pesel = PolandSpecProvider().pesel()
    second_pesel = PolandSpecProvider().pesel()
    assert first_pesel != second_pesel


# Generated at 2022-06-25 19:56:25.864579
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel_0 = PolandSpecProvider().pesel()
    assert len(pesel_0) == 11
    assert int(pesel_0[0]) in range(1, 9)
    assert int(pesel_0[1]) in range(0, 9)
    assert int(pesel_0[2]) in range(0, 2)
    assert int(pesel_0[3]) in range(0, 9)
    assert int(pesel_0[4]) in range(0, 3)
    assert int(pesel_0[5]) in range(0, 9)
    assert int(pesel_0[6]) in range(0, 9)
    assert int(pesel_0[7]) in range(0, 9)
    assert int(pesel_0[8]) in range(0, 9)

# Generated at 2022-06-25 19:56:35.351537
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    from datetime import datetime
    poland_spec_provider_0 = PolandSpecProvider()
    assert poland_spec_provider_0.pesel(datetime(1985, 1, 31), Gender.MALE) in ['85013129231', '85013129232', '85013129233', '85013129234', '85013129235', '85013129236', '85013129237', '85013129238', '85013129239', '85013129241']
    assert poland_spec_provider_0.pesel(datetime(2001, 4, 13), Gender.FEMALE) in ['01041389330', '01041389332', '01041389334', '01041389336', '01041389338']


# Generated at 2022-06-25 19:56:43.674176
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    flg_flag = True
    cntr_count = 0
    while (cntr_count < 1000):
        poland_spec_provider_0 = PolandSpecProvider()
        str_result = poland_spec_provider_0.pesel()
        if len(str_result) != 11:
            flg_flag = False
            break
        cntr_count += 1
    if (cntr_count == 1000):
        assert flg_flag == True

# Generated at 2022-06-25 19:56:55.554784
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    poland_spec_provider_0.seed(368833)
    output_0 = poland_spec_provider_0.pesel(Gender.FEMALE)
    assert output_0 == '17063006108'


# Generated at 2022-06-25 19:57:02.719095
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()

    pesel = poland_spec_provider_0.pesel()
    assert len(pesel) == 11
    assert int(pesel[4:6]) >= 1 and int(pesel[4:6]) <= 12
    assert int(pesel[6:8]) >= 1 and int(pesel[6:8]) <= 31
    assert int(pesel[0:2]) >= 0 and int(pesel[0:2]) <= 99
    assert int(pesel[8:9]) % 2 == 0
    assert int(pesel[2:4]) >= 0 and int(pesel[2:4]) <= 99
    assert int(pesel[10:11]) >= 0 and int(pesel[10:11]) <= 9

# Generated at 2022-06-25 19:57:05.976663
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    pseudo_random_pesel = poland_spec_provider.pesel()
    assert 11 == len(pseudo_random_pesel)


# Generated at 2022-06-25 19:57:09.885109
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    datetime_0 = poland_spec_provider_0.datetime(1940, 2018)
    assert isinstance(datetime_0, Datetime().datetime(1940, 2018))


# Generated at 2022-06-25 19:57:14.135410
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    data = [provider.pesel() for _ in range(1000)]
    assert len(data) == 1000
    assert len(set(data)) == len(data)
    assert all(d.isdigit() and len(d) == 11 for d in data)


# Generated at 2022-06-25 19:57:17.432252
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """
    Make sure that pesel method works correctly
    """
    poland_spec_provider_1 = PolandSpecProvider()
    pesel = poland_spec_provider_1.pesel()
    assert len(pesel) == 11


# Generated at 2022-06-25 19:57:20.976568
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    ret = poland_spec_provider_0.pesel()
    assert len(ret) == 11, 'Unexpected value'


# Generated at 2022-06-25 19:57:23.198291
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert len(poland_spec_provider_0.pesel()) == 11


# Generated at 2022-06-25 19:57:25.255754
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()
    assert len(pesel) == 11


# Generated at 2022-06-25 19:57:26.938496
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()
    assert len(pesel) == 11


# Generated at 2022-06-25 19:57:37.045390
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert len(poland_spec_provider_0.pesel()) == 11


# Generated at 2022-06-25 19:57:42.646469
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    from datetime import datetime
    poland_spec_provider_0 = PolandSpecProvider()
    poland_spec_provider_0.pesel(datetime(2019, 3, 28, 15, 28, 8, 234000), Gender.FEMALE)

# Generated at 2022-06-25 19:57:45.087118
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert len(poland_spec_provider_0.pesel()) == 11


# Generated at 2022-06-25 19:57:46.232453
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    assert PolandSpecProvider().pesel() != ''


# Generated at 2022-06-25 19:57:48.646733
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    assert poland_spec_provider.pesel() in '89030373743'


# Generated at 2022-06-25 19:57:50.861553
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert poland_spec_provider_0.pesel()


# Generated at 2022-06-25 19:57:54.153486
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    pesel = poland_spec_provider_0.pesel()
    assert(type(pesel) is str)
    assert(len(pesel) == 11)


# Generated at 2022-06-25 19:57:56.700241
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert re.match('^\d{11}$', poland_spec_provider_0.pesel())


# Generated at 2022-06-25 19:57:59.902562
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()

    assert len(pesel) == 11
    assert int(pesel[0]) in (2, 3, 4, 5, 6, 7)



# Generated at 2022-06-25 19:58:02.780196
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert len(poland_spec_provider_0.pesel()) == 11


# Generated at 2022-06-25 19:58:29.153390
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert len(poland_spec_provider_0.pesel()) == 11

# Generated at 2022-06-25 19:58:32.453650
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    pesel = poland_spec_provider.pesel()
    assert len(pesel) == 11
    assert isinstance(pesel, str)


# Generated at 2022-06-25 19:58:34.904619
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    ret = poland_spec_provider.pesel()
    assert len(ret) == 11


# Generated at 2022-06-25 19:58:36.981004
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert len(poland_spec_provider_0.pesel()) == 11


# Generated at 2022-06-25 19:58:44.968365
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_1 = PolandSpecProvider()
    pesel_1 = poland_spec_provider_1.pesel(birth_date = datetime.datetime(1990, 2, 20, 9, 52, 2, 517411), gender = Gender.MALE)
    assert len(pesel_1) == 11
    pesel_2 = poland_spec_provider_1.pesel(birth_date = datetime.datetime(1991, 2, 26, 9, 52, 2, 517411), gender = Gender.MALE)
    assert len(pesel_2) == 11
    pesel_3 = poland_spec_provider_1.pesel(birth_date = datetime.datetime(1992, 3, 4, 9, 52, 2, 517411), gender = Gender.FEMALE)

# Generated at 2022-06-25 19:58:49.115799
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    gender = Gender.FEMALE
    birth_date = Datetime().datetime(1940, 2018)
    assert len(poland_spec_provider_0.pesel(birth_date, gender)) == 11


# Generated at 2022-06-25 19:58:51.823250
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    seed = 54904
    poland_spec_provider_0 = PolandSpecProvider(seed)
    pesel_1 = poland_spec_provider_0.pesel()



# Generated at 2022-06-25 19:58:53.604260
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    f = PolandSpecProvider().pesel()
    assert type(f) is str and len(f) == 11 and f

# Generated at 2022-06-25 19:58:59.015085
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # PESEL: https://pl.wikipedia.org/wiki/PESEL
    # E.g. 27050901359
    # birth: 27 maja 2009
    # sex 1 - man, 2 - woman
    birth_date = Datetime().datetime(2009, 2009)
    pesel = PolandSpecProvider().pesel(birth_date=birth_date, gender = Gender.FEMALE)
    assert pesel == '2705'
    assert len(pesel) == 11


# Generated at 2022-06-25 19:59:00.282814
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel_0 = PolandSpecProvider().pesel()
    assert len(pesel_0) == 11


# Generated at 2022-06-25 19:59:38.207956
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider(Gender.MALE, 'pl')
    assert poland_spec_provider_0.pesel(Gender.MALE).isdigit()
    assert len(poland_spec_provider_0.pesel(Gender.MALE)) == 11

    poland_spec_provider_1 = PolandSpecProvider(Gender.FEMALE, 'pl')
    assert poland_spec_provider_1.pesel(Gender.FEMALE).isdigit()
    assert len(poland_spec_provider_1.pesel(Gender.FEMALE)) == 11


# Generated at 2022-06-25 19:59:47.072458
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    rand_num = randint(0, 100)
    rand_num2 = randint(0, 10)
    rand_num3 = randint(0, 10)
    rand_num4 = randint(0, 10)
    prov = PolandSpecProvider()
    res = prov.pesel(birth_date=date(rand_num, rand_num2, rand_num3), gender=Gender(rand_num4))
    assert (
        re.match(r'\d{11}', res)
        and len(res) == 11
        and int(res[2:4]) in range(1, 13)
        and int(res[4:6]) in range(1, 32)
    )
    assert len(res) == 11


# Generated at 2022-06-25 19:59:51.217943
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    pesel_0 = poland_spec_provider_0.pesel(gender=Gender.MALE)
    assert len(pesel_0) == 11

    poland_spec_provider_1 = PolandSpecProvider()
    pesel_1 = poland_spec_provider_1.pesel(gender=Gender.FEMALE)
    assert len(pesel_1) == 11


# Generated at 2022-06-25 19:59:56.913239
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider = PolandSpecProvider()
    assert len(poland_spec_provider.pesel()) == 11
    assert len(poland_spec_provider.pesel(Gender.MALE)) == 11
    assert len(poland_spec_provider.pesel(Gender.FEMALE)) == 11
    

# Generated at 2022-06-25 20:00:00.383682
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_1 = PolandSpecProvider()
    response = poland_spec_provider_1.pesel()
    assert response is not None
    assert isinstance(response, str) is True
    assert len(response) == 11
    assert response.isdigit() is True


# Generated at 2022-06-25 20:00:04.408039
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert(poland_spec_provider_0.pesel() is not None)


# Generated at 2022-06-25 20:00:13.293807
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()

    # Test default input
    assert provider.pesel() in str(range(10000000000, 100000000000))
    assert len(provider.pesel()) == 11

    # Test specified input
    assert provider.pesel(birth_date=Datetime.datetime(1900, 1990),
                          gender=Gender.MALE) in str(range(10000000000, 100000000000))
    assert len(provider.pesel(birth_date=Datetime.datetime(1900, 1990), gender=Gender.MALE)) == 11
    assert provider.pesel(birth_date=Datetime.datetime(1900, 1990),
                          gender=Gender.FEMALE) in str(range(10000000000, 100000000000))

# Generated at 2022-06-25 20:00:15.802013
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    print(poland_spec_provider_0.pesel())


# Generated at 2022-06-25 20:00:22.869194
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    assert poland_spec_provider_0.pesel() == '96102401342'
    assert poland_spec_provider_0.pesel() == '32051031158'
    assert poland_spec_provider_0.pesel() == '35102530042'
    assert poland_spec_provider_0.pesel() == '03112606324'
    assert poland_spec_provider_0.pesel() == '86051413861'
    assert poland_spec_provider_0.pesel() == '06020271374'
    assert poland_spec_provider_0.pesel() == '98022382867'
    assert poland_spec_provider_0.pesel()

# Generated at 2022-06-25 20:00:32.261069
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider()
    poland_spec_provider_1 = PolandSpecProvider()
    poland_spec_provider_2 = PolandSpecProvider()
    poland_spec_provider_3 = PolandSpecProvider()
    poland_spec_provider_4 = PolandSpecProvider()
    poland_spec_provider_5 = PolandSpecProvider()
    poland_spec_provider_6 = PolandSpecProvider()
    poland_spec_provider_7 = PolandSpecProvider()
    poland_spec_provider_8 = PolandSpecProvider()
    poland_spec_provider_9 = PolandSpecProvider()

    assert (poland_spec_provider_0.pesel() != poland_spec_provider_1.pesel())

# Generated at 2022-06-25 20:04:56.055065
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_spec_provider_0 = PolandSpecProvider(seed=123)
    assert poland_spec_provider_0.pesel() == '92121414393'
    # Code should throw TypeError which implies method returns string, not DateTime
    try:
        poland_spec_provider_0.pesel(Datetime().datetime(1940, 2018))
    except TypeError:
        pass
