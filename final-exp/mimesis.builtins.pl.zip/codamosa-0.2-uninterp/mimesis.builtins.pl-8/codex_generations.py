

# Generated at 2022-06-17 21:41:52.118112
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    p = PolandSpecProvider()
    pesel = p.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) <= 12
    assert int(pesel[4:6]) <= 31
    assert int(pesel[6:9]) <= 999
    assert int(pesel[9]) <= 9
    assert int(pesel[10]) <= 9


# Generated at 2022-06-17 21:42:03.777514
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test for method pesel of class PolandSpecProvider."""
    from mimesis.enums import Gender
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.person import Person

    p = Person('pl')
    d = Datetime('pl')
    pesel = p.pesel(d.datetime(1940, 2018), Gender.MALE)
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) <= 12
    assert int(pesel[4:6]) <= 31
    assert int(pesel[2:4]) in [1, 3, 5, 7, 8, 10, 12] or int(pesel[4:6]) <= 30
    assert int(pesel[2:4]) == 2 and int

# Generated at 2022-06-17 21:42:15.763223
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from datetime import datetime
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    person = Person('pl')
    gender = person.gender()
    birth_date = person.birth_date(minimum=1940, maximum=2018)
    pesel = PolandSpecProvider().pesel(birth_date=birth_date, gender=gender)
    assert len(pesel) == 11
    assert int(pesel[0]) in range(1, 3)
    assert int(pesel[1]) in range(0, 9)
    assert int(pesel[2]) in range(0, 9)
    assert int(pesel[3]) in range(0, 9)

# Generated at 2022-06-17 21:42:25.278788
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from datetime import datetime
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.providers.poland import PolandSpecProvider
    from mimesis.typing import Seed

    seed = Seed.random()
    p = Person('pl', seed=seed)
    ps = PolandSpecProvider(seed=seed)
    assert len(ps.pesel()) == 11
    assert len(ps.pesel(birth_date=datetime(2000, 1, 1))) == 11
    assert len(ps.pesel(gender=Gender.MALE)) == 11
    assert len(ps.pesel(birth_date=datetime(2000, 1, 1),
                        gender=Gender.MALE)) == 11

# Generated at 2022-06-17 21:42:37.414275
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test for method pesel of class PolandSpecProvider"""
    from mimesis.enums import Gender
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.poland import PolandSpecProvider
    from mimesis.typing import DateTime
    import datetime
    import re
    import unittest

    class TestPolandSpecProviderPesel(unittest.TestCase):
        """Test for method pesel of class PolandSpecProvider"""

        def setUp(self):
            """Initialize attributes."""
            self.provider = PolandSpecProvider()

        def test_pesel(self):
            """Test for method pesel of class PolandSpecProvider"""
            result = self.provider.pesel()
            self.assertIsInstance(result, str)

# Generated at 2022-06-17 21:42:41.331100
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:42:45.541859
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:42:52.522661
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) <= 12
    assert int(pesel[4:6]) <= 31
    assert int(pesel[2:4]) in (1, 3, 5, 7, 8, 10, 12) or int(pesel[4:6]) <= 30
    assert int(pesel[2:4]) != 2 or int(pesel[4:6]) <= 29
    assert int(pesel[2:4]) != 2 or int(pesel[4:6]) <= 28 or int(pesel[0:2]) % 4 == 0
    assert int(pesel[2:4])

# Generated at 2022-06-17 21:42:56.189713
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:43:05.915277
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from datetime import datetime
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.providers.poland import PolandSpecProvider

    p = Person('pl')
    pl = PolandSpecProvider()
    pesel = pl.pesel(birth_date=datetime(2000, 1, 1), gender=Gender.MALE)
    assert pesel == '00020101001'
    pesel = pl.pesel(birth_date=datetime(2000, 1, 1), gender=Gender.FEMALE)
    assert pesel == '00020101000'
    pesel = pl.pesel(birth_date=datetime(2000, 1, 1))

# Generated at 2022-06-17 21:43:28.816558
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from datetime import datetime
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.providers.poland import PolandSpecProvider
    from mimesis.typing import Seed

    seed = Seed.random()
    p = Person('pl', seed=seed)
    pl = PolandSpecProvider(seed=seed)
    pesel = pl.pesel(birth_date=datetime(2000, 1, 1), gender=Gender.MALE)
    assert pesel == '00100100000'
    pesel = pl.pesel(birth_date=datetime(2000, 1, 1), gender=Gender.FEMALE)
    assert pesel == '00100100010'

# Generated at 2022-06-17 21:43:38.892995
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert pesel[0] in ('0', '1', '2', '3', '4', '5', '6', '7', '8', '9')
    assert pesel[1] in ('0', '1', '2', '3', '4', '5', '6', '7', '8', '9')
    assert pesel[2] in ('0', '1', '2', '3', '4', '5', '6', '7', '8', '9')

# Generated at 2022-06-17 21:43:40.886518
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:43:50.762513
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    assert provider.pesel(birth_date=Datetime().datetime(1990, 1, 1), gender=Gender.MALE) == '90010203901'
    assert provider.pesel(birth_date=Datetime().datetime(1990, 1, 1), gender=Gender.FEMALE) == '90010203902'
    assert provider.pesel(birth_date=Datetime().datetime(1990, 1, 1)) == '90010203901'
    assert provider.pesel(birth_date=Datetime().datetime(1990, 1, 1)) == '90010203901'
    assert provider.pesel(birth_date=Datetime().datetime(1990, 1, 1)) == '90010203901'

# Generated at 2022-06-17 21:43:54.609766
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:44:02.187772
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) in range(1, 13)
    assert int(pesel[4:6]) in range(1, 32)
    assert int(pesel[6:9]) in range(0, 1000)
    assert int(pesel[9]) in range(0, 10)
    assert int(pesel[10]) in range(0, 10)
    assert int(pesel[2:4]) in range(1, 13)
    assert int(pesel[4:6]) in range(1, 32)

# Generated at 2022-06-17 21:44:04.598079
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:44:07.545659
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:44:10.819185
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:44:12.465998
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:44:35.485514
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) <= 12
    assert int(pesel[4:6]) <= 31


# Generated at 2022-06-17 21:44:37.814255
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert provider.validate_pesel(pesel)

# Generated at 2022-06-17 21:44:39.385603
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()

# Generated at 2022-06-17 21:44:42.639349
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:44:45.298631
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:44:50.708094
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) <= 12
    assert int(pesel[4:6]) <= 31
    assert int(pesel[0:2]) >= 40
    assert int(pesel[0:2]) <= 99
    assert int(pesel[9]) % 2 == 0 or int(pesel[9]) % 2 == 1


# Generated at 2022-06-17 21:45:02.482737
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    p = PolandSpecProvider()
    pesel = p.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) <= 12
    assert int(pesel[4:6]) <= 31
    assert int(pesel[0:2]) <= 99
    assert int(pesel[2:4]) >= 1
    assert int(pesel[4:6]) >= 1
    assert int(pesel[0:2]) >= 1
    assert int(pesel[9]) in [0, 2, 4, 6, 8]
    assert int(pesel[10]) in range(10)


# Generated at 2022-06-17 21:45:05.391224
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:45:09.932507
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    pesel = PolandSpecProvider().pesel(birth_date=Datetime().datetime(2000, 1, 1), gender=Gender.MALE)
    assert pesel == '00022300000'

# Generated at 2022-06-17 21:45:12.049321
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
