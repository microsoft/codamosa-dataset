

# Generated at 2022-06-17 21:41:51.841432
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    p = PolandSpecProvider()
    pesel = p.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit() == True


# Generated at 2022-06-17 21:41:54.110175
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel(birth_date=Datetime().datetime(1990, 1, 1), gender=Gender.MALE)
    assert pesel == '90010200001'

# Generated at 2022-06-17 21:42:00.126843
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from datetime import datetime
    from mimesis.enums import Gender
    from mimesis.providers import PolandSpecProvider
    from mimesis.typing import DateTime
    poland_provider = PolandSpecProvider()
    pesel = poland_provider.pesel(birth_date=DateTime(datetime(1998, 1, 1)),
                                  gender=Gender.MALE)
    assert pesel == '98010112345'
    pesel = poland_provider.pesel(birth_date=DateTime(datetime(1998, 1, 1)),
                                  gender=Gender.FEMALE)
    assert pesel == '98010112340'

# Generated at 2022-06-17 21:42:12.303882
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from datetime import datetime
    from mimesis.enums import Gender
    from mimesis.providers import PolandSpecProvider
    from mimesis.providers.person import Person
    from mimesis.providers.datetime import Datetime
    from mimesis.typing import DateTime

    pl_provider = PolandSpecProvider()
    person = Person('pl')
    datetime = Datetime('pl')
    gender = Gender.MALE
    birth_date = datetime.datetime(1940, 2018)
    pesel = pl_provider.pesel(birth_date, gender)
    assert len(pesel) == 11
    assert pesel[-1] in ('1', '3', '5', '7', '9')

# Generated at 2022-06-17 21:42:14.769217
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    assert len(PolandSpecProvider().pesel()) == 11


# Generated at 2022-06-17 21:42:17.788727
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    p = PolandSpecProvider()
    pesel = p.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:42:22.076009
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) <= 12
    assert int(pesel[4:6]) <= 31


# Generated at 2022-06-17 21:42:28.140366
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from datetime import datetime
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    person = Person('pl')
    pesel = person.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()

    pesel = person.pesel(gender=Gender.MALE)
    assert len(pesel) == 11
    assert pesel.isdigit()

    pesel = person.pesel(gender=Gender.FEMALE)
    assert len(pesel) == 11
    assert pesel.isdigit()

    pesel = person.pesel(birth_date=datetime(2000, 1, 1))
    assert len(pesel) == 11
    assert pesel.isdig

# Generated at 2022-06-17 21:42:31.004118
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:42:40.988634
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from datetime import datetime
    from mimesis.enums import Gender
    from mimesis.providers.person.poland import PolandSpecProvider
    from mimesis.providers.person.poland import PolandPerson
    from mimesis.providers.person.poland import PolandSpecProvider
    from mimesis.providers.person.poland import PolandPerson
    from mimesis.providers.person.poland import PolandSpecProvider
    from mimesis.providers.person.poland import PolandPerson
    from mimesis.providers.person.poland import PolandSpecProvider
    from mimesis.providers.person.poland import PolandPerson
    from mimesis.providers.person.poland import PolandSpecProvider

# Generated at 2022-06-17 21:43:01.009887
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:43:10.714655
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test pesel method of class PolandSpecProvider."""
    from mimesis.providers.person import Person
    from mimesis.providers.datetime import Datetime
    from mimesis.enums import Gender
    from mimesis.builtins.poland import PolandSpecProvider
    from mimesis.typing import DateTime
    from datetime import datetime
    import re
    person = Person('pl')
    datetime = Datetime('pl')
    poland = PolandSpecProvider('pl')
    gender = Gender.MALE
    birth_date = datetime.datetime(1940, 2018)
    pesel = poland.pesel(birth_date, gender)
    assert re.match(r'^[0-9]{11}$', pesel)
    assert len(pesel) == 11

# Generated at 2022-06-17 21:43:16.866480
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) <= 12
    assert int(pesel[4:6]) <= 31
    assert int(pesel[0:2]) <= 99
    assert int(pesel[9]) in (0, 2, 4, 6, 8)
    assert int(pesel[10]) in (1, 3, 5, 7, 9)

# Generated at 2022-06-17 21:43:18.592420
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()

# Generated at 2022-06-17 21:43:23.638212
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider"""
    from mimesis.providers.person import Person
    from mimesis.enums import Gender
    from mimesis.builtins.poland import PolandSpecProvider
    from mimesis.typing import Seed
    from datetime import datetime
    from random import seed
    person = Person('pl')
    poland = PolandSpecProvider(seed=Seed(seed(1)))
    gender = Gender.MALE
    birth_date = datetime(year=1990, month=1, day=1)
    pesel = poland.pesel(birth_date=birth_date, gender=gender)
    assert pesel == '90011012345'
    pesel = poland.pesel(gender=gender)
    assert pesel == '90011012345'
    pes

# Generated at 2022-06-17 21:43:25.827486
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:43:27.219800
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    assert provider.pesel() == '94092400862'

# Generated at 2022-06-17 21:43:31.003238
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:43:34.189898
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:43:44.014725
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    assert provider.pesel(birth_date=Datetime().datetime(2000, 1, 1), gender=Gender.MALE) == '20010101001'
    assert provider.pesel(birth_date=Datetime().datetime(2000, 1, 1), gender=Gender.FEMALE) == '20010101000'
    assert provider.pesel(birth_date=Datetime().datetime(2000, 1, 1)) == '20010101000'
    assert provider.pesel() == '20010101000'
    assert provider.pesel(birth_date=Datetime().datetime(2000, 1, 1), gender=Gender.MALE) == '20010101001'

# Generated at 2022-06-17 21:44:10.328315
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    assert PolandSpecProvider().pesel() == '94061808741'

# Generated at 2022-06-17 21:44:17.222693
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from mimesis.enums import Gender
    from mimesis.providers import Datetime
    from mimesis.providers.poland import PolandSpecProvider
    from mimesis.typing import DateTime
    from datetime import datetime

    poland_provider = PolandSpecProvider()
    pesel = poland_provider.pesel(birth_date=datetime(1994, 12, 1), gender=Gender.MALE)
    assert pesel == '94120101234'
    pesel = poland_provider.pesel(birth_date=datetime(1994, 12, 1), gender=Gender.FEMALE)
    assert pesel == '94120101234'

# Generated at 2022-06-17 21:44:22.496275
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    from mimesis.enums import Gender
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.person import Person
    from mimesis.providers.poland import PolandSpecProvider
    from mimesis.typing import DateTime

    poland_provider = PolandSpecProvider()
    person_provider = Person('pl')
    datetime_provider = Datetime()
    gender = Gender.MALE
    birth_date = datetime_provider.datetime(1940, 2018)
    pesel = poland_provider.pesel(birth_date, gender)
    assert len(pesel) == 11
    assert pesel[-1] in ('1', '3', '5', '7', '9')
    assert pesel[:2] == birth_date.strftime

# Generated at 2022-06-17 21:44:27.894550
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from datetime import datetime
    from mimesis.enums import Gender
    from mimesis.providers.person.poland import PolandSpecProvider
    from mimesis.typing import DateTime

    p = PolandSpecProvider()
    pesel = p.pesel(birth_date=datetime(1993, 2, 1), gender=Gender.MALE)
    assert pesel == '93020112345'
    pesel = p.pesel(birth_date=datetime(1993, 2, 1), gender=Gender.FEMALE)
    assert pesel == '93020112346'
    pesel = p.pesel(birth_date=datetime(1993, 2, 1))
    assert pesel == '93020112347'
    pesel = p.pesel

# Generated at 2022-06-17 21:44:36.786167
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    from mimesis.providers.person import Person
    from mimesis.enums import Gender
    from mimesis.builtins.pl import PolandSpecProvider
    from datetime import datetime
    import re

    p = Person('pl')
    pl = PolandSpecProvider()

    # Check if pesel is valid
    pesel = pl.pesel()
    assert re.match(r'^\d{11}$', pesel)

    # Check if pesel is valid for given gender
    pesel = pl.pesel(gender=Gender.MALE)
    assert re.match(r'^\d{11}$', pesel)
    assert pesel[-1] in ['1', '3', '5', '7', '9']

    pesel

# Generated at 2022-06-17 21:44:40.944462
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    assert provider.pesel() == '98081400100'
    assert provider.pesel(gender=Gender.MALE) == '98081400100'
    assert provider.pesel(gender=Gender.FEMALE) == '98081400100'
    assert provider.pesel(birth_date=Datetime().datetime(1940, 2018)) == '98081400100'
    assert provider.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.MALE) == '98081400100'
    assert provider.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.FEMALE) == '98081400100'

# Generated at 2022-06-17 21:44:44.437475
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert provider.validate_pesel(pesel)


# Generated at 2022-06-17 21:44:47.626139
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:44:51.125426
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    p = PolandSpecProvider()
    assert len(p.pesel()) == 11
    assert len(p.pesel(gender=Gender.MALE)) == 11
    assert len(p.pesel(gender=Gender.FEMALE)) == 11
    assert len(p.pesel(birth_date=Datetime().datetime(1940, 2018))) == 11


# Generated at 2022-06-17 21:44:55.083581
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
