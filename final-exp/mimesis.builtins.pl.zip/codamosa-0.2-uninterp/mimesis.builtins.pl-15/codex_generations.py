

# Generated at 2022-06-17 21:41:53.106572
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:42:00.652174
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    p = PolandSpecProvider()
    pesel = p.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) <= 12
    assert int(pesel[4:6]) <= 31
    assert int(pesel[6:9]) <= 999
    assert int(pesel[9]) in range(10)
    assert int(pesel[10]) in range(10)


# Generated at 2022-06-17 21:42:12.403240
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from datetime import datetime
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.providers.poland import PolandSpecProvider

    p = PolandSpecProvider()
    pesel = p.pesel(birth_date=datetime(2000, 1, 1), gender=Gender.MALE)
    assert len(pesel) == 11
    assert pesel[0] == '0'
    assert pesel[1] == '0'
    assert pesel[2] == '0'
    assert pesel[3] == '1'
    assert pesel[4] == '0'
    assert pesel[5] == '1'
    assert pesel[6] == '0'

# Generated at 2022-06-17 21:42:14.913968
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()

# Generated at 2022-06-17 21:42:17.835168
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2]) % 2 == 0
    assert int(pesel[4]) % 2 == 1


# Generated at 2022-06-17 21:42:21.021629
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:42:27.560689
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) <= 12
    assert int(pesel[4:6]) <= 31
    assert int(pesel[0:2]) in range(18, 100) or int(pesel[0:2]) in range(20, 100) or int(pesel[0:2]) in range(21, 100) or int(pesel[0:2]) in range(22, 100)
    assert int(pesel[9]) in range(0, 10)
    assert int(pesel[10]) in range(0, 10)


# Generated at 2022-06-17 21:42:31.904600
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:42:34.108099
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:42:42.461951
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    assert len(provider.pesel()) == 11
    assert len(provider.pesel(gender=Gender.MALE)) == 11
    assert len(provider.pesel(gender=Gender.FEMALE)) == 11
    assert len(provider.pesel(birth_date=Datetime().datetime(1940, 2018))) == 11
    assert len(provider.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.MALE)) == 11
    assert len(provider.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.FEMALE)) == 11


# Generated at 2022-06-17 21:43:01.710145
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) in range(1, 13)
    assert int(pesel[4:6]) in range(1, 32)
    assert int(pesel[0:2]) in range(18, 100) or int(pesel[0:2]) in range(0, 20)
    assert int(pesel[9]) in range(0, 10)
    assert int(pesel[10]) in range(0, 10)


# Generated at 2022-06-17 21:43:03.392395
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:43:05.264547
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()



# Generated at 2022-06-17 21:43:15.380583
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from datetime import datetime
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    p = Person('pl')
    pesel = p.pesel(datetime(2000, 1, 1), Gender.MALE)
    assert len(pesel) == 11
    assert pesel[0:2] == '00'
    assert pesel[2:4] == '01'
    assert pesel[4:6] == '01'
    assert pesel[6:9] == '000'
    assert pesel[9] in ['1', '3', '5', '7', '9']

# Generated at 2022-06-17 21:43:17.547159
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:43:20.849543
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test for method pesel of class PolandSpecProvider."""
    pesel = PolandSpecProvider().pesel(birth_date=Datetime().datetime(1990, 1, 1), gender=Gender.MALE)
    assert len(pesel) == 11
    assert pesel[-1] in '13579'
    assert pesel[:2] == '90'
    assert pesel[2:4] == '01'
    assert pesel[4:6] == '01'

# Generated at 2022-06-17 21:43:24.546062
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:43:30.136420
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from datetime import datetime
    from mimesis.enums import Gender
    from mimesis.providers.person.poland import PolandSpecProvider
    from mimesis.providers.person.person import Person
    from mimesis.providers.person.poland import PolandSpecProvider
    from mimesis.providers.person.person import Person
    from mimesis.providers.person.poland import PolandSpecProvider
    from mimesis.providers.person.person import Person
    from mimesis.providers.person.poland import PolandSpecProvider
    from mimesis.providers.person.person import Person
    from mimesis.providers.person.poland import PolandSpecProvider
    from mimesis.providers.person.person import Person
   

# Generated at 2022-06-17 21:43:34.507888
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) <= 12
    assert int(pesel[4:6]) <= 31


# Generated at 2022-06-17 21:43:41.227629
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) in range(1, 13)
    assert int(pesel[4:6]) in range(1, 32)
    assert int(pesel[6:9]) in range(0, 1000)
    assert int(pesel[9]) in range(0, 10)
    assert int(pesel[10]) in range(0, 10)


# Generated at 2022-06-17 21:46:06.165151
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from datetime import datetime
    from mimesis.enums import Gender
    from mimesis.providers.person.poland import PolandSpecProvider
    from mimesis.typing import DateTime
    from mimesis.utils import random_datetime

    p = PolandSpecProvider()
    assert p.pesel(birth_date=datetime(2000, 1, 1), gender=Gender.MALE) == '00021012345'
    assert p.pesel(birth_date=datetime(2000, 1, 1), gender=Gender.FEMALE) == '00021012346'
    assert p.pesel(birth_date=datetime(2000, 1, 1)) == '00021012347'

# Generated at 2022-06-17 21:46:12.239495
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from mimesis.enums import Gender
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.person import Person

    p = Person('pl')
    d = Datetime('pl')
    gender = Gender.MALE
    birth_date = d.datetime(1940, 2018)
    pesel = p.pesel(birth_date, gender)
    assert len(pesel) == 11

# Generated at 2022-06-17 21:46:14.114019
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:46:15.850302
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:46:20.378844
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    assert provider.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.MALE) == '97080123456'
    assert provider.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.FEMALE) == '97080123457'
    assert provider.pesel(birth_date=Datetime().datetime(1940, 2018)) == '97080123458'
    assert provider.pesel() == '97080123459'


# Generated at 2022-06-17 21:46:31.143724
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    from datetime import datetime
    from mimesis.enums import Gender
    from mimesis.providers.poland import PolandSpecProvider
    from mimesis.providers.person import Person
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.address import Address
    from mimesis.providers.internet import Internet
    from mimesis.providers.misc import Misc
    from mimesis.providers.person import Person
    from mimesis.providers.text import Text
    from mimesis.providers.business import Business
    from mimesis.providers.code import Code
    from mimesis.providers.geo import Geo
    from mimesis.providers.payment import Payment

# Generated at 2022-06-17 21:46:33.668795
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[-1]) == provider.checksum(pesel[:-1], (9, 7, 3, 1, 9, 7, 3, 1, 9, 7))

# Generated at 2022-06-17 21:46:36.992506
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:46:41.884612
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert provider.validate_pesel(pesel)


# Generated at 2022-06-17 21:46:43.439200
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    pesel = p.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
