

# Generated at 2022-06-17 21:41:46.903306
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:41:55.052434
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from mimesis.providers.datetime import Datetime
    from mimesis.enums import Gender
    from mimesis.builtins import PolandSpecProvider
    from datetime import datetime
    import re

    poland_provider = PolandSpecProvider()
    pesel = poland_provider.pesel()
    assert len(pesel) == 11
    assert re.match(r'^\d{11}$', pesel)

    pesel = poland_provider.pesel(birth_date=datetime(2000, 1, 1),
                                  gender=Gender.MALE)
    assert len(pesel) == 11
    assert re.match(r'^\d{11}$', pesel)

# Generated at 2022-06-17 21:41:57.815697
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:41:59.918389
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:42:09.888268
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    assert provider.pesel() == '89080703615'
    assert provider.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.MALE) == '89080703615'
    assert provider.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.FEMALE) == '89080703615'
    assert provider.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.UNKNOWN) == '89080703615'


# Generated at 2022-06-17 21:42:14.813406
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test pesel method."""
    pl = PolandSpecProvider()
    pesel = pl.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) <= 12
    assert int(pesel[4:6]) <= 31


# Generated at 2022-06-17 21:42:17.831345
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert provider.validate_pesel(pesel)


# Generated at 2022-06-17 21:42:26.578276
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from mimesis.enums import Gender
    from mimesis.providers import Datetime
    from mimesis.providers.poland import PolandSpecProvider
    from mimesis.typing import DateTime
    from datetime import datetime
    from random import randint
    from re import match
    from time import sleep
    from unittest import TestCase

    class TestPolandSpecProviderPesel(TestCase):
        """Test class PolandSpecProvider."""

        def setUp(self):
            """Initialize attributes."""
            self.seed = randint(0, 100)
            self.pl = PolandSpecProvider(seed=self.seed)
            self.dt = Datetime(seed=self.seed)
            self.birth_date = self.dt.datetime

# Generated at 2022-06-17 21:42:36.713361
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    assert provider.pesel() == '96060107918'
    assert provider.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.MALE) == '96060107918'
    assert provider.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.FEMALE) == '96060107918'
    assert provider.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.UNKNOWN) == '96060107918'


# Generated at 2022-06-17 21:42:39.389976
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    pesel = PolandSpecProvider().pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:42:56.190211
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()



# Generated at 2022-06-17 21:43:02.192823
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    p = PolandSpecProvider()
    assert len(p.pesel()) == 11
    assert len(p.pesel(gender=Gender.MALE)) == 11
    assert len(p.pesel(gender=Gender.FEMALE)) == 11
    assert len(p.pesel(birth_date=Datetime().datetime(2000, 2018))) == 11


# Generated at 2022-06-17 21:43:06.434629
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    p = PolandSpecProvider()
    pesel = p.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) <= 12
    assert int(pesel[4:6]) <= 31
    assert int(pesel[0:2]) in range(18, 100) or int(pesel[0:2]) in range(20, 100) or int(pesel[0:2]) in range(21, 100) or int(pesel[0:2]) in range(22, 100)

# Generated at 2022-06-17 21:43:16.187367
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from datetime import datetime
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    p = Person('pl')
    pesel = p.pesel(datetime(2000, 1, 1), Gender.MALE)
    assert len(pesel) == 11
    assert pesel[0] == '0'
    assert pesel[1] == '0'
    assert pesel[2] == '0'
    assert pesel[3] == '1'
    assert pesel[4] == '0'
    assert pesel[5] == '1'
    assert pesel[6] == '0'
    assert pesel[7] == '1'
    assert pesel[8] == '0'
    assert pes

# Generated at 2022-06-17 21:43:19.604567
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:43:28.618130
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from datetime import datetime
    from mimesis.enums import Gender
    from mimesis.providers import PolandSpecProvider
    from mimesis.typing import DateTime

    poland_provider = PolandSpecProvider()
    pesel = poland_provider.pesel(datetime(2000, 1, 1), Gender.MALE)
    assert len(pesel) == 11
    assert pesel[:2] == '00'
    assert pesel[2:4] == '01'
    assert pesel[4:6] == '01'
    assert pesel[6:9] == '000'
    assert pesel[9] == '1'
    assert pesel[10] == '0'
    pesel = poland_provider.pesel

# Generated at 2022-06-17 21:43:35.088572
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    assert provider.pesel() == '92010112358'
    assert provider.pesel(birth_date=Datetime().datetime(1940, 2018),
                          gender=Gender.MALE) == '92010112358'
    assert provider.pesel(birth_date=Datetime().datetime(1940, 2018),
                          gender=Gender.FEMALE) == '92010112358'


# Generated at 2022-06-17 21:43:38.193255
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:43:44.158411
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    p = PolandSpecProvider()
    assert len(p.pesel()) == 11
    assert len(p.pesel(gender=Gender.MALE)) == 11
    assert len(p.pesel(gender=Gender.FEMALE)) == 11
    assert len(p.pesel(birth_date=Datetime().datetime(1940, 2018))) == 11


# Generated at 2022-06-17 21:43:52.056730
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.MALE)
    assert len(pesel) == 11
    assert pesel[-1] in ('1', '3', '5', '7', '9')
    pesel = provider.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.FEMALE)
    assert len(pesel) == 11
    assert pesel[-1] in ('0', '2', '4', '6', '8')
    pesel = provider.pesel(birth_date=Datetime().datetime(1940, 2018))
    assert len(pesel) == 11

# Generated at 2022-06-17 21:44:14.951080
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) <= 12
    assert int(pesel[4:6]) <= 31
    assert int(pesel[6:9]) <= 999
    assert int(pesel[9]) <= 9
    assert int(pesel[10]) <= 9


# Generated at 2022-06-17 21:44:18.995937
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) < 13
    assert int(pesel[4:6]) < 32
    assert int(pesel[6:9]) < 1000
    assert int(pesel[9]) < 10
    assert int(pesel[10]) < 10


# Generated at 2022-06-17 21:44:23.849208
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from datetime import datetime
    from mimesis.enums import Gender
    from mimesis.providers.person.pl import PolandSpecProvider

    p = PolandSpecProvider()
    pesel = p.pesel(birth_date=datetime(2000, 1, 1), gender=Gender.MALE)
    assert pesel == '00110101001'
    pesel = p.pesel(birth_date=datetime(2000, 1, 1), gender=Gender.FEMALE)
    assert pesel == '00110101000'
    pesel = p.pesel(birth_date=datetime(2000, 1, 1))
    assert pesel in ['00110101001', '00110101000']
    pesel = p.pesel()
   

# Generated at 2022-06-17 21:44:33.532527
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) in range(1, 13)
    assert int(pesel[4:6]) in range(1, 32)
    assert int(pesel[6:9]) in range(1, 1000)
    assert int(pesel[9]) in range(0, 10)
    assert int(pesel[10]) in range(0, 10)
    assert int(pesel[2:4]) in range(1, 13)
    assert int(pesel[4:6]) in range(1, 32)

# Generated at 2022-06-17 21:44:38.140459
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    # Test for method pesel of class PolandSpecProvider
    # with default parameters
    assert len(PolandSpecProvider().pesel()) == 11
    # Test for method pesel of class PolandSpecProvider
    # with custom parameters
    assert len(PolandSpecProvider().pesel(
        birth_date=Datetime().datetime(1940, 2018),
        gender=Gender.MALE)) == 11


# Generated at 2022-06-17 21:44:42.494119
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:44:50.278058
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from datetime import datetime
    from mimesis.enums import Gender
    from mimesis.providers.person.poland import PolandSpecProvider
    poland_provider = PolandSpecProvider()
    pesel = poland_provider.pesel(datetime(2000, 1, 1), Gender.MALE)
    assert len(pesel) == 11
    assert pesel[:2] == '00'
    assert pesel[2:4] == '01'
    assert pesel[4:6] == '01'
    assert pesel[6:9] == '000'
    assert pesel[9] in '13579'
    assert pesel[10] == '0'

# Generated at 2022-06-17 21:44:55.082409
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:45:00.859956
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test pesel method of class PolandSpecProvider."""
    from datetime import datetime
    from mimesis.enums import Gender
    from mimesis.providers import PolandSpecProvider
    from mimesis.typing import DateTime
    pl = PolandSpecProvider()
    pesel = pl.pesel(birth_date=DateTime(datetime(2000, 1, 1)),
                     gender=Gender.MALE)
    assert pesel == '00110101001'
    pesel = pl.pesel(birth_date=DateTime(datetime(2000, 1, 1)),
                     gender=Gender.FEMALE)
    assert pesel == '00110101000'
    pesel = pl.pesel(birth_date=DateTime(datetime(2000, 1, 1)))

# Generated at 2022-06-17 21:45:02.414018
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:45:23.793819
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) in range(1, 13)
    assert int(pesel[4:6]) in range(1, 32)
    assert int(pesel[6:9]) in range(0, 1000)
    assert int(pesel[9]) in range(0, 10)
    assert int(pesel[10]) in range(0, 10)


# Generated at 2022-06-17 21:45:28.070949
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()

# Generated at 2022-06-17 21:45:31.016785
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test pesel method of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:45:37.227166
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    assert p.pesel() == '92010107828'
    assert p.pesel(gender=Gender.MALE) == '92010107828'
    assert p.pesel(gender=Gender.FEMALE) == '92010107828'
    assert p.pesel(birth_date=Datetime().datetime(1940, 2018)) == '92010107828'
    assert p.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.MALE) == '92010107828'
    assert p.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.FEMALE) == '92010107828'


# Generated at 2022-06-17 21:45:41.249259
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    assert provider.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.MALE) == '96082907903'
    assert provider.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.FEMALE) == '96082907902'
    assert provider.pesel(birth_date=Datetime().datetime(1940, 2018)) == '96082907903'
    assert provider.pesel() == '96082907903'


# Generated at 2022-06-17 21:45:44.464250
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) <= 12
    assert int(pesel[4:6]) <= 31


# Generated at 2022-06-17 21:45:46.452923
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    p = PolandSpecProvider()
    pesel = p.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()

# Generated at 2022-06-17 21:45:51.442176
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert int(pesel[0:2]) in range(40, 100)
    assert int(pesel[2:4]) in range(1, 13)
    assert int(pesel[4:6]) in range(1, 32)
    assert int(pesel[6:9]) in range(0, 1000)
    assert int(pesel[9:10]) in range(0, 10)
    assert int(pesel[10:11]) in range(0, 10)

# Generated at 2022-06-17 21:45:54.735638
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()

# Generated at 2022-06-17 21:46:03.616480
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    p = PolandSpecProvider()
    pesel = p.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) <= 12
    assert int(pesel[4:6]) <= 31
    assert int(pesel[0:2]) in range(18, 23)
    assert int(pesel[9]) in range(0, 10)
    assert int(pesel[10]) in range(0, 10)


# Generated at 2022-06-17 21:46:42.391805
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) <= 12
    assert int(pesel[4:6]) <= 31
    assert int(pesel[6:9]) <= 999
    assert int(pesel[9]) <= 9
    assert int(pesel[10]) <= 9


# Generated at 2022-06-17 21:46:43.616447
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()

# Generated at 2022-06-17 21:46:51.505196
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    # Test 1
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()

    # Test 2
    pesel = provider.pesel(birth_date=Datetime().datetime(1940, 2018),
                           gender=Gender.MALE)
    assert len(pesel) == 11
    assert pesel.isdigit()

    # Test 3
    pesel = provider.pesel(birth_date=Datetime().datetime(1940, 2018),
                           gender=Gender.FEMALE)
    assert len(pesel) == 11
    assert pesel.isdigit()



# Generated at 2022-06-17 21:46:57.926493
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    assert provider.pesel(gender=Gender.MALE) == '97080100026'
    assert provider.pesel(gender=Gender.FEMALE) == '97080100026'
    assert provider.pesel() == '97080100026'


# Generated at 2022-06-17 21:47:00.720251
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_provider = PolandSpecProvider()
    pesel = poland_provider.pesel()
    assert len(pesel) == 11


# Generated at 2022-06-17 21:47:04.414194
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:47:07.096974
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    pesel = PolandSpecProvider().pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()

# Generated at 2022-06-17 21:47:16.029762
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    assert provider.pesel() == '91081805851'
    assert provider.pesel(gender=Gender.MALE) == '91081805851'
    assert provider.pesel(gender=Gender.FEMALE) == '91081805851'
    assert provider.pesel(birth_date=Datetime().datetime(1940, 2018)) == '91081805851'
    assert provider.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.MALE) == '91081805851'
    assert provider.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.FEMALE) == '91081805851'

# Generated at 2022-06-17 21:47:20.978796
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from mimesis.enums import Gender
    from mimesis.providers import Datetime
    from mimesis.providers.poland import PolandSpecProvider
    from mimesis.typing import DateTime

    poland_provider = PolandSpecProvider()
    pesel = poland_provider.pesel(Datetime().datetime(1940, 2018), Gender.MALE)
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) <= 12
    assert int(pesel[4:6]) <= 31
    assert int(pesel[9]) % 2 == 1

# Generated at 2022-06-17 21:47:24.630719
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from datetime import datetime
    from mimesis.enums import Gender
    poland_provider = PolandSpecProvider()
    pesel = poland_provider.pesel(datetime(2000, 1, 1), Gender.MALE)
    assert pesel == '00050101234'

# Generated at 2022-06-17 21:47:59.535714
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:48:01.948329
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:48:06.226208
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    pesel = provider.pesel(gender=Gender.MALE)
    assert pesel[-1] in ['1', '3', '5', '7', '9']
    pesel = provider.pesel(gender=Gender.FEMALE)
    assert pesel[-1] in ['0', '2', '4', '6', '8']


# Generated at 2022-06-17 21:48:08.073628
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:48:11.673834
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from mimesis.enums import Gender
    from mimesis.providers import Datetime
    from mimesis.providers.poland import PolandSpecProvider
    from mimesis.typing import DateTime
    from datetime import datetime
    import re
    import pytest

    # Test pesel with default arguments
    pesel = PolandSpecProvider().pesel()
    assert len(pesel) == 11
    assert re.match(r'^[0-9]{11}$', pesel)

    # Test pesel with birth_date
    birth_date = datetime(year=2000, month=1, day=1)
    pesel = PolandSpecProvider().pesel(birth_date=birth_date)
    assert len(pesel) == 11

# Generated at 2022-06-17 21:48:12.724579
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:48:16.678787
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from datetime import datetime
    from mimesis.enums import Gender
    from mimesis.providers.person.poland import PolandSpecProvider
    from mimesis.providers.person.poland import PolandPerson

    poland_person = PolandPerson(seed=42)
    poland_spec_provider = PolandSpecProvider(seed=42)
    pesel = poland_spec_provider.pesel(
        birth_date=datetime(year=1940, month=1, day=1),
        gender=Gender.MALE)
    assert pesel == '40010101234'

# Generated at 2022-06-17 21:48:18.865111
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:48:21.600808
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:48:27.537618
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    assert provider.pesel() == '92112606743'
    assert provider.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.MALE) == '92112606743'
    assert provider.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.FEMALE) == '92112606743'
    assert provider.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.UNKNOWN) == '92112606743'
