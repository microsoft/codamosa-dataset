

# Generated at 2022-06-17 21:41:49.070596
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:41:51.451005
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()

# Generated at 2022-06-17 21:42:02.650257
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    assert provider.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.MALE) == '94080101234'
    assert provider.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.FEMALE) == '94080101234'
    assert provider.pesel(birth_date=Datetime().datetime(1940, 2018)) == '94080101234'
    assert provider.pesel(gender=Gender.MALE) == '94080101234'
    assert provider.pesel(gender=Gender.FEMALE) == '94080101234'
    assert provider.pesel() == '94080101234'


# Generated at 2022-06-17 21:42:10.749877
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) <= 12
    assert int(pesel[4:6]) <= 31
    assert int(pesel[6:9]) <= 999
    assert int(pesel[9]) <= 9
    assert int(pesel[10]) <= 9


# Generated at 2022-06-17 21:42:21.415182
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from datetime import datetime
    from mimesis.enums import Gender
    from mimesis.providers import PolandSpecProvider
    from mimesis.typing import DateTime

    p = PolandSpecProvider()
    pesel = p.pesel(birth_date=datetime(1980, 1, 1), gender=Gender.MALE)
    assert pesel == '80010100100'
    pesel = p.pesel(birth_date=datetime(1980, 1, 1), gender=Gender.FEMALE)
    assert pesel == '80010100200'
    pesel = p.pesel(birth_date=datetime(1980, 1, 1))
    assert pesel == '80010100100'

# Generated at 2022-06-17 21:42:24.303525
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:42:27.376332
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    assert provider.pesel() == '92101012345'


# Generated at 2022-06-17 21:42:38.934355
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from datetime import datetime
    from mimesis.enums import Gender
    from mimesis.providers.person.pl import PolandSpecProvider
    p = PolandSpecProvider()
    pesel = p.pesel(datetime(2000, 1, 1), Gender.MALE)
    assert pesel == '00010112345'
    pesel = p.pesel(datetime(2000, 1, 1), Gender.FEMALE)
    assert pesel == '00010112340'
    pesel = p.pesel(datetime(2000, 1, 1))
    assert pesel == '00010112345' or pesel == '00010112340'
    pesel = p.pesel()
    assert len(pesel) == 11
    assert pesel.isdig

# Generated at 2022-06-17 21:42:44.637485
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    from mimesis.enums import Gender
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.person import Person
    from mimesis.providers.poland import PolandSpecProvider
    from mimesis.typing import DateTime
    from datetime import datetime
    from random import randint
    from unittest import TestCase

    class TestPolandSpecProvider(TestCase):
        """Test class for PolandSpecProvider."""

        def setUp(self):
            """Initialize attributes."""
            self.poland = PolandSpecProvider()
            self.person = Person('pl')
            self.datetime = Datetime('pl')

        def test_pesel(self):
            """Test method pesel."""
           

# Generated at 2022-06-17 21:42:47.255404
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    pesel = PolandSpecProvider().pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:43:09.919389
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_provider = PolandSpecProvider()
    pesel = poland_provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:43:17.293976
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    pesel = provider.pesel(birth_date=provider.datetime(1940, 2018),
                           gender=Gender.MALE)
    assert len(pesel) == 11
    assert pesel.isdigit()
    pesel = provider.pesel(birth_date=provider.datetime(1940, 2018),
                           gender=Gender.FEMALE)
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:43:25.621501
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test pesel method of class PolandSpecProvider."""
    p = PolandSpecProvider()
    pesel = p.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) <= 12
    assert int(pesel[4:6]) <= 31
    assert int(pesel[0:2]) >= 40
    assert int(pesel[0:2]) <= 99
    assert int(pesel[9]) % 2 == 0 or int(pesel[9]) % 2 == 1

# Generated at 2022-06-17 21:43:27.714968
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test for method pesel of class PolandSpecProvider."""
    pesel = PolandSpecProvider().pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:43:38.564893
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from datetime import datetime
    from mimesis.enums import Gender
    from mimesis.providers.poland import PolandSpecProvider
    from mimesis.typing import DateTime

    poland_provider = PolandSpecProvider()
    pesel = poland_provider.pesel(birth_date=datetime(2000, 1, 1), gender=Gender.MALE)
    assert pesel == '00050101234'
    pesel = poland_provider.pesel(birth_date=datetime(2000, 1, 1), gender=Gender.FEMALE)
    assert pesel == '00050101234'
    pesel = poland_provider.pesel(birth_date=datetime(2000, 1, 1), gender=None)

# Generated at 2022-06-17 21:43:44.906394
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) <= 12
    assert int(pesel[4:6]) <= 31
    assert int(pesel[6:9]) <= 999
    assert int(pesel[9]) <= 9
    assert int(pesel[10]) <= 9


# Generated at 2022-06-17 21:43:52.416635
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # Test for method pesel of class PolandSpecProvider
    # Create object of class PolandSpecProvider
    poland_provider = PolandSpecProvider()
    # Create list of pesel numbers
    pesel_numbers = []
    # Generate 100 pesel numbers
    for i in range(100):
        pesel_numbers.append(poland_provider.pesel())
    # Check if pesel numbers are valid
    for pesel_number in pesel_numbers:
        assert len(pesel_number) == 11
        assert pesel_number.isdigit()
        pesel_digits = [int(d) for d in pesel_number]
        pesel_coeffs = (9, 7, 3, 1, 9, 7, 3, 1, 9, 7)

# Generated at 2022-06-17 21:44:02.460907
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) in range(1, 13)
    assert int(pesel[4:6]) in range(1, 32)
    assert int(pesel[0:2]) in range(18, 100)
    assert int(pesel[0:2]) in range(18, 100)
    assert int(pesel[0:2]) in range(18, 100)
    assert int(pesel[0:2]) in range(18, 100)
    assert int(pesel[0:2]) in range(18, 100)
    assert int(pesel[0:2]) in range

# Generated at 2022-06-17 21:44:12.233062
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from mimesis.builtins import PolandSpecProvider
    from mimesis.enums import Gender
    from mimesis.typing import DateTime
    from datetime import datetime
    poland_provider = PolandSpecProvider()
    pesel = poland_provider.pesel()
    assert len(pesel) == 11
    pesel = poland_provider.pesel(gender=Gender.MALE)
    assert len(pesel) == 11
    pesel = poland_provider.pesel(gender=Gender.FEMALE)
    assert len(pesel) == 11
    pesel = poland_provider.pesel(birth_date=datetime(1990, 1, 1))
    assert len(pesel) == 11
    pesel = pol

# Generated at 2022-06-17 21:44:18.031715
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) <= 12
    assert int(pesel[4:6]) <= 31
    assert int(pesel[0:2]) >= 40
    assert int(pesel[0:2]) <= 99
    assert int(pesel[9]) % 2 == 0
    assert int(pesel[9]) % 2 == 1
    assert int(pesel[9]) % 2 == 0
    assert int(pesel[9]) % 2 == 1


# Generated at 2022-06-17 21:44:48.041720
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    p = PolandSpecProvider()
    pesel = p.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) <= 12
    assert int(pesel[4:6]) <= 31
    assert int(pesel[0:2]) in range(18, 23)
    assert int(pesel[9]) in range(0, 10)
    assert int(pesel[10]) in range(0, 10)


# Generated at 2022-06-17 21:44:50.218885
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:45:02.754531
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from datetime import datetime
    from mimesis.enums import Gender
    from mimesis.providers.person.pl import PolandSpecProvider
    pl = PolandSpecProvider()
    pesel = pl.pesel(birth_date=datetime(2000, 1, 1), gender=Gender.MALE)
    assert pesel == '00010112345'
    pesel = pl.pesel(birth_date=datetime(2000, 1, 1), gender=Gender.FEMALE)
    assert pesel == '00010112340'
    pesel = pl.pesel(birth_date=datetime(2000, 1, 1))
    assert pesel == '00010112347'
    pesel = pl.pesel()
    assert len(pesel) == 11



# Generated at 2022-06-17 21:45:12.144049
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from datetime import datetime
    from mimesis.enums import Gender
    from mimesis.providers.person.poland import PolandSpecProvider
    p = PolandSpecProvider()
    assert len(p.pesel()) == 11
    assert len(p.pesel(birth_date=datetime(2000, 1, 1), gender=Gender.MALE)) == 11
    assert len(p.pesel(birth_date=datetime(2000, 1, 1), gender=Gender.FEMALE)) == 11
    assert len(p.pesel(birth_date=datetime(2000, 1, 1))) == 11
    assert len(p.pesel(gender=Gender.MALE)) == 11
    assert len(p.pesel(gender=Gender.FEMALE)) == 11

# Generated at 2022-06-17 21:45:16.640692
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:45:22.786331
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) <= 12
    assert int(pesel[4:6]) <= 31
    assert int(pesel[0:2]) <= 99
    assert int(pesel[6:9]) <= 999
    assert int(pesel[9:]) <= 9

# Generated at 2022-06-17 21:45:25.975540
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:45:28.647072
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:45:35.718746
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) <= 12
    assert int(pesel[4:6]) <= 31
    assert int(pesel[0:2]) >= 40
    assert int(pesel[0:2]) <= 99
    assert int(pesel[9]) % 2 == 0
    assert int(pesel[9]) in [0, 2, 4, 6, 8]
    assert int(pesel[10]) % 2 == 1
    assert int(pesel[10]) in [1, 3, 5, 7, 9]

# Generated at 2022-06-17 21:45:38.696500
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from datetime import datetime
    from mimesis.enums import Gender
    from mimesis.providers import PolandSpecProvider
    p = PolandSpecProvider()
    pesel = p.pesel(datetime(2000, 1, 1), Gender.MALE)
    assert pesel == '00010101234'

# Generated at 2022-06-17 21:46:04.843193
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from datetime import datetime
    from mimesis.enums import Gender
    from mimesis.providers.person.poland import PolandSpecProvider
    from mimesis.providers.person.poland import PolandSpecProvider
    from mimesis.providers.person.poland import PolandSpecProvider
    from mimesis.providers.person.poland import PolandSpecProvider
    from mimesis.providers.person.poland import PolandSpecProvider
    from mimesis.providers.person.poland import PolandSpecProvider
    from mimesis.providers.person.poland import PolandSpecProvider
    from mimesis.providers.person.poland import PolandSpecProvider
    from mimesis.providers.person.poland import PolandSpecProvider

# Generated at 2022-06-17 21:46:08.341239
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) <= 12
    assert int(pesel[4:6]) <= 31
    assert int(pesel[6:9]) <= 999
    assert int(pesel[9]) <= 9
    assert int(pesel[10]) <= 9


# Generated at 2022-06-17 21:46:13.837379
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    assert provider.pesel() == '89022503862'
    assert provider.pesel(birth_date=Datetime().datetime(1940, 2018),
                          gender=Gender.MALE) == '89022503862'
    assert provider.pesel(birth_date=Datetime().datetime(1940, 2018),
                          gender=Gender.FEMALE) == '89022503862'


# Generated at 2022-06-17 21:46:17.688929
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) <= 12
    assert int(pesel[4:6]) <= 31
    assert int(pesel[0:2]) >= 40
    assert int(pesel[0:2]) <= 99


# Generated at 2022-06-17 21:46:20.391693
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:46:25.946052
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:46:32.577512
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from datetime import datetime
    from mimesis.enums import Gender
    from mimesis.providers import PolandSpecProvider
    from mimesis.typing import DateTime

    poland_provider = PolandSpecProvider()
    pesel = poland_provider.pesel(
        birth_date=DateTime(datetime(1980, 1, 1)),
        gender=Gender.MALE)
    assert pesel == '80010112345'

    pesel = poland_provider.pesel(
        birth_date=DateTime(datetime(1980, 1, 1)),
        gender=Gender.FEMALE)
    assert pesel == '80010112340'


# Generated at 2022-06-17 21:46:34.007758
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:46:38.983981
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    import datetime
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.providers.datetime import Datetime
    from mimesis.builtins.poland import PolandSpecProvider
    from mimesis.typing import DateTime
    import pytest

    person = Person('pl')
    date = Datetime('pl')
    poland = PolandSpecProvider()

    # Test pesel with gender
    assert len(poland.pesel(gender=Gender.MALE)) == 11
    assert len(poland.pesel(gender=Gender.FEMALE)) == 11

    # Test pesel with birth date
    assert len(poland.pesel(birth_date=date.datetime(1940, 2018)))

# Generated at 2022-06-17 21:46:42.248473
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:47:01.532455
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel(birth_date=provider.datetime(1940, 2018), gender=Gender.MALE)
    assert len(pesel) == 11
    assert pesel[-1] in ['1', '3', '5', '7', '9']


# Generated at 2022-06-17 21:47:04.416087
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    assert provider.pesel() == '98050101234'


# Generated at 2022-06-17 21:47:07.097460
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:47:16.029131
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from mimesis.enums import Gender
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.person import Person
    from mimesis.providers.poland import PolandSpecProvider
    from mimesis.typing import DateTime
    import datetime
    import pytest

    poland_provider = PolandSpecProvider()
    person_provider = Person('pl')
    datetime_provider = Datetime('pl')

    # Test for gender
    gender = Gender.MALE
    pesel = poland_provider.pesel(gender=gender)
    assert pesel[-1] in ('1', '3', '5', '7', '9')

    gender = Gender.FEMALE
    pesel = poland

# Generated at 2022-06-17 21:47:24.062034
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test pesel method of class PolandSpecProvider."""
    from datetime import datetime
    from mimesis.enums import Gender
    from mimesis.providers.person.pl import PolandSpecProvider
    from mimesis.providers.person.pl import PolandPerson
    from mimesis.providers.person.pl import PolandAddress
    from mimesis.providers.person.pl import PolandPayment
    from mimesis.providers.person.pl import PolandCode
    from mimesis.providers.person.pl import PolandBusiness
    from mimesis.providers.person.pl import PolandSpecProvider
    from mimesis.providers.person.pl import PolandTelecom
    from mimesis.providers.person.pl import PolandText
    from mimesis.providers.person.pl import PolandTransport
   

# Generated at 2022-06-17 21:47:25.379282
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:47:30.415548
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    assert provider.pesel() == '96081809827'
    assert provider.pesel(gender=Gender.MALE) == '96081809827'
    assert provider.pesel(gender=Gender.FEMALE) == '96081809828'
    assert provider.pesel(birth_date=Datetime().datetime(1940, 2018)) == '96081809827'
    assert provider.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.MALE) == '96081809827'
    assert provider.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.FEMALE) == '96081809828'


# Generated at 2022-06-17 21:47:32.031028
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:47:33.608850
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:47:38.411603
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from mimesis.enums import Gender
    from mimesis.providers import Datetime
    from mimesis.providers.poland import PolandSpecProvider
    from mimesis.typing import DateTime

    poland_provider = PolandSpecProvider()
    pesel = poland_provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()

    pesel = poland_provider.pesel(gender=Gender.MALE)
    assert len(pesel) == 11
    assert pesel.isdigit()

    pesel = poland_provider.pesel(gender=Gender.FEMALE)
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:48:11.266828
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:48:15.106798
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    assert provider.pesel() == '97082406957'
    assert provider.pesel(gender=Gender.MALE) == '97082406957'
    assert provider.pesel(gender=Gender.FEMALE) == '97082406957'
    assert provider.pesel(birth_date=Datetime().datetime(2000, 2018)) == '00082406957'
    assert provider.pesel(birth_date=Datetime().datetime(2000, 2018), gender=Gender.MALE) == '00082406957'
    assert provider.pesel(birth_date=Datetime().datetime(2000, 2018), gender=Gender.FEMALE) == '00082406957'

# Generated at 2022-06-17 21:48:21.208861
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from datetime import datetime
    from mimesis.enums import Gender
    from mimesis.providers.person.poland import PolandSpecProvider
    from mimesis.typing import DateTime

    p = PolandSpecProvider()
    assert len(p.pesel()) == 11
    assert len(p.pesel(birth_date=datetime(2000, 1, 1))) == 11
    assert len(p.pesel(birth_date=datetime(2000, 1, 1), gender=Gender.MALE)) == 11
    assert len(p.pesel(birth_date=DateTime(2000, 1, 1))) == 11
    assert len(p.pesel(birth_date=DateTime(2000, 1, 1), gender=Gender.MALE)) == 11

#

# Generated at 2022-06-17 21:48:24.655327
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:48:26.392529
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:48:32.766943
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test pesel method of class PolandSpecProvider."""
    from mimesis.providers.datetime import Datetime
    from mimesis.enums import Gender
    from mimesis.builtins import PolandSpecProvider
    from datetime import datetime
    import re

    poland_provider = PolandSpecProvider()
    pesel = poland_provider.pesel()
    assert len(pesel) == 11
    assert re.match(r'^\d{11}$', pesel)
    assert poland_provider.pesel(
        birth_date=Datetime().datetime(1940, 2018),
        gender=Gender.MALE)
    assert poland_provider.pesel(
        birth_date=Datetime().datetime(1940, 2018),
        gender=Gender.FEMALE)
   

# Generated at 2022-06-17 21:48:37.769968
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    assert provider.pesel() == '94052400891'
    assert provider.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.MALE) == '94052400891'
    assert provider.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.FEMALE) == '94052400892'


# Generated at 2022-06-17 21:48:41.859010
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[-1]) == provider.checksum(pesel, (9, 7, 3, 1, 9, 7, 3, 1, 9, 7))


# Generated at 2022-06-17 21:48:44.365846
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:48:46.218627
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:49:33.479325
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    p = PolandSpecProvider()
    pesel = p.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert p.validate_pesel(pesel)


# Generated at 2022-06-17 21:49:39.326954
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert pesel[0:2] in ('18', '19', '20', '21', '22')
    assert pesel[2:4] in ('01', '02', '03', '04', '05', '06', '07', '08', '09',
                          '10', '11', '12', '81', '82', '83', '84', '85', '86',
                          '87', '88', '89', '90', '91', '92', '93', '94', '95',
                          '96', '97', '98', '99')

# Generated at 2022-06-17 21:49:44.658910
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from mimesis.builtins import PolandSpecProvider
    from mimesis.enums import Gender
    from mimesis.typing import DateTime
    from datetime import datetime
    from random import seed

    seed(1)
    p = PolandSpecProvider()
    assert p.pesel(birth_date=datetime(year=1940, month=1, day=1),
                   gender=Gender.MALE) == '40010100100'
    assert p.pesel(birth_date=datetime(year=1940, month=1, day=1),
                   gender=Gender.FEMALE) == '40010100200'

# Generated at 2022-06-17 21:49:46.817777
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test pesel method of class PolandSpecProvider."""
    pl_provider = PolandSpecProvider()
    pesel = pl_provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:49:53.713756
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from mimesis.enums import Gender
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.person import Person
    from mimesis.providers.poland import PolandSpecProvider
    from mimesis.typing import DateTime
    from datetime import datetime
    from mimesis.builtins.base import BaseSpecProvider
    from mimesis.enums import Gender
    from mimesis.providers import Datetime
    from mimesis.typing import DateTime, Seed
    import unittest
    import random
    import string
    import re
    import pytest
    import pytest
    import random
    import string
    import re
    import pytest
    import pytest
    import random
    import string


# Generated at 2022-06-17 21:50:02.092076
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    assert provider.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.MALE) == '9808271234'
    assert provider.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.FEMALE) == '9808271234'
    assert provider.pesel(birth_date=Datetime().datetime(1940, 2018)) == '9808271234'
    assert provider.pesel() == '9808271234'


# Generated at 2022-06-17 21:50:07.931330
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from datetime import datetime
    from mimesis.enums import Gender
    from mimesis.providers import PolandSpecProvider
    from mimesis.typing import DateTime

    poland_provider = PolandSpecProvider()
    pesel = poland_provider.pesel(birth_date=DateTime(datetime(2000, 1, 1)), gender=Gender.MALE)
    assert pesel == '00022704021'


# Generated at 2022-06-17 21:50:12.975399
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    p = PolandSpecProvider()
    pesel = p.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) > 0
    assert int(pesel[2:4]) < 13
    assert int(pesel[4:6]) > 0
    assert int(pesel[4:6]) < 32
    assert int(pesel[6:9]) > 0
    assert int(pesel[6:9]) < 1000
    assert int(pesel[9]) in (0, 2, 4, 6, 8) or int(pesel[9]) in (1, 3, 5, 7, 9)
    assert int(pesel[10]) < 10


# Generated at 2022-06-17 21:50:17.291294
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) <= 12
    assert int(pesel[4:6]) <= 31
    assert int(pesel[6:9]) <= 999
    assert int(pesel[9]) <= 9
    assert int(pesel[10]) <= 9


# Generated at 2022-06-17 21:50:27.069351
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from mimesis.enums import Gender
    from mimesis.providers import Datetime
    from mimesis.providers.person import Person
    from mimesis.typing import DateTime

    p = Person('pl')
    dt = Datetime('pl')
    dt_obj = dt.datetime(1940, 2018)
    pesel = p.pesel(dt_obj, Gender.MALE)
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert p.pesel(dt_obj, Gender.FEMALE).isdigit()
    assert p.pesel(dt_obj).isdigit()
    assert p.pesel(birth_date=dt_obj, gender=Gender.MALE).isdig