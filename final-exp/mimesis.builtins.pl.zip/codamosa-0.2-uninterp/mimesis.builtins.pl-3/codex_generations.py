

# Generated at 2022-06-17 21:41:55.052587
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from mimesis.enums import Gender
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.poland import PolandSpecProvider
    from mimesis.typing import DateTime
    from datetime import datetime

    poland_provider = PolandSpecProvider()
    pesel = poland_provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()

    pesel = poland_provider.pesel(gender=Gender.MALE)
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert pesel[-1] in ('1', '3', '5', '7', '9')

    pesel = poland_provider.pes

# Generated at 2022-06-17 21:41:58.519353
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:42:10.801821
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) <= 12
    assert int(pesel[4:6]) <= 31
    assert int(pesel[0:2]) in range(18, 23)
    assert int(pesel[9]) in range(0, 10)
    assert int(pesel[10]) in range(0, 10)
    assert int(pesel[2:4]) in range(1, 13)
    assert int(pesel[4:6]) in range(1, 32)
    assert int(pesel[6:9]) in range(0, 1000)
    assert int(pesel[9]) in range(0, 10)

# Generated at 2022-06-17 21:42:21.460390
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    assert provider.pesel() == provider.pesel()
    assert provider.pesel(birth_date=provider.datetime(1940, 2018),
                          gender=Gender.MALE) == provider.pesel(
                              birth_date=provider.datetime(1940, 2018),
                              gender=Gender.MALE)
    assert provider.pesel(birth_date=provider.datetime(1940, 2018),
                          gender=Gender.FEMALE) == provider.pesel(
                              birth_date=provider.datetime(1940, 2018),
                              gender=Gender.FEMALE)

# Generated at 2022-06-17 21:42:22.738778
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:42:27.375749
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    p = PolandSpecProvider()
    pesel = p.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:42:30.348368
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:42:32.328377
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    assert p.pesel() == '94051805813'

# Generated at 2022-06-17 21:42:39.929828
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    assert provider.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.MALE) == '96080110984'
    assert provider.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.FEMALE) == '96080110984'
    assert provider.pesel(birth_date=Datetime().datetime(1940, 2018)) == '96080110984'
    assert provider.pesel() == '96080110984'


# Generated at 2022-06-17 21:42:47.539112
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) <= 12
    assert int(pesel[4:6]) <= 31
    assert int(pesel[6:9]) <= 999
    assert int(pesel[9]) <= 9
    assert int(pesel[10]) <= 9


# Generated at 2022-06-17 21:43:00.419868
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:43:02.012506
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:43:04.925984
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from datetime import datetime
    from mimesis.enums import Gender
    from mimesis.providers.person.poland import PolandSpecProvider
    p = PolandSpecProvider()
    pesel = p.pesel(datetime(2000, 1, 1), Gender.MALE)
    assert pesel == '20000101000'

# Generated at 2022-06-17 21:43:07.912990
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()

# Generated at 2022-06-17 21:43:12.301023
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:43:18.098601
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    assert provider.pesel() == '93112012345'
    assert provider.pesel(birth_date=Datetime().datetime(2000, 1, 1)) == '00110123456'
    assert provider.pesel(birth_date=Datetime().datetime(2000, 1, 1),
                          gender=Gender.MALE) == '00110123457'
    assert provider.pesel(birth_date=Datetime().datetime(2000, 1, 1),
                          gender=Gender.FEMALE) == '00110123458'


# Generated at 2022-06-17 21:43:20.522089
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:43:25.758827
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert provider.validate_pesel(pesel)


# Generated at 2022-06-17 21:43:36.212650
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from mimesis.enums import Gender
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.poland import PolandSpecProvider
    from mimesis.typing import DateTime
    from datetime import datetime
    import pytest

    # Test for method pesel of class PolandSpecProvider
    # without parameters
    poland_spec_provider = PolandSpecProvider()
    pesel = poland_spec_provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()

    # Test for method pesel of class PolandSpecProvider
    # with parameters
    date_object = Datetime().datetime(1940, 2018)

# Generated at 2022-06-17 21:43:38.610106
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:43:49.041682
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert provider.validate_pesel(pesel)


# Generated at 2022-06-17 21:43:53.376365
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:44:01.167771
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test pesel method of class PolandSpecProvider."""
    from mimesis.providers.datetime import Datetime
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    p = Person('pl')
    dt = Datetime('pl')
    date = dt.datetime(1940, 2018)
    gender = Gender.MALE
    pesel = p.pesel(date, gender)
    assert len(pesel) == 11
    assert pesel[0:2] == str(date.year)[-2:]
    assert int(pesel[2:4]) in range(1, 13)
    assert int(pesel[4:6]) in range(1, 32)
    assert int(pesel[6:9]) in range(0, 1000)

# Generated at 2022-06-17 21:44:03.460304
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    pesel = PolandSpecProvider().pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:44:13.221090
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from datetime import datetime
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.providers.poland import PolandSpecProvider
    from mimesis.typing import DateTime
    import re

    p = PolandSpecProvider()
    person = Person()
    gender = person.gender()
    birth_date = person.birth_date(minimum=1940, maximum=2018)
    pesel = p.pesel(birth_date=birth_date, gender=gender)
    assert len(pesel) == 11
    assert re.match(r'^[0-9]{11}$', pesel)
    assert int(pesel[2:4]) in range(1, 13)

# Generated at 2022-06-17 21:44:19.351748
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    assert provider.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.MALE) == '94050101234'
    assert provider.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.FEMALE) == '94050101234'
    assert provider.pesel(birth_date=Datetime().datetime(1940, 2018)) == '94050101234'
    assert provider.pesel(gender=Gender.MALE) == '94050101234'
    assert provider.pesel(gender=Gender.FEMALE) == '94050101234'
    assert provider.pesel() == '94050101234'


# Generated at 2022-06-17 21:44:23.306807
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    p = PolandSpecProvider()
    pesel = p.pesel(birth_date=Datetime().datetime(1990, 1, 1), gender=Gender.MALE)
    assert len(pesel) == 11
    assert pesel[9] == '1' or pesel[9] == '3' or pesel[9] == '5' or pesel[9] == '7' or pesel[9] == '9'


# Generated at 2022-06-17 21:44:33.193948
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from mimesis.enums import Gender
    from mimesis.providers import Datetime
    from mimesis.providers.poland import PolandSpecProvider
    from mimesis.typing import DateTime
    import datetime
    import re

    poland_provider = PolandSpecProvider()
    date_object = Datetime().datetime(1940, 2018)
    pesel = poland_provider.pesel(date_object, Gender.MALE)
    assert re.match(r'^\d{11}$', pesel)
    assert len(pesel) == 11
    assert int(pesel[0:2]) in range(40, 99)
    assert int(pesel[2:4]) in range(1, 13)

# Generated at 2022-06-17 21:44:35.451007
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()

# Generated at 2022-06-17 21:44:37.785514
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    assert len(provider.pesel()) == 11
    assert len(provider.pesel(gender=Gender.MALE)) == 11
    assert len(provider.pesel(gender=Gender.FEMALE)) == 11
