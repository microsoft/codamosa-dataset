

# Generated at 2022-06-17 21:41:52.791486
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) <= 12
    assert int(pesel[4:6]) <= 31
    assert int(pesel[0:2]) <= 99
    assert int(pesel[6:9]) <= 999
    assert int(pesel[9:11]) <= 99
    assert int(pesel[10]) == int(pesel[0]) + 3 * int(pesel[1]) + 7 * int(pesel[2]) + 9 * int(pesel[3]) + int(pesel[4]) + 3 * int(pesel[5]) + 7 * int(pesel[6]) + 9

# Generated at 2022-06-17 21:41:54.979187
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:42:01.013340
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from datetime import datetime
    from mimesis.enums import Gender
    from mimesis.providers import PolandSpecProvider
    from mimesis.typing import DateTime

    poland_provider = PolandSpecProvider()
    pesel = poland_provider.pesel(birth_date=DateTime(datetime(1990, 1, 1)),
                                  gender=Gender.MALE)
    assert pesel == '90010210102'

# Generated at 2022-06-17 21:42:03.586275
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:42:07.755858
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    p = PolandSpecProvider()
    pesel = p.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:42:11.865026
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    p = PolandSpecProvider()
    pesel = p.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:42:22.523136
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[:2]) in range(40, 100)
    assert int(pesel[2:4]) in range(1, 13)
    assert int(pesel[4:6]) in range(1, 32)
    assert int(pesel[6:9]) in range(0, 1000)
    assert int(pesel[9]) in range(0, 10)
    assert int(pesel[10]) in range(0, 10)
    assert int(pesel[-1]) == sum([int(pesel[i]) * int(pesel[i+1]) for i in range(0, 10, 2)]) % 10

# Generated at 2022-06-17 21:42:24.329743
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:42:28.753719
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()

# Generated at 2022-06-17 21:42:34.743573
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test for PolandSpecProvider.pesel."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert provider.pesel(birth_date=provider.datetime(1940, 2018))
    assert provider.pesel(gender=Gender.MALE)
    assert provider.pesel(gender=Gender.FEMALE)


# Generated at 2022-06-17 21:42:50.319677
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from mimesis.providers import PolandSpecProvider
    from mimesis.enums import Gender
    from datetime import datetime
    poland_provider = PolandSpecProvider()
    pesel = poland_provider.pesel(datetime(2000, 1, 1), Gender.MALE)
    assert len(pesel) == 11
    assert pesel[0:2] == '00'
    assert pesel[2:4] == '01'
    assert pesel[4:6] == '01'
    assert pesel[6:9] == '000'
    assert pesel[9] in '13579'
    assert pesel[10] == '0'

# Generated at 2022-06-17 21:42:59.363657
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    assert len(p.pesel()) == 11
    assert p.pesel(birth_date=Datetime().datetime(2000, 2000), gender=Gender.MALE)[-1] in ['1', '3', '5', '7', '9']
    assert p.pesel(birth_date=Datetime().datetime(2000, 2000), gender=Gender.FEMALE)[-1] in ['0', '2', '4', '6', '8']

# Generated at 2022-06-17 21:43:05.083193
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    from mimesis.enums import Gender
    from mimesis.providers import Datetime
    from mimesis.providers.poland import PolandSpecProvider
    from mimesis.typing import DateTime

    poland_provider = PolandSpecProvider()
    pesel = poland_provider.pesel(Datetime().datetime(1940, 2018), Gender.MALE)
    assert len(pesel) == 11
    assert pesel.isdigit()

# Generated at 2022-06-17 21:43:15.218942
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    assert provider.pesel() == '92082712078'
    assert provider.pesel(birth_date=Datetime().datetime(1940, 2018),
                          gender=Gender.MALE) == '92082712078'
    assert provider.pesel(birth_date=Datetime().datetime(1940, 2018),
                          gender=Gender.FEMALE) == '92082712078'
    assert provider.pesel(birth_date=Datetime().datetime(1940, 2018),
                          gender=Gender.UNKNOWN) == '92082712078'
    assert provider.pesel(birth_date=Datetime().datetime(1940, 2018)) == '92082712078'

# Generated at 2022-06-17 21:43:16.954869
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:43:20.116129
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    p = PolandSpecProvider()
    assert len(p.pesel()) == 11
    assert p.pesel(gender=Gender.MALE)[-1] in ('1', '3', '5', '7', '9')
    assert p.pesel(gender=Gender.FEMALE)[-1] in ('0', '2', '4', '6', '8')


# Generated at 2022-06-17 21:43:26.909253
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) <= 12
    assert int(pesel[4:6]) <= 31
    assert int(pesel[6:9]) <= 999
    assert int(pesel[9]) <= 9
    assert int(pesel[10]) <= 9


# Generated at 2022-06-17 21:43:29.975061
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:43:39.774863
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    import datetime
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.providers.poland import PolandSpecProvider

    poland_provider = PolandSpecProvider()
    person_provider = Person('pl')
    gender = person_provider.gender()
    birth_date = person_provider.birth_date(minimum=1940, maximum=2018)
    pesel = poland_provider.pesel(birth_date=birth_date, gender=gender)
    year = int(pesel[0:2])
    month = int(pesel[2:4])
    day = int(pesel[4:6])
    if 1800 <= year <= 1899:
        month -= 80

# Generated at 2022-06-17 21:43:50.047722
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    from mimesis.enums import Gender
    from mimesis.providers import Datetime
    from mimesis.providers.poland import PolandSpecProvider
    from mimesis.typing import DateTime
    from datetime import datetime

    p = PolandSpecProvider()
    assert p.pesel()
    assert p.pesel(gender=Gender.MALE)
    assert p.pesel(gender=Gender.FEMALE)
    assert p.pesel(birth_date=datetime(2000, 1, 1))
    assert p.pesel(birth_date=DateTime(2000, 1, 1))
    assert p.pesel(birth_date=Datetime().datetime(2000, 1, 1))


# Generated at 2022-06-17 21:44:04.921252
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:44:14.043671
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    assert p.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.MALE) == '90010112345'
    assert p.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.FEMALE) == '00010112345'
    assert p.pesel(birth_date=Datetime().datetime(1940, 2018)) == '00010112345'
    assert p.pesel(gender=Gender.MALE) == '90010112345'
    assert p.pesel(gender=Gender.FEMALE) == '00010112345'
    assert p.pesel() == '00010112345'


# Generated at 2022-06-17 21:44:19.989562
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    assert p.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.MALE) == '94101012345'
    assert p.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.FEMALE) == '94101012346'
    assert p.pesel(birth_date=Datetime().datetime(1940, 2018)) == '94101012347'
    assert p.pesel(gender=Gender.MALE) == '94101012348'
    assert p.pesel(gender=Gender.FEMALE) == '94101012349'
    assert p.pesel() == '94101012340'


# Generated at 2022-06-17 21:44:21.149029
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    assert provider.pesel() == '93072812098'


# Generated at 2022-06-17 21:44:23.202601
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert provider.validate_pesel(pesel)


# Generated at 2022-06-17 21:44:25.799411
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:44:35.656055
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) <= 12
    assert int(pesel[4:6]) <= 31
    assert int(pesel[2:4]) in (1, 3, 5, 7, 8, 10, 12) or int(pesel[4:6]) <= 30
    assert int(pesel[2:4]) != 2 or int(pesel[4:6]) <= 29
    assert int(pesel[2:4]) != 2 or int(pesel[4:6]) <= 28 or int(pesel[0:2]) % 4 == 0
    assert int(pesel[2:4]) != 2

# Generated at 2022-06-17 21:44:38.789337
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[-1]) == provider._checksum(pesel[:-1], (9, 7, 3, 1, 9, 7, 3, 1, 9, 7))

# Generated at 2022-06-17 21:44:48.939463
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    assert PolandSpecProvider().pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.MALE) == '89070803621'
    assert PolandSpecProvider().pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.FEMALE) == '89070803620'
    assert PolandSpecProvider().pesel(birth_date=Datetime().datetime(1940, 2018)) == '89070803621'
    assert PolandSpecProvider().pesel(gender=Gender.MALE) == '89070803621'
    assert PolandSpecProvider().pesel(gender=Gender.FEMALE) == '89070803620'

# Generated at 2022-06-17 21:44:58.597765
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    assert len(p.pesel()) == 11
    assert p.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.MALE)
    assert p.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.FEMALE)
    assert p.pesel(birth_date=Datetime().datetime(1940, 2018))


# Generated at 2022-06-17 21:45:23.704716
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from datetime import datetime
    from mimesis.enums import Gender
    from mimesis.providers.person.en import Person
    from mimesis.providers.person.pl import PolandSpecProvider
    from mimesis.typing import DateTime
    from mimesis.utils import random_datetime

    p = Person('pl')
    psp = PolandSpecProvider()
    for _ in range(10):
        gender = p.gender()
        birth_date = random_datetime(
            datetime(1940, 1, 1),
            datetime(2018, 12, 31),
        )
        pesel = psp.pesel(birth_date, gender)
        assert len(pesel) == 11
        assert pesel.isdigit()
       

# Generated at 2022-06-17 21:45:33.440591
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from mimesis.builtins import PolandSpecProvider
    from mimesis.enums import Gender
    from mimesis.typing import DateTime
    from datetime import datetime
    p = PolandSpecProvider()
    assert p.pesel(birth_date=datetime(1990, 1, 1), gender=Gender.MALE) == '90101012345'
    assert p.pesel(birth_date=datetime(1990, 1, 1), gender=Gender.FEMALE) == '90101012346'
    assert p.pesel(birth_date=datetime(1990, 1, 1)) == '90101012347'

# Generated at 2022-06-17 21:45:34.615679
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    assert provider.pesel() == '98091205849'

# Generated at 2022-06-17 21:45:35.979391
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:45:41.392067
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    assert provider.pesel() == '98081700111'
    assert provider.pesel(gender=Gender.MALE) == '98081700111'
    assert provider.pesel(gender=Gender.FEMALE) == '98081700111'
    assert provider.pesel(birth_date=Datetime().datetime(1940, 2018)) == '98081700111'
    assert provider.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.MALE) == '98081700111'
    assert provider.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.FEMALE) == '98081700111'


# Generated at 2022-06-17 21:45:45.708884
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    assert provider.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.MALE) == '98052909813'
    assert provider.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.FEMALE) == '98052909812'
    assert provider.pesel(birth_date=Datetime().datetime(1940, 2018)) == '98052909813'
    assert provider.pesel(birth_date=Datetime().datetime(1940, 2018)) == '98052909813'
    assert provider.pesel(birth_date=Datetime().datetime(1940, 2018)) == '98052909813'

# Generated at 2022-06-17 21:45:47.603314
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()

# Generated at 2022-06-17 21:45:51.180691
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from datetime import datetime
    from mimesis.enums import Gender
    from mimesis.providers.poland import PolandSpecProvider
    poland_provider = PolandSpecProvider()
    pesel = poland_provider.pesel(birth_date=datetime(2000, 1, 1), gender=Gender.MALE)
    assert pesel == '00010112345'

# Generated at 2022-06-17 21:46:03.848171
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from mimesis.enums import Gender
    from mimesis.providers import Datetime
    from mimesis.providers.person import Person

    p = Person('pl')
    dt = Datetime('pl')
    pesel = p.pesel(dt.datetime(1940, 2018), Gender.MALE)
    assert len(pesel) == 11
    assert pesel[0] in ('0', '1', '2', '3', '4', '5', '6', '7', '8', '9')
    assert pesel[1] in ('0', '1', '2', '3', '4', '5', '6', '7', '8', '9')

# Generated at 2022-06-17 21:46:06.061949
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.MALE)
    assert len(pesel) == 11
