

# Generated at 2022-06-17 21:42:02.649981
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    assert provider.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.MALE) == '93041301098'
    assert provider.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.FEMALE) == '93041301098'
    assert provider.pesel(birth_date=Datetime().datetime(1940, 2018)) == '93041301098'
    assert provider.pesel() == '93041301098'


# Generated at 2022-06-17 21:42:08.853937
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from datetime import datetime
    from mimesis.enums import Gender
    from mimesis.providers.poland import PolandSpecProvider
    provider = PolandSpecProvider()
    pesel = provider.pesel(birth_date=datetime(2000, 1, 1), gender=Gender.MALE)
    assert pesel == '00010112345'

# Generated at 2022-06-17 21:42:10.274387
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    p = PolandSpecProvider()
    pesel = p.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:42:20.920665
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from mimesis.providers.person import Person
    from mimesis.enums import Gender
    from mimesis.builtins.poland import PolandSpecProvider
    from datetime import datetime
    person = Person('pl')
    poland = PolandSpecProvider()
    gender = person.gender()
    if gender == Gender.MALE:
        gender_digit = poland.random.choice((1, 3, 5, 7, 9))
    elif gender == Gender.FEMALE:
        gender_digit = poland.random.choice((0, 2, 4, 6, 8))
    else:
        gender_digit = poland.random.choice(range(10))
    date_object = Datetime().datetime(1940, 2018)
    year = date_object

# Generated at 2022-06-17 21:42:22.914686
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test for method pesel of class PolandSpecProvider."""
    assert len(PolandSpecProvider().pesel()) == 11


# Generated at 2022-06-17 21:42:25.471211
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert provider.validate_pesel(pesel)


# Generated at 2022-06-17 21:42:33.404095
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel(gender=Gender.MALE)
    assert len(pesel) == 11
    assert int(pesel[9]) % 2 == 1
    pesel = provider.pesel(gender=Gender.FEMALE)
    assert len(pesel) == 11
    assert int(pesel[9]) % 2 == 0
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert int(pesel[9]) % 2 in (0, 1)


# Generated at 2022-06-17 21:42:37.379943
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    pesel = PolandSpecProvider().pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:42:48.184080
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from datetime import datetime
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.providers.poland import PolandSpecProvider
    from mimesis.typing import DateTime

    poland_provider = PolandSpecProvider()
    person = Person('pl')
    gender = Gender.MALE
    birth_date = datetime(2000, 1, 1)
    pesel = poland_provider.pesel(birth_date=birth_date, gender=gender)
    assert len(pesel) == 11
    assert pesel[0] == '0'
    assert pesel[1] == '0'
    assert pesel[2] == '0'

# Generated at 2022-06-17 21:42:52.643071
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:43:29.013390
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from datetime import datetime
    from mimesis.enums import Gender
    from mimesis.providers.person.poland import PolandSpecProvider
    poland_provider = PolandSpecProvider()
    pesel = poland_provider.pesel(datetime(2000, 1, 1), Gender.MALE)
    assert len(pesel) == 11
    assert pesel[0] == '0'
    assert pesel[1] == '0'
    assert pesel[2] == '0'
    assert pesel[3] == '1'
    assert pesel[4] == '0'
    assert pesel[5] == '1'
    assert pesel[6] == '0'
    assert pesel[7] == '0'

# Generated at 2022-06-17 21:43:38.123725
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) <= 12
    assert int(pesel[4:6]) <= 31
    assert int(pesel[6:9]) <= 999
    assert int(pesel[9:]) <= 9
    assert int(pesel[2:4]) > 0
    assert int(pesel[4:6]) > 0
    assert int(pesel[6:9]) > 0
    assert int(pesel[9:]) >= 0


# Generated at 2022-06-17 21:43:39.495173
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    assert provider.pesel() == '91072705831'

# Generated at 2022-06-17 21:43:49.952750
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from datetime import datetime
    from mimesis.enums import Gender
    from mimesis.providers import PolandSpecProvider
    provider = PolandSpecProvider()
    pesel = provider.pesel(birth_date=datetime(2000, 1, 1), gender=Gender.MALE)
    assert len(pesel) == 11
    assert pesel[-1] in ('1', '3', '5', '7', '9')
    pesel = provider.pesel(birth_date=datetime(2000, 1, 1), gender=Gender.FEMALE)
    assert len(pesel) == 11
    assert pesel[-1] in ('0', '2', '4', '6', '8')

# Generated at 2022-06-17 21:43:54.141802
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:44:01.455914
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    assert provider.pesel() == '93081607812'
    assert provider.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.MALE) == '93081607812'
    assert provider.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.FEMALE) == '93081607812'


# Generated at 2022-06-17 21:44:03.319312
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:44:10.540381
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) <= 12
    assert int(pesel[4:6]) <= 31
    assert int(pesel[6:9]) <= 999
    assert int(pesel[9]) <= 9
    assert int(pesel[10]) <= 9


# Generated at 2022-06-17 21:44:15.181248
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) <= 12
    assert int(pesel[4:6]) <= 31
    assert int(pesel[6:9]) <= 999
    assert int(pesel[9]) <= 9
    assert int(pesel[10]) <= 9


# Generated at 2022-06-17 21:44:18.966866
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    p = PolandSpecProvider()
    pesel = p.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert p.pesel(birth_date=p.datetime(1940, 2018), gender=Gender.MALE)
    assert p.pesel(birth_date=p.datetime(1940, 2018), gender=Gender.FEMALE)


# Generated at 2022-06-17 21:45:01.414352
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) <= 12
    assert int(pesel[4:6]) <= 31
    assert int(pesel[0:2]) >= 40


# Generated at 2022-06-17 21:45:04.272942
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) <= 12
    assert int(pesel[4:6]) <= 31
    assert int(pesel[6:9]) <= 999
    assert int(pesel[9]) <= 9
    assert int(pesel[10]) <= 9


# Generated at 2022-06-17 21:45:10.971588
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) <= 12
    assert int(pesel[4:6]) <= 31
    assert int(pesel[6:9]) <= 999
    assert int(pesel[9]) <= 9
    assert int(pesel[10]) <= 9


# Generated at 2022-06-17 21:45:19.518212
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    p = PolandSpecProvider()
    pesel = p.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert p.pesel(birth_date=p.datetime(1940, 2018), gender=Gender.MALE).isdigit()
    assert p.pesel(birth_date=p.datetime(1940, 2018), gender=Gender.FEMALE).isdigit()


# Generated at 2022-06-17 21:45:22.647519
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:45:29.603476
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    assert len(provider.pesel()) == 11
    assert len(provider.pesel(gender=Gender.MALE)) == 11
    assert len(provider.pesel(gender=Gender.FEMALE)) == 11
    assert len(provider.pesel(birth_date=Datetime().datetime(1940, 2018))) == 11


# Generated at 2022-06-17 21:45:31.880814
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    p = PolandSpecProvider()
    pesel = p.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()

# Generated at 2022-06-17 21:45:36.498746
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.MALE)
    assert len(pesel) == 11
    assert pesel[-2] in ('1', '3', '5', '7', '9')
    assert pesel[-1] in ('0', '1', '2', '3', '4', '5', '6', '7', '8', '9')


# Generated at 2022-06-17 21:45:41.967224
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test pesel method of class PolandSpecProvider."""
    from mimesis.enums import Gender
    from mimesis.providers import Datetime
    from mimesis.providers.poland import PolandSpecProvider
    from mimesis.typing import DateTime
    import datetime
    import pytest

    # Test pesel method with default parameters
    poland_provider = PolandSpecProvider()
    assert len(poland_provider.pesel()) == 11
    assert poland_provider.pesel().isdigit()

    # Test pesel method with custom parameters
    date_object = Datetime().datetime(1940, 2018)
    assert len(poland_provider.pesel(date_object)) == 11
    assert poland_provider.pesel(date_object).isdigit()

    # Test

# Generated at 2022-06-17 21:45:48.749146
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    assert provider.pesel() == '98082400984'
    assert provider.pesel(gender=Gender.MALE) == '98082400984'
    assert provider.pesel(gender=Gender.FEMALE) == '98082400984'
    assert provider.pesel(birth_date=Datetime().datetime(1990, 1, 1)) == '90010100984'
    assert provider.pesel(birth_date=Datetime().datetime(1990, 1, 1),
                          gender=Gender.MALE) == '90010100984'