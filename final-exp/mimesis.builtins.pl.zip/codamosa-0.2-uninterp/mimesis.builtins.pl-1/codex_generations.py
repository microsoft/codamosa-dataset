

# Generated at 2022-06-17 21:41:52.228699
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    assert provider.pesel() == '94080101234'
    assert provider.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.MALE) == '94080101234'
    assert provider.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.FEMALE) == '94080101234'
    assert provider.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.UNKNOWN) == '94080101234'
    assert provider.pesel(birth_date=Datetime().datetime(1940, 2018)) == '94080101234'
    assert provider.pesel(gender=Gender.MALE) == '94080101234'
    assert provider.pesel

# Generated at 2022-06-17 21:41:54.427343
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:42:05.861650
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from datetime import datetime
    from mimesis.enums import Gender
    from mimesis.providers.person.poland import PolandSpecProvider
    provider = PolandSpecProvider()
    pesel = provider.pesel(datetime(2000, 1, 1), Gender.MALE)
    assert pesel == '00110101001'
    pesel = provider.pesel(datetime(2000, 1, 1), Gender.FEMALE)
    assert pesel == '00110101000'
    pesel = provider.pesel(datetime(2000, 1, 1))
    assert pesel == '00110101001'
    pesel = provider.pesel()
    assert len(pesel) == 11


# Generated at 2022-06-17 21:42:06.717710
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()

# Generated at 2022-06-17 21:42:10.245478
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    p = PolandSpecProvider()
    assert len(p.pesel()) == 11


# Generated at 2022-06-17 21:42:17.302108
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) <= 12
    assert int(pesel[4:6]) <= 31
    assert int(pesel[9]) in (0, 2, 4, 6, 8) or int(pesel[9]) in (1, 3, 5, 7, 9)


# Generated at 2022-06-17 21:42:26.257002
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from datetime import datetime
    from mimesis.enums import Gender
    from mimesis.providers import PolandSpecProvider
    p = PolandSpecProvider()
    pesel = p.pesel(datetime(2000, 1, 1), Gender.MALE)
    assert len(pesel) == 11
    assert pesel[0:2] == '00'
    assert pesel[2:4] == '01'
    assert pesel[4:6] == '01'
    assert pesel[6:9] == '000'
    assert pesel[9] in ['1', '3', '5', '7', '9']

# Generated at 2022-06-17 21:42:30.632961
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:42:38.005138
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) <= 12
    assert int(pesel[4:6]) <= 31
    assert int(pesel[6:9]) <= 999
    assert int(pesel[9]) <= 9
    assert int(pesel[10]) <= 9


# Generated at 2022-06-17 21:42:40.390276
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()

# Generated at 2022-06-17 21:43:08.121172
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from datetime import datetime
    from mimesis.enums import Gender
    from mimesis.providers.person.pl import PolandSpecProvider
    from mimesis.providers.person.pl import PolandPerson

    poland_provider = PolandSpecProvider()
    poland_person = PolandPerson()

    # Test pesel with gender
    pesel_with_gender = poland_provider.pesel(
        birth_date=datetime(2000, 1, 1),
        gender=Gender.MALE
    )
    assert len(pesel_with_gender) == 11
    assert pesel_with_gender[-1] in ('1', '3', '5', '7', '9')

    # Test pesel with birth date
    pesel_with_birth

# Generated at 2022-06-17 21:43:15.708598
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) in range(1, 13)
    assert int(pesel[4:6]) in range(1, 32)
    assert int(pesel[6:9]) in range(0, 1000)
    assert int(pesel[9]) in range(0, 10)
    assert int(pesel[10]) in range(0, 10)


# Generated at 2022-06-17 21:43:17.154656
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:43:27.484903
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from mimesis.providers.person import Person
    from mimesis.enums import Gender
    from mimesis.builtins.poland import PolandSpecProvider
    from datetime import datetime
    from mimesis.typing import DateTime

    p = Person('pl')
    psp = PolandSpecProvider()
    gender = p.gender()
    birth_date = p.birthday(minimum=1940, maximum=2018)
    pesel = psp.pesel(birth_date, gender)
    assert len(pesel) == 11
    assert pesel[-1] in ('0', '1', '2', '3', '4', '5', '6', '7', '8', '9')

# Generated at 2022-06-17 21:43:33.662943
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) <= 12
    assert int(pesel[4:6]) <= 31


# Generated at 2022-06-17 21:43:43.547084
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from datetime import datetime
    from mimesis.enums import Gender
    from mimesis.providers import PolandSpecProvider
    from mimesis.typing import DateTime
    poland_provider = PolandSpecProvider()
    assert len(poland_provider.pesel()) == 11
    assert len(poland_provider.pesel(gender=Gender.MALE)) == 11
    assert len(poland_provider.pesel(gender=Gender.FEMALE)) == 11
    assert len(poland_provider.pesel(birth_date=DateTime(datetime(2000, 1, 1)))) == 11

# Generated at 2022-06-17 21:43:46.711998
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()

# Generated at 2022-06-17 21:43:53.379326
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    from mimesis.enums import Gender
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.person import Person
    from mimesis.providers.poland import PolandSpecProvider
    from mimesis.typing import DateTime

    dt = Datetime()
    p = Person('pl')
    pl = PolandSpecProvider()

    # Test for method pesel of class PolandSpecProvider
    # with gender
    for _ in range(10):
        gender = p.gender()
        pesel = pl.pesel(gender=gender)
        assert len(pesel) == 11

# Generated at 2022-06-17 21:44:02.718931
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from datetime import datetime
    from mimesis.enums import Gender
    from mimesis.providers import PolandSpecProvider
    p = PolandSpecProvider()
    pesel = p.pesel(datetime(1990, 1, 1), Gender.MALE)
    assert len(pesel) == 11
    assert pesel[0] == '9'
    assert pesel[1] == '0'
    assert pesel[2] == '0'
    assert pesel[3] == '1'
    assert pesel[4] == '0'
    assert pesel[5] == '1'
    assert pesel[6] == '0'
    assert pesel[7] == '0'
    assert pesel[8] == '0'
    assert pes

# Generated at 2022-06-17 21:44:04.694378
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:44:33.716098
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    p = PolandSpecProvider()
    pesel = p.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) <= 12
    assert int(pesel[4:6]) <= 31
    assert int(pesel[6:9]) <= 999
    assert int(pesel[9]) <= 9
    assert int(pesel[10]) <= 9


# Generated at 2022-06-17 21:44:35.836621
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:44:39.505248
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) <= 12
    assert int(pesel[4:6]) <= 31
    assert int(pesel[6:9]) <= 999
    assert int(pesel[9]) <= 9
    assert int(pesel[10]) <= 9


# Generated at 2022-06-17 21:44:44.437418
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.MALE)
    assert len(pesel) == 11
    assert pesel[9] in ['1', '3', '5', '7', '9']


# Generated at 2022-06-17 21:44:49.716591
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    p = PolandSpecProvider()
    pesel = p.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) <= 12
    assert int(pesel[4:6]) <= 31
    assert int(pesel[6:9]) <= 999
    assert int(pesel[9]) <= 9
    assert int(pesel[10]) <= 9


# Generated at 2022-06-17 21:44:59.560468
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) <= 12
    assert int(pesel[4:6]) <= 31
    assert int(pesel[6:9]) <= 999
    assert int(pesel[9]) <= 9
    assert int(pesel[10]) <= 9


# Generated at 2022-06-17 21:45:01.385634
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:45:02.845625
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:45:05.905042
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel(birth_date=Datetime().datetime(1990, 1, 1), gender=Gender.MALE)
    assert pesel == '90010200001'

# Generated at 2022-06-17 21:45:09.860957
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
