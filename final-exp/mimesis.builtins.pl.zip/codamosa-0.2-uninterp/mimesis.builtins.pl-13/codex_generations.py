

# Generated at 2022-06-17 21:41:46.742965
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:41:52.324592
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) <= 12
    assert int(pesel[4:6]) <= 31
    assert int(pesel[0:2]) <= 99
    assert int(pesel[6:9]) <= 999
    assert int(pesel[9:11]) <= 99


# Generated at 2022-06-17 21:41:54.427714
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:42:05.862201
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) > 0
    assert int(pesel[2:4]) < 13
    assert int(pesel[4:6]) > 0
    assert int(pesel[4:6]) < 32
    assert int(pesel[6:9]) > 0
    assert int(pesel[6:9]) < 1000
    assert int(pesel[9]) in (0, 2, 4, 6, 8) or int(pesel[9]) in (1, 3, 5, 7, 9)


# Generated at 2022-06-17 21:42:08.908409
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:42:10.054138
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:42:12.778735
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:42:15.499116
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:42:17.057938
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:42:23.688047
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) <= 12
    assert int(pesel[4:6]) <= 31
    assert int(pesel[6:9]) <= 999
    assert int(pesel[9]) <= 9
    assert int(pesel[10]) <= 9


# Generated at 2022-06-17 21:42:34.197924
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel(birth_date=Datetime().datetime(2000, 2000), gender=Gender.MALE)
    assert len(pesel) == 11
    assert pesel[-1] in ('1', '3', '5', '7', '9')


# Generated at 2022-06-17 21:42:37.536558
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    p = PolandSpecProvider()
    assert len(p.pesel()) == 11
    assert p.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.MALE)
    assert p.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.FEMALE)
    assert p.pesel(birth_date=Datetime().datetime(1940, 2018))
    assert p.pesel()


# Generated at 2022-06-17 21:42:40.166872
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:42:50.289221
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test pesel method of class PolandSpecProvider."""
    from mimesis.enums import Gender
    from mimesis.providers import Datetime
    from mimesis.providers.poland import PolandSpecProvider
    from mimesis.typing import DateTime

    poland_provider = PolandSpecProvider()
    pesel = poland_provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()

    date_object = Datetime().datetime(1940, 2018)
    pesel = poland_provider.pesel(date_object)
    assert len(pesel) == 11
    assert pesel.isdigit()

    pesel = poland_provider.pesel(gender=Gender.MALE)
    assert len(pesel) == 11

# Generated at 2022-06-17 21:42:56.871881
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) <= 12
    assert int(pesel[4:6]) <= 31
    assert int(pesel[0:2]) >= 40


# Generated at 2022-06-17 21:43:05.949300
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel(birth_date=Datetime().datetime(1980, 1, 1), gender=Gender.MALE)
    assert len(pesel) == 11
    assert pesel[-1] in ['1', '3', '5', '7', '9']
    assert int(pesel[:2]) in range(80, 100)
    assert int(pesel[2:4]) in range(1, 13)
    assert int(pesel[4:6]) in range(1, 32)
    assert int(pesel[6:9]) in range(0, 1000)
    assert int(pesel[9]) in range(0, 10)
    assert int(pesel[10]) in range(0, 10)


# Generated at 2022-06-17 21:43:16.027372
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) <= 12
    assert int(pesel[4:6]) <= 31
    assert int(pesel[-1]) <= 9
    assert int(pesel[-2]) <= 9
    assert int(pesel[-3]) <= 9
    assert int(pesel[-4]) <= 9
    assert int(pesel[-5]) <= 9
    assert int(pesel[-6]) <= 9
    assert int(pesel[-7]) <= 9
    assert int(pesel[-8]) <= 9
    assert int(pesel[-9]) <= 9


# Generated at 2022-06-17 21:43:24.755238
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) <= 12
    assert int(pesel[4:6]) <= 31
    assert int(pesel[0:2]) <= 99
    assert int(pesel[9]) % 2 == 0 or int(pesel[9]) % 2 == 1


# Generated at 2022-06-17 21:43:27.115251
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert provider.validate_pesel(pesel)


# Generated at 2022-06-17 21:43:29.761720
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    p = PolandSpecProvider()
    assert len(p.pesel()) == 11


# Generated at 2022-06-17 21:45:55.357587
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    assert provider.pesel() == '92010101234'

# Generated at 2022-06-17 21:46:06.035276
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test for method pesel of class PolandSpecProvider"""
    from mimesis.providers.person import Person
    from mimesis.enums import Gender
    from mimesis.builtins.poland import PolandSpecProvider
    from mimesis.typing import Seed
    from datetime import datetime
    import re
    import pytest
    import random

    # Test for method pesel of class PolandSpecProvider
    # with gender = None
    # and birth_date = None
    # and seed = None
    # and locale = 'pl'
    # and gender = None
    # and birth_date = None
    # and seed = None
    # and locale = 'pl'
    # and gender = None
    # and birth_date = None
    # and seed = None
    # and locale = 'pl'
    # and gender

# Generated at 2022-06-17 21:46:12.816111
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test pesel method of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) in range(1, 13)
    assert int(pesel[4:6]) in range(1, 32)
    assert int(pesel[6:9]) in range(1, 1000)
    assert int(pesel[9]) in range(10)
    assert int(pesel[10]) in range(10)
