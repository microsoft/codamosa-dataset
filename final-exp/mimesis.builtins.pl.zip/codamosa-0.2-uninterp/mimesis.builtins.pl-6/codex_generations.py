

# Generated at 2022-06-17 21:41:46.063005
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()

# Generated at 2022-06-17 21:41:48.952672
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:41:53.435750
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    assert provider.pesel() == '94101012345'
    assert provider.pesel(birth_date=Datetime().datetime(1940, 2018)) == '94101012345'
    assert provider.pesel(gender=Gender.MALE) == '94101012345'
    assert provider.pesel(gender=Gender.FEMALE) == '94101012345'


# Generated at 2022-06-17 21:42:04.787994
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from datetime import datetime
    from mimesis.enums import Gender
    from mimesis.providers.person.pl import PolandSpecProvider

    poland_provider = PolandSpecProvider()
    pesel = poland_provider.pesel(datetime(1940, 1, 1), Gender.MALE)
    assert len(pesel) == 11
    assert pesel[0] == '4'
    assert pesel[1] == '0'
    assert pesel[2] == '0'
    assert pesel[3] == '1'
    assert pesel[4] == '0'
    assert pesel[5] == '1'
    assert pesel[6] == '0'
    assert pesel[7] == '1'

# Generated at 2022-06-17 21:42:13.204682
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) <= 12
    assert int(pesel[4:6]) <= 31
    assert int(pesel[6:9]) <= 999
    assert int(pesel[9]) <= 9
    assert int(pesel[10]) <= 9


# Generated at 2022-06-17 21:42:15.500589
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:42:25.081909
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from datetime import datetime
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.providers.poland import PolandSpecProvider
    from mimesis.typing import DateTime
    from mimesis.utils import random_datetime
    from mimesis.builtins.poland import PolandSpecProvider as PolandSpecProviderBase

    p = Person('pl')
    pl = PolandSpecProvider()
    pl_base = PolandSpecProviderBase()
    gender = p.gender()
    birth_date = random_datetime(start=datetime(1940, 1, 1),
                                 end=datetime(2018, 1, 1))

# Generated at 2022-06-17 21:42:28.853158
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()

# Generated at 2022-06-17 21:42:39.941670
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.MALE)
    assert len(pesel) == 11
    assert pesel[-1] in ('1', '3', '5', '7', '9')
    assert pesel[-2] in ('0', '2', '4', '6', '8')
    assert pesel[-3] in ('0', '1', '2', '3', '4', '5', '6', '7', '8', '9')
    assert pesel[-4] in ('0', '1', '2', '3', '4', '5', '6', '7', '8', '9')
    assert pes

# Generated at 2022-06-17 21:42:47.843588
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) <= 12
    assert int(pesel[4:6]) <= 31
    assert int(pesel[0:2]) >= 40
    assert int(pesel[0:2]) <= 99
    assert int(pesel[9]) % 2 == 0


# Generated at 2022-06-17 21:43:12.086444
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) <= 12
    assert int(pesel[4:6]) <= 31


# Generated at 2022-06-17 21:43:17.069143
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    p = PolandSpecProvider()
    pesel = p.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) <= 12
    assert int(pesel[4:6]) <= 31
    assert int(pesel[0:2]) >= 40
    assert int(pesel[0:2]) <= 99
    assert int(pesel[9]) % 2 == 0


# Generated at 2022-06-17 21:43:18.976405
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert provider.validate_pesel(pesel)


# Generated at 2022-06-17 21:43:20.396441
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:43:29.036799
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from mimesis.enums import Gender
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.person import Person
    from mimesis.providers.poland import PolandSpecProvider
    from mimesis.typing import DateTime

    poland = PolandSpecProvider()
    person = Person('pl')
    datetime = Datetime('pl')
    birth_date = datetime.datetime(1940, 2018)
    gender = Gender.MALE
    pesel = poland.pesel(birth_date, gender)
    assert len(pesel) == 11
    assert pesel[0:2] == str(birth_date.date().year)[-2:]

# Generated at 2022-06-17 21:43:39.054295
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    assert provider.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.MALE) == '94061209871'
    assert provider.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.FEMALE) == '94061209872'
    assert provider.pesel(birth_date=Datetime().datetime(1940, 2018)) == '94061209873'
    assert provider.pesel(birth_date=Datetime().datetime(1940, 2018)) == '94061209874'
    assert provider.pesel(birth_date=Datetime().datetime(1940, 2018)) == '94061209875'
   

# Generated at 2022-06-17 21:43:49.510626
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from datetime import datetime
    from mimesis.enums import Gender
    from mimesis.providers import PolandSpecProvider
    from mimesis.typing import DateTime

    pl = PolandSpecProvider()
    pesel = pl.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()

    pesel = pl.pesel(birth_date=datetime(2000, 1, 1))
    assert len(pesel) == 11
    assert pesel.isdigit()

    pesel = pl.pesel(birth_date=DateTime(2000, 1, 1))
    assert len(pesel) == 11
    assert pesel.isdigit()

    pesel = pl.pesel(gender=Gender.MALE)


# Generated at 2022-06-17 21:44:01.581946
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    assert provider.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.MALE) == '89040404567'
    assert provider.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.FEMALE) == '89040404568'
    assert provider.pesel(birth_date=Datetime().datetime(1940, 2018)) == '89040404569'
    assert provider.pesel(gender=Gender.MALE) == '89040124563'
    assert provider.pesel(gender=Gender.FEMALE) == '89040124564'
    assert provider.pesel() == '89040124565'


# Generated at 2022-06-17 21:44:11.201956
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    from mimesis.enums import Gender
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.poland import PolandSpecProvider
    from mimesis.typing import DateTime
    from datetime import datetime
    import re

    poland_provider = PolandSpecProvider()
    date_object = Datetime().datetime(1940, 2018)
    pesel = poland_provider.pesel(date_object, Gender.MALE)
    assert re.match(r'^\d{11}$', pesel)
    assert len(pesel) == 11
    assert int(pesel[0]) in [1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-17 21:44:17.946511
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from datetime import datetime
    from mimesis.enums import Gender
    from mimesis.providers.poland import PolandSpecProvider

    p = PolandSpecProvider()
    pesel = p.pesel(birth_date=datetime(1990, 1, 1), gender=Gender.MALE)
    assert pesel == '90010200001'
    pesel = p.pesel(birth_date=datetime(1990, 1, 1), gender=Gender.FEMALE)
    assert pesel == '90010200002'
    pesel = p.pesel(birth_date=datetime(1990, 1, 1))
    assert pesel == '90010200003'
    pesel = p.pesel()
    assert len(pesel) == 11

#