

# Generated at 2022-06-17 21:41:52.399757
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test for method pesel of class PolandSpecProvider."""
    from mimesis.enums import Gender
    from mimesis.providers import Datetime
    from mimesis.providers.poland import PolandSpecProvider
    from mimesis.typing import DateTime
    from datetime import datetime

    # Test with default values
    poland = PolandSpecProvider()
    pesel = poland.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()

    # Test with custom values
    date_object = Datetime().datetime(1940, 2018)
    pesel = poland.pesel(birth_date=date_object, gender=Gender.MALE)
    assert len(pesel) == 11
    assert pesel.isdigit()

    # Test with custom values
   

# Generated at 2022-06-17 21:41:56.983507
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    pesel = p.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert p.validate_pesel(pesel)


# Generated at 2022-06-17 21:42:08.029406
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from mimesis.builtins import PolandSpecProvider
    from mimesis.enums import Gender
    from mimesis.typing import DateTime
    from datetime import datetime

    poland_provider = PolandSpecProvider()
    pesel = poland_provider.pesel(birth_date=datetime(2000, 1, 1), gender=Gender.MALE)
    assert len(pesel) == 11
    assert pesel[0] == '0'
    assert pesel[1] == '0'
    assert pesel[2] == '0'
    assert pesel[3] == '1'
    assert pesel[4] == '0'
    assert pesel[5] == '1'
    assert pesel[6] == '0'
   

# Generated at 2022-06-17 21:42:18.878260
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from mimesis.enums import Gender
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.person import Person
    from mimesis.providers.poland import PolandSpecProvider
    from mimesis.typing import DateTime
    from datetime import datetime
    import re

    poland_provider = PolandSpecProvider()
    person_provider = Person('pl')
    datetime_provider = Datetime('pl')

    # Test pesel with gender
    gender = Gender.MALE
    pesel = poland_provider.pesel(gender=gender)
    assert re.match(r'^[0-9]{11}$', pesel)

# Generated at 2022-06-17 21:42:27.140992
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    pesel = p.pesel()
    assert len(pesel) == 11

# Generated at 2022-06-17 21:42:33.903861
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from datetime import datetime
    from mimesis.enums import Gender
    from mimesis.providers import PolandSpecProvider
    from mimesis.typing import DateTime

    poland_provider = PolandSpecProvider()
    pesel = poland_provider.pesel(birth_date=datetime(2000, 1, 1),
                                  gender=Gender.MALE)
    assert pesel == '00010112345'

# Generated at 2022-06-17 21:42:39.735057
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    assert provider.pesel() == '97061405871'
    assert provider.pesel(gender=Gender.MALE) == '97061405871'
    assert provider.pesel(gender=Gender.FEMALE) == '97061405871'
    assert provider.pesel(birth_date=Datetime().datetime(2000, 2018)) == '97061405871'
    assert provider.pesel(birth_date=Datetime().datetime(2000, 2018), gender=Gender.MALE) == '97061405871'
    assert provider.pesel(birth_date=Datetime().datetime(2000, 2018), gender=Gender.FEMALE) == '97061405871'

# Unit

# Generated at 2022-06-17 21:42:45.035889
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from datetime import datetime
    from mimesis.enums import Gender
    from mimesis.providers import PolandSpecProvider
    p = PolandSpecProvider()
    pesel = p.pesel(birth_date=datetime(2000, 1, 1), gender=Gender.MALE)
    assert pesel == '00010112345'
    pesel = p.pesel(birth_date=datetime(2000, 1, 1), gender=Gender.FEMALE)
    assert pesel == '00010112340'
    pesel = p.pesel(birth_date=datetime(2000, 1, 1))
    assert pesel in ('00010112345', '00010112340')
    pesel = p.pesel()
    assert len(pesel) == 11

# Generated at 2022-06-17 21:42:46.942738
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:42:55.587334
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    assert provider.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.MALE) == '94082700100'
    assert provider.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.FEMALE) == '94082700200'
    assert provider.pesel(birth_date=Datetime().datetime(1940, 2018)) == '94082700300'
    assert provider.pesel(birth_date=Datetime().datetime(1940, 2018)) == '94082700400'
    assert provider.pesel(birth_date=Datetime().datetime(1940, 2018)) == '94082700500'

# Generated at 2022-06-17 21:43:03.506963
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test pesel method."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()

# Generated at 2022-06-17 21:43:07.135383
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) in range(1, 13)
    assert int(pesel[4:6]) in range(1, 32)
    assert int(pesel[6:9]) in range(0, 1000)
    assert int(pesel[9]) in range(0, 10)
    assert int(pesel[10]) in range(0, 10)


# Generated at 2022-06-17 21:43:16.508593
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    from mimesis.providers.poland import PolandSpecProvider
    from mimesis.enums import Gender

    poland_provider = PolandSpecProvider()
    pesel = poland_provider.pesel(gender=Gender.MALE)
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[9]) % 2 == 1

    pesel = poland_provider.pesel(gender=Gender.FEMALE)
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[9]) % 2 == 0

    pesel = poland_provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()

# Generated at 2022-06-17 21:43:17.821072
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()

# Generated at 2022-06-17 21:43:22.999406
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from mimesis.providers.datetime import Datetime
    from mimesis.enums import Gender
    from mimesis.builtins import PolandSpecProvider
    from datetime import datetime
    from mimesis.typing import DateTime

    poland_provider = PolandSpecProvider()
    pesel = poland_provider.pesel(birth_date=DateTime(datetime(2000, 1, 1)), gender=Gender.MALE)
    assert len(pesel) == 11
    assert pesel[0:2] == '00'
    assert pesel[2:4] == '01'
    assert pesel[4:6] == '01'
    assert pesel[6:9] == '000'

# Generated at 2022-06-17 21:43:29.655440
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    import datetime
    from mimesis.enums import Gender
    from mimesis.providers import PolandSpecProvider
    from mimesis.typing import DateTime

    p = PolandSpecProvider()
    pesel = p.pesel(birth_date=DateTime(datetime.datetime(2000, 1, 1)),
                    gender=Gender.MALE)
    assert len(pesel) == 11
    assert pesel[0:2] == '00'
    assert pesel[2:4] == '01'
    assert pesel[4:6] == '01'
    assert pesel[6:9] == '000'
    assert pesel[9] == '1'
    assert pesel[10] == '0'

    pesel = p.pesel

# Generated at 2022-06-17 21:43:32.966273
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:43:35.493201
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:43:41.159835
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) <= 12
    assert int(pesel[4:6]) <= 31
    assert int(pesel[6:9]) <= 999
    assert int(pesel[9]) <= 9
    assert int(pesel[10]) <= 9


# Generated at 2022-06-17 21:43:50.956810
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from mimesis.enums import Gender
    from mimesis.providers import PolandSpecProvider
    from mimesis.typing import DateTime
    from datetime import datetime
    poland_provider = PolandSpecProvider()
    pesel = poland_provider.pesel(birth_date=datetime(2000, 1, 1), gender=Gender.MALE)
    assert len(pesel) == 11
    assert pesel[-1] in ('1', '3', '5', '7', '9')
    pesel = poland_provider.pesel(birth_date=datetime(2000, 1, 1), gender=Gender.FEMALE)
    assert len(pesel) == 11

# Generated at 2022-06-17 21:44:09.501281
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    assert PolandSpecProvider().pesel(birth_date=Datetime().datetime(2000, 2000), gender=Gender.MALE) == '00081701097'

# Generated at 2022-06-17 21:44:12.658317
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert provider.validate_pesel(pesel)



# Generated at 2022-06-17 21:44:16.501192
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    p = PolandSpecProvider()
    assert len(p.pesel()) == 11
    assert len(p.pesel(gender=Gender.MALE)) == 11
    assert len(p.pesel(gender=Gender.FEMALE)) == 11
    assert len(p.pesel(birth_date=Datetime().datetime(2000, 2000))) == 11


# Generated at 2022-06-17 21:44:18.116135
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:44:20.063813
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:44:24.637787
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from datetime import datetime
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.providers.poland import PolandSpecProvider
    from mimesis.providers.address import Address
    from mimesis.providers.code import Code
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.internet import Internet
    from mimesis.providers.misc import Misc
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.payment import Payment
    from mimesis.providers.person import Person
    from mimesis.providers.science import Science
    from mimesis.providers.text import Text

# Generated at 2022-06-17 21:44:26.720188
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11


# Generated at 2022-06-17 21:44:29.151014
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.MALE)
    assert len(pesel) == 11


# Generated at 2022-06-17 21:44:35.614828
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) <= 12
    assert int(pesel[4:6]) <= 31
    assert int(pesel[6:9]) <= 999
    assert int(pesel[9]) <= 9
    assert int(pesel[10]) <= 9


# Generated at 2022-06-17 21:44:37.700162
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()

