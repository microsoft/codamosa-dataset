

# Generated at 2022-06-17 21:41:53.015391
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    assert provider.pesel(gender=Gender.MALE) == '97041607822'
    assert provider.pesel(gender=Gender.FEMALE) == '97041607822'
    assert provider.pesel() == '97041607822'
    assert provider.pesel(gender=Gender.MALE) == '97041607822'
    assert provider.pesel(gender=Gender.FEMALE) == '97041607822'
    assert provider.pesel() == '97041607822'
    assert provider.pesel(gender=Gender.MALE) == '97041607822'

# Generated at 2022-06-17 21:42:04.291003
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    import datetime
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.providers.poland import PolandSpecProvider

    p = Person('pl')
    pl = PolandSpecProvider()
    pesel = pl.pesel(birth_date=datetime.datetime(1990, 1, 1), gender=Gender.MALE)
    assert len(pesel) == 11
    assert pesel[0:2] == '90'
    assert pesel[2:4] == '01'
    assert pesel[4:6] == '01'
    assert pesel[6:9] == '000'
    assert pesel[9] in ['1', '3', '5', '7', '9']
   

# Generated at 2022-06-17 21:42:16.203453
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from datetime import datetime
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    p = Person('pl')
    pesel = p.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()

    pesel = p.pesel(birth_date=datetime(2000, 1, 1), gender=Gender.MALE)
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert pesel[9] in ('1', '3', '5', '7', '9')

    pesel = p.pesel(birth_date=datetime(2000, 1, 1), gender=Gender.FEMALE)
    assert len(pesel) == 11


# Generated at 2022-06-17 21:42:23.815316
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) in range(1, 13)
    assert int(pesel[4:6]) in range(1, 32)
    assert int(pesel[6:9]) in range(0, 1000)
    assert int(pesel[9]) in range(0, 10)
    assert int(pesel[10]) in range(0, 10)


# Generated at 2022-06-17 21:42:27.307635
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    assert len(provider.pesel()) == 11
    assert len(provider.pesel(gender=Gender.MALE)) == 11
    assert len(provider.pesel(gender=Gender.FEMALE)) == 11
    assert len(provider.pesel(birth_date=Datetime().datetime(1940, 2018))) == 11


# Generated at 2022-06-17 21:42:33.692689
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    assert len(provider.pesel()) == 11
    assert len(provider.pesel(birth_date=Datetime().datetime(1940, 2018))) == 11
    assert len(provider.pesel(gender=Gender.MALE)) == 11
    assert len(provider.pesel(gender=Gender.FEMALE)) == 11


# Generated at 2022-06-17 21:42:41.310001
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    assert provider.pesel()
    assert provider.pesel(gender=Gender.MALE)
    assert provider.pesel(gender=Gender.FEMALE)
    assert provider.pesel(birth_date=Datetime().datetime(1940, 2018))
    assert provider.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.MALE)
    assert provider.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.FEMALE)

# Generated at 2022-06-17 21:42:50.552200
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    from mimesis.enums import Gender
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.person import Person
    from mimesis.providers.poland import PolandSpecProvider
    from mimesis.typing import DateTime
    from datetime import datetime
    import re

    poland_provider = PolandSpecProvider()
    person_provider = Person('pl')
    datetime_provider = Datetime('pl')
    birth_date = datetime_provider.datetime(1940, 2018)
    gender = person_provider.gender()
    pesel = poland_provider.pesel(birth_date, gender)
    assert len(pesel) == 11

# Generated at 2022-06-17 21:43:02.460697
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from datetime import datetime
    from mimesis.enums import Gender
    from mimesis.providers.poland import PolandSpecProvider
    poland_provider = PolandSpecProvider()
    pesel = poland_provider.pesel(birth_date=datetime(2000, 1, 1), gender=Gender.MALE)
    assert len(pesel) == 11
    assert pesel[0:2] == '00'
    assert pesel[2:4] == '01'
    assert pesel[4:6] == '01'
    assert pesel[6:9] == '000'
    assert pesel[9] in ['1', '3', '5', '7', '9']
    assert pesel[10] == '1'

#

# Generated at 2022-06-17 21:43:05.265162
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from datetime import datetime
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    p = Person('pl')
    pesel = p.pesel(datetime(2000, 1, 1), Gender.MALE)
    assert pesel == '20000100912'

# Generated at 2022-06-17 21:43:19.382836
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:43:21.594626
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    assert len(p.pesel()) == 11


# Generated at 2022-06-17 21:43:25.510490
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()



# Generated at 2022-06-17 21:43:30.569106
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from mimesis.enums import Gender
    from mimesis.providers import Datetime
    from mimesis.providers.poland import PolandSpecProvider
    from mimesis.typing import DateTime

    p = PolandSpecProvider()
    pesel = p.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()

    pesel = p.pesel(birth_date=Datetime().datetime(1940, 2018))
    assert len(pesel) == 11
    assert pesel.isdigit()

    pesel = p.pesel(gender=Gender.MALE)
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:43:34.080553
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:43:43.914375
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    p = PolandSpecProvider()
    assert len(p.pesel()) == 11
    assert p.pesel(birth_date=Datetime().datetime(2000, 2000), gender=Gender.MALE) == '00091201098'
    assert p.pesel(birth_date=Datetime().datetime(2000, 2000), gender=Gender.FEMALE) == '00091201096'
    assert p.pesel(birth_date=Datetime().datetime(2000, 2000), gender=Gender.UNKNOWN) == '00091201097'
    assert p.pesel(birth_date=Datetime().datetime(2000, 2000)) == '00091201097'

# Generated at 2022-06-17 21:43:46.988529
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:43:51.911456
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from mimesis.enums import Gender
    from mimesis.providers import Datetime
    from mimesis.providers.poland import PolandSpecProvider
    from mimesis.typing import DateTime
    from datetime import datetime
    from re import match
    poland_spec_provider = PolandSpecProvider()
    pesel = poland_spec_provider.pesel()
    assert match(r'\d{11}', pesel)
    pesel = poland_spec_provider.pesel(gender=Gender.MALE)
    assert match(r'\d{11}', pesel)
    pesel = poland_spec_provider.pesel(gender=Gender.FEMALE)

# Generated at 2022-06-17 21:44:00.318378
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) <= 12
    assert int(pesel[4:6]) <= 31
    assert int(pesel[0:2]) >= 40
    assert int(pesel[0:2]) <= 99
    assert int(pesel[9]) % 2 == 0


# Generated at 2022-06-17 21:44:01.937061
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    assert provider.pesel() == '98072901094'


# Generated at 2022-06-17 21:44:21.533276
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) <= 12
    assert int(pesel[4:6]) <= 31
    assert int(pesel[0:2]) in range(18, 23)


# Generated at 2022-06-17 21:44:25.889993
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) in range(1, 13)
    assert int(pesel[4:6]) in range(1, 32)
    assert int(pesel[6:9]) in range(0, 1000)
    assert int(pesel[9]) in range(0, 10)
    assert int(pesel[10]) in range(0, 10)


# Generated at 2022-06-17 21:44:29.116246
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:44:31.950284
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:44:35.744768
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert provider.validate_pesel(pesel)



# Generated at 2022-06-17 21:44:40.919377
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from datetime import datetime
    from mimesis.enums import Gender
    from mimesis.providers.person.poland import PolandSpecProvider
    from mimesis.providers.person.poland import PolandPerson
    from mimesis.providers.person.poland import PolandAddress
    from mimesis.providers.person.poland import PolandBusiness
    from mimesis.providers.person.poland import PolandPayment
    from mimesis.providers.person.poland import PolandCode
    from mimesis.providers.person.poland import PolandSpecProvider
    from mimesis.providers.person.poland import PolandText
    from mimesis.providers.person.poland import PolandTime

# Generated at 2022-06-17 21:44:47.230609
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) <= 12
    assert int(pesel[4:6]) <= 31
    assert int(pesel[6:9]) <= 999
    assert int(pesel[9]) <= 9
    assert int(pesel[10]) <= 9


# Generated at 2022-06-17 21:44:49.925597
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) <= 12
    assert int(pesel[4:6]) <= 31


# Generated at 2022-06-17 21:45:02.659179
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from datetime import datetime
    from mimesis.enums import Gender
    from mimesis.providers.poland import PolandSpecProvider
    from mimesis.typing import DateTime
    from mimesis.builtins import PolandSpecProvider as PolandSpecProvider_
    from mimesis.builtins import PolandSpecProvider as PolandSpecProvider__
    from mimesis.builtins import PolandSpecProvider as PolandSpecProvider___
    from mimesis.builtins import PolandSpecProvider as PolandSpecProvider____
    from mimesis.builtins import PolandSpecProvider as PolandSpecProvider_____
    from mimesis.builtins import PolandSpecProvider as PolandSpecProvider______
    from mimesis.builtins import PolandSpecProvider as PolandSpecProvider_______
    from mimesis.builtins import PolandSpecProvider

# Generated at 2022-06-17 21:45:12.102322
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from datetime import datetime
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    p = Person('pl')
    pesel = p.pesel(datetime(2000, 1, 1), Gender.MALE)
    assert len(pesel) == 11
    assert pesel[0:2] == '00'
    assert pesel[2:4] == '01'
    assert pesel[4:6] == '01'
    assert pesel[6:9] == '000'
    assert pesel[9] in ('1', '3', '5', '7', '9')

# Generated at 2022-06-17 21:45:30.815667
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) <= 12
    assert int(pesel[4:6]) <= 31
    assert int(pesel[0:2]) >= 40
    assert int(pesel[0:2]) <= 99
    assert int(pesel[9]) % 2 == 0


# Generated at 2022-06-17 21:45:37.285408
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from datetime import datetime
    from mimesis.enums import Gender
    from mimesis.providers import PolandSpecProvider
    from mimesis.typing import DateTime

    p = PolandSpecProvider()
    pesel = p.pesel(birth_date=datetime(1990, 1, 1), gender=Gender.MALE)
    assert pesel == '90010391235'

    pesel = p.pesel(birth_date=datetime(1990, 1, 1), gender=Gender.FEMALE)
    assert pesel == '90010391234'

    pesel = p.pesel(birth_date=datetime(1990, 1, 1), gender=None)
    assert pesel == '90010391235'


# Generated at 2022-06-17 21:45:42.557719
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from datetime import datetime
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.providers.poland import PolandSpecProvider

    p = Person('pl')
    psp = PolandSpecProvider()
    pesel = psp.pesel(birth_date=datetime(2000, 1, 1), gender=Gender.MALE)
    assert len(pesel) == 11
    assert pesel[-1] in ('1', '3', '5', '7', '9')
    assert pesel[-2] in ('0', '2', '4', '6', '8')
    assert pesel[:2] == '00'
    assert pesel[2:4] == '01'

# Generated at 2022-06-17 21:45:49.211554
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    p = PolandSpecProvider()
    assert p.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.MALE) == '98081000123'
    assert p.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.FEMALE) == '98081000124'
    assert p.pesel(birth_date=Datetime().datetime(1940, 2018)) == '98081000125'
    assert p.pesel(gender=Gender.MALE) == '98081000126'
    assert p.pesel(gender=Gender.FEMALE) == '98081000127'
    assert p.pesel() == '98081000128'

# Unit test

# Generated at 2022-06-17 21:46:01.402783
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) in range(1, 13)
    assert int(pesel[4:6]) in range(1, 32)
    assert int(pesel[6:9]) in range(0, 1000)
    assert int(pesel[9]) in range(0, 10)
    assert int(pesel[10]) in range(0, 10)
    assert provider.validate_pesel(pesel)


# Generated at 2022-06-17 21:46:06.574083
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) in range(1, 13)
    assert int(pesel[4:6]) in range(1, 32)
    assert int(pesel[6:9]) in range(0, 1000)
    assert int(pesel[9]) in range(0, 10)
    assert int(pesel[10]) in range(0, 10)
    assert int(pesel[0:2]) in range(18, 100)


# Generated at 2022-06-17 21:46:14.875864
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from datetime import datetime
    from mimesis.enums import Gender
    from mimesis.providers.person.poland import PolandSpecProvider
    from mimesis.providers.person.poland import PolandSpecProvider
    from mimesis.providers.person.poland import PolandSpecProvider
    from mimesis.providers.person.poland import PolandSpecProvider
    from mimesis.providers.person.poland import PolandSpecProvider
    from mimesis.providers.person.poland import PolandSpecProvider
    from mimesis.providers.person.poland import PolandSpecProvider
    from mimesis.providers.person.poland import PolandSpecProvider
    from mimesis.providers.person.poland import PolandSpecProvider

# Generated at 2022-06-17 21:46:20.990905
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from datetime import datetime
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.providers.poland import PolandSpecProvider
    from mimesis.typing import DateTime
    from mimesis.utils import get_random_int

    poland_spec_provider = PolandSpecProvider()
    person = Person('pl')
    gender = Gender.MALE
    birth_date = datetime(1990, 1, 1)
    pesel = poland_spec_provider.pesel(birth_date, gender)
    assert len(pesel) == 11
    assert pesel[0:2] == '90'
    assert pesel[2:4] == '01'

# Generated at 2022-06-17 21:46:22.698552
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    pesel = PolandSpecProvider().pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:46:32.089681
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from mimesis.enums import Gender
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.person import Person
    from mimesis.providers.poland import PolandSpecProvider
    from mimesis.typing import DateTime
    from datetime import datetime
    from random import seed
    from unittest import TestCase

    class TestPolandSpecProvider(TestCase):
        """Test class PolandSpecProvider."""

        def setUp(self):
            """Initialize attributes."""
            self.seed = seed(42)
            self.poland = PolandSpecProvider(seed=self.seed)
            self.datetime = Datetime(seed=self.seed)
            self.person = Person(seed=self.seed)



# Generated at 2022-06-17 21:48:15.893902
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel(birth_date=Datetime().datetime(1990, 1, 1), gender=Gender.MALE)
    assert pesel == '90010101234'

# Generated at 2022-06-17 21:48:17.741378
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:48:20.303106
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test for method pesel of class PolandSpecProvider."""
    p = PolandSpecProvider()
    assert len(p.pesel()) == 11


# Generated at 2022-06-17 21:48:27.791059
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    assert provider.pesel() == '98071300982'
    assert provider.pesel(gender=Gender.MALE) == '98071300982'
    assert provider.pesel(gender=Gender.FEMALE) == '98071300982'
    assert provider.pesel(birth_date=Datetime().datetime(1990, 1, 1)) == '90010100982'
    assert provider.pesel(birth_date=Datetime().datetime(1990, 1, 1), gender=Gender.MALE) == '90010100982'
    assert provider.pesel(birth_date=Datetime().datetime(1990, 1, 1), gender=Gender.FEMALE) == '90010100982'


# Generated at 2022-06-17 21:48:31.025457
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[-1]) == provider.checksum(pesel[:-1], (9, 7, 3, 1, 9, 7, 3, 1, 9, 7))


# Generated at 2022-06-17 21:48:37.896610
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from datetime import datetime
    from mimesis.enums import Gender
    from mimesis.providers import PolandSpecProvider
    provider = PolandSpecProvider()
    pesel = provider.pesel(datetime(2000, 1, 1), Gender.MALE)
    assert pesel == '00010112345'
    pesel = provider.pesel(datetime(2000, 1, 1), Gender.FEMALE)
    assert pesel == '00010212345'
    pesel = provider.pesel(datetime(2000, 1, 1))
    assert pesel == '00010312345'
    pesel = provider.pesel()
    assert pesel == '00010412345'


# Generated at 2022-06-17 21:48:40.330681
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:48:42.282782
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:48:44.289466
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:48:56.352938
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from datetime import datetime
    from mimesis.enums import Gender
    from mimesis.providers.poland import PolandSpecProvider
    from mimesis.typing import DateTime

    p = PolandSpecProvider()
    pesel = p.pesel(birth_date=DateTime(datetime(2000, 1, 1)),
                    gender=Gender.MALE)
    assert pesel == '00110101001'
    pesel = p.pesel(birth_date=DateTime(datetime(2000, 1, 1)),
                    gender=Gender.FEMALE)
    assert pesel == '00110101000'
    pesel = p.pesel(birth_date=DateTime(datetime(2000, 1, 1)))