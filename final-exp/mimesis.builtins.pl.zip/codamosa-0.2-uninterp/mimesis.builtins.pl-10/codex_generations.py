

# Generated at 2022-06-17 21:41:53.620960
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) <= 12
    assert int(pesel[4:6]) <= 31
    assert int(pesel[6:9]) <= 999
    assert int(pesel[9]) in (0, 2, 4, 6, 8) or int(pesel[9]) in (1, 3, 5, 7, 9)
    assert int(pesel[10]) in range(10)


# Generated at 2022-06-17 21:41:57.956784
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:42:01.862928
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:42:05.176165
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    p = PolandSpecProvider()
    pesel = p.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:42:08.557674
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:42:19.370205
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    assert provider.pesel(birth_date=Datetime().datetime(2000, 2018), gender=Gender.MALE) == '00120101234'
    assert provider.pesel(birth_date=Datetime().datetime(2000, 2018), gender=Gender.FEMALE) == '00120101234'
    assert provider.pesel(birth_date=Datetime().datetime(2000, 2018)) == '00120101234'
    assert provider.pesel(birth_date=Datetime().datetime(2000, 2018)) == '00120101234'
    assert provider.pesel(birth_date=Datetime().datetime(2000, 2018)) == '00120101234'

# Generated at 2022-06-17 21:42:27.363309
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test pesel method of class PolandSpecProvider."""
    from datetime import datetime
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.providers.poland import PolandSpecProvider

    p = Person('pl')
    pl = PolandSpecProvider()
    pesel = pl.pesel(birth_date=datetime(2000, 1, 1), gender=Gender.MALE)
    assert len(pesel) == 11
    assert pesel[0:2] == '00'
    assert pesel[2:4] == '01'
    assert pesel[4:6] == '01'
    assert pesel[6:9] == '000'
    assert pesel[9] in ('1', '3', '5', '7', '9')
   

# Generated at 2022-06-17 21:42:38.934611
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from mimesis.enums import Gender
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.poland import PolandSpecProvider
    from mimesis.typing import DateTime

    poland_provider = PolandSpecProvider()
    pesel = poland_provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    pesel = poland_provider.pesel(gender=Gender.MALE)
    assert len(pesel) == 11
    assert pesel.isdigit()
    pesel = poland_provider.pesel(gender=Gender.FEMALE)
    assert len(pesel) == 11
    assert pesel.isdigit()
    date

# Generated at 2022-06-17 21:42:47.856914
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) <= 12
    assert int(pesel[4:6]) <= 31
    assert int(pesel[6:9]) <= 999
    assert int(pesel[9]) in [0, 2, 4, 6, 8]
    assert int(pesel[10]) in range(10)


# Generated at 2022-06-17 21:42:50.522095
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) <= 12
    assert int(pesel[4:6]) <= 31


# Generated at 2022-06-17 21:43:06.129499
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    from datetime import datetime
    from mimesis.enums import Gender
    from mimesis.providers.person.poland import PolandSpecProvider
    from mimesis.providers.person.poland import PolandSpecProvider
    from mimesis.providers.person.poland import PolandSpecProvider
    from mimesis.providers.person.poland import PolandSpecProvider
    from mimesis.providers.person.poland import PolandSpecProvider
    from mimesis.providers.person.poland import PolandSpecProvider
    from mimesis.providers.person.poland import PolandSpecProvider
    from mimesis.providers.person.poland import PolandSpecProvider
    from mimesis.providers.person.poland import PolandSpecProvider

# Generated at 2022-06-17 21:43:16.186878
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from mimesis.builtins import PolandSpecProvider
    from mimesis.enums import Gender
    from mimesis.typing import DateTime
    from datetime import datetime
    p = PolandSpecProvider()
    assert p.pesel(birth_date=datetime(2000, 1, 1), gender=Gender.MALE) == '00021013536'
    assert p.pesel(birth_date=datetime(2000, 1, 1), gender=Gender.FEMALE) == '00021013530'
    assert p.pesel(birth_date=datetime(2000, 1, 1)) == '00021013536'
    assert p.pesel(gender=Gender.MALE) == '9808013536'

# Generated at 2022-06-17 21:43:20.363886
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:43:25.053219
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    from mimesis.enums import Gender
    from mimesis.providers import Datetime
    from mimesis.providers.poland import PolandSpecProvider
    from mimesis.typing import DateTime
    from datetime import datetime
    from random import randint
    from unittest import TestCase

    class TestPolandSpecProvider(TestCase):
        """Test class for method pesel of class PolandSpecProvider."""

        def setUp(self):
            """Initialize attributes."""
            self.provider = PolandSpecProvider()
            self.date_object = Datetime().datetime(1940, 2018)
            self.gender = Gender.MALE
            self.pesel = self.provider.pesel(self.date_object, self.gender)

# Generated at 2022-06-17 21:43:29.012801
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    from mimesis.enums import Gender
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.person import Person

    p = Person('pl')
    dt = Datetime('pl')
    pesel = p.pesel(dt.datetime(1940, 2018), Gender.MALE)
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:43:32.973039
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test pesel method of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:43:33.946439
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:43:43.777860
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from mimesis.providers.datetime import Datetime
    from mimesis.enums import Gender
    import datetime
    import random
    import re
    import time

    random.seed(time.time())
    pesel_provider = PolandSpecProvider()
    pesel_provider.seed(random.randint(0, 100000))
    pesel_provider.reset_seed()
    pesel_provider.seed(random.randint(0, 100000))
    pesel_provider.reset_seed()
    pesel_provider.seed(random.randint(0, 100000))
    pesel_provider.reset_seed()
    pesel_provider.seed(random.randint(0, 100000))
    pesel_

# Generated at 2022-06-17 21:43:51.860541
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test pesel method of class PolandSpecProvider."""
    from mimesis.enums import Gender
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.person import Person
    from mimesis.providers.poland import PolandSpecProvider

    poland_provider = PolandSpecProvider()
    person_provider = Person('pl')
    datetime_provider = Datetime('pl')

    # Test pesel method with gender
    gender = Gender.MALE
    pesel = poland_provider.pesel(gender=gender)
    assert len(pesel) == 11
    assert int(pesel[9]) % 2 == 1

    gender = Gender.FEMALE
    pesel = poland_provider.pesel(gender=gender)

# Generated at 2022-06-17 21:44:02.311973
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from datetime import datetime
    from mimesis.enums import Gender
    from mimesis.providers.poland import PolandSpecProvider

    poland_provider = PolandSpecProvider()
    pesel = poland_provider.pesel(datetime(2000, 1, 1), Gender.MALE)
    assert len(pesel) == 11
    assert pesel[-2] in ('1', '3', '5', '7', '9')
    assert pesel[-1] == '2'
    pesel = poland_provider.pesel(datetime(2000, 1, 1), Gender.FEMALE)
    assert len(pesel) == 11

# Generated at 2022-06-17 21:44:15.787154
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test for method pesel of class PolandSpecProvider."""
    p = PolandSpecProvider()
    assert len(p.pesel()) == 11
    assert len(p.pesel(gender=Gender.MALE)) == 11
    assert len(p.pesel(gender=Gender.FEMALE)) == 11
    assert len(p.pesel(birth_date=Datetime().datetime(1940, 2018))) == 11


# Generated at 2022-06-17 21:44:19.710160
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test for method pesel of class PolandSpecProvider."""
    p = PolandSpecProvider()
    pesel = p.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) <= 12
    assert int(pesel[4:6]) <= 31
    assert int(pesel[6:9]) <= 999
    assert int(pesel[9]) <= 9
    assert int(pesel[10]) <= 9


# Generated at 2022-06-17 21:44:21.563680
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()

# Generated at 2022-06-17 21:44:22.935944
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:44:28.522072
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test pesel method of class PolandSpecProvider."""
    p = PolandSpecProvider()
    assert len(p.pesel()) == 11
    assert len(p.pesel(gender=Gender.MALE)) == 11
    assert len(p.pesel(gender=Gender.FEMALE)) == 11
    assert len(p.pesel(birth_date=Datetime().datetime(2000, 2018))) == 11


# Generated at 2022-06-17 21:44:34.475663
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) <= 12
    assert int(pesel[4:6]) <= 31
    assert int(pesel[6:9]) <= 999
    assert int(pesel[9]) <= 9

# Generated at 2022-06-17 21:44:36.025906
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()

# Generated at 2022-06-17 21:44:38.060875
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:44:45.542318
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) <= 12
    assert int(pesel[4:6]) <= 31
    assert int(pesel[6:9]) <= 999
    assert int(pesel[9]) <= 9
    assert int(pesel[10]) <= 9


# Generated at 2022-06-17 21:44:48.052311
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:45:05.415657
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    from mimesis.enums import Gender
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.person import Person
    from mimesis.providers.poland import PolandSpecProvider
    from mimesis.typing import DateTime
    import datetime
    import re
    import unittest

    class TestPolandSpecProviderPesel(unittest.TestCase):
        """Unit test for method pesel of class PolandSpecProvider."""

        def setUp(self):
            """Initialize attributes."""
            self.poland = PolandSpecProvider()
            self.person = Person('pl')
            self.datetime = Datetime('pl')


# Generated at 2022-06-17 21:45:12.462899
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    assert provider.pesel() == '94052800300'
    assert provider.pesel(gender=Gender.MALE) == '94052800300'
    assert provider.pesel(gender=Gender.FEMALE) == '94052800300'
    assert provider.pesel(birth_date='2000-01-01') == '00010101100'
    assert provider.pesel(birth_date='2000-01-01', gender=Gender.MALE) == '00010101100'
    assert provider.pesel(birth_date='2000-01-01', gender=Gender.FEMALE) == '00010101100'


# Generated at 2022-06-17 21:45:23.428995
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) <= 12
    assert int(pesel[4:6]) <= 31
    assert int(pesel[2:4]) in (1, 3, 5, 7, 8, 10, 12) or int(pesel[4:6]) <= 30
    assert int(pesel[2:4]) != 2 or int(pesel[4:6]) <= 28
    assert int(pesel[2:4]) != 2 or int(pesel[4:6]) <= 29 or int(pesel[0:2]) % 4 == 0


# Generated at 2022-06-17 21:45:26.606511
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert type(pesel) == str


# Generated at 2022-06-17 21:45:29.636992
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:45:31.913578
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    pesel = PolandSpecProvider().pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()

# Generated at 2022-06-17 21:45:33.700592
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:45:38.126596
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) <= 12
    assert int(pesel[4:6]) <= 31
    assert int(pesel[0:2]) <= 99
    assert int(pesel[6:9]) <= 999
    assert int(pesel[9:11]) <= 99
    assert int(pesel[10]) <= 9


# Generated at 2022-06-17 21:45:46.248176
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from datetime import datetime
    import pytest
    from mimesis.enums import Gender
    from mimesis.providers.person.poland import PolandSpecProvider
    from mimesis.typing import DateTime

    poland_provider = PolandSpecProvider()
    pesel = poland_provider.pesel(datetime(2000, 1, 1), Gender.MALE)
    assert len(pesel) == 11
    assert pesel[0:2] == '00'
    assert pesel[2:4] == '01'
    assert pesel[4:6] == '01'
    assert pesel[6:9] == '000'
    assert pesel[9] in ('1', '3', '5', '7', '9')
   

# Generated at 2022-06-17 21:45:50.600476
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    pesel = p.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.MALE)
    assert len(pesel) == 11
    assert pesel[-1] in ['1', '3', '5', '7', '9']
    pesel = p.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.FEMALE)
    assert len(pesel) == 11
    assert pesel[-1] in ['0', '2', '4', '6', '8']
    pesel = p.pesel(birth_date=Datetime().datetime(1940, 2018))
    assert len(pesel) == 11

# Generated at 2022-06-17 21:46:03.975867
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:46:10.008326
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    p = PolandSpecProvider()
    pesel = p.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) <= 12
    assert int(pesel[4:6]) <= 31
    assert int(pesel[0:2]) <= 99
    assert int(pesel[6:9]) <= 999
    assert int(pesel[9:10]) <= 9
    assert int(pesel[10:11]) <= 9


# Generated at 2022-06-17 21:46:16.366025
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    assert provider.pesel() == '97061409842'
    assert provider.pesel(birth_date=Datetime().datetime(2000, 2000), gender=Gender.MALE) == '00062409842'
    assert provider.pesel(birth_date=Datetime().datetime(2000, 2000), gender=Gender.FEMALE) == '00062409842'
    assert provider.pesel(birth_date=Datetime().datetime(2000, 2000)) == '00062409842'
    assert provider.pesel(gender=Gender.MALE) == '97061409842'
    assert provider.pesel(gender=Gender.FEMALE) == '97061409842'


# Generated at 2022-06-17 21:46:18.714904
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    p = PolandSpecProvider()
    pesel = p.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert p.validate_pesel(pesel)


# Generated at 2022-06-17 21:46:20.730890
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()



# Generated at 2022-06-17 21:46:24.428880
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from datetime import datetime
    from mimesis.enums import Gender
    from mimesis.providers.person.poland import PolandSpecProvider
    from mimesis.typing import DateTime
    poland_provider = PolandSpecProvider()
    pesel = poland_provider.pesel(
        birth_date=DateTime(datetime(2000, 1, 1)),
        gender=Gender.MALE)
    assert pesel == '00050101234'

# Generated at 2022-06-17 21:46:30.776586
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    p = PolandSpecProvider()
    assert len(p.pesel()) == 11
    assert len(p.pesel(birth_date=Datetime().datetime(1990, 1990), gender=Gender.MALE)) == 11
    assert len(p.pesel(birth_date=Datetime().datetime(1990, 1990), gender=Gender.FEMALE)) == 11
    assert len(p.pesel(birth_date=Datetime().datetime(1990, 1990))) == 11


# Generated at 2022-06-17 21:46:31.520372
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    assert PolandSpecProvider().pesel() == '92010101234'

# Generated at 2022-06-17 21:46:33.096964
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()

# Generated at 2022-06-17 21:46:41.776125
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    assert p.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.MALE) == '89040404040'
    assert p.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.FEMALE) == '89040404040'
    assert p.pesel(birth_date=Datetime().datetime(1940, 2018)) == '89040404040'
    assert p.pesel() == '89040404040'
