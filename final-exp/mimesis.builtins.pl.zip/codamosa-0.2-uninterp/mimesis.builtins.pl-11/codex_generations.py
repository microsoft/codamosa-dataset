

# Generated at 2022-06-17 21:41:53.837616
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from datetime import datetime
    from mimesis.enums import Gender
    from mimesis.providers.person.poland import PolandSpecProvider
    poland_provider = PolandSpecProvider()
    pesel = poland_provider.pesel(birth_date=datetime(2000, 1, 1), gender=Gender.MALE)
    assert pesel == '00010112345'
    pesel = poland_provider.pesel(birth_date=datetime(2000, 1, 1), gender=Gender.FEMALE)
    assert pesel == '00010112340'
    pesel = poland_provider.pesel(birth_date=datetime(2000, 1, 1))

# Generated at 2022-06-17 21:42:03.398107
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    assert provider.pesel() == '98052901093'
    assert provider.pesel(birth_date=Datetime().datetime(1940, 2018)) == '98052901093'
    assert provider.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.MALE) == '98052901093'
    assert provider.pesel(birth_date=Datetime().datetime(1940, 2018), gender=Gender.FEMALE) == '98052901093'


# Generated at 2022-06-17 21:42:07.937141
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert provider.validate_pesel(pesel)

# Generated at 2022-06-17 21:42:18.788395
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    from datetime import datetime
    from mimesis.enums import Gender
    from mimesis.providers.person.poland import PolandSpecProvider
    from mimesis.typing import DateTime

    poland_provider = PolandSpecProvider()
    pesel = poland_provider.pesel(datetime(2000, 1, 1), Gender.MALE)
    assert len(pesel) == 11
    assert pesel[0:2] == '00'
    assert pesel[2:4] == '01'
    assert pesel[4:6] == '01'
    assert pesel[6:9] == '000'
    assert pesel[9] in ('1', '3', '5', '7', '9')

# Generated at 2022-06-17 21:42:22.751316
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()



# Generated at 2022-06-17 21:42:34.565283
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test for method pesel of class PolandSpecProvider."""
    from mimesis.providers.person import Person
    from mimesis.enums import Gender
    from mimesis.builtins.pl import PolandSpecProvider
    from datetime import datetime
    import re

    p = Person('pl')
    pl = PolandSpecProvider()
    pesel = pl.pesel()
    assert len(pesel) == 11
    assert re.match(r'^[0-9]{11}$', pesel)
    pesel = pl.pesel(gender=Gender.MALE)
    assert pesel[9] in ('1', '3', '5', '7', '9')
    pesel = pl.pesel(gender=Gender.FEMALE)

# Generated at 2022-06-17 21:42:38.934177
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:42:42.865004
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) <= 12
    assert int(pesel[4:6]) <= 31
    assert int(pesel[0:2]) >= 40
    assert int(pesel[0:2]) <= 99
    assert int(pesel[9]) % 2 == 0


# Generated at 2022-06-17 21:42:46.081234
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()


# Generated at 2022-06-17 21:42:52.243481
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert pesel.isdigit()
    assert int(pesel[2:4]) > 0
    assert int(pesel[2:4]) < 13
    assert int(pesel[4:6]) > 0
    assert int(pesel[4:6]) < 32
    assert int(pesel[6:9]) > 0
    assert int(pesel[6:9]) < 1000
    assert int(pesel[9]) in (0, 2, 4, 6, 8) or int(pesel[9]) in (1, 3, 5, 7, 9)
