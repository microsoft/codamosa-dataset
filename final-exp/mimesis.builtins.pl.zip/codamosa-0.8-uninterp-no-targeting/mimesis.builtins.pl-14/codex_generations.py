

# Generated at 2022-06-21 15:22:07.982717
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel(gender=None)

    date_object = Datetime().datetime(1940, 2018)
    year = date_object.date().year
    month = date_object.date().month
    day = date_object.date().day
    pesel_digits = [int(d) for d in str(year)][-2:]

    if 1800 <= year <= 1899:
        month += 80
    elif 2000 <= year <= 2099:
        month += 20
    elif 2100 <= year <= 2199:
        month += 40
    elif 2200 <= year <= 2299:
        month += 60

    pesel_digits += [int(d) for d in '{:02d}'.format(month)]

# Generated at 2022-06-21 15:22:20.083350
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    plprov = PolandSpecProvider()
    #test against known valid PESEL nr
    assert plprov.pesel() == '75111608906'
    #test if pesels are of lenght 11
    assert len(plprov.pesel()) == 11
    #test against known invalid PESEL nr
    assert plprov.pesel() != '7511160890'
    #test if pesels are of lenght 11 even if a gender is provided
    assert len(plprov.pesel(gender=Gender.MALE)) == 11
    #test if pesels are of lenght 11 even if a date is provided
    assert len(plprov.pesel(birth_date=PolandSpecProvider().datetime(1940, 2018))) == 11
    #test if pesels are of lenght 11 even if a date and a

# Generated at 2022-06-21 15:22:20.768051
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    assert PolandSpecProvider()

# Generated at 2022-06-21 15:22:24.150462
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    pesel_provider = PolandSpecProvider()
    assert len(pesel_provider.regon()) == 9

test_PolandSpecProvider_regon()


# Generated at 2022-06-21 15:22:27.847938
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Test function"""
    assert PolandSpecProvider.Meta.name == 'poland_provider'
    provider = PolandSpecProvider()
    assert provider.__class__.__name__ == 'PolandSpecProvider'


# Generated at 2022-06-21 15:22:33.275524
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    expected_values = [
        '00010338',
        '00059325',
        '00008144',
        '00034766',
        '00168859',
        '00273424',
        '00053441',
        '00143731',
        '00399811',
        '00038627',
        '00318435',
        '00515022'
    ]

    for i in range(1, len(expected_values)+1):
        expected_value = expected_values[i-1]
        actual_value = PolandSpecProvider(seed=i).regon()
        assert expected_value == actual_value


# Generated at 2022-06-21 15:22:36.132285
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    assert (PolandSpecProvider().nip() in ['5011046607', '8735022478', '9189080084'])


# Generated at 2022-06-21 15:22:39.682815
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    print(provider.nip())
    print(provider.pesel())
    print(provider.regon())

# Unit test
if __name__ == '__main__':
    test_PolandSpecProvider()

# Generated at 2022-06-21 15:22:40.826807
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    poland = PolandSpecProvider()
    assert poland.regon() == '75185638'



# Generated at 2022-06-21 15:22:42.417661
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    polandSpecProvider = PolandSpecProvider()
    assert polandSpecProvider is not None


# Generated at 2022-06-21 15:22:57.228957
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    pol = PolandSpecProvider()
    assert pol.nip()
    assert pol.pesel()
    assert pol.regon()


# Generated at 2022-06-21 15:23:00.575037
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    for _ in range(10):
        nip = provider.nip()
        assert isinstance(nip, str)



# Generated at 2022-06-21 15:23:02.839194
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    print("Start test_PolandSpecProvider_nip")
    assert len(PolandSpecProvider().nip()) == 10



# Generated at 2022-06-21 15:23:11.261904
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    #Test to check if properties are initialized
    p=PolandSpecProvider()
    # Test to check if the generated NIP is correct
    assert p.nip() in ["8909052834","8407187568","6907185141","7009141799","8902130488","7006152689","7209209856","8310143641","6603037918","9312306609","8311284040","7305192845","8903017915","8607114892","6908122646","7211267508","7312186443","6304286929","8312045065"]


# Generated at 2022-06-21 15:23:12.974852
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    assert provider.nip() == '9411903308'


# Generated at 2022-06-21 15:23:15.738470
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Test if method regon of class PolandSpecProvider returns correct numbers of digits."""
    poland_spec = PolandSpecProvider()
    result = poland_spec.regon()
    assert len(result) == 9


# Generated at 2022-06-21 15:23:16.597060
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    assert PolandSpecProvider() is not None


# Generated at 2022-06-21 15:23:24.754313
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test the method pesel of class PolandSpecProvider."""
    from mimesis.providers import PolandSpecProvider
    from datetime import datetime
    from mimesis.enums import Gender
    provider = PolandSpecProvider()
    date = datetime.now()
    for i in range(10):
        assert len(provider.pesel(date, Gender.MALE)) == 11
        assert len(provider.pesel(date, Gender.FEMALE)) == 11
        assert len(provider.pesel(date)) == 11

# Generated at 2022-06-21 15:23:28.992793
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    poland_spec_provider = PolandSpecProvider()
    print(poland_spec_provider.nip())
    print(poland_spec_provider.pesel(Gender.MALE))
    print(poland_spec_provider.regon())

test_PolandSpecProvider()



# Generated at 2022-06-21 15:23:37.896335
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    from mimesis.providers.person import Person
    from mimesis.enums import Gender
    import re
    import random
    p = Person(seed=1)
    # g is for gender
    g = Gender.get_random()
    if g == Gender.MALE:
        r = p.regon(gender=g)
        assert r[8] in ['0', '2', '4', '6', '8']
    if g == Gender.FEMALE:
        r = p.regon(gender=g)
        assert r[8] in ['1', '3', '5', '7', '9']
    else:
        r = p.regon()
        assert r[8] in [str(i) for i in range(0, 10)]

    r_len = len(r)