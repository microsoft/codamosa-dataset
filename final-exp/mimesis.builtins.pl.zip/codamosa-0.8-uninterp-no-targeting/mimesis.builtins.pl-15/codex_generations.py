

# Generated at 2022-06-21 15:22:08.500396
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    pl = PolandSpecProvider()
    nip = pl.nip()
    assert type(nip) is str
    assert len(nip) is 10
    assert nip[0] == '1' or nip[0] == '2'
    assert nip[1] == '0'
    assert int(nip[2]) >=1 and int(nip[2]) <= 9


# Generated at 2022-06-21 15:22:18.756819
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    from mimesis.enums import Gender
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.datetime import Datetime
    from datetime import datetime
    from mimesis.builtins import PolandSpecProvider
    p = PolandSpecProvider(seed=42)
    assert type(p) == PolandSpecProvider
    assert type(p._random) == BaseProvider
    assert type(p._seed) == int
    assert type(p._datetime) == Datetime
    assert type(p._birth_date) == datetime
    assert type(p._gender) == Gender
    assert p._gender == Gender.FEMALE

# Generated at 2022-06-21 15:22:29.951140
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test PolandSpecProvider class method pesel."""

# Generated at 2022-06-21 15:22:41.705672
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    # First run with default seed
    data_provider = PolandSpecProvider()
    nip_no = PolandSpecProvider.nip(data_provider)
    # The same result because of the same seed
    nip_no_repeating = PolandSpecProvider.nip(data_provider)
    nip_1 = PolandSpecProvider.nip(data_provider)
    assert nip_no == nip_no_repeating
    assert nip_1 != nip_no

    # Run with custom seed
    seed_provider = PolandSpecProvider(seed=37)
    nip_no1 = PolandSpecProvider.nip(seed_provider)
    # The same result because of the same seed
    nip_no_repeating1 = PolandSpecProvider.nip(seed_provider)

# Generated at 2022-06-21 15:22:44.247024
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Test the correctness of the regon method."""
    regon = PolandSpecProvider().regon()
    assert isinstance(regon, str) and len(regon) == 9 and regon.isdigit()


# Generated at 2022-06-21 15:22:52.458789
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Unit test for method nip."""
    import re

    # Generate 10 random NIPs
    for i in range(10):
        nip = PolandSpecProvider().nip()
        # Check if generated NIP is valid
        assert re.match(r'[0-9]{10}$', nip) is not None
        # For all but the first iteration of loop...
        if i > 0:
            # ...check if the first NIP isn't equal to the generated NIP
            assert nip != first_nip
        else:
            # Otherwise, save NIP for later comparison
            first_nip = nip


# Generated at 2022-06-21 15:22:54.129399
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pl = PolandSpecProvider()
    pesel = pl.pesel()
    assert(len(pesel) == 11)
    assert(int(pesel) >= 0)


# Generated at 2022-06-21 15:22:59.022389
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider"""
    instance = PolandSpecProvider()
    result = instance.pesel()
    assert len(result) == 11
    assert isinstance(result, str)
    assert result.isnumeric()
    assert result[len(result)-1] == str(instance.gender())


# Generated at 2022-06-21 15:23:06.644393
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    assert len(PolandSpecProvider().pesel()) == 11
    assert PolandSpecProvider().pesel(Datetime().datetime(1940, 2018), Gender.MALE) not in PolandSpecProvider().pesel(Datetime().datetime(1940, 2018), Gender.FEMALE)
    assert PolandSpecProvider().pesel(birth_date, gender=Gender.FEMALE) not in PolandSpecProvider().pesel(birth_date, gender=Gender.MALE)


# Generated at 2022-06-21 15:23:11.029650
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    poland_provider = PolandSpecProvider()
    assert poland_provider.nip() == '1'
    assert poland_provider.regon() == '8'
    assert poland_provider.pesel() == '1'

# Generated at 2022-06-21 15:23:26.629774
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    assert PolandSpecProvider().pesel() == "98080693610"

# Generated at 2022-06-21 15:23:27.695277
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    pass


# Generated at 2022-06-21 15:23:30.608353
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # Given
    provider = PolandSpecProvider(seed=123)
    # When
    result = provider.pesel(gender=Gender.MALE)
    # Then
    assert result == '93071398535'


# Generated at 2022-06-21 15:23:32.390798
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    from mimesis.builtins.poland import PolandSpecProvider
    print(PolandSpecProvider().regon())

# Generated at 2022-06-21 15:23:34.826229
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Test method nip() of class PolandSpecProvider."""
    pl = PolandSpecProvider()
    assert len(pl.nip()) == 10


# Generated at 2022-06-21 15:23:38.517912
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Test for method regon of class PolandSpecProvider."""
    pesel_list = []
    while len(pesel_list) != 100:
        rand_regon = PolandSpecProvider().regon()
        if rand_regon not in pesel_list:
            pesel_list.append(rand_regon)
    assert len(pesel_list) == 100


# Generated at 2022-06-21 15:23:46.736607
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # Getting a random PESEL
    a = PolandSpecProvider()
    assert len(a.pesel()) == 11
    # Getting a random PESEL for female
    b = PolandSpecProvider()
    assert b.pesel(gender=Gender.FEMALE)[9] in ('0', '2', '4', '6', '8', '9')
    # Getting a random PESEL for male
    c = PolandSpecProvider()
    assert c.pesel(gender=Gender.MALE)[9] in ('1', '3', '5', '7', '8', '9')

# Generated at 2022-06-21 15:23:47.604927
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    test1 = PolandSpecProvider()


# Generated at 2022-06-21 15:23:48.950770
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    assert(len(PolandSpecProvider().regon()) == 9)

# Generated at 2022-06-21 15:23:50.382094
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider(seed=42)


# Generated at 2022-06-21 15:24:12.193289
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Test for method regon of class PolandSpecProvider."""
    seed = "Seed for regon"
    pl = PolandSpecProvider(seed)
    regon = pl.regon()
    assert len(regon) == 9


# Generated at 2022-06-21 15:24:18.478530
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider(seed=123)

    pesel1 = provider.pesel(gender=Gender.MALE)
    print(pesel1)
    assert pesel1 == "96111001327"

    pesel2 = provider.pesel(gender=Gender.FEMALE)
    print(pesel2)
    assert pesel2 == "94101900812"

    pesel3 = provider.pesel(gender=Gender.MALE)
    print(pesel3)
    assert pesel3 == "99022903054"

    pesel4 = provider.pesel(gender=Gender.MALE)
    print(pesel4)
    assert pesel4 == "95011607868"

    pesel5 = provider.pesel(gender=Gender.FEMALE)

# Generated at 2022-06-21 15:24:19.489205
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    assert PolandSpecProvider()


# Generated at 2022-06-21 15:24:25.474606
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    # Test without parameters
    provider = PolandSpecProvider()
    assert provider.provider.locale == 'pl'

    # Test with locale
    provider = PolandSpecProvider('pl')
    assert provider.provider.locale == 'pl'

    # Test with seed
    provider = PolandSpecProvider(seed=123456789)
    assert provider.seed == 123456789


# Generated at 2022-06-21 15:24:28.327444
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland = PolandSpecProvider(seed = 12345)
    pesel = poland.pesel(birth_date= DateTime.datetime(2018,10,10), gender=Gender.MALE)
    assert(pesel == "18101099659")

# Generated at 2022-06-21 15:24:39.446922
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    nip_digits = [int(d) for d in str(random.randint(101, 998))]
    nip_digits += [random.randint(0, 9) for _ in range(6)]
    nip_coefficients = (6, 5, 7, 2, 3, 4, 5, 6, 7)
    sum_v = sum([nc * nd for nc, nd in zip(nip_coefficients, nip_digits)])

    checksum_digit = sum_v % 11
    if checksum_digit > 9:
        return ''.join(str(d) for d in nip_digits)
    nip_digits.append(checksum_digit)
    return ''.join(str(d) for d in nip_digits)


# Generated at 2022-06-21 15:24:41.224179
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    p = PolandSpecProvider()
    assert p.locale == 'pl'


# Generated at 2022-06-21 15:24:44.730939
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    nip_list = []
    nip_list.append(PolandSpecProvider().nip())
    assert len(nip_list[0]) == 10
    assert nip_list[0].isdigit()
    nip_list.append(PolandSpecProvider().nip())
    assert nip_list[0] != nip_list[1]


# Generated at 2022-06-21 15:24:45.223318
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    PolandSpecProvider()

# Generated at 2022-06-21 15:24:46.820130
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Tests function regon of class PolandSpecProvider."""
    assert len(PolandSpecProvider().regon()) == 9


# Generated at 2022-06-21 15:25:16.535960
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel(1980-11-12, Gender.MALE)
    print(pesel)


if __name__ == '__main__':
    print(PolandSpecProvider().nip())
    test_PolandSpecProvider_pesel()
    print(PolandSpecProvider().regon())

# Generated at 2022-06-21 15:25:19.418303
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    pl = PolandSpecProvider()
    nip = pl.nip()
    assert len(nip) == 10
    assert pl.is_nip(nip) == True


# Generated at 2022-06-21 15:25:25.797675
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    #Given
    m = PolandSpecProvider()

    #When
    pesel_MALE = m.pesel(gender=Gender.MALE)
    pesel_FEMALE = m.pesel(gender=Gender.FEMALE)
    # Then
    if(pesel_MALE[10]%2 != 0):
        assert True
    else:
        assert False
    if(pesel_FEMALE[10]%2 == 0):
        assert True
    else:
        assert False

# Generated at 2022-06-21 15:25:29.434056
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    # create data from this class
    provider = PolandSpecProvider()
    # call method nip of class PolandSpecProvider
    nip = provider.nip()
    # validate length nip
    assert len(nip) == 10


# Generated at 2022-06-21 15:25:30.547990
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    print(provider.nip())


# Generated at 2022-06-21 15:25:35.451599
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    print(pesel)
    assert len(pesel) == 11
    assert int(pesel[0]) in [1, 2]
    assert 1 <= int(pesel[2:4]) <= 12
    assert 1 <= int(pesel[4:6]) <= 31
    assert int(pesel[9]) == 0 or int(pesel[9]) in [1, 3, 5, 7, 9]
    assert int(pesel[10]) >= 0 and int(pesel[10]) <= 9



# Generated at 2022-06-21 15:25:40.313629
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    test_nips = ['1026023522', '8951909192', '5586091766', '7701058199', '9672067892']
    provider = PolandSpecProvider()
    for test_nip in test_nips:
        provider.reset_seed()
        assert test_nip == provider.nip()


# Generated at 2022-06-21 15:25:46.708416
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    import re
    print("Test of method \"nip\" of class PolandSpecProvider")
    p = PolandSpecProvider()
    # Check if output is a string
    assert isinstance(p.nip(), str)
    # Check if output is 10 digits
    assert re.match(r'[0-9]{10}', p.nip())


# Generated at 2022-06-21 15:25:49.767004
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """ Unit test for method pesel of class PolandSpecProvider,
        the pesel should be 11 digits long
    """
    provider = PolandSpecProvider(seed=12345)
    assert len(provider.pesel()) == 11


# Generated at 2022-06-21 15:25:51.537276
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    a = PolandSpecProvider()
    print(a.nip())
    print(a.pesel())
    print(a.regon())

# Generated at 2022-06-21 15:27:06.185495
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider()
    random = provider.random.randint(100, 9999)
    regon1 = [int(digit) for digit in str(random)]
    while len(regon1) < 9:
        regon1.append(provider.random.randint(0, 9))
    regon2 = provider.regon()
    assert regon1 == regon2


# Generated at 2022-06-21 15:27:09.756258
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    for _ in range(100):
        assert len(provider.nip()) == 10
        assert len(provider.pesel()) == 11
        assert len(provider.regon()) == 9
test_PolandSpecProvider()

# Generated at 2022-06-21 15:27:13.849033
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
#   a = time.time()

#   for i in range(0, 100000):
    for i in range(0, 100000):
        regon_number = PolandSpecProvider().regon()
        if len(regon_number) != 9:
            print("Error. Length of regon_number: " + str(len(regon_number)))
            break
#       print(regon_number)
#   b = time.time()

#   print(b-a)

# test_PolandSpecProvider_regon()


# Generated at 2022-06-21 15:27:16.843423
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    polandSpecProvider1 = PolandSpecProvider()
    nipString = polandSpecProvider1.nip()
    assert len(nipString) == 10


# Generated at 2022-06-21 15:27:18.897578
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    assert provider.nip(1) is not None


# Generated at 2022-06-21 15:27:23.266684
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    p = PolandSpecProvider()
    nip = p.nip()
    assert nip == '452-083-52-52'
    pesel = p.pesel()
    assert pesel == '20123127080'
    regon = p.regon()
    assert regon == '566883595'

# Generated at 2022-06-21 15:27:25.360569
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    x = PolandSpecProvider()
    assert len(x.pesel()) == 11


# Generated at 2022-06-21 15:27:27.074873
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    pl_provider = PolandSpecProvider()
    assert pl_provider.locale == 'pl'


# Generated at 2022-06-21 15:27:29.072938
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    try:
        PolandSpecProvider.nip()
    except Exception as e:
        print("Exception in method nip of class PolandSpecProvider!")
        print(e)


# Generated at 2022-06-21 15:27:30.397399
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    a=PolandSpecProvider()
    assert(a.locale=="pl")

# Generated at 2022-06-21 15:29:51.670050
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(str(pesel)) == 11

# Generated at 2022-06-21 15:29:56.144346
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Test that PolandSpecProvider.regon() return 9-digit REGON code.
    """
    poland_provider = PolandSpecProvider()
    regon_code = poland_provider.regon()
    assert isinstance(regon_code, str) and len(regon_code) == 9, "REGON code has to be 9-digit length"


# Generated at 2022-06-21 15:29:59.528906
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Test method regon of class PolandSpecProvider"""
    # Test 1 - check regon consist of 9 digits
    regon = PolandSpecProvider().regon()
    assert len(regon) == 9
    # Test 2 - check regon consist of digits
    assert regon.isdigit()
# Test end

# Generated at 2022-06-21 15:30:01.655497
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    instance = PolandSpecProvider()
    result = instance.regon()
    assert len(result) == 9
    assert result.isdigit()


# Generated at 2022-06-21 15:30:03.371596
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11


# Generated at 2022-06-21 15:30:07.852194
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    # Test PolandSpecProvider.regon with default parameters
    PST = PolandSpecProvider()
    PSL = []
    for _ in range(10):
        PSL.append(PST.regon())
    print(PSL)

    # Test PolandSpecProvider.regon with default parameters
    PST = PolandSpecProvider(seed=22)
    PSL = []
    for _ in range(10):
        PSL.append(PST.regon())
    print(PSL)

test_PolandSpecProvider_regon()

# Generated at 2022-06-21 15:30:09.836243
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel(): # pragma: no cover
    pol = PolandSpecProvider()
    pes = pol.pesel()
    print(pes)

# Generated at 2022-06-21 15:30:11.554381
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    assert len(PolandSpecProvider().regon()) == 9


# Generated at 2022-06-21 15:30:20.345183
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # Creating the instance of PolandSpecProvider
    poland = PolandSpecProvider()
    pesel = poland.pesel()
    # Creating the instance of Datetime provider
    datetime = Datetime()
    # The random birth date in 2018
    random_birth_date = datetime.datetime(year=2018)
    pesel_with_birth_date = poland.pesel(birth_date=random_birth_date)
    # The random birth date in 2018 for a male
    random_birth_date_male = datetime.datetime(year=2018)
    pesel_with_birth_date = poland.pesel(birth_date=random_birth_date_male, gender=Gender.MALE)
    # The random birth date in 2018 for a female

# Generated at 2022-06-21 15:30:23.908431
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    id = provider.pesel(gender=Gender.MALE)
    assert len(id) == 11
    assert id[-1] in '02468'

    id = provider.pesel(gender=Gender.FEMALE)
    assert len(id) == 11
    assert id[-1] in '13579'