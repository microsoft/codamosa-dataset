

# Generated at 2022-06-21 15:22:05.623986
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # Initialisation
    seed = 5
    gender = "MALE"
    birth_date = 1

    p = PolandSpecProvider(seed)
    pesel = p.pesel(birth_date, gender)

    # Check if pesel has 11 digits
    assert len(pesel) == 11

    # Check if value is correct
    assert pesel == '63020902566'


# Generated at 2022-06-21 15:22:07.564178
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    p = PolandSpecProvider(seed=1)
    assert p.regon() == '988359696'



# Generated at 2022-06-21 15:22:11.606987
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    # Create test object
    p = PolandSpecProvider()

    # We want to test string lenght and string format
    assert str(p.nip()).__len__() == 10 and type(p.nip()) == str


# Generated at 2022-06-21 15:22:14.117167
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    object = PolandSpecProvider()
    print(object.nip())
    print(object.pesel(gender='female'))
    print(object.regon())

# Generated at 2022-06-21 15:22:15.543474
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    psp = PolandSpecProvider()
    print(psp.nip())


# Generated at 2022-06-21 15:22:16.734134
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    d = PolandSpecProvider()
    #10 digits
    assert len(d.nip()) == 10


# Generated at 2022-06-21 15:22:23.388711
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pl = PolandSpecProvider()
    pesel = pl.pesel()
    pesel = pesel[:2]
    if (pesel == '18' or pesel == '19' or pesel == '20' or pesel == '21'):
        print('Unit test for method pesel of class PolandSpecProvider: Pass')
    else:
        print('Unit test for method pesel of class PolandSpecProvider: Fail')


# Generated at 2022-06-21 15:22:25.741837
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Test the method regon of class PolandSpecProvider."""
    assert len(PolandSpecProvider().regon()) == 9


# Generated at 2022-06-21 15:22:29.371422
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    
    psp = PolandSpecProvider()
    assert psp.locale == 'pl'
    assert psp.nip() is not None
    assert psp.pesel() is not None
    assert psp.regon() is not None

# Generated at 2022-06-21 15:22:31.344789
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    inst = PolandSpecProvider()
    assert len(inst.regon()) == 9

# Generated at 2022-06-21 15:22:45.117334
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    p = PolandSpecProvider(seed=9999)
    # Print the first 10 elements of the list
    print(p.nip() for x in range(10))

# Generated at 2022-06-21 15:22:47.541188
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    a = PolandSpecProvider()
    for i in range(1,10):
        print(a.nip())


# Generated at 2022-06-21 15:22:49.178266
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider()
    regon = provider.regon()
    assert str(regon)

# Generated at 2022-06-21 15:22:52.832699
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip(): #TODO
    from mimesis.builtins import PolandSpecProvider
    obj = PolandSpecProvider()

    print('Result:: ', obj.nip())
    print('Type:: ', type(obj.nip()))


# Generated at 2022-06-21 15:22:58.910446
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    p = PolandSpecProvider()
    regon_digits = [int(d) for d in p.regon()]
    regon_coeffs = (8, 9, 2, 3, 4, 5, 6, 7)
    sum_v = sum([nc * nd for nc, nd in zip(regon_coeffs, regon_digits)])
    checksum_digit = sum_v % 11
    if checksum_digit == 10:
        print("Method regon of class PolandSpecProvider does not work properly.")
    print("Method regon of class PolandSpecProvider works properly.")

test_PolandSpecProvider_regon()

# Generated at 2022-06-21 15:23:01.620093
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    test = PolandSpecProvider()
    regon = test.regon()
    assert len(regon) == 9


# Generated at 2022-06-21 15:23:04.931448
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Test for the method regon of class PolandSpecProvider."""
    for i in range(10):
        regon = PolandSpecProvider().regon()
        assert regon and (len(regon)) == 9


# Generated at 2022-06-21 15:23:06.924316
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    pr = PolandSpecProvider()
    for _ in range(100):
        assert len(str(pr.regon())) == 9

# Generated at 2022-06-21 15:23:08.895629
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    x = PolandSpecProvider()
    assert x.nip() == '5290738547' or x.nip() == '7421339878'



# Generated at 2022-06-21 15:23:18.568304
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()

    # test all genders
    for gender in Gender:
        pesel = provider.pesel(gender=gender)
        # test length
        assert len(pesel) == 11
        # test gender
        if gender == Gender.MALE:
            assert int(pesel[9]) % 2 == 1
        elif gender == Gender.FEMALE:
            assert int(pesel[9]) % 2 == 0

    # test specific date
    date_fmt = '%Y-%m-%d'
    date = Datetime().datetime(min_year=1980, max_year=1999, fmt=date_fmt)
    pesel = provider.pesel(birth_date=date)