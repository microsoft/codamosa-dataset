

# Generated at 2022-06-21 15:22:05.838549
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    test = PolandSpecProvider()
    assert isinstance(test.regon(), str) # Check return type
    assert len(test.regon()) == 9 # Check length of return


# Generated at 2022-06-21 15:22:07.085000
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    assert PolandSpecProvider().regon() == '795020087'

# Generated at 2022-06-21 15:22:08.298075
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    assert len(provider.pesel())==11

# Generated at 2022-06-21 15:22:10.677535
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    assert PolandSpecProvider().pesel(datetime.datetime(1982, 11, 21)) == '82112102451'
    assert PolandSpecProvider().pesel(datetime.datetime(2018, 11, 21)) == '18211317692'

# Generated at 2022-06-21 15:22:12.552093
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    psp = PolandSpecProvider()
    n_cases = 5000
    regon = set()
    for i in range(n_cases):
        regon.add(psp.regon())
    assert len(regon) == n_cases



# Generated at 2022-06-21 15:22:24.680882
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    assert PolandSpecProvider().pesel() == '85042803038'
    assert PolandSpecProvider().pesel(gender=Gender.FEMALE) == '02060322143'
    assert PolandSpecProvider().pesel(gender=Gender.MALE) == '30063142764'
    assert PolandSpecProvider().pesel(
        Datetime().datetime(year=1948, month=3, day=12)) == '48030133214'
    assert PolandSpecProvider().pesel(
        Datetime().datetime(year=1948, month=3, day=12), gender=Gender.FEMALE) == '48030150707'

# Generated at 2022-06-21 15:22:31.176594
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    test_provider = PolandSpecProvider()
    test_regons = [test_provider.regon() for i in range(0, 10)]
    test_regons_str = [str(test_regons[i]) for i in range(0, 10)]
    regon_lengths = [len(r) for r in test_regons_str]
    assert all(r == 14 for r in regon_lengths)
    assert len(test_regons) == 10
    assert len(set(test_regons)) == 10


# Generated at 2022-06-21 15:22:35.021311
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    pol = PolandSpecProvider()
    reg = pol.regon()
    assert isinstance(reg, str)
    assert len(reg) == 9


# Generated at 2022-06-21 15:22:37.125463
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    b = PolandSpecProvider()
    assert isinstance(b, PolandSpecProvider)


# Generated at 2022-06-21 15:22:44.396087
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    from mimesis.providers.person import Person
    k = str(PolandSpecProvider().pesel())
    assert len(k) == 11
    if k[2:4] in ['81', '82', '83', '84', '85', '86', '87', '88', '89', '90', '91', '92', '93', '94', '95', '96', '97']:
        if not Person().gender() == Gender.MALE:
            raise Exception("The data is incorrect")

# Generated at 2022-06-21 15:24:23.507861
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    assert provider.provider.__name__ == 'PolandSpecProvider'


# Generated at 2022-06-21 15:24:27.991412
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Test constructor of class PolandSpecProvider."""
    pol_spec = PolandSpecProvider()
    assert pol_spec is not None
    assert pol_spec.locale is not None
    assert pol_spec.random is not None
    assert hasattr(pol_spec, 'Meta')



# Generated at 2022-06-21 15:24:33.601057
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    poland = PolandSpecProvider(seed=1)

    # Test method "nip"
    assert poland.nip() == '5151613797'

    # Test method "pesel"
    assert poland.pesel() == '85010781369'

    # Test method "regon"
    assert poland.regon() == '323516993'

# Generated at 2022-06-21 15:24:39.712105
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    ''' Tests for method nip from PolandSpecProvider class
    '''
    nip_1 = PolandSpecProvider().nip()
    nip_2 = PolandSpecProvider().nip()
    assert type(nip_1) == str
    assert type(nip_2) == str
    assert len(nip_1) == 10
    assert len(nip_2) == 10
    assert nip_1 != nip_2


# Generated at 2022-06-21 15:24:45.428138
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    obj = PolandSpecProvider()
    for _ in range(1000):
        pesel = obj.pesel()
        pesel_digits = [int(d) for d in pesel]
        pesel_coeffs = (9, 7, 3, 1, 9, 7, 3, 1, 9, 7)
        sum_v = sum([nc * nd for nc, nd in
                     zip(pesel_coeffs, pesel_digits)])
        assert sum_v % 10 == pesel_digits[10]


# Generated at 2022-06-21 15:24:46.462886
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    results = PolandSpecProvider()
    assert results is not None


# Generated at 2022-06-21 15:24:50.705520
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    psp = PolandSpecProvider()
    regon = psp.regon()
    assert len(regon) == 9


# Generated at 2022-06-21 15:24:52.106480
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    for i in range(1000):
        print(PolandSpecProvider().regon())

# Generated at 2022-06-21 15:24:54.667469
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Test regon of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    assert len(provider.regon()) == 9


# Generated at 2022-06-21 15:24:56.931044
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    pl_provider = PolandSpecProvider()
    nip = pl_provider.nip()
    assert len(nip) == 10

