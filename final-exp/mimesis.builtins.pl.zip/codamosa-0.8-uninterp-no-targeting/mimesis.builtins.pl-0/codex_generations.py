

# Generated at 2022-06-21 15:22:03.944551
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    print(provider.nip())
    print(provider.pesel())
    print(provider.regon())

# Generated at 2022-06-21 15:22:06.595135
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Test method regon of class PolandSpecProvider."""
    p = PolandSpecProvider(seed=0)
    regon = p.regon()
    print(regon)
    assert regon == "81352046"

# Generated at 2022-06-21 15:22:07.849137
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    data = PolandSpecProvider().nip()
    assert len(data) == 10


# Generated at 2022-06-21 15:22:13.959718
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider_1 = PolandSpecProvider()
    print(provider_1.nip())
    assert provider_1.nip() == '1730000761'
    print(provider_1.pesel())
    assert provider_1.pesel() == '99100100401'
    print(provider_1.regon())
    assert provider_1.regon() == '001828300'

# Generated at 2022-06-21 15:22:24.632463
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    p = PolandSpecProvider()
    regon = p.regon()
    assert len(regon) == 9
    assert int(regon[0]) in range(8, 10)
    assert int(regon[1]) in range(8, 10)
    assert int(regon[2]) in range(2, 4)
    assert int(regon[3]) in range(3, 5)
    assert int(regon[4]) in range(4, 6)
    assert int(regon[5]) in range(5, 7)
    assert int(regon[6]) in range(6, 8)
    assert int(regon[7]) in range(7, 9)
    assert int(regon[8]) in range(10)


# Generated at 2022-06-21 15:22:26.129526
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Test method regon of class PolandSpecProvider."""
    provider = PolandSpecProvider(seed=42)
    regon = provider.regon()
    assert regon == '313070292'



# Generated at 2022-06-21 15:22:30.381965
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    '''
    Test for method pesel of class PolandSpecProvider
    '''
    from datetime import datetime
    from mimesis.builtins import PolandSpecProvider
    from mimesis.enums import Gender
    from mimesis.utils import get_seed

    mimesis = PolandSpecProvider(seed=get_seed())
    pesel = mimesis.pesel(birth_date=datetime(2001, 1, 1),
                          gender=Gender.MALE)
    assert len(pesel) == 11



# Generated at 2022-06-21 15:22:37.076747
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    from mimesis.builtins.pl import PolandSpecProvider
    from mimesis.enums import Gender
    from mimesis.providers import Datetime
    from mimesis.typing import DateTime, Seed
    my_seed = Seed.random()
    pesel = PolandSpecProvider(seed = my_seed)
    print(pesel.nip())

# Generated at 2022-06-21 15:22:38.946811
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    rnd = PolandSpecProvider()
    for _ in range(0, 1000):
        regon = rnd.regon()
        print(regon)



# Generated at 2022-06-21 15:22:43.973925
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel1 = provider.pesel()
    pesel2 = provider.pesel(gender='M')
    pesel3 = provider.pesel(gender='K')
    print("PESEL:",pesel1,' ',pesel2,' ',pesel3)
    assert len(pesel1) == 11
    assert len(pesel2) == 11
    assert len(pesel3) == 11


# Generated at 2022-06-21 15:22:55.104196
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    assert provider.pesel(gender='female')
    assert provider.pesel(gender='male')
    assert provider.pesel(gender=Gender.MALE)
    assert provider.pesel(gender=Gender.FEMALE)

# Generated at 2022-06-21 15:23:06.744850
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    import unittest
    r = PolandSpecProvider()
    # test with default seed
    try:
        regon = r.regon()
        regon_long = r.regon(14)
    except:
        assert False
    assert regon
    assert len(regon) == 9
    assert regon_long
    assert len(regon_long) == 14
    # test with seed on list of regex of function PolandSpecProvider_regon
    pseed = 1234
    r = PolandSpecProvider(seed=pseed)
    i = 0
    regon_seed = [r.regon() for _ in range(10)]
    regon_seed_long = [r.regon(14) for _ in range(10)]
    # with default seed

# Generated at 2022-06-21 15:23:09.374023
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    # Arrange
    provider = PolandSpecProvider()

    # Act
    regon = provider.regon()

    # Assert
    assert isinstance(regon, str)

# Generated at 2022-06-21 15:23:12.127354
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    polandSpecProvider = PolandSpecProvider()
    assert re.match(r'[0-9]{10}', polandSpecProvider.nip())
    assert len(polandSpecProvider.nip()) == 10


# Generated at 2022-06-21 15:23:17.029448
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    regons = ['123456789', '234567892', '345678934', '456789345', '567893456', '678934567', '789345678', '893456789', '934567893', '456789345']
    for regon in regons:
        assert PolandSpecProvider.regon() == regon

# Generated at 2022-06-21 15:23:25.208382
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Test nip method of class PolandSpecProvider."""
    nip_pattern = re.compile(r"^(\d{3})(\d{3})(\d{2})(\d{2})$")
    data_provider = PolandSpecProvider()
    for i in range(10):
        nip_ = data_provider.nip()
        assert isinstance(nip_, str), "The result is not string."
        assert nip_pattern.match(nip_), "The result is not valid NIP."


# Generated at 2022-06-21 15:23:29.116031
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pl = PolandSpecProvider()
    r = pl.pesel(pl.datetime(1940, 2018))
    assert r[2:4] == '40'
    assert r[5:7] == '03'
    assert r[4] == '0'

# Generated at 2022-06-21 15:23:32.308806
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    pesels = [ p.pesel() for _ in range(0, 1000) ]

    expected = [p for p in pesels if len(p) != 11]
    assert len(expected) == 0

# Generated at 2022-06-21 15:23:38.544584
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Unit test for method regon of class PolandSpecProvider."""
    r = PolandSpecProvider()
    assert r.regon() == '880274723' or r.regon() == '844073242' or r.regon() == '653577142' or r.regon() == '596071422' or r.regon() == '254385933' or r.regon() == '616528442' or r.regon() == '675912002' or r.regon() == '847463962' or r.regon() == '631904502' or r.regon() == '254723112'

# Generated at 2022-06-21 15:23:40.049014
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    obj = PolandSpecProvider()
    result = obj.nip()
    assert result is not None


# Generated at 2022-06-21 15:23:57.296006
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    p = PolandSpecProvider()
    assert p.nip() == "438-001-80-59"


# Generated at 2022-06-21 15:23:59.216167
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    obj = PolandSpecProvider(seed=2)
    pesel = obj.pesel()
    assert pesel == '98030400094'

# Generated at 2022-06-21 15:24:01.639669
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    p = PolandSpecProvider()
    assert p.regon() == '4444444444444444444444444444444444444444444444444444444444444444444'

# Generated at 2022-06-21 15:24:03.076432
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    assert provider.provider == 'poland_provider'


# Generated at 2022-06-21 15:24:04.908013
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    from mimesis import PolandSpecProvider
    l = PolandSpecProvider()
    assert len(l.regon()) is 9
    assert l.regon().isdigit()


# Generated at 2022-06-21 15:24:13.682414
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    p = PolandSpecProvider()
    for i in range(10):
        nip = p.nip()
        nip_digits = [int(d) for d in nip]
        nip_coefficients = (6, 5, 7, 2, 3, 4, 5, 6, 7)
        sum_v = sum([nc * nd for nc, nd in zip(nip_coefficients, nip_digits)])
        checksum_digit = sum_v % 11
        if checksum_digit > 9:
            checksum_digit = 0
        assert nip_digits[9] == checksum_digit


# Generated at 2022-06-21 15:24:15.346164
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    seed = 123
    p = PolandSpecProvider(seed)
    assert p.nip() == '1251376914'


# Generated at 2022-06-21 15:24:17.470494
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()

    assert len(provider.nip()) is 10


# Generated at 2022-06-21 15:24:21.223187
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    test_object = PolandSpecProvider()
    nip = test_object.nip()
    # Check if the length of NIP is 10 digits
    assert len(nip) == 10



# Generated at 2022-06-21 15:24:23.859902
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    for _ in range(10):
        provider = PolandSpecProvider(seed=None)
        result = provider.nip()
        assert isinstance(result, str)
        assert len(result) == 10


# Generated at 2022-06-21 15:25:00.445555
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    # Test case 1: should return valid 10-digit NIP
    provider = PolandSpecProvider()
    for i in range(0, 10):
        nip = provider.nip()
        print(nip)
    assert len(nip) == 10


# Generated at 2022-06-21 15:25:05.921848
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    assert provider.pesel() == '97072124913'
    assert provider.pesel(birth_date='1995-07-21', gender=Gender.MALE) == '97072124913'
    assert provider.pesel(birth_date='1995-07-21', gender=Gender.FEMALE) == '97072124923'

test_PolandSpecProvider_pesel()


# Generated at 2022-06-21 15:25:07.466171
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    regon_1 = PolandSpecProvider().regon()
    assert len(regon_1) == 9



# Generated at 2022-06-21 15:25:10.066851
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    regon = PolandSpecProvider().regon()
    assert len(regon) == 9
    assert isinstance(regon, str)



# Generated at 2022-06-21 15:25:14.574738
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    from mimesis.providers import poland_provider
    from mimesis.enums import Gender
    from mimesis.builtins import PolandSpecProvider
    pl = PolandSpecProvider()
    print(PolandSpecProvider.nip(pl))

# Generated at 2022-06-21 15:25:16.929281
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    a = PolandSpecProvider()
    assert (len(a.nip()) == 11) and (type((a.nip())) == str)


# Generated at 2022-06-21 15:25:19.461163
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Generate random valid 9-digit REGON."""
    polandSpecProvider = PolandSpecProvider()
    result = polandSpecProvider.regon()
    print(result)


# Generated at 2022-06-21 15:25:21.910789
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    p = PolandSpecProvider()
    for i in range(100):
        assert len(p.nip()) == 10


# Generated at 2022-06-21 15:25:26.574986
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    from mimesis.enums import Gender

    poland = PolandSpecProvider()

    assert poland.__class__.__name__ == 'PolandSpecProvider'

    assert poland.nip() in poland.nip.__doc__
    assert poland.regon() in poland.regon.__doc__

    assert poland.pesel() in poland.pesel.__doc__
    assert poland.pesel(Gender.MALE) in poland.pesel.__doc__
    assert poland.pesel(Gender.FEMALE) in poland.pesel.__doc__


# Generated at 2022-06-21 15:25:27.678270
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    assert PolandSpecProvider().regon()

# Generated at 2022-06-21 15:27:07.915357
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    assert provider is not None


# Generated at 2022-06-21 15:27:10.488257
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    print('Testing PolandSpecProvider.regon():')
    pl = PolandSpecProvider()
    s = pl.regon()
    print(s)
    assert len(s) == 9


# Generated at 2022-06-21 15:27:14.890128
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    assert PolandSpecProvider().__class__ == PolandSpecProvider
    assert PolandSpecProvider().__doc__ == 'Class that provides special data for Poland (pl).'


# Generated at 2022-06-21 15:27:24.486695
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel1 = PolandSpecProvider().pesel(gender=Gender.MALE)
    assert isinstance(pesel1, str) and len(pesel1) == 11
    assert pesel1[-1] in ['1', '3', '5', '7', '9']
    assert PolandSpecProvider().pesel(gender=Gender.FEMALE)[-1] in ['0', '2', '4', '6', '8']
    assert PolandSpecProvider().pesel() is not None
    pesel2 = PolandSpecProvider().pesel(gender=Gender.MALE)
    assert isinstance(pesel1, str) and len(pesel1) == 11
    assert pesel2 != pesel1

# Generated at 2022-06-21 15:27:27.226872
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel_1 = provider.pesel()
    pesel_2 = provider.pesel()
    assert pesel_1 != pesel_2

# Generated at 2022-06-21 15:27:33.188843
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel(gender=Gender.MALE,
                           birth_date=provider.datetime(1970, 2018))
    assert len(pesel) == 11
    assert type(provider.pesel()).__name__ == 'str'
    assert type(provider.pesel()).__name__ == 'str'
    assert type(provider.pesel()).__name__ == 'str'
    assert type(provider.pesel()).__name__ == 'str'
    assert type(provider.pesel()).__name__ == 'str'
    assert type(provider.pesel()).__name__ == 'str'
    assert type(provider.pesel()).__name__ == 'str'
    assert type(provider.pesel()).__name__

# Generated at 2022-06-21 15:27:34.083503
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    PolandSpecProvider()


# Generated at 2022-06-21 15:27:34.973754
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    PolandSpecProvider()


# Generated at 2022-06-21 15:27:54.136064
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    p1 = PolandSpecProvider()
    nip1 = p1.nip()
    assert type(nip1) == str
    assert len(nip1) == 10
    assert int(nip1) > 100000000 and int(nip1) < 999999999
    coeffs = (6, 5, 7, 2, 3, 4, 5, 6, 7)
    checksum = None
    for i in range(9):
        checksum = 0
        # print("NIP: " + str(nip1) + ", i: " + str(i) + ", substring: " + str(nip1[i]))
        checksum += int(nip1[i]) * coeffs[i]
        # print("checksum: " + str(checksum))
    checksum = checksum % 11
   

# Generated at 2022-06-21 15:27:55.711358
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    obj = PolandSpecProvider()
    assert obj._locale == 'pl'
    assert obj._seed is None

# Generated at 2022-06-21 15:31:17.911167
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    from mimesis.enums import Gender
    from mimesis.providers.person.pl import PolandSpecProvider
    provider = PolandSpecProvider()
    result = provider.pesel(gender=Gender.MALE)
    assert result == '98041414338'

# Generated at 2022-06-21 15:31:22.738914
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    from mimesis.enums import Gender
    pl_provider = PolandSpecProvider()
    nip = pl_provider.nip()
    assert nip.isnumeric()
    assert len(nip) == 10
    pesel = pl_provider.pesel(birth_date=pl_provider.datetime(1940, 2018), gender=Gender.MALE)
    assert pesel.isnumeric()
    assert len(pesel) == 11
    regon = pl_provider.regon()
    assert regon.isnumeric()
    assert len(regon) == 9

# Generated at 2022-06-21 15:31:25.315539
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider()
    regon = provider.regon()
    print(regon)


# Generated at 2022-06-21 15:31:31.318841
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    #
    # Test case 1
    #
    k = PolandSpecProvider()
    x = k.nip()
    print(x)
    assert True

    #
    # Test case 2
    #
    k = PolandSpecProvider()
    x = k.pesel()
    print(x)
    assert True

    #
    # Test case 3
    #
    k = PolandSpecProvider()
    x = k.regon()
    print(x)
    assert True

# Generated at 2022-06-21 15:31:34.111048
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider()
    regon1 = provider.regon()
    regon2 = provider.regon()
    regon3 = provider.regon()

    assert(regon1 != regon2)
    assert (regon2 != regon3)
    assert (regon3 != regon1)


# Generated at 2022-06-21 15:31:36.063737
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    obj = PolandSpecProvider()
    res = obj.regon()
    assert len(res) == 9
    assert type(res) == str



# Generated at 2022-06-21 15:31:37.199464
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    psp = PolandSpecProvider()
    assert psp.regon() == '93167629'


# Generated at 2022-06-21 15:31:41.360562
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    pesel = PolandSpecProvider().pesel()
    assert (pesel != '')
    assert (len(pesel) == 11)
    nip = PolandSpecProvider().nip()
    assert (nip != '')
    assert (len(nip) == 10)
    regon = PolandSpecProvider().regon()
    assert (regon != '')
    assert (len(regon) == 9)

# Generated at 2022-06-21 15:31:45.115753
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider(seed=1)
    pesel = provider.pesel(Gender.MALE)
    assert pesel == "93122514309"
    pesel = provider.pesel(Gender.FEMALE)
    assert pesel == "83110918069"

# Generated at 2022-06-21 15:31:45.589780
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    pass