

# Generated at 2022-06-21 15:22:13.302972
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    from datetime import datetime
    from mimesis.enums import Gender
    pp = PolandSpecProvider()
    pes = pp.pesel(datetime(2015, 4, 16), Gender.FEMALE)
    assert len(pes) == 11
    assert pes[:2] == '15'
    assert pes[2] in '0248'
    assert pes[3:5] == '04'
    assert pes[5:7] == '16'
    assert pes[7:10] in '654'
    print(pes)
    pes = pp.pesel(datetime(1999, 8, 5), Gender.MALE)
    assert len(pes) == 11
    assert pes[:2] == '99'
    assert pes[2] in '13579'
    assert pes[3:5] == '08'
   

# Generated at 2022-06-21 15:22:16.642838
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider(seed=1234)
    regon = provider.regon()
    assert regon == '842132739'


# Generated at 2022-06-21 15:22:18.996552
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():

    pl_provider = PolandSpecProvider()
    prov = pl_provider.regon()
    assert isinstance(prov, str)


# Generated at 2022-06-21 15:22:22.377205
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider()
    regon = provider.regon()
    print("Numer REGON: " + regon)
    assert len(regon) == 9
    return 0


# Generated at 2022-06-21 15:22:24.630694
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider()
    result = provider.regon()
    print(result)


# Generated at 2022-06-21 15:22:27.899542
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    testObject = PolandSpecProvider()
    for i in range(0, 1000):
        assert re.match("^[0-9]{9}$", testObject.regon()) is not None


# Generated at 2022-06-21 15:22:29.951918
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    nip = PolandSpecProvider().nip()
    assert len(nip) == 10
    assert nip.isdigit() == True


# Generated at 2022-06-21 15:22:34.151000
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    PolandSpecProvider_object = PolandSpecProvider(seed = 1)
    # Generate
    result = PolandSpecProvider_object.nip()
    assert result == '1391119781'


# Generated at 2022-06-21 15:22:38.713548
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    poland_spec_provider = PolandSpecProvider()
    assert poland_spec_provider.locale == 'pl'
    assert not poland_spec_provider.seed
    assert poland_spec_provider.datetime_provider is not None
    

# Generated at 2022-06-21 15:22:40.355258
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    p = PolandSpecProvider()
    print(p.pesel(), p.nip(), p.regon())

# Generated at 2022-06-21 15:23:07.215042
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Unit test for method regon of class PolandSpecProvider."""
    def test_regons_created_by_regon_method():
        """Unit test that checks if regons are generated correctly."""
        ps = PolandSpecProvider()
        ps.seed_provider.enable_random_data_fallback()
        regons = [ps.regon() for _ in range(1000)]
        assert len(regons) == 1000

        valid_regons = [r for r in regons if len(r) == 9]
        assert len(valid_regons) == 1000

    test_regons_created_by_regon_method()


# Generated at 2022-06-21 15:23:09.373971
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    for i in range(100):
        assert len(p.pesel()) == 11


# Generated at 2022-06-21 15:23:10.586569
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    ppp = PolandSpecProvider()
    assert ppp


# Generated at 2022-06-21 15:23:11.961423
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    pr = PolandSpecProvider()
    assert len(str(pr.regon())) == 9

# Generated at 2022-06-21 15:23:13.889415
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    pesel = PolandSpecProvider.Meta.name
    assert pesel == 'poland_provider'

# Unit tests for method nip

# Generated at 2022-06-21 15:23:16.520610
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p1 = PolandSpecProvider()
    p2 = PolandSpecProvider()
    assert len(p1.pesel(gender='MALE')) == 11
    assert len(p2.pesel(gender='FEMALE')) == 11


# Generated at 2022-06-21 15:23:22.895831
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    ps = PolandSpecProvider()
    assert(ps.nip())
    assert(ps.nip(Gender.MALE))
    assert(ps.nip(Gender.FEMALE))
    assert(ps.pesel())
    assert(ps.pesel(Gender.MALE))
    assert(ps.pesel(Gender.FEMALE))
    assert(ps.regon())

# Generated at 2022-06-21 15:23:24.890168
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pl = PolandSpecProvider()
    result = pl.pesel()
    assert len(result) == 11
    assert result.isnumeric()

# Generated at 2022-06-21 15:23:26.998184
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    polandSpecProvider = PolandSpecProvider()
    assert polandSpecProvider.__class__.__name__ == 'PolandSpecProvider'


# Generated at 2022-06-21 15:23:30.190158
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    # Test object of class PolandSpecProvider
    pl_provider = PolandSpecProvider()

    # For example, let's generate a valid NIP number
    nip = pl_provider.nip()
    print("NIP number:", nip)

# Generated at 2022-06-21 15:24:09.943596
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider()
    result = provider.regon()
    assert type(result) is str
    assert len(result) == 9


# Generated at 2022-06-21 15:24:16.547473
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    xml = '<testcase classname="PolandSpecProvider" name="regon"></testcase>\n'
    with open("results.xml", "a") as f:
        f.write(xml)

    results_file = open("results.xml", "a")
    provider = PolandSpecProvider(seed=42)
    regon = provider.regon()
    if regon == "823586020":
        test_result = '"success"'
    else:
        test_result = '"failure"'
    results_file.write(f'<testresult {test_result}>{regon}</testresult>\n')
    results_file.close()


# Generated at 2022-06-21 15:24:17.105431
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    PolandSpecProvider()

# Generated at 2022-06-21 15:24:27.706113
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()

    pesel = provider.pesel(birth_date=None, gender=Gender.MALE)
    assert re.fullmatch("[0-9]{11}", pesel) != None
    pesel = provider.pesel(birth_date=None, gender=Gender.FEMALE)
    assert re.fullmatch("[0-9]{11}", pesel) != None
    pesel = provider.pesel(birth_date=None, gender=Gender.BOTH)
    assert re.fullmatch("[0-9]{11}", pesel) != None

    date_object = Datetime().datetime(1940, 2018)
    pesel = provider.pesel(birth_date=date_object, gender=Gender.MALE)

# Generated at 2022-06-21 15:24:29.483739
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    print("Test for method regon of class PolandSpecProvider")
    provider = PolandSpecProvider()
    for _ in range(5):
        print(provider.regon())


# Generated at 2022-06-21 15:24:37.952919
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    from mimesis.enums import Gender
    my_p = PolandSpecProvider()
    pesel_result = my_p.pesel(gender=Gender.MALE)
    if len(pesel_result) == 11:
        print('Unit test for method pesel of class PolandSpecProvider, PASS')
    else:
        print('Unit test for method pesel of class PolandSpecProvider, FAIL')
    print('pesel: {}'.format(pesel_result))

#Unit test for method regon of class PolandSpecProvider

# Generated at 2022-06-21 15:24:40.966472
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    print(provider.pesel())
    print(provider.pesel(gender=Gender.MALE))
    print(provider.pesel(gender=Gender.FEMALE))


# Generated at 2022-06-21 15:24:46.460487
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    p = PolandSpecProvider(seed=0)
    assert p.nip() == '7193230283'
    assert p.pesel(birth_date=p.datetime(1940, 2018)) == "67110717078"
    assert p.pesel(birth_date=p.datetime(1940, 2018), gender=Gender.FEMALE) == "67110717078"
    assert p.pesel(birth_date=p.datetime(1940, 2018), gender=Gender.MALE) == "67110717078"
    assert p.regon() == '336959386'

# Generated at 2022-06-21 15:24:51.606954
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():                                                                
    d = PolandSpecProvider()                                                                  
    assert hasattr(d, 'nip')                                                                  
    d.nip()                                                                                   
    d.pesel()                                                                                 
    d.regon()

# Generated at 2022-06-21 15:24:54.696791
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    id_numer = provider.nip()
    assert len(id_numer) == 10
    assert id_numer.isdigit()

