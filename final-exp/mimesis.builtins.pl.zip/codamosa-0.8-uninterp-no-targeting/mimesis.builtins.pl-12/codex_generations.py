

# Generated at 2022-06-21 15:22:07.503129
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """
    Test pesel function
    """
    poland = PolandSpecProvider()
    pesel_number = poland.pesel(Gender.FEMALE)
    assert len(pesel_number) == 11, "The number is not of 11 size"
    assert int(pesel_number[10]) % 2 == 0, "The number is not an female"


# Generated at 2022-06-21 15:22:08.377131
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    PolandSpecProvider.regon()

# Generated at 2022-06-21 15:22:11.340321
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    for _ in range(100):
        nip = PolandSpecProvider().nip()
        assert len(nip) == 10


# Generated at 2022-06-21 15:22:17.427699
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    from mimesis.providers import PolandProvider
    nip_list = []
    for i in range(100):
        nip = PolandProvider().nip()
        nip_list.append(nip)
    assert nip_list.__len__() == 100
    assert nip_list.__contains__('8800204531') == False


# Generated at 2022-06-21 15:22:19.719191
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    random.seed(42)
    for _ in range(10):
        print(PolandSpecProvider().nip())



# Generated at 2022-06-21 15:22:30.344719
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
# Create instance of class PolandSpecProvider
    polandSpecProvider = PolandSpecProvider()
# Create empty list
    list = []
# Generate 1000 PESEL numbers and add them to the list
    for i in range(0,1000):
        pesel = polandSpecProvider.pesel()
        list.append(pesel)

# Count number of PESELs that were generated for each year
    for year in range(1940,2018):
        for pesel in list:
            if pesel[0:2] == str(year):
                count = list.count(pesel)
                print("PESEL: " + str(pesel) + " was generated " + str(count) + " times")

# Run the test
test_PolandSpecProvider_pesel()

# Generated at 2022-06-21 15:22:33.531210
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    pl = PolandSpecProvider(seed=4)

    assert pl.nip() == '3263857435'


# Generated at 2022-06-21 15:22:37.108304
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert pesel[:2] in provider.range('40', '99')
    assert pesel[2:4] in provider.range('01', '12')
    assert pesel[4:6] in provider.range('01', '31')
    assert pesel[6:9] in provider.range('000', '999')
    assert pesel[9] in provider.range('0', '9')
    assert pesel[10] in provider.range('0', '9')

# Generated at 2022-06-21 15:22:45.986774
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    p1 = PolandSpecProvider()
    assert p1.random.randint(0, 10000) != p1.random.randint(0, 10000)
    assert p1.random.randint(0, 10000) != p1.random.randint(0, 10000)
    assert p1.random.randint(0, 10000) != p1.random.randint(0, 10000)
    p2 = PolandSpecProvider(seed=1234)
    assert p2.random.randint(0, 10000) == p2.random.randint(0, 10000)
    assert p2.random.randint(0, 10000) == p2.random.randint(0, 10000)
    assert p2.random.randint(0, 10000) == p2.random.randint(0, 10000)


# Generated at 2022-06-21 15:22:47.035432
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    PolandSpecProvider()

# Generated at 2022-06-21 15:23:11.279702
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    nip = PolandSpecProvider().nip()
    assert len(nip) == 10
    assert all(str(d) in str(nip) for d in range(10))


# Generated at 2022-06-21 15:23:19.267493
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # Initialization of a class
    provider = PolandSpecProvider()
    # Generate the PESEL and print it to the console
    pesel = provider.pesel()
    print(pesel)
    # Check the result
    assert len(pesel) == 11
    assert pesel[0:2] in ['18', '19', '20', '21', '22', '23']
    assert pesel[2:4] in ['01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12']

# Generated at 2022-06-21 15:23:29.701122
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    import calendar

    from mimesis.enums import Gender
    p = PolandSpecProvider(seed=42)
    # print(p.pesel())

    for year in range(1940, 2018):
        for month in range(1, 13):
            for day in range(1, calendar.monthrange(year, month)[1] + 1):
                pesel = p.pesel(birth_date=p.datetime(year, year, month, month, day, day))
                result = int(pesel[2:4]) - 1
                if result == 0:
                    print('pesel = ', pesel, ', result = ', result)
                    # assert result == 11
                year_of_birth = int(pesel[0:2])
                if year < 2000:
                    year_of_birth += 1900

# Generated at 2022-06-21 15:23:31.143284
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    cpp = PolandSpecProvider()
    print(cpp.nip())

# Generated at 2022-06-21 15:23:33.097578
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    m = PolandSpecProvider()
    pesel = m.pesel()
    assert len(pesel) == 11


# Generated at 2022-06-21 15:23:35.839015
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Unit test for provider PolandSpecProvider."""
    print("Test constructor of class PolandSpecProvider.")
    provider = PolandSpecProvider()
    print("End of test constructor.")
    return provider


# Generated at 2022-06-21 15:23:41.158451
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    assert PolandSpecProvider().pesel() != PolandSpecProvider().pesel()
    assert (PolandSpecProvider().pesel(birth_date=Datetime(seed=42).datetime(min_year=2000)) != PolandSpecProvider().pesel(birth_date=Datetime(seed=42).datetime(min_year=2000)))
    assert (PolandSpecProvider(seed=42).pesel() == PolandSpecProvider(seed=42).pesel())
    assert PolandSpecProvider(seed=100).pesel(birth_date=Datetime(seed=42).datetime(min_year=2000)) == PolandSpecProvider(seed=100).pesel(birth_date=Datetime(seed=42).datetime(min_year=2000))

# Generated at 2022-06-21 15:23:48.020429
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test pesel method of class PolandSpecProvider."""
    print(PolandSpecProvider().pesel(birth_date='1995-01-01', gender=Gender.MALE))
    print(PolandSpecProvider().pesel(birth_date='1995-01-01', gender=Gender.FEMALE))
    print(PolandSpecProvider().pesel(birth_date='1995-01-01'))
    print(PolandSpecProvider().pesel())

# Generated at 2022-06-21 15:23:50.510876
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    psp = PolandSpecProvider()
    nip = psp.nip()
    print(nip)
    assert len(nip) == 10


# Generated at 2022-06-21 15:23:54.770060
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    poland_spec_provider = PolandSpecProvider()
    pesel_generated = poland_spec_provider.pesel(gender=Gender.MALE)
    pesel_generated = int(pesel_generated)
    assert pesel_generated >= 10000000000 and pesel_generated < 100000000000, "Exception in method pesel of class PolandSpecProvider"


# Generated at 2022-06-21 15:26:13.336152
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    print("pesel: " + provider.pesel())
    #pesel: 51050519887



# Generated at 2022-06-21 15:26:18.595605
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    plp = PolandSpecProvider()
    nip_result = plp.nip()
    assert nip_result != ""
    assert all(i in '1234567890' for i in nip_result)
    assert len(nip_result) == 10



# Generated at 2022-06-21 15:26:22.162511
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Test method regon of class PolandSpecProvider."""
    provider = PolandSpecProvider()
    regon = provider.regon()
    assert len(regon) == 9

# Generated at 2022-06-21 15:26:28.989595
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider"""
    test_provider = PolandSpecProvider()
    expected_gender = Gender.FEMALE
    expected_date_object = Datetime().datetime(1998, 1998)

    result = test_provider.pesel(expected_date_object, expected_gender)
    result_gender = Gender.MALE if int(result[9]) % 2 else Gender.FEMALE
    result_year = int('19' + result[0] + result[1])
    result_month = int(result[2] + result[3])
    result_day = int(result[4] + result[5])

    assert result_month <= 12
    assert result_day <= 31
    assert result_year <= 2018
    assert result_gender == expected_gender
    assert result_month == expected_date

# Generated at 2022-06-21 15:26:33.728135
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    p = PolandSpecProvider()
    pesel = p.nip()
    assert isinstance(pesel, str)
    assert len(pesel) == 10
    assert int(pesel) > 101000000
    assert int(pesel) < 998999999


# Generated at 2022-06-21 15:26:43.604711
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Unit test for method regon of class PolandSpecProvider."""
    def test_cases(number):
        for _ in range(number):
            provider = PolandSpecProvider(seed=Seed.create_from_hex(hex(number).lstrip('0x')))
            regon_result: str = provider.regon()
            if len(regon_result) != 9:
                print("Test case fail. Regon is not a 9-digit number.")

    test_cases(5)

# Generated at 2022-06-21 15:26:47.256787
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    seed = 11
    pl_provider = PolandSpecProvider(seed=seed)
    # Test the constructor
    assert pl_provider is not None
    assert pl_provider._random.seed == seed
    assert pl_provider.locale == 'pl'


# Generated at 2022-06-21 15:26:49.742052
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    assert provider.__class__.__name__ == 'PolandSpecProvider'

# Generated at 2022-06-21 15:26:57.577218
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    print("*** Test method nip of class PolandSpecProvider ***")
    pl1 = PolandSpecProvider()
    print("Random NIP:",pl1.nip())
    print("Random NIP:",pl1.nip())
    print("Random NIP:",pl1.nip())
    print("Random NIP:",pl1.nip())
    print("Random NIP:",pl1.nip())
    print("Random NIP:",pl1.nip())
    print("Random NIP:",pl1.nip())
    print("Random NIP:",pl1.nip())
    print("Random NIP:",pl1.nip())
    print("Random NIP:",pl1.nip())
    print("Random NIP:",pl1.nip())

# Generated at 2022-06-21 15:27:03.875996
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    pl_provider = PolandSpecProvider()
    nip = pl_provider.nip()
    assert len(nip) == 10
    assert nip[0] in (1, 2, 3, 5, 6, 7, 8, 9)
    assert nip[1] in (0, 1, 2, 3, 4, 5, 6, 7, 8, 9)
