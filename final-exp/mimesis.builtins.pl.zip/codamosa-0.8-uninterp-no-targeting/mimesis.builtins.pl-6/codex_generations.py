

# Generated at 2022-06-21 15:22:06.961704
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider(seed = 1)

    pesel = provider.pesel(birth_date = None, gender = None)
    assert pesel == "57092302905"

    pesel = provider.pesel(birth_date = Datetime().datetime(1988, 12, 24), gender = Gender.MALE)
    assert pesel == "88122417243"

    pesel = provider.pesel(birth_date = Datetime().datetime(1988, 12, 24), gender = Gender.FEMALE)
    assert pesel == "88122415896"


# Generated at 2022-06-21 15:22:09.441759
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():

    provider = PolandSpecProvider()
    nip = provider.nip()
    assert len(nip) == 10

    for digit in nip:
        assert digit in range(10)


# Generated at 2022-06-21 15:22:12.566286
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Test method regon of class PolandSpecProvider"""
    assert PolandSpecProvider().regon() == "712568602"


# Generated at 2022-06-21 15:22:18.097454
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    from mimesis.enums import Gender
    poland_spec_provider = PolandSpecProvider()
    poland_spec_provider.nip()
    poland_spec_provider.pesel(gender=Gender.MALE)
    poland_spec_provider.regon()
    assert poland_spec_provider is not None

# Generated at 2022-06-21 15:22:23.483092
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    assert provider.pesel(gender=Gender.FEMALE) == '73010400134'
    assert provider.pesel(gender=Gender.MALE) == '69010100232'
    assert provider.pesel(birth_date=Datetime().datetime(2018, 1, 1)) == '98010100547'

# Generated at 2022-06-21 15:22:25.838461
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    nip_data = provider.nip()
    print(nip_data)


# Generated at 2022-06-21 15:22:28.738832
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    rng = random.Random(1024)
    p = PolandSpecProvider(rng.seed)
    pesel = p.pesel()
    assert pesel == '92010112358'

# Generated at 2022-06-21 15:22:36.418287
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    instance = PolandSpecProvider(seed=0)
    assert instance.pesel(birth_date=Datetime(seed=0).datetime(2010,2019), gender=Gender.FEMALE) == '1912107116'
    assert instance.pesel(birth_date=Datetime(seed=0).datetime(2010,2019), gender=Gender.MALE) == '1912107114'


# Generated at 2022-06-21 15:22:38.045634
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    assert(len(PolandSpecProvider().nip())==10)

# Generated at 2022-06-21 15:22:39.066458
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    PolandSpecProvider(seed=1)

# Generated at 2022-06-21 15:22:55.222980
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    print("\n--- test_PolandSpecProvider_pesel ---\n")

    random.seed(1)
    pesel = PolandSpecProvider().pesel()
    print("Pesel: {}\n".format(pesel))
    assert pesel == "20032228555"

# Generated at 2022-06-21 15:22:57.187363
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    assert provider.nip() == '5212864354'


# Generated at 2022-06-21 15:23:08.670568
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider"""
    pr = PolandSpecProvider()
    p = pr.pesel()
    assert len(p) == 11
    if int(p[9]) % 2 == 0:
        assert pr.gender == 'female'
    else:
        assert pr.gender == 'male'
    year = int(p[0:2])
    if int(p[2:4]) <= 12:
        pass
    elif (int(p[2:4]) > 12) and (int(p[2:4])<= 32):
        year += 1800
    elif int(p[2:4]) > 32 and (int(p[2:4]) <= 52):
        year += 1900

# Generated at 2022-06-21 15:23:09.986486
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    polandspecprovider = PolandSpecProvider()
    assert polandspecprovider

# Generated at 2022-06-21 15:23:12.727085
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    seed = 11113141524
    psp = PolandSpecProvider(seed)
    nip = psp.nip()
    assert nip == '3296246051'



# Generated at 2022-06-21 15:23:15.524850
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    assert provider.nip() == '6010569795'
    assert provider.pesel() == '14072605992'
    assert provider.regon() == '979333250'


# Generated at 2022-06-21 15:23:17.623923
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    pl = PolandSpecProvider()
    assert isinstance(pl, PolandSpecProvider)
    assert isinstance(pl, BaseSpecProvider)
    assert pl.seed is not None


# Generated at 2022-06-21 15:23:23.746603
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Unit test by Artyom Litvinenko
    """
    id = PolandSpecProvider().regon()
    assert len(id) == 9, 'Wrong REGON length'
    assert id.isdigit(), 'REGON contains not digit characters'
    assert PolandSpecProvider().validate_regon(id), 'REGON is not valid'



# Generated at 2022-06-21 15:23:25.824339
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    pesel = PolandSpecProvider()
    nip = pesel.nip()
    assert len(nip) == 10


# Generated at 2022-06-21 15:23:28.902122
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Test method nip of class PolandSpecProvider."""
    assert len(PolandSpecProvider().nip()) == 10
    assert PolandSpecProvider().nip().isdigit()



# Generated at 2022-06-21 15:24:00.422229
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Test nip method."""
    for i in range(100):
        nip = PolandSpecProvider().nip()
        if int(nip[9]) == 9:
            continue
        assert int(nip[9]) == (7 * int(nip[0]) +
                    6 * int(nip[1]) +
                    5 * int(nip[2]) +
                    4 * int(nip[3]) +
                    3 * int(nip[4]) +
                    2 * int(nip[5]) +
                    int(nip[6])) % 11


# Generated at 2022-06-21 15:24:03.114189
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    import random
    import re
    p = PolandSpecProvider(random.SystemRandom())
    regon = p.regon()
    # Check if REGON is valid
    assert re.match(r'\d{9}', regon)


# Generated at 2022-06-21 15:24:03.953323
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    assert PolandSpecProvider() is not None


# Generated at 2022-06-21 15:24:08.495945
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    nipProvider = PolandSpecProvider()
    nip = nipProvider.nip()
    print("\nNIP: ", nip)
    assert len(nip) == 10

# Generated at 2022-06-21 15:24:10.501022
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    instance = PolandSpecProvider()
    regon = instance.regon()
    assert len(regon) == 9


# Generated at 2022-06-21 15:24:11.754278
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    assert PolandSpecProvider().__class__ == PolandSpecProvider


# Generated at 2022-06-21 15:24:16.146618
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    from mimesis.enums import Gender
    from datetime import datetime
    from mimesis import PolandSpecProvider

    pesel_exec1 = PolandSpecProvider().pesel()
    pesel_exec2 = PolandSpecProvider().pesel(
        gender=Gender.MALE,
        birth_date=datetime.now()
    )
    print(pesel_exec1)
    print(pesel_exec2)


# Generated at 2022-06-21 15:24:26.771380
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    date_object = '2000-07-04'
    pesel = PolandSpecProvider().pesel(date_object, gender=Gender.MALE)
    bool = True
    if not int(pesel[0:2]) == int(date_object[2:4]):
        bool = False
    if not int(pesel[2]) == 0:
        bool = False
    if not int(pesel[3:5]) == int(date_object[5:7]):
        bool = False
    if not int(pesel[5:7]) == int(date_object[8:10]):
        bool = False
    if not int(pesel[7:10]) == 150:
        bool = False

# Generated at 2022-06-21 15:24:28.829774
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Unit test for method regon of class PolandSpecProvider."""
    p = PolandSpecProvider()
    print(p.regon())
    return True


# Generated at 2022-06-21 15:24:32.037637
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    # TODO: Shouldn't this be working?
    # p = PolandSpecProvider()
    # print(p)
    assert int(42) == 42

# Generated at 2022-06-21 15:24:57.908654
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider(seed=42)
    assert p.pesel(birth_date=p.datetime(1900, 2020), gender=p.gender()) == '75072400331'

# Generated at 2022-06-21 15:25:01.681233
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    if len(provider.nip()) == 10:
        print("Unit test for method nip of class PolandSpecProvider: SUCCESS")
    else:
        print("Unit test for method nip of class PolandSpecProvider: FAIL")


# Generated at 2022-06-21 15:25:03.207721
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    # Тест не предполагает повторных выполнений
    provider = PolandSpecProvider()
    assert provider.nip()


# Generated at 2022-06-21 15:25:07.506652
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    from mimesis.enums import Gender
    from mimesis.providers import PolandSpecProvider
    # Datetime().datetime(start=1940, end=2018)
    poland = PolandSpecProvider()
    print(poland.pesel(birth_date=poland.datetime(1940, 2018), gender=Gender.MALE))

# Generated at 2022-06-21 15:25:11.944120
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    import os

    for i in range(10):
        pesel = PolandSpecProvider(seed=os.urandom(10)).pesel(gender=Gender.MALE)
        assert len(pesel) == 11


# Generated at 2022-06-21 15:25:21.996528
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    p = PolandSpecProvider(seed=100)
    assert p.nip() == "8383724227"
    assert p.pesel() == "84081136739"
    assert p.pesel(gender=Gender.MALE) == "99011394147"
    assert p.pesel(gender=Gender.FEMALE) == "96022236472"
    assert p.regon() == "279816750"
    assert p.pesel(birth_date=p.datetime(1940, 2018)) == "96022236472"
    assert p.nip() == "8383724227"
    assert p.pesel(gender=Gender.FEMALE) == "96022236472"
    assert p.regon() == "279816750"

# Generated at 2022-06-21 15:25:24.632701
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider(seed = 'Pesel')
    pesel = provider.pesel(gender = Gender.MALE)
    print(pesel)  #42040407035


# Generated at 2022-06-21 15:25:26.065411
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    assert PolandSpecProvider().pesel() == '58071325906'

# Generated at 2022-06-21 15:25:27.990497
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    p = PolandSpecProvider()
    print(p.nip())


# Generated at 2022-06-21 15:25:31.580842
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Check if pesel method works properly."""
    A = PolandSpecProvider()
    assert(A.pesel(birth_date=None, gender=Gender.MALE))
    assert(A.pesel(birth_date=None, gender=Gender.FEMALE))
    assert(A.pesel())
    assert(A.pesel(gender=str))

# Generated at 2022-06-21 15:25:54.834066
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    nip = PolandSpecProvider(seed=42).nip()
    assert nip == '2052143430'


# Generated at 2022-06-21 15:25:55.628627
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    assert PolandSpecProvider() != None


# Generated at 2022-06-21 15:25:57.900065
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    assert (PolandSpecProvider.pesel(Gender.FEMALE) == '09021205880')
    assert (PolandSpecProvider.pesel(Gender.MALE) == '03060704511')

# Generated at 2022-06-21 15:26:08.099014
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """
    Testing method pesel of class PolandSpecProvider
    """
    
    from datetime import date
    from mimesis.enums import Gender
    from mimesis.providers import PolandSpecProvider
    poland_provider = PolandSpecProvider()
    # test 1
    gender = Gender.MALE
    birth_date = date(1988, 6, 29)
    pesel = poland_provider.pesel(birth_date, gender)
    assert pesel[:6] == '880629'
    assert len(pesel) == 11
    assert int(pesel[6]) in [0, 2, 4, 6, 8]
    assert int(pesel[7:10]) < 1000
    
    # test 2 - pre-1800 PESEL
    gender = Gender.MALE

# Generated at 2022-06-21 15:26:09.078558
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    assert PolandSpecProvider().regon() == '33600716'

# Generated at 2022-06-21 15:26:10.774159
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Test method nip of class PolandSpecProvider."""
    c = PolandSpecProvider()
    answer = c.nip()
    assert type(answer) is str
    assert len(answer) == 10


# Generated at 2022-06-21 15:26:19.174920
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Test for PolandSpecProvider.nip method."""
    tester = PolandSpecProvider()

    # Valid NIP test
    nip = tester.nip()
    assert len(nip) == 10
    try:
        int(nip)
    except ValueError:
        raise ValueError("NIP is not an integer!")
    try:
        assert int(nip) in range(101, 998)
    except AssertionError:
        raise AssertionError("NIP is not valid!")



# Generated at 2022-06-21 15:26:27.662812
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Test method nip by checking if all generated nips are valid."""
    nip_provider = PolandSpecProvider()
    nips_sample = [nip_provider.nip() for i in range(100)]

    def check_nip(nip_string):
        checksum_digit = nip_string[-1]
        nip_digits = [int(d) for d in nip_string[:-1]]
        nip_coefficients = (6, 5, 7, 2, 3, 4, 5, 6, 7)
        sum_v = sum([nc * nd for nc, nd in
                     zip(nip_coefficients, nip_digits)])
        checksum_digit = sum_v % 11
        return checksum_digit <= 9


# Generated at 2022-06-21 15:26:30.396856
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    pr = PolandSpecProvider()
    assert len(pr.nip()) == 10


# Generated at 2022-06-21 15:26:31.765081
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    # Constructor
    PolandSpecProvider()

# Generated at 2022-06-21 15:26:54.919022
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    assert provider.__init__ is not None


# Generated at 2022-06-21 15:27:05.922243
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    import datetime
    import unittest

    pl = PolandSpecProvider()
    result = pl.pesel()
    assert len(result) == 11
    pesel_digits = [int(d) for d in result]
    pesel_coeffs = (9, 7, 3, 1, 9, 7, 3, 1, 9, 7)
    sum_v = sum([nc * nd for nc, nd in zip(pesel_coeffs, pesel_digits)])
    checksum_digit = sum_v % 10
    assert checksum_digit == pesel_digits[-1]

    datetime_birth = datetime.datetime(1990, 12, 12, 12, 12, 12)
    result = pl.pesel(birth_date=datetime_birth, gender=Gender.FEMALE)

# Generated at 2022-06-21 15:27:10.181175
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Test for method regon of class PolandSpecProvider."""
    # Example of valid REGON number taken from https://pl.wikipedia.org/wiki/REGON
    regon = PolandSpecProvider().regon()
    assert len(regon) == 9
    assert regon == '371702066'


# Generated at 2022-06-21 15:27:11.144808
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    assert len(PolandSpecProvider().regon()) == 9

# Generated at 2022-06-21 15:27:13.266960
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    Poland = PolandSpecProvider()
    assert isinstance(Poland, PolandSpecProvider)

# Generated at 2022-06-21 15:27:18.568533
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Unit Test for method regon of class PolandSpecProvider"""
    print("test_PolandSpecProvider_regon")
    test_provider = PolandSpecProvider(seed=42)
    actual = test_provider.regon()
    expected = '632878014'
    assert actual == expected



# Generated at 2022-06-21 15:27:28.573638
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    # Case 1: default call
    pesel_number = PolandSpecProvider().pesel()
    assert len(pesel_number) == 11
    assert pesel_number.isdigit()

    # Case 2: set birth_date, set gender
    pesel_number = PolandSpecProvider().pesel(birth_date=Datetime().datetime(1930, 1966),
                                              gender=Gender.MALE)
    assert len(pesel_number) == 11
    assert pesel_number.isdigit()

    # Case 3: set birth_date, do not set gender
    pesel_number = PolandSpecProvider().pesel(birth_date=Datetime().datetime(1940, 1998))
    assert len(pesel_number) == 11
    assert pesel

# Generated at 2022-06-21 15:27:30.131968
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    kod1 = PolandSpecProvider().nip()
    assert int(kod1[:3]) in range(101,999)


# Generated at 2022-06-21 15:27:33.037569
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    obj = PolandSpecProvider()
    assert obj.nip() == '5822799339'
    assert obj.pesel() == '02265572170'
    assert obj.regon() == '391375661'

# Generated at 2022-06-21 15:27:35.197184
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """
    Test method regon()
    """
    a = PolandSpecProvider()
    result = a.regon()
    assert len(result) == 9

