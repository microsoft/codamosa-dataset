

# Generated at 2022-06-21 15:22:03.601087
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
  tz_krakow = 25200
  pesel = PolandSpecProvider().pesel()
  assert len(pesel) == 11

# Generated at 2022-06-21 15:22:06.961629
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    pl = PolandSpecProvider()
    print(pl.nip())
    print(pl.pesel())
    print(pl.regon())

if __name__ == "__main__":
    # Unit test for constructor of class PolandSpecProvider
    test_PolandSpecProvider()

# Generated at 2022-06-21 15:22:09.928320
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    from mimesis.builtins import PolandSpecProvider
    from mimesis.enums import Gender
    poland_spec_provider = PolandSpecProvider()
    for _ in range (20):
        print(poland_spec_provider.pesel())

# Generated at 2022-06-21 15:22:13.601395
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    p = PolandSpecProvider()
    for i in range(100):
        regon = p.regon()
        assert regon.isnumeric()
        assert len(regon) == 9

# Generated at 2022-06-21 15:22:17.728104
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Test method nip of class PolandSpecProvider."""
    provider = PolandSpecProvider(seed=0)
    result = provider.nip()
    correct_result = '2786828200'
    assert result == correct_result


# Generated at 2022-06-21 15:22:19.713355
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    p = PolandSpecProvider();
    result = p.regon()
    print(result)
    #assert isinstance(result,str)
    assert len(result) == 9
    #assert 
    #assert result() ==

# Generated at 2022-06-21 15:22:21.829136
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    pl = PolandSpecProvider(seed=1337)
    assert pl.nip() == '2157102338'

# Generated at 2022-06-21 15:22:28.512051
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    assert len(provider.pesel()) == 11
    assert provider.pesel().isdigit()
    assert provider.pesel(gender=Gender.MALE).endswith(('1', '3', '5', '7', '9'))
    assert provider.pesel(gender=Gender.FEMALE).endswith(('0', '2', '4', '6', '8'))


# Generated at 2022-06-21 15:22:31.406787
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    psp = PolandSpecProvider()
    assert psp.nip()
    assert psp.region_code
    assert psp.street_suffix
    assert psp.voivodeship
    assert psp.pesel()
    assert psp.regon()

# Generated at 2022-06-21 15:22:36.204733
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel(birth_date=None, gender=Gender.FEMALE)
    assert len(pesel) == 11
    assert int(pesel[-1]) in (0, 2, 4, 6, 8)

# Generated at 2022-06-21 15:22:46.004972
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    seed = "1234567890"
    test_obj = PolandSpecProvider(seed=seed)
    assert (test_obj.nip() == "2622333893" )


# Generated at 2022-06-21 15:22:50.934537
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    result = provider.nip()
    assert result != None
    assert result != ""
    assert len(result) == 10
    assert result.isdigit() == True
    assert int(result) > 100000000 and int(result) < 1000000000


# Generated at 2022-06-21 15:22:51.897085
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    assert PolandSpecProvider().regon() == '859122356'



# Generated at 2022-06-21 15:22:56.221214
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Use method regon() from class PolandSpecProvider."""
    test = PolandSpecProvider()
    test.seed(0)
    assert test.regon() != '554764320'
    assert test.regon() == '682434223'
    assert test.regon() == '173425605'
    assert test.regon() == '716793137'


# Generated at 2022-06-21 15:22:57.669625
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    assert len(str(PolandSpecProvider().nip())) == 10


# Generated at 2022-06-21 15:23:09.224937
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Unit test for constructor of class PolandSpecProvider."""
    provider_1 = PolandSpecProvider()
    provider_2 = PolandSpecProvider()

    for _ in range(10):
        assert len(provider_1.nip()) == 10
        assert len(provider_1.nip()) == 10
        assert len(provider_1.pesel()) == 11
        assert len(provider_1.pesel(birth_date=Datetime().datetime())) == 11
        assert len(provider_1.pesel(gender=Gender.MALE)) == 11
        assert len(provider_1.pesel(birth_date=Datetime().datetime(), gender=Gender.MALE)) == 11
        assert len(provider_1.regon()) == 9
        assert len(provider_2.nip()) == 10

# Generated at 2022-06-21 15:23:12.127813
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    pl = PolandSpecProvider()
    regon = pl.regon()
    assert len(regon) == 9
    # input field in e-dokumenty.eu.com has only 9 digits
    assert int(regon) > 0


# Generated at 2022-06-21 15:23:14.694619
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Test regon method of PolandSpecProvider class."""
    # Generate random valid 9-digit REGON
    result = PolandSpecProvider().regon()

    assert len(result) == 9


# Generated at 2022-06-21 15:23:24.004157
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    for i in range(100):
        nip = PolandSpecProvider().nip()
        nip_coeffs = (6, 5, 7, 2, 3, 4, 5, 6, 7)
        nip_digits = [int(d) for d in nip]
        sum_v = sum([nc * nd for nc, nd in
                 zip(nip_coeffs, nip_digits)])
        checksum = sum_v % 11

        assert len(nip) == 10
        assert 101 <= int(nip[:3]) <= 998
        assert checksum <= 9


# Generated at 2022-06-21 15:23:29.272060
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    pl_provider = PolandSpecProvider()
    regon_numbers = []
    for i in range(100):
        regon_numbers.append(pl_provider.regon())
        regon_numbers.append(pl_provider.regon(seed=i))

    assert len(regon_numbers) == 200
    assert len(set(regon_numbers)) == 200



# Generated at 2022-06-21 15:23:36.044061
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    assert len(provider.nip()) == 10


# Generated at 2022-06-21 15:23:39.506045
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Test nip method of class PolandSpecProvider"""

    provider = PolandSpecProvider()
    nip = provider.nip()
    print("nip = {}".format(nip))
    assert len(nip) == 10


# Generated at 2022-06-21 15:23:47.207886
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    from datetime import datetime

    provider = PolandSpecProvider()
    assert provider.pesel() == provider.pesel(datetime(2018,12,12))
    assert provider.pesel(datetime(1900,12,12)) == \
        provider.pesel(datetime(1900,12,12), Gender.MALE)
    assert provider.pesel(datetime(1900,12,12), Gender.FEMALE) == \
        provider.pesel(datetime(1900,12,12), Gender.FEMALE)

# Generated at 2022-06-21 15:23:50.753691
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    from mimesis.enums import Gender
    p = PolandSpecProvider()
    pesel = p.pesel(birth_date = '2000-11-11', gender = Gender.FEMALE)
    assert pesel == '00111115811'


# Generated at 2022-06-21 15:23:52.191543
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    nip1 = PolandSpecProvider().nip()
    assert len(nip1) == 10



# Generated at 2022-06-21 15:23:52.690881
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    pass

# Generated at 2022-06-21 15:23:55.934806
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Test of method nip of class PolandSpecProvider.
    """
    data_provider = PolandSpecProvider()
    print(data_provider.nip())


# Generated at 2022-06-21 15:23:58.329521
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    
    provider = PolandSpecProvider()
    assert len(provider.nip()) == 10
    assert provider.nip().isdigit()


# Generated at 2022-06-21 15:24:01.380534
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    p = PolandSpecProvider()
    nip = p.nip()
    if len(nip) != 10:
        raise AssertionError("Method nip of class PolandSpecProvider does not generate correct NIP number. (Number length is not correct.)")


# Generated at 2022-06-21 15:24:03.151678
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():

    provider = PolandSpecProvider()
    nip = provider.nip()
    assert len(nip) == 10


# Generated at 2022-06-21 15:24:56.920587
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    # given
    test_provider = PolandSpecProvider()

    # when
    result = test_provider.nip()

    # then
    assert result
    assert isinstance(result, str)
    assert len(result) == 10
    assert result.isdigit()



# Generated at 2022-06-21 15:24:57.899304
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    print(PolandSpecProvider().pesel())

# Generated at 2022-06-21 15:24:59.731212
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    print(p.pesel())


# Generated at 2022-06-21 15:25:04.784100
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    import string
    import random
    
    provider = PolandSpecProvider()
    for i in range(10):
        id = ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(9))
        id = provider.regon()
        assert len(id) == 9
        assert isinstance(id, str)


# Generated at 2022-06-21 15:25:06.023329
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    assert(len(PolandSpecProvider().nip()) == 10)

# Generated at 2022-06-21 15:25:08.258341
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    poland_spec_provider = PolandSpecProvider()
    nip = poland_spec_provider.nip()
    assert len(nip) == 10



# Generated at 2022-06-21 15:25:12.201912
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    print('test_PolandSpecProvider_nip')
    pl_provider = PolandSpecProvider()
    print(pl_provider.nip())


# Generated at 2022-06-21 15:25:14.569416
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    r = provider.pesel(gender=Gender.FEMALE)
    print(r)



# Generated at 2022-06-21 15:25:17.049206
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """
    Check if function returns string and does not raise exception.
    """
    p = PolandSpecProvider()
    assert isinstance(p.nip(), str)


# Generated at 2022-06-21 15:25:20.961201
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Unit test for method regon of class PolandSpecProvider."""
    i = PolandSpecProvider()
    tmp = []
    while len(tmp) < 10:
        res = i.regon()
        if res not in tmp:
            tmp.append(res)
    assert len(tmp) == 10



# Generated at 2022-06-21 15:27:35.266927
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    regexp = re.compile('\d{9}')
    assert re.match(regexp, PolandSpecProvider().regon()) is not None

# Generated at 2022-06-21 15:27:40.676462
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    specloc = PolandSpecProvider()
    print("Test for instance constructor of class PolandSpecProvider")
    print("Basic method:")
    print("\t", "nip:", specloc.nip())
    print("\t", "pesel:", specloc.pesel())
    print("\t", "regon:", specloc.regon())


# Generated at 2022-06-21 15:27:42.541369
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    random_regon = PolandSpecProvider.reg

# Generated at 2022-06-21 15:27:54.155654
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    assert provider is not None


# Generated at 2022-06-21 15:28:03.180343
# Unit test for method regon of class PolandSpecProvider

# Generated at 2022-06-21 15:28:04.296301
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    print('.......... Test regon ...........')
    assert len(PolandSpecProvider().regon()) == 9


# Generated at 2022-06-21 15:28:06.509652
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    unit_test = PolandSpecProvider(seed=1234)
    unit_test.random.seed(1234)
    assert unit_test.regon() == '294939593'



# Generated at 2022-06-21 15:28:07.934794
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider(seed=0)
    nip = provider.nip()
    assert nip == '1022798830'



# Generated at 2022-06-21 15:28:09.170119
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pl_provider = PolandSpecProvider()
    assert len(pl_provider.pesel()) == 11

# Generated at 2022-06-21 15:28:12.896881
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    gen_pesel = set()
    spec_provider = PolandSpecProvider()
    for i in range(1000):
        pesel = spec_provider.pesel()
        # print(pesel)
        assert len(pesel) == 11
        gen_pesel.add(pesel)
    print(gen_pesel)
    assert len(gen_pesel) == 1000
