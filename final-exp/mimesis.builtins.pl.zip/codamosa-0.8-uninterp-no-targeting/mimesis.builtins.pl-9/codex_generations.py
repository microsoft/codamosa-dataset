

# Generated at 2022-06-21 15:21:59.461146
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    print ('test PolandSpecProvider constructor')
    PolandSpecProvider()


# Generated at 2022-06-21 15:22:01.814995
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    PolandSpecProvider().nip()
    PolandSpecProvider().pesel()
    PolandSpecProvider().regon()

# Generated at 2022-06-21 15:22:05.313833
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    pesel = PolandSpecProvider().pesel(None, None)
    assert len(pesel) == 11

    nip = PolandSpecProvider().nip()
    assert len(nip) == 10

    regon = PolandSpecProvider().regon()
    assert len(regon) == 9

# Generated at 2022-06-21 15:22:09.488587
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    from mimesis.enums import Gender
    from mimesis.providers import PolandSpecProvider
    """Test for proving that method nip of class PolandSpecProvider generates valid nip number."""
    # Preconditions
    provider = PolandSpecProvider()
    Gender.FEMALE.value
    # Postconditions
    assert provider.nip()==provider.nip()


# Generated at 2022-06-21 15:22:19.176642
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():

    # Instance the class PolandSpecProvider
    poland_spec_provider = PolandSpecProvider()

    # test nip()
    nip = poland_spec_provider.nip()
    print(nip)
    assert len(nip) == 10

    # test pesel()
    pesel = poland_spec_provider.pesel()
    print(pesel)
    assert len(pesel) == 11

    # test regon()
    regon = poland_spec_provider.regon()
    print(regon)
    assert len(regon) == 9


# Generated at 2022-06-21 15:22:21.264401
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    pl = PolandSpecProvider()
    reg = pl.regon()
    print(reg)


# Generated at 2022-06-21 15:22:24.525911
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    r = PolandSpecProvider(seed=None)

    assert r.nip() is not None
    assert r.pesel() is not None
    assert r.regon() is not None

# Generated at 2022-06-21 15:22:25.777575
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider(seed=20)
    print(provider.pesel(birth_date=None, gender=None))

# Generated at 2022-06-21 15:22:28.280535
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    polish_spec = PolandSpecProvider()
    assert polish_spec.nip() == '3541237549'



# Generated at 2022-06-21 15:22:30.204765
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    tester = PolandSpecProvider()
    for i in range(1000):
        assert len(tester.pesel()) == 11

# Generated at 2022-06-21 15:22:36.533115
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test that pesel method returns valid PESEL (11-digit)"""
    provider = PolandSpecProvider()
    assert len(provider.pesel()) == 11

# Generated at 2022-06-21 15:22:45.583297
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    poland = PolandSpecProvider()
    regon = poland.regon()
    c = regon[len(regon) - 1:]
    regon_9 = regon[:len(regon) - 1]
    regon_8 = regon_9[:len(regon_9) - 1]
    regon_7 = regon_8[:len(regon_8) - 1]
    regon_6 = regon_7[:len(regon_7) - 1]
    regon_5 = regon_6[:len(regon_6) - 1]
    regon_4 = regon_5[:len(regon_5) - 1]
    regon_3 = regon_4[:len(regon_4) - 1]

# Generated at 2022-06-21 15:22:48.088626
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    pl = PolandSpecProvider()
    print(pl.nip())
    print(pl.pesel())
    print(pl.regon())

# Generated at 2022-06-21 15:22:50.470068
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    try:
        print(PolandSpecProvider().pesel())
    except AssertionError:
        pass


# Generated at 2022-06-21 15:22:56.397656
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Test for method nip of class PolandSpecProvider."""
    psp = PolandSpecProvider(seed=42)
    nip_results = [psp.nip() for _ in range(100)]

    assert nip_results
    assert len(set(nip_results)) == len(nip_results)
    assert '5252551733' in nip_results
    assert '9326184132' in nip_results
    assert '8065876368' in nip_results


# Generated at 2022-06-21 15:22:59.366552
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    pl = PolandSpecProvider()
    output = pl.regon()
    assert isinstance(output, str)
    assert len(output) == 9
    assert output.isdigit()


# Generated at 2022-06-21 15:23:03.875289
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Test for method nip of class PolandSpecProvider."""
    nip_test = PolandSpecProvider()
    print("NIP " + nip_test.nip())
    
#Unit test for method pesel of class PolandSpecProvider

# Generated at 2022-06-21 15:23:07.087809
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_provider = PolandSpecProvider()
    assert poland_provider.pesel() != poland_provider.pesel()
    assert len(poland_provider.pesel()) == 11


# Generated at 2022-06-21 15:23:16.046063
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    random_generator = PolandSpecProvider()
    assert len(random_generator.pesel()) == 11
    assert random_generator.pesel()[4] == '4'
    assert random_generator.pesel(gender=Gender.MALE)[9] in ('0', '2', '4', '6', '8')
    assert random_generator.pesel(gender=Gender.FEMALE)[9] in ('1', '3', '5', '7', '9')
    assert random_generator.pesel(birth_date=Datetime().datetime(1991, 10, 27))[0:2] == '91'

# Generated at 2022-06-21 15:23:20.311971
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Unit test for method regon of class PolandSpecProvider"""
    pesel_pattern = compile('^[0-9]{9}$')
    for _ in range(100):
        assert pesel_pattern.match(PolandSpecProvider().regon())

# Generated at 2022-06-21 15:23:30.627882
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    nip = provider.nip()
    assert len(nip) == 10
    assert nip.isdigit()


# Generated at 2022-06-21 15:23:33.957395
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Method test_PolandSpecProvider_regon test method regon of class PolandSpecProvider."""
    tester = PolandSpecProvider()
    print('test_PolandSpecProvider_regon: ',tester.regon())


# Generated at 2022-06-21 15:23:36.112114
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    res = provider.nip()
    assert len(res) == 10
    assert provider.nip() != provider.nip()


# Generated at 2022-06-21 15:23:38.046496
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    import datetime

    p = PolandSpecProvider()
    d = Datetime().datetime(1990, 2000)

    assert len(p.pesel(d)) == 11

# Generated at 2022-06-21 15:23:46.076118
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # Arrange
    provider = PolandSpecProvider()

    # Act
    pesel = provider.pesel()

    # Assert
    is_valid = False
    if len(str(pesel)) == 11:
        suma = 0
        for i in range(10):
            suma += int(pesel[i]) * (i + 1)
        waga = suma % 11
        if waga > 9:
            waga = 0
        if waga == int(pesel[10]):
            is_valid = True
    assert is_valid

# Generated at 2022-06-21 15:23:48.796140
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_provider = PolandSpecProvider()
    pesel_result = poland_provider.pesel()
    assert len(pesel_result) == 11
    assert pesel_result.isnumeric()

# Generated at 2022-06-21 15:23:54.359914
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    nip_number = PolandSpecProvider().nip()
    nip_number_list = [int(d) for d in nip_number]
    nip_coefficients = (6, 5, 7, 2, 3, 4, 5, 6, 7)
    sum_v = sum([nc * nd for nc, nd in zip(nip_coefficients, nip_number_list)])
    checksum_digit = sum_v % 11
    assert checksum_digit == nip_number_list[-1]


# Generated at 2022-06-21 15:23:56.735055
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider()
    regon = provider.regon()
    assert regon == '174015612'


# Generated at 2022-06-21 15:23:57.294471
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    PolandSpecProvider()

# Generated at 2022-06-21 15:24:05.084777
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    PolandSpecProvider(seed=3).pesel(birth_date=DateTime().datetime(1940, 2018),gender=Gender.MALE)=='19400521628'
    PolandSpecProvider(seed=3).pesel(birth_date=DateTime().datetime(1940, 2018),gender=Gender.FEMALE)=='19401121283'
    PolandSpecProvider(seed=3).pesel(birth_date=DateTime().datetime(1940, 2018),gender=None)=='19402121288'
    PolandSpecProvider(seed=3).pesel(birth_date=None,gender=Gender.MALE)=='21111121629'
    PolandSpecProvider(seed=3).pesel(birth_date=None,gender=Gender.FEMALE)=='00421221282'
    PolandSpec

# Generated at 2022-06-21 15:24:17.602781
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()

    #valid for all dates
    assert len(provider.pesel()) == 11

    #valid for dates from 1940 to 2018
    assert 0 < int(provider.pesel()[:2]) <= 99

    #valid for dates from 1940 to 1999
    assert 0 < int(provider.pesel()[2:4]) <= 12

    #valid for dates from 1940 to 2099
    assert 0 < int(provider.pesel()[4:6]) <= 31

    #valid for dates from 2018 to 2137
    assert 0 < int(provider.pesel()[6:9]) <= 999

    #valid for dates from 1940 to 2099
    assert 0 < int(provider.pesel()[9]) <= 9

# Generated at 2022-06-21 15:24:22.029878
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pl = PolandSpecProvider()
    p = pl.pesel(gender=Gender.FEMALE)
    assert len(p) == 11, "pesel does not contain 11 digits"
    assert p[0] in ['3', '4'], "pesel does not start with 3 or 4"

# Generated at 2022-06-21 15:24:24.366908
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    result = p.pesel()
    assert type(result) is str
    assert len(result) == 11


# Generated at 2022-06-21 15:24:29.806119
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Unit test for method regon of class PolandSpecProvider."""
    print('\nUnit test for method regon of class PolandSpecProvider:')
    p = PolandSpecProvider()
    print('\tREGON: ', p.regon())
    print('\tREGON: ', p.regon())
    print('\tREGON: ', p.regon())
    print('\tREGON: ', p.regon())
    print('\tREGON: ', p.regon())


# Generated at 2022-06-21 15:24:32.171720
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    assert PolandSpecProvider().nip() == '5221013194'


# Generated at 2022-06-21 15:24:34.709318
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    m = PolandSpecProvider()
    test = m.pesel(birth_date=m.datetime(1940, 2018), gender=Gender.MALE)
    assert len(test) == 11

# Generated at 2022-06-21 15:24:36.712272
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    pass


# Generated at 2022-06-21 15:24:38.174543
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    PolandSpecProvider=PolandSpecProvider()
    assert isinstance (PolandSpecProvider.nip(),str)


# Generated at 2022-06-21 15:24:45.917197
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Unit test for constructor of class PolandSpecProvider."""
    pl_provider = PolandSpecProvider()
    print(pl_provider.nip())  # 7520607381
    print(pl_provider.nip(seed=11111))  # 1622595901
    
    print(pl_provider.pesel())  # 12040916314
    print(pl_provider.pesel(gender=Gender.FEMALE))  # 39010718846
    print(pl_provider.pesel(seed=11111))  # 34070678000
    
    print(pl_provider.regon())  # 293499898
    print(pl_provider.regon(seed=11111))  # 838844747

if __name__ == '__main__':
    test_PolandSpecProvider()

# Generated at 2022-06-21 15:24:51.222609
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    obj = PolandSpecProvider()
    pesel = obj.pesel(birth_date=Datetime().datetime(1990, 2010), gender=Gender.MALE)
    assert len(pesel) == 11
    assert int(pesel[-1]) % 2 != 0
    assert int(pesel[0:2]) in range(90, 100)
    pesel = obj.pesel(birth_date=Datetime().datetime(1990, 2010), gender=Gender.FEMALE)
    assert len(pesel) == 11
    assert int(pesel[-1]) % 2 == 0
    assert int(pesel[0:2]) in range(90, 100)
    pesel = obj.pesel(birth_date=Datetime().datetime(1990, 2010))


# Generated at 2022-06-21 15:24:58.262661
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider()
    regon = provider.regon()
    assert len(regon) == 9
    assert regon.isdigit()


# Generated at 2022-06-21 15:25:03.195730
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    from mimesis.providers.poland_provider import PolandSpecProvider
    from random import random

    # Test 1
    poland_spec_provider = PolandSpecProvider(random())
    result = poland_spec_provider.regon()
    assert isinstance(result, str) and len(result) == 9 and result.isdigit()


# Generated at 2022-06-21 15:25:06.792124
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    new_PolandSpecProvider = PolandSpecProvider()
    pesel = new_PolandSpecProvider.pesel(birth_date=None, gender=Gender.FEMALE)
    assert len(pesel) == 11
    assert type(pesel) == str


# Generated at 2022-06-21 15:25:11.517234
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider(seed=12345)

    x = provider.pesel()
    assert x == '92091406600'
    provider = PolandSpecProvider(seed=12345)
    y = provider.pesel(birth_date=Datetime().datetime(1984, 9, 14), gender=Gender.MALE)
    assert x == y

    provider = PolandSpecProvider(seed=1234)
    y = provider.pesel(birth_date=Datetime().datetime(1940, 1, 1), gender=Gender.FEMALE)
    assert y == '40010106783'

# Generated at 2022-06-21 15:25:19.419449
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    result = provider.pesel()
    assert(len(result) == 11)
    assert(result[4:6] in ('01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12',
                           '21', '22', '23', '24', '25', '26', '27', '28', '29', '30', '31', '32'))
    assert(result[-1] in ('0', '1', '2', '3', '4', '5', '6', '7', '8', '9'))

# Generated at 2022-06-21 15:25:21.347868
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    pl = PolandSpecProvider()
    nip = pl.nip()
    assert len(nip) == 10


# Generated at 2022-06-21 15:25:24.434371
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Test if method nip of class PolandSpecProvider works correctly."""
    p = PolandSpecProvider()
    for _ in range(20):
        assert len(p.nip()) == 10 and isinstance(p.nip(), str)


# Generated at 2022-06-21 15:25:27.269565
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel()
    assert len(pesel) == 11
    assert all(c.isdigit() for c in pesel)

# Generated at 2022-06-21 15:25:28.435373
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of class PolandSpecProvider."""

    obj = PolandSpecProvider()
    pesel = obj.pesel()

    assert(len(pesel) == 11)

# Generated at 2022-06-21 15:25:30.183944
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    pl = PolandSpecProvider()
    pesel = pl.pesel()
    assert len(pesel) == 11


# Generated at 2022-06-21 15:26:18.448733
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider()
    REGON = provider.regon()
    print(REGON)

if __name__ == '__main__':
    print(PolandSpecProvider.__doc__)
    test_PolandSpecProvider_regon()

# Generated at 2022-06-21 15:26:21.740536
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    poland = PolandSpecProvider(seed = 1)
    regon = poland.regon()
    assert regon == '893826362'

# Generated at 2022-06-21 15:26:23.303744
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    assert len(provider.pesel()) == 11


# Generated at 2022-06-21 15:26:29.715289
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    p = PolandSpecProvider()
    nip_number = p.nip()
    nip_number_is_correct = False
    if len(nip_number) == 10:
        nip_number_is_correct = True
    for n in nip_number:
        if not n.isdigit():
            nip_number_is_correct = False
    if nip_number_is_correct:
        nip_digits = [int(d) for d in nip_number]
        nip_coefficients = (6, 5, 7, 2, 3, 4, 5, 6, 7)
        sum_v = sum([nc * nd for nc, nd in zip(nip_coefficients, nip_digits)])
        checksum_digit = sum_v % 11

# Generated at 2022-06-21 15:26:33.099909
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Unit test for PolandSpecProvider."""
    provider = PolandSpecProvider(seed=12345)
    for _ in range(20):
        print(provider.nip())

# Generated at 2022-06-21 15:26:35.322076
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider()
    regon = provider.regon()
    assert len(regon) == 9

# Generated at 2022-06-21 15:26:38.339516
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Test method nip of class PolandSpecProvider."""
    ps = PolandSpecProvider(seed=42)
    actual = ps.nip()
    expected = '7580379538'
    assert actual == expected


# Generated at 2022-06-21 15:26:42.370841
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    pl = PolandSpecProvider()
    nip = pl.nip()
    assert (isinstance(nip, str) and int(nip[-1]) % 11 == 0 and
            len(nip) == 10)


# Generated at 2022-06-21 15:26:43.571732
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    print(PolandSpecProvider().nip())


# Generated at 2022-06-21 15:26:45.801758
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    p = PolandSpecProvider()
    assert(len(p.nip()) == 10)
