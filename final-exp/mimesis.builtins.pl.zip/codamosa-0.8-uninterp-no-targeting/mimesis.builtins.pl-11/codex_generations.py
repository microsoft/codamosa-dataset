

# Generated at 2022-06-21 15:22:13.396872
# Unit test for constructor of class PolandSpecProvider

# Generated at 2022-06-21 15:22:20.083758
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    seed = 3456 # here we specify seed value
    gender = Gender.MALE # specify gender (MALE/FEMALE)
    p = PolandSpecProvider(seed)
    pesel_value = p.pesel(gender=gender)
    # pesel_value - value returned by pesel method of PolandSpecProvider
    print(pesel_value)
    # assert statement to compare with expected value
    assert pesel_value == "62040333620"

# Generated at 2022-06-21 15:22:23.434366
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test for method pesel of class PolandSpecProvider."""
    p = PolandSpecProvider()
    result = p.pesel()
    assert len(result) == 11


# Generated at 2022-06-21 15:22:27.297545
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    assert len(provider.pesel()) == 11
    assert len(provider.pesel(gender=Gender.MALE)) == 11
    assert len(provider.pesel(gender=Gender.FEMALE)) == 11

# Generated at 2022-06-21 15:22:29.752975
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Test method nip of class PolandSpecProvider."""
    test_data = {'nip': PolandSpecProvider().nip()}
    print(test_data)


# Generated at 2022-06-21 15:22:34.018249
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Unit test: PolandSpecProvider: regon."""
    locale = PolandSpecProvider()
    regon = locale.regon()
    assert isinstance(regon, str)
    assert len(regon) == 9


# Generated at 2022-06-21 15:22:36.882927
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    poland = PolandSpecProvider( seed = "MyTestSeed")
    print(poland.nip())


# Generated at 2022-06-21 15:22:40.903676
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test for method pesel of class PolandSpecProvider."""
    provider_pl = PolandSpecProvider()
    assert provider_pl.pesel() == "88071301386"
    assert provider_pl.pesel(gender=Gender.MALE) == "44021501148"


# Generated at 2022-06-21 15:22:42.499851
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    assert len(p.pesel()) == Len(11)


# Generated at 2022-06-21 15:22:51.970975
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    test = PolandSpecProvider()
    regon_ball = [test.regon() for x in range(100)]
    for each in regon_ball:
        list_number = [int(each_number) for each_number in each]
        l1 = list_number[:8]
        l2 = list_number[-1:]
        l1_coeffs = (8, 9, 2, 3, 4, 5, 6, 7)
        sum_v = sum([nc * nd for nc, nd in zip(l1_coeffs, l1)])
        checksum_digit = sum_v % 11
        if checksum_digit > 9:
            checksum_digit = 0
        assert l2 == [checksum_digit]


# Generated at 2022-06-21 15:23:25.208176
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    obj = PolandSpecProvider()
    val = obj.pesel()
    assert isinstance(val, str) == True
    assert len(val) == 11
    val = obj.pesel(birth_date='2000/12/25')
    assert isinstance(val, str) == True
    assert len(val) == 11
    val = obj.pesel(birth_date='2000/12/25', gender=Gender.MALE)
    assert isinstance(val, str) == True
    assert len(val) == 11
    assert val[-1] in ('1', '3', '5', '7', '9')
    val = obj.pesel(birth_date='2000/12/25', gender=Gender.FEMALE)
    assert isinstance(val, str) == True
    assert len(val) == 11

# Generated at 2022-06-21 15:23:31.863934
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # GIVEN
    from datetime import datetime
    from mimesis.enums import Gender
    import mimesis.builtins.poland_provider as poland_provider
    poland = poland_provider.PolandSpecProvider()

    # WHEN
    start = datetime(1950,1,1)
    end = datetime(2004,12,31)
    pesel = poland.pesel(gender=Gender.MALE)
    birth_date = datetime.fromisoformat(pesel[:8])

    # THEN
    assert(start < birth_date)
    assert(birth_date < end)

# Generated at 2022-06-21 15:23:33.137574
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    assert PolandSpecProvider().nip() == '366-999-04'


# Generated at 2022-06-21 15:23:39.233612
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    p = PolandSpecProvider()
    for i in range(0, 10):
        regon = p.regon()
        assert len(regon) == 9
        regon_int = int(regon)

        regon_coeffs = (8, 9, 2, 3, 4, 5, 6, 7)
        regon_int_arr = [int(d) for d in str(regon_int)]
        sum_v = sum([nc * nd for nc, nd in zip(regon_coeffs, regon_int_arr)])
        assert sum_v % 11 == regon_int_arr[8]


# Generated at 2022-06-21 15:23:40.429913
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    p = PolandSpecProvider()
    assert p is not None


# Generated at 2022-06-21 15:23:51.076350
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Test case for method regon of class PolandSpecProvider."""
    test_data = [
        ('066230075', ('7', '3', '5', '7', '5', '2', '8', '2', '6')),
        ('278846803', ('0', '9', '7', '8', '8', '7', '5', '3', '6')),
        ('431298273', ('5', '7', '5', '2', '6', '1', '7', '2', '8')),
    ]
    psp = PolandSpecProvider(seed=1)
    for regon, digits in test_data:
        assert regon == psp.regon()
        for digit in digits:
            assert digit in regon



# Generated at 2022-06-21 15:23:57.644659
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # Test default birth date, gender
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    assert len(pesel) == 11
    assert str.isdigit(pesel) == True
    # Test birth date = 1940-01-01
    birth_date = '1940-01-01'
    pesel = provider.pesel(birth_date=birth_date)
    assert len(pesel) == 11
    assert str.isdigit(pesel) == True
    # Test gender = Male
    gender = Gender.MALE
    pesel = provider.pesel(gender=gender)
    assert len(pesel) == 11
    assert str.isdigit(pesel) == True
    # Test birth date = 1940-01-01, gender = Male

# Generated at 2022-06-21 15:23:59.214683
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    pl = PolandSpecProvider()
    assert isinstance(pl, PolandSpecProvider)


# Generated at 2022-06-21 15:24:05.465699
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Test method regon of class PolandSpecProvider"""
    test_obj1 = PolandSpecProvider()
    test_obj1_regon = test_obj1.regon()
    test_obj2 = PolandSpecProvider()
    test_obj2_regon = test_obj2.regon()
    if test_obj2_regon != test_obj1_regon:
        print("Unit test for method regon of class PolandSpecProvider PASSED")
        print("Method for generating random REGON number is working correctly")
    else:
        print("Unit test for method regon of class PolandSpecProvider FAILED")
# End of unit test for method regon of class PolandSpecProvider



# Generated at 2022-06-21 15:24:10.674035
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    print("Constructor of class PolandSpecProvider")
    poland_obj = PolandSpecProvider()
    print(poland_obj.nip())
    print(poland_obj.pesel())
    print(poland_obj.regon())

if __name__ == "__main__":
    test_PolandSpecProvider()

# Generated at 2022-06-21 15:25:00.918004
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    assert len(provider.nip()) == 10


# Generated at 2022-06-21 15:25:05.780415
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """
    Test method nip of class PolandSpecProvider
    """
    random_provider = PolandSpecProvider(seed=123456)
    assert random_provider.nip() == "9089345933"
    assert random_provider.nip() == "2329395755"
    assert random_provider.nip() == "2421684682"


# Generated at 2022-06-21 15:25:08.537299
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    # Test for method regon of class PolandSpecProvider
    spec = PolandSpecProvider(seed='99')
    for _ in range(1000):
        regon_str = spec.regon()
        assert len(regon_str) == 9
        assert regon_str == '613408916'

# Generated at 2022-06-21 15:25:19.502780
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_provider = PolandSpecProvider()
    # Create date from string in format "01_01_2000"
    birth_date_01_01_2000 = poland_provider.datetime(2000, 2000)
    # Get gender out of Pesel
    gender_01_01_2000 = poland_provider.pesel(birth_date=birth_date_01_01_2000)[9:10]
    # Check if gender is correct
    assert gender_01_01_2000 in [0, 2, 4, 6, 8]
    # Create date from string in format "12_12_2000"
    birth_date_12_12_2000 = poland_provider.datetime(2000, 2000, 12, 12)
    # Get gender out of Pesel
    gender_12_12_2000 = poland_provider.pes

# Generated at 2022-06-21 15:25:23.394928
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    p1 = PolandSpecProvider()
    x = p1.nip()
    y = p1.pesel()
    z = p1.regon()
    print(x)
    print(y)
    print(z)

test_PolandSpecProvider()

# Generated at 2022-06-21 15:25:24.315085
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()


# Generated at 2022-06-21 15:25:30.626963
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    import numpy as np
    instance = PolandSpecProvider()
    regon = instance.regon()
    regon_digits = np.asarray([int(d) for d in regon])
    regon_coeffs = np.asarray([8, 9, 2, 3, 4, 5, 6, 7])
    sum_v = np.sum(regon_coeffs*regon_digits)
    checksum_digit = sum_v % 11
    assert checksum_digit == regon_digits[8]

# Generated at 2022-06-21 15:25:32.328839
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    assert provider.pesel(gender=Gender.MALE).startswith('75') == True


# Generated at 2022-06-21 15:25:34.173981
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel(self, birth_date: DateTime = None,
              gender: Gender = None) -> str:."""
    assert len(PolandSpecProvider().pesel()) == 11

# Generated at 2022-06-21 15:25:39.829718
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    # Scenarios for method regon
    scenarios = [('871887268', True), ('8718872689', False), ('87188726', False)]
    for scenario in scenarios:
        expected_result, isValid = scenario
        if isValid:
            assert PolandSpecProvider().regon() == expected_result
        else:
            assert PolandSpecProvider().regon() != expected_result


# Generated at 2022-06-21 15:28:33.376711
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    pl = PolandSpecProvider()
    assert len(pl.nip()) == 10


# Generated at 2022-06-21 15:28:34.429092
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider()
    assert len(provider.regon()) == 9


# Generated at 2022-06-21 15:28:35.888517
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider(seed=123)
    assert provider.pesel(gender=Gender.FEMALE) == '02030404457'


# Generated at 2022-06-21 15:28:46.517731
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Unit test for method nip of class PolandSpecProvider"""
    import pytest
    from mimesis.providers.poland import PolandSpecProvider

    # Create PolandSpecProvider object with default seed
    poland = PolandSpecProvider()

    # Create PolandSpecProvider object with fixed seed
    poland_fixed = PolandSpecProvider('fixed')
    poland_fixed1 = PolandSpecProvider('fixed')

    # Create PolandSpecProvider object with other seed
    poland_other = PolandSpecProvider('other')
    poland_other1 = PolandSpecProvider('other')

    # Test random NIP
    # Test result equals expected value
    assert poland.nip() == '6300330000'

    # Test generation of NIP with fixed seed
    # Test result equals expected value
    assert poland_fixed.nip() == '0980990000'

# Generated at 2022-06-21 15:28:49.591462
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    for _ in range(100):
        NIP = provider.nip()
        assert type(NIP) is str and all(d.isdigit() for d in NIP) and len(NIP) == 10


# Generated at 2022-06-21 15:28:50.722570
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    p = PolandSpecProvider()

# Generated at 2022-06-21 15:28:55.636578
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider(seed=42)
    assert provider.nip() == "039860015"
    assert provider.pesel(birth_date=Datetime().datetime(1970, 1, 1)) == "70101117227"
    assert provider.regon() == "054153484"

# Generated at 2022-06-21 15:28:56.900477
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    assert provider.pesel() != None

# Generated at 2022-06-21 15:29:03.165156
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    from mimesis.enums import Gender
    from mimesis.providers import Datetime
    from spec.spec_provider_units import unique

    data_provider = PolandSpecProvider()
    nip = data_provider.nip()
    assert nip
    assert len(nip) == 10
    assert int(nip[:3]) >= 101
    assert int(nip[:3]) <= 998
    assert all(int(c) >= 0 and int(c) <= 9 for c in nip)
    assert unique(nip)

    data_provider = PolandSpecProvider(seed=0)
    nip2 = data_provider.nip()
    assert nip2 == '6011912580'
    assert nip == nip2

    assert data_provider.nip() != data_prov

# Generated at 2022-06-21 15:29:12.350411
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    poland_provider = PolandSpecProvider()
    poland_provider.nip() == poland_provider.nip()
    assert poland_provider.nip() != poland_provider.nip()
    poland_provider.pesel() == poland_provider.pesel()
    assert poland_provider.pesel() != poland_provider.pesel()
    poland_provider.regon() == poland_provider.regon()
    assert poland_provider.regon() != poland_provider.regon()