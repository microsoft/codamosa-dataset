

# Generated at 2022-06-21 15:22:04.039585
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    assert len(PolandSpecProvider().regon()) == 9


# Generated at 2022-06-21 15:22:09.591946
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Test generating random valid 9-digit REGON."""
    res=PolandSpecProvider().regon()
    assert len(res) == 9
    sum_v = 0
    regon_coeffs = (8, 9, 2, 3, 4, 5, 6, 7)
    for index in range(len(res)):
        sum_v += regon_coeffs[index] * int(res[index])
    assert sum_v % 11 == int(res[8])


# Generated at 2022-06-21 15:22:14.117782
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel_str=PolandSpecProvider().pesel()
    print('\n Your PESEL number is: ',pesel_str)

if __name__ == '__main__':
    test_PolandSpecProvider_pesel()

# Generated at 2022-06-21 15:22:17.375431
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    a=PolandSpecProvider()
    assert a.nip() is not None
    assert a.pesel() is not None
    assert a.regon() is not None

# Generated at 2022-06-21 15:22:21.667878
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    pl_provider = PolandSpecProvider()
    nip = pl_provider.nip()
    assert len(nip) == 10
    assert nip[0:3] == str(pl_provider.random.randint(101, 998))


# Generated at 2022-06-21 15:22:26.053921
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    test_object = PolandSpecProvider()
    # test if nip method, response is always number and contains 10 digits
    assert (test_object.nip().isdigit() == True) and (len(str(test_object.nip())) == 10)


# Generated at 2022-06-21 15:22:28.093376
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pl = PolandSpecProvider()
    assert len(pl.pesel()) == 11
    

# Generated at 2022-06-21 15:22:30.919952
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    pl = PolandSpecProvider()
    assert len(pl.regon()) == 9
    assert pl.validate_regon(pl.regon())

# Generated at 2022-06-21 15:22:41.992501
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    nip_value = provider.nip()
    assert 10 == len(str(nip_value))

    # verify checksum
    nip_digits = [int(d) for d in str(nip_value)][:-1]
    nip_coefficients = (6, 5, 7, 2, 3, 4, 5, 6, 7)
    sum_v = sum([nc * nd for nc, nd in
                 zip(nip_coefficients, nip_digits)])
    checksum_digit = sum_v % 11
    if checksum_digit > 9:
        checksum_digit = 0
    assert str(nip_value)[-1] == str(checksum_digit)


# Generated at 2022-06-21 15:22:42.559196
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    PolandSpecProvider()

# Generated at 2022-06-21 15:22:52.457845
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    for i in range (0, 3):
        provider.pesel()
    print(provider.pesel())

# Generated at 2022-06-21 15:22:53.510237
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    actual = PolandSpecProvider().nip()
    assert len(actual) == 10



# Generated at 2022-06-21 15:23:00.575424
# Unit test for method nip of class PolandSpecProvider

# Generated at 2022-06-21 15:23:07.707638
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    pesel = provider.pesel()
    # Testing length of the PESEL
    assert len(pesel) == 11
    # Testing that the PESEL returns a string
    assert type(pesel) is str
    # Testing if the PESEL is a number
    assert pesel.isdigit()
    # Testing that the PESEL is between
    assert int(pesel) >= 10000000000 and int(pesel) <= 99999999999


# Generated at 2022-06-21 15:23:13.731785
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    # print(provider.pesel(gender=Gender.FEMALE))
    # print(provider.pesel(gender=Gender.MALE))
    # print(provider.pesel(gender=None))
    # assert provider.pesel()
    assert provider.pesel(gender=Gender.FEMALE) in provider
    assert provider.pesel(gender=Gender.MALE) in provider
    assert provider.pesel(gender=None) in provider

# Generated at 2022-06-21 15:23:17.030297
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider_pl = PolandSpecProvider()
    pesel = provider_pl.pesel()
    print("PESEL: ", pesel)
    assert len(pesel) == 11


# Generated at 2022-06-21 15:23:20.791892
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    pl_provider = PolandSpecProvider(seed=0)
    test_regon = pl_provider.regon()
    assert test_regon == "244908127"


# Generated at 2022-06-21 15:23:30.516363
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    nip1 = nip2 = nip3 = nip4 = nip5 = nip6 = nip7 = nip8 = nip9 = nip10 = ""
    TestPolandSpecProvider = PolandSpecProvider()
    nip1 = TestPolandSpecProvider.nip()
    nip2 = TestPolandSpecProvider.nip()
    nip3 = TestPolandSpecProvider.nip()
    nip4 = TestPolandSpecProvider.nip()
    nip5 = TestPolandSpecProvider.nip()
    nip6 = TestPolandSpecProvider.nip()
    nip7 = TestPolandSpecProvider.nip()
    nip8 = TestPolandSpecProvider.nip()
    nip9 = TestPolandSpecProvider.nip()
    nip10 = TestPolandSpec

# Generated at 2022-06-21 15:23:36.850392
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():

    p = PolandSpecProvider()
    assert str(p.__class__.__name__) == 'PolandSpecProvider'
    assert str(p.__class__.__base__.__name__) == 'BaseSpecProvider'
    assert str(p._meta.name) == 'poland_provider'

    assert p.nip() != None
    assert p.pesel() != None
    assert p.regon() != None

"""
PolandSpecProvider.
Issues:
    $ pydoc issues
Help:
    $ pydoc help
"""

# Generated at 2022-06-21 15:23:39.106631
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    psp = PolandSpecProvider()
    r = psp.regon()
    assert len(r) == 9
    assert type(r) == str


# Generated at 2022-06-21 15:23:47.900289
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    nip = provider.nip()
    assert len(nip) == 10


# Generated at 2022-06-21 15:23:49.200096
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    assert len(PolandSpecProvider().nip()) == 10


# Generated at 2022-06-21 15:23:51.271441
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    p = PolandSpecProvider()
    print(p.nip())
    print(p.pesel())
    print(p.regon())

# Generated at 2022-06-21 15:23:52.978993
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    generator = PolandSpecProvider()
    print(generator.nip())


# Test of method pesel of class PolandSpecProvider

# Generated at 2022-06-21 15:23:55.018430
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider().pesel(birth_date=Datetime.datetime(2001, 10, 15), gender=Gender.MALE)
    assert (pesel == '01101520249')

# Generated at 2022-06-21 15:23:58.243996
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider()
    REGON = provider.regon()
    assert len(REGON) == 9
    REGON_CORRECT = '838058874'
    assert REGON == REGON_CORRECT


# Generated at 2022-06-21 15:24:05.027354
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():

    pesel_provider = PolandSpecProvider()

    nip = pesel_provider.nip()
    nip_list = [int(nip) for nip in str(nip)]

    nip_coefficients = (6, 5, 7, 2, 3, 4, 5, 6, 7)
    sum_v = sum([nc * nd for nc, nd in zip(nip_coefficients, nip_list)])
    checksum_digit = sum_v % 11
    print(nip)
    print(sum_v)
    print(checksum_digit)
    print(nip_list[9])
    assert checksum_digit == nip_list[9]


# Generated at 2022-06-21 15:24:08.541023
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Test for method regon of class PolandSpecProvider"""
    poland = PolandSpecProvider()
    regon = poland.regon()
    assert len(regon) == 9


# Generated at 2022-06-21 15:24:13.200466
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    p = PolandSpecProvider(seed=0)

    # Method should return the result
    result = p.nip()
    assert result == '2213144778'

    # Check the uniqueness of the method
    result2 = p.nip()
    assert result != result2

    # Check return type
    assert isinstance(result, str)


# Generated at 2022-06-21 15:24:15.720926
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Calling method regon of class PolandSpecProvider."""
    poland_provider = PolandSpecProvider()
    result_method = poland_provider.regon()
    assert len(result_method) == 9


# Generated at 2022-06-21 15:24:36.103292
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    obj = PolandSpecProvider()
    result = obj.nip()
    assert isinstance(result, str)
    assert len(result) == 10

    result = obj.pesel()
    assert isinstance(result, str)
    assert len(result) == 11

    result = obj.regon()
    assert isinstance(result, str)
    assert len(result) == 9

# Generated at 2022-06-21 15:24:38.699362
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Test method nip of class PolandSpecProvider."""
    test_PolandSpecProvider = PolandSpecProvider()
    nip = test_PolandSpecProvider.nip()
    assert len(nip) == 10


# Generated at 2022-06-21 15:24:45.993907
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider(seed=42)
    regex = r'^\d{9}$'
    assert provider.validate('regon', regex)
    assert provider.validate('regon', regex, flags=0)
    assert not provider.validate('regon', regex, flags=re.IGNORECASE)
    assert not provider.validate('regon', regex, flags=re.I)
    assert provider.validate('regon', regex, flags=re.VERBOSE)
    assert not provider.validate('regon', regex, flags=re.X)
    assert provider.validate('regon', regex, flags=re.DOTALL)
    assert not provider.validate('regon', regex, flags=re.S)
    assert provider.validate('regon', regex, flags=re.DEBUG)

# Generated at 2022-06-21 15:24:57.417687
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for pesel method of PolandSpecProvider class."""

# Generated at 2022-06-21 15:25:04.633846
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Test case for constructor of class PolandSpecProvider."""
    # Initialize class
    provider = PolandSpecProvider()

    # Test constructor with default arguments
    poland_provider1 = provider.__class__()
    assert hasattr(poland_provider1, 'seed')
    assert hasattr(poland_provider1, 'random')

    # Test constructor of BaseSpecProvider
    poland_provider2 = provider.__class__(seed=42)
    assert poland_provider2.seed == 42


# Generated at 2022-06-21 15:25:05.778739
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    pl = PolandSpecProvider()
    print(pl.regon())


# Generated at 2022-06-21 15:25:08.752130
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Unit test for method 'regon' of class 'PolandSpecProvider'."""
    pl = PolandSpecProvider()
    regon_series = (pl.regon(), pl.regon(), pl.regon())
    assert(regon_series[0] != regon_series[1] != regon_series[2])



# Generated at 2022-06-21 15:25:11.894971
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    assert PolandSpecProvider().nip()
    assert PolandSpecProvider().pesel()
    assert PolandSpecProvider().regon()


# Generated at 2022-06-21 15:25:21.910803
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    poland_data = PolandSpecProvider()
    regon = poland_data.regon()
    assert len(regon) == 9
    control_sum = 0
    control_sum += 8*int(regon[0])
    control_sum += 9*int(regon[1])
    control_sum += 2*int(regon[2])
    control_sum += 3*int(regon[3])
    control_sum += 4*int(regon[4])
    control_sum += 5*int(regon[5])
    control_sum += 6*int(regon[6])
    control_sum += 7*int(regon[7])
    control_sum = control_sum % 11
    if control_sum > 9:
        control_sum = 0
    assert control_sum == int(regon[8])


# Generated at 2022-06-21 15:25:26.060745
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    poland_provider = PolandSpecProvider()
    try:
        regon = poland_provider.regon()
        assert len(regon) == 9
        print('regon: ', regon)
    except:
        print('Test failed!')
        raise
    else:
        print('Test passed.')


# Generated at 2022-06-21 15:25:44.037865
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    x = PolandSpecProvider()
    assert x



# Generated at 2022-06-21 15:25:45.782421
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Unit test for method regon of class PolandSpecProvider"""
    assert PolandSpecProvider().regon() == "648380231"

# Generated at 2022-06-21 15:25:46.940079
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    pl = PolandSpecProvider()
    assert pl.regon() is not None

# Generated at 2022-06-21 15:25:50.278756
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    import random
    provider = PolandSpecProvider(seed=random.seed(0))
    count = 0
    for i in range(100000):
        count += 1 if provider.regon() == '331138351' else 0
    assert count > 0


# Generated at 2022-06-21 15:25:55.953451
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Test NIP method of class PolandSpecProvider."""
    # Create random PolandSpecProvider object
    p = PolandSpecProvider()

    # We will test how many times 10-digit NIP will match 
    # the rules of creating a valid NIP
    test_counter = 100
    valid_nips = 0    # Counter of valid NIPs

    while test_counter > 0:
        test_counter -= 1
        # Get 10-digit NIP
        nip = p.nip()
        # NIP is 10-digit string
        if not isinstance(nip, str):
            raise TypeError('NIP generated by PolandSpecProvider '
                            'should be str, not {}.'
                            .format(type(nip)))

# Generated at 2022-06-21 15:26:05.374025
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():

    """
    I've applied the following test for this function. This test check some example REGON numbers
    for accuracy and if there isn't any mistakes in our function that generates REGON numbers.
    """


# Generated at 2022-06-21 15:26:08.098146
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    pl = PolandSpecProvider()
    print(pl.nip())

if __name__ == "__main__":
    test_PolandSpecProvider()

# Generated at 2022-06-21 15:26:19.140800
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    from mimesis.enums import Gender
    from datetime import date

    pl = PolandSpecProvider(seed=47)

    assert pl.pesel() == '88050870087'
    assert pl.pesel(birth_date=date(1930, 1, 1)) == '30010380299'
    assert pl.pesel(birth_date=date(1930, 1, 1),
                    gender=Gender.MALE) == '30010380299'
    assert pl.pesel(birth_date=date(1930, 1, 1),
                    gender=Gender.FEMALE) == '30010380299'
    assert pl.pesel(birth_date=date(1988, 8, 5),
                    gender=Gender.MALE) == '88050870087'

# Generated at 2022-06-21 15:26:26.266779
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """20 tests for gender of person"""
    pesel_provider = PolandSpecProvider(seed=3)
    for i in range(20):
        pesel = pesel_provider.pesel(gender=Gender.MALE)
        if int(pesel[-1]) == 0 or int(pesel[-1]) == 2 or int(pesel[-1]) == 4 or int(pesel[-1]) == 6 or int(pesel[-1]) == 8:
            print(pesel)
            print(int(pesel[-1]))
    return pesel_provider.pesel()

# Generated at 2022-06-21 15:26:32.127851
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    import re
    provider = PolandSpecProvider()
    a_nip = provider.nip()
    print(a_nip)
    pattern = r"\d{10}"
    assert re.match(pattern, a_nip, flags=0)


# Generated at 2022-06-21 15:27:06.614232
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    obj = PolandSpecProvider()
    pesel = obj.pesel()
    assert (pesel in [str(x) for x in range(10000000000, 10000000000 + 10000000)])



# Generated at 2022-06-21 15:27:09.165365
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Test function nip"""
    provider = PolandSpecProvider()
    assert provider.nip() == '8281543878'


# Generated at 2022-06-21 15:27:11.712933
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    poland = PolandSpecProvider()
    nip = poland.nip()
    assert len(nip) == 10
    assert nip.isdigit()
    # print(nip)


# Generated at 2022-06-21 15:27:18.245151
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Test method is_reg_number."""
    p = PolandSpecProvider()
    regon = p.regon()
    regon_list = [int(d) for d in regon]
    print(regon)
    assert all(regon_list)
    assert len(regon) == 9
    # Unit test for method nip of class PolandSpecProvider



# Generated at 2022-06-21 15:27:19.932420
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    PolandSpecProvider().nip()

# Generated at 2022-06-21 15:27:22.061330
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    p = PolandSpecProvider()
    n = p.regon()
    print("\nRegon: {0}".format(n))
    assert len(n) == 9


# Generated at 2022-06-21 15:27:25.278214
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    p = PolandSpecProvider()
    regon = p.regon()
    assert isinstance(regon, str)
    assert len(regon) == 9
    assert regon.isdigit()


# Generated at 2022-06-21 15:27:26.994086
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider()
    regon = provider.regon()
    assert len(regon) == 9

# Generated at 2022-06-21 15:27:29.277747
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """ Test constructor of class PolandSpecProvider """
    generator = PolandSpecProvider()
    assert generator.__repr__() == "PolandSpecProvider('pl')"
    return True


# Generated at 2022-06-21 15:27:33.579821
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    bd = Datetime().datetime(1990, 2021)
    # bd_string = bd.date().strftime('%Y-%m-%d')
    for i in range(100):
        pesel = PolandSpecProvider().pesel(birth_date=bd, gender=Gender.MALE)
        print(pesel)