

# Generated at 2022-06-21 15:22:05.484181
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    prov = PolandSpecProvider()
    assert len(prov.nip()) == 10


# Generated at 2022-06-21 15:22:09.342804
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    print('Test for method regon of class PolandSpecProvider')
    pl = PolandSpecProvider()
    regon_1 = pl.regon()
    regon_2 = pl.regon()
    assert regon_1 != regon_2
    assert len(regon_1) == 9
    assert len(regon_2) == 9


# Generated at 2022-06-21 15:22:18.395256
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel1 = PolandSpecProvider().pesel(birth_date=Datetime().datetime(1990, 1, 1), gender=Gender.MALE)
    pesel2 = PolandSpecProvider().pesel(birth_date=Datetime().datetime(1990, 1, 1), gender=Gender.FEMALE)
    pesel3 = PolandSpecProvider().pesel(birth_date=Datetime().datetime(1990, 1, 1))
    print(pesel1)
    print(pesel2)
    print(pesel3)


# Generated at 2022-06-21 15:22:29.672097
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Test function nip of class PolandSpecProvider."""
    # Initialize PolandSpecProvider
    ppp = PolandSpecProvider()

    # Create list of 10 random NIPs
    lst = [ppp.nip() for _ in range(10)]

    # Test validity of NIPs
    assert all([len(s) == 10 for s in lst])
    assert all([int(s[0]) in range(1, 9) for s in lst])
    assert all([int(s[1]) in range(0, 9) for s in lst])
    assert all([int(s[2]) in range(0, 9) for s in lst])
    assert all([int(s[3]) == 0 for s in lst])

# Generated at 2022-06-21 15:22:32.442353
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    p = PolandSpecProvider()
    ret = p.regon()
    assert len(ret) == 9
    assert ret.isdecimal()

# Generated at 2022-06-21 15:22:36.365416
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider(seed=12345)
    for i in range(10):
        nip = provider.nip()
        print(nip)


# Generated at 2022-06-21 15:22:39.156962
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pl_provider = PolandSpecProvider(seed=42)
    pesel = pl_provider.pesel()
    assert pesel == '97111207538'

# Generated at 2022-06-21 15:22:41.827979
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    p = PolandSpecProvider()
    assert isinstance(p, PolandSpecProvider)
    assert isinstance(p.__dict__['_random'], p.__dict__['_numerical'])


# Generated at 2022-06-21 15:22:42.762329
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    PolandSpecProvider()


# Generated at 2022-06-21 15:22:44.851734
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    g = PolandSpecProvider()
    f = g.nip()
    assert len(f) == 10
    assert f.isdigit()
