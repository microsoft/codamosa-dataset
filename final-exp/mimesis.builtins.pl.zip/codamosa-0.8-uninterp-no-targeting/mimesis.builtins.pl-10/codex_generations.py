

# Generated at 2022-06-21 15:22:08.576168
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    tests = [["", ""]]
    tests = [
        ["", ""]
    ]
    p = PolandSpecProvider()
    for [input, expected] in tests:
        actual = p.regon()
        assert actual == expected


# Generated at 2022-06-21 15:22:14.473867
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    test_regons = ['111234567', '988756734', '597572984', '504883400', '015893462']
    p = PolandSpecProvider()
    for _ in range(10):
        regon = p.regon()
        assert '{}'.format(regon) in test_regons



# Generated at 2022-06-21 15:22:26.595083
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # Arrange
    from mimesis.enums import Gender
    from datetime import datetime
    my_datetime = datetime(year=1980, month=1, day=1)
    provider = PolandSpecProvider()
    # Act
    pesel_male = provider.pesel(birth_date=my_datetime, gender=Gender.MALE)
    pesel_female = provider.pesel(birth_date=my_datetime, gender=Gender.FEMALE)
    pesel_unknown = provider.pesel(birth_date=my_datetime, gender=Gender.UNKNOWN)
    # Assert
    assert len(pesel_male) == 11
    assert len(pesel_female) == 11
    assert len(pesel_unknown) == 11



# Generated at 2022-06-21 15:22:32.454931
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    poland_provider = PolandSpecProvider()
    nip_digits_0 = int(''.join(str(d) for d in [1, 0, 1, 2, 3, 4, 5, 6, 7, 8]))
    nip_digits_1 = int(''.join(str(d) for d in [9, 9, 7, 2, 3, 4, 5, 6, 7, 9]))
    nip = poland_provider.nip()
    assert int(nip) >= nip_digits_0
    assert int(nip) <= nip_digits_1



# Generated at 2022-06-21 15:22:35.938294
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Unit test for class PolandProvider."""
    provider = PolandSpecProvider()
    assert provider.locale == 'pl'


# Generated at 2022-06-21 15:22:40.269719
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider(seed=12345)
    nip = provider.nip()
    # Assert that generated NIP is valid
    # These two assertions are equivalent
    assert nip == "146470528"
    assert provider.is_valid_nip(nip) == True


# Generated at 2022-06-21 15:22:41.532994
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    assert PolandSpecProvider().regon() == "792028503"


# Generated at 2022-06-21 15:22:43.460426
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    assert PolandSpecProvider().pesel() == "95012812345"

# Generated at 2022-06-21 15:22:45.848769
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    assert provider.nip() == '1342590224'
    assert len(provider.nip()) == 10
    assert provider.nip().isdigit(), provider.nip()

# Generated at 2022-06-21 15:22:48.672307
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    poland = PolandSpecProvider(seed = 1)
    print(poland.regon())
    assert poland.regon()== "068210044"


# Generated at 2022-06-21 15:23:10.710410
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    constructor_test_1 = PolandSpecProvider()
    assert constructor_test_1.locale == 'pl'
    assert constructor_test_1.seed is None


# Generated at 2022-06-21 15:23:13.171533
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    """Unit test for method nip of class PolandSpecProvider"""

    #Initialization
    provider = PolandSpecProvider()

    #Test
    provider.nip()


# Generated at 2022-06-21 15:23:15.043130
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Unit test for constructor of class PolandSpecProvider."""
    print("Testing constructor of class PolandSpecProvider")
    assert PolandSpecProvider()

# Generated at 2022-06-21 15:23:18.155560
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    # Initialize object
    pl=PolandSpecProvider()
    # Call function
    data=pl.nip()
    # Check length with expected length
    assert len(data) == 10, 'Length of the result is not 10' 


# Generated at 2022-06-21 15:23:21.364275
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    NIP = provider.nip()
    assert len(NIP) == 10



# Generated at 2022-06-21 15:23:30.846632
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider"""
    from mimesis.enums import Gender
    from mimesis.providers import Datetime
    pl = PolandSpecProvider()
    date_object = Datetime().datetime(1940, 2018)
    year = date_object.date().year
    month = date_object.date().month
    day = date_object.date().day
    pesel_digits = [int(d) for d in str(year)][-2:]

    if 1800 <= year <= 1899:
        month += 80
    elif 2000 <= year <= 2099:
        month += 20
    elif 2100 <= year <= 2199:
        month += 40
    elif 2200 <= year <= 2299:
        month += 60


# Generated at 2022-06-21 15:23:32.932238
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    provider = PolandSpecProvider()
    # Method pesel should not be invoked with any parameter
    assert len(provider.pesel()) == 11


# Generated at 2022-06-21 15:23:37.557961
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    result = provider.nip()
    assert isinstance(result, str)
    assert len(result) == 10

    result = provider.pesel()
    assert isinstance(result, str)
    assert len(result) == 11

    result = provider.regon()
    assert isinstance(result, str)
    assert len(result) == 9


# Generated at 2022-06-21 15:23:48.479301
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Tests the pesel method of class PolandSpecProvider."""
    from datetime import datetime
    from mimesis import Random

    p = PolandSpecProvider(seed=Random())
    p.seed.add_provider('poland_provider')
    for _ in range(1000):
        pesel = p.pesel(datetime(1998, 3, 13))
        # Check if possibly generated PESEL has correct gender
        if int(pesel[9]) % 2 == 0:
            assert 'Kobieta' == p.gender(pesel)
        else:
            assert 'Mężczyzna' == p.gender(pesel)
        # Check if possibly generated PESEL has correct birth date
        assert datetime(1998, 3, 13) == p.birth_date(pesel)

# Generated at 2022-06-21 15:23:49.657566
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    assert len(PolandSpecProvider().nip()) == 10
