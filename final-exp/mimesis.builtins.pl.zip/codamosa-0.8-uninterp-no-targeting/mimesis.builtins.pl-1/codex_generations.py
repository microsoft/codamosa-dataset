

# Generated at 2022-06-21 15:22:04.170789
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    actual = ''.join(str(p.nip()) for p in PolandSpecProvider(seed=1234))
    expected = '185600904025120910'
    assert actual == expected


# Generated at 2022-06-21 15:22:06.475072
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider()
    regon = provider.regon()

    assert isinstance(regon, str)
    assert len(regon) == 9



# Generated at 2022-06-21 15:22:08.020840
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    pp = PolandSpecProvider()
    assert pp.regon() == '065395080'


# Generated at 2022-06-21 15:22:09.195277
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    assert provider



# Generated at 2022-06-21 15:22:19.893728
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider."""
    seed = 1

    provider = PolandSpecProvider(seed=seed)

    assert provider.pesel() == '74081375860', 'Should be 74081375860'
    assert provider.pesel(birth_date=Datetime(seed=seed).datetime(1940, 2018), gender=Gender.FEMALE) == '47042799633', 'Should be 47042799633'
    assert provider.pesel(birth_date=Datetime(seed=seed).datetime(1940, 2018), gender=Gender.MALE) == '48092712822', 'Should be 48092712822'



# Generated at 2022-06-21 15:22:22.784835
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Test class PolandSpecProvider.
    """
    pl = PolandSpecProvider()
    assert pl.nip() == '7503057662'

# Generated at 2022-06-21 15:22:23.997280
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    assert len(PolandSpecProvider().pesel()) == 11

# Generated at 2022-06-21 15:22:26.939490
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    P = PolandSpecProvider()
    pesel = P.pesel()
    PESEL_len = len(pesel)
    assert PESEL_len == 11


# Generated at 2022-06-21 15:22:28.739030
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Unit test for constructor of class PolandSpecProvider"""
    Provider = PolandSpecProvider()
    assert Provider


# Generated at 2022-06-21 15:22:33.052855
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    assert isinstance(provider, PolandSpecProvider)
    assert isinstance(provider, BaseSpecProvider)
    assert provider.locale == 'pl'


# Generated at 2022-06-21 15:22:54.110799
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    PolandSpecProvider.nip()


# Generated at 2022-06-21 15:22:56.261497
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    pesel = PolandSpecProvider.pesel()
    print(pesel)


# Generated at 2022-06-21 15:23:07.856227
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Unit test for method pesel of class PolandSpecProvider"""
    p = PolandSpecProvider()
    g1 = p.pesel(gender=Gender.MALE)
    assert g1[-1] == '1' or g1[-1] == '3' or g1[-1] == '5' or g1[-1] == '7' or g1[-1] == '9'
    g2 = p.pesel(gender=Gender.FEMALE)
    assert g2[-1] == '0' or g2[-1] == '2' or g2[-1] == '4' or g2[-1] == '6' or g2[-1] == '8'
    assert len(g1) == 11 and len(g2) == 11

# Generated at 2022-06-21 15:23:10.309680
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    from mimesis.providers import PolandSpecProvider
    provider = PolandSpecProvider()
    nip = provider.nip()

    return len(nip) == 10


# Generated at 2022-06-21 15:23:11.998307
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    poland = PolandSpecProvider()
    assert poland.nip() == '4721003317'



# Generated at 2022-06-21 15:23:13.614274
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    a = PolandSpecProvider()
    b = a.pesel()
    assert len(b) == 11


# Generated at 2022-06-21 15:23:17.590242
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test for method pesel of class PolandSpecProvider."""
    from mimesis.builtins.pl import PolandSpecProvider
    from mimesis.enums import Gender
    provider = PolandSpecProvider()
    assert bool(provider.pesel(gender=Gender.MALE))
    assert bool(provider.pesel(gender=Gender.FEMALE))
    assert bool(provider.pesel())


# Generated at 2022-06-21 15:23:26.282770
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    """Test method pesel of the class PolandSpecProvider."""
    assert len(PolandSpecProvider().pesel()) == 11
    assert len(PolandSpecProvider().pesel(birth_date=Datetime().datetime(), gender=Gender.MALE)) == 11
    assert len(PolandSpecProvider().pesel(birth_date=Datetime().datetime(), gender=Gender.FEMALE)) == 11
    assert len(PolandSpecProvider().pesel(gender=Gender.MALE)) == 11
    assert len(PolandSpecProvider().pesel(gender=Gender.FEMALE)) == 11

# Generated at 2022-06-21 15:23:28.560255
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland_provider = PolandSpecProvider()
    pesel = poland_provider.pesel()
    assert pesel is not None


# Generated at 2022-06-21 15:23:31.316012
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider(seed=42)
    provider.random.seed(42)
    assert provider.regon() == '045786355'



# Generated at 2022-06-21 15:24:22.282784
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    p = PolandSpecProvider(seed=123)
    assert p.regon() == '544042490'

# Generated at 2022-06-21 15:24:26.081258
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    # create an instance of class PolandSpecProvider
    plsp = PolandSpecProvider(seed=1)

    # get the value of method nip
    nip = plsp.nip()

    assert nip == '1042787351'

# Generated at 2022-06-21 15:24:27.956273
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
   test = PolandSpecProvider()
   test.seed(1)
   assert test.pesel() == "9802156901"


# Generated at 2022-06-21 15:24:30.546297
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    polish_spec_provider = PolandSpecProvider()
    assert polish_spec_provider.__class__.__name__ == "PolandSpecProvider"
    assert polish_spec_provider.__class__.__bases__[0].__name__ == "BaseSpecProvider"


# Generated at 2022-06-21 15:24:41.187129
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    random_data1 = PolandSpecProvider(seed=1)
    data_with_gender = random_data1.pesel(birth_date=Datetime().datetime(),
                                          gender=Gender.MALE)
    data_without_gender = random_data1.pesel(birth_date=Datetime().datetime())

# Generated at 2022-06-21 15:24:42.696368
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider(seed=123)
    assert provider.nip() == '4370068678'



# Generated at 2022-06-21 15:24:48.649868
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    np = PolandSpecProvider()
    for _ in range(500):
        assert len(np.nip()) == 10
        assert(np.nip()).isdigit()
    assert np.nip() in {1001001008, 7820005717, 8536012421}
    for _ in range(500):
        assert len(np.nip(mask="# #### ####")) == 11
        assert(np.nip(mask="# #### ####")).replace(' ', '').isdigit()
    assert np.nip(mask="# #### ####") in \
           {'5 005 01022', '1 2217 0528', '9 9047 00019'}


# Generated at 2022-06-21 15:24:51.659624
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    assert len(provider.nip()) == 10


# Generated at 2022-06-21 15:24:54.114587
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider()
    assert isinstance(provider.regon(), str)
    assert len(provider.regon()) == 9


# Generated at 2022-06-21 15:24:56.900018
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    pl_regons = []
    for i in range(0,100):
        pl_regons.append(PolandSpecProvider().regon())
        print(pl_regons[i])


# Generated at 2022-06-21 15:25:34.531317
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Test regon method of PolandSpecProvider class."""
    poland = PolandSpecProvider()
    regon = poland.regon()
    regon_int = int(regon)
    assert len(regon) == 9
    assert 1 <= regon_int <= 2147483647


# Generated at 2022-06-21 15:25:35.981218
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    PolandSpecProvider()


# Generated at 2022-06-21 15:25:47.219846
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    men_PESELs = set()
    women_PESELs = set()
    persons_PESELs = set()
    person = PolandSpecProvider()
    for i in range(1000):
        result_men = person.pesel(gender=Gender.MALE)
        result_women = person.pesel(gender=Gender.FEMALE)
        result_persons = person.pesel()
        men_PESELs.add(result_men)
        women_PESELs.add(result_women)
        persons_PESELs.add(result_persons)
        assert (len(result_men) == 11)
        assert (len(result_women) == 11)
        assert (len(result_persons) == 11)

# Generated at 2022-06-21 15:25:48.604051
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    print(provider.nip())


# Generated at 2022-06-21 15:25:50.097483
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    bg = PolandSpecProvider()
    assert len(bg.nip()) == 10


# Generated at 2022-06-21 15:25:52.652388
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider()

    # regon returns a string with 9 chars
    assert len(provider.regon()) == 9

    # regon returns a valid number
    assert provider.regon() in provider.list_valid_numbers('regon')

# Generated at 2022-06-21 15:25:55.059173
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
        nip = PolandSpecProvider().nip()
        assert len(nip) == 10


# Generated at 2022-06-21 15:25:58.071062
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    p1 = PolandSpecProvider()
    nip1 = p1.nip()
    nip2 = p1.nip()
    assert len(nip1) == 10 and len(nip2) == 10
    assert not nip1 == nip2


# Generated at 2022-06-21 15:26:03.712294
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    import re
    pl = PolandSpecProvider(seed=45315)
    assert re.match("^[0-9]{10}$", pl.nip()) is not None
    assert re.match("^[0-9]{11}$", pl.pesel(Gender.MALE)) is not None
    assert re.match("^[0-9]{9}$", pl.regon()) is not None

# Generated at 2022-06-21 15:26:04.895132
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    tor = PolandSpecProvider().regon()
    print(tor)
