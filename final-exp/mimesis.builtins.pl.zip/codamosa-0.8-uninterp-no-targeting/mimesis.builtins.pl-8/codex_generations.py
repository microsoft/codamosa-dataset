

# Generated at 2022-06-21 15:22:05.838547
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    check_PolandSpecProvider = PolandSpecProvider()
    nip_value = check_PolandSpecProvider.nip()
    assert nip_value.isdigit()
    assert len(nip_value) == 10


# Generated at 2022-06-21 15:22:08.498128
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    obj = PolandSpecProvider()
    assert obj.provider == 'poland_provider'
    assert obj.datetime.datetime(1940, 2018).date().month in range(1, 13)

# Generated at 2022-06-21 15:22:10.850286
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Unit test for method regon of class PolandSpecProvider."""
    pl = PolandSpecProvider()
    regon = pl.regon()
    length_regon = len(regon)
    assert length_regon == 9


# Generated at 2022-06-21 15:22:15.176882
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    expected_result = True
    result = PolandSpecProvider().regon()
    assert expected_result == bool((re.search(r'^[0-9]{9}$', result)))
    print('Test 1. Passed!')


# Generated at 2022-06-21 15:22:17.727859
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    nip = provider.nip()
    assert nip == '3011048532'


# Generated at 2022-06-21 15:22:21.511216
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    # Get random nip
    nip = PolandSpecProvider().nip()

    # Check type of result
    assert isinstance(nip, str)

    # Check length of result
    assert len(nip) == 10


# Generated at 2022-06-21 15:22:31.542987
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    """Test class PolandSpecProvider"""
    pl_provider = PolandSpecProvider()
    
    # Unit test for function nip
    def test_nip():
        """Test function nip"""
        assert len(pl_provider.nip()) == 10
        assert type(pl_provider.nip()) == str
        
    # Unit test for function pesel
    def test_pesel():
        """Test function pesel"""
        assert len(pl_provider.pesel()) == 11
        assert type(pl_provider.pesel()) == str
        
    # Unit test for function regon
    def test_regon():
        """Test function regon"""
        assert len(pl_provider.regon()) == 9
        assert type(pl_provider.regon()) == str
        
    test_nip()
    test

# Generated at 2022-06-21 15:22:34.681167
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    nip = provider.nip()
    assert len(nip) == 10


# Generated at 2022-06-21 15:22:37.556811
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland = PolandSpecProvider()
    pesel = poland.pesel(birth_date=poland.datetime())
    assert pesel

# Generated at 2022-06-21 15:22:40.014821
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    generator = PolandSpecProvider(seed=0)
    expected = '189471573'
    generated = generator.regon()
    assert (generated == expected)


# Generated at 2022-06-21 15:22:53.764478
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider_pl = PolandSpecProvider()
    assert len(provider_pl.nip()) == 10


# Generated at 2022-06-21 15:22:56.034459
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    gen = PolandSpecProvider()
    regon = gen.regon()
    assert len(regon) == 9
    assert regon.isdigit() == True

# Generated at 2022-06-21 15:23:05.024899
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    assert PolandSpecProvider().nip() == '123-456-32-18'
    assert PolandSpecProvider().regon() == '123456785'
    assert PolandSpecProvider().pesel() == '91062508957'
    assert PolandSpecProvider().pesel(gender=Gender.MALE) == '91062508957'
    assert PolandSpecProvider().pesel(gender=Gender.FEMALE) == '91062508957'
    assert PolandSpecProvider().pesel(
        birth_date=Datetime().datetime(1994, 12, 23, 12, 22, 0, 70000)) == '9412238957'

# Generated at 2022-06-21 15:23:12.220703
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    from mimesis.builtins import PolandSpecProvider
    from mimesis.enums import Gender
    from datetime import datetime

    pl = PolandSpecProvider()
    p = pl.pesel()
    assert type(p) is str
    assert len(p) == 11
    p2 = pl.pesel(birth_date=datetime(2004, 6, 10), gender=Gender.MALE)
    assert p2[:6] == '040610'
    assert p2[10] in ('1', '3', '5', '7', '9')

# Generated at 2022-06-21 15:23:14.770812
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    p = PolandSpecProvider()
    print(p.pesel(birth_date = Datetime().datetime(1995,2,2,2,3)))
#test_PolandSpecProvider_pesel()

# Generated at 2022-06-21 15:23:18.514801
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    p = PolandSpecProvider()
    print(p.nip())
    print(p.nip())
    print(p.pesel())
    print(p.pesel())
    print(p.regon())
    print(p.regon())


# Generated at 2022-06-21 15:23:26.044983
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Unit test for method regon of class PolandSpecProvider.
    """
    random.seed(0)

    test_class = PolandSpecProvider()   
    test_object1 = test_class.regon()
    test_object2 = test_class.regon()
    test_object3 = test_class.regon()

    assert test_object1 == '837609411'
    assert test_object2 == '556080898'
    assert test_object3 == '054986566'


# Generated at 2022-06-21 15:23:28.737779
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    poland = PolandSpecProvider()
    print(poland.nip())
    print(poland.pesel())
    print(poland.regon())


# Generated at 2022-06-21 15:23:37.325266
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    # regon = PolandSpecProvider().regon()
    regon = '644848703'

    regon_coeffs = (8, 9, 2, 3, 4, 5, 6, 7)
    regon_digits = [int(digit) for digit in regon]

    sum = 0
    for i in range(0, len(regon_digits) - 1):
        sum = sum + regon_coeffs[i] * regon_digits[i]

    checksum_digit = sum % 11
    if checksum_digit > 9:
        checksum_digit = 0

    if checksum_digit != regon_digits[8]:
        print("Invalid Regon: " + regon)



# Generated at 2022-06-21 15:23:38.691978
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    obj = PolandSpecProvider()
    assert(len(obj.nip()) == 10)

# Generated at 2022-06-21 15:24:23.235132
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    try:
        r = PolandSpecProvider()
        assert r is not None
    except Exception:
        assert False

test_PolandSpecProvider()

# Generated at 2022-06-21 15:24:26.287009
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider()
    assert len(provider.nip()) == 10
    assert provider.nip() != provider.nip()


# Generated at 2022-06-21 15:24:28.709122
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # given
    provider = PolandSpecProvider()
    # when
    result = provider.pesel()
    # then
    assert isinstance(result, str)
    assert len(result) == 11

# Generated at 2022-06-21 15:24:31.909038
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    provider = PolandSpecProvider(seed=42)
    result = provider.nip()
    assert result == '4742236391'


# Generated at 2022-06-21 15:24:34.420691
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    poland_provider = PolandSpecProvider()
    assert poland_provider is not None
    assert poland_provider.locale == 'pl'


# Generated at 2022-06-21 15:24:38.345331
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Test the method regon of PolandSpecProvider class."""
    pl = PolandSpecProvider()
    regon = pl.regon()
    assert len(regon) == 9
    assert str.isdigit(regon)


# Generated at 2022-06-21 15:24:41.041183
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    poland = PolandSpecProvider(seed=0)
    pesel = poland.pesel(birth_date='2000-10-05', gender=Gender.FEMALE)
    assert pesel == '00100505526'

# Generated at 2022-06-21 15:24:43.963118
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    from mimesis.typing import Seed
    poland_provider = PolandSpecProvider(Seed.random())
    
    for i in range(50):
        assert isinstance(poland_provider.nip(), str)
        assert len(poland_provider.nip()) == 10


# Generated at 2022-06-21 15:24:47.652061
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    # Case: random seed is not provided
    ps = PolandSpecProvider()

    # Case: random seed is provided
    seed = b'test seed'
    ps = PolandSpecProvider(seed=seed)
    assert ps.seed == seed

    # Case: other seed type
    seed = 'test seed'
    ps = PolandSpecProvider(seed=seed)
    assert ps.seed == seed.encode()


# Generated at 2022-06-21 15:24:50.812725
# Unit test for method nip of class PolandSpecProvider
def test_PolandSpecProvider_nip():
    p = PolandSpecProvider()
    print(p.nip())


# Generated at 2022-06-21 15:25:45.942169
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    from mimesis.providers.poland_provider import PolandSpecProvider
    provider = PolandSpecProvider()
    result = provider.pesel(gender = Gender.FEMALE)
    print(result)


# Generated at 2022-06-21 15:25:47.063511
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    x = PolandSpecProvider()
    print(x.nip())

# Generated at 2022-06-21 15:25:48.039503
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    provider = PolandSpecProvider()
    assert provider.__class__.__name__ == 'PolandSpecProvider'

# Generated at 2022-06-21 15:25:54.751432
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Test regon method of class PolandSpecProvider.
    Expected result: 9-digit str with first 2 digits divisible by 8 and
    rest of them divisible by 9."""
    poland_provider = PolandSpecProvider(seed=0)
    regon = poland_provider.regon()
    print(regon)  # 804106032
    print(type(regon))  # <class 'str'>
    # test
    regon_digits = [int(d) for d in regon]
    regon_first_two_digits = 8 * regon_digits[0] + regon_digits[1]
    if regon_first_two_digits % 8 != 0: print("Error 1")
    regon_middle_digits = list(range(2, 8))
    regon_first

# Generated at 2022-06-21 15:25:57.694863
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider()
    regon = provider.regon()
    assert len(regon) == 9
    # we can check that checksum is correct with this function
    # https://www.webtoolkitonline.com/mod97-10.html


# Generated at 2022-06-21 15:26:02.436355
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # for i in range(100):
    #     print(PolandSpecProvider().pesel(gender=Gender.MALE))
    print(PolandSpecProvider().pesel(gender=Gender.MALE))
    
if __name__ == "__main__":
    test_PolandSpecProvider_pesel()

# Generated at 2022-06-21 15:26:08.097261
# Unit test for method pesel of class PolandSpecProvider
def test_PolandSpecProvider_pesel():
    # pesel without parameters
    pesel = PolandSpecProvider(seed=0).pesel()
    assert pesel == "97092001030"

    # pesel with birth date and gender
    gender = Gender.MALE
    birth_date = Datetime().datetime(1899, 2000)
    pesel = PolandSpecProvider(seed=0).pesel(birth_date=birth_date, gender=gender)
    assert pesel == "99092001030"


# Generated at 2022-06-21 15:26:10.827438
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    """Test the method regon of class PolandSpecProvider.

    Usage example:
    >>>

    """
    data = []
    test_obj = PolandSpecProvider()
    for _ in range(100):
        data.append(test_obj.regon())
    assert len(data) == 100
    assert len(set(data)) == 100


# Generated at 2022-06-21 15:26:13.922095
# Unit test for method regon of class PolandSpecProvider
def test_PolandSpecProvider_regon():
    provider = PolandSpecProvider()
    assert provider.regon() == "355275777"
    assert provider.regon() == "145621891"
    assert provider.regon() == "931310013"


# Generated at 2022-06-21 15:26:18.190475
# Unit test for constructor of class PolandSpecProvider
def test_PolandSpecProvider():
    x = PolandSpecProvider()

    assert x.nip() == "0661208147"
    assert x.regon() == "858309440"
    assert x.pesel() == "86072906691"