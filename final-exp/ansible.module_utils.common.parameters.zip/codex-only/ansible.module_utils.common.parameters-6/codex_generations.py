

# Generated at 2022-06-22 21:51:25.836115
# Unit test for function env_fallback
def test_env_fallback():
    """Test env_fallback()"""

    no_fallback = 'ANSIBLE_TEST_ENV_FALLBACK_NOT_SET'
    with set_environment_variable(no_fallback, 'ANSIBLE_TEST_ENV_FALLBACK_NOT_SET'):
        assert env_fallback(no_fallback) is AnsibleFallbackNotFound
    with set_environment_variable(no_fallback, None):
        assert env_fallback(no_fallback) is AnsibleFallbackNotFound
    with set_environment_variable(no_fallback, []):
        assert env_fallback(no_fallback) is AnsibleFallbackNotFound
    with set_environment_variable(no_fallback, {}):
        assert env_fallback(no_fallback) is AnsibleFallbackNotFound

    value1

# Generated at 2022-06-22 21:51:30.955515
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_NET_PW'] = 'changed_pass'
    value = 'changed_pass'
    assert env_fallback('ANSIBLE_NET_PW') == value

    # default value
    value = 'foo'
    assert env_fallback('ANSIBLE_NET_PW', value) == value

# Generated at 2022-06-22 21:51:40.201599
# Unit test for function set_fallbacks
def test_set_fallbacks():
    with patch.dict(os.environ, {'foo': 'bar'}):
        spec = dict(
            a=dict(type='str', fallback=(env_fallback, 'foo')),
            b=dict(type='str', fallback=(env_fallback, 'bar')),
            c=dict(type='str', fallback=(env_fallback, 'foo', dict(spam='eggs'))),
        )
        params = dict()
        parameters = dict(a='with value', c=None)
        no_log = set_fallbacks(spec, params)
        assert params == dict(a='with value')
        assert not no_log
        no_log = set_fallbacks(spec, parameters)
        assert parameters == dict(a='with value', c='bar')
        assert not no_log



# Generated at 2022-06-22 21:51:48.653219
# Unit test for function remove_values
def test_remove_values():
    '''
    该函数处理传入参数中可能存在的敏感信息
    :return:
    '''
    values = [
        "ansible_ssh_pass=pass1",
        {
            "ssh_pass": "pass2",
            "ssh_key": "key1"
        },
        {
            "ssh_pass": "pass3",
            "ssh_key": ["key2", "key3"]
        },
    ]

    no_log_strings = ['pass1', 'pass2']

    result = remove_values(values, no_log_strings)
    print(result)



# Generated at 2022-06-22 21:51:59.358554
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict()
    argument_spec['test1'] = dict(required=True)
    argument_spec['test2'] = dict(required=True, no_log=True)
    argument_spec['test3'] = dict(required=True, fallback=(env_fallback, ('TEST_ENV',)))
    argument_spec['test4'] = dict(required=True, fallback=(env_fallback, ('TEST_ENV',)), no_log=True)
    argument_spec['test5'] = dict(required=True, fallback=(env_fallback, ('TEST_ENV', 'FOO')), no_log=True)

# Generated at 2022-06-22 21:52:09.378386
# Unit test for function sanitize_keys
def test_sanitize_keys():

    test_obj = {
        "items": [
            {
                "key1": "value1",
                "key2": "value2",
            },
            {
                "key1": "value1",
                "key2": "value2",
            },
        ],
        "key4": {
            "key5": {
                "key6": "value6",
                "key3": "value3",
                "key6": "value6",
            },
        },
    }

# Generated at 2022-06-22 21:52:15.811446
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert not set_fallbacks({'foo': {'fallback': (env_fallback, 'foo')}}, {})
    assert set_fallbacks({'foo': {'fallback': (env_fallback, 'bar')}}, {}) == set()
    assert set_fallbacks({'foo': {'fallback': (env_fallback, 'foo')}}, {}) == {'foo': 'bar'}
    os.environ['foo'] = 'bar'



# Generated at 2022-06-22 21:52:20.231765
# Unit test for function set_fallbacks
def test_set_fallbacks():
    basic_parameters = {}
    basic_argument_spec = {'basic_parameter': {'type': 'str', 'fallback': (str,)}}
    set_fallbacks(basic_argument_spec, basic_parameters)
    assert 'basic_parameter' in basic_parameters
    assert basic_parameters['basic_parameter'] == ''

    basic_parameters = {'basic_parameter': 'set'}
    basic_argument_spec = {'basic_parameter': {'type': 'str', 'fallback': (str,)}}
    set_fallbacks(basic_argument_spec, basic_parameters)
    assert 'basic_parameter' in basic_parameters
    assert basic_parameters['basic_parameter'] == 'set'



# Generated at 2022-06-22 21:52:25.577561
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback() == ...
    assert env_fallback(None) == ...
    assert env_fallback('Foo') == ...
    assert env_fallback('BAR') == ...
    os.environ['FOO'] = 'foo'
    try:
        assert env_fallback('FOO') == 'foo'
    finally:
        del os.environ['FOO']


# Generated at 2022-06-22 21:52:37.378460
# Unit test for function remove_values
def test_remove_values():
    no_log_sensitive = ['password', 'passphrase', 'private_key', 'secret', 'access_token']
    no_log_strings = set(no_log_sensitive)
    data = {'a': 'password', 'b': {'c': 'passphrase'}, 'd': ['password', 'passphrase'], 'e': [{'f': 'secret'}]}

# Generated at 2022-06-22 21:52:45.447242
# Unit test for function remove_values

# Generated at 2022-06-22 21:52:50.862040
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        str_test=dict(type='str', fallback=(env_fallback, 'TEST_PARAM_STR')),
        default_test=dict(type='str', default='default', fallback=(env_fallback, 'TEST_PARAM_STR')),
        list_test=dict(type='list', fallback=(env_fallback, 'TEST_PARAM_STR')),
        required_test=dict(type='str', required=True),
        colliding_defaults_test=dict(type='str', fallback=(env_fallback, 'TEST_PARAM_STR'), default='unexpected'),
        overridden_test=dict(type='str', fallback=(env_fallback, 'TEST_PARAM_STR'), default='unexpected'),
    )

# Generated at 2022-06-22 21:52:56.689507
# Unit test for function env_fallback
def test_env_fallback():
    # Makes sure env_fallback raises AnsibleFallbackNotFound if no environment variable is present
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('ENV_VAR_NOT_FOUND')
    # Makes sure env_fallback returns the value of the environment variable if present
    assert env_fallback('HOME') == os.environ['HOME']


# Generated at 2022-06-22 21:53:06.761723
# Unit test for function sanitize_keys
def test_sanitize_keys():
    # Strings are not sanitized
    result = sanitize_keys('string', 'test_string')
    assert result == 'string'

    # Non-string keys in dictionaries are sanitized if they contain the string to sanitize
    result = sanitize_keys({1: 'one'}, 'one')
    assert result == {'1': 'one'}

    # Keys which start with _ansible are not sanitized
    result = sanitize_keys({'_ansible_one': 'one'}, 'one')
    assert result == {'_ansible_one': 'one'}

    # Keys which are in the ignore_keys set are not sanitized
    result = sanitize_keys({1: 'one', 2: 'two'}, 'one', {2})

# Generated at 2022-06-22 21:53:18.670749
# Unit test for function remove_values
def test_remove_values():
    # Remove a string
    test_data = {'my_secret': 'this is no longer secret'}
    result_data = remove_values(test_data, ['secret'])
    assert result_data == {'my_': 'this is no longer '}

    # Remove a string in a nested data structure
    test_data = {'my_secret': {'a': 'this is no longer secret'}}
    result_data = remove_values(test_data, ['secret'])
    assert result_data == {'my_': {'a': 'this is no longer '}}

    # Remove a string in a nested data structure, where a string is not found
    test_data = {'my_secret': {'a': 'this is no longer secret'}}
    result_data = remove_values(test_data, ['password'])


# Generated at 2022-06-22 21:53:30.065544
# Unit test for function set_fallbacks
def test_set_fallbacks():
    from ansible.module_utils.common._collections_compat import ordereddict
    d = dict(
        dict=dict(
            fallback=[env_fallback, 'FOO']
        ),
        list=dict(
            elements='str',
            fallback=[env_fallback, 'BAR']
        ),
        string=dict(
            fallback=[env_fallback, 'BAZ']
        )
    )
    p = ordereddict()
    p['dict'] = {}
    p['list'] = []
    no_log_values = set_fallbacks(d, p)
    assert p['dict'] == {}
    assert p['list'] == []
    os.environ['FOO'] = 'dict_value'

# Generated at 2022-06-22 21:53:34.488534
# Unit test for function env_fallback
def test_env_fallback():
    """Unit test for env_fallback"""

    os.environ['GOOD_ENV'] = 'GOOD_VALUE'
    assert env_fallback('BAD_ENV', 'GOOD_ENV') == 'GOOD_VALUE'

    os.environ['GOOD_ENV'] = 'BAD_VALUE'
    assert env_fallback('BAD_ENV', 'GOOD_ENV') == 'BAD_VALUE'

    del os.environ['GOOD_ENV']
    raises(AnsibleFallbackNotFound, env_fallback, 'BAD_ENV', 'GOOD_ENV')



# Generated at 2022-06-22 21:53:47.526973
# Unit test for function set_fallbacks
def test_set_fallbacks():

    # Test with a parameter that doesn't have a fallback
    argument_spec = {'param1': {'type': 'str'}}
    parameters = {'param1': 'one'}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert len(no_log_values) == 0

    # Test with a parameter that has a fallback callback
    argument_spec = {'param1': {'type': 'str', 'fallback': (env_fallback, 'ANSIBLE_PARAM1')}}
    parameters = {'param1': 'one'}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert len(no_log_values) == 0

    # Test with a parameter that has a fallback callback but no value

# Generated at 2022-06-22 21:53:57.400726
# Unit test for function sanitize_keys
def test_sanitize_keys():
    obj_data = {'foo': 'bar', 'baz': 'qux', 'key_foo': 'value_bar', 'key_baz': 'value_qux', 'key_foobar': 'value_foobar',
                'key_no_log': 'value_no_log', '_ansible_param': '_ansible_foo_value', '_ansible_no_log': '_ansible_bar_value'}

# Generated at 2022-06-22 21:54:08.384837
# Unit test for function remove_values
def test_remove_values():
    # Test the removal of all scalar values
    assert remove_values(1, [1]) == 1
    assert remove_values(1.0, [1.0]) == 1.0
    assert remove_values("hello", ["hello"]) == "hello"
    assert remove_values("bye", ["hello"]) == "bye"
    # Test the removal of a value from a nested dict and list
    assert remove_values({"foo": [1, 2, 3]}, [2]) == {"foo": [1, 3]}
    assert remove_values({"foo": [{"foo": 1}, {"bar": 2}, {"baz": 3}]}, [1]) == {"foo": [{}, {"bar": 2}, {"baz": 3}]}

# Generated at 2022-06-22 21:54:19.566189
# Unit test for function remove_values
def test_remove_values():
    assert [] == remove_values([], [])
    assert {'a': 1} == remove_values({'a': 1}, [])
    assert 'a' == remove_values('a', [])

    assert [] == remove_values(['a', 'b', 'c'], ['a', 'b', 'c'])
    assert [] == remove_values(['a', 'b', 'c'], ['d', 'b', 'a'])
    assert [] == remove_values(['a', 'b', 'c'], ['a', 'b', 'c', 'd'])

    # We don't consider an empty sequence to be private, so we cannot remove the private string.
    assert ['a'] == remove_values(['a'], [])

    assert ['a'] == remove_values(['a', 'b'], ['b'])


# Generated at 2022-06-22 21:54:28.107405
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'foo': {'type': 'str', 'fallback': (env_fallback, 'TEST_FOO')},
                     'bar': {'type': 'str', 'fallback': (env_fallback, 'TEST_BAR', 'FALLBACK_BAR')},
                     'baz': {'type': 'str', 'fallback': (env_fallback, 'TEST_BAZ'), 'vault_password': True},
                     'qux': {'type': 'str', 'fallback': (env_fallback, 'TEST_QUX', {'password': True})}}
    parameters = {}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['foo'] == 'FOO'
    assert parameters['bar'] == 'FALLBACK_BAR'

# Generated at 2022-06-22 21:54:37.424130
# Unit test for function remove_values
def test_remove_values():
    assert remove_values(123, ['foo']) == 123

    assert remove_values('foo', ['foo']) == 'foo'
    assert remove_values('foo', ['foo', 'bar']) == 'foo'
    assert remove_values('foo', ['bar', 'baz']) == 'foo'
    assert remove_values('bar', ['bar', 'baz']) == '***'
    assert remove_values('bar', [u'bar', 'baz']) == '***'

    assert remove_values([], ['foo']) == []
    assert remove_values([], ['bar', 'baz']) == []
    assert remove_values([123], ['foo']) == [123]
    assert remove_values([123], ['bar', 'baz']) == [123]

# Generated at 2022-06-22 21:54:48.518419
# Unit test for function set_fallbacks

# Generated at 2022-06-22 21:54:59.567715
# Unit test for function remove_values
def test_remove_values():
    """Test removal of private values from output."""
    assert {'key': 'content'} == remove_values({'key': 'content', 'to_be_removed': 'private'}, ['private'])
    assert {'key': 'content'} == remove_values({'key': 'content', 'to_be_removed': 'private', 'to_stay': 'public'}, ['private'])
    assert {'key': 'content'} == remove_values({'key': 'content'}, ['not here'])
    assert 'content' == remove_values('content', ['not here'])
    assert {'key': 'content'} == remove_values({'key': 'content', 'to_be_removed': 'private'})

# Generated at 2022-06-22 21:55:12.645611
# Unit test for function set_fallbacks
def test_set_fallbacks():

    # No fallback
    argument_spec = {'name': {'type': 'str', }}
    args = {}
    no_log_values = set_fallbacks(argument_spec, args)
    assert 'name' not in args
    assert no_log_values == set()

    # Fallback
    argument_spec = {'name': {'type': 'str', 'fallback': (env_fallback, 'TEST_NAME')}}
    args = {}
    no_log_values = set_fallbacks(argument_spec, args)
    assert args['name'] == os.environ['TEST_NAME']
    assert no_log_values == set()

    # Fallback with args and kwargs

# Generated at 2022-06-22 21:55:21.450454
# Unit test for function remove_values
def test_remove_values():
    log_aggregator = ResultLogAggregator()
    log_aggregator.start_test(instance=None)
    my_str = 'p@ssw0rd'
    my_list = list(my_str)
    my_list.append(my_list)
    my_list.append(my_list)
    my_list.append(list(my_list))
    my_list.append(list(my_list))
    my_list.append(list(my_list))
    my_list.append(list(my_list))
    my_list.append(list(my_list))
    my_list.append(list(my_list))

# Generated at 2022-06-22 21:55:32.791854
# Unit test for function sanitize_keys

# Generated at 2022-06-22 21:55:40.057765
# Unit test for function remove_values
def test_remove_values():
    # Test if  remove_values  works proper when value is a dict
    assert remove_values({'a':'abc', 'b':'def'}, ['abc']) == {'b':'def'}
    assert remove_values({'a':'abc', 'b':'def'}, ['abcdef']) == {'a':'abc', 'b':'def'}
    assert remove_values({'a':'abc', 'b':'def'}, ['abc', 'def']) == {}
    assert remove_values({'a':'abc', 'b':'def', 'c':'ghijklmnop'}, ['abc', 'def', 'ghijklmnop']) == {}
    # Test if  remove_values  works proper when value is a dict with dict values

# Generated at 2022-06-22 21:55:46.932244
# Unit test for function sanitize_keys
def test_sanitize_keys():
    fail = False
    no_log_strings = ['foo']
    obj = {'api_key': 'foo', 'password': 'foo', '_ansible_foo': 'foo', 'ansible_foo': 'foo',
           'foo': 'foo', '_ansible_bar': 'foo', '_ansible_baz': 'foo', 'bar': ['foo', 'foo', 'foo'], 'baz': {'foo': 'foo'}}
    new_obj = sanitize_keys(obj, no_log_strings)

# Generated at 2022-06-22 21:55:49.757677
# Unit test for function env_fallback
def test_env_fallback():
    """Test env_fallback function"""

    os.environ['FOO'] = 'baz'
    assert env_fallback('FOO') == 'baz'



# Generated at 2022-06-22 21:55:52.020784
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('FOO') == os.environ['FOO']



# Generated at 2022-06-22 21:55:56.918995
# Unit test for function remove_values
def test_remove_values():
    # Test removing from a string
    result = remove_values('this is a real ansible string', ['real'])
    assert result == 'this is a real ansible string'

    result = remove_values('this is a real ansible string', ['a'])
    assert result == 'this is  real ansible string'

    result = remove_values('this is a real ansible string', ['is'])
    assert result == 'th  a real ansible string'

    result = remove_values('this is a real ansible string', ['this', 'real'])
    assert result == 'th  a  ansible string'

    # Test removing from a map
    result = remove_values({'key1': 'value1', 'key2': 'value2'}, ['value1'])

# Generated at 2022-06-22 21:56:04.425528
# Unit test for function sanitize_keys
def test_sanitize_keys():
    data = {'key': 'value', 'nologkey': 'value', 'nologkey2': 'value'}
    original_data = data.copy()
    no_log_values = ['nologkey', 'nologkey2']
    data = sanitize_keys(data, no_log_values)
    assert original_data['key'] == data['key']
    assert original_data['nologkey'] == data['**']
    assert original_data['nologkey2'] == data['**']



# Generated at 2022-06-22 21:56:08.323996
# Unit test for function env_fallback
def test_env_fallback():
    result = env_fallback('a', 'b')
    os.environ['b'] = 'b'
    try:
        assert result == env_fallback('a', 'b')
    finally:
        del os.environ['b']



# Generated at 2022-06-22 21:56:15.749979
# Unit test for function env_fallback
def test_env_fallback():
    module = AnsibleModuleTest(argument_spec=dict(foo=dict(env_fallback=("FOO", "FOO_DEFAULT"))), supports_check_mode=False)
    assert "FOO_DEFAULT" == module.params["foo"]
    os.environ["FOO"] = "FOO_ENV"
    module = AnsibleModuleTest(argument_spec=dict(foo=dict(env_fallback=("FOO", "FOO_DEFAULT"))), supports_check_mode=False)
    assert "FOO_ENV" == module.params["foo"]



# Generated at 2022-06-22 21:56:19.021207
# Unit test for function env_fallback
def test_env_fallback():
    '''env_fallback unit test'''
    assert env_fallback('abc') == os.environ['abc']



# Generated at 2022-06-22 21:56:30.172464
# Unit test for function sanitize_keys
def test_sanitize_keys():
    obj = {
        'normal_key': 'keys_should_not_be_sanitized',
        'normal_keys'.upper(): 'normal_keys'.upper(),
        'no_log_key': 'no_log_string_value',
        'no_log_keys'.upper(): 'no_log_keys'.upper(),
        'ignored_key': 'ignored_key',
        'ignored_keys'.upper(): 'ignored_keys'.upper(),
        'tmp_key': 'tmp_key',
        'tmp_keys'.upper(): 'tmp_keys'.upper(),
        'tmp_key1': 'tmp_key1',
        'tmp_keys1'.upper(): 'tmp_keys1'.upper(),
    }

# Generated at 2022-06-22 21:56:40.612484
# Unit test for function remove_values

# Generated at 2022-06-22 21:56:52.511637
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys('some string', ['some string']) == '*****'
    assert sanitize_keys({'some string': 'some string'}, ['some string']) == {'*****': '*****'}
    assert sanitize_keys({'some string': 'some string'}, ['some string'], ignore_keys=('some string',)) == {'some string': '*****'}
    assert sanitize_keys(['some string', 'some string'], ['some string']) == ['*****', '*****']
    assert sanitize_keys({'some string': ['some string']}, ['some string']) == {'*****': ['*****']}
    assert sanitize_keys({'some string': ['some string']}, ['some string'], ignore_keys=('some string',)) == {'some string': ['*****']}


# Generated at 2022-06-22 21:57:03.208349
# Unit test for function sanitize_keys
def test_sanitize_keys():
    argspec = {
        'api_key': {'type': 'str', 'no_log': True, 'required': True},
        'client_id': {'type': 'str', 'required': True},
        'host': {'type': 'str', 'required': True},
        'username': {'type': 'str', 'no_log': True, 'required': True},
        'password': {'type': 'str', 'no_log': True, 'required': True},
        'validate_certs': {'default': True, 'type': 'bool'},
    }

# Generated at 2022-06-22 21:57:13.973749
# Unit test for function set_fallbacks
def test_set_fallbacks():
    from ansible.module_utils import basic
    result = None
    no_log_values = set()

    # With No AnsibleFallbackNotFound
    parameters = {}
    argument_spec = dict(
        connection=dict(default='smart', fallback=(env_fallback, 'ANSIBLE_NET_CONNECTION')),
        username=dict(fallback=(env_fallback, 'ANSIBLE_NET_USERNAME'))
    )
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['connection'] == 'smart'
    assert parameters['username'] == os.environ['ANSIBLE_NET_USERNAME']
    assert no_log_values == set()

    # With AnsibleFallbackNotFound
    parameters = {}

# Generated at 2022-06-22 21:57:26.018073
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        agnostic=dict(type='str', fallback=(env_fallback, ['agnostic_env']), required=False),
        required=dict(type='str', fallback=(env_fallback, ['required_env']), required=True),
        notrequired=dict(type='str', fallback=(env_fallback, ['notrequired_env']), required=False),
        nolog=dict(type='str', fallback=(env_fallback, ['nolog_env']), no_log=True, required=False),
        default=dict(type='str', fallback=(env_fallback, ['default_env']), default='default', required=False),
    )

# Generated at 2022-06-22 21:57:33.748042
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict (
        foo=dict(fallback=(env_fallback, "FOO", "BAR")),
        bar=dict(fallback=(env_fallback, "FOO", "BAR"))
    )
    parameters = dict(foo=None, bar=None)
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert no_log_values == set()
    assert parameters == dict(foo=None, bar=None)
    os.environ['FOO'] = '1'
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters == dict(foo='1', bar=None)
    os.environ['BAR'] = '2'
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters

# Generated at 2022-06-22 21:57:44.365122
# Unit test for function set_fallbacks
def test_set_fallbacks():
    """Test that we can get fallbacks"""
    argument_spec = dict(ansible_env_test1=dict(fallback=(env_fallback, 'ANSIBLE_TEST1')),
                         ansible_env_test2=dict(fallback=(env_fallback, "ANSIBLE_TEST2")),
                         ansible_env_test3=dict(fallback=(env_fallback, "ANSIBLE_TEST3")))

    no_log_values = set_fallbacks(argument_spec, dict())

    assert len(no_log_values) == 0

    os.environ['ANSIBLE_TEST1'] = 'true'
    os.environ['ANSIBLE_TEST2'] = 'false'
    os.environ['ANSIBLE_TEST3'] = 'true'

    no_log_values = set_

# Generated at 2022-06-22 21:57:56.145728
# Unit test for function remove_values
def test_remove_values():

    # Create a list of strings to remove from the value
    no_log_strings = ['password', 'passwd', 'host_password']

    # Create a scalar value
    value = 'Hello, my password is password'
    assert remove_values(value, no_log_strings) == 'Hello, my ******** is ********'

    # Create a string object
    value = u'Hello, my password is password'
    assert remove_values(value, no_log_strings) == u'Hello, my ******** is ********'

    # Create a dictionary value where only a scalar value has the strings to remove
    value = {'hello': 'my password is password'}
    assert remove_values(value, no_log_strings) == {'hello': 'my ******** is ********'}

    # Create a dictionary value where only a list item

# Generated at 2022-06-22 21:58:06.195288
# Unit test for function remove_values
def test_remove_values():
    data = dict(something='password:1234', something_else='password:5678', other='president')
    removed = remove_values(data, ['password:1234', 'password:5678'])
    assert removed == dict(something='***', something_else='***', other='president')

    data = dict(a=dict(b=dict(c='password:1234', d='president')))
    removed = remove_values(data, ['password:1234'])
    assert removed == dict(a=dict(b=dict(c='***', d='president')))

    data = ['password:1234', 'password:5678', 'president']
    removed = remove_values(data, ['password:1234', 'password:5678'])
    assert removed == ['***', '***', 'president']


# Generated at 2022-06-22 21:58:12.169109
# Unit test for function set_fallbacks
def test_set_fallbacks():

    assert set_fallbacks(
        {'test': {'type': 'bool', 'fallback': (env_fallback, 'TEST_FALLBACK_ENV_VAR_NAME')}},
        {'test': False}) == set()

    assert set_fallbacks(
        {'test': {'type': 'bool', 'fallback': (env_fallback, 'TEST_FALLBACK_ENV_VAR_NAME')}},
        {}) == {'1'}

    assert set_fallbacks(
        {'test': {'type': 'str', 'fallback': (env_fallback, 'TEST_FALLBACK_ENV_VAR_NAME')}},
        {}) == {'not empty'}


# Generated at 2022-06-22 21:58:23.151131
# Unit test for function sanitize_keys
def test_sanitize_keys():
    expected_1 = {'a': 'b'}
    expected_2 = {'b': 'c', 'd': {'a': 'b'}}
    expected_3 = {'a': ['c'], 'b': {'d': 'e'}}
    expected_4 = {'a': 'b', 'c': 'd', 'e': {'g': 'h'}, 'i': ['k']}

    result_1 = sanitize_keys({'a': 'b', '_ansible_value_as_tmp_file_b': 'c'}, ['c'])
    assert result_1 == expected_1

    result_2 = sanitize_keys({'_ansible_value_as_tmp_file_b': 'c', 'd': {'a': 'b'}}, ['c'])

# Generated at 2022-06-22 21:58:28.603099
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['FOO'] = 'bar'
    assert env_fallback('FOO') == 'bar'

    # make sure that errors are being handled
    raised = False
    try:
        env_fallback('FOOBAR')
    except AnsibleFallbackNotFound:
        raised = True
    assert raised is True



# Generated at 2022-06-22 21:58:40.126848
# Unit test for function remove_values
def test_remove_values():
    """Remove strings in ``no_log_strings`` from value.

    If value is a container type, then remove a lot more.

    Use of ``deferred_removals`` exists, rather than a pure recursive solution,
    because of the potential to hit the maximum recursion depth when dealing with
    large amounts of data (see `issue #24560 <https://github.com/ansible/ansible/issues/24560>`_).
    """

    deferred_removals = deque()

    no_log_strings = [to_native(s, errors='surrogate_or_strict') for s in ['test']]
    new_value = _remove_values_conditions('testtest', no_log_strings, deferred_removals)

    while deferred_removals:
        old_data, new_data = deferred_rem

# Generated at 2022-06-22 21:58:50.754429
# Unit test for function set_fallbacks

# Generated at 2022-06-22 21:59:02.193307
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'foo': {'default': 'bar', 'fallback': (env_fallback, 'TEST_FOO')}}
    try:
        del os.environ['TEST_FOO']
        assert set_fallbacks(argument_spec, {}) == set()
    except KeyError:
        pass
    else:
        raise Exception('TEST_FOO should not be set')
    try:
        os.environ['TEST_FOO'] = 'baz'
        assert set_fallbacks(argument_spec, {}) == {'baz'}
    finally:
        try:
            del os.environ['TEST_FOO']
        except KeyError:
            pass


# Generated at 2022-06-22 21:59:14.274056
# Unit test for function sanitize_keys
def test_sanitize_keys():
    import string
    import random
    import json

    def generate_random_dict(n, l, s=None):
        if s is None:
            s = string.ascii_letters + string.digits + '_-=+'

        d = {}
        for i in range(n):
            d[generate_random_str(l, s)] = generate_random_str(l, s)
        return d

    def generate_random_str(l, s):
        return ''.join([random.choice(s) for i in range(l)])

    def generate_random_list(n, l, s=None):
        if s is None:
            s = string.ascii_letters + string.digits + '_-=+'

        d = []

# Generated at 2022-06-22 21:59:22.043285
# Unit test for function env_fallback
def test_env_fallback():
    x = os.environ.copy()
    os.environ['ANSIBLE_TEST_ENVIRONMENT_FALLBACK'] = 'foo'
    assert env_fallback('ANSIBLE_TEST_ENVIRONMENT_FALLBACK') == 'foo'
    os.environ.clear()
    os.environ.update(x)
    assert env_fallback('ANSIBLE_TEST_ENVIRONMENT_FALLBACK') == 'foo'



# Generated at 2022-06-22 21:59:30.788307
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['FOO'] = 'foo'
    os.environ['BAR'] = 'bar'
    assert env_fallback('FOO', 'BAR') == 'foo'
    assert env_fallback('ANSIBLE_FOO', 'ANSIBLE_BAR') == 'bar'
    assert env_fallback('ANSIBLE_FOO', 'BAR') == 'bar'
    assert env_fallback('FOO', 'ANSIBLE_BAR') == 'foo'

_required_together_options = []

# Generated at 2022-06-22 21:59:40.269724
# Unit test for function remove_values
def test_remove_values():
    """Unit test for function remove_values

    Conformance/positive test
    """
    example_value = {
        'ansible_env': {'UNIT_TEST': 'test passed'},
        'ansible_facts': {
            'distribution': 'Fedora',
            'distribution_release': '26',
            'distribution_version': '26',
            'os_family': 'RedHat',
            'system': 'Linux',
            'system_vendor': 'LENOVO'
        }
    }
    assert remove_values(example_value, []) == example_value



# Generated at 2022-06-22 21:59:48.329148
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(first=dict(fallback=(env_fallback, 'FIRST')),
                         second=dict(fallback=(env_fallback, 'SECOND')),
                         third=dict(fallback=(env_fallback, 'THIRD')))
    os.environ['FIRST'] = 'first'
    os.environ['SECOND'] = 'second'

    parameters = dict()
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert no_log_values == set()
    assert parameters == dict(first='first', second='second')

    argument_spec['first']['no_log'] = True
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert no_log_values == set(['first'])

# Generated at 2022-06-22 21:59:54.838083
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'name': {
            'required': True,
            'type': 'str'
        },
        'age': {
            'fallback': (env_fallback, ['USER_AGE'])
        }
    }
    parameters = {
        'name': 'John'
    }
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['age'] is None
    assert no_log_values == set()



# Generated at 2022-06-22 22:00:03.189603
# Unit test for function sanitize_keys
def test_sanitize_keys():
    '''
    Sanity check to verify functionality of the sanitize_keys function.
    '''
    # Test dict with simple values
    original_dict = {'foo': 'bar', 'baz': 'quux', 'corge': 'grault'}
    expected_dict = {'foo': 'bar', 'baz': 'quux', 'corge': 'grault'}
    assert sanitize_keys(original_dict, set()) == expected_dict

    # Test dict with secret values
    original_dict = {'foo': 'bar', 'baz': 'quux', 'corge': 'grault', 'garply': 'waldo'}
    expected_dict = {'foo': '****', 'baz': 'quux', 'corge': '****', 'garply': '****'}
    assert sanitize

# Generated at 2022-06-22 22:00:13.432225
# Unit test for function set_fallbacks
def test_set_fallbacks():
    fallback_spec = {
        'name': dict(type='str', fallback=(env_fallback, 'USERNAME')),
        'password': dict(type='str', no_log=True, fallback=(env_fallback, 'USER_PASSWORD')),
        'ip': dict(type='str', fallback=(env_fallback, 'MY_IP', dict(fallback_variable='MY_IP_2'))),
    }
    parameters = {}
    no_log_values = set_fallbacks(fallback_spec, parameters)
    assert parameters['name'] == os.environ['USERNAME']
    assert parameters['password'] == os.environ['USER_PASSWORD']
    assert parameters['ip'] == os.environ['MY_IP_2']
    assert 'USER_PASSWORD' in no_log

# Generated at 2022-06-22 22:00:24.840328
# Unit test for function remove_values
def test_remove_values():
    # When remove_values is converted to use deferred_removals internally, then we can remove the
    # call to remove_values in _remove_values_conditions.
    def test_func(value, no_log_strings=[], expected_value=None, test_description=None):
        test_value = remove_values(value, no_log_strings)
        assert test_value == expected_value, test_description

    # Dict
    test_func(
        value={0: 'test'},
        expected_value={0: 'test'},
        test_description='Dict - no str in values'
    )

    test_func(
        value={0: {0: 'test'}},
        expected_value={0: {0: 'test'}},
        test_description='Nested dicts'
    )

# Generated at 2022-06-22 22:00:36.551616
# Unit test for function sanitize_keys
def test_sanitize_keys():
    expected_output = {
        "provider": "local",
        "password": "VAGRANT-SOMETHING",
        "install_options": {
            "group": "vagrant",
            "uid": 500
        }
    }
    input_data = {
        "provider": "local",
        "install_options": {
            "group": "vagrant",
            "uid": 500
        },
        "password": "VAGRANT-SOMETHING"
    }
    no_log_strings = {'VAGRANT-SOMETHING'}
    actual_output = sanitize_keys(input_data, no_log_strings)

    assert actual_output == expected_output

SANITIZED_DATA = '<SANITIZED>'


# Generated at 2022-06-22 22:00:47.248476
# Unit test for function set_fallbacks
def test_set_fallbacks():

    # env_fallback function definition
    def env_fallback(*args, **kwargs):
        """Load value from environment variable"""
        for arg in args:
            if arg in os.environ:
                return os.environ[arg]
        raise AnsibleFallbackNotFound

    argument_spec = {
        'name': {
            'type': 'str',
            'fallback': (env_fallback, ['ANSIBLE_NET_USERNAME'])
        }
    }

    parameters = {}
    no_log_values = set()
    try:
        os.environ['ANSIBLE_NET_USERNAME'] = 'spam'
        no_log_values = set_fallbacks(argument_spec, parameters)
    except KeyError:
        pass

    assert parameters['name'] == 'spam'
    assert len

# Generated at 2022-06-22 22:00:59.348337
# Unit test for function remove_values
def test_remove_values():
    # Test all container types: list, dict and set
    test_in = dict(
        list_in=[dict(changed=True, user=dict(name='joe', password='abcdefg'), password='abcdefg'), dict(changed=True, user=dict(name='joe', password='abcdefg',), password='abcdefg')],
        dict_in=dict(changed=True, user=dict(name='joe', password='abcdefg'), password='abcdefg'),
        set_in=set(dict(changed=True, user=dict(name='joe', password='abcdefg'), password='abcdefg')),
    )

# Generated at 2022-06-22 22:01:08.546748
# Unit test for function sanitize_keys
def test_sanitize_keys():
    # Test dict
    d = {'foo': 'baz', 'password': 'hunter2', 'sub_dict': {'host': 'testhost', 'username': 'admin', 'sub_sub_dict': {'subsub_password': 'foo'}}}
    # Test list
    l = ['password', 'foo', 'bar']
    # Test set
    s = set(['password', 'foo'])
    # Test string
    password_str = 'password'
    # Test bytes object (in python3 these are treated as strings, not binary data)
    b = 'password'.encode('utf-8')
    # Test other object
    class Foo(object):
        pass
    p = Foo()
    p.password = 'hunter2'
    p.username = 'admin'
    # Test empty container object
    empty_list = list

# Generated at 2022-06-22 22:01:15.196431
# Unit test for function set_fallbacks
def test_set_fallbacks():
    module_args = {}
    argument_spec = {'name': {'type': 'str', 'default': 'Tom', 'fallback': (env_fallback, ['ANSIBLE_NET_USERNAME', 'USER'])}}
    no_log_values = set_fallbacks(argument_spec, module_args)
    assert 'Tom' == module_args.get('name')
    assert 'Tom' in no_log_values



# Generated at 2022-06-22 22:01:25.731425
# Unit test for function set_fallbacks