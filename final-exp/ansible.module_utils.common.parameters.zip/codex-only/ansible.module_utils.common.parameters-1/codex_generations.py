

# Generated at 2022-06-22 21:51:25.015075
# Unit test for function remove_values
def test_remove_values():
    """Test remove values function.

    It's not perfect but could help to find some errors.
    """

# Generated at 2022-06-22 21:51:32.238092
# Unit test for function set_fallbacks
def test_set_fallbacks():
    """Test fallback loading from environment variable"""
    # Test basic fallback
    argument_spec = {'a': {'type': 'int', 'fallback': (env_fallback, ['ansible_testenv_a'])}}
    params = {}
    os.environ['ansible_testenv_a'] = '1'
    assert set_fallbacks(argument_spec, params) == set()
    assert params == {'a': 1}

    # Test no logging fallback
    argument_spec = {'a': {'type': 'str', 'fallback': (env_fallback, ['ansible_testenv_a'])},
                     'b': {'type': 'str', 'fallback': (env_fallback, ['ansible_testenv_b']), 'no_log': True}}

# Generated at 2022-06-22 21:51:38.224471
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['foo'] = 'bar'
    assert env_fallback('foo') == 'bar'
    os.environ['TEST_FOO'] = 'bar'
    assert env_fallback('TEST_FOO') == 'bar'
    del os.environ['foo']
    try:
        env_fallback('foo')
        raise AssertionError('should have raised')
    except AnsibleFallbackNotFound:
        pass
    del os.environ['TEST_FOO']


# Generated at 2022-06-22 21:51:47.481522
# Unit test for function set_fallbacks

# Generated at 2022-06-22 21:51:59.273939
# Unit test for function set_fallbacks
def test_set_fallbacks():
    for i in range(100):
        argument_spec = {'a': {'type': 'int', 'fallback': (random.randint, i)},
                         'b': {'type': 'str', 'fallback': (env_fallback, 'TEST_ENV_VAR')}}
        parameters = {}
        os.environ['TEST_ENV_VAR'] = '{}'
        no_log_values = set_fallbacks(argument_spec, parameters)
        if i != parameters['a']:
            raise AssertionError("set_fallbacks: expected '%d', got '%d'" % (i, parameters['a']))

# Generated at 2022-06-22 21:52:07.270319
# Unit test for function set_fallbacks

# Generated at 2022-06-22 21:52:18.213649
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Test loading env variable with fallback
    assert set_fallbacks({'env_var1': {'fallback': (env_fallback, ['ENV_VAR_A'])}}, {}) == {'yes'}
    assert set_fallbacks({'env_var1': {'fallback': (env_fallback, ['ENV_VAR_A'])}}, {'env_var1': 'set'}) == set()
    assert set_fallbacks({'env_var2': {'fallback': (env_fallback, ['ENV_VAR_B', 'ENV_VAR_C'])}}, {}) == {'yes'}

# Generated at 2022-06-22 21:52:25.183927
# Unit test for function set_fallbacks

# Generated at 2022-06-22 21:52:36.820084
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Testing for parameters None
    parameters = {}
    argument_spec = dict(
        test_string=dict(fallback=(env_fallback, ('TEST_STRING',))),
        test_list=dict(fallback=(env_fallback, ('TEST_LIST',)))
    )
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['test_string'] == os.environ['TEST_STRING']
    assert parameters['test_list'] == os.environ['TEST_LIST']
    assert len(no_log_values) == 0

    # Testing for parameters not None
    parameters = dict(
        test_string=dict(fallback=(env_fallback, ('TEST_STRING',)))
    )

# Generated at 2022-06-22 21:52:46.450509
# Unit test for function set_fallbacks
def test_set_fallbacks():
    parameter_spec = {
        'test1': {'required': False, 'type': 'int', 'fallback': (env_fallback, ['TEST_ENV'])},
        'test2': {'required': False, 'type': 'int', 'fallback': (AnsibleUnsafeText, [123])},
    }

    #  test1 fallback fails, test2 fallback succeeds
    assert set_fallbacks(parameter_spec, {}) == set()

    os.environ['TEST_ENV'] = '123'
    # test1 fallback succeeds, test2 fallback succeeds
    assert set_fallbacks(parameter_spec, {}) == {'123'}



# Generated at 2022-06-22 21:52:50.967213
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys({'a': 'abc', 'b': 'def'}, ['abc', 'def']) == {'a': 'REDACTED', 'b': 'REDACTED'}
    assert sanitize_keys({'a': {'a': 'abc', 'b': 'def'}}, ['abc', 'def']) == {'a': {'a': 'REDACTED', 'b': 'REDACTED'}}



# Generated at 2022-06-22 21:53:01.553304
# Unit test for function env_fallback
def test_env_fallback():
    """Unit test for function env_fallback"""

    # test_args and test_kwargs are arbitrary except the length of kwargs must be less than 5
    test_args = ('test_args_1', 'test_args_2')
    test_kwargs = {'test_kwargs_1': 'test_kwargs_1', 'test_kwargs_2': 'test_kwargs_2'}
    os.environ['test_kwargs_1'] = 'test_kwargs_1'

    assert env_fallback('test_kwargs_1') == 'test_kwargs_1'
    assert env_fallback(*test_args, **test_kwargs) == 'test_kwargs_1'
    assert env_fallback(**test_kwargs) == 'test_kwargs_1'


# Generated at 2022-06-22 21:53:10.635287
# Unit test for function set_fallbacks
def test_set_fallbacks():
    spec = dict(
        foo=dict(
            type='str',
            fallback=(env_fallback, 'FOO_VAR')
        )
    )
    parameters = dict()
    set_fallbacks(spec, parameters)
    assert 'foo' in parameters

    spec = dict(
        foo=dict(
            type='str',
            fallback=(env_fallback, 'NON_EXISTING_VAR')
        )
    )
    parameters = dict()
    set_fallbacks(spec, parameters)
    assert 'foo' not in parameters

    spec = dict(
        foo=dict(
            type='str',
            fallback=(env_fallback, ('FOO_VAR', 'BAR_VAR'))
        )
    )
    parameters = dict()

# Generated at 2022-06-22 21:53:17.349942
# Unit test for function set_fallbacks

# Generated at 2022-06-22 21:53:24.465173
# Unit test for function sanitize_keys
def test_sanitize_keys():
    no_log_strings = ['foo', 'bar']
    ignore_keys = ['ansible_password']
    example_metadata = {
        'ansible_password': 'foo',
        'ansible_connection': 'bar',
        'foo': 'bar'
    }
    assert sanitize_keys(example_metadata, no_log_strings, ignore_keys) == {
        'ansible_password': 'foo',
        'ansible_connection': 'bar',
        '********': 'bar'
    }
    example_metadata = {
        'ansible_password': 'foo',
        'variables': {'ansible_password': 'foo', 'ansible_connection': 'bar', 'foo': 'bar'}
    }
    assert sanitize_keys(example_metadata, no_log_strings, ignore_keys)

# Generated at 2022-06-22 21:53:29.360430
# Unit test for function sanitize_keys
def test_sanitize_keys():
    source = { b'nolog_a': b'foo', b'nolog_b': b'bar', b'nolog_c': b'abc' }

    no_log_strings = set([b'abc', b'bar', b'foo'])
    ignore_keys = set()

    result = sanitize_keys(source, no_log_strings, ignore_keys)

    assert isinstance(result, dict)
    assert len(result) == 1
    assert 'nolog_c' in result



# Generated at 2022-06-22 21:53:39.245381
# Unit test for function remove_values
def test_remove_values():
    # Add string values to keep in value
    no_log_strings = ['password', 'secret']
    # Set value to remove no_log_strings values from
    value = {'key1': 'password', 'key2': 'password', 'key3': [{'subkey1': 'password', 'subkey2': 'password'}]}
    # Set expected value to compare to
    expected_value = {'key1': 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER', 'key2': 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER',
                      'key3': [{'subkey1': 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER', 'subkey2': 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'}]}
    # Check that values were

# Generated at 2022-06-22 21:53:49.653931
# Unit test for function sanitize_keys
def test_sanitize_keys():
    obj_dict = {}
    obj_dict['abc@def.com'] = 'foo'
    obj_dict['abc_def'] = 'foo'
    obj_dict['abc-def'] = 'foo'
    obj_dict['abcdef'] = 'foo'
    obj_dict['abc/def'] = 'foo'

    expected_dict = {}
    expected_dict['abc@def.com'] = 'foo'
    expected_dict['abc_def'] = 'foo'
    expected_dict['abc-def'] = 'foo'
    expected_dict['ABCDEF'] = 'foo'
    expected_dict['abc/def'] = 'foo'

    assert sanitize_keys(obj_dict, ['abcdef']) == expected_dict



# Generated at 2022-06-22 21:54:00.843765
# Unit test for function remove_values
def test_remove_values():
    """Remove strings in ``no_log_strings`` from value.
    """

    value = ""
    no_log_strings = "abc"
    try:
        removed_value = remove_values(value, no_log_strings)
    except TypeError as e:
        print("Error : %s" % to_native(e))

    print("Test passed - Value is %s and removed_value is %s" % (value, removed_value))
    
    value = "aabcaabcd"
    no_log_strings = "abc"
    try:
        removed_value = remove_values(value, no_log_strings)
    except TypeError as e:
        print("Error : %s" % to_native(e))


# Generated at 2022-06-22 21:54:10.845285
# Unit test for function set_fallbacks
def test_set_fallbacks():

    no_log_values = set()
    argument_spec = {'param1': {'type': 'int', 'fallback': (env_fallback, 'ANSIBLE_PARAM1')}}
    parameters = {}
    os.environ['ANSIBLE_PARAM1'] = '1'
    no_log_values.update(set_fallbacks(argument_spec, parameters))
    assert parameters == {'param1': 1}
    assert '1' in no_log_values

    os.environ['ANSIBLE_PARAM1'] = ''
    try:
        set_fallbacks(argument_spec, parameters)
    except AnsibleFallbackNotFound:
        pass
    assert parameters == {'param1': 1}
    assert '1' in no_log_values


# Generated at 2022-06-22 21:54:16.595265
# Unit test for function sanitize_keys
def test_sanitize_keys():
    obj = {'public': {'private': 'foo'}, 'public_bar': 'baz'}
    new_value = sanitize_keys(obj, {'private'})

    # test to make sure that no_log values are removed from keys
    assert new_value == {'public': {'_ansible_private': 'foo'}, 'public_bar': 'baz'}



# Generated at 2022-06-22 21:54:27.756476
# Unit test for function sanitize_keys
def test_sanitize_keys():
    # Assert sanitize_keys can be used on nested dicts
    params = {'param1': 'value1', 'param2': {'param2-1': 'value2-1', 'param2-2': {'param2-2-1': 'value2-2-1'}}}
    no_log_values = {'param1', 'value2-2-1'}
    ignore_keys = {'param2'}

    assert(sanitize_keys(params, no_log_values, ignore_keys) == {'param1': 'value1', 'param2': {'param2-1': 'value2-1', 'param2-2': {'param2-2-1': 'value2-2-1'}}})


# Generated at 2022-06-22 21:54:37.172159
# Unit test for function remove_values
def test_remove_values():
    """ Unit tests for remove_values. """
    import copy
    import json
    import yaml

    # We're using yaml to represent the test data as yaml since yaml is a superset
    # of json.

    # Helper function to convert from yaml to json.
    def yaml_to_json(data):
        """
        Convert yaml to json.
        """
        return json.loads(yaml.safe_dump(yaml.safe_load(data)))

    def test_case(input_data, output_data, no_log_strings):
        """
        Run a single test case.
        """
        input_data = yaml_to_json(input_data)
        output_data = yaml_to_json(output_data)

        # Clone the input data so we don't modify the original since

# Generated at 2022-06-22 21:54:40.960953
# Unit test for function sanitize_keys
def test_sanitize_keys():
    data = {'my': {'password': 'secret', 'password2': 'secret2'}, 'key': 'value', 'birth': '2020-08-26'}
    assert 'password' in data['my'].keys()
    log_sanitize = sanitize_keys(data, ['secret'])
    print(log_sanitize)



# Generated at 2022-06-22 21:54:49.676395
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['foo'] = 'bar'
    os.environ['hello'] = 'world'
    assert env_fallback('foo') == 'bar'
    assert env_fallback('quux', 'foo') == 'bar'
    assert env_fallback('quux', 'hello') == 'world'
    assert env_fallback('quux', 'answer', 'hello') == 42
    assert env_fallback('quux', 'answer') == 42
    assert env_fallback('quux', 'answer', 'default') == 'default'
    assert_raises(AnsibleFallbackNotFound, env_fallback, 'quux')



# Generated at 2022-06-22 21:54:56.073497
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'my_param': {'type': 'str', 'fallback': (env_fallback, ['TEST_ENV_VAR'])}}
    parameters = {'my_param': None}
    result = set_fallbacks(argument_spec, parameters)
    assert len(result) == 0


# Generated at 2022-06-22 21:54:57.658324
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys('test', ['test']) == 'test'



# Generated at 2022-06-22 21:55:05.516218
# Unit test for function set_fallbacks
def test_set_fallbacks():
    from ansible.module_utils import basic

    argument_spec = {
        'a': {'type': 'str', 'fallback': ('env_fallback', 'TEST_A',)},
        'b': {'type': 'str', 'fallback': ('env_fallback', 'TEST_C',), 'no_log': True},
        'c': {'type': 'str', 'fallback': (basic.env_fallback, 'TEST_C')},
    }

    parameters = {"b": "test"}

    no_log_values = set_fallbacks(argument_spec, parameters)
    assert no_log_values == set(["test"])
    assert parameters['a'] == 'TEST_A'
    assert parameters['c'] == 'TEST_C'



# Generated at 2022-06-22 21:55:16.472475
# Unit test for function remove_values

# Generated at 2022-06-22 21:55:22.960434
# Unit test for function remove_values
def test_remove_values():
    actual = remove_values('this is a secret', ['secret', 'sensitive'])
    assert actual == 'this is a '

    actual = remove_values(['this is a secret', 'this is also secret', 'this is an ssh key'], ['secret', 'sensitive', 'key'])
    assert actual == ['this is a ', 'this is also ', 'this is an ssh ']

    actual = remove_values(['a', ['b', ['c', 'secret', 'd'], 'e']], ['secret'])
    assert actual == ['a', ['b', ['c', '', 'd'], 'e']]


# Generated at 2022-06-22 21:55:33.987050
# Unit test for function remove_values
def test_remove_values():
    no_log_strings = ['foo']

    assert remove_values('foo', no_log_strings) == 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'
    assert remove_values('bar', no_log_strings) == 'bar'

    assert remove_values([1, 2, 3, 'foo', 'bar'], no_log_strings) == [1, 2, 3, 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER', 'bar']
    assert remove_values(['foo', 'bar'], no_log_strings) == ['VALUE_SPECIFIED_IN_NO_LOG_PARAMETER', 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER']


# Generated at 2022-06-22 21:55:40.378122
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'name': {'type': 'str', 'required': True, 'fallback': (env_fallback, ['ANSIBLE_NET_USERNAME'])},
        'force': {'type': 'bool', 'default': False, 'fallback': (env_fallback, ['ANSIBLE_NET_FORCE'])},
    }

    parameters = {'host': 'testhost'}

    no_log_values = set_fallbacks(argument_spec, parameters)

    assert 'force' in parameters
    assert 'name' not in parameters

    assert 'ANSIBLE_NET_FORCE' in no_log_values
    assert 'username' not in no_log_values



# Generated at 2022-06-22 21:55:52.506840
# Unit test for function sanitize_keys
def test_sanitize_keys():
    no_log_strings = set()

# Generated at 2022-06-22 21:55:55.877713
# Unit test for function remove_values
def test_remove_values():
  assert remove_values([{'a': 'abcabcabc', 'b': 'cde', 'c': None}], ['abc']) == \
      [{'a': '***', 'b': 'cde', 'c': None}]


# Generated at 2022-06-22 21:55:59.733296
# Unit test for function env_fallback
def test_env_fallback():
    os.environ["FOO"] = "BAR"
    assert "BAR" == env_fallback("FOO")
    assert "BAZ" == env_fallback("BAR", "BAZ")
    try:
        env_fallback("BAR")
    except:
        pass


# Generated at 2022-06-22 21:56:01.598247
# Unit test for function env_fallback
def test_env_fallback():
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('FOO', 'BAR')



# Generated at 2022-06-22 21:56:13.812906
# Unit test for function sanitize_keys
def test_sanitize_keys():
    no_log_strings = set()
    ignore_keys = frozenset()
    data = dict(a=5, b=dict(c='hello', d='world', _ansible_no_log='yes'), _ansible_no_log='yes')
    expected_data = dict(a=5, b=dict(c='hello', d='world', _ansible_no_log='yes'), _ansible_no_log='yes')
    assert sanitize_keys(data, no_log_strings, ignore_keys) == expected_data
    assert sanitize_keys(dict(a=5, b=dict(c='hello', d='world', _ansible_no_log='yes'), _ansible_no_log='yes'), no_log_strings, ignore_keys) == expected_data


# Generated at 2022-06-22 21:56:24.554748
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Setup test parameters
    fallback1_args = ['a', 'b', {'x': 'y', 'z': 'w'}]
    expected_fallback1_kwargs = {'x': 'y', 'z': 'w'}
    fallback2_args = ['a']
    fallback3_args = ['a', {'x': 'y'}]
    expected_fallback3_kwargs = {'x': 'y'}
    fallback4_args = ['a', {'z': 'w'}]
    expected_fallback4_kwargs = {'z': 'w'}
    fallback5_args = ['a', 'b', {'x': 'y'}]
    expected_fallback5_kwargs = {'x': 'y'}

# Generated at 2022-06-22 21:56:33.739211
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'name': {'required': True},
        'password': {'required': True, 'no_log': True},
        'ssh_key': {'required': True, 'fallback': (env_fallback, ['ANSIBLE_NET_SSH_KEY'])},
    }
    parameters = {
        'name': 'test',
        'password': 'test',
    }
    no_log_values = set()
    no_log_values.update(set_fallbacks(argument_spec, parameters))

    assert len(no_log_values) == 1
    assert 'test' in no_log_values
    assert 'password' not in parameters

# Generated at 2022-06-22 21:56:40.486822
# Unit test for function env_fallback
def test_env_fallback():
    """Test function env_fallback"""
    # Test env_fallback
    get_exception = False
    try:
        env_fallback('ansible_test')
    except:
        get_exception = True
    assert get_exception is True, "Expect an exception when read an undefined environment variable"

    os.environ['ansible_test'] = 'test_env_fallback'
    assert env_fallback('ansible_test') == 'test_env_fallback', "Fail to read defined environment variable ansible_test"


# Generated at 2022-06-22 21:56:47.232855
# Unit test for function sanitize_keys
def test_sanitize_keys():
    keys_pass = [
        {'a': 'b', '_ansible_no_log': True},
        '_ansible_no_log_123',
        {'#abc': 'xyz'},
        {'#': '_'},
        {'#': 123},
        {'#': {'a': 'b'}},
        {'#': None},
        {'#': True},
        {'#': False},
        {'#': {'#': None}},
        {'#': {'#': {'#': None}}},
    ]

# Generated at 2022-06-22 21:56:57.864640
# Unit test for function remove_values
def test_remove_values():
    assert remove_values('abcd', ['a']) == 'bcd'
    assert remove_values('abcd', ['a', 'b', 'c']) == 'd'
    assert remove_values('abcd', ['a', 'b', 'c', 'd']) == ''
    assert remove_values('abcd', ['e']) == 'abcd'
    assert remove_values('abcd', []) == 'abcd'
    assert remove_values('abcd', ['']) == 'abcd'

    assert remove_values({'a': 'b'}, ['b']) == {'a': ''}
    assert remove_values(['a', 'b'], ['b', 'x']) == ['a']
    assert remove_values(('a', 'b'), ['b', 'x']) == ('a',)

# Generated at 2022-06-22 21:57:06.451975
# Unit test for function sanitize_keys
def test_sanitize_keys():
    no_log_strings = set()
    ignore_keys = frozenset()
    sandbox = {"x-x-x-x":'y-y-y-y', 'aba':'bab', 'c':'d', 'x_x':{'x_x':'y_y'}, 'l':[{'l':'l'}]}
    valid_sandbox = {"x_x_x_x":'y-y-y-y', 'aba':'bab', 'c':'d', 'x_x':{'x_x':'y_y'}, 'l':[{'l':'l'}]}
    assert sanitize_keys(sandbox, no_log_strings, ignore_keys) == valid_sandbox

# Generated at 2022-06-22 21:57:15.542260
# Unit test for function remove_values
def test_remove_values():
    print("testing dict")
    testinp = dict(one=1, two=2, three=dict(four=4, five=5), six="six", seven=['a', 'b', 'c'])
    testinp['three']['four'] = dict(x=1, y=2, z=3)
    testinp['three']['four']['z'] = "z"
    testinp['seven'][1] = dict(a=1, b=2)
    testinp['seven'][1]['b'] = "b"
    expected = dict(three=dict(four=dict(z=CENSORED)))
    expected['three']['four']['z'] = CENSORED
    expected['seven'] = [CENSORED, dict(b=CENSORED)]

# Generated at 2022-06-22 21:57:25.393417
# Unit test for function sanitize_keys
def test_sanitize_keys():
    obj = {
        'foo': 'bar',
        'baz': {
            'bar': 'foo',
            'password': {
                'password': 'foo',
            },
        },
    }

    # The object to sanitize.
    new_value = sanitize_keys(obj, ['password'])

    # The sanitized object.
    expected_value = {
        'foo': 'bar',
        'baz': {
            'bar': 'foo',
            '**': {
                '**': 'foo',
            },
        },
    }

    assert new_value == expected_value



# Generated at 2022-06-22 21:57:33.534375
# Unit test for function sanitize_keys
def test_sanitize_keys():
    '''Sanitize the keys with data by removing no_log values from key names'''
    d = {'a':'1', 'b':[1,2], 'c':[{'p':'r', 'o':'w', 'l':'e'}, {'d':'e', 'm':'a'}], 'd':{'x':1,'y':2}}
    res = sanitize_keys(d, ['name@localhost'])
    assert 'name' in res['d'], 'The key name should be present in resultant dictionary'
    assert '@localhost' not in res['d'], 'The key @localhost should not present in resultant dictionary'
    assert 'o' not in res['c'][1], 'The key o should not present in resultant dictionary'

# Generated at 2022-06-22 21:57:43.162018
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['TEST_ENV_VAR_1'] = 'test_env_fallback_1'
    os.environ['TEST_ENV_VAR_2'] = 'test_env_fallback_2'
    assert env_fallback('TEST_ENV_VAR_1') == 'test_env_fallback_1'
    assert env_fallback('TEST_ENV_VAR_2') == 'test_env_fallback_2'
    try:
        env_fallback('TEST_ENV_VAR_NOT_EXIST')
    except:
        pass
    else:
        assert False
# End of unit tests



# Generated at 2022-06-22 21:57:52.095561
# Unit test for function sanitize_keys
def test_sanitize_keys():
    no_log_strings = ['asdf', 'ghjk']
    ignore_keys = ['test']
    test_dict = {'test': 'test_val', 'test_3': 'test_3_val', 'test_4': {'test': 'test_4_val', 'test_4_2': 'test_4_2_val', 'test_4_3': {'test': 'test_4_3_val', 'test_4_3_2': 'test_4_3_2_val'}, '_ansible_no_log': False}, '_ansible_no_log': True, '_ansible_parsed': True}

# Generated at 2022-06-22 21:58:00.012521
# Unit test for function remove_values

# Generated at 2022-06-22 21:58:11.563263
# Unit test for function sanitize_keys
def test_sanitize_keys():
    class test_dict(dict):
        pass

    class test_list(list):
        pass

    class test_set(set):
        pass

    # Make sure we don't get an exception for non-container objects
    input_value = 'foo'
    output_value = sanitize_keys(input_value)
    assert input_value == output_value
    assert isinstance(output_value, str)

    # Make sure we don't get an exception for non-container objects
    # that aren't strings
    input_value = 100
    output_value = sanitize_keys(input_value)
    assert input_value == output_value
    assert isinstance(output_value, int)

    # Make sure we don't get an exception for non-container objects
    # that aren't strings
    input_value = b'foo'

# Generated at 2022-06-22 21:58:22.578863
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        foo=dict(required=True),
        bar=dict(type='path', fallback=(env_fallback, 'BAR', 'BAZ')),
        bam=dict(type='path', fallback=(env_fallback, dict(fallback='BAM', fail_on_missing=True))),
    )

    parameters = dict(foo='foo_value')

    no_log_values = set_fallbacks(argument_spec, parameters)
    assert 'foo_value' not in no_log_values
    assert parameters.get('foo') == 'foo_value'
    assert parameters.get('bar') == 'bar_value'
    assert 'bar_value' in no_log_values
    assert parameters.get('bam') == 'bam_value'
    assert 'bam_value'

# Generated at 2022-06-22 21:58:33.556537
# Unit test for function sanitize_keys
def test_sanitize_keys():
    keys = [('foo', 'bar'), ('baz', 'qux', 'baz'), (1, 2, 3)]
    values_to_remove = [('foo',), ('baz', 'qux', 'baz'), (1,), (2,), (3,)]
    no_log_strings = {"foo", "baz", "2", "3"}
    new_keys = [("bar",), ("qux",), (1, 2, 3)]
    for k, v, n, new_k in zip(keys, values_to_remove, no_log_strings, new_keys):
        assert sanitize_keys(k, set(v), {'_ansible_foo', '_ansible_bar'}) == new_k



# Generated at 2022-06-22 21:58:38.854253
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert set_fallbacks({'hello':{'type':'int', 'fallback': (env_fallback, 'PYTHON_WORLD')}}, {}) == set(['PYTHON_WORLD'])
    assert set_fallbacks({'hello':{'type':'int', 'fallback': (env_fallback, 'PYTHON_WORLD')}}, {'hello':'1'}) == set()
    assert set_fallbacks({'hello':{'type':'int', 'fallback': (env_fallback, 'PYTHON_WORLD')}}, {'hello':'1'}) == set()
    assert set_fallbacks({'hello':{'type':'int', 'fallback': (env_fallback, 'GOODBYE_WORLD')}}, {}) == set()



# Generated at 2022-06-22 21:58:48.965654
# Unit test for function remove_values
def test_remove_values():
    data = {'a': 'b', 'c': {'d': 'e', 'f': 'g', 'h': ['i', 'j', 'k']}}
    remove_values(data, ['b']) == {'a': 'b', 'c': {'d': 'e', 'f': 'g', 'h': ['i', 'j', 'k']}}
    remove_values(data, ['b', 'e']) == {'a': '', 'c': {'d': '', 'f': 'g', 'h': ['i', 'j', 'k']}}
    remove_values(data, ['a']) == {'a': '', 'c': {'d': 'e', 'f': 'g', 'h': ['i', 'j', 'k']}}

# Generated at 2022-06-22 21:59:01.385465
# Unit test for function env_fallback
def test_env_fallback():
    import os
    name = 'PYTHON_HOME'
    # Set an environment variable
    os.environ[name] = '/usr/local/python'
    # Test a fallback class that use the environment variable
    class TestEnvFallback(object):
        _fallback_str = '{0}_{1}'.format(name, '3')
        _fallback_list = [name, '{0}_2'.format(name), name]
        _fallback_dict = {
            'test_1': name,
            'test_2': '{0}_2'.format(name)}

# Generated at 2022-06-22 21:59:13.411530
# Unit test for function set_fallbacks

# Generated at 2022-06-22 21:59:21.784690
# Unit test for function env_fallback
def test_env_fallback():
    # Save old environ for cleanup
    old_environ = dict(os.environ)
    os.environ.clear()

    # Test with no arguments
    try:
        env_fallback()
    except AnsibleFallbackNotFound:
        pass
    else:
        raise AssertionError('Failed to raise AnsibleFallbackNotFound')

    # Test with single argument set
    os.environ['FOO'] = 'foo1'
    assert env_fallback(['BAR', 'FOO']) == 'foo1'

    # Test with multiple arguments set
    os.environ['BAR'] = 'bar1'
    assert env_fallback(['BAR', 'FOO']) == 'bar1'

    # Test with multiple arguments not set
    del os.environ['FOO']
    del os

# Generated at 2022-06-22 21:59:27.340080
# Unit test for function env_fallback
def test_env_fallback():
    import os
    assert os.environ.get('PATH') != None
    os.environ['TESTENV'] = 'hello'
    assert env_fallback('TESTENV') == 'hello'
    assert env_fallback('TESTENV', 'PATH') == 'hello'
    assert env_fallback('TESTX', 'PATH') == os.environ.get('PATH')
    assert env_fallback('TESTY') == None


# Generated at 2022-06-22 21:59:37.118670
# Unit test for function remove_values
def test_remove_values():
    assert remove_values({'a': 'b', 'c': {'d': 'this is a no_log string'}}, ['this is a no_log string']) == {'a': 'b', 'c': {'d': 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'}}
    assert remove_values({'a': 'b', 'c': {'d': 'this is a no_log string'}}, []) == {'a': 'b', 'c': {'d': 'this is a no_log string'}}

# Generated at 2022-06-22 21:59:42.755736
# Unit test for function sanitize_keys
def test_sanitize_keys():

    assert sanitize_keys('abcd', []) == 'abcd'
    assert sanitize_keys(['abcd'], []) == ['abcd']
    assert sanitize_keys(set(['abcd']), []) == set(['abcd'])
    assert sanitize_keys(('abcd',), []) == ('abcd',)

    assert sanitize_keys({'abcd': {'efgh': 'ijkl'}}, []) == {'abcd': {'efgh': 'ijkl'}}
    assert sorted(sanitize_keys({'abcd': {'efgh': 'ijkl'}, 'no_log': {'foo': {'efgh': 'ijkl', 'bar': 'baz'}}}, ['baz']).keys()) == ['abcd', 'no_log']


# Generated at 2022-06-22 21:59:54.579426
# Unit test for function remove_values
def test_remove_values():
    no_log_strings = ['REDACTED']
    some_dict = {'password': 'hunter2', 'other': 'foo'}
    some_list = ['hunter2']
    some_str = 'hunter2'
    some_tuple = ('hunter2',)
    some_simple_nested_structure = {'password': ['hunter2', some_dict], 'other': 'foo'}
    some_nested_structure = {'password': ['hunter2', some_dict], 'other': [['foo'], some_list]}
    assert remove_values(some_dict, no_log_strings) == {'password': 'REDACTED', 'other': 'foo'}
    assert remove_values(some_list, no_log_strings) == ['REDACTED']

# Generated at 2022-06-22 21:59:58.846558
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('TEST_ENVIRONMENT_VARIABLE') == os.environ['TEST_ENVIRONMENT_VARIABLE']
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('TEST_ENVIRONMENT_VARIABLE_NOT')


# Generated at 2022-06-22 22:00:10.589034
# Unit test for function remove_values

# Generated at 2022-06-22 22:00:23.237045
# Unit test for function sanitize_keys
def test_sanitize_keys():
    dct = {'status': {'phase': '1'}, 'result': '2'}
    assert_equal(sanitize_keys(dct, {'status', 'result'}), {'status': {'phase': '1'}, 'result': '2'})
    assert_equal(sanitize_keys(dct, {'status', 'result'}, {'second'}), {'status': {'phase': '1'}, 'result': '2'})
    assert_equal(sanitize_keys(dct, {'status', 'result'}, {'status'}), {'status': {'phase': '1'}, 'result': '2'})

# Generated at 2022-06-22 22:00:31.553180
# Unit test for function env_fallback
def test_env_fallback():
    env = {
        "ANSIBLE_GET_URL_TIMEOUT": "10",
        "ANSIBLE_HOST_KEY_CHECKING": "False",
    }
    with patch.dict(os.environ, env):
        assert env_fallback("ANSIBLE_GET_URL_TIMEOUT") == '10'
        assert env_fallback("ANSIBLE_HOST_KEY_CHECKING") == 'False'
        assert env_fallback("FOO") == 'False'  # This will fail
        assert env_fallback("FOO", "BAR") == 'False'  # This will fail also



# Generated at 2022-06-22 22:00:43.964454
# Unit test for function sanitize_keys
def test_sanitize_keys():

    def create_data(string):
        return {
            'a': {'A': {'A1': {'A11': 'a', 'A12': 'b'}, 'A2': 'c'}, 'B': {'B1': {'B11': 'd', 'B12': 'e'}, 'B2': 'f'}},
            'b': {'A': {'A1': {'A11': 'a', 'A12': 'b'}, 'A2': 'c'}, 'B': {'B1': {'B11': 'd', 'B12': 'e'}, 'B2': 'f'}},
            'password': string
        }


# Generated at 2022-06-22 22:00:50.851386
# Unit test for function env_fallback
def test_env_fallback():
    try:
        fallback = env_fallback('ANSIBLE_MODULE_ARGS')
    except AnsibleFallbackNotFound as e:
        raise AssertionError("Unable to get value for 'ANSIBLE_MODULE_ARGS' from environment, exception: %s" % e)
    assert fallback == os.environ['ANSIBLE_MODULE_ARGS'], "Fallback value from environment '%s' did not match expected value '%s'" \
        % (fallback, os.environ['ANSIBLE_MODULE_ARGS'])



# Generated at 2022-06-22 22:01:02.797810
# Unit test for function sanitize_keys
def test_sanitize_keys():
    '''
    Test sanitize_keys function
    '''

# Generated at 2022-06-22 22:01:10.862137
# Unit test for function sanitize_keys

# Generated at 2022-06-22 22:01:22.865254
# Unit test for function sanitize_keys
def test_sanitize_keys():
    def assert_equal(old, new):
        if old != new:
            raise AssertionError("%s != %s" % (old, new))

    assert_equal(
        sanitize_keys(
            {}, {},
        ),
        {},
    )
    assert_equal(
        sanitize_keys(
            {'foo': {'bar': 'baz'}}, {'bar'},
        ),
        {'foo': {'bar': 'baz'}},
    )
    assert_equal(
        sanitize_keys(
            {'foo': {'bar': 'baz'}}, {'bar'},
        ),
        {'foo': {'bar': 'baz'}},
    )