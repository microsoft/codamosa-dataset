

# Generated at 2022-06-22 21:51:23.076597
# Unit test for function sanitize_keys
def test_sanitize_keys():
    '''
    Unit test for function sanitize_keys
    '''
    from ansible.module_utils.common.text.converters import to_bytes, to_unicode
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.utils.unicode import to_unicode
    from ansible.module_utils.six import text_type
    from ansible.module_utils._text import to_native, to_text
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.six import string_types , text_type
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_FALSE, BOOLEANS_TRUE, boolean

# Generated at 2022-06-22 21:51:33.930136
# Unit test for function remove_values
def test_remove_values():
    from ansible.module_utils.common._collections_compat import GetAttrProxy
    from ansible.module_utils.six import PY3

    class MyClass(object):
        def __init__(self, value):
            self.value = value

        def __str__(self):
            return self.value

    class MyClassNoStr(object):
        def __init__(self, value):
            self.value = value

        def __repr__(self):
            return self.value

        def __bytes__(self):
            return b'MyClassNoStr'

    class MyClassBytes(object):
        def __init__(self, value):
            self.value = value

        def __bytes__(self):
            return self.value


# Generated at 2022-06-22 21:51:42.924119
# Unit test for function sanitize_keys
def test_sanitize_keys():
    obj = {'some key': {'other key': {'a.key': 'value'}},
           '_ansible_foo': 'bar', '_ansible_bar': {'a.key': 'value'},
           '_ansible_no_log': 'baz', '_ansible_no_log_': {'a.key': 'value'},
           '_ansible_secret': 'buzz', '_ansible_secret_': {'a.key': 'value'},
           '_ansible_vault': 'fuzz', '_ansible_vault_': {'a.key': 'value'},
           '_ansible_ssh_pass': 'fizz', '_ansible_ssh_pass_': {'a.key': 'value'}}
    # no_log_strings is the blacklist of

# Generated at 2022-06-22 21:51:50.488691
# Unit test for function sanitize_keys
def test_sanitize_keys():
    # test with simple example
    dct = {'k1': 'v1', 'k2': 'v2', 'k3': 'v3'}
    new_dct = sanitize_keys(dct, ['v1'], ignore_keys=set())
    assert new_dct == {'k2': 'v2', 'k3': 'v3'}
    # test with nested example
    dct = {'k1': 'v1', 'k2': {'k3': 'v1'}, 'k4': 'v2'}
    new_dct = sanitize_keys(dct, ['v1'], ignore_keys=set())
    assert new_dct == {'k4': 'v2'}

# Generated at 2022-06-22 21:51:54.230427
# Unit test for function sanitize_keys
def test_sanitize_keys():
    """
    Sanity check function to make sure when we ignore keys, we don't modify them.
    """
    for obj in [dict, list, set]:
        ob = obj([('key1', 'value1'), ('key2', 'value2')])
        sanitize_keys(ob, ('value1', 'value2'), ignore_keys=('key2',))
        assert ob == obj([('key1', 'value1'), ('key2', 'value2')])



# Generated at 2022-06-22 21:52:01.265066
# Unit test for function remove_values
def test_remove_values():
    assert remove_values('abcd', 'a') == 'bcd'
    assert remove_values(['a', 'b'], 'a') == ['', 'b']
    assert remove_values({'a': 'a', 'b': ['a', 'b'], 'c': {'a': 'a', 'b': 'b'}}, 'a') == {'b': ['', 'b'], 'c': {'b': 'b'}}
    assert remove_values({'a': 'a', 'b': 'a', 'c': {'a': 'a', 'b': 'a'}}, 'a') == {'b': '', 'c': {'b': ''}}

# Generated at 2022-06-22 21:52:08.520056
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # test_name is name of the test
    def test_name(test_case):
        test_case.assertEqual(None, set_fallbacks(
            dict(x=dict(type='str', fallback=('env:FOO', 'default'))), {})
        )
        test_case.assertEqual({'FOO'}, set_fallbacks(
            dict(x=dict(type='str', no_log=True, fallback=('env:FOO', 'default'))), {})
        )

    # pylint: disable=invalid-name
    test_cases = []
    # pylint: disable=invalid-name
    test_cases.append(TestCase('test_name'))

    for test_case in test_cases:
        test_case.execute()


# Unit test

# Generated at 2022-06-22 21:52:14.910844
# Unit test for function remove_values
def test_remove_values():
    value1 = dict(a=2, b=3)
    value2 = dict(a=2, b=3, c=4, c_password="password")
    value3 = 'test string'
    value4 = dict(a=2, b=dict(ba=2, bb=3), c=[1, 2])
    value5 = dict(a=2, b=dict(ba=2, bb=3), c=[1, 'password'])
    value6 = dict(a=2, b=dict(ba=2, bb=3), c=[1, 'password'], d={'da': 2, 'db': 'password'})

# Generated at 2022-06-22 21:52:23.745569
# Unit test for function sanitize_keys
def test_sanitize_keys():
    import functools
    def test(a, b, **kwargs):
        assert sanitize_keys(a, **kwargs) == b

    test({'a': 'b', 'pass': 'd'}, {'a': 'b', 'pass': '**'})
    test({'a': 'b', 'pass': 'd', 'no_log': True}, {'a': 'b', 'pass': '**'})
    test({'a': 'b', 'pass': 'd', 'no_log': True}, {'a': 'b', 'pass': 'd'}, no_log_values=['d'])
    test({'a': 'b', 'pass': 'd', 'no_log': True}, {'a': 'b', 'pass': 'd'}, no_log_values=['d'])
   

# Generated at 2022-06-22 21:52:31.014975
# Unit test for function sanitize_keys

# Generated at 2022-06-22 21:52:41.433434
# Unit test for function remove_values

# Generated at 2022-06-22 21:52:48.155326
# Unit test for function remove_values
def test_remove_values():
    value = 'abcdef'
    assert remove_values(value, ['bcd']) == 'aef'
    value = ['bcd', 'bcd', 'bcd']
    assert remove_values(value, ['bcd']) == ['', '', '']
    value = 'bcdCD'
    assert remove_values(value, ['bcd']) == 'CD'
    value = ['bcdCD', 'bcd']
    assert remove_values(value, ['bcd']) == ['CD', '']
    value = {'abc': 'abcdef'}
    assert remove_values(value, ['bcd']) == {'abc': 'aef'}
    value = {'bcd': 'abcdef'}
    assert remove_values(value, ['bcd']) == {'bcd': 'abcdef'}

# Generated at 2022-06-22 21:52:58.589665
# Unit test for function sanitize_keys
def test_sanitize_keys():
    obj1 = {'a': 'b'}
    new_obj1 = sanitize_keys(obj1, ["b"])
    assert new_obj1 == {'a': 'b'}

    obj2 = {'password': 'foo', 'nested':{'password':'bar', 'names':{'name':'lbar'}}, 'a':'b'}
    new_obj2 = sanitize_keys(obj2, ["password", "bar"])
    assert new_obj2 == {'_ansible_no_log': 'foo', 'nested':{'_ansible_no_log':'bar', 'names':{'name':'lbar'}}, 'a':'b'}


# Generated at 2022-06-22 21:53:04.288683
# Unit test for function env_fallback
def test_env_fallback():
    with patch.object(os, 'environ', {}):
        with pytest.raises(AnsibleFallbackNotFound):
            env_fallback('FOO')
        assert env_fallback('FOO', default='bar') == 'bar'

        os.environ['FOO'] = 'foo'
        assert env_fallback('FOO') == 'foo'



# Generated at 2022-06-22 21:53:16.403476
# Unit test for function remove_values
def test_remove_values():
    secret_data = {
        'password': 'password1',
        'ssh_key': 'private_key',
        'ssh_key_file': '/home/user1/.ssh/id_rsa',
        'api_key': 'private_api_key',
        'connection_key': 'private_connection_key',
        'account_key': 'private_account_key',
        'secret': 'private_secret',
        'secret_key': 'private_secret_key',
        'no_log_test': 'no_log_test'}

# Generated at 2022-06-22 21:53:22.249210
# Unit test for function remove_values
def test_remove_values():
    a = make_itertools_immutable({'x': 'a', 'y': 'b'})
    b = make_itertools_immutable({'x': 'a', 'y': 'b'})
    # Check that it returns a different object
    assert remove_values(a, {'a'}) is not a
    # Check that it is functionally equivalent
    assert remove_values(a, {'a'}) == {'x': None, 'y': 'b'}
    # confirm it's not just a shallow copy
    assert remove_values(a, {'a'}) != b



# Generated at 2022-06-22 21:53:30.904491
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys('hihihi', ['hi']) == 'hihihi'
    assert sanitize_keys({'foo': 'bar', 'hi': 'ho'}, ['hi', 'foo']) == {'h_': 'bar', '_': 'ho'}
    assert sanitize_keys([1, 2, 3], [1]) == [1, 2, 3]
    assert sanitize_keys({'hi': [1, 2, 3]}, [1]) == {'hi': [1, 2, 3]}
    assert sanitize_keys({'hi': {'foo': 'bar', 'hi': 'ho'}}, ['hi', 'foo']) == {'hi': {'h_': 'bar', '_': 'ho'}}

# Generated at 2022-06-22 21:53:40.869944
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'a': {'type': 'str', 'fallback': (env_fallback, 'A_ENV')},
                     'b': {'type': 'str', 'fallback': (env_fallback, 'B_ENV')}}
    parameters = {'a': 'value', 'b': None}
    # Test no fallback
    assert set_fallbacks(argument_spec, parameters) == set()
    assert parameters == {'a': 'value', 'b': None}
    # Test fallback
    os.environ['B_ENV'] = 'b_value'
    assert set_fallbacks(argument_spec, parameters) == set()
    assert parameters == {'a': 'value', 'b': 'b_value'}
    # Test no_log

# Generated at 2022-06-22 21:53:51.110502
# Unit test for function sanitize_keys
def test_sanitize_keys():
    keys = {'key1':'value1','key2':'value2','key3':'value3','_ansible_key1':'value1'}
    assert keys.keys() == ['key1','key2','key3','_ansible_key1']
    keys_result = {'key1':'value1','key2':'value2','key3':'value3','_ansible_key1':'value1'}
    assert sanitize_keys(keys, no_log_strings=['value1','value2'], ignore_keys=['key2','_ansible_key1']) == keys_result
    keys_result = {'key1':'value1','key2':'value2','key3':'value3','ansible_key1':'value1'}

# Generated at 2022-06-22 21:54:00.580136
# Unit test for function sanitize_keys
def test_sanitize_keys():
    from ansible.compat.tests import unittest

    class TestSanitizeKeys(unittest.TestCase):

        def test_sanitize_keys_sequences(self):
            self.assertEqual(sanitize_keys([1, 2, 3], ['1']), [1, 2, 3])
            self.assertEqual(sanitize_keys((1, 2, 3), ['1']), (1, 2, 3))
            self.assertEqual(sanitize_keys((1, '2', 3), ['1']), (1, '2', 3))
            self.assertEqual(sanitize_keys([1, '2', 3], ['1']), [1, '2', 3])

# Generated at 2022-06-22 21:54:10.682762
# Unit test for function sanitize_keys
def test_sanitize_keys():
    import pytest
    from ansible.module_utils._text import to_text


# Generated at 2022-06-22 21:54:20.389580
# Unit test for function env_fallback
def test_env_fallback():
    assert 'SHELL' in os.environ, "SHELL environment variable must be set to test env_fallback"
    assert env_fallback('SHELL') == os.environ['SHELL']
    assert env_fallback('SHELL', 'SHELL2') == os.environ['SHELL']
    assert env_fallback('SHELL2', 'SHELL') == os.environ['SHELL']
    assert env_fallback('SHELL2', 'SHELL2') == os.environ['SHELL']
    assert env_fallback('ANSIBLE_TEST_ENV', 'SHELL2') == os.environ['SHELL']

# Generated at 2022-06-22 21:54:31.491386
# Unit test for function sanitize_keys
def test_sanitize_keys():
    class _TestSanitizeKeys(unittest.TestCase):
        def test_sanitize_keys(self):
            obj = {'foo': 'bar', 'foo_no_log': 'baz'}
            new_value = sanitize_keys(obj, no_log_strings={'_no_log'})
            self.assertTrue('foo_no_log' in new_value)
            self.assertEqual(new_value['foo_no_log'], 'baz')
            self.assertFalse('foo' in new_value)
    _TestSanitizeKeys = make_doctest(_TestSanitizeKeys)  # noqa
    globs = globals()
    globs.update(dict(sanitize_keys=sanitize_keys))

# Generated at 2022-06-22 21:54:34.178684
# Unit test for function sanitize_keys
def test_sanitize_keys():
    """ test_sanitize_keys: do something """
    # dummy function to test the function above
    #assert test_sanitize_keys() == 0


# Generated at 2022-06-22 21:54:39.007930
# Unit test for function env_fallback
def test_env_fallback():
    env = os.environ.copy()
    os.environ['ANSIBLE_FOO'] = 'bar'
    try:
        assert env_fallback('ANSIBLE_FOO') == 'bar'
        assert env_fallback('FOO') == 'bar'
        with pytest.raises(AnsibleFallbackNotFound):
            env_fallback('ANSIBLE_FOO', 'FOO')
    finally:
        os.environ = env



# Generated at 2022-06-22 21:54:49.719298
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(foo=dict(type='str', default='bar'),
                         bar=dict(type='str', default='baz'),
                         foobar=dict(type='str', default='baz'),
                         baz=dict(type='str', default='bar'),
                         bazbar=dict(type='str', fallback=(env_fallback, 'BAZ_BAR')))
    parameters = {'foo': 'test'}

    no_log_values = set_fallbacks(argument_spec, parameters)

    assert parameters['foo'] == 'test'
    assert parameters['bar'] == 'baz'
    assert parameters['foobar'] == 'baz'
    assert parameters['baz'] == 'bar'
    assert parameters['bazbar'] == 'bazbar'
    assert 'bazbar' in no_log

# Generated at 2022-06-22 21:54:59.367093
# Unit test for function set_fallbacks
def test_set_fallbacks():
    result = set_fallbacks({'src': {'type': 'path', 'fallback': (env_fallback, ['SRC_PATH'])}}, {})
    assert result == set()
    os.environ['SRC_PATH'] = 'dummy_path'
    result = set_fallbacks({'src': {'type': 'path', 'fallback': (env_fallback, ['SRC_PATH'])}}, {})
    assert result == set()
    result = set_fallbacks({'src': {'type': 'path', 'fallback': (env_fallback, ['SRC_PATH'])}}, {})
    assert result == {'dummy_path'}



# Generated at 2022-06-22 21:55:06.180643
# Unit test for function remove_values
def test_remove_values():
    no_log_strings = ['test_priv', 'secret']
    test_output = dict(
        dict_key=dict(),
        list_key=list(),
        set_key=set(),
        string_key='secret',
        int_key=42
    )
    expected = dict(
        dict_key=dict(),
        list_key=list(),
        set_key=set(),
        string_key='',
        int_key=42
    )
    test_input = deepcopy(test_output)
    result = remove_values(test_input, no_log_strings)
    assert result == expected
    assert test_input == test_output

    test_input = deepcopy(test_output)
    test_input['dict_key']['dict_key'] = 'test_priv'
    test_input

# Generated at 2022-06-22 21:55:15.474383
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        name=dict(type='str'),
        age=dict(type='int', fallback=(env_fallback, 'AGE', 'DEFAULT_AGE')),
        sex=dict(type='str', fallback=(env_fallback, 'SEX', dict(fallback='other'))),
    )
    parameters = dict(
        name='Harry'
    )
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters == dict(
        name='Harry',
        age=None,
        sex='other',
    )
    assert no_log_values == set(['other'])



# Generated at 2022-06-22 21:55:27.138274
# Unit test for function set_fallbacks

# Generated at 2022-06-22 21:55:33.023691
# Unit test for function env_fallback
def test_env_fallback():
    os.environ["A_VAR_NAME"] = "A_VALUE"
    assert "A_VALUE" == env_fallback("B_VAR_NAME", "A_VAR_NAME")
    os.environ.pop("A_VAR_NAME", None)
    assert os.environ.get("A_VAR_NAME") is None


# Generated at 2022-06-22 21:55:37.977191
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('FOO') == os.environ['FOO']
    assert env_fallback('FOO', 'BAR') == os.environ['FOO']
    assert env_fallback('BAR') == os.environ['BAR']
    assert env_fallback('BAR', 'BAZ') == os.environ['BAR']
    assert_raises(AnsibleFallbackNotFound, env_fallback, 'FOO', 'BAR', 'BAZ')



# Generated at 2022-06-22 21:55:47.132288
# Unit test for function set_fallbacks

# Generated at 2022-06-22 21:55:55.737652
# Unit test for function env_fallback
def test_env_fallback():
    ''' env_fallback should return value from 1st environment variable which is defined '''
    os.environ['TEST_ENV'] = 'TEST_VALUE'
    assert env_fallback('TEST_ENV', 'TEST_ENV2') == 'TEST_VALUE'
    assert env_fallback('TEST_ENV2', 'TEST_ENV') == 'TEST_VALUE'
    assert env_fallback('TEST_ENV2') == 'TEST_VALUE'
    del os.environ['TEST_ENV']


# Generated at 2022-06-22 21:56:03.718228
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys(None, ['n']) == None
    assert sanitize_keys(['n', 'n'], ['n']) == ['n', 'n']
    assert sanitize_keys({'k': 'v'}, ['k']) == {'k': 'v'}
    assert sanitize_keys({'n': 'v'}, ['n']) == {'n': 'v'}
    assert sanitize_keys({'no_log_': 'v'}, ['no_log_']) == {'no_log_': 'v'}
    assert sanitize_keys({'_ansible_no_log': 'v'}, ['_ansible_']) == {'_ansible_no_log': 'v'}

# Generated at 2022-06-22 21:56:15.019290
# Unit test for function set_fallbacks
def test_set_fallbacks():
    spec = dict(
        one=dict(fallback=(env_fallback, 'ANSIBLE_ONE')),
        two=dict(fallback=(env_fallback, 'ANSIBLE_TWO', 'ANSIBLE_ALT_TWO')),
        three=dict(fallback=(env_fallback, ('ANSIBLE_THREE_A', 'ANSIBLE_THREE_B'))),
        four=dict(),
        five=dict(fallback=(env_fallback, 'ANSIBLE_FIVE')),
        six=dict(fallback=(env_fallback, 'ANSIBLE_SIX',
                           dict(value='six_default', no_log=True))),
    )

# Generated at 2022-06-22 21:56:20.800254
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['test_env'] = 'env_test'
    assert env_fallback('test_env') == 'env_test'
    try:
        env_fallback('test_env_another')
    except AnsibleFallbackNotFound:
        pass
    else:
        raise Exception('env_fallback should not return')



# Generated at 2022-06-22 21:56:31.197625
# Unit test for function sanitize_keys
def test_sanitize_keys():
    no_log_strings = set()

    assert_equal(sanitize_keys({}, no_log_strings), {})
    assert_equal(sanitize_keys({'a': 1}, no_log_strings), {'a': 1})
    assert_equal(sanitize_keys({'a': 1, 'b': 2}, no_log_strings), {'a': 1, 'b': 2})
    assert_equal(sanitize_keys({'a': 1, 'b': 2, 'NOT_LOGGED_1': 3}, no_log_strings), {'a': 1, 'b': 2, 'NOT_LOGGED': 3})

# Generated at 2022-06-22 21:56:40.799129
# Unit test for function sanitize_keys
def test_sanitize_keys():
    test_obj = {'a': 'A', 'private_value': 'redacted', 'c': {'d': 'redacted_again'}, 'e': [{'f': 5, 'g': 'redacted_again'}]}
    assert sanitize_keys(test_obj, ('redacted', 'redacted_again')) == {'a': 'A', 'private_value': '!!!', 'c': {'d': '!!!'},
                                         'e': [{'f': 5, 'g': '!!!'}]}
    test_obj = {'a': 'A', 'p_v_1': 'redacted', 'p_v_2': 'redacted_again', 'p_v_3': 'redacted'}

# Generated at 2022-06-22 21:56:46.523009
# Unit test for function env_fallback
def test_env_fallback():
    class args(object):
        pass
    assert env_fallback('x') == None
    os.environ['x'] = 'y'
    try:
        assert env_fallback('x') == 'y'
    finally:
        del os.environ['x']



# Generated at 2022-06-22 21:56:55.258916
# Unit test for function set_fallbacks
def test_set_fallbacks():
    from collections import namedtuple
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils._text import to_bytes

    TestModule = namedtuple('TestModule', ['params', 'module_name'])

    def _assert_result(spec, params, no_log_values, expected):
        am = TestModule(params, 'test_module')
        actual_no_log_values = set_fallbacks(spec, am.params)
        assert actual_no_log_values == no_log_values
        assert am.params == expected

    # Test value that is already present
    spec = dict(a=dict(type='str'))
    params = dict(a='b')

# Generated at 2022-06-22 21:57:01.639861
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_VAULT_PASSWORD_FILE'] = '/dev/null'
    assert env_fallback('ANSIBLE_VAULT_PASSWORD_FILE') == '/dev/null'
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('FOO_VAULT_PASSWORD_FILE')
    os.environ.pop('ANSIBLE_VAULT_PASSWORD_FILE')



# Generated at 2022-06-22 21:57:12.698661
# Unit test for function set_fallbacks
def test_set_fallbacks():
    """Test the set_fallbacks function"""

    argument_spec = {'a': {'type': 'str', 'fallback': (env_fallback, 'A_ENV_VAR')},
                     'b': {'type': 'str', 'fallback': (env_fallback, ['B_ENV_VAR', 'OTHER_B_ENV'])}}
    parameters = {'a': 'foo'}

    expected = 'bar'
    os.environ['B_ENV_VAR'] = expected
    no_log_values = set_fallbacks(argument_spec, parameters)

    assert len(no_log_values) == 1
    assert parameters['b'] == expected
    assert expected in no_log_values



# Generated at 2022-06-22 21:57:25.393671
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        baz=dict(type='str', fallback=(env_fallback, ['FOO_BAR'])),
        bar=dict(type='str', fallback=(env_fallback, ['BAR_BAZ'])),
    )
    parameters = dict(
        bar='foo'
    )

    assert set_fallbacks(argument_spec, parameters) == set()
    assert set_fallbacks(argument_spec, {}) == set()
    assert set_fallbacks(argument_spec, dict(baz='some_value')) == set()

    # This will mutate the environment variable
    os.environ['FOO_BAR'] = 'foo'
    os.environ['BAR_BAZ'] = 'foo'


# Generated at 2022-06-22 21:57:30.128574
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['FOO'] = 'bar'
    assert env_fallback('FOO') == 'bar'
    assert env_fallback('bar') == 'bar'
    assert env_fallback('EISDIR') == 'EISDIR'
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('BAR')



# Generated at 2022-06-22 21:57:39.096438
# Unit test for function remove_values
def test_remove_values():

    assert {'value': 'success', 'foo_private': 'success'} == remove_values({'value': 'success', 'foo_private': 'success'}, ['!private'])
    assert {'value': 'success', 'foo': 'success'} == remove_values({'value': 'success', 'foo': 'success'}, ['!private'])
    assert {'value': 'success', 'foo_private': 'success'} == remove_values({'value': 'success', 'foo_private': 'success'}, [])
    assert {'value': 'success', 'foo_private__private': 'success'} == remove_values({'value': 'success', 'foo_private__private': 'success'}, ['!private'])

# Generated at 2022-06-22 21:57:49.243915
# Unit test for function remove_values
def test_remove_values():
    """Test the remove_values function"""

    assert remove_values('foobar', ['foo']) == 'bar'
    assert remove_values('foobar', ['foo', 'bar']) == ''
    assert remove_values('foobar', ['foo', 'bar', 'foobar']) == ''
    assert remove_values(['foobar'], ['foo']) == ['bar']
    assert remove_values(['foobar'], ['foo', 'bar']) == ['']
    assert remove_values(['foobar'], ['foo', 'bar', 'foobar']) == ['']
    assert remove_values(('foobar',), ['foo']) == ('bar',)
    assert remove_values(('foobar',), ['foo', 'bar']) == ('',)

# Generated at 2022-06-22 21:58:00.092157
# Unit test for function remove_values
def test_remove_values():
    """
    Test the correct operation of the function remove_values
    """
    # Test a single value
    result = remove_values(u'Cant remove_values this', [u'remove'])
    assert result == u'Cant remove_values this', 'remove_values failed on a single value'

    # Test a list value
    result = remove_values([u'Cant remove_values', u'this'], [u'remove'])
    assert result == [u'Cant remove_values', u'this'], 'remove_values failed on a list'

    # Test a dictionary value
    result = remove_values({u'Cant remove_values': u'this'}, [u'remove'])
    assert result == {u'Cant remove_values': u'this'}, 'remove_values failed on a dictionary'

    # Test

# Generated at 2022-06-22 21:58:11.709414
# Unit test for function remove_values
def test_remove_values():
    from ansible_collections.ansible.community.tests.unit.compat.mock import MagicMock

    # No logging enabled, does not remove anything
    value = {'foo': 'bar', 'bar': 'baz', 'baz': 'foo', 'fiz': {'biz': [42, 'foo'], 'buz': 'baz'}}
    assert remove_values(value, []) == {'foo': 'bar', 'bar': 'baz', 'baz': 'foo', 'fiz': {'biz': [42, 'foo'], 'buz': 'baz'}}

    # 'bar' and 'baz' are filtered out everywhere

# Generated at 2022-06-22 21:58:22.713117
# Unit test for function remove_values
def test_remove_values():
    assert remove_values("test", ["test"]) == ""
    data_to_test = {'test': 'test'}
    assert remove_values(data_to_test, ["test"]) == {'test': ''}

    data_to_test = {'test': [{'test': 'test2'}]}
    assert remove_values(data_to_test, ["test"]) == {'test': [{'test': ''}]}

    data_to_test = {'test': ['test2']}
    assert remove_values(data_to_test, ["test"]) == {'test': ['']}

    data_to_test = {'test': ('test2', )}
    assert remove_values(data_to_test, ["test"]) == {'test': ('', )}

    # The following tests

# Generated at 2022-06-22 21:58:34.567139
# Unit test for function sanitize_keys
def test_sanitize_keys():

    data = {
        'a': 1,
        'b': {
            'c': 2,
            'd': [3],
        },
        'c': [
            {
                'd': {
                    'password': 'abc123'
                },
            },
        ],
    }
    safe_strings = ['password', 'passwd', 'secret', 'authorization', 'api_key', 'apikey', 'access_token']
    result = sanitize_keys(data, safe_strings, ignore_keys=['a'])
    assert result == {'a': 1, 'b': {'c': 2, 'd': [{'p****wd': 'abc123'}]}, 'c': [{'d': {'p****wd': 'abc123'}}]}



# Generated at 2022-06-22 21:58:41.004172
# Unit test for function remove_values
def test_remove_values():
    assert remove_values(u'abc', [u'x']) == u'abc'
    assert remove_values(u'a\u2022c', [u'x']) == u'a\u2022c'
    assert remove_values(u'ab\u2022c', [u'b']) == u'a\u2022c'
    assert remove_values(u'abc', [u'bc']) == u'a'
    assert remove_values(u'abc', [u'bc', u'a']) == u''
    assert remove_values(u'ab\u2013c', [u'b']) == u'a\u2013c'

# Generated at 2022-06-22 21:58:45.483886
# Unit test for function env_fallback
def test_env_fallback():
    os.environ["ANSIBLE_TEST_VARIABLE"] = "hello"
    class FakeModule(object):
        def __init__(self):
            self.params = {"foo": "bar"}
        def fail_json(self, **kwargs):
            raise Exception(kwargs['msg'])

    assert env_fallback("ANSIBLE_TEST_VARIABLE") == "hello"
    assert env_fallback("ANSIBLE_TEST_VARIABLE", "ANSIBLE_TEST_VARIABLE_2") == "hello"
    assert_raises(AnsibleFallbackNotFound, env_fallback, "ANSIBLE_TEST_VARIABLE_3")


# Generated at 2022-06-22 21:58:56.643126
# Unit test for function remove_values
def test_remove_values():
    data_dict = {
        'foo': ['bar', 'baz', 'boo'],
        'boo': ['bar', 'bad'],
        'dict': {
            'foo': ['bar', 'baz'],
            'boo': ['bar', 'bad'],
        },
        'good': 'good',
    }
    expected_dict = {
        'foo': ['bar', '***'],
        '***': ['bar', '***'],
        'dict': {
            'foo': ['bar', '***'],
            '***': ['bar', '***'],
        },
        'good': 'good',
    }
    assert expected_dict == remove_values(data_dict, ['baz', 'boo'])


# Generated at 2022-06-22 21:59:05.461250
# Unit test for function remove_values
def test_remove_values():
    example = [
        'foo',
        {'bar': ['baz', 'test']},
        'test',
    ]

    pass_data = copy.deepcopy(example)
    assert remove_values(pass_data, []) == example

    fail_data = copy.deepcopy(example)
    assert remove_values(fail_data, ['test']) == [
        'foo',
        {'bar': ['baz', 'UNSAFE_VALUE']},
        'UNSAFE_VALUE',
    ]

    fail_data = copy.deepcopy(example)
    assert remove_values(fail_data, ['test', 'foo']) == [
        'UNSAFE_VALUE',
        {'bar': ['baz', 'UNSAFE_VALUE']},
        'UNSAFE_VALUE',
    ]


# Generated at 2022-06-22 21:59:16.266310
# Unit test for function set_fallbacks
def test_set_fallbacks():

    # If a required argument is not provided, and there is also a fallback, the fallback should get used
    result = {'a': 'b'}
    assert set_fallbacks({'a': {'required': True, 'fallback': ('a',)}}, result) == set()
    assert result == {'a': 'a'}

    # If a required argument is provided, and there is also a fallback, the argument should get used, and no_log value be returned
    result = {'a': 'b'}
    assert set_fallbacks({'a': {'required': True, 'fallback': ('a',), 'no_log': True}}, result) == set()
    assert result == {'a': 'b'}



# Generated at 2022-06-22 21:59:27.062218
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {"a":{"fallback":(env_fallback, ["A_ENV_VAR_1", "A_ENV_VAR_2"])}, 'b': {"fallback":(env_fallback, "B_ENV_VAR")}}
    parameters = {"c":"C"}
    no_log_values = set()
    os.environ["A_ENV_VAR_1"] = "a"
    os.environ["B_ENV_VAR"] = "b"
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters["a"] == "a"
    assert parameters["b"] == "b"
    assert parameters["c"] == "C"
    assert len(no_log_values) == 2
    assert "a" in no_log_

# Generated at 2022-06-22 21:59:35.349725
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'success'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'success'
    del os.environ['ANSIBLE_TEST_ENV_FALLBACK']
    # Test single fallback without env
    assert_raises(AnsibleFallbackNotFound, env_fallback, 'FOO_BAR')
    # Test multiple fallbacks without env
    assert_raises(AnsibleFallbackNotFound, env_fallback, 'FOO_BAR', 'ANSIBLE_TEST_ENV_FALLBACK')



# Generated at 2022-06-22 21:59:39.884321
# Unit test for function remove_values
def test_remove_values():
    mock_return = {
        "changed": True,
        "failed": False,
        "mock_key": "mock_value",
        "ansible_facts": {
            "discovered_interpreter_python": "/usr/bin/python"
        },
        "_ansible_parsed": True,
        "encrypted_password": "VALUE_SPECIFIED_IN_NO_LOG_PARAMETER"
    }
    assert test_remove_values_result() == mock_return


# Generated at 2022-06-22 21:59:50.503411
# Unit test for function env_fallback
def test_env_fallback():
    """Ensure that env_fallback function works as expected"""
    assert env_fallback('ENV_FALLBACK_TEST_VAR') == os.environ.get('ENV_FALLBACK_TEST_VAR', None)
    assert env_fallback('UNKNOWN_VAR', 'UNKNOWN_VAR2') == os.environ.get('UNKNOWN_VAR', None)
    assert env_fallback('UNKNOWN_ENV') is None
    assert env_fallback('UNKNOWN_ENV2') is None
    assert env_fallback('UNKNOWN_ENV3') == os.environ.get('UNKNOWN_ENV3')


# Generated at 2022-06-22 22:00:02.566974
# Unit test for function sanitize_keys

# Generated at 2022-06-22 22:00:07.273963
# Unit test for function set_fallbacks
def test_set_fallbacks():
    ref = {'foo': 'bar'}
    argument_spec = {'foo': {'type': 'str', 'fallback': (env_fallback, 'FOO_ENV')}}
    parameters = {}
    set_fallbacks(argument_spec, parameters)
    assert parameters == ref



# Generated at 2022-06-22 22:00:12.962617
# Unit test for function set_fallbacks
def test_set_fallbacks():
    spec = dict(
        option_a=dict(fallback=(env_fallback, 'OPTION_A'))
    )
    parameters = dict(
        option_b='b'
    )

    actual = set_fallbacks(spec, parameters)

    assert 'a' in os.environ
    assert parameters == dict(
        option_a='a',
        option_b='b'
    )
    assert actual == set()



# Generated at 2022-06-22 22:00:24.518755
# Unit test for function sanitize_keys
def test_sanitize_keys():
    import threading
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    def make_TestModule(module_name, module_args=None):
        if module_args is None:
            module_args = {}

        class TestModule(basic.AnsibleModule):
            def __init__(self, *args, **kwargs):
                super(TestModule, self).__init__(*args, **kwargs)
                self._result = {}

            def exit_json(self, **kwargs):
                self._result.update(kwargs)
                raise SystemExit()


# Generated at 2022-06-22 22:00:32.194430
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_NET_USERNAME'] = 'username'
    if env_fallback('ANSIBLE_NET_USERNAME') != 'username':
        raise AssertionError("Expected 'username' but got '{0}'".format(env_fallback('ANSIBLE_NET_USERNAME')))
    try:
        env_fallback('NOT_SET')
    except AnsibleFallbackNotFound:
        pass
    else:
        raise AssertionError("Expected AnsibleFallbackNotFound exception")


# Generated at 2022-06-22 22:00:44.485572
# Unit test for function sanitize_keys
def test_sanitize_keys():
    """
        Test sanitize_keys function
        For non-container objects, sanitize_keys will return unmodified object
        Container object should have all key names with no_log values removed
    """
    no_log_values = ['a', 'b']
    no_log_values_set = set(no_log_values)

    test_object = {
        'abc': 'abc',
        'a': 'foo',
        'x': 'x',
        'y': {'y': 'y'},
        'z': ('z', 'z'),
        '_ansible_foo': 'bar',
        'bcd': {
            'bcd': 'bcd',
            'a': 'foo2'
        }
    }

# Generated at 2022-06-22 22:00:47.043301
# Unit test for function remove_values
def test_remove_values():
    """Unit test for function remove_values"""
    return_value = remove_values("test", ["t"])

    # Verify the value of return_value
    assert return_value == "es"


# Generated at 2022-06-22 22:00:59.152197
# Unit test for function sanitize_keys
def test_sanitize_keys():
    # NoLog objects
    class NoLog(object):
        def __init__(self):
            self.no_log_value = 'this_should_not_be_logged'

    # Dictionary
    dict_obj = {
        '_ansible_no_log': True,
        'test': 'this should be logged',
        'foo': NoLog(),
        'bar': 'this should not be logged',
        '_ansible_no_log_bar': True,
        'this_should_not_be_logged': 'this should not be logged',
        '_ansible_this_should_be_logged': True,
    }

    dict_obj['foo'].no_log_value = 'this should not be logged'

    ignore_keys_dict = set(['_ansible_foo'])
    no

# Generated at 2022-06-22 22:01:08.392448
# Unit test for function sanitize_keys
def test_sanitize_keys():
    class TestClass:
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

        def __eq__(self, other):
            return self.args == other.args and self.kwargs == other.kwargs

    obj = {u'secret': u'sha256:c1d20f522a4d95cac8d25aa61c7eef30b5227fd7b95e06ebcc5a5c5b5e1d5d18', u'not_secret': u'abc123'}
    expected = {u'secret': u'filtered', u'not_secret': u'abc123'}

# Generated at 2022-06-22 22:01:21.010097
# Unit test for function sanitize_keys
def test_sanitize_keys():
    import ansible
    container = {
        'foo': 'bar',
        'password': 'secret',
        'ansible_facts': {
            'ansible_module_name': 'foo',
            'ansible_distribution': 'redhat'
        },
        'some_dict': {
            'some_key': 'value',
            'a': {
                'b': {
                    'c': 'd'
                }
            }
        },
        'some_list': [
            {
                'a': 'b',
                'b': [
                    {
                        'c': 'd',
                        'd': {
                            'e': 'f'
                        }
                    },
                    'g'
                ]
            },
            'h'
        ]
    }
