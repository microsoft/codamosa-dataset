

# Generated at 2022-06-22 21:51:19.613089
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # unfilled required argument
    spec = {'parameter_name': {'type': 'str', 'required': True}}
    parameters = {}
    no_log_values = set_fallbacks(spec, parameters)
    assert parameters['parameter_name'] == "this is the default value"
    assert no_log_values == set()



# Generated at 2022-06-22 21:51:24.929655
# Unit test for function remove_values
def test_remove_values():
    input_value={"a":"b","c":{"d":"e","f":"g"}}
    expected_value={"a":"_VALUE_SPECIFIED_IN_NO_LOG_PARAMETER","c":{"d":"_VALUE_SPECIFIED_IN_NO_LOG_PARAMETER","f":"_VALUE_SPECIFIED_IN_NO_LOG_PARAMETER"}}
    assert remove_values(input_value, []) == input_value
    assert remove_values(input_value, no_log_strings=["b","e","g"]) == expected_value


# Generated at 2022-06-22 21:51:32.114569
# Unit test for function set_fallbacks

# Generated at 2022-06-22 21:51:41.250131
# Unit test for function sanitize_keys
def test_sanitize_keys():
    # list has no keys
    assert sanitize_keys([1, 2, 3], []) == [1, 2, 3]

    # set has no keys
    assert sanitize_keys({'a', 'b', 'c'}, []) == {'a', 'b', 'c'}

    # dict case
    assert sanitize_keys({'k1': 'v1', 'k2': 'v2', 'k3': 'v3'}, []) == {'k1': 'v1', 'k2': 'v2', 'k3': 'v3'}

    # dict case with no_log_values

# Generated at 2022-06-22 21:51:50.340424
# Unit test for function sanitize_keys
def test_sanitize_keys():
    class DummyClass(object):
        def __init__(self, value):
            self.value = value
        def __repr__(self):
            return 'DummyClass(%r)' % (self.value,)

    no_log_strings = [b'DUMMYSTRING']
    empty_ignore_keys = frozenset()
    non_empty_ignore_keys = frozenset([b'DUMMYKEY'])

    # Make sure to exercise both "if elem == no_log_strings" and "if elem in no_log_strings"
    data = {
        'DUMMYSTRINGKEY': [],
        b'DUMMYSTRING': [],
        u'DUMMYSTRING': [],
        'NORMALKEY': [],
        b'NORMALKEY': [],
    }


# Generated at 2022-06-22 21:51:56.318916
# Unit test for function sanitize_keys
def test_sanitize_keys():
    # pylint: disable=too-few-public-methods
    class TestModule(object):
        def __init__(self, data):
            self.params = data
        def fail_json(*_, **__):
            pass
    class TestParams(object):
        def __init__(self, module):
            self.module = module
        def as_dict(self, *_, **__):
            return self.module.params
    module = TestModule({})
    params = TestParams(module)

# Generated at 2022-06-22 21:52:02.727984
# Unit test for function remove_values
def test_remove_values():
    private_strings = ['thisisanonlogstring', 'thisisalsoanonlogstring']
    no_log_strings = set(private_strings)
    # strings do not match, should not get removed
    assert 'password' == remove_values('password', no_log_strings)
    # strings match, should get removed
    assert private_strings[0] != remove_values(private_strings[0], no_log_strings)
    # dicts have keys that match, should not get removed
    assert 'password' == remove_values({'password': 'hunter2'}, no_log_strings)
    # dicts have keys that match, should get removed
    assert private_strings[0] != remove_values({private_strings[0]: 'hunter2'}, no_log_strings)
    # tuples have strings that match, should get removed

# Generated at 2022-06-22 21:52:09.315071
# Unit test for function env_fallback
def test_env_fallback():
    # Save original environ for later restore
    old_environ = os.environ.copy()
    os.environ["HOME"] = "/home/foo"
    os.environ["FOO"] = "foo"

    result = env_fallback("FOO", "SSH_CLIENT")
    assert result == "foo"
    try:
        result = env_fallback("NOT_SET")
        assert False
    except AnsibleFallbackNotFound:
        pass

    # Restore os.environ
    os.environ = old_environ

# *** Type spec checkers ***
# These functions are responsible for parsing the type spec and returning a
# checker function that can be used to validate values. The type spec is a
# string that can use option shortcuts and nested types.

# Used to avoid having to write if-elses for

# Generated at 2022-06-22 21:52:15.695504
# Unit test for function remove_values
def test_remove_values():

    # Test the simplest case
    simple_value = 'this is a simple string'
    assert remove_values(simple_value, set()) == simple_value
    assert remove_values(simple_value, set(['simple'])) == 'this is a string'
    assert remove_values(simple_value, set(['string'])) == 'this is a simple '
    assert remove_values(simple_value, set(['simple', 'string'])) == 'this is a '
    assert remove_values(simple_value, set(['nope'])) == simple_value

    # Test a dictionary
    dictionary = dict(a_simple_key='this is a simple string', a_nested_dict=dict(a_simple_key='this is a simple string'))
    assert remove_values(dictionary, set()) == dictionary

# Generated at 2022-06-22 21:52:18.555578
# Unit test for function set_fallbacks
def test_set_fallbacks():
    params = {'param1': None}
    spec = {
        'param1': {
            'required': False,
            'fallback': (env_fallback, ('ENV_VAR_1', 'ENV_VAR_2')),
            'type': 'str'
        }
    }
    # Make sure fallback is set for param1
    assert set_fallbacks(spec, params) == set()
    assert params.get('param1') is not None



# Generated at 2022-06-22 21:52:28.487803
# Unit test for function sanitize_keys
def test_sanitize_keys():
    x = {'no_log_key1': 'value1', 'log_key2': 'value2', 'no_log_key3': {'log_key3_1': 'no_log_value3_1'}}
    no_log_values = {'no_log_value3_1'}
    x_sanitized = sanitize_keys(x, no_log_values, ignore_keys=['log_key2'])
    assert 'no_log_key1' not in x_sanitized.keys()
    assert 'log_key2' in x_sanitized.keys()
    assert 'no_log_key3' not in x_sanitized.keys()
    assert 'log_key3_1' in x_sanitized['log_key2'].keys()

# Generated at 2022-06-22 21:52:40.158858
# Unit test for function set_fallbacks
def test_set_fallbacks():
    spec = dict(
        a = dict(type='int', fallback=(env_fallback, 'AAA')),
        b = dict(type='int', fallback=(env_fallback, 'BBB'))
    )
    args = dict(b=10)
    assert set_fallbacks(spec, args) == set()
    assert args == dict(a=None, b=10)

    os.environ['AAA'] = '1'
    assert set_fallbacks(spec, args) == set()
    assert args == dict(a=1, b=10)

    os.environ['BBB'] = '2'
    assert set_fallbacks(spec, args) == set()
    assert args == dict(a=1, b=2)



# Generated at 2022-06-22 21:52:43.412831
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ENV_FALLBACK'] = 'env_fallback_value'
    assert env_fallback('ENV_FALLBACK') == 'env_fallback_value'
    assert env_fallback('env_fallback') == 'env_fallback_value'



# Generated at 2022-06-22 21:52:47.559826
# Unit test for function set_fallbacks

# Generated at 2022-06-22 21:52:54.695418
# Unit test for function set_fallbacks

# Generated at 2022-06-22 21:52:57.108480
# Unit test for function env_fallback
def test_env_fallback():
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('ANSIBLE_NON_EXISTENT_ENV_VARIABLE')



# Generated at 2022-06-22 21:53:07.252630
# Unit test for function set_fallbacks
def test_set_fallbacks():
    from ansible.module_utils._text import to_bytes
    argument_spec = dict(enabled=dict(type='bool', default=True),
                         port=dict(type='int', fallback=(env_fallback, 'PORT')),
                         database=dict(type='dict', fallback=(dict,), options=dict(
                             db_type=dict(type='str', choices=['mongo', 'redis'], fallback=(env_fallback, 'DB_TYPE')))))
    spec = dict(enabled=True, port=None, database={})
    assert b"PORT" not in os.environ
    set_fallbacks(argument_spec, spec)
    assert spec['enabled'] and spec['port'] is None and spec['database'] == {}
    os.environ["PORT"] = "1234"
    set_fallbacks

# Generated at 2022-06-22 21:53:14.953802
# Unit test for function sanitize_keys
def test_sanitize_keys():
    from .basic import AnsibleModule
    test_module = AnsibleModule(argument_spec={'no_log': dict(type='bool'), 'test1': dict(type='dict', no_log=True),
                                               'test2': dict(type='list'), 'test3': dict(type='int')},
                                supports_check_mode=True, no_log=False)
    test_module._supports_check_mode = True
    test_module._debug = True
    test_module._verbosity = 0
    test_module._aliases = dict()
    test_module._legacy_play_context = False

    no_log_values = set()
    no_log_values.add('test1')
    no_log_values.add('test2')

# Generated at 2022-06-22 21:53:24.941206
# Unit test for function remove_values
def test_remove_values():
    with pytest.raises(TypeError):
        remove_values(1, '')
    assert remove_values('a', ('a', '')) == ''
    assert remove_values(1, ('a', '')) == 1
    assert remove_values({'a': 'a'}, ('a', 'b')) == {'a': ''}
    assert remove_values({'a': 'b'}, ('b',)) == {'a': ''}
    assert remove_values({'a': 'a'}, ('a',)) == {'a': ''}
    assert remove_values(['a', 'a'], ('a','')) == ['', '']
    assert remove_values(('a', 'a'), ('a', 'b')) == ('', '')

# Generated at 2022-06-22 21:53:36.295087
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'mandatory_var': {}}
    parameters1 = {'mandatory_var': 'value'}
    assert set_fallbacks(argument_spec, parameters1) == set()
    parameters2 = {}
    assert set_fallbacks(argument_spec, parameters2) == set()

# Generated at 2022-06-22 21:53:42.923487
# Unit test for function env_fallback
def test_env_fallback():
    # Test fallback
    os.environ['FOO'] = 'BAR'
    assert env_fallback('FOO') == 'BAR'
    # Test fallback not found
    try:
        env_fallback('TEST')
    except AnsibleFallbackNotFound:
        assert True
    else:
        assert False



# Generated at 2022-06-22 21:53:53.958113
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys({}, set()) == {}
    assert sanitize_keys([], set()) == []

    obj = {'key1': 'val1', 'key2': 'val2'}
    assert sanitize_keys(obj, set()) == {'key1': 'val1', 'key2': 'val2'}

    obj = {'key1': 'val1', 'key2': 'val2'}
    assert sanitize_keys(obj, {'1'}) == {'key': 'val1', 'key2': 'val2'}

    obj = {'key1': 'val1', 'key2': 'val2'}
    assert sanitize_keys(obj, {'1', '2'}) == {'key': 'val1', 'key': 'val2'}


# Generated at 2022-06-22 21:54:01.132130
# Unit test for function env_fallback
def test_env_fallback():
    """Unit test for env_fallback"""

    os.environ['ANSIBLE_TEST_ENV_VAR'] = 'ANSIBLE_TEST_ENV_VAR_VALUE'
    assert env_fallback('ANSIBLE_TEST_ENV_VAR') == 'ANSIBLE_TEST_ENV_VAR_VALUE'
    os.environ.pop('ANSIBLE_TEST_ENV_VAR')
    try:
        env_fallback('ANSIBLE_TEST_ENV_VAR')
        assert False
    except AnsibleFallbackNotFound:
        assert True
test_env_fallback()



# Generated at 2022-06-22 21:54:11.002951
# Unit test for function remove_values

# Generated at 2022-06-22 21:54:17.316698
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys({'a': 1, 'b': {'c': 2, 'd': 3}, 'e': 4, 'f': [5, 6, 7]}, ['c']) == {'a': 1, 'b': {'_ansible_no_log_c': 2, 'd': 3}, 'e': 4, 'f': [5, 6, 7]}
    assert sanitize_keys({'a': 'b', 'c': 'd'}, ['d']) == {'a': 'b', '_ansible_no_log_c': 'd'}

# Generated at 2022-06-22 21:54:28.393036
# Unit test for function remove_values
def test_remove_values():
    from ansible.utils.unsafe_proxy import wrap_var


# Generated at 2022-06-22 21:54:37.045892
# Unit test for function remove_values
def test_remove_values():
    assert remove_values('foo', ['foo']) == ''
    assert remove_values('foo', ['f']) == ''
    assert remove_values('foo', ['o']) == ''
    assert remove_values('foo', ['oo']) == ''
    assert remove_values('foo', ['f', 'o']) == ''

    assert remove_values('foox', ['foo']) == 'x'
    assert remove_values('foox', ['f']) == 'oox'
    assert remove_values('foox', ['o']) == 'foox'
    assert remove_values('foox', ['oo']) == 'fox'
    assert remove_values('foox', ['f', 'o']) == 'x'



# Generated at 2022-06-22 21:54:48.465665
# Unit test for function set_fallbacks
def test_set_fallbacks():
    """Unit test for function set_fallbacks"""
    options = dict(
        foo=dict(fallback=(env_fallback, ['FOO_VAR_1', 'FOO_VAR_2'])),
        bar=dict(fallback=(env_fallback, ['BAR_VAR']))
    )
    parameters = {}
    os.environ['FOO_VAR_1'] = 'FOO_VAR_1'
    os.environ['FOO_VAR_2'] = 'FOO_VAR_2'
    no_log = set_fallbacks(options, parameters)
    assert len(no_log) == 2
    assert 'FOO_VAR_1' in no_log
    assert 'FOO_VAR_2' in no_log

# Generated at 2022-06-22 21:54:54.445392
# Unit test for function env_fallback
def test_env_fallback():
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('var_not_exist', 'var_not_exist2')
    # When os.environ is None, this function will raise an exception
    original_environ = os.environ
    os.environ = None
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('var_not_exist')
    os.environ = original_environ



# Generated at 2022-06-22 21:55:04.304938
# Unit test for function sanitize_keys
def test_sanitize_keys():
    _data = {
        'abc': {'abc': 1, 'xyz': 2, 'password': 3},
        'xyz': [{'abc': 1, 'xyz': 2, 'password': 3}]
    }


# Generated at 2022-06-22 21:55:07.961043
# Unit test for function remove_values
def test_remove_values():
    """Return True if function remove_values works properly

    Returns:
        True if function remove_values works properly, False otherwise
    """
    return remove_values("string", ["str"]) == ""



# Generated at 2022-06-22 21:55:12.316658
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['BALOGNA'] = 'delicious'
    assert env_fallback('BALOGNA', 'SPAM') == 'delicious'
    del os.environ['BALOGNA']
    with raises(AnsibleFallbackNotFound):
        env_fallback('BALOGNA', 'SPAM')



# Generated at 2022-06-22 21:55:23.700440
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys({'a': {'b': 3, 'c': 4}}, ['4']) == {'a': {'b': 3, 'c': '***'}}
    assert sanitize_keys({'a': {'b': 3, 'c': 4}}, ['b']) == {'a': {'***': 3, 'c': 4}}
    assert sanitize_keys({'a': {'b': '3', 'c': '4'}}, ['3', '4']) == {'a': {'b': '***', 'c': '***'}}
    # Passing an empty string will not remove any keys, as an empty string is not in no_log_strings

# Generated at 2022-06-22 21:55:34.447433
# Unit test for function set_fallbacks
def test_set_fallbacks():
    pd = dict(
        param1=100,
        param2=0,
    )
    asd = dict(
        param1=dict(required=True),
        param2=dict(required=True),
        param3=dict(fallback=(env_fallback, 'TEST_PARAM3')),
        param4=dict(fallback=(env_fallback, 'TEST_PARAM4', dict(default='123'))),
        param5=dict(fallback=(env_fallback, 'TEST_PARAM5', dict(default='123'))),
    )
    nlv = set_fallbacks(asd, pd)
    assert 'param1' in pd
    assert 'param2' in pd
    assert 'param3' not in pd
    assert 'param4' not in pd

# Generated at 2022-06-22 21:55:44.681592
# Unit test for function sanitize_keys
def test_sanitize_keys():
    # Empty object
    obj = {}
    assert(sanitize_keys(obj, ['no_log_string']) == obj)

    # Non-container
    obj = 'foo'
    assert(sanitize_keys(obj, ['no_log_string']) == obj)

    # Basic key sanitization
    obj = {'no_log_string': 'bar'}
    new_obj = sanitize_keys(obj, ['no_log_string'])
    assert(obj != new_obj)
    assert(len(new_obj) == 1)
    assert('' in new_obj)
    assert(new_obj[''] == 'bar')

    # Key sanitization with non-logged escape char
    obj = {'no_log_string': 'bar'}
    new_obj = sanit

# Generated at 2022-06-22 21:55:56.393702
# Unit test for function sanitize_keys
def test_sanitize_keys():
    data = [{b'username': b'ssuthan', b'password': b'mysecretpass'},
            {b'username': b'baduser', b'password': b'badpass'}]

    assert sanitize_keys(data, [b'mysecretpass']) == [{b'username': b'ssuthan', b'password': b'REDACTED'},
                                                      {b'username': b'baduser', b'password': b'badpass'}]

    assert sanitize_keys(data, [b'mysecretpass', b'badpass']) == [{b'username': b'ssuthan', b'password': b'REDACTED'},
                                                                  {b'username': b'baduser', b'password': b'REDACTED'}]


# Generated at 2022-06-22 21:56:00.137057
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_FALLBACK_ENVIRONMENT'] = 'true'
    assert env_fallback('ANSIBLE_TEST_FALLBACK_ENVIRONMENT') == 'true'
    assert env_fallback('THIS_DOES_NOT_EXIST') == ''



# Generated at 2022-06-22 21:56:11.945943
# Unit test for function set_fallbacks
def test_set_fallbacks():
    def fail_first(*_args, **_kwargs):
        raise AnsibleFallbackNotFound

    argument_spec = {
        'name': {
            'type': 'str',
            'default': 'Fallback not required',
            'fallback': (fail_first, fail_first),
        },
    }

    # Test default fallback
    parameters = {}
    no_log_values = set()
    no_log_values.update(set_fallbacks(argument_spec, parameters))
    assert len(no_log_values) == 0
    assert parameters['name'] == 'Fallback not required'

    # Test fallback list

# Generated at 2022-06-22 21:56:20.687453
# Unit test for function remove_values
def test_remove_values():

    # Given:
    no_log_strings = ['secret']
    data = {
        'a': {'b': 'secret'},
        'c': ['secret'],
        'd': set(['secret']),
        'e': [['secret']]
    }

    # When:
    result = remove_values(data, no_log_strings)

    # Then:
    assert result == {
        'a': 'REDACTED',
        'c': 'REDACTED',
        'd': 'REDACTED',
        'e': 'REDACTED'
    }



# Generated at 2022-06-22 21:56:31.120070
# Unit test for function sanitize_keys
def test_sanitize_keys():
    class test_item(object):
        try:
            ignored_member1
        except:
            ignored_member1 = None
        try:
            _ansible_member1
        except:
            _ansible_member1 = None
    obj = {}
    obj['test_key'] = 'test_value'
    obj['test_no_log'] = 'test_no_log'
    obj['test_ignore_key'] = 'test_ignore_key'
    obj['test_ansible_key'] = 'test_ansible_key'
    obj['test_member'] = test_item()

# Generated at 2022-06-22 21:56:41.469243
# Unit test for function remove_values
def test_remove_values():
    # TODO: Move this function to somewhere more appropriate

    private_data = dict(
        ansible_ssh_host='1.2.3.4',
        ssh_pass='12345',
        become_pass='67890',
        ansible_ssh_pass='12345',
        ansible_become_pass='67890',
        password='12345',
        passwd='12345',
        secret='67890',
        vault_password='78910',
        password_url='http://mypassword.com',
    )

    # Create a 'private' structure to match private_data, with an additional token.
    # The token is used to identify which elements should remain, so we know to
    # remove the elements that matched the token.
    # The token will always be a dictionary with a single key-value pair.
    # The name

# Generated at 2022-06-22 21:56:53.078532
# Unit test for function sanitize_keys
def test_sanitize_keys():
    """Unit tests for the sanitize_keys function."""

    no_log_strings = frozenset([b'foo'])

    # Test sanitization of dict keys
    assert sanitize_keys({b'_ansible_foo': b'bar'}, no_log_strings) == {u'_ansible_foo': b'bar'}
    assert sanitize_keys({b'foo_bar': b'bar'}, no_log_strings) == {u'f_bar': b'bar'}
    assert sanitize_keys({b'bar_foo': b'bar'}, no_log_strings) == {b'bar_foo': b'bar'}

# Generated at 2022-06-22 21:57:04.041116
# Unit test for function set_fallbacks
def test_set_fallbacks():
    import types
    test_spec = {'name': {'type': 'str', 'fallback': (env_fallback, [], {'name': 'TEST_NAME', 'default': None})}}
    test_parameters = {}
    test_no_log_values = set()
    os.environ['TEST_NAME'] = 'foo'
    set_fallbacks(test_spec, test_parameters)
    assert test_parameters == {'name': os.environ['TEST_NAME']}
    del os.environ['TEST_NAME']
    test_spec = {'password': {'type': 'str', 'no_log': True, 'fallback': (env_fallback, [], {'name': 'TEST_PASSWORD', 'default': None})}}
    test_parameters = {}


# Generated at 2022-06-22 21:57:14.518216
# Unit test for function sanitize_keys
def test_sanitize_keys():
    import json
    from collections import namedtuple
    from ansible.module_utils._text import to_text

    json_data = to_text('''
        {
            "my_ansible_var": "foo",
            "my_ansible_password": "bar"
        }
    ''')
    data = json.loads(json_data, object_pairs_hook=namedtuple)

    keys = {'my_ansible_password'}
    # make sure we're setting no_log on the right values
    assert data.my_ansible_password == 'bar'
    assert data.my_ansible_var == 'foo'

    no_log_strings = {'bar'}
    sanitized_data = sanitize_keys(data, no_log_strings, keys)

    # check that the

# Generated at 2022-06-22 21:57:20.249368
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['TEST_1'] = 'unittest_value'
    assert env_fallback('TEST_1') == 'unittest_value'
    assert env_fallback('TEST_2') == 'unittest_value', "env_fallback is not returning None if no key found"
    del os.environ['TEST_1']



# Generated at 2022-06-22 21:57:30.558284
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'test': {
            'type': str,
            'fallback': (env_fallback, 'TEST_VAR')
        }
    }
    parameters = dict()
    no_log_values = set()

    os.environ['TEST_VAR'] = 'HELLO'
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['test'] == 'HELLO'
    assert len(no_log_values) == 0

    os.environ['TEST_VAR'] = 'ANSIBLE'
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['test'] == 'ANSIBLE'
    assert len(no_log_values) == 0



# Generated at 2022-06-22 21:57:33.934648
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'a'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'a'
    del os.environ['ANSIBLE_TEST_ENV_FALLBACK']


# Generated at 2022-06-22 21:57:38.565236
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_INVENTORY'] = '/some_path/ansible_hosts'
    assert '/some_path/ansible_hosts' == env_fallback('ANSIBLE_INVENTORY')



# Generated at 2022-06-22 21:57:48.805222
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # dict
    argument_spec = dict(
        foo=dict(fallback=['bar', 'baz'])
    )
    parameters = dict(foo='qux')
    assert set_fallbacks(argument_spec, parameters) == set()
    assert parameters['foo'] == 'qux'

    argument_spec = dict(
        foo=dict(fallback=['bar', 'baz'])
    )
    parameters = dict()
    assert set_fallbacks(argument_spec, parameters) == set()
    assert parameters['foo'] == 'bar'

    argument_spec = dict(
        foo=dict(fallback=['bar', 'baz'])
    )
    parameters = dict(foo=None)
    assert set_fallbacks(argument_spec, parameters) == set()
    assert parameters['foo'] is None

   

# Generated at 2022-06-22 21:57:59.794779
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys('test', ['s', 'test']) == 'xxxx'
    assert sanitize_keys('test', ['s', 'test'], ignore_keys={'test'}) == 'test'
    assert sanitize_keys(['test', 'test'], ['s', 'test']) == ['xxxx', 'xxxx']
    assert sanitize_keys(('test', 'test'), ['s', 'test']) == ('xxxx', 'xxxx')
    assert sanitize_keys({'test': 'test', 'test1': 'test1'}, ['s', 'test']) == {'xxxx': 'xxxx', 'test1': 'test1'}

# Generated at 2022-06-22 21:58:04.201681
# Unit test for function env_fallback
def test_env_fallback():
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('ANSIBLE_TEST_NO_FALLBACK')
    assert env_fallback('ANSIBLE_TEST_FALLBACK') == 'yay'


# Generated at 2022-06-22 21:58:15.261651
# Unit test for function remove_values
def test_remove_values():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.common._collections_compat import Mapping, MutableSequence, MutableSet
    from ansible.module_utils.common._collections_compat import Dict
    from copy import copy

    # Values for scalar types
    for value in (1, 1.5, 'abc', b'abc', True, None):
        assert remove_values(value, ['abc']) == value

    # Test that we handle all unsupported types

# Generated at 2022-06-22 21:58:20.895911
# Unit test for function env_fallback
def test_env_fallback():
    with patch.dict(os.environ, {'TEST_ENV_VAR1': 'env_var_value'}):
        assert env_fallback('TEST_ENV_VAR1') == 'env_var_value'
        assert env_fallback('TEST_ENV_VAR2') == 'env_var_value'



# Generated at 2022-06-22 21:58:29.049798
# Unit test for function env_fallback
def test_env_fallback():
    envs = {'ANSIBLE_TEST_VAR': "ansible_test_var_value", 'ANSIBLE_TEST_VAR_2': "ansible_test_var_2_value"}

    # Test fallback to env var value
    os.environ.update(envs)
    assert env_fallback('ANSIBLE_TEST_VAR') == "ansible_test_var_value"

    # Test fallback to env var value for multiple variables
    assert env_fallback('ANSIBLE_TEST_VAR_3', 'ANSIBLE_TEST_VAR_2') == "ansible_test_var_2_value"

    # Test fallback to env var when no arg is passed
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback()

    # Test fall

# Generated at 2022-06-22 21:58:38.141679
# Unit test for function sanitize_keys
def test_sanitize_keys():
    """Unit test function for testing function ``sanitize_keys``"""
    no_log_strings = set(['key1', 'key2'])
    ignore_keys = set(['key2'])
    input_data = {
        'key1': 'xyz',
        'key2': 'abc',
        'abc': 'abc',
    }
    output_data = {
        '****': 'xyz',
        'key2': 'abc',
        'abc': 'abc',
    }

    assert sanitize_keys(input_data, no_log_strings, ignore_keys) == output_data


# Generated at 2022-06-22 21:58:48.465272
# Unit test for function set_fallbacks
def test_set_fallbacks():
    arg = dict(
        param_1=dict(type='str', fallback=(env_fallback, 'TEST_PARAM_1')),
        param_2=dict(type='str', fallback=(env_fallback, 'TEST_PARAM_2')),
        param_3=dict(type='str', fallback=(env_fallback, 'TEST_PARAM_3')),
        param_4=dict(type='str', fallback=(env_fallback, 'TEST_PARAM_4')),
    )

    with set_environ(dict(TEST_PARAM_1='1', TEST_PARAM_2='2', TEST_PARAM_3='3')):
        params = dict(param_1=None, param_2=None, param_3=None, param_4=None)
       

# Generated at 2022-06-22 21:59:00.861730
# Unit test for function remove_values
def test_remove_values():
    value = ['0','1','group','pwd','name','ssh','public','private','2','3','5','3','5','5','5','5','5','5','5','5','5','5','5','5','5','5','5','5','5','5','5','5','5','5','5','5','5','5','5','5','5','5','5','5','5','5','5','5','5','5','5','5','5','5','5','5','5','5','5','5','5','5','5','5','5','5','5','5','5','5','5','5','5','5']

# Generated at 2022-06-22 21:59:04.828445
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['FOO'] = 'spam'
    assert env_fallback('FOO') == 'spam'

    # Test exception
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('BAR') == 'spam'



# Generated at 2022-06-22 21:59:09.646367
# Unit test for function env_fallback
def test_env_fallback():
    with patch.dict('os.environ', {'TEST_FOO': 'bar'}):
        assert os.environ['TEST_FOO'] == 'bar'
        assert env_fallback('TEST_FOO') == 'bar'



# Generated at 2022-06-22 21:59:14.661679
# Unit test for function sanitize_keys
def test_sanitize_keys():
    """Unit test for function sanitize_keys()."""
    result = sanitize_keys({'a': {'b': 'c'}, 'd': 'e'}, {'b', 'd'})
    assert result == {'a': {'***': 'c'}, '***': 'e'}



# Generated at 2022-06-22 21:59:23.694522
# Unit test for function remove_values
def test_remove_values():
    assert remove_values('dont-change-me', ['change-me']) == 'dont-change-me'
    assert remove_values('change-me', ['change-me']) == '********'
    assert remove_values({'dont': 'change-me'}, ['change-me']) == {'dont': 'change-me'}
    assert remove_values({'change': 'change-me'}, ['change-me']) == {'change': '********'}
    assert remove_values({'dont': 'change-me', 'change': 'change-me'}, ['change-me']) == {'dont': 'change-me', 'change': '********'}

# Generated at 2022-06-22 21:59:34.793815
# Unit test for function remove_values
def test_remove_values():
    data = {
        'public_data': 'foo',
        'secret_data': 'bar',
        'nested_data': {
            'public_data': 'foo',
            'secret_data': 'bar',
            'nested_list': [
                {
                    'public_data': 'foo',
                    'secret_data': 'bar',
                },
                ['foo', {'public_data': 'foo', 'secret_data': 'bar', }],
            ]
        }
    }

    # Should remove all secret_data from a data structure
    no_log_strings = ['secret_data']
    output = remove_values(data, no_log_strings)

# Generated at 2022-06-22 21:59:38.753551
# Unit test for function env_fallback
def test_env_fallback():
    '''test_env'''

    def check(arg, result):
        assert env_fallback(arg) == result

    os.environ['HOME'] = '/root'
    check('HOME', '/root')
    check('HAI', AnsibleFallbackNotFound)



# Generated at 2022-06-22 21:59:47.285500
# Unit test for function env_fallback
def test_env_fallback():
    for arg in ['ANSIBLE_REMOTE_USER', 'ANSIBLE_NET_USERNAME']:
        os.environ[arg] = 'test_env_fallback'

    try:
        from ansible.module_utils._text import to_bytes
    except ImportError:
        # ansible < 2.6
        to_bytes = lambda x:x

    assert env_fallback('ANSIBLE_REMOTE_USER', 'ANSIBLE_NET_USERNAME') == to_bytes('test_env_fallback')

    del os.environ['ANSIBLE_REMOTE_USER']
    assert env_fallback('ANSIBLE_REMOTE_USER', 'ANSIBLE_NET_USERNAME') == to_bytes('test_env_fallback')

    del os.environ['ANSIBLE_NET_USERNAME']

# Generated at 2022-06-22 21:59:58.236438
# Unit test for function sanitize_keys
def test_sanitize_keys():

    # Wrap the actual function for unit testing
    def test_func(obj, no_log_strings, ignore_keys=frozenset()):
        return sanitize_keys(obj, no_log_strings, ignore_keys)

    assert test_func(object(), []) == test_func(object(), [])

    data = {
        'a': {
            'b': 'b',
            'c': 'c',
            'd': 'd',
            'e': {
                'f': 'f',
                'g': 'g',
                'h': 'h',
                'i': {
                    'j': {
                        'k': u'k',
                        'l': u'l',
                        'm': u'm',
                    },
                },
            },
        },
    }
    assert data == test

# Generated at 2022-06-22 22:00:01.794564
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'param1': {'fallback': (env_fallback, 'ANSIBLE')}}
    parameters = {}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert no_log_values == set()
    assert parameters == {'param1': 'ANSIBLE'}



# Generated at 2022-06-22 22:00:12.476103
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys([1, 2, 3, 4], []) == [1, 2, 3, 4]
    assert sanitize_keys([1, 2, 3, 4], [], ignore_keys=frozenset(['fred'])) == [1, 2, 3, 4]
    assert sanitize_keys({'foo': 'bar', 'baz': 'nope'}, []) == {'foo': 'bar', 'baz': 'nope'}
    assert sanitize_keys({'foo': 'bar', 'baz': 'nope'}, [], ignore_keys=frozenset(['baz'])) == {'foo': 'bar', 'baz': 'nope'}

# Generated at 2022-06-22 22:00:24.146857
# Unit test for function remove_values
def test_remove_values():
    def _run_tests(tests):
        for test_data, expected in tests:
            assert remove_values(test_data, ['test']) == expected

    # Simple list containing strings, numbers and nested lists
    _run_tests([
        (['test', 'string', ['test', 2, 'test'], 4], ['', 'string', ['', 2, ''], 4])
    ])

    # Simple dictionary containing strings, numbers, nested dictionaries and lists
    _run_tests([
        ({'test': 'string', 'test2': ['test', 2, 'test'], 4: {'test': 5}}, {'test': '', 'test2': ['', 2, ''], 4: {'test': 5}})
    ])

    # Dictionary with nested lists, in nested dictionaries, containing lists

# Generated at 2022-06-22 22:00:35.583978
# Unit test for function remove_values

# Generated at 2022-06-22 22:00:46.637401
# Unit test for function set_fallbacks
def test_set_fallbacks():
    import os
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch
    from ansible.module_utils.common.validation import env_fallback
    from ansible.module_utils.six import string_types

    class AnsibleFallbackNotFound(Exception):
        pass

    def dummy_fallback(dummy1, dummy2='dummy'):
        raise AnsibleFallbackNotFound


# Generated at 2022-06-22 22:00:48.769573
# Unit test for function remove_values
def test_remove_values():
    for src, res in REMOVE_VALUES_TESTS:
        assert res == remove_values(src, ['test'])



# Generated at 2022-06-22 22:01:01.049740
# Unit test for function sanitize_keys
def test_sanitize_keys():
    keys_to_sanitize = ['API_TOKEN', 'SECRET']
    no_log_strings = ['SECRET']
    ignore_keys = ['BUILD_NUMBER']
    test_dict1 = {'BUILD_NUMBER': '123',
                  'DETAILS': {'API_TOKEN': 'SECRET', 'COUNT': '10', 'MESSAGE': 'Hi'},
                  'RESULT': 'PASS'}
    test_dict2 = {'BUILD_NUMBER': '123',
                  'DETAILS': {'API_TOKEN': 'SECRET', 'COUNT': '10', 'MESSAGE': 'Hi'},
                  'RESULT': 'PASS',
                  'LOG': ['a', 'b', 'c']}

# Generated at 2022-06-22 22:01:09.678963
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        test_param=dict(
            type='str',
            fallback=(env_fallback, ['TEST_PARAM_ENV_VAR']),
        )
    )

    parameters = {}

    no_log_values = set_fallbacks(argument_spec, parameters)

    assert parameters['test_param'] == 'TEST_PARAM_ENV_VAR'
    assert no_log_values == set()

    with set_environment_variable('TEST_PARAM_ENV_VAR', 'TEST_PARAM_ENV_VAR'):
        parameters = {}

        no_log_values = set_fallbacks(argument_spec, parameters)

        assert parameters['test_param'] == 'TEST_PARAM_ENV_VAR'
        assert no_log_values

# Generated at 2022-06-22 22:01:22.312753
# Unit test for function sanitize_keys
def test_sanitize_keys():
    no_log_strings = {'foo', 'bar'}
    ignore_keys = {'baz'}
    assert sanitize_keys('foo', no_log_strings) == 'foo'
    assert sanitize_keys('foofoo', no_log_strings) == 'foofoo'
    assert sanitize_keys('foobar', no_log_strings) == 'foobar'
    assert sanitize_keys('foo baz bar', no_log_strings) == 'foo baz bar'
    assert sanitize_keys('foo', no_log_strings, ignore_keys) == 'foo'
    assert sanitize_keys('foofoo', no_log_strings, ignore_keys) == 'foofoo'
    assert sanitize_keys('foobar', no_log_strings, ignore_keys)