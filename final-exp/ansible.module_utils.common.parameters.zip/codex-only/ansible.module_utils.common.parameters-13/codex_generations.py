

# Generated at 2022-06-22 21:51:22.043028
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('a') == os.environ.get('a')
    assert env_fallback('a', 'b') == os.environ.get('a') or os.environ.get('b')
    assert env_fallback('a', 'b', 'c') == os.environ.get('a') or os.environ.get('b') or os.environ.get('c')
    assert env_fallback('d', 'e', 'f') is not os.environ.get('d') and os.environ.get('e') and os.environ.get('f')


# Generated at 2022-06-22 21:51:31.985444
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['PAASTA_API_URL'] = 'http://paasta.fake'
    assert env_fallback('PAASTA_API_URL') == 'http://paasta.fake'
    assert env_fallback('ANOTHER_URL') == 'http://paasta.fake'
    os.environ['ANOTHER_URL'] = 'http://another.fake'
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('YET_ANOTHER_URL')
    del os.environ['PAASTA_API_URL']
    del os.environ['ANOTHER_URL']


# Generated at 2022-06-22 21:51:40.852716
# Unit test for function env_fallback
def test_env_fallback():
    # 1. Test if AnsibleFallbackNotFound is raised if all args are in the env
    try:
        env_fallback('ABC', 'DEF', 'GHI')
    except AnsibleFallbackNotFound:
        pass
    else:
        raise AssertionError("AnsibleFallbackNotFound was not raised")
    # 2. Test if first value is returned if found in env
    os.environ['ABC'] = 'abc'
    assert env_fallback('ABC', 'DEF', 'GHI') == 'abc'
    # 3. Test if second value is returned if found in env
    os.environ['DEF'] = 'def'
    assert env_fallback('ABC', 'DEF', 'GHI') == 'def'
    del os.environ['ABC']
    del os.environ['DEF']



# Generated at 2022-06-22 21:51:46.799423
# Unit test for function sanitize_keys
def test_sanitize_keys():
    struct = {
        "key": "value",
        "no_log": "value",
        "a": {
            "key": "value",
            "no_log": "value"
        },
        "b": [
            "value",
            {"key": "value", "no_log": "value"}
        ]
    }

    no_log_values = set()
    for value in struct.values():
        if isinstance(value, Mapping):
            no_log_values.update(value.values())
        else:
            no_log_values.add(value)

    no_log_values = [to_native(s, errors='surrogate_or_strict') for s in no_log_values]


# Generated at 2022-06-22 21:51:59.351887
# Unit test for function remove_values
def test_remove_values():
    """Unit tests for remove_values()."""

    # AnsibleModule object
    am_module = AnsibleModule(argument_spec={
        'one': {'type': 'str', 'default': 'foo'},
        'two': {'type': 'list', 'elements': 'str', 'default': ['bar', 'baz']},
    })

    # Module input
    am_params = get_module_params(am_module)

    # AnsibleModule args
    am_args = get_module_args(am_module)

    # AnsibleModule extras
    am_extras = get_module_extras(am_module)

    # AnsibleModule no_log_strings
    am_no_log = get_module_no_log_values(am_module)

    # AnsibleModule errors

# Generated at 2022-06-22 21:52:02.624000
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('TEST_ENV') == os.environ['TEST_ENV']
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('TEST_ENV1')



# Generated at 2022-06-22 21:52:14.605587
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys({'k1': 'v1', 'k2': 'v2'}, set()) == {'k1': 'v1', 'k2': 'v2'}
    assert sanitize_keys({'k1': 'v1', 'k2': 'v2', 'k3': {'k4': 'v4', 'k5': 'v5'}}, set()) == {'k1': 'v1', 'k2': 'v2', 'k3': {'k4': 'v4', 'k5': 'v5'}}
    assert sanitize_keys({'k1': 'v1', 'k2': 'v2', 'k3': ['v3']}, set()) == {'k1': 'v1', 'k2': 'v2', 'k3': ['v3']}

# Generated at 2022-06-22 21:52:16.373778
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['TEST_ENV_FALLBACK'] = "abcd"
    assert env_fallback("TEST_ENV_FALLBACK") == "abcd"



# Generated at 2022-06-22 21:52:19.052239
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['TEST_ENV_FALLBACK'] = 'TEST_VALUE'
    assert env_fallback('TEST_ENV_FALLBACK') == 'TEST_VALUE'
    try:
        env_fallback('END_ENV_FALLBACK')
        assert False
    except AnsibleFallbackNotFound:
        assert True



# Generated at 2022-06-22 21:52:28.634596
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys("test", ["tes", "test"]) == "****"
    assert sanitize_keys("test", ["tes", "test"], ignore_keys=("ignore",)) == "test"
    assert sanitize_keys("test", ["test"], ignore_keys=("t",)) == "test"
    assert sanitize_keys("test", ["test"], ignore_keys=("test",)) == "test"
    assert sanitize_keys("test", ["test"]) == "****"
    assert sanitize_keys("test", ["test"], ignore_keys=("ignore",)) == "****"
    assert sanitize_keys("test", []) == "test"
    assert sanitize_keys("test", [], ignore_keys=("ignore",)) == "test"


# Generated at 2022-06-22 21:52:40.544693
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['TEST_FALLBACK'] = 'env_fallback'
    assert env_fallback("TEST_FALLBACK") == 'env_fallback'
    assert env_fallback("TEST_FALLBACK", "TEST_FALLBACK2") == 'env_fallback'
    os.environ['TEST_FALLBACK2'] = 'env_fallback2'
    assert env_fallback("TEST_FALLBACK1", "TEST_FALLBACK2", "TEST_FALLBACK3") == 'env_fallback2'
    assert env_fallback("TEST_FALLBACK1", "TEST_FALLBACK3") == 'env_fallback2'

# Generated at 2022-06-22 21:52:47.554738
# Unit test for function env_fallback
def test_env_fallback():
    key = 'TEST_ENV_FALLBACK'
    for value in [b(u('value')), u('value')]:
        # NOTE: the test will fail if you have a TEST_ENV_FALLBACK environment variable set up
        try:
            del os.environ[key]
        except KeyError:
            pass
        os.environ[key] = value
        options = {key: env_fallback(key)}
        # NOTE: the test will fail if you have a TEST_ENV_FALLBACK environment variable set up
        del os.environ[key]
        assert options[key] == value

    # When fallback value is not found
    try:
        del os.environ[key]
    except KeyError:
        pass
    options = {key: env_fallback(key)}

# Generated at 2022-06-22 21:52:58.247431
# Unit test for function remove_values
def test_remove_values():
    no_log_list = ['secret', 'password']
    test_list = ['application_id', 'secret', 'password', 'user']
    new_list = remove_values(test_list, no_log_list)
    if not new_list == ['application_id', '*****', '*****', 'user']:
        raise ValueError('test_remove_values failed')
    test_dict = {'id': 123,'secret':'123456','password':'abcdef','type':'f5'}
    new_dict = remove_values(test_dict, no_log_list)
    if not new_dict == {'id': 123,'secret':'*****','password':'*****','type':'f5'}:
        raise ValueError('test_remove_values failed')
#test_remove_values()



# Generated at 2022-06-22 21:53:10.015873
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'test1': {'default': 'test1_default'},
                     'test2': {'fallback': (env_fallback, ['test2_env'], {'default': 'test2_fallback_default'})},
                     'test3': {'fallback': (env_fallback, ['test3_env'])},
                     'test4': {'fallback': (env_fallback, ['test4_env'], {'default': None})}}

    parameters = {'test1': 'test1_value'}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert len(no_log_values) == 0

# Generated at 2022-06-22 21:53:12.395274
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('FOO') == os.environ['FOO']



# Generated at 2022-06-22 21:53:21.354987
# Unit test for function sanitize_keys
def test_sanitize_keys():
    from ansible.module_utils._text import to_native

    # Note: This test assumes 'sanitize_private_data' option is set to True
    # Use to_native() because it will turn bytestrings into unicode in Python 2
    assert(to_native(sanitize_keys('foo', ['foo'])) == u'***')
    assert(to_native(sanitize_keys('foobar', ['foo'])) == u'***bar')
    assert(to_native(sanitize_keys('barfoo', ['foo'])) == u'bar***')
    assert(to_native(sanitize_keys('barbar', ['foo'])) == u'barbar')

    assert(to_native(sanitize_keys('foo', ['foo'], ignore_keys=['foo'])) == u'foo')

# Generated at 2022-06-22 21:53:28.408514
# Unit test for function remove_values

# Generated at 2022-06-22 21:53:36.715781
# Unit test for function remove_values
def test_remove_values():
    input_data = {
        'private': {
            'key': 'value',
            'key2': 'value2',
        },
        'public': {
            'key': 'value',
            'key2': 'value2',
        },
    }
    output_data = {
        'private': {
            'key': '********',
            'key2': '********',
        },
        'public': {
            'key': 'value',
            'key2': 'value2',
        },
    }
    assert remove_values(input_data, ['value']) == output_data



# Generated at 2022-06-22 21:53:48.918627
# Unit test for function sanitize_keys
def test_sanitize_keys():
    no_log_strings = ('password', 'secret', to_bytes(b'secret'))
    ignore_keys = ('_ansible_verbose_always',)

# Generated at 2022-06-22 21:53:59.893933
# Unit test for function remove_values
def test_remove_values():
    data = {
        'foo': 'bar',
        'baz': {
            'bork': 'bark',
            'dork': {
                'cork': 'chark',
                'lork': [
                    'lark',
                    'mork',
                    {
                        'nork': ['pork', 'quark']
                    },
                    'pork',
                    'quark'
                ]
            },
            'flerk': [
                'flark',
                'glerk',
                {
                    'hork': ['jork', 'kark']
                },
                'jork',
                'kark'
            ]
        }
    }
    no_log_strings = ['lark', 'mork', 'pork', 'quark']

# Generated at 2022-06-22 21:54:07.439071
# Unit test for function env_fallback
def test_env_fallback():
    test_env = dict(ANSIBLE_TEST_ENV_VAR1='env_var1')
    with patch.dict('os.environ', test_env):
        fallback_value = env_fallback('ANSIBLE_TEST_ENV_VAR1', 'ANSIBLE_TEST_BAD_ENV_VAR')
        assert fallback_value == 'env_var1'

    with patch.dict('os.environ', test_env):
        fallback_value = env_fallback()
        assert fallback_value is None


# Generated at 2022-06-22 21:54:14.167665
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['TEST_KEY'] = 'testing key'
    assert env_fallback('TEST_KEY', 'TEST_KEY2') == 'testing key'
    assert_raises(AnsibleFallbackNotFound, env_fallback, 'TEST_KEY2')
    del os.environ['TEST_KEY']



# Generated at 2022-06-22 21:54:18.893129
# Unit test for function env_fallback
def test_env_fallback():
    with patch.dict(os.environ, {'test_env': 'testing'}):
        assert env_fallback('test_env') == 'testing'
        assert env_fallback('not_found', 'test_env') == 'testing'
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('not_found')



# Generated at 2022-06-22 21:54:29.898690
# Unit test for function remove_values
def test_remove_values():
    name_1 = 'test_remove_values: remove_values'
    from ansible import errors
    from ansible.plugins.loader import module_loader
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    # Boolean
    data_1 = {'key_0': True}
    data_1_0 = data_1.copy()
    result_1 = remove_values(data_1, set())
    assert result_1 == data_1_0, name_1
    # Boolean
    data_2 = {'key_0': False}
    data_2_0 = data_2.copy()
    result_2 = remove_values(data_2, set())
    assert result_2 == data_2_0, name_1
    # Boolean

# Generated at 2022-06-22 21:54:38.818441
# Unit test for function remove_values
def test_remove_values():
    test_str = 'The passwd is secret'
    test_list = ['The passwd is secret', 'The key is secret']
    test_set = {'The passwd is secret', 'The key is secret'}
    test_tuple = ('The passwd is secret', 'The key is secret')
    test_dict = {'password': 'The passwd is secret',
                 'key': 'The key is secret',
                 'ignored_value': 'A value that should not be sanitized'}

    # test strings
    assert remove_values(test_str, ['secret']) == 'The passwd is ***'
    assert remove_values(test_str, ['passwd']) == 'The ****** is secret'
    assert remove_values(test_str, ['The']) == '** passwd is secret'
    assert remove_

# Generated at 2022-06-22 21:54:47.148168
# Unit test for function sanitize_keys
def test_sanitize_keys():
    no_log_values = set()
    no_log_values.add('password')
    container_obj = {"ip_address" : "192.168.10.2", "test_password" : "test_password", "user_name" : "cloudbyte", "secret_key" : "secret_key"}
    out_obj = sanitize_keys(container_obj, no_log_values)
    print(out_obj)
    out_obj = sanitize_keys(container_obj, no_log_values)
    print(out_obj)
# test_sanitize_keys()


# Generated at 2022-06-22 21:54:58.053935
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert set_fallbacks({'test_fallback': {'type': 'str', 'fallback': (env_fallback, 'TEST_ENV_VAR')}},
                         {}) == set()

    os.environ['TEST_ENV_VAR'] = 'ENV_VAR'
    assert set_fallbacks({'test_fallback': {'type': 'str', 'fallback': (env_fallback, 'TEST_ENV_VAR')}},
                         {}) == set()

    assert set_fallbacks({'test_fallback': {'type': 'str', 'fallback': (env_fallback, 'TEST_ENV_VAR'), 'no_log': True}},
                         {}) == set(['ENV_VAR'])


# Generated at 2022-06-22 21:55:05.390707
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['FOO'] = 'bar'
    assert env_fallback('FOO') == 'bar'
    assert env_fallback('FOO', 'BAR') == 'bar'
    try:
        env_fallback('BAR', 'FOO')
    except AnsibleFallbackNotFound as e:
        assert str(e) == 'Unable to find required configuration value, please check environment variables FOO, BAR'
        pass
    assert env_fallback('BAR', 'FOO', 'BAZ') == 'bar'
    try:
        env_fallback('BAZ')
    except AnsibleFallbackNotFound as e:
        assert str(e) == 'Unable to find required configuration value, please check environment variable BAZ'
        pass



# Generated at 2022-06-22 21:55:16.397681
# Unit test for function remove_values
def test_remove_values():
    assert testlib.returnkeys(remove_values) == ['deferred_removals', 'no_log_strings', 'value']
    l0 = [1, 2, 3]
    l1 = [{1: [2, {3: [4, {5: 6}, 7]}]}]
    l2 = [{1: [2, {3: [4, {'5': 6}, 7]}]}]
    l3 = [{1: [2, {3: [4, {'5': '6'}, 7]}]}]
    assert remove_values(l0, {}) == l0
    assert remove_values(l0, {5}) == l0
    assert remove_values(l1, {5}) == l1
    assert remove_values(l2, {5}) == l1

# Generated at 2022-06-22 21:55:27.637723
# Unit test for function set_fallbacks
def test_set_fallbacks():

    argument_spec = {
        'a': {'type': 'str', 'fallback': (env_fallback, ['A'])},
        'b': {'type': 'str', 'fallback': (env_fallback, 'B')},
        'c': {'type': 'str', 'fallback': env_fallback},
        'd': {'type': 'str', 'fallback': (env_fallback, 'E', 'F')},
        'e': {'type': 'str', 'fallback': (env_fallback, 'G')},
    }

    parameters = {'a': '1', 'b': '2', 'c': '3', 'd': '4', 'e': '5'}

# Generated at 2022-06-22 21:55:32.791535
# Unit test for function env_fallback
def test_env_fallback():
    with set_env_var('ANSIBLE_TEST_FOO_BAR', '42'):
        assert env_fallback('ANSIBLE_TEST_FOO_BAR') == '42'
    assert env_fallback('ANSIBLE_TEST_NOT_FOUND') == None



# Generated at 2022-06-22 21:55:40.191431
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys('hello', ('hell',)) == 'heXXX'
    assert sanitize_keys({'fizz': 'buzz'}, ('fizz',)) == {'fiXX': 'buzz'}
    assert sanitize_keys({'fizz': 'buzz', 'foo': 'bar'}, ('fizz',)) == {'fiXX': 'buzz', 'foo': 'bar'}
    assert sanitize_keys({'fizz': 'buzz', 'foo': 'bar'}, ('fizz',), ('foo',)) == {'fiXX': 'buzz', 'foo': 'bar'}
    assert sanitize_keys({'fizz': 'buzz', 'foo': 'bar'}, ('fizz',), ()) == {'fiXX': 'buzz', 'foo': 'bar'}

# Generated at 2022-06-22 21:55:52.072176
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys({'foo': 'bar'}, []) == {'foo': 'bar'}
    assert sanitize_keys({'foo': 'bar'}, ['foo']) == {'**': 'bar'}
    assert sanitize_keys({'foo': {'bar': 'baz'}}, ['foo']) == {'***': {'bar': 'baz'}}
    assert sanitize_keys({'foo': {'bar': 'baz'}}, ['bar']) == {'foo': {'**': 'baz'}}
    assert sanitize_keys({'foo': {'bar': 'baz'}}, ['foo', 'bar']) == {'***': {'**': 'baz'}}

# Generated at 2022-06-22 21:55:56.984846
# Unit test for function remove_values
def test_remove_values():
    for no_log_strings in [[], [''], [' ', ''], [' ', '', ' '], ['"']]:
        assert remove_values(None, no_log_strings) is None
        assert remove_values('', no_log_strings) == ''
        assert remove_values('a', no_log_strings) == 'a'
        assert remove_values('key_with_no_log_string', no_log_strings) == 'key_with_no_log_string'
        for no_log_string in no_log_strings:
            assert remove_values(no_log_string, no_log_strings) == ''
            assert remove_values('key_%s_with_no_log_string' % no_log_string, no_log_strings) == 'key__with_no_log_string'


# Generated at 2022-06-22 21:56:08.073814
# Unit test for function remove_values
def test_remove_values():
    """Unit test for remove_values function."""
    test_list = ['1', '2', '3', '4']
    assert remove_values(test_list, '2') == ['1', '3', '4']
    test_dict = {'a': '1', 'b': '2', 'c': '3', 'd': '4'}
    assert remove_values(test_dict, '2') == {'a': '1', 'c': '3', 'd': '4'}
    test_list_multiple = ['1', '2', '3', '4', '2', '5']
    assert remove_values(test_list_multiple, '2') == ['1', '3', '4', '5']

# Generated at 2022-06-22 21:56:14.690334
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_NETCONF_SSH_KEYFILE'] = 'test'
    assert env_fallback('ANSIBLE_NETCONF_SSH_KEYFILE') == 'test'
    del os.environ['ANSIBLE_NETCONF_SSH_KEYFILE']
    raises(AnsibleFallbackNotFound, env_fallback, 'ANSIBLE_NETCONF_SSH_KEYFILE')


# Generated at 2022-06-22 21:56:25.238225
# Unit test for function set_fallbacks
def test_set_fallbacks():
    """Test set_fallbacks function"""

    parameters = {'a': 'A'}
    argument_spec = {'a': {'type': 'str'}, 'b': {'type': 'int', 'fallback': (env_fallback, 'ANSIBLE')}}

    no_log_values = set_fallbacks(argument_spec, parameters)
    assert no_log_values == set(), \
            "set_fallbacks should return an empty set when there are no no_log parameters that were loaded from fallback"

    assert parameters['b'] == int(os.environ['ANSIBLE']), \
            "set_fallbacks should load fallback value for parameter when it is not set in task"

    # Test loading no_log value from fallback
    parameters = {'a': 'A'}

# Generated at 2022-06-22 21:56:36.284532
# Unit test for function sanitize_keys
def test_sanitize_keys():
    """Test function sanitize_keys"""

    # Make sure startswith() throws no exceptions on non-strings.
    for test in (42, {}, []):
        assert not test.startswith('_ansible')


# Generated at 2022-06-22 21:56:43.186822
# Unit test for function sanitize_keys
def test_sanitize_keys():

    obj = {'a': {'db_pass': 'foo'}, 'b': ['c', 'd', 'e'], 'd': {'db_pass2': 'bar', '_ansible_no_log': True}, 'e': 'f'}
    returned = sanitize_keys(obj, ['foo', 'bar'], ignore_keys=['e'])
    assert returned == {'a': {'db_pass': '****'}, 'b': ['c', 'd', 'e'], 'd': {'db_pass2': '****', '_ansible_no_log': True}, 'e': '****'}



# Generated at 2022-06-22 21:56:53.897555
# Unit test for function remove_values
def test_remove_values():

    def _identity(obj):
        return obj

    def _test_remove_values(test_cases, no_log_strings, expected_results):
        if not isinstance(no_log_strings, set):
            no_log_strings = set(no_log_strings)

        for test in test_cases:
            result = remove_values(test, no_log_strings)
            assert result == expected_results[test_cases.index(test)]

    def _test_sanitize_keys(test_cases, no_log_strings, expected_results):
        if not isinstance(no_log_strings, set):
            no_log_strings = set(no_log_strings)

        for test in test_cases:
            result = sanitize_keys(test, no_log_strings)
            assert result == expected

# Generated at 2022-06-22 21:57:02.910356
# Unit test for function env_fallback
def test_env_fallback():
    env = os.environ
    with set_env_fallback_vars({'ANSIBLE_ANSIBLE_SSH_ARGS': '-o UserKnownHostsFile=/dev/null -o ControlMaster=auto -o ControlPersist=60s -o Port=2222 -o StrictHostKeyChecking=no'}):
        assert env_fallback('ANSIBLE_ANSIBLE_SSH_ARGS') == '-o UserKnownHostsFile=/dev/null -o ControlMaster=auto -o ControlPersist=60s -o Port=2222 -o StrictHostKeyChecking=no'


# Generated at 2022-06-22 21:57:11.083582
# Unit test for function remove_values
def test_remove_values():
    value = dict(key1='abc', key2='abcdef', key3='abcdefg')
    result = dict(key1='abc', key2='******', key3='*******')
    assert remove_values(value, ('def',)) == result

    value = dict(key1='abc', key2='abcdef', key3='abcdefg')
    result = dict(key1='abc', key2='ABC***', key3='ABC****')
    assert remove_values(value, ('def',), case_sensitive=False) == result



# Generated at 2022-06-22 21:57:15.538135
# Unit test for function sanitize_keys
def test_sanitize_keys():
    class TestNoLogStrings(object):
        def __contains__(self, key):
            return key == 'a'
    no_log_strings = TestNoLogStrings()
    test_data = dict(a='1', b='2', c='3')
    expected_result = dict(_an='1', b='2', c='3')
    assert sanitize_keys(test_data, no_log_strings) == expected_result



# Generated at 2022-06-22 21:57:27.612534
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'command': {'type': 'str', 'choices': ['present', 'absent', 'reboot'], 'fallback': (env_fallback, 'ANSIBLE_NET_COMMAND')},
        'test_value': {'type': 'str', 'required': True, 'fallback': (env_fallback, 'ANSIBLE_NET_TEST_VALUE')},
    }
    parameters = {
        'command': None
    }
    set_fallbacks(argument_spec, parameters)
    assert parameters['command'] == 'present'
    assert 'test_value' not in parameters
    # Use fallback again, should not change anything in parameters
    set_fallbacks(argument_spec, parameters)
    assert parameters['command'] == 'present'
    assert 'test_value' not in parameters

   

# Generated at 2022-06-22 21:57:37.478448
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # This is an incomplete test, as there are many possible combinations of parameters
    test_params = dict(a=None, b=None, c=None, d=None, e=None, f=None, g=None)

# Generated at 2022-06-22 21:57:47.856279
# Unit test for function sanitize_keys
def test_sanitize_keys():
    fd, path = tempfile.mkstemp()
    os.close(fd)
    obj = {
        'foo': 'bar',
        'foobar': 'boo',
        'bax': {
            'boo': 'fay',
        },
        'yes': ['one', 'two'],
        'numbers': {1, 2},
        'in_file': read_vault_file(path, 'test'),
    }

    obj = sanitize_keys(obj, {'foo'})
    assert sorted(obj.keys()) == ['bax', 'foobar', 'in_file', 'numbers', 'yes']
    assert obj['foobar'] == 'boo'
    assert sorted(obj['bax'].keys()) == ['boo']

# Generated at 2022-06-22 21:57:58.949627
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        boolean=dict(type='bool', fallback=(env_fallback, 'BOOL_VAR')),
        string=dict(type='str', fallback=(env_fallback, ['STR_VAR1', 'STR_VAR2'], {'default': 'default'})),
        list=dict(type='list', fallback=(env_fallback, 'LIST_VAR')),
        dict=dict(type='dict', fallback=(env_fallback, 'DICT_VAR'), no_log=True),
        integer=dict(type='int', fallback=(env_fallback, 'INT_VAR')),
    )
    parameters = dict()
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert no_log_values == dict()

    assert parameters

# Generated at 2022-06-22 21:58:10.566957
# Unit test for function set_fallbacks

# Generated at 2022-06-22 21:58:16.777251
# Unit test for function remove_values
def test_remove_values():
    assert 'an' == remove_values('an', ['no_log'])
    assert 'no_log' == remove_values('no_log', ['no_log'])
    assert '' == remove_values('no_log', ['no_log', 'no_log'])
    assert u('an') == remove_values(u('an'), ['no_log'])
    assert u('no_log') == remove_values(u('no_log'), ['no_log'])
    assert u('') == remove_values(u('no_log'), ['no_log', 'no_log'])

    assert 'an' == remove_values('an', [10])
    assert 'an' == remove_values('an', [])

    assert [10] == remove_values([10], ['no_log'])


# Generated at 2022-06-22 21:58:26.403513
# Unit test for function remove_values
def test_remove_values():
    """Unit test for remove_values"""
    # Dict of input values and expected results

# Generated at 2022-06-22 21:58:37.847412
# Unit test for function set_fallbacks
def test_set_fallbacks():
    import os

    def test_fallback_callable(*args, **kwargs):
        return 'test'

    def test_fallback_callable_with_kwargs(*args, **kwargs):
        return kwargs.get('test_kwarg', 'test')

    def test_fallback_fail(*args, **kwargs):
        raise AnsibleFallbackNotFound


# Generated at 2022-06-22 21:58:48.192367
# Unit test for function remove_values
def test_remove_values():
    # All values remain.
    assert remove_values(['a', 'b', 'c'], ['d']) == ['a', 'b', 'c']

    # All elements are lists, so the results are nested lists.
    assert remove_values(['a', ['b', 'c'], 'd'], ['a', 'e', 'f']) == ['c']

    # All elements are dicts, so the results are dicts.
    assert remove_values(
        {'a': 'b', 'c': {'a': 'b', 'd': 'e', 'f': {'a': 'b'}, 'g': ['a', 'b']}},
        ['a', 'b', 'c', 'd']
    ) == {'c': {'f': {}}}

    # Mixture of dicts, lists, and strings.

# Generated at 2022-06-22 21:59:00.548928
# Unit test for function remove_values

# Generated at 2022-06-22 21:59:06.390244
# Unit test for function env_fallback
def test_env_fallback():
    test_arg = 'TEST_VAR'
    test_value = 'test_value'
    os.environ[test_arg] = test_value
    assert env_fallback(test_arg) == test_value
    del os.environ[test_arg]
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback(test_arg)


# Generated at 2022-06-22 21:59:13.309072
# Unit test for function set_fallbacks
def test_set_fallbacks():
    values = {'b': 2}
    parameters = {}
    argument_spec = {'a': {'type': 'int', 'fallback': (env_fallback, ('A', 'B'))}, 'b': {'type': 'dict'}}
    set_fallbacks(argument_spec, parameters)
    parameters['b'] = values
    assert parameters['b'] == values


# Generated at 2022-06-22 21:59:21.638406
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'a': {'type': 'str', 'fallback': (env_fallback, 'a')}}
    assert set_fallbacks(argument_spec, {}) == set()

    # Test env_fallback success
    os.environ['a'] = 'b'
    assert set_fallbacks(argument_spec, {}) == set()

    # Test env_fallback failure
    os.environ.pop('a')
    assert set_fallbacks(argument_spec, {}) == set()

    # Test no_log
    argument_spec = {'a': {'type': 'str', 'fallback': (env_fallback, 'a'), 'no_log': True}}
    assert set_fallbacks(argument_spec, {}) == set()

    os.environ['a'] = 'b'
   

# Generated at 2022-06-22 21:59:31.003150
# Unit test for function env_fallback
def test_env_fallback():
    """Test function env_fallback"""
    patch_environ(CLEAR_VARS)
    try:
        env_fallback('NOT_SET_ENV_VAR')
    except AnsibleFallbackNotFound:
        pass
    else:
        raise AssertionError('env_fallback did not raise AnsibleFallbackNotFound when environment variable was not set')
    os.environ['TEST_VAR'] = 'test_value'
    assert env_fallback('TEST_VAR') == 'test_value'
    assert env_fallback('TEST_VAR', 'TEST_VAR2') == 'test_value'
    assert env_fallback('TEST_VAR', 'TEST_VAR2') == 'test_value'
    patch_environ(CLEAR_VARS)



# Generated at 2022-06-22 21:59:42.534273
# Unit test for function remove_values
def test_remove_values():
    no_log_strings = 'BAR'
    val_str = 'foo BAR'
    val_str_ret = 'foo'
    val_dict = {'foo': 'bar', 'FOO': 'BAR'}
    val_dict_ret = {'foo': 'bar'}
    val_dict_ret_wo_key = val_dict
    val_list = ['foo', ['foo', 'BAR'], {'foo': 'BAR'}]
    val_list_ret = ['foo', ['foo'], {'foo': None}]
    val_list_ret_wo = ['foo', ['foo', 'BAR'], {'foo': 'BAR'}]
    val_set = {'foo', 'BAR'}
    val_set_ret = {'foo'}

    assert remove_values

# Generated at 2022-06-22 21:59:54.579676
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Test with fallbacks
    spec = dict(
        foo=dict(type='int', fallback=(env_fallback, 'FOO', 'FOO2')),
        bar=dict(type='int', fallback=(env_fallback, 'BAR', 'BAR2')),
        zoo=dict(type='int', fallback=(env_fallback, 'ZOO', 'ZOO2')),
        flag=dict(type='bool', fallback=(env_fallback, 'FLAG', 'FLAG2')),
        flag2=dict(type='bool', fallback=(env_fallback, 'FLAG2', 'FLAG3')),
        flag3=dict(type='bool', fallback=(env_fallback, 'FLAG3', 'FLAG4')),
    )

# Generated at 2022-06-22 22:00:00.306855
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys(
        {'a': {'b': 'foo'}, 'a.b': {'c': 'bar'}, 'a.b.c': {'d': {'e': 'baz'}}},
        {'private_value'},
        ignore_keys={'a.b.c'},
    ) == {'a': {'b': 'foo'}, 'a.b': {'c': {'d': {'e': 'baz'}}}}



# Generated at 2022-06-22 22:00:11.547077
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert set_fallbacks({'test': {'fallback': ('test', [1])}}, {}) == set([])
    assert set_fallbacks({'test': {'fallback': ('test', [1]), 'no_log': False}}, {}) == set([])
    assert set_fallbacks({'test': {'fallback': (None, [1])}, 'test2': {'fallback': ('test', [1]), 'no_log': False}}, {}) == set([])
    assert set_fallbacks({'test': {'fallback': ('test', [1])}}, {'test': 2}) == set([])
    assert set_fallbacks({'test': {'fallback': ('test', [1]), 'no_log': True}}, {}) == set([1])



# Generated at 2022-06-22 22:00:23.568590
# Unit test for function sanitize_keys
def test_sanitize_keys():
    no_log_strings = ['its_a_secret']

    # Test a simple dict
    obj = {'some_key': 'some_value', 'its_a_secret_key': 'its_a_secret_value'}
    expected = {'some_key': 'some_value', 'its_a_secret_key': '**********'}
    actual = sanitize_keys(obj, no_log_strings)
    assert expected == actual, "Sanitize keys did not work for simple dict"

    # Test a simple dict with no matches
    obj = {'some_key': 'some_value', 'no_match': 'no_match_value'}
    expected = {'some_key': 'some_value', 'no_match': 'no_match_value'}

# Generated at 2022-06-22 22:00:24.552063
# Unit test for function env_fallback
def test_env_fallback():
    assert False is not True

# Generated at 2022-06-22 22:00:31.441927
# Unit test for function set_fallbacks
def test_set_fallbacks():
    param = {'name': {'type': 'str', 'fallback': (env_fallback, 'ANSIBLE_MODULE_NAME')}}
    os.environ['ANSIBLE_MODULE_NAME'] = 'test_module'
    no_log_values = set_fallbacks(param, {})
    assert no_log_values == set()
    assert len(param) == 1
    assert 'name' in param
    assert param['name'] == 'test_module'



# Generated at 2022-06-22 22:00:43.881870
# Unit test for function sanitize_keys
def test_sanitize_keys():
    from ansible.module_utils.common._text import to_text
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils._text import to_native
    from copy import copy
    from collections import defaultdict, namedtuple

    def _sanitize_keys_test_inner(test_input, expected_output):
        test_input = copy(test_input)
        expected_output = copy(expected_output)

        no_log_strings = set(['secret'])
        actual_output = sanitize_keys(test_input, no_log_strings)
        assert actual_output == expected_output


# Generated at 2022-06-22 22:00:54.613423
# Unit test for function remove_values
def test_remove_values():
    no_log_strings = frozenset(['password', 'secret'])
    data_in = {
        'dict': {
            'login': 'testuser',
            'password': 'secret',
            'data': {
                'password': 'secret',
                'non-dict': ['passwd', 'password', 'secret', 'passwd', 'password', 'secret'],
            },
            'list': [
                {'password': 'secret'},
                'secret',
                ['password', 'secret'],
                'password',
                'secret',
                ['password', 'secret'],
            ],
            'set': set(['password', 'secret']),
            'tuple': ('password', 'secret'),
        }
    }

# Generated at 2022-06-22 22:01:01.871388
# Unit test for function sanitize_keys
def test_sanitize_keys():
    obj = {'ansible_become_password':'foo', 'ansible_become_method':'baz'}
    new_value = sanitize_keys(obj, ('foo', 'bar'))
    assert new_value != obj
    new_key = list(new_value.keys())[0]
    assert not new_key.startswith('ansible')
    assert new_value == {new_key:'foo', 'ansible_become_method':'baz'}



# Generated at 2022-06-22 22:01:10.299019
# Unit test for function remove_values
def test_remove_values():
    # Test removing from a non-container type
    assert remove_values('abcdefg', {'b'}) == 'acdefg'
    assert remove_values(2, {'2'}) == 2
    assert remove_values(False, {'False'}) is False

    # Test removing from a known container type
    assert remove_values({'a': 'b', 'c': 'd'}, {'b'}) == {'a': 'c', 'c': 'd'}
    assert remove_values(['a', 'b', 'c'], {'b'}) == ['a', 'c']
    assert remove_values(set(['a', 'b', 'c']), {'b'}) == set(['a', 'c'])

    # Test removing from a dictionary with a dictionary as a value

# Generated at 2022-06-22 22:01:22.535533
# Unit test for function sanitize_keys
def test_sanitize_keys():
    no_log_strings = ['test_string']
    assert sanitize_keys({'test_string': 'value'}, no_log_strings) == {'#ansible_string': 'value'}
    assert sanitize_keys([{'test_string': 'value'}], no_log_strings) == [{'#ansible_string': 'value'}]
    assert sanitize_keys({'test_string': 'value', 'other': 'value'}, no_log_strings) == {'#ansible_string': 'value', 'other': 'value'}
    assert sanitize_keys([{'test_string': 'value'}, {'other': 'value'}], no_log_strings) == [{'#ansible_string': 'value'}, {'other': 'value'}]