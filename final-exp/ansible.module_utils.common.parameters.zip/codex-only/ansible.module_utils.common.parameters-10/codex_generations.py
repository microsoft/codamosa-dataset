

# Generated at 2022-06-22 21:51:17.534978
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('ANSIBLE_CONFIG') == os.environ.get('ANSIBLE_CONFIG')



# Generated at 2022-06-22 21:51:26.381202
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys("YWRtaW4=", DECODED) is "YWRtaW4="
    # In this case the key is decoded, but the data is not removed
    assert sanitize_keys("YWRtaW4=", DECODED, ignore_keys={"YWRtaW4="}) == "YWRtaW4="
    assert sanitize_keys("YWRtaW4=", DECODED, ignore_keys={"YWRtaW4="}) != "*****"
    for data in PRIVATE_DATA, NESTED_PRIVATE_DATA, DICT_PRIVATE:
        assert sanitize_keys(data, DECODED) is None

# Generated at 2022-06-22 21:51:33.944751
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Test with fallback values
    spec = dict(
        foo=dict(fallback=(env_fallback, 'FOO')),
        bar=dict(fallback=(env_fallback, 'BAR')),
        baz=dict(fallback=(env_fallback, 'BAZ', dict(default='default'))),
    )
    params = dict(
        foo='from dict',
    )
    expected_no_log_values = set()
    expected_params = dict(
        foo='from dict',
        bar='barfromenv',
        baz='bazfromenv',
    )
    os.environ['FOO'] = 'fromenv'
    os.environ['BAR'] = 'barfromenv'
    os.environ['BAZ'] = 'bazfromenv'
    no_log_

# Generated at 2022-06-22 21:51:42.886541
# Unit test for function sanitize_keys
def test_sanitize_keys():
    test_input = collections.OrderedDict()
    # OrderedDict will be converted to dict in the sanitize_keys function
    # and will not be able to recover its original order, so it is necessary
    # to generate a list to ensure that the result is sorted.
    test_list = []
    for i in range(0, 10):
        test_input['id_%s' % i] = 'id_value_%s' % i
        test_list.append('id_%s' % i)
    test_output = sanitize_keys(test_input, ['id'])
    assert isinstance(test_output, Mapping)
    assert len(test_output.keys()) == 10
    assert list(test_output.keys()) == test_list  # The order remains unchanged after the dictionary is processed.
   

# Generated at 2022-06-22 21:51:52.097692
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        param1=dict(fallback=(env_fallback, 'AMP_PARAM1')),
        param2=dict(fallback=(env_fallback, 'AMP_PARAM2')),
        param3=dict(fallback=(env_fallback, 'AMP_PARAM3')),
        param4=dict(fallback=(env_fallback, 'AMP_PARAM4', dict(fallback_value='default'))),
        param5=dict(fallback=(lambda: 'default'))
    )
    parameters = dict()
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['param1'] == 'value1'
    assert parameters['param2'] == 'value2'
    assert parameters['param3'] == 'value3'

# Generated at 2022-06-22 21:51:56.719094
# Unit test for function env_fallback
def test_env_fallback():
    """Unit test for env_fallback"""
    os.environ['FOO'] = 'bar'
    os.environ['BAZ'] = 'quux'
    assert env_fallback('FOO', 'BAZ') == 'quux'


# FIXME(a_tal): this function should just set the module.fail_json function

# Generated at 2022-06-22 21:52:01.586678
# Unit test for function env_fallback
def test_env_fallback():
    """Unittest for function env_fallback"""

    test_val = 'test_value'
    test_env_var = 'ANSIBLE_TEST_ENV_VAR'

    os.environ[test_env_var] = test_val
    assert env_fallback(test_env_var) == test_val
    del os.environ[test_env_var]



# Generated at 2022-06-22 21:52:08.705764
# Unit test for function remove_values
def test_remove_values():
    no_log_strings = [
        'c0n7@1n3r',
        'B4d5p4C3',
    ]
    # Test a few simple cases
    assert remove_values('c0n7@1n3r', no_log_strings) == ''
    assert remove_values('B4d5p4C3', no_log_strings) == 'd5'
    assert remove_values('Th1s 1s f1n3', no_log_strings) == 'Th1s 1s f1n3'

    # Test a container

# Generated at 2022-06-22 21:52:19.367920
# Unit test for function sanitize_keys
def test_sanitize_keys():
    obj={'_ansible_no_log':True,'_ansible_ignore':[]}
    new_obj = sanitize_keys(obj,[])
    assert(obj == new_obj)

    obj={'_ansible_no_log':True,'_ansible_ignore':[],'key1':{'key1_1':'value1_1','key1_2':{'key1_2_1':'value1_2_1'}}}
    new_obj = sanitize_keys(obj,[])
    assert(obj == new_obj)

    obj={'_ansible_no_log':True,'_ansible_ignore':[],'key1':'value1'}
    new_obj = sanitize_keys(obj,[])
    assert(obj == new_obj)


# Generated at 2022-06-22 21:52:28.809174
# Unit test for function sanitize_keys
def test_sanitize_keys():

    # Remove values from inner keys
    data = {'foo': 'bar', 'baz': 1}
    assert sanitize_keys(data, set('bar')) == data

    # Remove values from outer keys
    data = {'foo': 'bar', 'baz': 1}
    assert sanitize_keys(data, set('foo')) == {'xoo': 'bar', 'baz': 1}
    assert sanitize_keys(data, set('foo'), ignore_keys={'baz'}) == {'xoo': 'bar', 'baz': 1}

    # Remove values using multiple no_log strings
    data = {'foo': 'bar', 'baz': 1, 'bar': 'foo'}

# Generated at 2022-06-22 21:52:40.544971
# Unit test for function remove_values
def test_remove_values():
    assert remove_values('hello world', ['world']) == 'hello world'
    assert remove_values('hello worldworld', ['world']) == 'hello worldworld'

    for no_log_string in ['world', 'worldworld']:
        assert remove_values('hello worldworld', [no_log_string]) == 'hello '
        assert remove_values('hello\nworldworld', [no_log_string]) == 'hello\n'
        assert remove_values({'hello': 'worldworld'}, [no_log_string]) == {'hello': ''}
        assert remove_values(['hello', 'worldworld'], [no_log_string]) == ['hello', '']
        assert remove_values(['hello', {'world': 'worldworld'}], [no_log_string]) == ['hello', {'world': ''}]

# Generated at 2022-06-22 21:52:44.212650
# Unit test for function remove_values
def test_remove_values():
    assert remove_values({'a': 'x', 'b': 'x', 'c': 'y'}, ['x']) == {'c': 'y'}
    assert remove_values({'a': {'a': 'x', 'b': 'y'}, 'b': ['x', 'y']}, ['x']) == {'a': {'b': 'y'}, 'b': ['y']}
    assert remove_values({'a': {'a': 'x', 'b': 'y'}, 'b': ('x', 'y')}, ['x']) == {'a': {'b': 'y'}, 'b': ('y',)}



# Generated at 2022-06-22 21:52:52.959654
# Unit test for function sanitize_keys
def test_sanitize_keys():
    # test_default_params
    obj = {'foo': 'bar'}
    res = sanitize_keys(obj, ["foo"])
    assert res == {'foo': 'bar'}

    # test_ignore_keys
    obj = {'foo': 'bar'}
    res = sanitize_keys(obj, ["foo"], ignore_keys=frozenset(["foo"]))
    assert res == {'foo': 'bar'}

    # test_dict
    obj = {'foo': 'bar', 'foo_bar_baz': 'bar'}
    res = sanitize_keys(obj, ["foo"])
    assert res == {'bar': 'bar', 'bar_baz': 'bar'}

    # test_list

# Generated at 2022-06-22 21:53:00.989466
# Unit test for function remove_values
def test_remove_values():
    from ansible.utils.unsafe_proxy import wrap_var
    func = wrap_var(remove_values)
    assert func([1, 2, 3, 4], [2, 3, 5]) == [1, 4]
    assert func([1, {'b': 2, 'c': 3}, 4], [2, 3, 5]) == [1, {'b': None, 'c': None}, 4]
    assert func({'a': [{'b': 2, 'c': 3}, {'d': 4, 'e': 5}]}, [2, 3, 5]) == {'a': [{'b': None, 'c': None}, {'d': 4, 'e': None}]}
    assert func([1, [2, 3], 4], [2, 3, 5]) == [1, [], 4]
    assert func

# Generated at 2022-06-22 21:53:06.018907
# Unit test for function env_fallback
def test_env_fallback():
    assert os.environ['TEST_ENV'] == 'TEST_VALUE'
    assert env_fallback('TEST_ENV') == 'TEST_VALUE'
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('TEST_ENV2')
    del os.environ['TEST_ENV']



# Generated at 2022-06-22 21:53:13.177390
# Unit test for function remove_values
def test_remove_values():
    # test list
    target = [['admin', 'password'], [['admin', 'password'], ['admin', 'password'], [1, 2]], 'admin']
    remove_values(target, ['admin'])
    assert target == ['', [['', ''], ['', ''], [1, 2]], '']

    # test list inside list
    target = [['admin', 'password'], [['admin', 'password'], ['admin', 'password'], [1, 2]], 'admin']
    remove_values(target, ['admin'])
    assert target == ['', [['', ''], ['', ''], [1, 2]], '']

    # test tuples
    target = ([('admin', 'password'), ('admin', 'password'), 'admin'])
    remove_values(target, ['admin'])

# Generated at 2022-06-22 21:53:23.035202
# Unit test for function remove_values
def test_remove_values():
    ''' Test the remove_values function with conditions '''
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_native

    class DummyModule(AnsibleModule):
        def __init__(self, no_log=False, **kwargs):
            kwargs['argument_spec'] = {'value': dict(type='str', no_log=False)}
            super(DummyModule, self).__init__(**kwargs)

    class Test:
        def test(self):
            return dict(key='value', list=['ass', 'pass'], dict={'dict_key': 'dict_value', 'list': ['asdict_s', 'pass']})

    m = DummyModule()
    no_log_strings = ['ass', 'pass']
    value

# Generated at 2022-06-22 21:53:34.902742
# Unit test for function set_fallbacks

# Generated at 2022-06-22 21:53:42.861159
# Unit test for function remove_values
def test_remove_values():
    test_set = [
        'test_string',
        ['a', 'test_string', 'b'],
        {'test_dict': 'test_string'},
        {'test_dict': ['a', 'test_string', 'b']},
        {'test_dict': {'test_dict': 'test_string'}},
    ]
    assert remove_values(test_set, ['test_string']) == ['[REDACTED]', ['a', '[REDACTED]', 'b'], {'test_dict': '[REDACTED]'}, {'test_dict': ['a', '[REDACTED]', 'b']}, {'test_dict': {'test_dict': '[REDACTED]'}}]
    assert remove_values('test string', ['test_string']) == 'test string'

# Generated at 2022-06-22 21:53:53.911804
# Unit test for function sanitize_keys
def test_sanitize_keys():
    # old_value is a test data structure containing single key/value pair
    # new_value is a test data structure with single key/value pair after sanitization
    old_value = {'key_ansible_test': 'secret_value'}
    no_log_strings = ['secret']
    ignore_keys = set()
    new_value = sanitize_keys(old_value, no_log_strings, ignore_keys)
    assert new_value == {'key': 'secret_value'}
    # old_value is a test data structure containing multiple key/value pairs
    # new_value is a test data structure with multiple key/value pairs after sanitization
    old_value = {'key_ansible_test': 'secret_value', 'key1': 'value1', 'key2': 'value2'}
    no_

# Generated at 2022-06-22 21:53:59.817411
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert set_fallbacks({'test_str': {'type': 'str', 'fallback': [env_fallback, ['test_str']]},
                          'test_dict': {'type': 'str', 'fallback': [env_fallback, [{'bla': 'test_dict'}]]},
                          'test_two': {'type': 'str', 'fallback': [env_fallback, ['one', 'two']]}},
                         {}) == {'test_value'}



# Generated at 2022-06-22 21:54:10.141956
# Unit test for function sanitize_keys
def test_sanitize_keys():

    assert sanitize_keys({'foo': 'bar'}, ['bar']) == {'foo': '***'}
    assert sanitize_keys({'foo': 'bar'}, ignore_keys=('foo',)) == {'foo': 'bar'}
    assert sanitize_keys({'foo': 'bar'}, None) == {'foo': 'bar'}
    assert sanitize_keys({'foo': 'bar'}, []) == {'foo': 'bar'}
    assert sanitize_keys('foo', ['foo']) == '***'
    assert sanitize_keys({'foo': ['bar', 'baz']}, ['bar']) == {'foo': ['***', 'baz']}

# Generated at 2022-06-22 21:54:20.324666
# Unit test for function remove_values

# Generated at 2022-06-22 21:54:24.664195
# Unit test for function env_fallback
def test_env_fallback():
    os.environ = env = {"ANSIBLE_DEBUG" : "True"}
    assert env_fallback('ANSIBLE_DEBUG') == "True"
    assert env_fallback('ANSIBLE_HOST') == "None"


# Generated at 2022-06-22 21:54:36.082979
# Unit test for function set_fallbacks
def test_set_fallbacks():

    # Test the base case with a valid value
    argument_spec = {'test_param': {}}
    test_params = {'test_param': 'valid'}
    try:
        set_fallbacks(argument_spec, test_params)
    except TypeError as e:
        assert_equal(str(e), '')
    else:
        assert_equal(test_params['test_param'], 'valid')

    # Test the base case with no valid value
    argument_spec = {'test_param': {}}
    test_params = {}
    try:
        set_fallbacks(argument_spec, test_params)
    except TypeError as e:
        assert_equal(str(e), '')
    else:
        assert_equal(test_params['test_param'], None)

    # Test with a

# Generated at 2022-06-22 21:54:44.598786
# Unit test for function remove_values
def test_remove_values():

    test_cases = [
        # no_log_str, value, expected_output
        ['token_password', 'password123', 'REDACTED'],
        ['token_password', {'password': 'password123'}, {'password': 'REDACTED'}],
        ['token_password', 'mypassword', 'mypassword'],
        ['token_password', '', ''],
    ]

    for test_case in test_cases:
        no_log_strings, value, expected_output = test_case
        assert remove_values(value, no_log_strings) == expected_output



# Generated at 2022-06-22 21:54:51.441870
# Unit test for function env_fallback
def test_env_fallback():
    with patch.dict(os.environ, {'FOO': 'foo'}):
        assert env_fallback("FOO") == 'foo'
        assert env_fallback("BAR") == 'foo'
    with patch.dict(os.environ, {'FOO': 'foo', 'BAR': 'bar'}):
        assert env_fallback("BAR") == 'bar'
    with patch.dict(os.environ, {}):
        assert env_fallback("FOO") == 'foo'



# Generated at 2022-06-22 21:54:59.765749
# Unit test for function env_fallback
def test_env_fallback():
    ''' test functionality of env_fallback '''
    os.environ['MY_ENV'] = 'xyz123'

    # test if env_fallback function is not raising exception
    assert env_fallback('MY_ENV') == 'xyz123'

    # test if env_fallback function is raising proper exception
    with pytest.raises(AnsibleFallbackNotFound) as excinfo:
        env_fallback('SOME_ENV')

    assert 'SOME_ENV' in str(excinfo.value)

# Generated at 2022-06-22 21:55:12.683434
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        ansible_user=dict(type='str', fallback=(env_fallback, 'ANSIBLE_NET_USERNAME')),
        ansible_password=dict(type='str', fallback=(env_fallback, 'ANSIBLE_NET_PASSWORD')),
        test_key=dict(type='int', fallback=(env_fallback, 'ANSIBLE_TEST_KEY'))
    )
    parameters = dict()
    no_log_values = dict()
    set_fallbacks(argument_spec, parameters)
    assert parameters['ansible_user'] == 'ANSIBLE_NET_USERNAME'
    assert parameters['ansible_password'] == 'ANSIBLE_NET_PASSWORD'
    assert 'test_key' not in parameters

    assert parameters['ansible_user'] in no_log_

# Generated at 2022-06-22 21:55:21.477778
# Unit test for function set_fallbacks
def test_set_fallbacks():
    spec = dict(name=dict(required=True, type='str', no_log=True),
                password=dict(type='str', no_log=True),
                secret=dict(type='str', no_log=True, fallback=(env_fallback, ['MY_SECRET', 'SECRET'])),
                client_cert=dict(type='path', no_log=True, fallback=(env_fallback, 'CLIENT_CERT_FILE')))
    parameters = {}
    no_log_values = set_fallbacks(spec, parameters)
    assert parameters == dict()
    assert no_log_values == set()
    parameters = dict(name='bob', client_cert='/etc/ssl/certs/client.pem')
    no_log_values = set_fallbacks(spec, parameters)

# Generated at 2022-06-22 21:55:32.838353
# Unit test for function remove_values
def test_remove_values():
    assert remove_values({'k1': 'v1','k2': 'v2','k3': 'v3'},['v1','v2']) == {'k1': 'PRIVATE DATA HIDDEN','k2': 'PRIVATE DATA HIDDEN','k3': 'v3'}
    assert remove_values({'k1': 'v1','k2': 'v2','k3': 'v3'},['v1','v2','123']) == {'k1': 'PRIVATE DATA HIDDEN','k2': 'PRIVATE DATA HIDDEN','k3': 'v3'}

# Generated at 2022-06-22 21:55:37.279762
# Unit test for function env_fallback
def test_env_fallback():
    for arg in ("ANSIBLE_FOO", "ANSIBLE_BAR"):
        os.environ[arg] = arg
    assert env_fallback("ANSIBLE_FOO", "ANSIBLE_BAR") == "ANSIBLE_FOO"
    del os.environ["ANSIBLE_FOO"]
    assert env_fallback("ANSIBLE_FOO", "ANSIBLE_BAR") == "ANSIBLE_BAR"



# Generated at 2022-06-22 21:55:42.890887
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['TEST_ENV'] = 'True'
    assert env_fallback('TEST_ENV') == 'True'
    assert env_fallback('TEST_ENV', 'TEST_ENV') == 'True'
    assert env_fallback('TEST_ENV', 'TEST_ENV1', 'TEST_ENV2') == 'True'
    del os.environ['TEST_ENV']
    try:
        env_fallback('TEST_ENV')
    except AnsibleFallbackNotFound:
        pass
    try:
        env_fallback('TEST_ENV1', 'TEST_ENV2')
    except AnsibleFallbackNotFound:
        pass

# Generated at 2022-06-22 21:55:52.759610
# Unit test for function remove_values
def test_remove_values():
    """Unit test for function remove_values"""

    # Test with value of only a no_log_string
    result = remove_values("foo", ["foo"])
    assert "value has been hidden" == result

    # Test with value not in no_log_strings
    result = remove_values("foo", ["bar"])
    assert "foo" == result

    # Test with value of a container
    result = remove_values(["bar", ["foo", "baz"], "foo"], ["foo"])
    assert ["bar", ["value has been hidden", "baz"], "value has been hidden"] == result



# Generated at 2022-06-22 21:55:56.112564
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('TEST_VALUE') == os.environ['TEST_VALUE']
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('TEST_VALUE2')



# Generated at 2022-06-22 21:56:03.905062
# Unit test for function env_fallback
def test_env_fallback():
    with mock.patch('os.environ') as mock_env:
        mock_env.get.return_value = 'bar'
        assert env_fallback('foo') == 'bar'
        mock_env.get.assert_called_with('foo')
        mock_env.get.return_value = None
        assert env_fallback('foo') == 'bar'
        assert env_fallback('foo', 'bar') == 'bar'
        assert env_fallback('foo', 'bar') == 'bar'
        assert env_fallback('foo') == 'bar'
        assert env_fallback('foo', default='bar') == 'bar'
        mock_env.get.assert_called_with('foo')
        assert env_fallback('foo', default=None) is None
        mock_env.get.assert_called_with

# Generated at 2022-06-22 21:56:15.140591
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys('spiderman', {'spiderman'}) == u''
    assert sanitize_keys(dict(foo='spiderman', bar='superman'), {'spiderman'}) == dict(foo='', bar='superman')
    assert sanitize_keys(dict(foospiderman='spiderman', barsuperman='superman'), {'spiderman'}) == dict(foospiderman='', barsuperman='superman')
    assert sanitize_keys(dict(foo=dict(bar='spiderman', baz='superman'), qux='spiderman'), {'spiderman'}) == dict(foo=dict(bar='', baz='superman'), qux='')

# Generated at 2022-06-22 21:56:25.585442
# Unit test for function set_fallbacks

# Generated at 2022-06-22 21:56:36.596421
# Unit test for function set_fallbacks
def test_set_fallbacks():
    fallback_spec = dict(
        parameter1=dict(fallback=(env_fallback, 'PARAM1')),
        parameter2=dict(fallback=(env_fallback, 'PARAM2')),
        parameter3=dict(fallback=(env_fallback, 'PARAM3')),
        parameter4=dict(fallback=(env_fallback, 'PARAM4')),
    )
    parameters = dict(parameter1='Value1', parameter2='Value2')
    os.environ['PARAM3'] = 'Value3'
    os.environ['PARAM4'] = 'Value4'

    expected_result = dict(parameter1='Value1', parameter2='Value2', parameter3='Value3', parameter4='Value4')


# Generated at 2022-06-22 21:56:48.184467
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert set_fallbacks({'a': {'type': 'str', 'fallback': (env_fallback, ['FOO'])}}, {'b': 'c'}) == set()
    assert set_fallbacks({'a': {'type': 'str', 'fallback': (env_fallback, ['FOO'])}}, {}) == set()
    assert set_fallbacks({'a': {'type': 'str', 'fallback': (env_fallback, ['FOO'])}}, {'a': 'd'}) == set()
    assert set_fallbacks({'a': {'type': 'str', 'fallback': (env_fallback, ['FOO'])}}, {'a': ''}) == set()

    os.environ['FOO'] = ''

# Generated at 2022-06-22 21:56:58.284739
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'param1': {'type': 'str', 'fallback': (env_fallback, ['param1', 'PARAM1'])}}
    parameters = {}
    got_no_log_values = set_fallbacks(argument_spec, parameters)
    assert(isinstance(got_no_log_values, set))
    assert(0 == len(got_no_log_values))
    assert(parameters.get('param1') is None)
    os.environ['param1'] = 'param1_from_env'
    got_no_log_values = set_fallbacks(argument_spec, parameters)
    assert(isinstance(got_no_log_values, set))
    assert(1 == len(got_no_log_values))

# Generated at 2022-06-22 21:57:09.677961
# Unit test for function set_fallbacks
def test_set_fallbacks():
    def load_from_file(path):
        try:
            with open(path, 'r') as f:
                return f.read().strip()
        except IOError:
            raise AnsibleFallbackNotFound

    argument_spec1 = {
        'param1': {
            'type': 'str',
            'fallback': (env_fallback, 'TEST_ENV_PARAM')
        },
        'param2': {
            'type': 'str',
            'fallback': (load_from_file, '/tmp/test')
        }
    }

    parameters1 = {
        'param1': 'param1'
    }

    no_log_values = set_fallbacks(argument_spec1, parameters1)

# Generated at 2022-06-22 21:57:16.825230
# Unit test for function sanitize_keys
def test_sanitize_keys():
    data = [1, 2, 3, 4]
    assert [1, 2, 3, 4] == sanitize_keys(data, set())

    data = [1, 2, 3, 4]
    assert [1, 2, 3, 4] == sanitize_keys(data, set())

    data = {'red': 'fish', 'blue': 'fish', 'green': 'fish'}
    assert {'red': 'fish', 'blue': 'fish', 'green': 'fish'} == sanitize_keys(data, set())

    data = {'red': 'fish', 'blue': 'fish', 'green': 'fish'}
    assert {'red': 'fish', 'blue': 'fish', 'green': 'fish'} == sanitize_keys(data, set())



# Generated at 2022-06-22 21:57:20.411412
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('HOME') == os.environ['HOME']
    try:
        env_fallback('HOME1')
        assert False
    except AnsibleFallbackNotFound:
        assert True



# Generated at 2022-06-22 21:57:22.204531
# Unit test for function env_fallback
def test_env_fallback():
    with patch.dict(os.environ, {"TEST_param": "TEST"}):
        assert env_fallback("TEST_param") == "TEST"



# Generated at 2022-06-22 21:57:32.073834
# Unit test for function set_fallbacks
def test_set_fallbacks():
    param = dict(param1 = 'test_value')
    spec = dict(param1 = dict(type = 'str', fallback = (env_fallback, 'TEST_ENV')))
    no_log_vals = set_fallbacks(spec, param)
    assert param['param1'] == 'test_value'
    assert len(no_log_vals) == 0

    os.environ['TEST_ENV'] = 'test_env_value'
    param = dict(param1 = 'test_value')
    spec = dict(param1 = dict(type = 'str', fallback = (env_fallback, 'TEST_ENV')))
    no_log_vals = set_fallbacks(spec, param)
    assert param['param1'] == 'test_env_value'

# Generated at 2022-06-22 21:57:43.743179
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'vpc_id': dict(fallback=(env_fallback, ['vpc_id']))
    }
    parameters = {
    }
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert 'vpc_id' in parameters
    assert no_log_values == set()

    os.environ['vpc_id'] = 'vpc-123456'
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['vpc_id'] == 'vpc-123456'
    assert no_log_values == set()

    del os.environ['vpc_id']
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert 'vpc_id' not in parameters
    assert no

# Generated at 2022-06-22 21:57:51.171735
# Unit test for function env_fallback
def test_env_fallback():
    assert os.environ['PATH'] == env_fallback('PATH')
    assert 'PATH' not in os.environ
    assert os.environ.pop('PATH') == env_fallback('PATH')
    assert 'PATH' not in os.environ
    try:
        env_fallback('foo')
    except AnsibleFallbackNotFound:
        pass
    else:
        raise Exception('env_fallback() did not raise AnsibleFallbackNotFound')



# Generated at 2022-06-22 21:58:02.388455
# Unit test for function remove_values
def test_remove_values():
    no_log_strings = ['secret', 'password', 'passwd']

# Generated at 2022-06-22 21:58:13.542483
# Unit test for function sanitize_keys
def test_sanitize_keys():
    test_data = {
        'no_log_dict': {
            'password' : 'foo',
            'other' : 'bar'
        },
        'log_dict' : {
            'nothing_to_sanitize': 'baz',
            'no_log_dict_protected': {
                'password' : 'foo',
                'id': 'bar'
            },
            'no_log_list_protected': [
                'foo',
                'bar'
            ]
        },
        'no_log_list': [
            {'password': 'foo', 'id': 'bar'},
            {'password': 'baz', 'id': 'qux'}
        ]
    }
    ignore_keys = frozenset()
    no_log_strings = {'password'}

    # This should

# Generated at 2022-06-22 21:58:18.763226
# Unit test for function remove_values
def test_remove_values():
    """
    Remove strings in ``no_log_strings`` from value.
    If value is a container type, then remove a lot more.
    """
    no_log_strings = ['password', 'secret']
    expected = dict(password='password', secret='secret')
    result = remove_values(expected, no_log_strings)
    assert result == {}

# Generated at 2022-06-22 21:58:27.417838
# Unit test for function sanitize_keys
def test_sanitize_keys():
    """
    Test function to see if sanitize_keys works properly.
    """
    assert sanitize_keys('This is a string', set()) == 'This is a string'
    assert sanitize_keys({'super_secret_key': 'super_secret_value'}, set()) \
        == {'super_secret_key': 'super_secret_value'}
    assert sanitize_keys({'super_secret_key': 'super_secret_value'}, {'super_secret_value'}) \
        == {'<redacted>': '<redacted>'}

# Generated at 2022-06-22 21:58:31.964278
# Unit test for function env_fallback
def test_env_fallback():
    env_var = 'FOO'
    value = 'bar'
    os.environ[env_var] = value
    assert env_fallback(env_var) == value
    assert env_fallback(env_var, 'bar') == value



# Generated at 2022-06-22 21:58:42.378533
# Unit test for function set_fallbacks

# Generated at 2022-06-22 21:58:51.631572
# Unit test for function sanitize_keys
def test_sanitize_keys():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_text

    def run_module():

        # This is the minimum skeleton for an AnsibleModule,
        # with the argspec defined in our test module 'test_arg_spec.py'.
        # The rest of the module's implementation is the same as the old
        # style module.
        module = AnsibleModule(
            argument_spec=dict(
                param1=dict(),
            ),
            supports_check_mode=True,
        )

        # The rest of our test code is as we would write it in a legacy module.
        result = dict(
            changed=False,
            param1=module.params['param1'],
        )

        module.exit_json(**result)


# Generated at 2022-06-22 21:59:00.123779
# Unit test for function set_fallbacks
def test_set_fallbacks():
    params = {'arg1': 1, 'arg2': 'test'}
    ansible_vars = {'var1': 'val1', 'var2': 'val2'}
    host_vars = {'host_var1': 'host_val1', 'host_var2': 'host_val2'}

    def _my_fallback(arg1, arg2):
        if arg1 == 'var1' and arg2 == 'test':
            return 'val1'
        else:
            raise AnsibleFallbackNotFound

    def _my_fallback_kwargs(arg1, arg2, kwargs=None):
        if arg1 == 'var1' and arg2 == 'test' and kwargs == 'val2':
            return 'val1'
        else:
            raise AnsibleFallbackNotFound

# Generated at 2022-06-22 21:59:06.952177
# Unit test for function sanitize_keys
def test_sanitize_keys():
    ignore_keys = frozenset(['_ansible_no_log'])
    no_log_strings = set()


# Generated at 2022-06-22 21:59:17.765746
# Unit test for function remove_values
def test_remove_values():
    # test start
    no_log_values = [
        "hudson.model.PasswordParameterDefinition._value",
        "password",
        "king",
        "david",
        "pass",
        "secret",
        "pwd",
        "mysql_pass",
        "mysqlroot",
        "mysql_root",
        "ssh_pass",
        "f5_password",
        "fortinet_ssh_password",
        "fortigate_ssh_password",
        "microfocus_ssh_password",
        "passwd",
        "changed",
        "invocation",
        "log",
        "results",
    ]

# Generated at 2022-06-22 21:59:28.617106
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys('a string', {'sensitive'}) == 'a string'
    assert sanitize_keys(1, {'sensitive'}) == 1
    assert sanitize_keys({'a sensitive key': 'value'}, {'sensitive'}) == {'a <PRIVATE> key': 'value'}
    assert sanitize_keys({'a sensitive key': 'value', 'a normal key': 'other value'}, {'sensitive'}) == {'a <PRIVATE> key': 'value', 'a normal key': 'other value'}
    assert sanitize_keys({'a sensitive key': 'value', 'sensitive': 'other value'}, {'sensitive'}) == {'a <PRIVATE> key': 'value', 'sensitive': 'other value'}

# Generated at 2022-06-22 21:59:36.098485
# Unit test for function env_fallback
def test_env_fallback():
    with mock.patch('ansible.module_utils.common._ANSIBLE_ARGS', new_callable=mock.PropertyMock) as mock_ansible_args:
        mock_ansible_args.return_value = dict(private=dict(env_test='BAR', env='FOO'))
        assert env_fallback('FOO', 'BAR') == 'BAR'
        assert env_fallback('FOO', 'BAZ') == 'FOO'



# Generated at 2022-06-22 21:59:44.525684
# Unit test for function remove_values
def test_remove_values():
    """
    Test to ensure remove_values removes all strings marked no_log

    Test to ensure remove_values that there is
    no disruption to the original structure of the data.
    """

    data = {
        'foo': 'elitech',
        'bar': {'password': 'drowssap', 'login': 'elitech'},
        'baz': ['elitech']
    }

    no_log = {'drowssap'}

    data = remove_values(data, no_log)

    assert data == {
        'foo': 'elitech',
        'bar': {'password': '****', 'login': 'elitech'},
        'baz': ['elitech']
    }



# Generated at 2022-06-22 21:59:55.458799
# Unit test for function env_fallback
def test_env_fallback():
    if 'ANSIBLE_NET_USERNAME' in os.environ:
        ANSIBLE_NET_USERNAME = os.environ['ANSIBLE_NET_USERNAME']
    else:
        ANSIBLE_NET_USERNAME = 'no_username_set'
    if 'ANSIBLE_NET_PASSWORD' in os.environ:
        ANSIBLE_NET_PASSWORD = os.environ['ANSIBLE_NET_PASSWORD']
    else:
        ANSIBLE_NET_PASSWORD = 'no_password_set'
    try:
        env_username = env_fallback('ANSIBLE_NET_USERNAME')
    except AnsibleFallbackNotFound:
        env_username = 'no_username_set'

# Generated at 2022-06-22 22:00:03.613919
# Unit test for function set_fallbacks
def test_set_fallbacks():
    module_args = {}
    spec = {
        'aaa': {
            'type': 'str',
            'default': 'a',
            'fallback': (env_fallback, ['AAA'])
        },
        'bbb': {
            'type': 'str'
        },
        'ccc': {
            'type': 'str',
            'fallback': (env_fallback, ['CCC'])
        },
        'ddd': {
            'type': 'str',
            'default': 'd',
            'fallback': (False,)
        }
    }
    parameters = {}
    assert set_fallbacks(spec, parameters) == set()
    assert parameters == {'aaa': 'a'}

    module_args = {'aaa': 'aaa'}

# Generated at 2022-06-22 22:00:13.831852
# Unit test for function remove_values
def test_remove_values():
    # create a list of strings for the test
    strings = []
    for i in range(0,1000):
        strings.append('string #%d' % i)
    # create a nested list with the strings
    nestedlist = []
    for i in range(0,100):
        temp = []
        for j in range(0,10):
            temp.append(strings[i*j])
        nestedlist.append(temp)
    # create a nested dictionary with the strings
    nesteddict = {}
    start = 0
    end = len(strings)
    while start < end:
        nesteddict[strings[start]] = strings[start+1]
        start += 2
    # test the remove_values function on a nested list, a nested dictionary and a string
    assert remove_values(nestedlist,strings) == '***'


# Generated at 2022-06-22 22:00:24.903929
# Unit test for function set_fallbacks
def test_set_fallbacks():
    """
    Test set_fallbacks
    """
    module_argument_spec = dict(
        test_simple_fallback=dict(fallback=(env_fallback, 'TEST1')),
        test_fallback_with_args=dict(fallback=(env_fallback, dict(fallback1='TEST2', fallback2='TEST3'))),
        test_fallback_with_args_and_kwargs=dict(fallback=(env_fallback, dict(fallback1='TEST2'), dict(fallback2='TEST3'))),
    )

    options = dict()
    no_log_values = set_fallbacks(module_argument_spec, options)

    assert options.get('test_simple_fallback') == os.getenv('TEST1')

# Generated at 2022-06-22 22:00:27.589991
# Unit test for function env_fallback
def test_env_fallback():
    errors = AnsibleFallbackNotFound()
    return env_fallback(errors)

# Generated at 2022-06-22 22:00:34.840873
# Unit test for function set_fallbacks
def test_set_fallbacks():
    parameters = dict()
    argument_spec = dict(
        host=dict(type='str', fallback=(env_fallback, ['GATEWAY_IP'])),
        password=dict(type='str', no_log=True, fallback=(env_fallback, ['PASSWORD'])),
    )
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters == dict(host='127.0.0.1', password=None), parameters
    assert no_log_values == set(), no_log_values



# Generated at 2022-06-22 22:00:46.212522
# Unit test for function set_fallbacks
def test_set_fallbacks():
    def myfallback(*args, **kwargs):
        """Load value from environment variable"""
        return 'default'

    # Standard fallback
    assert set_fallbacks({'a': {'fallback': (env_fallback, 'a', 'b', 'c')}}, {}) == set()
    assert set_fallbacks({'a': {'fallback': (env_fallback, 'a', 'b', 'c')}}, {'a': 'foo'}) == set()
    assert set_fallbacks({'a': {'fallback': (env_fallback, 'a', 'b', 'c')}}, {'b': 'foo'}) == set()

# Generated at 2022-06-22 22:00:49.600706
# Unit test for function env_fallback
def test_env_fallback():
    with patch('os.environ', {'FOO': 'bar'}), patch('os.environ', clear=True):
        assert env_fallback('FOO') == 'bar'
        assert env_fallback('BAR') is None


# Generated at 2022-06-22 22:00:56.491513
# Unit test for function env_fallback
def test_env_fallback():
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('ANSIBLE_THIS_IS_NOT_AN_ENV_VAR')
    os.environ['ANSIBLE_THIS_IS_AN_ENV_VAR'] = '1'
    assert env_fallback('ANSIBLE_THIS_IS_AN_ENV_VAR') == '1'



# Generated at 2022-06-22 22:01:06.478944
# Unit test for function remove_values
def test_remove_values():
    """Testing remove_values."""
    import json

    no_log_data = 'HIDDEN_DATA'
    string_data = 'data'
    list_data = ['data', no_log_data]
    dict_data = {'data': string_data, 'data_to_hide': no_log_data}

# Generated at 2022-06-22 22:01:13.067942
# Unit test for function set_fallbacks

# Generated at 2022-06-22 22:01:22.938698
# Unit test for function remove_values
def test_remove_values():
    import json
    inp = json.loads('''{"foo": ["bar", ["baz", {"x": "zzz", "y": ["qaz", "qwe"]}]]}''')
    no_log_strings = ['zzz', 'qaz']
    out = json.loads('''{"foo": ["bar", ["baz", {"x": "VALUE_SPECIFIED_IN_NO_LOG_PARAMETER", "y": ["VALUE_SPECIFIED_IN_NO_LOG_PARAMETER", "qwe"]}]]}''')
    assert remove_values(inp, no_log_strings) == out

