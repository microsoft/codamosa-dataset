

# Generated at 2022-06-22 21:51:17.307608
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys({'secret-password': 'hunter2'}, set(['hunter2'])) == {'secret-x-x-x-x-x': 'hunter2'}



# Generated at 2022-06-22 21:51:24.845772
# Unit test for function remove_values
def test_remove_values():
    import copy
    import json

# Generated at 2022-06-22 21:51:30.520642
# Unit test for function sanitize_keys
def test_sanitize_keys():
    # Test simple cases
    test_data = {
        'a': 'b',
        'yes': 'no',
        'hello': 'world',
        '_ansible_no_log': True,
        '_ansible_verbose_always': True,
    }
    expected_data = {
        'a': 'b',
        'no': 'world',
        'hello': 'world',
        '_ansible_no_log': True,
        '_ansible_verbose_always': True,
    }
    no_log_values = {'yes'}
    ignore_keys = {'_ansible_no_log', '_ansible_verbose_always'}
    new_data = sanitize_keys(test_data, no_log_values, ignore_keys)
    assert new_data

# Generated at 2022-06-22 21:51:34.164180
# Unit test for function sanitize_keys
def test_sanitize_keys():
    fail = {"username": "testuser", "password": "mypass", "SSH_PRIVATE_KEY": "value1"}
    pass_ = {"username": "testuser", "password": "mypass"}
    assert sanitize_keys(fail, ["mypass"]) == pass_


# Generated at 2022-06-22 21:51:43.051391
# Unit test for function remove_values
def test_remove_values():
    '''
    Remove the password on the ansible output
    '''

# Generated at 2022-06-22 21:51:52.224194
# Unit test for function remove_values

# Generated at 2022-06-22 21:52:01.734996
# Unit test for function remove_values
def test_remove_values():
    from collections import namedtuple

    # Data to test against
    no_log_strings = frozenset(['password=bar', 'foo'])


# Generated at 2022-06-22 21:52:08.804542
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'some_param': {'type': 'str', 'fallback': (env_fallback, 'SOME_PARAM')},
        'some_other_param': {'type': 'str', 'fallback': (env_fallback, 'SOME_OTHER_PARAM')},
        'some_param_no_log': {'type': 'str', 'fallback': (env_fallback, 'SOME_PARAM_NO_LOG'), 'no_log': True},
    }
    if 'SOME_PARAM' in os.environ:
        del os.environ['SOME_PARAM']
    if 'SOME_OTHER_PARAM' in os.environ:
        del os.environ['SOME_OTHER_PARAM']

# Generated at 2022-06-22 21:52:19.408889
# Unit test for function sanitize_keys

# Generated at 2022-06-22 21:52:22.868984
# Unit test for function set_fallbacks
def test_set_fallbacks():
    args = dict(parameter = dict(required = True, fallback = (env_fallback, 'PARAMETER_ENV')))
    parameters = dict()
    parameters = set_fallbacks(args, parameters)
    assert 'parameter' in parameters
    assert parameters['parameter'] == os.environ['PARAMETER_ENV']



# Generated at 2022-06-22 21:52:30.576510
# Unit test for function sanitize_keys
def test_sanitize_keys():

    no_log_strings = frozenset(['SECRET', 'PASSWORD'])

    dict_playbook_data = dict(
        port=dict(
            password='SECRET',
            host='HOST',
            user='USER',
        ),
        password='SECRET',
        user='USER'
    )

    list_playbook_data = [dict(
        port=dict(
            password='SECRET',
            host='HOST',
            user='USER',
        ),
        password='SECRET',
        user='USER'
    )]

    tuple_playbook_data = (
        dict(
            port=dict(
                password='SECRET',
                host='HOST',
                user='USER',
            ),
            password='SECRET',
            user='USER'
        ),
    )

    list

# Generated at 2022-06-22 21:52:41.359884
# Unit test for function set_fallbacks

# Generated at 2022-06-22 21:52:48.104427
# Unit test for function env_fallback
def test_env_fallback():

    mock_environ = {
        'ANSIBLE_NET_USERNAME': 'foo',
        'ANSIBLE_NET_AUTH_PASS': 'bar',
    }


# Generated at 2022-06-22 21:52:55.039292
# Unit test for function set_fallbacks
def test_set_fallbacks():
    required_spec = dict(
        param1=dict(type='str', required=True),
        param2=dict(type='str', fallback=(env_fallback, 'PARM2')),
        param3=dict(type='str', fallback=(env_fallback, 'PARM3')),
        param4=dict(type='str', fallback=(env_fallback, 'PARM5', 'PARM6'), no_log=True),
        param5=dict(type='str', fallback=(env_fallback, ['PARM5', 'PARM6'], {'fallback1': 'PARM7'})),
    )

    # Test fallback for two params
    parameters = dict(param1='val1')
    params_with_fallback = set_fallbacks(required_spec, parameters)


# Generated at 2022-06-22 21:53:05.769449
# Unit test for function sanitize_keys
def test_sanitize_keys():
    testobj = {}

    # Test that non sequence/mapping objects are returned unchanged
    assert sanitize_keys(None) is None
    assert sanitize_keys(1) == 1
    assert sanitize_keys("test") == "test"

    # Test that if we have a mapping where no keys will be removed we end up with the same object
    testobj = {'test': 'test'}
    new_testobj = sanitize_keys(testobj, no_log_strings=['secret'])
    assert testobj == new_testobj
    assert testobj is new_testobj

    # Test that when a key is removed we get a copy back
    testobj = {'test': 'test', 'secret': 'secret'}

# Generated at 2022-06-22 21:53:13.849922
# Unit test for function sanitize_keys
def test_sanitize_keys():
    #pylint: disable=too-many-locals
    """Tests as to whether module's sanitize keys function is working correctly
    """

    def assert_func(before, after, no_log_strings=[]):
        """Function to assure that given 'before' and 'no_log_strings' result in 'after'
       """
        no_log_strings = ([to_native(s, errors='surrogate_or_strict') for s in no_log_strings]
                          if no_log_strings else None)
        sanitized = sanitize_keys(before, no_log_strings)
        assert sanitized == after


# Generated at 2022-06-22 21:53:23.468691
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        foo=dict(fallback=('env', 'FOO')),
        bar=dict(fallback=(lambda x: 'y', 1)),
        default=dict(type='str', default='test'),
        no_log=dict(type='str', no_log=True, fallback=('env', 'SECRET_MESSAGE'), default='hello'),
    )

    parameters = dict(
        foo='foo',
        bar='bar',
    )

    expected_params = dict(
        foo='foo',
        bar='bar',
        default='test',
        no_log='secret',
    )

    # start with an empty environment
    environ = dict(os.environ)
    os.environ.clear()

# Generated at 2022-06-22 21:53:26.317714
# Unit test for function env_fallback
def test_env_fallback():
    """Test env_fallback"""
    # Not sure how to test this, but at least test that it returns something
    if len(env_fallback('foo')) > 0:
        pass



# Generated at 2022-06-22 21:53:33.263978
# Unit test for function sanitize_keys
def test_sanitize_keys():
    """Validate behaviour of sanitize_keys function"""


# Generated at 2022-06-22 21:53:47.291823
# Unit test for function sanitize_keys
def test_sanitize_keys():
    no_log_strings = set()

    obj = dict(foo=42)
    new_value = sanitize_keys(obj, no_log_strings)
    assert obj == new_value

    obj = dict(foo=dict(bar=42))
    new_value = sanitize_keys(obj, no_log_strings)
    assert obj == new_value

    obj = dict(foo=dict(bar=42,__bar=42))
    new_value = sanitize_keys(obj, no_log_strings)
    assert obj == new_value

    obj = dict(foo=dict(bar=42,__bar=42), __bar=42)
    no_log_strings.add('__bar')
    new_value = sanitize_keys(obj, no_log_strings)

# Generated at 2022-06-22 21:53:57.084231
# Unit test for function sanitize_keys
def test_sanitize_keys():
    class PrivateData(object):
        def __init__(self, data=None, private=False):
            self.data = data
            self.private = private

        def __getitem__(self, key):
            if self.private:
                if isinstance(key, string_types):
                    return PrivateData(key, private=True)
                else:
                    raise TypeError('Key must be a string type')
            else:
                return self.data.__getitem__(key)

        def __setitem__(self, key, value):
            if self.private:
                raise AttributeError('PrivateData object has no attribute __setitem__')
            else:
                return self.data.__setitem__(key, value)

        def __delitem__(self, key):
            if self.private:
                raise Attribute

# Generated at 2022-06-22 21:54:05.673150
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys("lastpass", {'ansible', 'ansible-lastpass'}) == "lastpass"
    assert sanitize_keys({'lastpass': 'ansible', 'last_pass': 'ansible-lastpass'}, {'ansible', 'ansible-lastpass'}) == {'lastpass': 'ansible', 'last_pass': 'ansible-lastpass'}
    assert sanitize_keys({'lastpass': 'ansible', 'last_pass': 'ansible-lastpass'}, {'ansible-lastpass'}, ignore_keys={'lastpass'}) == {'lastpass': 'ansible', 'last_pass': '**********'}

# Generated at 2022-06-22 21:54:18.295455
# Unit test for function set_fallbacks
def test_set_fallbacks():
    spec = dict(
        bool_=dict(type='bool'),
        dict_=dict(type='dict'),
        env_=dict(type='str', fallback=(env_fallback, 'ANSIBLE_TEST_ENV', 'ANSIBLE_TEST_ENV_SECOND_CHOICE', {'fallback_var': 'ANSIBLE_TEST_ENV_DICT_FALLBACK'})),
    )

    parameters = dict(
        string_='foo',
    )

    assert set_fallbacks(spec, parameters) == set()
    assert parameters == dict(
        bool_=False,
        dict_={},
        env_=None,
        string_='foo',
    )

    os.environ['ANSIBLE_TEST_ENV'] = 'bar'

# Generated at 2022-06-22 21:54:24.004660
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # test without fallback
    argument_spec = dict(
        name=dict(required=True),
        age=dict(),
        state=dict(default='present'),
    )
    parameters = dict(name='test_name')
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert list(no_log_values) == []
    assert parameters == dict(name='test_name', state='present')
    # test with fallback
    argument_spec = dict(
        name=dict(required=True, fallback=('env_fallback', 'NAME')),
        age=dict(),
        state=dict(default='present'),
    )
    parameters = dict(name='test_name')
    os.environ['NAME'] = 'env_name'
    no_log_values = set_fall

# Generated at 2022-06-22 21:54:25.968660
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('ANSIBLE_CONFIG')



# Generated at 2022-06-22 21:54:35.807477
# Unit test for function remove_values
def test_remove_values():
    class TestObj(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    def test(value, no_log_strings, expected):
        assert remove_values(value, no_log_strings) == expected

    # None
    test(None, ('danger', 'warning'), None)

    # string
    test('string', ('danger', 'warning'), 'string')
    test('danger is here', ('danger', 'warning'), '****** is here')
    test('warning is here', ('danger', 'warning'), '****** is here')
    test('danger and warning are here', ('danger', 'warning'), '**************** are here')
    test('nothing is here', ('danger', 'warning'), 'nothing is here')

    # unicode

# Generated at 2022-06-22 21:54:42.914827
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['BOO'] = 'barr'
    assert env_fallback('BOO', 'BAA') == 'barr'
    os.environ['MOO'] = 'meow'
    assert env_fallback('BOO', 'MOO') == 'barr'
    assert env_fallback('NOO') == 'NOO'
    assert env_fallback('NOO', 'POO', 'BOO', 'MOO') == 'barr'



# Generated at 2022-06-22 21:54:50.489908
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys({'not_logged': 'key_foo', 'not_logged_either': 'value_foo', 'not_logged_at_all': 'value_foo', 'logged': 'bar', 'also_logged': 'bar', '_ansible': 'bar'}, {'value_foo', 'key_foo'}) == {'not_logged_either': 'value_foo', 'not_logged_at_all': 'value_foo', 'logged': 'bar', 'also_logged': 'bar', '_ansible': 'bar'}



# Generated at 2022-06-22 21:55:00.451161
# Unit test for function remove_values
def test_remove_values():
    input = {'foo': 'bar',
             'blah': [1, 2, 3, 'change', 'me'],
             'password': 'pa$$w0rd',
             'password1': 'pa$$w0rd',
             'xxx': {'creds': {'aws': 'secret'}, 'baz': 'baz'},
             'num': 24,
             'nested': {'password': '$ecre7', 'content': {'blah': ['secret']}}}
    output = remove_values(input, ['secret', 'pa$$w0rd', 'change'])

# Generated at 2022-06-22 21:55:12.752875
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        foo=dict(type='str', fallback=(env_fallback, 'ANSIBLE_FOO')),
        bar=dict(type='str', fallback=(env_fallback, 'ANSIBLE_BAR'), no_log=True),
        baz=dict(type='str', fallback=(env_fallback, 'ANSIBLE_BAZ'), no_log=False),
        qux=dict(type='str', fallback=(env_fallback, 'ANSIBLE_QUX'), no_log=True),
        quux=dict(type='str', fallback=(env_fallback, 'ANSIBLE_QUUX'), no_log=False),
        quuz=dict(type='str', fallback=(env_fallback, 'ANSIBLE_QUUZ'), no_log=False),
    )
    os

# Generated at 2022-06-22 21:55:17.561584
# Unit test for function remove_values
def test_remove_values():
    no_log_strings = ['TEST_PASSWORD']

# Generated at 2022-06-22 21:55:23.494694
# Unit test for function remove_values
def test_remove_values():
    assert remove_values({'some_dict': {'key': 'value'}}, ['key']) == {'some_dict': {'key': 'VALUE_HIDDEN'}}
    assert remove_values({'some_dict': {'key': 'value'}}, ['value']) == {'some_dict': {'key': 'value'}}
    assert remove_values({'some_dict': {'key': 'value'}}, ['value'], ['key']) == {'some_dict': {'key': 'value'}}
    assert remove_values({'some_dict': {'key': 'value'}}, ['value'], ['other_key']) == {'some_dict': {'key': 'VALUE_HIDDEN'}}

# Generated at 2022-06-22 21:55:33.943362
# Unit test for function sanitize_keys
def test_sanitize_keys():
    my_dict = {'foo': 'bar',
               'no_log_value': 'my_password',
               'list_with_no_log': ['foo', 'my_pass', 'bar'],
               'dict_with_no_log': {'foo': 'bar', 'password': 'secret'}}

    no_log_values = ['secret', 'my_pass', 'my_password']

    assert my_dict == sanitize_keys(my_dict, no_log_values)
    assert {'foo': 'bar', 'no_log_value': 'my_password', 'list_with_no_log': ['foo', 'my_pass', 'bar'], 'dict_with_no_log': {'foo': 'bar', 'password': 'secret'}} == my_dict

# Generated at 2022-06-22 21:55:40.926677
# Unit test for function set_fallbacks

# Generated at 2022-06-22 21:55:45.323135
# Unit test for function env_fallback
def test_env_fallback():
    with mock.patch.dict(os.environ, {'TEST_ENV':'foo'}):
        assert env_fallback('TEST_ENV') == 'foo'
    assert env_fallback('NONEXISTANT') == ''



# Generated at 2022-06-22 21:55:56.807260
# Unit test for function sanitize_keys
def test_sanitize_keys():
    # Simple test not containing any no_log strings
    j1 = {'a': 'b', 'c': {'de': {'f': 'g'}, 'hi': 'jk'}}
    j_res1 = sanitize_keys(j1, {'asdasda'})
    assert sorted(j_res1.keys()) == ['a', 'c']
    assert sorted(j_res1['c'].keys()) == ['de', 'hi']
    assert j_res1['a'] == 'b'
    assert j_res1['c']['de']['f'] == 'g'
    assert j_res1['c']['hi'] == 'jk'

    # Simple test containing a no_log string

# Generated at 2022-06-22 21:56:07.875837
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_VALUE'] = 'foo'
    assert env_fallback('ANSIBLE_TEST_VALUE') == 'foo'
    assert env_fallback('ANSIBLE_TEST_BAR') == 'foo'
    assert env_fallback('ANSIBLE_TEST_BAR', 'ANSIBLE_TEST_VALUE') == 'foo'
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('ANSIBLE_TEST_FOO')
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('ANSIBLE_TEST_FOO', 'ANSIBLE_TEST_BAR')


# Generated at 2022-06-22 21:56:10.408771
# Unit test for function env_fallback
def test_env_fallback():
    env_value = "dev"
    os.environ["ANSIBLE_TEST_ENV"] = env_value
    assert env_fallback("ANSIBLE_TEST_ENV") == env_value


# Generated at 2022-06-22 21:56:21.542345
# Unit test for function sanitize_keys
def test_sanitize_keys():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from collections import OrderedDict
    from functools import partial

    # This function is needed to ensure we can compare OrderedDict objects
    def convert_elements(obj):
        if isinstance(obj, OrderedDict):
            return type(obj)((k, convert_elements(v)) for k, v in obj.items())
        elif isinstance(obj, (list, tuple, set)):
            return obj.__class__(convert_elements(v) for v in obj)
        elif isinstance(obj, (AnsibleUnsafeText, binary_type, text_type)):
            return to_native(obj, errors='surrogate_or_strict')
        else:
            return obj

    no_log_

# Generated at 2022-06-22 21:56:31.943494
# Unit test for function set_fallbacks

# Generated at 2022-06-22 21:56:41.184935
# Unit test for function env_fallback
def test_env_fallback():
    test_arglist = ['ANSIBLE_FOO', 'ANSIBLE_BAR']
    test_kwargs = {'ANSIBLE_FOO': 'expected_value'}
    assert env_fallback(*test_arglist) == os.environ[test_arglist[0]]
    assert env_fallback(*test_arglist, **test_kwargs) == os.environ[test_arglist[0]]
    try:
        env_fallback(test_arglist[1])
    except AnsibleFallbackNotFound as e:
        assert e.message == "The required environment variable '%s' was not set." % test_arglist[1]
        return
    assert False  # should not reach here



# Generated at 2022-06-22 21:56:52.918918
# Unit test for function sanitize_keys
def test_sanitize_keys():
    # Source: https://github.com/ansible/ansible/pull/23426
    # Make sure that sanitize_keys() works on a dict with two duplicate keys.
    test_dict = dict(a=1, b=2, c=3, a=1)

    # If sanitize_keys() doesn't handle duplicate keys correctly, this will throw an exception.
    sanitized_dict = sanitize_keys(test_dict, ('a', 'b'))

    # Make sure that sanitize_keys() is working.
    assert 'b' in sanitized_dict['b']
    assert 'a' in sanitized_dict['b']
    assert 'b' in sanitized_dict['c']
    assert 'a' in sanitized_dict['c']

    # Make sure that sanitize_keys() doesn't incorrectly modify

# Generated at 2022-06-22 21:57:03.792303
# Unit test for function sanitize_keys
def test_sanitize_keys():
    """Sanitize the keys in a container object by removing ``no_log`` values from key names.

    This is a companion function to the :func:`remove_values` function. Similar to that function,
    we make use of ``deferred_removals`` to avoid hitting maximum recursion depth in cases of
    large data structures.

    :arg obj: The container object to sanitize. Non-container objects are returned unmodified.
    :arg no_log_strings: A set of string values we do not want logged.
    :kwarg ignore_keys: A set of string values of keys to not sanitize.

    :returns: An object with sanitized keys.
    """

    deferred_removals = deque()


# Generated at 2022-06-22 21:57:14.355226
# Unit test for function sanitize_keys
def test_sanitize_keys():
    struct = {
        'foo': 'bar',
        'redacted': 'REDACTED',
        'baz': {
            'quux': {
                'quuux': 'REDACTED'
            },
            'corge': ['REDACTED', 'grault', 'garply']
        },
        'wy': 'xz'
    }

    redact = ['REDACTED']
    expected = {
        'foo': 'bar',
        'redacted': 'REDACTED',
        'baz': {
            'quux': {
                'quuux': 'REDACTED'
            },
            'corge': ['REDACTED', 'grault', 'garply']
        },
        'wy': 'xz'
    }
    result = sanitize_keys(struct, redact)

    assert result == expected



# Generated at 2022-06-22 21:57:26.379059
# Unit test for function remove_values
def test_remove_values():
    # Tests for remove_values() where private data is not removed.
    assert remove_values(None, []) == None
    assert remove_values(['my text', 'my password'], ['my password']) == ['my text', 'my password']
    assert remove_values({'mykey': 'abc', 'mypassword': '123'}, ['mypassword']) == {'mykey': 'abc', 'mypassword': '123'}
    assert remove_values([{'mykey': 'abc', 'mypassword': '123'}], ['mypassword']) == [{'mykey': 'abc', 'mypassword': '123'}]

# Generated at 2022-06-22 21:57:37.277202
# Unit test for function remove_values
def test_remove_values():
    a = { 'a':'1', 'b':'2', 'c': '3'}
    b = ['1', '2', '3']
    c = ['1', '2', '3']
    d = '123'
    e = u'super_secret'
    f = {'a':['1', '2', '3'], 'b':'2', 'c': '3'}
    g = {'a':{'x':'1', 'y':'2', 'z': '3'}, 'b':'2', 'c': {'x':'1', 'y': '2', 'z': '3'}}
    h = {'a':{'x':'1', 'y':'2', 'z': '3'}, 'b':'2', 'c': '3'}

# Generated at 2022-06-22 21:57:47.649928
# Unit test for function sanitize_keys
def test_sanitize_keys():
    class Object(object):
        def __init__(self, test, name):
            self.test = test
            self.name = name

    # Test with a standalone object
    obj = Object('test', 'ansible')
    obj_mod = sanitize_keys(obj, set(['a', 'n', 's', 'i', 'b', 'l', 'e']))
    assert obj is not obj_mod, 'Object was modified'
    assert obj.test == 'test' and obj.name == 'ansible', 'Object was modified'

    # Test with an object in a container
    obj = Object('test', 'ansible')
    obj_list = [obj]

# Generated at 2022-06-22 21:57:54.906615
# Unit test for function set_fallbacks
def test_set_fallbacks():
    fallback_key = 'AWX_TEST_FALLBACK'
    fallback_val = 'abcdefg'
    if not os.environ.get(fallback_key):
        os.environ[fallback_key] = fallback_val
    # Test load from environment variable
    spec = dict(param=dict(type='str', fallback=(env_fallback, fallback_key)),
                )
    parameters = dict()
    no_log_values = set_fallbacks(spec, parameters)
    assert parameters['param'] == fallback_val
    assert len(no_log_values) == 0
    os.environ.pop(fallback_key)
    # Test load with fallback not found
    parameters = dict()
    no_log_values = set_fallbacks(spec, parameters)
    assert parameters

# Generated at 2022-06-22 21:58:05.308140
# Unit test for function sanitize_keys
def test_sanitize_keys():
    no_log_strings = ['password']
    ignore_keys = ['some_key_name', 'some_value']
    parameters = {
        'some_key_name': 'some_value',
        'password': 'some_password',
        'keys_should_not_be_sanitized': {
            'other_key_name': 'other_value',
            'password': 'other_password'
        },
        'keys_should_be_sanitized_unless_they_start_with_underscore': {
            'password': 'other_password',
            'some_other_key_name': 'some_other_value',
            '_ansible_internal': 'some_internal_value'
        },
    }
    new_parameters = sanitize_keys(parameters, no_log_strings, ignore_keys)

# Generated at 2022-06-22 21:58:15.958770
# Unit test for function sanitize_keys
def test_sanitize_keys():
    #simple tests
    param_value = {'key1': 'value', 'key2': 'value', 'key_with_a_no_log_value': 'value'}
    no_log_strings = ['no_log_value']
    expected_value = {'key1': 'value', 'key2': 'value', 'key__with__a__': 'value'}
    assert sanitize_keys(param_value, no_log_strings) == expected_value

    #test list
    param_value = ['key1', 'key2', 'key_with_a_no_log_value', 'key4']
    no_log_strings = ['no_log_value']
    expected_value = ['key1', 'key2', 'key__with__a__', 'key4']

# Generated at 2022-06-22 21:58:25.904345
# Unit test for function sanitize_keys
def test_sanitize_keys():
    #Test a dictionary
    test_dict = {
        'ansible_network_os': 'ios',
        'ansible_user': 'foo',
        'ansible_user_test': 'bar',
    }
    expected_dict = {
        'network_os': 'ios',
        'user': 'foo',
        'user_test': 'bar',
    }
    assert expected_dict == sanitize_keys(test_dict, set('$'))

    # Test a list of dictionaries
    test_list = [test_dict, test_dict]
    expected_list = [expected_dict, expected_dict]
    assert expected_list == sanitize_keys(test_list, set('$'))

    # Test a tuple of dictionaries
    test_tuple = (test_dict, test_dict)


# Generated at 2022-06-22 21:58:37.453511
# Unit test for function remove_values
def test_remove_values():
    # Unit test for function remove_values
    import os
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch

    from ansible.utils.unsafe_proxy import wrap_var

    class TestModule(object):

        no_log_strings = {u'password', u'pwd', u'secret', u'ssh-key'}
        no_log = [u'password', u'pwd', u'secret', u'ssh-key']

        def __init__(self, no_log=None, no_log_strings=None):
            self._no_log = no_log
            self._no_log_strings = no_log_strings


# Generated at 2022-06-22 21:58:43.436988
# Unit test for function remove_values
def test_remove_values():
    assert {'a': 1, 'b': 2, 'c': 3} == remove_values({'a': 1, 'b': 2, 'c': 3}, [])
    assert {'a': 1, 'b': 2, 'c': u('**')} == remove_values({'a': 1, 'b': 2, 'c': u('foo')}, [u('foo')])
    assert [1, 2, 3] == remove_values([1, 2, 3], [])
    assert [1, 2, 3] == remove_values([1, 2, 3], [])
    assert [1, 2, u('**')] == remove_values([1, 2, u('foo')], [u('foo')])

# Generated at 2022-06-22 21:58:55.931008
# Unit test for function sanitize_keys
def test_sanitize_keys():
    # Test list
    obj = [
        {'a': 1, 'b': 2},
        {'a': 3, 'b': 4, 'x': [{'a': 5, 'b': 6}, {'a': 7, 'b': 8}]},
        {'a': 9, 'b': 10, 'x': [{'a': 11, 'b': 12, 'x': {'a': 13, 'b': 14}}]}
    ]
    # No log value to test and exclude from removal
    no_log_strings = ['a']
    # No log strings removed from key
    # keys in ignore_keys are not modified
    no_log_values = sanitize_keys(obj, no_log_strings, ignore_keys=['x'])

# Generated at 2022-06-22 21:59:05.113792
# Unit test for function remove_values

# Generated at 2022-06-22 21:59:16.562036
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'key1': dict(required=False, fallback=('env_fallback', 'FOO')),
                     'key2': dict(required=False, fallback=(env_fallback, 'FOO'))}
    parameters = {}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert not parameters
    assert not no_log_values

    os.environ['FOO'] = 'bar'
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['key1'] == 'bar'
    assert parameters['key2'] == 'bar'
    assert not no_log_values


# Generated at 2022-06-22 21:59:27.381224
# Unit test for function sanitize_keys
def test_sanitize_keys():
    ansible_vars = dict(
        foo=dict(
            bar=dict(
                baz=dict(
                    qux='some string'
                )
            )
        ),
        list_of_dicts=[
            dict(
                a='a',
                b='b'
            ),
            dict(
                a='a',
                b='b'
            )
        ]
    )
    no_log_values = ['string']
    ignore_keys = {'b'}

# Generated at 2022-06-22 21:59:37.151830
# Unit test for function sanitize_keys
def test_sanitize_keys():
    import json
    import yaml

    # We want the same values for no_log_strings in all tests.
    no_log_values = ['TEST_VALUE', 'TEST_VALUE_1', 'TEST_VALUE_2']
    no_log_strings = set([to_native(s, errors='surrogate_or_strict') for s in no_log_values])
    ignore_keys = ['_ansible_ignore_errors', '_ansible_module_name', '_ansible_no_log']

    # Test with a simple argument_spec

# Generated at 2022-06-22 21:59:46.219567
# Unit test for function set_fallbacks
def test_set_fallbacks():
    test_case_0 = dict(argument_spec={}, parameters={}, expected={})
    test_case_1 = dict(
        argument_spec={
            'arg': {
                'type': 'str',
                'default': 'default',
                'fallback': (env_fallback, 'ANSIBLE_TEST_FALLBACK')
            }
        },
        parameters={},
        expected={}
    )
    test_case_1b = dict(
        argument_spec={
            'arg': {
                'type': 'str',
                'default': 'default',
                'fallback': (env_fallback, 'ANSIBLE_TEST_FALLBACK')
            }
        },
        parameters={'arg': 'value'},
        expected={'arg': 'value'}
    )
    test_case_

# Generated at 2022-06-22 21:59:52.979938
# Unit test for function remove_values
def test_remove_values():
    assert_equal('logfile', remove_values('logfile', ['*']))
    assert_equal('', remove_values('logfile', ['logfile']))
    assert_equal('', remove_values('log*file', ['log*file']))
    assert_equal('password: ***', remove_values('password: logfile', ['logfile']))
    assert_equal('pass*word: ***', remove_values('pass*word: log*file', ['log*file']))
    assert_equal('', remove_values('password: logfile', ['logfile', 'password']))
    assert_equal('pass*word: ***', remove_values('pass*word: log*file', ['pass*word', 'log*file']))
    assert_equal('', remove_values([], ['logfile', 'password']))

# Generated at 2022-06-22 22:00:05.245691
# Unit test for function set_fallbacks
def test_set_fallbacks():

    argument_spec = {'a': {'fallback': (env_fallback, 'ANSIBLE_A')},
                     'b': {'fallback': (env_fallback, 'ANSIBLE_B')},
                     'c': {'fallback': (env_fallback, 'ANSIBLE_C')}}

    params = {}

    os.environ['ANSIBLE_A'] = '3'
    os.environ['ANSIBLE_B'] = '5'

    no_log_values = set_fallbacks(argument_spec, params)

    # function set_fallbacks returns a set(no_log_values)
    assert len(no_log_values) == 2

    # function set_fallbacks updated params with values from fallbacks
    assert params['a'] == '3' and params['b'] == '5'



# Generated at 2022-06-22 22:00:14.541221
# Unit test for function remove_values
def test_remove_values():
    no_log_strings = ['password']
    value = 'mypassword'
    assert remove_values(value, no_log_strings) == 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'

    value = {'foo': 'bar', 'baz': 'password'}
    assert remove_values(value, no_log_strings) == {'foo': 'bar', 'baz': 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'}

    value = {'foo': 'bar', 'baz': {'password': 'password'}}
    assert remove_values(value, no_log_strings) == {'foo': 'bar', 'baz': {'password': 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'}}



# Generated at 2022-06-22 22:00:23.406064
# Unit test for function set_fallbacks
def test_set_fallbacks():
    spec = {'x': {'type': 'str', 'required': True, 'fallback': (env_fallback, 'A')}}
    params = {}
    no_log = set_fallbacks(spec, params)
    assert len(no_log) == 0
    assert params['x'] == os.environ['A']
    params = {'x': '7'}
    no_log = set_fallbacks(spec, params)
    assert len(no_log) == 0
    assert params['x'] == '7'
    del os.environ['A']



# Generated at 2022-06-22 22:00:34.424662
# Unit test for function remove_values
def test_remove_values():
    """Test logic behind function ``remove_values``."""
    no_log_strings = ['A', 'B']
    # The expected result of ``remove_values(value, no_log_strings)``
    expected = {
        'a': {
            'public1': 'foo',
            'private1': '',
        },
        'b': {
            'public2': 'bar',
            'private2': '',
        }
    }
    # The value we pass to the ``remove_values`` function
    value = {
        'a': {
            'public1': 'foo',
            'private1': 'A',
        },
        'b': {
            'public2': 'bar',
            'private2': 'B',
        }
    }

# Generated at 2022-06-22 22:00:46.031359
# Unit test for function sanitize_keys
def test_sanitize_keys():
    my_dict = {'_ansible_no_log': True, 'password': 'secret'}

    fixed_dict = sanitize_keys(my_dict, ['secret'])
    assert fixed_dict == {'_ansible_no_log': True, 'pass_': 'redacted'}
    assert isinstance(fixed_dict, dict)
    assert isinstance(fixed_dict['_ansible_no_log'], bool)

    fixed_dict = sanitize_keys(my_dict, ['secret', 'redacted'])
    assert fixed_dict == {'_ansible_no_log': True, 'pass_': 'redacted'}
    assert isinstance(fixed_dict, dict)
    assert isinstance(fixed_dict['_ansible_no_log'], bool)


# Generated at 2022-06-22 22:00:57.788028
# Unit test for function remove_values
def test_remove_values():
    from ansible.module_utils import basic

    def check_value_removed(value, no_log_strings):
        assert(remove_values(value, no_log_strings) != value)

    def check_value_not_removed(value, no_log_strings):
        assert(remove_values(value, no_log_strings) == value)

    def check_value_identical(value1, value2):
        assert(remove_values(value1, no_log_strings=['foo']) == remove_values(value2, no_log_strings=['foo']))

    # Check that parameter-supplied no_log_strings are removed
    check_value_removed('foo', ['foo'])

    # Check that AnsibleModule-supplied no_log_strings are removed
    module = basic.Ansible

# Generated at 2022-06-22 22:00:59.405330
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback(None) == AnsibleFallbackNotFound

# Generated at 2022-06-22 22:01:09.335068
# Unit test for function set_fallbacks
def test_set_fallbacks():
    ansible_module_args = {'one': 1}

# Generated at 2022-06-22 22:01:22.113122
# Unit test for function sanitize_keys
def test_sanitize_keys():
    no_log_strings = ['password']
    ignore_keys = {'command', 'ansible_facts'}