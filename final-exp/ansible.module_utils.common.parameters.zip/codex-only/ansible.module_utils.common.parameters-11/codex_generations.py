

# Generated at 2022-06-22 21:51:23.598444
# Unit test for function remove_values
def test_remove_values():
    assert(remove_values({'password': 'asdf', 'secret': 'asdf'}, ['asdf']) == {'password': '********', 'secret': '********'})
    assert(remove_values({'password': {'password': 'asdf'}}, ['asdf'])[
        'password']['password'] == '********')
    assert(remove_values([{'password': 'asdf'}], ['asdf']) == [{'password': '********'}])
    assert(remove_values('asdf', ['asdf']) == 'asdf')
    assert(remove_values(1234, ['asdf']) == 1234)
    assert(remove_values(None, ['asdf']) == None)
    assert(remove_values(False, ['asdf']) == False)

# Generated at 2022-06-22 21:51:29.765202
# Unit test for function sanitize_keys
def test_sanitize_keys():
    ex_dict = {'key1': 'normal_value', 'key2': 'value_to_remove'}
    ex_dict_ignored = {'_ansible_key1': 'normal_value', '__ansible_key2': 'value_to_remove'}
    ex_list = ['normal_value1', 'normal_value2', 'value_to_remove']
    ex_list_ignored = ['_ansible_value1', '__ansible_value2', 'normal_value']

    answer_dict = {'key1': 'normal_value'}
    answer_dict_ignored = {'_ansible_key1': 'normal_value', '__ansible_key2': 'value_to_remove'}
    answer_list = ['normal_value1', 'normal_value2']
    answer_

# Generated at 2022-06-22 21:51:38.948571
# Unit test for function remove_values
def test_remove_values():
    # Tests with non-container value
    values = [
        "test",
        (1, 2),
        ["test", "test", "test"],
        ("test", "test"),
        "test test test",
        b"test",
        None,
        True,
        False,
    ]
    for value in values:
        assert remove_values(value, []) == value
        assert remove_values(value, ["test"]) == value

    # Tests for list
    data = [
        "test",
        [],
        [[]],
        ["test", ["test"]],
        "test test test",
        ["test", "test", "test"],
        ["test", "test"],
    ]
    assert remove_values(data, []) == data

    expected = ["test"]

# Generated at 2022-06-22 21:51:43.156272
# Unit test for function sanitize_keys
def test_sanitize_keys():
    # test some basic string sanitization
    data = { 'payload': 'secret' }
    result = sanitize_keys(data, ['secret'])
    assert result == { 'payload': '[REDACTED]' }, "sanitize_keys failed to sanitize a simple string"

    # test sanitization of a key that is a subset of another key
    data = { 'payload': 'secret', 'payload-secret': 'confidential' }
    result = sanitize_keys(data, ['secret'])
    assert result == { 'payload': '[REDACTED]', 'paylo[REDACTED]' : 'confidential' }, "sanitize_keys failed to sanitize a subset key"

    # test sanitization of a key that is a superset of another key

# Generated at 2022-06-22 21:51:50.661384
# Unit test for function sanitize_keys
def test_sanitize_keys():
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.text.converters import to_text

    class MySentinel(object):
        pass

    argspec = {
        'foo': dict(type='str'),
        'baz': dict(type='str', no_log=True),
    }
    params = {
        'foo': 'bar',
        'baz': 'password',
    }
    no_log_values = {'password'}
    expected = {'foo': 'bar'}
    actual = sanitize_keys(params, no_log_values)

    assert isinstance(actual, dict)
    assert actual == expected

    # Test using the function in a real module.

# Generated at 2022-06-22 21:51:55.481735
# Unit test for function sanitize_keys
def test_sanitize_keys():
    try:
        d = dict()
        d['a'] = 'b'
        d['c'] = 'd'
        d['e'] = dict()
        d['e']['f'] = 'h'
        d = sanitize_keys(d, ['b', 'f'])
        assert d['a'] == 'b', 'a'
        assert d['c'] == 'd', 'b'
        assert d['e']['f'] == 'h', 'c'
    except AssertionError as e:
        print(e)
        raise
# END Unit test for function sanitize_keys


# Generated at 2022-06-22 21:52:02.170616
# Unit test for function set_fallbacks
def test_set_fallbacks():
    mock_module = MagicMock()
    mock_module.params = {'nested': {'first': 1234, 'second': 5678}}
    mock_module.params['nested']['third'] = {'third_val1': 1234, 'third_val2': 5678}

# Generated at 2022-06-22 21:52:09.040033
# Unit test for function remove_values
def test_remove_values():
    no_log_strings = set()
    no_log_strings.add("Remove this")

    results = {
        "key": "value",
        "key_list": [
            "value1",
            "value2",
            "Remove this"
        ],
        "key_dict": {
            "key1": "value1",
            "key2": "Remove this",
            "key3": "value3"
        },
        "private_key": "Remove this"
    }

# Generated at 2022-06-22 21:52:19.489562
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert not set_fallbacks({}, {})

    spec = dict(
        first=dict(type='str', fallback=(env_fallback, 'FIRST')),
        second=dict(type='str', fallback=(lenient_fallback, 'SECOND', 'default_value')),
        third=dict(type='str', fallback=(fail_if_no_crypto, 'THIRD'))
    )
    assert set_fallbacks(spec, {}) == set()
    os.environ['FIRST'] = 'ok'
    assert set_fallbacks(spec, {}) == set()

    parameters = dict(second='ok')
    assert set_fallbacks(spec, parameters) == set()

    parameters = dict(first='ok')
    assert set_fallbacks(spec, parameters) == set(['ok'])

   

# Generated at 2022-06-22 21:52:25.847364
# Unit test for function set_fallbacks

# Generated at 2022-06-22 21:52:37.728273
# Unit test for function set_fallbacks
def test_set_fallbacks():

    argument_spec = {
        'first_param': {'type': 'str',
                        'fallback': (env_fallback, ['first_param_value'])},
        'second_param': {'type': 'str',
                         'fallback': (env_fallback, ['second_param_value'])},
        'third_param': {'type': 'str',
                        'no_log': True,
                        'fallback': (env_fallback, ['third_param_value'])},
        'fourth_param': {'type': 'str',
                         'no_log': True,
                         'fallback': (env_fallback, ['fourth_param_value1', 'fourth_param_value2'])},
    }

    parameters = {'first_param': 'absent_value'}
    no_log_

# Generated at 2022-06-22 21:52:45.695084
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'ansible_python_interpreter': {'type': 'path', 'fallback': (env_fallback, ['ANSIBLE_PYTHON_INTERPRETER'])}}
    parameters = {}
    no_log_values = set()
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['ansible_python_interpreter'] == os.environ['ANSIBLE_PYTHON_INTERPRETER']
    assert isinstance(no_log_values, set)
    assert no_log_values == {os.environ['ANSIBLE_PYTHON_INTERPRETER']}
    # Test no_log=False
    argument_spec = {'ansible_python_interpreter': {'type': 'path'}}
    parameters = {}
    no_

# Generated at 2022-06-22 21:52:56.381006
# Unit test for function env_fallback
def test_env_fallback():
    """Check env_fallback function"""
    import os

    # Test that no value is returned if no environment variable is set.
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('FOOBAR')

    # Test that correct value is returned when the correct environment variable is set.
    os.environ['FOOBAR'] = 'PASS'
    assert (env_fallback('FOOBAR') == 'PASS')
    os.environ.pop('FOOBAR')

    # Test that correct value is returned when the correct environment variable is set.
    os.environ['FOOBAR'] = 'PASS'
    assert (env_fallback('FOOBAR1', 'FOOBAR') == 'PASS')
    os.environ.pop('FOOBAR')


# Generated at 2022-06-22 21:53:07.422857
# Unit test for function remove_values
def test_remove_values():
    assert remove_values('hello', ('hi',)) == 'hello'
    assert remove_values([b'hi', 'hi'], ('hi',)) == ['hi', 'hi']
    assert remove_values('hi', ('hi',)) == 'hi'
    assert remove_values('hi', ('lo',)) == 'hi'
    assert remove_values({'a': 'hi', 'b': 'lo'}, ('lo',)) == {'a': 'hi', 'b': 'lo'}
    assert remove_values({'a': 'hi', 'b': 'lo', 'c': ('hi', 'lo')}, ('lo',)) == {'a': 'hi', 'b': 'lo', 'c': ('hi', 'lo')}

# Generated at 2022-06-22 21:53:19.228369
# Unit test for function remove_values
def test_remove_values():
    # https://github.com/ansible/ansible/issues/31091
    assert remove_values(
        '$ANSIBLE_CONFIG', ['$ANSIBLE_CONFIG'],
    ) == '****'
    assert remove_values(
        'test $ANSIBLE_CONFIG', ['$ANSIBLE_CONFIG'],
    ) == 'test $ANSIBLE_CONFIG'
    assert remove_values(
        'test $ANSIBLE_CONFIG test', ['$ANSIBLE_CONFIG'],
    ) == 'test $ANSIBLE_CONFIG test'
    assert remove_values(
        'test $ANSIBLE_CONFIG test $ANSIBLE_CONFIG', ['$ANSIBLE_CONFIG'],
    ) == 'test $ANSIBLE_CONFIG test $ANSIBLE_CONFIG'

# Generated at 2022-06-22 21:53:25.655339
# Unit test for function remove_values
def test_remove_values():
    assert remove_values("foobar", ['foo']) == '***'
    assert remove_values("barfoo", ['foo']) == '***'
    assert remove_values("fofoo", ['foo']) == '***'
    assert remove_values("foo", ['foo']) == '***'
    assert remove_values("foo ", ['foo']) == '***'
    assert remove_values(" foo", ['foo']) == '***'
    assert remove_values("barfoobarfoobar", ['foo']) == '********'

    # Ignore non-strings
    assert remove_values(None, ['foo']) is None
    assert remove_values(1, ['foo']) == 1
    assert remove_values(1.1, ['foo']) == 1.1

    # Ignore unicode

# Generated at 2022-06-22 21:53:36.920540
# Unit test for function remove_values
def test_remove_values():
    f = {
        'foo': 'foo',
        'bar': 'bar',
        'baz': 'baz',
        'bat': {
            'foo': 'foo',
            'bar': 'bar',
            'baz': 'baz',
            'bat': {
                'foo': 'foo',
                'bar': 'bar',
                'baz': 'baz',
            },
            'list': [
                'foo',
                'bar',
                'baz'
            ],
        }
    }

    f2 = remove_values(f, 'bar')


# Generated at 2022-06-22 21:53:49.090145
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys("somestring", ("somestring",)) == "somestring"
    assert sanitize_keys(
        {"old_key": "somestring", "new_key": "somestring", "old_key_nested": {"new_key_nested": "somestring"}},
        ("somestring",)) == {"old_key": "somestring", "new_key": "somestring", "old_key_nested": {"new_key_nested": "somestring"}}

# Generated at 2022-06-22 21:54:00.134346
# Unit test for function sanitize_keys

# Generated at 2022-06-22 21:54:10.360593
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(param1=dict(fallback=(env_fallback, 'TEST_VAR_1', 'TEST_VAR_2')),
                         param2=dict(fallback=(env_fallback, 'TEST_VAR_3', 'TEST_VAR_4')))
    # Test that fallback for param1 finds TEST_VAR_1
    os.environ['TEST_VAR_1'] = 'hello'
    os.environ['TEST_VAR_3'] = 'goodbye'
    no_log_values = set()
    parameters = dict(param2='foobar')
    set_fallbacks(argument_spec, parameters)
    assert parameters['param1'] == 'hello'
    # Test that fallback for param2 finds nothing

# Generated at 2022-06-22 21:54:20.345033
# Unit test for function set_fallbacks

# Generated at 2022-06-22 21:54:28.739281
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['TEST_ENV'] = 'foo'
    assert env_fallback('TEST_ENV') == 'foo'
    del os.environ['TEST_ENV']
    assert not os.environ.get('TEST_ENV')
    assert env_fallback('TEST_ENV') is None
    try:
        env_fallback('TEST_ENV', required=True)
        raise AssertionError("env_fallback didn't raise AnsibleFallbackNotFound")
    except AnsibleFallbackNotFound:
        pass



# Generated at 2022-06-22 21:54:38.345244
# Unit test for function set_fallbacks

# Generated at 2022-06-22 21:54:49.151030
# Unit test for function remove_values
def test_remove_values():
    assert remove_values('abcdefg', ['abcdefg']) == "VALUE_SPECIFIED_IN_NO_LOG_PARAMETER"
    assert remove_values('', ['abcdefg']) == ''
    assert remove_values({'thekey': {'thevalue': 'novalue'}}, ['novalue']) == {'thekey': {'thevalue': 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'}}
    assert remove_values({'thekey': {'thevalue': 'novalue'}}, ['someothervalue']) == {'thekey': {'thevalue': 'novalue'}}

# Generated at 2022-06-22 21:54:59.872817
# Unit test for function sanitize_keys
def test_sanitize_keys():
    keys = []

    # Test that dictionary keys are sanitized
    keys.append({'key': 'value'})
    keys.append(dict(zip(['key'], ['value'])))
    keys.append({'key': {'name': 'value'}})
    keys.append({'key': [1, 2, 3]})
    keys.append({'key': ('a', 'b')})
    keys.append({'key': ('a', 'b'), 'key2': ('a', 'b')})
    keys.append({'key': frozenset(['a', 'b'])})
    keys.append({'key': {'name': {'key': 'value'}}})
    keys.append({'key': {'name': ['value', 'value2']}})

# Generated at 2022-06-22 21:55:12.683378
# Unit test for function remove_values
def test_remove_values():
    def _remove_values_helper_list(value, no_log_strings, expected_result):
        assert remove_values(value, no_log_strings) == expected_result

    _remove_values_helper_list(['foo', ['bar', 'baz']], ['baz'], ['foo', ['bar', 'XXX', 'XXX']])
    _remove_values_helper_list(['foo', 'bar', 'baz'], ['baz', 'bar'], ['foo', 'XXX', 'XXX'])
    _remove_values_helper_list(['foo', 'bar', 'baz'], ['baz', 'bar', 'foo'], ['XXX', 'XXX', 'XXX'])

# Generated at 2022-06-22 21:55:21.450147
# Unit test for function remove_values
def test_remove_values():
    # no_log_strings is a list, so ensure we can handle a list argument
    data_list = ['test_data', 'test_data_no_log1', 'test_data_no_log2']
    no_log_strings = ['test_data_no_log2']
    result = remove_values(data_list, no_log_strings)
    # Simple list should remove the item found in no_log_strings
    assert(result == ['test_data', 'test_data_no_log1'])

    # Nested list should remove the item found in no_log_strings
    data_nested = {'test_key': ['test_data', 'test_data_no_log1', 'test_data_no_log2']}
    result = remove_values(data_nested, no_log_strings)

# Generated at 2022-06-22 21:55:27.677397
# Unit test for function env_fallback
def test_env_fallback():
    with patch.dict('os.environ', {'ENV_FOO': 'FOO_VALUE'}):
        assert env_fallback('ENV_FOO') == 'FOO_VALUE'
    with patch.dict('os.environ', {'ENV_BAR': 'BAR_VALUE'}):
        assert env_fallback('ENV_FOO', 'ENV_BAR') == 'BAR_VALUE'



# Generated at 2022-06-22 21:55:34.254621
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['FAKE'] = 'FALSE'
    assert env_fallback('FAKE') == 'FALSE'
    assert env_fallback('FAKE', 'REAL') == 'FALSE'
    assert env_fallback('REAL') == 'REAL'
    args = []
    try:
        env_fallback(*args)
        assert False
    except AnsibleFallbackNotFound:
        assert True



# Generated at 2022-06-22 21:55:43.543856
# Unit test for function sanitize_keys
def test_sanitize_keys():
    input_data = dict(
        key1='value1',
        key2=dict(
            nest1='value2',
            nest2=dict(
                nest1='value3',
            ),
        ),
    )
    no_log_strings = set(['value1', 'value2', 'value3'])
    output_data = dict(
        key1='value1',
        key2=dict(
            nest1='value2',
            nest2=dict(
                nest1='value3',
            ),
        ),
    )
    assert_equal(sanitize_keys(input_data, no_log_strings), output_data)



# Generated at 2022-06-22 21:55:52.652558
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_FOO'] = 'ANSIBLE_TEST_FOO'
    assert env_fallback('ANSIBLE_TEST_FOO') == 'ANSIBLE_TEST_FOO'
    assert env_fallback('ANSIBLE_TEST_BAR') == 'ANSIBLE_TEST_BAR'
    assert env_fallback('ANSIBLE_TEST_BAZ') == 'ANSIBLE_TEST_BAZ'
    del os.environ['ANSIBLE_TEST_FOO']



# Generated at 2022-06-22 21:56:01.775399
# Unit test for function sanitize_keys
def test_sanitize_keys():
    # use the None option for ignore_keys
    assert sanitize_keys({'a': 'b'}, frozenset(['b']), None) == {'a': '*'}
    # use the frozenset option for ignore_keys
    assert sanitize_keys({'a': 'b'}, frozenset(['b']), frozenset(['a'])) == {'a': 'b'}
    # ensure the default frozenset option for ignore_keys doesn't cause issues
    assert sanitize_keys({'a': 'b'}, frozenset(['b']), frozenset()) == {'a': '*'}
    # use the list option for no_log_strings
    assert sanitize_keys({'a': 'b'}, ['b'], None) == {'a': '*'}


# Generated at 2022-06-22 21:56:14.019459
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_FALLBACK_ENV'] = 'ANSIBLE_TEST_FALLBACK'

# Generated at 2022-06-22 21:56:24.673040
# Unit test for function remove_values
def test_remove_values():
    assert remove_values('username: password', ['password']) == 'username: <value of type "str" marked as sensitive>'
    assert remove_values({'password': 'foo'}, ['password']) == {'password': '<value of type "str" marked as sensitive>'}
    assert remove_values({'password': 'foo', 'no_log': 'foo'}, ['password']) == {'password': '<value of type "str" marked as sensitive>', 'no_log': 'foo'}

    assert remove_values('key is username:password', ['username:password']) == 'key is <value of type "str" marked as sensitive>'
    assert remove_values('key is user:password', ['user:password']) == 'key is <value of type "str" marked as sensitive>'

# Generated at 2022-06-22 21:56:34.283618
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert set_fallbacks({'a': {'type': 'str', 'fallback': (env_fallback, 'A_FALLBACK_ENV_VAR')}}, {}) == set()
    assert set_fallbacks({'a': {'type': 'str', 'fallback': (env_fallback, 'A_FALLBACK_ENV_VAR', {'no_log': True})}}, {}) == {'a'}
    with pytest.raises(AnsibleFallbackNotFound):
        assert set_fallbacks({'a': {'type': 'str', 'fallback': (env_fallback, 'DOES_NOT_EXIST')}}, {}) == set()



# Generated at 2022-06-22 21:56:43.328065
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys({'foo': 'foobar', 'foo.bar': 'barfoo'}, {'foo', 'bar'}) == {'foobar': 'foobar', 'barfoo': 'barfoo'}
    assert sanitize_keys({'foo': 'foobar', 'bar': 'barfoo'}, {'foo', 'bar'}) == {'foobar': 'foobar', 'barfoo': 'barfoo'}
    assert sanitize_keys({'a.foo': 'foobar', 'a.bar': 'barfoo'}, {'foo', 'bar'}) == {'a.foobar': 'foobar', 'a.barfoo': 'barfoo'}

# Generated at 2022-06-22 21:56:50.590200
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['FOO'] = 'bar'
    assert env_fallback('FOO', 'baz') == 'bar'
    os.environ['BAR'] = 'baz'
    assert env_fallback('BAR', 'qux') == 'baz'
    assert env_fallback('QUX') == 'qux'
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('QUUX')



# Generated at 2022-06-22 21:57:01.216038
# Unit test for function remove_values
def test_remove_values():
    # Remove simple string
    value = 'A simple string'
    no_log_strings = ['simple']
    new_value = remove_values(value, no_log_strings)
    assert(new_value == 'A string')

    value = 'A simple string with simple things in it'
    new_value = remove_values(value, no_log_strings)
    assert(new_value == 'A string with things in it')

    # Remove private strings
    value = {
        'key1': 'string1',
        'key2': 'string2',
    }
    no_log_strings = ['string1']
    new_value = remove_values(value, no_log_strings)
    assert(new_value == {
        'key2': 'string2',
    })


# Generated at 2022-06-22 21:57:13.030725
# Unit test for function remove_values
def test_remove_values():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from collections import Mapping, Sequence, MutableSequence, MutableSet
    assert remove_values('blah', ['blah']) == ''
    assert remove_values(AnsibleUnsafeText('blah'), ['blah']) == AnsibleUnsafeText('')
    assert remove_values({'a': 'blah', 'b': ['blah', 'blah'], 'c': {'a': 'blah'}}, ['blah']) == {'a': '', 'b': ['', ''], 'c': {'a': ''}}

# Generated at 2022-06-22 21:57:24.844390
# Unit test for function env_fallback
def test_env_fallback():
    ''' validate that env_fallback works for single and multiple env vars '''
    os.environ['ANSIBLE_TEST'] = 'test'
    os.environ['ANSIBLE_TEST2'] = 'test2'
    assert env_fallback('ANSIBLE_TEST') == 'test'
    assert env_fallback('ANSIBLE_TEST', 'ANSIBLE_TEST2') == 'test'
    assert env_fallback('ANSIBLE_TEST2', 'ANSIBLE_TEST') == 'test2'
    try:
        env_fallback('MISSING')
        raise Exception("env_fallback('MISSING') should have raised AnsibleFallbackNotFound")
    except AnsibleFallbackNotFound:
        pass



# Generated at 2022-06-22 21:57:33.324353
# Unit test for function remove_values
def test_remove_values():
    param1 = {
        'x': 'PASSWORD',
        'y': [{'y2': 'SECRET'}],
        'z': [{'z1': 'PASSWORD', 'z2': 'SECRET'}],
    }
    no_log_strings = ['PASSWORD', 'SECRET']

    ref1 = {
        'x': 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER',
        'y': [{'y2': 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'}],
        'z': [{'z1': 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER', 'z2': 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'}],
    }


# Generated at 2022-06-22 21:57:41.654889
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_STUB'] = 'stub_value'
    assert env_fallback('ANSIBLE_STUB') == 'stub_value'
    os.environ.pop('ANSIBLE_STUB')
    try:
        env_fallback('ANSIBLE_FAKE')
        assert False
    except AnsibleFallbackNotFound:
        pass
    assert env_fallback('ANSIBLE_FAKE', 'ANSIBLE_FAKE', 'ANSIBLE_STUB') == 'ANSIBLE_STUB'


# Generated at 2022-06-22 21:57:48.764193
# Unit test for function set_fallbacks
def test_set_fallbacks():
    spec = {
        'param1': {
            'type': 'str',
            'fallback': (env_fallback, 'TEST_ENV_VAR')
        }
    }
    parameters = {}
    set_fallbacks(spec, parameters)
    assert 'param1' not in parameters
    parameters = {}
    os.environ['TEST_ENV_VAR'] = 'testing'
    set_fallbacks(spec, parameters)
    assert 'param1' in parameters



# Generated at 2022-06-22 21:57:51.068697
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('TEST_VARIABLE_NOT_SET') == AnsibleFallbackNotFound



# Generated at 2022-06-22 21:58:02.290050
# Unit test for function sanitize_keys
def test_sanitize_keys():
    """Test the behaviour of the sanitize_keys function"""
    test_string = u('test_string')
    assert test_string == sanitize_keys(test_string, no_log_strings=['test_string'])

    test_string_unicode = u('test_string_\u263a')
    assert test_string_unicode == sanitize_keys(test_string_unicode, no_log_strings=['test_string_\u263a'])

    # List
    test_list = [1, 2, 3]
    assert test_list == sanitize_keys(test_list, no_log_strings=['test_string'])
    test_list.append(test_string)

# Generated at 2022-06-22 21:58:13.433164
# Unit test for function set_fallbacks
def test_set_fallbacks():
    '''
    Test for set_fallbacks
    '''

    # Test for simple fallback
    argument_spec = {
        'name': {'required': True, 'fallback': (env_fallback, 'ANSIBLE_TEST_FOO')},
    }
    parameters = {}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['name'] == 'bar'
    assert no_log_values == set()

    # Test for multiple fallbacks
    argument_spec = {
        'name': {'required': True, 'fallback': (env_fallback, 'ANSIBLE_TEST_BAR',
                                                'ANSIBLE_TEST_BAZ', 'ANSIBLE_TEST_FOO')}
    }
    parameters = {}
    no_log_values = set

# Generated at 2022-06-22 21:58:24.163914
# Unit test for function sanitize_keys
def test_sanitize_keys():
    def assert_no_log(value):
        # If the sanitizing function was run, the value will have been removed. However,
        # if it was not run, we will also get AssertionError.
        assert_raises(AssertionError, assert_no_log_value, value)

    def assert_no_log_value(value):
        # If the sanitizing function was run, the value will have been removed.
        assert not value

    # Test with a single string value
    value = 'helloworld'
    no_log_strings = set([value])
    test_obj = {'hello': {value: 'world'}}
    expected_obj = copy.deepcopy(test_obj)
    sanitize_keys(test_obj, no_log_strings)
    assert not test_obj['hello']


# Generated at 2022-06-22 21:58:35.795166
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        foo=dict(fallback=(env_fallback, 'foo', 'bar')),
        baz=dict(type='float', fallback=(env_fallback, ['baz']))
    )
    parameters = dict()
    assert set_fallbacks(argument_spec, parameters) == set()
    assert parameters == dict()
    os.environ['foo'] = 'my foo'
    assert set_fallbacks(argument_spec, parameters) == set(['my foo'])
    assert parameters == dict(foo='my foo')
    os.environ['baz'] = 'my baz'
    assert set_fallbacks(argument_spec, parameters) == set(['my foo', 'my baz'])
    assert parameters == dict(foo='my foo', baz='my baz')

# Generated at 2022-06-22 21:58:46.138159
# Unit test for function sanitize_keys
def test_sanitize_keys():
    strings = ['to_sanitize', 'secret', 'password', 'PASSWORD', 'secret phrase', 'passwd', 'pwd', 'pw']
    no_log_strings = set(strings)
    ignore_keys = ['_ansible_ignore', '_ansible_no_log']

# Generated at 2022-06-22 21:58:49.040649
# Unit test for function env_fallback
def test_env_fallback():
    assert('ANSIBLE_FOO_BAR' in os.environ)
    assert(env_fallback('ANSIBLE_FOO_BAR') == 'baz')



# Generated at 2022-06-22 21:59:01.471126
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # No fallbacks set
    assert set_fallbacks({'not': {'type': 'str'}}, {'not': 'fallback'}) == set()
    assert set_fallbacks({'no': {'type': 'str'}}, {}) == set()
    # Fallback with no arguments
    assert set_fallbacks({'def': {'type': 'str', 'fallback': (env_fallback,)}}, {}) == set()
    # Fallback with arguments
    assert set_fallbacks({'def': {'type': 'str', 'fallback': (env_fallback, ['HOME', 'USER', 'USERNAME'])}}, {}) == set()
    # Fallback with kwargs

# Generated at 2022-06-22 21:59:13.509421
# Unit test for function remove_values
def test_remove_values():
    result = remove_values('foo', set(['f', 'oo', 'o']))
    assert result == '*oo'

    result = remove_values('foo', set(['f', 'oo', 'o', '*']))
    assert result == '****'

    result = remove_values(None, set())
    assert result is None

    result = remove_values(1, set())
    assert result == 1

    result = remove_values(dict(a=1, b=dict(a=1, b=2)), set())
    assert result == dict(a=1, b=dict(a=1, b=2))

    result = remove_values(dict(a=1, b=dict(a=1, b='foo')), set(['foo']))

# Generated at 2022-06-22 21:59:25.579385
# Unit test for function remove_values
def test_remove_values():
    value = {
        'a': {
            'b': [
                'a:b:c:d:e',
                'f:g:h:i:j',
                'k:l:m:n:o',
                'p:q:r:s:t',
            ],
            'c': {
                'd': 'a:b:c:d:e',
            },
        },
        'b': [
            'a:b:c:d:e',
            'f:g:h:i:j',
            {
                'c': 'a:b:c:d:e',
            },
        ],
        'c': 'a:b:c:d:e',
    }


# Generated at 2022-06-22 21:59:36.304032
# Unit test for function sanitize_keys
def test_sanitize_keys():
    """Unit tests to verify that sanitize_keys works as expected.
    """
    # Py2 vs. Py3 differences, what a joy they are.

# Generated at 2022-06-22 21:59:41.689930
# Unit test for function env_fallback
def test_env_fallback():
    """Test env_fallback"""

    with patch.dict(os.environ):
        del os.environ['TEST']
        assert env_fallback('TEST') is None

        os.environ['TEST'] = 'test'
        assert env_fallback('TEST') == 'test'

        del os.environ['TEST']
        assert env_fallback('TEST') is None



# Generated at 2022-06-22 21:59:54.442942
# Unit test for function sanitize_keys
def test_sanitize_keys():
    test_data = dict(
        string='foo',
        list=[dict(
            string='bar',
            dict={'string': 'baz'},
        )],
    )
    expected_data = dict(
        string='foo',
        list=[dict(
            string='bar',
            dict={'string': 'baz'},
        )],
    )

    assert sanitize_keys(test_data, [], set()) == expected_data

    test_data = dict(
        string='foo',
        list=[dict(
            string='bar',
            dict={'string': 'baz'},
        )],
    )

# Generated at 2022-06-22 21:59:59.235406
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('a') == os.environ['a']
    assert env_fallback('a', 'b') == os.environ['a']
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('x')



# Generated at 2022-06-22 22:00:05.292813
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['FOO'] = 'bar'
    assert env_fallback('FOO') == 'bar'
    assert env_fallback('BAR', 'FOO') == 'bar'
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('BAR')
    del os.environ['FOO']


# Generated at 2022-06-22 22:00:14.859042
# Unit test for function remove_values
def test_remove_values():
    # pylint: disable=import-error
    from io import BytesIO
    from io import StringIO
    from ansible.constants import DEFAULT_STDOUT_JSON_FORMAT
    from ansible.module_utils._text import to_text
    from .json import _write_results_as_json
    answer = '{"one": "two", "three": "four", "five": "six"}'
    answer = to_text(answer, DEFAULT_STDOUT_JSON_FORMAT)
    result = dict(ansible_facts=dict(some_fact='some_value'),
                  changed=False,
                  foo='bar',
                  rc=0,
                  stderr='ERROR',
                  stdout='SUCCESS')

# Generated at 2022-06-22 22:00:25.503545
# Unit test for function sanitize_keys
def test_sanitize_keys():
    '''
    Test that deep objects have the keys containing no_log data sanitized.
    '''
    secret = 'secret string'
    not_logged_dict = {
        'key1': 'value1',
        'key2': 'value2',
        'key3': {
            secret: 'should not be logged'
        }
    }
    not_logged_list = [
        'item1',
        {
            'item2key1': 'item2value1',
            'item2key2': 'item2value2',
            secret: 'should not be logged'
        },
        [
            56,
            {
                secret: 'should not be logged'
            },
            'item3value'
        ]
    ]
    not_logged_set = set()
    not_logged_

# Generated at 2022-06-22 22:00:30.049563
# Unit test for function env_fallback
def test_env_fallback():
    expected_value = 'foo'
    os.environ['ANSIBLE_FOO'] = expected_value
    assert expected_value == env_fallback('ANSIBLE_FOO')
    assert os.environ['ANSIBLE_FOO'] == env_fallback('ANSIBLE_FOO')



# Generated at 2022-06-22 22:00:42.590449
# Unit test for function remove_values
def test_remove_values():
    # Test base cases
    assert remove_values(None, []) == None
    assert remove_values(None, ['None']) == None
    assert remove_values(1, ['1']) == 1

    # Test string type
    assert remove_values('None', ['None']) == ''
    assert remove_values('1', ['1']) == ''
    assert remove_values('test', ['test']) == ''
    assert remove_values('test', ['test', '1']) == ''
    assert remove_values('test', ['test', '']) == ''
    assert remove_values('test', ['test', 'None', '1']) == ''
    assert remove_values('test', ['', 'None', '1']) == ''
    assert remove_values('test', ['None', '1']) == ''

# Generated at 2022-06-22 22:00:53.099902
# Unit test for function sanitize_keys
def test_sanitize_keys():
    from ansible.module_utils.basic import AnsibleModule
    no_log_strings = AnsibleModule()._log_gather_no_log_strings([])

# Generated at 2022-06-22 22:00:57.829121
# Unit test for function env_fallback
def test_env_fallback():
    with mock.patch('os.environ', {'a': 'b'}):
        assert env_fallback('a') == 'b'
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('bad')


# Generated at 2022-06-22 22:01:07.461077
# Unit test for function set_fallbacks

# Generated at 2022-06-22 22:01:19.757320
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys('foo', None) == 'foo'
    assert sanitize_keys(b'foo', None) == b'foo'
    assert sanitize_keys(u'foo', None) == u'foo'
    assert sanitize_keys(123, None) == 123
    assert sanitize_keys(True, None) is True
    assert sanitize_keys(None, None) is None

    assert sanitize_keys({'foo': 'bar'}, None) == {'foo': 'bar'}
    with pytest.raises(TypeError):
        sanitize_keys(['foo'], None)

    assert sanitize_keys({'foo': 'bar'}, ['bar']) == {'f[FILTERED]o': 'bar'}