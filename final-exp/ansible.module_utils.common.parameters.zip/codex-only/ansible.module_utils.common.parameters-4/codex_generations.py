

# Generated at 2022-06-22 21:51:26.532200
# Unit test for function sanitize_keys
def test_sanitize_keys():
    # Test with lists
    data = {'first_value': [
        {'merge_res': [
            {'ansible_password': '12345'},
            {'ansible_password': '56789'}]}]}


    expected = {'first_value': [
        {'merge_res': [
            {'ansible_passwor': '12345'},
            {'ansible_passwor': '56789'}]}]}

    # 'ansible_password' should be replaced with 'ansible_passwor'
    assert expected == sanitize_keys(data, ['password'])


    # Test with dicts
    data = {'first_value': {
        'ansible_password': '12345'}}


# Generated at 2022-06-22 21:51:33.944566
# Unit test for function remove_values
def test_remove_values():
    """Returns True if function remove_values() works properly"""
    # Test list
    test_list = [1, {'abc': 'abc'}, 3, [{'bcd': 'bcd'}, 5, 2], 4]
    no_log_strings = ['abc', 'bcd']
    assert remove_values(test_list, no_log_strings) == [1, {'***': '***'}, 3, [{'***': '***'}, 5, 2], 4]

    # Test string
    test_string = 'abc'
    no_log_strings = ['abc']
    assert remove_values(test_string, no_log_strings) == '***'

    # Test dictionary

# Generated at 2022-06-22 21:51:43.166779
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        test1=dict(type='str', default='test1'),
        test2=dict(type='str', fallback=(env_fallback, 'ANSIBLE_TEST2')),
        test3=dict(type='str', fallback=(env_fallback, 'ANSIBLE_TEST3', 'default')),
        test4=dict(type='str', fallback=(lambda: 'default')),
        test5=dict(type='str', no_log=True, fallback=(env_fallback, 'ANSIBLE_TEST5')),
    )
    parameters = dict()

    assert set_fallbacks(argument_spec, parameters) == set()
    assert parameters == dict(test1='test1')

    os.environ['ANSIBLE_TEST2'] = 'test2'
    assert set_

# Generated at 2022-06-22 21:51:48.317602
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_FALLBACK'] = 'fallback'
    assert env_fallback('ANSIBLE_FALLBACK') == os.environ['ANSIBLE_FALLBACK']
    del os.environ['ANSIBLE_FALLBACK']
    assert env_fallback('ANSIBLE_FALLBACK') == os.environ['ANSIBLE_FALLBACK']



# Generated at 2022-06-22 21:51:59.352273
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert set_fallbacks(dict(a=dict(type='str', fallback=(env_fallback, 'VARIABLE'))), {}) == set()
    assert set_fallbacks(dict(a=dict(type='str', fallback=(env_fallback, 'VARIABLE'))), {'a': ''}) == set()
    assert set_fallbacks(dict(a=dict(type='str', fallback=(env_fallback, 'VARIABLE'))), {}) == set()
    assert set_fallbacks(dict(a=dict(type='str', fallback=(env_fallback, 'VARIABLE'), no_log=False)), {}) == set()

    os.environ['VARIABLE'] = 'value'

# Generated at 2022-06-22 21:52:09.332904
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys({'a': 'b'}, set()) == {'a': 'b'}
    assert sanitize_keys([1, 2, 3], set()) == [1, 2, 3]
    assert sanitize_keys('a', set()) == 'a'
    assert sanitize_keys(1, set()) == 1
    assert sanitize_keys(None, set()) is None

    assert sanitize_keys({'a': 'b'}, {'b'}) == {'a': 'b'}
    assert sanitize_keys([1, 2, 3], {2}) == [1, 2, 3]
    assert sanitize_keys('a', {'a'}) == 'a'
    assert sanitize_keys(1, {1}) == 1

# Generated at 2022-06-22 21:52:15.723761
# Unit test for function env_fallback
def test_env_fallback():
    """ Test case for function 'env_fallback' """

    import os
    import tempfile
    curr_env = os.environ

    def _setenv(key, val):
        os.environ[key] = val

    def _del_env(key):
        del os.environ[key]


# Generated at 2022-06-22 21:52:24.072712
# Unit test for function sanitize_keys
def test_sanitize_keys():
    data = {
        'user': 'foo',
        'password': 'bar',
        'port': 22,
        'log_path': '/var/log/my.log',
        'partially_secret': {
            'a': 'foo',
            'b': 'bar',
        },
        'secret': {
            'user': 'foo',
            'password': 'bar',
        },
        'mixed_list': [1, 2, 3, {'b': 'secret'}],
        'mixed_dict': {'a': 'public', 'b': 'secret'},
        'no_secret': {
            'a': 'foo',
            'b': 'bar',
        },
    }
    new_data = sanitize_keys(data, ['bar'], set())


# Generated at 2022-06-22 21:52:35.813653
# Unit test for function remove_values
def test_remove_values():
    from copy import deepcopy

    class Dummy(object):
        def __init__(self, value):
            self.value = value

        def __str__(self):
            return '<Dummy value: {0}>'.format(self.value)

        def __repr__(self):
            return '<Dummy value: {0}>'.format(self.value)


# Generated at 2022-06-22 21:52:39.977757
# Unit test for function remove_values
def test_remove_values():
    assert remove_values('test_value', []) == 'test_value'
    assert remove_values({'key1': 'test_value', 'key2': 'test_value'}, []) == {'key1': 'test_value', 'key2': 'test_value'}
    assert remove_values({'key1': 'test_value', 'key2': 'test_value'}, ['test_value']) == {'key1': [], 'key2': []}
    assert remove_values(['test_value', 'test_value'], ['test_value']) == [[], []]

# Generated at 2022-06-22 21:52:50.134398
# Unit test for function set_fallbacks
def test_set_fallbacks():

    test_params = {}
    test_spec = {'param1':{'type': 'str', 'fallback':(None, ['arg1'])}, 'param2':{'type': 'str', 'fallback':(env_fallback, ['env_var'])}}

    no_log = set_fallbacks(test_spec, test_params)
    assert 'param1' not in test_params
    assert 'param2' not in test_params

    test_params['param2'] = 'Hello'
    no_log = set_fallbacks(test_spec, test_params)
    assert 'param1' not in test_params
    assert 'param2' == test_params['param2']

    test_params['param1'] = 'Hello_again'

# Generated at 2022-06-22 21:52:58.283731
# Unit test for function sanitize_keys
def test_sanitize_keys():
    """ unit test for function sanitize_keys """
    from ansible.module_utils.basic import AnsibleModule
    import json

    with open('tests/sanitize_keys.json') as data_file:
        data = json.load(data_file)

    test = dict()
    for test_case in data:
        test[test_case['input']] = test_case['output']

    module = AnsibleModule(argument_spec=dict())
    results = sanitize_keys(test, set())
    module.exit_json(changed=False, ansible_facts=dict(sanitize_keys_result=results))



# Generated at 2022-06-22 21:53:10.017752
# Unit test for function remove_values
def test_remove_values():
    assert remove_values(None, ['xxx']) is None
    assert remove_values(1, ['xxx']) == 1
    assert remove_values('foo', ['xxx']) == 'foo'
    assert remove_values('foo xxx', ['xxx']) == 'foo xxx'
    assert remove_values('foo xxx bar', ['xxx']) == 'foo xxx bar'
    assert remove_values('foo xxx bar xxx', ['xxx']) == 'foo xxx bar xxx'
    assert remove_values('xxx bar xxx', ['xxx']) == 'xxx bar xxx'
    assert remove_values('foo bar baz', ['xxx']) == 'foo bar baz'
    assert remove_values('bar', ['xxx', 'x']) == 'bar'
    assert remove_values('bar', ['xxx', 'bar'])

# Generated at 2022-06-22 21:53:19.641514
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        param1=dict(type='str', fallback=(env_fallback, ['PARAM1']))
    )
    tests = [
        {'args': (argument_spec, dict()), 'expect': set(['fake_secret'])}
    ]
    # Set the environment variable
    os.environ['PARAM1'] = 'fake_secret'
    for t in tests:
        set_fallbacks(*t['args'])
        assert os.environ['PARAM1'] == t['expect'].pop()
    # Clear the environment variable
    del os.environ['PARAM1']



# Generated at 2022-06-22 21:53:30.265776
# Unit test for function set_fallbacks

# Generated at 2022-06-22 21:53:40.365065
# Unit test for function remove_values
def test_remove_values():
    '''
        unit test for function remove_values
    '''
    # Test list type
    lst = ['a', 'b', 'c']
    no_log_string = ['c']
    assert remove_values(lst, no_log_string) == ['a', 'b']
    lst = ['a', 'b', 'c']
    no_log_string = ['c', 'a']
    assert remove_values(lst, no_log_string) == ['b']
    lst = ['a', 'b', 'c']
    no_log_string = ['c', 'a', 'd']
    assert remove_values(lst, no_log_string) == ['b']
    # Test set type
    s = {'a', 'b', 'c'}

# Generated at 2022-06-22 21:53:50.841373
# Unit test for function sanitize_keys
def test_sanitize_keys():

    # Test simple dictionary
    test_dict = {
        'password': 'V3rYS3cret',
        'username': 'testuser',
    }
    test_dict_copy = copy.deepcopy(test_dict)
    test_dict_result = {
        'stored_password': 'V3rYS3cret',
        'username': 'testuser',
    }
    result = sanitize_keys(test_dict, ['password', 'V3rYS3cret'], ignore_keys=['username'])
    assert test_dict == test_dict_copy
    assert result == test_dict_result

    # Test dictionary with nested dictionary

# Generated at 2022-06-22 21:54:02.485026
# Unit test for function remove_values
def test_remove_values():
    # From module_utils/basic.py
    no_log_strings = ['authorize', 'no_log', 'password', 'secret', 'ssh_pass', 'become_pass']

    def check_remove(data, expected):
        result = remove_values(data, no_log_strings)
        assert result == expected, (result, expected)

    # Lists
    input_data = [
        'authorize',
        ['authorize'],
        {'authorize': ['password', 'secret']},
        {'authorize': [{'password': 'ssh_pass', 'secret': 'become_pass'}]},
        [{'authorize': 'authorize'}, ['authorize', ['authorize'], {'authorize': 'authorize'}]],
    ]

# Generated at 2022-06-22 21:54:11.467101
# Unit test for function set_fallbacks

# Generated at 2022-06-22 21:54:20.712926
# Unit test for function set_fallbacks
def test_set_fallbacks():
    parameter_spec = dict(param1=dict(fallback=(env_fallback, ["ANSIBLE_PARAM1", "ANSIBLE_PARAM2"], {})),
                          param2=dict(fallback=(env_fallback, "ANSIBLE_PARAM4", {}), no_log=True))

    parameters = {}
    no_log_values = set_fallbacks(parameter_spec, parameters)
    assert parameters['param1'] == 'some value'
    assert 'some value' not in no_log_values

    parameters = {}
    no_log_values = set_fallbacks(parameter_spec, parameters)
    assert parameters['param2'] == 'some value'
    assert 'some value' in no_log_values

    parameters = {}
    no_log_values = set_fallbacks(parameter_spec, parameters)


# Generated at 2022-06-22 21:54:31.790312
# Unit test for function remove_values
def test_remove_values():
    # test for strings
    assert '' == remove_values('my password is 1234', ['my password is 1234'])
    assert '[REDACTED]' == remove_values('my password is 1234', ['1234'])
    assert 'my password is [REDACTED]' == remove_values('my password is 1234', ['my password is 1234', '1234'])
    assert 'my password is [REDACTED]' == remove_values('my password is 1234', ['1234', 'my password is 1234'])

    # test for lists
    assert remove_values([], ['my password is 1234']) == []
    assert remove_values(['my password is 1234'], ['my password is 1234']) == ['[REDACTED]']
    assert remove_values(['my password is 1234'], ['1234']) == ['my password is [REDACTED]']


# Generated at 2022-06-22 21:54:39.998250
# Unit test for function remove_values
def test_remove_values():
    str1 = 'someword:somevalue'
    str2 = 'word'
    str3 = 'word:value'
    lst1 = [{'someword': {'somevalue': 'somevalue'}}, str1]
    lst2 = [str2, str2]
    lst3 = [str1, str2]
    dct1 = {'someword': 'somevalue', 'anotherword': 'anothervalue'}
    dct2 = {'someword': 'somevalue', 'anotherword': 'anothervalue'}
    dct3 = {'word': 'value'}
    str_private = 'private'
    str_no_log = 'no_log'
    str_value_private = 'password'
    str_value_no_log = 'secret'
    lst_private

# Generated at 2022-06-22 21:54:47.781679
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Test a file path listed as a fallback
    fallback_path = "/path/to/fallback"
    # Create a file at location listed as fallback
    with open(fallback_path, 'w') as f:
        f.write("fallback value")
    # Test argument spec with file path as fallback
    test_arg_spec = {
        "param": {
            "type": "path",
            "fallback": (env_fallback, os.path.expanduser(fallback_path)),
        }
    }
    # Assign an empty parameters dictionary
    test_parameters = {}
    # Verify that the file path is in the no_log_values set
    assert isinstance(set_fallbacks(test_arg_spec, test_parameters), set)
    assert fallback_path in set_fall

# Generated at 2022-06-22 21:54:51.972340
# Unit test for function remove_values
def test_remove_values():
    value = dict(
        one=1,
        two=dict(
            foo='bar',
            baz=dict(
                three=dict(
                    four=4,
                    five=5
                ),
                six=6
            )
        ),
        seven=[7, dict(eight=8)],
        nine={9, dict(ten=10)},
    )

    expected = dict(
        one=1,
        two=dict(
            foo='******',
            baz=dict(
                three=dict(
                    four=4,
                    five=5
                ),
                six=6
            )
        ),
        seven=[7, dict(eight=8)],
        nine={9, dict(ten=10)}
    )

    no_log_strings = ['bar']

    new_value = remove

# Generated at 2022-06-22 21:55:02.878793
# Unit test for function env_fallback
def test_env_fallback():
    # with an env variable set
    os.environ['FOO'] = 'bar'
    assert env_fallback('FOO') == 'bar'
    # with two env variables set, the first
    os.environ['BAR'] = 'foo'
    assert env_fallback('FOO', 'BAR') == 'bar'
    # with two env variables set, the second
    del os.environ['FOO']
    assert env_fallback('FOO', 'BAR') == 'foo'
    # with no env variables set
    del os.environ['BAR']
    try:
        env_fallback('FOO', 'BAR')
    except AnsibleFallbackNotFound:
        assert True
    else:
        assert False, "env_fallback didn't throw AnsibleFallbackNotFound"
    #

# Generated at 2022-06-22 21:55:13.653414
# Unit test for function remove_values
def test_remove_values():
    assert remove_values('foobar', ['bar']) == 'foo'
    assert remove_values('barbaz', ['bar', 'baz']) == ''
    assert remove_values('bazqux', ['bar', 'baz']) == 'qux'
    assert remove_values('foobazqux', ['bar', 'baz']) == 'fooqux'
    assert remove_values(['foo', 'bar'], ['bar']) == ['foo']
    assert remove_values(['bar'], ['bar']) == []
    assert remove_values(['bar'], []) == ['bar']
    assert remove_values({'foo': 'bar'}, ['bar']) == {'foo': ''}

# Generated at 2022-06-22 21:55:25.870517
# Unit test for function sanitize_keys
def test_sanitize_keys():
    """Test for sanitize_keys"""
    assert sanitize_keys(dict(key='value'), ('value',)) == dict(key='********')

# Generated at 2022-06-22 21:55:36.098380
# Unit test for function sanitize_keys
def test_sanitize_keys():
    # Test the sanitize_keys function
    no_log_strings = set()

    obj = {
        'foo': 'bar',
        'foobar': 'bar',
        'foo-bar': 'bar',
        'bar': 'foo',
    }

    result = {
        'foo': 'bar',
        'foobar': 'bar',
        'foo-bar': 'bar',
        'bar': 'foo'
    }

    no_log_strings.add('foo')

    ansible_obj = sanitize_keys(obj, no_log_strings)
    assert ansible_obj == result

    # Make sure we can handle nested structures

# Generated at 2022-06-22 21:55:40.655674
# Unit test for function remove_values
def test_remove_values():
    # Test scalar removal
    assert remove_values("PASSWORD", ['PASSWORD']) == 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'

    # Test collections
    assert remove_values("PASSWORD", ['PASSWORD']) == 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'
    assert remove_values("PASSWORD", ['PASSWORD']) == 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'
    assert remove_values("PASSWORD", ['PASSWORD']) == 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'



# Generated at 2022-06-22 21:55:52.911793
# Unit test for function env_fallback
def test_env_fallback():

    os.environ['ANSIBLE_NETCONF_SSH_KEYFILE'] = 'passed'
    result = env_fallback('ANSIBLE_NETCONF_SSH_KEYFILE')
    del(os.environ['ANSIBLE_NETCONF_SSH_KEYFILE'])
    assert result == 'passed'
    # Test raising of error when env_fallback fails
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('ANSIBLE_NETCONF_SSH_KEYFILE')

# Test case for env_fallback with various inputs
# Parameters parsed to env_fallback via args should be strings
# Asserts TypeError when parameters are not strings
# Asserts fallback_not_found when env variable does not exist

# Generated at 2022-06-22 21:56:01.949906
# Unit test for function set_fallbacks

# Generated at 2022-06-22 21:56:09.013630
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['TEST'] = 'foo'
    assert env_fallback('TEST') == 'foo'
    assert env_fallback('TEST', 'TESTING') == 'foo'
    assert env_fallback('TESTING') == 'foo'
    os.environ.pop('TEST')
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('TEST')



# Generated at 2022-06-22 21:56:17.353305
# Unit test for function sanitize_keys
def test_sanitize_keys():
    test_data = [
        (
            {
                'my_key': 'my_value',
                'my_key_hidden': 'my_value_hidden',
            },
            {
                'my_key': 'my_value',
                'hidden': 'my_value_hidden',
            }
        ),
        (
            {
                'my_key': {
                    'my_key_hidden': 'my_value_hidden',
                    'my_key': 'my_value',
                },
            },
            {
                'my_key': {
                    'hidden': 'my_value_hidden',
                    'my_key': 'my_value',
                },
            }
        ),
    ]

    for test in test_data:
        assert sanitize_keys(test[0], ['hidden']) == test

# Generated at 2022-06-22 21:56:23.074041
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ansible_test_var'] = "test"
    assert env_fallback('ansible_test_var') == "test"
    assert env_fallback('ansible_test_var', 'another_test_var') == "test"
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('another_test_var')



# Generated at 2022-06-22 21:56:29.266038
# Unit test for function set_fallbacks

# Generated at 2022-06-22 21:56:39.441359
# Unit test for function set_fallbacks
def test_set_fallbacks():
    parameters = {'test_parameter_one': 1}
    argument_spec = {'test_parameter_one': {'type': 'str'},
                        'test_parameter_two': {'type': 'str', 'fallback': (env_fallback, 'TEST_PARAMETER_TWO')}}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['test_parameter_two'] == os.environ['TEST_PARAMETER_TWO']
    assert 'TEST_PARAMETER_TWO' in no_log_values
    assert 'TEST_PARAMETER_THREE' not in parameters
    assert 'TEST_PARAMETER_THREE' not in no_log_values



# Generated at 2022-06-22 21:56:44.574091
# Unit test for function env_fallback
def test_env_fallback():
    assert None == env_fallback('blah')

    os.environ = {'foo': 'bar'}
    assert 'bar' == env_fallback('foo')

    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('foo', 'bar')


# Generated at 2022-06-22 21:56:54.622728
# Unit test for function sanitize_keys
def test_sanitize_keys():
    obj = [{'playbook_id': 1, 'password': 'supersecret', 'tasks': [{'action': {'module': 'mymodule', 'private': {'x': 1, 'y': 2, 'foo': 'supersecret'}}, 'tags': ['always']}], 'hosts': ['all']}]
    no_log_strings = [{'hosts': ['all'], 'password': 'supersecret'}]
    ignore_keys = frozenset({'action', 'module', 'tasks', 'playbook_id'})


# Generated at 2022-06-22 21:57:04.445664
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['TEST_FOO'] = 'foo'
    os.environ['TEST_BAR'] = 'bar'
    assert env_fallback("TEST_FOO", "TEST_BAR") == os.environ['TEST_FOO']
    assert env_fallback("TEST_BAR", "TEST_BAZ") == os.environ['TEST_BAR']
    try:
        env_fallback("TEST_BAZ")
        assert False
    except AnsibleFallbackNotFound:
        pass

    try:
        env_fallback("TEST_BAR", "TEST_BAZ")
        assert False
    except AnsibleFallbackNotFound:
        pass


# Generated at 2022-06-22 21:57:13.829018
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys({'key1':'value1','key2':'value2'},set('key1')) == {'key2':'value2'}
    assert sanitize_keys([{'key1':'value1','key2':'value2'},{'key1':'value1','key2':'value2'}],set('key1')) == [{'key2':'value2'},{'key2':'value2'}]
    assert sanitize_keys({'key1':'value1','key2':'value2'},set('key1'), {'key2'}) == {'key1':'value1','key2':'value2'}



# Generated at 2022-06-22 21:57:15.439794
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback(test_env='test') == 'test'


# Generated at 2022-06-22 21:57:24.442645
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(test1=dict(type='str', fallback=('env', 'test2', 'test3')),
                         test2=dict(type='str', fallback=('env', 'test3')),
                         test3=dict(type='str', no_log=True, fallback=('env', 'test4')),
                         test4=dict(type='str'))
    parameters = dict(test1='a', test2='b')
    result = set_fallbacks(argument_spec, parameters)
    assert result == {'a'}


# Generated at 2022-06-22 21:57:32.125820
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert_equals("""{
    "ansible_python_interpreter": "python", 
    "ansible_password": "REDACTED", 
    "ansible_ssh_pass": "REDACTED", 
    "ansible_become_password": "REDACTED", 
    "secret": "potatoe"
}""", to_text(sanitize_keys({
    "ansible_password": 'foo',
    "ansible_become_password": 'foo',
    "ansible_ssh_pass": 'bar',
    'secret': 'potatoe',
    'ansible_python_interpreter': 'python'
}, ['foo', 'bar'])))



# Generated at 2022-06-22 21:57:43.743669
# Unit test for function sanitize_keys
def test_sanitize_keys():
    obj = {
        u'abc': 'abc',
        u'abcde': 'abcde',
        '_ansible_sensitive_backup': {
            u'abc': 'abc',
            u'abcde': 'abcde',
            '_ansible_sensitive_backup': {
                u'abc': 'abc',
                u'abcde': 'abcde',
                '_ansible_no_log': None
            }
        },
        '_ansible_no_log': None
    }

    # These strings will be sanitized
    no_log_strings = ['abc', 'def']
    ignore_keys = ['ignored']

# Generated at 2022-06-22 21:57:54.181892
# Unit test for function sanitize_keys
def test_sanitize_keys():
    yaml_str = """---
    foo:
      - 'bar':
          password: 'foo_password'
        ssh_port: 22
      - 'bar2':
          password: 'bar2_password'
          ssh_port: 22
    """
    data = parse_yaml(yaml_str)
    assert sanitize_keys(data, ['foo_password', 'bar2_password']) == {'foo': [{'bar': {'password': 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER', 'ssh_port': 22}}, {'bar2': {'password': 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER', 'ssh_port': 22}}]}



# Generated at 2022-06-22 21:58:00.050229
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['var'] = 'value'
    assert env_fallback('var') == 'value'
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('does_not_exist')

    # Only the first of multiple matches should be returned
    os.environ['var'] = 'another_value'
    assert env_fallback('var', 'does_not_exist') == 'value'



# Generated at 2022-06-22 21:58:11.612428
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Test 1: Test for all fallback strategies
    argument_spec = {
        'test_str': {'type': 'str', 'fallback': (env_fallback, 'test_env')},
        'test_list': {'type': 'list', 'fallback': (lambda: ['a', 'b', 'c'],)},
        'test_dict': {'type': 'dict', 'fallback': (lambda: {'a': 'b'},)},
        'test_bool': {'type': 'bool', 'fallback': (lambda: True,)},
        'test_int': {'type': 'int', 'fallback': (lambda: 1,)},
        'test_missing': {'type': 'int', 'fallback': (env_fallback, 'no_env')},
    }

    parameters = {}



# Generated at 2022-06-22 21:58:18.814684
# Unit test for function env_fallback
def test_env_fallback():
    fake_environ = dict(
        foo='Hello world!',
        bar='foobar',
    )
    with patch.dict(os.environ, fake_environ):
        assert 'Hello world!' == env_fallback('foo')

    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('not_in_fake_environ')

    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('zzz', 'www')



# Generated at 2022-06-22 21:58:21.914818
# Unit test for function env_fallback
def test_env_fallback():
    with mock.patch('os.environ.get', MagicMock(return_value='42')):
        assert env_fallback('MY_TEST_VARIABLE') == '42'


# Generated at 2022-06-22 21:58:34.567266
# Unit test for function set_fallbacks
def test_set_fallbacks():
    mock_spec = {'port': {'type': 'int', 'default': 22},
                 'name': {'type': 'str', 'default': 'ansible'},
                 'user_name': {'type': 'str', 'default': 'root', 'fallback': (env_fallback, ['ANSIBLE_REMOTE_USER'])},
                 'sub_options': {'type': 'dict', 'options': {'sub_options_param': {'type': 'str', 'default': 'sub_options_param_default',
                                                                                   'fallback': (env_fallback, ['sub_options_param_env_var'])}}}}

    assert set_fallbacks(mock_spec, {}) == set()
    assert set_fallbacks(mock_spec, {'port': 80}) == {'root'}

# Generated at 2022-06-22 21:58:44.735144
# Unit test for function remove_values
def test_remove_values():
    assert remove_values("password", ['password']) == 'REDACTED'
    assert remove_values("password123", ['password']) == 'password123'
    assert remove_values("password", []) == 'password'
    assert remove_values("word", ['password']) == 'word'
    assert remove_values("p4ssword", ['password']) == 'p4ssword'
    assert remove_values("pass.word", ['password']) == 'pass.word'
    assert remove_values("pass.word", ['pass', 'word']) == 'REDACTED'
    assert remove_values("password", ['pass', 'word']) == 'REDACTED'
    assert remove_values("pass.word", ['pass']) == 'pass.word'
    assert remove_values("pass.word", ['word']) == 'pass.word'
    assert remove

# Generated at 2022-06-22 21:58:55.329606
# Unit test for function remove_values
def test_remove_values():
    test_data = dict(
        a='a',
        b=dict(
            c='c',
            d='d',
            e=dict(
                f='f',
                g='g',
            ),
            h=dict(
                i=['i', 'j'],
                k=['k', 'l'],
            ),
        ),
    )

    no_log_strings = ['e', 'i', 'k']
    new_value = remove_values(test_data, no_log_strings)

    assert new_value == dict(a='a', b=dict(c='c', d='d', e='**', h=dict(i='**', k='**')))


# Generated at 2022-06-22 21:59:04.752836
# Unit test for function remove_values
def test_remove_values():
    from .test_utils import assert_equal

# Generated at 2022-06-22 21:59:12.692448
# Unit test for function env_fallback
def test_env_fallback():
    "Unit test for function env_fallback"
    # Create the environment variable
    var = 'ANSIBLE_TEST_DATA_FOO'
    value = 'bar'
    os.environ[var] = value
    assert env_fallback(var) == value
    # Remove the environment variable
    del os.environ[var]
    with pytest.raises(AnsibleFallbackNotFound):
        assert env_fallback(var)


# Generated at 2022-06-22 21:59:21.290911
# Unit test for function remove_values
def test_remove_values():
    result = remove_values({'key': 'val', 'password': '123', 'token': 'abc', 'secret': 'xyz'}, ['abc', 'xyz'])
    assert(result == {'key': 'val', 'password': '123', 'token': 'abc', 'secret': 'xyz'})

    result = remove_values({'key': 'val', 'password': '123', 'token': 'abc', 'secret': 'xyz'}, ['abc', 'xyz'], no_log_strings=['abc', 'xyz'])
    assert(result == {'key': 'val', 'password': '123', 'token': '***', 'secret': '***'})


# Generated at 2022-06-22 21:59:30.852670
# Unit test for function remove_values
def test_remove_values():
    assert remove_values('string', ('invalid',)) == 'string'
    assert remove_values(u'unicode_string', ('invalid',)) == u'unicode_string'
    assert remove_values(42, ('invalid',)) == 42
    assert remove_values(3.14, ('invalid',)) == 3.14
    assert remove_values(True, ('invalid',)) is True
    assert remove_values(False, ('invalid',)) is False
    assert remove_values(None, ('invalid',)) is None

    assert remove_values('string', ('string',)) == '<value redacted>'
    assert remove_values([1, 2, 'string'], ('string',)) == [1, 2, '<value redacted>']

# Generated at 2022-06-22 21:59:42.433151
# Unit test for function sanitize_keys
def test_sanitize_keys():
    data = dict(
        dict1=dict(
            _ansible_no_log=True,
            dict2=dict(
                key1='value1',
                key2='value2',
            )
        ),
        dict3=dict(
            _ansible_no_log=True,
            dict4=dict(
                key3='value3',
            )
        ),
        dict5=dict(
            _ansible_no_log=True,
            dict6=dict(
                key4='value4',
            ),
            **{'foo': 'bar'}
        )
    )

    no_log_strings = set(to_native(v) for v in data.values())

    result = sanitize_keys(data, no_log_strings)

# Generated at 2022-06-22 21:59:54.536259
# Unit test for function remove_values

# Generated at 2022-06-22 22:00:00.857697
# Unit test for function env_fallback
def test_env_fallback():
    ''' Test function env_fallback '''
    assert env_fallback('FAKE_ENVVAR') == AnsibleFallbackNotFound
    os.environ['FAKE_ENVVAR'] = 'set'
    assert env_fallback('FAKE_ENVVAR') == 'set'
    del os.environ['FAKE_ENVVAR']


# Generated at 2022-06-22 22:00:11.984442
# Unit test for function remove_values
def test_remove_values():
    # create a string that contains the no_log_string
    # If the no_log_string was "password" then the log_strain would contain password
    log_string = "password"
    no_log_string = "password"
    assert remove_values(log_string, no_log_string) == "********"

    # create a list containing no_log_string
    log_list = ["mypassword", "mypassword2"]
    no_log_list = ["mypassword", "mypassword2"]
    assert remove_values(log_list, no_log_list) == ["********", "********"]

    # create a dict containing no_log_string
    log_dict = {"password":"mypassword", "password2":"mypassword2"}
    no_log_dict = ["mypassword", "mypassword2"]
    assert remove_

# Generated at 2022-06-22 22:00:23.804749
# Unit test for function sanitize_keys
def test_sanitize_keys():
    """
    Test sanitize_keys function
    """
    test_dict = {'a': {'b': 'c'}, 'd':'e', 'f':'g'}
    test_list = [{'a': {'b': 'c'}, 'd':'e', 'f':'g'}, {'a': {'b': 'c'}, 'd':'e', 'f':'g'}]
    test_set = [{'a': {'b': 'c'}, 'd':'e', 'f':'g'}, {'a': {'b': 'c'}, 'd':'e', 'f':'g'}]


# Generated at 2022-06-22 22:00:30.614200
# Unit test for function sanitize_keys
def test_sanitize_keys():
    test_list = [{"key1":"value1", "_ansible_no_log":"value2"}, {"key2":"value2"}, {"_ansible_no_log":"value3"}]
    ansible_list = [{"key1":"value1"}, {"key2":"value2"}, {}]
    assert sanitize_keys(test_list, ['value2', 'value3'], ignore_keys={"_ansible_no_log"}) == ansible_list



# Generated at 2022-06-22 22:00:43.130011
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        name=dict(type='str', fallback=(env_fallback, ['FOO_default'])),
        state=dict(type='str', fallback=(env_fallback, ['FOO_default', {'key': 'value'}])),
        state2=dict(type='str', fallback=(env_fallback, ['FOO_default', {'key': 'value'}]), no_log=True),
    )

    parameters = dict(
        name="testing"
    )

    os.environ['FOO_default'] = 'env_value'

    expected_no_log_values = set()
    expected_parameters = dict(
        name="testing",
        state="env_value",
    )

    # Test with no parameters
    no_log_values = set_fall

# Generated at 2022-06-22 22:00:49.228232
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Check the fallback action for args
    argument_spec = dict(provider=dict(fallback=(env_fallback, dict(fallback_provider='*'))))
    assert set_fallbacks(argument_spec, dict()) == set(['*'])
    # Check the fallback action for kwargs
    assert set_fallbacks(argument_spec, dict()) == set([os.environ['ANSIBLE_NET_USERNAME']])
    # Check the fallback action for kwargs
    assert set_fallbacks(argument_spec, dict()) == set([os.environ['ANSIBLE_NET_USERNAME']])



# Generated at 2022-06-22 22:01:01.372789
# Unit test for function remove_values
def test_remove_values():
    # test list
    assert remove_values(['a', 'b', 'c'], ['b']) == ['a', 'c']
    assert remove_values(['a', ['b', 'c'], 'd'], ['b']) == ['a', ['c'], 'd']
    # test tuples
    assert remove_values(('a', 'b', 'c'), ['b']) == ('a', 'c')
    assert remove_values(('a', ('b', 'c'), 'd'), ['b']) == ('a', ('c'), 'd')
    # test set
    assert remove_values({'a', 'b', 'c'}, ['b']) == {'a', 'c'}

# Generated at 2022-06-22 22:01:09.947434
# Unit test for function remove_values
def test_remove_values():
    no_log_strings = ALL_NO_LOG_VALUES + [u'foo', u'bar', b'baz']

# Generated at 2022-06-22 22:01:18.582992
# Unit test for function env_fallback
def test_env_fallback():
    "Test that env_fallback loads from the environment"

    key = 'ANSIBLE_TEST_FALLBACK'
    os.environ[key] = 'value1'
    assert env_fallback(key) == 'value1'

    assert env_fallback('FALLBACK1', 'FALLBACK2') == 'value1'

    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('FALLBACK_DOES_NOT_EXIST')

