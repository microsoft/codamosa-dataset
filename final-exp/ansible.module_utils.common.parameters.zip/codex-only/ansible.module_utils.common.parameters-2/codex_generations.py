

# Generated at 2022-06-22 21:51:19.090681
# Unit test for function remove_values
def test_remove_values():
    normal_mapping = {'left': 1, 'right': 2}
    no_log_strings = ['left']
    no_log_dict = remove_values(normal_mapping, no_log_strings)
    print('normal_mapping: ', no_log_dict)
    assert 'left' not in no_log_dict


# Generated at 2022-06-22 21:51:26.154359
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'omit_values': {},
        'encrypted_value': {
            'fallback': (env_fallback, ('ENCRYPTED_VALUE',)),
            'no_log': True
        },
        'plaintext_value': {
            'fallback': (env_fallback, ('PLAINTEXT_VALUE',))
        }
    }
    parameters = {
        'omit_values': True
    }
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['plaintext_value'] == os.environ['PLAINTEXT_VALUE']
    assert parameters['encrypted_value'] == os.environ['ENCRYPTED_VALUE']
    assert 'ENCRYPTED_VALUE' in no_log_values

# Generated at 2022-06-22 21:51:35.747241
# Unit test for function remove_values
def test_remove_values():
    test_dict = {
        "key1": 'value1',
        "key2": {
            "key3": 'testing_private_data',
            "key4": 'value4'
        },
        "key5": {
            "key6": [
                'testing_private_data',
                'value7'
            ]
        },
        "key8": [
            "value9",
            "testing_private_data"
        ],
        "key10": [
            {
                "key11": "value12",
                "key13": "testing_private_data"
            }
        ]
    }

# Generated at 2022-06-22 21:51:44.108446
# Unit test for function sanitize_keys
def test_sanitize_keys():
    obj = {
        'foo': {
            'bar': {
                'baz': [
                    {'one': 'two'},
                    {'three': 'four'},
                ],
            },
            'baz': [
                {'one': 'two'},
                {'three': 'four'},
            ],
        },
    }

    new_value = sanitize_keys({'foo': {'bar': {'baz': 'value'}}}, {'baz'})
    assert new_value == {'foo': {'__ansible_sanitized_bar': {'__ansible_sanitized_baz': 'value'}}}

    new_value = sanitize_keys(obj, {'baz'})

# Generated at 2022-06-22 21:51:53.222563
# Unit test for function remove_values

# Generated at 2022-06-22 21:51:58.987002
# Unit test for function sanitize_keys
def test_sanitize_keys():
    obj = {
        "password": "foobar",
        "ssh_key": "barfoo",
        "no_log": "ignoreme",
    }
    result = sanitize_keys(obj, {"foobar", "barfoo"})
    assert result["password"] == "**"
    assert result["ssh_key"] == "**"
    assert result["no_log"] == "ignoreme"
    result = sanitize_keys(obj, {"foobar", "barfoo"}, {"no_log"})
    assert result["password"] == "**"
    assert result["ssh_key"] == "**"
    assert result["no_log"] == "ignoreme"
    result = sanitize_keys(obj, {"foobar", "barfoo"}, {"password"})
    assert result["password"] == "foobar"
   

# Generated at 2022-06-22 21:52:07.058480
# Unit test for function remove_values
def test_remove_values():
    import copy
    import base64
    import json

    # These tests don't catch everything here, just the most obvious cases
    assert remove_values('foo', ['foo']) == 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'
    assert remove_values('foo', ['foo', 'bar']) == 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'
    assert remove_values('foo', ['bar']) == 'foo'
    assert remove_values(['foo', 'bar', 'baz'], ['foo', 'bar']) == ['VALUE_SPECIFIED_IN_NO_LOG_PARAMETER', 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER', 'baz']

# Generated at 2022-06-22 21:52:17.994901
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys(["a", "b", "c"]) == ["a", "b", "c"]
    assert sanitize_keys(["a", []], no_log_strings=["b"]) == ["a", []]
    assert sanitize_keys({"x": "a", "y": "b", "z": "c"}, no_log_strings=["b"]) == {"x": "a", "y": "b", "z": "c"}
    assert sanitize_keys({"x": "a", "y": "b", "z": "c"}, no_log_strings=["b"]) == {"x": "a", "y": "b", "z": "c"}

# Generated at 2022-06-22 21:52:21.996505
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('') == env_fallback('foo', 'bar')


_FALLBACKS = {
    'env': env_fallback,
}



# Generated at 2022-06-22 21:52:30.141666
# Unit test for function sanitize_keys
def test_sanitize_keys():
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.vault import VaultSecret
    from ansible.module_utils.six import binary_type, text_type
    from ansible.module_utils.six.moves import xrange
    from ansible.module_utils.six.moves.queue import Queue
    import ansible.module_utils.six.moves.builtins as __builtin__


# Generated at 2022-06-22 21:52:41.323900
# Unit test for function sanitize_keys
def test_sanitize_keys():
    fake_no_log_strings = ['secret', 'dontlog']
    fake_ignore_keys = ['ignoredkey', 'foo']

    fake_data1 = dict(
        dictonary="foo",
        listonary=[
            dict(
                secret="don't show",
                dontlog="don't log",
                ignoredkey="hidden",
            ),
            dict(
                secret="don't show",
                dontlog="don't log",
                ignoredkey="hidden",
            ),
        ],
        ignoredkey="shown",
        secret="don't show",
        dontlog="don't log",
        foo="bar",
    )
    fake_data2 = dict(
        key=fake_data1,
    )
    fake_data3 = dict(
        key2=fake_data2,
    )

   

# Generated at 2022-06-22 21:52:50.966951
# Unit test for function sanitize_keys
def test_sanitize_keys():
    # Test functions are only visible in the unit test
    # pylint: disable=unused-variable
    wanted = ['password', 'secret', 'authorization', 'passphrase', 'private_key', 'private_key_file', 'secret_key']

    # Binary strings
    no_log_strings = [b'password', b'secret', b'authorization', b'passphrase', b'private_key', b'private_key_file', b'secret_key']
    no_log_strings = set(no_log_strings)

# Generated at 2022-06-22 21:53:00.041960
# Unit test for function remove_values
def test_remove_values():
    value = 'this value has a *********** in it'
    no_log_strings = set(['***********'])
    assert remove_values(value, no_log_strings) == 'this value has a *********** in it'

    value = 'this value does not have ***********'
    no_log_strings = set(['***********'])
    assert remove_values(value, no_log_strings) == 'this value does not have ***********'


# Generated at 2022-06-22 21:53:04.703944
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK_1'] = 'env1'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_1') == 'env1'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_2') == 'env2'



# Generated at 2022-06-22 21:53:12.395307
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_FOO'] = 'bar'
    assert env_fallback('ANSIBLE_FOO') == 'bar'
    del os.environ['ANSIBLE_FOO']
    with pytest.raises(AnsibleFallbackNotFound):
        assert env_fallback('ANSIBLE_FOO')
    assert env_fallback('ANSIBLE_FOO', 'ANSIBLE_FOO') == 'ANSIBLE_FOO'



# Generated at 2022-06-22 21:53:19.953923
# Unit test for function env_fallback
def test_env_fallback():
    env = os.environ.copy()
    os.environ.clear()
    # Test for none existing env_variable
    try:
        env_fallback('TEST')
    except Exception as e:
        assert isinstance(e, AnsibleFallbackNotFound)
    # Test for existing env_variable
    os.environ['TEST'] = 'test'
    test = env_fallback('TEST')
    assert type(test) is str
    os.environ.clear()
    os.environ.update(env)



# Generated at 2022-06-22 21:53:28.192469
# Unit test for function env_fallback
def test_env_fallback():
    import os

    orig_env = os.environ.copy()

    os.environ['ENV_FOO_BAR'] = 'test'
    assert env_fallback('ENV_FOO_BAR') == 'test'
    del os.environ['ENV_FOO_BAR']
    try:
        env_fallback('ENV_FOO_BAR')
        assert False, 'AnsibleFallbackNotFound not raised'
    except AnsibleFallbackNotFound:
        pass

    os.environ = orig_env



# Generated at 2022-06-22 21:53:32.782559
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('FOO', 'BAR') == os.environ["FOO"]
    assert env_fallback('BAR', 'FOO') == os.environ["BAR"]


# This function must be defined outside of the set_fallbacks function to
# prevent a circular dependency when the function calls itself.

# Generated at 2022-06-22 21:53:45.241663
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'foo': {'type': 'str', 'fallback': (env_fallback, 'TEST_FOO')}}
    parameters = {'bar': 'baz'}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert 'foo' not in parameters
    assert no_log_values == set()

    os.environ['TEST_FOO'] = 'baz'
    set_fallbacks(argument_spec, parameters)
    assert parameters['foo'] == 'baz'
    assert 'foo' in parameters
    assert no_log_values == set()



# Generated at 2022-06-22 21:53:55.899536
# Unit test for function sanitize_keys
def test_sanitize_keys():
    """ Unit test for function sanitize_keys
    """

    def _compare_json_files(json_file1, json_file2, msg=None):
        with open(json_file1) as f1:
            with open(json_file2) as f2:
                try:
                    assert json.load(f1) == json.load(f2)
                except AssertionError as e:
                    e.args += (msg,)
                    raise e

    # Test sanitization of str, dict, list and tuples.
    # Also test sanitization of a variant of keys by nesting str and dict.

# Generated at 2022-06-22 21:54:04.831427
# Unit test for function set_fallbacks
def test_set_fallbacks():
    module = argparse.ArgumentParser(description='Test module')
    module.add_argument('foo')
    module.add_argument('bar', nargs='?', default='boo')
    module.add_argument('baz', nargs='?', default='boo')
    module.add_argument('qux', nargs='?', default='boo')
    module.add_argument('corge', nargs='?', default='boo')
    module.add_argument('grault', nargs='?', default='boo')
    module.add_argument('garply', nargs='?', default='boo')
    module.add_argument('waldo', nargs='?', default='boo')
    module.add_argument('fred', nargs='?', default='boo')

# Generated at 2022-06-22 21:54:12.548252
# Unit test for function remove_values
def test_remove_values():
    # Boolean values
    assert remove_values(True, ['True']) == True
    assert remove_values(False, ['False']) == False

    # Numeric values
    assert remove_values(0, ['0']) == 0
    assert remove_values(1, ['1']) == 1
    assert remove_values(2.2, ['2.2']) == 2.2
    assert remove_values(-1, ['-1']) == -1

    # String values
    assert remove_values('', ['']) == ''
    assert remove_values('1', ['1']) == '1'
    assert remove_values('2.2', ['2.2']) == '2.2'
    assert remove_values('-1', ['-1']) == '-1'

    # Container types
    # List
    assert remove

# Generated at 2022-06-22 21:54:18.581230
# Unit test for function sanitize_keys
def test_sanitize_keys():
    origin_data = {'a': [{'b': {'c': 'd'}}, 'e'], 'f': {'g': 'h'}}
    processed_data = {'a': [{'b': {'c': 'd'}}, 'e'], 'f': {'g': 'h'}}
    new_value = sanitize_keys(origin_data, ['g', 'h'])
    assert new_value == processed_data



# Generated at 2022-06-22 21:54:29.597124
# Unit test for function sanitize_keys

# Generated at 2022-06-22 21:54:38.581946
# Unit test for function sanitize_keys
def test_sanitize_keys():
    fail_key = 'fail'
    passed_key = 'passed'
    fail_value = 'remove_me'
    passed_value = 'keep_me'
    data = {fail_key: fail_value, passed_key: passed_value}
    data_missing_key = {fail_key: fail_value}
    data_missing_value = {fail_key: None, passed_key: passed_value}

    # Test the data with the key and value
    result = sanitize_keys(data, set())
    assert result == data
    result = sanitize_keys(data, set([fail_value]), set())
    assert result == data_missing_key

    # Test the data with missing key and value
    result = sanitize_keys(data_missing_key, set())
    assert result == data_missing

# Generated at 2022-06-22 21:54:49.369154
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys('foo', {"foo"}) == 'foo'
    assert sanitize_keys('foo', {"bar"}) == 'foo'

    assert sanitize_keys('_ansible_foo', {"foo"}) == '_ansible_foo'
    assert sanitize_keys('_ansible_foo', {"bar"}) == '_ansible_foo'
    assert sanitize_keys('_ansible_foo', {"foo"}, ignore_keys={"_ansible_foo"}) == '_ansible_foo'

    assert sanitize_keys({'foo': 'bar'}, {"bar"}) == {'foo': 'bar'}
    assert sanitize_keys({'foo': 'bar'}, {"foo"}) == {'foo': 'bar'}

# Generated at 2022-06-22 21:55:00.045823
# Unit test for function sanitize_keys
def test_sanitize_keys():
    result = sanitize_keys({"foo": "bar"}, ["bar"])
    assert result == {"foo": "bar"}
    result = sanitize_keys({"foo": "bar", "hello": "bar"}, ["bar"])
    assert result == {"foo": "bar", "hello": "bar"}
    result = sanitize_keys({"foo": "bar", "hello": "bar", "baz": "bar"}, ["bar"])
    assert result == {"foo": "bar", "hello": "bar", "baz": "bar"}
    result = sanitize_keys({"foo": "bar", "hello": "bar", "baz": "bar", "ANOTHER": "bar"}, ["bar"])

# Generated at 2022-06-22 21:55:12.719310
# Unit test for function set_fallbacks

# Generated at 2022-06-22 21:55:21.575862
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'some_value'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK', 'ANOTHER_ENV_VAR') == 'some_value'
    assert env_fallback('NONEXISTENT_ENV_VAR', 'ANOTHER_ENV_VAR') == 'another_value'
    with pytest.raises(AnsibleFallbackNotFound):
        assert env_fallback('NONEXISTENT_ENV_VAR')



# Generated at 2022-06-22 21:55:26.246386
# Unit test for function env_fallback
def test_env_fallback():
    os.environ.update({'foo': 'bar'})
    assert env_fallback(env='foo') == 'bar'
    assert os.environ.pop('foo') == 'bar'
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback(env='foo')



# Generated at 2022-06-22 21:55:36.372009
# Unit test for function sanitize_keys
def test_sanitize_keys():

    ansible_result = {
            '_ansible_parsed': True,
            '_ansible_no_log': True,
            'invocation': {
                'module_args': {
                    'arg3': '3',
                    'arg1': '1',
                    'arg2': '2'
                },
                'module_name': 'test_module'
            },
            'word': 'Hello There',
            'changed': False,
            'failed': False
        }
    no_log_values = set()
    for key, value in ansible_result.items():
        if value and isinstance(value, string_types):
            no_log_values.add(value)

    tested_result = sanitize_keys(ansible_result, no_log_values)
    print('**********')


# Generated at 2022-06-22 21:55:43.161566
# Unit test for function remove_values
def test_remove_values():
    no_log_strings = ['password', 'secret']
    a, b = {1: {'password': 'secret'}}, {1: {'password': 'secret'}}
    out = remove_values(a, no_log_strings)
    assert b == out
    a, b = [{'password': 'secret'}], [{'password': 'secret'}]
    out = remove_values(a, no_log_strings)
    assert b == out
    a, b = {1: {'password': 'secret'}, 2: {'password': 'secret'}}, {1: {'password': '*****'}, 2: {'password': '*****'}}
    out = remove_values(a, no_log_strings)
    assert b == out

# Generated at 2022-06-22 21:55:55.364723
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert set_fallbacks({'test': {'type': 'str', 'fallback': (env_fallback, 'ANSIBLE_TEST')}}, {}) == set()
    assert set_fallbacks({'test': {'type': 'str', 'fallback': (env_fallback, 'ANSIBLE_TEST')}}, {'test': 'abc'}) == set()
    assert set_fallbacks({'test': {'type': 'str', 'fallback': (env_fallback, 'ANSIBLE_TEST')}}, {}) == {'abc'}
    assert set_fallbacks({'test': {'type': 'str', 'no_log': True, 'fallback': (env_fallback, 'ANSIBLE_TEST')}}, {}) == {'abc'}

# Generated at 2022-06-22 21:56:03.494904
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys(
        {'value': {'a': 'foo', 'b': 'bar', 'c': 'baz'}},
        ['foo']) == {'value': {'a': 'foo', 'b': 'bar', 'c': 'baz'}}

    assert sanitize_keys(
        {'value': {'a': 'foo', 'b': 'bar', 'c': 'baz'}},
        ['bar']) == {'value': {'b': 'bar', 'c': 'baz'}}

    assert sanitize_keys(
        {'value': {'a': 'foo', 'b': 'bar', 'c': 'baz'}},
        ['baz']) == {'value': {'a': 'foo', 'b': 'bar'}}


# Generated at 2022-06-22 21:56:13.332470
# Unit test for function sanitize_keys
def test_sanitize_keys():
    from collections import OrderedDict

    # Simple string value
    assert sanitize_keys('foo', ['foo']) == '***'

    # Simple list value
    data = [1, 2, 3]
    assert sanitize_keys(data, ['3']) == data
    data = [1, 2, '3']
    assert sanitize_keys(data, ['3']) == [1, 2, '***']

    # List of lists
    data = [[1, 2, 3], [4, 5, 6]]
    assert sanitize_keys(data, ['3', ]) == data
    data = [[1, 2, '3'], [4, 5, 6]]
    assert sanitize_keys(data, ['3']) == [[1, 2, '***'], [4, 5, 6]]
    data

# Generated at 2022-06-22 21:56:24.101733
# Unit test for function sanitize_keys
def test_sanitize_keys():
    bad_key = 'my_secret'
    good_key = 'not_my_secret'
    assert bad_key not in sanitize_keys({bad_key: 'my_value'}, [bad_key])
    assert good_key in sanitize_keys({good_key: 'my_value'}, [bad_key])
    assert good_key in sanitize_keys({good_key: 'my_value', bad_key: 'my_secret_value'}, [bad_key])
    assert good_key in sanitize_keys({good_key: 'my_value', bad_key: 'my_secret_value'}, [bad_key], ignore_keys={good_key})

# Generated at 2022-06-22 21:56:35.039111
# Unit test for function sanitize_keys
def test_sanitize_keys():
    from mock import Mock

    class DummyNoLog(object):
        def sensitive_strings(self):
            return ['sensitive']

    class DummyPlugin(object):
        def get_option(name):
            return no_log

        def get_bin_path(name, opts=None, required=False):
            return 'bin_path'

    no_log = DummyNoLog()

    tmp_elem = Mock()
    tmp_elem.__str__ = Mock(return_value='str')
    tmp_elem.__repr__ = Mock(return_value='repr')
    tmp_elem.__class__ = DummyPlugin
    tmp_elem.__iter__ = Mock(return_value=iter([]))
    tmp_elem.__contains__ = Mock(return_value=False)

   

# Generated at 2022-06-22 21:56:43.726277
# Unit test for function remove_values
def test_remove_values():
    """ Test remove_values function """
    # Test with no log strings of lower case and make sure they get removed
    test_dict = {"key": "xxx", "key1": ["xxx", "xx", 123, {"y": "yyy", "z": "xxx"}], "key2": "xx"}
    new_dict = remove_values(test_dict, ['xx', 'yy'])
    assert new_dict == {'key': 'xxx', 'key1': [None, None, 123, {'y': 'yyy', 'z': 'xxx'}], 'key2': 'xx'}, 'remove_values failed'

    # Test with no log strings of upper case and make sure they get removed

# Generated at 2022-06-22 21:56:49.728353
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['test_env_fallback'] = 'success'
    assert env_fallback('test_env_fallback') == 'success'
    os.environ.pop('test_env_fallback')
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('test_env_fallback_fail')


# Generated at 2022-06-22 21:56:56.819586
# Unit test for function remove_values
def test_remove_values():
    # List
    list_with_no_nested = [1, 2, 3, 4]
    list_with_nested = [1, [2, 3], 4]
    list_with_scalar = [1, 2, 3, 4]
    list_with_dict = [{'a': 1}, {'b': 2}]
    assert remove_values(list_with_no_nested, []) == list_with_no_nested
    assert remove_values(list_with_nested, []) == list_with_nested
    assert remove_values(list_with_scalar, []) == list_with_scalar
    assert remove_values(list_with_dict, []) == list_with_dict

# Generated at 2022-06-22 21:57:05.095531
# Unit test for function remove_values
def test_remove_values():
    strings = ['string1', 'string2']
    multi_line_string = 'ab\nc\nd'
    dict_data1 = {'top_level': {'load_balancer_name': 'value1', 'list': [{'load_balancer_name': 'string1'}, {'load_balancer_name': 'string2'}], 'set': set(['string1', 'string2'])}}
    dict_data2 = {'top_level': {'load_balancer_name': 'value1', 'list': [{'load_balancer_name': 'string1'}, {'load_balancer_name': 'string2'}], 'set': set(['string1', 'string2'])}}

# Generated at 2022-06-22 21:57:14.862025
# Unit test for function sanitize_keys
def test_sanitize_keys():
    import pytest
    from copy import deepcopy
    from pprint import pformat

    def _sanitize_keys_assert_equal(old_obj, new_obj, expected, no_log_strings, ignore_keys=frozenset()):
        assert sanitize_keys(deepcopy(old_obj), no_log_strings, ignore_keys=ignore_keys) == expected


# Generated at 2022-06-22 21:57:26.887194
# Unit test for function sanitize_keys
def test_sanitize_keys():
    ''' unit testing for function sanitize_keys '''
    assert sanitize_keys({'a':'b'}, {'b'}) == {'a':'b'}
    assert sanitize_keys({'ab':'b'}, {'b'}) == {'a':'b'}
    assert sanitize_keys({'bc':'b'}, {'b'}) == {'bc':'b'}
    assert sanitize_keys({'ab':'b', 'bc':'b'}, {'b'}) == {'a':'b', 'bc':'b'}
    assert sanitize_keys({'abc':'b'}, {'b'}) == {'a':'b'}

# Generated at 2022-06-22 21:57:37.358853
# Unit test for function remove_values
def test_remove_values():
    # Ensure top-level values are not removed
    assert remove_values('foo', ['foo']) == 'foo'
    assert remove_values(['foo'], ['foo']) == ['foo']
    assert remove_values({'foo': 'bar'}, ['foo']) == {'foo': 'bar'}

    assert remove_values('foo', ['bar']) == 'foo'
    assert remove_values(['foo'], ['bar']) == ['foo']
    assert remove_values({'foo': 'bar'}, ['bar']) == {'foo': 'bar'}

    # Empty values should be removed
    assert remove_values('', ['foo']) == ''
    assert remove_values(['', ''], ['foo']) == ['', '']

# Generated at 2022-06-22 21:57:39.522608
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('TEST_ENV_VAR') == os.environ['TEST_ENV_VAR']


# Generated at 2022-06-22 21:57:47.039783
# Unit test for function sanitize_keys
def test_sanitize_keys():

    def _assert(expected_value, args, kwargs):
        """Helper function for unit testing"""
        sanitize_keys_test_value = sanitize_keys(*args, **kwargs)
        assert sanitize_keys_test_value == expected_value, "sanitize_keys(): wrong value, expected '%s', got '%s'" \
                                                           % (expected_value, sanitize_keys_test_value)

    # Sanitize keys recursively
    _assert(
        {'b': 2},
        [{'_ansible_no_log_a': 1, 'b': {'_ansible_no_log_c': 3}}], dict(ignore_keys=frozenset(), no_log_strings=frozenset())
    )

    # Sanitize the root key

# Generated at 2022-06-22 21:57:58.485153
# Unit test for function remove_values
def test_remove_values():

    def test_output(data):
        test_data = copy.deepcopy(data)
        test_data = remove_values(test_data, ['test'])
        assert test_data == data

    # Test scalar values.
    for i in ("test", u"test", b"test", 42, 0.42, [], {}, set()):
        yield test_output, i

    # List.
    yield test_output, ['test', 'test1', 'test2', 'test3', 'test4', 'test5', 'test6', 'test7', 'test8', 'test9', 'test10']

    # Dict.

# Generated at 2022-06-22 21:58:04.205786
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'host': {'type': 'str', 'fallback': (env_fallback, ['HOST'])}}
    parameters = {}
    set_fallbacks(argument_spec, parameters)
    assert parameters['host'] == os.environ['HOST']
    assert len(parameters) == 1



# Generated at 2022-06-22 21:58:10.530034
# Unit test for function sanitize_keys
def test_sanitize_keys():
    no_log_strings = ['password', 'become_pass']

    # Dictionary test case
    data = {'foo': {'become_pass': 'hunter2', 'bar': {'password': 'hunter3'}, 'baz': 'hunter1'}}
    assert sanitize_keys(data, no_log_strings) == {'foo': 'SANITIZED', 'bar': {'password': 'SANITIZED'}}

    # List test case
    data = [{'become_pass': 'hunter2'}, {'password': 'hunter3'}]
    assert sanitize_keys(data, no_log_strings) == [{'become_pass': 'SANITIZED'}, {'password': 'SANITIZED'}]


# Generated at 2022-06-22 21:58:21.457356
# Unit test for function sanitize_keys

# Generated at 2022-06-22 21:58:34.264967
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Test with fallback not found
    argument_spec = dict(
        test=dict(
            type='str',
            fallback=(env_fallback, 'TEST_A')
        )
    )
    params = dict()
    no_log_values = set_fallbacks(argument_spec, params)
    assert 'test' not in params
    assert len(no_log_values) == 0

    # Test with valid fallback
    os.environ['TEST_A'] = 'test_a'
    no_log_values = set_fallbacks(argument_spec, params)
    assert params['test'] == 'test_a'
    assert len(no_log_values) == 0

    # Test with no_log value

# Generated at 2022-06-22 21:58:40.998711
# Unit test for function remove_values
def test_remove_values():
    test_list = [{"test": "test"}, [[{"test": "test"}], {"test": "test"}], [{"test": "test"}, [{"test": "test"}]]]
    assert (remove_values(test_list, ['test']) == [{'**********': '**********'}, [[{'**********': '**********'}], {'**********': '**********'}], [{'**********': '**********'}, [{'**********': '**********'}]]])



# Generated at 2022-06-22 21:58:51.661436
# Unit test for function sanitize_keys
def test_sanitize_keys():
    original = {'a': 'b', 'no_log': 'value_to_remove', 'some_no_log': 'other_value_to_remove'}
    cleaned = sanitize_keys(original, {'value_to_remove', 'other_value_to_remove'})
    assert cleaned == {'a': 'b'}
    cleaned = sanitize_keys(original, {'value_to_remove'}, {'some_no_log'})
    assert cleaned == {'a': 'b', 'some_no_log': 'other_value_to_remove'}
    original = {'a': 'b', 'no_log': 'value_to_remove', 'some_no_log': 'other_value_to_remove'}

# Generated at 2022-06-22 21:59:00.125710
# Unit test for function sanitize_keys
def test_sanitize_keys():
    from ansible.module_utils.six import PY3

    data_dict = {'password': 'hunter22', 'redhat': {'password': 'hunter22', 'default_password': 'hunter22'}}
    whitelisted_expression = '^password$'
    whitelisted_keys = ['password']
    no_log_values = ['hunter22']
    ignore_keys = {'redhat'}

    result = sanitize_keys(data_dict, no_log_values, ignore_keys)
    assert result.get('password') == 'hunter22'
    assert result.get('redhat').get('password') == 'hunter22'
    assert result.get('redhat').get('default_password') == 'hunter22'

    # Test where the password is in an array

# Generated at 2022-06-22 21:59:11.431541
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        b=dict(type='str'), a=dict(type='int', fallback=(int, dict(vars=['B']))),
        c=dict(type='list', elements='str', fallback=(lambda x: ['test'], dict(vars=['D']))),
        d=dict(type='dict'), e=dict(type='str', fallback=(env_fallback, dict(vars=['ANSIBLE_FOO']))),
    )
    parameters = dict(a=1, c=['2'], d=dict(e=3))
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['a'] == 1
    assert parameters['b'] == '2'
    assert parameters['c'] == ['test']

# Generated at 2022-06-22 21:59:20.691943
# Unit test for function env_fallback
def test_env_fallback():
    if 'ANSIBLE_TEST_ENV_FALLBACK' in os.environ:
        del os.environ['ANSIBLE_TEST_ENV_FALLBACK']
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('ANSIBLE_TEST_ENV_FALLBACK')

    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test_env_fallback'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test_env_fallback'

    os.environ['LOWERCASE_VAR'] = 'lowercase'
    os.environ['UPPERCASE_VAR'] = 'UPPERCASE'

# Generated at 2022-06-22 21:59:30.573560
# Unit test for function sanitize_keys
def test_sanitize_keys():
    a = {'key1': 'value1', 'key2': 'value2', 'key3': 'value3', 'key4': 'value4'}
    aa = {'key1': 'value1', 'key2': 'value2', 'key3': 'value3', 'key4': 'value4', 'key5': {'key6': 'value6'}}
    aaa = {'key1': 'value1', 'key2': 'value2', 'key3': 'value3', 'key4': 'value4', 'key5': {'key6': 'value6',
                                                                                            'key7': 'value7'}}

# Generated at 2022-06-22 21:59:37.729647
# Unit test for function env_fallback
def test_env_fallback():
    """ env_fallback: validate function return output"""

    with mock.patch.dict('os.environ', {'TEST_ENV_KEY': 'test_value'}):
        assert env_fallback('TEST_ENV_KEY') == 'test_value'
        assert env_fallback('TEST_ENV_KEY_NOT_EXIST') == 'NOT_EXIST'



# Generated at 2022-06-22 21:59:45.431219
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_NET_PASSWORD'] = 'test'
    assert env_fallback('ANSIBLE_NET_PASSWORD') == 'test'
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback("VAR_NOT_THERE")
    os.environ.pop('ANSIBLE_NET_PASSWORD')

PARAM_VALIDATORS = {
    'password': validate_password,
    'port': validate_port,
    'asn': validate_asn,
    'ip': validate_ip,
    'provider': validate_provider,
    'vlan': validate_vlan,
}



# Generated at 2022-06-22 21:59:53.554990
# Unit test for function sanitize_keys
def test_sanitize_keys():
    raw = {
        'foo': {
            'bar': 'baz',
            'ok': {
                'ansible_secret': 'really secret'
            }
        },
        'ansible_password': 'secret!',
        '_ansible_no_log': True
    }
    expected = {
        'foo': {
            'bar': 'baz'
        },
        '_ansible_password': 'secret!',
    }
    actual = sanitize_keys(copy.deepcopy(raw), NO_LOG_PARAMS)
    assert actual == expected



# Generated at 2022-06-22 22:00:05.884938
# Unit test for function sanitize_keys
def test_sanitize_keys():
    # No recursive action
    obj = {
        'a': 'b',
        'c': {
            'd': 'e'
        }
    }
    no_log_values = ['a']
    assert sanitize_keys(obj, no_log_values, ignore_keys=frozenset()) == {
        'a': 'b',
        'c': {
            'd': 'e'
        }
    }
    assert sanitize_keys(obj, no_log_values, ignore_keys=frozenset()) == {
        'a': 'b',
        'c': {
            'd': 'e'
        }
    }

# Generated at 2022-06-22 22:00:15.249065
# Unit test for function sanitize_keys
def test_sanitize_keys():
    import sys
    import textwrap
    import unittest

    # We need to monkey-patch textwrap.dedent to produce a version of dedent that's
    # 2.6-compatible since this module is run from ansible-test
    textwrap.dedent = lambda x: x.replace('    ', '')

    from ansible.module_utils.basic import AnsibleModule

    if sys.version_info[0:2] == (2, 6):
        # We need a version of super that's 2.6-compatible since this module is run from ansible-test
        class super(object):
            def __init__(self, typeobj):
                self.typeobj = typeobj

            def __get__(self, instance, owner):
                # Note: this is where super() in Python 2.6 would fail with a TypeError
                return

# Generated at 2022-06-22 22:00:21.169357
# Unit test for function env_fallback
def test_env_fallback():
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback()
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('asdf')

    os.environ['asdf'] = 'foo'
    assert 'foo' == env_fallback('asdf')



# Generated at 2022-06-22 22:00:28.365249
# Unit test for function remove_values
def test_remove_values():
    """Unit test for function remove_values"""
    class TestException(Exception):
        pass

    no_log_strings = ['sensitive data']
    test_data = dict(
        a_string='sensitive data',
        another_string='sensitive data',
        a_dict=dict(
            a_string='sensitive data',
            another_string='sensitive data',
            a_dict=dict(
                a_string='sensitive data',
                another_string='sensitive data'
            )
        )
    )

    result = remove_values(test_data, no_log_strings)

# Generated at 2022-06-22 22:00:34.038176
# Unit test for function env_fallback
def test_env_fallback():
    '''Test env_fallback function'''
    os.environ['TEST_VALUE'] = 'test'
    assert env_fallback('TEST_VALUE') == 'test'

    # Test that it raises AnsibleFallbackNotFound, if key not in env
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('TEST_VALUE_NOT_FOUND')



# Generated at 2022-06-22 22:00:45.813509
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert set_fallbacks(dict(a=dict(), b=dict()), dict()) == set()
    assert set_fallbacks(dict(a=dict(fallback=(env_fallback, 'a')), b=dict()), dict()) == set()
    assert set_fallbacks(dict(a=dict(fallback=(env_fallback, 'a')), b=dict(fallback=(env_fallback, 'b'))), dict()) == set()

    os.environ['a'] = '1'
    os.environ['b'] = '2'
    assert set_fallbacks(dict(a=dict(fallback=(env_fallback, 'a')), b=dict(fallback=(env_fallback, 'b'))), dict()) == set()

    os.environ['a'] = ''

# Generated at 2022-06-22 22:00:57.579744
# Unit test for function set_fallbacks
def test_set_fallbacks():
    spec = dict(
        param1=dict(type='int', fallback=(env_fallback, 'ANSIBLE_TEST_PARAM1')),
        param2=dict(type='int', fallback=(env_fallback, 'ANSIBLE_TEST_PARAM2')),
        param3=dict(type='int', fallback=(env_fallback, 'ANSIBLE_TEST_PARAM3')),
        param4=dict(type='int', fallback=(lambda: 1)),
    )
    params = dict(
        param1=2,
        param4=4,
    )
    os.environ['ANSIBLE_TEST_PARAM1'] = '5'
    os.environ['ANSIBLE_TEST_PARAM2'] = '6'
    no_log = set()
    no_log = set

# Generated at 2022-06-22 22:01:07.260595
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'client_cert': {
            'aliases': ['client-cert'], 'required': False, 'type': 'path',
            'fallback': (env_fallback, 'CLIENT_CERT'),
            'no_log': True,
            'version_added': '1.7'
        }
    }
    parameters = {
        'client-cert': 'some/path/cert.pem'
    }
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert no_log_values == set()


# Generated at 2022-06-22 22:01:13.615178
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys({'hello': 'world'}, no_log_strings=set()) == {'hello': 'world'}
    assert sanitize_keys({'hello': 'world'}, no_log_strings=set(), ignore_keys=('hello',)) == {'hello': 'world'}
    assert sanitize_keys({'hello': 'world'}, no_log_strings=set(['world', 'foo']), ignore_keys=('hello',)) == {'hello': 'world'}
    assert sanitize_keys({'hello': 'world'}, no_log_strings=set(['world', 'foo'])) == {'hell__': 'world'}