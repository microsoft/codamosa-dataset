

# Generated at 2022-06-22 21:51:25.283697
# Unit test for function set_fallbacks
def test_set_fallbacks():
    spec = dict(
        dict_arg=dict(type='dict', default={'dict_arg': 'dict_arg_value'}),
        fallback_arg=dict(type='int', default=-1, fallback=(lambda: 1, )),
        fallback_arg_env=dict(type='int', default=-1, fallback=(env_fallback, 'FALLBACK_ARG_ENV')),
        fallback_arg_kwarg=dict(type='int', default=-1, fallback=(lambda: 1, dict(fallback_arg_kwarg=dict(default=2)))),
        fallback_arg_kwarg_env=dict(type='int', default=-1, fallback=(env_fallback, dict(fallback_arg_kwarg_env=dict(default=2)))),
    )
    parameters = dict

# Generated at 2022-06-22 21:51:35.620371
# Unit test for function sanitize_keys
def test_sanitize_keys():
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.module_utils.common.text.converters.json import to_json

    no_log_strings = set()
    ignore_keys = frozenset()

    from ansible.module_utils._text import to_text
    from ansible.module_utils.common._collections_compat import MutableSequence, MutableSet

    # Test basic types, expect values to pass through unchanged
    assert sanitize_keys(42, no_log_strings, ignore_keys) == 42
    assert sanitize_keys(42.5, no_log_strings, ignore_keys) == 42.5
    assert sanitize_keys(to_text(u'foo'), no_log_strings, ignore_keys) == to_text(u'foo')



# Generated at 2022-06-22 21:51:44.004694
# Unit test for function sanitize_keys
def test_sanitize_keys():
    # Mock recursive function
    recursive_func = MagicMock(name='recursive_func')
    recursive_func.side_effect = [
        'fake_value',
        [],
        ['fake_value'],
        [],
        None,
        {},
        {'fake_key': None, '_ansible_fake_key': 'fake_key'},
        {'fake_key': 'fake_value', '_ansible_fake_key': 'fake_key'},
        None
    ]

    mock_item = create_autospec(
        MutableSequence,
        instance=True,
        methods=[
            'append'
        ]
    )
    mock_item.append.side_effect = lambda value: recursive_func(value)


# Generated at 2022-06-22 21:51:52.895633
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert set_fallbacks({'host': {'type': 'str', 'fallback': ['fallback_strategy']}}, {}) == set()
    assert set_fallbacks({'host': {'type': 'str', 'fallback': [env_fallback, 'FALLBACK_STRATEGY']}}, {}) == set()
    assert set_fallbacks({'no_log_ng': {'type': 'str', 'fallback': [env_fallback, 'FALLBACK_STRATEGY']}}, {}) == set()
    assert set_fallbacks({'no_log_ok': {'type': 'str', 'fallback': [env_fallback, 'FALLBACK_STRATEGY'], 'no_log': True}}, {}) == {os.environ['FALLBACK_STRATEGY']}
    assert set

# Generated at 2022-06-22 21:51:58.219737
# Unit test for function env_fallback
def test_env_fallback():
    os.environ[u'ansible_collections'] = 'my_collection/my_namespace'
    res = env_fallback(u'ansible_collections')
    assert os.environ[u'ansible_collections'] == res
    os.environ[u'ansible_collections'] = 'my_collection/my_namespace'
    res = env_fallback(u'my_collection/my_namespace')
    assert os.environ[u'ansible_collections'] == res


# Generated at 2022-06-22 21:52:03.523496
# Unit test for function sanitize_keys
def test_sanitize_keys():
    # Dicts
    assert sanitize_keys({}, ['pass'], {}) == {}
    assert sanitize_keys({'test_key': 'test_val'}, ['pass'], {}) == {'test_key': 'test_val'}
    assert sanitize_keys({'_ansible_test': 'test_val'}, ['pass'], {}) == {'_ansible_test': 'test_val'}
    assert sanitize_keys({'_ansible_test': 'test_val'}, ['pass'], {'_ansible_test'}) == {'_ansible_test': 'test_val'}
    assert sanitize_keys({'_ansible_test': 'test_val'}, ['test'], {}) == {'_ansible_test': 'test_val'}
   

# Generated at 2022-06-22 21:52:15.297697
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        param=dict(type='str', default='test', fallback=(env_fallback, 'TEST', 'NOTEST')),
        param1=dict(type='str', default='test', fallback=(env_fallback, 'TEST', 'NOTEST')),
    )
    parameters = dict()
    no_log_values = set()
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert len(no_log_values) == 0
    # Set no_log to true
    argument_spec['param']['no_log'] = True
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert 'test' not in no_log_values
    # Set env TEST
    os.environ['TEST'] = 'test'


# Generated at 2022-06-22 21:52:23.963155
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert set_fallbacks({'param': {'fallback': (env_fallback, 'TEST_ENV')}}, {}) == set()
    assert set_fallbacks({'param': {'fallback': (env_fallback, 'TEST_ENV')}}, {'param': 1}) == set()
    os.environ['TEST_ENV'] = 'fallback_value'
    assert set_fallbacks({'param': {'fallback': (env_fallback, 'TEST_ENV')}}, {}) == set(['fallback_value'])
    assert set_fallbacks({'param': {'fallback': (env_fallback, 'TEST_ENV'), 'no_log': True}}, {}) == set(['fallback_value'])

# Generated at 2022-06-22 21:52:35.812864
# Unit test for function set_fallbacks
def test_set_fallbacks():
    spec_fallback = dict(
        one=dict(fallback=(env_fallback, 'ANSIBLE_ONE', 'ANSIBLE_FOO')),
        two=dict(fallback=(env_fallback, 'ANSIBLE_TWO', 'ANSIBLE_BAR')),
        three=dict(fallback=(env_fallback, 'ANSIBLE_THREE')),
        four=dict(fallback=(env_fallback, dict(use_system_errors=False, fallback_errors=(None,)), 'ANSIBLE_FOUR', 'ANSIBLE_BAZ')),
    )
    args_fallback = dict(
        one='one',
        two='two',
        three=None,
        four=None,
    )
    os.environ['ANSIBLE_ONE'] = 'one'

# Generated at 2022-06-22 21:52:46.543192
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        foo=dict(type='str', no_log=True, fallback=(env_fallback, 'FOO')),
        baz=dict(type='str', fallback=('BAR',)),
        foobar=dict(type='str'),  # no fallback
        bar=dict(type='str', fallback=(env_fallback, 'BAR')),
    )

    parameters = dict(
        foo='FOO',
    )
    assert set_fallbacks(argument_spec, parameters) == set()
    assert parameters == dict(
        foo='FOO',
        baz='BAR',
    )

    parameters = dict()
    assert set_fallbacks(argument_spec, parameters) == set(['FOO'])

# Generated at 2022-06-22 21:52:54.120835
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'param1': {'type': 'int', 'fallback': (env_fallback, 'ENV_VAR_1')},
        'param2': {'type': 'int', 'fallback': (env_fallback, 'ENV_VAR_2')},
        'param3': {'type': 'int', 'fallback': (env_fallback, 'ENV_VAR_3')},
    }
    parameters = {}
    os.environ['ENV_VAR_1'] = '1'
    os.environ['ENV_VAR_2'] = '2'

    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters == {'param1': 1, 'param2': 2}
    assert no_log_values == set()

# Generated at 2022-06-22 21:53:04.902267
# Unit test for function sanitize_keys

# Generated at 2022-06-22 21:53:16.874259
# Unit test for function remove_values
def test_remove_values():
    assert remove_values(1, [1]) == 1
    assert remove_values('2', ['2']) == '2'
    assert remove_values('secret_pw', ['secret_pw']) == ''
    assert remove_values({'a': 'secret_pw'}, ['secret_pw']) == {'a': ''}
    assert remove_values({'a': 'secret_pw', 'b': {'c': '4'}}, ['secret_pw']) == {'a': '', 'b': {'c': '4'}}
    assert remove_values({'a': 'secret_pw', 'b': {'c': 'secret_pw'}}, ['secret_pw']) == {'a': '', 'b': {'c': ''}}

# Generated at 2022-06-22 21:53:26.804944
# Unit test for function remove_values
def test_remove_values():
    """Unit tests for remove_values function"""
    from ansible.errors import AnsibleError
    from ansible.module_utils._text import to_native

    class TestNoLogStrings(Exception):
        """Defines no_log_strings array"""
        def __init__(self):
            self.no_log_strings = ['to_be_removed']

    class TestRemoveValues(unittest.TestCase):
        def test_should_remove_if_string(self):
            self.assertEqual(remove_values('to_be_removed', TestNoLogStrings().no_log_strings), '')

# Generated at 2022-06-22 21:53:37.819425
# Unit test for function sanitize_keys
def test_sanitize_keys():
    simple_dict = {'http_user': 'changeme',
                   'http_pass': 'changeme'}
    expected_dict = {'http_user': 'changeme',
                     'http_pass': 'changeme'}
    assert dict(sanitize_keys(simple_dict, no_log_strings=['changeme'])) == expected_dict, \
        "sanitize_keys dict changed dict"

    simple_list = ['http_user', 'http_pass']
    expected_list = ['http_user', 'http_pass']
    assert list(sanitize_keys(simple_list, no_log_strings=['changeme'])) == expected_list, \
        "sanitize_keys list changed list"


# Generated at 2022-06-22 21:53:49.533840
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['THE_ANSIBLE_TEST_ENV'] = 'env_fallback_works'
    assert env_fallback('THE_ANSIBLE_TEST_ENV') == 'env_fallback_works'
    os.environ['THE_ANSIBLE_TEST_ENV'] = 'overwrite_works'
    assert env_fallback('THE_ANSIBLE_TEST_ENV', default='overwrite_works') == 'overwrite_works'
    os.environ['THE_ANSIBLE_TEST_ENV'] = 'overwrite_works'
    assert env_fallback('THE_ANSIBLE_TEST_ENV', 'NOT_SET', default='overwrite_works') == 'overwrite_works'

# Generated at 2022-06-22 21:54:00.638449
# Unit test for function set_fallbacks
def test_set_fallbacks():
    """Test function set_fallbacks"""
    argument_spec = {'from_fallback': {'type': 'str', 'default': 'not set', 'fallback': (env_fallback, ('ANSIBLE_TEST_FALLBACK_FROM',))}}
    parameters = {}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters.get('from_fallback') == 'from_fallback'
    assert 'from_fallback' in no_log_values

    argument_spec = {'from_fallback': {'type': 'str', 'default': 'not set', 'fallback': (env_fallback, ('ANSIBLE_TEST_FALLBACK_FROM',)), 'no_log': False}}
    parameters = {}

# Generated at 2022-06-22 21:54:10.716003
# Unit test for function remove_values
def test_remove_values():
    value1 = u"this could contain a password we don't want to log"
    no_log_strings = [u"password"]
    new_value1 = remove_values(value1, no_log_strings)
    assert new_value1 == u"this could contain a ******** we don't want to log"
    # Non-string types should return the orig value
    assert remove_values(1234, no_log_strings) == 1234
    assert remove_values(None, no_log_strings) is None
    mydict = {u"password": u"password"}
    assert remove_values(mydict, no_log_strings) == {u"password": u"********"}
    mylist = [u"password", u"password"]

# Generated at 2022-06-22 21:54:17.030469
# Unit test for function sanitize_keys
def test_sanitize_keys():
    """Unit test for function sanitize_keys"""

    assert sanitize_keys({'foobar': 'foobar'}, set()) == {'foobar': 'foobar'}
    assert sanitize_keys({'foobar': 'foobar'}, set(['bar'])) == {'foobar': 'foobar'}
    assert sanitize_keys({'foobar': 'foobar'}, set(['foo'])) == {'bar': 'foobar'}
    assert sanitize_keys({'foobar': 'foobar'}, set(['ob'])) == {'far': 'foobar'}
    assert sanitize_keys({'foobar': 'foobar'}, set(['f'])) == {'oobar': 'foobar'}

# Generated at 2022-06-22 21:54:22.055381
# Unit test for function set_fallbacks
def test_set_fallbacks():

    assert set_fallbacks({'test': {'type': 'str', 'required': False, 'fallback': (env_fallback, 'SOME_KEY')}}, {"test": None}) == set()
    # fallback should not be set since parameter is already set on the command line
    assert set_fallbacks({'test': {'type': 'str', 'required': False, 'fallback': (env_fallback, 'SOME_KEY')}}, {"test": "test_value"}) == set()
    # env fallback called, should get back env variable
    assert set_fallbacks({'test2': {'type': 'str', 'required': False, 'fallback': (env_fallback, 'PATH')}}, {"test2": None}) == {"test_value"}


# Generated at 2022-06-22 21:54:33.181248
# Unit test for function set_fallbacks
def test_set_fallbacks():

    spec = dict(
        param1=dict(type='str', fallback=(env_fallback, 'TEST_PARAM')),
        param2=dict(type='str', fallback=(env_fallback, 'TEST_PARAM2', 'TEST_PARAM3'), default='b'),
        param3=dict(type='str', fallback=(env_fallback, 'TEST_PARAM1')),
    )
    params = dict(param1='a')
    assert set_fallbacks(spec, params) == {'b'}
    assert params == dict(param1='a', param2='b')

    # test env fallback
    os.environ['TEST_PARAM1'] = 'c'
    os.environ['TEST_PARAM2'] = 'd'

# Generated at 2022-06-22 21:54:40.660531
# Unit test for function set_fallbacks
def test_set_fallbacks():
    args = {'a': {'default': 1, 'no_log': False}, 'b': {'default': 2, 'no_log': True}}
    parameters = {}
    no_log_values = set_fallbacks(args, parameters)
    assert parameters['a'] == 1
    assert parameters['b'] == 2
    assert no_log_values == set()

    parameters = {'b': 3}
    set_fallbacks(args, parameters)
    assert parameters['a'] == 1
    assert parameters['b'] == 3
    assert no_log_values == set()

    parameters = {'a': None, 'b': None}
    no_log_values = set_fallbacks(args, parameters)
    assert parameters['a'] == 1
    assert parameters['b'] == 2
    assert no_log_values == set()



# Generated at 2022-06-22 21:54:51.127822
# Unit test for function set_fallbacks

# Generated at 2022-06-22 21:55:01.560045
# Unit test for function env_fallback
def test_env_fallback():
    test_vars = [
        'ANSIBLE_LIBRARY',
        '/etc/ansible/ansible.cfg',
        'PWD',
        'SHELL',
        'USER',
        'HOME',
        'PATH',
        'MAIL',
    ]
    for var in test_vars:
        result = env_fallback(var)
        if 'ANSIBLE_LIBRARY' in var:
            assert result != '', ("Value returned from env_fallback() is empty. Should be '%s'." % os.environ['ANSIBLE_LIBRARY'])
        else:
            assert var in result, ("Value '%s' returned from env_fallback() is not in '%s'." % (result, var))


# Generated at 2022-06-22 21:55:13.032133
# Unit test for function set_fallbacks
def test_set_fallbacks():
    from ansible_collections.ansible.community.tests.unit.compat.mock import MagicMock
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch

    argument_spec = dict(
        param1=dict(fallback=(env_fallback, 'TEST_VALUE', 'TEST_VALUE_TWO')),
        param2=dict(fallback=(env_fallback, 'TEST_VALUE', 'TEST_VALUE_THREE'), type='dict')
    )
    parameters = dict(param3='value3')
    mock_dict = MagicMock(return_value='dict_value')

# Generated at 2022-06-22 21:55:24.391746
# Unit test for function set_fallbacks

# Generated at 2022-06-22 21:55:33.820081
# Unit test for function set_fallbacks
def test_set_fallbacks():
    spec = {
        'str1': dict(type='str', fallback=('env', 'arg1', 'arg2')),
        'str2': dict(type='str', fallback=(env_fallback, 'arg1', 'arg2')),
        'str3': dict(type='str', fallback=('fail', 'arg1', 'arg2')),
        'str4': dict(type='str', fallback=('env', 'arg1', dict(key='arg2')))
    }

    params = {'str1': 'value1', 'str2': 'value2'}

    os.environ['arg1'] = 'env_value'
    no_log_values = set_fallbacks(spec, params)

    assert params['str1'] == 'value1'

# Generated at 2022-06-22 21:55:40.913578
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys({'password': 'foo', 'password_file': 'bar'}, set()) == {'password': 'foo', 'password_file': 'bar'}
    assert sanitize_keys({'password': 'foo', 'password_file': 'bar'}, {'password'}) == {'password': 'foo', 'password_file': 'bar'}
    assert sanitize_keys({'password': 'foo', 'password_file': 'bar'}, {'foo'}) == {'password': 'foo', 'password_file': 'bar'}

# Generated at 2022-06-22 21:55:53.111892
# Unit test for function remove_values
def test_remove_values():
    assert remove_values({"a": "b"}, {"b"}) == {"a": None}
    assert remove_values({"a": {"b": "c"}}, {"c"}) == {"a": {"b": None}}
    assert remove_values([["a", "b"], ["c", "d"]], {"a", "b", "c", "d"}) == [[None, None], [None, None]]
    assert remove_values([{"a": "b"}, {"c": "d"}], {"b", "d"}) == [{"a": None}, {"c": None}]

    # Testing support for serialized tuple
    assert remove_values({"a": "b"}, {"b"}) == {"a": None}

# Generated at 2022-06-22 21:56:02.074621
# Unit test for function set_fallbacks
def test_set_fallbacks():
    parameter_spec = dict(
        key1=dict(type='str', fallback=('myfallback', ['arg1', {'kwarg1': 'value'}])),
        key2=dict(type='int', fallback=('myfallback', ['arg1'])),
        key3=dict(type='int', fallback=('myfallback', [])),
        key4=dict(type='int', fallback=(env_fallback, ['ANSIBLE_TEST_ENV'])),
        key5=dict(type='int', fallback=(env_fallback, ['ANSIBLE_TEST_ENV_NOT_SET']))
    )

    parameters = dict(key1='first', key2='2')


# Generated at 2022-06-22 21:56:14.349277
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['TEST_VAR'] = 'TEST_VALUE'
    assert env_fallback('TEST_VAR') == 'TEST_VALUE'
    assert env_fallback('NOT_IN_ENV') == 'TEST_VALUE'
    os.environ['NOT_IN_ENV'] = 'NOT_IN_ENV_VALUE'
    assert env_fallback('NOT_IN_ENV') == 'NOT_IN_ENV_VALUE'
try:
    # This is only imported if we are running tests, otherwise the fallback
    # variable is not needed.
    from ansible.module_utils.six import PY2
except ImportError:
    PY2 = False


# Generated at 2022-06-22 21:56:24.992179
# Unit test for function set_fallbacks

# Generated at 2022-06-22 21:56:36.023800
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys(None, ['redacted']) is None

    assert sanitize_keys(1, ['redacted']) == 1

    assert sanitize_keys('blah', ['redacted']) == 'blah'

    assert sanitize_keys('redacted', ['redacted']) == 'REDACTED'

    assert sanitize_keys('redacted', ['redacted'], ['redacted']) == 'redacted'

    assert sanitize_keys('redacted', ['redacted'], {'redacted'}) == 'redacted'

    assert sanitize_keys('redacted', ['redacted'], {'redact'}) == 'REDACTED'

    assert sanitize_keys('redacted', ['REDACTED'], {'redacted'}) == 'redacted'


# Generated at 2022-06-22 21:56:47.423295
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        param1=dict(type='str', default='my default'),
        param2=dict(type='str', fallback=(env_fallback, 'ANSIBLE_PARAM2')),
    )
    parameters = dict(param1='bar')
    os.environ['ANSIBLE_PARAM2'] = 'baz'
    assert set_fallbacks(argument_spec, parameters) == set()
    assert parameters == dict(param1='bar', param2='baz')
    del os.environ['ANSIBLE_PARAM2']
    assert set_fallbacks(argument_spec, parameters) == set()
    assert parameters == dict(param1='bar', param2='baz')
    del os.environ['ANSIBLE_PARAM2']

# Generated at 2022-06-22 21:56:57.905623
# Unit test for function remove_values
def test_remove_values():
    # _remove_values_conditions() is a helper function for remove_values(),
    # and as such we test it directly, as a unit test.
    assert _remove_values_conditions('', ['']) == ''
    assert _remove_values_conditions('', ['a']) == 'a'
    assert _remove_values_conditions('a', ['']) == 'a'
    assert _remove_values_conditions('a', ['a']) == '*'
    assert _remove_values_conditions('a', ['b']) == 'a'
    assert _remove_values_conditions('abcdefghijklmnopqrstuvwxyz', ['abcdefghijklmnopqrstuvwxyz']) == '******************************'

# Generated at 2022-06-22 21:57:05.751074
# Unit test for function set_fallbacks
def test_set_fallbacks():
    parameter_spec = {
        'test': {'type': 'str'},
        'result': {'type': 'str'},
        'foo': {'type': 'str'},
        'bar': {'type': 'str', 'fallback': (env_fallback, 'BAR')},
        'baz': {'type': 'str', 'fallback': (env_fallback, 'BAZ'), 'no_log': True},
    }

    fake_env = {
        'BAR': '1',
        'BAZ': '2',
    }

    # Test an empty parameters
    parameters = {}
    set_fallbacks(parameter_spec, parameters)
    assert 'bar' in parameters
    assert parameters['bar'] == '1'
    assert 'baz' in parameters
    assert parameters['baz']

# Generated at 2022-06-22 21:57:15.228611
# Unit test for function sanitize_keys
def test_sanitize_keys():
    input_string = '''
        {
            "ansible_winrm_server_cert_validation": "ignore",
            "ansible_winrm_transport": [
                "ntlm",
                "negotiate",
                "kerberos"
            ]
        }
    '''
    json_input = json.loads(input_string)
    sanitized_output = sanitize_keys(json_input, ['server_cert_validation'])
    assert "ansible_winrm_transport" in sanitized_output and "ansible_winrm_server_cert_validation" in sanitized_output
    assert "ansible_winrm_server_cert_validation" not in json_input and "ansible_winrm_transport" not in json_input



# Generated at 2022-06-22 21:57:19.331459
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('ANSIBLE_FOO') == os.environ['ANSIBLE_FOO']
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback("FOO")



# Generated at 2022-06-22 21:57:30.169328
# Unit test for function sanitize_keys
def test_sanitize_keys():
    from ansible.module_utils.six import iteritems
    from ansible.module_utils._text import to_text

    my_dict = {
        'aasdf': 'asdf',
        'foo': 'foo123',
        'password': 'pass123',
        'access_token': 'abc123',
    }
    keys_to_sanitize = ['password', 'access_token']
    # We need to have a set of strings to replace in the keys. We just use the value of the keys
    # as a stand-in for these values.
    replacements = set(keys_to_sanitize)

# Generated at 2022-06-22 21:57:31.151012
# Unit test for function remove_values
def test_remove_values():
  return


# Generated at 2022-06-22 21:57:43.044736
# Unit test for function remove_values
def test_remove_values():

    no_log_strings = {u'hideme'}
    input_value = {'nested': {'nested2': ['hideme', {'hideme': 'hideme'}]},
                   'hideme': 'hideme',
                   'nolist': {'nested': [u'hideme']}}

    expected_value = {'nested': {'nested2': ['REDACTED', {'REDACTED': 'REDACTED'}]},
                      'REDACTED': 'REDACTED',
                      'nolist': {'nested': [u'REDACTED']}}

    actual_value = remove_values(input_value, no_log_strings)

    # Assert we recursively remove values in nested containers
    assert input_value['nested']['nested2'][1]['hideme']
   

# Generated at 2022-06-22 21:57:52.066056
# Unit test for function set_fallbacks
def test_set_fallbacks():
    parameters = dict()
    argument_spec = dict()
    argument_spec['param1'] = dict()
    argument_spec['param2'] = dict()
    argument_spec['param3'] = dict()
    argument_spec['param4'] = dict()
    argument_spec['param5'] = dict()
    argument_spec['param6'] = dict()
    argument_spec['param1']['fallback'] = (env_fallback, 'test_param1')
    argument_spec['param2']['fallback'] = (env_fallback, 'test_param2')
    argument_spec['param3']['fallback'] = (env_fallback, 'test_param3')
    argument_spec['param4']['fallback'] = (env_fallback, 'test_param4')

# Generated at 2022-06-22 21:58:03.206725
# Unit test for function remove_values
def test_remove_values():
    import pytest
    no_log_strings = {'password', 'secret'}
    value = 'foo_password_bar'
    new_value = remove_values(value, no_log_strings)
    assert new_value == 'foo_********_bar'

    value = {'password': 'foo_password_bar', 'secret': 'foo_secret_bar'}
    new_value = remove_values(value, no_log_strings)
    assert new_value == {'password': 'foo_********_bar', 'secret': 'foo_******_bar'}

    value = {'not_secret': 'foo_password_bar', 'secret': 'foo_secret_bar'}
    new_value = remove_values(value, no_log_strings)

# Generated at 2022-06-22 21:58:14.123602
# Unit test for function sanitize_keys
def test_sanitize_keys():
    o = {'2': 3, 'foo': {'1a': '345', '1b': 'xyz'}, 'bar': [{'2a': '123'}, {'2b': '456'}]}
    assert sanitize_keys(o, set(['3', '4'])) == {'2': 3, 'foo': {'a': '345', 'b': 'xyz'}, 'bar': [{'a': 123}, {'b': '456'}]}

    o = {'2': 3, 'foo': {'1a': '345', '1b': 'xyz'}, 'bar': [{'2a': '123'}, {'2b': '456'}]}

# Generated at 2022-06-22 21:58:24.709177
# Unit test for function remove_values
def test_remove_values():
    import unittest
    import datetime
    from types import GeneratorType

    # Use the assertRaises method as a context manager
    # to check that the correct exception is raised
    with unittest.TestCase('__init__') as tc:
        # Test basic functionality.
        tc.assertEqual(remove_values(1, ['1']), 1)
        tc.assertEqual(remove_values(1, [1]), 1)
        tc.assertEqual(remove_values(True, [True]), True)
        tc.assertEqual(remove_values(False, [False]), False)
        tc.assertEqual(remove_values(1.0, [1]), 1.0)
        tc.assertEqual(remove_values(1.0, [1.0]), 1.0)

# Generated at 2022-06-22 21:58:36.357722
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        foo=dict(fallback=(env_fallback, ('ANSIBLE_FOO', 'FOO'))),
        bar=dict(required=True, fallback=(lambda bar: bar.upper(), None)),
        baz=dict(fallback=(lambda baz: baz.lower(), None)),
        waldo=dict(fallback=(env_fallback, 'ANSIBLE_WALDO')),
    )
    assert set_fallbacks(argument_spec, dict()) == set()

    os.environ['ANSIBLE_FOO'] = 'foo'
    assert set_fallbacks(argument_spec, dict()) == set(['foo'])
    os.environ['FOO'] = 'not'
    assert set_fallbacks(argument_spec, dict()) == set(['not'])
    os.en

# Generated at 2022-06-22 21:58:46.632470
# Unit test for function remove_values
def test_remove_values():
    def assert_equal(expected, actual):
        if expected != actual:
            raise AssertionError("Expected %s, got %s" % (expected, actual))

    assert_equal(remove_values({"a": "hello", "b": "world"}, []), {"a": "hello", "b": "world"})
    assert_equal(remove_values({"a": "hello", "b": "world"}, ["hello", "world"]), {"a": "hello", "b": "world"})
    assert_equal(remove_values({"a": {"b": "world", "c": "hello"}, "d": "world"}, ["hello"]), {"a": {"b": "world", "c": "hello"}, "d": "world"})

# Generated at 2022-06-22 21:58:58.265177
# Unit test for function sanitize_keys
def test_sanitize_keys():
    from collections import OrderedDict
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    d = {'foo':'bar',u'b\u00e4r':u'baz', u'unic\u00f8de':'unicode',
            AnsibleUnsafeText(u'unsafe_text'): AnsibleUnsafeText(u'secret')}
    od = OrderedDict(d)
    assert _sanitize_keys_conditions(d, ['secret']) == {'foo': 'bar', u'b\u00e4r': 'baz', u'unic\u00f8de': 'unicode', 'unsafe_text': '**'}

# Generated at 2022-06-22 21:59:06.411431
# Unit test for function set_fallbacks
def test_set_fallbacks():

    arg_spec = dict(
        param1=dict(fallback=(env_fallback,)),
        param2=dict(fallback=(env_fallback, 'P2_ENV_VALUE')),
        param3=dict(fallback=(env_fallback, ('P3_ENV_VALUE',))),
        param4=dict(fallback=(env_fallback, ('P4_ENV_VALUE', 'P2_ENV_VALUE'))),
    )
    parameters = dict()

    os.environ['P2_ENV_VALUE'] = 'P2_VALUE'
    os.environ['P3_ENV_VALUE'] = 'P3_VALUE'
    os.environ['P4_ENV_VALUE'] = 'P4_VALUE'

    set_fallbacks(arg_spec, parameters)
   

# Generated at 2022-06-22 21:59:12.197721
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_FOO_BAR'] = 'baz'
    assert env_fallback('ANSIBLE_FOO_BAR') == 'baz'
    os.environ.pop('ANSIBLE_FOO_BAR')
    assert env_fallback('ANSIBLE_FOO_BAR') == 'baz'



# Generated at 2022-06-22 21:59:24.541477
# Unit test for function remove_values
def test_remove_values():
    '''Unit test for function remove_values'''
    # Check for case where input is string
    no_log_strings = ['test']
    in_string = 'testtest'
    out_string = '****test'
    assert remove_values(in_string, no_log_strings) == out_string

    # Check for case where input is dict
    no_log_strings = ['test']
    in_dict = {'test':'testtest'}
    out_dict = {'test':'****test'}
    assert remove_values(in_dict, no_log_strings) == out_dict

    # Check for case where input is list
    no_log_strings = ['test']
    in_list = ['test', 'testtest']
    out_list = ['test', '****test']
    assert remove_values

# Generated at 2022-06-22 21:59:34.422181
# Unit test for function env_fallback
def test_env_fallback():
    """Return value of environment variable.

    First argument is the name of the variable to return. Will raise an
    AnsibleFallbackNotFound exception if the variable is not set.
    """

    assert os.environ.get('PATH', None) == env_fallback('PATH'), 'Fallback calls os.environ.get'
    assert env_fallback('HOME', 'USER', 'USERNAME') == os.environ.get('HOME', os.environ.get('USER', os.environ.get('USERNAME'))), 'Multiple args are checked'
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('FOO')
# Unit tests for function env_fallback

# Generated at 2022-06-22 21:59:40.732219
# Unit test for function env_fallback
def test_env_fallback():
    os.environ["arg1"] = "1"
    assert env_fallback("arg1") == "1"
    assert env_fallback("arg2") == "2"
    assert env_fallback("arg1", "arg2") == "1"
    assert env_fallback("arg2", "arg3") == "2"
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback("arg3")



# Generated at 2022-06-22 21:59:53.329463
# Unit test for function sanitize_keys
def test_sanitize_keys():
    original = '{"key": "value"}'
    assert original == str(sanitize_keys(json.loads(original), {'value'}))

    original = '{"key": "value"}'
    assert original == str(sanitize_keys(json.loads(original), {'key'}))

    original = '{"This sends private key": "value"}'
    assert original == str(sanitize_keys(json.loads(original), {'value'}))

    original = '{"key": "This sends private key"}'
    assert '"k***": "This sends private key"' == str(sanitize_keys(json.loads(original), {'key'}))

    original = '{"key": "This is NOT a private key"}'

# Generated at 2022-06-22 22:00:05.577480
# Unit test for function remove_values
def test_remove_values():

    # Test simple single values
    assert remove_values(None, ['sensitive']) is None
    assert remove_values('sensitive', ['sensitive']) == 'VALUE OMITTED'
    assert remove_values(True, ['sensitive']) is True
    assert remove_values(42, ['sensitive']) == 42

    # Test nested data structures
    assert remove_values({}, []) == {}
    assert remove_values({'password': 'sensitive', 'other': 'sensitive'}, ['sensitive']) == {'password': 'VALUE OMITTED', 'other': 'VALUE OMITTED'}
    assert remove_values(['sensitive'], ['sensitive']) == ['VALUE OMITTED']
    assert remove_values(['sensitive', 'sensitive'], ['sensitive']) == ['VALUE OMITTED', 'VALUE OMITTED']

# Generated at 2022-06-22 22:00:15.058269
# Unit test for function remove_values
def test_remove_values():
    value = ['a', 'b', 'c', 'd']
    no_log_strings = ['b', 'c']
    expected = ['a', 'd']
    result = remove_values(value, no_log_strings)
    assert result == expected

    value = ['a', 'b', ['c', 'e'], 'd']
    no_log_strings = ['b', 'c']
    expected = ['a', ['e'], 'd']
    result = remove_values(value, no_log_strings)
    assert result == expected

    value = ['a', 'b', ['c', 'e'], 'd']
    no_log_strings = ['e']
    expected = ['a', 'b', ['c'], 'd']
    result = remove_values(value, no_log_strings)
    assert result

# Generated at 2022-06-22 22:00:18.312516
# Unit test for function remove_values
def test_remove_values():
    print('Testing remove_values()')

    # This is a recursive function; we'll test each branch below
    pass



# Generated at 2022-06-22 22:00:28.945008
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        param1=dict(type='str', fallback=(env_fallback, 'TEST_ANSIBLE_PARAMETER', None)),
        param2=dict(type='str', fallback=(env_fallback, 'TEST_ANSIBLE_PARAMETER', None)),
        param3=dict(type='str', fallback=(env_fallback, 'TEST_ANSIBLE_PARAMETER', None)),
        param4=dict(type='str', fallback=(env_fallback, 'TEST_ANSIBLE_NOD_LOG', None)),
        param5=dict(type='str', fallback=(env_fallback, 'TEST_ANSIBLE_NOD_LOG', None))
    )
    no_log_values = set()

# Generated at 2022-06-22 22:00:40.310923
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'host': {'required': True, 'fallback': ('env_fallback', ['ANSIBLE_NET_HOST'])},
        'port': {'default': 22, 'fallback': ('env_fallback', ['ANSIBLE_NET_PORT'])},
        'password': {'required': True, 'no_log': True, 'fallback': ('env_fallback', ['ANSIBLE_NET_PASSWORD'])},
    }
    parameters = {}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['host'] == 'localhost'
    assert parameters['port'] == 22
    assert 'password' in parameters
    assert parameters['password'] in no_log_values



# Generated at 2022-06-22 22:00:48.860646
# Unit test for function remove_values
def test_remove_values():
    result = remove_values({'a': 'abc', 'b': 123, 'c': 'abc', 'd': ['abc', 'def', 'ghi']}, 'abc')
    assert result == {'b': 123, 'd': ['def', 'ghi']}

    result = remove_values({'a': 'abc', 'b': 123, 'c': 'abc', 'd': ['abc', 'def', 'ghi']}, 'def')
    assert result == {'a': 'abc', 'b': 123, 'c': 'abc', 'd': ['abc', 'ghi']}

    result = remove_values({'a': 'abc', 'b': 123, 'c': 'abc', 'd': ['abc', 'def', 'ghi']}, ('abc', 'ghi'))

# Generated at 2022-06-22 22:01:01.149736
# Unit test for function sanitize_keys
def test_sanitize_keys():
    from collections import namedtuple

    TestCase = namedtuple('TestCase', ('obj', 'expected', 'no_log_strings', 'ignore_keys'))


# Generated at 2022-06-22 22:01:07.381158
# Unit test for function sanitize_keys
def test_sanitize_keys():
    test_list = ['foo', {'a': {'b': 'c', 'bar': 'foo'}, 'bar': 'baz'}]
    new_list = sanitize_keys(test_list, ['bar', 'c'])
    match_elem = new_list[1]
    assert match_elem['_ansible_bar'] == 'baz'
    assert match_elem['a']['_ansible_bar'] == 'foo'
    assert '_ansible_bar' in new_list[0]



# Generated at 2022-06-22 22:01:13.631692
# Unit test for function env_fallback
def test_env_fallback():
    def env_to_dict(env):
        return dict((key, value) for key, value in env.items())

    def dict_to_env(env):
        return dict(("{0}={1}".format(key, value) for key, value in env.items()))

    curr_env = env_to_dict(os.environ)
    try:
        os.environ.clear()
        assert(env_fallback('ANSIBLE_FOO') is AnsibleFallbackNotFound)

        os.environ.update(dict_to_env({'ANSIBLE_FOO': '1'}))
        assert(env_fallback('ANSIBLE_FOO') == '1')

    finally:
        os.environ.clear()

# Generated at 2022-06-22 22:01:24.789080
# Unit test for function set_fallbacks
def test_set_fallbacks():
  assert set_fallbacks({'something': {'type': 'str', 'fallback': (env_fallback, 'SOMETHING_ENV_VAR')}}, {}) == set()
  assert os.environ['SOMETHING_ENV_VAR'] == 'Nothing'
  assert set_fallbacks({'something': {'type': 'str', 'fallback': (env_fallback, 'SOMETHING_ENV_VAR')}}, {}) == {'Nothing'}
  assert set_fallbacks({}, {}) == set()
  assert set_fallbacks({'something': {'type': 'str', 'fallback': (env_fallback, 'NOTHING_ENV_VAR')}}, {}) == set()