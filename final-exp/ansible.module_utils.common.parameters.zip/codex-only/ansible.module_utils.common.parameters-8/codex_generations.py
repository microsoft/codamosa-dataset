

# Generated at 2022-06-22 21:51:27.059787
# Unit test for function sanitize_keys
def test_sanitize_keys():
    from ansible.module_utils.common._collections_compat import MutableMapping, MutableSequence, MutableSet
    from ansible.module_utils.common.text.converters import to_bytes, to_text

    def check_sanitize_keys(input_data, no_log_strings, output_data=None, ignore_keys=frozenset()):
        if output_data is None:
            output_data = input_data

        s = sanitize_keys(input_data, no_log_strings, ignore_keys=ignore_keys)
        assert s == output_data
        if hasattr(s, '__iter__'):
            for item in s:
                assert isinstance(item, (string_types, byte_type))

# Generated at 2022-06-22 21:51:29.015921
# Unit test for function env_fallback
def test_env_fallback():
    try:
        env_fallback('foo')
    except AnsibleFallbackNotFound:
        pass
    else:
        assert False



# Generated at 2022-06-22 21:51:37.969180
# Unit test for function set_fallbacks
def test_set_fallbacks():

    argument_spec = dict(param1=dict(fallback=(env_fallback, 'FOO'), type='str'),
                         param2=dict(fallback=(env_fallback, 'BAR'), type='str'),
                         param3=dict(fallback=(env_fallback, 'FOO3'), type='str'),
                         param5=dict(fallback=(env_fallback, 'FOO5'), type='str'),
                         param6=dict(fallback=(env_fallback, 'FOO6'), type='str', no_log=True),
                         param7=dict(fallback=(env_fallback, 'FOO7'), type='str', no_log=True))
    parameters = dict(param1='test', param2='testing', param4='test4')
    os.environ['FOO'] = 'env_foo'
   

# Generated at 2022-06-22 21:51:47.135123
# Unit test for function remove_values
def test_remove_values():
    from ansible.compat import OrderedDict

    # Test 1 - Remove from a simple key.
    d = OrderedDict()
    d['key1'] = 'I should be removed'
    d['key2'] = 'I should be removed'
    d['key3'] = 'I should be removed'
    assert remove_values(d, {'I should be removed'}) == OrderedDict()

    # Test 2 - Remove from a simple value.
    d = OrderedDict()
    d['I should be removed'] = 'value1'
    d['I should be removed'] = 'value2'
    d['I should be removed'] = 'value3'
    assert remove_values(d, {'I should be removed'}) == OrderedDict()

    # Test 3 - Remove from a nested dictionary.
    d

# Generated at 2022-06-22 21:51:59.195036
# Unit test for function set_fallbacks
def test_set_fallbacks():

    argument_spec = dict(
        username=dict(required=False, fallback=(env_fallback, ['ANSIBLE_NET_USERNAME'])),
        password=dict(required=False, no_log=True, fallback=(env_fallback, ['ANSIBLE_NET_PASSWORD'])),
        secret=dict(required=False, no_log=True, fallback=(env_fallback, ['ANSIBLE_NET_PASSWORD'])),
        provider=dict(type='dict', options=dict(
            host=dict(required=False),
            username=dict(required=False),
            password=dict(required=False, no_log=True),
        ))
    )


# Generated at 2022-06-22 21:52:08.685539
# Unit test for function sanitize_keys
def test_sanitize_keys():
    """
    :return:
    """

# Generated at 2022-06-22 21:52:14.079316
# Unit test for function sanitize_keys
def test_sanitize_keys():
    no_log_strings = [
        'no log me 1',
        'no log me 2',
        'c'
    ]

# Generated at 2022-06-22 21:52:19.536097
# Unit test for function env_fallback
def test_env_fallback():
    class TestEnvFallback(unittest.TestCase):
        def setUp(self):
            self.os_module_getenv = os.getenv
            self.os_module_environ = dict(os.environ)
            self.val = None
            self.key = 'foo'
            self.default = 'bar'

        def tearDown(self):
            os.getenv = self.os_module_getenv
            os.environ = self.os_module_environ

        def test_env_fallback(self):
            self.val = 'bar'
            self.assertRaises(AnsibleFallbackNotFound, env_fallback, 'baz')
            self.assertEqual(self.val, env_fallback(self.key, self.default))


# Generated at 2022-06-22 21:52:26.122028
# Unit test for function remove_values
def test_remove_values():
    """Sanity check for function remove_values."""
    import json
    import yaml
    import copy

    private_values = ['secret1', 'secret2']

    # Simple types (no private values removed)
    simple_types = [
        'foo',
        [1, 2, 3],
        (1, 2, 3),
        123.45,
        True,
        False,
        None,
    ]
    for original in simple_types:
        assert remove_values(original, private_values) == original

    # Test mapping types
    mapping_types = [
        dict,
        collections.OrderedDict,
    ]
    for mapping_type in mapping_types:
        data = mapping_type()
        for original in simple_types:
            data[original] = original

# Generated at 2022-06-22 21:52:28.297508
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback("HOME") == os.environ["HOME"]
    assert_raises(AnsibleFallbackNotFound, env_fallback, "FOO")

# Generated at 2022-06-22 21:52:40.504299
# Unit test for function remove_values

# Generated at 2022-06-22 21:52:47.527500
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['TEST_ENV_FALLBACK'] = 'foobar'
    assert 'foobar' == env_fallback('TEST_ENV_FALLBACK')
    os.environ['TEST_ENV_FALLBACK_FOO'] = 'foobar'
    assert 'foobar' == env_fallback('TEST_ENV_FALLBACK', 'TEST_ENV_FALLBACK_FOO')
    os.environ.pop('TEST_ENV_FALLBACK')
    assert 'foobar' == env_fallback('TEST_ENV_FALLBACK', 'TEST_ENV_FALLBACK_FOO')

    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('TEST_ENV_FALLBACK_BAR')

# Generated at 2022-06-22 21:52:52.400677
# Unit test for function set_fallbacks
def test_set_fallbacks():
    spec = dict(test=dict(type='str', fallback=(env_fallback, ('TEST_VAR', 'TEST_VAR2'))))
    assert set_fallbacks(spec, dict()) == set()
    assert set_fallbacks(spec, dict(test='asdf')) == set()

    spec = dict(test=dict(type='str', fallback=(env_fallback, ('TEST_VAR', 'TEST_VAR2')), no_log=True))
    assert set_fallbacks(spec, dict()) == set()
    assert set_fallbacks(spec, dict(test='asdf')) == set(['asdf'])


# Generated at 2022-06-22 21:52:55.306239
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['GARBAGE'] = 'test'
    assert env_fallback('GARBAGE') == 'test'



# Generated at 2022-06-22 21:53:06.018556
# Unit test for function set_fallbacks
def test_set_fallbacks():
    options = {'param1': 'value1'}
    argument_spec = {
        'param1': {'type': 'str'},
        'param2': {'type': 'str',
                   'fallback': (env_fallback, ['PARAM2']),
                   'required': True},
        'param3': {'type': 'str',
                   'fallback': (env_fallback, ['PARAM3']),
                   'no_log': True},
    }

    no_log_values = set_fallbacks(argument_spec, options)
    assert 'param1' in options
    assert 'param2' in options
    assert 'param3' in options
    assert 'PARAM3' not in os.environ
    assert no_log_values == set()


# Generated at 2022-06-22 21:53:17.573889
# Unit test for function remove_values
def test_remove_values():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    assert remove_values("test", ["test"]) == ''
    assert remove_values("test test", ["test"]) == 'test'
    assert remove_values("test", ["test1"]) == 'test'
    # Test sequence types
    assert remove_values(["test", "test"], ["test"]) == ['', '']
    assert remove_values(("test", "test"), ["test"]) == ('', '')
    assert remove_values(("test", "test"), ["test1"]) == ('test', 'test')
    assert remove_values({'name': 'test', 'password': 'test'}, ["test"]) == {'name': '', 'password': ''}

# Generated at 2022-06-22 21:53:22.081569
# Unit test for function remove_values
def test_remove_values():
    for value, no_log_strings in (('foo', ['foo']), ('foob', ['foo']), ('barfoo', ['foo']), ('bafoo', ['foo']), ('foobar', ['bar']), ('bar', ['bar'])):
        assert remove_values(value, no_log_strings) == '****'
test_remove_values()  # noqa



# Generated at 2022-06-22 21:53:27.325712
# Unit test for function remove_values
def test_remove_values():
    # Testing for list
    assert remove_values(['ab', 'cd'], 'cd') == ['ab']

    # Testing for dict
    assert remove_values({'ab': 'cd', 'ef': 'gh'}, 'gh') == {'ab': 'cd', 'ef': 'PRIVATE DATA HIDDEN'}

    # Testing for tuple
    assert remove_values(('ab', 'cd'), 'cd') == ('ab',)

    # Testing for set
    assert remove_values(set(['ab', 'cd']), 'cd') == set(['ab'])


# Generated at 2022-06-22 21:53:37.888297
# Unit test for function sanitize_keys
def test_sanitize_keys():
    ignore_keys = frozenset(['_ansible_verbose_always'])
    no_log_strings = set(['no_log'])
    simple_dict = {'k1': {'k2': 'v2'}}
    complex_dict = dict(simple_dict=simple_dict, k1='v1')
    complex_dict += {'k1_no_log': {'k2_no_log': 'v2_no_log', 'k2': 'v2'}, 'k1': 'v1_no_log'}
    simple_list = [{'k1_no_log': {'k2_no_log': 'v2_no_log'}}]

# Generated at 2022-06-22 21:53:44.658460
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'name': {'type': 'str', 'defalut': 'test', 'fallback': (env_fallback, 'ANSIBLE_NET_USERNAME')}}
    parameters = {}
    assert set_fallbacks(argument_spec, parameters) == set()
    parameters = {'name': 'ansible'}
    assert set_fallbacks(argument_spec, parameters) == set()
    parameters = {'name': None}
    assert set_fallbacks(argument_spec, parameters) == set(['test'])
    with pytest.raises(AnsibleFallbackNotFound):
        parameter = {}
        argument_spec = {'name': {'type': 'str', 'defalut': None, 'fallback': (env_fallback, 'ANSIBLE_NET_USERNAME')}}
        fallback_value

# Generated at 2022-06-22 21:53:55.365386
# Unit test for function env_fallback
def test_env_fallback():
    os_environ_save = os.environ
    os.environ = {}

    # Test env variable does not exist
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('AZURE_SECRET')

    # Test env variable exists
    os.environ = {'AZURE_SECRET': 'abc123'}
    assert env_fallback('AZURE_SECRET') == 'abc123'

    # Test more than one env variable exists, first one in args should be returned
    os.environ = {'AZURE_SECRET': 'abc123', 'AZURE_PROFILE': 'test', 'AZURE_SUBSCRIPTION_ID': 'id123'}
    assert env_fallback('AZURE_SECRET', 'AZURE_PROFILE') == 'abc123'

    os.environ

# Generated at 2022-06-22 21:54:05.527840
# Unit test for function remove_values
def test_remove_values():
    assert remove_values("A string", []) == "A string"
    assert remove_values("A string", ["string"]) == "A ******"
    assert remove_values("A super secret string", ["super", "secret"]) == "A **** ****** ******"
    assert remove_values("A super secret string", ["super secret"]) == "A ************** ******"
    assert remove_values("string", ["g"]) == "strin"
    assert remove_values("string", ["g", "s"]) == "****"
    assert remove_values("A string", [u"string"]) == "A ******"
    assert remove_values("string", [u"g"]) == "strin"



# Generated at 2022-06-22 21:54:18.214623
# Unit test for function sanitize_keys
def test_sanitize_keys():
    no_log_values = set()
    no_log_values.add('Sanitize the key')
    no_log_values.add('Sanitize the value')

    # Test strings
    assert sanitize_keys('Sanitize the key', no_log_values, ignore_keys=frozenset(['ignore'])) == 'Sanitize the key'
    assert sanitize_keys('Sanitize the value', no_log_values, ignore_keys=frozenset(['ignore'])) == 'Sanitize the [VALUE_HIDDEN]'

    # Test lists

# Generated at 2022-06-22 21:54:29.334755
# Unit test for function remove_values
def test_remove_values():
    '''Test that remove_values checks what it needs to'''
    assert remove_values('foo', []) == 'foo'
    assert remove_values('foo', None) == 'foo'
    assert remove_values(None, None) is None
    assert remove_values(1, []) == 1
    assert remove_values(True, ['True']) == True
    assert remove_values('hello world', ['hello world']) is None
    assert remove_values('hello world', ['hello']) == ' world'
    assert remove_values('password="this should be hidden"', ['password']) == 'password="*********"'
    assert remove_values(list(range(0, 100)), []) == list(range(0, 100))

# Generated at 2022-06-22 21:54:38.366832
# Unit test for function sanitize_keys
def test_sanitize_keys():
    """test_sanitize_keys"""
    obj = {'foo': 'bar', 'my_password': 'super secret',
           'foo_password': 'another secret',
           'list': [], 'dict': {'foo': 'bar'},
           'nested': {'foo': {'bar': {'password': 'in the nested dictionary'}}},
           'nested_list': [{'password': 'in the nested list'}]
           }
    no_log_values = ['super secret', 'in the nested dictionary', 'in the nested list']
    result = sanitize_keys(obj, no_log_values, ignore_keys=frozenset(['foo']))

# Generated at 2022-06-22 21:54:45.956976
# Unit test for function env_fallback
def test_env_fallback():
    # single match
    assert env_fallback('FOO') == 'bar'
    # no matches
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('xFOO')
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('FOOx')
    # first match wins
    os.environ['FOO'] = 'baz'
    assert env_fallback('FOO') == 'bar'
    os.environ.pop('FOO')



# Generated at 2022-06-22 21:54:55.967336
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        test_param=dict(required=False, fallback=(env_fallback, 'TEST_PARAM')),
        test_param_list=dict(required=False, type='list', fallback=(env_fallback, 'TEST_PARAM_LIST')),
        test_param_dict=dict(required=False, type='dict', fallback=(env_fallback, 'TEST_PARAM_DICT'))
    )
    parameters = dict()
    no_log_values = set()
    no_log_values.update(set_fallbacks(argument_spec, parameters))
    assert len(parameters) == 1
    assert list(parameters.keys()) == ['test_param']
    assert parameters['test_param'] == 'True'

# Generated at 2022-06-22 21:55:04.759916
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV'] = 'TEST'
    os.environ['ANSIBLE_TEST_NOTFOUND_ENV'] = 'NOTFOUND'
    os.environ['ANSIBLE_TEST_UNSET_ENV'] = 'UNSET'
    os.environ['ANSIBLE_TEST_UNSET'] = 'UNSET'

# Generated at 2022-06-22 21:55:12.951743
# Unit test for function remove_values
def test_remove_values():
    obj = {'a': {'b': 'a', 'c': 'b'}, 'b': ['Hello', 'World', 'Hello', 'World'], 'c': {'b': 'c', 'c': 'd'}}
    no_log_strings = ['Hello', 'World']
    assert remove_values(obj, no_log_strings) == {'a': {'b': 'a', 'c': 'b'},
                                                  'b': ['*' * 5, '*' * 5, '*' * 5, '*' * 5],
                                                  'c': {'b': 'c', 'c': 'd'}}



# Generated at 2022-06-22 21:55:24.348771
# Unit test for function sanitize_keys
def test_sanitize_keys():
    no_log_strings = [b'hunter2', 'hunter2']
    obj = {
        '_ansible_no_log': True,
        'key1': 'hunter2',
        'key2': {
            'key1': 'hunter2',
            '_ansible_no_log': True,
        },
        'key3': [
            {
                '_ansible_no_log': True,
                'key1': 'hunter2',
                'key2': {
                    'key1': 'hunter2',
                    '_ansible_no_log': True,
                },
            },
            {},
        ]
    }


# Generated at 2022-06-22 21:55:34.927331
# Unit test for function remove_values
def test_remove_values():
    no_log_strings = ['PASSWORD', 'SECRET', 'PRIVATE']
    old_data = dict(PASSWORD=5, SECRET=7, PRIVATE=9, PUBLIC=11)
    new_data = remove_values(old_data, no_log_strings)
    assert new_data == dict(PUBLIC=11)

    old_data = dict(PASSWORD=5, SECRET=7, PRIVATE=9, PUBLIC=dict(PASSWORD=13))
    # This looks circular but it's actually just a dictionary containing itself.
    old_data['self'] = old_data
    new_data = remove_values(old_data, no_log_strings)

# Generated at 2022-06-22 21:55:40.096338
# Unit test for function remove_values
def test_remove_values():
    no_log_strings_list = ['password', 'secret', 'passwd', 'authorization', 'api_key', 'apikey', 'access_token']
    no_log_strings_set = set(no_log_strings_list)
    no_log_strings_tuple = tuple(no_log_strings_list)
    # value is string
    value_str = 'password'
    expected_str = '???'
    result_str = remove_values(value_str, no_log_strings_list)
    assert result_str == expected_str
    result_str = remove_values(value_str, no_log_strings_set)
    assert result_str == expected_str
    result_str = remove_values(value_str, no_log_strings_tuple)
    assert result_str == expected_

# Generated at 2022-06-22 21:55:51.971000
# Unit test for function env_fallback
def test_env_fallback():

    def check(args, val):
        try:
            result = env_fallback(*args)
        except AnsibleFallbackNotFound:
            if val is not None:
                print("error: expected %s, got none" % val)
            return

        if result != val:
            print("error: expected %s, got %s" % (val, result))

    check(['ANSIBLE_TEST_ONE'], None)
    check(['ANSIBLE_TEST_ONE', 'ANSIBLE_TEST_TWO'], 'foo')
    check(['ANSIBLE_TEST_TWO', 'ANSIBLE_TEST_ONE'], 'foo')

    # temporarily set some env vars and ensure they're used
    os.environ['ANSIBLE_TEST_ONE'] = 'bar'

# Generated at 2022-06-22 21:56:01.408469
# Unit test for function set_fallbacks
def test_set_fallbacks():

    class TestModule(object):
        def __init__(self, params):
            self.params = params

# Generated at 2022-06-22 21:56:13.573740
# Unit test for function env_fallback
def test_env_fallback():
    def mock_os_environ(environment):
        def inner():
            return environment
        return inner
    assert env_fallback('test_1') == 'test_1'
    test_dict = {'test_1': 'test'}
    assert env_fallback('test_1', 'test_2', os_environ=mock_os_environ(test_dict)) == 'test'
    test_dict = {}
    assert env_fallback('test_2', os_environ=mock_os_environ(test_dict)) == 'test_2'
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('test_2', 'test_3', os_environ=mock_os_environ(test_dict))


# Generated at 2022-06-22 21:56:24.332352
# Unit test for function remove_values
def test_remove_values():
    assert remove_values('some_value', ['value']) == 'some_'
    assert remove_values(['value'], ['value']) == ['']
    assert remove_values(dict(a='value', b='value'), ['value']) == {'a': '', 'b': ''}
    assert remove_values(dict(a='value', b=dict(c='value')), ['value']) == {'a': '', 'b': {'c': ''}}
    assert remove_values(dict(a='value', b=dict(c='value', d=dict(e='value'))), ['value']) == {'a': '', 'b': {'c': '', 'd': {'e': ''}}}
    assert remove_values(['value'], ['value']) == ['']

# Generated at 2022-06-22 21:56:35.322816
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys(dict(a=dict(b='foo')), {'foo'}) == {'a': {'b': 'sanitized_or_removed'}}
    assert sanitize_keys(dict(a=dict(no_log_bar='foo'), b='foo'), {'foo'}) == {'a': {'sanitized_or_removed': 'sanitized_or_removed'}, 'b': 'sanitized_or_removed'}
    assert sanitize_keys(dict(a=dict(b=dict(c='foo'))), {'foo'}) == {'a': {'b': {'c': 'sanitized_or_removed'}}}
    assert SanitizeBytesType(b'foo') == b'sanitized_or_removed'

# Generated at 2022-06-22 21:56:37.492568
# Unit test for function env_fallback
def test_env_fallback():
    import os
    os.environ['FOO'] = 'bar'
    assert env_fallback('FOO') == 'bar'



# Generated at 2022-06-22 21:56:46.213257
# Unit test for function remove_values
def test_remove_values():
    MOCK_INPUT = {
        'ansible_ssh_host': 'localhost',
        'ansible_ssh_port': '2222',
        'ansible_ssh_pass': 'password'
    }

    MOCK_OUTPUT = {
        'ansible_ssh_host': 'localhost',
        'ansible_ssh_port': '2222',
        'ansible_ssh_pass': '**'
    }

    assert remove_values(MOCK_INPUT, ['password']) == MOCK_OUTPUT



# Generated at 2022-06-22 21:56:55.738490
# Unit test for function env_fallback
def test_env_fallback():
    """test function env_fallback"""
    os.environ['AZ_SECRET_NAME'] = 'my secrets'
    os.environ['AZ_COSTCENTER'] = 'default'
    assert env_fallback('AZ_SECRET_NAME') == 'my secrets'
    assert env_fallback('AZ_COSTCENTER') == 'default'
    os.environ['AZ_COSTCENTER'] = 'default'
    with pytest.raises(AnsibleFallbackNotFound) as ex:
        env_fallback('AZ_RESOURCE_GROUP')
    assert 'No fallback to populate missing parameter `AZ_RESOURCE_GROUP` found' == to_native(ex.value)


# Generated at 2022-06-22 21:57:05.560073
# Unit test for function remove_values
def test_remove_values():
    import sys
    import difflib
    from ansible.module_utils._text import to_bytes

    def test(value, no_log_strings, expected):
        """Helper function to run a single test"""

        # I made this a function instead of running it inline in the tests below
        # because doing so was causing the interpreter to crash on exit from the
        # module. This may be related to issue #27234.
        actual = remove_values(value, no_log_strings)

# Generated at 2022-06-22 21:57:12.221487
# Unit test for function env_fallback
def test_env_fallback():
    assert_equals(env_fallback('ANSIBLE_REMOTE_USER', 'ANSIBLE_NET_USERNAME'), 'root')
    assert_equals(env_fallback('ANSIBLE_REMOTE_USER', 'ANSIBLE_NET_USERNAME', 'ANSIBLE_USER'), 'admin')
    assert_raises(AnsibleFallbackNotFound, env_fallback, 'ANSIBLE_REMOTE_USER', 'ANSIBLE_NET_USERNAME', 'ANSIBLE_USER')



# Generated at 2022-06-22 21:57:21.842988
# Unit test for function remove_values
def test_remove_values():
    '''
    Sanity test for function remove_values
    '''
    import sys
    import io
    from ansible.module_utils import basic

    # make sure that no exception is raised,
    # and there is no traceback printed to stderr
    stderr = sys.stderr
    try:
        sys.stderr = io.StringIO()
        try:
            remove_values({}, [])
        except:
            raise AssertionError("Incorrect exception thrown by remove_values")
        assert not sys.stderr.getvalue()
    finally:
        sys.stderr = stderr

# Generated at 2022-06-22 21:57:31.863317
# Unit test for function sanitize_keys
def test_sanitize_keys():
    class Dummy(object):
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    obj = Dummy(1, 2, 3, a=4, b=5, c=6)
    obj.d = obj

    updated = sanitize_keys(obj, [3, 5, 6], ignore_keys=('a', 'd'))
    assert updated.args[0] == 1
    assert updated.args[1] == 2
    assert updated.args[2] == 'NO_LOG'
    assert updated.kwargs['a'] == 4
    assert updated.kwargs['b'] == 'NO_LOG'
    assert updated.kwargs['c'] == 'NO_LOG'
    assert updated.d == 'NO_LOG'


# Unit

# Generated at 2022-06-22 21:57:42.367830
# Unit test for function env_fallback
def test_env_fallback():
    """
    Ensure we can fall back to environment variable.
    """
    # We are not testing the environemnt variable interaction
    # so just mock it to this
    def mock_environ(name, value):
        os.environ[name] = value

    mock_environ('AWX_TEST_VAR', 'awx')
    res = env_fallback('AWX_TEST_VAR')
    os.environ.pop('AWX_TEST_VAR')
    assert res == 'awx'
    raises(AnsibleFallbackNotFound, env_fallback, 'NOT_A_REAL_VARIABLE')



# Generated at 2022-06-22 21:57:51.936243
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys({'foo': 'bar'}, {'bar'}) == {'foo': 'bar'}

    assert sanitize_keys({'foo': 'bar'}, {'foo'}) == {'***': 'bar'}
    assert sanitize_keys({'foo': 'bar', 'baz': 'blah'}, {'foo'}) == {'***': 'bar', 'baz': 'blah'}

    # Test nested dicts
    assert sanitize_keys({'foo': {'bar': 'baz'}}, {'foo'}) == {'***': {'bar': 'baz'}}

    # Test nested dicts with dict keys and values

# Generated at 2022-06-22 21:57:58.949575
# Unit test for function env_fallback
def test_env_fallback():
    env_dict = {'first': 'test_test', 'second': 'test_test'}
    env_var_name = 'test_test'
    os.environ[env_var_name] = 'test_test'
    assert env_fallback(env_var_name) == 'test_test'
    os.environ[env_var_name] = ''
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback(env_var_name)


# Generated at 2022-06-22 21:58:10.566775
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('FOO') == os.environ['FOO']
    assert env_fallback('FOO', 'BAR') == os.environ['FOO']
    assert env_fallback('FOO', 'BAR', 'BAZ') == os.environ['FOO']
    os.environ['FOO'] = 'FOOBAR'
    assert env_fallback('FOO') == 'FOOBAR'
    del os.environ['FOO']
    os.environ['BAR'] = 'BARFOO'
    assert env_fallback('FOO', 'BAR') == 'BARFOO'
    del os.environ['BAR']
    os.environ['BAZ'] = 'BAZBAZ'

# Generated at 2022-06-22 21:58:15.140639
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('FOO') == os.environ['FOO']
    assert env_fallback('FOO', 'BAR') == os.environ['FOO']
    assert env_fallback('FOO', 'BAR', 'BAZ') == os.environ['FOO']
    assert env_fallback('FOO', 'BAR', 'BAZ', 'QQQ') == os.environ['FOO']
    assert env_fallback('FOO', 'BAR', 'FOO') == os.environ['FOO']



# Generated at 2022-06-22 21:58:25.306557
# Unit test for function set_fallbacks
def test_set_fallbacks():
    arg_spec = dict(param1=dict(type='str', fallback=(env_fallback, 'PARAMETER1')),
                    param2=dict(type='int', fallback=(env_fallback, 'PARAMETER2')),
                    param3=dict(type='bool', fallback=(env_fallback, 'PARAMETER3')),
                    param4=dict(type='float', fallback=(env_fallback, 'PARAMETER4')),
                    param5=dict(type='list', fallback=(env_fallback, 'PARAMETER5')),
                    param6=dict(type='path', fallback=(env_fallback, 'PARAMETER6')),
                    )
    parameters = dict()
    os.environ['PARAMETER1'] = 'test string'
    os.en

# Generated at 2022-06-22 21:58:36.893229
# Unit test for function remove_values
def test_remove_values():
    a = ''
    b = 'simple string'
    c = 'string with %s %d' % (b, 1)
    d = '%ss with' % b
    e = ['%s strings' % c, d, c]
    f = ['list with %s strings' % c, d, c]
    g = {'key1': c, 'key2': d, 'key3': e, 'key4': f}
    h = {'key1': c, 'key2': d, 'key3': e, 'key4': f, 'key5': g}
    i = {'key1': c, 'key2': d, 'key3': e, 'key4': f, 'key5': g, 'key6': h}

# Generated at 2022-06-22 21:58:41.714943
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_VAR'] = 'testing'
    assert env_fallback('ANSIBLE_TEST_VAR') == 'testing'
    del os.environ['ANSIBLE_TEST_VAR']
    raises(AnsibleFallbackNotFound, env_fallback, 'ANSIBLE_TEST_VAR')



# Generated at 2022-06-22 21:58:45.670328
# Unit test for function remove_values
def test_remove_values():
    assert remove_values("Hello world. Some pass is test", ["pass"]) == "Hello world. Some ******** is test"
    assert remove_values("Hello world. Some PASS is test", ["pass"]) == "Hello world. Some PASS is test"



# Generated at 2022-06-22 21:58:57.201748
# Unit test for function remove_values
def test_remove_values():
    """Basic unit tests for remove_values"""

    # This test is explicitly written without any use of dict(s)
    # Because the dicts take a different order in py3.6 and we
    # want to make sure we are testing the right thing

# Generated at 2022-06-22 21:59:05.789505
# Unit test for function remove_values
def test_remove_values():
    assert remove_values('hello world', ['world']) == 'hello '
    assert remove_values('hello world', ['hello']) == ' world'
    assert remove_values('hello world', []) == 'hello world'
    assert remove_values('hello world', ['hello', 'world']) == ' '
    assert remove_values('helloworld', ['hello', 'world']) == ''
    assert remove_values('helloworld', ['hello', 'world', 'low']) == 'he'
    assert remove_values('helloworld', ['hello', 'world', 'low', 'he']) == 'd'
    assert remove_values({'foo': 'hello world'}, ['world']) == {'foo': 'hello '}

# Generated at 2022-06-22 21:59:13.692655
# Unit test for function env_fallback
def test_env_fallback():
    env = os.environ.copy()
    try:
        del env['ANSIBLE_CONFIG']
        with set_environ(env):
            assert None == env_fallback('ANSIBLE_CONFIG')
        with set_environ({'ANSIBLE_CONFIG': './test.cfg'}):
            assert './test.cfg' == env_fallback('ANSIBLE_CONFIG')
    finally:
        # Restore environment
        os.environ.update(env)



# Generated at 2022-06-22 21:59:18.334378
# Unit test for function env_fallback
def test_env_fallback():
    """Unit test for env_fallback function"""

    assert env_fallback(None) == AnsibleFallbackNotFound
    assert env_fallback("UNIT_TEST_ENV_VAR") == "UNIT_TEST_VALUE"


# Generated at 2022-06-22 21:59:23.794317
# Unit test for function env_fallback
def test_env_fallback():

    assert 'HOME' in os.environ

    assert env_fallback('HOME') == os.environ['HOME']

    assert env_fallback('asdf', 'HOME') == os.environ['HOME']

    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('asdf', 'asdf2')



# Generated at 2022-06-22 21:59:30.147461
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert set_fallbacks({"one": {"type": "path", "fallback": (env_fallback, "ANSIBLE_LOCAL_TMP")}}, {}) == set()
    assert 'ANSIBLE_LOCAL_TMP' in set_fallbacks({"one": {"type": "path", "fallback": (env_fallback, "ANSIBLE_LOCAL_TMP")}}, {"one": ''})



# Generated at 2022-06-22 21:59:41.870541
# Unit test for function set_fallbacks

# Generated at 2022-06-22 21:59:54.489138
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'first': {
            'type': 'str',
            'fallback': ('env_fallback', ('FIRST_FALLBACK', 'SECOND_FALLBACK'))
        },
        'second': {
            'type': 'int',
            'fallback': (int_fallback, (0, 1))
        },
        'third': {
            'type': 'dict',
            'fallback': (dict_fallback, ({'foo': 'bar'}, {'bar': 'baz'}))
        }
    }
    parameters = {}
    os.environ['FIRST_FALLBACK'] = 'first'
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['first'] == 'first'
    assert parameters['second'] == 0


# Generated at 2022-06-22 21:59:56.358767
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('ANSIBLE_FOO') == os.environ['ANSIBLE_FOO']


# Generated at 2022-06-22 22:00:04.149760
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys({'abc': 'def'}, set()) == {'abc': 'def'}
    assert sanitize_keys({'abc': 'def', 'g': [2, 3, 4]}, {'def'}) == {'abc': '***'}
    assert sanitize_keys({'abc': 'def', 'g': [2, 3, 4]}, {'def'}, {'g'}) == {'abc': '***', 'g': [2, 3, 4]}
    assert sanitize_keys({'abc': 'def', 'g': [2, 3, 4]}, {'def', 'cd'}) == {'ab': '**'}

# Generated at 2022-06-22 22:00:14.212421
# Unit test for function remove_values
def test_remove_values():
    assert remove_values({"key": "value", "key2": "value2"}, ["value"]) == {"key": "@HIDDEN", "key2": "value2"}
    assert remove_values({"key": {"key": "value"}, "key2": {"key": "value2"}, "key3": {"key": "value"}}, ["value"]) == {"key": {"key": "@HIDDEN"}, "key2": {"key": "value2"}, "key3": {"key": "@HIDDEN"}}
    assert remove_values(["value", ["value"]], ["value"]) == ["@HIDDEN", ["@HIDDEN"]]
    assert remove_values(["value", ["value"]], ["value", "@HIDDEN"]) == ["@HIDDEN", ["@HIDDEN"]]

# Generated at 2022-06-22 22:00:25.176470
# Unit test for function sanitize_keys
def test_sanitize_keys():
    no_log_strings = set(['SOME_PASSWORD'])
    ignore_keys = set(['FINGERPRINT'])

    data = dict(
        ANSWER=42,
        _ansible_verbose_override=True, # should be kept as-is
        FINGERPRINT='xxx', # should be kept as-is
        PASSWORD='SOME_PASSWORD',
        PASSWORD_HERE='SOME_PASSWORD',
        PASSWORD_FIELD='SOME_PASSWORD')

    new_value = sanitize_keys(data, no_log_strings, ignore_keys)


# Generated at 2022-06-22 22:00:36.606268
# Unit test for function remove_values
def test_remove_values():
    test_private_value = 'foo'
    test_value_dict = {'key1': 'foo', 'key2': 'bar', 'key3': 'foo'}
    test_value_list = ['foo', 'bar']
    test_value_set = {'foo', 'bar'}
    test_value_tuple = ('foo', 'bar')

    result_dict = remove_values(test_value_dict, test_private_value)
    assert result_dict == {'key1': 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER', 'key2': 'bar', 'key3': 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'}

    result_list = remove_values(test_value_list, test_private_value)

# Generated at 2022-06-22 22:00:44.931980
# Unit test for function env_fallback
def test_env_fallback():
    """Test env_fallback"""
    try:
        env_fallback('foo', 'bar')
    except AnsibleFallbackNotFound:
        pass
    else:
        raise AssertionError('env_fallback did not raise AnsibleFallbackNotFound when there is no matching environment variable')
    os.environ['foo'] = 'bar'
    if env_fallback('foo', 'bar') != 'bar':
        raise AssertionError('env_fallback did not return value from environment variable')
    del os.environ['foo']



# Generated at 2022-06-22 22:00:51.195661
# Unit test for function sanitize_keys
def test_sanitize_keys():
    s = set()
    s.add('secretvalue')
    d = {
        'first': 'testvalue',
        'second': s,
        'third': {'othertest': 'abc', 'password': '123'},
        'fourth': ['foo', 'bar', 'baz']
    }
    assert sanitize_keys(d, ['secretvalue']) == {
        'first': 'testvalue',
        'second': {'secretvalue'},
        'third': {'othertest': 'abc', 'password': 'REDACTED'},
        'fourth': ['foo', 'bar', 'baz']
    }, 'sanitize_keys did not remove value from key'



# Generated at 2022-06-22 22:00:59.493330
# Unit test for function env_fallback
def test_env_fallback():

    os.environ['ANSIBLE_NET_PASSWORD'] = 'test123'
    assert env_fallback('ANSIBLE_NET_USERNAME', 'ANSIBLE_NET_PASSWORD') == 'test123'
    assert env_fallback('ANSIBLE_NET_USERNAME') == 'test123'

# Reference: https://github.com/ansible/ansible/blob/devel/lib/ansible/module_utils/connection.py#L96

DEFAULT_TIMEOUT = 10



# Generated at 2022-06-22 22:01:08.657675
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        foo=dict(fallback=(env_fallback, 'MY_VAR')),
        bar=dict(fallback=(env_fallback, 'MY_OTHER_VAR')),
        context=dict(type='list', elements='int', fallback=[[3, 4, 5]])
    )
    # Test 1.
    # set_fallbacks should not set parameters if a fallback does not exist.
    parameters = dict(foo='not_bar', bar='bar_bar')
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert no_log_values == set([])
    assert parameters == dict(foo='not_bar', bar='bar_bar')
    # Test 2.
    # set_fallbacks should set parameters if a fallback exists.
    parameters = dict

# Generated at 2022-06-22 22:01:20.355045
# Unit test for function env_fallback
def test_env_fallback():
    # Remove this variable if it exists and replace it with our variable
    if 'TEST_ENV_KEY' in os.environ:
        del os.environ['TEST_ENV_KEY']

    test_key = 'TEST_ENV_KEY'
    test_value = 'TEST_ENV_VALUE'

    # Fail gracefully if the env variable isn't set
    new_value = env_fallback(test_value)
    assert new_value == test_value

    # Ensure that the fallback returns our env variable
    os.environ[test_key] = test_value
    new_value = env_fallback(test_value)
    assert new_value == os.environ[test_key]

