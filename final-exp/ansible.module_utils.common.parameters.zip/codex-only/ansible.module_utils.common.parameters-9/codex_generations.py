

# Generated at 2022-06-22 21:51:23.699850
# Unit test for function set_fallbacks
def test_set_fallbacks():
    arguments_spec = dict(
        fb_str=dict(required=True, type='str'),
        fb_int=dict(required=True, type='int', default=0),
        fb_default=dict(required=True, type='str', default='fb_default'),
        fb_no_default=dict(required=True, type='str'),
        fb_env=dict(required=True, type='str', fallback=(env_fallback, 'FB_ENV')),
        fb_callable=dict(required=True, type='str', fallback=(lambda: 'fb_callable'), no_log=True),
    )

# Generated at 2022-06-22 21:51:33.646091
# Unit test for function env_fallback
def test_env_fallback():
    assert os.environ['PATH']
    assert env_fallback('PATH') == os.environ['PATH']
    assert env_fallback('ANSIBLE_FOOBAR_BAZ') == os.environ['ANSIBLE_FOOBAR_BAZ']
    os.environ['ANSIBLE_FOOBAR_BAZ'] = 2
    assert env_fallback('ANSIBLE_FOOBAR_BAZ') == 2
    del os.environ['ANSIBLE_FOOBAR_BAZ']
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('SOME_OTHER_VAR')
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('PATH', 'SOME_OTHER_VAR')



# Generated at 2022-06-22 21:51:42.639711
# Unit test for function sanitize_keys
def test_sanitize_keys():
    remove_values = remove_values_list(['foo'], [])
    assert isinstance(remove_values, list)
    assert len(remove_values) == 1
    assert remove_values[0] == 'foo'
    remove_values = remove_values_list(['foo', 'bar', 'baz'], [])
    assert isinstance(remove_values, list)
    assert len(remove_values) == 3
    assert remove_values[0] == 'foo'
    assert remove_values[1] == 'bar'
    assert remove_values[2] == 'baz'
    remove_values = remove_values_tuple(['foo'], [])
    assert isinstance(remove_values, tuple)
    assert len(remove_values) == 1
    assert remove_values[0] == 'foo'
    remove

# Generated at 2022-06-22 21:51:46.083096
# Unit test for function env_fallback
def test_env_fallback():
    try:
        env_fallback()
    except AnsibleFallbackNotFound as e:
        pass
    os.environ['FOO'] = 'BAR'
    assert env_fallback('FOO') == 'BAR'


# Generated at 2022-06-22 21:51:59.076119
# Unit test for function set_fallbacks
def test_set_fallbacks():
    arg_spec = {
        'param1': {
            'type': 'str',
            'fallback': (env_fallback, 'env_var1')
        }
    }

    params = {
        'param2': 'value2'
    }

    no_log_values = set_fallbacks(arg_spec, params)
    assert len(no_log_values) == 0
    assert params['param1'] == os.environ['env_var1']
    assert len(params) == 2

    del params['param1']
    no_log_values = set_fallbacks(arg_spec, params)
    assert len(no_log_values) == 0
    assert 'param1' not in params
    assert len(params) == 1


# Generated at 2022-06-22 21:52:08.403482
# Unit test for function sanitize_keys
def test_sanitize_keys():
    obj = {
        "name": "john",
        "PASSWORD": "s3cret",
        "SSN": "7",
        "ansible_private": "foo"
    }
    no_log_strings = [b"s3cret", b"foo"]
    assert {"name": "john", "PASSWORD": "VALUE_SPECIFIED_IN_NO_LOG_PARAMETER", "SSN": "7", "ansible_private": "foo"} == sanitize_keys(obj, no_log_strings)

    obj = [1,2,3,4]
    no_log_strings = ["3"]
    assert [1,2,3,4] == sanitize_keys(obj, no_log_strings)

    obj = [1,2,3,4]
    no_log

# Generated at 2022-06-22 21:52:17.357962
# Unit test for function sanitize_keys
def test_sanitize_keys():
    data = {'key1': 'value1', 'key2': 'value2', 'key3': 'value3', 'key4': 'value4'}
    test1 = sanitize_keys(data, ['value1'])
    assert test1 == {'key1': 'value1', 'key2': 'value2', 'key3': 'value3', 'key4': 'value4'}
    test2 = sanitize_keys(data, ['value2', 'value3'])
    assert test2 == {'key1': 'value1', 'key2': '*****', 'key3': '*****', 'key4': 'value4'}



# Generated at 2022-06-22 21:52:19.865638
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('TEST_FOOBAR') == os.environ['TEST_FOOBAR']
    raises(AnsibleFallbackNotFound, env_fallback, 'TEST_FOOBAR_MISSING')
    assert env_fallback('TEST_FOOBAR', 'TEST_FOOBAR_MISSING') == os.environ['TEST_FOOBAR']



# Generated at 2022-06-22 21:52:29.011698
# Unit test for function sanitize_keys
def test_sanitize_keys():
    # Create a mapping object with one nested mapping and one nested list
    data = dict(
        key_1='value_1',
        key_2=dict(
            key_2_a='value_2_a',
            key_2_b='value_2_b',
        ),
        key_3=['value_3_a', 'value_3_b'],
    )

    # Ensure that the keys are not modified
    assert sanitize_keys(data, ['value_1']) == data
    assert sanitize_keys(data, ['value_2_a']) == data

    # Ensure that sanitizing 'key_2_a' removes just that key
    assert 'key_2_a' in data['key_2']

# Generated at 2022-06-22 21:52:35.000513
# Unit test for function env_fallback
def test_env_fallback():
    field, value = 'foo', 'bar'
    assert env_fallback(field, 'foo') == value
    os.environ['foo'] = 'bar'
    assert env_fallback(field, 'foo') == value
    del os.environ['foo']
    assert env_fallback(field, 'foo') == value



# Generated at 2022-06-22 21:52:46.400142
# Unit test for function set_fallbacks

# Generated at 2022-06-22 21:52:53.092374
# Unit test for function set_fallbacks
def test_set_fallbacks():
    '''to test function set_fallbacks'''
    argument_spec = {
        'foo': {'required': True, 'type': 'str'},
        'bar': {'required': True, 'type': 'str', 'default': 'foobar'},
        'baz': {'required': True, 'type': 'str', 'env': ['/not_set/foo']},
        'bak': {'required': True, 'type': 'str', 'env': ['/not_set/foo']},
    }
    parameters = {}
    set_fallbacks(argument_spec, parameters)
    assert sorted(parameters.keys()) == ['bar']


# Generated at 2022-06-22 21:52:58.751922
# Unit test for function env_fallback
def test_env_fallback():
    var_name = 'ANSIBLE_TEST_ENV_FALLBACK_MODULE'
    var_value = '123'
    os.environ[var_name] = var_value
    assert env_fallback(var_name) == var_value
    with pytest.raises(AnsibleFallbackNotFound):
        assert env_fallback('ANSIBLE_DOES_NOT_EXIST')
    os.environ.pop(var_name)



# Generated at 2022-06-22 21:53:04.001144
# Unit test for function sanitize_keys
def test_sanitize_keys():
  from collections import defaultdict
  import base64

  # Note that the order or dicts does not matter for the results
  dicts = [
    {'secret-key': 'value'},
    {'not-secret-key': 'value'}
  ]

  # The code in this function will only encode the keys that match a string in
  # no_log_strings.
  no_log_strings = ['secret-key']

  # Base64 encoded value of "secret-key"
  encoded_secret_key = base64.urlsafe_b64encode(b"secret-key")

  # Create a dict with the keys base64 encoded
  encoded_dicts = [{encoded_secret_key: "value"}, {'not-secret-key': 'value'}]

  # Create a dict with the encoded key
  encoded_dict

# Generated at 2022-06-22 21:53:12.530588
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys(1, ['a']) == 1
    assert sanitize_keys('a', ['a']) == 'a'
    assert sanitize_keys([1, 'a', None], ['a'], ignore_keys=['a']) == [1, 'a', None]
    assert sanitize_keys({'a': 1}, ['a']) == {'_ansible_no_log': 1}
    assert (sanitize_keys({'test': {'a': 1}}, ['a'], ignore_keys=['test']) ==
            {'test': {'_ansible_no_log': 1}})

# Generated at 2022-06-22 21:53:22.482760
# Unit test for function remove_values
def test_remove_values():
    assert remove_values('pw:sekret', ['pw:', 'sekret']) == '********'

    assert remove_values('pw:sekret', ['pw:', 'sekret']) == '********'
    good = {'pw': 'sekret'}
    assert remove_values(good, ['pw:', 'sekret']) == {}

    good = {'pw': 'sekret', 'pid': 42}
    assert remove_values(good, ['pw:', 'sekret']) == {'pid': 42}

    good = {'pw': 'sekret', 'pid': 42}
    assert remove_values(good, ['pw:', 'sekret']) == {'pid': 42}


# Generated at 2022-06-22 21:53:34.207961
# Unit test for function remove_values
def test_remove_values():
    no_log_strings = ['TEST1', u'TEST2', b'TEST3']
    # Simple test.
    assert remove_values('ABCD TEST1 EFGH IQJK', no_log_strings) == 'ABCD  EFGH IQJK'
    assert remove_values(u'ABCD TEST2 EFGH IQJK', no_log_strings) == u'ABCD  EFGH IQJK'
    assert remove_values(b'ABCD TEST3 EFGH IQJK', no_log_strings) == b'ABCD  EFGH IQJK'

    # Test that we can use this function on containers.
    assert remove_values(['ABCD', 'TEST1'], no_log_strings) == ['ABCD', '']

# Generated at 2022-06-22 21:53:42.310426
# Unit test for function remove_values
def test_remove_values():
    list_of_str = ['foo', 'bar', 'baz']
    list_of_dict = [{'foo': 1, 'bar': 2, 'baz': 3}, {'foo': 1, 'bar': 2, 'baz': 3}]
    list_of_mix = ['foo', {'bar': {'baz': 1, 'qux': 2}}, 3]
    for data in (list_of_str, list_of_dict, list_of_mix):
        assert remove_values(data, 'bar') == ['foo', 'baz']
    assert remove_values({'foo': list_of_dict}, 'bar') == {'foo': [{'foo': 1, 'baz': 3}, {'foo': 1, 'baz': 3}]}



# Generated at 2022-06-22 21:53:51.466954
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys('string', 'str') == '********'
    assert sanitize_keys('string', 'str', ignore_keys=set()) == '********'
    assert sanitize_keys('string', 'str', ignore_keys=frozenset()) == '********'
    assert sanitize_keys('string', no_log_strings=['str']) == '********'
    assert sanitize_keys('string', ['str']) == '********'

    assert sanitize_keys({'key': 'string', '_ansible_no_log': True}, 'str') == {'k****': 'string', '_ansible_no_log': True}

# Generated at 2022-06-22 21:54:02.536894
# Unit test for function remove_values
def test_remove_values():
    assert remove_values("dog\ncat\nfish\n", "dog") == "********\ncat\nfish\n"
    assert remove_values("dog\ncat\nfish\n", ["dog", "fish"]) == "********\ncat\n*******\n"
    assert remove_values("dog\ncat\nfish\n", ["dog", "cat"]) == "********\n*******\nfish\n"
    assert remove_values("dog\ncat\nfish\n", ["dog", "cat", "fish"]) == "*********************************\n"
    assert remove_values("dog\ncat\nfish cat\n", ["dog", "cat", "fish"]) == "*********************************\n*** ****\n"

# Generated at 2022-06-22 21:54:11.494135
# Unit test for function sanitize_keys
def test_sanitize_keys():
    template = dict(
        a=None,
        b=1,
        c="string",
        m=dict(
            b=1,
            c="string",
            d=[10, 20, 30],
            e=(40, 50, 60),
            f={'one': 1, 'two': 2},
            g=set([70, 80, 90])
        )
    )
    data = copy.deepcopy(template)
    no_log_strings = set()
    assert sanitize_keys(data, no_log_strings) == template

    data = copy.deepcopy(template)
    no_log_strings = None
    assert sanitize_keys(data, no_log_strings) == template

    data = copy.deepcopy(template)
    no_log_strings = set(['string'])
   

# Generated at 2022-06-22 21:54:13.890653
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('ANSIBLE_FOO', 'ANSIBLE_BAR') == os.environ['ANSIBLE_FOO']


# Generated at 2022-06-22 21:54:18.009587
# Unit test for function env_fallback
def test_env_fallback():
    # Test a valid environment variable
    assert env_fallback('HOME') == os.environ['HOME']
    # Test an invalid environment variable
    with raises(AnsibleFallbackNotFound):
        env_fallback('invalid_envvar')

_FALLBACKS['env'] = env_fallback



# Generated at 2022-06-22 21:54:23.878300
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert set_fallbacks({'foo': {'fallback': (env_fallback, 'FOO')}}, {}) == set()
    assert set_fallbacks({'foo': {'fallback': (env_fallback, 'FOO')}}, {'foo': 12}) == set()
    assert set_fallbacks({'foo': {'fallback': (env_fallback, 'FOO')}}, {'foo': 12, 'bar': 13}) == set()
    assert not set_fallbacks({'foo': {'fallback': (env_fallback, 'MISSING')}}, {})
    assert set_fallbacks({'foo': {'fallback': (env_fallback, 'FOO')}}, {}) == set(['12341234'])

    os.environ['FOO'] = "1234"


# Generated at 2022-06-22 21:54:35.680163
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys({'k1': 'v1'}, {'v1'}) == {'k1': 'v1'}
    assert sanitize_keys({'k1': 'v1'}, {'k1'}) == {'k1': 'v1'}
    assert sanitize_keys({'k1': 'v1', 'k2': 'v2'}, {'k1'}) == {'k2': 'v2'}
    assert sanitize_keys({'k1': 'v1'}, {'k1', 'k2'}) == {}

# Generated at 2022-06-22 21:54:40.726777
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['TEST_VALUE'] = 'sometestvalue'
    assert env_fallback('TEST_VALUE')  == 'sometestvalue'
    os.environ.pop('TEST_VALUE')
    assert env_fallback('BLAH_VALUE')  == AnsibleFallbackNotFound



# Generated at 2022-06-22 21:54:51.167224
# Unit test for function env_fallback
def test_env_fallback():
    """Test env_fallback()"""

    # Test if it falls back to environment varialbe
    os.environ['ANSIBLE_TEST_ENV_FALLBACK_1'] = 'test env 1'
    result = env_fallback('ANSIBLE_TEST_ENV_FALLBACK_1')
    assert('test env 1' == result)

    # Test if it falls back to environment varialbe with prefix
    os.environ['ANSIBLE_TEST_ENV_FALLBACK_PREFIX_2'] = 'test env 2'
    result = env_fallback('TEST_ENV_FALLBACK_PREFIX', prefix='ANSIBLE_')
    assert('test env 2' == result)

    # Test if it can find fallback

# Generated at 2022-06-22 21:54:56.704509
# Unit test for function env_fallback
def test_env_fallback():
    """Test function env_fallback"""
    v = '__unittest_envvar_env_fallback'
    assert v not in os.environ

    try:
        os.environ[v] = 'k'
        assert env_fallback(v) == 'k'
    finally:
        del os.environ[v]



# Generated at 2022-06-22 21:55:05.113651
# Unit test for function set_fallbacks
def test_set_fallbacks():
    spec = {'param': {'type': 'str'}}
    values = {}
    fallback_values = set_fallbacks(spec, values)
    assert len(fallback_values) == 0
    assert len(values) == 0

    env_var = 'ANSIBLE_TEST_VAR'
    os.environ[env_var] = '123'
    spec = {'param': {'type': 'str', 'fallback': (env_fallback, env_var)}}
    values = {}
    fallback_values = set_fallbacks(spec, values)
    assert len(fallback_values) == 0
    assert len(values) == 1

    spec = {'param': {'type': 'str', 'fallback': (env_fallback, env_var), 'no_log': True}}
    values

# Generated at 2022-06-22 21:55:16.089364
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # No fallbacks
    f_args = dict(fallback=None)
    assert set_fallbacks(dict(foo=f_args), {}) == set()

    # No fallback value
    f_args = dict(fallback=(env_fallback, 'FOO'))
    assert set_fallbacks(dict(foo=f_args), {}) == set()

    # Fallback value set
    os.environ['FOO'] = 'bar'
    assert set_fallbacks(dict(foo=f_args), {}) == {'bar'}

    # No-log fallback value set
    f_args = dict(fallback=(env_fallback, 'FOO'), no_log=True)
    assert set_fallbacks(dict(foo=f_args), {}) == {'bar'}

    del os.en

# Generated at 2022-06-22 21:55:22.789598
# Unit test for function env_fallback
def test_env_fallback():
    os.environ.pop('TEST_ENV_VAR_1', None)
    os.environ['TEST_ENV_VAR_2'] = 'TEST_VALUE'
    assert env_fallback('TEST_ENV_VAR_1', 'TEST_ENV_VAR_2') == 'TEST_VALUE'
    os.environ.pop('TEST_ENV_VAR_2', None)



# Generated at 2022-06-22 21:55:26.068659
# Unit test for function env_fallback
def test_env_fallback():
    assert 'HOME' in os.environ, "%s environment variable required for this test"
    assert env_fallback('HOME') == os.environ['HOME'], "%s environment variable not returned by env_fallback"



# Generated at 2022-06-22 21:55:36.233213
# Unit test for function remove_values
def test_remove_values():
    assert remove_values('secretkey01', ['secret']) == '*******key01'
    assert remove_values('secretkey01', ['secret']) == '*******key01'
    assert remove_values('secretkey01', ['key01']) == 'secretkey01'
    assert remove_values(['secretkey01', 'secretkey02'], ['secret']) == ['*******key01', '*******key02']
    assert remove_values(['secretkey01', 'secretkey02'], ['key02']) == ['secretkey01', 'secretkey02']
    assert remove_values({'secretkey01': 'secretkey02'}, ['key01']) == {'secretkey01': 'secretkey02'}

# Generated at 2022-06-22 21:55:42.900517
# Unit test for function remove_values

# Generated at 2022-06-22 21:55:55.087934
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Testing fallback when no, value is not set
    argument_spec = {'name': {'type': 'str', 'fallback': (env_fallback, ['ANSIBLE_NAME'])}}
    parameters = {}
    no_log_values = set()

    no_log_values.update(set_fallbacks(argument_spec, parameters))
    assert len(no_log_values) == 0
    assert 'name' not in parameters

    # Testing fallback with value set
    os.environ['ANSIBLE_NAME'] = 'ansible'
    parameters = {}
    no_log_values = set()
    no_log_values.update(set_fallbacks(argument_spec, parameters))
    assert len(no_log_values) == 0
    assert parameters['name'] == 'ansible'

    # Testing fallback does

# Generated at 2022-06-22 21:56:03.322245
# Unit test for function set_fallbacks
def test_set_fallbacks():
    params = {'param1': 'value1'}
    arg_spec = dict(param1={'type': 'string'},
                    param2={'type': 'string', 'fallback': ('env_fallback', 'FOO')})
    expect_result = {'param1': 'value1'}
    expect_no_log_values = set()

    os.environ['FOO'] = 'fallback_value'
    result, no_log_values = set_fallbacks(arg_spec, params)
    assert result == expect_result
    assert no_log_values == expect_no_log_values

    del os.environ['FOO']
    result, no_log_values = set_fallbacks(arg_spec, params)
    assert result == expect_result
    assert no_log_values == expect_no

# Generated at 2022-06-22 21:56:14.925771
# Unit test for function remove_values
def test_remove_values():
    data = {
        'name': 'secret name',
        'password': 'secret pass',
        'data': [
            {'name': 'secret name'},
            {'name': 'secret pass'},
        ],
        'nested': {
            'name': 'secret name',
            'password': 'secret pass',
            'data': [
                {'name': 'secret name'},
                {'name': 'secret pass'},
            ],
        }
    }

# Generated at 2022-06-22 21:56:25.399318
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys('hello', set([])) == 'hello'

    assert sanitize_keys('hello', set(['h'])) == 'ello'
    assert sanitize_keys('hello', set(['hello'])) == ''

    assert sanitize_keys(['hello'], set([])) == ['hello']
    assert sanitize_keys(['hello'], set(['hello'])) == ['']

    assert sanitize_keys({'old': 'hello'}, set([])) == {'old': 'hello'}
    assert sanitize_keys({'old': 'hello'}, set(['o'])) == {'ld': 'hello'}
    assert sanitize_keys({'old': 'hello'}, set(['old'])) == {'': 'hello'}

    assert sanitize_

# Generated at 2022-06-22 21:56:36.465129
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Verify that we can set a fallback from an environment variable
    env_key = 'ANSIBLE_FALLBACK_ENV_KEY'
    env_value = '42'
    os.environ[env_key] = env_value
    parameters = {}
    args = ('env:%s' % env_key,)
    test_spec = {'test': {'fallback': args, 'type': 'str'}}
    set_fallbacks(test_spec, parameters)
    assert parameters['test'] == env_value
    os.environ.pop(env_key)

    # Verify that we can set a fallback from an environment variable if no_log is false
    env_key = 'ANSIBLE_FALLBACK_ENV_KEY'
    env_value = '42'

# Generated at 2022-06-22 21:56:44.576369
# Unit test for function sanitize_keys
def test_sanitize_keys():

    # First we need to create a complex object to traverse.
    test_dict = {
        'foo': {
            'bar': 'baz',
            'baz': 'qux',
            'qux': {
                'quux': 'quuz'
            }
        },
        'baz': 'qux',
        'qux': [
            {
                'baz': 'qux',
                'qux': 'quux'
            },
            {
                'baz': 'qux',
                'qux': 'quux'
            },
            'quux'
        ]
    }

    # Now we need to create a set of keys that should be ignored
    ignore_keys = frozenset(['foo', 'quux'])

    # Finally create a set of no_log match strings
    no

# Generated at 2022-06-22 21:56:50.424072
# Unit test for function sanitize_keys
def test_sanitize_keys():
    # Check our sanitize works correctly
    # we should end up with a key of 'ANSIBLEDEBUG' and a value of 'True'
    d = dict(foo="bar", baz="quux", ANSIBLEDEBUG="True")
    ns = set(['bar', 'quux', 'True'])
    no_log_strings = set('foo')
    res = sanitize_keys(d, no_log_strings)
    assert 'ANSIBLEDEBUG' in res
    assert res['ANSIBLEDEBUG'] == 'True'
    assert res['foo'] == 'bar'
    assert res['baz'] == 'quux'

    d = dict(foo="bar", baz="quux", ANSIBLEDEBUG="True")

# Generated at 2022-06-22 21:56:54.570740
# Unit test for function env_fallback
def test_env_fallback():
    try:
        assert env_fallback('PATH') == os.environ['PATH']
    except AnsibleFallbackNotFound:
        # We are not testing that env_fallback raised AnsibleFallbackNotFound
        pass



# Generated at 2022-06-22 21:57:05.000769
# Unit test for function sanitize_keys
def test_sanitize_keys():
    """Unit tests for the sanitize_keys function."""

    # Set the no_log value to something unique to the test
    NO_LOG_VALUE = 'TEST_VALUE_TO_HIDE'

    # The list of tests to run. Each test is a dictionary with the following keys:
    #
    # input_data: The input to the function under test
    # ignore_keys: A list of keys to ignore changes to
    # output_data: The expected output from the function under test
    #
    # The test_name is used to provide the name of the test when reporting the results of the test.
    #
    # Each test can have an additional key named "exception". If this key is present, the test is
    # expected to raise an exception matching the value of this key.

# Generated at 2022-06-22 21:57:14.037681
# Unit test for function remove_values
def test_remove_values():
    assert remove_values([['a', ['b', 'oob']], {'c': 'd'}, 'oob', 'f', ['g'], 'oob'], {'oob'}) == \
        [['a', ['b', '***']], {'c': 'd'}, '***', 'f', ['g'], '***']
    assert remove_values([['a', ['b', 'oob']], {'c': 'd'}, 'oob', 'f', ['g'], 'oob'], {'oob', 'not here'}) == \
        [['a', ['b', 'oob']], {'c': 'd'}, 'oob', 'f', ['g'], 'oob']

# Generated at 2022-06-22 21:57:21.939813
# Unit test for function env_fallback
def test_env_fallback():

    assert 'SHELL' in os.environ
    assert env_fallback('SHELL') == os.environ['SHELL']
    assert 'ANSIBLE_TEST_NONE' not in os.environ
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('ANSIBLE_TEST_NONE')
    assert 'ANSIBLE_TEST_NONE' not in os.environ


_FALLBACK_FUNCTIONS = {
    'env': env_fallback,
}



# Generated at 2022-06-22 21:57:24.389395
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback("dev_user") == os.environ["dev_user"]


# Generated at 2022-06-22 21:57:31.545535
# Unit test for function env_fallback
def test_env_fallback():
    import os

    os.environ['ANSIBLE_TEST'] = 'test_value'
    assert env_fallback('ANSIBLE_TEST') == 'test_value'
    assert env_fallback('ANSIBLE_TEST', 'ANSIBLE_TEST_2') == 'test_value'

    del os.environ['ANSIBLE_TEST']

    assert env_fallback('ANSIBLE_TEST') == '$ANSIBLE_TEST'
    assert env_fallback('ANSIBLE_TEST', 'ANSIBLE_TEST_2') == '$ANSIBLE_TEST_2'



# Generated at 2022-06-22 21:57:43.513562
# Unit test for function sanitize_keys
def test_sanitize_keys():
    """Test function to check sanitize keys function

    :returns: 'ok' if function works correctly, 'fail' if not
    :rtype: str

    """

    test_obj = {'testkey1': {'testkey3': 'testvalue3', 'testkey4': ['testvalue4']},
                'testkey2': {'testkey5': {'testkey6': 'testvalue6'}}}

# Generated at 2022-06-22 21:57:55.166862
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        host=dict(type='str',
                  fallback=(env_fallback, ['ANSIBLE_HOST'])),
        port=dict(type='int', default=8080)
    )
    parameters = dict()
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert len(parameters) == 0
    assert len(no_log_values) == 0

    os.environ['ANSIBLE_HOST'] = '192.0.2.1'
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['host'] == '192.0.2.1'
    assert parameters['port'] == 8080
    assert len(no_log_values) == 0


# Generated at 2022-06-22 21:58:05.485278
# Unit test for function sanitize_keys
def test_sanitize_keys():
    # This dict contains values that need to be removed from the keys
    old_data = dict(
        _remove_me_1='value1',
        _remove_me_2='value2',
        _remove_me_3_password='password123'
    )

    # Define the elements we want removed
    no_log_strings = ['password']

    # Expected the the result contains keys with values removed
    new_data = dict(
        _remove_me_1='value1',
        _remove_me_2='value2',
        me_3='me_3'
    )
    assert new_data == sanitize_keys(old_data, no_log_strings)

    # Check with an additional ignore key

# Generated at 2022-06-22 21:58:16.058600
# Unit test for function remove_values
def test_remove_values():
    from ansible.module_utils._text import to_bytes, to_text

    # Standard container types
    obj = {'foo': 'bar',
           'no_log_foo': 'no_log_bar',
           'a_no_log_element': ['first', 'second', 'no_log_third']}
    test_obj = copy.deepcopy(obj)
    no_log_strings = ['no_log_', 'NOLOG_']

    # Non-container types
    obj = 'no_log_string'
    test_obj = copy.deepcopy(obj)

    # Non-container types
    obj = to_bytes('no_log_bytes')
    test_obj = copy.deepcopy(obj)

    # Container types
    obj = ['first', 'second', 'no_log_third']
    test_

# Generated at 2022-06-22 21:58:25.941350
# Unit test for function remove_values
def test_remove_values():
    # Test removal from simple scalar values
    assert remove_values(b'abc123', [b'abc']) == b'123'
    assert remove_values(b'abc123', [b'123']) == b'abc'
    assert remove_values(b'abc123', [b'abc123']) == b''
    assert remove_values(b'abc123', [b'xyz123']) == b'abc'
    assert remove_values(b'abc123', [b'xyz']) == b'abc123'

    # Test removal from arbitrary scalar values
    assert remove_values(123, [b'abc']) == 123
    assert remove_values(None, [b'abc']) is None
    assert remove_values(1.23, [b'abc']) == 1.23

    # Test removal from simple

# Generated at 2022-06-22 21:58:37.449469
# Unit test for function sanitize_keys
def test_sanitize_keys():
    """Unit test for function sanitize_keys"""
    test_ignore_keys = frozenset(('key_1', 'key_2', '_ansible_foo'))
    test_no_log_strings = frozenset(('bar', 'baz'))


# Generated at 2022-06-22 21:58:47.698639
# Unit test for function set_fallbacks
def test_set_fallbacks():
    arg_spec = dict(
        dict_param=dict(type='dict', fallback=(env_fallback, ['TEST_ENV_PARAM']), default={}),
        bool_param=dict(type='bool', fallback=(env_fallback, ['TEST_ENV_PARAM']), default=True),
        int_param=dict(type='int', fallback=(env_fallback, ['TEST_ENV_PARAM']), default=1),
        float_param=dict(type='float', fallback=(env_fallback, ['TEST_ENV_PARAM']), default=1.0),
        list_param=dict(type='list', fallback=(env_fallback, ['TEST_ENV_PARAM']), default=[])
    )

# Generated at 2022-06-22 21:58:59.579282
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Test usage of the env_fallback fallback strategy
    parameters = {'test_param': 'param'}
    argument_spec = {'test_param': {'fallback': (env_fallback, 'TEST_PARAM')}}
    os.environ['TEST_PARAM'] = 'test_param'
    parameters = set_fallbacks(argument_spec, parameters)
    assert len(parameters) == 2
    del os.environ['TEST_PARAM']

    # Test usage of the env_fallback fallback strategy with no_log
    os.environ['TEST_PARAM'] = 'test_param'
    parameters = {'test_param': 'param'}

# Generated at 2022-06-22 21:59:06.892843
# Unit test for function sanitize_keys
def test_sanitize_keys():
    from ansible.compat import collections_abc as abc
    from ansible.module_utils._text import to_native, to_bytes

# Generated at 2022-06-22 21:59:17.725450
# Unit test for function sanitize_keys
def test_sanitize_keys():

    """
    This is a helper function for test_module.py:assert_no_log
    """
    no_log_strings = set()
    ignore_keys = frozenset()

    sample = dict(
        password='foo',
        secret='bar',
        value=dict(
            keys=set('abcdefghijklmnopqrstuvwxyz'),
            value=list('abcdefghijklmnopqrstuvwxyz'),
        ),
        value_list=list(('password', 'secret', 'newvalue')),
        value_set=set(('password', 'secret', 'newvalue')),
    )
    no_log_strings.update(sample['password'])
    no_log_strings.update(sample['secret'])

# Generated at 2022-06-22 21:59:29.002317
# Unit test for function set_fallbacks
def test_set_fallbacks():
    parameters = {}
    argument_spec = {
        'param1': {
            'type': 'str',
            'fallback': (env_fallback, ('ANSIBLE_PARAM1', 'ANSIBLE_PARAM2'), {'true_value': 'dummy1', 'false_value': 'dummy2'})
        }
    }
    with mock.patch.dict('os.environ', ANSIBLE_PARAM1='true_value'):
        no_log_values = set_fallbacks(argument_spec, parameters)
        assert parameters.get('param1') == 'dummy1'
        assert no_log_values == set()

    parameters = {}

# Generated at 2022-06-22 21:59:36.626688
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'a': {'type': 'str', 'default': 'def_val', 'no_log': True}}
    parameters = {'a':'a_val'}

    assert set_fallbacks(argument_spec, parameters) == set()
    assert parameters['a'] == 'a_val'
    parameters = {}
    assert set_fallbacks(argument_spec, parameters) == set()
    assert parameters['a'] == 'def_val'


# Generated at 2022-06-22 21:59:42.341670
# Unit test for function remove_values
def test_remove_values():
    no_log_strings = ('PASSWORD','SECRET','PRIVATE')
    output = {}
    output["PASSWORD"] = "PASSWORD"
    output["SECRET"] = "SECRET"
    output["PRIVATE"] = "PRIVATE"
    output_modified = remove_values(output, no_log_strings)
    assert output_modified == {"REDACTED": "REDACTED", "REDACTED": "REDACTED", "REDACTED": "REDACTED"}


# Generated at 2022-06-22 21:59:54.535635
# Unit test for function remove_values
def test_remove_values():
    class MockData:
        def __init__(self, data):
            self.data = data

    # Some items which could be in a list/dict
    str1 = 'foo'
    int1 = 1
    list_item = ['foo', 1, ['bar', {'hi': 'there'}], {'foo': 'bar'}]

    # First level of nesting
    dict_item = {'foo': 'bar'}
    list_item2 = ['foo', 1, ['bar', {'hi': 'there'}], dict_item]
    dict_item2 = {'foo': 'bar', 'hi': 'there', 'list': list_item2}
    dict_item3 = {'foo': 'bar', 'hi': 'there', 'dict': dict_item2}

    # Second level of nesting
    dict_item

# Generated at 2022-06-22 22:00:03.006195
# Unit test for function remove_values
def test_remove_values():
    # Test method 'remove_values'
    # Test invalid types
    test_dict = {
        1: (1, "password", "ansible"),
        "test": {"key": "value", "ansible": "password"},
        "test1": "test,test1,ansible,test2",
        "test2": [1, "password", "test", "ansible"],
        "test3": {"key": "value", "ansible": "password"},
    }
    test_result = {"test": {"value": "value", "ansible": "PASSWORD"}, "test1": "test,test1,ANSIBLE,test2", "test2": [1, "PASSWORD", "test", "ANSIBLE"], "test3": {"ansible": "PASSWORD", "value": "value"}}

# Generated at 2022-06-22 22:00:08.034711
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_VAR'] = 'test_value'
    assert env_fallback('ANSIBLE_TEST_VAR') == 'test_value'
    os.environ['ANSIBLE_TEST_VAR'] = None
    assert env_fallback('ANSIBLE_TEST_VAR') is None



# Generated at 2022-06-22 22:00:16.343018
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['FOO'] = 'BAR'
    assert env_fallback('FOO') == 'BAR'
    os.environ['STR_BOO'] = 'yes'
    assert env_fallback('STR_BOO', boolean=True) is True
    assert env_fallback('BAZ', boolean=True) is False
    assert env_fallback('FOO', boolean=True) is False
    assert env_fallback('FOO', boolean=True, fail_on_false=True) is True

    os.environ['FOO'] = '0.1'
    assert env_fallback('FOO', type='float') == 0.1
    assert env_fallback('FOO', type='int') == 0
    assert env_fallback('BAZ', type='int') == 0

    os.environ

# Generated at 2022-06-22 22:00:22.401192
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test' 
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK1') == 'test'
    del os.environ['ANSIBLE_TEST_ENV_FALLBACK']


# Generated at 2022-06-22 22:00:32.857947
# Unit test for function env_fallback
def test_env_fallback():
    import tempfile

    module = AnsibleModule(argument_spec={'options': {'required': True, 'type': 'dict', 'fallback': env_fallback,
                                                      'options': {'key1': {'required': True, 'aliases': ['alias1']}}}})
    os.environ['ANSIBLE_TEST_KEY1'] = 'env_value'
    os.environ['ANSIBLE_TEST_ALIAS1'] = 'env_alias_value'

    rc, out, err = module.run_command('echo "hello"')

    assert rc == 0
    assert out == 'hello'
    assert err == ''
    del os.environ['ANSIBLE_TEST_KEY1']
    del os.environ['ANSIBLE_TEST_ALIAS1']



# Generated at 2022-06-22 22:00:45.039863
# Unit test for function remove_values
def test_remove_values():
    assert remove_values('123456',['123','456']) == '***'
    assert remove_values('1234567',['123','456']) == '1234567'
    assert remove_values('1234567',['123']) == '4567'
    assert remove_values('1234567',['123','678']) == '4567'
    assert remove_values('1234567',['123','678']) == '4567'
    assert remove_values('1234567',['1234','678']) == '567'
    assert remove_values(['123456'],['123','456']) == ['***']
    assert remove_values(['123456','123456'],['123','456']) == ['***','***']

# Generated at 2022-06-22 22:00:52.805237
# Unit test for function sanitize_keys
def test_sanitize_keys():
    # Basic case: remove one no_log value
    no_log_values = ['secret']
    data = {'secret': 'value'}
    expected_data = {'xxx': 'value'}

    new_data = sanitize_keys(data, no_log_values)
    assert new_data == expected_data

    # Remove from dict nested inside another dict
    no_log_values = ['secret']
    data = {'key1': {'secret': 'value'}}
    expected_data = {'key1': {'xxx': 'value'}}

    new_data = sanitize_keys(data, no_log_values)
    assert new_data == expected_data

    # Remove from a deeply nested dict
    no_log_values = ['secret']

# Generated at 2022-06-22 22:01:04.016643
# Unit test for function remove_values

# Generated at 2022-06-22 22:01:11.621608
# Unit test for function sanitize_keys
def test_sanitize_keys():
    data = {
        'key1': 'value1',
        'key2': 'value2',
        'key3': {'subkey1': 'subvalue1', 'subkey2': 'subvalue2'},
        'key4': ['val1', 'val2'],
        'key5': ['val1', 'val2'],
    }
    no_log_values = set()
    no_log_values.add('value1')
    no_log_values.add('subvalue1')

    # Test no_log_values from dict
    new_value = sanitize_keys(data, no_log_values)

# Generated at 2022-06-22 22:01:23.378775
# Unit test for function sanitize_keys
def test_sanitize_keys():
    no_log_strings = ('pwd','password','ssh-pass','secret','autopass')

    test_case1 = {
        'public_key': 'my_key',
        'other_secret': 'my_secret',
        'password': 'pwd_pwd123',
        'ssh_secret': 'ssh-pass'
    }
    expected_test_case1 = {
        'public_key': 'my_key',
        'other_secret': 'my_secret',
        'pwd': 'pwd_pwd123',
        'ssh_pass': 'ssh-pass'
    }
