

# Generated at 2022-06-22 21:51:20.773826
# Unit test for function env_fallback
def test_env_fallback():
    # set an environment variable
    env_var = 'PYTHON_CALLABLE_ENV_FALLBACK'
    value = 'foo'
    os.environ[env_var] = value

    # call the tested function
    assert env_fallback(env_var) == value

    # cleanup
    del os.environ[env_var]


# Generated at 2022-06-22 21:51:27.588084
# Unit test for function env_fallback
def test_env_fallback():
    environ = dict(os.environ)
    if 'FOO' in environ:
        del os.environ['FOO']

    calls = []
    def my_exit(rv):
        calls.append(rv)


# Generated at 2022-06-22 21:51:36.412372
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys('foo', no_log_strings=['f']) == 'foo'
    assert sanitize_keys('foofoo', no_log_strings=['f']) == 'oo'
    assert sanitize_keys('foofoofoofoofoofoofoofoo', no_log_strings=['f']) == 'oooooooo'
    assert sanitize_keys('Foo Foo', no_log_strings=['f']) == 'Foo Foo'
    assert sanitize_keys(['foo', 'fofofoofoofoofoofoo', 'foofoofoo'], no_log_strings=['f']) == ['oo', 'oooooooooo', 'oooooooo']

# Generated at 2022-06-22 21:51:44.597141
# Unit test for function remove_values
def test_remove_values():
    from six import string_types
    from ansible.module_utils.six.moves import xrange
    from ansible.module_utils.six import binary_type, text_type
    from ansible.module_utils.common.collections import MutableSequence, MutableSet

    rvalue = remove_values('password',['password'])
    assert rvalue == 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'

    # Ensure that bytes strings aren't converted to Unicode.
    rvalue = remove_values(b'bytes_password',['bytes_password'])
    assert isinstance(rvalue, binary_type)
    assert rvalue == b'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'

    # Ensure that Unicode strings aren't converted to bytes.

# Generated at 2022-06-22 21:51:51.920489
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys({}, []) == {}
    assert sanitize_keys("", []) == ""
    assert sanitize_keys("", ['a', 'b']) == ""
    assert sanitize_keys(['', {}], ['a', 'b']) == ["", {}]
    assert sanitize_keys({'a': 'b', 'b': [{'c': 'b'}, None, 'c']}, ['a', 'b']) == {'a': 'b', 'b': [{'c': 'b'}, None, 'c']}

# Generated at 2022-06-22 21:52:01.341636
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'name': {'type': 'str', 'required': True, 'no_log': False, 'fallback': (env_fallback, ['NAME'])}
    }
    parameters = {}
    os.environ['NAME'] = 'foo'
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['name'] == 'foo'
    assert no_log_values == set()

    argument_spec['name']['no_log'] = True
    parameters = {}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['name'] == 'foo'
    assert no_log_values == {'foo'}

    argument_spec['name']['fallback'][-1] = ['NAME2']
    parameters = {}

# Generated at 2022-06-22 21:52:08.547102
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'param1': {'type': 'str', 'required': True, 'fallback': (env_fallback, ('ANSIBLE_PARAM1', 'ANSIBLE_PARAM'))}}
    parameters = {}
    no_log_values = set()

    # Verify fallback doesn't occur when no fallbacks are possible.
    result = set_fallbacks(argument_spec, parameters)
    assert len(result) == 0

    # Verify fallback doesn't occur when only invalid fallback is possible.
    parameters = {'param1': None}
    result = set_fallbacks(argument_spec, parameters)
    assert len(result) == 0

    # Verify fallback doesn't occur when fallback is disabled.

# Generated at 2022-06-22 21:52:14.938945
# Unit test for function remove_values
def test_remove_values():
    no_log_strings = []
    value = {
        'pets': ['dogs', 'cats'],
        'house': {
            'windows': ['north', 'south', 'east', 'west'],
            'rooms': ['kitchen', 'living room', 'bathroom', 'playroom'],
            'hiding_spots': ['under the stairs', 'inside a cabinet', 'in the closet', 'behind the couch']
        },
        'farm': {
            'animals': ['horses', 'cows', 'chickens', 'pigs'],
            'food': ['hay', 'grass', 'corn', 'slop'],
            'workers': ['Henry', 'George', 'Samson', 'Simon']
        }
    }
    new_value = remove_values(value, no_log_strings)

# Generated at 2022-06-22 21:52:16.066586
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('FOO_BAR_BAZ') == 'BAZ'


# Generated at 2022-06-22 21:52:24.231795
# Unit test for function sanitize_keys

# Generated at 2022-06-22 21:52:35.812978
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'y': {'type': 'int', 'default': 5}}
    parameters = {}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert no_log_values == set()
    assert parameters == {'y': 5}

    argument_spec = {'z': {'type': 'int', 'fallback': (env_fallback, 'Z')}}
    parameters = {}
    os.environ['Z'] = '5'
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert no_log_values == set()
    assert parameters == {'z': 5}
    del os.environ['Z']
    parameters = {}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert no_log_values

# Generated at 2022-06-22 21:52:44.379244
# Unit test for function remove_values

# Generated at 2022-06-22 21:52:53.036666
# Unit test for function set_fallbacks

# Generated at 2022-06-22 21:52:56.544352
# Unit test for function env_fallback
def test_env_fallback():
    assert 'HOME' in os.environ
    assert env_fallback('HOME') == os.environ['HOME']
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('FOOBAR')



# Generated at 2022-06-22 21:53:00.445505
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['FOO'] = 'foo'
    assert env_fallback('FOO', 'BAR') == 'foo'
    assert os.environ['FOO'] == 'foo'
    assert env_fallback('BAR', 'BAZ') is None



# Generated at 2022-06-22 21:53:09.790623
# Unit test for function sanitize_keys
def test_sanitize_keys():
    import json
    import copy

    # we build a data structure with a string object at the top level which contains a password
    # the structure is copied to a new data structure with that string replaced by the key of a
    # dictionary with the value of the string as the value of the dictionary
    # this ensures that if the removal logic traverses the data structure in the wrong order,
    # the password will not be removed.
    data = {
        'key1': 'value1',
        'key2': 'value2',
        'key3': {
            'subkey1': 'subvalue1',
            'subkey2': 'subvalue2'
        },
        'server_url': {
            'password': 'test_value'
        },
        'foo': 'bar'
    }
    password = data['server_url']['password']

# Generated at 2022-06-22 21:53:16.709392
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert set(set_fallbacks({'test_param': {'fallback': (env_fallback, 'env_var_name')}}, {'test_param': None})) == set(['env_var_name'])
    assert set(set_fallbacks({'test_param': {'no_log': True, 'fallback': (env_fallback, 'env_var_name')}}, {'test_param': None})) == set(['env_var_name'])
    assert set(set_fallbacks({'test_param': {'fallback': (env_fallback, 'env_var_name')}}, {})) == set([])

# Generated at 2022-06-22 21:53:26.642879
# Unit test for function set_fallbacks

# Generated at 2022-06-22 21:53:31.274432
# Unit test for function env_fallback
def test_env_fallback():
    """Unit test for function env_fallback"""
    os.environ['FOO'] = 'bar'
    assert env_fallback('FOO') == 'bar'
    assert env_fallback('FEDCBA') == 'FEDCBA'



# Generated at 2022-06-22 21:53:41.117357
# Unit test for function sanitize_keys
def test_sanitize_keys():
    some_dict = {'my_dict': {'one_key': 'one_value', 'no_log_value': 'my_secret', 'two_key': 'two_value'}, 'my_list': [{'one_key': 'one_value', 'no_log_value': 'my_secret', 'two_key': 'two_value'}]}
    no_log_values = {'my_secret'}
    result = sanitize_keys(some_dict, no_log_values)

# Generated at 2022-06-22 21:53:51.253039
# Unit test for function set_fallbacks

# Generated at 2022-06-22 21:54:02.536586
# Unit test for function remove_values
def test_remove_values():
    """Unit tests for function remove_values"""
    no_log_strings = ['password']
    # This is a simplistic case of a data structure containing
    # a single occurrence of the word 'password' in a plain text
    # string. The function should remove this word from the string
    # leaving the rest of the data structure untouched.
    test_data = {'password': 'hello world', 'foo': 'bar'}
    new_data = remove_values(test_data, no_log_strings)
    assert new_data['password'] == 'hello world'
    assert new_data['foo'] == 'bar'

    # This test case should remove the occurrence of the word
    # 'password' in the string. The word is in the key of the dictionary
    # inside the data structure. The key should be removed and the
    # dictionary elements should be renamed

# Generated at 2022-06-22 21:54:11.853662
# Unit test for function remove_values
def test_remove_values():
    """
    Unit test for function remove_values
    """
    no_log_strings = ['password123', 'secret123']
    test_data = {
        'test1' : {
            'test2' : [
                {
                    'test3' : 'a secret test',
                    'test4' : 'password123'
                },
                'secret123',
                'another secret'
            ],
            'test5' : 'not secret'
        },
        'a_secret_test' : 'a secret test',
        'secret_list' : ['password123', 'secret123']
    }

# Generated at 2022-06-22 21:54:19.638727
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ENVTEST'] = 'test123'

    assert env_fallback('ENVTEST') == 'test123'
    assert env_fallback('ENVTEST2', 'ENVTEST') == 'test123'
    assert env_fallback('ENVTEST2', 'ENVTEST3') == 'test123'

    try:
        env_fallback('ENVTEST2', 'ENVTEST3')
        raise AssertionError('env_fallback() should have raised AnsibleFallbackNotFound')
    except AnsibleFallbackNotFound:
        pass

    del os.environ['ENVTEST']



# Generated at 2022-06-22 21:54:28.291193
# Unit test for function set_fallbacks

# Generated at 2022-06-22 21:54:37.570608
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys({'name':'pankaj', 'password':'jinitiator'}, ['password'], ['password']) == {'name': 'pankaj', 'password': 'jinitiator'}
    assert sanitize_keys({'name':'pankaj', 'password':'jinitiator'}, ['password'], []) == {'name': 'pankaj', 'password': '***'}
    assert sanitize_keys({'name': 'pankaj'}, ['password']) == {'name': 'pankaj'}

# Generated at 2022-06-22 21:54:42.990804
# Unit test for function remove_values
def test_remove_values():
    # check list
    assert remove_values([1, 2, 3, 4], []) == [1, 2, 3, 4]
    assert remove_values(["a", "b", "c", "d", "1", "2", "3", "4"], []) == ["a", "b", "c", "d", "1", "2", "3", "4"]
    assert remove_values(["a", "b", "c", "d", "1", "2", "3", "4"], ["1", "2", "3", "4"]) == ["a", "b", "c", "d"]

# Generated at 2022-06-22 21:54:53.200933
# Unit test for function remove_values
def test_remove_values():
    # pylint: disable=protected-access
    from ansible.module_utils.basic import AnsibleFallbackNotFound

    # Test list removal
    list_value = ['a', 'b', 'c', 'd']
    assert remove_values(list_value, ['b']) == ['a', 'c', 'd']
    # Test tuple removal
    tuple_value = (1, 2, 3, 4)
    assert remove_values(tuple_value, [2]) == (1, 3, 4)
    # Test set removal
    set_value = {'a', 'b', 'c', 'd'}
    assert remove_values(set_value, ['a']) == {'b', 'c', 'd'}

    # Test nested list removal

# Generated at 2022-06-22 21:55:03.577096
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'name': {'type': 'str', 'required': True},
                     'state': {'type': 'str', 'required': True, 'choices': ['present', 'absent']},
                     'password': {'type': 'str', 'required': True, 'fallback': (env_fallback, 'MY_PASSWORD_DEFAULT')}}
    parameters = {}
    _set_defaults(argument_spec, parameters)
    assert 'password' in parameters

    parameters = {}
    os.environ["MY_PASSWORD_DEFAULT"] = "helloworld"
    _set_defaults(argument_spec, parameters)
    assert 'password' in parameters
    assert parameters.get('password') == 'helloworld'
    del os.environ["MY_PASSWORD_DEFAULT"]

    no

# Generated at 2022-06-22 21:55:06.883109
# Unit test for function remove_values
def test_remove_values():
    d1 = [{'foo': 'bar', 'baz':'qux', 'corge': 'grault'}]
    d2 = [{'foo': 'bar', 'baz':'qux', 'corge': 'grault'}]

    assert(d1 == d2)

    remove_values(d1, ['grault'])

    assert(d1 == [{'foo': 'bar', 'baz': 'qux', 'corge': '***'}])


# Generated at 2022-06-22 21:55:17.495554
# Unit test for function sanitize_keys
def test_sanitize_keys():
    '''Test unit for submethod sanitize_keys'''
    from collections import MutableSet
    from collections import MutableSequence
    dict_obj = dict()
    dict_obj['secret_key'] = 'password'
    dict_obj['username'] = 'abcd'
    dict_obj['dict_obj'] = dict()
    dict_obj['dict_obj']['username'] = 'abcd'
    dict_obj['dict_obj']['password'] = 'password'
    dict_obj['list_obj'] = list()
    dict_obj['list_obj'].append(dict())
    dict_obj['list_obj'][0]['username'] = 'abcd'
    dict_obj['list_obj'][0]['password'] = 'password'
    dict_obj['tuple_obj'] = tuple

# Generated at 2022-06-22 21:55:24.892182
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'foo'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'foo'
    try:
        env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_FOUND')
        assert False, 'test should fail'
    except AnsibleFallbackNotFound:
        pass
    # Restore
    del os.environ['ANSIBLE_TEST_ENV_FALLBACK']



# Generated at 2022-06-22 21:55:35.279695
# Unit test for function remove_values
def test_remove_values():
    assert remove_values('mypassword', ['mypassword']) == 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'
    assert remove_values(['mypassword'], ['mypassword']) == ['VALUE_SPECIFIED_IN_NO_LOG_PARAMETER']
    assert remove_values({'foo': 'bar', 'secret': 'mypassword'}, ['mypassword']) == {'foo': 'bar', 'secret': 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'}

    # Test that a complex data structure is processed without maximum recursion depth being hit
    orig = []
    for _ in range(300):
        orig.append({'foo': 'bar', 'secret': 'mypassword'})

# Generated at 2022-06-22 21:55:40.694411
# Unit test for function set_fallbacks
def test_set_fallbacks():
    no_log_values = set()
    # TODO: add test cases
    parameter = {}
    argument_spec = {}
    no_log_values = set_fallbacks(argument_spec, parameter)
    assert no_log_values == set()
    argument_spec = {'test': {'fallback': 'test_value'}}
    parameter = {}
    no_log_values = set_fallbacks(argument_spec, parameter)
    assert no_log_values == set()
    argument_spec = {'test': {'fallback': 'test_value', 'no_log': True}}
    parameter = {}
    no_log_values = set_fallbacks(argument_spec, parameter)
    assert no_log_values == set(['test_value'])

# Generated at 2022-06-22 21:55:52.967277
# Unit test for function env_fallback
def test_env_fallback():
    from os import environ as os_environ
    from ansible.module_utils.six import iteritems
    from unittest import mock
    from ansible.module_utils._text import to_text
    from six import iterkeys

    for env_value in [u"value", "value", [u"value", 42], [b"value", 42], [u"value", b"value"], {u"key": u"value"}, {u"key": 42}, {b"key": b"value"}, {u"key": b"value"}]:
        mock_env = {}
        mock_env[u'ANSIBLE_TEST_VALUE'] = env_value
        with mock.patch('os.environ', mock_env):
            assert env_fallback('ANSIBLE_TEST_VALUE') == env_value

# Generated at 2022-06-22 21:56:01.981876
# Unit test for function sanitize_keys
def test_sanitize_keys():
    no_log_values = frozenset(['secret1', 'secret2'])
    args = {'test_arg': "password is {{ lookup('env', 'secret1') }}"}
    result = sanitize_keys(args, no_log_values)
    assert result == {u'test_arg': u'password is NOT_LOGGING_PARAMETER'}
    args = {'test_arg': "password is {{ lookup('env', 'secret1') }}"}
    args['_ansible_ignore_errors'] = True
    result = sanitize_keys(args, no_log_values)
    assert result == {u'test_arg': u'password is NOT_LOGGING_PARAMETER', '_ansible_ignore_errors': True}


# Generated at 2022-06-22 21:56:14.230210
# Unit test for function env_fallback
def test_env_fallback():
    '''
    :return:
    '''
    os.environ['ANSIBLE_TEST_VAR1'] = '1234'
    assert env_fallback('ANSIBLE_TEST_VAR1') == '1234'
    os.environ['ANSIBLE_TEST_VAR2'] = '5678'
    assert env_fallback('ANSIBLE_TEST_VAR1', 'ANSIBLE_TEST_VAR2') == '1234'
    os.environ['ANSIBLE_TEST_VAR1'] = ''
    assert env_fallback('ANSIBLE_TEST_VAR1', 'ANSIBLE_TEST_VAR2') == '5678'
    del os.environ['ANSIBLE_TEST_VAR1']

# Generated at 2022-06-22 21:56:24.885647
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Test where parameter is not in parameters and fallback value is None
    spec = dict(param1=dict(default=False, fallback=(None,)))
    parameters = {}
    no_log_values = set()
    no_log_values.update(set_fallbacks(spec, parameters))
    assert 'param1' not in parameters
    assert no_log_values == set()

    # Test where parameter is not in parameters and fallback value is not None
    spec = dict(param2=dict(default=False, fallback=(env_fallback, 'ANSIBLE_TEST_FALLBACK_PARAMETER_NO_LOG')))
    parameters = {}
    no_log_values = set()
    no_log_values.update(set_fallbacks(spec, parameters))
    assert 'param2' in parameters
    assert parameters

# Generated at 2022-06-22 21:56:35.888164
# Unit test for function set_fallbacks
def test_set_fallbacks():
    data = {
        'name': 'Bob',
        'age': '25',
        'password': 'pass123',
        'sub_data': [{
            'sub_key': 'sub_value',
        }],
    }
    spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int', 'fallback': (int, ['AGE'])},
        'password': {'type': 'str', 'no_log': True},
        'sub_data': {'type': 'list', 'elements': 'dict', 'options': {
            'sub_key': {'type': 'str'},
        }},
    }
    os.environ['AGE'] = '30'

# Generated at 2022-06-22 21:56:44.253207
# Unit test for function set_fallbacks
def test_set_fallbacks():
    import os
    os.environ['ANSIBLE_ANYTHING'] = 'foo'
    os.environ['ANSIBLE_SOMETHING'] = 'bar'
    os.environ['ANSIBLE_SOMETIMES_BAR'] = 'bar'


# Generated at 2022-06-22 21:56:48.331404
# Unit test for function env_fallback
def test_env_fallback():
    os.environ["THIS_EXISTS"] = "it does"
    assert env_fallback('THIS_EXISTS', 'THIS_DOES_NOT') == "it does"



# Generated at 2022-06-22 21:56:58.564651
# Unit test for function sanitize_keys
def test_sanitize_keys():

    # remove_values and sanitize_keys handle containers but not non-container objects
    # Verify that non-container objects are returned unmodified
    obj = object()
    assert sanitize_keys(obj, 'password') == obj

    # Handle the case where a password string is included in a key
    data = {'api_key': 'password'}
    assert sanitize_keys(data, 'password') == {'api_key': u'********'}

    # Verify that the length of the dictionary is preserved even if the value
    # of a key is a password string.
    data = {'api_key': 'password', 'secret': 'toomanysecrets'}
    assert len(sanitize_keys(data, 'password')) == 2

    # Verify that keys and values can be both password strings

# Generated at 2022-06-22 21:57:00.724113
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['FOO'] = 'bar'
    assert env_fallback('FOO') == 'bar'



# Generated at 2022-06-22 21:57:12.441755
# Unit test for function set_fallbacks
def test_set_fallbacks():
    params = {'name': 'value'}
    argument_spec = {'name': {'type': 'str'},
                     'password': {'type': 'str', 'fallback': (env_fallback, 'ANSIBLE_PASSWORD')}}
    no_log_values = set_fallbacks(argument_spec, params)

    assert 'password' in params
    assert params['password'] == 'ANSIBLE_PASSWORD'
    assert no_log_values == set()

    os.environ['ANSIBLE_PASSWORD'] = 'SECRET'
    params = {'name': 'value'}
    no_log_values = set_fallbacks(argument_spec, params)

    assert 'password' in params
    assert params['password'] == 'SECRET'
    assert no_log_values == set()

    del os

# Generated at 2022-06-22 21:57:24.895890
# Unit test for function remove_values
def test_remove_values():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    test_dict = {'foo': {'bar': [1, 2, {'baz': 'spam'}]}}
    no_log_strings = ['spam']
    sanitized_dict = remove_values(test_dict, no_log_strings)
    # Sanitized dict should be a deep copy of test_dict
    assert test_dict == sanitized_dict
    assert test_dict is not sanitized_dict
    # The value of spam has been replaced by a string
    assert sanitized_dict['foo']['bar'][2]['baz'] == AnsibleUnsafeText('VALUE_SPECIFIED_IN_NO_LOG_PARAMETER')
    # The test_dict has not been modified

# Generated at 2022-06-22 21:57:33.352100
# Unit test for function remove_values
def test_remove_values():
    complex_data = {
        'foo': 'foo',
        'bar': {
            'foo': 'foo',
            'bar': ['foo', ['foo', 'bar', 'baz', {'foo': ['foo', 'bar']}]],
            'baz': ['some', 'secret', 'data', {'foo': ['foo', ['some', 'secret', 'data']]}]
        }
    }

    basic_data = {
        'foo': 'foo',
        'bar': 'bar',
        'baz': 'baz',
        'secret': 'some secret data'
    }


# Generated at 2022-06-22 21:57:44.297583
# Unit test for function remove_values
def test_remove_values():
    from ansible.utils import remove_values
    from collections import Mapping, Sequence, Set

    def _seq(val):
        if isinstance(val, (Mapping, Sequence, Set)):
            val = list(val)
        return val


# Generated at 2022-06-22 21:57:56.040246
# Unit test for function remove_values
def test_remove_values():
    assert 'value1' == remove_values('value1', ['value1'])
    assert '' == remove_values('value1', ['value1', 'value2'])
    # Test nested data structures
    assert 'value1' == remove_values(dict(key='value1'), ['value1'])
    assert 'value1' == remove_values(dict(key=('value1', 'value2')), ['value1', 'value2'])

    # Test that we remove all appearances of no_log_strings
    assert 'value1' == remove_values('value1value2value1', ['value1'])

    # Test the use of deferred_removals
    assert 'value1' == remove_values([[['value1', 'value2']]], ['value1', 'value2'])



# Generated at 2022-06-22 21:58:06.158966
# Unit test for function set_fallbacks
def test_set_fallbacks():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    os.environ['HOME'] = '/home/foo'
    os.environ['USER'] = 'foo'
    os.environ['PASS'] = '123'
    os.environ['KEY'] = 'ssh-rsa'
    os.environ['ID'] = 'jdoe'
    os.environ['PATH'] = '/bin:/usr/bin'

# Generated at 2022-06-22 21:58:16.885004
# Unit test for function remove_values
def test_remove_values():
    """Test for function remove_values"""
    # Test for remove_values

# Generated at 2022-06-22 21:58:26.471210
# Unit test for function sanitize_keys
def test_sanitize_keys():

    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.common._collections_compat import MutableSequence
    from ansible.module_utils.common._collections_compat import MutableSet

    test_data = {
        'foo': 'bar',
        'bar': [
            {'foo': 'bar'},
            'baz',
        ],
        'baz': {
            'foo': 'bar',
            'bar': 'baz',
        },
    }


# Generated at 2022-06-22 21:58:37.932933
# Unit test for function sanitize_keys
def test_sanitize_keys():
    data = [{'1.1.1.1': 'secret text'}, {'192.168.1.1': 'more secret text'}]
    expected = [{'1_1_1_1': 'secret text'}, {'192_168_1_1': 'more secret text'}]
    actual = sanitize_keys(data, [])
    assert expected == actual

    data = [{'1.1.1.1': 'secret text'}, {'192.168.1.1': 'more secret text'}]
    expected = [{'1.1.1.1': 'secret text'}, {'192.168.1.1': 'more secret text'}]
    actual = sanitize_keys(data, [], ignore_keys={'1.1.1.1'})
    assert expected

# Generated at 2022-06-22 21:58:48.358622
# Unit test for function sanitize_keys
def test_sanitize_keys():
    obj = {
        'foo': 'bar',
        'baz': {
            'foo': 'bar',
            'bar': ['a', 'b', 'c'],
            'baz': ['a', 'b', 'c']
        }
    }
    # keys, no_log_strings, ignore_keys, deferred_removals
    assert 'foo' == _sanitize_keys_conditions('foo', 'foo', None)
    assert 'bar' == _sanitize_keys_conditions('bar', 'foo', None)
    assert 'foo' == _sanitize_keys_conditions('foo', 'foo', set(['foo']))
    assert 'bar' == _sanitize_keys_conditions('bar', 'foo', set(['foo']))

# Generated at 2022-06-22 21:58:53.807261
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_FOO'] = 'bar'
    assert env_fallback('ANSIBLE_TEST_FOO') == 'bar'
    try:
        env_fallback('ANSIBLE_TEST_BAR')
    except AnsibleFallbackNotFound:
        pass
    else:
        assert False, "env_fallback should raise AnsibleFallbackNotFound exception when no key is found"



# Generated at 2022-06-22 21:59:04.096493
# Unit test for function env_fallback
def test_env_fallback():
    """Unit test for env_fallback"""
    from ansible.module_utils.six import PY3
    environ = os.environ

# Generated at 2022-06-22 21:59:15.756249
# Unit test for function set_fallbacks
def test_set_fallbacks():
    import os
    from types import ModuleType
    from tempfile import mkstemp
    from shutil import move


# Generated at 2022-06-22 21:59:25.192598
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'foo': {'type': 'str', 'fallback': (env_fallback, ('FOO', ))}
    }

    os.environ['FOO'] = 'bar'
    parameters = {}
    import datetime, sys
    startTime = datetime.datetime.now()
    result = set_fallbacks(argument_spec, parameters)
    runTime = datetime.datetime.now() - startTime
    print(runTime)
    print(sys.version_info[0])

    assert parameters['foo'] == 'bar'
    assert len(result) == 1
    assert 'bar' in result

# Generated at 2022-06-22 21:59:36.034798
# Unit test for function remove_values
def test_remove_values():
    # test removing values from a simple data structure
    data = {
        'string1': 'secret value 1',
        'string2': 'secret value 2',
        'string3': 'secret value 3',
        'string4': 'secret value 4',
        'string5': 'secret value 5',
        'list1': ['secret', 'value', '1'],
        'list2': ['secret', 'value', '2'],
        'list3': ['secret', 'value', '3'],
        'list4': ['secret', 'value', '4'],
        'list5': ['secret', 'value', '5'],
        'dict1': {
            'secret': 'value 1',
            'more_secret': 'value 2',
            'this_is_not_secret': 'value 3',
        }
    }


# Generated at 2022-06-22 21:59:45.395121
# Unit test for function remove_values
def test_remove_values():
    from . import get_connection_type

    import pytest
    from types import GeneratorType

    class NoLogType(object):
        """A type we will hand to the module to test no_log.

        It has a few special methods for validation.
        """
        def __init__(self, no_log=False):
            self.no_log = no_log

        def __eq__(self, other):
            if self.no_log:
                assert other.no_log, '__eq__ called on no_log object, but other object is not no_log'
            return object.__eq__(self, other)

        def __str__(self):
            assert self.no_log, 'str called on no_log object'
            return 'NoLogType instance'

        def __repr__(self):
            assert self

# Generated at 2022-06-22 21:59:56.013282
# Unit test for function remove_values
def test_remove_values():
    assert remove_values({}, ('secret')) == {}
    assert remove_values(['s3cret'], ('secret',)) == ['s3cret']
    assert remove_values({'clear_text': 'secret', 'clear': 'not a secret', 'lists': ['secret', 'not secret'], 'dicts': {'secret': 'blah'}}, ('secret',)) == \
        {'clear_text': 'secret', 'clear': 'not a secret', 'lists': ['secret', 'not secret'], 'dicts': {'secret': 'blah'}}

# Generated at 2022-06-22 22:00:03.893365
# Unit test for function remove_values
def test_remove_values():
    # all test failures are due to a bug, should get a TypeError
    # can not use assertRaises(TypeError) because it is a context manager,
    # which can not catch TypeError raised in a recursive coroutine
    # the generic exception is not used to avoid catching bugs in test code
    class TestException(Exception):
        pass

    # the test list is a list of tuples of the form (obj, no_log_strings, expected_output)

# Generated at 2022-06-22 22:00:11.059362
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['TEST_ENV_FALLBACK'] = 'TEST_ENV_FALLBACK_RESULT'
    assert env_fallback('TEST_ENV_FALLBACK') == 'TEST_ENV_FALLBACK_RESULT'
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('TEST_ENV_NO_SUCH_VARIABLE')
    del os.environ['TEST_ENV_FALLBACK']

# Generated at 2022-06-22 22:00:23.406481
# Unit test for function remove_values
def test_remove_values():
    test_data_1 = {'a': 'test', 'b': ['test', 1, 2, 3], 'c': [1, 2, 3, {'test': 'test', 'test2': 'test2'}], \
                   'd': {'a': 'test', 'b': {'test': 'test', 'test2': 'test2'}}}
    test_data_2 = ['test', 1, 2, {'test': 'test', 'test2': 'test2'}]
    test_data_3 = ['test', ['test', {'test': 'test', 'test2': 'test2'}]]

# Generated at 2022-06-22 22:00:34.425145
# Unit test for function set_fallbacks
def test_set_fallbacks():
    args = dict(
        test_arg1 = dict(fallback=(env_fallback, 'TEST_ARG1')),
        test_arg2 = dict(fallback=(env_fallback, 'TEST_ARG2')),
        test_arg3 = dict(fallback=(env_fallback, 'TEST_ARG3')),
        test_arg4 = dict(fallback=(env_fallback, 'TEST_ARG4')),
        test_arg5 = dict(fallback=(env_fallback, 'TEST_ARG5')),
    )

    env_vars = {
        'TEST_ARG1': 'env_test_arg1',
        'TEST_ARG4': '"env_test_arg4"',
        'TEST_ARG5': True,
    }

# Generated at 2022-06-22 22:00:46.030187
# Unit test for function sanitize_keys
def test_sanitize_keys():
    no_log_strings = ['password', 'secret', 'private', 'passwd']
    assert 'type' == sanitize_keys({'type': 'password'}, no_log_strings)
    assert {'type': 'password'} == sanitize_keys({'type': 'password'}, no_log_strings, ignore_keys=['type'])
    assert 'type' == sanitize_keys({'type': 'password'}, no_log_strings, ignore_keys=['type'])
    assert {'type': 'password', 'passwd': 'password'} == sanitize_keys({'type': 'password', 'passwd': 'password'}, no_log_strings)

# Generated at 2022-06-22 22:00:57.829370
# Unit test for function set_fallbacks
def test_set_fallbacks():
    args = {'imap_pass': 'pass', 'remote_user': 'user'}

# Generated at 2022-06-22 22:01:08.618884
# Unit test for function set_fallbacks
def test_set_fallbacks():
    arg_spec = {'param': {'type': 'str', 'no_log': True, 'fallback': (env_fallback, 'ENV_VALUE')}}
    parameters = {}
    assert os.environ.get('ENV_VALUE') is None
    assert set_fallbacks(arg_spec, parameters) == set()
    assert parameters == {}

    os.environ['ENV_VALUE'] = 'foo'
    assert set_fallbacks(arg_spec, parameters) == {'foo'}
    assert parameters == {'param': 'foo'}

    del os.environ['ENV_VALUE']

    arg_spec = {'param': {'type': 'str', 'no_log': True, 'fallback': (env_fallback, 'ENV_VALUE_1', 'ENV_VALUE_2')}}


# Generated at 2022-06-22 22:01:21.263526
# Unit test for function sanitize_keys
def test_sanitize_keys():
    from collections import namedtuple

    sanitize_keys.no_log_strings = ['foo', 'bar']

    data = OrderedDict()
    data['foo'] = 1
    data['bar'] = 2

    nl_list = [1]
    nl_list.append(2)
    data['nl_list'] = nl_list

    nl_tuple = (1,)
    nl_tuple += (2,)
    data['nl_tuple'] = nl_tuple

    nl_dict = {'foo': 1}
    nl_dict['bar'] = 2
    data['nl_dict'] = nl_dict

    nl_set = set([1])
    nl_set.add(2)
    data['nl_set'] = nl_set

    nl