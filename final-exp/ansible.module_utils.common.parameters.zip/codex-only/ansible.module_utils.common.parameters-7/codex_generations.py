

# Generated at 2022-06-22 21:51:23.665118
# Unit test for function remove_values
def test_remove_values():
    assert remove_values('string', []) == 'string'
    assert remove_values('string', ['secret']) == 'string'
    assert remove_values('string', ['str']) == 'ing'
    assert remove_values('secret', ['secret']) == '**********'
    assert remove_values(None, ['secret']) is None
    assert remove_values('secret', [None]) == 'secret'

    # Test lists
    assert remove_values(['string', 'secret'], ['secret']) == ['string', '**********']
    assert remove_values(['string', 'secret'], ['secret', '']) == ['string', '**********']
    assert remove_values(['string', 'secret'], ['str']) == ['ing', 'ecret']

# Generated at 2022-06-22 21:51:29.790216
# Unit test for function sanitize_keys
def test_sanitize_keys():
    no_log_strings = [b'SECRET']
    data = {
        'ANOTHER': 'MYDATA',
        'SECRETDATA': 'NOTSECRET',
        '_ansible_SECRETDATA': 'SECRET'
    }
    sanitized_data = sanitize_keys(data, no_log_strings)
    assert sanitized_data == {'ANOTHER': 'MYDATA'}

    no_log_strings = [b'SECRET']
    data = [
        'SECRETDATA',
        {
            'ANSIBLE_SECRETDATA': 'SECRET'
        }
    ]
    sanitized_data = sanitize_keys(data, no_log_strings)

# Generated at 2022-06-22 21:51:38.889370
# Unit test for function set_fallbacks
def test_set_fallbacks():
    params = {}
    argument_spec = {
        'd': {'type': 'path', 'fallback': (env_fallback, 'VAULT_PASSWORD_FILE')},
        'e': {'type': 'path', 'fallback': (fallback_local, 'd')}
    }
    assert set_fallbacks(argument_spec, params) == set()
    expected = {'d': 'a', 'e': 'b'}
    assert params == expected
    params = {}

# Generated at 2022-06-22 21:51:46.130355
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['FOO'] = 'bar'
    os.environ['BAZ'] = 'qux'

    assert env_fallback('FOO') == 'bar'
    assert env_fallback('FOO', 'BAZ') == 'bar'
    raises(AnsibleFallbackNotFound, env_fallback, 'missing')
    raises(AnsibleFallbackNotFound, env_fallback, '')
    raises(AnsibleFallbackNotFound, env_fallback, 'foo', 'bar')

    del os.environ['FOO']
    del os.environ['BAZ']
# end unit test


# Generated at 2022-06-22 21:51:52.551146
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['TEST_FOO_BAR_FOO'] = 'foo'
    assert env_fallback('TEST_FOO_BAR_FOO') == 'foo'



# Generated at 2022-06-22 21:51:56.462485
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['arg'] = 'value'
    assert env_fallback('arg') == 'value'
    assert env_fallback('arg1', 'arg') == 'value'
    assert env_fallback('arg1', 'arg2') == 'arg1'
    os.environ.clear()



# Generated at 2022-06-22 21:52:00.566507
# Unit test for function set_fallbacks
def test_set_fallbacks():
    params = {'foo': 'bar'}
    spec = {'bar':{'type': 'str',
                   'fallback': [env_fallback, 'BAR']}}
    no_log_values = set_fallbacks(spec,params)
    assert params['bar'] == os.environ['BAR']
    assert no_log_values == set()


# Generated at 2022-06-22 21:52:08.941858
# Unit test for function sanitize_keys
def test_sanitize_keys():

    class Container(object):
        def __init__(self, data):
            self.data = data

        def __str__(self):
            return '<Container({0})>'.format(self.data)

        def _log_private_value(self):
            return True

        def _private_value(self):
            return self.data

        def _private_value_no_log(self):
            return self.data

        def _log_private_value_no_log(self):
            return True

        def _private_data(self):
            return self

    class Sequence(object):
        def __init__(self, data):
            self.data = data

        def __iter__(self):
            return iter(self.data)

        def __len__(self):
            return len(self.data)

       

# Generated at 2022-06-22 21:52:11.500782
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_FOO'] = 'bar'
    assert env_fallback('ANSIBLE_FOO') == 'bar'
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('ANSIBLE_BAR')


# Generated at 2022-06-22 21:52:13.806498
# Unit test for function env_fallback
def test_env_fallback():
    fallback = env_fallback('FOO')
    assert fallback == os.environ['FOO']
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('BAR')


# Generated at 2022-06-22 21:52:23.183854
# Unit test for function set_fallbacks
def test_set_fallbacks():
    '''Test set_fallbacks function'''
    
    # Assert that when a fallback is found in os.environ, it will be added to the parameters
    argument_spec = {'test_param': {'fallback': (env_fallback, "TEST_PARAM_ENV_VAR")}}
    parameters = {}
    assert 'TEST_PARAM_ENV_VAR' not in parameters
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['test_param'] == 'TEST_PARAM_ENV_VAR'
    assert 'TEST_PARAM_ENV_VAR' in no_log_values

    # Assert that when a fallback is found in os.environ, it will be added to the parameters
    # and the no_log value is set

# Generated at 2022-06-22 21:52:24.828849
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys("user_password", set("password")) == "user_password"



# Generated at 2022-06-22 21:52:36.345141
# Unit test for function set_fallbacks
def test_set_fallbacks():
    #Ensure that set_fallbacks works for all fallbacks, including env var fallback
    #Save env var, set it, run test
    old_env = dict(os.environ)
    os.environ['ANSIBLE_TEST_VALUE'] = 'passed'

# Generated at 2022-06-22 21:52:43.294756
# Unit test for function set_fallbacks
def test_set_fallbacks():
    params = {'param1': 'value1'}
    arg_spec = {
        'param1': {
            'type': 'str',
            'default': 'value2'
        },
        'param2': {
            'type': 'str',
            'fallback': (env_fallback, 'TEST_PARAM')
        }
    }
    os.environ['TEST_PARAM'] = 'value3'

    expected_params = {'param1': 'value1', 'param2': 'value3'}
    assert set_fallbacks(arg_spec, params) == set()
    assert params == expected_params

# Generated at 2022-06-22 21:52:49.414337
# Unit test for function remove_values
def test_remove_values():
    from itertools import chain

    # These are the values that we expect to be removed by the remove_values
    # function.
    # NOTE: We are using frozenset to avoid ordering issues.

# Generated at 2022-06-22 21:52:55.061541
# Unit test for function set_fallbacks
def test_set_fallbacks():
    spec = {
        'test': {
            'type': 'str',
            'fallback': (env_fallback, ['ANSIBLE_TEST_FALLBACK']),
            'no_log': True
        }
    }

    parameters = {}
    os.environ['ANSIBLE_TEST_FALLBACK'] = 'fallback_value'
    no_log_values = set_fallbacks(spec, parameters)
    os.environ.pop('ANSIBLE_TEST_FALLBACK')
    assert parameters['test'] == 'fallback_value'
    assert 'fallback_value' in no_log_values
    assert len(no_log_values) == 1



# Generated at 2022-06-22 21:53:01.465019
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['TEST_ENV'] = 'test'
    return_value = env_fallback('TEST_ENV')
    os.environ.pop('TEST_ENV')
    assert return_value == 'test'
    return_value = None
    try:
        env_fallback('UNKNOWN_ENV')
    except AnsibleFallbackNotFound:
        return_value = True
    assert return_value is True



# Generated at 2022-06-22 21:53:10.600522
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # case 1: 'fallback' not in argument_spec[param]
    params = {'param1': 'param1_value', 'param2': 'param2_value'}
    argument_spec = {'param1': {'type': 'str', 'no_log': True}, 'param2': {'type': 'str', 'no_log': False}}
    no_log_values = set_fallbacks(argument_spec, params)
    assert no_log_values == set()

    # case 2: 'fallback' in argument_spec[param] but fallback_value is empty;
    #         param is not in parameters
    params = {'param1': 'param1_value', 'param2': 'param2_value'}

# Generated at 2022-06-22 21:53:18.413720
# Unit test for function env_fallback
def test_env_fallback():
    # Let env_fallback accept arbitrary list of arguments
    assert env_fallback('test_env_fallback') is not None
    os.environ['test_env_fallback'] = 'Test environment variable'
    assert env_fallback('test_env_fallback') == os.environ['test_env_fallback']
    del os.environ['test_env_fallback']
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('test')

# Generated at 2022-06-22 21:53:30.025124
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        param1=dict(fallback=(env_fallback, 'PARAM1')),
        param2=dict(fallback=(env_fallback, ('PARAM2', 'FALLBACK_PARAM2'), dict(fail_on_missing=False, use_default=True, no_log=True)), type='str'),
        param3=dict(fallback=(env_fallback, 'PARAM3', dict(fail_on_missing=False, use_default=True)), default='bad default'),
    )
    parameters = dict(param1='test param1')
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert no_log_values == set()
    assert parameters == dict(param1='test param1')

    # No values set and no env vars set:
   

# Generated at 2022-06-22 21:53:40.187417
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # test multiple fallbacks
    argument_spec = dict(
        a=dict(type='str', fallback=(str, '${a}', env_fallback, '${b}', 'c')),
        b=dict(type='str', fallback=(str, '${b}', env_fallback, 'd')),
    )
    parameters = dict()
    os.environ['a'] = 'x'
    os.environ['b'] = 'y'
    set_fallbacks(argument_spec, parameters)
    assert parameters['a'] == 'x'
    assert parameters['b'] == 'y'
    # test dict fallback

# Generated at 2022-06-22 21:53:50.747241
# Unit test for function set_fallbacks
def test_set_fallbacks():
    params = {}
    arg_spec = {}
    no_log_val = set()
    assert set_fallbacks(arg_spec, params) == no_log_val

    arg_spec = {'param1': {'type': 'str'}}
    # no_log is False per default, so the return value should not contain any item
    params = {'param1': 'value1'}
    assert set_fallbacks(arg_spec, params) == no_log_val

    # If no_log is set to True, then the return value should contain a value
    arg_spec = {'param1': {'type': 'str', 'no_log': True}}
    params = {'param1': 'value1'}
    no_log_val.add('value1')

# Generated at 2022-06-22 21:54:00.270128
# Unit test for function set_fallbacks

# Generated at 2022-06-22 21:54:05.743941
# Unit test for function remove_values
def test_remove_values():
    data = {"password":"passw0rd"}
    data_expected = {"password":"VALUE_SPECIFIED_IN_NO_LOG_PARAMETER"}
    data_sanitized = remove_values(data,["passw0rd"])
    assert data_sanitized == data_expected

# Generated at 2022-06-22 21:54:14.569706
# Unit test for function env_fallback
def test_env_fallback():
    def os_environ():
        return {'foo': 'bar'}

    orig_os_environ = os.environ
    try:
        os.environ = os_environ
        result = env_fallback('foo')
        assert result == 'bar'
        result = env_fallback('bar')
        assert isinstance(result, AnsibleFallbackNotFound)
    finally:
        os.environ = orig_os_environ



# Generated at 2022-06-22 21:54:22.244081
# Unit test for function remove_values

# Generated at 2022-06-22 21:54:33.227940
# Unit test for function remove_values
def test_remove_values():
    assert remove_values({'a': {},
                          'b': {'c': 'd'}}, []) == {'a': {}, 'b': {'c': 'd'}}

    assert remove_values({'a': {'b': 'c'},
                          'd': {'e': 'f'}}, ['c']) == {'a': {'b': '<value omitted>'}, 'd': {'e': 'f'}}

    assert remove_values({'a': {'b': 'c'},
                          'd': {'e': 'f'}}, ['e']) == {'a': {'b': 'c'}, 'd': {'e': '<value omitted>'}}


# Generated at 2022-06-22 21:54:40.682878
# Unit test for function remove_values
def test_remove_values():
    if not HAS_PYTHON26:
        raise SkipTest
    # verify that ascii-encoded unicode strings are handled properly
    data = u'this is a unicode string, son'
    assert remove_values(data, [data]) == u'This is a unicode string, son'
    data = u"this contains a 'single quote'"
    assert remove_values(data, [data]) == u"This contains a 'single quote'"
    data = u"this contains a 'single quote' and a \"double quote\""
    assert remove_values(data, [data]) == u"This contains a 'single quote' and a \"double quote\""
    data = u"this contains a 'single quote', a \"double quote\" and a \\\" backslash"

# Generated at 2022-06-22 21:54:51.127691
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ENV_VAR'] = 'env_var'
    assert env_fallback('ENV_VAR') == 'env_var'
    os.environ['ENV_VAR'] = "it's back to the 'future'"
    assert env_fallback('ENV_VAR') == "it's back to the 'future'"
    os.environ['ENV_VAR'] = 'uńıc0dé\u2032'
    assert env_fallback('ENV_VAR') == u'uńıc0dé⁂'
    os.environ['ENV_VAR'] = 'uńıc0dé\u2032'
    assert env_fallback('ENV_VAR') == 'uńıc0dé\u2032'


# Generated at 2022-06-22 21:55:02.236354
# Unit test for function env_fallback
def test_env_fallback():
    with patch.dict(os.environ, {'TEST_FOO': 'FOO'}):
        assert env_fallback('TEST_FOO') == 'FOO'
        assert env_fallback('TEST_BAR', 'TEST_FOO') == 'FOO'
        assert 'TEST_BAR' not in os.environ

    with patch.dict(os.environ, {'TEST_BAR': 'BAR'}):
        assert env_fallback('TEST_FOO', 'TEST_BAR') == 'BAR'
        assert env_fallback('TEST_FOO') == 'BAR'
        assert env_fallback('TEST_BAR', 'TEST_FOO') == 'BAR'
        assert 'TEST_FOO' not in os.environ

# Generated at 2022-06-22 21:55:11.592645
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV'] = 'test_env'
    assert env_fallback('ANSIBLE_TEST_ENV') == 'test_env'
    del os.environ['ANSIBLE_TEST_ENV']
    try:
        env_fallback('ANSIBLE_TEST_ENV')
        assert False
    except AnsibleFallbackNotFound:
        assert True
    try:
        env_fallback('ANSIBLE_TEST_ENV', 'ANSIBLE_TEST_ENV')
        assert False
    except AnsibleFallbackNotFound:
        assert True



# Generated at 2022-06-22 21:55:17.119884
# Unit test for function env_fallback
def test_env_fallback():
    # Script should not fail with missing os.environ
    # Remove this line if os.environ behaves correctly
    os.environ = None
    raise_except = lambda: env_fallback("ANSIBLE_ANSIBLE_HOST", "ANSIBLE_HOST")
    assert_raises(AnsibleFallbackNotFound, raise_except)



# Generated at 2022-06-22 21:55:23.256332
# Unit test for function remove_values
def test_remove_values():
    print ("Start to test_remove_values")
    test_data = {'password': 'abc', 'password1' : '123', 'secret': 'xyz'}
    no_log_strings = ['abc', '123']
    test_data_list = ['abc', ['abc','def'], 'xyz', {'pwd': 'abc'}, {'password': 'xyz'}, [{'password': 'def'}, 'xyz']]
    new_data = remove_values(test_data, no_log_strings)
    new_data_list = remove_values(test_data_list, no_log_strings)
    print ("new_data = ", new_data)
    print ("new_data_list = ", new_data_list)
    assert new_data['password'] == "***"
    assert new_

# Generated at 2022-06-22 21:55:34.244762
# Unit test for function remove_values
def test_remove_values():
    # test basic functionality
    no_log_strings = ['bobbins']
    value = {'password': 'bobbins', 'random': 'string'}
    expected_value = {'password': 'FILTERED', 'random': 'string'}
    assert expected_value == remove_values(value, no_log_strings)

    # test deep emptying of dict
    value = {'password': 'bobbins', 'random': {'password': 'bobbins'}}
    expected_value = {'password': 'FILTERED', 'random': {}}
    assert expected_value == remove_values(value, no_log_strings)

    # test emptying of list
    value = ['password', 'bobbins', 'random']
    expected_value = ['password', 'FILTERED', 'random']
    assert expected_value

# Generated at 2022-06-22 21:55:40.950966
# Unit test for function remove_values
def test_remove_values():
    assert remove_values('ssh-rsa', ['ssh-rsa']) == '<<VARIABLE, value was hidden>>'
    assert remove_values('I can see the future', ['I can see the future']) == '<<VARIABLE, value was hidden>>'
    assert remove_values('ssh-rsa', ['I can see the future']) == 'ssh-rsa'
    assert remove_values('I can see the future', ['ssh-rsa']) == 'I can see the future'
    assert remove_values(['ssh-rsa', 'I can see the future', 'I can see the past'], ['ssh-rsa']) == ['<<VARIABLE, value was hidden>>', 'I can see the future', 'I can see the past']

# Generated at 2022-06-22 21:55:53.157955
# Unit test for function set_fallbacks
def test_set_fallbacks():
    parameters = dict()
    module_arg_spec = dict()
    resulting_parameters = dict()
    module_arg_spec['one'] = dict(fallback=(env_fallback, 'TEST_ENV_VAR'))
    module_arg_spec['two'] = dict(fallback=(env_fallback, 'TEST_ENV_VAR'))
    module_arg_spec['three'] = dict(fallback=(env_fallback, 'TEST_ENV_VAR_NOTSET'))
    module_arg_spec['four'] = dict(fallback=(env_fallback, 'TEST_ENV_VAR'), no_log=True)
    os.environ['TEST_ENV_VAR'] = 'env_var_value'

# Generated at 2022-06-22 21:56:02.370691
# Unit test for function remove_values
def test_remove_values():
    seq = [dict(a='abc', b='vwxyz'), ['abc', 'vwxyz']]
    ret = remove_values(seq, 'xyz')
    assert ret == [{'a': 'abc', 'b': 'vw'}, ['abc', 'vw']]
    # test that removing a number does nothing
    seq = [123]
    ret = remove_values(seq, 123)
    assert ret == [123]
    # test that a str is not touched
    seq = 'xyz'
    ret = remove_values(seq, 'xyz')
    assert ret == 'xyz'
    # test that a unicode string is not touched
    seq = u'xyz'
    ret = remove_values(seq, 'xyz')
    assert ret == u'xyz'
    # test that removing

# Generated at 2022-06-22 21:56:14.582261
# Unit test for function remove_values
def test_remove_values():
    '''
    Helper function to test function remove_values.
    '''
    import doctest
    from ansible.module_utils.common.collections import MutableMapping, MutableSequence, MutableSet
    import random
    import string

    # Generate random string of specified length
    def random_string(length):
        return ''.join(random.choice(string.ascii_lowercase) for _ in range(length))
    # Generate random string of specified length, which begins with the given string
    def random_string_begin(begin):
        length = random.randint(10, 15)
        return random_string(length) + begin
    # Generate random string of specified length, with the given string somewhere in the middle

# Generated at 2022-06-22 21:56:25.172432
# Unit test for function remove_values
def test_remove_values():
    '''test for function remove_values'''


# Generated at 2022-06-22 21:56:36.231848
# Unit test for function remove_values

# Generated at 2022-06-22 21:56:44.430642
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert set_fallbacks({"a": {}}, {"a": 1}) == set()
    assert set_fallbacks({"a": {"fallback": (env_fallback, "ANSIBLE_UNIT_TEST_SET_FALLBACKS")}}, {}) == set()
    os.environ["ANSIBLE_UNIT_TEST_SET_FALLBACKS"] = "test"
    assert set_fallbacks({"a": {"fallback": (env_fallback, ["ANSIBLE_UNIT_TEST_SET_FALLBACKS"])}}, {}) == {"test"}
    assert set_fallbacks({"a": {"fallback": (env_fallback, ["ANSIBLE_UNIT_TEST_SET_FALLBACKS"]), "no_log": True}}, {}) == {"test"}



# Generated at 2022-06-22 21:56:54.545228
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # call set_fallbacks with no fallback
    assert set_fallbacks({'no_fallback': {}}, {}) == set()
    assert set_fallbacks({'no_fallback': {}}, {'no_fallback': False}) == set()
    # call set_fallbacks with a fallback
    assert set_fallbacks({'fallback': {'fallback': (lambda: True, )}}, {}) == {True}
    # call set_fallbacks with a fallback that fails to find a value
    assert set_fallbacks({'fallback': {'fallback': (env_fallback, '')}}, {}) == set()
    # call set_fallbacks with a fallback that finds a value
    os.environ['ONE'] = 'ONE'

# Generated at 2022-06-22 21:57:05.000542
# Unit test for function env_fallback
def test_env_fallback():
    # Make sure the environment variable is not defined before we start the test
    try:
        del os.environ['ENV_FALLBACK_TEST']
    except KeyError:
        pass
    # Test a key that does not exist in the environment
    assert env_fallback('ENV_FALLBACK_TEST') == 'https'
    # Test a key that does exist in the environment
    os.environ['ENV_FALLBACK_TEST'] = 'http'
    assert env_fallback('ENV_FALLBACK_TEST') == 'http'
    # Test multiple args where one key exists in the environment
    assert env_fallback('ENV_FALLBACK_TEST', 'ENV_FALLBACK_DOES_NOT_EXIST') == 'http'
    # Test multiple args where multiple keys exist in the

# Generated at 2022-06-22 21:57:14.025351
# Unit test for function remove_values
def test_remove_values():
    # Test the inner loops of remove_values()
    no_log_strings = frozenset(['PRIVATE DATA HIDDEN'])
    assert _remove_values_conditions('abc', no_log_strings, None) == 'abc'

    assert _remove_values_conditions(u'abc', no_log_strings, None) == u'abc'

    assert _remove_values_conditions(dict(foo='abc'), no_log_strings, None) == dict(foo='abc')

    assert _remove_values_conditions(dict(foo=u'abc'), no_log_strings, None) == dict(foo=u'abc')

    assert _remove_values_conditions(dict(foo='PRIVATE DATA HIDDEN'), no_log_strings, None) == dict(foo='**********')

    assert _remove_

# Generated at 2022-06-22 21:57:26.126531
# Unit test for function remove_values
def test_remove_values():
    assert remove_values({"foo": "bar"}, {"bar"}) == {}
    assert remove_values({"foo": "bar", "hello": "world"}, {"foo"}) == {"hello": "world"}
    assert remove_values({"foo": "bar", "hello": "world"}, {"bar"}) == {"foo": "***", "hello": "world"}
    assert remove_values(["foo", "bar"], {"foo"}) == ["***"]
    assert remove_values(["foo", "bar"], {"bar"}) == ["foo", "***"]
    assert remove_values(set(["foo", "bar"]), {"foo"}) == {"***"}
    assert remove_values(set(["foo", "bar"]), {"bar"}) == {"foo", "***"}
    # mapping types (dicts)

# Generated at 2022-06-22 21:57:31.156056
# Unit test for function remove_values
def test_remove_values():
    demo = {'a': 'b', 'c': ['d', 'e']}
    assert remove_values(demo, ['b']) == {'a': 'b', 'c': ['d', 'e']}
    assert remove_values(demo, ['a']) == {'c': ['d', 'e']}
    assert remove_values(demo, ['b', 'd', 'c']) == {'a': 'b'}


# Generated at 2022-06-22 21:57:43.044706
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Test for basic usage of the fallback parameter
    # The test dictionary argument_spec contains parameters that are commonly used
    # in module arguments. The fallback is set for valid param combination to it's value
    # and can be retrieved once it is called.
    argument_spec = dict(
        age=dict(type='str', fallback=(env_fallback, ['AGE', 'RANDOM_AGE'])),
        fallback_group_param=dict(type='str'),
        fallback_group=dict(type='bool', fallback=(lambda: True)),
        fallback_values=dict(type='str', fallback=(env_fallback, 'VALUE', dict(default='DEFAULT_VALUE')))
    )
    parameters = dict(fallback_group_param='param', fallback_group=False)
    os.environ['AGE']

# Generated at 2022-06-22 21:57:54.384088
# Unit test for function sanitize_keys
def test_sanitize_keys():
    # Invalid arguments
    # Invalid type
    with pytest.raises(TypeError) as execinfo:
        sanitize_keys(None, 'value')
    assert "The value for no_log_strings must be a set" in str(execinfo.value)

    # Invalid type
    with pytest.raises(TypeError) as execinfo:
        sanitize_keys({}, 1)
    assert "The value for no_log_strings must be a set" in str(execinfo.value)

    # No_log_strings must be a string not a dict
    with pytest.raises(TypeError) as execinfo:
        sanitize_keys({}, {'value': 'value'})
    assert "The value for no_log_strings must be a set" in str(execinfo.value)

    # Invalid type


# Generated at 2022-06-22 21:58:04.976067
# Unit test for function remove_values
def test_remove_values():
    # This test is for unit testing of the remove_values function
    # Remove_values does the following
    # 1. If the value is a container, it removes values form the container
    # 2. In case of dicts it removes keys form keys
    # 3. In case of list, it removes values form items
    # 4. In case of set, it removes items form the set
    # 5. In case of other container types, it removes values form their attributes
    # 6. It preserves the type of the container
    # _remove_values only acts on the container, it does not recurse into the container elements
    no_log = ['key', 'value', 'name']
    # Test a dict
    dict_data = dict(key='key', value='value', name='name')
    dict_data1 = dict_data.copy()

# Generated at 2022-06-22 21:58:08.910735
# Unit test for function env_fallback
def test_env_fallback():
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('foo')
    os.environ["foo"] = "bar"
    assert env_fallback("foo") == os.environ["foo"]
    del os.environ["foo"]



# Generated at 2022-06-22 21:58:20.002656
# Unit test for function sanitize_keys
def test_sanitize_keys():
    # Test nested keys
    assert sanitize_keys(
        {'k_1': {'k_2': {'k_3': {'k_4': 'foo'}}}},
        set(['k_3'])
    ) == {'k_1': {'k_2': {'*': {'k_4': 'foo'}}}}

    # Test many nested keys

# Generated at 2022-06-22 21:58:28.442402
# Unit test for function remove_values
def test_remove_values():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_text

    no_log_strings = {'masked number', 'masked string'}

    class TestRemoveValues(unittest.TestCase):

        def test_basic(self):
            data = {'secret': 'very secret'}
            data_expected = {'secret': 'masked string'}
            self.assertEqual(remove_values(data, no_log_strings), data_expected)

        def test_basic_string(self):
            data = 'very secret'
            data_expected = 'masked string'

# Generated at 2022-06-22 21:58:39.972626
# Unit test for function set_fallbacks
def test_set_fallbacks():
    spec = {'a':{'fallback': (env_fallback, 'ANSIBLE_TEST_A')},
            'b':{'fallback': (env_fallback, 'ANSIBLE_TEST_B1', 'ANSIBLE_TEST_B2')},
            'c':{'fallback': (env_fallback, 'ANSIBLE_TEST_C', {'fallback_value': 'default_c'})}}
    os.environ['ANSIBLE_TEST_A'] = 'test_a'
    os.environ['ANSIBLE_TEST_B1'] = 'test_b1'
    os.environ['ANSIBLE_TEST_C'] = 'test_c'
    parameters = {}
    no_log_values = set_fallbacks(spec, parameters)

# Generated at 2022-06-22 21:58:50.572449
# Unit test for function remove_values

# Generated at 2022-06-22 21:58:51.785880
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('ANSIBLERY') == 'ANSIBLERY'



# Generated at 2022-06-22 21:58:54.512391
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['FOO'] = 'foo'
    assert env_fallback('FOO') == 'foo'
    assert env_fallback('BAR') == 'bar'


# Generated at 2022-06-22 21:58:58.440377
# Unit test for function env_fallback
def test_env_fallback():
    with patch('os.environ', {'TEST_ENV': 'testenv'}):
        assert env_fallback('TEST_ENV') == 'testenv'

    with patch('os.environ', {}):
        with pytest.raises(AnsibleFallbackNotFound):
            env_fallback('TEST_ENV')


# Generated at 2022-06-22 21:59:06.526270
# Unit test for function set_fallbacks
def test_set_fallbacks():

    def _test_as_dict(fallback_strategy, expected_dict, expected_expanduser):
        argument_spec = dict(
            dict_key=dict(fallback=(fallback_strategy, None, dict(dict_key='DICT_KEY'))),
            expanduser_key=dict(fallback=(fallback_strategy, None, dict(expanduser_key='EXPANDUSER_KEY'))),
        )
        parameters = dict()
        no_log_values = set_fallbacks(argument_spec, parameters)
        assert parameters == expected_dict
        assert no_log_values == expected_expanduser, 'No log values should be %s' % expected_expanduser

    # Test with env_fallback (which is a fallback function)

# Generated at 2022-06-22 21:59:13.002933
# Unit test for function env_fallback
def test_env_fallback():
    if not os.environ.get('FOO'):
        os.environ['FOO'] = 'FOOBAR'
    assert env_fallback('FOO', 'BAR') == os.environ['FOO']
    assert env_fallback('BAR', 'FOO') == os.environ['FOO']
    del os.environ['FOO']



# Generated at 2022-06-22 21:59:25.315565
# Unit test for function remove_values

# Generated at 2022-06-22 21:59:35.317366
# Unit test for function sanitize_keys
def test_sanitize_keys():
    # Create test values
    test_dict = {
        'test1': 1,
        'test2': 2,
        'test3': {
            'test4': {
                'test6': 'test6',
                'test7': 'test7'
            },
            'test5': 'test5'
        },
    }
    # Sanitize and compare result
    assert sanitize_keys(test_dict, {"test5"}) == {
        'test1': 1,
        'test2': 2,
        'test3': {
            'test4': {
                'test6': 'test6',
                'test7': 'test7'
            },
            'test5': '***'
        },
    }



# Generated at 2022-06-22 21:59:44.875273
# Unit test for function sanitize_keys
def test_sanitize_keys():
    # mock StrParamSpec obj
    class StrParamSpec(object):
        type = 'str'
        no_log = False
    # mock DictParamSpec obj
    class DictParamSpec(object):
        type = 'dict'
        no_log = False
        options = {'netmask': StrParamSpec()}
    # mock ListParamSpec obj
    class ListParamSpec(object):
        type = 'list'
        no_log = False
        elements = 'dict'
        options = {'netmask': StrParamSpec()}
    # or parameter spec for ansible module
    argument_spec = {'mask': DictParamSpec(),
                     'masks': ListParamSpec()}

# Generated at 2022-06-22 21:59:55.657932
# Unit test for function remove_values

# Generated at 2022-06-22 22:00:02.350153
# Unit test for function env_fallback
def test_env_fallback():
    """Test function env_fallback"""

    my_env = os.environ.copy()
    my_env["ANSIBLE_TEST_ENV"] = "testing env var fallback"
    os.environ = my_env
    assert env_fallback("ANSIBLE_TEST_ENV") == "testing env var fallback"

    my_env = os.environ.copy()
    del my_env["ANSIBLE_TEST_ENV"]
    os.environ = my_env
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback("ANSIBLE_TEST_ENV")



# Generated at 2022-06-22 22:00:08.488470
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['FOO'] = 'bar'
    assert env_fallback('FOO', 'ANSIBLE_FOO') == 'bar'
    del os.environ['FOO']
    try:
        env_fallback('FOO', 'bar')
    except AnsibleFallbackNotFound as e:
        pass
    else:
        raise AssertionError('Test must raise AnsibleFallbackNotFound')

# Generated at 2022-06-22 22:00:16.556540
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['TEST_ENV_1'] = 'test-value-1'
    os.environ['TEST_ENV_2'] = 'test-value-2'
    os.environ['TEST_ENV_3'] = 'test-value-3'
    assert env_fallback('TEST_ENV_1', 'TEST_ENV_2', 'TEST_ENV_3') == 'test-value-1'
    assert env_fallback('TEST_ENV_2', 'TEST_ENV_1', 'TEST_ENV_3') == 'test-value-2'
    assert env_fallback('TEST_ENV_3', 'TEST_ENV_2', 'TEST_ENV_1') == 'test-value-3'

# Generated at 2022-06-22 22:00:25.885219
# Unit test for function remove_values
def test_remove_values():
    # Setup
    empty = {}
    no_log_values = {'foo': 'bar'}
    mutable = {
        'a': ['foo', 'bar'],
        'b': {'c': 'foo'},
        'd': ('foo', 'bar'),
        'e': frozenset(['foo', 'bar']),
    }
    expected = {
        'a': ['***', '***'],
        'b': {'c': '***'},
        'd': ('***', '***'),
        'e': frozenset(['***', '***']),
    }
    for name, value in itertools.chain(no_log_values.items(), mutable.items()):
        expected[name] = remove_values(value, no_log_values)

    # Test simple values
   

# Generated at 2022-06-22 22:00:36.884486
# Unit test for function sanitize_keys
def test_sanitize_keys():
    # Unit test for function sanitize_keys
    from ansible.module_utils.json_utils import json_dumps, json_loads

    input_data = u'''
{
    "_ansible_parsed": {
        "tags": [], 
        "skip_tags": []
    }, 
    "gather_subset": [
        "all"
    ], 
    "gather_timeout": 10, 
    "gather_facts": "yes", 
    "playbook_dir": ".", 
    "path": "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
}
'''

# Generated at 2022-06-22 22:00:42.952792
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('UNITTEST_env_fallback_1') == os.environ['UNITTEST_env_fallback_1']
    assert raises(AnsibleFallbackNotFound, env_fallback, 'UNITTEST_env_fallback_2')


# Unit tests for function _get_fallback_value

# Generated at 2022-06-22 22:00:48.351956
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys({'Yes': 'n0', 'No': 'y1'}, ['y1']) == {'Yes': 'n0'}
    assert sanitize_keys({'y0': {'Yes': 'n0', 'No': 'y1'}}, ['y1']) == {'y0': {'Yes': 'n0'}}
    assert sanitize_keys({'y0': ['y1', 'n0']}, ['y1']) == {'y0': ['n0']}


# Generated at 2022-06-22 22:01:00.492188
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'test1': {'fallback': (env_fallback, 'TEST1')}}
    parameters = {}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert len(no_log_values) == 0
    assert len(parameters) == 1

    argument_spec = {'test2': {'fallback': (env_fallback, 'TEST2'), 'no_log': True}}
    parameters = {}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert len(no_log_values) == 0
    assert len(parameters) == 1

    argument_spec = {'test3': {'fallback': (env_fallback, 'TEST3'), 'no_log': True}}
    parameters = {}
    os.en

# Generated at 2022-06-22 22:01:09.987122
# Unit test for function env_fallback
def test_env_fallback():
    env_fallback = AnsibleModule.env_fallback
    os.environ['ENV_FALLBACK1'] = 'foo'
    os.environ['ENV_FALLBACK2'] = 'bar'
    os.environ['ENV_FALLBACK3'] = 'baz'

    # callable should raise AnsibleFallbackNotFound when no env variables are set
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('ENV_FALLBACK4')

    # callable should return os.environ value when env variables are set
    assert env_fallback('ENV_FALLBACK1') == 'foo'
    assert env_fallback('ENV_FALLBACK2') == 'bar'

# Generated at 2022-06-22 22:01:22.529689
# Unit test for function sanitize_keys
def test_sanitize_keys():
    """Test sanitize_keys()"""
    assert sanitize_keys(['A', 'B', 'C'], {'A'}) == ['[A]', 'B', 'C']
    assert sanitize_keys(['A', 'B', 'C'], {'A', 'B'}) == ['[A]', '[B]', 'C']
    assert sanitize_keys(['A', 'B', 'C'], {'A', 'B', 'Z'}) == ['[A]', '[B]', 'C']
    assert sanitize_keys(['A', 'B', 'C'], {'A', 'B', 'C'}) == ['[A]', '[B]', '[C]']