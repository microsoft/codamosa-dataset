

# Generated at 2022-06-22 21:51:23.759331
# Unit test for function remove_values
def test_remove_values():
    assert remove_values('abcdabcd', ['abcd']) == 'abcdabcd'
    assert remove_values('abcdabcd', ['abcd'] * 2) == 'abcdabcd'
    assert remove_values('abcd', ['abcd']) == ''
    assert remove_values('abcd', ['abcd'] * 2) == ''
    assert remove_values('abcd', ['abcd'] * 5) == ''
    assert remove_values('abcabcabcabcabcabcabcabcabcabcabcabcabcabcabc', ['abc'] * 5) == ''
    assert remove_values('', ['abcd']) == ''
    assert remove_values('', ['abcd'] * 5) == ''

# Generated at 2022-06-22 21:51:34.009013
# Unit test for function remove_values
def test_remove_values():
    import random, string
    from six import StringIO, binary_type
    from ansible.module_utils._text import to_bytes, to_text

    # Create a random data structure for the test
    def _random_string():
        return ''.join(random.choice(string.ascii_uppercase) for _ in range(random.randint(1, 10)))
    def _random_container():
        value = {}
        for _ in xrange(random.randint(2, 5)):
            key = _random_string()
            item = random.choice([_random_string, _random_container])()
            value[key] = item
        return value

# Generated at 2022-06-22 21:51:42.955676
# Unit test for function remove_values
def test_remove_values():
    assert remove_values("hello, world", "world") == "hello, "
    assert remove_values("hello, world", "hello") == ", world"
    assert remove_values("hello, world", "wor%le") == "h, o"
    assert remove_values("", "") == ""
    i = {"x": "hello", "y": {1: "world"}, "z": [{"a": "hi"}, {"b": "world"}]}
    assert remove_values(i, "hello") == {"x": "", "y": {1: "world"}, "z": [{"a": ""}, {"b": "world"}]}
    assert remove_values(i, "world") == {"x": "hello", "y": {1: ""}, "z": [{"a": "hi"}, {"b": ""}]}
    assert remove_values

# Generated at 2022-06-22 21:51:49.490570
# Unit test for function remove_values
def test_remove_values():
    data = {
        'foo': 'bar',
        'baz': {
            'bar': 'foo',
        }
    }

    # conversion to list is necessary because sets are not ordered and
    # we need to test the order of the returned keys
    assert list(remove_values(data, ['foo']).keys()) == ['baz']
    assert remove_values(data, ['baz']) == {'foo': 'bar'}
    assert remove_values(data, []) == data



# Generated at 2022-06-22 21:51:59.542747
# Unit test for function remove_values
def test_remove_values():
    assert remove_values('a password val', ['password']) == 'a ****** val'
    assert remove_values('a password password val', ['password']) == 'a ****** ****** val'
    assert remove_values('a passwordpassword val', ['password']) == 'a ************* val'
    assert remove_values('a pass val password val', ['password']) == 'a pass val ****** val'
    assert remove_values('a pass val password val', ['pass']) == 'a **** val ****** val'
    assert remove_values('a password val', ['password', 'pass']) == 'a ****** val'
    assert remove_values('a password password val', ['password', 'pass']) == 'a ****** ****** val'

# Generated at 2022-06-22 21:52:04.903386
# Unit test for function env_fallback
def test_env_fallback():
    for arg in ['ADMIN_PASSWORD', 'ADMIN_PASS']:
        if arg in os.environ:
            assert os.environ[arg] == env_fallback(arg)
            os.environ.pop(arg)
    try:
        env_fallback('ADMIN_PASSWORD', 'ADMIN_PASS')
        assert False, 'AnsibleFallbackNotFound not raised'
    except AnsibleFallbackNotFound:
        pass



# Generated at 2022-06-22 21:52:07.588473
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['TEST_ENV_FALLBACK'] = '42'
    assert env_fallback('TEST_ENV_FALLBACK') == '42'
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('TEST_ENV_FALLBACK_DOES_NOT_EXIST')


# Look up fallback value, but not if it's set in the 'parameters' we were given

# Generated at 2022-06-22 21:52:13.684622
# Unit test for function remove_values

# Generated at 2022-06-22 21:52:16.975566
# Unit test for function env_fallback
def test_env_fallback():
    with patch.dict('os.environ', {'TEST_FOO': 'bar'}):
        assert env_fallback('TEST_FOO') == 'bar'
    # env_fallback raises exception if no env var found
    raises(AnsibleFallbackNotFound, env_fallback, 'TEST_FOO')
    raises(AnsibleFallbackNotFound, env_fallback, 'NO_SUCH_KEY')



# Generated at 2022-06-22 21:52:19.988783
# Unit test for function env_fallback
def test_env_fallback():
    ''' Test function env_fallback
    '''
    env_name = 'ANSIBLE_TEST_FALLBACK'
    env_value = 'testing_env'
    os.environ[env_name] = env_value
    assert env_fallback(env_name) == env_value
    os.environ.pop(env_name, None)
    assert env_fallback(env_name) == None


# Generated at 2022-06-22 21:52:29.076356
# Unit test for function sanitize_keys
def test_sanitize_keys():
    test_dict = {'password': 'secret', 'password2': 'secret2'}
    assert set(sanitize_keys(test_dict, 'secret')) == set({'password': '***', 'password2': '***'})
    assert set(sanitize_keys(test_dict, ['secret', 'secret2'])) == set({'password': '***', 'password2': '***'})
    assert set(sanitize_keys(test_dict, ['secret', 'secret2'], ignore_keys=['password2'])) == set({'password': '***', 'password2': 'secret2'})

    test_tuple = (1, {'password': 'secret'})
    assert set(sanitize_keys(test_tuple, 'secret')) == set((1, {'password': '***'}))

# Generated at 2022-06-22 21:52:40.623849
# Unit test for function env_fallback
def test_env_fallback():
    with set_env_fallback({}):
        assert env_fallback("FOO") == os.environ["FOO"]
    assert env_fallback("FOO", "BAR") == os.environ["FOO"]
    assert env_fallback("FOO") == "BAR"
    assert env_fallback("FOO", "BAR", "BAZ") == "BAR"
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback("FOO")
    os.environ.pop("FOO")
    os.environ.pop("BAR")
    os.environ.pop("BAZ")



# Generated at 2022-06-22 21:52:46.214065
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST'] = u"TEST"
    assert env_fallback('ANSIBLE_TEST', 'ANSIBLE_MISSING') == u"TEST"
    assert env_fallback('ANSIBLE_MISSING') == u"TEST"
    os.environ.pop('ANSIBLE_TEST', None)
    assert env_fallback('ANSIBLE_MISSING') == u"TEST"
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('ANSIBLE_MISSING', 'ANSIBLE_MISSING')


# Generated at 2022-06-22 21:52:57.345275
# Unit test for function remove_values
def test_remove_values():
    """Execute the remove_values unit tests."""

    class TestException(Exception):
        """Exception raised by test assertion methods."""
        pass

    def check_result(result, input_dict):
        """Check if result is as expected for a certain input."""
        for key, value in input_dict.items():
            if key in result:
                if isinstance(input_dict[key], dict):
                    check_result(result[key], input_dict[key])
                elif isinstance(input_dict[key], list):
                    for index, list_dict in enumerate(input_dict[key]):
                        check_result(result[key][index], list_dict)
                else:
                    raise TestException("Error in test, please raise a bug report")

# Generated at 2022-06-22 21:53:08.918317
# Unit test for function remove_values
def test_remove_values():
    assert remove_values(None, []) == None
    assert remove_values([], []) == []
    assert remove_values({}, []) == {}
    assert remove_values(['abc', {'abc': 'def'}], []) == ['abc', {'abc': 'def'}]
    assert remove_values(['abc', {'abc': 'def'}], ['def']) == ['abc', {'abc': '***'}]
    assert remove_values(['abc', {'abc': 'def'}], ['abc']) == ['***', {'***': 'def'}]
    assert remove_values(['abc', {'abc': 'def'}], ['abc', 'def']) == ['***', {'***': '***'}]

# Generated at 2022-06-22 21:53:16.073234
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # checking for fallback for env variable
    argument_spec = dict(
        my_env=dict(type='str', fallback=(env_fallback, 'MY_ENV_VAR')),
    )
    paramters = dict()
    no_log_values = set_fallbacks(argument_spec, paramters)
    assert no_log_values == set()
    assert paramters.get('my_env') == os.environ.get('MY_ENV_VAR')
    # checking for fallback for env variable with no_log option
    os.environ['MY_ENV_VAR'] = 'some_value'
    argument_spec = dict(
        my_env=dict(type='str', fallback=(env_fallback, 'MY_ENV_VAR'), no_log=True),
    )


# Generated at 2022-06-22 21:53:23.579558
# Unit test for function sanitize_keys
def test_sanitize_keys():
    d = dict(
        dict(foo2='bar2'),
        foo1=dict(
            dict(foo4='bar4'),
            foo3='bar3',
            foo5=['bar5', 'bar6']),
    )

    # test sanitize_keys
    d = sanitize_keys(d,
                      no_log_strings=[
                          'foo2', 'bar2',
                          'foo3', 'bar3',
                          'foo5', 'bar5', 'bar6'])

    assert ('foo1' in d)
    assert ('foo2' in d['foo1'])
    assert ('foo2' not in d)
    assert ('bar2' not in d['foo1'])
    assert ('bar2' in d['foo1']['foo2'])

# Generated at 2022-06-22 21:53:29.980146
# Unit test for function env_fallback
def test_env_fallback():
    # Test with only args
    assert env_fallback('foo') == 'bar'
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('foo1')

    # Test with args and kwargs
    assert env_fallback('foo', foo='bar') == 'bar'
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('foo1', foo='bar')

    # Test that kwargs don't override environment variable
    assert env_fallback('foo', foo1='bar') == 'bar'



# Generated at 2022-06-22 21:53:35.810295
# Unit test for function sanitize_keys
def test_sanitize_keys():
    struct = ({'foo':'bar', 'password':'123456', 'no_log':{'foobar':'foobar'}})
    answer = ({'foo':'bar', 'password':'123456', 'NO_LOG':{'foobar':'foobar'}})
    assert sanitize_keys(struct, {'NO_LOG'}) == answer
test_sanitize_keys()



# Generated at 2022-06-22 21:53:48.263421
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert set_fallbacks({'dummy_param': {'type': 'str', 'fallback': (env_fallback, ('HOME', '/tmp'))},
                          'dummy_param2': {'type': 'str', 'fallback': (env_fallback, ('USER', '/home/root'))}},
                         {'dummy_param2': 'some_value', 'dummy_param': 'some_value'}) == set()
    assert set_fallbacks({'dummy_param': {'type': 'str', 'fallback': (env_fallback, ('HOME', '/tmp'))},
                          'dummy_param2': {'type': 'str', 'fallback': (env_fallback, ('USER', '/home/root'))}},
                         {'dummy_param2': 'some_value'})

# Generated at 2022-06-22 21:53:59.246554
# Unit test for function remove_values
def test_remove_values():
    no_log_strings = ['password', 'secret']

    # Empty strings should be removed from any container type
    assert remove_values({}, no_log_strings) == {}
    assert remove_values([], no_log_strings) == []
    assert remove_values(set(), no_log_strings) == set()

    # Non-container types should have empty strings removed
    assert remove_values('', no_log_strings) == ''
    assert remove_values(b'', no_log_strings) == b''
    assert remove_values(u'', no_log_strings) == u''

    # Non-container types should be returned unmodified if no strings are removed
    assert remove_values('foo', no_log_strings) == 'foo'
    assert remove_values(b'foo', no_log_strings) == b'foo'

# Generated at 2022-06-22 21:54:09.692055
# Unit test for function remove_values
def test_remove_values():
    obj = {'foo': 'bar', b'binary': b'foo'}
    new_obj = remove_values(obj, ['bar'])
    assert new_obj == {'foo': '?', b'binary': b'foo'}, new_obj
    obj = [1, 2, 'bar', 'baz', b'foo']
    new_obj = remove_values(obj, ['bar'])
    assert new_obj == [1, 2, '?', 'baz', b'foo'], new_obj
    obj = [1, 2, [3, 'bar', 'baz'], 4]
    new_obj = remove_values(obj, ['bar'])
    assert new_obj == [1, 2, [3, '?', 'baz'], 4], new_obj

# Generated at 2022-06-22 21:54:20.181666
# Unit test for function remove_values
def test_remove_values():
    # function and test cases
    def _test_remove_values(value, no_log_strings, result):
        assert result == remove_values(value, no_log_strings)

    # test remove_values function: use cases from remove_values() docstring
    _test_remove_strings = ['Sensitive data removed for brevity']

# Generated at 2022-06-22 21:54:25.264102
# Unit test for function remove_values
def test_remove_values():
    assert remove_values(
        {'a': 'foo', 'b': {'c': 'bar', 'd': 'foo'}}, 
        set(['foo'])
    ) == {'a': '***', 'b': {'c': 'bar', 'd': '***'}}


# Generated at 2022-06-22 21:54:36.381554
# Unit test for function env_fallback
def test_env_fallback():
    # A function call with no args should raise AnsibleFallbackNotFound
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback()

    # A function call with a single arg that is not in the env should raise AnsibleFallbackNotFound
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('DOES_NOT_EXIST')

    # A function call with an arg that is in the env should return the value of the env
    # This is meant to be query a 'secure' environment variable with a value that should
    # not be exposed in any output (including task output and system info)
    os.environ['ANSIBLE_SECURE'] = 'secure_value'
    assert env_fallback('ANSIBLE_SECURE') == 'secure_value'

    # A function call

# Generated at 2022-06-22 21:54:47.001240
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_FOO'] = 'bar'
    os.environ['ANSIBLE_BAR'] = 'baz'
    assert env_fallback('ANSIBLE_FOO', 'foo', 'bar') == 'bar'
    os.environ.pop('ANSIBLE_FOO')
    assert env_fallback('ANSIBLE_FOO', 'ANSIBLE_BAR', 'foo', 'bar') == 'baz'
    os.environ.pop('ANSIBLE_BAR')
    try:
        env_fallback('ANSIBLE_BAZ', 'ANSIBLE_BAR', 'foo', 'bar')
        assert False, 'AnsibleFallbackNotFound not raised'
    except AnsibleFallbackNotFound:
        pass



# Generated at 2022-06-22 21:54:51.687109
# Unit test for function env_fallback
def test_env_fallback():
    """Unit test for env_fallback"""
    test_env_var = u'test_env_var'
    test_env_var_value = u'test_env_var_value'
    os.environ[test_env_var] = test_env_var_value
    assert env_fallback(test_env_var) == test_env_var_value



# Generated at 2022-06-22 21:55:00.332823
# Unit test for function env_fallback
def test_env_fallback():
    if os.environ.get('ANSIBLE_TEST_ENV_FALLBACK', None) is None:
        raise SkipTest('ANSIBLE_TEST_ENV_FALLBACK is not set')
    else:
        assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == os.environ.get('ANSIBLE_TEST_ENV_FALLBACK')
    assert_raises(AnsibleFallbackNotFound, env_fallback, 'ANSIBLE_TEST_ENV_FALLBACK_DOES_NOT_EXIST')



# Generated at 2022-06-22 21:55:12.719387
# Unit test for function set_fallbacks
def test_set_fallbacks():
    fallback_strategy_return_val = 'test'
    fallback_strategy_return_val_2 = {'foo': 'bar'}
    fallback_strategy_return_val_3 = ['foo']

    def fallback_strategy_1(*args, **kwargs):
        return fallback_strategy_return_val

    def fallback_strategy_2(*args, **kwargs):
        return fallback_strategy_return_val_2

    def fallback_strategy_3(*args, **kwargs):
        return fallback_strategy_return_val_3


# Generated at 2022-06-22 21:55:19.809154
# Unit test for function remove_values

# Generated at 2022-06-22 21:55:31.289681
# Unit test for function remove_values
def test_remove_values():
    import copy
    import pytest


# Generated at 2022-06-22 21:55:39.075219
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        foo=dict(type='str', default='bar', fallback=(env_fallback, ('FOO', 'BAR'))),
        bar=dict(type='str', fallback=(env_fallback, ('FOO', 'BAR'), dict(foo='1'))),
        baz=dict(type='str', fallback=(env_fallback, ('FOO', 'BAR'), dict(foo=2))),
    )
    parameters = dict()
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['foo'] == 'bar'
    assert parameters['bar'] == '1'
    assert parameters['baz'] == 2
    assert no_log_values == set()

    # Test no_log fallback

# Generated at 2022-06-22 21:55:46.498442
# Unit test for function sanitize_keys
def test_sanitize_keys():
    test_data = dict(
        test_dict=dict(
            test_key="test_value",
            test_no_log_key="test_value",
            test_no_log_dict_key=dict(
                test_key="test_value",
                test_no_log_key="test_value",
            )
        ),
        test_list=["test_value", "test_value"],
        test_no_log_key="test_value",
        test_no_log_list=["test_value", "test_value"],
        test_no_log_dict=dict(
            test_key="test_value",
            test_no_log_key="test_value",
        )
    )


# Generated at 2022-06-22 21:55:56.852244
# Unit test for function remove_values
def test_remove_values():
    assert remove_values({'a': 'some_string', 'b': 'some_other_string',
                          'd': {'a': 'some_string', 'b': 'some_other_string'},
                          'f': {'g': {'h': 'some_string'}},
                          'e': ['some_string', 'some_other_string']},
                         ['some_string']) == {'b': 'some_other_string',
                                              'd': {'b': 'some_other_string'},
                                              'f': {'g': {'h': 'REDACTED'}},
                                              'e': ['REDACTED', 'some_other_string']}



# Generated at 2022-06-22 21:56:04.331189
# Unit test for function remove_values
def test_remove_values():
    assert(remove_values('secret', ['secret']) == 'VALUE_REMOVED')
    value = {
        'key1': 'secret',
        'key2': {
            'key3': {
                'key4': 'secret'
            },
            'key5': [
                'secret',
                {
                    'key6': 'secret'
                },
                [
                    'secret',
                    'notsecret',
                    'secret'
                ],
                {
                    'key7': 'secret'
                }
            ]
        }
    }

# Generated at 2022-06-22 21:56:15.367772
# Unit test for function remove_values
def test_remove_values():
    test_value = {}
    no_log_strings = set()
    new_value = remove_values(test_value, no_log_strings)
    assert test_value == new_value
    test_value = []
    new_value = remove_values(test_value, no_log_strings)
    assert test_value == new_value
    test_value = ''
    new_value = remove_values(test_value, no_log_strings)
    assert test_value == new_value
    test_value = ()
    new_value = remove_values(test_value, no_log_strings)
    assert test_value == new_value
    test_value = 0
    new_value = remove_values(test_value, no_log_strings)
    assert test_value == new_value
    test_value

# Generated at 2022-06-22 21:56:25.738349
# Unit test for function set_fallbacks
def test_set_fallbacks():
    set_fallbacks_spec_1 = {
        'one': {'type': 'str', 'fallback': (env_fallback, 'ONE')},
        'two': {'type': 'str', 'fallback': (env_fallback, 'TWO')},
        'three': {'type': 'str', 'fallback': (env_fallback, 'three')},
        'four': {'type': 'str', 'fallback': (env_fallback, 'FOUR'), 'no_log': True},
    }
    set_fallbacks_params_1 = {}
    os.environ['ONE'] = 'one'
    os.environ['TWO'] = 'two'

    no_log_values = set_fallbacks(set_fallbacks_spec_1, set_fallbacks_params_1)


# Generated at 2022-06-22 21:56:27.912965
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['HOME'] = '/tmp'
    os.environ['USER'] = 'you'
    assert env_fallback('HOME') == '/tmp'
    assert env_fallback('USER') == 'you'
    assert env_fallback('BOGUS') is None



# Generated at 2022-06-22 21:56:33.047924
# Unit test for function env_fallback
def test_env_fallback():

    env.reset()

    env.set('ANSIBLE_HOST_KEY_CHECKING', 'True')
    assert env_fallback('ANSIBLE_HOST_KEY_CHECKING') == 'True'

    assert env_fallback('FOOBAR') == 'False'
    assert env_fallback('FOOBAR', 'BAZ') == 'BAZ'



# Generated at 2022-06-22 21:56:42.651662
# Unit test for function sanitize_keys
def test_sanitize_keys():
#     Given a dictionary with sanitized keys
    d = {'clear_key': 'value', 'secret_key' : 'secret_value'}

    sanitized_d = sanitize_keys(d, no_log_strings=['secret'], ignore_keys=['clear_key'])
    
#     Then the sanitized dictionary should be: {'clear_key': 'value', '****_key' : 'secret_value'}
    assert sanitized_d == {'clear_key': 'value', '****_key' : 'secret_value'}

#     When a list of dictionaries are recieved
    l = [{'clear_key': 'value', 'secret_key' : 'secret_value'}]

#     Then the list should be sanitized to: [{'clear_key': 'value', '****_key

# Generated at 2022-06-22 21:56:53.716337
# Unit test for function remove_values
def test_remove_values():
    """Run a small set of tests for remove_values()."""
    # Basic test data for testing the remove_values() function
    test_data = dict(
        simple='x',
        hello='Hello, world!',
        intval=5,
        floatval=5.5,
        binary=b'x',
        u='\u1234',
        u8='\u1234'.encode('utf-8'),
        u16='\u1234'.encode('utf-16'),
        list=[
            'a', 'b', 'c',
        ],
        dict={
            'a': 'yes',
            'b': 'no',
            'c': 'maybe',
        },
        set={
            'a', 'b', 'c',
        },
    )

    # tests is a sequence of tuples

# Generated at 2022-06-22 21:57:04.872816
# Unit test for function remove_values
def test_remove_values():
    assert remove_values("", [""]) == ""
    assert remove_values(b"", [b""]) == b""
    assert remove_values("abc", [""]) == "abc"
    assert remove_values("abc", ["b"]) == "ac"
    assert remove_values("abc", ["c"]) == "ab"
    assert remove_values("abc", ["d"]) == "abc"
    assert remove_values("abc", ["a"]) == "bc"
    assert remove_values(u"abc", [u"b"]) == u"ac"
    assert remove_values({"a":"b"}, ["b"]) == {"a":""}
    assert remove_values({"a":"d"}, ["c"]) == {"a":"d"}
    assert remove_values({"a":"b","b":"c"}, ["b"])

# Generated at 2022-06-22 21:57:12.783022
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'param': {'type': 'str', 'fallback': (env_fallback, 'INVALID', 'VALID')}}
    parameters = {}
    os.environ['INVALID'] = 'INVALID'
    os.environ['VALID'] = 'VALID'
    set_fallbacks(argument_spec, parameters)
    assert parameters['param'] == 'VALID'

    parameters = {'param': 'value'}
    set_fallbacks(argument_spec, parameters)
    assert parameters['param'] == 'value'



# Generated at 2022-06-22 21:57:25.562723
# Unit test for function remove_values
def test_remove_values():
    import pytest
    no_log_strs = ['Something', 'Something else', 'Mismatch']
    assert remove_values('Hello', no_log_strs) == 'Hello'
    assert remove_values('Something else to do', no_log_strs) == '*** to do'
    assert remove_values('Something', []) == 'Something'
    assert remove_values([], no_log_strs) == []
    assert remove_values([1, 2, 'Something else'], no_log_strs) == [1, 2, '***']
    assert remove_values((1, 2, 'Something else'), no_log_strs) == (1, 2, '***')
    with pytest.raises(TypeError):
        remove_values(1, no_log_strs)

# Generated at 2022-06-22 21:57:30.859467
# Unit test for function env_fallback
def test_env_fallback():
    env = os.environ
    try:
        os.environ = {}
        assert env_fallback('foo') == raise_(AnsibleFallbackNotFound)
        os.environ = {'key': 'value'}
        assert env_fallback('key') == 'value'
        assert env_fallback('foo') == raise_(AnsibleFallbackNotFound)
    finally:
        os.environ = env



# Generated at 2022-06-22 21:57:42.570086
# Unit test for function remove_values
def test_remove_values():
    no_log_strings = ['bar', 'foo']
    data = dict(a=1, b=dict(foo='bar', bar='foo'))
    removed = remove_values(data, no_log_strings)
    assert removed == dict(a=1, b=dict(**{'**': '***'}))
    data = dict(a=1, b=dict(foo='bar', bar='foo'), c={1, 2, 3, 4}, d='foo')
    removed = remove_values(data, no_log_strings)
    assert removed == dict(a=1, b=dict(**{'**': '***'}), c={'**', '***'}, d='***')

# Generated at 2022-06-22 21:57:49.144681
# Unit test for function sanitize_keys

# Generated at 2022-06-22 21:57:54.028459
# Unit test for function env_fallback
def test_env_fallback():
    # Set environment variable
    os.environ['TEST_ENV_VAR'] = 'hello world!'
    assert env_fallback('TEST_ENV_VAR') == 'hello world!'
    # Unset environment variable
    del os.environ['TEST_ENV_VAR']



# Generated at 2022-06-22 21:58:04.710594
# Unit test for function set_fallbacks
def test_set_fallbacks():
    print("Test set_fallbacks")
    argument_spec = {'a': dict(type='int', fallback=(env_fallback, "TEST_A")), 'b': dict(type='int', fallback=(env_fallback, "TEST_B")), 'c': dict(type='int', fallback=(env_fallback, "TEST_C")), 'd': dict(type='int', fallback=(env_fallback, "TEST_D"))}
    parameters = {}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert len(no_log_values) == 0, "expected no_log values should be empty but got %s" % no_log_values
    assert len(parameters) == 0, "expected parameters should be empty but got %s" % parameters

    os.en

# Generated at 2022-06-22 21:58:09.490359
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec={'param': {'type': 'str', 'fallback': [env_fallback, 'param1']}}
    parameters={}
    os.environ['param1']='xyz'
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert 'xyz' in no_log_values



# Generated at 2022-06-22 21:58:20.610805
# Unit test for function set_fallbacks
def test_set_fallbacks():
    '''
        Test set_fallbacks
    '''
    # Mock os.environ
    mock_environ = {
        'ANSIBLE_REMOTE_USER': 'ansible-remote-user',
        'TEST_KEY': 'TEST_VALUE',
    }
    mock_environ_original = os.environ.copy()
    os.environ = mock_environ

    # Testing fallback from env variable
    argument_spec = {
        'name': {'type': 'str', 'fallback': (env_fallback, ['ANSIBLE_REMOTE_USER'])},
        'key': {'type': 'str', 'fallback': (env_fallback, ['TEST_KEY'])},
    }
    parameters = {
        'name': 'ansible-user',
    }
    no_log

# Generated at 2022-06-22 21:58:28.834228
# Unit test for function remove_values
def test_remove_values():
    """Unit test for module remove_values"""
    import unittest

    class TestRemoveValues(unittest.TestCase):
        """Unit test for remove_values."""

# Generated at 2022-06-22 21:58:40.278972
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # test fallback from env variable
    os.environ['ANSIBLE_TEST_FALLBACK_1'] = 'test'
    args = {
        'a': {'type': 'str', 'fallback': (env_fallback, 'ANSIBLE_TEST_FALLBACK_1')},
    }
    kwargs = {}
    assert set_fallbacks(args, kwargs) == set()
    assert kwargs['a'] == 'test'

    # test missing fallback
    args = {
        'a': {'type': 'str', 'fallback': (env_fallback, 'NOT_THERE')},
    }
    kwargs = {}
    assert set_fallbacks(args, kwargs) == set()
    assert 'a' not in kwargs

    # test missing fallback,

# Generated at 2022-06-22 21:58:50.962166
# Unit test for function sanitize_keys
def test_sanitize_keys():

    no_log_strings_sensitive = set(['sensitive_data', 'sensitive_data_with_\\x5c_escape'])
    no_log_strings_obvious = set(['obvious_value'])

    data_mapping_sensitive = dict(sensitive_key='sensitive_data')
    data_mapping_obvious = dict(obvious_key='obvious_value')
    data_mapping_mixed = dict(sensitive_key='sensitive_data', obvious_key='obvious_value')

# Generated at 2022-06-22 21:58:57.479125
# Unit test for function env_fallback
def test_env_fallback():
    env = {'HOME': '/home/user', 'USER': 'user', 'LANG': 'en_US.UTF-8', 'PATH': '/bin:/usr/bin'}
    with set_environ(env):
        assert env_fallback('HOME') == '/home/user'
        assert env_fallback('USER') == 'user'
        assert env_fallback('LANG') == 'en_US.UTF-8'
        assert env_fallback('PATH') == '/bin:/usr/bin'
        assert env_fallback('NOT_SET') == 'NOT_SET'



# Generated at 2022-06-22 21:59:03.944592
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        foo=dict(type='dict', fallback=(env_fallback, 'ANSIBLE_FOO')),
        bar=dict(type='dict', fallback=(env_fallback, 'ANSIBLE_BAR')),
        baz=dict(type='dict', fallback=(env_fallback, 'ANSIBLE_BAZ')),
        foobar=dict(type='str', no_log=True, fallback=(env_fallback, 'ANSIBLE_FOOBAR')),
        barbar=dict(type='str', no_log=True, fallback=(env_fallback, 'ANSIBLE_BARBR')),
        bazbar=dict(type='str', no_log=True, fallback=(env_fallback, 'ANSIBLE_BAZBR')),
    )

# Generated at 2022-06-22 21:59:15.675410
# Unit test for function set_fallbacks
def test_set_fallbacks():
    SOME_ENV = 'SOME_ENV'
    SOME_OTHER_ENV = 'SOME_OTHER_ENV_VAR'
    TEST_ENV_VALUE = 'TEST_ENV_VALUE'
    TEST_OTHER_ENV_VALUE = 'TEST_OTHER_ENV_VALUE'

    def mock_env_fallback(env_var):
        if env_var == SOME_ENV:
            return TEST_ENV_VALUE
        if env_var == SOME_OTHER_ENV:
            return TEST_OTHER_ENV_VALUE


# Generated at 2022-06-22 21:59:24.455026
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['FOO'] = 'bar'
    assert env_fallback('FOO') == 'bar'
    os.environ['ANSIBLE_FOO'] = 'baz'
    assert env_fallback('FOO', 'ANSIBLE_FOO') == 'baz'
    del os.environ['ANSIBLE_FOO']
    del os.environ['FOO']
    try:
        env_fallback()
        assert False, "should have thrown AnsibleFallbackNotFound"
    except AnsibleFallbackNotFound:
        pass



# Generated at 2022-06-22 21:59:35.219397
# Unit test for function set_fallbacks
def test_set_fallbacks():

    argument_spec = {
        "test_parameter": {
            "type": "str",
            "fallback": (env_fallback, "TEST_PARAMETER")
        },
        "test_parameter2": {
            "type": "str",
            "fallback": (env_fallback, ["TEST_PARAMETER"], {'default': 'TEST_DEFAULT'})
        },
        "test_parameter3": {
            "type": "str",
            'no_log': True,
            "fallback": (env_fallback, "TEST_PARAMETER")
        },
    }

    parameters = {}

    os.environ["TEST_PARAMETER"] = "env_fallback"

# Generated at 2022-06-22 21:59:41.672595
# Unit test for function remove_values
def test_remove_values():
    from ansible.module_utils.common.collections import ImmutableDict

    c1 = {'foo': 1, 'bar': 2, 'baz': 3}
    c2 = [1, 2, 3]
    c3 = (1, 2, 3)
    c4 = 'foobar'
    c5 = u'foobar'
    c6 = ImmutableDict(c1)
    c7 = frozenset(c2)

    # Test simple string
    # Test Unicode string
    # Test type that isn't a container type
    for c in [c4, c5, c6]:
        assert id(c) == id(remove_values(c, ['foo']))

    # Test container type that contains no sub-containers

# Generated at 2022-06-22 21:59:54.398180
# Unit test for function remove_values
def test_remove_values():
    import collections
    t1 = collections.OrderedDict()
    t1["a"] = "b"
    t1["c"] = "d"
    t1["e"] = {}
    t1["e"]["f"] = "g"
    t1["e"]["h"] = "i"
    t1["j"] = ["l", "m", "n"]
    t1["o"] = ["p", "q", "r"]
    t1["o"][1] = {}
    t1["o"][1]["s"] = "t"
    t1["o"][1]["u"] = "v"
    t1["o"][1]["w"] = "z"
    t1["m"] = {}
    t1["m"]["x"] = "y"
   

# Generated at 2022-06-22 22:00:06.743790
# Unit test for function remove_values
def test_remove_values():
    import copy
    import uuid

    # test data
    skip = ['skip', 'me']
    private = ['private', 'me']
    private_dict = {'sensitive': 'password', 'also_sensitive': 'passw0rd'}
    private_dict_copy = copy.deepcopy(private_dict)
    private_list = ['password', 'passw0rd']
    private_set = set(['password', 'passw0rd'])

    original_data = {'a': 'keep this', 'b': private_dict, 'c': private, 'd': private_list, 'e': skip, 'f': private_set}
    original_data_copy = copy.deepcopy(original_data)

    # expected data

# Generated at 2022-06-22 22:00:15.484514
# Unit test for function env_fallback
def test_env_fallback():
    """Test env_fallback function"""

    try:
        env_fallback('a', 'b')
        got = False
    except AnsibleFallbackNotFound:
        got = True

    assert got, 'env_fallback should raise AnsibleFallbackNotFound if none of the args are in os.environ'

    def mock_getenv(key, default=None):
        if key == 'a':
            return 'b'
        else:
            raise KeyError

    with patch('ansible.module_utils.common._ansible_utils.os.environ.get', mock_getenv):
        got = env_fallback('a', 'b')
        assert got == 'b', 'env_fallback should return os.environ["a"]'



# Generated at 2022-06-22 22:00:19.496469
# Unit test for function env_fallback
def test_env_fallback():
    with patch.dict('os.environ', {'TEST_ENV_VAR': 'TEST_ENV_VALUE'}):
        assert env_fallback('TEST_ENV_VAR') == 'TEST_ENV_VALUE'
    assert env_fallback('TEST_ENV_NON_EXISTENT_VAR') == 'ansible'



# Generated at 2022-06-22 22:00:30.096025
# Unit test for function sanitize_keys
def test_sanitize_keys():
    from collections import Mapping, Sequence, Set
    from random import randrange
    # Classes that we want to be able to sanitize
    container_types = (Mapping, Sequence, Set)
    # Classes that we want to ignore
    ignore_types = (int, float, binary_type, text_type)
    def generate_recursive(depth, ignore_keys=frozenset()):
        nonlocal container_types, ignore_types
        if depth == 0:
            # Return random non-container, non-ignored object
            while True:
                candidate = object()
                if not isinstance(candidate, container_types + ignore_types):
                    return candidate

# Generated at 2022-06-22 22:00:42.681373
# Unit test for function sanitize_keys
def test_sanitize_keys():
    """Test sanitize_keys function"""


# Generated at 2022-06-22 22:00:46.490024
# Unit test for function env_fallback
def test_env_fallback():
    TEST_ENV = {'FOO': '1', 'BAR': '2'}
    assert env_fallback('FOO', 'BAR') == '1'
    assert env_fallback('BAR') == '2'
    assert env_fallback('BAZ') == AnsibleFallbackNotFound


# Generated at 2022-06-22 22:00:50.453189
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('ANOTHER_TEST_VAR', 'TEST_VAR') == 'bar'
    assert env_fallback('TEST_VARIABLE') == 'foo'
    assert env_fallback('TEST_VARIABLE') == 'foo'



# Generated at 2022-06-22 22:00:56.496253
# Unit test for function env_fallback
def test_env_fallback():
    ''' Test fallback to environment variables '''
    os.environ['ANSIBLE_TEST_ENVIRONMENT'] = 'from_env'
    assert env_fallback('ANSIBLE_TEST_ENVIRONMENT') == 'from_env'
    del os.environ['ANSIBLE_TEST_ENVIRONMENT']



# Generated at 2022-06-22 22:01:07.211005
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # I'm paranoid about what happens if argument_spec is really
    # huge.  So I should test for it.
    for argument_spec in [
            {},
            {"param1": {"fallback": (lambda: True,)}}
            ]:
        for parameters in [
                {},
                {"param1": ""},
                {"param1": False, "param2": "my string"}
                ]:
            parameters = parameters.copy()
            no_log_values = set_fallbacks(argument_spec, parameters)
            assert(len(no_log_values) == 0)
        # fallback that should work
        parameters = {"param1": "Going Down"}
        no_log_values = set_fallbacks(argument_spec, parameters)
        assert(len(no_log_values) == 0)

        # check that no

# Generated at 2022-06-22 22:01:13.564745
# Unit test for function set_fallbacks
def test_set_fallbacks():
    spec = {
        'one': {'type': 'int', 'fallback': (42,)},
        'two': {'type': 'int', 'fallback': (env_fallback, 'xyz')},
        'three': {'type': 'int', 'fallback': (env_fallback, ['abc', 'xyz'])},
        'four': {'type': 'int', 'fallback': (env_fallback, 'xyz', {'default': 42})},
        'five': {'type': 'int', 'fallback': (env_fallback, 'xyz', {'key': 'val'})},
    }
    parameters = {}
    os.environ['abc'] = '42'

    # Test a custom fallback function
    assert set_fallbacks(spec, parameters) == set()
    assert parameters

# Generated at 2022-06-22 22:01:19.369532
# Unit test for function sanitize_keys
def test_sanitize_keys():
    from collections import OrderedDict
    assert sanitize_keys(OrderedDict([('foo', 'bar'), ('baz', ['quux'])]), ['bar', 'quux']) == OrderedDict([('foo', '*****'), ('baz', ['******'])])
