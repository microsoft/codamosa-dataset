

# Generated at 2022-06-20 16:05:30.349827
# Unit test for function set_fallbacks
def test_set_fallbacks():
    """Test setting fallback values."""

# Generated at 2022-06-20 16:05:36.239760
# Unit test for function sanitize_keys
def test_sanitize_keys():
    test_dict = dict(
        dict_key=dict(
            dict_key2=1
        ),
        dict_key2=2,
        dict_key3=3
    )

    no_log_strings = [to_native('dict_')]
    ignore_keys = set(['_ansible_ssh_host'])
    expected_dict = dict(
        dict_key='value_removed',
        dict_key2='value_removed',
        dict_key3='value_removed'
    )

    actual_dict = sanitize_keys(test_dict, no_log_strings, ignore_keys)

    assert actual_dict == expected_dict



# Generated at 2022-06-20 16:05:41.171857
# Unit test for function sanitize_keys
def test_sanitize_keys():
    # test for dict
    assert sanitize_keys({'a': 1, 'b': 2}, ['a']) == {'b': 2}
    # test for list
    assert sanitize_keys(['a', 'b'], ['a']) == ['b']
    # test for set
    assert sanitize_keys(set(['a', 'b']), ['a']) == set(['b'])
    # test for ignore keys
    assert sanitize_keys({'a': 1, 'b': 2}, ['a'], ignore_keys=set(['a'])) == {'a': 1, 'b': 2}
    # test for nested dict
    assert sanitize_keys({'a': {'a': 1, 'b': 2}, 'b': 2}, ['a']) == {'b': 2}


# Generated at 2022-06-20 16:05:45.966523
# Unit test for function remove_values
def test_remove_values():
    def test_equality(value, no_log_strings, expected):
        new_value = remove_values(value, no_log_strings)
        assert new_value == expected
        assert isinstance(new_value, type(expected))

    test_equality('string', [], 'string')
    test_equality('string', ['string'], '')
    test_equality('string', ['ring', 'ing'], 'st')

    test_equality(1, [], 1)
    test_equality(1, [1], 1)

    test_equality(True, [], True)
    test_equality(True, [True], True)

    test_equality(False, [], False)
    test_equality(False, [False], False)

    test_equality(None, [], None)

# Generated at 2022-06-20 16:05:51.973822
# Unit test for function env_fallback
def test_env_fallback():
    with patch('os.environ', {'FOO': 'bar', 'foo': 'bar'}):
        assert 'bar' == env_fallback('FOO')
        assert 'bar' == env_fallback('FOO', 'FOO1')
        assert 'bar' == env_fallback('FOO', 'FOO1', 'foo')
        assert 'bar' == env_fallback('baz', 'FOO', 'FOO1', 'foo')
        assert_raises(AnsibleFallbackNotFound, env_fallback, 'baz', 'FOO1')


# Generated at 2022-06-20 16:06:02.046817
# Unit test for function remove_values
def test_remove_values():

    # Intentionally trigger a maximum recursion depth exception
    # When fixed, it should only trigger a RuntimeError
    with pytest.raises(RuntimeError):
        objs = [{'_ansible_no_log': True}]
        for i in range(0, 500):
            objs.append(deepcopy(objs))

        no_log_strings = ['_ansible_no_log']
        remove_values(objs, no_log_strings)

    # Test for _sanitize_keys_conditions function
    assert sanitize_keys('_ansible_no_log', ['_ansible_no_log']) == 'sanitized_keys'
    assert sanitize_keys('no_log_match', ['no_log_match']) == 'no_log_match'
    assert sanitize_

# Generated at 2022-06-20 16:06:13.874719
# Unit test for function set_fallbacks

# Generated at 2022-06-20 16:06:20.157494
# Unit test for function sanitize_keys
def test_sanitize_keys():

    test_data = {
        'valid': {
            'value': 'foo',
            '_ansible_no_log': True,
        }
    }

    expected_data = {
        'valid_1': {
            'value': 'foo',
            '_ansible_no_log': True,
        }
    }

    results = sanitize_keys(test_data, no_log_strings=('foo',))

    assert_equals(results, expected_data)



# Generated at 2022-06-20 16:06:32.656852
# Unit test for function remove_values
def test_remove_values():
    # Simple test.
    value = chr(0xa9) + ' Ansible ' + chr(0xa9) + ' is awesome'
    no_log_strings = ['is awesome']
    assert remove_values(value, no_log_strings) == chr(0xa9) + ' Ansible ' + chr(0xa9) + ' ' + "VALUE_SPECIFIED_IN_NO_LOG_PARAMETER"

    # Test a data structure.

# Generated at 2022-06-20 16:06:36.830864
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_STRATEGY']='debug'
    assert env_fallback("ANSIBLE_STRATEGY") == 'debug'


_DEFAULT_VALUES = {'lookup': ['env'], 'fallback': [env_fallback]}

# Generated at 2022-06-20 16:07:06.037453
# Unit test for function set_fallbacks
def test_set_fallbacks():
    test_arg_spec = {
        'param1': {'type': 'str', 'fallback': (env_fallback, 'PARAM1')},
        'param2': {'type': 'str', 'fallback': (env_fallback, 'PARAM2')},
        'param3': {'type': 'str', 'fallback': (env_fallback, 'PARAM3')},
    }

    test_parameters = {
        'param1': None,
        'param2': None,
        'param3': 'param3',
    }

    res = set_fallbacks(test_arg_spec, test_parameters)
    assert not res

    test_parameters['param2'] = 'param2'
    os.environ['PARAM2'] = 'env_param2'

    res = set_

# Generated at 2022-06-20 16:07:12.129459
# Unit test for function remove_values
def test_remove_values():
    assert remove_values('abcd', ['bc']) == 'ad'
    assert remove_values('a b c d', ['bc']) == 'a   d'
    assert remove_values('abcd', ['bc', 'b']) == 'ad'
    assert remove_values('foobar', ['[a-zA-Z0-9]', 'a']) == ''
    assert remove_values('a', ['a', 'b']) == ''

    assert remove_values(OrderedDict([('b', '2'), ('a', '1')]), ['[a-zA-Z0-9]', 'a']) == OrderedDict([('b', '2'), ('', '')])

# Generated at 2022-06-20 16:07:22.396531
# Unit test for function remove_values
def test_remove_values():
    """
    Test the result of removing "no log" values from output
    """
    no_log_strings = ['password', 'secret', 'private', 'token', 'passphrase', 'secret_key']

# Generated at 2022-06-20 16:07:32.238402
# Unit test for function remove_values
def test_remove_values():
    """Test that private values are removed from data structures as expected."""

    # no_log_strings are python strings
    no_log_strings = ['bar']

    # Try a string
    original = 'foo bar baz'
    new_value = remove_values(original, no_log_strings)
    assert new_value == 'foo *** baz'

    # Try a list
    original = ['foo', 'bar', 'baz']
    new_value = remove_values(original, no_log_strings)
    assert new_value == ['foo', '***', 'baz']

    # Try a dictionary
    original = {'foo': 'foo', 'bar': 'bar', 'baz': 'baz'}
    new_value = remove_values(original, no_log_strings)

# Generated at 2022-06-20 16:07:40.943156
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'param1': dict(type='str', fallback=(env_fallback, 'ABC')),
                     'param2': dict(type='str', fallback=(env_fallback, 'XYZ'))}
    parameters = {'param1': 'AAA'}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['param1'] == 'AAA'
    assert parameters['param2'] == 'XYZ'
    assert len(no_log_values) == 0

    parameters = {'param2': 'XXX'}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['param1'] == 'ABC'
    assert parameters['param2'] == 'XXX'
    assert len(no_log_values) == 0


# Generated at 2022-06-20 16:07:54.088213
# Unit test for function set_fallbacks
def test_set_fallbacks():
    '''Test set_fallbacks()'''
    assert len(set_fallbacks({'test': dict(required=False, fallback=(env_fallback, 'TEST_ENV_VAR'))}, {})) == 0
    assert len(set_fallbacks({'test': dict(required=False, fallback=(env_fallback, 'NOT_EXIST'))}, {})) == 0
    assert len(set_fallbacks({'test': dict(required=False, fallback=(env_fallback, 'TEST_ENV_VAR'))}, {'test': 'test_value'})) == 0
    assert set(set_fallbacks({'test': dict(required=False, fallback=(env_fallback, 'TEST_ENV_VAR'))}, {}).keys()) == {'test'}



# Generated at 2022-06-20 16:08:05.436973
# Unit test for function sanitize_keys
def test_sanitize_keys():
    '''
    test function sanitize_keys
    '''
    os.environ["ANSIBLE_CONFIG"] = "../ansible.cfg"
    tmp_path = ansible_temp_path()
    ansible_cfg = os.path.join(tmp_path, "ansible.cfg")
    if not os.path.isfile(ansible_cfg):
        shutil.copy(os.path.join(HERE, os.pardir, "ansible.cfg"),
                    os.path.join(tmp_path, "ansible.cfg"))

    list_test = [{"key1": [{"key21": "value21"}, {"key22": "value22"}]}, {"key2": "value2"}]

# Generated at 2022-06-20 16:08:17.598692
# Unit test for function set_fallbacks

# Generated at 2022-06-20 16:08:29.349361
# Unit test for function sanitize_keys
def test_sanitize_keys():
    obj1 = {'k1': 'v1', 'k2': 'v2', 'no_log': 'v3'}
    obj2 = OrderedDict(obj1)
    obj3 = [obj1, obj2]
    obj4 = (obj1, obj2)

    test_obj = {'nonesuch': None, 'obj1': obj1, 'obj2': obj2, 'obj3': obj3, 'obj4': obj4}
    shadow_obj = {'nonesuch': None, 'obj1': obj1, 'obj2': obj2, 'obj3': obj3, 'obj4': obj4}

    # With no no_log strings, nothing changes
    result = sanitize_keys(test_obj, no_log_strings=[])
    assert result == shadow_obj

    # With no_

# Generated at 2022-06-20 16:08:32.845278
# Unit test for function sanitize_keys
def test_sanitize_keys():
  assert(sanitize_keys({'ansible_test':'test','password':'test_pwd'},['test','test_pwd'], ['ansible_test']) == {'ansible_test':'test', 'password':'REDACTED'})


# Generated at 2022-06-20 16:09:02.788228
# Unit test for function env_fallback
def test_env_fallback():
    '''env_fallback should return the first environment variable defined in args'''

    # Test all illegal parameters (including no parameters)
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback()
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback(None)
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback(None, None)
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('')
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('', '')

    # Test environment variable defined
    os.environ['ANSIBLE_TEST_ENV_FALLBACK_1'] = 'value1'
    assert env

# Generated at 2022-06-20 16:09:11.032914
# Unit test for function sanitize_keys
def test_sanitize_keys():
    structure = {
        'a': {
            'b': {
                'c': 1,
            },
            'd': {
                'f': 2,
            },
        },
        'e': [
            3,
            4,
            5,
            6,
            {
                'g': 7,
            },
        ],
    }

    # Sanitize the keys. This should remove the 'b' key and the 'g' key.
    new_structure = sanitize_keys(structure, {'b', 'g', 'f'})


# Generated at 2022-06-20 16:09:21.107205
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys(None, no_log_strings=set()) is None
    assert sanitize_keys('foo', no_log_strings=set()) == 'foo'
    assert sanitize_keys(1, no_log_strings=set()) == 1
    assert sanitize_keys(1.1, no_log_strings=set()) == 1.1
    assert sanitize_keys(tuple(), no_log_strings=set()) == tuple()
    assert sanitize_keys(set(), no_log_strings=set()) == set()
    assert sanitize_keys(dict(), no_log_strings=set()) == dict()
    assert sanitize_keys(list(), no_log_strings=set()) == list()

    # test simple mapping

# Generated at 2022-06-20 16:09:27.204825
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['TEST_ARG'] = "foo"
    assert env_fallback('TEST_ARG') == os.environ['TEST_ARG']
    assert env_fallback('BAR') == 'bar'
    assert env_fallback('THIS_DOES_NOT_EXIST') == 'baz'
    del os.environ['TEST_ARG']



# Generated at 2022-06-20 16:09:38.276545
# Unit test for function remove_values

# Generated at 2022-06-20 16:09:39.799095
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('gibberish') == 'gibberish'



# Generated at 2022-06-20 16:09:52.957469
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert 'test' == sanitize_keys('test', [])
    assert 'test' == sanitize_keys('test', ['test'])
    assert 'test' == sanitize_keys('test', ['test', 'pass'])
    assert 'test' == sanitize_keys('te********', ['test', 'pass'])
    assert 'te********' == sanitize_keys('te********', ['test', 'pass'])
    assert {'test': 'test'} == sanitize_keys({'test': 'test'}, ['test', 'pass'])
    assert {'te********': 'test'} == sanitize_keys({'te********': 'test'}, ['test', 'pass'])

# Generated at 2022-06-20 16:10:05.904576
# Unit test for function remove_values
def test_remove_values():
    from ansible.module_utils.six import string_types

    assert remove_values('s3cr3t', ['s3cr3t']) == '********'
    assert remove_values(None, ['s3cr3t']) is None
    assert remove_values('s3cr3t', ['n0th1ng']) == 's3cr3t'
    assert remove_values('s3cr3t', []) == 's3cr3t'

    assert remove_values([], ['s3cr3t']) == []
    assert remove_values(['s3cr3t'], ['s3cr3t']) == ['********']
    assert remove_values(['s3cr3t', 's3cr3t'], ['s3cr3t']) == ['********', '********']

# Generated at 2022-06-20 16:10:18.186313
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['FOO'] = 'BAR'
    assert env_fallback('FOO') == 'BAR'
    assert env_fallback('FOO', 'BAR') == 'BAR'
    assert env_fallback('BAR', 'FOO') == 'FOO'
    assert env_fallback('BAZ', 'BAR', 'FOO') == 'FOO'

    del os.environ['FOO']
    os.environ['BAR'] = 'FOO'
    assert env_fallback('FOO', 'BAR') == 'FOO'

    del os.environ['BAR']
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('FOO')



# Generated at 2022-06-20 16:10:23.914449
# Unit test for function remove_values
def test_remove_values():
    assert remove_values([0, 1, 2, 3, 4], no_log_strings={3}) == [0, 1, 2, 4]
    assert remove_values([0, 1, 2, 3, 4], no_log_strings={'a'}) == [0, 1, 2, 3, 4]
    assert remove_values({'a': 0, 'b': 1, 'c': 2, 'd': 3, 'e': 4, 'f': 'fast', 'g': 'forward', 'h': 'horse'}, no_log_strings={3}) == {'e': 4, 'f': 'fast', 'g': 'forward', 'h': 'horse'}

# Generated at 2022-06-20 16:10:57.534151
# Unit test for function remove_values
def test_remove_values():
    no_log_strings = set(['secret', 'password'])
    test_strings = dict(text='This is a secret')
    assert remove_values(test_strings, no_log_strings) == dict(text='This is a <value omitted>')
    test_strings = dict(text='This is a secret word')
    assert remove_values(test_strings, no_log_strings) == dict(text='This is a <value omitted> word')
    test_strings = dict(text='This is a password')
    assert remove_values(test_strings, no_log_strings) == dict(text='This is a <value omitted>')
    test_strings = dict(text='This is a password word')

# Generated at 2022-06-20 16:11:03.809944
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys({'foo': 'bar'}, ['bar']) == {'foo': 'bar'}
    assert sanitize_keys({'foo': 'bar'}, ['bar'], ignore_keys={'foo'}) == {'foo': 'bar'}
    assert sanitize_keys({'foo': 'bar'}, ['bar'], ignore_keys={'foo', '_ansible_item_result'}) == {'foo': 'bar'}
    assert sanitize_keys({'foo bar': 'bar'}, ['bar']) == {'foo***': 'bar'}
    assert sanitize_keys({False: 'bar'}, ['bar']) == {'false': 'bar'}

# Generated at 2022-06-20 16:11:12.109995
# Unit test for function sanitize_keys
def test_sanitize_keys():
    fail = False
    # test to see if string keys are being sanitized
    data = {
        'valid_key': 'valid_val',
        'invalid_key_sensitive_data': 'sensitive_data',
        'invalid_key_password': 'password',
        'invalid_key_private_key': 'private_key',
        'invalid_key_certificate': 'certificate',
        'invalid_key_authorization': 'authorization',
        'invalid_key_passphrase': 'passphrase',
    }
    no_log_strings = ['sensitive_data', 'password', 'private_key', 'certificate', 'authorization', 'passphrase']
    data = sanitize_keys(data, no_log_strings)

# Generated at 2022-06-20 16:11:17.601481
# Unit test for function env_fallback
def test_env_fallback():
    with mock.patch.dict('os.environ', {'ANSIBLE_NET_AUTHORIZE': 'yes'}):
        assert env_fallback('ANSIBLE_NET_AUTHORIZE') == 'yes'
    with pytest.raises(AnsibleFallbackNotFound):
        assert env_fallback('FOO_BAR_BAZ') == 'yes'


# Generated at 2022-06-20 16:11:25.545902
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('1', '2', '3') == '1'
    os.environ.pop('1', None)
    assert env_fallback('1', '2', '3') == '2'
    os.environ.pop('2', None)
    assert env_fallback('1', '2', '3') == '3'
    os.environ.pop('3', None)
    assert_raises(AnsibleFallbackNotFound, env_fallback, '1', '2', '3')



# Generated at 2022-06-20 16:11:37.066761
# Unit test for function set_fallbacks

# Generated at 2022-06-20 16:11:48.815684
# Unit test for function remove_values
def test_remove_values():
    # Test values from remove_values()
    assert remove_values('value', ['test']) == 'value'
    assert remove_values('test', ['test']) == 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'
    assert remove_values(['test'], ['test']) == ['VALUE_SPECIFIED_IN_NO_LOG_PARAMETER']
    assert remove_values(['value', 'test'], ['test']) == ['value', 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER']
    assert remove_values({'test': 'value'}, ['test']) == {'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER': 'value'}

# Generated at 2022-06-20 16:12:00.277258
# Unit test for function set_fallbacks

# Generated at 2022-06-20 16:12:12.224065
# Unit test for function remove_values
def test_remove_values():
    assert remove_values([1, 2], []) == [1, 2]
    assert remove_values("1,2", []) == "1,2"
    assert remove_values({"a": 1, "b": 2}, []) == {"a": 1, "b": 2}

    assert remove_values([1, 2], [2]) == [1]
    assert remove_values("1,2", [","]) == "12"
    assert remove_values({"a": 1, "b": 2}, ["b"]) == {"a": 1}

    assert remove_values([1, 2, 3], [2, 3]) == [1]
    assert remove_values("1,2,3", [","]) == "123"

# Generated at 2022-06-20 16:12:20.756745
# Unit test for function set_fallbacks
def test_set_fallbacks():
    class FakeModule(object):
        def __init__(self, fail_json=None, params=None, ansible_facts=None):
            self.fail_json = fail_json
            self.params = params
            self.ansible_facts = ansible_facts

        def fail_json_in_clean(self, msg, **kwargs):
            self.fail_json(msg, **kwargs)

    class TestException(Exception):
        pass

    # Nested dict
    argument_spec = {'a': {'type': 'dict', 'options': {
        'b': {'type': 'str', 'fallback': (env_fallback, 'ANSIBLE_TEST_FAILBACK')}}}}
    parameters = {'a': {}}
    no_log_values = set_fallbacks(argument_spec, parameters)

# Generated at 2022-06-20 16:12:54.380329
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Test for no fallback and no parameters
    parameters = {}
    argument_spec = {'test_param': {}}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert no_log_values == set()
    assert parameters == {}

    # Test for success
    parameters = {}
    argument_spec = {'test_param': {'fallback': (env_fallback, 'TEST_PARAM_ENV')}}
    os.environ['TEST_PARAM_ENV'] = 'test_val'
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert no_log_values == set()
    assert parameters == {'test_param': 'test_val'}

    # Test for failure
    parameters = {}

# Generated at 2022-06-20 16:13:04.535073
# Unit test for function remove_values
def test_remove_values():
    no_log_values = [
        'foo',
        u'bar',
        u'baz'
    ]

    value = [
        'foo',
        'bar baz',
        u'baz',
        {
            'foo': 'bar',
            'bar': 'baz baz',
            'baz': 'foo foo',
            'spam': {
                'eggs': 'baz baz foo'
            }
        },
        [
            'foo',
            'bar'
        ],
        (
            'foo',
            'bar'
        ),
        frozenset([
            'baz',
            'foo'
        ]),
        {
            frozenset(),
            frozenset([
                'foo'
            ])
        }
    ]


# Generated at 2022-06-20 16:13:13.177062
# Unit test for function set_fallbacks
def test_set_fallbacks():
    env_fallback_called = False
    def env_fallback(*args, **kwargs):
        nonlocal env_fallback_called
        env_fallback_called = True
        params = {'one': {'required': True, 'fallback': (env_fallback, 'ONE')}}
        if args[0] in os.environ:
            return os.environ[args[0]]
        raise AnsibleFallbackNotFound
    orig_env_fallback = __builtin__.__dict__.get('env_fallback')


# Generated at 2022-06-20 16:13:18.345236
# Unit test for function sanitize_keys
def test_sanitize_keys():

    assert sanitize_keys(None, set()) == None
    assert sanitize_keys("1234", set()) == "1234"
    assert sanitize_keys({'a': 'b'}, set()) == {'a': 'b'}
    assert sanitize_keys({'no_log': 'b'}, set()) == {'no_log': 'b'}
    assert sanitize_keys({'no_log': 'b'}, {'b'}) == {'no_lo': 'b'}
    assert sanitize_keys({'a': 'no_log'}, {'no_log'}) == {'a': 'no_log'}
    assert sanitize_keys({'a': 'no_log'}, {'a'}) == {'a': 'no_log'}
    assert san

# Generated at 2022-06-20 16:13:20.972793
# Unit test for function env_fallback
def test_env_fallback():

    os.environ['ANSIBLE_FOO'] = 'bar'
    assert env_fallback('ANSIBLE_FOO') == 'bar'



# Generated at 2022-06-20 16:13:29.339539
# Unit test for function sanitize_keys
def test_sanitize_keys():
    """Unit test for function sanitize_keys"""
    # no_log strings
    no_log_strings = ['foo', 'bar']
    # ignore_keys
    ignore_keys = ['foo']
    # Input string
    input_string = 'foo'
    # Expected output string
    output_string = 'foo'
    # Test for string
    output = sanitize_keys(input_string, no_log_strings, ignore_keys)
    assert output == output_string
    # Input list
    input_list = ['foo', 'bar']
    # Expected output list
    output_list = ['foo', 'XXX-REDACTED-XXX']
    # Test for list
    output = sanitize_keys(input_list, no_log_strings, ignore_keys)
    assert output == output_list
    # Input dict

# Generated at 2022-06-20 16:13:40.833506
# Unit test for function set_fallbacks

# Generated at 2022-06-20 16:13:46.858942
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_FOO'] = 'bar'
    assert env_fallback('ANSIBLE_FOO') == 'bar'
    assert env_fallback('ANSIBLE_BAR') == ''  # trigger AnsibleFallbackNotFound



# Generated at 2022-06-20 16:13:55.897704
# Unit test for function set_fallbacks
def test_set_fallbacks():
    """ Testcase to check if param & fallback values are getting set correctly """
    spec = dict(param=dict(type='str', required=True, fallback=(env_fallback, 'TEST_PARAM')))
    os.environ['TEST_PARAM'] = 'test'
    parameters = {}
    expected_result = dict(param='test')
    no_log_values = set_fallbacks(spec, parameters)
    assert parameters == expected_result
    assert len(no_log_values) == 0
    os.unsetenv('TEST_PARAM')



# Generated at 2022-06-20 16:14:03.665139
# Unit test for function set_fallbacks
def test_set_fallbacks():
    example_spec = dict(
        name=dict(type='str', fallback=('env_fallback', 'default')),
        age=dict(type='int'),
        friends=dict(type='list', elements='str'),
        info=dict(type='dict', options=dict(
            salary=dict(type='int', no_log=True),
            status=dict(type='str', fallback=(env_fallback, 'default'))
        ))
    )
    parameters = dict(name='zixia')
    assert set_fallbacks(example_spec, parameters) == set()
    assert parameters['name'] == 'zixia'
    assert 'age' not in parameters
    assert 'friends' not in parameters
    assert 'info' not in parameters



# Generated at 2022-06-20 16:14:39.985677
# Unit test for function remove_values
def test_remove_values():
    """Test functionality of ``remove_values``"""


# Generated at 2022-06-20 16:14:44.757239
# Unit test for function sanitize_keys
def test_sanitize_keys():
    # Verify function is called recursively
    key_name = 'test_sanitized_key'
    test_dict = {key_name: 'value'}
    params = {'no_log_values': {}}
    expected_dict = dict(
        test_sanitized_key='value')
    assert expected_dict == sanitize_keys(test_dict, params['no_log_values'])



# Generated at 2022-06-20 16:14:54.575547
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(test_str=dict(type='str', fallback=(env_fallback, 'ANSIBLE_TEST_STR')),
                         test_float=dict(type='float', fallback=(env_fallback, 'ANSIBLE_TEST_FLOAT')),
                         test_list=dict(type='list', fallback=(env_fallback, 'ANSIBLE_TEST_LIST'), elements='str')
                         )
    parameters = dict()
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['test_str'] == os.environ['ANSIBLE_TEST_STR']
    assert parameters['test_float'] == float(os.environ['ANSIBLE_TEST_FLOAT'])
    assert parameters['test_list'] == ['t3', 't4']
   