

# Generated at 2022-06-20 16:05:34.220895
# Unit test for function sanitize_keys
def test_sanitize_keys():
    no_log_strings = [to_text(u'NotForLogging')]

    def _sanitize_keys_wrapper(data, no_log_strings=no_log_strings, ignore_keys=set()):
        return sanitize_keys(data, no_log_strings, ignore_keys)

    # Test dict keys
    assert _sanitize_keys_wrapper({'abc': 'abc', 'abcNotForLogging': 'abc', 'abcNotForLoggingNotForLogging': 'abc'}) ==\
        {'abc': 'abc', '_ansible_no_log_values': {'abcNotForLogging': 'abc', 'abcNotForLoggingNotForLogging': 'abc'}}

    # Test nested dict keys

# Generated at 2022-06-20 16:05:37.138144
# Unit test for function env_fallback
def test_env_fallback():
    with patch.object(builtins, 'environ', {'ANSIBLE_VAR': 'ANSIBLE_VAR_VALUE_FROM_ENV'}):
        assert env_fallback('ANSIBLE_VAR') == 'ANSIBLE_VAR_VALUE_FROM_ENV'
    assert env_fallback('ANSIBLE_VAR_NOT_EXISTS_IN_ENV') == None


# Generated at 2022-06-20 16:05:41.944661
# Unit test for function sanitize_keys
def test_sanitize_keys():
    """
    Test function for sanitize_keys
    """
    # Try sanitizing keys in a dict
    thing = {'a': 'b', 'sensitive': 'abc123', '_ansible_sensitive': 'def456', '_ansible_no_log': True}
    outcome = {'a': 'b', '_ansible_sensitive': 'def456', '_ansible_no_log': True, 'sensitive': 'abc123'}

    assert(sanitize_keys(thing, ['abc123']) == outcome)

    # Try sanitizing keys in a list of dicts
    thing = [{'a': 'b', 'sensitive': 'abc123', '_ansible_sensitive': 'def456', '_ansible_no_log': True}]

# Generated at 2022-06-20 16:05:47.766127
# Unit test for function env_fallback
def test_env_fallback():
    with patch.dict(os.environ, {'ANSIBLE_NET_TRANSPORT': 'netconf'}, clear=True):
        assert env_fallback('ANSIBLE_NET_TRANSPORT') == 'netconf'
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('ANSIBLE_NET_TRANSPORT')



# Generated at 2022-06-20 16:06:00.317903
# Unit test for function set_fallbacks
def test_set_fallbacks():
    '''Test that set_fallbacks works as expected.'''

    args = dict(param1='value1', param2='value2', param3='value3', param4='value4', param5='value5', param6='value6')
    param1_spec = dict(type='str', fallback=(env_fallback, ['PARAM1_ENV']))
    param2_spec = dict(type='str', fallback=(env_fallback, ['PARAM2_ENV']))
    param3_spec = dict(type='str', fallback=(env_fallback, ['PARAM3_ENV']))
    param4_spec = dict(type='str', no_log=False, fallback=(env_fallback, ['PARAM4_ENV']))

# Generated at 2022-06-20 16:06:07.541693
# Unit test for function set_fallbacks
def test_set_fallbacks():

    argument_spec = {'secret': {'required': False, 'type': 'int', 'fallback': [env_fallback, 'SECRET']},
                     'password': {'required': False, 'type': 'int', 'fallback': [env_fallback, 'DUMMY'], 'no_log': True}}
    parameters = {'password': 'test'}

    no_log_values = set_fallbacks(argument_spec, parameters)
    assert 'test' in no_log_values



# Generated at 2022-06-20 16:06:09.934231
# Unit test for function env_fallback
def test_env_fallback():
    """Test env_fallback function"""

    assert env_fallback('THIS_VAR_DOESNT_EXIST') is None



# Generated at 2022-06-20 16:06:12.789420
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('SUDO_UID') == os.environ['SUDO_UID']



# Generated at 2022-06-20 16:06:22.110697
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'foo': {'type': 'str'},
        'bar': {'fallback': (env_fallback, 'BAR_ENV_VAR')},
    }

    parameters = {'foo': 'foo value'}

    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters == {'foo': 'foo value', 'bar': 'bar value'}
    assert no_log_values == set()

    os.environ.pop('BAR_ENV_VAR', None)
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters == {'foo': 'foo value', 'bar': 'bar value'}
    assert no_log_values == set()



# Generated at 2022-06-20 16:06:35.228852
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Test with env_fallback
    assert set_fallbacks(dict(a=dict(fallback=(env_fallback, 'FOO'))), {}) == {'FALLBACK'}
    assert set_fallbacks(dict(a=dict(fallback=(env_fallback, 'FOO'))), {'a': 'b'}) == set()
    assert set_fallbacks(dict(a=dict(fallback=(env_fallback, 'FOO'), no_log=True)), {}) == {'FALLBACK'}
    assert set_fallbacks(dict(a=dict(fallback=(env_fallback, 'FOO'), no_log=False)), {}) == set()

    # Test with custom fallback
    def fallback(param):
        if param == 'FOO':
            return 'BAR'
        raise

# Generated at 2022-06-20 16:07:30.177574
# Unit test for function set_fallbacks
def test_set_fallbacks():
    import sys
    if len(sys.argv) > 1 and sys.argv[1] == 'set_fallbacks':
        params = dict()
        cdict = dict(parameters=params)
        cdict['parameters']['foo'] = 'bar'
        set_fallbacks(dict(foo={'type': 'str', 'default': 'baz'}), cdict['parameters'])
        set_fallbacks(dict(foo={'type': 'str', 'default': 'baz', 'fallback': (env_fallback, 'fizz')}), cdict['parameters'])

        print(cdict)
        assert cdict['parameters']['foo'] == 'bar'
        assert cdict['parameters']['foo'] == 'baz'



# Generated at 2022-06-20 16:07:40.636214
# Unit test for function remove_values
def test_remove_values():
    obj = {'omit_this': 'forget_me', 'this_should': 'stay'}
    no_log_strings = ['forget_me']
    new_obj = remove_values(obj, no_log_strings)
    assert_equal(new_obj, {'this_should': 'stay'})

    obj = {'omit_this': 'forget_me', 'this_should': 'stay', 'this_is_a_list': ['forget_me', 'stay', 'forget_me']}
    no_log_strings = ['forget_me']
    new_obj = remove_values(obj, no_log_strings)
    assert_equal(new_obj, {'this_is_a_list': ['', 'stay', ''], 'this_should': 'stay'})


# Generated at 2022-06-20 16:07:50.765735
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['TEST_ENV_FALLBACK'] = 'TESTVALUE'
    assert env_fallback('TEST_ENV_FALLBACK') == 'TESTVALUE'
    del os.environ['TEST_ENV_FALLBACK']
    assert env_fallback('TEST_ENV_FALLBACK') == 'TESTVALUE'
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('TEST_ENV_FALLBACK', 'ANOTHER_ENV_VARIABLE')



# Generated at 2022-06-20 16:07:58.186878
# Unit test for function remove_values
def test_remove_values():
    import pytest

    for item in ['test','test','test']:
        item = remove_values(item, ['test'])
        assert item == CENSORED

    for item in ['foo', {'bar': 'test'}, ['test']]:
        item = remove_values(item, ['test'])
        assert item == [{'bar': CENSORED}, [CENSORED]]

    assert remove_values(['test', 'test', 'test'], ['test']) == [CENSORED, CENSORED, CENSORED]
    assert remove_values(('test', 'test', 'test'), ['test']) == (CENSORED, CENSORED, CENSORED)

# Generated at 2022-06-20 16:08:02.768536
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ENV_AVAILABLE'] = 'AVAILABLE'
    assert env_fallback('ENV_AVAILABLE') == 'AVAILABLE'
    assert env_fallback('NOT_AVAILABLE') == None



# Generated at 2022-06-20 16:08:11.033835
# Unit test for function env_fallback
def test_env_fallback():
    assert len(os.environ) == 0
    os.environ['ANSIBLE_FOO_BAR'] = 'foo'
    assert env_fallback('ANSIBLE_FOO_BAR') == 'foo'
    ret = env_fallback('ANSIBLE_KLOBBER_ME')
    assert isinstance(ret, AnsibleFallbackNotFound)
    assert 'ANSIBLE_KLOBBER_ME' not in os.environ
try:
    os.environ.pop('ANSIBLE_FOO_BAR')
except KeyError:
    pass



# Generated at 2022-06-20 16:08:18.770852
# Unit test for function remove_values
def test_remove_values():
    """Unit test for function remove_values"""

    # Normal operation on strings
    assert remove_values('testvalue', ('testvalue',)) == 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'
    assert remove_values('testvaluetestvalue', ('testvalue',)) == 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETERVALUE_SPECIFIED_IN_NO_LOG_PARAMETER'

    # Normal operation on lists
    assert remove_values(['testvalue'], ('testvalue',)) == ['VALUE_SPECIFIED_IN_NO_LOG_PARAMETER']

    # Normal operation on sequences
    test_seq = sequence.Sequence('abcdefg')

# Generated at 2022-06-20 16:08:30.446365
# Unit test for function env_fallback
def test_env_fallback():
    # pylint: disable=protected-access
    # Test 1, no args
    actual = AnsibleFallbackNotFound
    try:
        env_fallback('ENV_FALLBACK_DOES_NOT_EXIST')
    except AnsibleFallbackNotFound:
        actual = AnsibleFallbackNotFound
    assert actual is AnsibleFallbackNotFound
    # Test 2, arg present
    actual = 'CASCADE'
    os.environ['ANSIBLE_ACTION_PLUGINS'] = 'CASCADE'
    try:
        env_fallback('ANSIBLE_ACTION_PLUGINS')
    except AnsibleFallbackNotFound:
        actual = None
    assert actual == 'CASCADE'
    # Test 3, multiple args, one present
    actual = 'CASCADE'

# Generated at 2022-06-20 16:08:36.302510
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        test_parameter=dict(
            type='str',
            fallback=(env_fallback, ['TEST_PARAMETER_ENV'])
        ),
        test_parameter2=dict(
            type='str',
            no_log=True,
            fallback=(env_fallback, ['TEST_PARAMETER2_ENV'])
        )
    )
    # Set envvars test
    os.environ['TEST_PARAMETER_ENV'] = 'test_value'
    os.environ['TEST_PARAMETER2_ENV'] = 'test_value2'

    parameters = {}

    no_log_values = set_fallbacks(argument_spec, parameters)


# Generated at 2022-06-20 16:08:45.870666
# Unit test for function remove_values
def test_remove_values():
    """Test remove_values with various container-type objects."""

    assert remove_values('test', ['test']) is None
    assert remove_values('not_removed', ['test']) == 'not_removed'

    assert remove_values({'test': 'test'}, ['test']) is None
    assert remove_values({'test': 'test', 'not_removed': 'not_removed'}, ['test']) == {'not_removed': 'not_removed'}

    assert remove_values(('test',), ['test']) is None
    assert remove_values(('not_removed',), ['test']) == ('not_removed',)

    assert remove_values(['test'], ['test']) is None

# Generated at 2022-06-20 16:09:21.147479
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys({'a': 'a'}, ['a']) == {'_a': 'a'}
    assert sanitize_keys([1, 2, 3, 'a'], ['a']) == [1, 2, 3, '_a']
    assert sanitize_keys({'a': 'b', 'b': 'a'}, ['a']) == {'_a': 'b', 'b': '_a'}
    assert sanitize_keys({'a_a': 'a_a'}, ['a', '_']) == {'__a': 'a_a'}
    assert sanitize_keys({'a_a': {'a_a': 'a_a'}}, ['a', '_']) == {'__a': {'__a': 'a_a'}}
   

# Generated at 2022-06-20 16:09:32.365365
# Unit test for function remove_values
def test_remove_values():
    """Unit tests for function remove_values"""
    import copy

    no_log_strings = frozenset({'password', 'passwd', 'PWD'})

    assert remove_values('foo', no_log_strings) == 'foo'


# Generated at 2022-06-20 16:09:42.445764
# Unit test for function remove_values
def test_remove_values():
    # This is a test code for the function remove_values()
    # Remove the give string values from the value
    # If the value is a container type, remove the given string values from the value recursively
    class Obj(object):
        def __init__(self, value):
            self.value = value

    class Obj2(object):
        def __init__(self, value):
            self.value = value

    def obj_filter_func(obj):
        return obj.value != 'no_log_test_value'

    v1 = {'k1': 'v1', 'k2': 'no_log_test_value'}
    v2 = ('v1', 'no_log_test_value', 'v3', 'v4')

# Generated at 2022-06-20 16:09:54.122776
# Unit test for function remove_values
def test_remove_values():
    from ansible.module_utils.common._collections_compat import Sequence
    from ansible.module_utils.common._collections_compat import MutableSequence, MutableSet, Mapping
    class TestObject(object):
        def __init__(self, d):
            self.__dict__ = d

    d1 = dict(key='value')
    d2 = dict(key='value', key2=dict(key3='value'))
    d3 = dict(key='value', key2=dict(key3='value', key4=['v1', 'v2']))
    d4 = dict(key='value', key2=dict(key3='value', key4=['v1', 'v2', dict(key5='v3')]))

# Generated at 2022-06-20 16:10:04.035099
# Unit test for function remove_values
def test_remove_values():
    """
    Basic test of remove_values.
    """
    assert remove_values(None, None) is None
    assert remove_values(None, [None]) is None
    assert remove_values('foo', ['foo']) is None
    assert remove_values(True, [True]) is None
    assert remove_values(False, [False]) is None
    assert remove_values(1, [1]) is None
    assert remove_values(1, ['1']) is None
    assert remove_values('foo', ['bar']) == 'foo'
    assert remove_values('foo', ['FOO']) == 'foo'
    assert remove_values({}, ['foo']) == {}
    assert remove_values({'foo': 'bar'}, ['foo']) == {}

# Generated at 2022-06-20 16:10:12.628667
# Unit test for function env_fallback
def test_env_fallback():
    # Returns environment variable if it exists
    assert env_fallback('HOME') == os.environ['HOME']

    # Raise exception otherwise
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('UNDEFINED_ENV_VAR')


# Generated at 2022-06-20 16:10:17.549066
# Unit test for function sanitize_keys
def test_sanitize_keys():
    # no_log_strings are just for verifying that the test works, real strings will be different
    # and computed from the argument spec
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    no_log_strings = {'3des-cbc', 'aes256-cbc'}

# Generated at 2022-06-20 16:10:19.792162
# Unit test for function env_fallback
def test_env_fallback():
    os.environ["ANSIBLE_STRATEGY"] = "free"
    assert env_fallback('ANSIBLE_STRATEGY') == 'free'
    assert env_fallback('ANSIBLE_FOO_BAR') == 'ANSIBLE_FOO_BAR'



# Generated at 2022-06-20 16:10:29.363117
# Unit test for function env_fallback
def test_env_fallback():

    os.environ['AZURE_CLIENT_ID'] = 'test'
    assert env_fallback('AZURE_CLIENT_ID') == 'test', "env_fallback failed with 'AZURE_CLIENT_ID'"
    del os.environ['AZURE_CLIENT_ID']

    os.environ['AZURE_CLIENT_ID'] = 'test'
    os.environ['AZURE_CLIENT_ID_1'] = 'test1'
    assert env_fallback('AZURE_CLIENT_ID_2', 'AZURE_CLIENT_ID_1', 'AZURE_CLIENT_ID') == 'test', \
        "env_fallback failed with 'AZURE_CLIENT_ID_2', 'AZURE_CLIENT_ID_1', 'AZURE_CLIENT_ID'"

# Generated at 2022-06-20 16:10:41.650083
# Unit test for function sanitize_keys
def test_sanitize_keys():
    strings = [b'sansible_ssh_pass', b'ansible_password']

# Generated at 2022-06-20 16:11:13.372335
# Unit test for function remove_values
def test_remove_values():
  no_log_strings = ['password', 'secret', 'private']
  value = {'name': 'Mary',
           'password': 'private',
           'friends': ['Joe', {'name': 'John', 'secret': 'password'}],
           'parents': [{'name': 'Mary', 'password': 'private'}, {'name': 'Alice', 'secret': 'password'}]}
  new_value = remove_values(value, no_log_strings)
  assert new_value['parents'][1]['secret'] == 'PRIVATE DATA HIDDEN'
  assert new_value['parents'][0]['password'] == 'PRIVATE DATA HIDDEN'
  assert new_value['friends'][1]['secret'] == 'PRIVATE DATA HIDDEN'

# Generated at 2022-06-20 16:11:23.154417
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_FOO'] = 'bar'
    os.environ['ANSIBLE_BAR'] = 'foo'
    assert 'bar' == env_fallback('ANSIBLE_FOO')
    assert 'foo' == env_fallback('ANSIBLE_BAR')
    assert 'bar' == env_fallback('FOO', 'ANSIBLE_FOO')
    assert 'foo' == env_fallback('BAR', 'ANSIBLE_BAR')
    assert 'bar' == env_fallback('FOO', 'BAR', 'ANSIBLE_FOO', 'ANSIBLE_BAR')
    assert 'foo' == env_fallback('BAR', 'FOO', 'ANSIBLE_BAR', 'ANSIBLE_FOO')
    with pytest.raises(AnsibleFallbackNotFound):
        env

# Generated at 2022-06-20 16:11:25.634951
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_ABC'] = 'abc'
    assert env_fallback('ANSIBLE_ABC') is not AnsibleFallbackNotFound



# Generated at 2022-06-20 16:11:37.596120
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        a=dict(type='str', fallback=(env_fallback, 'TEST_A')),
        b=dict(type='str', fallback=(env_fallback, 'TEST_B')),
        c=dict(type='str', fallback=(env_fallback, 'TEST_C')),
    )

    parameters = dict(
        a='foo',
        b='{{ test_b }}',
        c='{{ test_c }}',
    )

    with mock.patch.dict('os.environ', {'TEST_A': 'bar', 'TEST_B': 'bar', 'TEST_C': 'bar'}, clear=True):
        no_log_values = set_fallbacks(argument_spec, parameters)


# Generated at 2022-06-20 16:11:42.872589
# Unit test for function env_fallback
def test_env_fallback():
    # Test that it raises an exception
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('FOO')
    # Test that it returns the right value
    os.environ['FOO'] = 'BAR'
    assert env_fallback('FOO') == 'BAR'



# Generated at 2022-06-20 16:11:54.672872
# Unit test for function sanitize_keys
def test_sanitize_keys():
    no_log_strings = ['password', 'secret', 'login', 'private_key', 'passphrase', 'authorization', 'ssh-key']

# Generated at 2022-06-20 16:12:00.912650
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'new_name': {'required': True},
                     'name': {'required': False,
                              'fallback': (env_fallback, ['NAME'])}
                     }
    parameters = {'new_name': 'new'}
    os.environ['NAME'] = 'old'
    set_fallbacks(argument_spec, parameters)
    assert parameters['name'] == 'old'



# Generated at 2022-06-20 16:12:07.514230
# Unit test for function sanitize_keys
def test_sanitize_keys():
    obj = dict(a=1, b=2, c=3)
    expected_obj = dict(a=1, b=2, c=3)
    actual_obj = sanitize_keys(obj, set())
    assert actual_obj == expected_obj

    obj = dict(a=1, b=2, c=3)
    expected_obj = dict(a=1, b=2, c=3)
    actual_obj = sanitize_keys(obj, set(['c']))
    assert actual_obj == expected_obj

    obj = dict(a='password', b=2, c=3)
    expected_obj = dict(a='REDACTED', b=2, c=3)
    actual_obj = sanitize_keys(obj, set(['password']))
    assert actual_obj == expected_obj

# Generated at 2022-06-20 16:12:18.540329
# Unit test for function env_fallback
def test_env_fallback():
    testcase = (
        ('FOO', 'FOO', 'bar', {'FOO': 'bar'}, 'bar'),
        ('FOO', 'BAR', 'bar', {'FOO': 'baz'}, AnsibleFallbackNotFound),
        ('FOO', 'BAR', 'bar', {}, AnsibleFallbackNotFound),
        ((), 'BAR', 'bar', {'FOO': 'bar'}, AnsibleFallbackNotFound),
        (('FOO', 'BAR'), 'BAR', 'bar', {'BAR': 'bar'}, 'bar'),
        ('FOO', 'BAR', 'bar', {'FOO': None}, None),
        ('FOO', 'BAR', None, {'FOO': 'bar'}, 'bar'),
    )

# Generated at 2022-06-20 16:12:30.538347
# Unit test for function sanitize_keys
def test_sanitize_keys():
    # Setup
    original = {'foo': 'bar', 'baz': 'qux', 'quux': 'quuux', 'corge': 'grault'}
    changed_key = object()
    changed_value = object()
    expected = {'foo': 'bar', 'baz': 'qux', 'quux': 'quuux', changed_key: changed_value}
    test_str = "--sanitized--"
    replacements = {test_str: ""}

    changed_key = replacer(changed_key, replacements)
    changed_value = replacer(changed_value, replacements)

    # Test
    result = sanitize_keys(original, replacements.keys())

    # Verify
    assert result == expected
    assert result[changed_key] == changed_value



# Generated at 2022-06-20 16:13:02.053685
# Unit test for function env_fallback
def test_env_fallback():
    """Test env_fallback()'s ability to be called with multiple args and fall back to the last one."""
    import tempfile
    import subprocess
    temp_file = tempfile.NamedTemporaryFile()
    temp_file.write(u'export MY_ENV_FALLBACK_TEST_VAR="value"'.encode('utf-8'))
    temp_file.flush()

    # We must use shell=True here to actually source the file
    # https://github.com/ansible/ansible/pull/34263#issuecomment-270774665
    subprocess.check_call('source {0} ; env'.format(temp_file.name), shell=True)

    assert env_fallback('MY_ENV_FALLBACK_TEST_VAR') == "value"
    assert env_fall

# Generated at 2022-06-20 16:13:10.785586
# Unit test for function set_fallbacks
def test_set_fallbacks():
    param = 'param'
    fallback = 'fallback'
    param_spec = {
        param: {
            'type': 'str',
            'fallback': ('env_fallback', ['ENV'])
        }
    }
    env_before = dict(os.environ)
    # Test with no ENV
    parameters = {}
    set_fallbacks(param_spec, parameters)
    assert param not in parameters

    # Test with ENV
    os.environ['ENV'] = fallback
    parameters = {}
    set_fallbacks(param_spec, parameters)
    assert param in parameters
    assert parameters[param] == fallback

    # Test with no ENV but fallback present
    parameters = {param: fallback}
    set_fallbacks(param_spec, parameters)
    assert param in parameters

# Generated at 2022-06-20 16:13:23.768690
# Unit test for function sanitize_keys
def test_sanitize_keys():
    convert_to_text = lambda x: to_text(x, errors='surrogate_or_strict')

    no_log_strings = ['REDACTED']
    no_log_strings_encoded = [to_bytes(x) for x in no_log_strings]

    # Test keys sanitization for Dict
    ret = sanitize_keys({
        'foo': 'bar',
        'baz_pass': 'REDACTED',
        'qux_user': 'root',
        'corge_secret': 'REDACTED',
        'grault': 'REDACT_user',
        'garply_password': 'REDACTED',
        'waldo_key': 'REDACTED',
        'fred_token': 'some_token',
    }, no_log_strings)


# Generated at 2022-06-20 16:13:27.626430
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('ANSIBLE_RETRY_FILES_ENABLED', 'ANSIBLE_LOGS_DIR') == "False"
    try:
        env_fallback('FOO', 'BAR')
    except AnsibleFallbackNotFound:
        pass
    else:
        raise AssertionError("AnsibleFallbackNotFound not raised")



# Generated at 2022-06-20 16:13:29.797203
# Unit test for function env_fallback
def test_env_fallback():
    with testtools.ExpectedException(AnsibleFallbackNotFound):
        env_fallback('FOO')



# Generated at 2022-06-20 16:13:41.172090
# Unit test for function sanitize_keys
def test_sanitize_keys():
    def verify(message, value, expected):
        sanitized_value = sanitize_keys(value, C.NO_LOG_VALUES, ignore_keys=C.SANITIZE_KEYS_BLACKLIST)
        assert sanitized_value == expected, message
    # Simple string
    verify('sanitize_keys(values, "test1", "test1")', 'test1', 'test1')

    # Simple strings with data that needs removal
    verify('sanitize_keys(values, "test2=-")', 'test2=-', 'test2=VALUE_SPECIFIED_IN_NO_LOG_PARAMETER')

    # String that shouldn't be modified because password isn't at the end and shouldn't be modified because it is a uri

# Generated at 2022-06-20 16:13:49.447286
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert set_fallbacks({}, {}) == set()
    assert set_fallbacks({'key1': {'fallback': (env_fallback, 'ANSIBLE_TEST_KEY1')}}, {}) == set()
    os.environ['ANSIBLE_TEST_KEY1'] = 'test_value1'
    assert set_fallbacks({'key1': {'fallback': (env_fallback, 'ANSIBLE_TEST_KEY1')}}, {}) == set()
    assert set_fallbacks({'key1': {'fallback': (env_fallback, 'ANSIBLE_TEST_KEY1')}}, {}) == set()
    assert set_fallbacks({'key1': {'fallback': (env_fallback, 'ANSIBLE_TEST_KEY1')}}, {}) == set()

# Generated at 2022-06-20 16:13:52.953172
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert set_fallbacks({'test': dict(fallback=(env_fallback, 'TEST'))}, {}) == {os.environ['TEST']}



# Generated at 2022-06-20 16:14:00.347458
# Unit test for function set_fallbacks
def test_set_fallbacks():
    test_parameter = dict()
    test_parameter['test_key'] = dict()
    test_parameter['test_key']['type'] = 'str'
    test_parameter['test_key']['fallback'] = (env_fallback, 'TEST_KEY_ENV')
    os.environ['TEST_KEY_ENV'] = 'test_value'
    no_log_values = set_fallbacks(test_parameter, {})
    del os.environ['TEST_KEY_ENV']
    assert no_log_values == set()



# Generated at 2022-06-20 16:14:11.521063
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV'] = '1'
    assert env_fallback('ANSIBLE_TEST_ENV') == '1'
    assert env_fallback('ANSIBLE_TEST_ENV', 'ANSIBLE_TEST_ENV_2') == '1'
    assert env_fallback('ANSIBLE_TEST_ENV_2', 'ANSIBLE_TEST_ENV') == '1'
    assert env_fallback('ANSIBLE_TEST_ENV_3') == '1'
    del os.environ['ANSIBLE_TEST_ENV']
    # Test that when no key is in os.environ, it raises an exception
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('ANSIBLE_NOT_SET')



# Generated at 2022-06-20 16:14:45.984209
# Unit test for function remove_values
def test_remove_values():
    assert remove_values('test_secret', ['test_secret']) == '************'
    assert remove_values('test_secret', ['test_secret', 'unknow_string']) == '************'
    assert remove_values('test_secret_test_unknow', ['test_secret']) == 'test_secret_test_unknow'
    assert remove_values('test_secret_test_unknow', ['test_unknow']) == 'test_secret_test_unknow'
    assert remove_values('test_secret_test_unknow', ['test_secret', 'test_unknow']) == '************'
    assert remove_values('test_secret_test_test_test_test_test_unknow', ['test_test', 'test_unknow']) == 'test_secret_test_test_test_test_************'
