

# Generated at 2022-06-20 16:05:27.148561
# Unit test for function sanitize_keys
def test_sanitize_keys():
    obj = {'key1': 'value1', 'key2': 'value2'}

    mod_obj = sanitize_keys(obj, no_log_strings=['value1'])
    assert obj == mod_obj, 'Sanitize keys failed'

    obj = {'key1': 'value1', 'key2': 'value2', 'key3': 'value123'}
    mod_obj = sanitize_keys(obj, no_log_strings=['value1'])
    assert mod_obj == {'key2': 'value2', 'key3': 'value123'}, 'Sanitize keys failed'
    mod_obj = sanitize_keys(obj, no_log_strings=['value2'])

# Generated at 2022-06-20 16:05:34.510540
# Unit test for function sanitize_keys
def test_sanitize_keys():
    from ansible.module_utils.basic import AnsibleModule
    no_log_strings = {'password', 'secret', 'authentication_key'}
    test_dict = {'foo': {'bar': 'baz'}, 'password': None, 'secret': {'auth_key': 'authentication_key'}}
    test_sanitized_dict = {'foo': {'bar': 'baz'}, 'password': None, 'secret': {'auth_key': 'REDACTED'}}
    test_sanitized_dict_with_ignore_key = {'foo': {'bar': 'baz'}, 'password': None, 'authentication_key': {'auth_key': 'authentication_key'}}
    test_list = [{'foo': 'bar'}, {'password': 'secret'}]
    test_sanitized_

# Generated at 2022-06-20 16:05:40.359104
# Unit test for function remove_values
def test_remove_values():
    x = {'a': 'b',
         'c': None,
         'd': False,
         'e': 1,
         'f': ['a', 'b'],
         'g': set(['a', 'b', 'c']),
         'h': {'a': 'b', 'c': 'd'}}
    x_expected = {'a': '**',
                  'c': None,
                  'd': False,
                  'e': 1,
                  'f': ['**', '**'],
                  'g': set(['**', '**', '**']),
                  'h': {'a': '**', 'c': '**'}}
    assert remove_values(x, no_log_strings=['b', 'd']) == x_expected

    # Test that this function is idempotent

# Generated at 2022-06-20 16:05:45.485628
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert {'ansible_facts': '{{foo}}'} == sanitize_keys(
        {'_ansible_facts': '{{foo}}'},
        ['foo', 'bar'],
        ignore_keys=set(['_ansible_facts']))

    assert {'ansible_facts': '{{foo}}'} == sanitize_keys(
        {'_ansible_facts': '{{foo}}'},
        ['foo', 'bar'],
        ignore_keys=frozenset(['_ansible_facts']))

    assert {'ansible_facts': '{{foo}}'} == sanitize_keys(
        {'_ansible_facts': '{{foo}}'},
        ['foo', 'bar'],
        ignore_keys=frozenset(['_ansible_facts']))

   

# Generated at 2022-06-20 16:05:55.246996
# Unit test for function remove_values
def test_remove_values():
    assert remove_values(
        'This is a string', ['private', 'password']
    ) == 'This is a string'

    assert remove_values(
        'This is a private string', ['private', 'password']
    ) == 'This is a [FILTERED] string'

    assert remove_values(
        'This is a password string', ['private', 'password']
    ) == 'This is a [FILTERED] string'


# Generated at 2022-06-20 16:06:04.026716
# Unit test for function remove_values
def test_remove_values():
    # Test no change
    assert remove_values(dict(), []) == dict()
    # Test change
    assert remove_values("password", []) == "password"
    assert remove_values("password", ["password"]) == "VALUE_SPECIFIED_IN_NO_LOG_PARAMETER"
    assert remove_values("password", ["pass"]) == "password"
    assert remove_values("password", ["d", "n", "o", "p", "r", "s", "w"]) == "VALUE_SPECIFIED_IN_NO_LOG_PARAMETER"
    # Test container types
    assert remove_values(dict(a='password'), []) == dict(a='password')

# Generated at 2022-06-20 16:06:16.538629
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Simplest fallback check
    spec = {"a": {"default": "A", "fallback": (env_fallback, "A_ENV")}}
    param = {}
    no_log_values = set()
    no_log_values.update(set_fallbacks(spec, param))
    assert param["a"] == "A"
    assert no_log_values == set()

    # Override the default
    param = {"a": True}
    no_log_values = set()
    no_log_values.update(set_fallbacks(spec, param))
    assert param["a"] is True
    assert no_log_values == set()

    # Use fallback
    param = {}
    os.environ['A_ENV'] = 'B'
    no_log_values = set()
    no_

# Generated at 2022-06-20 16:06:23.044975
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert_equals('hi', sanitize_keys('hi', ['hi']))
    assert_equals('h*', sanitize_keys('hi', ['hi'], ignore_keys=['hi']))
    assert_equals(
        {'h*': 'hi', 'ignored': 'hi'},
        sanitize_keys({'hi': 'hi', 'ignored': 'hi'}, ['hi'], ignore_keys=['ignored'])
    )



# Generated at 2022-06-20 16:06:28.625727
# Unit test for function env_fallback
def test_env_fallback():
    """Ensure env_fallback behaves correctly with expected exceptions"""
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback()
    assert env_fallback('PATH') == os.environ.get('PATH')



# Generated at 2022-06-20 16:06:40.205213
# Unit test for function set_fallbacks

# Generated at 2022-06-20 16:07:06.207602
# Unit test for function set_fallbacks
def test_set_fallbacks():

    tdict = [{'required': True, 'type': 'dict', 'options': {'name': {'required': True, 'type': 'str'}}}]
    parameters = {}
    no_log_values = set_fallbacks(tdict, parameters)

    assert len(no_log_values) == 0
    assert len(parameters) == 0

    tdict = [{'required': True, 'type': 'dict', 'options': {'name': {'required': True, 'type': 'str', 'fallback': (env_fallback, 'AN_ENV_VAR',)}},}]
    parameters = {}
    no_log_values = set_fallbacks(tdict, parameters)

    assert len(no_log_values) == 0
    assert len(parameters) == 0


# Generated at 2022-06-20 16:07:17.104320
# Unit test for function set_fallbacks
def test_set_fallbacks():

    # This is the unit test for set_fallbacks()
    # It checks that an appropriate value is returned
    # after the function is called.
    #
    # Note: the values are hardcoded in the test.
    # They might need to be adjusted in case the
    # code changes in the future.

    class SampleSpec(object):
        def __init__(self, name=None, type=None, fallback=None):
            self.name = name
            self.type = type
            self.fallback = fallback

        @property
        def params(self):
            return self.name, self.type, self.fallback

    # test if a value is returned after set_fallbacks() is called
    # if the argument spec contains a value for the appropriate key
    # 'param'

# Generated at 2022-06-20 16:07:24.852634
# Unit test for function sanitize_keys
def test_sanitize_keys():
    """Unit test for function sanitize_keys"""
    import collections

    no_log_strings = {'secret', 'password', 'private_key'}
    ignore_keys = {'ansible_ssh_private_key_file'}

# Generated at 2022-06-20 16:07:33.683992
# Unit test for function sanitize_keys
def test_sanitize_keys():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.parsing.convert_bool import boolean


# Generated at 2022-06-20 16:07:43.945258
# Unit test for function remove_values
def test_remove_values():
    no_log_strings = ['password', 'host']

# Generated at 2022-06-20 16:07:56.812599
# Unit test for function remove_values
def test_remove_values():
    results = remove_values('ansible_facts.foo', ['bar', 'baz'])
    assert results == 'ansible_facts.***'
    results = remove_values('ansible_facts.boo', ['bar', 'baz'])
    assert results == 'ansible_facts.boo'
    results = remove_values('ansible_facts.boo', ['bar', 'foo'])
    assert results == 'ansible_facts.boo'
    results = remove_values('ansible_facts.foo', ['bar', 'baz', 'redacted'])
    assert results == 'ansible_facts.***'
    results = remove_values('ansible_facts.foo', ['bar', 'baz', 'foo'])
    assert results == 'ansible_facts.***'

# Generated at 2022-06-20 16:08:06.890350
# Unit test for function remove_values
def test_remove_values():
    # Create the source data structure
    sample_data = {
        'name': 'George',
        'user': 'jgeorgie123',
        'password': 'supersecret',
        'secret_hosts': [
            'oracle://sys:supersecret@localhost/xe',
            'postgresql://my_pass:supersecret@localhost/secret_db'
        ]
    }

    # Copy the data structure and remove values
    data = copy.deepcopy(sample_data)
    cls = AnsibleModule(argument_spec={'no_log': {'type': 'bool', 'default': False, 'no_log': False}})
    data = remove_values(data, ["supersecret"], cls.params['no_log'])

    # Verify that the values were removed

# Generated at 2022-06-20 16:08:13.837383
# Unit test for function remove_values
def test_remove_values():
    def check_no_log_strings_removed(arg, no_log_strings):
        """Ensure strings in no_log_strings are removed from arg"""
        new_arg = remove_values(arg, no_log_strings)
        for no_log_string in no_log_strings:
            assert no_log_string not in new_arg

    # Ensure orphaned no_log strings are removed.
    arg = ['password: abc']
    no_log_strings = ['password:']
    check_no_log_strings_removed(arg, no_log_strings)

    # Ensure values with no no_log keys are not removed.
    arg = ['password: abc', 'other: xyz']
    no_log_strings = ['password:']

# Generated at 2022-06-20 16:08:24.204679
# Unit test for function sanitize_keys
def test_sanitize_keys():

    assert sanitize_keys('secret', ['secret'],) == '***'
    assert sanitize_keys(['secret', 'secret'], ['secret'],) == ['***', '***']
    # Dicts with string keys
    assert sanitize_keys({'secret': 'secret'}, ['secret'],) == {'***': '***'}
    assert sanitize_keys({'secret': 'secret', 'secret2': 'secret'}, ['secret'],) == {'***': '***', '***2': '***'}
    assert sanitize_keys({'secret': 'secret', 'secret2': 'secret', 'keepit': 'secret'}, ['secret'],) == {'***': '***', '***2': '***', 'keepit': '***'}
    # Dicts with int keys
    assert san

# Generated at 2022-06-20 16:08:35.263899
# Unit test for function remove_values
def test_remove_values():
    # Single string input
    assert remove_values('password', {'password'}) == 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'

    # Multiple string input
    assert remove_values('password', {'password', 'secret'}) == 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'

    # Sequence type input
    test_string_list = ['password1', 'password2', 'password3']
    expected_string_list = ['VALUE_SPECIFIED_IN_NO_LOG_PARAMETER', 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER',
                            'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER']
    assert remove_values(test_string_list, {'password1', 'password2', 'password3'}) == expected_string_list

# Generated at 2022-06-20 16:08:56.629323
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_NET_USERNAME'] = 'jsmith'
    assert env_fallback('ANSIBLE_NET_USERNAME') == 'jsmith'



# Generated at 2022-06-20 16:08:58.122487
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('MY_VAR') == os.environ['MY_VAR']


# Generated at 2022-06-20 16:09:07.947913
# Unit test for function remove_values
def test_remove_values():
    dicts = dict()
    dicts['b64string'] = b'abcdefg'
    dicts['b64string'] = b64encode(dicts['b64string'])
    dicts['b64string'] = dicts['b64string'].decode('ascii')
    dicts['string'] = 'abcdefg'
    dicts['secret'] = 'secret'
    dicts['bool_true'] = True
    dicts['bool_false'] = False
    dicts['none'] = None
    dicts['float'] = 1.0
    dicts['int'] = 10
    dicts['tuple'] = (1, 2, 3)
    dicts['tuple_containing_dict'] = (1, 2, 3, dicts)


# Generated at 2022-06-20 16:09:13.672192
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'foo': {'type': 'str'}}

    parameters = {}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters == {}
    assert no_log_values == set()

    parameters = {'foo': 'bar'}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters == {'foo': 'bar'}
    assert no_log_values == set()

    argument_spec['foo']['fallback'] = ['env_fallback', 'FOO']
    os.environ['FOO'] = 'bar'
    parameters = {}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters == {'foo': 'bar'}
    assert no_log_values == set()

# Generated at 2022-06-20 16:09:18.593935
# Unit test for function env_fallback
def test_env_fallback():
    """Test env_fallback for invalid and valid values"""
    assert env_fallback('THIS_VAR_DOES_NOT_EXIST') == AnsibleFallbackNotFound
    assert env_fallback('HOME') == os.getenv('HOME')
    assert env_fallback('ANSIBLE_MODULE_ARGS') == AnsibleFallbackNotFound

# Generated at 2022-06-20 16:09:26.639155
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['FOOBAR_1'] = 'foo'
    os.environ['FOOBAR_2'] = 'bar'
    assert env_fallback('FOOBAR_1', 'FOOBAR_2') == 'foo'
    assert env_fallback('FOOBAR_3', 'FOOBAR_2') == 'bar'
    os.environ.pop('FOOBAR_1', None)
    os.environ.pop('FOOBAR_2', None)
    os.environ.pop('FOOBAR_3', None)



# Generated at 2022-06-20 16:09:32.860497
# Unit test for function env_fallback
def test_env_fallback():
    # Test that env_fallback returns the value of an existing environment variable
    os.environ['TEST_ENV'] = 'test'
    assert env_fallback('TEST_ENV') == 'test'

    # Test that env_fallback raises an exception when the environment variable does not exist
    assert_raises(AnsibleFallbackNotFound, env_fallback, 'TEST_ENV_NOT_EXIST')


# Generated at 2022-06-20 16:09:42.769020
# Unit test for function remove_values
def test_remove_values():
    assert remove_values('hello', ['ello']) == 'h'
    assert remove_values(u'hello', ['ello']) == u'h'
    assert remove_values('hello', ['hello']) == '!'
    assert remove_values(u'hello', [u'hello']) == u'!'
    assert remove_values('hellö', ['ello']) == 'h'
    # If we can't decode the string, it should be replaced with a !
    assert remove_values(b'\x80\x81\x82\x83\x84', ['\x81']) == '!!!!!'
    assert remove_values('hello', ['abc']) == 'hello'
    assert remove_values([5, 6, 7], [7]) == [5, 6, None]

# Generated at 2022-06-20 16:09:54.534966
# Unit test for function remove_values
def test_remove_values():
    no_log_strings = ['password', 'secret']
    assert '{"password": "abc"}' == remove_values('{"password": "abc"}', no_log_strings)
    assert '{"password": "*****"}' == remove_values('{"password": "abc", "key": "value"}', no_log_strings)
    assert '{"key": "value"}' == remove_values('{"password": "abc", "key": "value"}', no_log_strings)
    assert 'true' == remove_values('true', no_log_strings)
    assert 'false' == remove_values('false', no_log_strings)
    assert '["password", "is", "secret"]' == remove_values('["password", "is", "secret"]', no_log_strings)

# Generated at 2022-06-20 16:10:04.397173
# Unit test for function remove_values
def test_remove_values():
    no_log_values = set(['password', 'secret', '*_password', '*_secret', '*_key', 'api_key'])
    no_log_json_str = json.dumps(dict(data="login: `username`, password: `pasword`",
                                      dict=dict(username="user", password="pass", nested=dict(username="user", password="pass")),
                                      list=[dict(username="user", password="pass"), dict(username="user", password="pass")],
                                      set=set([dict(username="user", password="pass"), dict(username="user", password="pass")]),
                                      tuple=(dict(username="user", password="pass"), dict(username="user", password="pass"))), indent=2)

# Generated at 2022-06-20 16:10:32.709191
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # call set_fallbacks with an ArgSpec
    # ArgSpec will be None if called before argument parsing.
    argument_spec = dict(a=dict(type='int', fallback=(env_fallback, 'A_ENV_VAR')))
    parameters = {}
    set_fallbacks(argument_spec, parameters)
    assert parameters == dict()

    os.environ['A_ENV_VAR'] = '1'
    set_fallbacks(argument_spec, parameters)
    assert parameters == dict(a=1)

    # Verify that no_log is honored.
    argument_spec = dict(a=dict(type='str', fallback=(env_fallback, 'A_ENV_VAR'), no_log=True))
    parameters = {}

# Generated at 2022-06-20 16:10:33.746434
# Unit test for function env_fallback
def test_env_fallback():
    '''Test env_fallback'''
    assert env_fallback()



# Generated at 2022-06-20 16:10:42.298064
# Unit test for function remove_values
def test_remove_values():
    # Simple test
    assert remove_values(u'foo bar', [u'bar']) == u'foo'
    # Test a frozen set
    assert remove_values(frozenset([u'foo', u'bar']), [u'bar']) == frozenset([u'foo'])
    # Test this is idempotent
    assert remove_values(remove_values(u'foo bar', [u'bar']), [u'bar']) == u'foo'
    # Test a list
    assert remove_values([u'foo', u'bar'], [u'bar']) == [u'foo']
    # Test a complex set of data types

# Generated at 2022-06-20 16:10:51.024903
# Unit test for function sanitize_keys
def test_sanitize_keys():
    keys_to_sanitize = {
        'password': 'passw0rd',
        'secret': 's3cr3t',
    }
    result = {
        'password': 'SOME_MASK',
        'secret': 'SOME_MASK',
    }

    # list
    key_list = ['password', 'secret']
    assert sanitize_keys(key_list, set('password')) == ['SOME_MASK', 'SOME_MASK']

    # tuple
    key_tuple = ('password', 'secret')
    assert sanitize_keys(key_tuple, set('password')) == ('SOME_MASK', 'SOME_MASK')

    # set
    key_set = set(['password', 'secret'])

# Generated at 2022-06-20 16:10:58.978420
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys({'foo': 'bar'}, []) == {'foo': 'bar'}
    assert sanitize_keys({'payload': 'foo', 'no_log': 'on'}, []) == {'pa***': 'foo', 'no_log': 'on'}
    assert sanitize_keys({'payload': 'foo', 'no_log': 'on'}, [], ignore_keys=['no_log']) == {'pa***': 'foo', 'no_log': 'on'}



# Generated at 2022-06-20 16:11:00.346995
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['FOO'] = 'bar'
    assert env_fallback('FOO') == 'bar'
    assert env_fallback('missing') == None



# Generated at 2022-06-20 16:11:01.815501
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['FOO'] = 'bar'
    assert env_fallback('FOO') == 'bar'


# Generated at 2022-06-20 16:11:10.040631
# Unit test for function set_fallbacks
def test_set_fallbacks():
    """Unit test for function set_fallbacks"""

    # Test that it works when fallback is not set
    spec = dict(
        test=dict(type='str'),
        test2=dict(type='str'),
    )
    parameters = dict(test='test')
    no_log_values = set_fallbacks(spec, parameters)
    assert len(no_log_values) == 0

    # Test that it works when fallback is set
    spec = dict(
        test=dict(type='str'),
        test2=dict(type='str', fallback=('env', 'TEST2')),
    )
    parameters = dict(test='test')
    no_log_values = set_fallbacks(spec, parameters)
    assert len(no_log_values) == 0

# Generated at 2022-06-20 16:11:21.577058
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys({b'hello': b'world', b'crypto': b'password'}, [b'password']) == {b'hello': b'world'}, \
        "Unable to sanitize a unicode bytestring"
    assert sanitize_keys({u'hello': u'world', u'crypto': u'password'}, [u'password']) == {u'hello': u'world'}, \
        "Unable to sanitize a unicode object"
    assert sanitize_keys({'hello': 'world', 'crypto': 'password'}, {'password'}) == {'hello': 'world'}, \
        "Unable to sanitize a text type object"

# Generated at 2022-06-20 16:11:32.236364
# Unit test for function set_fallbacks
def test_set_fallbacks():
    spec = dict(
        option1=dict(type='str', fallback=(env_fallback, ['FIRST_OPTION', 'SECOND_OPTION'])),
        option2=dict(type='str', fallback=(env_fallback, ['FIRST_OPTION'])),
        option3=dict(type='str', fallback=(env_fallback, ['FIRST_OPTION'], dict(value='val'))),
    )
    params = dict(
        option3='should use first env var as fallback',
    )
    result = set_fallbacks(spec, params)
    assert result == set([])
    assert params == dict(
        option2='NORMAL_OPTION',
        option3='val',
    )



# Generated at 2022-06-20 16:12:00.857389
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'param1': {
            'required': True,
            'type': 'str',
        },
        'param2': {
            'required': True,
            'type': 'str',
        },
        'param3': {
            'required': True,
            'type': 'str',
        },
        'param4': {
            'required': True,
            'type': 'str',
        },
        'param5': {
            'required': True,
            'type': 'str',
            'fallback': (env_fallback, 'test_env'),
        }
    }

    # Test with no parameters
    parameters = {}
    assert set_fallbacks(argument_spec, parameters) == set()
    assert parameters == {'param5': 'test'}

    # Test fall

# Generated at 2022-06-20 16:12:09.719825
# Unit test for function env_fallback
def test_env_fallback():
    # Test env_fallback returns the value from the environment variable
    os.environ['TEST_CASE_ONE'] = 'TEST_CASE_ONE_VALUE'
    assert env_fallback('TEST_CASE_ONE') == 'TEST_CASE_ONE_VALUE'

    # Test env_fallback throws AnsibleFallbackNotFound if var not found
    os.environ.pop('TEST_CASE_ONE')
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('TEST_CASE_ONE')


# Generated at 2022-06-20 16:12:21.377862
# Unit test for function sanitize_keys

# Generated at 2022-06-20 16:12:32.002032
# Unit test for function remove_values
def test_remove_values():
    assert remove_values("password=123", ["123", "password"]) == "********"
    assert remove_values("this should not be removed", ["foo", "bar"]) == "this should not be removed"
    assert remove_values(dict(key="value", password="123", data=["password=123", "some data"]), ["password", "123"]) == dict(key="value", password="********", data=["********", "some data"])
    assert remove_values(dict(key="value", password="123", data=["password=123", "some data"]), ["123", "password"]) == dict(key="value", password="********", data=["********", "some data"])



# Generated at 2022-06-20 16:12:42.611658
# Unit test for function set_fallbacks
def test_set_fallbacks():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.validation import env_fallback

    # test a param that is not in parameters, but has a fallback
    argument_spec = ImmutableDict(a=dict(type='str', no_log=True, fallback=(env_fallback, ['ANSIBLE_TEST_FOO'])))
    parameters = ImmutableDict(b='foo')
    assert set_fallbacks(argument_spec, parameters) == set(['foo'])

    # test a param that is not in parameters and has no fallback
    argument_spec = ImmutableDict(a=dict(type='str', no_log=True))
    parameters = ImmutableDict(b='foo')

# Generated at 2022-06-20 16:12:48.556691
# Unit test for function set_fallbacks
def test_set_fallbacks():
    arg_spec = dict(foo= dict(type='str', fallback=(env_fallback, 'FOO'), required=False),
                    bar= dict(type='str', fallback=(env_fallback, 'BAR'), required=True)
                   )
    params = {'bar': 'bar'}
    no_log_values = set_fallbacks(argument_spec=arg_spec, parameters=params)
    assert len(no_log_values) == 0
    params = {}
    os.environ['FOO'] = 'FOO'
    no_log_values = set_fallbacks(argument_spec=arg_spec, parameters=params)
    assert params['foo'] == 'FOO'
    assert len(no_log_values) == 0
    params = {}

# Generated at 2022-06-20 16:12:54.312114
# Unit test for function set_fallbacks
def test_set_fallbacks():
    spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'secret': {'type': 'str', 'no_log': True, 'fallback': (env_fallback, 'MY_SECRET')},
        'secondary': {'type': 'str', 'required': True},
    }
    params = {'name': 'John C Doe'}
    no_log_vals = set_fallbacks(spec, params)
    assert params == {'name': 'John C Doe', 'secret': None}
    assert no_log_vals == set()

    # Test that required triggers fallback
    params = {}
    with pytest.raises(AnsibleValidationError):
        _set_defaults(spec, params, validate_required=True)
    assert params

# Generated at 2022-06-20 16:13:04.534586
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys(
        {'key': 'value'}, set([])) == {'key': 'value'}
    assert sanitize_keys(
        {'key': 'value'}, set(['key'])) == {'***': 'value'}
    assert sanitize_keys(
        {'key': {'key': 'value'}}, set(['key'])) == {'***': {'***': 'value'}}
    assert sanitize_keys(
        {'key': ['value1', 'value2']}, set(['key', 'value1'])) == {'***': ['***', 'value2']}

# Generated at 2022-06-20 16:13:07.649421
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_NET_USERNAME'] = 'test_user'
    assert env_fallback('ANSIBLE_NET_USERNAME', 'ANSIBLE_NET_PASSWORD') == 'test_user'

    os.environ['ANSIBLE_BECOME_PASS'] = 'test_pass'
    assert env_fallback('ANSIBLE_NET_PASSWORD', 'ANSIBLE_BECOME_PASS') == 'test_pass'



# Generated at 2022-06-20 16:13:15.657920
# Unit test for function sanitize_keys
def test_sanitize_keys():
    no_log_strings = ['password', 'secret', 'passwd', 'authorization', 'api_key', 'apikey', 'access_token']
    no_log_strings.extend([to_text(uuid4()) for _ in range(random.randint(3, 5))])

    def _generate_data(max_depth, key_length, value_length, max_children):
        key = to_text(uuid4())[:key_length]
        value = to_text(uuid4())[:value_length]

        if max_depth <= 1:
            if random.choice(no_log_strings) in value:
                return key, {'_ansible_no_log': True}
            else:
                return key, value

        children = []

# Generated at 2022-06-20 16:13:52.132700
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert set_fallbacks(dict(
        test_param=dict(fallback=(env_fallback, 'TEST_PARAM', 'TEST_PARAM_OTHER'))
    ), {}) == set()
    os.environ['TEST_PARAM'] = 'test123'
    assert set_fallbacks(dict(
        test_param=dict(fallback=(env_fallback, 'TEST_PARAM', 'TEST_PARAM_OTHER'))
    ), {}) == set(['test123'])

# Generated at 2022-06-20 16:14:01.506455
# Unit test for function remove_values

# Generated at 2022-06-20 16:14:10.248789
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['TEST_ENV1'] = 'test1'
    os.environ['TEST_ENV2'] = 'test2'
    assert env_fallback('TEST_ENV1') == 'test1'
    assert env_fallback(('TEST_ENV1', 'TEST_ENV2')) == 'test1'
    assert env_fallback('TEST_ENV2', 'TEST_ENV1') == 'test2'
    del os.environ['TEST_ENV1']
    del os.environ['TEST_ENV2']



# Generated at 2022-06-20 16:14:22.156848
# Unit test for function remove_values
def test_remove_values():
    assert remove_values(['a', ['b', ['c', 'd']], 'e'], ['e']) == ['a', ['b', ['c', 'd']]]
    # Check that unicode strings are handled
    assert remove_values(['a', '\u2603'], ['a']) == ['\u2603']
    assert remove_values(u'\u2603', [u'a']) == u'\u2603'
    # Check that mixed types are handled
    assert remove_values(['a', ['b', ['c', 'd']], u'\u2603'], ['e', u'\u2603']) == ['a', ['b', ['c', 'd']]]
    # Check that sequences and sets are handled

# Generated at 2022-06-20 16:14:32.897148
# Unit test for function sanitize_keys
def test_sanitize_keys():

    #
    # Test a simple case on a dict
    #
    obj = {
        'foo': {
            'bar1': 'baz1',
            'bar2': 'baz2',
        },
        'foo2': {
            'bar3': 'baz3',
            'bar4': 'baz4',
        }
    }

    new_value = sanitize_keys(obj, ['2', '4'])

    assert new_value == {
        'foo': {
            'bar1': 'baz1',
            'bar': 'baz2',
        },
        'foo': {
            'bar3': 'baz3',
            'bar': 'baz4',
        }
    }

    #
    # Test a complex case on a list
    #

# Generated at 2022-06-20 16:14:37.286057
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('BLA') == os.environ['BLA']
    assert_raises(AnsibleFallbackNotFound, env_fallback, ['BLA', 'BLO'])



# Generated at 2022-06-20 16:14:45.837673
# Unit test for function remove_values
def test_remove_values():
    def deep_obj():
        return {'a': {'aa': {'aaa': 'foo', 'aab': 'bar'}}, 'b': [{'ba': 'foo'}, {'bb': 'bar'}]}
    no_log_strings = ['foo']
    a = deep_obj()
    b = deep_obj()
    remove_values(a, no_log_strings)
    assert a == {'a': {'aa': {'aab': 'bar'}}, 'b': [{'bb': 'bar'}]}
    remove_values(b, no_log_strings)
    assert b == {'a': {'aa': {'aab': 'bar'}}, 'b': [{'bb': 'bar'}]}
    assert a == b



# Generated at 2022-06-20 16:14:55.075096
# Unit test for function env_fallback
def test_env_fallback():
    if PY3:
        context = dict(__import__('builtins', globals(), locals(), ['setenv']), os=dict(environ=dict(FOO='bar')))
    else:
        context = dict(os=dict(environ=dict(FOO='bar')))
    assert env_fallback('FOO') == 'bar'
    assert env_fallback('BAR') == 'baz'
    os.environ['LONG_ENV_VAR'] = 'baz'
    context['os']['environ']['LONG_ENV_VAR'] = 'baz'
    assert env_fallback('LONG_ENV_VAR') == 'baz'
    assert env_fallback('FOO', 'BAR', 'LONG_ENV_VAR') == 'bar'