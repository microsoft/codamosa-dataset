

# Generated at 2022-06-20 16:05:49.051386
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'foo': {'type': 'str', 'fallback': ('env', 'foo')},
                     'bar': {'type': 'str', 'fallback': ('env', 'bar')}}
    parameters = {}

    os.environ['foo'] = 'value1'

    result = set_fallbacks(argument_spec, parameters)
    assert len(result) == 1
    assert result == {'value1'}
    assert parameters == {'foo': 'value1'}



# Generated at 2022-06-20 16:06:02.230569
# Unit test for function sanitize_keys
def test_sanitize_keys():

    from collections import Mapping, OrderedDict

    class TestMapping(Mapping):
        def __init__(self, value):
            self.value = value

        def __getitem__(self, key):
            return self.value[key]

        def __iter__(self):
            return iter(self.value)

        def __len__(self):
            return len(self.value)

    class TestDict(dict):
        pass

    class TestOrderedDict(OrderedDict):
        pass

    class TestList(list):
        pass

    class TestMutableSequence(MutableSequence):
        def __init__(self, value):
            self.value = value
            super(TestMutableSequence, self).__init__()

        def __getitem__(self, key):
            return

# Generated at 2022-06-20 16:06:14.100947
# Unit test for function remove_values
def test_remove_values():
    assert remove_values(
        {
            'foo': 42,
            'bar': [{'baz': 42}, 42],
            'baz': {'foo': 42, 'bar': 42},
        },
        ('baz',),
    ) == {'foo': 42, 'bar': [{'baz': 42}, 42], 'baz': {'foo': 42, 'bar': 42}}


# Generated at 2022-06-20 16:06:20.199144
# Unit test for function env_fallback
def test_env_fallback():
    """ test env_fallback for set_fallbacks() """
    with patch.dict(os.environ, {'ANSIBLE_FOO': 'FOO'}):
        assert env_fallback('NOT_SET', 'ANSIBLE_FOO') == 'FOO'
        assert env_fallback('NOT_SET') == 'NOT_SET'
    with patch.dict(os.environ, {}, clear=True):
        assert env_fallback('NOT_SET') == 'NOT_SET'



# Generated at 2022-06-20 16:06:32.657934
# Unit test for function set_fallbacks
def test_set_fallbacks():
    values = dict()

    # test with an empty dict for argument spec
    spec = dict()
    no_log_values = set_fallbacks(spec, values)
    assert (not values)
    assert (not no_log_values)

    # test if first fallback is not found, second fallback is found
    spec = {
        'secondary': dict(fallback=('env_fallback', 'SECONDARY', 'PRIMARY')),
    }
    os.environ['PRIMARY'] = 'default_value'
    values = dict()
    no_log_values = set_fallbacks(spec, values)
    assert (values['secondary'] == 'default_value')
    assert (not no_log_values)

    # test if both fallbacks are found

# Generated at 2022-06-20 16:06:39.880034
# Unit test for function env_fallback
def test_env_fallback():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.common._collections_compat import OrderedDict
    from ansible.module_utils.common.namespace import Namespace

    def test_all_types():
        all_types = [object(),
                     Exception(),
                     int(),
                     float(),
                     complex(),
                     str(),
                     text_type(),
                     binary_type(),
                     list(),
                     tuple(),
                     frozenset(),
                     set(),
                     dict(),
                     OrderedDict(),
                     Mapping(),
                     MutableMapping(),
                     Namespace(),
                     os.environ]

# Generated at 2022-06-20 16:06:48.571027
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys({'a': 'b', 'c': 'd', 'a_secret': 'e'}, set(['a_secret', 'e'])) == {'a': 'b', 'c': 'd'}
    assert sanitize_keys({'a': 'b', 'a_secret': 'e'}, set(['a_secret', 'e'])) == {'a': 'b'}
    assert sanitize_keys({'a_secret': 'e'}, set(['a_secret', 'e'])) == {}
    assert sanitize_keys([{'e': 'a', 'd': 'b'}, {'e': 'c', 'f': 'd'}], set(['a', 'c'])) == [{'d': 'b'}, {}]

# Generated at 2022-06-20 16:06:51.621637
# Unit test for function env_fallback
def test_env_fallback():
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('foo')
    os.environ['foo'] = 'bar'
    assert env_fallback('foo') == 'bar'
    del os.environ['foo']



# Generated at 2022-06-20 16:07:00.550151
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_VAR_BAR'] = 'foo'
    os.environ['ANSIBLE_VAR_FOO'] = 'bar'


# Generated at 2022-06-20 16:07:10.137363
# Unit test for function remove_values
def test_remove_values():
    value = {1: 'test', 2: {1: 'test'}, 3: [1, 'test', [2, 3, 'test']]}
    no_log_strings = ['test']
    new_value = remove_values(value, no_log_strings)
    assert new_value == {1: '', 2: {1: ''}, 3: [1, '', [2, 3, '']]}

    value = 'test'
    no_log_strings = ['test']
    new_value = remove_values(value, no_log_strings)
    assert new_value == ''
# End unit test



# Generated at 2022-06-20 16:07:41.021905
# Unit test for function set_fallbacks

# Generated at 2022-06-20 16:07:49.494957
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ansible_test_variable'] = 'test'
    assert 'test' == env_fallback('ansible_test_variable')
    try:
        env_fallback('ansible_does_not_exist')
        assert False, "AnsibleFallbackNotFound should have been raised"
    except AnsibleFallbackNotFound:
        pass
    finally:
        del os.environ['ansible_test_variable']



# Generated at 2022-06-20 16:07:59.894612
# Unit test for function env_fallback
def test_env_fallback():

    import os

    # The function should raise error AnsibleFallbackNotFound if no environment variable exists.
    try:
        env_fallback("TOM")
    except AnsibleFallbackNotFound:
        # test passed
        pass
    else:
        # test failed
        raise AssertionError("AnsibleFallbackNotFound was not raised")

    # The function should return the value of the environment variable if it exists.
    os.environ["TOM"] = "JERRY"
    if env_fallback("TOM")=="JERRY":
        # test passed
        pass
    else:
        # test failed
        raise AssertionError("env_fallback returned unexpected value")



# Generated at 2022-06-20 16:08:08.328249
# Unit test for function remove_values
def test_remove_values():
    mdict = {'password': 'secretpassword'}
    mlist = [mdict]
    mset = set(mlist)

    # remove values from dict
    result = remove_values(mdict, ('password',))
    assert result == {'password': 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'}

    # remove values from list
    result = remove_values(mlist, ('password',))
    assert result == [{'password': 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'}]

    # remove values from tuple
    result = remove_values(tuple(mlist), ('password',))
    assert result == ({'password': 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'},)

    # remove values from set
    result = remove_values

# Generated at 2022-06-20 16:08:14.907234
# Unit test for function set_fallbacks
def test_set_fallbacks():
    text_spec = dict(type='str')
    fallback_spec = dict(type='str', fallback=(env_fallback, 'TEST_WITH_ENV'))
    spec = dict(text=text_spec,
                fallback_value=fallback_spec,
                )
    parameters = dict(text='foo')
    no_log_values = set_fallbacks(spec, parameters)
    assert parameters['fallback_value'] == 'bar'
    assert 'bar' in no_log_values



# Generated at 2022-06-20 16:08:26.408600
# Unit test for function remove_values
def test_remove_values():
    # Test normal cases
    dict_input = {"key1": "value1", "key2": "value2"}
    dict_output = {"key1": "value1", "key2": "value2"}
    list_input = ["value1", "value2"]
    list_output = ["value1", "value2"]
    set_input = {"value1", "value2"}
    set_output = {"value1", "value2"}
    deep_input = {"key1": "value1", "key2": set_input, "key3": dict_input, "key4": list_input}
    deep_output = {"key1": "value1", "key2": set_output, "key3": dict_output, "key4": list_output}

    output = remove_values(deep_input, ["value1"])


# Generated at 2022-06-20 16:08:28.072904
# Unit test for function remove_values
def test_remove_values():
    assert('abcdefghi==' == remove_values('abcdefghi==', 'def'))


# Generated at 2022-06-20 16:08:38.768257
# Unit test for function remove_values
def test_remove_values():
    test_value = {'a': 'b', 'c': 1, 'd': [1, '2', 'test', 3, {'foo': [1, 2], 'bar': 'baz'}]}
    assert remove_values(test_value, ['test']) == {'a': 'b', 'c': 1, 'd': [1, '2', 3, {'foo': [1, 2], 'bar': 'baz'}]}
    assert remove_values(test_value, ['baz']) == {'a': 'b', 'c': 1, 'd': [1, '2', 'test', 3, {'foo': [1, 2], 'bar': 'baz'}]}

# Generated at 2022-06-20 16:08:49.225154
# Unit test for function env_fallback
def test_env_fallback():
    assert os.environ.get('TEST_ENV_FALLBACK') is None
    try:
        assert env_fallback('TEST_ENV_FALLBACK') == 'TEST_VALUE'
    except AnsibleFallbackNotFound:
        # This is the expected outcome
        pass

    os.environ['TEST_ENV_FALLBACK'] = 'TEST_VALUE'
    assert env_fallback('TEST_ENV_FALLBACK') == 'TEST_VALUE'
    del os.environ['TEST_ENV_FALLBACK']



# Generated at 2022-06-20 16:08:59.415454
# Unit test for function set_fallbacks
def test_set_fallbacks():
    d = dict()
    d['name'] = dict(type='str')
    d['password'] = dict(type='str', no_log=True)
    d['port'] = dict(type='int')
    d['path'] = dict(type='path')
    d['inherit'] = dict(type='bool', default=True)
    argument_spec = dict(d)

    p = dict()
    p['name'] = 'robert'
    p['password'] = 'secret'
    p['path'] = '/path/to/something'
    parameters = dict(p)

    env_parameters = dict(p)
    env_parameters['port'] = '80'

    env_parameters_old = dict(env_parameters)
    env_parameters_old['inherit'] = 'True'



# Generated at 2022-06-20 16:09:43.102548
# Unit test for function remove_values
def test_remove_values():
    assert remove_values({'avar': 'a', 'bvar': 'b', 'cvar': 'c'}, 'b') == {'avar': 'a', 'cvar': 'c'}
    assert remove_values({'avar': 'a', 'bvar': 'b', 'cvar': 'c'}, 'b', 'c') == {'avar': 'a'}
    assert remove_values({'avar': 'a', 'bvar': 'b', 'cvar': 'c'}, ['b']) == {'avar': 'a', 'cvar': 'c'}
    assert remove_values({'avar': 'a', 'bvar': 'b', 'cvar': 'c'}, ['b', 'c']) == {'avar': 'a'}

# Generated at 2022-06-20 16:09:55.048547
# Unit test for function sanitize_keys
def test_sanitize_keys():
    data = {
        'foo': {
            u'test': u'bar',
            u'good': u'bar',
            'bad': 'bar',
            u'foo': u'bar'
        },
        'good': {
            u'test': u'bar',
            u'good': u'bar',
            'bad': 'bar',
            u'foo': u'bar'
        },
        'bad': {
            u'test': u'bar',
            u'good': u'bar',
            'bad': 'bar',
            u'foo': u'bar'
        }
    }


# Generated at 2022-06-20 16:10:01.081146
# Unit test for function env_fallback
def test_env_fallback():
    var1 = "TEST_A"
    var2 = "TEST_B"

    os.environ[var1] = "value_a"
    os.environ[var2] = "value_b"

    assert env_fallback(var1, var2) == "value_a"
    assert env_fallback(var2, var1) == "value_b"

    del os.environ[var1]
    del os.environ[var2]


# Generated at 2022-06-20 16:10:09.256960
# Unit test for function sanitize_keys
def test_sanitize_keys():
    """Unit test for function sanitize_keys"""
    if PY2:
        # On Python 2, we can't construct a dict with a bytes key, so we set the following
        # constant to a unicode string
        MOCK_KEY_NEED_SANITIZE = u'uabcd'
    else:
        MOCK_KEY_NEED_SANITIZE = b'babcd'
    MOCK_VALUE_NEED_SANITIZE = 'abcd'
    MOCK_KEY_BASIC = 'abcd'
    MOCK_VALUE_BASIC = 'abcd'
    MOCK_KEY_UNICODE = u'\uabcd'
    MOCK_VALUE_UNICODE = u'\uabcd'

# Generated at 2022-06-20 16:10:20.003030
# Unit test for function set_fallbacks

# Generated at 2022-06-20 16:10:29.528394
# Unit test for function remove_values
def test_remove_values():

    # test with simple data types
    assert remove_values('password', 'drowssap') == '****'
    assert remove_values('passwords', ['drowssap', 'test', 'no_log_string']) == '********'
    assert remove_values('passwords', ['no_log_string', 'test', 'drowssap']) == '********'
    assert remove_values('passwords', ['no_log_string', 'drowssap', 'drowssap']) == '*********'
    assert remove_values('password', ['drowssap', 'test', 'no_log_string']) == '****'
    assert remove_values(1234567890, ['drowssap', 'test', 'no_log_string']) == 1234567890

# Generated at 2022-06-20 16:10:31.658776
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('FOO') == os.environ['FOO']
    assert env_fallback('NOT_FOUND') == None



# Generated at 2022-06-20 16:10:41.729439
# Unit test for function set_fallbacks

# Generated at 2022-06-20 16:10:49.216230
# Unit test for function remove_values
def test_remove_values():
    example = {'k1': 'v1', 'k2': ['v2', 'v3'], 'k3': {'k4': ['v4', {'k5': 'v5'}]}, 'k6': ['v6', {'k7': ['v7', 'v8']}]}
    ansible_private = ['v3', 'v5', 'v6']
    expected = {'k1': 'v1', 'k2': ['v2', 'PRIVATE DATA HIDDEN'], 'k3': {'k4': ['v4', {'k5': 'PRIVATE DATA HIDDEN'}]}, 'k6': ['PRIVATE DATA HIDDEN', {'k7': ['v7', 'v8']}]}

    result = remove_values(example, ansible_private)


# Generated at 2022-06-20 16:10:53.654448
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['HOME'] = '/tmp/doesnotexist'
    assert env_fallback('HOME') == '/tmp/doesnotexist'



# Generated at 2022-06-20 16:11:46.231604
# Unit test for function remove_values

# Generated at 2022-06-20 16:11:53.813264
# Unit test for function env_fallback
def test_env_fallback():
    with mock.patch.dict(os.environ,
                         {'ARG1':'ARG1',
                          'ARG3':'ARG3'}):

        assert env_fallback('ARG1','ARG2','ARG3') == 'ARG1'
        assert env_fallback('ARG2','ARG3') == 'ARG3'
        with pytest.raises(AnsibleFallbackNotFound):
            env_fallback('ARG2','ARG4')



# Generated at 2022-06-20 16:12:00.812149
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['var1'] = "value1"
    os.environ['var2'] = "value2"
    os.environ['var3'] = "value3"
    assert env_fallback('var1') == "value1"
    assert env_fallback('var2') == "value2"
    assert env_fallback('var4') == "value4"



# Generated at 2022-06-20 16:12:12.928436
# Unit test for function sanitize_keys
def test_sanitize_keys():
    no_log_strings = {'pass', 'password'}
    ignore_keys = {'ignore_key'}

    no_log_strings2 = {'pass', 'password', 'test'}

    # Test: Sanitize keys from dictionary object and check the result
    obj1 = {'test': 'pass', 'password': 'test', 'test_pass': 'test_pass', 'test_pass_hidden': 'test_pass_hidden',
            'ignore_key': 'test'}
    obj1_expected = {'__sanitized_key__': 'pass', '____sanitized_key__': 'test', 'test_pass': 'test_pass',
                     'test_pass_hidden': 'test_pass_hidden', 'ignore_key': 'test'}

# Generated at 2022-06-20 16:12:21.722981
# Unit test for function remove_values
def test_remove_values():
    assert remove_values({'key': 'value', 'no_log_key': 'no_log_value'}, ['no_log_value']) == {'key': 'value', 'no_log_key': 'VALUE_HIDDEN'}
    assert remove_values({'key': 'value', 'no_log_key': 'no_log_value'}, ['no_log_value', 'key']) == {'key': 'VALUE_HIDDEN', 'no_log_key': 'VALUE_HIDDEN'}

# Generated at 2022-06-20 16:12:33.969830
# Unit test for function set_fallbacks
def test_set_fallbacks():
    parameters = dict(param1='somevalue', param3='anothervalue')
    argu_spec = dict(param1=dict(type='str'), param2=dict(type='str', fallback=(env_fallback, ['lang'])),
                     param3=dict(type='str'), param4=dict(type='str', fallback=(env_fallback, ['lang'])),
                     param5=dict(type='str', fallback=(env_fallback, ['lang'])),
                     param6=dict(type='str', fallback=(env_fallback, [{'lang': 'overriden_env_var'}])))
    env_vars = dict(lang='env_value')

# Generated at 2022-06-20 16:12:44.103174
# Unit test for function sanitize_keys
def test_sanitize_keys():
    """Unit test for sanitize_keys"""
    # prepare
    big_list = [{'a': 1, 'b': 2}, {'a': 3, 'b': 2}, {'a': 4, 'b': 2}]

    # test
    result = sanitize_keys(big_list, no_log_strings=['b'])
    assert result == [{'a': 1, '**': 2}, {'a': 3, '**': 2}, {'a': 4, '**': 2}]

    # test
    result = sanitize_keys(big_list, no_log_strings=['b'], ignore_keys=['a'])

# Generated at 2022-06-20 16:12:53.342990
# Unit test for function set_fallbacks
def test_set_fallbacks():
    module_name = 'command'

# Generated at 2022-06-20 16:12:55.524527
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback("AN", "BSD") == os.environ.get("AN", os.environ.get("BSD"))



# Generated at 2022-06-20 16:13:05.072018
# Unit test for function sanitize_keys
def test_sanitize_keys():
    '''Test sanitize_keys function'''
    test_dict = {'ansible_user': 'user',
                 'ansible_password': 'password',
                 'ansible_ssh_pass': 'ssh_pass',
                 'ansible_become_pass': 'ansible_become_pass',
                 'ansible_become_method': 'ansible_become_method',
                 'ansible_become_user': 'ansible_become_user'}
    test_list = ['ansible_user', 'ansible_password', 'ansible_ssh_pass',
                 'ansible_become_pass', 'ansible_become_method', 'ansible_become_user']

# Generated at 2022-06-20 16:14:12.322583
# Unit test for function remove_values
def test_remove_values():
    assert remove_values('1234567890', ['1234']) == '567890'
    assert remove_values({'a': '1234'}, ['1234']) == {'a': ''}
    assert remove_values({'a': '1234'}, []) == {'a': '1234'}
    assert remove_values({'a': {'b': '1234'}}, ['1234']) == {'a': {'b': ''}}
    assert remove_values({'a': {'b': {'c': '1234'}}}, ['1234']) == {'a': {'b': {'c': ''}}}
    assert remove_values(['1234'], ['1234']) == ['']

# Generated at 2022-06-20 16:14:22.976970
# Unit test for function remove_values
def test_remove_values():
    assert 'foo' == remove_values('foo', ['bar'])
    assert 'ba' == remove_values('bar', ['bar'])
    assert 'ba' == remove_values('bar', ['a'])
    assert 'bar' == remove_values('bar', ['z'])
    assert 'bar' == remove_values('bar', [])
    assert 'foo' == remove_values('foobar', ['bar'])
    assert 'foo' == remove_values('barfoo', ['bar'])
    assert 'frabaz' == remove_values('barfoo', ['bar', 'foo'])

    assert ['foo'] == remove_values(['foo'], ['bar'])
    assert ['foo'] == remove_values(['foobar'], ['bar'])

# Generated at 2022-06-20 16:14:33.609971
# Unit test for function set_fallbacks
def test_set_fallbacks():

    spec = {
        'param1': {
            'type': 'str',
            'required': True,
            'fallback': (env_fallback, 'PARAM1_ENV_VAR', 'PARAM1_DEFAULT')
        },
        'param2': {
            'type': 'str',
            'required': False,
            'fallback': (env_fallback, {'vars': ['PARAM2_ENV_VAR']})
        }
    }

    # No fallback required
    noop_input = {'param1': 'value1'}
    output = set_fallbacks(spec, noop_input)
    assert noop_input == {'param1': 'value1'}
    assert output == set()

    # Fallback for required parameter
    noop_input = {}


# Generated at 2022-06-20 16:14:44.281998
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Set up data
    fallback_1 = (env_fallback, 'ANSIBLE_TEST_FALLBACK_1', {'default': 'default_value_1'})
    fallback_2 = (env_fallback, 'ANSIBLE_TEST_FALLBACK_2')
    fallback_3 = (env_fallback, 'ANSIBLE_TEST_FALLBACK_3', {'default': 'default_value_3'})
