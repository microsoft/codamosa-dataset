

# Generated at 2022-06-20 16:05:28.919242
# Unit test for function remove_values
def test_remove_values():
    assert remove_values('', []) == ''
    assert remove_values('foo', []) == 'foo'
    assert remove_values('foo', ['foo']) == 'PRIVATE DATA HIDDEN'
    assert remove_values('foobar', ['foo']) == 'foobar'
    assert remove_values({'foo': 'bar'}, []) == {'foo': 'bar'}
    assert remove_values({'foo': 'bar'}, ['foo']) == {'foo': 'PRIVATE DATA HIDDEN'}
    assert remove_values({'foo': 'bar'}, ['bar']) == {'foo': 'bar'}
    assert remove_values({'foo': {'bar': 'baz'}}, ['baz']) == {'foo': {'bar': 'baz'}}

# Generated at 2022-06-20 16:05:33.634708
# Unit test for function remove_values
def test_remove_values():
    assert remove_values(
        {
            'a': 'abc',
            'b': 'def',
            'c': 'ghi',
            'd': {'a': 1, 'b': 2},
            'e': (1, 2),
            'f': {1, 2},
        },
        ['abc', 'def', 'ghi'],
    ) == {'d': {'a': 1, 'b': 2}, 'e': (1, 2), 'f': {1, 2}}


# Generated at 2022-06-20 16:05:39.394199
# Unit test for function remove_values
def test_remove_values():
    raw_data = {
        'a': {'b': {'c': 'hello'}},
        'b': [
            {'c': ['hello', {'hi': 'bye'}]},
            {'d': 'hello'},
            'hi'],
        'c': {'d': {'e': {'f': [{'g': 'hello'}]}}}
    }


# Generated at 2022-06-20 16:05:44.261550
# Unit test for function remove_values
def test_remove_values():
    no_log_strings = ['some_text']
    assert remove_values('some_text', no_log_strings) == 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'
    # A list of strings should not be returned for a single string
    assert remove_values('some_text', no_log_strings) != ['VALUE_SPECIFIED_IN_NO_LOG_PARAMETER']
    # A list of strings should not be returned for a single string
    assert remove_values('some_text', no_log_strings) != ['VALUE_SPECIFIED_IN_NO_LOG_PARAMETER', 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER']

    no_log = {'some_text': 'some_value', 'other_text': 'other_value'}

# Generated at 2022-06-20 16:05:52.995245
# Unit test for function remove_values
def test_remove_values():
    assert remove_values(b'value', [b'l']) == b'vue'
    assert remove_values(b'value', [b'v']) == b'lue'
    assert remove_values(b'value', [b'l', b'u']) == b've'
    assert remove_values(b'value', b'l,u'.split(b',')) == b've'
    assert remove_values(b'value', b'l,v'.split(b',')) == b'ue'
    assert remove_values(b'value', [b'e', b'u']) == b'val'
    assert remove_values(b'value', [b'l', b'ue']) == b'v'

# Generated at 2022-06-20 16:05:55.812873
# Unit test for function env_fallback
def test_env_fallback():
    '''Validates if environment variable is used as fallback if value is not passed
    in.
    '''
    os.environ['ANSIBLE_STR'] = '123'
    assert env_fallback('ANSIBLE_STR') == '123'



# Generated at 2022-06-20 16:06:06.896749
# Unit test for function set_fallbacks
def test_set_fallbacks():
    test_spec = dict(
        foo=dict(type='str', fallback=(env_fallback, 'FOO')),
        bar=dict(type='str', fallback=(env_fallback, dict(key='BAR'))),
    )
    test_params = dict()

    # Test case 1: try to set fallback values with environment variables
    assert set_fallbacks(test_spec, test_params) == set()
    assert test_params == dict(foo=None, bar=None)
    os.environ['FOO'] = 'testing foo'
    assert set_fallbacks(test_spec, test_params) == set(['testing foo'])
    assert test_params == dict(foo='testing foo', bar=None)
    os.environ['BAR'] = 'testing bar'
    assert set_fallbacks

# Generated at 2022-06-20 16:06:13.533469
# Unit test for function remove_values
def test_remove_values():
    returned = remove_values({'foo': 'bar', 'bam': 'pam'}, ['pam'])
    assert returned == {'foo': 'bar', 'bam': '***'}
    returned = remove_values({'foo': 'bar', 'bam': 'pam'}, ['pam', 'bar'])
    assert returned == {'foo': '***', 'bam': '***'}



# Generated at 2022-06-20 16:06:20.483304
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['env_fallback_test_var'] = 'some_value'
    assert env_fallback('env_fallback_test_var') == 'some_value'
    assert env_fallback('env_fallback_test_var', 'other_value') == 'some_value'
    assert env_fallback('non_existent_env_var', 'some_value') == 'some_value'
    assert env_fallback('non_existent_env_var') == None  # noqa
    os.environ.pop('env_fallback_test_var')



# Generated at 2022-06-20 16:06:32.955540
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        foo=dict(fallback=(env_fallback, 'TEST_FOO'), type='str'),
        bar=dict(fallback=(env_fallback, 'TEST_BAR'), type='str'),
        baz=dict(fallback=(env_fallback, 'TEST_BAZ'), type='str'),
        xyz=dict(fallback=(env_fallback, 'TEST_XYZ'), type='str'),
        ansible_log_path=dict(fallback=(env_fallback, 'ANSIBLE_LOG_PATH'), type='path'),
    )

    parameters = dict(ansible_log_path=None)
    no_log_values = set_fallbacks(argument_spec, parameters)

# Generated at 2022-06-20 16:07:23.032212
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('FOO', 'BAR') == 'foo'
    assert env_fallback('BAR', 'FOO') == 'bar'
    try:
        env_fallback('BAZ')
    except AnsibleFallbackNotFound:
        pass
    else:
        fail("Should raise ValueError when second argument not found")
    # Test environment variable boolean parsing
    os.environ['FOO_FALSE'] = 'false'
    assert env_fallback('FOO_FALSE') is False
    os.environ['FOO_TRUE'] = 'true'
    assert env_fallback('FOO_TRUE') is True



# Generated at 2022-06-20 16:07:25.171312
# Unit test for function env_fallback
def test_env_fallback():
    target = 'ANSIBLE_TEST_VAR'
    value = 'ANSIBLE_TEST_VALUE'
    os.environ[target] = value
    assert env_fallback(target) == value


# Generated at 2022-06-20 16:07:36.078888
# Unit test for function env_fallback
def test_env_fallback():
    original = os.environ.copy()
    os.environ['ANSIBLE_TEST_CONFIG_VALUE'] = 'test config value'
    os.environ['ANSIBLE_TEST_CONFIG_VALUE_INT'] = '5'
    os.environ['ANSIBLE_TEST_CONFIG_VALUE_NONE'] = 'none'
    os.environ['ANSIBLE_TEST_CONFIG_VALUE_BOOL_FALSE'] = 'false'
    os.environ['ANSIBLE_TEST_CONFIG_VALUE_BOOL_TRUE'] = 'true'

    assert env_fallback('ANSIBLE_TEST_CONFIG_VALUE') == 'test config value'

# Generated at 2022-06-20 16:07:41.072529
# Unit test for function set_fallbacks
def test_set_fallbacks():
    parameters = {}
    args = ['ansible_password', 'vault_password', 'lookup("env", "ANSIBLE_VAULT_PASSWORD_FILE")']
    params = {'vault_password_file': {'required': True, 'type': 'path', 'fallback': ['env_fallback', args]}}
    no_log_values = set_fallbacks(params, parameters)
    assert parameters['vault_password_file'] == os.environ['ANSIBLE_VAULT_PASSWORD_FILE']
    assert no_log_values == set()



# Generated at 2022-06-20 16:07:54.134163
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        param1=dict(type='str', fallback=('foo',)),
        param2=dict(type='str', fallback=(env_fallback, 'ANSIBLE_TEST_PARAM2')),
        param3=dict(type='str', fallback=('bar', dict(key='value'))),
    )
    parameters = {'param1': 'bar', 'param3': 'baz'}
    os.environ['ANSIBLE_TEST_PARAM2'] = 'buzz'
    assert set(set_fallbacks(argument_spec, parameters)) == set(['foo', 'buzz'])
    parameters = {}
    assert set(set_fallbacks(argument_spec, parameters)) == set(['foo', 'buzz'])

# Generated at 2022-06-20 16:08:03.433418
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys({'a': 'b'}, ['a']) == {'****': 'b'}
    assert sanitize_keys({'a': 'b', 'c': 'd'}, ['a']) == {'****': 'b', 'c': 'd'}
    assert sanitize_keys({'a': {'b': 'c'}}, ['a']) == {'****': {'b': 'c'}}
    assert sanitize_keys({'a': {'b': 'c'}}, ['b']) == {'a': {'****': 'c'}}



# Generated at 2022-06-20 16:08:11.400444
# Unit test for function sanitize_keys
def test_sanitize_keys():
    from ansible.compat import StringIO
    from ansible.utils import json


# Generated at 2022-06-20 16:08:20.559603
# Unit test for function remove_values
def test_remove_values():
    assert remove_values('password123', ('password',)) == "****"
    assert remove_values({'foo': 'password123'}, ('password',)) == {'foo': "****"}
    assert remove_values({'foo': {'bar': 'password123'}}, ('password',)) == {'foo': {'bar': "****"}}
    assert remove_values({'foo': {'bar': ['password123']}}, ('password',)) == {'foo': {'bar': ["****"]}}
    assert remove_values({'foo': {'bar': [{'baz': 'password123'}]}}, ('password',)) == {'foo': {'bar': [{'baz': "****"}]}}
    assert remove_values(['password123'], ('password',)) == ["****"]

# Generated at 2022-06-20 16:08:30.893804
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['test_env'] = 'test_val'
    assert env_fallback('test_env') == 'test_val'
    assert env_fallback('test_env2') == 'test_val'
    assert env_fallback('test_env', 'test_env2') == 'test_val'
    assert env_fallback('test_env2', 'test_env') == 'test_val'
    assert env_fallback('test_env2', 'test_env2') == 'test_val'
    assert env_fallback('test_env2') == 'test_val'
    assert env_fallback('test_env2') == 'test_val'
    assert env_fallback('test_env2') == 'test_val'

# Generated at 2022-06-20 16:08:41.697624
# Unit test for function remove_values
def test_remove_values():
    assert remove_values('password', ['assword']) == 'p******'
    assert remove_values('password', ['assword'], no_log_strings=['assword']) == 'p******'
    assert remove_values('pw', ['pw']) == 'p****'
    assert remove_values('username', ['name']) == 'usern****'
    assert remove_values('mypass', ['my', 'pass']) == '********'
    assert remove_values('pass', ['pass']) == '****'
    assert remove_values('password', ['p', 'd']) == '***a***or****'
    assert remove_values('mytoken', ['mytoken']) == '***********'
    assert remove_values('mytoken', ['token']) == 'myt******'

# Generated at 2022-06-20 16:09:30.446010
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_VAR'] = 'test'
    assert env_fallback('ANSIBLE_TEST_VAR') == 'test'
    del os.environ['ANSIBLE_TEST_VAR']
    try:
        env_fallback('ANSIBLE_TEST_VAR')
    except AnsibleFallbackNotFound:
        pass
    else:
        raise AssertionError('Did not receive expected exception')



# Generated at 2022-06-20 16:09:41.353572
# Unit test for function remove_values
def test_remove_values():
    """Unit test for function remove_values"""
    assert remove_values(
        {
            'nested': [
                {'value': 'password'},
                {'value': 'secret'}
            ]
        },
        ('password', 'secret')
    ) == {
        'nested': [
            {'value': 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'},
            {'value': 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'}
        ]
    }


# Generated at 2022-06-20 16:09:52.957365
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys({"a": "b"}, set()) == {"a": "b"}
    assert sanitize_keys({"a": "b"}, set(["b"])) == {"a": "********"}
    assert sanitize_keys({"z": "b"}, set(["b"])) == {"z": "********"}
    assert sanitize_keys({"a": {"b": "c"}}, set(["d"])) == {"a": {"b": "c"}}
    assert sanitize_keys({"a": {"b": "c", "c": "d"}}, set(["b", "d"])) == {"a": {"b": "********", "c": "********"}}

# Generated at 2022-06-20 16:10:03.239521
# Unit test for function sanitize_keys
def test_sanitize_keys():
    no_log_strings = set(['to_sanitize'])
    ignore_keys = set()

    # List
    obj = [('key1', {'_ansible_no_log': True, 'key2': [('key3', 'to_sanitize')]})]
    new_value = sanitize_keys(obj, no_log_strings, ignore_keys)
    assert new_value == [('key1', {'key2': [('key3', '********')]})]

    # Dict
    obj = {'key1': {'_ansible_no_log': True, 'key2': [{'key3': 'to_sanitize', 'key4': {}}]}}
    new_value = sanitize_keys(obj, no_log_strings, ignore_keys)
    assert new_

# Generated at 2022-06-20 16:10:09.737035
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('ANSIBLE_FOO', 'FOO') == os.environ['FOO']
    try:
        env_fallback('ANSIBLE_BAR', 'BAR')
    except AnsibleFallbackNotFound:
        pass
    else:
        raise AssertionError("Should have raised AnsibleFallbackNotFound")



# Generated at 2022-06-20 16:10:20.551311
# Unit test for function sanitize_keys
def test_sanitize_keys():
    """Validate the function sanitize_keys"""

    from collections import OrderedDict

    class DummyProvider:
        secret = "bar"

    def test_func(foo):
        return foo

    no_log_strings = set(['foo'])

    # Basic tests
    assert sanitize_keys('foo', no_log_strings) == 'foo'
    assert sanitize_keys(None, no_log_strings) is None
    assert sanitize_keys([], no_log_strings) == []
    assert sanitize_keys([1, 2, 3], no_log_strings) == [1, 2, 3]
    assert sanitize_keys(['foo'], no_log_strings) == ['foo']
    assert sanitize_keys({}, no_log_strings) == {}
    assert san

# Generated at 2022-06-20 16:10:24.121180
# Unit test for function env_fallback
def test_env_fallback():
    arg = 'TEST_ENV_FALLBACK'
    value = 'testvalue'
    os.environ[arg] = value
    assert env_fallback(arg) == value
    os.environ.pop(arg)



# Generated at 2022-06-20 16:10:30.457510
# Unit test for function env_fallback
def test_env_fallback():
    with patch("ansible.module_utils.basic.os.environ", {"PATH": "/bin:/usr/bin:/usr/local/bin", "FOO": "bar"}):
        assert env_fallback("PATH") == "/bin:/usr/bin:/usr/local/bin"
        assert env_fallback("FOO") == "bar"
        assert env_fallback("BAR") == None



# Generated at 2022-06-20 16:10:41.709066
# Unit test for function remove_values
def test_remove_values():
    assert remove_values('', []) == ''
    assert remove_values('', ['secret']) == ''
    assert remove_values('secret', ['secret']) == 'VALUE_REMOVED'
    assert remove_values([], ['secret']) == []
    assert remove_values(['secret'], ['secret']) == ['VALUE_REMOVED']
    assert remove_values([[], [['secret']]], ['secret']) == [[], [['VALUE_REMOVED']]]
    assert remove_values({}, ['secret']) == {}
    assert remove_values({'secret': 'secret'}, ['secret']) == {'secret': 'VALUE_REMOVED'}

# Generated at 2022-06-20 16:10:48.785386
# Unit test for function env_fallback
def test_env_fallback():
    # Test an env variable that exists
    os.environ['ANSIBLE_FOO'] = "bar"
    assert env_fallback("ANSIBLE_FOO") == "bar"

    # Test an env variable that does not exist
    assert env_fallback("ANSIBLE_BAR") == "foo"
    assert env_fallback("ANSIBLE_BAR", "foo") == "foo"

    try:
        env_fallback("ANSIBLE_BAR", "foo", "ANSIBLE_BAZ")
    except AnsibleFallbackNotFound:
        pass
    else:
        assert False


# Generated at 2022-06-20 16:11:51.002777
# Unit test for function remove_values
def test_remove_values():
    assert _remove_values_conditions(None, None) is None
    assert _remove_values_conditions('foo', ['foo']) == '****'
    assert _remove_values_conditions('foo', ['baz']) == 'foo'
    assert _remove_values_conditions('foo', ['Foo']) == '****'
    assert _remove_values_conditions({'foo': 'bar'}, ['foo']) == {'****': 'bar'}
    assert _remove_values_conditions({'foo': 'bar'}, ['baz']) == {'foo': 'bar'}
    assert _remove_values_conditions({'foo': 'bar'}, ['Foo']) == {'****': 'bar'}

# Generated at 2022-06-20 16:12:01.415672
# Unit test for function set_fallbacks

# Generated at 2022-06-20 16:12:13.274681
# Unit test for function set_fallbacks
def test_set_fallbacks():
    params = {'a': 'b'}
    argument_spec = {'a': {'type': 'str'}, 'b': {'type': 'bool', 'fallback': (env_fallback, ('BOOL_OPTION',))}}
    result = set_fallbacks(argument_spec, params)
    assert('b' not in params)
    assert(len(result) == 0)
    params['b'] = True
    result = set_fallbacks(argument_spec, params)
    assert(params['b'] == True)
    assert(result == set())
    os.environ['BOOL_OPTION'] = 'true'
    result = set_fallbacks(argument_spec, params)
    assert(params['b'] == True)
    assert(result == set())

# Generated at 2022-06-20 16:12:18.200120
# Unit test for function env_fallback
def test_env_fallback():

    with mock.patch.dict(os.environ, {'A': '1'}):
        assert env_fallback('A') == '1'
        assert env_fallback('A', 'B') == '1'
        assert env_fallback('B', 'C') == 'C'


# Generated at 2022-06-20 16:12:29.452867
# Unit test for function set_fallbacks
def test_set_fallbacks():
    spec = {
        'fruits': dict(type='str', choices=['orange']),
        'vegetables': dict(type='str', choices=['carrot'], fallback=('env_fallback', 'ANSIBLE_TEST_VEGETABLES', 'ANSIBLE_TEST_FRUITS', dict(fallback='broccoli'))),
    }
    params = dict(fruits='blueberry')
    os.environ['ANSIBLE_TEST_FRUITS'] = 'orange'
    os.environ['ANSIBLE_TEST_VEGETABLES'] = 'carrot'
    assert set_fallbacks(spec, params) == set()
    assert params == dict(fruits='blueberry', vegetables='carrot')



# Generated at 2022-06-20 16:12:40.467445
# Unit test for function sanitize_keys

# Generated at 2022-06-20 16:12:47.275749
# Unit test for function remove_values
def test_remove_values():
    from collections import OrderedDict
    from copy import deepcopy
    from ansible.module_utils import six

    # simple scalar value
    assert remove_values('value', ['value']) == 'VALUE'

    # simple container value
    assert remove_values('set(value)', ['value']) == 'set(VALUE)'

    # list of ints
    assert remove_values([1, 2, 3], [2]) == [1, 2, 3]

    # dict of ints
    assert remove_values({'key': 1, 'secret': 2}, [2]) == {'key': 1, 'secret': 2}

    # can handle native strings
    assert remove_values('secret', [u'secret']) == 'VALUE'

    # can handle unicode strings

# Generated at 2022-06-20 16:12:54.027061
# Unit test for function sanitize_keys
def test_sanitize_keys():
    # Test to ensure that ordering of items in a container is maintained
    assert sanitize_keys(MutableMapping([('a', 1), ('b', 2), ('c', 3)]), ['b']) == MutableMapping([('a', 1), ('c', 3)])
    assert sanitize_keys(MutableSequence(['a', 'b', 'c']), ['b']) == MutableSequence(['a', 'c'])

    # Test to ensure that an object is returned unmodified if it is not a container type
    assert sanitize_keys('not a container', ['b']) == 'not a container'
# END OF Unit test for function sanitize_keys



# Generated at 2022-06-20 16:13:04.499325
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert set_fallbacks({
        'parm1': {'type': 'str', 'fallback': ('env_fallback', 'ANSIBLE_TEST_PARM1', 'ANSIBLE_TEST_PARM2')}
    }, {}) == set()

    os.environ['ANSIBLE_TEST_PARM2'] = 'password'
    assert set_fallbacks({
        'parm1': {'type': 'str', 'fallback': ('env_fallback', 'ANSIBLE_TEST_PARM1', 'ANSIBLE_TEST_PARM2'), 'no_log': True}
    }, {}) == {'password'}


# Generated at 2022-06-20 16:13:08.707897
# Unit test for function remove_values
def test_remove_values():
    fake_list_values = ["a", "b", "c", "d", "e", "f"]
    fake_list_values_removed = remove_values(fake_list_values, ["b", "d", "f"])
    assert(fake_list_values_removed == ["a", "c", "e"])

    # For the remaining tests, use a list of 3-tuples:
    # 1st: The value to use as the parameter to remove_values()
    # 2nd: A set of values to remove
    # 3rd: The expected result of remove_values()

# Generated at 2022-06-20 16:13:54.696810
# Unit test for function env_fallback
def test_env_fallback():
    os.environ["DETECT"] = "expected"
    assert env_fallback("DETECT") == "expected"
    # Ensure AnsibleFallbackNotFound is thrown when a variable is not defined in the environment
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback("UNDEFINED")


# Generated at 2022-06-20 16:14:03.208782
# Unit test for function env_fallback
def test_env_fallback():
    os_environ = os.environ

# Generated at 2022-06-20 16:14:13.243217
# Unit test for function remove_values

# Generated at 2022-06-20 16:14:20.179992
# Unit test for function remove_values
def test_remove_values():
    value = {
        'key1': 'ABCD',
        'key2': "The",
        'key3': 'password',
        'key4': 'is',
        'key5': 'password',
    }
    no_log_strings = {'password'}
    new_value = remove_values(value, no_log_strings)

    assert(new_value == {'key1': 'ABCD', 'key2': "The", 'key3': '*****', 'key4': 'is', 'key5': '*****'})

# Generated at 2022-06-20 16:14:30.719491
# Unit test for function remove_values
def test_remove_values():
    value = {'foo': 'bar', 'no_log': True}
    new_value = remove_values(value, ['bar', 'baz'])
    assert new_value['foo'] == '**'
    value = 'foo'
    new_value = remove_values(value, ['foo'])
    assert new_value == '**'
    value = 'foo secrets'
    new_value = remove_values(value, ['secrets'])
    assert new_value == 'foo **'
    value = {'foo': {'no_log': True}}
    new_value = remove_values(value, ['foo'])
    assert new_value['foo']['no_log']



# Generated at 2022-06-20 16:14:38.040872
# Unit test for function remove_values
def test_remove_values():
    assert remove_values('abc123abc123abc123abc123', ['123']) == 'abcabcabcabc'
    assert remove_values(LazyAnsibleUnicode('abc123abc123abc123abc123'), ['123']) == LazyAnsibleUnicode('abcabcabcabc')
    assert remove_values('abc123abc123abc123abc123', ['123', 'abc']) == ''
    assert remove_values('abc123abc123abc123abc123', []) == 'abc123abc123abc123abc123'
    assert remove_values('abc123abc123abc123abc123', ['123', 'abc', '456', 'def']) == ''
    assert remove_values('abc123', ['123', 'abc', '456', 'def']) == ''

    assert remove_values(123, [123]) == 0
    assert remove_

# Generated at 2022-06-20 16:14:46.456977
# Unit test for function env_fallback
def test_env_fallback():
    # Test that the fallback does not work if the value is not in the environment.
    os.environ['test_env_fallback'] = 'success'
    assert env_fallback('bogus') == 'success'
    assert env_fallback('bogus', 'success') == 'success'
    assert env_fallback('bogus', 'bogus2', 'success') == 'success'
    assert env_fallback('bogus', 'bogus2', 'bogus3', 'success') == 'success'
    assert env_fallback('bogus', 'bogus2', 'bogus3', 'bogus4', 'success') == 'success'

    # Test that the fallback does not work if the value is not in the environment

# Generated at 2022-06-20 16:14:55.784027
# Unit test for function set_fallbacks
def test_set_fallbacks():
    test_spec = {
        'param1': {'fallback': (env_fallback, 'env_test1')},
        'param2': {'fallback': (env_fallback, ['env_test2_1', 'env_test2_2'])},
        'param3': {'fallback': (env_fallback, ['env_test3_1', {'foo': 'env_test3_2'}])},
        'param4': {'fallback': (env_fallback, {'foo': 'env_test4'})},
        'param5': {'fallback': {'nope': 'should_not_exist'}},
        'param6': {'fallback': (env_fallback, 'dummy')},
    }
    test_params = dict()

    no_log_values