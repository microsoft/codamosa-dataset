

# Generated at 2022-06-20 16:05:24.397715
# Unit test for function env_fallback
def test_env_fallback():
    with mock.patch.dict(os.environ, {'TEST_ENV': 'foo'}, clear=True):
        assert env_fallback('TEST_ENV') == 'foo'
    with mock.patch.dict(os.environ, {'TEST_ENV': 'foo'}, clear=True):
        assert env_fallback('TEST_ENV2', 'TEST_ENV') == 'foo'
    with mock.patch.dict(os.environ, clear=True):
        with pytest.raises(AnsibleFallbackNotFound):
            env_fallback('DOES_NOT_EXIST')



# Generated at 2022-06-20 16:05:29.733422
# Unit test for function remove_values
def test_remove_values():
    values = [
        {'key': {'foo': 'bar'}},
        {'key': ['bar']},
        {'key': 'bar'},
        {'key': 'password: bar'}
    ]
    no_log_strings = ['bar']
    results = [
        {'key': {'foo': 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'}},
        {'key': ['VALUE_SPECIFIED_IN_NO_LOG_PARAMETER']},
        {'key': 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'},
        {'key': 'password: VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'}
    ]

# Generated at 2022-06-20 16:05:34.424433
# Unit test for function remove_values
def test_remove_values():
    from ansible.module_utils.common._collections_compat import Sequence
    from collections import Mapping, MutableMapping, MutableSequence, MutableSet


# Generated at 2022-06-20 16:05:40.237509
# Unit test for function remove_values
def test_remove_values():
    assert remove_values('super_secret_string', ['super_secret_string']) == 'VALUE_REMOVED_BY_ANSIBLE'
    assert remove_values(('super_secret_string', 'second_string'), ['super_secret_string']) == ('VALUE_REMOVED_BY_ANSIBLE', 'second_string')
    assert remove_values(['super_secret_string', 'second_string', 'third_string'], ['super_secret_string']) == ['VALUE_REMOVED_BY_ANSIBLE', 'second_string', 'third_string']
    assert remove_values(['super_secret_string', 'second_string'], ['super_secret_string', 'second_string']) == ['VALUE_REMOVED_BY_ANSIBLE', 'VALUE_REMOVED_BY_ANSIBLE']

# Generated at 2022-06-20 16:05:45.338894
# Unit test for function sanitize_keys
def test_sanitize_keys():
    bad_key_dict = {'password': 'secret', 'pass_phrase': 'shhhh'}
    bad_key_list = [{'password': 'supersecret'}, {'user': 'root', 'password': 'toor'}]
    bad_key_set = set([{'password': 'supersecret'}, {'user': 'root', 'password': 'toor'}])
    bad_key_dict_expected = {u'password': 'secret', u'pass_phrase': 'shhhh'}
    bad_key_list_expected = [{u'password': 'supersecret'}, {u'user': 'root', u'password': 'toor'}]

# Generated at 2022-06-20 16:05:48.308266
# Unit test for function env_fallback
def test_env_fallback():
    try:
        env_fallback('ANSIBLE_FAILBACK')
    except AnsibleFallbackNotFound:
        # this is what should happen since the variable doesn't exist
        pass



# Generated at 2022-06-20 16:06:00.500571
# Unit test for function set_fallbacks

# Generated at 2022-06-20 16:06:07.342853
# Unit test for function env_fallback
def test_env_fallback():
    assert 'HOME' in os.environ
    new_value = env_fallback('HOME')
    assert os.environ['HOME'] == new_value
    assert env_fallback('ANSIBLE_HOME') == os.environ['ANSIBLE_HOME']
    try:
        env_fallback('NON_EXISTING_ENV_VARIABLE')
        assert False, 'Expected to raise exception from env_fallback'
    except AnsibleFallbackNotFound:
        assert True



# Generated at 2022-06-20 16:06:18.678250
# Unit test for function sanitize_keys
def test_sanitize_keys():
    # Test a variety of container types
    assert sanitize_keys(['a', 'b', {'bak': {'c': 'd'}, 'foo': 'bar'}], ['bar']) == ['a', 'b', {'bak': {'c': 'd'}, 'foo': 'bar'}]

    assert sanitize_keys({'a': {'bak': 'b', 'foo': 'bar', 'barfoo': 'bar'}}, ['bar']) == {'a': {'bak': 'b', 'foo': 'bar', 'barfoo': 'bar'}}


# Generated at 2022-06-20 16:06:30.938595
# Unit test for function remove_values
def test_remove_values():
    # Output will be a string
    output = remove_values("no_log_values", ["no_log_values"])
    assert output == "***"
    # Output will be a list
    output = remove_values('no_log_list', ['no_log_list'])
    assert output == '***'
    # Output will be a list of strings
    output = remove_values(["no_log_values", "no_log_list"], ["no_log_values", "no_log_list"])
    assert output == ["***", "***"]
    # Output will be a list of a combination of strings and lists
    output = remove_values([["no_log_list", "no_log_values"], "no_log_values"], ["no_log_list", "no_log_values"])

# Generated at 2022-06-20 16:07:03.502046
# Unit test for function set_fallbacks

# Generated at 2022-06-20 16:07:09.641606
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys('My name is', set('m')) == 'My name is'
    assert sanitize_keys('m3t4lg3ar', {'m', '3', '4', 'l', 'g', 'a', 'r'}) == '__t__gea__'
    assert sanitize_keys('m3t4lg3ar', {'m'}) == 'm3t4lg3ar'
    assert sanitize_keys(list('m3t4lg3ar'), {'m', '3', '4', 'l', 'g', 'a', 'r'}) == ['__t__gea__']

# Generated at 2022-06-20 16:07:19.503327
# Unit test for function remove_values
def test_remove_values():
    from ansible.compat.tests.mock import patch, MagicMock
    from ansible.compat.tests import unittest

    class TestRemoveValues(unittest.TestCase):
        ''' ansible.module_utils.basic.remove_values unittest'''

        @patch.object(logging, 'debug')
        def test_list_removal(self, debug_mock):
            ansible_vars = [
                {'ip': '127.0.0.1'},
                {'ip': '192.168.1.1'},
                {'ip': '10.0.0.1'},
            ]
            test_cli = {'ANSIBLE_NOCOWS': 1}
            test_passwords = ['admin']
            # remove_values function will be tested with the following data


# Generated at 2022-06-20 16:07:25.600861
# Unit test for function set_fallbacks
def test_set_fallbacks():
    _test_set_fallbacks_string()
    _test_set_fallbacks_list()
    _test_set_fallbacks_list_of_strings()
    _test_set_fallbacks_list_of_string_and_dict()
    _test_set_fallbacks_list_of_dict()
    _test_set_fallbacks_dict()
    _test_set_fallbacks_sub_spec()
    _test_set_fallbacks_sub_spec_list()
    _test_set_fallbacks_sub_spec_dict()



# Generated at 2022-06-20 16:07:33.742070
# Unit test for function remove_values
def test_remove_values():
    assert remove_values("This is some text", ["text"]) == "This is some "
    assert remove_values("This is some text", ['This is some text']) == ""
    assert remove_values("This is some text", ['This is some text', "text"]) == ""
    assert remove_values("This is some text", ["bad regex\n"]) == "This is some text"
    assert remove_values("This text matches", ["text matches"]) == "This  matches"
    assert remove_values("This text matches", [re.compile("text matches")]) == "This  matches"

    assert remove_values(["This is some text"], ["text"]) == ["This is some "]
    assert remove_values(["This is some text"], ["This is some text"]) == [""]

# Generated at 2022-06-20 16:07:43.978897
# Unit test for function remove_values
def test_remove_values():
    assert remove_values('test', ('test',)) == '****'
    assert remove_values(1, ('test',)) == 1
    assert remove_values(None, ('test',)) == None
    assert remove_values('10.20.30.40', ('test',)) == '10.20.30.40'
    assert remove_values(['10.20.30.40'], ('test',)) == ['10.20.30.40']
    assert remove_values(('10.20.30.40',), ('test',)) == ('10.20.30.40',)
    assert remove_values(set(['10.20.30.40']), ('test',)) == set(['10.20.30.40'])

# Generated at 2022-06-20 16:07:53.050094
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_FOO'] = 'bar'
    assert env_fallback('ANSIBLE_TEST_FOO') == 'bar'
    try:
        env_fallback('ANSIBLE_TEST_NONE')
    except AnsibleFallbackNotFound:
        pass
    else:
        assert False, 'AnsibleFallbackNotFound not raised'
    del os.environ['ANSIBLE_TEST_FOO']



# Generated at 2022-06-20 16:08:04.553084
# Unit test for function set_fallbacks

# Generated at 2022-06-20 16:08:17.565012
# Unit test for function set_fallbacks
def test_set_fallbacks():
    parameters = {}

# Generated at 2022-06-20 16:08:20.951178
# Unit test for function set_fallbacks
def test_set_fallbacks():

    argument_spec = {'parameter': {'required': True, 'type': 'int', 'fallback': (env_fallback, ['ENV_VAR'])}}
    parameters = {}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters == {'parameter': os.environ.get('ENV_VAR')}



# Generated at 2022-06-20 16:08:50.224957
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys({'one': {'two': {'three': True}}}, ['foo', 'bar']) == \
        {'one': {'two': {'three': True}}}

    assert sanitize_keys({'one': {'two': {'three': True}}}, ['foo', 'bar'], ignore_keys=['two']) == \
        {'one': {'two': {'three': True}}}

    assert sanitize_keys({'one': {'two': {'three': True}}}, ['two', 'bar'], ignore_keys=['two']) == \
        {'one': {'two': {'three': True}}}


# Generated at 2022-06-20 16:09:02.337899
# Unit test for function remove_values
def test_remove_values():
    # Test string types
    assert remove_values('secret', ('secret',)) == 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'
    assert remove_values('secret', ('S',)) == 'secret'
    assert remove_values('secret', ('',)) == 'secret'
    assert remove_values('secret', ()) == 'secret'

    # Test immutable container types.
    assert remove_values(tuple(['secret']), ('secret',)) == tuple(['VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'])
    assert remove_values((1, 2, 3, 'secret'), ('secret',)) == (1, 2, 3, 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER')

    # Test mutable container types

# Generated at 2022-06-20 16:09:06.569990
# Unit test for function env_fallback
def test_env_fallback():
    # Test without env set
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('FOOBAR')

    # Test with env set
    os.environ['FOOBAR'] = 'baz'
    assert env_fallback('FOOBAR') == 'baz'


# Generated at 2022-06-20 16:09:11.653607
# Unit test for function sanitize_keys
def test_sanitize_keys():
    '''Tests the sanitize_keys function'''

    # Example data
    data = {
        'foo': 1,
        'bar_ssh_pass': '1234567890123456789012345678901234567890',
        'baz_ssh_key': '1324567890123456789012345678901234567890',
        'bar_ssh_key': '234567890123456789012345678901234567890',
        'foo_ssh_pass': '34567890123456789012345678901234567890',
    }

    no_log_strings = ['_pass', '_key']


# Generated at 2022-06-20 16:09:21.267726
# Unit test for function sanitize_keys
def test_sanitize_keys():
    mylist = ['hello', 'this', 'is', 'a', 'test']
    assert sanitize_keys(mylist, set()) == ['hello', 'this', 'is', 'a', 'test']
    assert sanitize_keys(mylist, set(['hello', 'a'])) == ['this', 'is', 'test']
    myset = set(['hello', 'this', 'is', 'a', 'test'])
    assert sanitize_keys(myset, set()) == set(['hello', 'this', 'is', 'a', 'test'])
    assert sanitize_keys(myset, set(['hello', 'a'])) == set(['this', 'is', 'test'])

# Generated at 2022-06-20 16:09:32.608262
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {"a": {"fallback": [env_fallback, "a_env"]},
                     "b": {"fallback": [env_fallback, "b_env"]},
                     "c": {"fallback": [env_fallback, "c_env"], "no_log": True},
                     "d": {"fallback": [env_fallback, "d_env"], "no_log": True},
                     "e": {"fallback": [env_fallback],
                           "no_log": True},
                     "f": {"fallback": ["no_fallback"],
                           "no_log": True}}

    parameters = dict(a='a_arg', b='b_arg', c='c_arg', d='d_arg', e='e_arg', f='f_arg')
    os.environ.update

# Generated at 2022-06-20 16:09:42.595094
# Unit test for function set_fallbacks
def test_set_fallbacks():
    parameters = {'param1': 'hello'}
    argument_spec = {'param1': {'type': 'str', 'required': True}, 'param2': {'type': 'str', 'required': False, 'fallback': (str,"hello")}}

    assert set_fallbacks(argument_spec, parameters) == set()
    assert parameters == {'param1': 'hello', 'param2': 'hello'}

    parameters = {'param1': 'hello'}
    argument_spec = {'param1': {'type': 'str', 'required': True}, 'param2': {'type': 'str', 'required': False, 'fallback': (str,"world")}}

    no_log_values = set_fallbacks(argument_spec,parameters)
    assert no_log_values == set(['world'])

# Generated at 2022-06-20 16:09:54.307906
# Unit test for function set_fallbacks

# Generated at 2022-06-20 16:09:59.374221
# Unit test for function env_fallback
def test_env_fallback():
    os.environ["foo"] = "bar"
    assert env_fallback("foo") == "bar"
    assert "HOME" not in os.environ
    try:
        env_fallback("HOME")
    except AnsibleFallbackNotFound as e:
        pass
    else:
        raise Exception("AnsibleFallbackNotFound not raised")



# Generated at 2022-06-20 16:10:05.032105
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['TEST_ENV_FALLBACK'] = 'testing'
    assert env_fallback('TEST_ENV_FALLBACK') == 'testing'
    del os.environ['TEST_ENV_FALLBACK']
    assert env_fallback('TEST_ENV_FALLBACK_FAIL') == AnsibleFallbackNotFound

_FALLBACK_FUNCS = {
    'env': env_fallback,
}

# Generated at 2022-06-20 16:10:59.948593
# Unit test for function remove_values
def test_remove_values():
    """Removing no_log strings from value"""

    no_log_strings = ['secret_value', 'secret_key']

    value = {'key_1': 'hello world', 'key_2': 'secret_value'}
    new_value = remove_values(value, no_log_strings)
    assert new_value == {'key_1': 'hello world', 'key_2': 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'}

    value = {'key_1': 'hello world', 'key_2': ['secret_value']}
    new_value = remove_values(value, no_log_strings)
    assert new_value == {'key_1': 'hello world', 'key_2': ['VALUE_SPECIFIED_IN_NO_LOG_PARAMETER']}


# Generated at 2022-06-20 16:11:07.463840
# Unit test for function env_fallback
def test_env_fallback():
    assert 'tmp' == env_fallback('TMPDIR', 'TEMPDIR', 'TMP')
    assert raise_if_error(AnsibleFallbackNotFound, env_fallback, 'FOO')

# pylint: disable=redefined-outer-name

# Generated at 2022-06-20 16:11:16.723958
# Unit test for function sanitize_keys
def test_sanitize_keys():
    data = dict(
        stand_alone=dict(
            hello=None,
            no_log_string='password',
        ),
        complex=dict(
            hello=[
                'password',
                None,
                dict(no_log_string='password'),
            ],
        ),
    )

    def check(original, test_data, no_log_strings):
        """Run the tests and verify that the results are what we expect.

        :arg original: A copy of the original data that we can modify.
        :arg test_data: The data to run through the sanitization.
        :arg no_log_strings: The set of strings that will be replaced if they are a value in a key.
        :arg ignore_keys: The set of keys to ignore
        """
        ignore_keys = set(('hello',))
        expected

# Generated at 2022-06-20 16:11:18.835335
# Unit test for function env_fallback
def test_env_fallback():
    pass

# Generated at 2022-06-20 16:11:30.639818
# Unit test for function sanitize_keys
def test_sanitize_keys():
    # note: the first two arguments are not used by sanitize_keys so we just use None
    assert dict(sanitize_keys(None, None, ['foo:bar:baz'], no_log_strings=['baz'])) == {'foo:bar:': None}
    assert dict(sanitize_keys(None, None, dict(foo='bar', baz='qux'), no_log_strings=['qux'])) == {'foo': 'bar', 'baz:': None}
    assert dict(sanitize_keys(None, None, dict(foo='bar', baz=dict(qux='quux')), no_log_strings=['quux'])) == {'foo': 'bar', 'baz:': {'qux:': None}}

# Generated at 2022-06-20 16:11:41.571886
# Unit test for function set_fallbacks

# Generated at 2022-06-20 16:11:48.350435
# Unit test for function sanitize_keys
def test_sanitize_keys():
    obj = {
        'auth_pass': 'password',
        'extra_vars': {
            '_ansible_ssh_pass': 'password',
        }
    }

    expected = {
        'auth_pass': 'password',
        'extra_vars': {
            '_ansible_ssh_pass': 'password',
        }
    }

    assert sanitize_keys(obj, {'password'}) == expected



# Generated at 2022-06-20 16:11:59.781610
# Unit test for function remove_values
def test_remove_values():
    def test_data_structure(private_value, structure, expected_result):
        """Test the data structure against the expected result.

        This is a helper function called by ``test_remove_values()``.
        """

        private_value = to_text(private_value)
        result = remove_values(structure, (private_value,))
        assert result == expected_result

    # Test basic functionality
    test_data_structure('test', 'test', '')

    # Test with non-string types as input and output
    int_test = 1
    test_data_structure('test', int_test, int_test)
    test_data_structure(1, int_test, int_test)

    dict_test = {'a': 'test', 'b': 'test value'}

# Generated at 2022-06-20 16:12:11.306274
# Unit test for function remove_values
def test_remove_values():
    assertNone(remove_values(None, None))

    assertEquals(remove_values(0, ['ok']), 0)
    assertEquals(remove_values(1, ['ok']), 1)
    assertEquals(remove_values(0.0, ['ok']), 0.0)
    assertEquals(remove_values(1.0, ['ok']), 1.0)
    assertEquals(remove_values('', ['ok']), '')
    assertEquals(remove_values('abc', ['ok']), 'abc')
    assertEquals(remove_values(u'', ['ok']), u'')
    assertEquals(remove_values(u'abc', ['ok']), u'abc')

    assertEquals(remove_values(['ok'], ['ok']), [])

# Generated at 2022-06-20 16:12:20.427090
# Unit test for function env_fallback
def test_env_fallback():
    class MockOSEnv(object):
        """Class to mock environment variable"""
        def __init__(self):
            self._env = {}

        def __getitem__(self, key):
            return self._env[key]

        def __setitem__(self, key, value):
            self._env[key] = value

    with patch('os.environ', MockOSEnv()) as mock_env:
        mock_env._env['1'] = 1
        mock_env._env['2'] = 2
        mock_env._env['3'] = 3
        assert env_fallback('1', '2', '3') == 1
        assert env_fallback('1', '3', '2') == 1
        mock_env._env.clear()
        mock_env._env['1'] = 1
        mock_env._

# Generated at 2022-06-20 16:13:14.653040
# Unit test for function remove_values
def test_remove_values():
    data = dict(
        password='somepassword',
        list=[
            dict(username='steve',
                 password='someotherpassword'),
        ],
    )
    result = remove_values(data, ['somepassword'])
    assert result == dict(
        password='VALUE_SPECIFIED_IN_NO_LOG_PARAMETER',
        list=[
            dict(username='steve',
                 password='VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'),
        ]
    )



# Generated at 2022-06-20 16:13:16.447563
# Unit test for function remove_values
def test_remove_values():
    for values in itertools.product((1, 'foo', ), (None, True, False, ), (None, 1, 'foo', ), (None, 1, 'foo', )):
        assert 'foo' not in remove_values(values, 'foo')

# Generated at 2022-06-20 16:13:20.439882
# Unit test for function set_fallbacks
def test_set_fallbacks():
    a = {'test': {'type': 'str', 'fallback': (env_fallback, 'ANSIBLE_TEST_MODULE_FALLBACK')}}
    b = {}
    set_fallbacks(a, b)
    assert b == {'test': 'blah'}



# Generated at 2022-06-20 16:13:24.998323
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys('random_string', ['random', '_string']) == 'REDACTED_REDACTED'
    assert sanitize_keys(['random_string'], ['random', '_string']) == ['REDACTED_REDACTED']
    assert sanitize_keys(('random_string', ), ['random', '_string']) == ('REDACTED_REDACTED', )
    assert sanitize_keys({'random_string': 'value'}, ['random', '_string']) == {'REDACTED_REDACTED': 'value'}
    assert sanitize_keys({'random_string': ['dont_touch']}, ['random', '_string']) == {'REDACTED_REDACTED': ['dont_touch']}

# Generated at 2022-06-20 16:13:28.721297
# Unit test for function env_fallback
def test_env_fallback():
    arguments = dict()
    # Test error
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback("FOO")
    # Test success
    os.environ["FOO"] = "value"
    assert env_fallback("FOO") == "value"
    # Cleanup
    del os.environ["FOO"]



# Generated at 2022-06-20 16:13:40.112056
# Unit test for function remove_values
def test_remove_values():
    # simple scalars
    assert remove_values(to_text(u'abc'), set([to_text(u'a')])) == to_text(u'bc')
    # simple dict
    element = dict(a=1, b=2)
    result = remove_values(element, set([to_text(u'a')]))
    assert result == dict(b=2)
    # simple list
    element = [1, 2, 3, 4]
    result = remove_values(element, set([to_text(u'2')]))
    assert result == [1, 3, 4]
    # dict of dicts
    inner_element = dict(a=1, b=2, c=3)
    element = dict(a=inner_element, b=2)

# Generated at 2022-06-20 16:13:51.986768
# Unit test for function set_fallbacks
def test_set_fallbacks():
    p = {
        'param1': 'value1',
        'param2': 'value2',
        'param3': 'value3',
        'param4': 'value4'
    }
    spec = {
        'param1': {
            'type': 'str',
            'required': False
        },
        'param2': {
            'type': 'str',
            'required': False
        },
        'param3': {
            'type': 'str',
            'required': False,
            'fallback': (env_fallback, ['param_from_env'])
        },
        'param4': {
            'type': 'str',
            'required': False,
            'fallback': (env_fallback, ['param_from_env'])
        }
    }
    assert set_fall

# Generated at 2022-06-20 16:13:57.048314
# Unit test for function env_fallback
def test_env_fallback():
    arg = "TEST_VALUE"
    os.environ[arg] = "TEST"
    assert env_fallback(arg) == os.environ[arg]
    os.environ.pop(arg)
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback(arg)
    assert env_fallback("FOO") == ""


# Generated at 2022-06-20 16:14:04.109612
# Unit test for function sanitize_keys
def test_sanitize_keys():
    '''
    Test function to make sure the sanitize_keys function works as expected
    '''
    # myset = {"foo", "bar"}
    # mydict = {"foo": 1, "foo2": 2, "foobaz": 3, "bar": 4, "bar2": 4, "barbaz": 4}

    assert sanitize_keys({'foo': None, 'foo2': None, 'foobaz': None, 'bar': None, 'bar2': None, 'barbaz': None}, ['foo', 'bar']) == {'******': None, '******2': None, '******baz': None, '******': None, '******2': None, '******baz': None}



# Generated at 2022-06-20 16:14:12.887603
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec_test_data = {
        'host': {
            'type': 'str',
            'required': False,
            'fallback': (env_fallback, ['ANSIBLE_NET_HOST'], {'key': 'value'})
        },
        'port': {
            'type': 'int',
            'required': False,
            'fallback': (env_fallback, ['ANSIBLE_NET_PORT'])
        }
    }

    parameters_test_data = {'host': '127.0.0.1'}

    # Test with no env vars
    no_log_values = set_fallbacks(argument_spec_test_data, parameters_test_data)
    assert len(no_log_values) == 0

    # Test with env vars