

# Generated at 2022-06-20 16:05:57.870240
# Unit test for function set_fallbacks
def test_set_fallbacks():
    from collections import OrderedDict
    class MyAnsibleFallbackNotFound(Exception):
        pass

    # OrderedDict is used so that unit tests will fail consistently
    #   instead of sometimes working correctly and sometimes not
    test_parameters = OrderedDict()
    expected_parameters = OrderedDict()
    expected_no_log_values = set()

    # Tests for fallback. function returns None

# Generated at 2022-06-20 16:06:05.453208
# Unit test for function remove_values

# Generated at 2022-06-20 16:06:09.980513
# Unit test for function env_fallback
def test_env_fallback():
    # Testing fallback with no matches
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('ANSIBLE_TEST_NON_EXISTANT', 'ANSIBLE_TEST_NON_EXISTANT_1', 'ANSIBLE_TEST_NON_EXISTANT_2')

    # Testing fallback with one match
    os.environ['ANSIBLE_TEST_1'] = 'one'
    os.environ['ANSIBLE_TEST_2'] = 'two'
    os.environ['ANSIBLE_TEST_3'] = 'three'

# Generated at 2022-06-20 16:06:20.646865
# Unit test for function sanitize_keys
def test_sanitize_keys():
    # test Dict
    value = copy.deepcopy(dict_obj)
    res = {u'A': {u'a': {u'B': {u'b': u'1', u'c': u'!foo'}, u'c': u'3'}, u'b': u'2'}}
    ans = sanitize_keys(value, ['foo'])
    assert ans == res

    value = copy.deepcopy(dict_obj)
    res = {u'A': {u'a': {u'B': {u'b': u'1', u'c': u'!foo'}, u'c': u'3'}, u'b': u'2'}}
    ans = sanitize_keys(value, ['foo'], ignore_keys={'B', 'c'})
    assert ans == res



# Generated at 2022-06-20 16:06:31.770332
# Unit test for function env_fallback
def test_env_fallback():
    for arg in [SOMETHING, SOMETHING_ELSE]:
        os.environ[arg] = 'env_fallback_test'
    assert env_fallback(SOMETHING, SOMETHING_ELSE) == 'env_fallback_test'
    del(os.environ[SOMETHING])
    assert env_fallback(SOMETHING, SOMETHING_ELSE) == 'env_fallback_test'
    del(os.environ[SOMETHING_ELSE])
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback(SOMETHING, SOMETHING_ELSE)



# Generated at 2022-06-20 16:06:41.855203
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys('test', ['e']) == 'tst'
    assert sanitize_keys({'key': 'test'}, ['e', 'y']) == {':': 'tst'}
    assert sanitize_keys({'key': 'test'}, ['e', 'y'], ignore_keys={'key'}) == {'key': 'tst'}
    assert sanitize_keys({'ke:y': 'test'}, [':']) == {'key' : 'test'}
    assert sanitize_keys({'ke:y': 'test'}, [], ignore_keys={'key'}) == {'ke:y' : 'test'}



# Generated at 2022-06-20 16:06:47.547038
# Unit test for function sanitize_keys
def test_sanitize_keys():
    no_log_strings = set()
    ignore_keys = frozenset()
    values = [ 'test',
               ['test', 'test2'],
               dict(test=1, test2=2) ]
    expected = [ 'test',
                 ['test', 'test2'],
                 dict(test=1, test2=2) ]
    for i, value in enumerate(values):
        assert expected[i] == sanitize_keys(value, no_log_strings, ignore_keys)

# Generated at 2022-06-20 16:06:48.692739
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('FOO') == 'bar'



# Generated at 2022-06-20 16:06:51.618034
# Unit test for function set_fallbacks
def test_set_fallbacks():
    params = {}
    spec = {
        'my_arg': {'type': 'str', 'fallback': (env_fallback, ['ANSIBLE_TEST_FALLBACK'])}
    }
    assert set_fallbacks(spec, params) == set()
assert set_fallbacks(spec, params) == set()



# Generated at 2022-06-20 16:06:59.563430
# Unit test for function remove_values
def test_remove_values():

    assert remove_values(
        {'key1': 'value1', 'key2': 'value2', 'key3': 'value3'}, ['value1', 'value2', 'value3']) == {'key1': '', 'key2': '', 'key3': ''}
    assert remove_values(['value1', 'value2', 'value3', 'value4'], ['value1', 'value2', 'value3', 'value4']) == ['', '', '', '']
    assert remove_values(['value1', ['value2', {'key1': 'value3'}], 'value4'], ['value1', 'value2', 'value3', 'value4']) == \
        [['', [{'key1': ''}], '']]



# Generated at 2022-06-20 16:07:31.986876
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # These tests show we'll provide more fallback arguments than the function takes, it should only use the first argument.
    # These tests should raise no Exception, even though the fallback strategy env_fallback takes no arguments.
    assert(set_fallbacks({'first': {'type': 'str', 'fallback': (env_fallback, ['ENV_FALLBACK', 'ENV_FALLBACK2'])}}, {}) == set())
    assert(set_fallbacks({'first': {'type': 'str', 'fallback': (env_fallback, 'ENV_FALLBACK', 'ENV_FALLBACK2')}}, {}) == set())
    # These tests show fallback strategy env_fallback should not be triggered, because the key has been passed in the 'parameters'

# Generated at 2022-06-20 16:07:43.211261
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys(
        {
            'user': 'password',
            'ansible_password': 'password',
        },
        no_log_strings={
            'password',
        },
        ignore_keys={'ansible_password'},
    ) == {
        'user': '<SANITIZED PASSWORD>',
        'ansible_password': 'password',
    }


# Generated at 2022-06-20 16:07:55.841615
# Unit test for function remove_values
def test_remove_values():
    """ Test to ensure remove_values yields the correct results on a variety
    of data types """

    # Using a class to reduce boilerplate
    class TestValue(object):
        def __init__(self, value, scrub, result):
            self.value = value
            self.scrub = scrub
            self.result = result

    # Scalar types

# Generated at 2022-06-20 16:07:57.343532
# Unit test for function env_fallback
def test_env_fallback():
    ''' env_fallback is tested in test_fallbacks '''
    pass



# Generated at 2022-06-20 16:08:07.270291
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Simple module with one parameter and a fallback to 'fallen'
    basic_args = dict(fallen=dict(fallback=('fallen',), type='str'))
    # One parameter with a sub parameter and fallback
    nested_args = dict(nest=dict(type='dict', options=dict(nested=dict(fallback=('fallen',), type='str'))))
    # One parameter with fallback that takes a parameter
    param_args = dict(parameter=dict(fallback=(env_fallback, 'ANSIBLE_PARAMETER'), type='str'))

    args1 = {'parameter': 'param'}
    args2 = {}
    args3 = {'nest': {'nested': 'nested_val'}}

# Generated at 2022-06-20 16:08:14.193125
# Unit test for function remove_values
def test_remove_values():
    # Dict test case
    data_dict = {
        'abc': 'xyz',
        'foo': {
            'bar': ['abc', 'xyz'],
            'baz': {
                'xyz': 'abc'
            }
        },
        'xyz': 'abc'
    }
    no_log_strings = ['xyz']

    new_data = remove_values(data_dict, no_log_strings)
    assert new_data == {
        'abc': '***',
        'foo': {
            'bar': ['abc', '***'],
            'baz': {
                '***': 'abc'
            }
        },
        '***': 'abc'
    }

    # List test case

# Generated at 2022-06-20 16:08:24.831662
# Unit test for function sanitize_keys
def test_sanitize_keys():
    no_log = [
        {'src': {'redacted': 'mysecret', 'baz': 'bar', 'foo': 'bar'}, 'no_log': {'foo': 'bar', 'baz': 'bar'}},
        {'src': {'redacted': 'mysecret', 'baz': 'bar', 'foo': 'bar'}, 'no_log': {'foo': 'bar', 'baz': 'bar'}, 'ignore_keys': {'redacted'}},
        {'src': {'redacted': 'mysecret', 'baz': 'bar', 'foo': 'bar'}, 'no_log': {'foo': 'bar', 'baz': 'bar'}, 'ignore_keys': {'foo'}}
    ]


# Generated at 2022-06-20 16:08:35.700182
# Unit test for function remove_values
def test_remove_values():
    assert remove_values(None, []) == None

    assert remove_values("hello world", []) == "hello world"
    assert remove_values("hello world", ["world"]) == "hello "
    assert remove_values("hello world", ["hello", "world"]) == " "
    assert remove_values("hello world", ["world", "hello"]) == " "
    assert remove_values("hello world", ["world", "hello", "world"]) == " "
    assert remove_values("hello world", ["hello", "world", "hello"]) == " "
    assert remove_values("hello world", ["hello", "hello", "world"]) == " "
    assert remove_values("hello hello world", ["hello", "hello", "world"]) == " "

# Generated at 2022-06-20 16:08:45.351125
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys({'a': 'a', 'b': 'b'}, set()) == {'a': 'a', 'b': 'b'}
    assert sanitize_keys({'a': 'a', 'b': 'b'}, {'b'}) == {'a': 'a', 'b': 'REDACTED'}
    assert sanitize_keys({'a': 'a', 'b': 'b'}, {'c'}) == {'a': 'a', 'b': 'b'}
    assert sanitize_keys({'a': 'a', 'b': 'b'}, {'b'}, ignore_keys={'a', 'b'}) == {'a': 'a', 'b': 'b'}

# Generated at 2022-06-20 16:08:47.422424
# Unit test for function env_fallback
def test_env_fallback():
    os.environ = {'ANSIBLE': True}
    assert env_fallback('ANSIBLE') == True



# Generated at 2022-06-20 16:09:14.121770
# Unit test for function env_fallback
def test_env_fallback():
    with mock.patch('os.environ', {'VALUE': 'foo'}):
        assert env_fallback('VALUE') == 'foo'
        with pytest.raises(AnsibleFallbackNotFound):
            env_fallback('NOT_VALUE')

        assert env_fallback('NOT_FOO', 'VALUE') == 'foo'

        args = ['NOT_FOO', 'VALUE']
        assert env_fallback(*args) == 'foo'



# Generated at 2022-06-20 16:09:21.107072
# Unit test for function remove_values
def test_remove_values():
    """
       Unit test for function remove_values.
       Uses the remove_values_test data structure, defined at bottom of this file.
    """
    for elem in remove_values_test:
        in_obj = elem['in']
        out_obj = elem['out']
        no_log_strings = []
        if elem.get('no_log_strings'):
            no_log_strings = elem['no_log_strings']
        assert remove_values(in_obj, no_log_strings) == out_obj



# Generated at 2022-06-20 16:09:32.322406
# Unit test for function remove_values
def test_remove_values():
    assert(remove_values({}, set()) == {})
    assert(remove_values(['a'], set()) == ['a'])
    assert(remove_values('abcdef', set()) == 'abcdef')
    assert(remove_values({'a': 'b', 'cd': 'ef'}, set()) == {'a': 'b', 'cd': 'ef'})
    assert(remove_values({'a': 'b', 'cd': 'ef'}, {'b', 'ef'}) == {'a': '', 'cd': ''})
    assert(remove_values({'a': 'b', 'cd': 'ef'}, {'b', 'e'}) == {'a': 'b', 'cd': 'ef'})

# Generated at 2022-06-20 16:09:42.617286
# Unit test for function sanitize_keys
def test_sanitize_keys():

    for obj in [
        [{'bananas', 'apples'}, {'pears': {'cantaloupes'}}],
        [{'bananas': 'apples', 'pears': 'cantaloupes'}],
        {'bananas': 'apples', 'pears': 'cantaloupes'},
        {'bananas': {'pears': 'cantaloupes'}},
    ]:
        new_obj = sanitize_keys(obj, {b'apples', 'pears'})

        if isinstance(new_obj, Mapping):
            assert new_obj.keys() == {'bananas', 'pears'}

# Generated at 2022-06-20 16:09:54.347137
# Unit test for function set_fallbacks
def test_set_fallbacks():
    params = {'type': 'str', 'fallback': (env_fallback, 'ANSIBLE_TEST_FALLBACK')}
    arg_spec = {'test_param': params}
    parameters = {}
    no_log_values = set()
    assert set_fallbacks(arg_spec, parameters) == no_log_values
    assert 'test_param' not in parameters
    os.environ['ANSIBLE_TEST_FALLBACK'] = 'test value'
    assert set_fallbacks(arg_spec, parameters) == no_log_values
    assert 'test_param' in parameters
    assert parameters['test_param'] == 'test value'
    params['no_log'] = True
    assert set_fallbacks(arg_spec, parameters) == {'test value'}

# Generated at 2022-06-20 16:10:03.903731
# Unit test for function set_fallbacks
def test_set_fallbacks():
    """
    Test function to check set_fallbacks arguments
    """
    # Check if parameters are set from env variable
    argument_spec = {'test1': {'type': 'str', 'fallback': (env_fallback, 'ANSIBLE_NET_TEST1')}}
    result = set_fallbacks(argument_spec, {'test1': None})
    assert len(result) == 1
    assert result == set(['test'])

    argument_spec = {'test1': {'type': 'str', 'fallback': (env_fallback, ['ANSIBLE_NET_TEST1'])}}
    result = set_fallbacks(argument_spec, {'test1': None})
    assert len(result) == 1
    assert result == set(['test'])



# Generated at 2022-06-20 16:10:12.597016
# Unit test for function sanitize_keys
def test_sanitize_keys():
    data = {
        'foo': 'bar',
        'baz': {
            'foo': 'bar',
            'frooble': {
                'foo': 'bar',
                'fribble': {
                    'foo': 'bar',
                }
            }
        }
    }
    alias = {1: 'froo', 2: 'frob'}
    new_data = deepcopy(data)
    sanitize_keys(new_data, [], {'foo', 'froo'})
    assert new_data == data

    new_data = deepcopy(data)
    sanitize_keys(new_data, ['bar'], {'foo', 'froo'})

# Generated at 2022-06-20 16:10:23.374928
# Unit test for function remove_values
def test_remove_values():
    # No value or no_log_strings are acceptable.
    # No value, with default no_log_strings
    assert remove_values(None, []) == None
    assert remove_values("", []) == ""
    assert remove_values([], []) == []
    assert remove_values({}, []) == {}

    # No no_log_strings, with default value
    assert remove_values(None, None) == None
    assert remove_values("", None) == ""
    assert remove_values([], None) == []
    assert remove_values({}, None) == {}

    # valid list, string input
    assert remove_values(['hello', 'world'], ['hello']) == ['world']
    assert remove_values('hello world', ['hello']) == 'world'

    # valid list, list input
    assert remove_values

# Generated at 2022-06-20 16:10:32.918254
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys(None, None) is None

    result = sanitize_keys('test', (None,))
    assert isinstance(result, string_types) and result == 'test'

    result = sanitize_keys(42, ('a',))
    assert isinstance(result, int) and result == 42

    assert sanitize_keys({}, (None,)) == {}
    assert sanitize_keys(set(), (None,)) == set()
    assert sanitize_keys([], (None,)) == []
    assert sanitize_keys(tuple(), (None,)) == tuple()


# Generated at 2022-06-20 16:10:39.611911
# Unit test for function remove_values
def test_remove_values():
    ''' test remove_values '''
    # This is an example YAML file used for testing the remove_values function

# Generated at 2022-06-20 16:11:12.446254
# Unit test for function sanitize_keys
def test_sanitize_keys():
    ignore = ['test_ignore','test_result','test_dict','test_list','test_set','test_string']
    old_data = {'test_dont_ignore':'test_result',
                'test_ignore':'test_result',
                'test_dict':{'test_dont_ignore':'test_result',
                             'test_ignore':'test_result',
                             'test_list':['test_dont_ignore',
                                          'test_ignore']},
                'test_list':['test_dont_ignore',
                             'test_ignore'],
                'test_set':{'test_dont_ignore',
                            'test_ignore'}
               }
    no_value='test_ignore'

# Generated at 2022-06-20 16:11:22.420294
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        name=dict(type='str', required=True),
        state=dict(type='str', default='present', fallback=(env_fallback, 'MOLECULE_STATE')),
    )

    parameters = dict(
        name='foo',
    )

    no_log_values = set_fallbacks(argument_spec, parameters)
    assert no_log_values == set()

    assert parameters == dict(
        name='foo',
        state='present',
    )

    os.environ['MOLECULE_STATE'] = 'absent'
    parameters = dict(
        name='foo',
    )
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert no_log_values == set()


# Generated at 2022-06-20 16:11:33.755304
# Unit test for function remove_values
def test_remove_values():
    test_data = [
        'ANSIBLE_REMOTE_USER',
        'ANSIBLE_NET_USERNAME',
        'ANSIBLE_NET_PASSWORD',
        'ANSIBLE_NET_AUTH_PASS',
    ]
    assert 'ANSIBLE_NET_USERNAME' in remove_values(test_data, no_log_strings=['ANSIBLE_NET_USERNAME'])
    assert 'ANSIBLE_NET_USERNAME' not in remove_values(test_data, no_log_strings=['ANSIBLE_NET_USERNAME'])
    assert 'ANSIBLE_NET_PASSWORD' in remove_values(test_data, no_log_strings=['ANSIBLE_NET_PASSWORD'])

# Generated at 2022-06-20 16:11:45.375548
# Unit test for function sanitize_keys
def test_sanitize_keys():
    ignore_keys = frozenset(['foo', 'bar'])
    no_log_strs = frozenset(["'pass'", "'private_key'"])

    # Set up the data we will sanitize
    # In this test, we change all keys that aren't ignored and do not contain a no_log string

# Generated at 2022-06-20 16:11:56.284726
# Unit test for function remove_values
def test_remove_values():
    import pprint
    def test(old):
        new = remove_values(old, no_log_strings=[])
        assert old == new

    test('foo')
    test(b'foo')
    test(1)
    test(1.0)
    test({1, '2', b'3'})
    test([4, '5', b'6'])
    test(set(['a', 'b']))
    test((7, '8', b'9'))

    test({'1': {'2': [3, 4]}, '5': set(['6', '7'])})
    test([{'1': {'2': [3, 4]}, '5': set(['6', '7'])}])


# Generated at 2022-06-20 16:12:05.281763
# Unit test for function env_fallback
def test_env_fallback():
    """env_fallback unit tests"""

    # error without any args
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback()

    # error without any matching environment variables
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('UNKNOWN')

    # error without any matching environment variables
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('UNKNOWN', 'FOO')

    # match first var
    assert env_fallback('ANSIBLE_ANSIBLE_CONNECTION') == 'local'

    # match second var
    os.environ['FOO'] = 'bar'
    assert env_fallback('UNKNOWN', 'FOO') == 'bar'

    # match first var

# Generated at 2022-06-20 16:12:13.929244
# Unit test for function env_fallback
def test_env_fallback():
    if 'AZURE_TEST_ENV_FALLBACK' in os.environ:
        del os.environ['AZURE_TEST_ENV_FALLBACK']
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('AZURE_TEST_ENV_FALLBACK')
    os.environ['AZURE_TEST_ENV_FALLBACK'] = "1"
    res = env_fallback('AZURE_TEST_ENV_FALLBACK')
    assert res == "1"


# Generated at 2022-06-20 16:12:23.010108
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Ensure fallback values are set
    argument_spec = dict(
        alpha=dict(default=None, fallback=(lambda x: 'one', ['ALPHA'])),
        beta=dict(default=None, fallback=(lambda: 'two')),
        charlie=dict(default=None, fallback=(lambda x: 'three', 'CHARLIE')),
    )
    parameters = dict()
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters == dict(alpha='one', beta='two', charlie='three')
    assert len(no_log_values) == 0

    # Ensure no_log values are tracked

# Generated at 2022-06-20 16:12:28.687403
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('ANSIBLE_STRICT_COMPARISON', 'ANSIBLE_STRICT_COMPARISON') == 'ANSIBLE_STRICT_COMPARISON'

    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('ANSIBLE_STRICT_COMPARISON')



# Generated at 2022-06-20 16:12:39.737280
# Unit test for function remove_values
def test_remove_values():
    no_log_strings = ["password", "secret", "private_key", "key_data", "access_token", "client_secret"]
    ansible_module_args = "{\"secret_parameter\": \"secret_value\", \"no_log_parameter\": \"nolog_value\"}"

    # Deferred removals is a deque
    assert isinstance(remove_values(ansible_module_args, no_log_strings), str)

# Generated at 2022-06-20 16:13:10.449996
# Unit test for function set_fallbacks
def test_set_fallbacks():
    test_spec = {
        'param1': {'type': 'str', 'required': True, 'no_log': True, 'fallback': (env_fallback, ['param1_env', 'param2_env'])},
        'param2': {'type': 'bool', 'required': True, 'fallback': (env_fallback, ['param2_env'])},
        'param3': {'type': 'str', 'required': True},
        'param4': {'type': 'str', 'required': True, 'fallback': (env_fallback, ['param4_env'], {'default': 'param4_default'})}
    }
    test_parameters = {'param3': 'param3'}
    no_log_values = set_fallbacks(test_spec, test_parameters)


# Generated at 2022-06-20 16:13:24.344486
# Unit test for function set_fallbacks
def test_set_fallbacks():
    arg_spec = dict(
        foo=dict(type='str', fallback=(env_fallback, 'ANSIBLE_NET_SSH_KEYFILE')),
        bar=dict(type='int', fallback=(env_fallback, 'ANSIBLE_NET_SSH_PORT')),
        foobar=dict(type='bool', fallback=(env_fallback, 'ANSIBLE_NET_FOOBAR')),
        baz=dict(type='bool', fallback=(env_fallback, 'ANSIBLE_NET_BAZ')),
        foobaz=dict(type='bool', fallback=(env_fallback, 'ANSIBLE_NET_FOOBAZ')),
    )

# Generated at 2022-06-20 16:13:32.787079
# Unit test for function remove_values
def test_remove_values():
    str = 'foo=bar'
    no_log_strings = [str]
    value = {}
    value['name'] = 'test'
    value['test_val'] = str
    value['test_val2'] = {}
    value['test_val2']['name'] = str
    value['test_val2']['value'] = 'bar'
    value['test_val2']['value2'] = 123
    value['test_val3'] = []
    value['test_val3'].append('foo')
    value['test_val3'].append('bar')
    value['test_val3'].append(str)
    value['test_val3'].append(123)
    value['test_val4'] = {}
    value['test_val4']['name'] = 'foo'


# Generated at 2022-06-20 16:13:44.379942
# Unit test for function sanitize_keys
def test_sanitize_keys():
    #
    # Test that keys in a collection of MutableMappings are sanitized.
    #
    data = [{u'key1': u'value1', u'key2': [u'value2']}]

    def _sanitize_keys_helper(data):
        return sanitize_keys(data, [u'value1'], ignore_keys=frozenset(['key2']))

    mock_data = [{u'key1': u'**VALUE_REMOVED**', u'key2': [u'value2']}]
    assert _sanitize_keys_helper(data) == mock_data
    assert _sanitize_keys_helper(mock_data) == mock_data

    #
    # Test that keys in a collection of MutableSequences are sanitized.
   

# Generated at 2022-06-20 16:13:46.089493
# Unit test for function env_fallback
def test_env_fallback():
    assert len(os.environ) is len(env_fallback(*os.environ))



# Generated at 2022-06-20 16:13:57.881444
# Unit test for function sanitize_keys
def test_sanitize_keys():
    # Create a simple dict with a nested dict
    simple_dict = dict(key1='value1',
                       key2='value2',
                       key3=dict(key31='value31',
                                 key32='value32'),
                       key4=['value41',
                             'value42'])
    # Create a class with a dict attribute
    class DictClass(object):
        def __init__(self, key='value'):
            self.key = key
            self.dict_attr = simple_dict

    dc = DictClass()

    # Create a class with a list of classes with dict attributes
    class ListClass(object):
        def __init__(self):
            self.list = []

        def add(self, c):
            self.list.append(c)

    lc = ListClass()
    lc

# Generated at 2022-06-20 16:14:04.852804
# Unit test for function sanitize_keys
def test_sanitize_keys():
    # this test is used to test the function sanitize_keys
    assert sanitize_keys({"key1": "value1", "key2": "value2", "key3": "value3"}, {"value1"}) == {"key2": "value2", "key3": "value3"}
    assert sanitize_keys({"key1": "value1", "key2": "value2", "key3": "value3"}, {"value1", "value2"}) == {"key3": "value3"}
    assert sanitize_keys({"key1": "value1", "key2": "value2", "key3": "value3"}, {"value1", "value2", "value3"}) == {}
    assert sanitize_keys({"key1": {"key11": "value1"}}, {"value1"}) == {}



# Generated at 2022-06-20 16:14:07.451453
# Unit test for function set_fallbacks
def test_set_fallbacks():
  # TODO: test this function
  assert set_fallbacks({}, {}) == set()



# Generated at 2022-06-20 16:14:15.611872
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(state=dict(default='present', choices=['present', 'absent'], type='str'))
    parameters = dict()
    no_log_values = set()

    test_value = 'present'
    no_log_values.update(set_fallbacks(argument_spec, parameters))
    assert parameters['state'] == test_value
    assert parameters['state'] not in no_log_values



# Generated at 2022-06-20 16:14:17.812479
# Unit test for function remove_values
def test_remove_values():
    for i in range(0, len(remove_values_parameters)):
        new_value = remove_values(remove_values_parameters[i]['value'], remove_values_parameters[i]['no_log_strings'])
        assert new_value == remove_values_parameters[i]['result']



# Generated at 2022-06-20 16:14:44.215849
# Unit test for function set_fallbacks
def test_set_fallbacks():
    spec = dict(
        foo=dict(type='str', fallback=(env_fallback, 'FOO')),
        bar=dict(type='str', fallback=(env_fallback, ['BAR1', 'BAR2'])),
        baz=dict(type='list', fallback=(env_fallback, 'BAZ', dict(delimiter=' '))),
        quux=dict(type='str', fallback=(env_fallback, 'QUUX', dict(boolean=True))),
        quuz=dict(type='bool', fallback=(env_fallback, 'QUUZ', dict(boolean=True)), default=False),
        corge=dict(type='bool', fallback=(env_fallback, 'CORGE', dict(boolean=True)), no_log=True),
    )


# Generated at 2022-06-20 16:14:46.071992
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys({'no_log': None}, ['no_log']) == {'log': None}
    assert sanitize_keys({'no_log': {'foo': None}}, ['no_log']) == {'log': {'foo': None}}

