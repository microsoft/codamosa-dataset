

# Generated at 2022-06-20 16:05:50.998336
# Unit test for function set_fallbacks

# Generated at 2022-06-20 16:06:01.578380
# Unit test for function remove_values
def test_remove_values():
    # some basic testing ...
    assert remove_values({'foo': 'bar'}, ('bar',)) == {'foo': '**VALUE_REDACTED**'}
    assert remove_values(['foo', 'bar'], ('bar',)) == ['foo', '**VALUE_REDACTED**']
    assert remove_values({'foo': 'bar', 'bar': 'foo', 'baz': 'baz'}, ('foo',)) == {'foo': '**VALUE_REDACTED**', 'bar': '**VALUE_REDACTED**', 'baz': 'baz'}

# Generated at 2022-06-20 16:06:10.683162
# Unit test for function sanitize_keys
def test_sanitize_keys():
    data = dict(
        a=dict(
            b=dict(
                c='c',
                d='d'
            )
        )
    )
    assert 'c' in data['a']['b']
    assert 'd' in data['a']['b']
    data = sanitize_keys(data, ['c'])
    assert 'c' in data['a']['b']
    assert 'd' in data['a']['b']
    data = sanitize_keys(data, ['d'])
    assert 'c' in data['a']['b']
    assert 'd' in data['a']['b']



# Generated at 2022-06-20 16:06:21.120398
# Unit test for function sanitize_keys
def test_sanitize_keys():
    # Test logging a dict of dicts
    test_dict = {'test': {'test_string': 'secret1'}}
    secret_strings = ['secret1']
    expected_dict = {'test': {'te**': 'secret1'}}
    assert sanitize_keys(test_dict, secret_strings) == expected_dict

    # Test logging a dict of dicts ignoring a key
    test_dict = {'test': {'test_string': 'secret1'}}
    ignore_keys = ['test']
    expected_dict = {'test': {'test_string': 'secret1'}}
    assert sanitize_keys(test_dict, secret_strings, ignore_keys) == expected_dict

    # Test sanitizing a dict of lists

# Generated at 2022-06-20 16:06:33.939039
# Unit test for function remove_values
def test_remove_values():
    from ansible.compat.tests import unittest

    class TestModule(unittest.TestCase):
        def test_remove_values(self):
            value = 'test_test_test'
            no_log_strings = ['test']
            new_value = remove_values(value, no_log_strings)
            assert new_value == '__test__'


# Generated at 2022-06-20 16:06:44.599384
# Unit test for function sanitize_keys
def test_sanitize_keys():
    x = {'foo': 'bar'}
    x['baz'] = sanitize_keys(x, ['foo'])
    assert x['baz'] == {'foo': 'bar'}
    assert x == {'baz': {'foo': 'bar'}, 'foo': 'bar'}

    x = {'foo': 'bar', 'baz': {'name': 'foo'}, 'name': 'foo'}
    x['baz'] = sanitize_keys(x, ['foo'], ignore_keys=frozenset(['name']))
    assert x['baz'] == {'name': 'foo'}
    assert x == {'foo': 'bar', 'baz': {'name': 'foo'}, 'name': 'foo'}


# Generated at 2022-06-20 16:06:51.985195
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'arg1': {'fallback': (env_fallback, ['ARG1'])}}
    parameters = {}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert set() == no_log_values
    parameters = {'arg1': 'arg1'}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert set() == no_log_values
    os.environ['ARG1'] = 'test_env_fallback'
    parameters = {}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert set() == no_log_values
    parameters = {'arg1': 'arg1'}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert set

# Generated at 2022-06-20 16:06:56.651408
# Unit test for function sanitize_keys
def test_sanitize_keys():
    data = {'user': 'test', 'password': 'test123'}
    no_log_strings = ['test123']
    result_data = sanitize_keys(data, no_log_strings)
    assert result_data == {'pass***rd': 'test123'}



# Generated at 2022-06-20 16:07:02.022035
# Unit test for function env_fallback
def test_env_fallback():
    module = AnsibleModule(argument_spec=dict(), supports_check_mode=True)
    os.environ['TEST_FOO_BAR_VAR'] = 'one'
    os.environ['TEST_FOO_BAR_VAR_SECOND'] = 'two'
    module.exit_json(
        msg='Test env_fallback',
        env_fallback=env_fallback('TEST_FOO_BAR_VAR', 'TEST_FOO_BAR_VAR_SECOND')
    )


# Generated at 2022-06-20 16:07:07.644473
# Unit test for function remove_values
def test_remove_values():

    no_log_strings = {'PASSWORD', 'SECRET'}

    # test list and dict
    old_data = [{'password': 'PASSWORD', 'content': {'secret': 'SECRET'}},
                {'PASSWORD': 'password', 'content': 'content'},
                {'content': {'SECRET': 'secret'}},
                {'content': [{'password': 'PASSWORD', 'content': {'secret': 'SECRET'}},
                             {'PASSWORD': 'password', 'content': 'content'},
                             {'content': {'SECRET': 'secret'}}]}]

    new_data = remove_values(old_data, no_log_strings)

# Generated at 2022-06-20 16:07:35.411418
# Unit test for function sanitize_keys
def test_sanitize_keys():
    set_module_args({'a': '1', 'b': {'c': '2', 'd': '3'}, 'e': ['1', '2', '3']})
    result = AnsibleModule(argument_spec={'a': {'type': 'str', 'no_log': True},
                                          'b': {'type': 'dict', 'no_log': True},
                                          'e': {'type': 'list', 'no_log': True}},
                           no_log=True).sanitize()
    # No log values were removed from the data
    assert result == {'a': '1', 'b': {'c': '2', 'd': '3'}, 'e': ['1', '2', '3']}

    # Now make sure keys were sanitized

# Generated at 2022-06-20 16:07:42.665689
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        foo=dict(fallback=(env_fallback, ('FALLBACK_FOO', 'other'))),
        bar=dict(fallback=(env_fallback, ('FALLBACK_BAR',))),
        baz=dict(fallback=(env_fallback,)),
    )
    parameters = dict(
        foo='zab',
        bar='bar',
        baz='baz',
    )
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert len(no_log_values) == 2
    assert 'zab' in no_log_values
    assert 'baz' in no_log_values



# Generated at 2022-06-20 16:07:49.200898
# Unit test for function sanitize_keys
def test_sanitize_keys():
    pass
# Metadata for function sanitize_keys
sanitize_keys.no_log_strings = set(['password'])
sanitize_keys._ignore_keys = frozenset(['ansible_facts', 'ansible_ssh_host', 'ansible_module_name', 'ansible_module_args'])


# Generated at 2022-06-20 16:07:52.197707
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_STRATEGY'] = 'linear'
    result = env_fallback('ANSIBLE_STRATEGY')
    assert result == 'linear'


# Generated at 2022-06-20 16:07:57.475432
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['TEST_VAR'] = 'test_var'

    try:
        assert env_fallback('TEST_VAR') == 'test_var'
        assert env_fallback('test_var') == 'test_var'
    finally:
        del os.environ['TEST_VAR']



# Generated at 2022-06-20 16:08:07.354957
# Unit test for function env_fallback
def test_env_fallback():
    with EnvVars(ANSIBLE_FALLBACK_ENABLES='True', ANSIBLE_FALLBACK_TEST_ENV_VAR_1='my_value_1', ANSIBLE_FALLBACK_TEST_ENV_VAR_2='my_value_2',
                 ANSIBLE_FALLBACK_TEST_ENV_VAR_3='my_value_3'):
        assert env_fallback('TEST_ENV_VAR_1', 'TEST_ENV_VAR_2') == 'my_value_1'
        assert env_fallback('TEST_ENV_VAR_2', 'TEST_ENV_VAR_1') == 'my_value_2'
        with pytest.raises(AnsibleFallbackNotFound):
            env_fallback

# Generated at 2022-06-20 16:08:14.288141
# Unit test for function sanitize_keys

# Generated at 2022-06-20 16:08:21.883127
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'foo': {'type': 'str', 'fallback': ('env_fallback', 'BAR')}}
    parameters = {'foo': 'bar'}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters == {'foo': 'bar'}
    assert no_log_values == set()
    parameters = {}
    os.environ['BAR'] = 'bar'
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters == {'foo': 'bar'}
    assert no_log_values == set()
    del os.environ['BAR']
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters == {}
    assert no_log_values == set()



# Generated at 2022-06-20 16:08:32.049943
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_VAR_1'] = "TEST VALUE 1"
    os.environ['ANSIBLE_TEST_VAR_2'] = "TEST VALUE 2"
    assert env_fallback('ANSIBLE_TEST_VAR_1', 'ANSIBLE_TEST_VAR_2') == "TEST VALUE 1"  # noqa
    del os.environ['ANSIBLE_TEST_VAR_1']
    assert env_fallback('ANSIBLE_TEST_VAR_1', 'ANSIBLE_TEST_VAR_2') == "TEST VALUE 2"  # noqa
    del os.environ['ANSIBLE_TEST_VAR_2']

# Generated at 2022-06-20 16:08:37.903920
# Unit test for function set_fallbacks
def test_set_fallbacks():
    '''Test that the set_fallback function works'''
    test_spec = {'param1': {'type': 'bool', 'fallback': (env_fallback, 'TEST_PARAM1')}}
    spec_no_param = {'param1': {'type': 'bool', 'fallback': (env_fallback, 'TEST_PARAM1')}}
    spec_no_fallback = {'param1': {'type': 'bool'}}
    spec_fallback_return_none = {'param1': {'type': 'bool', 'fallback': (env_fallback, 'TEST_PARAM1')}}
    spec_no_env_var = {'param1': {'type': 'bool', 'fallback': (env_fallback, 'TEST_PARAM1')}}

    test_

# Generated at 2022-06-20 16:09:09.739879
# Unit test for function remove_values
def test_remove_values():
    '''sanitize: Removes no_log_strings from object'''
    assert remove_values('hello world', ['hello']) == '**VALUE REMOVED BY ANSIBLE**'
    assert remove_values('helloworld', ['hello']) == '**VALUE REMOVED BY ANSIBLE**'
    assert remove_values('helloworld', ['hello', 'world']) == '**VALUE REMOVED BY ANSIBLE**'
    assert remove_values({'hello':'world'}, ['hello']) == {'**VALUE REMOVED BY ANSIBLE**': 'world'}
    assert remove_values({'hello':'world'}, ['world']) == {'hello': '**VALUE REMOVED BY ANSIBLE**'}
    assert remove_values({'hello':'world'}, ['hello', 'world']) == {}

# Generated at 2022-06-20 16:09:20.777440
# Unit test for function remove_values
def test_remove_values():
    assert remove_values([{'a': 'b', 'c': [1, 2, 3]}, ['a', 'b', 'c'], elist, {'d': 'e', 'f': 'g'}], ['a', 'b', 'c']) == [{'****': '****', '****': [1, 2, 3]}, ['****', '****', '****'], eset, {'****': '****', '****': '****'}]
    assert remove_values({'a': 'b', 'c': [1, 2, 3], 'd': 'e', 'f': 'g'}, ['a', 'b', 'c', 'e', 'g']) == {'****': '****', '****': [1, 2, 3], 'd': '****', 'f': '****'}
    assert remove_values

# Generated at 2022-06-20 16:09:31.977949
# Unit test for function sanitize_keys
def test_sanitize_keys():
    expected_result = dict(my_list=[dict(my_dict=dict(key3='value3'))],
                           my_dict=dict(key2='value2'))
    param = dict(my_list=[dict(my_dict=dict(key1='value1'))],
                 my_dict=dict(key2='value2'))
    param[0] = dict(my_dict=dict(key1='value1'))
    param[0][0] = dict(key1='value1')
    param2 = dict(my_list=[dict(my_dict=dict(key1='value1'))], key1='value1')
    param3 = dict(my_list=[dict(my_dict=dict(key1='value1'))], key1='value1')

# Generated at 2022-06-20 16:09:42.234305
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'my_param': {'type': 'str', 'fallback': (env_fallback, ('TEST', 'TEST2'))},
        'my_param2': {'type': 'str', 'fallback': (env_fallback, 'TEST3')},
        'my_param3': {'type': 'str', 'fallback': (env_fallback, {'a': 'b'})},
        'my_param4': {'type': 'str', 'fallback': (env_fallback, {'b': 'c'}, {'a': 'b'})}
    }

    parameters = {
        'my_param': None,
        'my_param3': None
    }

    with pytest.raises(AnsibleFallbackNotFound):
        set_fall

# Generated at 2022-06-20 16:09:53.778781
# Unit test for function set_fallbacks
def test_set_fallbacks():
    from ansible.module_utils.basic import AnsibleModule

    def test(a, b=None):
        return a + b

    def test2(a):
        return a * 2


# Generated at 2022-06-20 16:10:01.555434
# Unit test for function sanitize_keys
def test_sanitize_keys():
    '''
    Test sanitize_keys function with different kinds of objects
    '''
    assert sanitize_keys('obj', None) == 'obj'
    assert sanitize_keys(1, None) == 1
    assert sanitize_keys(1.1, None) == 1.1
    assert sanitize_keys(True, None) is True
    assert sanitize_keys(complex(1, 1), None) == 1+1j
    assert sanitize_keys(object, None) == object
    assert sanitize_keys(object(), None) == object()


# Generated at 2022-06-20 16:10:08.819425
# Unit test for function env_fallback
def test_env_fallback():
    with mock.patch.dict(os.environ, {'FROM_ENV': 'foo'}):
        assert env_fallback('NOT_IN_ENV', 'FROM_ENV') == 'foo'
    with mock.patch.dict(os.environ, {'NOT_IN_ENV': 'bar'}), pytest.raises(AnsibleFallbackNotFound):
        env_fallback('FROM_ENV')
    with mock.patch.dict(os.environ, {'NOT_IN_ENV': 'baz'}), pytest.raises(AnsibleFallbackNotFound):
        env_fallback('FROM_ENV', 'NOT_IN_ENV')



# Generated at 2022-06-20 16:10:19.668700
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys({}, ['sanitized']) == {}
    assert sanitize_keys(1, ['sanitized']) == 1
    assert sanitize_keys('sanitized', ['sanitized']) == '*****'
    assert sanitize_keys('sanitized', []) == 'sanitized'
    assert sanitize_keys({'sanitized':'sanitized'}, ['sanitized']) == {'******':'*****'}
    assert sanitize_keys({'sanitized': 'sanitized'}, []) == {'sanitized': 'sanitized'}
    assert sanitize_keys({'sanitized': 'sanitized'}, ['not in here']) == {'sanitized': '*****'}
    assert sanitize_keys({'sanitized': 'sanitized'}, ['sanitized', 'sanitized'])

# Generated at 2022-06-20 16:10:29.258737
# Unit test for function remove_values
def test_remove_values():

    output = remove_values('test_string', ['_string'])
    assert output == 'test'

    output = remove_values('test', ['_string'])
    assert output == 'test'

    output = remove_values(['test_string'], ['_string'])
    assert output == ['test']

    output = remove_values({'test_string': 'test_string'}, ['_string'])
    assert output == {'test': 'test'}

    output = remove_values({'test_string': 'test_string', 'int_value': 0}, ['_string'])
    assert output == {'test': 'test', 'int_value': 0}

    output = remove_values({'test_string': 'test_string', 'int_value': 0}, ['string'])

# Generated at 2022-06-20 16:10:37.591178
# Unit test for function sanitize_keys
def test_sanitize_keys():
    d1 = {u'password': u'12345', u'username': u'admin', u'connect_timeout': 100}
    assert_equal(d1, sanitize_keys(d1, ["12345"]))
    d2 = {u'password': u'12345', u'username': u'admin', u'connect_timeout': 100}
    assert_equal({u'*****': u'12345', u'username': u'admin', u'connect_timeout': 100}, sanitize_keys(d2, ["password"]))
    d3 = {u'password': u'12345', u'username': u'admin', u'connect_timeout': 100}

# Generated at 2022-06-20 16:11:35.150859
# Unit test for function sanitize_keys
def test_sanitize_keys():
    # assertRaises
    values = {
        'div': 'b',
        'a': 'h',
        'pa': 'b',
        'params': {'pass': 'd', 'bd': 'd'},
        'password': 'd',
        'dict': {'password': 'd', 'passwd': 'd'},
        'list': [{'passs': 'd'}]
    }


# Generated at 2022-06-20 16:11:46.540314
# Unit test for function env_fallback
def test_env_fallback():
    module_name = get_pytest_execution_environment().get('MODULE_NAME')
    if module_name == 'ec2_group':
        fail_key = 'AWS_SECRET_ACCESS_KEY'
        success_key = 'AWS_ACCESS_KEY_ID'
    elif module_name == 'azure_rm_dnsrecordset':
        fail_key = 'AZURE_CLIENT_SECRET'
        success_key = 'AZURE_CLIENT_ID'
    elif module_name == 'gcp_compute_instance_group_manager':
        fail_key = 'GOOGLE_CLOUD_KEYFILE_JSON'
        success_key = 'GCE_EMAIL'
    elif module_name == 'gcp_compute_ssl_certificate':
        fail_

# Generated at 2022-06-20 16:11:58.277765
# Unit test for function set_fallbacks
def test_set_fallbacks():
  import unittest
  """Test fallback options for Ansible module argument_spec"""
  class TestSetFallbacks(unittest.TestCase):
    """Test function set_fallbacks"""
    def test_set_fallbacks(self):
      """Test set_fallbacks with valid input"""
      sb_parameter_spec = dict(
        src=dict(type='path'),
        dest=dict(type='path'),
        force=dict(type='bool', default=False),
      )
      sb_parameters = dict(src='abc')
      expected = set(['abc'])
      no_log_values = set_fallbacks(sb_parameter_spec, sb_parameters)
      self.assertEqual(expected, no_log_values)
      sb_parameters = dict()
      expected = set

# Generated at 2022-06-20 16:12:05.429674
# Unit test for function remove_values
def test_remove_values():
    value = {'a':{'a':'key','b':'password','c':'secret','d':'a:b:c:d'},'b':'value','c':{'a':['value1','value2','value3'],'b':['secret','secret2','secret3']}}
    no_log_strings = ['password','secret','secret1','secret2','secret3']
    assert remove_values(value, no_log_strings) == {'a':{'a':'key','b':'****','c':'****','d':'a:b:c:d'},'b':'value','c':{'a':['value1','value2','value3'],'b':['****','****','****']}}



# Generated at 2022-06-20 16:12:13.443121
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('_INVALID') == env_fallback('_INVALID')
    assert env_fallback('PATH') != env_fallback('_INVALID')
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('_INVALID')
    # if no args are specified, then AnsibleFallbackNotFound should be returned
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback()



# Generated at 2022-06-20 16:12:21.897619
# Unit test for function remove_values
def test_remove_values():
    no_log_strings = ('no_log',)

    # Test for empty inputs
    assert remove_values(None, no_log_strings) == ''
    assert remove_values([], no_log_strings) == []

    # Test for various non-container types
    assert remove_values(False, no_log_strings) is False
    assert remove_values(True, no_log_strings) is True
    assert remove_values(10, no_log_strings) == 10
    assert remove_values('test string', no_log_strings) == 'test string'
    assert remove_values(u('non_ascii'), no_log_strings) == u('non_ascii')
    assert remove_values(b'binary', no_log_strings) == b'binary'

    # Test dict
    dict_value = dict

# Generated at 2022-06-20 16:12:33.120867
# Unit test for function remove_values
def test_remove_values():
    # This only tests non-container types.
    # Note that set is not tested because sets are not hashable and cannot be used as keys.

    assert remove_values(123, [123]) == '123'
    assert remove_values('abc', [123]) == 'abc'
    assert remove_values(123, []) == 123
    assert remove_values('abc', []) == 'abc'
    assert remove_values('not-private', [123]) == 'not-private'
    assert remove_values(123, ['123']) == '123'
    assert remove_values('abc', ['123']) == 'abc'
    assert remove_values('not-private', ['123']) == 'not-private'


# Generated at 2022-06-20 16:12:43.443790
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'option1': {'fallback': (env_fallback, ['ENV_1', 'ENV_2'])},
        'option2': {'fallback': (env_fallback, ['ENV_3', 'ENV_4'])},
    }
    parameters = {'option1': None}
    assert set_fallbacks(argument_spec, parameters) == set()
    assert parameters['option1'] is None

    os.environ['ENV_2'] = 'test_env2'
    assert set_fallbacks(argument_spec, parameters) == set()
    assert parameters['option1'] == 'test_env2'

    assert set_fallbacks(argument_spec, {'option2': None}) == set()
    assert set_fallbacks(argument_spec, {}) == set()

# Generated at 2022-06-20 16:12:52.877361
# Unit test for function remove_values
def test_remove_values():
    """Test the remove_values function."""
    # Dicts
    value = {'ansible_password': 'foo', 'ansible_ssh_pass': 'bar', 'ansible_become_pass': 'baz'}
    assert remove_values(value, ['*']) == {'ansible_password': 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER',
                                           'ansible_ssh_pass': 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER',
                                           'ansible_become_pass': 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'}

    value = {'ansible_password': 'foo', 'no_log': True}

# Generated at 2022-06-20 16:13:03.502607
# Unit test for function remove_values
def test_remove_values():
    no_log_strings = ['password', 'pwd', 'ssh_pass', 'become_pass']
    value = 'abc password def'
    assert remove_values(value, no_log_strings) == 'abc ******** def'
    value = 'abc pwd def'
    assert remove_values(value, no_log_strings) == 'abc ******** def'
    value = 'abc ssh_pass def'
    assert remove_values(value, no_log_strings) == 'abc ******** def'
    value = 'abc become_pass def'
    assert remove_values(value, no_log_strings) == 'abc ******** def'
    value = 'abc ssh_pwd def'
    assert remove_values(value, no_log_strings) == 'abc ssh_pwd def'

# Generated at 2022-06-20 16:13:55.510174
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_VALUE'] = 'FOO'
    assert env_fallback('ANSIBLE_TEST_VALUE') == 'FOO'
    try:
        env_fallback('ANSIBLE_DOES_NOT_EXIST')
    except AnsibleFallbackNotFound:
        pass
    else:
        assert 'Fallback should not have found a value'



# Generated at 2022-06-20 16:14:01.371935
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('test') == os.environ['test']
    assert env_fallback('test', 'test2') == os.environ['test']
    assert env_fallback('test1', 'test2') == os.environ['test2']
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback()
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('test1', 'test2', 'test3')



# Generated at 2022-06-20 16:14:12.214429
# Unit test for function remove_values
def test_remove_values():
  result = remove_values('test_test', no_log_strings=['test'])
  assert 'test' not in result
  result = remove_values({'test_test':4, 'test_test2':'test'}, no_log_strings=['test'])
  assert 'test' not in result
  result = remove_values(['test_test', 'test_test2'], no_log_strings=['test'])
  assert 'test' not in result.__str__()
  result = remove_values(['test_test', 'test_test2'], no_log_strings=['test'])
  assert 'test' not in result
  result = remove_values(('test_test', 'test_test2'), no_log_strings=['test'])
  assert 'test' not in result

# Generated at 2022-06-20 16:14:22.938244
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys({'a': 1}, ['b']) == {'a': 1}
    assert sanitize_keys(['a', 'b'], ['b']) == ['a', 'b']
    assert sanitize_keys({'a': 1, 'b': 2}, ['a']) == {'[cO]': 1, 'b': 2}
    assert sanitize_keys(['a', 'b'], ['a']) == ['[cO]', 'b']
    assert sanitize_keys({'a': 1, 'b': 2}, ['a', 'b']) == {'[cO]': 1, '[cO]': 2}
    assert sanitize_keys(['a', 'b'], ['a', 'b']) == ['[cO]', '[cO]']
   

# Generated at 2022-06-20 16:14:33.536280
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys('test_value', 'test_value') == '**********'
    assert sanitize_keys(['test_value', 'test_value'], 'test_value') == ['**********', '**********']
    assert sanitize_keys(['test_value', ['test_value']], 'test_value') == ['**********', ['**********']]
    assert sanitize_keys(['test_value', {'test_value': 'test_value'}], 'test_value') == ['**********', {'**********': '**********'}]
    assert sanitize_keys(['test_value', {'test_value': 'test_value'}], 'test_value') == ['**********', {'**********': '**********'}]

# Generated at 2022-06-20 16:14:44.281885
# Unit test for function remove_values
def test_remove_values():

    no_log_strings = ['password', 'secret']
    value = {'password': 'mysecret', 'hostname': 'myhost', 'users': [{'user': 'root', 'password': 'mysecret'}, {'user': 'mysql'}]}
    assert remove_values(value, no_log_strings) == {'password': 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER', 'hostname': 'myhost', 'users': [{'user': 'root', 'password': 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'}, {'user': 'mysql'}]}
    value = [{'password': 'mysecret', 'hostname': 'myhost'}, {'password': 'mysecret', 'hostname': 'myhost'}]

# Generated at 2022-06-20 16:14:54.369681
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Given
    argument_spec = dict(
        hello=dict(
            fallback=('env_fallback', 'HELLO_WORLD')
        ),
        world=dict(
            fallback=(env_fallback, 'WORLD_HELLO')
        ),
        hello_no_log=dict(
            fallback=('env_fallback', 'HELLO_WORLD'),
            no_log=True
        ),
        world_no_log=dict(
            fallback=(env_fallback, 'WORLD_HELLO'),
            no_log=True
        ),
    )
    parameters = dict()
    os.environ['HELLO_WORLD'] = 'hello'
    os.environ['WORLD_HELLO'] = 'world'

    # When
    res = set_fall