

# Generated at 2022-06-20 16:05:24.646054
# Unit test for function set_fallbacks
def test_set_fallbacks():
    params = {}
    argspec_func1(params)
    assert params['val1'] == 1
    assert params['val2'] == 2
    params = {}
    argspec_func2(params)
    assert params['val2'] == 2
    assert 'val1' not in params
    params = {}
    argspec_func3(params)
    assert params['val1'] == 1
    assert params['val2'] == 2



# Generated at 2022-06-20 16:05:31.385657
# Unit test for function sanitize_keys
def test_sanitize_keys():
    import collections
    # Test dictionary
    input_data = {
        'a': {1: 2},
        '_ansible_no_log': [{'x': 'secret'}, {'y': 'secret'}],
        '_ansible_no_log_': collections.OrderedDict([('x', 'secret'), ('y', 'secret')]),
    }
    expected_output = {
        'a': {1: 2},
        '_ansible_no_log_': {'x': 'secret', 'y': 'secret'},
    }
    assert sanitize_keys(input_data, ['secret']) == expected_output

    # Test list
    input_data = [
        ['secret1', 'secret2'],
        {'_ansible_no_log_': 'secret'},
    ]

# Generated at 2022-06-20 16:05:36.464000
# Unit test for function env_fallback
def test_env_fallback():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.urls import open_url

    test_env_vars = ImmutableDict({'FOO': 'foo', 'BAR': 'bar', 'FOOBAR': 'foobar'})

    # Setup environment variables to test different conditions
    os.environ['FOO'] = 'foo1'
    os.environ['BAR'] = 'bar1'

    # Test when arg exists in env var
    assert 'foo1' == env_fallback('FOO')

    # Test when arg doesn't exist in env var
    assert 'bar1' == env_fallback('BAR')

    # Test when arg doesn't exist in env var and default value is provided

# Generated at 2022-06-20 16:05:42.096900
# Unit test for function remove_values
def test_remove_values():

    # A few non-container types
    assert remove_values(None, ['a']) is None
    assert remove_values(True, ['a']) is True
    assert remove_values(False, ['a']) is False
    assert remove_values('', ['a']) == ''
    assert remove_values(b'', ['a']) == b''
    assert remove_values(1, ['a']) == 1

    # Various container types
    assert remove_values({}, ['a']) == {}
    assert remove_values([], ['a']) == []
    assert remove_values(set(), ['a']) == set()

    # Various container values
    assert remove_values({1: 2}, ['a']) == {1: 2}

# Generated at 2022-06-20 16:05:47.082582
# Unit test for function sanitize_keys
def test_sanitize_keys():
    sanitize_keys({'k1': 'v1', 'k2': 'v2'}, ['v1', 'v2'], ignore_keys=None)
    sanitize_keys({'k1': 'v1', 'k2': 'v2'}, ['v1', 'v2'], ignore_keys=['k1'])
    obj = {'k1': 'v1', 'k2': 'v2'}
    sanitize_keys(obj, ['v1', 'v2'], ignore_keys=None)
    assert obj == {'k1': 'v1', 'k2': 'v2'}, "sanitize_keys should not modify the obj"
    obj = {'k1': 'v1', 'k2': 'v2'}

# Generated at 2022-06-20 16:05:58.010657
# Unit test for function remove_values

# Generated at 2022-06-20 16:06:09.663586
# Unit test for function sanitize_keys
def test_sanitize_keys():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import ensure_binary, ensure_text
    import sys

    assert sys.version_info >= (2, 7), "This module is only for Python >= 2.7"

    def test_module(argument_spec, no_log_params):
        module = AnsibleModule(argument_spec=argument_spec)
        keys = []

        for param in no_log_params:
            keys.append(param)
            module.params[param] = 'some value %s' % param

        sanitized_params = sanitize_keys(module.params, keys)
        expected_params = dict()

# Generated at 2022-06-20 16:06:20.565388
# Unit test for function remove_values
def test_remove_values():
    output = dict(a=dict(b=dict(abc='abc', hello='world', this=dict(that='hello world')), c=dict(this='that')),
                  d=dict(b=dict(abc='abc', hello='world', this=dict(that='hello world')), e=dict(this='that')))
    output_wanted = dict(a=dict(b=dict(hello='world', this=dict(that='hello world')), c=dict(this='that')),
                         d=dict(b=dict(hello='world', this=dict(that='hello world')), e=dict(this='that')))

    for key in output['a']['b']:
        if key != 'hello':
            output['a']['b'][key] = None

# Generated at 2022-06-20 16:06:33.081837
# Unit test for function sanitize_keys
def test_sanitize_keys():

    class FakeMapping(Mapping):
        def __init__(self, data):
            self.data = data

        def __getitem__(self, item):
            return self.data[item]

        def __iter__(self):
            return iter(self.data)

        def __len__(self):
            return len(self.data)

    class FakeList(MutableSequence):
        def __init__(self, data):
            self.data = data

        def __getitem__(self, item):
            return self.data[item]

        def __setitem__(self, item):
            self.data[item] = item

        def __delitem__(self, item):
            del self.data[item]

        def __len__(self):
            return len(self.data)


# Generated at 2022-06-20 16:06:43.984735
# Unit test for function set_fallbacks

# Generated at 2022-06-20 16:07:10.634493
# Unit test for function env_fallback
def test_env_fallback():
    with patch.dict(os.environ, {'FOO': 'bar'}):
        assert env_fallback('FOO') == 'bar'
    with patch.dict(os.environ, {'FOO': 'bar'}):
        assert env_fallback('FOO', 'BAR') == 'bar'
    with patch.dict(os.environ, {'FOO': 'bar'}):
        with pytest.raises(AnsibleFallbackNotFound):
            env_fallback('BAR')
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback()


# Generated at 2022-06-20 16:07:21.384456
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys([1], [1]) == [1]
    assert sanitize_keys((1,), [1]) == (1,)
    assert sanitize_keys({1: 2}, [1]) == {1: 2}
    assert sanitize_keys({1: 2, 2: 3}, [1]) == {1: 2, '2': 3}
    assert sanitize_keys({1: 2, 2: 3, 4: 4}, [1]) == {1: 2, '2': 3, 4: 4}
    assert sanitize_keys({1: 2, 2: 3, 4: {5: 6}}, [1, 5]) == {1: 2, '2': 3, '4': {5: 6}}

# Generated at 2022-06-20 16:07:28.429552
# Unit test for function sanitize_keys

# Generated at 2022-06-20 16:07:32.945519
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys({"key": "value"}, {"value"}) == {"key": "VALUE"}
    assert sanitize_keys(["key"], {"key"}) == ["KEY"]



# Generated at 2022-06-20 16:07:41.277500
# Unit test for function remove_values
def test_remove_values():
    # Strings
    assert remove_values('test', ('t',)) == 'es'
    # Sets
    assert remove_values(set('test'), ('t',)) == set('es')
    # Sequences
    assert remove_values(['test', {'password': 'test'}], ('t',)) == ['es', {'password': 'es'}]
    # Mappings
    assert remove_values({'test': 'test', 'test2': {'password': 'test'}}, ('t',)) == {'es': 'es', 'es2': {'password': 'es'}}



# Generated at 2022-06-20 16:07:44.272945
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['A'] = 'bar'
    assert env_fallback('foo', 'A') == 'bar'



# Generated at 2022-06-20 16:07:53.235053
# Unit test for function env_fallback
def test_env_fallback():
    for arg in ('', ' '):  # empty value
        assert env_fallback(arg) == None

    for arg in ('_', '_a'):  # no such key
        assert env_fallback(arg) == None

    original_env = dict(os.environ)   # shallow copy
    for arg in ('A', 'Ab', 'Abc'):
        os.environ[arg] = arg
        assert env_fallback(arg) == arg

    # no fallback key
    os.environ = dict(original_env)



# Generated at 2022-06-20 16:08:04.720736
# Unit test for function remove_values
def test_remove_values():
    result = remove_values(
        {'a': 'foo', 'list': ['bar', 'baz'], 'set': set(['baz', 'bam', 'baw'])},
        ['foo']
    )
    assert result == {'a': 'foo', 'list': ['bar', 'baz'], 'set': set(['baz', 'bam', 'baw'])}

    result = remove_values(
        {'a': 'foo', 'list': ['bar', 'baz'], 'set': set(['baz', 'bam', 'baw'])},
        ['b', 'ba']
    )
    assert result == {'a': 'foo', 'list': [], 'set': set()}


# Generated at 2022-06-20 16:08:11.956038
# Unit test for function remove_values
def test_remove_values():
    assert remove_values(1, [1]) == 1
    assert remove_values('test', ['test']) == '*'
    assert remove_values('test', ['foo']) == 'test'
    assert remove_values('test', []) == 'test'
    assert remove_values({}, []) == {}
    assert remove_values({1: 'test'}, []) == {1: 'test'}
    assert remove_values({1: 'test'}, ['test']) == {1: '*'}
    assert remove_values({'test': 'test'}, []) == {'test': 'test'}
    assert remove_values({'test': 'test'}, ['test']) == {'test': '*'}

# Generated at 2022-06-20 16:08:21.416378
# Unit test for function remove_values
def test_remove_values():
    assert remove_values('abc', set(['c'])) == 'ab'
    assert remove_values('abc', set(['a'])) == 'bc'
    assert remove_values('abc', set(['b'])) == 'ac'
    assert remove_values('abc', set()) == 'abc'
    assert remove_values('abc', set(['a', 'b', 'c'])) == ''
    assert remove_values({'a': 'abc'}, set(['c'])) == {'a': 'ab'}
    assert remove_values({'a': 'abc', 'b': 'cde'}, set(['c'])) == {'a': 'ab', 'b': 'de'}

# Generated at 2022-06-20 16:09:01.102716
# Unit test for function sanitize_keys
def test_sanitize_keys():
    data = dict(
        foo=dict(
            bar=dict(
                baz=1,
                quux='foo',
            ),
            qux=2,
        ),
        list=[dict(baz='bar')],
        set=set(['foo']),
    )

    assert sanitize_keys(data, ['foo']) == dict(
        fo=dict(
            bar=dict(
                baz=1,
                quu=u'foo',
            ),
            qux=2,
        ),
        list=[dict(baz='bar')],
        set=set(['foo']),
    )



# Generated at 2022-06-20 16:09:09.865169
# Unit test for function remove_values
def test_remove_values():
    """Unit tests for function remove_values
    """
    # A really simple test case
    test_dict = {'a': 'b', 'c': 'd', 'e': 'f'}
    result = remove_values(test_dict, ['d'])
    assert result == {'a': 'b', 'c': '*'}

    # A more complex test case
    test_dict = {'a': 'b', 'z': [{'k1': 'v1', 'k2': 'v2'}, {'k3': 'v3', 'k4': 'v4'}]}
    result = remove_values(test_dict, ['v2'])

# Generated at 2022-06-20 16:09:20.823850
# Unit test for function remove_values
def test_remove_values():
    no_log_string = b'test_string'
    complex_no_log_string = b'{"a": "test_string"}'
    no_log_values = [no_log_string, complex_no_log_string]


# Generated at 2022-06-20 16:09:31.978321
# Unit test for function env_fallback
def test_env_fallback():
    """Unit tests for function env_fallback"""
    # Clear out any values in os.environ
    saved_env = os.environ.copy()
    os.environ.clear()
    # first test case: no values in os.environ, no args, should raise exc
    try:
        env_fallback()
        assert False, 'should have raised AnsibleFallbackNotFound'
    except AnsibleFallbackNotFound:
        pass
    # second test case: values in os.environ, no args, should raise exc
    os.environ['SHOULD_NOT_FIND_THIS_VALUE'] = '0'
    try:
        env_fallback()
        assert False, 'should have raised AnsibleFallbackNotFound'
    except AnsibleFallbackNotFound:
        pass
    # third test case: values in os

# Generated at 2022-06-20 16:09:39.895532
# Unit test for function set_fallbacks
def test_set_fallbacks():
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.basic import env_fallback, AnsibleModule
    argument_spec = MutableMapping(username = MutableMapping(type='str', fallback=(env_fallback, ['ANSIBLE_NET_USERNAME'])))
    parameters = {}
    os.environ['ANSIBLE_NET_USERNAME'] = "cisco"
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters.get('username') == "cisco"
    assert not no_log_values



# Generated at 2022-06-20 16:09:44.425311
# Unit test for function remove_values
def test_remove_values():
    # Regression test for https://github.com/ansible/ansible/issues/25190
    # No-log strings should not be removed from non-string values
    assert remove_values(['foo', 42, 'bar'], ['foo']) == ['foo', 42, 'bar']



# Generated at 2022-06-20 16:09:56.563093
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        passwd=dict(type='str', fallback=(env_fallback, ('ANSIBLE_NET_PASSWORD', ), {'require_pass': True})),
        username=dict(type='str', fallback=(env_fallback, 'ANSIBLE_NET_USERNAME')),
        host=dict(type='str', fallback=(env_fallback, 'ANSIBLE_NET_HOST')),
    )

    module = MagicMock()
    module.params = dict()
    module.get_option = lambda x: None

    no_log_values = set_fallbacks(argument_spec, module.params)
    assert len(no_log_values) == 0


# Generated at 2022-06-20 16:10:05.893894
# Unit test for function set_fallbacks

# Generated at 2022-06-20 16:10:18.851581
# Unit test for function env_fallback
def test_env_fallback():
    def cleanup():
        if 'FOO' in os.environ:
            del os.environ['FOO']
        if 'BAR' in os.environ:
            del os.environ['BAR']
    cleanup()
    os.environ['FOO'] = '1'
    assert env_fallback('FOO') == '1'
    assert env_fallback('FOO', 'BAR') == '1'
    assert env_fallback('BAR', 'FOO') == '1'
    cleanup()
    os.environ['BAR'] = '1'
    assert env_fallback('FOO', 'BAR') == '1'
    assert env_fallback('BAR', 'FOO') == '1'
    cleanup()

# Generated at 2022-06-20 16:10:22.938537
# Unit test for function env_fallback
def test_env_fallback():
    with patch.dict('os.environ', foo='bar'):
        assert env_fallback('does_not_exist', 'foo') == 'bar'
        assert env_fallback('does_not_exist_either') == 'AnsibleFallbackNotFound'



# Generated at 2022-06-20 16:10:50.473847
# Unit test for function sanitize_keys
def test_sanitize_keys():

    def _sanitize_keys_test(text, no_log_strings, ignore_keys, expected):
        """
        An internal function for testing sanitize_keys.
        """
        no_log_strings = [to_native(s, errors='surrogate_or_strict') for s in no_log_strings]
        obj = json.loads(text)

        if isinstance(ignore_keys, text_type):
            ignore_keys = frozenset(ignore_keys.split())

        new_obj = sanitize_keys(obj, no_log_strings, ignore_keys)
        assert json.dumps(new_obj, sort_keys=True) == json.dumps(expected, sort_keys=True)

    _sanitize_keys_test("{}", set(), frozenset(), {})
   

# Generated at 2022-06-20 16:11:02.125039
# Unit test for function set_fallbacks

# Generated at 2022-06-20 16:11:07.096513
# Unit test for function sanitize_keys
def test_sanitize_keys():

    # Validate on a dict
    data = dict(
        dict1=dict(
            dict2=dict(
                key1='value1',
                key2='value2',
                key3='value3',
            ),
            dict3=dict(
                key4='value4',
            ),
        ),
        dict4=dict(
            key5='value5',
        ),
    )
    new_data = sanitize_keys(data, ['value4'], ignore_keys=frozenset(['key1']))

# Generated at 2022-06-20 16:11:14.549799
# Unit test for function sanitize_keys
def test_sanitize_keys():
    no_log_strings = ['username', 'password']
    assert 'ansible_user' == sanitize_keys('ansible_user', no_log_strings)

    data = dict(
        ansible_user='username',
        ansible_password='password'
    )
    expected = dict(
        ansible_user='username',
        ansible_pa=''
    )
    assert expected == sanitize_keys(data, no_log_strings)

    data = dict(
        ansible_user='username',
        ansible_password='password',
        ansible_become_password='password'
    )
    expected = dict(
        ansible_user='username',
        ansible_pa='',
        ansible_become_pa=''
    )

# Generated at 2022-06-20 16:11:24.049046
# Unit test for function set_fallbacks
def test_set_fallbacks():
    parameter_spec = dict(
        install_repo=dict(type='str', fallback=(env_fallback, 'MY_REPO')),
        install_loc=dict(type='str', fallback=(env_fallback, ['MY_LOC', 'MY_LOC_2'], dict(fallback_var='MY_LOC_3'))),
        install_loc_2=dict(type='str', fallback=(env_fallback, 'MY_LOC_4')),
        install_loc_3=dict(type='str'),
    )

    os.environ['MY_REPO'] = 'https://example.com/downloads'
    os.environ['MY_LOC'] = '/opt/ansible/somepackage'
    os.environ['MY_LOC_2'] = '/opt/ansible/somepackage2'


# Generated at 2022-06-20 16:11:35.663582
# Unit test for function set_fallbacks
def test_set_fallbacks():
    """
    This test validates that the parameter is set using fallback.
    """

# Generated at 2022-06-20 16:11:43.621679
# Unit test for function env_fallback
def test_env_fallback():
    path_to_variables = "../../ansible/roles/test/vars/main.yml"
    vars = yaml.load(open(path_to_variables).read())
    assert env_fallback('ANSIBLE_TEST_VAR') == vars['ANSIBLE_TEST_VAR']
    assert env_fallback('ANSIBLE_OTHER_TEST_VAR') == vars['ANSIBLE_OTHER_TEST_VAR']
    assert env_fallback('ANSIBLE_TEST_VAR_NO_EXIST') == None


# Generated at 2022-06-20 16:11:55.245500
# Unit test for function remove_values
def test_remove_values():
    # Test if function can handle simple container types
    assert remove_values({'test_key': 'test_value'}, ['test_value']) == {'test_key': ''}
    assert remove_values([1], [1]) == ['']
    assert remove_values((1,), [1]) == ('',)
    assert remove_values({'test_key': ['test_value']}, ['test_value']) == {'test_key': ['']}
    assert remove_values({'test_key': ('test_value',)}, ['test_value']) == {'test_key': ('',)}
    assert remove_values({'test_key': {'test_key': 'test_value2'}}, ['test_value2']) == {'test_key': {'test_key': ''}}

    # Test if function

# Generated at 2022-06-20 16:12:04.522302
# Unit test for function sanitize_keys
def test_sanitize_keys():
    dict_to_sanitize = {'rand_key_0':
                            {'ssh_password': 'rand_string_0',
                             'api_key': 'rand_string_1',
                             'rand_key_3': [
                                 {'rand_key_4': 'rand_value_4'}
                             ]
                            },
                        'rand_key_1':
                            {'ssh_password': 'rand_string_2',
                             'api_key': 'rand_string_3',
                             'rand_key_5': [
                                 {'rand_key_6': 'rand_value_6'}
                             ]
                            }
                       }

# Generated at 2022-06-20 16:12:16.911057
# Unit test for function sanitize_keys

# Generated at 2022-06-20 16:12:46.572069
# Unit test for function remove_values
def test_remove_values():
    # Value is a string
    assert remove_values("string", ["string"]) == '***'
    assert remove_values("string", ["string", "String"]) == '***'
    assert remove_values("string", ["string", "String"], regexp=True) == '******'
    assert remove_values("string", ["string", "String"], regexp=True) == '******'
    # Value is a sequence
    assert remove_values(["string", "string2"], ["string"]) == ['***', "string2"]
    assert remove_values(["string", "string2"], ["string", "string2"]) == ['***', '***']
    assert remove_values(["string", "string2"], ["string", "string2"], regexp=True) == ['******', '******']

# Generated at 2022-06-20 16:12:54.646307
# Unit test for function remove_values
def test_remove_values():
    # Test no_log = True
    assert remove_values('value_with_no_log', ['value_with']) is None
    # Test no_log = False
    assert remove_values('not_touching_this', ['value_with']) == 'not_touching_this'
    # Test no_log = False on a falsy value
    assert remove_values('', ['value_with']) == ''
    # Test no_log = None
    assert remove_values('value_with_no_log', ['value_with']) is None
    # Test no_log = None on a falsy value
    assert remove_values('', ['value_with']) == ''

    #  Test a list

# Generated at 2022-06-20 16:12:57.272647
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('my_environment_var') == os.environ['my_environment_var']
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('my_future_environment_var')



# Generated at 2022-06-20 16:13:05.862701
# Unit test for function sanitize_keys
def test_sanitize_keys():
    results = []
    results.append(sanitize_keys("doesnt_do_anything", ['spam'], ['eggs']))
    results.append(sanitize_keys("spam", ['spam'], ['eggs']))
    results.append(sanitize_keys("spam_eggs_and_spam", ['spam'], ['eggs']))
    results.append(sanitize_keys("SOME_SECRET_KEY", ['SOME_SECRET'], ['key']))
    results.append(sanitize_keys("SOME_SECRET_KEY", ['SOME_SECRET'], []))
    results.append(sanitize_keys("SOME_SECRET__KEY", ['SOME_SECRET'], []))

    expected_results = []

# Generated at 2022-06-20 16:13:14.275285
# Unit test for function set_fallbacks

# Generated at 2022-06-20 16:13:19.862149
# Unit test for function sanitize_keys
def test_sanitize_keys():
    '''Test sanitize_keys'''
    assert sanitize_keys({'a': 'test'}, set()) == {'a': 'test'}
    assert sanitize_keys({'a': 'test'}, set(['test'])) == {'a': 'test'}
    assert sanitize_keys({'a': 'test'}, set(['test']), ignore_keys=set(['a'])) == {'a': 'test'}
    # key 'a' is not in no_log_strings
    assert sanitize_keys({'a': 'test'}, set(['test']), ignore_keys=set(['a'])) == {'a': 'test'}

# Generated at 2022-06-20 16:13:28.339838
# Unit test for function sanitize_keys
def test_sanitize_keys():
    s = 'This is a test of the emergency broadcasting system.'
    assert sanitize_keys(s, ['emergency']) == s
    d = {'one': 1, 'two': 2, 'twenty-one': 21, 'twenty-two': 22, 'twenty_two': 22}
    assert sanitize_keys(d, ['two', 'twenty-two'], ignore_keys=frozenset(['two'])) == {'one': 1, 'two': 2, 'twenty_one': 21, 'twenty_two': 22}
    d = {'some': {'nested': {'values': {'deep': 'deep values'}}}}

# Generated at 2022-06-20 16:13:33.227563
# Unit test for function sanitize_keys

# Generated at 2022-06-20 16:13:44.957903
# Unit test for function remove_values

# Generated at 2022-06-20 16:13:57.130095
# Unit test for function remove_values
def test_remove_values():
    assert _remove_values('abcdef', 'def') == 'abc'
    assert _remove_values(['def', 'abcdef'], 'def') == ['', 'abc']
    assert _remove_values(('def', 'abcdef'), 'def') == ('', 'abc')
    assert _remove_values({'k1': 'def', 'k2': 'abcdef'}, 'def') == {'k1': '', 'k2': 'abc'}
    assert _remove_values({'k1': 'def', 'k2': 'abcdef'}, ['abc', 'def']) == {'k1': '', 'k2': ''}
    assert _remove_values({'k1': ['def', 'abcdef']}, 'def') == {'k1': ['', 'abc']}