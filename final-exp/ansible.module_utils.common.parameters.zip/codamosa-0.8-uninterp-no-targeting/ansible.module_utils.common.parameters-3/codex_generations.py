

# Generated at 2022-06-20 16:06:09.940224
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # AnsibleFallBackNotFound test
    spec = {'param1': {'fallback': (env_fallback, ['paramn', 'paramz'])}, 'param2': {'fallback': (env_fallback, ['paramz'])}}
    params = {}
    assert set_fallbacks(spec, params) == set()

    # Complex dictionary fallback test
    spec = {'param1': {'fallback': (env_fallback, ['paramn', {'env_var': 'paramz'}])}}
    params = {}
    assert set_fallbacks(spec, params) == set()

    # No_log test
    spec = {'param1': {'fallback': (env_fallback, ['param1']), 'no_log': True}}
    params = {}

# Generated at 2022-06-20 16:06:20.646252
# Unit test for function sanitize_keys
def test_sanitize_keys():
    x = {
        'foo bar': 'bar',
        'baz': {
            'foo bar': 'bar',
            'fizz': ['buzz', 'buzzx', 'buzzy']
        },
        'foo@bar': 'should be unchanged',
        'ssh-private-key': 'should be changed'
    }
    no_log_strings = {'private', 'password', 'secret', 'ssh-private-key', 'ssh-private-keyfile'}
    y = sanitize_keys(x, no_log_strings)


# Generated at 2022-06-20 16:06:30.498115
# Unit test for function remove_values
def test_remove_values():
    data = {
        'test1': {
            '@test2': 'test3',
            '@test4': 5,
            'test5': [{'@test6': {'@test7': 'test8'}}]
        }
    }

    no_log_strings = ['@test2', '@test6']
    new_value = remove_values(data, no_log_strings)

    assert new_value == {
        'test1': {
            'test5': [{'@test7': 'test8'}]
        }
    }



# Generated at 2022-06-20 16:06:41.810689
# Unit test for function set_fallbacks
def test_set_fallbacks():
    TEST_SET_FALLBACK_ARG_SPEC = dict(
        test_param=dict(
            required=True,
            type='str',
            fallback=(env_fallback, ['TEST_PARAM']),
        ),
        test_param_with_dict=dict(
            type='str',
            fallback=(env_fallback, [dict(variable='TEST_PARAM_WITH_DICT')]),
        )
    )
    TEST_SET_FALLBACK_PARAMETERS = dict(
        test_param='test_value',
    )

    os.environ['TEST_PARAM_WITH_DICT'] = 'env_value'

# Generated at 2022-06-20 16:06:49.713726
# Unit test for function set_fallbacks
def test_set_fallbacks():
    parameters = {}
    fallback_strategy = MagicMock(return_value='foo')
    argument_spec = dict(
        foo=dict(
            fallback=(fallback_strategy, ['FOO'])
        )
    )

    set_fallbacks(argument_spec, parameters)

    fallback_strategy.assert_called_once_with('FOO')
    assert parameters == dict(foo='foo')

    fallback_strategy = MagicMock(side_effect=AnsibleFallbackNotFound)
    argument_spec = dict(
        foo=dict(
            fallback=(fallback_strategy, ['FOO'])
        )
    )

    set_fallbacks(argument_spec, parameters)
    assert parameters == dict(foo='foo')



# Generated at 2022-06-20 16:06:51.200985
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('ANALYTICS_KEY') == '$encrypted$'



# Generated at 2022-06-20 16:06:59.408582
# Unit test for function remove_values
def test_remove_values():
    # Test the data types of the function
    # Test for result
    # Test for value
    # Test for no_log_strings
    # Test for deferred_removals
    # Test for old_data
    # Test for new_data
    # Test for old_key
    # Test for old_elem
    # Test for new_elem
    # Test for container type
    # Test for value container

    test_value = {'param':1,'param2':2,'param3':3}
    test_no_log_strings = [2]
    test_deferred_removals = []
    test_old_data = [1,2]
    test_new_data = []
    test_old_key = 'key'
    test_old_elem = 2
    test_new_elem = 3
   

# Generated at 2022-06-20 16:07:11.626761
# Unit test for function set_fallbacks
def test_set_fallbacks():

    argument_spec = {'result': {'type': 'bool', 'aliases': ['output'], 'default': False, 'fallback': (env_fallback, ['LOG_RESULTS'])}}

    # test case 1: expected output when fallback is not called
    parameters = {'result': True}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert no_log_values == set()

    # test case 2: expected output when fallback is called
    parameters = {}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters == {'result': False}
    assert no_log_values == {False}

    # test case 3: expected output when fallback is not called as fallback value is not set in env
    parameters = {'output': True}
    no

# Generated at 2022-06-20 16:07:22.395572
# Unit test for function remove_values
def test_remove_values():
    # Ensure we can add things to a container
    my_set = set()
    my_seq = []
    my_dict = {}
    data = [my_set, my_seq, my_dict]
    for elem in data:
        new_elem = _remove_values_conditions(None, [], deque())
        if isinstance(new_elem, MutableSequence):
            new_elem.append('test')
        elif isinstance(new_elem, MutableSet):
            new_elem.add('test')
        elif isinstance(new_elem, Mapping):
            new_elem['test'] = 'test'
        else:
            raise TypeError('Unknown container type encountered when removing private values from output')
        if isinstance(new_elem, Sequence):
            assert new

# Generated at 2022-06-20 16:07:32.273612
# Unit test for function set_fallbacks
def test_set_fallbacks():
    spec = {"testing": {"env": ("env_fallback", "TESTING_ENV"), "type": "str", "fallback": ("env_fallback", "TESTING_ENV")}}
    parameters = {"testing": None}
    if "TESTING_ENV" in os.environ:
        del os.environ["TESTING_ENV"]
    assert set_fallbacks(spec, parameters) == set()
    assert parameters == {"testing": None}

    os.environ["TESTING_ENV"] = "testing"
    parameters = {"testing": None}
    assert set_fallbacks(spec, parameters) == set()
    assert parameters == {"testing": "testing"}


# Generated at 2022-06-20 16:07:59.912295
# Unit test for function set_fallbacks
def test_set_fallbacks():
    """Unit test for function set_fallbacks"""

    argument_spec = dict(
        param1=dict(required=True, type='int'),
        param2=dict(required=True, type='int')
    )
    parameters = dict(param1=1)

    fallback_params = dict(param1=dict(fallback=(env_fallback, 'ANSIBLE_FOO')),
                           param2=dict(fallback=(env_fallback, 'ANSIBLE_FOO')))

    argument_spec.update(fallback_params)

    assert set_fallbacks(argument_spec, parameters) == set()
    assert parameters == dict(param1=1, param2=None)

    os.environ['ANSIBLE_FOO'] = '99'
    assert set_fallbacks(argument_spec, parameters) == set()


# Generated at 2022-06-20 16:08:10.982068
# Unit test for function env_fallback
def test_env_fallback():
    env = dict(os.environ)
    os.environ['ANSIBLE_FOO'] = 'foo'
    assert env_fallback('FOO', 'BAR') == 'foo'
    del os.environ['ANSIBLE_FOO']
    os.environ['FOO'] = 'foo'
    assert env_fallback('FOO', 'BAR') == 'foo'
    del os.environ['FOO']
    os.environ['ANSIBLE_BAR'] = 'bar'
    assert env_fallback('FOO', 'BAR') == 'bar'
    del os.environ['ANSIBLE_BAR']
    os.environ.clear()
    os.environ.update(env)
    assert env_fallback('FOO', 'BAR') == 'bar'



# Generated at 2022-06-20 16:08:17.388301
# Unit test for function set_fallbacks
def test_set_fallbacks():
    """Unit test for function set_fallbacks"""

    assert set_fallbacks({}, {}) == set()
    assert set_fallbacks({'foo': {}}, {}) == set()
    assert set_fallbacks({'foo': {'fallback': ('test',)}}, {}) == set()
    assert set_fallbacks({'foo': {'fallback': ('test', 'bar')}}, {}) == set()
    assert set_fallbacks({'foo': {'fallback': ('test', {})}}, {}) == set()



# Generated at 2022-06-20 16:08:23.600735
# Unit test for function set_fallbacks

# Generated at 2022-06-20 16:08:33.710568
# Unit test for function remove_values
def test_remove_values():
    assert remove_values('hello world', ['hello']) == 'world'
    assert remove_values('my super secret password', ['super', 'secret']) == 'my password'
    assert remove_values('joe:password:hello', [':password:']) == 'joehello'
    assert remove_values(b'my super secret password', [b'super', b'secret']) == b'my password'
    assert remove_values(b'joe:password:hello', [b':password:']) == b'joehello'
    assert remove_values({'my_secret': 'hello world', 'my_super_secret': 'hello world'}, ['hello']) == {'my_secret': 'world', 'my_super_secret': 'world'}

# Generated at 2022-06-20 16:08:42.259303
# Unit test for function sanitize_keys
def test_sanitize_keys():
    data = {'test': 'value',
            'test2': 'value2',
            'test3': {'test3-1': 'value3-1', 'test3-2': 'value3-2'}}
    new_data = sanitize_keys(data, (b'test2',))
    NoLogValue.assert_sanitized(new_data)
    assert new_data == {'test': 'value',
                        'value2': 'value2',
                        'test3': {'test3-1': 'value3-1', 'test3-2': 'value3-2'}}



# Generated at 2022-06-20 16:08:49.532945
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # no fallback
    argument_spec = {
        'foo': {},
    }

    parameters = {
    }

    no_log_values = set_fallbacks(argument_spec, parameters)
    assert set(parameters.keys()) == {'foo'}
    assert no_log_values == set()

    # one fallback
    argument_spec = {
        'foo': {
            'fallback': (env_fallback, 'ANSIBLE_FOO')
        },
    }

    parameters = {
    }

    no_log_values = set_fallbacks(argument_spec, parameters)
    assert set(parameters.keys()) == {'foo'}
    assert no_log_values == set()

    # one fallback found, one not

# Generated at 2022-06-20 16:08:59.715632
# Unit test for function sanitize_keys
def test_sanitize_keys():
    # Set
    test_set = {
        'foo': 'bar',
        'baz': b'qux'
    }
    test_set_copy = deepcopy(test_set)
    result = sanitize_keys(test_set, ('foo', 'bar'))

    assert result == {
        'foo_nolog': 'bar',
        'baz': b'qux'
    }
    assert test_set_copy == test_set  # test_set should not be modified

    # Dict
    test_dict = {
        'foo': 'bar',
        'baz': b'qux',
        'quux': {
            'corge': {
                'grault': 'garply'
            }
        }
    }
    test_dict_copy = deepcopy(test_dict)

# Generated at 2022-06-20 16:09:04.863077
# Unit test for function env_fallback
def test_env_fallback():
    if sys.version_info[0] > 2:
        os.environ['DEFAULT_PARAM_FOO'] = 'my_env_value'
        assert env_fallback('DEFAULT_PARAM_FOO') == 'my_env_value'
        del os.environ['DEFAULT_PARAM_FOO']
        assert env_fallback('DEFAULT_PARAM_FOO') == None



# Generated at 2022-06-20 16:09:10.681236
# Unit test for function env_fallback
def test_env_fallback():
    '''Test for env_fallback'''
    # First test for existing environment variable
    os.environ['EXISTING'] = '123'
    result = env_fallback('EXISTING')
    assert result == '123', 'Test for env_fallback failed'
    # Cleanup
    del os.environ['EXISTING']
    try:
        # Test for non-existing environment variable
        result = env_fallback('NON-EXISTING')
        assert result is False, 'Test for env_fallback failed'
    except AnsibleFallbackNotFound:
        pass



# Generated at 2022-06-20 16:09:43.546911
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys(dict(password='password', password2="pass2", names=['user', 'pass']), ['pass']) == dict(password='REDACTED', password2='REDACTED', names=['user', 'REDACTED'])
    assert sanitize_keys(dict(password='password', password2="pass2", names=['user', 'pass']), ('pass',)) == dict(password='REDACTED', password2='REDACTED', names=['user', 'REDACTED'])
    assert sanitize_keys(dict(password='password', password2="pass2", names=['user', 'pass']), set(['pass'])) == dict(password='REDACTED', password2='REDACTED', names=['user', 'REDACTED'])



# Generated at 2022-06-20 16:09:55.759368
# Unit test for function sanitize_keys
def test_sanitize_keys():
    """Basic test for sanitize_keys
    """
    key_hash = 'e79b6753f3d1d930b1e0b6ba166a9a9a'
    string1 = 'super_secret=%s' % key_hash
    string2 = 'no_log=%s' % key_hash
    string3 = '%s_hash' % key_hash

    obj = {string1: 'value1', string2: 'value2', 'non_string1': {'key': 'value', string3: 'value3'}}
    new_obj = sanitize_keys(obj, [key_hash])

# Generated at 2022-06-20 16:09:59.908185
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('FOO') == 'bar'
    assert env_fallback('AFOO') == 'bar'
    assert env_fallback('BFOO') == 'bar'
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('CFOO')



# Generated at 2022-06-20 16:10:04.277762
# Unit test for function remove_values
def test_remove_values():
    in_val = {'a': {'foo': 'password', 'bar': {'baz': 'password'}}}
    out_val = {'a': {'foo': '**', 'bar': {'baz': '**'}}}
    assert remove_values(in_val, ['password']) == out_val



# Generated at 2022-06-20 16:10:07.555226
# Unit test for function remove_values
def test_remove_values():
    values = [
        # Valid inputs

        # Invalid inputs
        # (containers, no_log_strings),
    ]

    for value, no_log_strings, output in values:
        assert remove_values(value, no_log_strings) == output



# Generated at 2022-06-20 16:10:18.889789
# Unit test for function remove_values
def test_remove_values():
    def check_values(value_list, expected):
        for value in value_list:
            assert value == expected

    assert remove_values('credentials', ('credentials',)) == '<value redacted>'
    assert remove_values('password', ('credentials',)) == 'password'
    assert remove_values('hello', ('credentials',)) == 'hello'


# Generated at 2022-06-20 16:10:28.658515
# Unit test for function remove_values
def test_remove_values():
    aList = [1, 2, 3]
    aDict = {"a":1, "b":2}
    aSet = {1, 2, 3}

    lResult = remove_values(aList, {"2"})
    assert lResult == [1, 3]

    dResult = remove_values(aDict, {"1"})
    assert dResult == {"a":1, "b":2}

    sResult = remove_values(aSet, {"2"})
    assert sResult == {1, 3}

    strResult = remove_values("test", {"st"})
    assert strResult == "tet"

    intResult = remove_values(1, {"1"})
    assert intResult == 1

    floatResult = remove_values(1.23, {"1"})
    assert floatResult == 1.23

# Generated at 2022-06-20 16:10:41.705147
# Unit test for function set_fallbacks
def test_set_fallbacks():
    params = {}

# Generated at 2022-06-20 16:10:49.187665
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys(dict(Test_Password='foo', Test_Password2='bar'), set('foo')) == {'Test_Password': 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER', 'Test_Password2': 'bar'}
    assert sanitize_keys(dict(Test_Password='foo', Test_Password2='bar'), set('bar')) == {'Test_Password': 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER', 'Test_Password2': 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'}

# Generated at 2022-06-20 16:11:01.314193
# Unit test for function sanitize_keys
def test_sanitize_keys():
    obj1 = {'test': 'value'}
    obj2 = {'no_log_test': 'value', 'no-log-test2': 'value'}
    obj3 = {'no_log': 'value', 'no-log-test2': 'value'}
    obj4 = {'nolog': 'value', 'no-log-test2': 'value'}
    obj5 = {'nolog': 'value', 'no_log_test2': 'value'}
    obj6 = {'nolog': 'value', 'no-log': 'value'}
    obj7 = {'nolog': 'value'}
    result1 = {'test': 'value'}
    result2 = {'10_log_test': 'value', '10-log-test2': 'value'}

# Generated at 2022-06-20 16:11:28.552398
# Unit test for function sanitize_keys

# Generated at 2022-06-20 16:11:37.066326
# Unit test for function sanitize_keys
def test_sanitize_keys():
    no_log_strings = frozenset(['foo'])

    assert sanitize_keys({'foo': 'bar'}, no_log_strings) == {'<censored>': 'bar'}
    assert sanitize_keys({'foo': 'bar', 'baz': 'buz'}, no_log_strings) == {'<censored>': 'bar', 'baz': 'buz'}
    assert sanitize_keys({'baz': ['foo']}, no_log_strings) == {'baz': ['<censored>']}



# Generated at 2022-06-20 16:11:48.816518
# Unit test for function sanitize_keys
def test_sanitize_keys():
    no_log_strings = ['foo']
    res = sanitize_keys({'a': 'foo', 'b': 'bar'}, no_log_strings)
    assert res == {'a': '***'}, \
        'sanitize_keys with string key, no_log_strings and dict'

    res = sanitize_keys(['foo', 'bar'], no_log_strings)
    assert res == ['***', 'bar'], \
        'sanitize_keys with string key, no_log_strings and list'

    res = sanitize_keys({'a': {'b': {'c': 'foo'}}}, no_log_strings)

# Generated at 2022-06-20 16:11:54.931921
# Unit test for function env_fallback
def test_env_fallback():
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('non-existent-var')
    # This can be "None" but we treat it as default
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('AWS_ACCESS_KEY_ID')
    # But this can not!
    assert env_fallback('SHELL')



# Generated at 2022-06-20 16:12:02.872476
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST'] = 'test'
    assert env_fallback('ANSIBLE_TEST') == 'test'
    assert env_fallback('test', 'ANSIBLE_TEST') == 'test'
    try:
        env_fallback('test')
    except AnsibleFallbackNotFound:
        pass
    else:
        assert False, "AnsibleFallbackNotFound should have been raised"
    try:
        env_fallback()
    except AnsibleFallbackNotFound:
        pass
    else:
        assert False, "AnsibleFallbackNotFound should have been raised"



# Generated at 2022-06-20 16:12:12.848781
# Unit test for function sanitize_keys
def test_sanitize_keys():
    a = {
        'secret': 'this is confidential',
        'conf': {
            'password': 'sekret'
        },
        'data': [
            'this is a secret',
            'this is not',
        ]
    }

    no_log_val = 'sekret'
    ignore_keys = ('secret',)
    result = sanitize_keys(a, no_log_val, ignore_keys)

    expected = {
        'secret': 'this is confidential',
        'conf': {
            'password': '**********'
        },
        'data': [
            '**********',
            'this is not',
        ]
    }



# Generated at 2022-06-20 16:12:21.066228
# Unit test for function sanitize_keys
def test_sanitize_keys():
    """Unit test for function sanitize_keys()"""

    class TestKeysClass(object):
        def __init__(self):
            self.foo = 'bar'
            self.bar = 'baz'

    # Test dict
    obj = dict(a=1, b=2, c=3)
    assert sanitize_keys(obj, {}) == obj
    assert sanitize_keys(obj, {'c'}) == dict(a=1, b=2, c='')
    obj['d'] = 4
    assert sanitize_keys(obj, {'d'}) == dict(a=1, b=2, c=3, d='')

    # Test list
    obj = [1, 2, 3, [4, 5], {'foo': 'bar', 'bar': 'baz'}]

# Generated at 2022-06-20 16:12:33.254911
# Unit test for function sanitize_keys
def test_sanitize_keys():
    result = sanitize_keys({'a': 'a', 'b': {'c': 'a'}}, ['a'], ignore_keys=set())
    assert result == {'a': 'a', 'b': {'c': 'a'}}
    result = sanitize_keys({'a': 'a', 'b': {'c': 'a'}}, ['a'], ignore_keys=set(['a']))
    assert result == {'a': 'a', 'b': {'c': 'a'}}
    result = sanitize_keys({'a': 'a', 'b': {'c': 'a'}}, ['a'], ignore_keys=set(['a', 'c']))
    assert result == {'a': 'a', 'b': {'c': 'a'}}
    result = sanit

# Generated at 2022-06-20 16:12:37.984616
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Trivial test
    assert set_fallbacks({}, {}) == set()
    # Test empty fallback
    assert set_fallbacks({'x': {}}, {}) == set()
    # Test env_fallback
    assert set_fallbacks({'x': {'fallback': (env_fallback, 'TEST_A')}}, {}) == set()
    os.environ['TEST_A'] = 'a'
    assert set_fallbacks({'x': {'fallback': (env_fallback, 'TEST_A')}}, {}) == set(['a'])
    del os.environ['TEST_A']
    # Test fallback with kwargs

# Generated at 2022-06-20 16:12:46.204498
# Unit test for function sanitize_keys

# Generated at 2022-06-20 16:13:13.273362
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'foo': {'type': 'str', 'fallback': ['env_fallback', 'FOO']}, 'bar': {'type': 'int', 'fallback': (int, '99')}}
    parameters = {}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters == {}
    os.environ['FOO'] = '1'
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters == {'foo': u'1'}
    assert no_log_values == set()
    os.environ['FOO'] = ''
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters == {'foo': u''}
    os.environ['FOO'] = '1'
   

# Generated at 2022-06-20 16:13:20.810964
# Unit test for function env_fallback
def test_env_fallback():
    """Test loading value from environment variable"""

    assert env_fallback('ANSIBLE_FOO') == os.environ['ANSIBLE_FOO']

    try:
        env_fallback('FOO')
        assert False
    except AnsibleFallbackNotFound:
        assert True
    except:
        assert False



# Generated at 2022-06-20 16:13:25.721329
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys({'a': 'b', 'c': 'd'}, ['d']) == {'a': 'b', 'c': '**'}
    assert sanitize_keys({'a': 'b', 'c': {'d': 'e'}}, ['e']) == {'a': 'b', 'c': {'d': '**'}}
    assert sanitize_keys({'a': 'b', 'c': {'d': 'e'}}, ['d']) == {'a': 'b', 'c': '**'}
    assert sanitize_keys({'a': 'b', 'c': {'d': {'e': 'f'}}}, ['d']) == {'a': 'b', 'c': '**'}

# Generated at 2022-06-20 16:13:34.390433
# Unit test for function remove_values

# Generated at 2022-06-20 16:13:45.756775
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        no_env=dict(type='str', required=False),
        env_default=dict(type='str', required=False, fallback=(env_fallback, 'ANSIBLE_TEST_ENV_VAR_DEFAULT', dict(fallback_value='default'))),
        env_only=dict(type='str', required=False, fallback=(env_fallback, 'ANSIBLE_TEST_ENV_VAR_ONLY', dict(fallback_value='default'))),
    )
    os.environ['ANSIBLE_TEST_ENV_VAR_ONLY'] = 'only'
    parameters = dict()
    no_log_values = set()
    no_log_values.update(set_fallbacks(argument_spec, parameters))

# Generated at 2022-06-20 16:13:49.208619
# Unit test for function env_fallback
def test_env_fallback():
    """Test env_fallback function"""
    os.environ['ANSIBLE_NET_USERNAME'] = "test"
    assert test_env_fallback('ANSIBLE_NET_USERNAME') == "test"



# Generated at 2022-06-20 16:13:57.087165
# Unit test for function remove_values
def test_remove_values():
    """Unit test for function remove_values"""

    passed = []
    passed.append(_remove_values_conditions('novalue', ['novalue']) == '****')
    passed.append(_remove_values_conditions(['novalue'], ['novalue']) == ['****'])
    passed.append(_remove_values_conditions({'novalue': 'novalue'}, ['novalue']) == {'novalue': '****'})
    passed.append(_remove_values_conditions({'novalue': 'novalue', 'value': 'value'}, ['novalue']) == {'novalue': '****', 'value': 'value'})

# Generated at 2022-06-20 16:14:01.966815
# Unit test for function remove_values
def test_remove_values():
    assert remove_values('junk', ['junk']) == '*****'
    assert remove_values({'junk': 'junk', 'foo': 'bar'}, ['junk']) == {'junk': '*****', 'foo': 'bar'}
    assert remove_values(['junk', {'foo': 'junk'}], ['junk']) == ['*****', {'foo': '*****'}]



# Generated at 2022-06-20 16:14:08.153426
# Unit test for function remove_values
def test_remove_values():
    my_list = [1, {'b': [2, {'d': 4, 'e': 6}]}, [3, 5]]
    new_list = remove_values(my_list, ['2', '4'])
    assert new_list == [1, {'b': [{'d': '4'}, {'e': 6}]}, [3, 5]]



# Generated at 2022-06-20 16:14:20.743595
# Unit test for function remove_values
def test_remove_values():
    strings = ["this is a string", "this is another string", "this one is not removed"]
    strings2 = ["this one is removed"]
    assert remove_values(strings, strings2) == ["this is a string", "this is another string"]

    strings3 = ["this is a string", "this is another string", "this one is not removed", ["this one is removed"]]
    assert remove_values(strings3, strings2) == ["this is a string", "this is another string", "this one is not removed", []]

    strings4 = ["this is a string", "this is another string", "this one is not removed", {"this one is removed": "this one is removed"}]