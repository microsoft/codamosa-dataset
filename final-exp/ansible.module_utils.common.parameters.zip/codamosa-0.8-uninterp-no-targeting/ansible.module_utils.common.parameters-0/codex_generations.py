

# Generated at 2022-06-20 16:05:51.720132
# Unit test for function env_fallback
def test_env_fallback():
    """ test env_fallback function """
    from ansible_collections.ansible.community.tests.unit.compat.mock import Mock, patch

    lookup_module = 'ansible_collections.ansible.community.plugins.module_utils.common.validation.env_fallback'
    fake_env = {
        'test1': 'hello',
        'test2': 'world',
    }

    # test module.run_command()
    with patch(lookup_module + ".os") as mock_os:
        mock_os.environ = fake_env
        assert env_fallback('test1', 'test2') == 'hello'
        assert env_fallback('test2', 'test1') == 'world'
        # test exc

# Generated at 2022-06-20 16:05:54.294531
# Unit test for function remove_values
def test_remove_values():
    # pylint: disable=unused-variable
    import doctest
    doctest.testmod()



# Generated at 2022-06-20 16:06:03.666761
# Unit test for function remove_values
def test_remove_values():

    # Test for a container type
    complex_container = {
        'k1': 'v1',
        'k2': ['v2', 'v3', 'v4'],
        'k3': {
            'k5': {
                'k6': ['v6', 'v7'],
                'k7': ['v8', 'v9'],
            },
        },
    }
    no_log_strings = ['v2', 'v3']
    new_complex_container = {
        'k1': 'v1',
        'k2': ['v4'],
        'k3': {
            'k5': {
                'k6': ['v6', 'v7'],
                'k7': ['v8', 'v9'],
            },
        },
    }
    assert remove

# Generated at 2022-06-20 16:06:16.179070
# Unit test for function sanitize_keys
def test_sanitize_keys():

    # Gather test data from a simple model of an argument spec used in a real Ansible module
    test_data = dict()

    test_data['argument_spec'] = dict()
    test_data['argument_spec']['spec'] = dict()

    test_data['argument_spec']['spec']['host'] = dict()
    test_data['argument_spec']['spec']['host']['type'] = 'str'
    test_data['argument_spec']['spec']['host']['aliases'] = ['conjur_host']
    test_data['argument_spec']['spec']['host']['required'] = False
    test_data['argument_spec']['spec']['host']['no_log'] = True


# Generated at 2022-06-20 16:06:21.531571
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['test_env_fallback'] = 'foo'
    assert env_fallback('test_env_fallback') == 'foo'
    del os.environ['test_env_fallback']
    try:
        env_fallback('test_env_fallback')
        assert False
    except AnsibleFallbackNotFound as e:
        assert isinstance(e, AnsibleFallbackNotFound)
test_env_fallback()



# Generated at 2022-06-20 16:06:34.780619
# Unit test for function remove_values
def test_remove_values():
    from datetime import datetime
    from decimal import Decimal
    from fractions import Fraction

    # [{}] -> [{}]
    check_string = 'ansible'
    assert remove_values([{}], [check_string]) == [{}]

    # check_string -> '******'
    assert remove_values(check_string, [check_string]) == '******'

    # check_string -> '******'
    assert remove_values(check_string.encode(b'utf-8'), [check_string]) == '******'

    # check_string -> '******'
    assert remove_values(bytearray(check_string, b'utf-8'), [check_string]) == bytearray('******', b'utf-8')

    # check_string -> '******

# Generated at 2022-06-20 16:06:44.941623
# Unit test for function remove_values
def test_remove_values():
    # Bare strings
    assert remove_values('hello', ['hello']) == 'VALUE_REMOVED'
    assert remove_values('hello', []) == 'hello'

    # lists
    assert remove_values(['hello'], ['hello']) == ['VALUE_REMOVED']
    assert remove_values(['hello', 'world'], ['hello']) == ['VALUE_REMOVED', 'world']
    assert remove_values(['hello', 'world', 'hello'], ['hello']) == ['VALUE_REMOVED', 'world', 'VALUE_REMOVED']

    # dicts
    assert remove_values({'foo': 'hello'}, ['hello']) == {'foo': 'VALUE_REMOVED'}

# Generated at 2022-06-20 16:06:52.169413
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Ensure fallbacks do not happen if the parameter is already set
    argument_spec = dict(
        foo = dict(default='bar', type='str'),
        bar = dict(fallback=(env_fallback, 'FOO'), type='str'),
    )
    parameters = dict(foo='baz')
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters == dict(foo='baz'), 'foo should not change'
    assert no_log_values == set(), 'no_log should be empty'

    # Ensure fallbacks are applied if the parameter is not set
    parameter_spec = argument_spec.copy()
    parameters = {}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters == dict(foo='bar'), 'foo should take the default'

# Generated at 2022-06-20 16:07:00.067882
# Unit test for function sanitize_keys

# Generated at 2022-06-20 16:07:11.659470
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Test successful fallback from env var
    arg_spec = dict(
        module_arg=dict(fallback=(env_fallback, 'ANSIBLE_MODULE_ARG'))
    )
    parameters = {}
    os.environ['ANSIBLE_MODULE_ARG'] = 'env'
    result = set_fallbacks(arg_spec, parameters)
    assert parameters['module_arg'] == 'env'
    assert result == set()
    os.environ.pop('ANSIBLE_MODULE_ARG')

    # Test fallback from env var that isn't set
    result = set_fallbacks(arg_spec, parameters)
    assert 'module_arg' not in parameters
    assert result == set()

    # Test fallback from env var with no_log=True

# Generated at 2022-06-20 16:07:40.723945
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec_good_password = dict(
        username=dict(type='str'),
        password=dict(type='str', no_log=True, fallback=(env_fallback, ['ANSIBLE_NET_PASSWORD']))
    )
    params_good_password = dict(username='u1')
    no_log_values_good_password0 = set()
    no_log_values_good_password1 = set(['p1'])

    no_log_values_good_password = set_fallbacks(argument_spec_good_password, params_good_password)

# Generated at 2022-06-20 16:07:49.454379
# Unit test for function env_fallback
def test_env_fallback():
    os.environ["FOO"] = 'bar'
    assert env_fallback('FOO', 'baz') == 'bar'
    assert env_fallback('baz', 'FOO') == 'bar'
    assert env_fallback('baz', 'bar') == 'bar'
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('baz')
    del(os.environ["FOO"])



# Generated at 2022-06-20 16:07:57.121970
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'some_param': {'fallback': (env_fallback, ['SOME_PARAM']),
                                    'required': True,
                                    'type': 'str'}}
    try:
        os.environ['SOME_PARAM'] = 'some_value'
        no_log_values = set_fallbacks(argument_spec, {})
        assert no_log_values == set()
    finally:
        del os.environ['SOME_PARAM']



# Generated at 2022-06-20 16:08:07.391279
# Unit test for function sanitize_keys
def test_sanitize_keys():
    # Check strings and unicode replaced
    assert sanitize_keys('foo', frozenset('o')) == 'f*o'
    assert sanitize_keys(u'foo', frozenset(u'o')) == 'f*o'
    # Check keys in list replaced
    assert sanitize_keys(['foobar', 'foo', 'bar'], frozenset('foo')) == ['f*oobar', 'f*o', 'bar']
    # Check keys in tuple replaced
    assert sanitize_keys(('foobar', 'foo', 'bar'), frozenset('foo')) == ('f*oobar', 'f*o', 'bar')
    # Check keys in set replaced

# Generated at 2022-06-20 16:08:14.310991
# Unit test for function sanitize_keys
def test_sanitize_keys():
    no_log_strings = {'secret', 'private'}

    # Simple dictionary object
    old_data = {'no_log': 'secret', 'foo': {'bar': 'baz'}}
    new_data = sanitize_keys(old_data, no_log_strings)
    assert new_data['foo']['bar'] == 'baz'
    assert 'no_log' not in new_data

    # Nested object with multiple levels where the private value is encountered
    old_data = {'no_log': 'secret', 'foo': {'bar': 'baz'}, 'one': {'two': {'two': '2', 'no_log': 'foo', 'three': '3'}, 'four': '4'}}

# Generated at 2022-06-20 16:08:18.421003
# Unit test for function env_fallback
def test_env_fallback():
    param, value = 'FOO', 'BAR'

    # missing param
    if param in os.environ:
        del os.environ[param]
    assert env_fallback(param) == value
    assert env_fallback(param) != param

    # param and value missing
    if param in os.environ:
        del os.environ[param]
    try:
        env_fallback(param, value)
        assert False
    except AnsibleFallbackNotFound:
        pass

    # param present, value missing
    if param not in os.environ:
        os.environ[param] = value
    assert env_fallback(param) == param
    assert env_fallback(param) != value

    # param and value present
    if param not in os.environ:
        os.environ

# Generated at 2022-06-20 16:08:30.149070
# Unit test for function remove_values
def test_remove_values():
    a = {'foo': 'bar', 'this': {'is': 'secret', 'not': 'this', 'another': ['secret', 'is', 123, {'foo': 'bar'}]}, 'or': 'secret', 'another2': ['secret', 'is', 123, {'foo': 'bar'}], 'yet': {'another': 'secret', 'type': ['of', 'secret'], 'in': {'a': 'secret', 'nested': 'dict'}}, 'list': ['foo', ['secret', 'is']], 'tuple': ('foo', ('secret', 'is'))}

# Generated at 2022-06-20 16:08:41.025193
# Unit test for function sanitize_keys
def test_sanitize_keys():
    nested_dict = {
        'foo' : {
            'bar' : "baz",
            'foobar' : {
                'barfoo' : "foobaz",
            },
        },
        'barfoo' : "bazfoo",
        'bar' : [
            {"foo": "bar"},
            {"foobar": "barfoo"},
        ],
    }
    no_log_strings = ['foobar', 'barfoo']
    ignore_keys=frozenset()
    sanitized_nested_dict = sanitize_keys(nested_dict, no_log_strings, ignore_keys)

# Generated at 2022-06-20 16:08:52.640850
# Unit test for function sanitize_keys
def test_sanitize_keys():
    example_object = {
        'should_be_unchanged': 'because_key_is_ok',
        'no_log_string_in_key': {
            'should_be_cleared': 'because_top_level_key_is_bad',
            'no_log_string_in_key': 'because_this_key_is_ok'
        },
        'no_log_string_in_value': {
            'should_be_unchanged': 'because_the_value_is_ok',
            'should_be_unchanged_too': 'because_the_value_is_ok'
        }
    }

# Generated at 2022-06-20 16:09:01.506413
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'test_param': {
            'required': True,
            'choices': ['a', 'b'],
            'fallback': (env_fallback, ['ANSIBLE_TEST_PARAM'])
        }
    }

    parameters = {
        'test_param': 'a',
    }

    os.environ['ANSIBLE_TEST_PARAM'] = 'testing'

    no_log_values = set()
    no_log_values = set_fallbacks(argument_spec, parameters)

    assert parameters['test_param'] == 'a'
    assert no_log_values == set()

    del os.environ['ANSIBLE_TEST_PARAM']



# Generated at 2022-06-20 16:09:42.333199
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['FOO'] = 'bar'

    try:
        assert env_fallback('FOO') == 'bar'
        assert env_fallback('BAR') == ''
        with pytest.raises(AnsibleFallbackNotFound):
            env_fallback('BAR', 'BAZ')
    finally:
        del os.environ['FOO']



# Generated at 2022-06-20 16:09:54.574202
# Unit test for function remove_values
def test_remove_values():
    def _recur(old_data, new_data):
        if isinstance(new_data, Mapping):
            for old_key, old_elem in old_data.items():
                assert old_key in new_data
                _recur(old_elem, new_data[old_key])
        else:
            for elem in old_data:
                assert elem in new_data

    old_data = {'redacted': {'msg': 'PRIVATE DATA HIDDEN', 'password': 'PRIVATE DATA HIDDEN', 'other_no_log': 'value'}, 'some': ['other', 'data', 'here'], 'with': {'sub': 'elements'}}

# Generated at 2022-06-20 16:10:04.434918
# Unit test for function env_fallback
def test_env_fallback():
    import os
    import sys

    # Create some environment variables
    os.environ['ANSIBLE_TEST_VAR_1'] = 'test1'
    os.environ['ANSIBLE_TEST_VAR_2'] = 'test2'

    # Save them to restore them later
    saved_env = dict(ANSIBLE_TEST_VAR_1=os.environ['ANSIBLE_TEST_VAR_1'], ANSIBLE_TEST_VAR_2=os.environ['ANSIBLE_TEST_VAR_2'])

    def _cleanup_env():
        del os.environ['ANSIBLE_TEST_VAR_1']
        del os.environ['ANSIBLE_TEST_VAR_2']


# Generated at 2022-06-20 16:10:12.646950
# Unit test for function remove_values
def test_remove_values():
    no_log_strings = set()
    test_data = {
        'A': None,
        'B': 1,
        'C': '',
        'D': {
            'a': 'password',
            'b': '1',
            'c': '',
            'd': {'z': 0},
        },
    }
    result = remove_values(test_data, no_log_strings)
    assert result == test_data

    no_log_strings = {'password'}

# Generated at 2022-06-20 16:10:23.374671
# Unit test for function sanitize_keys
def test_sanitize_keys():

    obj = {'password': 'abc', 'pass_phrase': '123'}
    no_log_strings = set(['password'])

    assert sanitize_keys(obj, no_log_strings) == {'*password': 'abc', 'pass_phrase': '123'}

    obj = [{'password': 'abc'}]
    assert sanitize_keys(obj, no_log_strings) == [{'*password': 'abc'}]

    obj = {'follow': {'password': 'abc'}}
    assert sanitize_keys(obj, no_log_strings) == {'follow': {'*password': 'abc'}}

    obj = 'password'
    assert sanitize_keys(obj, no_log_strings) == 'password'

    obj = ['password', 'pass_phrase']


# Generated at 2022-06-20 16:10:32.927446
# Unit test for function remove_values
def test_remove_values():
    """function remove_values unit test"""
    assert remove_values(1, ['1']) == 1
    assert remove_values('abc', ['abc']) == '***'
    assert remove_values('a\nb\nc', ['a\nb']) == 'a\n***\nc'
    assert remove_values(('a', 'b', 'c'), ['b']) == ('a', '***', 'c')
    assert remove_values(['a', 'b', 'c'], ['b']) == ['a', '***', 'c']
    assert remove_values({'a': 'b', 'c': 'd'}, ['b']) == {'a': '***', 'c': 'd'}

# Generated at 2022-06-20 16:10:38.942482
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert set_fallbacks({'foo': {'fallback': (env_fallback, 'FOO_ANSIBLE_TEST_VAR')}}, {}) == set()
    os.environ['FOO_ANSIBLE_TEST_VAR'] = 'test'
    assert set_fallbacks({'foo': {'fallback': (env_fallback, 'FOO_ANSIBLE_TEST_VAR')}}, {}) == {'test'}

# Generated at 2022-06-20 16:10:41.008400
# Unit test for function env_fallback
def test_env_fallback():
    import os
    os.environ['ANSIBLE_NET_PASSWORD'] = 'test123'
    assert env_fallback('ANSIBLE_NET_PASSWORD') == 'test123'



# Generated at 2022-06-20 16:10:44.879583
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['TEST_SECRET'] = 'my_secret'
    assert env_fallback('TEST_SECRET') == 'my_secret'
    assert env_fallback('TEST_SECRET_INVALID') == None
    del os.environ['TEST_SECRET']
    assert env_fallback('TEST_SECRET') == None



# Generated at 2022-06-20 16:10:49.947857
# Unit test for function sanitize_keys
def test_sanitize_keys():
    '''
    return true if function sanitize_keys return expected o/p else false
    '''
    no_log_value = set()
    no_log_value.add('test')
    test_dict = {'test_key': 'test'}

    test_dict_output = sanitize_keys(test_dict, no_log_value)

    if '_test_key' not in test_dict_output and test_dict_output['_test_key'] == 'test':
        return True
    else:
        return False

# Generated at 2022-06-20 16:12:01.698274
# Unit test for function set_fallbacks
def test_set_fallbacks():
    from ansible.module_utils.common.validation import validate_parameters, DEFAULT_ARGUMENT_SPEC, HUMAN_LOG
    parameter = {
        'name': 'my_answer',
    }
    argument_spec = {
        'name': dict(default='42'),
        'question': dict(required=True)
    }
    HUMAN_LOG = False

    # Test setting fallback value
    validate_parameters(argument_spec, parameter)
    assert parameter == {
        'name': '42',
        'question': 'Life, the Universe, and Everything',
    }

    # Test that default is ignored if parameter value is set
    argument_spec['name']['default'] = 'Answer to the Ultimate Question of Life,'
    validate_parameters(argument_spec, parameter)

# Generated at 2022-06-20 16:12:06.638243
# Unit test for function set_fallbacks
def test_set_fallbacks():
  argument_spec = dict(state=dict(required=False, type='str', choices=['present', 'absent'], fallback=(env_fallback, ['ANSIBLE_NET_HOSTNAME'])), host=dict(required=False, type='str'), username=dict(required=False, type='str', fallback=(env_fallback, ['ANSIBLE_NET_USERNAME'])))
  parameters = dict(host="fortimanager_host")
  result = set_fallbacks(argument_spec, parameters)
  assert result == {'fortimanager_host'}



# Generated at 2022-06-20 16:12:18.000108
# Unit test for function set_fallbacks
def test_set_fallbacks():

    argument_spec = dict(
        password=dict(type='str', fallback=(env_fallback, ['ANSIBLE_NET_PASSWORD'])),
        backup=dict(type='bool', fallback=(False,)),
        dns_check_ipv6=dict(type='bool', fallback=(False,)),
    )

    parameters = dict(
        password='foo',
        backup=True,
        dns_check_ipv6=None
    )
    # Test with all args already defined
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['password'] == 'foo'
    assert parameters['backup'] is True
    assert parameters['dns_check_ipv6'] is False
    assert len(no_log_values) == 0

    # Test with no args defined


# Generated at 2022-06-20 16:12:29.652115
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        one=dict(type='str', fallback=(env_fallback, 'TEST_ONE')),
        two=dict(type='str', fallback=(env_fallback, 'TEST_TWO')),
    )
    parameters = dict()
    os.environ['TEST_ONE'] = 'one'
    os.environ['TEST_TWO'] = 'two'

    no_log_values = set_fallbacks(argument_spec, parameters)

    assert parameters['one'] == 'one'
    assert parameters['two'] == 'two'
    assert len(no_log_values) == 0

    del os.environ['TEST_ONE']
    del os.environ['TEST_TWO']



# Generated at 2022-06-20 16:12:33.451905
# Unit test for function sanitize_keys
def test_sanitize_keys():
    obj = [1, 2, 3, {"a": "b", "c": "d"}, {"a": "b", "c": "d"}]
    no_log_strings = ('d', )
    ignore_keys = ('a', 'c')
    new_value = sanitize_keys(obj, no_log_strings, ignore_keys)
    assert new_value == [1, 2, 3, {"a": "b", "c": "********"}, {"a": "b", "c": "********"}]



# Generated at 2022-06-20 16:12:43.735503
# Unit test for function set_fallbacks
def test_set_fallbacks():
    params = os.environ.copy()
    params['ANSIBLE_FOO'] = 'bar'
    spec = {
        'foo': {'type': 'str',
                'no_log': True,
                'fallback': (env_fallback, 'ANSIBLE_FOO')},
        'bar': {'type': 'bool', 'fallback': (bool, False)},
        'baz': {'type': 'int', 'fallback': (int, '42')},
        'qux': {'type': 'str', 'no_log': True, 'fallback': [env_fallback, 'ANSIBLE_FOO']},
    }

    no_log_values = set_fallbacks(spec, params)
    # bool fallback should not be added
    assert 'bar' not in params
    # int fallback

# Generated at 2022-06-20 16:12:47.867346
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('DOES_NOT_EXIST') == AnsibleFallbackNotFound
    os.environ['FOO'] = 'BAR'
    assert env_fallback('FOO') == 'BAR'
test_env_fallback.no_ansible = True



# Generated at 2022-06-20 16:12:53.670433
# Unit test for function remove_values
def test_remove_values(): 
    assert remove_values([b'onetwo'], ['one']) == [b'one'], 'non-list no_log_strings param'
    assert remove_values('onetwo', ['one']) == 'one', 'non-str input'
    assert remove_values('onetwo', ['one', 'two']) == 'onethree', 'private_value_replacement param'
    assert remove_values({'one': 'twothree'}, ['two']) == {'one': 'twothree'}, 'non-list, non-str no_log_strings'
    assert remove_values({'one': 'twothree'}, ['']) == {'one': 'twothree'}, 'non-list, non-str no_log_strings'

# Generated at 2022-06-20 16:13:04.386358
# Unit test for function set_fallbacks

# Generated at 2022-06-20 16:13:09.436198
# Unit test for function sanitize_keys
def test_sanitize_keys():

    obj1 = {'abc': {'def': 'ghi'}}
    assert sanitize_keys(obj1, no_log_strings=['ghi']) == {'abc': {'def': 'ghi'}}

    obj2 = {'abc': {'def': 'ghi'}}
    assert sanitize_keys(obj2, no_log_strings=['ghi'], ignore_keys=['abc']) == {'abc': {'def': 'ghi'}}

    obj3 = {'abc': {'def': 'ghi'}}
    assert sanitize_keys(obj3, no_log_strings=['ghi'], ignore_keys=['def']) == {'abc': {'def': 'ghi'}}

    obj4 = {'abc': {'def': 'ghi'}}


# Generated at 2022-06-20 16:14:33.647113
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('HOME') == os.environ['HOME']
    env_var_name = 'foo'
    if env_var_name not in os.environ:
        os.environ[env_var_name] = 'bar'
    assert env_fallback(env_var_name) == 'bar'
    del os.environ[env_var_name]
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback(env_var_name)
    del os.environ[env_var_name]



# Generated at 2022-06-20 16:14:44.283336
# Unit test for function sanitize_keys
def test_sanitize_keys():
    # Sanitize keys with no ignore_keys
    x = {u'password': u'password', u'username': u'user'}
    y = sanitize_keys(x, set([u'password']))
    assert y == {'sanitized_password': 'password', u'username': u'user'}
    assert y.keys() == ['sanitized_password', u'username']

    # Sanitize keys with no ignore_keys with unicode in the sanitized string
    x = {u'password': u'password', u'username': u'user'}
    z = 'P\xc3\xa1ssw0rd'
    y = sanitize_keys(x, set([z]))