

# Generated at 2022-06-20 16:05:51.595575
# Unit test for function set_fallbacks
def test_set_fallbacks():
    """Set fallback values in test case.

    Test that set_fallbacks successfully sets fallback values in the following cases
    1. Only fallback value provided
    2. Fallback provided with args
    3. Fallback provided with keyword args
    4. Fallback provided with args and keyword args
    5. Fallback provided with no_log
    """


# Generated at 2022-06-20 16:06:01.826633
# Unit test for function remove_values
def test_remove_values():
    no_log_strings = set(['foo'])
    result = remove_values('foo bar', no_log_strings)
    assert result == 'bar'

    mylist = ['foo', 'bar', 'baz']
    result = remove_values(mylist, no_log_strings)
    assert result == ['bar', 'baz']

    mydict = {'foo': 'bar', 'baz': 'quux'}
    result = remove_values(mydict, no_log_strings)
    assert result == {'baz': 'quux'}

    mydict = {'foo': 'bar', 'baz': 'quux'}
    result = remove_values(mydict, no_log_strings)
    assert result == {'baz': 'quux'}


# Generated at 2022-06-20 16:06:07.541619
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('FOO') == 'bar'
    assert env_fallback('FOO', 'BAR') == 'bar'
    assert env_fallback('BAR', 'FOO') == 'bar'
    assert env_fallback('BAR') == os.environ['BAR']


# Generated at 2022-06-20 16:06:12.930410
# Unit test for function sanitize_keys
def test_sanitize_keys():
    class Obj(object):
        def __init__(self, value):
            self.value = value

        def __repr__(self):
            return self.value

    obj = {'a': {'b': 'c', 'd': 'e', 'f': Obj('g')}, 'h': [{'i': 'j', 'k': 'l'}, {'m': 'n', 'o': 'p'}], 'q': {}, 'r': set()}
    assert sanitize_keys(obj, set()) == obj

# Generated at 2022-06-20 16:06:23.048209
# Unit test for function remove_values
def test_remove_values():

    # TODO: Add test for keys with regex.
    # TODO: Add test for handler/tasks.
    # TODO: Add test for plugin settings.

    # Test for dict
    value_dict = {'key_1': 'string1', 'key_2': 'string2'}
    no_log_strings_list = ['string1']
    new_value_dict = remove_values(value_dict, no_log_strings_list)
    assert new_value_dict == {'key_1': 'VALUE STRINGIFIED', 'key_2': 'string2'}

    # Test for list
    value_list = [{'key_1': 'string1', 'key_2': 'string2'}, 'string1']
    no_log_strings_list = ['string1']
    new_value_list = remove

# Generated at 2022-06-20 16:06:27.629783
# Unit test for function env_fallback
def test_env_fallback():
    """Fail if env_fallback function fails"""

    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('__not_in_env__')



# Generated at 2022-06-20 16:06:39.341732
# Unit test for function remove_values
def test_remove_values():
    ''' test remove_values function '''
    no_log_strings = set(['Redacted', 'Private data'])

    # test remove string
    value = 'This is some Private data'
    new_value = remove_values(value, no_log_strings)
    assert new_value == 'This is some '

    # test remove string in a list
    value = ['This is some Private data']
    new_value = remove_values(value, no_log_strings)
    assert new_value == ['This is some ']

    # test remove string in a list of strings
    value = ['This is some Private data', 'This is another string']
    new_value = remove_values(value, no_log_strings)
    assert new_value == ['This is some ', 'This is another string']

    # test remove string in a

# Generated at 2022-06-20 16:06:48.190406
# Unit test for function sanitize_keys
def test_sanitize_keys():
    from ansible.compat.tests.mock import patch
    from ansible.compat.tests import unittest
    from ansible.module_utils.six import binary_type, text_type, PY3

    # Open file to write results to
    result_file = open("sanitize_keys_test_results", "w+")

    # Strings that are NOT no_log strings
    test_strings = [
        "This is a key",
        "",
        "This is not a valid no_log string",
        text_type('\xe2\x98\xa0'),
        "This is not a valid no_log string\nThis is not a valid no_log string",
        "This is not a valid no_log string\x00This is not a valid no_log string"
    ]

    # Strings

# Generated at 2022-06-20 16:06:53.918797
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys({'ansible_password': 'secret'}, ['secret']) == {'__ansible_password': 'secret'}
    assert sanitize_keys({'ansible_password': 'secret', 'foo': 'bar'}, ['secret']) == {'__ansible_password': 'secret', 'foo': 'bar'}
    assert sanitize_keys({'ansible_password': 'secret', 'foo': 'bar'}, ['secret', 'bar']) == {'__ansible_password': 'secret', '__foo': 'bar'}
    assert sanitize_keys({'ansible_password': 'secret', 'foo': {'bar': 'secret'}}, ['secret']) == {'__ansible_password': 'secret', 'foo': {'__bar': 'secret'}}
    assert sanitize

# Generated at 2022-06-20 16:06:59.063274
# Unit test for function env_fallback
def test_env_fallback():
    # Inject env variable
    os.environ['FOO'] = 'bar'

    # Testing env variable exists
    assert env_fallback('FOO') == 'bar'

    # Testing env variable doesn't exist
    try:
        env_fallback('BAR')
        assert False
    except AnsibleFallbackNotFound:
        assert True

    # Clean up
    os.environ.pop('FOO')


# Generated at 2022-06-20 16:07:36.951533
# Unit test for function remove_values
def test_remove_values():
    assert remove_values('mypassword', ['mypassword']) == 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'

    conn_dict = dict(
        password='mypass',
        otherpassword='otherpass'
    )
    result = remove_values(conn_dict, ['mypass'])
    assert result == {'password': 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER', 'otherpassword': 'otherpass'}

    conn_dict['ssh_args'] = "-o PasswordAuthentication=no -o PubkeyAuthentication=yes"
    result = remove_values(conn_dict, ['mypass'])

# Generated at 2022-06-20 16:07:45.372597
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {"param1": {"type": "str", "fallback": (env_fallback, "param1_1", "param1_2")}}
    parameters = {}
    os.environ["param1_1"] = "1"
    os.environ["param1_2"] = "2"

    assert set_fallbacks(argument_spec, parameters) == set()
    assert parameters["param1"] == '1'
    assert "param1" in parameters
    assert "param1_1" in os.environ
    assert "param1_2" in os.environ

    del os.environ["param1_1"]
    del os.environ["param1_2"]



# Generated at 2022-06-20 16:07:56.992944
# Unit test for function set_fallbacks
def test_set_fallbacks():
    params = {'foo': 'bar', 'baz': 'qux'}
    assert set_fallbacks({}, params) == set([])
    spec = {'foo': {}, 'bar': {'fallback': (str, 'bar_default')}, 'baz': {'fallback': (str, ['baz_default'])}, 'cux': {'fallback': (env_fallback, 'CUX')}}
    assert set_fallbacks(spec, params) == set([])
    os.environ['CUX'] = 'cux_env_value'
    assert set_fallbacks(spec, params) == set(['cux_env_value'])
    del os.environ['CUX']
    assert set_fallbacks(spec, params) == set([])



# Generated at 2022-06-20 16:08:07.382767
# Unit test for function set_fallbacks
def test_set_fallbacks():
    def test_fallback_strategy(arg1, arg2, kwarg1=None, kwarg2=None):
        return [arg1, arg2, kwarg1, kwarg2]

    fallback_arguments = ['arg1', 'arg2', {'kwarg1': 'kwarg1'}, {'kwarg2': 'kwarg2'}]

    no_log_values = set()

# Generated at 2022-06-20 16:08:14.308311
# Unit test for function remove_values
def test_remove_values():
    assert remove_values("'password': 'secret'", ['secret']) == "^password^: 'secret'"
    assert remove_values("'password': u'secret'", ['secret']) == "^password^: u'secret'"
    assert remove_values("'password': u'secret'", ['secret']) == "^password^: u^secret^"
    assert remove_values("'password': u'sec' + 'ret'", ['secret']) == "^password^: u'sec' + 'ret'"
    assert remove_values("''", ['string']) == "''"
    assert remove_values("'string'", ['string']) == "'string'"
    assert remove_values("u'string'", ['string']) == "u'string'"

# Generated at 2022-06-20 16:08:21.909255
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Test A: fallback is found and it is logged
    spec = dict(
        option_a=dict(type='int', fallback=(1,)),
        option_b=dict(type='str', fallback=(env_fallback, 'B')),
        option_c=dict(type='str', fallback=(env_fallback, 'C')),
        option_d=dict(type='str', fallback=(env_fallback, 'D'), no_log=True),
    )
    params = dict(
        option_a=42,
        option_c=42,
    )
    no_log_values = set_fallbacks(spec, params)

    expected_no_log_values = set([])
    assert no_log_values == expected_no_log_values


# Generated at 2022-06-20 16:08:26.356862
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('ANSIBLE_ANSIBLE_NOCOLOR', 'ANSIBLE_NOCOLOR') == 'ANSIBLE_ANSIBLE_NOCOLOR'
    assert env_fallback('ANSIBLE_VERBOSITY', 'ANSIBLE_DEBUG') == 'ANSIBLE_VERBOSITY'



# Generated at 2022-06-20 16:08:36.737941
# Unit test for function remove_values

# Generated at 2022-06-20 16:08:46.228348
# Unit test for function remove_values
def test_remove_values():
    assert remove_values('test password string value', ['password']) == 'test ***** string value'
    assert remove_values({
        'key': 'test password string value',
        'password': 'secret string',
        'list': [
            {'password': 'secret string', 'other': 'test'},
            'test password string value',
        ],
    }, ['password']) == {
        'key': 'test ***** string value',
        'password': '*****',
        'list': [
            {'password': '*****', 'other': 'test'},
            'test ***** string value'
        ]
    }
    assert remove_values(
        {'dict': {'password': 'secret string'}},
        ['password']
    ) == {'dict': {'password': '*****'}}
    assert remove_

# Generated at 2022-06-20 16:08:55.939982
# Unit test for function remove_values
def test_remove_values():
    value = {
        'ansible_net_hostname': 'test_host',
        'ansible_net_api': 'restconf'
    }
    no_log_strings = ['ansible_net_api']
    assert remove_values(value, no_log_strings) == {'ansible_net_hostname': 'test_host'}

    value = {
        'ansible_net_hostname': 'test_host',
        'ansible_net_api': 'restconf'
    }
    no_log_strings = ['restconf']
    assert remove_values(value, no_log_strings) == {'ansible_net_hostname': 'test_host', 'ansible_net_api': 'restconf'}


# Generated at 2022-06-20 16:09:50.706729
# Unit test for function sanitize_keys
def test_sanitize_keys():
    import json
    import pprint
    no_log_strings = ['password', 'cert']

    data = {
        "foo": "bar",
        "password": "hello",
        "foo_password": {
            "hello": "world",
            "password": "abc",
            "cert": "xyz"
        }
    }
    expected = {
        "foo": "bar",
        "foo_password": {
            "hello": "world",
            "cert": "xyz"
        }
    }
    sanitized = sanitize_keys(data, no_log_strings)
    assert sanitized == expected



# Generated at 2022-06-20 16:09:54.810827
# Unit test for function env_fallback
def test_env_fallback():
    import os
    os.environ['TEST'] = '/test/path'
    assert env_fallback('TEST', 'FOO') == '/test/path'
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('BAD')


# Generated at 2022-06-20 16:09:59.463485
# Unit test for function env_fallback
def test_env_fallback():
    assert 'PATH' in os.environ
    assert env_fallback('PATH', 'FOO') == os.environ['PATH']
    assert env_fallback('FOO', 'PATH') == os.environ['PATH']
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('FOO')



# Generated at 2022-06-20 16:10:04.508661
# Unit test for function env_fallback
def test_env_fallback():
    assert 'HOME' in os.environ
    assert env_fallback('HOME') == os.environ['HOME']
    assert env_fallback('HOME', 'USER') == os.environ['HOME']
    assert env_fallback('USER') == os.environ['USER']
    assert env_fallback('OTHER_VARIABLE') == os.environ.get('OTHER_VARIABLE')



# Generated at 2022-06-20 16:10:18.771475
# Unit test for function env_fallback
def test_env_fallback():
    test_vars = dict(one='1', two='2', three='3')
    os.environ = test_vars
    assert env_fallback('one') == '1'
    assert env_fallback('two') == '2'
    assert env_fallback('three') == '3'
    os.environ = {}
    assert env_fallback('one') == '1'
    assert env_fallback('two') == '2'
    assert env_fallback('three') == '3'
    os.environ = test_vars

# Generated at 2022-06-20 16:10:28.537277
# Unit test for function env_fallback
def test_env_fallback():
    # There is a possibility that there is an environment variable called
    # ANSIBLE_ARGUMENT_SPEC_TEST_VAR, so set it and remove it if it exists
    env_var = 'ANSIBLE_ARGUMENT_SPEC_TEST_VAR'
    env_val = 'ANSIBLE_SPEC_TEST_VALUE'
    env_orig_val = os.environ.get(env_var, None)
    os.environ[env_var] = env_val

    # Test that env_fallback finds the variable
    assert env_fallback(env_var) == env_val

    # Test that env_fallback raises AnsibleFallbackNotFound when env var is not found

# Generated at 2022-06-20 16:10:36.562576
# Unit test for function env_fallback
def test_env_fallback():
    if 'THIS_IS_AN_UNUSED_ENV' in os.environ:
        del os.environ['THIS_IS_AN_UNUSED_ENV']
    try:
        env_fallback('THIS_IS_AN_UNUSED_ENV')
    except AnsibleFallbackNotFound:
        pass
    else:
        assert False, "env_fallback() failed"
    os.environ['THIS_IS_AN_UNUSED_ENV'] = 'bad value'
    assert env_fallback('THIS_IS_AN_UNUSED_ENV') == 'bad value'
    del os.environ['THIS_IS_AN_UNUSED_ENV']



# Generated at 2022-06-20 16:10:40.489417
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert set_fallbacks({'name': {'default': 'new', 'fallback': (env_fallback, 'OLDNAME') }}, {}) == set(['new'])
    assert set_fallbacks({'name': {'default': 'new', 'fallback': (env_fallback, 'OLDNAME') }}, {'name': 'old'}) == set(['old'])



# Generated at 2022-06-20 16:10:48.144339
# Unit test for function sanitize_keys
def test_sanitize_keys():
    no_log_strings = set()
    ignore_keys = frozenset()
    # Sanitize keys of a list
    test_list = [{'key1': 'value1', 'key2': 'value2'}, {'key1': 'value1', 'key2': 'value2'}]
    test_list_em = sanitize_keys(test_list, no_log_strings, ignore_keys)
    assert test_list_em == [{'key1': 'value1', 'key2': 'value2'}, {'key1': 'value1', 'key2': 'value2'}]
    # Sanitize keys of a dictionary
    test_dict = {'key1': 'value1', 'key2': 'value2'}

# Generated at 2022-06-20 16:10:57.809567
# Unit test for function set_fallbacks
def test_set_fallbacks():
    spec = dict(
        foo=dict(type=dict, fallback=(dict, {'bar': 'baz'})),
        bar=dict(type='str', fallback='a_string')
    )

    parameters = dict()
    parameters.update(dict(foo={'a': 'b'}))
    no_log_values = set_fallbacks(spec, parameters)
    assert parameters.get('foo') == {'a': 'b'}
    assert parameters.get('bar') == 'a_string'
    assert no_log_values == set()

    parameters = dict()
    no_log_values = set_fallbacks(spec, parameters)
    assert parameters.get('foo') == {'bar': 'baz'}
    assert parameters.get('bar') is None
    assert no_log_values == set()

# Generated at 2022-06-20 16:11:59.350355
# Unit test for function remove_values
def test_remove_values():
    from ansible.compat.tests import unittest

    class TestValues(unittest.TestCase):
        def setUp(self):
            self.nolog_strings = ['password', 'token', 'ssh-key']
            self.ignore_keys = ['nonce']

        def test_dict(self):
            data = {
                'key1': 'value1',
                'key2': 'token',
                'key3': {
                    'key4': 'value3',
                    'nonce': 'random',
                    'password': 'secret',
                },
            }
            new_data = remove_values(data, self.nolog_strings)

# Generated at 2022-06-20 16:12:07.905975
# Unit test for function sanitize_keys

# Generated at 2022-06-20 16:12:18.634934
# Unit test for function sanitize_keys
def test_sanitize_keys():
    # Test some simple text strings
    assert sanitize_keys('foo', ['foo']) == ''
    assert sanitize_keys('foo', ['foo'], ignore_keys=['foo']) == 'foo'
    assert sanitize_keys('foo', ['foo'], ignore_keys=['foo']) == 'foo'

    # Test a list with a string
    assert sanitize_keys(['foo'], ['foo']) == ['']

    # Test a list with a dictionary and a list
    assert sanitize_keys([{'foo': 'bar', 'baz': 'qux'}, ['foo', 'bar', 'baz']], ['foo']) == [
        {'bar', 'qux'},
        ['bar', 'baz'],
    ]

    # Test a list with a dictionary and a list,

# Generated at 2022-06-20 16:12:30.632286
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert True == True
    # key remove
    assert sanitize_keys({u'key_1': 'value_1', u'key_2': 'value_2'}, set(['key_1'])) == {u'****': 'value_1', u'key_2': 'value_2'}
    # nested key remove
    assert sanitize_keys({u'key_1': [{u'key_2': 'value_2'}]}, set(['key_2'])) == {u'key_1': [{u'****': 'value_2'}]}
    # key ignore

# Generated at 2022-06-20 16:12:32.882769
# Unit test for function env_fallback
def test_env_fallback():
    """Test for function env_fallback"""
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback()



# Generated at 2022-06-20 16:12:43.260026
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys(['a', 'b', 'c'], {'a'}) == ['b', 'c']
    assert sanitize_keys(set(['a', 'b', 'c']), {'a'}) == set(['b', 'c'])
    assert sanitize_keys({'a': 'a', 'b': 'b'}, {'a'}) == {'b': 'b'}
    assert sanitize_keys({'a': {'a': {'a': 'a'}}}, {'a'}) == {'b': {'c': {'d': 'a'}}}

# Generated at 2022-06-20 16:12:52.810922
# Unit test for function remove_values
def test_remove_values():
    # values to be removed
    ps = ['arbor', 'elm', 'oak']

    # container types

# Generated at 2022-06-20 16:12:57.134251
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_FOO_BAR'] = 'baz'
    result = env_fallback('ANSIBLE_FOO_BAR')
    assert result == 'baz'
    result = env_fallback('ANSIBLE_FOO_BAR_INVALID')
    assert isinstance(result, AnsibleFallbackNotFound)



# Generated at 2022-06-20 16:13:05.770306
# Unit test for function env_fallback
def test_env_fallback():
    try:
        env_fallback('/tmp/no_such_file')
        assert False
    except AnsibleFallbackNotFound:
        pass
    try:
        env_fallback('/tmp/ansible_test_env_fallback_unit_test_file')
        assert False
    except AnsibleFallbackNotFound:
        pass

    (fd, fname) = tempfile.mkstemp(dir='/tmp')
    os.close(fd)
    fd = None
    fd_str = None

# Generated at 2022-06-20 16:13:14.187569
# Unit test for function set_fallbacks
def test_set_fallbacks():

    params = dict(
        bool1=True,
        bool2=False,
        string='a string',
        list=['a', 'b'],
        dict1=dict(a=1, b=2),
        dict2=dict(c=3, d=4),
        missing=None,
    )

    # Set fallbacks