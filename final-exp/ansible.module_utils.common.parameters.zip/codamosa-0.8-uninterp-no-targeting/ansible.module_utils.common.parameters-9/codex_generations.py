

# Generated at 2022-06-20 16:05:27.004226
# Unit test for function remove_values
def test_remove_values():
    from collections import MutableMapping, MutableSequence, MutableSet

    # String replacements
    assert remove_values('some string', []) == 'some string'
    assert remove_values('some string', ['some']) == '<omitted string>'
    assert remove_values('some string', ['some', 'string']) == '<omitted>'
    assert remove_values('some string', ['some', 'string', 'string']) == '<omitted>'
    assert remove_values('some string', ['some', 'sTring', 'string']) == '<omitted>'
    assert remove_values('some string', ['some', 'string'], replace_multiple=False) == '<omitted string>'

# Generated at 2022-06-20 16:05:34.510828
# Unit test for function sanitize_keys
def test_sanitize_keys():
    no_log_strings = ['password']
    def _assert(input_data, expected_output_data):
        no_log_strings = [to_native(s, 'utf-8') for s in no_log_strings]
        actual_output_data = sanitize_keys(input_data, no_log_strings)
        assert actual_output_data == expected_output_data

    # Basic tests
    _assert({'foo': 'bar'}, {'foo': 'bar'})
    _assert({'foo': 'bar', 'foo_password': 'a password'}, {'foo': 'bar'})
    _assert({'foo_password': 'a password'}, {})

    # Nested dictionary

# Generated at 2022-06-20 16:05:40.391809
# Unit test for function remove_values
def test_remove_values():

    class Fake(object):
        def __init__(self, **kwargs):
            self.__dict__ = kwargs

    fake = Fake(password='password', private_info=Fake(password='password'))

    assert remove_values(fake, 'password') == Fake(password='VALUE_SPECIFIED_IN_NO_LOG_PARAMETER', private_info=Fake(password='VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'))
    assert remove_values([fake], 'password') == [Fake(password='VALUE_SPECIFIED_IN_NO_LOG_PARAMETER', private_info=Fake(password='VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'))]

# Generated at 2022-06-20 16:05:45.256876
# Unit test for function remove_values
def test_remove_values():
    value = {
        "A": {
            "password": "PASS",
            "aws_secret_key": "AWS",
            "bearer_token": "TOKEN"
        },
        "B": [
            {
                "client_secret": "CLIENT",
                "api_key": "API"
            },
            {
                "ssh_key": "SSH",
                "ssh_pass": "PASS"
            }
        ]
    }

    no_log_strings = ["PASS", "TOKEN", "AWS", "CLIENT", "API", "SSH"]

    no_log_strings_stripped = [remove_values(value, no_log_strings) for _ in no_log_strings]


# Generated at 2022-06-20 16:05:50.078382
# Unit test for function env_fallback
def test_env_fallback():
    os.environ["TEST_ENV_FALLBACK"] = "test_env_fallback"
    assert env_fallback('TEST_ENV_FALLBACK') == 'test_env_fallback'
    assert env_fallback('TEST_ENV_FALLBACK_NOT_SET') is None
    del os.environ["TEST_ENV_FALLBACK"]

# Generated at 2022-06-20 16:06:01.034268
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        foo=dict(type='str', fallback=(env_fallback, ['ANSIBLE_TEST_FOO'])),
        bar=dict(type='str', fallback=(env_fallback, ['ANSIBLE_TEST_BAR'])),
        baz=dict(type='str', fallback=(env_fallback, ['ANSIBLE_TEST_BAZ'])),
        bat=dict(type='str', fallback=(env_fallback, ['ANSIBLE_TEST_BAT'])),
    )
    parameters = dict(foo='foo_value')
    expected_no_log_values = set()
    expected_parameters = dict(foo='foo_value', bar='bar_value', baz='', bat=None)
    os.environ['ANSIBLE_TEST_FOO']

# Generated at 2022-06-20 16:06:12.365172
# Unit test for function remove_values
def test_remove_values():
    def check_remove_values(value, expected, no_log_strings):
        new_value = remove_values(value, no_log_strings)
        if new_value != expected:
            raise Exception('remove_values() failed. Expected %s. Got %s' % (expected, new_value))

    check_remove_values(
        dict(foo=dict(bar='baz', qux=dict(quux='corge', grault='garply', waldo='fred')), corge='baz'),
        dict(foo=dict(bar='baz', qux=dict(quux='***', grault='***', waldo='***')), corge='***'),
        ['corge', 'garply', 'fred']
    )


# Generated at 2022-06-20 16:06:20.251543
# Unit test for function remove_values
def test_remove_values():
    small_mapping = {'key': 'val', 'key2': 'val', 'other': {'key': 'val'}}
    assert remove_values(small_mapping, ['val']) == {'key': '', 'key2': '', 'other': {'key': ''}}
    small_list = ['val', 'val2']
    assert remove_values(small_list, ['val']) == ['', 'val2']
    small_set = set(['val', 'val', 'val2'])
    assert remove_values(small_set, ['val']) == set(['', 'val2'])



# Generated at 2022-06-20 16:06:32.699972
# Unit test for function sanitize_keys
def test_sanitize_keys():
    data = { 'attr1': 'value1',
             'attr2': 'value2',
             'attr3': {
                 'attr1': 'value1',
                 'attr2': 'value2',
                 'attr3': {
                     'attr1': 'value1',
                     'attr2': 'value2',
                     }
                 }
             }
    no_log_strings = set(['value2'])
    ignore_keys = []

    new_data = sanitize_keys(data, no_log_strings, ignore_keys)


# Generated at 2022-06-20 16:06:37.846682
# Unit test for function remove_values
def test_remove_values():
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-20 16:07:40.430876
# Unit test for function sanitize_keys
def test_sanitize_keys():
    # Unit test for function sanitize_keys
    def assert_no_private_keys(obj):
        private_keys = [key for key in obj if isinstance(key, string_types) and key.startswith('_ansible_')]
        assert not private_keys

    # Just recurse the data structure
    result = sanitize_keys({'key': 'value', 'list': ['value1', 'value2'], 'dict': {'key': 'value'}}, set())

    assert_no_private_keys(result)
    assert_no_private_keys(result['list'])
    assert_no_private_keys(result['dict'])

    # Add a scalar that has a private key

# Generated at 2022-06-20 16:07:51.905844
# Unit test for function remove_values
def test_remove_values():
    # Test list removal
    assert remove_values([1, u'2', 3, u'blah'], [u'blah']) == [1, u'2', 3]

    # Test dict removal
    assert remove_values({1: u'2', 3: u'blah'}, [u'blah']) == {1: u'2'}

    # Test set removal
    assert remove_values(set([u'blah', u'blah2', u'blah3']), [u'blah']) == set([u'blah2', u'blah3'])

    # Test recursion

# Generated at 2022-06-20 16:08:03.478390
# Unit test for function env_fallback
def test_env_fallback():
    varname = 'ANSIBLE_INVENTORY_VAR1'
    if varname in os.environ:
        old_value = os.environ[varname]
        del os.environ[varname]
    else:
        old_value = None
    os.environ[varname] = 'Hello World'
    assert env_fallback(varname) == 'Hello World'
    assert env_fallback('ANSIBLE_INVENTORY_VAR2') == 'Hello World'
    assert env_fallback('ANSIBLE_INVENTORY_VAR3') == 'Hello World'
    try:
        assert env_fallback('ANSIBLE_INVENTORY_VAR4')
    except AnsibleFallbackNotFound:
        pass

# Generated at 2022-06-20 16:08:07.829005
# Unit test for function env_fallback
def test_env_fallback():
    # Test with no value found
    try:
        env_fallback('FOOBAR')
    except AnsibleFallbackNotFound:
        pass
    else:
        raise AssertionError('env_fallback should have raised exception')
    # Test with value found
    os.environ['FOOBAR'] = 'beer'
    assert env_fallback('FOOBAR') == 'beer'
    del os.environ['FOOBAR']



# Generated at 2022-06-20 16:08:13.051836
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys('password', ['pass']) == 'password'
    assert sanitize_keys({'pass': 'word'}, ['pass']) == {'<censored>': 'word'}
    assert sanitize_keys({'pass': 'word', 'user': 'foo'}, ['pass']) == {'<censored>': 'word', 'user': 'foo'}
    assert sanitize_keys({'pass': 'word', 'user': 'foo'}, ['foo']) == {'pass': 'word', 'user': 'foo'}



# Generated at 2022-06-20 16:08:17.132096
# Unit test for function remove_values
def test_remove_values():
    data = [{"key1":"value1", "key2": ["value2", {"key3": "value3"}] }, "value4"]
    no_log_strings = ["value1","value4"]
    result = remove_values(data, no_log_strings)
    assert result == [{"key1":"***", "key2": ["***", {"key3": "***"}] }, "***"]


# Generated at 2022-06-20 16:08:23.458683
# Unit test for function set_fallbacks
def test_set_fallbacks():
    import pytest

    # Ensure that environment variables get pulled in as fallbacks
    os.environ['ANSIBLE_NET_USERNAME'] = 'myusername'
    os.environ['ANSIBLE_NET_PASSWORD'] = 'mypassword'
    assert set_fallbacks({'username': {'fallback': (env_fallback, ('ANSIBLE_NET_USERNAME',))},
                          'password': {'fallback': (env_fallback, ('ANSIBLE_NET_PASSWORD',))}},
                         {'username': None, 'password': None}) == set()

# Generated at 2022-06-20 16:08:33.540862
# Unit test for function remove_values
def test_remove_values():
    data = dict(
        foo=dict(
            bar=dict(
                baz='foo'
            ),
        ),
        one=[
            'one',
            dict(
                two='two',
                three=['tree', 'four']
            ),
            dict(
                four='four',
                five='five'
            ),
            'six'
        ],
        seven='seven',
        eight=dict(
            nine='nine',
            ten='ten',
            eleven='eleven',
            twelve=dict(
                thirteen=dict(
                    fourteen='fourteen',
                ),
                fifteen=dict(
                    sixteen=dict(
                        seventeen='seventeen',
                        eighteen='eighteen',
                    )
                ),
            ),
        ),
    )

    expected_output = copy.deepcopy(data)
   

# Generated at 2022-06-20 16:08:44.365360
# Unit test for function set_fallbacks
def test_set_fallbacks():
    arg_spec = dict(
        option1=dict(type='str', fallback=(env_fallback, "TEST_ENV_1", "TEST_ENV_2", "TEST_ENV_3")),
        option2=dict(type='str', fallback=(env_fallback, "TEST_ENV_1", "TEST_ENV_2")),
    )
    params = dict(option1="test value")
    set_fallbacks(arg_spec, params)
    assert "option1" not in params
    assert "option2" not in params

    os.environ["TEST_ENV_2"] = "test value 2"
    set_fallbacks(arg_spec, params)
    assert params["option1"] == "test value 2"
    assert "option2" not in params



# Generated at 2022-06-20 16:08:49.659389
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('ANSIBLE_MODULE_ARGS', 'ANSIBLE_MODULE_ARGS') == os.environ['ANSIBLE_MODULE_ARGS']
    assert_raises(AnsibleFallbackNotFound, env_fallback, 'ANSIBLE_MODULE_ARGS', 'ANSIBLE_MODULE_ARGS', 'ANSIBLE_NON_EXISTING_VAR')



# Generated at 2022-06-20 16:09:18.822769
# Unit test for function remove_values
def test_remove_values():
    no_log_strings = ['password', 'secret']
    remove_values(['password', 'secret'], no_log_strings)
    remove_values({'password': 'secret'}, no_log_strings)
    remove_values({'password': ['secret', 'secret']}, no_log_strings)
    remove_values({'password': {'password': 'secret'}}, no_log_strings)



# Generated at 2022-06-20 16:09:23.033605
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Test env fallback
    os.environ['TEST_ENV_VAR'] = '1'
    os.environ['TEST_ENV_VAR_2'] = '2'

# Generated at 2022-06-20 16:09:34.206682
# Unit test for function remove_values
def test_remove_values():
    no_log_strings = ['3', '4', '5']
    no_log_strings_1 = ['1', '2', '3']
    test_replace_value = '***'
    mutable_test_data = {'C': '3', 'B': ['3', ['3', '4', '3', '4', '5'], {'3': '4', '5': '6'}], 'A': [{'1': '2', '2': '3', '3': '4', '4': '5', '5': '6'}], 'D': '6'}

# Generated at 2022-06-20 16:09:43.717212
# Unit test for function set_fallbacks
def test_set_fallbacks():
    options = dict()
    argument_spec = dict(a=dict(required=True, fallback=('str_type',)
                                ),
                         b=dict(required=True, fallback=[env_fallback, 'OS_USERNAME'],
                                ),
                         c=dict(required=True, fallback=(env_fallback, 'OS_USERNAME', {'fallback': 'OS_PASSWORD'})
                                )
                         )
    set_fallbacks(argument_spec, options)
    assert options['a'] == 'str_type'
    assert options['b'] == os.getenv('OS_USERNAME')
    assert options['c'] == os.getenv('OS_PASSWORD')



# Generated at 2022-06-20 16:09:56.015406
# Unit test for function remove_values
def test_remove_values():
    no_log_strings = ['two']
    plain_value = 'one'
    container_value = {
        'plain_string': 'one',
        'no_log_string': 'two',
        'another_no_log_string': 'two',
        'list_of_strings': ['one', 'two', 'three'],
        'dict': {
            'plain_string': 'one',
            'no_log_string': 'two',
            'another_no_log_string': 'two',
            'list_of_strings': ['one', 'two', 'three'],
        }
    }

# Generated at 2022-06-20 16:09:59.600072
# Unit test for function env_fallback
def test_env_fallback():
    # Invalid data type as argument
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback("")
    # Value not found in environment variables
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback("test_env_fallback_value")
    # Valid case
    os.environ["test_env_fallback_value"] = "test_env_fallback_value"
    assert env_fallback("test_env_fallback_value") == "test_env_fallback_value"
    del os.environ["test_env_fallback_value"]



# Generated at 2022-06-20 16:10:08.337994
# Unit test for function remove_values
def test_remove_values():
    assert remove_values('a', 'a') == '***'
    assert remove_values('ab', 'a') == '*b'
    assert remove_values('ba', 'a') == 'b*'
    assert remove_values('ba', 'ab') == '**'
    assert remove_values('abc', 'bc') == 'a**'
    assert remove_values('abc', 'ab') == 'a**'
    assert remove_values(['a', 'b', 'ab'], 'ab') == ['*', '*', '**']
    assert remove_values({'b': 'a', 'a': 'ab'}, 'ab') == {'b': '*', 'a': '**'}
    assert remove_values({'a': None}, 'a') == {'a': None}

# Generated at 2022-06-20 16:10:19.505885
# Unit test for function remove_values
def test_remove_values():
    # no_log_strings is a set
    no_log_strings = {"no_log_strings", "password", "passwd", "myvalue"}
    # List

# Generated at 2022-06-20 16:10:29.114042
# Unit test for function env_fallback
def test_env_fallback():
    '''Validate unpacking of lists as fallbacks'''
    os.environ["FOO"] = "bar"
    os.environ["BAR"] = "foo"
    # Test each arg as an env var
    assert env_fallback("FOO"), "bar"
    assert env_fallback("BAR"), "foo"
    # Test only one arg as an env var, rest as a list
    assert env_fallback("FOO", ["bar"]), "bar"
    assert env_fallback("BAR", ["foo"]), "foo"
    # Test only one arg as an env var, rest as a list
    assert env_fallback("FOO", ["bar"]), "bar"
    assert env_fallback("BAR", ["foo"]), "foo"

    # Test fallback to list
    assert env_fallback

# Generated at 2022-06-20 16:10:41.649875
# Unit test for function sanitize_keys
def test_sanitize_keys():
    """Test sanitize_keys function"""
    no_log_strings = ['a_password', 'another_password']
    test_obj = {'a_secret': 'a_password', 'this_is_a_password': 'another_password'}

    # Test for both Mapping and MutableSequence and MutableSet
    test_container_mapping = {'a_mapping': test_obj}
    test_container_sequence = [test_obj]
    test_container_set = {test_obj}

    # Test without ignore_keys
    result_container_mapping = sanitize_keys(test_container_mapping, no_log_strings)
    result_container_sequence = sanitize_keys(test_container_sequence, no_log_strings)

# Generated at 2022-06-20 16:11:13.381231
# Unit test for function set_fallbacks
def test_set_fallbacks():
    args = {'default1': {'default': "a",
                         'type': 'str'},
            'default2': {'default': "a",
                         'type': 'str',
                         'fallback': (env_fallback, ['ANSIBLE_TEST_FALLBACK_VAR'])
                         }
            }
    parameters = {'default1': None,
                  'default2': None}


    # environment variable not set
    set_fallbacks(args, parameters)
    assert parameters == {'default1': "a",
                          'default2': None}

    # environment variable set
    os.environ['ANSIBLE_TEST_FALLBACK_VAR'] = 'b'
    set_fallbacks(args, parameters)

# Generated at 2022-06-20 16:11:25.767715
# Unit test for function set_fallbacks
def test_set_fallbacks():
    import sys
    import textwrap

    from ansible.module_utils._text import to_bytes, to_native

    # Save real function references for later
    _get_bin_path = ansible.module_utils.basic._get_bin_path
    _get_distribution = ansible.module_utils.basic._get_distribution
    _is_platform_windows = ansible.module_utils.basic._is_platform_windows

    # Define dummy functions to override the real ones
    def _get_bin_path_dummy(cmd, required=False):
        if cmd == 'git':
            return '/foo/git'
        elif cmd == 'bar':
            return None
        else:
            raise ValueError("No basic function specified for parameter %s" % cmd)


# Generated at 2022-06-20 16:11:37.267056
# Unit test for function sanitize_keys
def test_sanitize_keys():
    # test edge cases
    assert sanitize_keys(None, no_log_strings=[]) == None
    assert sanitize_keys([], no_log_strings=[]) == []
    assert sanitize_keys((), no_log_strings=[]) == ()
    assert sanitize_keys('', no_log_strings=[]) == ''
    assert sanitize_keys(True, no_log_strings=[]) == True
    assert sanitize_keys(False, no_log_strings=[]) == False
    assert sanitize_keys(set(), no_log_strings=[]) == set()
    assert sanitize_keys(0, no_log_strings=[]) == 0
    assert sanitize_keys(0.0, no_log_strings=[]) == 0.0

# Generated at 2022-06-20 16:11:49.045307
# Unit test for function sanitize_keys
def test_sanitize_keys():

    assert sanitize_keys({"no_log": "password", "this_key_will_not_be_shown": "foo"}, "password") == {"nolog": "password",
                                                                                                     "thiskeywillnotbeshown": "foo"}
    assert sanitize_keys({"no_log": "password", "this_key_will_be_shown": "foo"}, "foo") == {"no_log": "password",
                                                                                                     "thiskeywillbeshown": "foo"}

# Generated at 2022-06-20 16:12:00.420583
# Unit test for function remove_values
def test_remove_values():
    # Test ``remove_values`` with a bunch of different types of data.
    assert remove_values('foobar', ['foo']) == 'bar'

    assert remove_values('foo', ['foo']) == 'PRIVATE OUTPUT'
    assert remove_values(b'foo', [b'foo']) == 'PRIVATE OUTPUT'

    assert remove_values(['foo'], ['foo']) == ['PRIVATE OUTPUT']
    assert remove_values(b'foo', [b'foo']) == 'PRIVATE OUTPUT'

    assert remove_values(['foo', 'foo'], ['foo']) == ['PRIVATE OUTPUT', 'PRIVATE OUTPUT']
    assert remove_values([b'foo', b'foo'], [b'foo']) == ['PRIVATE OUTPUT', 'PRIVATE OUTPUT']

# Generated at 2022-06-20 16:12:12.430939
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'test': {
            'type': 'str',
            'fallback': (env_fallback, ('ANSIBLE_TEST_FALLBACK',))
        },
        'test2': {
            'type': 'str',
            'fallback': (env_fallback, ('ANSIBLE_TEST_FALLBACK_STRING',))
        },
        'test3': {
            'type': 'str',
            'fallback': (env_fallback, ('ANSIBLE_TEST_FALLBACK_NONE',))
        }
    }
    parameters = {}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['test'] == 1
    assert parameters['test2'] == 'string'
    assert no_log_values == set()



# Generated at 2022-06-20 16:12:17.481573
# Unit test for function remove_values
def test_remove_values():
    assert remove_values(None, []) is None
    assert remove_values(1, []) == 1
    assert remove_values(1.0, []) == 1.0
    assert remove_values('string', []) == 'string'
    assert remove_values(['string'], []) == ['string']
    assert remove_values(set(['string']), []) == set(['string'])
    assert remove_values({'key': 'value'}, []) == {'key': 'value'}

    assert remove_values(None, ['value']) is None
    assert remove_values(1, ['value']) == 1
    assert remove_values(1.0, ['value']) == 1.0
    assert remove_values('string', ['value']) == 'string'

# Generated at 2022-06-20 16:12:19.595973
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback("TEST_CONFIG") == "TEST_CONFIG_VALUE"


# Generated at 2022-06-20 16:12:31.583323
# Unit test for function sanitize_keys
def test_sanitize_keys():

    # Test dict keys/values
    obj = dict(key1='value1', key2='value2', key3='value3')
    sanitized_obj = sanitize_keys(obj, no_log_strings=['key2'])
    assert isinstance(sanitized_obj, dict)
    assert sanitized_obj == dict(key1='value1', key2='**', key3='value3')

    # Test list keys/values
    obj = ['key1=value1', 'key2=value2', 'key3=value3']
    sanitized_obj = sanitize_keys(obj, no_log_strings=['key2'])
    assert isinstance(sanitized_obj, list)
    assert sanitized_obj == ['key1=value1', 'key2=**', 'key3=value3']

   

# Generated at 2022-06-20 16:12:42.271737
# Unit test for function set_fallbacks

# Generated at 2022-06-20 16:13:34.682853
# Unit test for function set_fallbacks
def test_set_fallbacks():
    parameters = {}
    argument_spec = {}
    argument_spec['param_1'] = {'type': 'str'}
    argument_spec['param_2'] = {'type': 'int'}
    argument_spec['param_3'] = {'type': 'str'}
    argument_spec['param_4'] = {'type': 'str'}
    argument_spec['param_5'] = {'type': 'str', 'no_log': True}
    argument_spec['param_6'] = {'type': 'str', 'no_log': True}
    argument_spec['param_7'] = {'type': 'str', 'no_log': True}
    argument_spec['param_8'] = {'type': 'str', 'no_log': True}


# Generated at 2022-06-20 16:13:46.039923
# Unit test for function set_fallbacks
def test_set_fallbacks():
    params = {}
    spec = dict(foo=dict(type='str', fallback=('env_fallback', 'FOO')),
                bar=dict(type='str', fallback=(env_fallback, 'BAR'), no_log=True))
    os.environ['FOO'] = 'foo'
    os.environ['BAR'] = 'bar'
    assert set_fallbacks(spec, params) == set(['bar'])

    # Test fallback not found
    params = dict(bar='bar')
    assert set_fallbacks(spec, params) == set()

    # Test fallback for list type
    params = dict(foo=['foo1', 'foo2'])
    assert set_fallbacks(spec, params) == set()

    # Test fallback for dict type

# Generated at 2022-06-20 16:13:50.543764
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_VAR'] = 'Test'
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('TEST')
    assert env_fallback('ANSIBLE_TEST_VAR') == 'Test'



# Generated at 2022-06-20 16:14:00.921810
# Unit test for function remove_values
def test_remove_values():
    assert_equal(remove_values('string', ['s']), 'tring')
    assert_equal(remove_values('string', ['s', 't']), 'ring')
    assert_equal(remove_values('string', ['s', 'r']), 'ting')
    assert_equal(remove_values('string', ['str']), 'ing')
    assert_equal(remove_values('string', ['str', 'ing']), '')
    assert_equal(remove_values('string', ['str', 'in', 'g']), ' ')
    assert_equal(remove_values('string', ['str', 'ing', 'tr']), None)
    assert_equal(remove_values('string', [None]), 'string')
    assert_equal(remove_values('string', []), 'string')

# Generated at 2022-06-20 16:14:06.229798
# Unit test for function remove_values
def test_remove_values():
    """Unit test for function remove_values"""


# Generated at 2022-06-20 16:14:14.777640
# Unit test for function remove_values
def test_remove_values():
    no_log_strings = ['password', 'secret']
    test_list = ['#password', '#secret']
    assert remove_values(test_list, no_log_strings) == ['#********', '#********']
    test_set = {'#password', '#secret'}
    assert remove_values(test_set, no_log_strings) == {'#********', '#********'}
    test_tuple = ('#password', '#secret')
    assert remove_values(test_tuple, no_log_strings) == ('#********', '#********')
    test_dict = {'requested_url': 'http://www.ansible.com',
                 'body': '#secret'}

# Generated at 2022-06-20 16:14:25.614621
# Unit test for function remove_values
def test_remove_values():
    """Unit test for function remove_values"""

    list_test = [1, 2, ['test1', 'test2'], 'test3', {'test4': 'test5'}, ('test6', 'test7'), {'test8': ('test9', ('test10',))}]
    set_test = set(list_test)
    tuple_test = tuple(list_test)
    dict_test = {1: 'test1', 2: 'test2', 3: ['test3', 'test4', ('test5', 'test6')], 4: {'test7': 'test8'}, 5: ('test9', 'test10'), 'test11': {'test12': ('test13', 'test14')}}

    for test_input in [list_test, set_test, tuple_test, dict_test]:
        cleaned_output

# Generated at 2022-06-20 16:14:35.193156
# Unit test for function remove_values
def test_remove_values():
    from ansible.module_utils.six import b
    from ansible.module_utils._text import to_bytes

# Generated at 2022-06-20 16:14:45.143587
# Unit test for function sanitize_keys
def test_sanitize_keys():
    """Unit test for function sanitize_keys."""
    s = 'this should be redacted'

    # Test item removal where the key is the value to remove and it is a hash (dict) key.
    value = {'foo': s, 'bar': 'baz'}
    assert sanitize_keys(value, no_log_strings=set([s])) == {'foo': 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER', 'bar': 'baz'}

    # Test item removal where the key is the value to remove and it is a list index.
    value = [s, 'baz']
    assert sanitize_keys(value, no_log_strings=set([s])) == ['VALUE_SPECIFIED_IN_NO_LOG_PARAMETER', 'baz']

    # Test item removal