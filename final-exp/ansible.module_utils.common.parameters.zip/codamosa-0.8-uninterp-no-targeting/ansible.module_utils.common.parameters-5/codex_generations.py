

# Generated at 2022-06-20 16:05:22.340401
# Unit test for function env_fallback
def test_env_fallback():
    with mock.patch('os.environ', {'A': 'a'}):
        assert env_fallback('A') == 'a'
        with pytest.raises(AnsibleFallbackNotFound, message="The ``env_fallback`` function should raise when fallback not found."):
            env_fallback('B')


# Generated at 2022-06-20 16:05:28.256458
# Unit test for function remove_values

# Generated at 2022-06-20 16:05:35.019176
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        param1=dict(
            type='str',
            no_log=True,
            fallback=(env_fallback, 'PARAM1')
        )
    )

    parameters = dict()
    set_fallbacks(argument_spec, parameters)
    assert 'param1' not in parameters

    os.environ['PARAM1'] = 'foo'
    set_fallbacks(argument_spec, parameters)
    assert parameters['param1'] == 'foo'



# Generated at 2022-06-20 16:05:40.159088
# Unit test for function sanitize_keys
def test_sanitize_keys():
    class Foo(object):
        def __init__(self, value):
            self.value = value

    data = {
        'foo': 'bar',
        'baz': [1, {'qux': [Foo('quux'), 'quuz']}],
        'corge': 'grault',
        'garply': {'waldo': {'fred': 'baz'}},
        '_ansible_no_log': True,
        'empty': {},
        'list': [],
        'set': set(),
        'empty_list': [],
        'empty_set': set(),
        'empty_dict': {},
        'empty_dict_list': [{}],
        'empty_dict_set': set([{}]),
    }


# Generated at 2022-06-20 16:05:50.644654
# Unit test for function set_fallbacks
def test_set_fallbacks():

    def _test_set_fallbacks(fallback, value):
        assert set_fallbacks({"mock": {"fallback": fallback}}, {"mock": value}) == set()

    _test_set_fallbacks(('env', 'MOCK_ONE', 'MOCK_TWO'), None)
    _test_set_fallbacks(('env', 'MOCK_ONE', 'MOCK_TWO'), "test")
    _test_set_fallbacks((env_fallback, 'MOCK_ONE', 'MOCK_TWO'), None)
    _test_set_fallbacks((env_fallback, 'MOCK_ONE', 'MOCK_TWO'), "test")
    _test_set_fallbacks((env_fallback, 'MOCK_ONE', 'MOCK_TWO'), ["test"])



# Generated at 2022-06-20 16:06:01.324559
# Unit test for function remove_values
def test_remove_values():

    assert remove_values(42, ['hello']) == 42
    assert remove_values('hello', ['hello']) == '<value redacted>'
    assert remove_values('hello', []) == 'hello'
    assert remove_values('hello', ['hel', 'llo']) == '<value redacted>'

    assert remove_values(['hello'], ['hello']) == ['<value redacted>']
    assert remove_values(('hello',), ['hello']) == ('<value redacted>',)
    assert remove_values(set(['hello']), ['hello']) == {'<value redacted>'}
    assert remove_values({'hello': 'world'}, ['hello']) == {'<value redacted>': 'world'}

# Generated at 2022-06-20 16:06:12.902436
# Unit test for function remove_values
def test_remove_values():
    assert remove_values(0, ['0']) == 0
    assert remove_values('', ['0']) == ''
    assert remove_values('foo', ['0']) == 'foo'
    assert remove_values('foo', ['foo']) == '***'
    assert remove_values('foo', ['foo', 'baz']) == '***'
    assert remove_values('foo', ['foo', 'bar', 'baz']) == '***'

    assert remove_values({'foo': 'bar'}, ['foo']) == {'***': 'bar'}
    assert remove_values({'foo': 'bar'}, ['foo', 'baz']) == {'***': 'bar'}
    assert remove_values({'foo': 'bar'}, ['foo', 'bar', 'baz']) == {'***': '***'}

# Generated at 2022-06-20 16:06:22.540217
# Unit test for function set_fallbacks

# Generated at 2022-06-20 16:06:35.619524
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'name': {'type': 'str',
                 'required': True},
        'state': {'type': 'str',
                  'default': 'present',
                  'choices': ['present', 'absent']},
    }

    parameters = {
        'name': 'foo',
    }

    no_log_values = set_fallbacks(argument_spec, parameters)
    assert no_log_values == set()
    assert parameters['state'] == 'present'

    parameters = {}

    set_fallbacks(argument_spec, parameters)
    assert 'state' not in parameters


# Generated at 2022-06-20 16:06:40.387295
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['var'] = 'value'
    assert env_fallback('var') == 'value'
    os.environ.pop('var')
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('not_var')



# Generated at 2022-06-20 16:07:11.661598
# Unit test for function remove_values
def test_remove_values():
    assert remove_values('password', ['password']) == 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'
    assert remove_values('PASSWORD', ['password']) == 'PASSWORD'
    assert remove_values('pasSword', ['password']) == 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'
    assert remove_values('password', [u'pass\u2075\u2070rd']) == 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'
    assert remove_values('password', ['pass', 'word']) == 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'
    assert remove_values('password', ['assword']) == 'password'
    assert remove_values('password', [u'assword']) == 'password'
   

# Generated at 2022-06-20 16:07:19.457577
# Unit test for function remove_values
def test_remove_values():

    # basic string example
    assert remove_values('password', ['password']) == 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'
    # other container example
    assert remove_values({'password': 'password'}, ['password']) == {'password': 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'}



# Generated at 2022-06-20 16:07:27.238937
# Unit test for function remove_values
def test_remove_values():
    assert remove_values({"name": "private_data", "public_data": "data"}, ["private_data"]) == {"name": "********", "public_data": "data"}
    assert remove_values(["private_data", "public_data"], ["private_data"]) == ["********", "public_data"]
    assert remove_values({"key1": "private_data", "key2": ["private_data", "public_data"]}, ["private_data"]) == {"key1": "********", "key2": ["********", "public_data"]}
    assert remove_values({"key1": "private_data", "key2": {"key21": "private_data"}}, ["private_data"]) == {"key1": "********", "key2": {"key21": "********"}}

# Generated at 2022-06-20 16:07:31.347634
# Unit test for function env_fallback
def test_env_fallback():
    os.environ.update({'ANSIBLE_TEST_ENV_FALLBACK': 'test'})
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('ANSIBLE_TEST_ENV_FALLBACK1')



# Generated at 2022-06-20 16:07:39.023070
# Unit test for function sanitize_keys
def test_sanitize_keys():
    def iterate_keys(mapping):
        for key in mapping.keys():
            if isinstance(key, Mapping):
                yield from iterate_keys(key)
            else:
                yield key

    assert 'error' not in iterate_keys(sanitize_keys(dict(module_defaults=dict(error='Default value')), no_log_strings=set()))
    assert 'error' not in iterate_keys(sanitize_keys(dict(module_defaults=dict(error='Default value')), no_log_strings=set(['Default value'])))



# Generated at 2022-06-20 16:07:50.236315
# Unit test for function remove_values
def test_remove_values():

    # List of values to mask
    no_log_strings = ["password", "passphrase", "private"]

    # Dictionary with value to be masked as part of keys, values
    o1 = {"a_password": "foo", "passphrase": {"a": 1, "b": 1, "c": 1}, "d": "password", "e": "passphrase"}
    # Dictionary with value to be masked as part of keys, values; nested dictionary
    o2 = {"a_password": "foo", "passphrase": {"a": 1, "b": 1, "c": {"password": "foo"}}, "d": "password", "e": "passphrase"}
    # Dictionary with value to be masked as part of keys; nested dictionary

# Generated at 2022-06-20 16:08:01.664766
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Empty values, should not set empty values
    parameters = {}
    argument_spec = {
        'foo': {'type': 'str'},
        'bar': {'type': 'str'},
        'baz': {'type': 'str'},
        'qux': {'type': 'str'},
    }
    set_fallbacks(argument_spec, parameters)
    assert parameters == {}, set_fallbacks(argument_spec, parameters)

    # Set 'foo' through fallbacks, 'bar' should not be used
    parameters = {}
    argument_spec['foo']['fallback'] = (env_fallback, 'FOO')
    argument_spec['bar']['fallback'] = (env_fallback, 'BAR')
    set_fallbacks(argument_spec, parameters)

# Generated at 2022-06-20 16:08:09.070261
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'name': {'type': 'str', 'required': True},
        'state': {'type': 'str', 'required': True, 'fallback': (env_fallback, ('my_state_env',))},
        'password': {'type': 'str', 'no_log': True, 'required': True},
        'ssh_key_bits': {'type': 'int', 'default': 2048, 'fallback': (env_fallback, ('SSH_KEY_BITS',))},
        'ssh_key_file': {'type': 'str', 'required': True,
                         'fallback': (my_fallback_function, ('my_param_name',), {'special_env': 'special_value'})}
    }

# Generated at 2022-06-20 16:08:18.273259
# Unit test for function set_fallbacks
def test_set_fallbacks():

    params = {
        'ansible_password': 'test',
    }

    spec = {
        'ansible_password': {'type': 'str', 'no_log': True},
        'ansible_ssh_user': {'type': 'str', 'fallback': (env_fallback, ['ANSIBLE_REMOTE_USER'], {})},
        'ansible_user': {'type': 'str', 'fallback': (env_fallback, ['ANSIBLE_USER'], )},
        'ansible_ssh_host': {'type': 'str', 'fallback': (env_fallback, ['ANSIBLE_HOST'], )},
    }

    no_log_values = set()
    no_log_values = set_fallbacks(spec, params)
    assert len(no_log_values) == 2

# Generated at 2022-06-20 16:08:28.465260
# Unit test for function sanitize_keys
def test_sanitize_keys():
    """Unit test for function sanitize_keys:
    """
    data = {u'key1': u'value1', u'key2': u'value2', u'key3': u'value3'}
    data_elements = list(data.items())
    no_log_strings = [u'value1', u'value2']
    ignore_keys = set()
    expected_results = {u'k1': u'value1', u'k2': u'value2', u'key3': u'value3'}
    results = sanitize_keys(data, no_log_strings, ignore_keys)
    assert results == expected_results

# Generated at 2022-06-20 16:08:59.885442
# Unit test for function remove_values
def test_remove_values():
    # Check regular strings
    no_log_strings = ['TOKENID', 'TOKENKEY']
    s = 'This is a value with a TOKENID in it'
    assert remove_values(s, no_log_strings) == 'This is a value with a <value omitted> in it'

    # Check unicode strings
    s = u'This is a unicode value with a TOKENID in it'
    assert remove_values(s, no_log_strings) == u'This is a unicode value with a <value omitted> in it'

    # Check lists

# Generated at 2022-06-20 16:09:07.569520
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'name': {'type': 'str', 'fallback': (env_fallback, 'OS_USERNAME')},
    }
    module_args = {'name': 'User1'}
    parameters = set_fallbacks(argument_spec, module_args)
    assert parameters == set()
    os.environ['OS_USERNAME'] = 'env_user'
    parameters = set_fallbacks(argument_spec, {})
    assert parameters == set()
    parameters = set_fallbacks(argument_spec, module_args)
    assert parameters == set()



# Generated at 2022-06-20 16:09:13.452944
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert set_fallbacks({'my_var': {'fallback': (env_fallback, 'MY_VAR')}}, {}) == set()
    parameters = {}
    assert set_fallbacks({'my_var': {'fallback': (env_fallback, 'MY_VAR')}}, parameters) == set()
    os.environ['MY_VAR'] = "HELLO"
    assert set_fallbacks({'my_var': {'fallback': (env_fallback, 'MY_VAR')}}, parameters) == set()
    assert parameters.get('my_var') == "HELLO"
    assert set_fallbacks({'my_var': {'fallback': (env_fallback, 'MY_VAR'), 'no_log': True}}, parameters) == set(['HELLO'])

# Generated at 2022-06-20 16:09:23.743821
# Unit test for function sanitize_keys
def test_sanitize_keys():
  obj = {
    'a': {
      'this_field': 'should_not_be_sanitized',
      'this_field_should_be_sanitized': 'should_be_sanitized',
      'b': {
        'this_field_should_be_sanitized_too': 'should_be_sanitized'
      },
      'c': [
        'this_field_should_also_be_sanitized',
      ],
    },
    'redacted': 'redacted',
    'redacted_too': 'redacted',
  }
  no_log_strings = {'redacted'}
  ignore_keys = frozenset()
  field_to_check = obj['a']['b'].keys()[0]

# Generated at 2022-06-20 16:09:34.920558
# Unit test for function sanitize_keys
def test_sanitize_keys():

    obj = {
        "a": "b",
        "password": "123456",
        "c": {
            "d": {
                "e": {
                    "password": "234567"
                }
            },
            "f": [
                {
                    "g": {
                        "h": "password"
                    }
                },
                {
                    "i": {
                        "password": "345678"
                    }
                }
            ]
        }
    }


# Generated at 2022-06-20 16:09:44.232946
# Unit test for function set_fallbacks
def test_set_fallbacks():

    def simple_fallback(n):
        return n

    def complex_fallback(*args, **kwargs):
        return kwargs['n']


# Generated at 2022-06-20 16:09:56.562687
# Unit test for function sanitize_keys
def test_sanitize_keys():
    input_val = [
        {
            '_ansible_verbose_override': True,
            'foo': {
                'bar': {
                    'baz': 'password1',
                    'passwd': 'password2',
                }
            },
            'password3': 'password3',
            'ansible_ssh_pass': 'password4',
            'ansible_become_pass': 'password5',
            'ansible_winrm_pass': 'password6',
        },
    ]

# Generated at 2022-06-20 16:10:00.992590
# Unit test for function remove_values
def test_remove_values():
    for no_log_strings in (
            (None, ),
            (1, ),
            ([], ),
            ({}, ),
            ('', ),
            ('a', ),
            (['a'], ),
            ({'a': None}, ),
    ):
        assert remove_values(None, no_log_strings) is None
        assert remove_values(1, no_log_strings) == 1
        assert remove_values([], no_log_strings) == []
        assert remove_values({}, no_log_strings) == {}
        assert remove_values('', no_log_strings) == ''
        assert remove_values('a', no_log_strings) == 'a'
        assert remove_values(['a'], no_log_strings) == ['a']
        assert remove_values('a', no_log_strings)

# Generated at 2022-06-20 16:10:06.337898
# Unit test for function sanitize_keys
def test_sanitize_keys():
    info = dict()
    info['type'] = 'password'
    info['value'] = 'abc'
    info['something'] = '123'
    info['type_abc'] = 'something'
    info['key_value'] = dict()
    info['some_list'] = [{}, {'type': 'value'}]

    new_info = sanitize_keys(info, ['password'])
    assert new_info['type'] == 'value'



# Generated at 2022-06-20 16:10:08.944008
# Unit test for function env_fallback
def test_env_fallback():
    # No env variable
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('ANSIBLE_TEST_VAR', 'ANSIBLE_TEST_VAR2')

    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('ANSIBLE_TEST_VAR2')

    # Has env variable
    assert env_fallback('ANSIBLE_TEST_VAR') == 'TEST'

# Generated at 2022-06-20 16:10:38.997375
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argspec = dict(
        foo=dict(fallback=(env_fallback, "FOO_PATH")),
        bar=dict(fallback=(env_fallback, "BAR_PATH")),
        baz=dict(fallback=(env_fallback, "BAZ_PATH")),
        qux=dict(fallback=(env_fallback, "QUX_PATH"))
    )
    os.environ["FOO_PATH"] = "/foo/path"
    os.environ["BAR_PATH"] = "/bar/path"
    parameters = dict(foo=None, bar=None, baz=None)
    result_args = dict(foo="/foo/path", bar="/bar/path", baz=None)
    assert (set_fallbacks(argspec, parameters) == set())

# Generated at 2022-06-20 16:10:46.520171
# Unit test for function remove_values
def test_remove_values():
    from ansible.parsing.yaml.objects import AnsibleUnicode

# Generated at 2022-06-20 16:10:52.544729
# Unit test for function remove_values
def test_remove_values():
    assert(remove_values('ansible', ['ansible']) == '****************')
    assert(remove_values({'key': 'ansible'}, ['ansible']) == {'key': '****************'})
    assert(remove_values({'ansible': 'user'}, ['ansible']) == {'****************': 'user'})
    assert(remove_values({'key': 'value', 'ansible': 'user'}, ['ansible']) == {'key': 'value', '****************': 'user'})
    assert(remove_values([1, 2], ['2']) == [1, '****************'])

# Generated at 2022-06-20 16:10:58.897499
# Unit test for function remove_values
def test_remove_values():
    no_log_strings = ["ansible_winrm_server_cert_validation"]
    old_value = "ansible_winrm_server_cert_validation=ignore"
    new_value = remove_values(old_value, no_log_strings)
    assert new_value == '**"value stripped"**'



# Generated at 2022-06-20 16:11:02.538370
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['test_env_fallback'] = 'foo'
    assert env_fallback('test_env_fallback') == 'foo'
    if 'test_env_fallback' in os.environ:
        del os.environ['test_env_fallback']
    try:
        env_fallback('env_fallback')
        assert False, 'AnsibleFallbackNotFound not raised'
    except AnsibleFallbackNotFound:
        pass



# Generated at 2022-06-20 16:11:10.885556
# Unit test for function remove_values
def test_remove_values():
    class TestObj(object):
        def __init__(self, value):
            self.value = value
        def __str__(self):
            return str(self.value)

    assert 'Test' == remove_values('Test', ('No', 'For', 'Log'))
    assert 'Test' == remove_values(TestObj('Test'), ('No', 'For', 'Log'))

    assert {'One': 'OneValue', 'Two': 'TwoValue'} == remove_values({'One': 'OneValue', 'Two': 'TwoValue'}, ('No', 'For', 'Log'))

# Generated at 2022-06-20 16:11:20.867823
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # We'll have to test this with a full module example.
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six.moves import xrange


# Generated at 2022-06-20 16:11:32.236282
# Unit test for function remove_values
def test_remove_values():
    assert remove_values('foo', []) == 'foo'
    assert remove_values(None, []) == None
    assert remove_values(42, []) == 42
    assert remove_values(['foo'], []) == ['foo']
    assert remove_values(('foo',), []) == ('foo',)
    assert remove_values({'foo': 'bar'}, []) == {'foo': 'bar'}
    assert remove_values(set(['foo']), []) == set(['foo'])
    assert remove_values(['foo'], ['foo']) == ['***']
    assert remove_values(('foo',), ['foo']) == ('***',)
    assert remove_values({'foo': 'bar'}, ['bar']) == {'foo': '***'}

# Generated at 2022-06-20 16:11:36.189923
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['TEST_VAR'] = '1'
    assert env_fallback('TEST_VAR') == '1'
    assert env_fallback('NOT_THERE') == 1
    return 'test env_fallback ok'



# Generated at 2022-06-20 16:11:40.035543
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['MY_TEST_ENV'] = "test_value"
    assert env_fallback('MY_TEST_ENV') == 'test_value'
    assert env_fallback('NOT_EXIST') is missing


# Generated at 2022-06-20 16:12:12.821222
# Unit test for function sanitize_keys
def test_sanitize_keys():
    # Test non-container types
    assert isinstance(sanitize_keys(None, []), type(None))
    assert isinstance(sanitize_keys(1, []), int)
    assert isinstance(sanitize_keys(1.1, []), float)
    assert isinstance(sanitize_keys('', []), text_type)
    assert isinstance(sanitize_keys(b'', []), binary_type)
    assert isinstance(sanitize_keys(set(), []), set)
    assert isinstance(sanitize_keys(frozenset(), []), frozenset)

    # Test values are passed through
    assert '' == sanitize_keys('', [])
    assert u'abc' == sanitize_keys(u'abc', [])
    assert 'abc' == sanitize_

# Generated at 2022-06-20 16:12:24.858683
# Unit test for function remove_values

# Generated at 2022-06-20 16:12:36.523776
# Unit test for function remove_values
def test_remove_values():
    # Some of the test cases in this function have been found by fuzzing.
    # Any test case that fails should be checked for security implications.
    # See https://github.com/ansible/ansible/issues/38342

    # Helper function to test function remove_values
    # checks that the value was transformed as expected
    def check_result(value, new_value, expected):
        # The expected result should not have been modified by the function
        if expected != new_value:
            raise AssertionError("Result does not match expected output: %s != %s" % (new_value, expected))

        # The output should be the same as the expected result
        # if the input did not contain any of the no_log_strings

# Generated at 2022-06-20 16:12:44.510391
# Unit test for function env_fallback
def test_env_fallback():
    with patch('os.environ', {'FOO': 'bar'}):
        assert env_fallback('FOO') == 'bar'
    with patch('os.environ', {}):
        with pytest.raises(AnsibleFallbackNotFound) as exc:
            env_fallback('FOO')
        assert 'The environment variable FOO is not set.' in str(exc)
    with patch('os.environ', {}):
        with pytest.raises(AnsibleFallbackNotFound) as exc:
            env_fallback('FOO', 'BAR')
        assert 'The environment variables BAR, FOO are not set.' in str(exc)



# Generated at 2022-06-20 16:12:53.610710
# Unit test for function remove_values
def test_remove_values():
    '''Test the two conditionals encountered in remove_values()'''
    # Test the function with no_log_string=''
    assert 'a' == _remove_values_conditions('a', '', None)
    assert 'a,b' == _remove_values_conditions('a,b', '', None)
    assert 'a, b' == _remove_values_conditions('a, b', '', None)
    assert '******' == _remove_values_conditions('a, b', 'a, b', None)
    # Test the function with no_log_string='a'
    assert 'a' == _remove_values_conditions('a', 'a', None)
    assert 'a' == _remove_values_conditions('a', 'a', None)
    assert 'a' == _remove_values_

# Generated at 2022-06-20 16:13:04.035252
# Unit test for function set_fallbacks
def test_set_fallbacks():
    def fake_fallback(*args, **kwargs):
        if 'USER' in os.environ:
            return os.environ['USER']
        raise AnsibleFallbackNotFound

    argument_spec = {'password': {'type': 'str', 'fallback': (fake_fallback, 'BOB')},
                     'not_present': {'type': 'str', 'fallback': (env_fallback, 'FOO')}}
    parameters = {'password': 's3cr3t'}
    assert set_fallbacks(argument_spec, parameters) == set()
    parameters = {}
    assert set_fallbacks(argument_spec, parameters) == set()
    assert parameters == {'password': 's3cr3t', 'not_present': 'BOB'}



# Generated at 2022-06-20 16:13:09.108859
# Unit test for function remove_values
def test_remove_values():
    #pylint: disable=invalid-name
    def check_remove_values(value, no_log_strings, expected):
        actual = remove_values(value, no_log_strings)
        if expected != actual:
            raise AssertionError('Exp: %s\nAct: %s' % (expected, actual))

    # no_log_strings is an iterable, so we can't just use a string itself, but
    # we can use tuples of strings, ...
    check_remove_values('the', ('the',), '**')
    check_remove_values('the', ('the', 'other'), '**')
    check_remove_values('the', ('other', 'other2'), 'the')

    # ... or lists, ...
    check_remove_values('the', ['the'], '**')
    check

# Generated at 2022-06-20 16:13:16.284693
# Unit test for function remove_values
def test_remove_values():
    import ansible.module_utils.common.removed
    import ansible.module_utils.common.clean
    import ansible.module_utils.facts.system.smartos
    import ansible.module_utils.network.f5.bigip
    import ansible.module_utils.network.f5.common
    import ansible.module_utils.network.f5.icontrol
    import ansible.module_utils.network.f5.icontrol_rest
    import ansible.module_utils.network.f5.common
    import ansible.module_utils.network.f5.common.mixins
    import ansible.module_utils.network.f5.common.name_collection
    import ansible.module_utils.network.f5.common.validators

# Generated at 2022-06-20 16:13:25.664580
# Unit test for function remove_values
def test_remove_values():
    value1 = 'abc123_no_log'
    value2 = 'abc123_no_log_that_is_longer_than_twenty_characters'
    value3 = 'abc123_no_log_that_is_longer_than_twenty_characters_12345678901234'
    value4 = 'abc123_no_log_that_is_longer_than_twenty_characters_123456789012345'
    value5 = 'abc123_no_log_that_is_longer_than_twenty_characters_1234567890123456'
    value6 = 'abc123_no_log_that_is_longer_than_twenty_characters_12345678901234567'

# Generated at 2022-06-20 16:13:34.135374
# Unit test for function sanitize_keys
def test_sanitize_keys():
    input_ = {'foo': 'somevalue',
              'bar': 'somevalue',
              'foo_with_no_log': 'somevalue'}
    reference = {'foo': 'somevalue',
                 'bar': 'somevalue',
                 'sanitized_0_': 'somevalue'}

    expected = [('sanitized_0_', 'somevalue')]
    no_log_strings = ["somevalue"]
    ignore_keys = []

    actual = {}
    actual_removals = []

    def _sanitize_mock(obj, no_log_strings, ignore_keys, deferred_removals):
        actual[obj[0]] = obj[1]
        return obj[1]


# Generated at 2022-06-20 16:14:04.645016
# Unit test for function sanitize_keys
def test_sanitize_keys():
    from ansible.errors import AnsibleParserError
    from ansible.module_utils._text import to_native
    from ansible.module_utils.common.validation import (
        check_mutually_exclusive,
        check_required_together,
        check_required_one_of,
        check_required_arguments,
        check_argument_types,
        check_argument_values,
        check_deprecated_terms,
        check_aliases,
    )
    from ansible.module_utils.six import string_types
    import json
    import pytest

    def _read_json_file(file_name):
        with open(file_name) as f:
            return json.load(f)


# Generated at 2022-06-20 16:14:14.297907
# Unit test for function remove_values

# Generated at 2022-06-20 16:14:25.514958
# Unit test for function remove_values
def test_remove_values():
    # Test Some container object.
    assert remove_values({'a': 'b', 'c': 'd'}, set()) == {'a': 'b', 'c': 'd'}
    assert remove_values({'a': 'b', 'c': 'd'}, {'b'} ) == {'a': '', 'c': 'd'}
    assert remove_values({'a': 'a', 'c': 'd'}, {'a'} ) == {'a': '', 'c': 'd'}

    # Test Sequence object.
    assert remove_values(('a', 'b'), set()) == {'a', 'b'}
    assert remove_values(('a', 'a'), {'a'} ) == set()
    assert remove_values(('a', 'b', 'b'), {'b'} )

# Generated at 2022-06-20 16:14:35.130793
# Unit test for function sanitize_keys
def test_sanitize_keys():
    from collections import OrderedDict
    from copy import deepcopy
    from collections import namedtuple

# Generated at 2022-06-20 16:14:42.696289
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys({"foo": "bar", "acme.example.com": "password"}, ["password"], ignore_keys=["acme.example.com"]) == {"foo": "bar", "acme.example.com": "password"}
    assert sanitize_keys({"foo": "bar", "acme.example.com": "password", "password": "password"}, ["password"], ignore_keys=["acme.example.com"]) == {"foo": "bar", "acme.example.com": "password", "password": "password"}



# Generated at 2022-06-20 16:14:47.783977
# Unit test for function remove_values
def test_remove_values():
    assert remove_values('hello', []) == 'hello'
    assert remove_values('hello', ['hello']) == 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'
    assert remove_values('heXXllo', ['XX']) == 'heVALUE_SPECIFIED_IN_NO_LOG_PARAMETERllo'
    assert remove_values('heXXo', ['XX']) == 'heVALUE_SPECIFIED_IN_NO_LOG_PARAMETERo'
    assert remove_values('heXXo', ['XX', 'o']) == 'heVALUE_SPECIFIED_IN_NO_LOG_PARAMETERVALUE_SPECIFIED_IN_NO_LOG_PARAMETER'