

# Generated at 2022-06-20 16:06:02.624899
# Unit test for function set_fallbacks
def test_set_fallbacks():
    """Test set_fallbacks function"""


# Generated at 2022-06-20 16:06:13.873140
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['MY_ENV_VAR'] = "test"
    os.environ['MY_ENV_VAR_2'] = "test_2"
    assert env_fallback('MY_ENV_VAR', 'MY_ENV_VAR_2') == 'test'
    os.environ['MY_ENV_VAR_3'] = "test_3"
    assert env_fallback('MY_ENV_VAR_4', 'MY_ENV_VAR_3', 'MY_ENV_VAR_2') == 'test_3'
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('MY_ENV_VAR_4')



# Generated at 2022-06-20 16:06:18.464094
# Unit test for function set_fallbacks
def test_set_fallbacks():

    # Test that multiple fallbacks are iterated until a non-None fallback is found
    argument_spec = dict(
        param1=dict(type='str', required=True, fallback=(env_fallback, 'value_not_set', 'value_not_set_either')),
        param2=dict(type='str', required=True, fallback=(env_fallback, 'missing_env_variable')),
        param3=dict(type='str'),
    )
    params = {}
    os.environ['missing_env_variable'] = 'value_found_in_env'
    no_log_values = set_fallbacks(argument_spec, params)
    assert params == {'param1': 'value_not_set', 'param2': 'value_found_in_env'}

    # Test that fallback values are

# Generated at 2022-06-20 16:06:30.679320
# Unit test for function remove_values
def test_remove_values():
    test_data = dict(
        string="this is a string",
        list_of_strings=["one", "two", "three"],
        list_of_lists=[["one", "two"], ["three", "four"]],
        dict=dict(
            dict_of_strings=dict(
                dict_of_strings2=dict(
                    one="test",
                    two="test",
                    three="test",
                )
            ),
            list_of_dicts=[
                dict(
                    one="test",
                    two="test",
                    three="test",
                ),
                dict(
                    one="test",
                    two="test",
                    three="test",
                ),
            ],
        )
    )

    test_output = remove_values(test_data, ["test"])
    assert test_output == dict

# Generated at 2022-06-20 16:06:41.942026
# Unit test for function sanitize_keys
def test_sanitize_keys():
    my_data = {
        'a': {'b': 'b_value', 'c': 'c_value'},
        'b': {'a': 'a_value', 'c': 'c_value'},
        'c': {'a': 'a_value', 'b': 'b_value'}
    }

    assert my_data == sanitize_keys(my_data, {'c_value'}, {'c'})

    class Foo(dict):
        pass

    my_data = {
        'a': {'b': 'b_value', 'c': 'c_value'},
        'b': {'a': 'a_value', 'c': 'c_value'},
        'c': Foo({'a': 'a_value', 'b': 'b_value'})
    }

   

# Generated at 2022-06-20 16:06:50.094559
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys(dict(a='b', c='d'), frozenset()) == dict(a='b', c='d')

# Generated at 2022-06-20 16:06:59.134749
# Unit test for function remove_values
def test_remove_values():
    no_log_strings = ['password', 'ansible_password']

    assert remove_values('password', no_log_strings) == 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'
    assert remove_values(u'password', no_log_strings) == u'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'
    assert remove_values(b'password', no_log_strings) == b'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'
    assert remove_values('password', no_log_strings, 'security') == 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'
    assert remove_values('spam', no_log_strings) == 'spam'

    assert remove_values(5, no_log_strings) == 5
    assert remove

# Generated at 2022-06-20 16:07:05.919871
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'param1': {'type': 'str', 'fallback': (env_fallback, 'TEST_ENV')},
        'param2': {'type': 'bool', 'fallback': (env_fallback, 'TEST_ENV')}
    }
    parameters = {'param1': 'value1'}
    os.environ['TEST_ENV'] = 'test'
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert set(no_log_values) == set()
    assert parameters['param1'] == 'value1'
    assert parameters['param2'] == 'test'
    del os.environ['TEST_ENV']



# Generated at 2022-06-20 16:07:14.042740
# Unit test for function env_fallback
def test_env_fallback():
    def test_base(expected, *args):
        if args:
            for arg in args:
                os.environ[arg] = arg
        try:
            result = env_fallback(*args)
            assert expected == result
        finally:
            if args:
                for arg in args:
                    del os.environ[arg]

    test_base('arg1')
    test_base('arg2', 'arg2')
    test_base('arg1', 'arg1')
    test_base('arg1', 'arg1', 'arg2')


# Generated at 2022-06-20 16:07:19.106656
# Unit test for function remove_values
def test_remove_values():
    data = {
        'header1': 'value1',
        'header2': 'value2',
    }

    no_log_strings = {'value1'}
    assert remove_values(data, no_log_strings) == {'header1': 'VALUE_CONCEALED', 'header2': 'value2'}



# Generated at 2022-06-20 16:07:56.295637
# Unit test for function sanitize_keys
def test_sanitize_keys():
    import pytest

    def _sanitize_keys(obj, no_log_strings, ignore_keys=frozenset()):
        return sanitize_keys(obj, no_log_strings, ignore_keys)

    def _test_no_change(test_data):
        assert _sanitize_keys(test_data, set()) == test_data

    def _test_sanitize_keys(test_data, no_log_strings, expected_data):
        assert _sanitize_keys(test_data, no_log_strings) == expected_data

    # Test that an empty no_log_strings set does nothing
    _test_no_change('foo')
    _test_no_change(123)
    _test_no_change(True)
    _test_no_change(False)
    _

# Generated at 2022-06-20 16:07:57.557652
# Unit test for function env_fallback
def test_env_fallback():
    from ansible.module_utils.validate import env_fallback
    assert env_fallback() is not None

# Helper function to turn binary keys into unicode keys

# Generated at 2022-06-20 16:08:07.390185
# Unit test for function remove_values
def test_remove_values():
    test_no_log_strings = [
        'foo',
        'bar',
    ]

    assert remove_values('foo', test_no_log_strings) == CENSORED_RESULT

    test_container1 = [
        'foo',
        'bar',
        'baz',
    ]
    assert remove_values(test_container1, test_no_log_strings) == [CENSORED_RESULT, CENSORED_RESULT, 'baz']

    test_container2 = {
        'foo': 'bar',
        'baz': 'qux',
        'quux': 'quuz',
    }

# Generated at 2022-06-20 16:08:14.307722
# Unit test for function remove_values
def test_remove_values():
    '''
    Test function remove_values
    '''

# Generated at 2022-06-20 16:08:21.608354
# Unit test for function sanitize_keys
def test_sanitize_keys():
    no_log_strings = ['key_with_value']
    ignore_keys = ['ok_key']
    obj = dict(ignore_key='foo',
               ok_key = 'bar',
               key_with_value = 'baz')

# Generated at 2022-06-20 16:08:31.789665
# Unit test for function sanitize_keys
def test_sanitize_keys():
    data = {
        'a': {
            'b': 'password_revealed',
            'password': 'password_removed',
            'secret': {'nested': 'password_removed', 'nested_revealed': 'password_revealed'}
        },
        'c': [
            {
                'password': 'password_removed',
                'secret': {'nested': 'password_removed', 'nested_revealed': 'password_revealed'}
            }
        ]
    }

    data = sanitize_keys(data, ['password'])

# Generated at 2022-06-20 16:08:35.529027
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('TEST_ONE') is not None
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('TEST_TWO')



# Generated at 2022-06-20 16:08:36.821855
# Unit test for function env_fallback
def test_env_fallback():
    raise SkipTest("FIXME: no test")

# Generated at 2022-06-20 16:08:46.300729
# Unit test for function sanitize_keys
def test_sanitize_keys():
    # Test no change
    test_obj = {'one': 'two', 'three': 'four'}
    new_obj = sanitize_keys(test_obj, set())
    assert test_obj == new_obj

    # Test with string keys
    test_obj = {'one': 'two', 'three': 'four'}
    new_obj = sanitize_keys(test_obj, set(('thr',)))
    assert test_obj != new_obj
    assert new_obj == {'one': 'two', '*****': 'four'}

    # Test with nested mapping
    test_obj = {'one': 'two', 'three': {'four': 'five', 'six': 'seven'}}
    new_obj = sanitize_keys(test_obj, set(('thr', 'six')))
   

# Generated at 2022-06-20 16:08:51.629859
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        foo=dict(default='bar'),
        baz=dict(fallback=('my_fallback',), default='qux'),
        qux=dict(fallback=('env', 'ANSIBLE_TEST_QUX')),
        corge=dict(fallback=(env_fallback, 'ANSIBLE_TEST_CORGE')),
        grault=dict(fallback=(env_fallback, 'ANSIBLE_TEST_GRAULT', dict(key='val'))),
        garply=dict(fallback=(env_fallback, 'ANSIBLE_TEST_GARPLY', dict(key='val'))),
    )
    os.environ['ANSIBLE_TEST_QUX'] = 'wibble'

# Generated at 2022-06-20 16:09:15.884369
# Unit test for function set_fallbacks
def test_set_fallbacks():
    parameters = {}

    argument_spec = {
        "param1": {
            "required": True,
            "type": "str",
            "fallback": (env_fallback, ['ANSIBLE_PARAM1']),
        },
        "param2": {
            "required": True,
            "type": "str",
            "fallback": (env_fallback, ['ANSIBLE_PARAM2']),
        },
    }

    os.environ["ANSIBLE_PARAM1"] = "foo"
    os.environ["ANSIBLE_PARAM2"] = "bar"

    no_log_values = set_fallbacks(argument_spec, parameters)

    assert parameters["param1"] == "foo"
    assert parameters["param2"] == "bar"
    assert len(no_log_values) == 0


# Generated at 2022-06-20 16:09:26.897744
# Unit test for function remove_values
def test_remove_values():
    test_data = """
        {
            "default": {
                "password": "hello world 1",
                "ssh_host_rsa_key": "hello world 2",
                "private_key": "hello world 3",
                "authorize_password": "hello world 4",
                "remote_user_password": "hello world 5"
            },
            "another_dict": {
                "remote_user_password": "hello world 6"
            },
            "list": [
                {
                    "password": "hello world 7",
                    "remote_user_password": "hello world 8"
                }
            ]
        }
    """
    no_log_strings = ["hello world"]
    test_data = json.loads(test_data)

# Generated at 2022-06-20 16:09:36.391942
# Unit test for function remove_values
def test_remove_values():
    assert {'hello': 'world'} == remove_values({'hello': 'world'}, ['super_secret_value'])
    assert {'hello': '*****'} == remove_values({'hello': 'secret_value'}, ['secret_value'])
    assert {'hello': {'hello': 'world', 'secret': '*****'}} == remove_values({'hello': {'hello': 'world', 'secret': 'secret_value'}}, ['secret_value'])
    assert {'hello': ['world', '*****']} == remove_values({'hello': ['world', 'secret_value']}, ['secret_value'])



# Generated at 2022-06-20 16:09:44.016513
# Unit test for function sanitize_keys
def test_sanitize_keys():
    obj = {
        'foo': 'bar',
        'baz': {
            'foo': {
                'baz': 'I am baz and I am not being sanitized',
                'secret_string': 'this string is not being sanitized',
                '_ansible_foo': 'I am not being sanitized'
            },
            'ansible': {
                'secret_string': 'change me'
            }
        }
    }
    no_log_strings = ['secret_string', 'change me']

    new_obj = sanitize_keys(obj, no_log_strings, ignore_keys=frozenset(['preserve_me']))
    assert new_obj['foo'] == 'bar'

# Generated at 2022-06-20 16:09:47.219433
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['test'] = "testvalue"
    assert env_fallback('test') == "testvalue"



# Generated at 2022-06-20 16:09:58.476369
# Unit test for function set_fallbacks

# Generated at 2022-06-20 16:10:07.652536
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys('abc', {'a', 'b', 'c'}) == 'abc'
    assert sanitize_keys(['abc'], {'a', 'b', 'c'}) == 'abc'
    assert sanitize_keys(['abc', 'def'], {'a', 'b', 'c'}) == 'abc'
    assert sanitize_keys('abc', {'a', 'b', 'c'}, {'a', 'b', 'c'}) == 'abc'
    assert sanitize_keys(['abc', 'def'], {'a', 'b', 'c'}, {'a', 'b', 'c'}) == 'abc'

# Generated at 2022-06-20 16:10:18.931691
# Unit test for function remove_values
def test_remove_values():
    # Test that basic string substitution works
    assert remove_values('abcdef', ('c',)) == 'abdef'

    # Test that basic objects are returned unchanged
    assert remove_values(None, ()) == None
    assert remove_values(False, ()) == False
    assert remove_values(True, ()) == True
    assert remove_values(42, ()) == 42
    assert remove_values(3.1415, ()) == 3.1415

    # Test that keys in no_log_strings are removed from dict keys
    assert remove_values({'abc': 'def'}, ('abc',)) == {'_ANSIBLE_NO_LOG': 'def'}

    # Test that only keys containing values in no_log_strings are removed
    assert remove_values({'carrot': 'def'}, ('abc',)) == {'carrot': 'def'}

# Generated at 2022-06-20 16:10:28.698899
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'parameter1': {
            'type': 'str',
            'fallback': (env_fallback, ['TEST_ENV_1', 'TEST_ENV_2']),
        },
        'parameter2': {
            'type': 'str',
            'fallback': (env_fallback, ['TEST_ENV_2', 'TEST_ENV_3']),
        },
        'parameter3': {
            'type': 'str',
            'fallback': (env_fallback, ['TEST_ENV_4']),
        }
    }

    parameters = {
        'parameter1': 'value1'
    }

    # Environment variables not set
    assert set_fallbacks(argument_spec, parameters) == set()

    # Set TEST_

# Generated at 2022-06-20 16:10:41.656130
# Unit test for function sanitize_keys
def test_sanitize_keys():

    data = {
        'host': 'localhost',
        'password': 'password',
        'name': 'Bob',
        'nested': {
            'password': 'password',
        },
    }

    class MyClass(object):
        def __init__(self, param):
            self.param = param

        def method(self):
            return self.param

    # Set up a more complex data structure

# Generated at 2022-06-20 16:11:12.475532
# Unit test for function sanitize_keys

# Generated at 2022-06-20 16:11:24.317250
# Unit test for function env_fallback
def test_env_fallback():
    term_mode = False
    ANSIBLE_CALLBACK_WHITELIST = None
    display = Display()
    # set term mode to false


# Generated at 2022-06-20 16:11:35.983888
# Unit test for function remove_values
def test_remove_values():
    test_list = []
    test_list.append(remove_values('password=changeme', ['changeme']))
    test_list.append(remove_values(dict(password=dict(changeme='string')), ['changeme']))
    test_list.append(remove_values(dict(password='changeme', user='vivek'), ['changeme']))
    test_list.append(remove_values(dict(password=dict(changeme='string'), user='vivek'), ['changeme', 'string']))
    test_list.append(remove_values(dict(password=dict(changeme=set(['secret', 'gaurav']))), ['changeme', 'string']))

    for item in test_list:
        assert 'changeme' not in item

# Generated at 2022-06-20 16:11:39.368970
# Unit test for function env_fallback
def test_env_fallback():
    try:
        env_fallback('undefined')
        assert False, "env_fallback did not raise AnsibleFallbackNotFound"
    except AnsibleFallbackNotFound:
        pass



# Generated at 2022-06-20 16:11:44.433817
# Unit test for function env_fallback
def test_env_fallback():
    test_val = "test"
    os.environ['test'] = test_val
    assert env_fallback('test') == test_val
    assert env_fallback('test2') == test_val
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('test3')



# Generated at 2022-06-20 16:11:55.816177
# Unit test for function sanitize_keys
def test_sanitize_keys():
    from ansible.module_utils.common.removed import removed
    assert sanitize_keys([{'no_log': 'masked', 'not_no_log': 'not_masked'}, 'not_masked'], {'masked'}) == [{'***': 'masked', 'not_no_log': 'not_masked'}, 'not_masked']
    assert sanitize_keys([{'_ansible_no_log': 'masked', 'not_no_log': 'not_masked'}, 'not_masked'], {'masked'}) == [{'_ansible_no_log': 'masked', 'not_no_log': 'not_masked'}, 'not_masked']

# Generated at 2022-06-20 16:12:06.690686
# Unit test for function remove_values
def test_remove_values():
    remove_values_container_test = {'foo': {'bar': 'hi', 'baz': 'bye'}}
    remove_values_container_test['foo']['bar'] = remove_values_container_test

    # Test container types
    for container_type in (list, tuple, set, frozenset, dict):
        if container_type == dict:
            c = remove_values_container_test
        else:
            if container_type == frozenset:
                c = (1, 2, 3, 4)
            else:
                c = [1, 2, 3, 4]

            c = container_type(c)

        new_c = remove_values(c, ('2', '4'))
        # New object should not be original object
        assert c is not new_c

        # Ensure the new object is

# Generated at 2022-06-20 16:12:17.076918
# Unit test for function sanitize_keys
def test_sanitize_keys():
    # Arrange
    no_log_strings = set()
    ignore_keys = frozenset()
    deferred_removals = deque()
    expected = '[{"password_param":{"value": "supersecret"}}]'
    test_data = {'_ansible_no_log': True, 'super_secret': '[{"password_param":{"value": "supersecret"}}]'}

    # Assert
    result = _sanitize_keys_conditions(test_data, no_log_strings, ignore_keys, deferred_removals)

# Generated at 2022-06-20 16:12:29.617175
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Test if specified, fallback will be considered
    params = [{'test': 'test', 'test1': 'test1'}, {'test': 'test', 'test1': 'test1', 'test2': 'test2'}]
    assert set_fallbacks(params[0], params[1]) == set()
    params = [{'test': 'test', 'test1': {'default': 'test1'}}, {'test': 'test'}]
    assert set_fallbacks(params[0], params[1]) == set()
    params = [{'test': 'test', 'test1': {'default': 'test1', 'fallback': env_fallback, 'fallback_args': 'test1_env'}},
              {'test': 'test'}]

# Generated at 2022-06-20 16:12:40.613605
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'paramA': {'type': 'str', 'fallback': ('env_fallback', 'ANSIBLE_TEST_PARAMA')},
        'paramB': {'type': 'str', 'fallback': ('env_fallback', 'ANSIBLE_TEST_PARAMB')},
    }
    parameters = {
        'paramA': 'valueA',
        'paramB': 'valueB',
    }
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert no_log_values == set(), 'no_log_values is not empty'
    assert parameters['paramA'] == 'valueA', 'value of paramA was changed'
    assert parameters['paramB'] == 'valueB', 'value of paramB was changed'

# Generated at 2022-06-20 16:13:06.721656
# Unit test for function env_fallback
def test_env_fallback():
    def test_env_fallback_no_args():
        with pytest.raises(AnsibleFallbackNotFound) as exc:
            env_fallback()
        assert 'No value found in environment' in str(exc)

    def test_env_fallback():
        os.environ['ONE'] = 'ONE'
        os.environ['TWO'] = 'TWO'
        assert env_fallback('ONE', 'TWO') == 'ONE'
        assert env_fallback('TWO', 'ONE') == 'TWO'
        assert env_fallback('TWO', 'THREE') == 'TWO'

    def test_env_fallback_not_found():
        os.environ['ONE'] = 'ONE'
        os.environ['TWO'] = 'TWO'

# Generated at 2022-06-20 16:13:14.885332
# Unit test for function remove_values
def test_remove_values():
    class T(dict):
        def __init__(self, data):
            self.data = data

        def __getitem__(self, key):
            return self.data[key]

        def __contains__(self, key):
            return key in self.data

        def __iter__(self):
            return self.data.__iter__()

        def __len__(self):
            return self.data.__len__()

    no_log_strings = ['$', '@', '#', '!', '%']

    assert remove_values('$3434$', no_log_strings) == ''
    assert remove_values(['$3434$'], no_log_strings) == ['']
    assert remove_values(3, no_log_strings) == 3

# Generated at 2022-06-20 16:13:19.407232
# Unit test for function remove_values
def test_remove_values():
    data = {
        'hello': 'world',
        'foo': 'bar',
        'one': [1, 2, 3],
        'set': {'x', 'y', 'z'},
        'map': {'a': 1, 'b': 2, 'c': 3}
    }
    data_copy = copy.deepcopy(data)
    no_log_strings = frozenset(['hello', 'bar', 1, 3])
    new_data = remove_values(data, no_log_strings)
    assert new_data['hello'] == CENSOR
    assert new_data['foo'] == CENSOR
    assert new_data['one'] == [CENSOR, 2, CENSOR]
    assert new_data['set'] == {CENSOR, 'y', CENSOR}
    assert new_

# Generated at 2022-06-20 16:13:29.281924
# Unit test for function env_fallback
def test_env_fallback():
    ''' Test env_fallback function '''
    from ansible.module_utils.basic import AnsibleModule
    # This shouldn't ever be set. If it is, we'll mock it here
    if 'FIXTURES_PATH' in os.environ:
        del os.environ['FIXTURES_PATH']
    if not HAS_STUB:
        module = AnsibleModule(argument_spec=dict(foo=dict(type='str', fallback=(env_fallback, 'FIXTURES_PATH'))), supports_check_mode=True)
        with pytest.raises(AnsibleFallbackNotFound):
            module.params['foo']
    else:
        with pytest.raises(TypeError):
            stub = StubModule()
            env_fallback(stub, 'FOO')



# Generated at 2022-06-20 16:13:32.935940
# Unit test for function env_fallback
def test_env_fallback():
    try:
        env_fallback('test_env_fallback_12345')
        assert False
    except AnsibleFallbackNotFound:
        assert True
    test_env_var = 'test_env_fallback_12345'
    os.environ[test_env_var] = 'test_value'
    assert env_fallback(test_env_var) == 'test_value'



# Generated at 2022-06-20 16:13:44.579164
# Unit test for function env_fallback
def test_env_fallback():
    if os.environ.get('ANSIBLE_TEST_ENV_FALLBACK') is None:
        pytest.skip("No environment variable ANSIBLE_TEST_ENV_FALLBACK set.")
    with patch.dict(os.environ, clear=True, ANSIBLE_TEST_ENV_FALLBACK='ANSIBLE_TEST_ENV_FALLBACK_VALUE'):
        assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'ANSIBLE_TEST_ENV_FALLBACK_VALUE'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'ANSIBLE_TEST_ENV_FALLBACK_VALUE'

# Generated at 2022-06-20 16:13:53.469381
# Unit test for function set_fallbacks

# Generated at 2022-06-20 16:14:02.464003
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # idempotency test
    argument_spec = dict(a=dict(type='int', fallback=(env_fallback, 'A')),
                         b=dict(type='bool', fallback=(env_fallback, 'B')))

    parameters = dict(a=1, b=False)
    assert set_fallbacks(argument_spec, parameters) == set()
    assert parameters == dict(a=1, b=False)

    # test fallback but no env var set, so no change
    parameters = dict()
    assert set_fallbacks(argument_spec, parameters) == set()
    assert parameters == dict()

    # test fallback to env var
    os.environ['A'] = '1'
    os.environ['B'] = 'yes'
    parameters = dict()

# Generated at 2022-06-20 16:14:10.270056
# Unit test for function remove_values
def test_remove_values():
    if __name__ == "__main__":
        print("test_remove_values")
        a = {
            'k' : ['v', 1, {'q':'w'}],
            'k2' : 'v2',
            'k3' : ['v3', 1, {'q':'w'}],
        }
        no_log_strings = {'v', 'w'}
        new_value = remove_values(a, no_log_strings)
        print(new_value)

# Generated at 2022-06-20 16:14:16.613618
# Unit test for function remove_values
def test_remove_values():
    # pylint: disable=unused-variable

    from collections import namedtuple

    TestToRemove = namedtuple('TestToRemove', ['value'])
    TestNotToRemove = namedtuple('TestNotToRemove', ['value'])

    class TestToRemove_Instance(object):
        pass

    class TestNotToRemove_Instance(object):
        pass

    test_to_remove_instance = TestToRemove_Instance()
    test_to_remove_instance.value = 'TestToRemove'
    test_not_to_remove_instance = TestNotToRemove_Instance()
    test_not_to_remove_instance.value = 'TestNotToRemove'


# Generated at 2022-06-20 16:14:46.330808
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['test1'] = 'test'
    os.environ['test2'] = 'test'
    try:
        assert env_fallback('test1') == 'test'
        assert env_fallback('test1', 'test2') == 'test'
        assert env_fallback('test2', 'test1') == 'test'
        assert env_fallback('test1', 'test2', 'test2') == 'test'
        assert env_fallback('test1', 'test1') == 'test'
        assert env_fallback('test2', 'test2') == 'test'
        assert env_fallback('test3') == None
    finally:
        del os.environ['test1']
        del os.environ['test2']



# Generated at 2022-06-20 16:14:55.736845
# Unit test for function remove_values
def test_remove_values():
    # Basic test
    str_value = 'test string one'
    new_value = remove_values(str_value, ['string'])
    assert new_value == 'test one'

    # Test with unicode and surrogate pairs
    str_value = u'\u0041\u00DF\u6771\uD801\uDC00'
    new_value = remove_values(str_value, [u'\u0041\u00DF\u6771\uD801\uDC00'])
    assert new_value == ''

    # Test with ints and floats
    int_value = 1
    new_value = remove_values(int_value, [1])
    assert new_value == 1

    float_value = 1.1
    new_value = remove_values(float_value, [1.1])