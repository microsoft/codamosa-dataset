

# Generated at 2022-06-20 16:05:25.358693
# Unit test for function env_fallback
def test_env_fallback():
    # test that AnsibleFallbackNotFound raised
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('')
    os.environ['ANSIBLE_TEST_ENV_FALLBACK_1'] = 'ANSIBLE_TEST_ENV_FALLBACK_1'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_1') == 'ANSIBLE_TEST_ENV_FALLBACK_1'
# END - Unit test for function env_fallback



# Generated at 2022-06-20 16:05:32.110496
# Unit test for function sanitize_keys

# Generated at 2022-06-20 16:05:41.249178
# Unit test for function set_fallbacks
def test_set_fallbacks():
    fake_fallback_function = Mock(return_value=['Fallback Answer'])
    fake_required_function = Mock(side_effect=TypeError('error msg'))

# Generated at 2022-06-20 16:05:46.361026
# Unit test for function sanitize_keys
def test_sanitize_keys():
    data = [{'foo': 1, 'bar': 2, 'baz': 3, '_ansible_foo': 4}, {'bar': 5}]
    old_data = copy.deepcopy(data)
    no_log_values = ['bar']
    new_data = sanitize_keys(data, no_log_values)

    assert old_data[0]['_ansible_foo'] == 4
    assert old_data[0]['baz'] == 3
    assert old_data == data
    assert new_data[0]['foo'] == 1
    assert new_data[0]['baz'] == 3
    assert new_data[0]['bar'] is None
    assert new_data[1]['bar'] == 5
    assert list(new_data[1].keys()) == ['bar']

# Generated at 2022-06-20 16:05:51.528335
# Unit test for function env_fallback
def test_env_fallback():
    test_args = ('TEST_ENV_VAR', 'OTHER_TEST_ENV_VAR')
    os.environ['TEST_ENV_VAR'] = 'test'
    assert env_fallback(*test_args) == 'test'
    del os.environ['TEST_ENV_VAR']
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback(*test_args)



# Generated at 2022-06-20 16:06:02.373309
# Unit test for function sanitize_keys
def test_sanitize_keys():
    """Unit test for function sanitize_keys"""
    expected_string = '**********'

    # Test 1: test sanitize_keys for dictionaries
    options = {
        'my_key': 'my_value'
    }
    no_log_values = set([expected_string])
    sanitized_string = sanitize_keys(options, no_log_values)
    assert sanitized_string == {'**********': 'my_value'}

    # Test 2: test sanitize_keys for lists
    no_log_values = set([expected_string])
    options = ['my_key']
    sanitized_string = sanitize_keys(options, no_log_values)
    assert sanitized_string == ['**********']

    # Test 3: test sanitize_keys for sets
    no_

# Generated at 2022-06-20 16:06:06.759061
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('DOESNT_EXIST') == AnsibleFallbackNotFound
    os.environ['EXISTS'] = 'test_env_fallback'
    assert env_fallback('EXISTS') == 'test_env_fallback'



# Generated at 2022-06-20 16:06:18.125974
# Unit test for function sanitize_keys
def test_sanitize_keys():
    from ansible.module_utils.six import iteritems
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common.collections import is_iterable

    # Unit test for function sanitize_keys
    class FakeConfig:
        no_log = False
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    class FakeModule:
        config = FakeConfig()

    class FakeTaskVars(dict):
        def __init__(self, *args, **kwargs):
            super(FakeTaskVars, self).__init__(*args, **kwargs)
            self['ansible_ssh_host'] = "testhost"


# Generated at 2022-06-20 16:06:30.318421
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        param_1=dict(type='str', fallback=(None,)),
        param_2=dict(type='str', fallback=(env_fallback, ('ANSIBLE_MODULE_PARAM_2',),)),
        param_3=dict(type='str', fallback=(env_fallback, ('ANSIBLE_MODULE_PARAM_3',))),
        param_4=dict(type='str', fallback=(env_fallback, ('ANSIBLE_MODULE_PARAM_4',), {'default': 'default value'})),
        param_5=dict(type='str', fallback=(None,)),
        param_6=dict(type='str', fallback=(env_fallback, ('ANSIBLE_MODULE_PARAM_6',),)),
    )
    parameters = dict()
   

# Generated at 2022-06-20 16:06:41.638932
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_STR'] = 'unit test string'
    os.environ['ANSIBLE_TEST_INT'] = '55'
    os.environ['ANSIBLE_TEST_BOOL'] = 'False'
    os.environ['ANSIBLE_TEST_LIST'] = '["a", "b"]'
    os.environ['ANSIBLE_TEST_DICT'] = '{"a": "b"}'

    assert env_fallback('ANSIBLE_TEST_STR') == 'unit test string'
    assert env_fallback('ANSIBLE_TEST_INT') == '55'
    assert env_fallback('ANSIBLE_TEST_BOOL') == 'False'
    assert env_fallback('ANSIBLE_TEST_LIST') == ['a', 'b']
    assert env_

# Generated at 2022-06-20 16:07:15.918408
# Unit test for function remove_values
def test_remove_values():

    def assert_no_values(new_data, expected):
        """Assert key/value pairs in new_data do not appear in expected."""
        if isinstance(new_data, Mapping):
            for key, val in new_data.items():
                assert_no_values(val, expected)

        # Checking MutableSequences and MutableSets is complicated because these
        # containers can contain duplicate values. We simplify the problem by
        # only checking that each element in new_data does not exist in expected.
        # If needed, we can revisit the problem later.
        #
        # Suppose we want to check for the string "foo". If new_data is a
        # MutableSequence, then we can't just check for "foo" in new_data,
        # because there may be multiple items. Instead, we should check
        # by

# Generated at 2022-06-20 16:07:26.282636
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        name=dict(required=True, fallback=(env_fallback, 'ANSIBLE_NET_USERNAME')),
        password=dict(required=True, no_log=True, fallback=(env_fallback, 'ANSIBLE_NET_PASSWORD')),
        host=dict(required=True, fallback=(env_fallback, 'ANSIBLE_NET_HOST')),
    )
    parameters = dict(name='ansible', host='127.0.0.1')
    os.environ['ANSIBLE_NET_PASSWORD'] = 'password'

    no_log_values = set_fallbacks(argument_spec, parameters)
    assert all(item in parameters for item in argument_spec)
    assert all(item in no_log_values for item in ['password'])



# Generated at 2022-06-20 16:07:29.856296
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['VAR1'] = 'foo'
    os.environ['VAR2'] = 'bar'
    assert env_fallback('VAR2') == 'bar'
    with pytest.raises(AnsibleFallbackNotFound):
        assert env_fallback('VAR3')



# Generated at 2022-06-20 16:07:40.578255
# Unit test for function remove_values
def test_remove_values():
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.module_utils._text import to_bytes
    #use os.linesep as newlines are normalized in the function
    removals = set([b'password', b'pwd', b'private', b'passwd', b'password1', b'password2', b'password12', b'password123',
                    b'old_password', b'new_password', b'root_password', b'adminPassword', b'pwd123', b'pwd12', b'pwd1',
                    b'admin_password', to_bytes(os.linesep, errors='surrogate_or_strict')])
    # Simple string
    test_value = 'password = mysecret'
    result = remove_values(test_value, removals)
   

# Generated at 2022-06-20 16:07:44.124685
# Unit test for function env_fallback
def test_env_fallback():
    for arg in ('', 'host_string', 'SOME_VAR'):
        try:
            env_fallback(arg)
        except AnsibleFallbackNotFound:
            pass
        if 'SOME_VAR' in os.environ:
            del os.environ['SOME_VAR']
    os.environ['SOME_VAR'] = 'some_value'
    assert env_fallback('', 'host_string') == 'some_value'

FALLBACK_HASH = {
    'env': env_fallback,
}



# Generated at 2022-06-20 16:07:56.992223
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys('asdf', ['a'], ['b']) == 'sd'
    assert sanitize_keys('asdf', []) == 'asdf'
    assert sanitize_keys({'a': 'asdf', 'b': 'asdf'}, ['a']) == {'a': 'sdf', 'b': 'asdf'}
    assert sanitize_keys({'a': 'asdf', 'b': 'asdf'}, ['a', 'b']) == {}
    assert sanitize_keys({'a': 'asdf', 'b': 'asdf'}, ['a', 'b'], ['b']) == {'b': 'asdf'}

# Generated at 2022-06-20 16:08:07.022745
# Unit test for function env_fallback
def test_env_fallback():
    '''Test env_fallback'''

    def _test_env_fallback_setup():
        '''Setup for env_fallback'''

        os.environ['ANSIBLE_TEST_ENV_VAR_1'] = 'ANSIBLE_TEST_ENV_VAR_1'
        os.environ['ANSIBLE_TEST_ENV_VAR_2'] = 'ANSIBLE_TEST_ENV_VAR_2'
        os.environ['ANSIBLE_TEST_ENV_VAR_3'] = 'ANSIBLE_TEST_ENV_VAR_3'
        os.environ['ANSIBLE_TEST_ENV_VAR_4'] = 'ANSIBLE_TEST_ENV_VAR_4'

# Generated at 2022-06-20 16:08:13.956443
# Unit test for function remove_values

# Generated at 2022-06-20 16:08:14.513646
# Unit test for function env_fallback
def test_env_fallback():
    """Test env_fallback"""
    pass



# Generated at 2022-06-20 16:08:25.490188
# Unit test for function sanitize_keys

# Generated at 2022-06-20 16:09:02.349095
# Unit test for function remove_values
def test_remove_values():
    assert remove_values('test', ['test']) == '[VALUE REMOVED]'
    assert remove_values({'test': 'test'}, ['test']) == {'test': '[VALUE REMOVED]'}
    assert remove_values(['test', 'test'], ['test']) == ['[VALUE REMOVED]', '[VALUE REMOVED]']
    assert remove_values(frozenset(['test', 'test']), ['test']) == frozenset(['[VALUE REMOVED]', '[VALUE REMOVED]'])
    assert remove_values(set(['test', 'test']), ['test']) == set(['[VALUE REMOVED]', '[VALUE REMOVED]'])

# Generated at 2022-06-20 16:09:10.740526
# Unit test for function remove_values
def test_remove_values():
    # basic testing
    assert remove_values('abc', ['abc']) == '***'
    assert remove_values('abcdefg', ['abc']) == 'abcdefg'
    assert remove_values((('abc', 'def'),), ['def']) == (('abc', '***'),)
    assert remove_values((('abc', 'def'), {'abc': 'def'}), ['def']) == (('abc', '***'), {'abc': '***'})
    assert remove_values((('abc', 'def'), {'abc': 'def'}, 'abc'), ['abc', 'def']) == (('***', '***'), {'***': '***'}, '***')
    assert remove_values([], ['abc']) == []
    assert remove_values(set([]), ['abc']) == set([])
    assert remove_

# Generated at 2022-06-20 16:09:21.064478
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanity_check_simple_input(sanitize_keys('asdf', ['a', 's'])) == '**'
    assert sanity_check_simple_input(sanitize_keys({'a': 1, 'b': 2}, ['a', 's'])) == {'b': 2, '**': 1}
    assert sanity_check_simple_input(sanitize_keys({'a': 1, 'b': 2}, ['a', 's'], set('ab'))) == {'a': 1, 'b': 2}
    assert sanity_check_simple_input(sanitize_keys({'a': {'a': 1, 'b': 2}}, ['a', 's'])) == {'**': {'b': 2, '**': 1}}

# Generated at 2022-06-20 16:09:32.279254
# Unit test for function remove_values
def test_remove_values():
    """ test for function remove_values
    """

    # Empty string
    assert remove_values(u'', []) == u''
    # Empty list
    assert remove_values([], []) == []
    # Empty tuple
    assert remove_values((), []) == ()
    # Empty dict
    assert remove_values({}, []) == {}
    # Empty set
    assert remove_values(set(), []) == set()

    # No values to remove
    assert remove_values(u'foo', []) == u'foo'

    # Sequence
    assert remove_values([u'foo', [u'baz', b'bar']], [b'bar']) == [u'foo', [u'baz']]

    # Tuple

# Generated at 2022-06-20 16:09:42.382824
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        test1=dict(type=str),
        test2=dict(type=str, fallback=('test', 'testfallback')),
        test3=dict(type=str, fallback=(env_fallback, 'test3', {'booltest': True, 'inttest': 42})),
        test4=dict(type=str, fallback=(env_fallback, 'test4'))
    )

    parameters = dict(test1='test1')
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert 'test1' not in no_log_values
    assert parameters['test1'] == 'test1'
    assert parameters['test2'] == 'test'
    assert parameters['test3'] == 'test3'
    assert 'test4' not in parameters


# Generated at 2022-06-20 16:09:54.062831
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        foo=dict(type='str', no_log=True, fallback=(env_fallback, ['FOO'], 'bar')),
        bar=dict(type='str', no_log=True, fallback=(env_fallback, ['BAR'])),
        baz=dict(type='str', no_log=False, fallback=(env_fallback, ['BAZ'])),
    )

    parameters = dict()

    no_log_values = set_fallbacks(argument_spec, parameters)
    assert 'bar' in parameters
    assert 'bar' not in no_log_values
    assert parameters['bar'] == 'bar'
    assert parameters['foo'] == 'foo'
    assert 'foo' in no_log_values

    del os.environ['FOO']
    no_

# Generated at 2022-06-20 16:10:03.993276
# Unit test for function env_fallback
def test_env_fallback():
    """Unit test for function env_fallback"""
    from os import environ
    from ansible.module_utils._text import to_native

    def _test(name, value, fallback, expected):
        """Test function"""
        environ[name] = value
        try:
            if expected is not None:
                assert env_fallback(fallback) == expected
            else:
                env_fallback(fallback)
                assert False, "Should have failed with fallback {}".format(fallback)
        except AnsibleFallbackNotFound:
            if expected is not None:
                assert False, "Should not have failed with fallback {}".format(fallback)
        except AssertionError as e:
            raise AssertionError('{}: {}'.format(to_native(e), fallback))

# Generated at 2022-06-20 16:10:18.770837
# Unit test for function sanitize_keys
def test_sanitize_keys():
    data = [
        {'key': 'value', 'no_log': 'value2', 'key': 'value3'},
        ['value3', 'value4', 'value5'],
        {'key': 'no_logvalue', 'key2': 'value6'},
        'a', 'b', 'c'
    ]
    no_log_strings = ['no_logvalue', 'value4', 'value2', 'password']
    new_data = sanitize_keys(data, no_log_strings)

# Generated at 2022-06-20 16:10:20.639242
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('CI_USER_MISSING_ENV_VAR') is None


# Generated at 2022-06-20 16:10:29.845033
# Unit test for function set_fallbacks

# Generated at 2022-06-20 16:11:25.139588
# Unit test for function remove_values
def test_remove_values():
    import copy

# Generated at 2022-06-20 16:11:33.017570
# Unit test for function env_fallback
def test_env_fallback():
    os.environ.update(ANSIBLE_TEST_ENV_VAR='test')
    assert env_fallback('ANSIBLE_TEST_ENV_VAR') == 'test'
    try:
        env_fallback('NOT_FOUND')
    except AnsibleFallbackNotFound:
        pass
    else:
        assert False, 'env_fallback should raise AnsibleFallbackNotFound'
    del os.environ['ANSIBLE_TEST_ENV_VAR']


# Generated at 2022-06-20 16:11:38.189656
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'env_value': {'type': 'str', 'fallback': (env_fallback, 'TEST_ENV')}}
    parameters = {}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert len(no_log_values) == 0
    assert len(parameters) == 0
    os.environ['TEST_ENV'] = 'test'
    argument_spec = {'env_value': {'type': 'str', 'fallback': (env_fallback, 'TEST_ENV')}}
    parameters = {}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert len(no_log_values) == 0
    assert len(parameters) == 1
    assert parameters['env_value'] == 'test'




# Generated at 2022-06-20 16:11:50.430239
# Unit test for function remove_values
def test_remove_values():
    # Pytest is required to run this test. You can install it by: pip install pytest
    import pytest

    # Test for a non-container input
    value = 'a value'
    no_log_strings = ('a value',)
    new_value = remove_values(value, no_log_strings)
    assert new_value == u'!!!!'

    # Test for a container input
    value = {'a value': ['a value', {'a value': 'a value'}, 'other value', ['a value', 'other value'], {'a value': ['a value', 'other value']}]}
    no_log_strings = ('a value',)
    new_value = remove_values(value, no_log_strings)

# Generated at 2022-06-20 16:12:00.990997
# Unit test for function remove_values
def test_remove_values():
    a = {'host': 'localhost', 'password': 'pwd', 'nested': {'username': 'admin', 'port': 2002}}
    result = remove_values(a, ['pwd'])
    assert result['password'] == '<value omitted>'
    assert result['nested']['username'] == 'admin'

    b = [{'host': 'localhost', 'password': 'pwd', 'nested': {'username': 'admin', 'port': 2002}},
         {'host': 'localhost', 'password': 'pwd2', 'nested': {'username': 'admin2', 'port': 2003}}]
    result = remove_values(b, ['pwd'])

# Generated at 2022-06-20 16:12:13.016019
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        _ansible_tmpdir=dict(fallback=(env_fallback, 'TMPDIR')),
        _ansible_keep_remote_files=dict(type='bool', fallback=(env_fallback, 'ANSIBLE_KEEP_REMOTE_FILES'), no_log=True),
        _ansible_shell_executable=dict(fallback=(env_fallback, 'SHELL'), no_log=True, required=True)
    )
    parameters = dict()

    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['_ansible_tmpdir'] == '/tmp'
    assert parameters['_ansible_keep_remote_files'] is False
    assert 'sh' in parameters['_ansible_shell_executable']

# Generated at 2022-06-20 16:12:21.746352
# Unit test for function remove_values
def test_remove_values():
    """Helper function to help test the remove_values function."""
    failures = []

    # FIXME: That's probably not a good way to write this.
    def check_remove(unfiltered_value, filtered_value):
        """Helper function for testing that the remove_values function does what is expected."""
        actual_filtered_value = remove_values(unfiltered_value, no_log_strings)
        if actual_filtered_value != filtered_value:
            failures.append("remove_values failed: expected %s, returned %s" % (filtered_value, actual_filtered_value))


# Generated at 2022-06-20 16:12:34.013695
# Unit test for function sanitize_keys
def test_sanitize_keys():
    # Test sanitize_keys with a dict
    data = {
        'name': 'foo',
        'ansible_become_pass': 'bar'
    }
    no_log_strings = {'bar'}
    result = sanitize_keys(data, no_log_strings)
    assert result == {'name': 'foo', '_ansible_become_pass': 'FILTERED'}

    # Test sanitize_keys with a nested dict
    data = {
        'name': 'foo',
        'command': 'bar',
        'env': {
            'ANSIBLE_BECOME_PASS': 'baz',
            'TEST': 'asdf'
        }
    }
    no_log_strings = {'baz'}

# Generated at 2022-06-20 16:12:44.129450
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Single-level dict
    spec = dict(a=dict(type='int', fallback=(lambda: 3, ())), b=dict(type='str', fallback=(env_fallback, 'FOO')))
    parameters = dict(b='bar')
    assert set_fallbacks(spec, parameters) == set()
    assert parameters == dict(a=3, b='bar')

    # Nested dict
    spec = dict(a=dict(type='dict', options=dict(b=dict(type='int', fallback=(lambda: 3, ())))))
    parameters = dict()
    assert set_fallbacks(spec, parameters) == set()
    assert parameters == dict(a=dict(b=3))
    parameters = dict(a=dict())
    assert set_fallbacks(spec, parameters) == set()

# Generated at 2022-06-20 16:12:53.402882
# Unit test for function sanitize_keys
def test_sanitize_keys():
    class Foo(object):
        def __init__(self, passthru_parent=None):
            self.passthru_parent = passthru_parent

        def __getitem__(self, key):
            return self.__dict__[key]

        def __setitem__(self, key, value):
            self.__dict__[key] = value

    def passthru(obj):
        if isinstance(obj, Mapping):
            return {k: passthru(v) for k, v in obj.items()}
        elif isinstance(obj, Sequence):
            return [passthru(elem) for elem in obj]
        else:
            return obj

    # Test removing private values from a mapping
    # Note that we handle removing private values from keys in dicts specially so we don't
    # need

# Generated at 2022-06-20 16:13:25.583231
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['API_TOKEN'] = 'mock_token'
    assert env_fallback('API_TOKEN') == 'mock_token'
    assert env_fallback('API_TOKEN', 'SOME_OTHER_TOKEN') == 'mock_token'
    assert env_fallback('SOME_OTHER_TOKEN', 'API_TOKEN') == 'mock_token'
    try:
        env_fallback('NO_SUCH_ENV_VARIABLE') == 'mock_token'
    except AnsibleFallbackNotFound:
        assert True
    finally:
        del os.environ['API_TOKEN']



# Generated at 2022-06-20 16:13:34.329705
# Unit test for function env_fallback
def test_env_fallback():
    with mock.patch.dict(os.environ, {'ansible_COLUMNS': '80'}):
        assert env_fallback('ansible_COLUMNS') == '80'
        assert env_fallback('ansible_ROWS') == '80'
    with mock.patch.dict(os.environ, {'ansible_COLUMNS': '80'}):
        assert env_fallback('ansible_COLUMNS', 'ansible_ROWS') == '80'
    with mock.patch.dict(os.environ, {'ansible_COLUMNS': '80'}):
        assert env_fallback('ansible_COLUMNS', 'ansible_ROWS') == '80'
        assert env_fallback('ansible_ROWS') == '80'

# Generated at 2022-06-20 16:13:45.767293
# Unit test for function set_fallbacks

# Generated at 2022-06-20 16:13:57.331452
# Unit test for function env_fallback
def test_env_fallback():

    os.environ['TEST_ENV'] = 'env_var'

    # check that env_fallback raises if no args are passed
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback()

    # check that env_fallback raises if no env var is found
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('TEST_ENV2')

    # check that env_fallback returns the env var value
    assert env_fallback('TEST_ENV') == 'env_var'

    # check that env_fallback uses the first available env var
    assert env_fallback('TEST_ENV2', 'TEST_ENV') == 'env_var'

    del os.environ['TEST_ENV']

# Unit

# Generated at 2022-06-20 16:14:08.154222
# Unit test for function remove_values
def test_remove_values():
    test_data = dict(
        one=dict(
            two=dict(
                three='pass',
                four='fail',
            )
        ),
        one_only='fail',
        weird_list=['pass', 'pass', 'fail', dict(fail='fail'), ['fail']],
        weird_set=set(['pass', 'pass', 'fail', dict(fail='fail'), ['fail']]),
        not_a_container='fail',
    )
    no_log_strings = set(['fail'])

# Generated at 2022-06-20 16:14:15.544132
# Unit test for function remove_values
def test_remove_values():
    assert remove_values({'foo': {'bar': {'baz': 'secret'}, 'baz': [1, 2, 3], 'qux': []}, 'qux': set([{'quux': 'secret'}])}, ['secret']) == {'foo': {'baz': [1, 2, 3], 'qux': []}, 'qux': set()}

# Generated at 2022-06-20 16:14:18.121611
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('HOME') == os.environ['HOME']
    assert_raises(AnsibleFallbackNotFound, env_fallback, '')



# Generated at 2022-06-20 16:14:24.773797
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_FOO'] = 'bar'
    assert env_fallback('ANSIBLE_FOO') == 'bar'
    assert env_fallback('ANSIBLE_FOO', 'ANSIBLE_BAR', 'ANSIBLE_BAZ') == 'bar'
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('ANSIBLE_BAR', 'ANSIBLE_BAZ')



# Generated at 2022-06-20 16:14:34.525560
# Unit test for function remove_values
def test_remove_values():
    assert remove_values('password', ['password']) == 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'
    assert remove_values('passwords', ['password']) == 'passwords'
    assert remove_values('i am a password', ['password']) == 'i am a VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'
    assert remove_values(['i am a password', 'i am also a password'], ['password']) == ['i am a VALUE_SPECIFIED_IN_NO_LOG_PARAMETER', 'i am also a VALUE_SPECIFIED_IN_NO_LOG_PARAMETER']

# Generated at 2022-06-20 16:14:44.626179
# Unit test for function set_fallbacks
def test_set_fallbacks():
    data = dict(
        host='example.net',
        port=80,
    )
    spec = dict(
        host=dict(type='str'),
        port=dict(type='int', fallback=(env_fallback, [('ANSIBLE_NET_PORT', 'ANSIBLE_PORT')])),
    )

    no_log_values = set_fallbacks(spec, data)
    assert data['port'] == 80

    os.environ['ANSIBLE_NET_PORT'] = '443'
    no_log_values = set_fallbacks(spec, data)
    assert data['port'] == 443
    assert os.environ['ANSIBLE_NET_PORT'] == '443'

    del os.environ['ANSIBLE_NET_PORT']