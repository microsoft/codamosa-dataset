

# Generated at 2022-06-11 01:20:01.287219
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'test_parameter1': {'type': 'str', 'fallback': (env_fallback, 'TEST_PARAMETER1')},
        'test_parameter2': {'type': 'str'},
        'test_parameter3': {'type': 'bool', 'default': False},
        'test_parameter4': {'type': 'list', 'elements': 'str', 'fallback': (lambda: ['abc', 'def'])},
        'test_parameter5': {'type': 'bool', 'default': False},
    }
    os.environ['TEST_PARAMETER1'] = 'test_parameter1_value'
    parameters = {
        'test_parameter2': 'test_parameter2_value'
    }
    set_

# Generated at 2022-06-11 01:20:06.720724
# Unit test for function env_fallback
def test_env_fallback():
    with patch.dict(os.environ, {'test_env_fallback_1': 'test1'}):
        assert env_fallback('test_env_fallback_1') == 'test1'
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('test_env_fallback_2')



# Generated at 2022-06-11 01:20:14.087190
# Unit test for function set_fallbacks
def test_set_fallbacks():
    spec = dict(test_param=dict(type='str'))
    parameters = {}
    no_log_values = set_fallbacks(spec, parameters)
    assert no_log_values == set()
    assert parameters == dict()

    parameters['test_param'] = 'TEST_PARAM'
    no_log_values = set_fallbacks(spec, parameters)
    assert no_log_values == set()
    assert parameters['test_param'] == 'TEST_PARAM'

    parameters['test_param'] = ''
    no_log_values = set_fallbacks(spec, parameters)
    assert no_log_values == set()

    spec = dict(test_param=dict(type='str', fallback='TEST_FALLBACK'))
    parameters = {}
    no_log_values = set_fallbacks

# Generated at 2022-06-11 01:20:23.610497
# Unit test for function set_fallbacks

# Generated at 2022-06-11 01:20:32.522792
# Unit test for function env_fallback
def test_env_fallback():
    """Test env_fallback function"""
    os.environ['TEST_VAR'] = 'TEST_STRING'
    assert env_fallback('TEST_VAR') == 'TEST_STRING'
    assert env_fallback('TEST_VAR', 'TEST_VAR2') == 'TEST_STRING'
    assert env_fallback('TEST_VAR2', 'TEST_VAR') == 'TEST_STRING'
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('TEST_VAR2')


# Generated at 2022-06-11 01:20:34.827791
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['FOO'] = 'bar'
    assert env_fallback('FOO') == 'bar'
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('BAR')

# Generated at 2022-06-11 01:20:45.193450
# Unit test for function set_fallbacks

# Generated at 2022-06-11 01:20:50.739584
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'name': {'type': 'str', 'fallback': (env_fallback, 'ANSIBLE_PARAM')}}
    parameters = {}
    os.environ['ANSIBLE_PARAM'] = 'foo'
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['name'] == 'foo'
    assert no_log_values == set()



# Generated at 2022-06-11 01:21:00.810903
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'param1': {'type': 'str', 'fallback': ('env_fallback', 'TEST1', 'TEST2')},
                     'param2': {'type': 'str', 'fallback': ('env_fallback', 'TEST3', 'TEST4')},
                     'param3': {'type': 'str', 'fallback': ('env_fallback', 'TEST5')}}

    os.environ['TEST1'] = "test1"
    os.environ['TEST3'] = "test3"
    expected_result = {'param1': "test1", 'param2': "test3"}
    result = set_fallbacks(argument_spec, {})
    assert result == expected_result

    os.environ['TEST1'] = "test1"

# Generated at 2022-06-11 01:21:09.836827
# Unit test for function env_fallback
def test_env_fallback():
    '''Return the first argument that exists in os.environ'''
    import os
    os.environ['ANSIBLE_MODULE_FOO'] = 'module_foo'
    os.environ['ANSIBLE_MODULE_BAR'] = 'module_bar'
    assert env_fallback('ANSIBLE_MODULE_FOO') == 'module_foo'
    assert env_fallback('ANSIBLE_MODULE_BAZ', 'ANSIBLE_MODULE_BAR') == 'module_bar'
    assert env_fallback('ANSIBLE_MODULE_BAZ') is None


# TODO: replace with ansible.module_utils.six.moves.winreg when we no longer support py2
try:
    import winreg
except ImportError:
    pass



# Generated at 2022-06-11 01:21:36.964169
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argspec = dict(
        param1=dict(fallback=(env_fallback, 'FOO')),
        param2=dict(fallback=(env_fallback, 'FOO', 'BAR')),
        param3=dict(fallback=(env_fallback, 'FOO', dict(default='BAR')))
    )

    # Test that fallback works for both string and list for env_fallback
    for args in (('FOO',), ('FOO', 'BAR')):
        os.environ['FOO'] = args[0]
        if len(args) == 2:
            os.environ['BAR'] = args[1]
        parameters = dict()
        set_fallbacks(argspec, parameters)
        assert parameters == dict(param1=args[0], param2=args[-1])



# Generated at 2022-06-11 01:21:47.518512
# Unit test for function set_fallbacks
def test_set_fallbacks():
    args = dict(name=dict(required=True), state=dict(choices=['present', 'absent'], fallback=(env_fallback, 'STATE'), required=True))
    options = dict(name='foo', state='present')
    no_log_values = set_fallbacks(args, options)
    assert options['state'] == 'present'
    assert 'present' in no_log_values

    options = dict(name='foo')
    os.environ['STATE'] = 'present'
    no_log_values = set_fallbacks(args, options)
    # Ensure the env var is removed so it doesn't break unrelated tests
    del os.environ['STATE']
    assert options['state'] == 'present'
    assert 'present' in no_log_values



# Generated at 2022-06-11 01:21:54.639796
# Unit test for function remove_values
def test_remove_values():
    """Sanitize output
    """
    value = {
        'param_A': 'value_A',
        'param_B': {
            'param_B_1': 'value_B_1'
        },
        'param_C': ['value_C_1', {'param_C_2': 'value_C_2'}]
    }

    no_log_strings = ['value_A', 'value_C']
    sanitized_value = remove_values(value, no_log_strings)

# Generated at 2022-06-11 01:22:05.422794
# Unit test for function set_fallbacks
def test_set_fallbacks():
    for argument_spec in (
        {'test': {'type': 'str', 'fallback': (env_fallback, [])}},
        {'test': {'type': 'str', 'fallback': (env_fallback, (None,))}},
        {'test': {'type': 'str', 'fallback': (env_fallback, (None, None))}},
        {'test': {'type': 'str', 'fallback': (env_fallback, None)}},
        {'test': {'type': 'str', 'fallback': (env_fallback, None, {})}},
    ):
        param = list(argument_spec.keys())[0]
        parameters = {}
        assert set_fallbacks(argument_spec, parameters) == set()
        assert param not in parameters

    # Nothing that

# Generated at 2022-06-11 01:22:12.939235
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert set_fallbacks({"a": {'type': 'str', 'fallback': (env_fallback, "b")}}, {}) == {"a": "b"}
    assert set_fallbacks({'a': {'type': 'str', 'fallback': (env_fallback, "b")}, 'c': {'type': 'str', 'fallback': (env_fallback, "d")}}, {}) == {'a': 'b', 'c': 'd'}
    assert set_fallbacks({}, {}) == set()



# Generated at 2022-06-11 01:22:19.367016
# Unit test for function env_fallback
def test_env_fallback():
    """Environment variables unit test function"""
    os.environ["ANSIBLE_FOO"] = "bar"
    assert env_fallback("ANSIBLE_FOO") == "bar"
    assert env_fallback("ANSIBLES", "ANSIBLE") == "ANSIBLES"
    assert env_fallback("ANSIBLE_FOO") != "baz"
    assert env_fallback("whatever") == "whatever"
# Unit test
test_env_fallback()



# Generated at 2022-06-11 01:22:22.491452
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert set_fallbacks({'test': {'fallback': ('test',)}}, {}) == set()
    assert set_fallbacks({'test': {'fallback': ('test',), 'no_log': True}}, {}) == {'test'}
test_set_fallbacks.set_fallbacks = set_fallbacks



# Generated at 2022-06-11 01:22:32.417685
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Test no_log=True
    argument_spec = dict(a=dict(type='int', fallback=(env_fallback, 'B')),
                         b=dict(type='int', fallback=(env_fallback, 'C'), no_log=True),
                         d=dict(type='int', fallback=(env_fallback, 'D')))
    env = {'B': '1', 'C': '2', 'D': '3'}
    with patch.dict(os.environ, env):
        no_log_values = set_fallbacks(argument_spec, dict())
        assert len(no_log_values) == 1
        assert '2' in no_log_values

    # Test env_fallback

# Generated at 2022-06-11 01:22:43.540687
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys(dict(foo='bar', bar='bar'), ['bar']) == {'foo': 'bar', 'b*r': 'bar'}
    assert sanitize_keys(dict(foo=dict(foo='bar', bar='bar'), bar='bar'), ['bar']) == {'foo': {'foo': 'bar', 'b*r': 'bar'}, 'b*r': 'bar'}
    assert sanitize_keys(dict(foo=dict(foo='bar', bar='bar'), bar='bar'), ['bar'], ignore_keys=['foo']) == {'foo': {'foo': 'bar', 'bar': 'bar'}, 'b*r': 'bar'}

# Generated at 2022-06-11 01:22:52.308547
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(foo=dict(type='str', fallback=(env_fallback, ('FOO', 'BAR'))))
    parameters = {}

    assert set_fallbacks(argument_spec, parameters) == set()
    assert parameters == {}
    os.environ['FOO'] = 'foo'
    assert set_fallbacks(argument_spec, parameters) == set()
    assert parameters['foo'] == 'foo'
    del os.environ['FOO']

    argument_spec = dict(foo=dict(type='str', fallback=(env_fallback, ('FOO', 'BAR'))),
                         bar=dict(type='str', fallback=(env_fallback, [('BAR',), dict(default='bar')])))
    os.environ['FOO'] = 'foo'
    os.environ

# Generated at 2022-06-11 01:23:33.724811
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_NET_USERNAME'] = 'user'
    os.environ['NS_USER'] = 'user'
    assert env_fallback('ANSIBLE_NET_USERNAME') == 'user'
    assert env_fallback('NS_USER') == 'user'



# Generated at 2022-06-11 01:23:43.741563
# Unit test for function env_fallback
def test_env_fallback():
    # Set the environment
    os.environ['ANSIBLE_FOO_BAR'] = 'FOO'
    os.environ['ANSIBLE_FOO_BAZ'] = 'BAZ'
    os.environ['ANSIBLE_FOO_BIFF'] = 'BIFF'

    # Try loading the value
    value = env_fallback('ANSIBLE_FOO_BAR', 'ANSIBLE_FOO_BAZ')
    assert value == 'FOO'

    value = env_fallback('ANSIBLE_FOO_BOO', 'ANSIBLE_FOO_BIFF')
    assert value == 'BIFF'

    # Deleting an environment variable
    del os.environ['ANSIBLE_FOO_BIFF']

# Generated at 2022-06-11 01:23:54.974732
# Unit test for function remove_values
def test_remove_values():
    assert remove_values("Nefarious Value",("Nefarious","Nefarious Value")) == "Value"
    assert remove_values("Nefarious Value",("Nefarious")) == "Nefarious Value"
    assert remove_values(["Nefarious","Nefarious Value","Nefarious"],("Nefarious","Nefarious Value")) == [None,None,None]
    assert remove_values([{"Nefarious":"Nefarious Value"},{"Nefarious":"Value","Nefarious Value":"Nefarious"},{"Nefarious":"Value"},{"Nefarious":"Value"}],"Nefarious") == [{None:"Nefarious Value"},{None:None,None:None},{None:"Value"},{None:"Value"}]

# Generated at 2022-06-11 01:23:58.226135
# Unit test for function remove_values
def test_remove_values():
    # Make sure remove_values is recursive
    no_log_strings = ['foo', 'bar']

    for exp_type in (list, dict, tuple, int, str, bool, type(None)):
        test_one_type(exp_type, no_log_strings)



# Generated at 2022-06-11 01:24:04.197742
# Unit test for function set_fallbacks

# Generated at 2022-06-11 01:24:11.704027
# Unit test for function set_fallbacks
def test_set_fallbacks():
    parameters = {}
    fallback_value = 'fallback'
    test_fallback = (lambda: fallback_value, )
    test_input_spec = dict(test_fallback=dict(fallback=test_fallback))
    test_fallback_no_log = (lambda: fallback_value, )
    parameters = {}
    test_input_spec_no_log = dict(test_fallback=dict(fallback=test_fallback_no_log, no_log=True))
    # If fallback is not set, then no_log_values should be None.
    no_log_values = set_fallbacks(test_input_spec, parameters)
    assert no_log_values == set()
    # If fallback is set, then no_log_values should be equal to fallback_value.
    no

# Generated at 2022-06-11 01:24:24.155704
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'name': {
                        'required': True,
                        'type': 'list'
                    },
                    'password': {
                        'required': True,
                        'type': 'str',
                        'no_log': True
                    },
                    'host': {
                        'required': False,
                        'type': 'list',
                        'elements': 'dict',
                        }
                    }

    parameters = {'name': 'thii'}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert no_log_values == set()

    parameters = {'name': 'thii', 'host': [{'name': 'test', 'ip': '10.10.1.1'}]}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert no

# Generated at 2022-06-11 01:24:36.030221
# Unit test for function sanitize_keys
def test_sanitize_keys():
    # Test if sanitize_keys will sanitize the keys of a dict recursively
    assert sanitize_keys({'a': 1, 'b': {'c': 'b', 'd': 3}}, ['b']) == {'a': 1, '**': {'**': 'b', 'd': 3}}
    # Test if sanitize_keys will sanitize the keys and the values of a dict recursively
    assert sanitize_keys({'a': 1, 'b': {'c': 'b', 'd': 3}}, ['b', '1']) == {'a': '*', '**': {'**': 'b', 'd': '*'}}
    # Test if sanitize_keys will ignore the keys with special prefix

# Generated at 2022-06-11 01:24:42.944613
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(test_param=dict(type='str', fallback=(env_fallback, ['TEST_PARAM'])))
    parameters = {}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert len(no_log_values) == 0
    assert len(parameters) == 1, 'No parameter was added'
    assert parameters['test_param'] == 'TEST_PARAM', 'Wrong default value was set'



# Generated at 2022-06-11 01:24:47.371521
# Unit test for function env_fallback
def test_env_fallback():
    # Test with no env var
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('ANSIBLE_TEST_NOT_EXISTING_VAR')

    # Test with env var existing
    assert env_fallback('PATH')



# Generated at 2022-06-11 01:25:16.182812
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_FALLBACK'] = 'SOME_STR'
    assert env_fallback('ANSIBLE_FALLBACK') == 'SOME_STR'
    os.environ['ANSIBLE_FALLBACK'] = '1'
    assert env_fallback('ANSIBLE_FALLBACK') == 1
    os.environ['ANSIBLE_FALLBACK'] = '0'
    assert env_fallback('ANSIBLE_FALLBACK') == 0
    os.environ['ANSIBLE_FALLBACK'] = 'True'
    assert env_fallback('ANSIBLE_FALLBACK') is True
    os.environ['ANSIBLE_FALLBACK'] = 'False'
    assert env_fallback('ANSIBLE_FALLBACK') is False

# Generated at 2022-06-11 01:25:19.763475
# Unit test for function env_fallback
def test_env_fallback():
    with patch.dict('os.environ', {'TEST_ENV_VAR': 'TEST'}):
        assert env_fallback('TEST_ENV_VAR') == 'TEST'



# Generated at 2022-06-11 01:25:30.437975
# Unit test for function set_fallbacks

# Generated at 2022-06-11 01:25:41.689606
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert not set_fallbacks({'a': {}}, {})
    assert not set_fallbacks({'a': {'fallback': None}}, {})
    assert not set_fallbacks({'a': {'fallback': (None,)}}, {})
    assert not set_fallbacks({'a': {'fallback': (None, 'a')}}, {})
    assert not set_fallbacks({'a': {'fallback': (env_fallback, 'a')}}, {})

    os.environ['A'] = '1'
    assert not set_fallbacks({'a': {'fallback': (env_fallback, 'b')}}, {'a': '2'})

# Generated at 2022-06-11 01:25:46.297292
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'foo': {'fallback': ('env_fallback', 'FOO_VAL', 'fallback')},
        'bar': {'fallback': ('env_fallback', 'BAR_VAL', 'fallback')},
    }
    parameters = {}
    set_fallbacks(argument_spec, parameters)
    assert parameters == {'foo': 'fallback', 'bar': 'fallback'}



# Generated at 2022-06-11 01:25:55.404767
# Unit test for function sanitize_keys
def test_sanitize_keys():
    obj = {'a': {'value': 'b'}, 'b': ['value', 'c', {'value': 'd'}], 'c': {'_ansible_foo': 'd'}}
    no_log_strings = ['value']
    ignore_keys = ['badkey']
    actual = icontains(sanitize_keys(obj, no_log_strings, ignore_keys), {'a': {'va*****': 'b'},
                                                                        'b': ['va*****', 'c', {'va*****': 'd'}],
                                                                        'c': {'_ansible_foo': 'd'}})
    assert actual == 'match'



# Generated at 2022-06-11 01:26:06.223562
# Unit test for function set_fallbacks
def test_set_fallbacks():
    '''Test setting fallback values'''


# Generated at 2022-06-11 01:26:14.527191
# Unit test for function env_fallback
def test_env_fallback():

    # Test that env_fallback exists and can be called
    assert callable(env_fallback)

    # Test that proper exception is raised for missing env variable
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('missing_var_name')

    # Test that a value is returned if the variable is found in the environment
    os.environ['test_var_name'] = 'test_var_value'
    assert env_fallback('test_var_name') == 'test_var_value'
    del os.environ['test_var_name']



# Generated at 2022-06-11 01:26:21.924756
# Unit test for function sanitize_keys
def test_sanitize_keys():
    values = {
        'foo': {
            'bar': {
                'baz': 'qux',
            },
        },
        'foo bar': [
            {
                'baz': 'qux',
            },
        ],
        'hello world': 'baz',
    }
    expected = {
        'foo': {
            'bar': {
                'baz': 'qux',
            },
        },
        'foo_bar': [
            {
                'baz': 'qux',
            },
        ],
        'hello_world': 'baz',
    }
    actual = sanitize_keys(values, [' '])
    assert actual == expected



# Generated at 2022-06-11 01:26:32.136111
# Unit test for function set_fallbacks

# Generated at 2022-06-11 01:27:02.766015
# Unit test for function env_fallback
def test_env_fallback():
    os.environ.pop('test_from_env', None)
    os.environ.pop('from_env', None)
    os.environ.pop('from_env_false', None)
    os.environ.pop('from_env_int', None)
    assert env_fallback('test_from_env') == 'from_env'
    os.environ.pop('from_env', None)
    os.environ.pop('from_env_true', None)
    os.environ.pop('from_env_false', None)
    os.environ.pop('from_env_int', None)



# Generated at 2022-06-11 01:27:13.894780
# Unit test for function sanitize_keys
def test_sanitize_keys():
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule


    def run_module():
        # define available arguments/parameters a user can pass to the module
        module_args = dict(
            name=dict(type='str', required=True),
            new=dict(type='bool', required=False, default=False),
        )

        result = dict(
            changed=False,
            original_message='',
            message='',
            ansible_facts=[]
        )

        module = AnsibleModule(
            argument_spec=module_args,
            supports_check_mode=True
        )

        if module.check_mode:
            return result

        result['original_message'] = module.params['name']
        result['message'] = 'goodbye'


# Generated at 2022-06-11 01:27:23.329437
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert set_fallbacks({'a': {'fallback': (env_fallback, 'ANSIBLE_A')}}, {}) == frozenset(['ANSIBLE_A'])
    assert set_fallbacks({'a': {'fallback': (env_fallback, ['ANSIBLE_A'])}}, {}) == frozenset(['ANSIBLE_A'])
    assert set_fallbacks({'a': {'fallback': (env_fallback, ['ANSIBLE_A'], {'default': 'a'})}}, {}) == frozenset(['a'])
    assert set_fallbacks({'b': {'fallback': (env_fallback, ['ANSIBLE_B'], {'default': 'b'}),
                                 'no_log': True}}, {}) == frozenset(['b'])


# Generated at 2022-06-11 01:27:28.060398
# Unit test for function env_fallback
def test_env_fallback():
    for key, val in (('HTTP_PROXY', 'http://foo.example.com'), ('http_proxy', 'http://bar.example.com')):
        os.environ[key] = val
        assert env_fallback('http_proxy') == val
        os.environ.pop(key, None)



# Generated at 2022-06-11 01:27:34.662704
# Unit test for function sanitize_keys
def test_sanitize_keys():
    obj = {
        'dict': {
            'with': {
                'value': 'hidden'
            }
        },
        'str': '1',
        'list': [1, 2, 3],
        'set': {1, 2, 3},
        'tuple': (1, 2, 3),
        'num': 1,
        'none': None,
        'bool': False,
        'ds': 'deeply_nested_string'
    }

# Generated at 2022-06-11 01:27:40.182639
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_FOO'] = 'bar'
    assert env_fallback('ANSIBLE_FOO') == 'bar'
    os.environ.pop('ANSIBLE_FOO')

    # Test that proper exception is thrown when value is not found
    try:
        env_fallback('ANSIBLE_FOO')
        raise AssertionError('Expected AnsibleFallbackNotFound')
    except AnsibleFallbackNotFound:
        pass
# end unit test



# Generated at 2022-06-11 01:27:48.540657
# Unit test for function set_fallbacks

# Generated at 2022-06-11 01:27:59.481567
# Unit test for function remove_values
def test_remove_values():
    """Unit test for remove_values"""

    assert remove_values("hello", ["hello"]) is None
    assert remove_values("hello", ["goodbye"]) == "hello"
    assert remove_values("hello", []) == "hello"

    assert remove_values("hello", ["hello"], True) == "********"
    assert remove_values("hello", ["goodbye"], True) == "hello"
    assert remove_values("hello", [], True) == "hello"

    assert remove_values(b"hello", [b"hello"]) is None
    assert remove_values(b"hello", [b"goodbye"]) == b"hello"
    assert remove_values(b"hello", []) == b"hello"

    assert remove_values(b"hello", [b"hello"], True) == b"********"
    assert remove_

# Generated at 2022-06-11 01:28:10.775098
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'param1': {
            'type': 'str',
            'required': True,
        },
        'param2': {
            'type': 'str',
            'required': True,
        },
        'param3': {
            'type': 'str',
            'required': True,
        },
        'param4': {
            'type': 'str',
            'required': True,
        },
    }
    parameters = {}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert not no_log_values
    assert parameters == {}

    parameters = {'param1': 'value1'}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert not no_log_values

# Generated at 2022-06-11 01:28:14.475097
# Unit test for function env_fallback
def test_env_fallback():
    try:
        assert env_fallback("ENV_TEST", "TEST_ENV") == "TEST"
    except AnsibleFallbackNotFound:
        pass
    return
test_env_fallback()



# Generated at 2022-06-11 01:28:46.780595
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert set_fallbacks(dict(a=dict(type='str', fallback=(env_fallback, 'TEST_A'))), dict()) == {'TEST_A'}
    assert set_fallbacks(dict(a=dict(type='str', fallback=(env_fallback, 'TEST_A'))), dict(a='b')) == set()
    assert set_fallbacks(dict(a=dict(type='dict', fallback=(lambda: dict(b=dict(c='d')),))), dict(a=dict(b=dict(c='e')))) == \
           set()

# Generated at 2022-06-11 01:28:57.030028
# Unit test for function sanitize_keys
def test_sanitize_keys():
    # Test for remove_values for Dictionary
    data = {"key1":"value1","key2":"value2","key3":"value3"}
    no_log_strings = ['value1']
    expected_result = {"key1":"value1", "key_2": "value2", "key_3": "value3"}
    actual_result=sanitize_keys(data, no_log_strings)
    assert actual_result == expected_result, "The function did not behave as expected"

    # Test for remove_values for List
    data = [{"key1":"value1","key2":"value2"}, {"key3":"value3"}]
    no_log_strings = ['value2']
    expected_result = [{"key1":"value1","key_2":"value2"}, {"key3":"value3"}]
    actual_result=san

# Generated at 2022-06-11 01:29:04.695984
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('not_in_env') == 'not_in_env'
    assert env_fallback('This is not in env') == 'This is not in env'
    os.environ['random_var_name'] = 'random_var_val'
    assert env_fallback('random_var_name') == 'random_var_val'
    assert env_fallback('random_var_name_not_exists', 'random_var_name') == 'random_var_val'
    assert env_fallback('random_var_name_not_exists', default='random_var_val') == 'random_var_val'

# Generated at 2022-06-11 01:29:09.623045
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('ANSIBLE_SSH_PASS') == 'sshpass'
    assert env_fallback('ANSIBLE_FOO') == 'bar'
    assert env_fallback('ANSIBLE_BAR') == 'baz'
    assert env_fallback('UNKNOWN') == ValueError
    assert env_fallback('UNKNOWN', 'UNKNOWN2') == ValueError
