

# Generated at 2022-06-11 01:20:01.254384
# Unit test for function set_fallbacks
def test_set_fallbacks():
    result = {}
    fallbacks = (
        ('skip_during_appliance_setup', {'type': 'bool', 'default': False, 'fallback': (env_fallback, ['ANSIBLE_SKIP_DURING_APPLIANCE_SETUP'], {'type': 'bool'})}),
        ('cowsay', {'type': 'bool', 'default': False, 'fallback': (env_fallback, ['ANSIBLE_COWSAY'])}),
    )
    spec = dict(fallbacks)
    no_log_values = set_fallbacks(spec, result)
    assert result['skip_during_appliance_setup'] == False
    assert result['cowsay'] == False
    assert len(no_log_values) == 1

# Generated at 2022-06-11 01:20:07.788747
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert set_fallbacks({'first_name': {'type': 'str', 'fallback': (env_fallback, 'FIRST_NAME')}},
                         {'last_name': 'Smith'}) == set()
    assert set_fallbacks({'first_name': {'type': 'str', 'fallback': (env_fallback, 'FIRST_NAME')}},
                         {}) == set(['Smithers'])



# Generated at 2022-06-11 01:20:18.233464
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert set_fallbacks({}, {'a': 'b', 'b': 'c'}) == set()
    assert set_fallbacks({'a': {'fallback': (lambda: 'd')}}, {'b': 'c'}) == {'d'}
    assert set_fallbacks({'a': {'fallback': (lambda: 'd')}}, {'a': 'b', 'b': 'c'}) == set()
    assert set_fallbacks({'a': {'_ansible_fallback': True}}, {'b': 'c'}) == {True}
    assert set_fallbacks({'a': {'fallback': (lambda: 'd'), 'no_log': True}}, {'b': 'c'}) == {'d'}

# Generated at 2022-06-11 01:20:25.850138
# Unit test for function set_fallbacks

# Generated at 2022-06-11 01:20:38.261163
# Unit test for function set_fallbacks

# Generated at 2022-06-11 01:20:47.609124
# Unit test for function set_fallbacks

# Generated at 2022-06-11 01:20:55.326033
# Unit test for function set_fallbacks

# Generated at 2022-06-11 01:21:06.832337
# Unit test for function set_fallbacks

# Generated at 2022-06-11 01:21:17.141404
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        param1=dict(fallback=(env_fallback, 'OTHER')),
        other=dict(fallback=(env_fallback, 'OTHER', dict(no_log=True))),
    )
    parameters = dict(param1='bad value')
    # Set a fake environment variable
    os.environ['OTHER'] = 'fallback value'
    no_log_values = set_fallbacks(argument_spec, parameters)

    assert parameters == dict(param1='fallback value', other='fallback value')
    assert no_log_values == set(['fallback value'])

    # Test fallback=None
    argument_spec = dict(
        param1=dict(fallback=None)
    )
    parameters = dict()
    os.environ['OTHER'] = 'fallback value'


# Generated at 2022-06-11 01:21:23.482128
# Unit test for function env_fallback
def test_env_fallback():
    with patch.object(os, 'environ', {'FOO': 'BAR'}):
        assert env_fallback('FOO') == 'BAR'
    with patch.object(os, 'environ', {'FOO': 'BAR'}):
        assert len(env_fallback('NOT_FOO'))
    with patch.object(os, 'environ', {}):
        assert len(env_fallback('NOT_FOO'))



# Generated at 2022-06-11 01:21:53.327941
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Test that valid fallback definitions work properly
    case1 = {'test_param': {'type': 'int', 'fallback': (lambda: 1,)}}
    case1_data = {}
    no_log_values = set_fallbacks(case1, case1_data)
    assert case1_data['test_param'] == 1
    assert len(no_log_values) == 0

    # Test that valid fallback with no_log set
    case2 = {'test_param': {'type': 'int', 'fallback': (lambda: 1,), 'no_log': True}}
    case2_data = {}
    no_log_values = set_fallbacks(case2, case2_data)
    assert case2_data['test_param'] == 1
    assert no_log_values == {1}

   

# Generated at 2022-06-11 01:22:03.388763
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(ansible_env=dict(type='str', fallback=(env_fallback, 'ANSIBLE_FOO')), ansible_string_env=dict(type='str', fallback=(env_fallback, 'ANSIBLE_BAR')), ansible_default=dict(type='str', default='d'), ansible_env_or_default=dict(type='str', default='d', fallback=(env_fallback, 'ANSIBLE_BAR')), ansible_env_or_required=dict(type='str', required=True, fallback=(env_fallback, 'ANSIBLE_BAR')))
    parameters = dict(ansible_default='m')
    no_log_values = set()
    no_log_values = set_fallbacks(argument_spec, parameters)

# Generated at 2022-06-11 01:22:14.025947
# Unit test for function remove_values
def test_remove_values():
    no_log_strings = ['123', '456']
    data = {
        'name': "data",
        'account': ['123', '456', '789'],
        'password':  ['123', '456', '789'],
        'info': {'account': '123', 'password': '456'},
        'nested': [{'account': '123', 'password': '456'}, {'account': '789', 'password': '012'}],
        'nested_dict': {'account': {'account': '123', 'password': '456'}, 'password': {'account': '789', 'password': '012'}}
    }

# Generated at 2022-06-11 01:22:18.304948
# Unit test for function sanitize_keys
def test_sanitize_keys():
  x = {'a' : 'b', 'b' : 'b'}
  y = sanitize_keys(x, ["b"], ignore_keys=frozenset(['a']))
  assert y == {'a' : 'b', '_sanitized_b' : 'b'}


# Generated at 2022-06-11 01:22:23.504913
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['TEST_ENV_VAR_1'] = '1'
    assert env_fallback('TEST_ENV_VAR_1') == '1'
    os.unsetenv('TEST_ENV_VAR_1')
    assert env_fallback('TEST_ENV_VAR_1') == '1'



# Generated at 2022-06-11 01:22:27.220804
# Unit test for function env_fallback
def test_env_fallback():
    with patch.dict(os.environ, {'foo': 'bar'}):
        assert env_fallback('foo') == 'bar'
        assert env_fallback('bar') is None
        assert env_fallback('bar', 'foo') == 'bar'



# Generated at 2022-06-11 01:22:35.397976
# Unit test for function set_fallbacks
def test_set_fallbacks():
    params = {}
    args = (env_fallback, 'TEST_ENV_VAR')
    spec = {'param_env': {'fallback': args}}
    no_log_values = set_fallbacks(spec, params)
    assert params['param_env'] == os.environ['TEST_ENV_VAR']
    assert no_log_values == set()

    params = {}
    os.environ['TEST_ENV_VAR'] = ''
    args = (env_fallback, 'TEST_ENV_VAR')
    spec = {'param_env': {'fallback': args}}
    no_log_values = set_fallbacks(spec, params)
    assert params['param_env'] == ''
    assert no_log_values == set()

    params = {}
   

# Generated at 2022-06-11 01:22:46.962852
# Unit test for function set_fallbacks
def test_set_fallbacks():
    '''
    Unit test for set_fallbacks
    '''
    argument_spec = {
        'name': {
            'type': 'str',
            'required': True
        },
        'state': {
            'type': 'str',
            'default': 'present'
        },
        'container_id': {
            'type': 'str',
            'required': True,
            'fallback': (env_fallback, ['CONTAINER_ID'])
        },
        'password': {
            'type': 'str',
            'no_log': True,
            'fallback': (env_fallback, ['PASSWORD'])
        }
    }

    parameters = {
        'name': 'ansible',
        'state': 'present',
        'container_id': '123'
    }

# Generated at 2022-06-11 01:22:57.640666
# Unit test for function set_fallbacks
def test_set_fallbacks():

    argument_spec = {"a": {"required": False, "type": "int", "fallback": (env_fallback, "a")}}
    parameters = {}
    os.environ['a'] = "6"
    set_fallbacks(argument_spec, parameters)
    assert parameters == {"a": 6}

    try:
        parameters = {}
        set_fallbacks(argument_spec, parameters)
    except Exception as e:
        assert str(e) == "AnsibleFallbackNotFound"
    else:
        assert parameters == {}

    argument_spec = {"a": {"required": False, "type": "int", "fallback": (env_fallback, ["a", "b"])}}
    parameters = {}
    os.environ['a'] = "6"
    set_fallbacks(argument_spec, parameters)

# Generated at 2022-06-11 01:23:06.649203
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert set_fallbacks({'a': {'type': 'str'}}, {}) == set()
    assert set_fallbacks({'a': {'type': 'str', 'fallback': (env_fallback, 'A')}}, {}) == set(['A'])
    assert set_fallbacks({'a': {'type': 'str', 'fallback': (env_fallback, ['A'])}}, {}) == set(['A'])
    assert set_fallbacks({'a': {'type': 'str', 'fallback': (env_fallback, 'A', 'B')}}, {}) == set(['A'])

# Generated at 2022-06-11 01:23:36.436881
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Test basic functionality
    argument_spec = {
        'test1': {'type': 'str', 'fallback': (env_fallback, ['ANSIBLE_TEST1'])},
        'test2': {'type': 'str', 'fallback': (env_fallback, ['ANSIBLE_TEST2'])},
        'test3': {'type': 'str', 'fallback': (env_fallback, ['ANSIBLE_TEST3'])},
    }
    parameters = {}
    os.environ['ANSIBLE_TEST1'] = 'test1'
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters == {'test1': 'test1'}
    assert no_log_values == set()

    # Test function 'env_fallback'
    parameters = {}

# Generated at 2022-06-11 01:23:47.713424
# Unit test for function env_fallback
def test_env_fallback():
    """Unit test for function env_fallback"""
    test_fallbacks_passed = {
        'FOO': 'FOO',
        'BAR': 'BAR',
        'BAZ': 'BAZ'
    }
    test_fallbacks_failed = ['FOO', 'BAR', 'BAZ']
    test_fallbacks_res = {
        'FOO': 'FOO',
        'BAR': 'BAR',
        'BAZ': 'BAZ'
    }
    with mock.patch("os.environ", test_fallbacks_passed):
        assert env_fallback(*test_fallbacks_passed) == test_fallbacks_res
        test_fallbacks_passed_2 = ['BAZ', 'BAR', 'FOO']

# Generated at 2022-06-11 01:23:58.103757
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        env_param=dict(
            type='str', fallback=(env_fallback, ['ENV_PARAM'])),
        env_param_arg=dict(
            type='str', fallback=(env_fallback, ['ENV_PARAM_ARG'], dict(fallback_var='default'))),
    )
    parameters = {}
    result = set_fallbacks(argument_spec, parameters)
    assert result == set()
    assert parameters == {}

    os.environ['ENV_PARAM'] = 'environment value of env param'
    os.environ['ENV_PARAM_ARG'] = 'environment value of env param arg'

    result = set_fallbacks(argument_spec, parameters)
    assert result == set()

# Generated at 2022-06-11 01:23:59.636611
# Unit test for function set_fallbacks
def test_set_fallbacks():
    result = set_fallbacks({'b': {'fallback': (env_fallback, 'FOO')}}, {})
    assert 'FOO' in result



# Generated at 2022-06-11 01:24:01.723053
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('_') == os.environ['_']
    try:
        env_fallback()
    except AnsibleFallbackNotFound:
        pass
    else:
        assert False, 'Expected exception not raised'



# Generated at 2022-06-11 01:24:08.054136
# Unit test for function set_fallbacks

# Generated at 2022-06-11 01:24:19.553616
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        param1=dict(fallback=(env_fallback, 'ANSIBLE_PARAM1')),
        param2=dict(fallback=(env_fallback, 'ANSIBLE_PARAM2')),
        param3=dict(fallback=(env_fallback, 'ANSIBLE_PARAM3')),
        param4=dict(fallback=(env_fallback, 'ANSIBLE_PARAM4'), no_log=True),
        param5=dict(fallback=(env_fallback, 'ANSIBLE_PARAM5'), no_log=True),
    )
    parameters = {}
    expected_no_log_values = set()
    set_fallbacks(argument_spec, parameters)
    assert expected_no_log_values == set()
    assert parameters == {}


# Generated at 2022-06-11 01:24:31.106168
# Unit test for function remove_values
def test_remove_values():
    '''
    Test the remove values function in a very simple manner.
    '''
    assert remove_values('this-is-a-secret', ['secret']) == 'this-is-a-'
    assert remove_values('this-is-a-secret', ['secret', 'this']) == '-is-a-'
    assert remove_values('this-is-a-seecret', ['secret', 'this']) == '-is-a-seecret'
    assert remove_values('this-is-a-seecret', ['secret', 'this', '-']) == 'thisisaseecret'
    assert remove_values(None, ['secret', 'this', '-']) is None
    assert remove_values(False, ['secret', 'this', '-']) is False

# Generated at 2022-06-11 01:24:42.480420
# Unit test for function sanitize_keys
def test_sanitize_keys():
    from ansible.module_utils.common.text.converters import to_bytes
    if PY2:
        assert sanitize_keys(to_bytes({'a': 'value', 'b': 'value'}), set(['a', 'b'])) == to_bytes({'_ansible_no_log_a': 'value', '_ansible_no_log_b': 'value'})
    else:
        assert sanitize_keys({'a': 'value', 'b': 'value'}, set(['a', 'b'])) == {'_ansible_no_log_a': 'value', '_ansible_no_log_b': 'value'}

# Generated at 2022-06-11 01:24:53.000993
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert set_fallbacks({'ansible_port': {'fallback': (env_fallback, 'ANSIBLE_PORT')}}, {}) == set()
    assert set_fallbacks({'ansible_port': {'fallback': (env_fallback, 'ANSIBLE_PORT')}}, {'ansible_port': 22}) == set()
    assert set_fallbacks({'ansible_port': {'fallback': (env_fallback, 'ANSIBLE_PORT')}}, {'ansible_port': 22}) == set()
    assert set_fallbacks({'ansible_port': {'fallback': (env_fallback, 'ANSIBLE_PORT')}}, {}) == set()

# Generated at 2022-06-11 01:25:27.855386
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'name': {'required': True, 'type': 'list', 'elements': 'str'},
        'password': {'required': True, 'type': 'str', 'no_log': True, 'fallback': (env_fallback, ['ANSIBLE_NET_PASSWORD'])},
    }
    parameters = {
        'name': ['foo', 'bar', 'baz'],
        'password': None,
    }
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['password'] == os.environ['ANSIBLE_NET_PASSWORD']
    assert no_log_values



# Generated at 2022-06-11 01:25:31.881439
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'foo': {'fallback': (env_fallback, 'FOO', 'BAR')}}
    parameters = {'zoo': True}
    parameters_with_fallback = {'foo': os.environ['FOO'], 'zoo': True}

    assert set_fallbacks(argument_spec, parameters) == set()
    assert parameters == parameters_with_fallback



# Generated at 2022-06-11 01:25:36.078541
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'supercede': {'fallback': (env_fallback, {'env': 'MY_ENV'})}}
    parameters = {}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert not no_log_values



# Generated at 2022-06-11 01:25:44.865234
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argumentspec = {
        "parameter1": {
            "type": "str",
            "fallback": (env_fallback, ['FOO']),
        },
        "parameter2": {
            "type": "str",
            "default": 'bar',
        },
        "parameter3": {
            "type": "str",
            "fallback": (env_fallback, ['BAR', {'key': 'val'}]),
        },
    }
    parameters = {"parameter2": True}
    os.environ['FOO'] = 'foo'
    os.environ['BAR'] = 'bar'

    no_log_values = set_fallbacks(argumentspec, parameters)
    assert 'foo' in parameters
    assert 'bar' not in parameters
    assert parameters['parameter2']

# Generated at 2022-06-11 01:25:55.216846
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'foo': {'type': 'str', 'fallback': (env_fallback, 'FOO_ENV_VAR')}}
    parameters = {}
    assert set(set_fallbacks(argument_spec, parameters)) == set()

    parameters = {}
    os.environ['FOO_ENV_VAR'] = 'foo'
    assert set(set_fallbacks(argument_spec, parameters)) == set()
    assert parameters['foo'] == 'foo'

    argument_spec = {'foo': {'type': 'int', 'fallback': (env_fallback, 'FOO_ENV_VAR')}}
    parameters = {}
    assert set(set_fallbacks(argument_spec, parameters)) == set()

    os.environ['FOO_ENV_VAR'] = '1'


# Generated at 2022-06-11 01:26:05.975058
# Unit test for function remove_values
def test_remove_values():
    from .unit.utils.dictdiffer import DictDiffer
    from .unit.utils.ansible_module_runner import AnsibleModuleRunner

    def test_remove_values(value, no_log_strings, expected):
        runner = AnsibleModuleRunner(dict(ANSIBLE_MODULE_ARGS=dict(
            value=value,
            no_log_strings=no_log_strings,
        )))
        runner.run('core/remove_values.py', 'remove_values', task_vars=dict())
        assert runner.json_output == expected

    test_remove_values(dict(a='users', b='pass'), 'pass', dict(a='users', b='*****'))
    test_remove_values(dict(a='users', b='pass'), 'pass', dict(a='users', b='*****'))


# Generated at 2022-06-11 01:26:16.532773
# Unit test for function set_fallbacks
def test_set_fallbacks():
    case = dict(
        argument_spec=dict(
            param1=dict(required=True, fallback=(env_fallback, ['param1', 'alt_param1'],)),
            param2=dict(fallback=(env_fallback, ['param2', 'alt_param2'],)),
            param3=dict(fallback=(env_fallback, ['param3', 'alt_param3'], {'fallback_name': 'alt_param3'})),
        ),
        parameters=dict(
            param1='test'
        ),
        expected_no_log_values=set(),
        expected_parameters=dict(
            param1='test',
            param2=None,
            param3=None,
        ),
    )
    os.environ['param1'] = 'from_env'

# Generated at 2022-06-11 01:26:17.811847
# Unit test for function set_fallbacks
def test_set_fallbacks():
    _set_fallbacks(ARGUMENT_SPEC, {})



# Generated at 2022-06-11 01:26:24.457130
# Unit test for function set_fallbacks
def test_set_fallbacks():

    argument_spec = dict(
        param1=dict(
            type='str',
            fallback=(env_fallback, ('ANSIBLE_PARAM', 'ANSIBLE_PARAM1'))
        ),
        param2=dict(
            type='dict',
            fallback=(env_fallback, ('ANSIBLE_PARAM2',))
        )
    )
    parameters = dict(param1='value1')
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['param2'] == os.environ['ANSIBLE_PARAM2']
    assert no_log_values == set()



# Generated at 2022-06-11 01:26:32.267573
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert False
    # test that values in argument_spec are being set to parameters
    assert False
    # test that the 'no_log' value is being added to no_log_values
    assert False
    # test that when the fallback import can't be found, the default value is used
    assert False
    # test that when the fallback error occurs, the default value is used
    assert False
    # test that when the fallback_strategy is none, the default value is used
    assert False
    # test that all fallbacks are tested, not just the first one
    assert False



# Generated at 2022-06-11 01:27:08.195494
# Unit test for function set_fallbacks

# Generated at 2022-06-11 01:27:19.105437
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {}
    params = {}
    no_log_values = set()

    params = {
        'username': 'user',
        'password': 'pw'
    }
    expected = {
        'username': 'user',
        'password': 'pw'
    }
    argument_spec = {
        'username': {'type': 'str'},
        'password': {'type': 'str', 'no_log': True}
    }
    set_fallbacks(argument_spec, params)
    assert params == expected, "arg_spec became: %s" % argument_spec


# Generated at 2022-06-11 01:27:27.158468
# Unit test for function set_fallbacks
def test_set_fallbacks():
    """Test set_fallbacks"""

    argument_spec = dict(
        scalar_value=dict(type='str', fallback=(env_fallback, 'SCALAR_VALUE'))
    )

    module_params = dict()
    os.environ['SCALAR_VALUE'] = 'scalar_value'
    no_log_values = set_fallbacks(argument_spec, module_params)
    os.environ.pop('SCALAR_VALUE')
    assert len(no_log_values) == 0
    assert module_params['scalar_value'] == 'scalar_value'



# Generated at 2022-06-11 01:27:35.558839
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'param1': {'type': 'bool'},
        'param2': {'type': 'string'},
        'param3': {'type': 'string', 'fallback': (env_fallback, 'ANSIBLE_TEST_PARAM3')},
    }
    parameters = {}
    os.environ['ANSIBLE_TEST_PARAM3'] = 'test'
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['param1'] is False
    assert parameters['param2'] == ''
    assert parameters['param3'] == 'test'
    assert no_log_values == set()

    parameters = {}
    os.environ['ANSIBLE_TEST_PARAM3'] = 'test'
    parameter_spec = deepcopy(argument_spec)

# Generated at 2022-06-11 01:27:43.839975
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(foo=dict(type='int', fallback=(42,)))
    assert set_fallbacks(argument_spec, dict()) == set()
    assert set_fallbacks(argument_spec, dict(foo=123)) == set()
    assert set_fallbacks(argument_spec, dict(foo=123, bar=42)) == set()
    assert set_fallbacks(argument_spec, dict(bar=42)) == {42}

    argument_spec = dict(foo=dict(type='str', fallback=('dummy value',)))
    assert set_fallbacks(argument_spec, dict()) == set()
    assert set_fallbacks(argument_spec, dict(foo='test value')) == set()
    assert set_fallbacks(argument_spec, dict(foo='test value', bar=42)) == set()
   

# Generated at 2022-06-11 01:27:51.644619
# Unit test for function set_fallbacks
def test_set_fallbacks():
    '''
    This is a unit test for the set_fallbacks method.
    '''
    param_dict, no_log_values = {}, set()
    param_dict['first'] = 'First'
    param_dict['second'] = 'Second'
    param_dict['third'] = 'Third'

    no_log_values.update(set_fallbacks(param_spec, param_dict))

    assert param_dict['first'] == 'First'
    assert param_dict['second'] == env_fallback('SECOND')
    assert param_dict['third'] == 'Third'

    assert len(no_log_values) == 1



# Generated at 2022-06-11 01:28:03.255182
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'name': {
            'type': 'str',
            'required': True,
            'fallback': (env_fallback, ['ANSIBLE_NET_USERNAME'])
        },
        'password': {
            'type': 'str',
            'required': True,
            'no_log': True,
            'fallback': (env_fallback, ['ANSIBLE_NET_PASSWORD'])
        },
        'port': {
            'type': 'int',
            'default': 22,
            'fallback': (env_fallback, ['ANSIBLE_NET_PORT'])
        }
    }

    parameters = {}

    set_fallbacks(argument_spec, parameters)

    assert parameters.get('name') == os.environ['ANSIBLE_NET_USERNAME']
   

# Generated at 2022-06-11 01:28:13.318595
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys({'k1': 'v1', 'k2': 'v2'}, set()) == {'k1': 'v1', 'k2': 'v2'}
    assert sanitize_keys({'k1': 'v1', 'k2': 'v2'}, {'v2'}) == {'k1': 'v1', 'k2_': 'v2'}
    assert sanitize_keys({'k1': 'v1', 'k2': 'v2', 'k3': {'k4': 'v4'}}, {'v2', 'v4'}) == {'k1': 'v1', 'k2_': 'v2', 'k3': {'k4_': 'v4'}}

# Generated at 2022-06-11 01:28:24.602209
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'foo': {'type': 'string', 'fallback': (env_fallback, ['FOO'])}}

    parameters = {}
    os.environ['FOO'] = 'bar'
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['foo'] == 'bar'
    assert no_log_values == set()

    parameters = {}
    os.environ['FOO'] = 'bar'
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['foo'] == 'bar'
    assert no_log_values == set()

    os.environ['FOO'] = 'bar'

# Generated at 2022-06-11 01:28:34.195812
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'myarg': {'type': 'int', 'fallback': (env_fallback, [], {'var': 'MYARG'})}}
    parameters = {}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['myarg'] == 0
    assert no_log_values == set()

    parameters = {'myarg': 0}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['myarg'] == 0
    assert no_log_values == set()

    parameters = {'myarg': None}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['myarg'] == 0
    assert no_log_values == set()


# Generated at 2022-06-11 01:29:06.981434
# Unit test for function set_fallbacks
def test_set_fallbacks():
    """Unit test for set_fallbacks"""

    # Test basic fallback
    argument_spec = dict(
        param1=dict(type='str', fallback=(env_fallback, 'TEST_ENVVAR_1')),
        param2=dict(type='str', fallback=(env_fallback, 'TEST_ENVVAR_2')),
        param3=dict(type='str', fallback=(env_fallback, 'TEST_ENVVAR_3')),
        param4=dict(type='str', fallback=(env_fallback, 'TEST_ENVVAR_4')),
        param5=dict(type='str', fallback=(env_fallback, ['TEST_ENVVAR_5_1', 'TEST_ENVVAR_5_2'])),
    )