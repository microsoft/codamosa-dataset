

# Generated at 2022-06-11 01:19:40.962487
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec_test = {'test_param': dict(required=False, type='str', fallback=(env_fallback, 'TEST_PARAM'))}
    parameters_test = {}
    os.environ['TEST_PARAM'] = 'test_param_value'
    no_log_values = set_fallbacks(argument_spec_test, parameters_test)
    assert parameters_test['test_param'] == 'test_param_value'
    assert 'test_param_value' in no_log_values
    argument_spec_test_2 = {'test_param': dict(required=False, type='str', fallback=(env_fallback, 'TEST_PARAM_VALUE'))}
    parameters_test_2 = {}

# Generated at 2022-06-11 01:19:53.081995
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert set_fallbacks({'test_int': {'type': 'int', 'fallback': (env_fallback, 'TEST_INT_VALUE')}}, {'test_int2': 2}) == set()
    assert set_fallbacks({'test_int': {'type': 'int', 'fallback': (env_fallback, 'TEST_INT_VALUE')}}, {}) == {'111'}
    assert set_fallbacks({'test_int': {'type': 'int', 'fallback': (env_fallback, 'TEST_INT_VALUE')}}, {'test_int': 1}) == set()

# Generated at 2022-06-11 01:20:03.903287
# Unit test for function set_fallbacks
def test_set_fallbacks():
    spec = dict(
        default_from_env=dict(type='str', fallback=(env_fallback, 'ANOTHER_ENV_VAR')),
        default_from_fallback=dict(type='str', fallback=(lambda: 'HELLO WORLD!')),
        default_from_fallback_args=dict(type='str', fallback=(lambda a=None, b=None: a or b, 'HELLO world!', 'hello world2!')),
        default_kwarg_from_env=dict(type='str', fallback=(env_fallback, dict(varname='YET_ANOTHER_ENV_VAR'))),
    )
    params = dict(
        default_from_env='default_value',
        not_in_spec='not in spec',
    )
    out_params

# Generated at 2022-06-11 01:20:12.870879
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'one': {'type': 'str', 'fallback': (env_fallback, ['ONE'])},
        'two': {'type': 'str', 'fallback': (env_fallback,)},
        'three': {'type': 'str', 'fallback': (env_fallback, ['THREE'], {'optional': True})},
        'six': {'type': 'str', 'fallback': (env_fallback, ['SIX'], {'optional': True})},
    }
    parameters = {
        'one': '1',
        'two': '2',
        'four': '4',
        'five': '5',
    }
    # With the following environment
    os.environ['ONE'] = '1e'

# Generated at 2022-06-11 01:20:18.873398
# Unit test for function env_fallback
def test_env_fallback():
    # Arrange
    args = ['MY_PARAM']
    os.environ['MY_PARAM'] = '1234'

    # Act
    result = env_fallback(*args)

    # Assert
    assert result == os.environ['MY_PARAM']
    assert result == '1234'

# Add our own fallback mechanism to the list of fallback mechanisms
_add_fallback(env_fallback)



# Generated at 2022-06-11 01:20:29.333067
# Unit test for function remove_values
def test_remove_values():
    assert remove_values('hello world', ['hello']) == 'hello world'
    assert remove_values([['hello world']], ['hello']) == [['hello world']]

    assert remove_values('hello world', ['hello', 'world']) is None
    assert remove_values(u'hello world', ['hello', 'world']) is None
    assert remove_values([['hello world']], ['hello', 'world']) == [[None]]
    assert remove_values(['hello', 'world'], ['hello', 'world']) == [None, None]

    assert remove_values({'hello': 'world', 'foo': 'bar'}, ['hello', 'world']) == {'foo': 'bar'}

# Generated at 2022-06-11 01:20:39.142330
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'param1': dict(required=False, type='dict'),
                     'param2': dict(required=True, fallback=(env_fallback, 'FOO'))}
    params = {'param1': {'key1': 'value1'}}
    os.environ['FOO'] = 'bar'
    no_log_values = set_fallbacks(argument_spec, params)
    assert set(params.keys()) == set(['param1', 'param2'])
    assert params['param2'] == 'bar'
    assert no_log_values == set()
    del os.environ['FOO']



# Generated at 2022-06-11 01:20:48.317772
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        foo=dict(type='str', fallback=(env_fallback, 'ANSIBLE_TEST_FOO')),
        bar=dict(type='str', fallback=(env_fallback, 'ANSIBLE_TEST_BAR', 'ANSIBLE_TEST_BAZ')),
        baz=dict(type='str', fallback=(env_fallback, 'ANSIBLE_TEST_BAZ1', 'ANSIBLE_TEST_BAZ2')),
        no_log=dict(type='str', fallback=(env_fallback, 'ANSIBLE_NO_LOG'), no_log=True),
        missing_no_log=dict(type='str', fallback=(env_fallback, 'ANSIBLE_MISSING_NO_LOG'), no_log=True)
    )

    parameters = dict

# Generated at 2022-06-11 01:20:56.717018
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        key1=dict(type='str', fallback=(env_fallback, 'ANSIBLE_TEST_KEY1')),
        key2=dict(type='str', fallback=(env_fallback, 'ANSIBLE_TEST_KEY2', dict(fail_on_missing=True))),
        key3=dict(type='str', fallback=(env_fallback, 'ANSIBLE_TEST_KEY3', dict(fail_on_missing=False))),
    )
    parameters = dict(key3='basevalue')
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['key1'] == 'value1'
    assert parameters['key2'] == 'value2'
    assert parameters['key3'] == 'basevalue'

# Generated at 2022-06-11 01:21:07.523382
# Unit test for function set_fallbacks
def test_set_fallbacks():
    TEST_ARG_SPEC = dict(
        param1=dict(
            type='dict',
            fallback=(env_fallback, ['TEST_FILE']),
            default={'key1': 'value1'},
            options=dict(
                sub1=dict(
                    type='str',
                    default='test')
            )
        ),
        param2=dict(
            fallback=(env_fallback, ['TEST_FILE']),
            type='str',
            default='test'),
        param3=dict(
            type='str',
            fallback=(env_fallback, ['TEST_FILE']),
            no_log=True),
        param4=dict(
            type='str',
            fallback=(env_fallback, ['TEST_FILE']),
            default='test')
    )

   

# Generated at 2022-06-11 01:21:42.165446
# Unit test for function set_fallbacks
def test_set_fallbacks():

    argument_spec = {'foo': {'type': 'int', 'fallback': (env_fallback, 'TEST_FOO')},
                     'bar': {'type': 'list', 'fallback': (env_fallback, 'TEST_BAR')},
                     'baz': {'type': 'str', 'fallback': (env_fallback, 'TEST_BAZ')},
                     'qux': {'type': 'bool', 'fallback': (env_fallback, 'TEST_QUX')},
                     'quux': {'type': 'list', 'fallback': (env_fallback, 'TEST_QUUX')}}
    parameters = {}

    os.environ['TEST_FOO'] = '1'

# Generated at 2022-06-11 01:21:51.912323
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Setup a dict for test
    argument_spec = {'fallback': {'type': 'dict', 'options': {'strategy': {'type': 'str', 'default': 'env_fallback',
                                                                           'choices': ['env_fallback']},
                                                              'args': {'type': 'list', 'elements': 'str'},
                                                              'kwargs': {'type': 'dict'},
                                                              },
                                                              'fallback': (env_fallback, ['not_existing_env'])}
                    }
    parameters = {'fallback': None}
    no_log_values = set_fallbacks(argument_spec['fallback']['options'], parameters)
    assert (len(no_log_values) == 0)

    # Raise AnsibleFall

# Generated at 2022-06-11 01:21:55.037693
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys({"a": b2a_qp('value1'), "b": b2a_qp('value2')}, ['value2']) == {'a': 'value1', 'b': 'VALUE_HIDDEN'}



# Generated at 2022-06-11 01:22:06.106905
# Unit test for function set_fallbacks
def test_set_fallbacks():
    """Validate set_fallbacks function"""
    from ansible.executor.task_result import TaskResult

    mask_no_log_value = '**********'
    task_result = TaskResult(result=dict(invocation=dict(module_args=dict())))
    result = dict()

# Generated at 2022-06-11 01:22:15.413152
# Unit test for function set_fallbacks

# Generated at 2022-06-11 01:22:25.962223
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'param': {'type': 'str', 'required': True, 'fallback': (env_fallback, 'ANSIBLE_TEST')},
        'param2': {'type': 'str', 'required': True, 'fallback': (env_fallback, 'ANSIBLE_TEST2')},
        'param3': {'type': 'str', 'required': True, 'fallback': (env_fallback, 'ANSIBLE_TEST3'), 'no_log': True},
    }
    parameters = {}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters == {'param3': 'test3'}
    assert no_log_values == {'test3'}
    assert len(parameters) == 1
    assert len(no_log_values)

# Generated at 2022-06-11 01:22:34.040803
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Test the fallback for env vars
    assert set_fallbacks({'a': {'type': 'str', 'fallback': (env_fallback, 'TEST_VAR')}}, {}) == set()
    argument_spec = {'a': {'type': 'str', 'fallback': (env_fallback, 'TEST_VAR')}}
    assert set_fallbacks(argument_spec, {}) == set(os.environ.get('TEST_VAR'))
    with patch.dict('os.environ', clear=True):
        assert set_fallbacks(argument_spec, {}) == set()
        assert set_fallbacks(argument_spec, {'a': 'test'}) == set()



# Generated at 2022-06-11 01:22:38.154437
# Unit test for function env_fallback
def test_env_fallback():
    with mock.patch.dict(os.environ, {'FOO': 'bar'}):
        assert env_fallback('FOO') == 'bar'

    assert env_fallback('FOOBAR') is None



# Generated at 2022-06-11 01:22:41.587480
# Unit test for function env_fallback
def test_env_fallback():
    with patch.dict(os.environ, {'ANSIBLE_STRING': 'baz'}):
        assert env_fallback('ANSIBLE_STRING') == 'baz'



# Generated at 2022-06-11 01:22:50.903289
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(test_arg=dict(fallback=(env_fallback, 'TEST_ARG_FALLBACK')))
    parameters = dict()
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert not no_log_values
    assert 'test_arg' in parameters
    assert parameters['test_arg'] == 'TEST_ARG_FALLBACK'
    os.environ.clear()

    # Test no_log behavior
    argument_spec = dict(test_arg=dict(fallback=(env_fallback, 'TEST_ARG_FALLBACK'), no_log=True))
    parameters = dict()
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert 'TEST_ARG_FALLBACK' in no_log_values

# Generated at 2022-06-11 01:23:34.277165
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['A'] = 'fallback'
    assert env_fallback('A') == 'fallback'
    del os.environ['A']
    try:
        env_fallback('B')
        raise AssertionError('We should not get here')
    except AnsibleFallbackNotFound:
        pass


# Generated at 2022-06-11 01:23:44.749970
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'key_1': {'type': 'str', 'fallback': (env_fallback, 'KEY_1')}, 'key_2': {'type': 'str', 'fallback': (env_fallback, 'KEY_2')}}
    parameters = {'key_1': 'value_1'}
    assert set_fallbacks(argument_spec, parameters) == set()
    assert parameters == {'key_1': 'value_1'}
    parameters = {'key_1': 'value_1', 'key_2': 'value_2'}
    assert set_fallbacks(argument_spec, parameters) == set()
    assert parameters == {'key_1': 'value_1', 'key_2': 'value_2'}

# Generated at 2022-06-11 01:23:55.809427
# Unit test for function set_fallbacks
def test_set_fallbacks():

    # Test by setting parameter explicitly
    argument_spec = {'param1': {'type': 'str', 'fallback': (env_fallback, ['ANSIBLE_TEST_FALLBACK_ENV'])}}
    parameters = {'param1': 'foo'}
    assert set_fallbacks(argument_spec, parameters) == set()
    assert parameters == {'param1': 'foo'}

    # Test by setting default explicitly
    argument_spec = {'param1': {'type': 'str', 'fallback': (env_fallback, ['ANSIBLE_TEST_FALLBACK_ENV'])}}
    parameters = {}
    assert set_fallbacks(argument_spec, parameters) == set()
    assert parameters == {}

    # Test by setting default explicitly with no_log

# Generated at 2022-06-11 01:24:01.057488
# Unit test for function set_fallbacks

# Generated at 2022-06-11 01:24:07.391701
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert set_fallbacks({}, {}) == set()
    assert set_fallbacks({'a': {'fallback': (None,), 'type': 'str'}}, {}) == set()
    assert set_fallbacks({'a': {'fallback': (env_fallback, 'A'), 'type': 'str'}}, {}) == set('FALLBACK')
    assert set_fallbacks({'a': {'fallback': (env_fallback, 'A'), 'type': 'str'}}, {'a': 'fallback'}) == set('FALLBACK')
    assert set_fallbacks({'a': {'fallback': (env_fallback, 'A'), 'type': 'list'}}, {'a': ['fallback']}) == set('FALLBACK')

# Generated at 2022-06-11 01:24:18.486099
# Unit test for function set_fallbacks
def test_set_fallbacks():

    case1_argument_spec = {
        'param1': dict(type='int', fallback=(42,)),
        'param2': dict(type='int', fallback=(42,)),
        'param3': dict(type='int', fallback=(42,)),
        'param4': dict(type='int', fallback=(42,)),
        'param5': dict(type='int', fallback=(42,)),
        'param6': dict(type='int', fallback=(42,)),
        'param7': dict(type='int', fallback=(42,)),
        'param8': dict(type='int', fallback=(42,)),
        'param9': dict(type='int', fallback=(42,)),
        'param10': dict(type='int', fallback=(42,)),
    }

    case1_parameters

# Generated at 2022-06-11 01:24:29.986901
# Unit test for function set_fallbacks
def test_set_fallbacks():
    spec = {'param_1': {'type': 'str', 'default': 'Default 1', 'fallback': (env_fallback, 'ANSIBLE_PARAM1')},
            'param_2': {'type': 'str', 'default': 'Default 2', 'fallback': (env_fallback, 'ANSIBLE_PARAM2')},
            'param_3': {'type': 'str', 'default': 'Default 3', 'fallback': (env_fallback, 'ANSIBLE_PARAM3')},
            }
    test_parameters = {'param_2': 'Test 2'}
    # Test with empty parameters
    new_parameters = {}
    no_log_values = set_fallbacks(spec, new_parameters)

# Generated at 2022-06-11 01:24:40.654678
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'param1': {'type': 'bool', 'required': True, 'fallback': (env_fallback, ['PARAM1'])},
                     'param2': {'type': 'bool', 'required': True, 'fallback': (env_fallback, ['ANSIBLE_PARAM2'])}}
    parameters = {}
    os.environ['PARAM1'] = 'yes'
    os.environ['ANSIBLE_PARAM2'] = 'yes'

    set_fallbacks(argument_spec, parameters)
    assert parameters['param1'] == 'yes'
    assert parameters['param2'] == 'yes'

    del os.environ['PARAM1']
    del os.environ['ANSIBLE_PARAM2']



# Generated at 2022-06-11 01:24:51.889928
# Unit test for function set_fallbacks

# Generated at 2022-06-11 01:25:00.919609
# Unit test for function set_fallbacks
def test_set_fallbacks():
    spec = {
        'param1': dict(type='str', fallback=(env_fallback, ['TEST_PARAM1', 'TEST_PARAM2'])),
        'param2': dict(type='str', fallback=(env_fallback, 'TEST_PARAM3'))
    }
    assert set_fallbacks(spec, {}) == set()

    os.environ['TEST_PARAM1'] = 'Hi'
    assert set_fallbacks(spec, {}) == set(['Hi'])

    assert set_fallbacks(spec, {'param1': 'Bye'}) == set()



# Generated at 2022-06-11 01:25:27.510327
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_FOO'] = 'bar'
    os.environ['ANSIBLE_BAZ'] = 'quux'
    # Check that the fallback works
    assert env_fallback('ANSIBLE_FOO') == 'bar'
    # Check that it raises an exception if it does not work
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('FOO')
    # Check that it accepts multiple arguments
    assert env_fallback('FOO', 'ANSIBLE_BAZ') == 'quux'



# Generated at 2022-06-11 01:25:34.460326
# Unit test for function set_fallbacks
def test_set_fallbacks():
    class TestModule(AnsibleModule):
        def __init__(self, *args, **kwargs):
            argument_spec = {
                'foo': {'type': 'str', 'fallback': ('env_fallback',)},
                'bar': {'type': 'str', 'fallback': ('env_fallback', ['BAR_FALLBACK1', 'BAR_FALLBACK2'])},
                'baz': {'type': 'str', 'fallback': (env_fallback, ['BAZ_FALLBACK1', 'BAZ_FALLBACK2'])},
                'quz': {'type': 'str', 'fallback': (env_fallback, ['QUZ_FALLBACK1', {'QUZ_FALLBACK2': 'value'}])},
            }

# Generated at 2022-06-11 01:25:43.748433
# Unit test for function env_fallback
def test_env_fallback():

    assert env_fallback('C=') is None
    assert env_fallback('C=', 'D=') is None

    os.environ['FALLBACK_TEST_ENV'] = 'env'
    assert env_fallback('C=', 'FALLBACK_TEST_ENV=') == 'env'
    assert env_fallback('FALLBACK_TEST_ENV=', 'D=') == 'env'
    assert env_fallback('C=', 'D=', 'FALLBACK_TEST_ENV=') == 'env'
    assert env_fallback('C=', 'FALLBACK_TEST_ENV=', 'D=') == 'env'
    assert env_fallback('FALLBACK_TEST_ENV=', 'C=', 'D=') == 'env'
   

# Generated at 2022-06-11 01:25:53.971050
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_VAR'] = 'ANSIBLE_TEST_ENV_VAR'
    assert env_fallback('ANSIBLE_TEST_ENV_VAR') == 'ANSIBLE_TEST_ENV_VAR'
    os.environ['ANSIBLE_TEST_ENV_VAR'] = 'ANSIBLE_TEST_ENV_VAR2'
    assert env_fallback('ANSIBLE_TEST_ENV_VAR') == 'ANSIBLE_TEST_ENV_VAR2'
    del os.environ['ANSIBLE_TEST_ENV_VAR']
    assert env_fallback('ANSIBLE_TEST_ENV_VAR') == 'ANSIBLE_TEST_ENV_VAR2'

# Generated at 2022-06-11 01:26:04.760149
# Unit test for function set_fallbacks
def test_set_fallbacks():
    import sys

    test_spec = {
        'first_parameter': {'required': False, 'type': 'str', 'default': 'default value', 'no_log': False},
        'second_parameter': {'required': False, 'type': 'str', 'default': 'default value', 'no_log': False},
        'third_parameter': {'required': False, 'type': 'str', 'default': 'default value', 'no_log': True},
        'fourth_parameter': {'required': False, 'type': 'str', 'no_log': True}
    }

    test_parameters1 = {}
    test_parameters2 = {'first_parameter': 'first_parameter_value'}
    test_parameters3 = {'fourth_parameter': 'fourth_parameter_value'}

# Generated at 2022-06-11 01:26:15.387636
# Unit test for function remove_values
def test_remove_values():
    # non-container objects
    assert remove_values('foo', ['o']) == 'f**'
    assert remove_values('foo', ['o', 'f', 'x']) == '***'
    assert remove_values('', ['f']) == ''
    assert remove_values(5, []) == 5
    assert remove_values(None, []) is None

    # Mappings
    assert remove_values({'a': 'b'}, ['c']) == {'a': 'b'}
    assert remove_values({'a': 'b', 'c': 'd'}, ['a', 'e']) == {'**': '*', 'c': 'd'}

# Generated at 2022-06-11 01:26:23.494354
# Unit test for function set_fallbacks
def test_set_fallbacks():
    #assert set_fallbacks({}, {}) == []
    assert set_fallbacks({'a': {'fallback': (env_fallback, 'A-ENV')}}, {}) == []
    assert set_fallbacks({'b': {'fallback': (env_fallback, 'B-ENV')}}, {}) == []
    os.environ['A-ENV'] = 'foo'
    assert set_fallbacks({'a': {'fallback': (env_fallback, 'A-ENV')}}, {}) == []
    assert set_fallbacks({'a': {'fallback': (env_fallback, 'A-ENV'), 'no_log': True}}, {}) == ['foo']
    del os.environ['A-ENV']



# Generated at 2022-06-11 01:26:33.673280
# Unit test for function remove_values
def test_remove_values():
    strings_to_remove = [b'BECOME-SUCCESS', b'ssh-rsa']
    # test remove_values on string
    assert remove_values('Foo bar foobar', strings_to_remove) == 'Foo bar foobar'
    assert remove_values('Foo BECOME-SUCCESS bar foobar', strings_to_remove) == 'Foo bar foobar'
    assert remove_values('Foo BECOME-SUCCESS bar foobar', strings_to_remove) == 'Foo bar foobar'

    # test remove_values on list
    assert remove_values(['foo', 'bar', 'foobar'], strings_to_remove) == ['foo', 'bar', 'foobar']

# Generated at 2022-06-11 01:26:42.347524
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        foo=dict(type='str', fallback=(env_fallback, 'MISSING_FOO')),
        bar=dict(type='str', fallback=(env_fallback, 'MISSING_BAR')),
        baz=dict(type='str', default='something', fallback=('env_fallback', 'MISSING_BAZ'))
    )

    os.environ['MISSING_FOO'] = 'bar'
    result = set_fallbacks(argument_spec, dict())
    assert result == set() and len(result) == 0
    assert argument_spec['foo']['fallback'][0] == env_fallback
    assert argument_spec['bar']['fallback'][0] == env_fallback

# Generated at 2022-06-11 01:26:52.773067
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        foo=dict(fallback=(env_fallback, 'FOOBAR')),
        bar=dict(fallback=(env_fallback, dict(name='BARBAZ'))),
        baz=dict(fallback=(env_fallback, 'BAZQUX', dict(name='BAZQUX'))),
    )

    parameters = dict(
        bar=True
    )
    os.environ['FOOBAR'] = 'foo'
    os.environ['BARBAZ'] = 'bar'
    os.environ['BAZQUX'] = 'baz'
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert no_log_values == set()
    assert parameters['foo'] == 'foo'

# Generated at 2022-06-11 01:27:22.582485
# Unit test for function set_fallbacks

# Generated at 2022-06-11 01:27:32.911558
# Unit test for function env_fallback
def test_env_fallback():
    # Test with an existing environment variable
    os.environ['ANSIBLE_TEST_VARIABLE'] = 'ANSIBLE_TEST_VALUE'
    assert env_fallback('ANSIBLE_TEST_VARIABLE') == 'ANSIBLE_TEST_VALUE'
    assert env_fallback('ANSIBLE_TEST_VARIABLE', 'ANSIBLE_TEST_OTHER_VALUE') == 'ANSIBLE_TEST_VALUE'
    assert env_fallback('ANSIBLE_TEST_VARIABLE', 'ANSIBLE_TEST_OTHER_VALUE', 'ANSIBLE_TEST_VALUE') == 'ANSIBLE_TEST_VALUE'
    assert env_fallback('ANSIBLE_TEST_OTHER_VALUE', 'ANSIBLE_TEST_VARIABLE') == 'ANSIBLE_TEST_VALUE'
    assert env_

# Generated at 2022-06-11 01:27:42.077147
# Unit test for function set_fallbacks

# Generated at 2022-06-11 01:27:49.397623
# Unit test for function set_fallbacks

# Generated at 2022-06-11 01:28:00.637944
# Unit test for function set_fallbacks

# Generated at 2022-06-11 01:28:11.550990
# Unit test for function set_fallbacks
def test_set_fallbacks():
    args = dict(
        name='Jim',
        age=42,
        text='Hello World',
        host='localhost',
        password=None,
        port=None,
        sub=dict(
            ip='127.0.0.1',
            other='default')
    )
    no_log_values = set()

    parameters = dict(
        name='Bob',
        port=9000,
        sub=dict(
            ip='127.0.0.2'))


# Generated at 2022-06-11 01:28:21.965481
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('AAA', 'BBB') == 'AAA', 'Env fallback should be able to get 1st arg'
    assert env_fallback('BBB', 'AAA') == 'AAA', 'Env fallback should be able to get 2nd arg'
    assert env_fallback('CCC', 'BBB') == 'BBB', 'Env fallback should be able to get last arg'
    assert env_fallback('CCC', 'BBB', 'AAA') == 'AAA', 'Env fallback should be able to get last arg'
    assert env_fallback('AAA', 'BBB', 'AAA') == 'AAA', 'Env fallback should be able to get 1st arg'
    assert env_fallback('AAA', 'BBB', 'CCC') == 'CCC', 'Env fallback should be able to get last arg'


# Generated at 2022-06-11 01:28:32.734007
# Unit test for function set_fallbacks
def test_set_fallbacks():
    from ansible.module_utils import basic

    assert set() == set_fallbacks(dict(), dict())
    assert set() == set_fallbacks({'a': {}}, dict())

    import os
    os.environ['FOO'] = 'BAR'
    assert set() == set_fallbacks({'a': {'fallback': (None, 'a', 'b')}}, dict())
    assert {'BAR'} == set_fallbacks({'a': {'fallback': (env_fallback, 'FOO', 'BAR'), 'no_log': True}}, dict())

    assert set() == set_fallbacks({'a': {'fallback': (basic.fail_if_missing, 'a', 'b')}}, dict())

# Generated at 2022-06-11 01:28:34.030387
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('FOOBAR') == os.environ['FOOBAR']



# Generated at 2022-06-11 01:28:45.552368
# Unit test for function set_fallbacks
def test_set_fallbacks():
    arguments_spec = dict(
        username=dict(type='str', fallback=(env_fallback, 'USER', 'USERNAME')),
        foo=dict(type='str', fallback=(env_fallback, 'FOO')),
    )

    parameters = dict()

    # Test that env_fallback will get the right value
    assert set_fallbacks(arguments_spec, parameters) == {'user'}
    assert parameters == dict(username=pwd.getpwuid(os.geteuid()).pw_name)

    # Test that env_fallback doesn't find value
    os.environ.pop('USER', None)
    os.environ.pop('USERNAME', None)
    assert set_fallbacks(arguments_spec, parameters) == set()