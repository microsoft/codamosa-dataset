

# Generated at 2022-06-11 01:20:01.489089
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback(None, 'test') == os.environ['test']
    assert env_fallback('test', None) == os.environ['test']
    assert env_fallback(None, None, None) == os.environ['test']
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback(None)
    assert env_fallback(None, default='test') == 'test'


# Generated at 2022-06-11 01:20:11.452458
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'greeting': {'type': 'str', 'default': 'hi', 'fallback': (env_fallback, 'HELLO')}}
    parameters = {'greeting': 'hello'}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert(parameters['greeting'] == 'hello')
    assert(no_log_values == set())

    parameters = {'foo': 'bar'}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert(parameters['greeting'] == 'hi')
    assert(no_log_values == set())

    os.environ['HELLO'] = 'world'
    parameters = {'foo': 'bar'}

# Generated at 2022-06-11 01:20:21.522166
# Unit test for function env_fallback
def test_env_fallback():
    """Unit tests for function env_fallback"""

    # Check that lookup in both upper and lower case works
    os.environ['UpperCaseEnv'] = 'UpperCaseValue'
    os.environ['lowercaseenv'] = 'lowercasevalue'
    assert env_fallback('uppercaseenv') == 'UpperCaseValue'
    assert env_fallback('LOWERCASEENV') == 'lowercasevalue'
    del os.environ['UpperCaseEnv']
    del os.environ['lowercaseenv']

    # Test if no environment variable exists
    assert env_fallback('NOT_A_REAL_ENVIRONMENT_VARIABLE') == 'NOT_A_REAL_ENVIRONMENT_VARIABLE'



# Generated at 2022-06-11 01:20:33.029663
# Unit test for function set_fallbacks

# Generated at 2022-06-11 01:20:34.986794
# Unit test for function set_fallbacks
def test_set_fallbacks():
    from nose.plugins.skip import SkipTest
    raise SkipTest('deprecated')



# Generated at 2022-06-11 01:20:45.326681
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # just for testing purposes, ensure we return an AnsibleFallbackNotFound
    # if the env var does not exist, to avoid leaving 'None' for system tests
    def my_fallback(*args, **kwargs):
        return env_fallback(*args, **kwargs)


# Generated at 2022-06-11 01:20:49.832613
# Unit test for function set_fallbacks
def test_set_fallbacks():
    params = {'a': 'foo', 'c': 'd'}
    argspec = {'a': {}, 'b': {'fallback': (env_fallback, ['BAR'])}, 'c': {'fallback': (env_fallback, ['BAZ'])}}
    assert set_fallbacks(argspec, params) == set()

    os.environ['BAR'] = '123'
    os.environ['BAZ'] = '456'
    assert set_fallbacks(argspec, params) == set(['456'])
    assert set_fallbacks(argspec, params) == set([])
    del os.environ['BAR']
    del os.environ['BAZ']



# Generated at 2022-06-11 01:20:54.006298
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'arg1': {'type': 'dict', 'options': {
                        'subarg1': {'type': 'str', 'fallback': (env_fallback, ['subarg1'])},
                        'subarg2': {'type': 'str', 'fallback': (env_fallback, ['subarg2'])}}}}
    parameters = {'arg1': {'subarg2': 'sub2'}}
    os.environ['subarg1'] = 'sub1'
    assert set_fallbacks(argument_spec, parameters) == set()



# Generated at 2022-06-11 01:21:06.020872
# Unit test for function set_fallbacks
def test_set_fallbacks():
    module_args = {}
    argument_spec = {'name': {'type': 'str', 'required': False},
                     'mode': {'type': 'str', 'required': False}}
    set_fallbacks(argument_spec, module_args)
    assert 'mode' in module_args
    assert module_args['mode'] is None
    assert 'name' not in module_args

    module_args = {}
    argument_spec = {'name': {'type': 'str', 'required': False, 'default': 'foo'}}
    set_fallbacks(argument_spec, module_args)
    assert 'name' in module_args
    assert module_args['name'] == 'foo'

    module_args = {}

# Generated at 2022-06-11 01:21:09.616404
# Unit test for function env_fallback
def test_env_fallback():
    test_env = os.environ.copy()
    try:
        os.environ["FOO"] = "BAR"
        assert env_fallback("FOO") == "BAR"
    finally:
        os.environ.clear()
        os.environ.update(test_env)


# Generated at 2022-06-11 01:22:11.085144
# Unit test for function remove_values
def test_remove_values():
    def _eq(value, expected):
        # Because Python 2.6 doesn't have equal comparison for frozenset,
        # we compare the string representation of it.
        if isinstance(value, frozenset):
            assert str(value) == str(expected)
        else:
            assert value == expected

    _eq(remove_values(dict(a=1, password=2), ['password']), dict(a=1))
    _eq(remove_values(dict(a=1, password=dict(b=2)), ['password']), dict(a=1))
    _eq(remove_values(dict(a=1, password=dict(b=2)), ['b']), dict(a=1, password={}))

# Generated at 2022-06-11 01:22:20.802880
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        one=dict(type='str', fallback=(env_fallback, 'ONE')),
        two=dict(type='str', fallback=(env_fallback, 'TWO')),
        three=dict(type='str', fallback=(env_fallback, 'THREE')),
        four=dict(type='bool', fallback=(to_text, True)),
        five=dict(type='str', fallback=(env_fallback, 'FIVE', dict(fallback=5))),
        six=dict(type='str', fallback=(env_fallback, 'SIX', dict(fallback=0))),
        seven=dict(type='dict', fallback=(dict, dict(key='value'))),
    )


# Generated at 2022-06-11 01:22:26.048663
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert set_fallbacks({'baz': {'fallback': (env_fallback, ['FOO'])}}, {}) == set()
    assert set_fallbacks({'baz': {'fallback': (env_fallback, ['FOO'])}}, {}) == set()
    assert set_fallbacks({'baz': {'fallback': (env_fallback, ['FOO'])}}, {}) == set()
    assert set_fallbacks({'baz': {'fallback': (env_fallback, ['FOO'])}}, {}) == set()



# Generated at 2022-06-11 01:22:34.629054
# Unit test for function remove_values
def test_remove_values():
    import json

    def test_object():
        return dict(
            a=dict(
                b='c',
                d='e',
                f=['g', 'h', 'i', 'j', 'k'],
                l=[dict(m=['n', 'o', 'p', dict(q=0)])],
            ),
        )

    def assert_removal(input_value, private_values, expected_value):
        actual_value = remove_values(input_value, private_values)
        assert actual_value == expected_value, 'Unexpected value returned from remove_values(). Expected: %s\nActual: %s' % (expected_value, actual_value)

    value = test_object()
    assert_removal(value, set(), value)

# Generated at 2022-06-11 01:22:44.276200
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'param': {'type': 'str', 'fallback': (env_fallback, ['param'])}}
    parameters = {}
    assert set_fallbacks(argument_spec, parameters) == set()
    assert 'param' not in parameters

    os.environ['param'] = 'value'
    assert set_fallbacks(argument_spec, parameters) == set()
    assert parameters['param'] == 'value'

    argument_spec['param']['no_log'] = True
    assert set_fallbacks(argument_spec, parameters) == {'value'}
    assert parameters['param'] == 'value'



# Generated at 2022-06-11 01:22:53.994002
# Unit test for function sanitize_keys
def test_sanitize_keys():
    class NoLogDict(dict):
        def __setitem__(self, key, value):
            if key == 'noLog':
                dict.__setitem__(self, key + '_hidden', value)
            else:
                dict.__setitem__(self, key, value)


# Generated at 2022-06-11 01:23:04.235546
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys(None, []) == None
    assert sanitize_keys("None", []) == "None"
    assert sanitize_keys("None", ["None"]) == "*****"
    assert sanitize_keys("None", ["None"], ['None']) == "None"
    assert sanitize_keys("None", ["None"], ['None', 'None']) == "None"
    assert sanitize_keys("None", ["None"], ['None', 'none']) == "None"
    assert sanitize_keys("None", ["None"], ['None', 'NONE']) == "None"
    assert sanitize_keys("None", ["None"], ['None', 'NONE', 'None']) == "None"
    assert sanitize_keys("None", [], ['None']) == "None"


# Generated at 2022-06-11 01:23:11.806785
# Unit test for function set_fallbacks
def test_set_fallbacks():
    foo_module_args = dict(
        state='present',
        name='foo',
        password=dict(
            fallback=(env_fallback, ("ANSIBLE_NET_PASSWORD",)),
            type="str",
            no_log=True,
        ),
    )
    assert list(set_fallbacks(dict(password=dict(fallback=(env_fallback, ("ANSIBLE_NET_PASSWORD",)),
                                                 type="str", no_log=True)), foo_module_args)) == []
    os.environ['ANSIBLE_NET_PASSWORD'] = 'PASSWORD'

# Generated at 2022-06-11 01:23:20.446591
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert {"user": "myuser"} == sanitize_keys({"user": "myuser"}, {})
    assert {"user": "myuser"} == sanitize_keys({"user": "myuser"}, {}, ignore_keys=["user"])
    assert {"user": "myuser"} == sanitize_keys({"user": "myuser"}, {}, ignore_keys=["user", "pass"])

    assert {"u_er": "myuser"} == sanitize_keys({"user": "myuser"}, {"user"})
    assert {"u_er": "myuser"} == sanitize_keys({"user": "myuser"}, {"user", "pass"}, ignore_keys=["user"])

# Generated at 2022-06-11 01:23:26.470007
# Unit test for function sanitize_keys
def test_sanitize_keys():
    class TestObject(object):
        def __init__(self, ansible_forbidden, ansible_sensitive):
            self.ansible_forbidden = ansible_forbidden
            self.ansible_sensitive = ansible_sensitive

    class TestObject2(object):
        def __init__(self, ansible_forbidden, ansible_sensitive):
            self.ansible_forbidden = ansible_forbidden
            self.ansible_sensitive = ansible_sensitive

    # Test dict
    input_dict = {
        'ansible_forbidden': 'hello world',
        'ansible_sensitive': 'hello world',
        '_ansible_forbidden': 'hello world',
        '_ansible_sensitive': 'hello world',
        'not_ansible': 'hello world',
    }

# Generated at 2022-06-11 01:23:59.882804
# Unit test for function sanitize_keys
def test_sanitize_keys():
    obj = dict(a=dict(b=2), c=dict(d=4))
    results = sanitize_keys(obj, set(['d']))
    assert results == dict(a=dict(b=2), c=dict(**{'**d**': 4}))
    results = sanitize_keys(obj, set(['b', 'd']))
    assert results == dict(**{'**a**': dict(**{'**b**': 2})}, c=dict(**{'**d**': 4}))
    results = sanitize_keys(obj, set(['b', 'd']), ignore_keys=set(['c']))
    assert results == dict(a=dict(**{'**b**': 2}), **{'**c**': dict(d=4)})

# Generated at 2022-06-11 01:24:06.094479
# Unit test for function remove_values
def test_remove_values():
    # Test empty list
    assert remove_values([], []) == []
    
    # Test no-log list with non-string list
    assert remove_values(["foo", 1, False], []) == ["foo", 1, False]
    
    # Test no-log list with list
    # Defaults to removing all items
    assert remove_values(["foo", "bar"], ["bar"]) == [None, None]
    
    # Test no-log dict with dict
    # Defaults to replacing items with None
    assert remove_values({"foo": "bar"}, ["foo"]) == {"foo": None}
    assert remove_values({"foo": "bar"}, ["bar"]) == {"foo": "bar"}

# Generated at 2022-06-11 01:24:16.025795
# Unit test for function set_fallbacks
def test_set_fallbacks():

    argument_spec = {'test_param1': {'type': 'str', 'fallback': (env_fallback, ['TEST_PARAM1'])},
                     'test_param2': {'type': 'str', 'fallback': (env_fallback, ['TEST_PARAM2', 'TEST_PARAM3'])},
                     'test_param3': {'type': 'str', 'fallback': (env_fallback, ['TEST_PARAM4'])},
                     'test_param4': {'type': 'str', 'fallback': (env_fallback, ['TEST_PARAM5'], {'default': 'default_value'})}}

# Generated at 2022-06-11 01:24:27.338578
# Unit test for function sanitize_keys
def test_sanitize_keys():
    basic_dict = dict(a=1, b=2, c=3)
    dict_no_log_strings = dict(a=1, b=2, c='no_log_value')
    dict_no_log_strings_list = dict(a=1, b=2, c=('no_log_value1', 'no_log_value2'))
    dict_no_log_strings_dict = dict(a=1, b=2, c={'no_log_value1': 'foo', 'no_log_value2': 'bar'})

# Generated at 2022-06-11 01:24:39.195301
# Unit test for function set_fallbacks
def test_set_fallbacks():

    sub_spec = dict(
        foo=dict(type='int', fallback=(env_fallback, ['ANSIBLE_TEST_FOO'], dict(fallback=99))),
        bar=dict(type='int', fallback=(env_fallback, ['ANSIBLE_TEST_BAR']))
    )

    parameters = dict(foobar='foo')

    no_log_values = set_fallbacks(sub_spec, parameters)
    assert parameters['foo'] == 99, "Failed to fallback foo"
    assert 'bar' not in parameters, "Should not have fallen back for bar"
    assert 'ANSIBLE_TEST_FOO' in no_log_values, "Should have been marked for no_log"

# Generated at 2022-06-11 01:24:50.718339
# Unit test for function set_fallbacks

# Generated at 2022-06-11 01:24:57.553223
# Unit test for function set_fallbacks
def test_set_fallbacks():
    import os

    from ansible.module_utils.six import text_type

    # if os.environ.get('ANSIBLE_TEST_PWD') is None:
    #     os.environ['ANSIBLE_TEST_PWD'] = 'password123'

    # base argument spec

# Generated at 2022-06-11 01:25:08.751375
# Unit test for function set_fallbacks
def test_set_fallbacks():
    parameters = {}
    argument_spec = {
        'ask_pass': {'type': 'bool', 'default': False, 'fallback': (env_fallback, 'ANSIBLE_ASK_PASS')},
        'ask_sudo_pass': {'type': 'bool', 'default': False, 'fallback': (env_fallback, 'ANSIBLE_ASK_SUDO_PASS')},
    }

    no_log_values = set_fallbacks(argument_spec, parameters)
    assert len(no_log_values) == 2
    assert False in parameters.values()

    os.environ['ANSIBLE_ASK_PASS'] = 'false'
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert len(no_log_values) == 2
    assert parameters['ask_pass']

# Generated at 2022-06-11 01:25:16.235344
# Unit test for function set_fallbacks

# Generated at 2022-06-11 01:25:28.150662
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'param1': { 'fallback': (Fallback1, ) },
        'param2': { 'fallback': (env_fallback, 'ENV_VAR_2') },
        'param3': { 'fallback': (env_fallback, 'ENV_VAR_3', 'ENV_VAR_4', {'default_var': 'var'}) },
        'param4': { 'fallback': (Fallback2, ['a', {'b': None}]) },
        'param5': { 'fallback': (Fallback3, 'a', 'b', {'c': 'c'}, {'d': 'd'}) }
    }
    params = {}
    no_log_values = set_fallbacks(argument_spec, params)

# Generated at 2022-06-11 01:26:20.317469
# Unit test for function set_fallbacks

# Generated at 2022-06-11 01:26:25.283947
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'force_remove_path': {
            'type': 'path',
            'fallback': (env_fallback, 'FORCE_REMOVE_PATH'),
            'no_log': True,
        },
        'force_remove_path_with_args': {
            'type': 'path',
            'fallback': (env_fallback, 'FORCE_REMOVE_PATH', {'key': 'value'}),
            'no_log': True,
        }
    }
    parameters = {'force_remove_path_with_args': 'value'}
    expected_no_log_values = set()
    assert set_fallbacks(argument_spec, parameters) == expected_no_log_values
    parameters = {'force_remove_path': 'old_value'}


# Generated at 2022-06-11 01:26:35.368379
# Unit test for function set_fallbacks

# Generated at 2022-06-11 01:26:41.677009
# Unit test for function sanitize_keys
def test_sanitize_keys():
    no_log_strings = ['1', '2', '3']
    d = {'_ansible_no_log': True}
    new_dict = sanitize_keys(d, no_log_strings)
    assert new_dict == {'_ansible_no_log': True}

    l = ['_ansible_no_log', '_ansible_no_log']
    new_list = sanitize_keys(l, no_log_strings)
    assert new_list == ['_ansible_no_log', '_ansible_no_log']
    s = {'_ansible_no_log'}
    new_set = sanitize_keys(s, no_log_strings)
    assert new_set == {'_ansible_no_log'}


# Generated at 2022-06-11 01:26:46.235153
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'falcon': {'type': 'str', 'fallback': (env_fallback, 'FALCON_PATH')}}
    parameters = {}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['falcon'] == os.environ['FALCON_PATH']
    assert not no_log_values

    if 'FALCON_PATH' in os.environ:
        del os.environ['FALCON_PATH']

    argument_spec = {'falcon': {'type': 'str', 'fallback': (env_fallback, 'FALCON_PATH', 'not_found')}}
    parameters = {}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters == {}
    assert not no_log_values



# Generated at 2022-06-11 01:26:55.254312
# Unit test for function set_fallbacks

# Generated at 2022-06-11 01:26:59.537317
# Unit test for function set_fallbacks
def test_set_fallbacks():
    spec = dict(foo=dict(type='str', fallback=(env_fallback, 'FOO')))
    params = dict(bar='baz')
    no_log_values = set_fallbacks(spec, params)
    assert "baz" in no_log_values



# Generated at 2022-06-11 01:27:10.887364
# Unit test for function sanitize_keys
def test_sanitize_keys():
    expected_values = {}
    expected_values['dict'] = {'dict': {'test': False, 'password': 'hidden'}}
    expected_values['list'] = {'list': [{'test': False, 'password': 'hidden'}]}
    expected_values['set'] = {'set': {'test', ':hidden'}}
    expected_values['tuple'] = {'tuple': ('test', ':hidden')}
    expected_values['uuid_namespace'] = {'uuid': uuid.uuid5(uuid.NAMESPACE_DNS, ':hidden')}
    expected_values['uuid_random'] = {'uuid': uuid.uuid4()}
    for value_type, value in expected_values.items():
        data = copy.deepcopy(value)
       

# Generated at 2022-06-11 01:27:20.977385
# Unit test for function set_fallbacks

# Generated at 2022-06-11 01:27:31.995039
# Unit test for function set_fallbacks

# Generated at 2022-06-11 01:28:33.189893
# Unit test for function set_fallbacks

# Generated at 2022-06-11 01:28:40.929732
# Unit test for function set_fallbacks
def test_set_fallbacks():
    """Test setting values from fallbacks"""

    # Test basic fallback
    argument_spec = {'foo': {'fallback': (env_fallback, ['FOO'])}}
    parameters = {}
    expected_no_log_values = set()
    os.environ['FOO'] = 'bar'
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['foo'] == 'bar'
    assert no_log_values == expected_no_log_values



# Generated at 2022-06-11 01:28:50.806479
# Unit test for function remove_values
def test_remove_values():
    test_dict = {
        "keys": [
            "alpha",
            "bravo",
            "charlie",
            "delta"
        ],
        "values": [
            "1",
            "2",
            "3",
            "4"
        ],
        "dictionary": {
            "a": "1",
            "b": "2",
            "c": "3",
            "d": "4"
        }
    }

    # Do not alter the original dictionary by cloning it
    test_dict_clone = copy.deepcopy(test_dict)


# Generated at 2022-06-11 01:29:00.650731
# Unit test for function set_fallbacks

# Generated at 2022-06-11 01:29:07.060746
# Unit test for function sanitize_keys
def test_sanitize_keys():
    no_log_strings = [u'foo', u'bar']
    result = sanitize_keys({u'foo': u'bar'}, no_log_strings)
    assert result == {u'[REDACTED]': u'bar'}
    result = sanitize_keys({u'foo': u'bar', u'baz': u'qux'}, no_log_strings)
    assert result == {u'[REDACTED]': u'bar', u'baz': u'qux'}
    result = sanitize_keys({u'foo': u'bar', u'baz': {u'qux': u'quux'}}, no_log_strings)
    assert result == {u'[REDACTED]': u'bar', u'baz': {u'qux': u'quux'}}