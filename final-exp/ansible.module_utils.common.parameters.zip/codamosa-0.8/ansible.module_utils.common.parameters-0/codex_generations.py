

# Generated at 2022-06-11 01:19:44.596228
# Unit test for function set_fallbacks

# Generated at 2022-06-11 01:19:49.662465
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('FOO') == 'BAR'
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('FOO1')


# Generated at 2022-06-11 01:19:58.938954
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        one=dict(type='int', fallback=(int, 0)),
        two=dict(type='int', fallback=(int, 1)),
        three=dict(type='int', fallback=(int, 0)),
        four=dict(type='int', fallback=(env_fallback, "HOME", "USER")),
        five=dict(type='list', fallback=(env_fallback, "PATH"))
    )
    parameters = dict(three='3', four=4)
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert no_log_values == set()
    assert parameters == dict(one=0, two=1, three='3', four=4)



# Generated at 2022-06-11 01:20:09.705621
# Unit test for function set_fallbacks
def test_set_fallbacks():
    from ansible.module_utils.basic import AnsibleModule
    import os
    import copy
    import pytest
    from ansible.errors import AnsibleFallbackNotFound
    from ansible.module_utils._text import to_bytes, to_native
    from cStringIO import StringIO


# Generated at 2022-06-11 01:20:20.615331
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        ec2_url=dict(fallback=(env_fallback, ["EC2_URL"])),
        ec2_secret_key=dict(no_log=True, fallback=(env_fallback, ["EC2_SECRET_KEY"])),
        check_mode=dict(default=False, type='bool'),
        ec2_private_key=dict(aliases=['aws_secret_key', 'secret_key'], no_log=True),
    )
    input_parameters = dict(
        ec2_url='112233445566',
        check_mode=True
    )


# Generated at 2022-06-11 01:20:32.481076
# Unit test for function env_fallback
def test_env_fallback():
    os.environ["TEST_ENV_FALLBACK"] = "OK"
    os.environ["TEST_ENV_FALLBACK2"] = "OK"
    assert env_fallback('TEST_ENV_FALLBACK') == "OK"
    assert env_fallback('TEST_ENV_FALLBACK', 'TEST_ENV_FALLBACK2') == "OK"

    assert env_fallback('TEST_ENV_FALLBACK3') == None
    assert env_fallback('TEST_ENV_FALLBACK3', 'TEST_ENV_FALLBACK2') == "OK"

    os.environ.pop("TEST_ENV_FALLBACK")
    os.environ.pop("TEST_ENV_FALLBACK2")
    assert env_fall

# Generated at 2022-06-11 01:20:43.729620
# Unit test for function set_fallbacks
def test_set_fallbacks():
    args = {'test_var': 'something'}
    argument_spec = {
        'test_1': {'fallback': (env_fallback, ['FOO']), 'type': 'str'},
        'test_2': {'fallback': (env_fallback, ['FOO']), 'type': 'str'},
        'test_3': {'fallback': (env_fallback, ['FOO']), 'type': 'dict'},
        'test_4': {'fallback': (test_fallback_func, ['test_var']), 'type': 'str'}
    }
    foo_envvar = "bar"
    os.environ["FOO"] = foo_envvar
    no_log_values = set_fallbacks(argument_spec, args)
    assert args['test_1']

# Generated at 2022-06-11 01:20:53.768815
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'param_1': {'type': 'str', 'fallback': (env_fallback, ['PARAM_1'])},
                     'param_2': {'type': 'str', 'fallback': (env_fallback, ['PARAM_2'])}}

    parameters = {}
    with patch.dict(os.environ, {'PARAM_1': 'PARAM_1_VALUE'}):
        no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters == {'param_1': 'PARAM_1_VALUE', 'param_2': None}
    assert len(no_log_values) == 0

    parameters = {}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters == {'param_2': None}
   

# Generated at 2022-06-11 01:20:59.434403
# Unit test for function remove_values

# Generated at 2022-06-11 01:21:09.428051
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        one=dict(fallback=(env_fallback, ('TEST_ONE',))),
        two=dict(fallback=(env_fallback, ('TEST_TWO', 'TEST_THREE'))),
        three=dict(fallback=(env_fallback, ('TEST_THREE', 'TEST_TWO'))),
        four=dict(fallback=(env_fallback, ('TEST_FOUR',))),
        five=dict(fallback=(env_fallback, ('TEST_FIVE',))),
    )
    parameters = dict(
        four=True,
    )

# Generated at 2022-06-11 01:21:38.996569
# Unit test for function remove_values

# Generated at 2022-06-11 01:21:49.583072
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'required_param': dict(type='str', required=True),
        'no_log_param': dict(type='str', no_log=True),
        'fallback_param': dict(type='str', fallback=('foo', 'bar')),
        'fallback_default_param': dict(type='str', fallback=('foo', 'bar'), default='baz'),
        'no_log_fallback_default_param': dict(type='str', fallback=('foo', 'bar'), default='baz', no_log=True)
    }
    parameters = dict()

    no_log_values = set_fallbacks(argument_spec, parameters)
    assert len(no_log_values) == 0
    assert len(parameters) == 0


# Generated at 2022-06-11 01:21:58.455478
# Unit test for function set_fallbacks
def test_set_fallbacks():
    spec = dict(
        int_param=dict(type='int', fallback=(int, 10,)),
        env_param=dict(type='str', fallback=(env_fallback, 'TEST_ENV_VAR')),
        dict_param=dict(type='dict', fallback=(dict, dict(key='value'))),
        fail_param=dict(type='int', fallback=(int, 'not a valid int')),
        fail_env_param=dict(type='int', fallback=(env_fallback, 'TEST_ENV_VAR_NOT_EXIST')),
    )
    params = dict(
        int_param=10,
        env_param='this is my env param',
        dict_param=dict(key='value')
    )

    no_log_values = set_fallbacks

# Generated at 2022-06-11 01:22:10.354114
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # No fallbacks
    argument_spec = {
        'foo': {'type': 'str'}
    }
    parameters = {}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert len(parameters) == 0
    assert len(no_log_values) == 0

    # All fallbacks
    argument_spec = {
        'foo': {'type': 'str', 'fallback': (env_fallback, ('FOO',))},
        'bar': {'type': 'str', 'fallback': (env_fallback, ('BAR',))},
        'baz': {'type': 'str', 'fallback': (env_fallback, ('BAZ',))},
    }
    parameters = {}

# Generated at 2022-06-11 01:22:19.863678
# Unit test for function set_fallbacks
def test_set_fallbacks():
    spec = dict(
        foo=dict(required=True, type='int', fallback=(env_fallback, ('FOO',))),
        bar=dict(required=True, type='int', fallback=(env_fallback, ('BAR',))),
        baz=dict(required=True, type='int', fallback=(env_fallback, ('BAZ', 'qux'))),
    )
    params = dict(
        foo=1,
        bar=2,
        # baz is missing
    )
    no_log_values = set_fallbacks(spec, params)
    assert params['foo'] == 1
    assert params['bar'] == 2
    assert params['baz'] == 'qux'
    assert no_log_values == {'qux'}



# Generated at 2022-06-11 01:22:26.830088
# Unit test for function set_fallbacks
def test_set_fallbacks():
    spec = dict(
        foo=dict(
            required=True,
            fallback=(env_fallback, 'FOO')
        ),
        bar=dict(
            required=True,
            fallback=(env_fallback, 'BAR')
        ),
        baz=dict(
            fallback=(env_fallback, 'BAZ', dict(key='value'))
        ),
    )
    parameters = dict(baz='eggs')
    result = set_fallbacks(spec, parameters)
    assert parameters == dict(baz='eggs')
    assert result == set()
    assert 'FOO' not in os.environ
    os.environ['FOO'] = 'test'
    result = set_fallbacks(spec, parameters)
    assert parameters == dict(foo='test', baz='eggs')

# Generated at 2022-06-11 01:22:35.168148
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert set_fallbacks(dict(), dict()) == set()
    assert set_fallbacks(dict(a=dict(fallback=(env_fallback, 'ANSIBLE_TEST_B'))), dict()) == set()
    assert set_fallbacks(dict(a=dict(fallback=(env_fallback, 'ANSIBLE_TEST_A'))), dict()) == set('ANSIBLE_TEST_VALUE'.split())
    assert set_fallbacks(dict(a=dict(fallback=(env_fallback, 'ANSIBLE_TEST_A'), no_log=True)), dict()) == set('ANSIBLE_TEST_VALUE'.split())
    assert set_fallbacks(dict(a=dict(fallback=(env_fallback, 'ANSIBLE_TEST_A'), no_log=False)), dict()) == set()
    os.en

# Generated at 2022-06-11 01:22:46.792744
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {}
    parameters = {}
    no_log_values = set()
    argument_spec["foo"] = {"type": "str", "fallback": (env_fallback, "BAR")}
    argument_spec["foo2"] = {"type": "str", "fallback": (env_fallback,)}
    os.environ['BAR'] = "testing-set-fallbacks"
    os.environ['FOO'] = "testing-set-fallbacks2"
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert no_log_values == set()
    assert parameters["foo"] == "testing-set-fallbacks"
    assert parameters["foo2"] == "testing-set-fallbacks2"
    del os.environ['BAR']
    del os.environ

# Generated at 2022-06-11 01:22:51.131306
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_JINJA2_NATIVE']='True'
    assert env_fallback('ANSIBLE_JINJA2_NATIVE') == 'True'
    try:
        env_fallback('foo')
    except AnsibleFallbackNotFound:
        pass
    else:
        raise AssertionError('env_fallback did not raise AnsibleFallbackNotFound')


# Generated at 2022-06-11 01:22:53.240832
# Unit test for function env_fallback
def test_env_fallback():
    """Check env_fallback()"""
    assert kwargs == {}
    assert env_fallback("foo", "bar") == "bar"



# Generated at 2022-06-11 01:23:21.552033
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST'] = 'test'
    assert env_fallback('ANSIBLE_TEST') == 'test'
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('ANSIBLE_TEST_MISSING')

# Generated at 2022-06-11 01:23:26.869325
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_FOO'] = 'from_env_LAN'
    assert 'from_env_LAN' == env_fallback('ANSIBLE_TEST_FOO')
    del os.environ['ANSIBLE_TEST_FOO']
    assert 'my_default' == env_fallback('ANSIBLE_TEST_BAR', 'my_default')


_FALLBACK_SOURCE_VALUES = dict(
    env=env_fallback,
)

# NOTE: must be kept in sync with the list in setup.py
_SUPPORTED_MODULE_LANGUAGES = ('python', 'powershell', 'ruby', 'lua', 'bash')



# Generated at 2022-06-11 01:23:33.064861
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert len(set_fallbacks({'flag1': {'type': 'bool', 'default': False}, 'flag2': {'type': 'bool', 'default': False}, 'flag3': {'type': 'bool', 'default': False},
                              'flag4': {'type': 'bool', 'default': False}, 'flag5': {'type': 'bool', 'required': False, 'default': False}}, {})) == 0

# Generated at 2022-06-11 01:23:42.542943
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        required_opt=dict(type='str', required=True),
        fallback_opt1=dict(type='str', required=True, default='default_value'),
        fallback_opt2=dict(type='str', required=True, fallback='from_fallback'),
        fallback_opt3=dict(type='str', required=True, fallback=('from_fallback_with_args', ['opt3', 'opt4'])),
        fallback_opt4=dict(type='str', required=True, fallback=('from_fallback_with_kwargs', dict(opt='opt5', opt1='opt6'))),
        fallback_opt5=dict(type='str', required=True, fallback=(env_fallback, 'FALLBACKOPT5'))
    )

# Generated at 2022-06-11 01:23:54.069808
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'name': {
            'required': False,
            'default': None,
            'type': 'str',
            'fallback': (env_fallback, ('ANSIBLE_TEST_NAME', 'TEST_NAME'))
        }
    }
    parameters = {}
    assert set_fallbacks(argument_spec, parameters) == set()
    parameters = {'not_the_name': 'other'}
    assert set_fallbacks(argument_spec, parameters) == set()
    parameters = {'name': 'other'}
    assert set_fallbacks(argument_spec, parameters) == set()
    parameters = {'name': None}
    assert set_fallbacks(argument_spec, parameters) == set()
    parameters = {'name': 'other'}

# Generated at 2022-06-11 01:23:58.736741
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        param1=dict(fallback=(env_fallback, 'MYENV', 'MYENV2'), type='str'),
        param2=dict(fallback=(env_fallback, 'MYENV'), type='str'),
        param3=dict(fallback=(env_fallback, 'MYENV', 'MYENV2'), type='str'),
        param4=dict(fallback=(env_fallback, 'MYENV', 'MYENV2'), type='str'),
        param5=dict(fallback=(env_fallback, 'MYENV', 'MYENV2'), type='str'),
    )
    assert set_fallbacks(argument_spec, dict(param1='should remove')) == set()
    assert dict(param1='should remove', param2='env val') == set_fall

# Generated at 2022-06-11 01:24:04.795682
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        a=dict(type='str', fallback=(env_fallback, 'A_ENV',)),
        b=dict(type='str', fallback=(env_fallback, 'B_ENV', dict(default='a'))),
        c=dict(type='str', fallback=(env_fallback, 'C_ENV', dict(default='b', type='bool'))),
    )
    parameters = dict(a='a', b='a')
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert no_log_values == set()
    assert parameters['a'] == 'a'
    assert parameters['b'] == 'a'
    assert 'c' not in parameters
    os.environ['A_ENV'] = 'b'
    os.en

# Generated at 2022-06-11 01:24:07.575191
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec_fallback = {'param1': {'type': 'str', 'fallback': (env_fallback, ('param1', 'param2'))}}
    no_log_values = set_fallbacks(argument_spec_fallback, {})
    assert no_log_values == set()



# Generated at 2022-06-11 01:24:17.829602
# Unit test for function set_fallbacks
def test_set_fallbacks():

    def test_fallback(value, result):
        argument_spec = {'key': {'type': 'str', 'fallback': (lambda: value)}}
        params = {'key': 'not_value'}
        errors = AnsibleValidationErrorMultiple()
        no_log = set()
        fallback_params = set_fallbacks(argument_spec, params)
        value = params.get('key')
        if result is not None:
            assert value == result, "Got: %s" % value
            assert 'not_value' not in params
        else:
            assert params.get('key') == 'not_value'

    test_fallback('value', 'value')
    test_fallback(None, 'not_value')



# Generated at 2022-06-11 01:24:29.359619
# Unit test for function set_fallbacks

# Generated at 2022-06-11 01:25:05.198638
# Unit test for function set_fallbacks
def test_set_fallbacks():
    params = dict()
    spec = dict(
        test1=dict(
            fallback=(env_fallback, 'TEST1'),
            no_log=True,
        ),
        test2=dict(
            fallback=(env_fallback, 'TEST2'),
        ),
    )
    os.environ['TEST1'] = 'pass1'
    os.environ['TEST2'] = 'pass2'
    no_log_values = set_fallbacks(spec, params)
    assert no_log_values == {'pass1'}
    assert params == dict(test1='pass1', test2='pass2')

    # Test with fallback kwargs
    params = dict()

# Generated at 2022-06-11 01:25:13.964704
# Unit test for function set_fallbacks
def test_set_fallbacks():
    PARAMETERS = {
        'param1': '',
        'param2': '',
        'param3': '',
        'param4': '',
        'param5': '',
        'param6': '',
        'param8': '',
        'param9': '',
    }


# Generated at 2022-06-11 01:25:19.659032
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_STR'] = 'ANSIBLE_STR'
    assert env_fallback('ANSIBLE_STR') == 'ANSIBLE_STR'
    del os.environ['ANSIBLE_STR']
    try:
        env_fallback('ANSIBLE_STR')
    except AnsibleFallbackNotFound:
        pass

# Generated at 2022-06-11 01:25:30.367447
# Unit test for function set_fallbacks
def test_set_fallbacks():
    import os
    test_parameters = {'one': 1, 'two': 2}
    test_fallback_value = {'three': {'fallback': (env_fallback, ['THREE_FALLBACK'])}, 'four': 4}
    expected_parameters = {'one': 1, 'two': 2, 'four': 4}
    expected_no_log_values = set()
    os.environ['THREE_FALLBACK'] = '3'
    no_log_values = set_fallbacks(test_fallback_value, test_parameters)
    os.environ.pop('THREE_FALLBACK')
    assert no_log_values == expected_no_log_values
    assert test_parameters == expected_parameters

# Generated at 2022-06-11 01:25:40.882374
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK_TEST'] = 'ANSIBLE_TEST_ENV_FALLBACK_TEST_VALUE'
    try:
        assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_TEST') == 'ANSIBLE_TEST_ENV_FALLBACK_TEST_VALUE'
        assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_FOUND') == 'ANSIBLE_TEST_ENV_FALLBACK_NOT_FOUND'
    finally:
        del os.environ['ANSIBLE_TEST_ENV_FALLBACK_TEST']
test_env_fallback()



# Generated at 2022-06-11 01:25:48.360736
# Unit test for function set_fallbacks

# Generated at 2022-06-11 01:25:59.337053
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'param': {'type': 'str', 'fallback': (env_fallback, 'ANSIBLE_PARAM')}}
    parameters = {}
    os.environ['ANSIBLE_PARAM'] = 'param value'
    os.environ['ANSIBLE_PARAM1'] = 'param value 1'

    no_log_values = set_fallbacks(argument_spec, parameters)
    assert len(no_log_values) == 0
    assert len(parameters) == 1
    assert parameters['param'] == 'param value'

    parameters = {}
    argument_spec = {'param': {'type': 'str', 'no_log': True, 'fallback': (env_fallback, 'ANSIBLE_PARAM', 'ANSIBLE_PARAM1')}}


# Generated at 2022-06-11 01:26:09.668007
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        backend=dict(required=False, type='str'),
        foo=dict(required=False, type='str', fallback=(env_fallback, 'ANSIBLE_TEST_FOO')),
    )
    parameters = dict(
        backend='stdout',
    )
    os.environ['ANSIBLE_TEST_FOO'] = 'bar'
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert no_log_values == set()
    assert parameters == dict(backend='stdout', foo='bar')

    parameters['foo'] = 'spam'
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert no_log_values == set()
    assert parameters == dict(backend='stdout', foo='spam')

# Generated at 2022-06-11 01:26:19.515749
# Unit test for function set_fallbacks
def test_set_fallbacks():
    import os

    def _random(length):
        return ''.join(random.choice(string.ascii_lowercase) for _ in range(length))

    length = 10

    original_environ = dict(os.environ)
    original_random = random.choice
    random.choice = lambda x: '0'  # To ensure the first random value is not None

# Generated at 2022-06-11 01:26:29.120775
# Unit test for function sanitize_keys
def test_sanitize_keys():
    class TestClass(object):
        def __init__(self, no_log_values=None):
            if no_log_values is None:
                no_log_values = set()
            self.no_log_values = no_log_values

    class TestSubClass(TestClass):
        pass


# Generated at 2022-06-11 01:27:23.607946
# Unit test for function set_fallbacks
def test_set_fallbacks():
    host = "localhost"
    port = 22
    user = "me"
    fallback_argument_spec = {
        "host": {"fallback": (env_fallback, "ANSIBLE_NET_HOST")},
        "port": {"fallback": (env_fallback, "ANSIBLE_NET_PORT", 22)},
        "user": {"fallback": (env_fallback, "ANSIBLE_NET_USER")},
        "password": {"fallback": (env_fallback, "ANSIBLE_NET_PASSWORD", "default", dict(no_log=True)),
                     "no_log": True},
    }

    parameters = {
        "host": host,
        "port": port,
        "user": user,
    }
    result = set_fallbacks(fallback_argument_spec, parameters)


# Generated at 2022-06-11 01:27:33.394016
# Unit test for function set_fallbacks

# Generated at 2022-06-11 01:27:42.223400
# Unit test for function sanitize_keys
def test_sanitize_keys():
    one_level_dict = dict(
        key1='value1',
        key2='value2',
        answer=42,
        YAY=True,
        nested_dict=dict(x=1, y=2, z=True),
        nested_list=[1, dict(a=2, b=False), 3],
    )

    remove_list = ['value2', 42, '2', 'b']
    result = sanitize_keys(one_level_dict, remove_list)

# Generated at 2022-06-11 01:27:49.423859
# Unit test for function sanitize_keys
def test_sanitize_keys():
    def compare(obj, desired, no_log=None, ignore_keys=None):
        desired = AnsibleModule._ansible_module.deepcopy(desired)
        if no_log is not None:
            no_log = set(no_log)
        if ignore_keys is not None:
            ignore_keys = set(ignore_keys)
        obj2 = sanitize_keys(obj, no_log, ignore_keys)
        # Testing secret
        desired['secret'] = '******'
        assert obj2 == desired

    # Simple types
    assert sanitize_keys(1, None) == 1
    assert sanitize_keys('hello world', None) == 'hello world'

    # Simple list and dict
    compare({'hello': 'world'}, {'hello': 'world'})

# Generated at 2022-06-11 01:28:00.689710
# Unit test for function set_fallbacks

# Generated at 2022-06-11 01:28:11.631362
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # function with fallback
    myfunction = random.randint
    assert set_fallbacks(dict(param=dict(fallback=(myfunction, (1, 5)))), {}) == set()
    assert set_fallbacks(dict(param=dict(fallback=(myfunction, (1, 5)))), dict(param='')) == set()
    assert set_fallbacks(dict(param=dict(fallback=(myfunction, (1, 5)))), dict(param=None)) == set()
    assert set_fallbacks(dict(param=dict(fallback=(myfunction, (1, 5)))), dict(param=0)) == set()
    assert set_fallbacks(dict(param=dict(fallback=(myfunction, (1, 5)))), dict(param=5)) == set()

# Generated at 2022-06-11 01:28:16.473076
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('ANSIBLE_TEST_KEY') == 'ANSIBLE_TEST_VALUE'
    assert_raises(AnsibleFallbackNotFound, env_fallback, 'ANSIBLE_TEST_KEY_NONEXISTENT')
os.environ['ANSIBLE_TEST_KEY'] = 'ANSIBLE_TEST_VALUE'


# Generated at 2022-06-11 01:28:27.982170
# Unit test for function set_fallbacks
def test_set_fallbacks():
    PARAMETER_SPEC = {
        'param1': {
            'type': 'str',
            'fallback': (env_fallback, ('ENV_VAR1', 'ENV_VAR2')),
            'no_log': True
        },
        'param2': {
            'type': 'str',
            'fallback': (env_fallback, ('ENV_VAR3',))
        },
        'param3': {
            'type': 'str',
            'fallback': (env_fallback, (dict(vars=('ENV_VAR4',))))
        },
        'param4': {
            'type': 'str',
            'fallback': (None,)
        }
    }

    parameters = {}

# Generated at 2022-06-11 01:28:35.954313
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        param1=dict(type='int', fallback=(env_fallback, 'TEST_PARAM1')),
        param2=dict(type='int', fallback=(env_fallback, 'TEST_PARAM2')),
        param3=dict(type='str', fallback=(env_fallback, 'TEST_PARAM3')),
    )
    parameters = dict()
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['param1'] == int(os.environ['TEST_PARAM1'])
    assert parameters['param2'] == int(os.environ['TEST_PARAM2'])
    assert parameters['param3'] == os.environ['TEST_PARAM3']
    assert no_log_values == set()

# Generated at 2022-06-11 01:28:47.374691
# Unit test for function remove_values
def test_remove_values():
    from collections import Mapping
    from collections import MutableSet, MutableMapping, MutableSequence

    def _rm(val, to_rm):
        return remove_values(val, to_rm)
