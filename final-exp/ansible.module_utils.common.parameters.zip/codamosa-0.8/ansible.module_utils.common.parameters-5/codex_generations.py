

# Generated at 2022-06-11 01:20:16.355367
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        a=dict(type='str', fallback=('env_fallback', ['FOO'])),
        b=dict(type='str', fallback=('env_fallback', 'FOO')),
        c=dict(type='str', fallback=('env_fallback', dict(key=['FOO']))),
        d=dict(type='dict', fallback=('env_fallback', 'FOO')),
    )

    parameters = dict()
    no_log_values = set()
    no_log_values.update(set_fallbacks(argument_spec, parameters))
    assert len(no_log_values) == 0
    assert 'a' not in parameters
    assert 'b' not in parameters
    assert 'c' not in parameters
    assert 'd' not in parameters



# Generated at 2022-06-11 01:20:22.811105
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys(dict(a=1, b=2), ['a']) == dict(sanitize_keys_1=1, b=2)
    assert sanitize_keys(dict(a=dict(b=dict(c=3, d=4), e=5), f=6), ['a', 'b']) == dict(sanitize_keys_2=dict(sanitize_keys_3=dict(sanitize_keys_4=3, sanitize_keys_5=4), sanitize_keys_6=5), f=6)

# Generated at 2022-06-11 01:20:34.390301
# Unit test for function set_fallbacks
def test_set_fallbacks():
    c = C.Config()
    c.base_dir = os.path.join(os.path.dirname(__file__), '..')
    c.load_plugins(os.path.join(c.base_dir, 'lib', 'ansible', 'plugins'))

# Generated at 2022-06-11 01:20:44.987489
# Unit test for function set_fallbacks

# Generated at 2022-06-11 01:20:54.838202
# Unit test for function sanitize_keys
def test_sanitize_keys():
    def test(hidden, no_log_values, ignore_keys, data, expected_data):
        g_hidden = hidden
        g_no_log_values = no_log_values
        g_ignore_keys = ignore_keys
        g_data = data
        g_expected_data = expected_data
        res = sanitize_keys(g_data, g_ignore_keys, g_hidden, g_no_log_values)
        assert res == g_expected_data

    g1 = {'A_ARG': 'arg1', 'B_ARG': 'arg2', 'C_ARG': 'arg3'}
    g2 = {'A_ARG': 'arg1', 'B_ARG': 'arg2', 'C_ARG': 'arg3'}


# Generated at 2022-06-11 01:21:06.786133
# Unit test for function sanitize_keys
def test_sanitize_keys():
    obj = {'a': {'A': 'a', 'A.a.a': 'a.a.a'}, 'b': {'B': 'b', 'B.b.b': 'b.b.b'}}
    keys = {'a', 'b'}
    no_log_values = {'a', 'b', 'a.a.a', 'b.b.b', 'A', 'B'}
    new_value = sanitize_keys(obj, no_log_values, keys)
    new_value = json.dumps(new_value)

# Generated at 2022-06-11 01:21:15.660470
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'param': {'type': 'str',
                               'fallback': (env_fallback, ['INVALID_PARAM'])}
                     }
    parameters = {}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert len(no_log_values) == 0
    assert len(parameters) == 0

    os.environ['INVALID_PARAM'] = 'test'
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert no_log_values == set()
    assert parameters['param'] == 'test'
    del os.environ['INVALID_PARAM']



# Generated at 2022-06-11 01:21:25.410227
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'param1': {'type': 'str', 'fallback': [env_fallback, ['ANSIBLE_TEST_PARAM']]},
                     'param2': {'type': 'str', 'fallback': [env_fallback, 'ANSIBLE_TEST_PARAM']}}
    parameters = {}
    set_fallbacks(argument_spec, parameters)
    assert_equal(parameters, {'param1': '', 'param2': ''})

    parameters = {'param1': 'test'}
    set_fallbacks(argument_spec, parameters)
    assert_equal(parameters, {'param1': 'test', 'param2': ''})

    parameters = {'param1': '', 'param2': 'test'}
    set_fallbacks(argument_spec, parameters)
    assert_equal

# Generated at 2022-06-11 01:21:35.172397
# Unit test for function set_fallbacks
def test_set_fallbacks():
    expected_return = {'a': 'good', 'b': 'default', 'c': 'env1'}
    params = {'a': 'good'}
    argument_spec = dict(b=dict(fallback=('default',)),
                         a=dict(fallback=(env_fallback, 'env2')),
                         c=dict(fallback=(env_fallback, 'env1', dict(fallback=('default',)))))
    no_log_values = set_fallbacks(argument_spec, params)
    assert params == expected_return
    assert no_log_values == set()

    expected_return = {'a': 'good', 'b': 'default', 'c': 'env1'}
    params = {'a': 'good'}

# Generated at 2022-06-11 01:21:46.058429
# Unit test for function set_fallbacks

# Generated at 2022-06-11 01:22:20.973740
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('test_var') == os.environ['test_var']
    assert env_fallback('test_var', 'test_var2') == os.environ['test_var']
    env_var = 'test_env_fallback'
    os.environ[env_var] = env_var
    assert env_fallback(env_var) == env_var
    assert env_fallback('test_var_not_exists') == None



# Generated at 2022-06-11 01:22:28.316728
# Unit test for function set_fallbacks

# Generated at 2022-06-11 01:22:37.945849
# Unit test for function set_fallbacks
def test_set_fallbacks():
    test_spec = dict(
        foo=dict(fallback=('env_fallback', 'FOO_ENV_FALLBACK')))
    test_parameters = dict()
    assert set_fallbacks(test_spec, test_parameters) == set()
    assert test_parameters == dict()
    test_spec = dict(
        foo=dict(fallback=(env_fallback, 'FOO_ENV_FALLBACK')),
        bar=dict(fallback=(env_fallback, 'BAR_ENV_FALLBACK')))
    test_parameters = dict()
    assert set_fallbacks(test_spec, test_parameters) == set()
    assert test_parameters == dict()

# Generated at 2022-06-11 01:22:48.415507
# Unit test for function sanitize_keys
def test_sanitize_keys():
    data = {
        "sanitize": "OK",
        "sanitize_key": "OK",
        "nested": {
            "sanitize": "OK",
            "sanitize_key": "OK",
        },
        "list_of_dicts": [
            {"sanitize": "OK", "sanitize_key": "OK"},
            {"sanitize": "OK", "sanitize_key": "OK"},
        ],
        "list_of_lists": [
            ["OK", "sanitize_key"],
            ["OK", "sanitize_key"],
        ],

    }

    for no_log_strings in [["_key"], ["sanitize"], ["sanitize_key"]]:
        new_data = sanitize_keys(data, no_log_strings)

# Generated at 2022-06-11 01:23:00.209073
# Unit test for function set_fallbacks

# Generated at 2022-06-11 01:23:09.871505
# Unit test for function set_fallbacks
def test_set_fallbacks():

    # test when fallback exist
    input_1 = 'fallback value'
    argument_spec = {
        'param_1': {
            'type': 'str',
            'fallback': (env_fallback, {'param': 'param_1'}),
            'no_log': True
        }
    }
    parameters = {
        'param_2': input_1
    }
    os.environ['param_1'] = input_1
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert len(no_log_values) == 1
    assert input_1 in no_log_values
    assert 'param_1' in parameters

    # test when fallback does not exist
    input_2 = 'fallback value 2'

# Generated at 2022-06-11 01:23:19.038554
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Test a string param type
    argument_spec1 = {'test_string': dict(type='str', default='start/test_string', fallback=(env_fallback, ['TEST_STRING_ENV_VAR', 'TEST_STRING_ENV_VAR_DEFAULT']))}
    parameters = {'test_string': None}
    no_log_values = set_fallbacks(argument_spec1, parameters)
    assert parameters['test_string'] == 'start/test_string'
    assert no_log_values == set()

    # Test a password param type

# Generated at 2022-06-11 01:23:24.579904
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['FOO_BAR'] = 'FOO'
    assert env_fallback('FOO_BAR') == 'FOO'
    del os.environ['FOO_BAR']
    assert env_fallback('FOO_BAR') == 'FOO'
    del os.environ['FOO_BAR']
    assert env_fallback('foo_bar') == 'FOO'
    del os.environ['FOO_BAR']
    assert env_fallback('foo_bar') == 'FOO'
    del os.environ['FOO_BAR']
    assert env_fallback('FOO_BAR') == 'FOO'



# Generated at 2022-06-11 01:23:30.630459
# Unit test for function set_fallbacks

# Generated at 2022-06-11 01:23:36.350330
# Unit test for function set_fallbacks

# Generated at 2022-06-11 01:24:48.280445
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_NET_VERSION'] = '2.0'
    assert env_fallback('ANSIBLE_NET_VERSION') == '2.0'
    os.environ['ANSIBLE_NET_VERSION'] = ''
    assert env_fallback('ANSIBLE_NET_VERSION') == ''
    os.environ['ANSIBLE_NET_VERSION'] = '2.0'
    assert env_fallback('ANSIBLE_NET_VERSION_NOT_SET') == ''



# Generated at 2022-06-11 01:24:56.376551
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'test': {'fallback': (env_fallback, 'TEST_ENV_VAR'), 'type': 'str'},
                     'test2': {'fallback': (env_fallback, 'TEST2_ENV_VAR'), 'type': 'str', 'default': 'abc'}}
    parameters = {}
    os.environ['TEST_ENV_VAR'] = 'env_var'
    os.environ['TEST2_ENV_VAR'] = 'env2_var'
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters == {'test': 'env_var', 'test2': 'env2_var'}
    assert no_log_values == set()
    parameters = {'test': 'abc'}
    no

# Generated at 2022-06-11 01:25:04.284176
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['FOO'] = "bar"
    assert env_fallback("FOO", "BAR") == "bar"
    assert env_fallback("FOO") == "bar"
    try:
        env_fallback("bar")
        assert False
    except AnsibleFallbackNotFound:
        assert True
    try:
        env_fallback("FOO", "BAR", "BAZ")
        assert False
    except AnsibleFallbackNotFound:
        assert True
    del os.environ['FOO']



# Generated at 2022-06-11 01:25:09.616268
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        common_option=dict(type='int', fallback=(env_fallback, 'COMMON_OPTION')),
        required_option=dict(type='int', fallback=(lambda: 1), required=True),
        option_with_args=dict(type='int', fallback=(env_fallback, 'OPTION_WITH_ARGS')),
        option_with_kwargs=dict(type='int', fallback=(env_fallback, {'arg1': 'test'}))
    )
    params = dict()
    no_log_values = set_fallbacks(argument_spec, params)
    assert len(no_log_values) == 0

    os.environ['COMMON_OPTION'] = '2'
    params = dict()
    no_log_values = set_fall

# Generated at 2022-06-11 01:25:19.561264
# Unit test for function set_fallbacks
def test_set_fallbacks():

    # Test no fallback value is set
    argument_spec = dict(param1=dict(required=False, type='str', fallback=(None,)),
                         param2=dict(required=False, type='str', fallback=(None,)))
    parameters = dict(param2='value2')
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert no_log_values == set()
    assert 'param1' not in parameters

    # Test fallback value is set
    argument_spec = dict(param1=dict(required=False, type='str', fallback=('value1',)),
                         param2=dict(required=False, type='str', fallback=(env_fallback, 'wrongkey', 'RANDOM_KEY')))

# Generated at 2022-06-11 01:25:21.209086
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('FOO') == 'bar'



# Generated at 2022-06-11 01:25:31.345807
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # pylint: disable=unused-argument
    def _test_fallback(value):
        """Test fallback function"""

        return value


# Generated at 2022-06-11 01:25:37.506751
# Unit test for function set_fallbacks
def test_set_fallbacks():
    """Validate that set_fallbacks works properly and doesn't pollute parameters with wrong values"""

    argument_spec = {
        'param1': {'type': 'str', 'fallback': (env_fallback, 'ENV_FALLBACK')},
        'param2': {'type': 'str', 'fallback': (env_fallback, 'ENV_FALLBACK')}
    }
    expected = {'param1': 'ENV_FALLBACK'}
    # The following call is intentionally expected to fail because we pass a wrong string for the fallback
    with pytest.raises(AnsibleFallbackNotFound):
        set_fallbacks(argument_spec, expected)
    assert expected == {'param1': 'ENV_FALLBACK'}

# Generated at 2022-06-11 01:25:40.645541
# Unit test for function env_fallback
def test_env_fallback():
    with patch.dict(os.environ, {'FOO': 'bar'}):
        assert env_fallback('FOO') == 'bar'
        assert env_fallback('BAR') == False
    return True



# Generated at 2022-06-11 01:25:48.197860
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        foo1=dict(type='str', fallback=(env_fallback, 'FOO1')),
        foo2=dict(type='str', fallback=(env_fallback, 'FOO2')),
        foo3=dict(type='str', fallback=(env_fallback, 'FOO3')),
        foo4=dict(type='str', fallback=(env_fallback, dict(key='FOO4', default='nope'))),
        foo5=dict(type='str', no_log=True, fallback=(env_fallback, 'FOO5')),
    )

    parameters = dict(
        foo1='bar1'
    )


# Generated at 2022-06-11 01:27:02.400911
# Unit test for function set_fallbacks
def test_set_fallbacks():
    fb = set_fallbacks({'a': {'type': 'str', 'fallback': (env_fallback, 'ansible_test')}}, {})
    assert len(fb) == 1
    os.environ['ansible_test'] = 'value'
    fb = set_fallbacks({'a': {'type': 'str', 'fallback': (env_fallback, 'ansible_test')}}, {})
    assert len(fb) == 0



# Generated at 2022-06-11 01:27:13.485388
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        foo=dict(type='str', no_log=True, fallback=(env_fallback, 'ANSIBLE_TEST_FOO')),
        bar=dict(type='str', no_log=False, fallback=(env_fallback, 'ANSIBLE_TEST_BAR'))
    )
    parameters = {}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert len(no_log_values) == 0
    assert len(parameters) == 0

    # Empty environment variable
    os.environ['ANSIBLE_TEST_FOO'] = ''
    os.environ['ANSIBLE_TEST_BAR'] = ''
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert len(no_log_values)

# Generated at 2022-06-11 01:27:16.785586
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('TEST_VAR_NOT_EXIST', 'TEST_VAR_NOT_EXIST2') == os.environ['TEST_VAR_NOT_EXIST2']



# Generated at 2022-06-11 01:27:25.298192
# Unit test for function set_fallbacks
def test_set_fallbacks():
    """Test set_fallbacks function"""
    arg_spec = {
        'param1': {'type': 'str', 'fallback': (env_fallback, 'SPEC_PARAM1')},
        'param2': {'type': 'str', 'fallback': (env_fallback, 'SPEC_PARAM2')},
        'param3': {'type': 'str', 'fallback': (env_fallback, 'SPEC_PARAM3')},
    }
    params = {'param3': 'this is a test string'}
    os.environ['SPEC_PARAM1'] = 'a'
    os.environ['SPEC_PARAM2'] = 'b'
    no_log_values = set_fallbacks(arg_spec, params)

# Generated at 2022-06-11 01:27:34.599782
# Unit test for function set_fallbacks
def test_set_fallbacks():

    assert set_fallbacks({'test_fall':{'required':True, 'type':'str', 'fallback':(env_fallback, "TEST_VAR")}}, {}) == set(['TEST_VAR'])
    assert set_fallbacks({'test_fall':{'required':True, 'type':'str', 'fallback':(env_fallback, "TEST_VAR")}}, {'test_fall':'yay'}) == set()
    assert set_fallbacks({'test_fall':{'required':True, 'type':'str', 'fallback':(env_fallback, "TEST_VAR", 'default')}}, {}) == set(['default'])

# Generated at 2022-06-11 01:27:43.131685
# Unit test for function set_fallbacks
def test_set_fallbacks():
    args = dict(
        required_arg=dict(type='str', required=True),
        optional_arg=dict(type='str', required=False),
        logging_arg=dict(type='str', required=False),
        fallback_arg=dict(type='str', required=False, fallback=(env_fallback, ['REQUIRED_ARG'])),
        default_arg=dict(type='str', required=False, default='DEFAULT_ARG'),
        logging_fallback_arg=dict(type='str', required=False, fallback=(env_fallback, ['REQUIRED_ARG']), no_log=True),
    )

    # Test we set fallbacks properly

# Generated at 2022-06-11 01:27:50.652762
# Unit test for function env_fallback
def test_env_fallback():
    '''Validate environment variable fallback for specific variable name and no fallback variable'''
    # Clear environment variable and load fallback variable
    os.environ.pop('ANSIBLE_NET_USERNAME', None)
    os.environ.pop('ANSIBLE_NET_PASSWORD', None)
    username = env_fallback('ANSIBLE_NET_USERNAME')
    assert username == os.environ['ANSIBLE_NET_USERNAME']
    password = env_fallback('ANSIBLE_NET_PASSWORD')
    assert password == os.environ['ANSIBLE_NET_PASSWORD']



# Generated at 2022-06-11 01:27:51.282887
# Unit test for function set_fallbacks
def test_set_fallbacks():
    pass



# Generated at 2022-06-11 01:28:02.843598
# Unit test for function env_fallback
def test_env_fallback():
    test_env = copy.deepcopy(os.environ)
    test_env["TEST_ENV_FALLBACK_ENVVAR_A"] = "test_env_fallback_a"
    test_env["TEST_ENV_FALLBACK_ENVVAR_B"] = "test_env_fallback_b"
    test_env["TEST_ENV_FALLBACK_ENVVAR_C"] = "test_env_fallback_c"
    os.environ = test_env

    assert env_fallback("TEST_ENV_FALLBACK_ENVVAR_A") == "test_env_fallback_a"

# Generated at 2022-06-11 01:28:13.037468
# Unit test for function set_fallbacks
def test_set_fallbacks():
    params = {'one': 'two', 'three': 'four'}