

# Generated at 2022-06-11 01:19:52.830824
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_FOO_BAR'] = 'FOOBAR'
    assert os.environ['ANSIBLE_FOO_BAR'] == env_fallback('ANSIBLE_FOO_BAR')
    del os.environ['ANSIBLE_FOO_BAR']
    try:
       env_fallback('ANSIBLE_FOO_BAR')
       assert False
    except AnsibleFallbackNotFound:
       pass


# Generated at 2022-06-11 01:20:01.572683
# Unit test for function sanitize_keys
def test_sanitize_keys():
    no_log_values = set()
    no_log_values.add('SECRET')
    obj = {
        'first': 1,
        'secRET': 2,
        'other': {
            'foo': {
                'barSECRET': 3,
                'otherfoo': 4
            },
            'bar': {
                'fooSECRET': 5,
                'otherbar': 6
            }
        },
        'not_affected': {
            'fooSECRET': 7,
            'otherbar': 8
        }
    }
    # all value in 'other' dict will be sanitized

# Generated at 2022-06-11 01:20:07.239304
# Unit test for function sanitize_keys

# Generated at 2022-06-11 01:20:14.370611
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        test_key = dict(required=True, fallback=(env_fallback, 'TEST_ENV_VAR')),
    )

    parameters = {}
    os.environ['TEST_ENV_VAR'] = 'TEST_ENV_VALUE'
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert len(no_log_values) == 0

    assert parameters['test_key'] == 'TEST_ENV_VALUE'

    # test that we properly handle fallback for no_log values
    argument_spec['test_key2'] = dict(required=True, fallback=(env_fallback, 'TEST_ENV_VAR_2'), no_log=True)

# Generated at 2022-06-11 01:20:23.854928
# Unit test for function env_fallback
def test_env_fallback():
    """Test that env_fallback function works"""
    # Check default
    try:
        env_fallback()
        assert False, "default env_fallback should have raised error"
    except AnsibleFallbackNotFound as e:
        assert str(e) == "No fallback environment variable specified.", "Unexpected exception message: {0}".format(str(e))
        pass

    # Check no exists
    try:
        env_fallback('TEST_VALUE_ENVIRON')
        assert False, "non-existant env_fallback should have raised error"
    except AnsibleFallbackNotFound as e:
        assert str(e) == "Environment variable TEST_VALUE_ENVIRON not found.", "Unexpected exception message: {0}".format(str(e))
        pass

    # Check exists
    os.en

# Generated at 2022-06-11 01:20:36.048955
# Unit test for function set_fallbacks
def test_set_fallbacks():
    param_spec = {'param1': {'type': 'str', 'fallback': (env_fallback, ['ANSIBLE_TEST_PARAM1'])},
                  'param2': {'type': 'str', 'fallback': (env_fallback, None, {'key': 'ANSIBLE_TEST_PARAM2'})}}
    params = {'param1': 'param1_1', 'param2': 'param2_2'}
    os.environ['ANSIBLE_TEST_PARAM1'] = 'param1_env'
    os.environ['ANSIBLE_TEST_PARAM2'] = 'param2_env'
    no_log_values = set_fallbacks(param_spec, params)
    assert params['param1'] == 'param1_1'

# Generated at 2022-06-11 01:20:37.633838
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback(None) == os.environ[None]

# Generated at 2022-06-11 01:20:47.270803
# Unit test for function remove_values

# Generated at 2022-06-11 01:20:54.979396
# Unit test for function set_fallbacks
def test_set_fallbacks():
    is_fallback_exception_thrown = False
    # fallback should trigger and set parameters['param'] to 'foo'
    parameters = {}
    argument_spec = dict(param=dict(type='str', fallback=(env_fallback, 'FOO')))
    os.environ['FOO'] = 'foo'
    set_fallbacks(argument_spec, parameters)
    assert parameters['param'] == 'foo'

    # fallback should not trigger for parameters['param'] as it already has a value
    parameters = {'param': 'bar'}
    argument_spec = dict(param=dict(type='str', fallback=(env_fallback, 'FOO')))
    set_fallbacks(argument_spec, parameters)
    assert parameters['param'] == 'bar'

    # fallback should not trigger for parameters['param']

# Generated at 2022-06-11 01:21:02.534454
# Unit test for function env_fallback
def test_env_fallback():
    if PY2:
        x = 'HOSTS'
        y = 'NOT_HOSTS'
    else:
        x = b'HOSTS'
        y = b'NOT_HOSTS'

    os.environ[x] = 'example.org'
    assert env_fallback(x) == 'example.org'
    assert env_fallback(y) == AnsibleFallbackNotFound



# Generated at 2022-06-11 01:21:42.218204
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['UNITTEST_VAR'] = 'test'
    assert env_fallback('UNITTEST_VAR') == 'test'
    assert env_fallback('NOT_UNITTEST_VAR') is None

    try:
        env_fallback('NOT_UNITTEST_VAR') is None
    except AnsibleFallbackNotFound:
        pass

    del os.environ['UNITTEST_VAR']


# Generated at 2022-06-11 01:21:51.950711
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'param_with_fallback': {'type': 'str', 'fallback': (env_fallback, 'TEST_PARAM_1')},
        'param_with_fallback_list': {'type': 'list', 'elements': 'str', 'fallback': (env_fallback, 'TEST_PARAM_2')},
        'param_with_fallback_no_log': {'type': 'str', 'no_log': True, 'fallback': (env_fallback, 'TEST_PARAM_3')},
        'param_with_fallback_no_log_list': {'type': 'list', 'elements': 'str', 'no_log': True, 'fallback': (env_fallback, 'TEST_PARAM_4')},
    }

   

# Generated at 2022-06-11 01:22:01.561792
# Unit test for function remove_values
def test_remove_values():
    assert remove_values('foo $bar', ['$']) == 'foo ***'
    assert remove_values('foo $', ['$']) == 'foo $'
    assert remove_values('foo $bar', ['bar']) == 'foo $***'
    assert remove_values('foo $bar', ['foo']) == '*** $bar'
    assert remove_values('foo $bar', ['foo', 'bar']) == '*** ***'

    # Test list of strings
    assert remove_values(['foo $bar', 'bar baz'], ['$']) == ['foo ***', 'bar baz']

    # Test list of lists

# Generated at 2022-06-11 01:22:10.731556
# Unit test for function set_fallbacks
def test_set_fallbacks():
    no_log_values = set()
    argument_spec = dict(param1=dict(fallback=(env_fallback, ['HELLO'])), param2=dict(fallback=(env_fallback, ['WORLD'])), param3=dict(fallback=(env_fallback, ['FOO'])))
    parameters = dict(param2='bar')

    no_log_values = set_fallbacks(argument_spec, parameters)

    assert parameters.get('param1') == 'hello'
    assert parameters.get('param2') == 'bar'
    assert parameters.get('param3') is None



# Generated at 2022-06-11 01:22:20.412120
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        test={'fallback': (env_fallback, 'TEST_FALLBACK')},
        no_log={'fallback': (env_fallback, 'NO_LOG_FALLBACK'), 'no_log': True},
        test2={'fallback': (env_fallback, 'TEST2_FALLBACK', dict(deep=dict(fallback=True)))},
    )
    os.environ['TEST_FALLBACK'] = 'env'
    os.environ['NO_LOG_FALLBACK'] = 'env_no_log_value'
    os.environ['TEST2_FALLBACK'] = 'env'

    parameters = dict(no_log='value', test2=dict(deep=dict()))

# Generated at 2022-06-11 01:22:23.984532
# Unit test for function env_fallback
def test_env_fallback():
    # Test required
    dict_to_check = dict(
        x=dict(required=True),
    )
    os.environ['ANSIBLE_TEST_X'] = 'true'

    with patch('os.environ', os.environ), pytest.raises(AnsibleExitJson):
        set_fallbacks(dict_to_check, dict())


# Generated at 2022-06-11 01:22:29.450194
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'foo': dict(type='path', fallback=(env_fallback, 'BAZ', 'BAR')),
    }
    parameters = {}
    os.environ['BAZ'] = '/some/path'
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['foo'] == '/some/path'
    assert len(no_log_values) == 0



# Generated at 2022-06-11 01:22:32.887286
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback("TEST_ENV_FALLBACK") == os.environ['TEST_ENV_FALLBACK']
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback("TEST_ENV_FALLBACK_DOES_NOT_EXIST")



# Generated at 2022-06-11 01:22:44.224549
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argspec = dict(fallback_param=dict(type='str', no_log=True, fallback=(env_fallback, 'TEST_FALLBACK_VAR')))
    params = dict(other_param='other_value')
    result = set_fallbacks(argspec, params)
    assert result == {'other_value'}
    assert params['other_param'] == 'other_value'
    os.environ['TEST_FALLBACK_VAR'] = 'fallback_value'
    try:
        params = dict()
        result = set_fallbacks(argspec, params)
        assert result == {'fallback_value'}
        assert params['fallback_param'] == 'fallback_value'
    finally:
        del os.environ['TEST_FALLBACK_VAR']



# Generated at 2022-06-11 01:22:53.446787
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        ips=dict(type='list', fallback=(env_fallback, ['ANSIBLE_NET_IPS'])),
        username=dict(type='str', fallback=(env_fallback, ['ANSIBLE_NET_USERNAME'])),
        password=dict(type='str', no_log=True, fallback=(env_fallback, ['ANSIBLE_NET_PASSWORD'])),
    )
    parameters = dict(
        ips=[],
        username=None,
        password=None
    )
    result = dict(
        ips=['10.10.10.10'],
        username='myusername',
        password='mypassword'
    )
    os.environ['ANSIBLE_NET_IPS'] = '10.10.10.10'

# Generated at 2022-06-11 01:23:30.018130
# Unit test for function remove_values
def test_remove_values():
    assert remove_values('', ['']) == ''
    assert remove_values('foo', ['']) == 'foo'
    assert remove_values('foo', ['foo']) == ''
    assert remove_values('foo bar bar bar', ['bar']) == 'foo   '
    assert remove_values(['a', 'b', ['c', 'd'], {'e': 'f', 'g': 'h'}], ['c', 'e']) == ['a', 'b', [], {'g': 'h'}]


# Generated at 2022-06-11 01:23:35.883100
# Unit test for function set_fallbacks
def test_set_fallbacks():
    class TestException(Exception):
        def __init__(self, message):
            super(Exception, self).__init__(self, message)
            self.message = message
    def test_function(test_argument, not_test_argument):
        if test_argument == 'test_argument':
            raise TestException('test_function was called with argument {}'.format(test_argument))
        else:
            raise TestException('test_function was called with argument {}'.format(not_test_argument))
    def test_kwargs_function(**kwargs):
        if 'test_argument' in kwargs:
            requested_argument = kwargs['test_argument']
        else:
            requested_argument = 'not_test_argument'

# Generated at 2022-06-11 01:23:43.231091
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['__TEST_ENV_FALLBACK'] = 'bla'
    assert env_fallback('__TEST_ENV_FALLBACK') == 'bla'
    try:
        env_fallback('__UNSET_ENV_VALUE')
    except AnsibleFallbackNotFound:
        pass
    else:
        assert False, "should not have found any fallback value"
    del os.environ['__TEST_ENV_FALLBACK']



# Generated at 2022-06-11 01:23:54.523041
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # setup argument_spec
    argument_spec = dict(
        username=dict(
            required=True,
            type='str',
        ),
        password=dict(
            type='str',
            fallback=(env_fallback, ['ANSIBLE_NET_PASSWORD']),
            no_log=True,
        ),
        host=dict(
            type='str',
            fallback=(env_fallback, ['ANSIBLE_NET_HOST']),
        ),
    )
    # set up parameters and expected result
    parameters = dict(
        username='username',
        password=None,
        host=None,
    )
    expected_result = dict(
        username='username',
        password='12345',
        host='10.1.1.1',
    )
    # set up environment variables
    os

# Generated at 2022-06-11 01:23:59.345005
# Unit test for function set_fallbacks
def test_set_fallbacks():

    argument_spec = dict(
        baz=dict(type='str'),
        foo=dict(type='str', fallback=('env', 'ANSIBLE_FOO', dict(fallback='default'))),
    )

    # Ensure env fallback works
    os.environ['ANSIBLE_FOO'] = 'myenv'
    params = dict(baz='qux')
    no_log_values = set_fallbacks(argument_spec, params)
    assert params == dict(baz='qux', foo='myenv')
    assert no_log_values == set()
    os.environ.pop('ANSIBLE_FOO')

    # Ensure default fallback works
    params = dict(baz='qux')
    no_log_values = set_fallbacks(argument_spec, params)
    assert params == dict

# Generated at 2022-06-11 01:24:00.714498
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('ANSIBLE_NO_LOG', 'ANSIBLE_DEBUG') == os.environ['ANSIBLE_NO_LOG']



# Generated at 2022-06-11 01:24:07.015498
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Invalid fallback key
    argument_spec = {
        'key1': {'fallback': ('test_fallback_key', 'test_value')},
    }
    parameters = {
        'key2': ['value2'],
    }
    no_log_values = set()
    assert set_fallbacks(argument_spec, parameters) == no_log_values

    # Invalid fallback value
    argument_spec = {
        'key1': {'fallback': ('env_fallback', 'does_not_exist')},
    }
    parameters = {
        'key2': ['value2'],
    }
    no_log_values = set()
    assert set_fallbacks(argument_spec, parameters) == no_log_values

    # Valid fallback value

# Generated at 2022-06-11 01:24:15.869255
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'foo': dict(fallback=(env_fallback, 'FOO')), 'bar': dict(fallback=(env_fallback, 'BAR', 'BAZ')), 'bam': dict(fallback=(dict, {'name': 'BAM'}))}
    parameters = dict()

    no_log_values = set_fallbacks(argument_spec, parameters)

    assert parameters.get('foo') == 'FOO'
    assert parameters.get('bar') == 'BAR'
    assert parameters.get('bam') == {'name': 'BAM'}

    assert no_log_values == set(['FOO', 'BAR'])



# Generated at 2022-06-11 01:24:27.202589
# Unit test for function set_fallbacks

# Generated at 2022-06-11 01:24:39.055335
# Unit test for function sanitize_keys
def test_sanitize_keys():
    """Unit tests for function sanitize_keys"""

    # Dict tests
    assert u'sanitized_key' == sanitize_keys({u'key': u'value'}, [u'key'])[u'sanitized_key']
    assert u'key' == sanitize_keys({u'key': u'value'}, [u'key'], ignore_keys=[u'key'])[u'key']

    # List tests
    assert u'sanitized_item' == sanitize_keys([u'item'], [u'item'])[0]
    assert u'item' == sanitize_keys([u'item'], [u'item'], ignore_keys=[u'item'])[0]

    # Tuple tests

# Generated at 2022-06-11 01:25:13.479411
# Unit test for function set_fallbacks
def test_set_fallbacks():
    bad_spec = dict(a=dict(type='str', fallback=(env_fallback, None, 'BAD_STR')))
    parameters = dict()
    no_log_values = set()

    with pytest.raises(AnsibleValidationError, match='Internal error'):
        set_fallbacks(bad_spec, parameters)
    assert parameters == {}
    assert no_log_values == set()

    good_spec = dict(a=dict(type='str', fallback=(env_fallback, 'FOO')))
    parameters = dict()
    no_log_values = set()
    os.environ['FOO'] = 'foo'

# Generated at 2022-06-11 01:25:26.082739
# Unit test for function sanitize_keys
def test_sanitize_keys():
    # Test dict
    no_log_strings = ['super', 'secret']
    password = 'supersupersecret'
    s = {'password': password, 'pass': 'password', 'pass_2': 'password'}
    new_s = sanitize_keys(s, no_log_strings)
    assert isinstance(new_s, dict)
    assert list(new_s.keys()) == ['password', 'pass', 'pass_2']
    assert list(new_s.values()) == [password, 'password', 'password']

    # Test list
    no_log_strings = ['super', 'secret']
    password = 'supersupersecret'
    s = ['password', 'pass', 'pass_2', password]
    new_s = sanitize_keys(s, no_log_strings)

# Generated at 2022-06-11 01:25:31.117948
# Unit test for function env_fallback
def test_env_fallback():
    """ Test function env_fallback """
    arg1 = "PATH"
    arg2 = "TEST"
    assert env_fallback(arg1) == os.environ[arg1]
    assert env_fallback(arg1, arg2) == os.environ[arg1]
    assert_raises(AnsibleFallbackNotFound, env_fallback, arg2)
    assert_raises(AnsibleFallbackNotFound, env_fallback)



# Generated at 2022-06-11 01:25:41.731786
# Unit test for function env_fallback
def test_env_fallback():
    # env_fallback()
    try:
        env_fallback()
    except AnsibleFallbackNotFound:
        pass

    # env_fallback('')
    try:
        env_fallback('')
    except AnsibleFallbackNotFound:
        pass

    # env_fallback('HOME')
    if os.environ.get('HOME'):
        assert env_fallback('HOME') == os.environ.get('HOME')
    else:
        try:
            env_fallback('HOME')
        except AnsibleFallbackNotFound:
            pass

    # env_fallback('HOME', 'USER')
    if os.environ.get('HOME'):
        assert env_fallback('HOME', 'USER') == os.environ.get('HOME')

# Generated at 2022-06-11 01:25:48.844914
# Unit test for function set_fallbacks
def test_set_fallbacks():
    ARGUMENT_SPEC = {'param1': {'required': True, 'type': 'str',
                                'fallback': (env_fallback, ('ANSIBLE_PARAM',))},
                     'param2': {'type': 'bool', 'default': True,
                                'fallback': (env_fallback, ('ANSIBLE_PARAM_BOOL',))},
                     'param3': {'type': 'int',
                                'fallback': (env_fallback, ('ANSIBLE_PARAM_INT',))}}
    parameters = {}
    no_log_values = set_fallbacks(ARGUMENT_SPEC, parameters)
    assert len(no_log_values) == 0
    assert parameters == {}

    os.environ['ANSIBLE_PARAM_BOOL'] = 'TRUE'
    parameters = {}

# Generated at 2022-06-11 01:25:59.877084
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        foo = dict(type='str', fallback=(env_fallback, 'TEST_FOO')),
        bar = dict(type='str', fallback=(env_fallback, 'TEST_BAR')),
        baz = dict(type='str', fallback=(env_fallback, 'TEST_BAZ')),
        gaz = dict(type='str', fallback=(env_fallback, 'TEST_GAZ')),
    )
    parameters = dict(foo='foo')
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert no_log_values == set()
    assert parameters == dict(foo='foo', bar='bar')
    assert os.environ['TEST_FOO'] == 'foo'


# Generated at 2022-06-11 01:26:10.339739
# Unit test for function set_fallbacks
def test_set_fallbacks():
    '''
    Test set_fallbacks from ansible.module_utils.common.validation
    '''
    # import pdb
    # pdb.set_trace()

    fallback_arg_spec = dict(
        param1=dict(
            type='str',
            fallback=(env_fallback, ("FALLBACK_PARAM", {"default": "fooboo"})
                      ),
            no_log=True
        ),
        param2=dict(
            type='str',
            fallback=(env_fallback, ("FALLBACK_PARAM2",)
                      ),
            no_log=True
        )
    )

    parameters1 = dict()
    no_log_values = set_fallbacks(fallback_arg_spec, parameters1)
    assert "fooboo" in no_log_values

# Generated at 2022-06-11 01:26:19.940340
# Unit test for function set_fallbacks

# Generated at 2022-06-11 01:26:26.406837
# Unit test for function env_fallback
def test_env_fallback():
    """ env_fallback: Test that the environment fallback correctly loads from the environment """

    with mock.patch.dict(os.environ, {'ANSIBLE_TEST_ENV_FALLBACK': 'environ test'}):
        assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'environ test'
        assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_DOESNT_EXIST') == 'environ test'

    with mock.patch.dict(os.environ, {}):
        with pytest.raises(AnsibleFallbackNotFound):
            env_fallback('ANSIBLE_TEST_ENV_FALLBACK_DOESNT_EXIST')



# Generated at 2022-06-11 01:26:30.713964
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == os.environ['ANSIBLE_TEST_ENV_FALLBACK']
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('not_set')



# Generated at 2022-06-11 01:27:31.065817
# Unit test for function sanitize_keys
def test_sanitize_keys():
    testobj = {'test_key1': 'test_value1',
               'test_key2': 'test_value2',
               'test_key3': 'test_value3',
               '_ansible_ignore_errors': 'test_value4'}

    expectedresult = {'test_key1': 'test_value1',
                      'test_key2': 'test_value2',
                      'test_key3': 'test_value3',
                      '_ansible_ignore_errors': 'test_value4'}

    result = sanitize_keys(testobj, ['test_value2', 'test_value3'])
    assert result == expectedresult



# Generated at 2022-06-11 01:27:39.162912
# Unit test for function env_fallback
def test_env_fallback():
    os.environ["FOO"] = 'bar'
    assert env_fallback("FOO") == 'bar'
    # This would fail with IndexError if 3 was not a valid list index
    assert env_fallback("NOT_SET_ENV_VAR", "NOT_SET_ENV_VAR", "FOO") == 'bar'
    assert env_fallback("NOT_SET_ENV_VAR", "NOT_SET_ENV_VAR", "NOT_SET_ENV_VAR") == 'NOT_SET_ENV_VAR'
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback("NOT_SET_ENV_VAR")


# Generated at 2022-06-11 01:27:45.988576
# Unit test for function remove_values
def test_remove_values():
    # TODO: Move to test_utils_module
    import os

    class Container(object):
        def __init__(self, value):
            self.value = value

    class Private(Container):
        pass

    class NoLog(Container):
        pass

    class MutableSequenceContainer(MutableSequence):
        def __init__(self, *args):
            self._list = list(*args)

        def __delitem__(self, key):
            del self._list[key]

        def insert(self, key, value):
            self._list.insert(key, value)

        def __setitem__(self, key, value):
            self._list[key] = value

        def __getitem__(self, i):
            return self._list[i]

        def __len__(self):
            return

# Generated at 2022-06-11 01:27:53.297595
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'foo': {'type': 'str', 'fallback': (env_fallback, 'FOO'), 'no_log': True},
                     'bar': {'type': 'str', 'fallback': env_fallback, 'no_log': True}}
    parameters = {}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters == {'bar': 'ANSIBLE_NET_USERNAME'}
    assert no_log_values == set(['ANSIBLE_NET_USERNAME'])



# Generated at 2022-06-11 01:28:04.891055
# Unit test for function set_fallbacks

# Generated at 2022-06-11 01:28:12.704611
# Unit test for function env_fallback
def test_env_fallback():
    """Unit test for env_fallback"""

    os.environ['TEST'] = 'test'
    os.environ['TEST2'] = '2'
    for arg in ['TEST', 'TEST2']:
        assert env_fallback(arg) == os.environ[arg]
    os.environ.pop('TEST')
    os.environ.pop('TEST2')
    assert env_fallback('TEST', 'TEST2') == 'TEST2'

    try:
        env_fallback()
        assert False
    except AnsibleFallbackNotFound:
        pass



# Generated at 2022-06-11 01:28:21.222399
# Unit test for function env_fallback
def test_env_fallback():
    env_vars = ('ANSIBLE_NET_USERNAME', 'ANSIBLE_NET_PASSWORD')
    with mock.patch.dict('os.environ', {'ANSIBLE_NET_USERNAME': 'test_user', 'ANSIBLE_NET_PASSWORD': 'test_password'}):
        assert env_fallback(*env_vars) == 'test_user'
    with mock.patch.dict('os.environ', {'ANSIBLE_NET_PASSWORD': 'test_password'}):
        assert env_fallback(*env_vars) == 'test_password'
    assert env_fallback('')



# Generated at 2022-06-11 01:28:32.213333
# Unit test for function remove_values
def test_remove_values():
    no_log_strings = ('password', 'secret', 'passphrase')

# Generated at 2022-06-11 01:28:38.638623
# Unit test for function set_fallbacks
def test_set_fallbacks():
    args = dict(
    foo = dict(
        options = dict(
            bar = dict(
                type = 'str',
                required = True,
                fallback = (env_fallback, 'FOO_BAR'),
            ),
        ),
    ),
)
    os.environ['FOO_BAR'] = 'test'
    parameters = {}
    set_fallbacks(args, parameters)
    assert parameters['bar'] == 'test'
    del os.environ['FOO_BAR']



# Generated at 2022-06-11 01:28:40.673779
# Unit test for function env_fallback
def test_env_fallback():
    result = env_fallback('test')
    assert result == 'test'

