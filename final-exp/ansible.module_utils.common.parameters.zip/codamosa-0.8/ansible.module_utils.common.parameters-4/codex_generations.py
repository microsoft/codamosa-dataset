

# Generated at 2022-06-11 01:19:56.739939
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        param1=dict(type='str', fallback=(env_fallback, "TEST_ENV_VAR_1")),
        param2=dict(type='str', fallback=(env_fallback, "TEST_ENV_VAR_2", dict(fallback_var=True))),
        param3=dict(type='str', fallback=(env_fallback, "TEST_ENV_VAR_3", dict(fallback_var=False))),
        param4=dict(type='str', fallback=('wibble', "TEST_ENV_VAR_4")),
        param5=dict(type='str', fallback=(env_fallback, "TEST_ENV_VAR_5", "param5"), no_log=True),
    )
    #

# Generated at 2022-06-11 01:20:03.778170
# Unit test for function sanitize_keys

# Generated at 2022-06-11 01:20:12.783281
# Unit test for function set_fallbacks
def test_set_fallbacks():
    param_spec = dict(param1=dict(type='str', fallback=(env_fallback, 'ANSIBLE_PARAM1', 'ANSIBLE_PARAM2')))
    parameters = dict()
    no_log_values = set_fallbacks(param_spec, parameters)
    assert len(no_log_values) == 0
    os.environ['ANSIBLE_PARAM1'] = 'param1_value'
    parameters = dict()
    no_log_values = set_fallbacks(param_spec, parameters)
    assert parameters == {'param1': 'param1_value'}
    assert len(no_log_values) == 0
    os.environ['ANSIBLE_PARAM2'] = 'param2_value'
    parameters = dict()

# Generated at 2022-06-11 01:20:22.668139
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Test fallbacks
    argument_spec = {'test': {'required': True, 'fallback': (env_fallback, ['TEST_VAR'])}}
    parameters = {}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert len(no_log_values) == 0

    # Test fallbacks with no_log
    argument_spec = {'test': {'required': True, 'fallback': (env_fallback, ['TEST_VAR']), 'no_log': True}}
    parameters = {}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert len(no_log_values) == 0

    # Env variable is not set
    os.environ.pop('TEST_VAR', None)

# Generated at 2022-06-11 01:20:34.183141
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(b=dict(type='str', default='bar'))
    parameters = dict(a='foo')

    assert set_fallbacks(argument_spec, parameters) == set()
    assert parameters['b'] == 'bar'

    fallback_values = dict(a='bar')
    assert set_fallbacks(argument_spec, fallback_values) == set()
    assert fallback_values['a'] == 'bar'

    fallback_values = dict(a=dict(type='str', default='bar'))
    assert set_fallbacks(argument_spec, fallback_values) == set()
    assert fallback_values['a'] == 'bar'

    fallback_values = dict(
        b=dict(type='str', default='baz', no_log=True)
    )
    assert set_

# Generated at 2022-06-11 01:20:35.309907
# Unit test for function env_fallback
def test_env_fallback():
    assert True



# Generated at 2022-06-11 01:20:45.531789
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        foo=dict(required=True),
        bar=dict(required=True),
        baz=dict(required=True, fallback=(env_fallback, 'BAZ')),
        bip=dict(fallback=(env_fallback, 'BAZ')),
    )
    parameters = dict(foo='one', bar='two')
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters == dict(foo='one', bar='two', baz='three')
    assert no_log_values == set()
    os.environ['BAZ'] = 'three'
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters == dict(foo='one', bar='two', baz='three')

# Generated at 2022-06-11 01:20:54.909602
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'string': {'type': 'str', 'fallback': (env_fallback, 'STR')},
        'int': {'type': 'int', 'fallback': (env_fallback, 'INT')},
        'bool': {'type': 'bool', 'fallback': (env_fallback, 'BOOL')},
        'list': {'type': 'list', 'fallback': (env_fallback, 'LIST')},
        'dict': {'type': 'dict', 'fallback': (env_fallback, 'DICT')},
    }

    parameters = {}

    set_fallbacks(argument_spec, parameters)

    assert parameters['string'] == os.environ['STR'], "String fallback value did not work"

# Generated at 2022-06-11 01:21:04.072931
# Unit test for function set_fallbacks
def test_set_fallbacks():
    """
    Test function of set_fallbacks
    """
    argument_spec = {'test_param': {'type': 'str', 'fallback': (env_fallback, 'test_env')}}
    parameters = {}
    os.environ['test_env'] = 'test_env_value'
    result_no_log_values = set_fallbacks(argument_spec, parameters)
    assert result_no_log_values == set(['test_env_value'])
    assert parameters == {'test_param': 'test_env_value'}



# Generated at 2022-06-11 01:21:12.134344
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # test fallback with no_log=True
    parameter_spec = dict(
        foo=dict(type='str', fallback=(env_fallback, 'FOO', dict(no_log=True))),
        bar=dict(type='str', fallback=(env_fallback, 'BAR')),
        )
    parameters = dict(foo=None, bar='bar')

    no_log_values = set_fallbacks(parameter_spec, parameters)
    assert 'bar' not in no_log_values
    assert 'foo' in no_log_values

    # test fallback not found

# Generated at 2022-06-11 01:21:45.079946
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'foo': {'fallback': (env_fallback, ['ANSIBLE_FOO'])}, 'bar': {'fallback': (env_fallback, ['ANSIBLE_BAR'])}}
    parameters = {}

    no_log_values = set_fallbacks(argument_spec, parameters)

    assert parameters['foo'] == parameters['bar'] == 'bar'
    assert no_log_values == set()



# Generated at 2022-06-11 01:21:51.949348
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert set_fallbacks({"test1": {"fallback": (env_fallback, "test2")}},
                         {}) == set()
    assert set_fallbacks({"test1": {"fallback": (env_fallback, "test2")}},
                         {'test1': 'test3'}) == set()
    os.environ['test2'] = 'test4'
    assert set_fallbacks({"test1": {"fallback": (env_fallback, "test2")}},
                         {}) == set(['test4'])
    del os.environ['test2']



# Generated at 2022-06-11 01:21:57.957221
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLINUX_TEST']='123'
    assert env_fallback('ANSIBLINUX_TEST') == '123'
    os.environ['ANSIBLINUX_TEST']='456'
    assert env_fallback('ANSIBLINUX_TEST') == '456'
    # Should this raise an exception?
    #os.environ['ANSIBLINUX_TEST']=None
    #assert env_fallback('ANSIBLINUX_TEST') == None
    os.environ.pop('ANSIBLINUX_TEST')
    try:
        env_fallback('ANSIBLINUX_TEST')
    except AnsibleFallbackNotFound:
        pass
test_env_fallback()



# Generated at 2022-06-11 01:22:09.969328
# Unit test for function remove_values
def test_remove_values():
    import unittest

    class TestRemoveValues(unittest.TestCase):
        def test_basics(self):
            value = 'hello world'
            self.assertEqual(remove_values(value, []), value)
            self.assertEqual(remove_values(value, ['hello']), '********* world')
            self.assertEqual(remove_values(value, ['hello', 'world']), '********* *******')

        def test_lists(self):
            value = [
                ['hello', 'world'],
                'hello world',
                ['hello', ['world', ['hello world']]]
            ]
            expected = [
                ['hello', 'world'],
                '********* world',
                ['hello', ['world', ['********* world']]]
            ]

# Generated at 2022-06-11 01:22:19.405456
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert set_fallbacks({
        'foo': {'type': 'str'},
        'bar': {'type': 'str'},
        'baz': {'type': 'str', 'fallback': (str, ['qux'])}
    }, {}) == set()

    os.environ['FOO'] = 'env_foo'
    assert set_fallbacks({
        'foo': {'type': 'str', 'fallback': (env_fallback, ['FOO'])},
        'bar': {'type': 'str'},
    }, {}) == set()
    assert set_fallbacks({
        'foo': {'type': 'str', 'fallback': (env_fallback, ['FOO'])},
        'bar': {'type': 'str'},
    }, {}) == set()
   

# Generated at 2022-06-11 01:22:25.384867
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'name': {'type': 'str', 'default': 'foo'},
                     'password': {'type': 'str', 'default': 'foo', 'no_log': True},
                     'env': {'type': 'str', 'fallback': (env_fallback, ['ANSIBLE_TEST_ENV'])}}
    assert set_fallbacks(argument_spec, {'name': 'foo'}) == set()
    assert set_fallbacks(argument_spec, {'name': 'foo', 'password': 'foo'}) == set(['foo'])
    assert set_fallbacks(argument_spec, {'env': 'test'}) == set()



# Generated at 2022-06-11 01:22:34.145768
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Check that fallback works
    argument_spec = {'arg1': dict(fallback=(env_fallback, "arg1"))}
    parameters = dict(arg2='somevalue')
    os.environ['arg1'] = 'somevalue'
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['arg1'] == os.environ['arg1']
    assert len(no_log_values) == 0

    # Check that multiple fallbacks work
    argument_spec = {'arg1': dict(fallback=(env_fallback, "arg1", "arg2"))}
    parameters = dict(arg3='somevalue')
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['arg1'] == os.environ['arg1']

# Generated at 2022-06-11 01:22:45.803582
# Unit test for function remove_values
def test_remove_values():
    # Testing no_log_strings containing text and also containing a list. We only want to remove strings.
    no_log_strings = ['pw', 'id_rsa', 'A', ['password', 'A']]
    test_str = 'password'
    test_dict = {'password': 'pw', 'blah': 'b', 'blahblah': 'pw', 'blahblahpw': 'pwpw'}
    test_list = ['password', 'blah', 'blahblah', 'blahblahpw']
    test_tuple = ('password', 'blah', 'blahblah', 'blahblahpw')
    test_set = {'password', 'blah', 'blahblah', 'blahblahpw'}

# Generated at 2022-06-11 01:22:55.574635
# Unit test for function set_fallbacks

# Generated at 2022-06-11 01:23:00.778334
# Unit test for function set_fallbacks
def test_set_fallbacks():
    arg = dict(fallback=('env', 'AZURE_CLIENT_ID'))
    spec = dict(client=arg)
    values = {}
    set_fallbacks(spec, values)
    assert values['client'] == os.environ['AZURE_CLIENT_ID']


# Generated at 2022-06-11 01:23:46.324520
# Unit test for function sanitize_keys
def test_sanitize_keys():
    mydict = {"foo": "bar", "pass": "secret", "ansible_yes": "yes", "ansible_no": "no"}
    mydict_result = {"_ansible_yes": "yes", "pass": "secret", "foo": "bar", "_ansible_no": "no"}
    assert sanitize_keys(mydict, set(["pass"])) == mydict_result



# Generated at 2022-06-11 01:23:57.196723
# Unit test for function sanitize_keys
def test_sanitize_keys():
    ret = sanitize_keys(
            {'1k1': {'1k2': {'1k3': {'1k4': '1v4', 'pem': 'pemvalue'}, '1v2': '1val2'}, '1v1': '1val1'},
             '2k1': {'pem': 'pemvalue'}, '3k1': ['pemvalue']},
            no_log_strings=['pemvalue'],
            ignore_keys=['1k3'])

# Generated at 2022-06-11 01:24:03.940527
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # No 'fallback' defined
    argument_spec = {'foo': {}}
    parameters = {}
    no_log = set_fallbacks(argument_spec, parameters)
    assert no_log == set()
    assert parameters == {}

    # single fallback value
    argument_spec = {'foo': {'fallback': (env_fallback, 'FOO')}}
    parameters = {}
    no_log = set_fallbacks(argument_spec, parameters)
    assert no_log == set()
    assert parameters == {'foo': 'baz'}

    # multiple fallback values, only one of which exists
    argument_spec = {'foo': {'fallback': (env_fallback, ['FOO', 'BAR'])}}
    parameters = {}

# Generated at 2022-06-11 01:24:11.415151
# Unit test for function set_fallbacks
def test_set_fallbacks():
    empty_params = {}
    fallback_spec = dict(
        key1=dict(
            fallback=(list, ['foo']),
        ),
        key2=dict(
            fallback=(tuple, ('foo',)),
        ),
        key3=dict(
            fallback=(env_fallback, ('FOO',)),
        ),
    )

    no_log_values = set_fallbacks(fallback_spec, empty_params)
    assert no_log_values == set(), "no_log_values was not empty: %s" % no_log_values

    # We should have added two params: key1 and key2
    assert len(empty_params) == 2, "empty_params wasn't updated from the fallbacks: %s" % empty_params

    # FOO isn't present in the EMPTY_PARAMS

# Generated at 2022-06-11 01:24:23.773372
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['FOO'] = 'BAR'
    assert env_fallback('FOO') == 'BAR'
    assert env_fallback('FOO', 'BAR') == 'BAR'
    assert env_fallback('FOO', 'BAR', 'BAZZ') == 'BAR'
    try:
        env_fallback('FOO', 'BAR', 'BAZZ', 'XYZ')
    except AnsibleFallbackNotFound:
        pass
    else:
        fail("env_fallback('FOO', 'BAR', 'BAZZ', 'XYZ' should raise AnsibleFallbackNotFound")
    try:
        env_fallback('FOOP', 'BAR')
    except AnsibleFallbackNotFound:
        pass

# Generated at 2022-06-11 01:24:35.630743
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'test': {'fallback': (env_fallback, ("TEST", "TEST1"), {'arg': "default value"})}}
    parameters = {'test': "parameter value"}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert 'parameter value' in no_log_values
    assert 'not found' not in no_log_values
    assert parameters['test'] == 'parameter value'
    parameters = {}
    os.environ['TEST'] = "env value"
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert 'parameter value' not in no_log_values
    assert 'not found' not in no_log_values
    assert parameters['test'] == 'env value'
    del os.environ

# Generated at 2022-06-11 01:24:47.063448
# Unit test for function set_fallbacks

# Generated at 2022-06-11 01:24:53.408680
# Unit test for function set_fallbacks

# Generated at 2022-06-11 01:25:05.154231
# Unit test for function set_fallbacks
def test_set_fallbacks():
    module_args = dict(
        test_dict=dict(
            test_dict_key_int=None,
            test_dict_key_str=None,
            test_dict_key_dict=None,
            test_dict_key_list=None,
        ),
        test_str=None,
        test_int=None,
        test_list=None,
        test_dict_key_int=None,
        test_dict_key_str=None,
        test_dict_key_dict=None,
        test_dict_key_list=None,
    )

    def module_mock(module_args, **kwargs):
        return module_args


# Generated at 2022-06-11 01:25:13.930126
# Unit test for function set_fallbacks
def test_set_fallbacks():
    class AnsibleFallbackNotFoundException(Exception):
        pass

    def func1(*args, **kwargs):
        if 'TEST_ARG' in os.environ:
            return os.environ['TEST_ARG']
        raise AnsibleFallbackNotFoundException('TEST_ARG not found')

    def func2(*args, **kwargs):
        if 'TEST_ARG' in os.environ:
            return os.environ['TEST_ARG']
        raise AnsibleFallbackNotFoundException('TEST_ARG not found')


# Generated at 2022-06-11 01:25:43.094025
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        test1=dict(
            fallback=(lambda: 'test1-fallback',)
        ),
        test2=dict(
            fallback=(lambda: 'test2-fallback',)
        ),
        test3=dict(
            fallback=(env_fallback, 'TEST3')
        ),
        test4=dict(
            fallback=(env_fallback, 'TEST4')
        ),
        test5=dict(
            fallback=(lambda: 'test5-fallback', dict(no_log=True))
        )
    )
    expected_params_1 = dict(test1='test1-fallback')
    expected_params_2 = dict(test3='test3-fallback', test4='test4-fallback')
    expected_no_log_values_

# Generated at 2022-06-11 01:25:52.469355
# Unit test for function set_fallbacks
def test_set_fallbacks():
    _set_fallbacks = lambda spec, params: set_fallbacks(spec, params)
    spec = dict(arg1=dict(fallback=(env_fallback, 'arg1_env')), arg2=dict(fallback=(env_fallback, 'arg2_env')))
    assert not _set_fallbacks(spec, {})

    os.environ['arg1_env'] = 'val1'
    assert _set_fallbacks(spec, {}) == {'arg1': 'val1'}

    os.environ['arg2_env'] = 'val2'
    assert _set_fallbacks(spec, {'arg1': None}) == {'arg1': None, 'arg2': 'val2'}



# Generated at 2022-06-11 01:26:03.272759
# Unit test for function set_fallbacks
def test_set_fallbacks():
    def fake_env_fallback():
        raise Exception("cannot call fake_env_fallback")


# Generated at 2022-06-11 01:26:13.872879
# Unit test for function env_fallback
def test_env_fallback():
    # Check if ansible_test_env is set in environment. If so, unset it.
    # If not, set it to the value 'Test_ENV
    env = 'ansible_test_env'
    if env in os.environ:
        saved = os.environ[env]
        del os.environ[env]
    else:
        os.environ[env] = 'Test_ENV'
        saved = None

    # Check if env_fallback works with environment variables
    assert env_fallback(env) == 'Test_ENV'

    # Restore environment and try again
    if saved is None:
        del os.environ[env]
    else:
        os.environ[env] = saved

    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback

# Generated at 2022-06-11 01:26:22.455033
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys('test', ['fail']) == 'test'
    # List test
    test_list = ['test1', 'test2', 'test3']
    assert sanitize_keys(test_list, ['fail']) == test_list
    test_dict = {'test1': 'test1', 'test2': 'test2', 'test3': 'test3'}
    assert sanitize_keys(test_dict, ['fail']) == test_dict

    test_dict = {'test1': 'test1', 'test2': 'test2', 'test3': 'test3'}
    expected = {'test1': 'test1', 'test2': '****', 'test3': 'test3'}
    assert sanitize_keys(test_dict, ['test2']) == expected


# Generated at 2022-06-11 01:26:32.571096
# Unit test for function sanitize_keys
def test_sanitize_keys():
    data = {'a': {'a': {'c': {'b': 'b', 'a': 'b'}, 'b': 'a', 'c': 'c'}, 'b': {'a': 'd', 'b': 'e'}, 'c': {'a': 'f', 'b': 'g'}},
            'b': 'a',
            'c': 'b',
            'd': 'c',
            'e': {'a': {'a': 'b', 'c': 'a'}, 'b': 'b', 'c': 'd'},
            'f': {'a': 'a', 'b': 'b', 'c': 'c'},
            'g': ['a', 'b', {'c': 'd', 'b': 'e'}]}

# Generated at 2022-06-11 01:26:40.726842
# Unit test for function set_fallbacks
def test_set_fallbacks():
    '''
    Test the functionality of set_fallbacks.
    '''

    # Set up a spec and input parameters

# Generated at 2022-06-11 01:26:51.341160
# Unit test for function set_fallbacks
def test_set_fallbacks():

    class TestModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs

    args = dict(
        param1="1",
        param2="2",
        param3="3"
    )
    test_module = TestModule(**args)

    spec = {}
    spec['param1'] = dict(required=True)
    spec['param2'] = dict(fallback=(env_fallback, 'SPEC_ENV_PARAM2'))
    spec['param3'] = dict(fallback=(env_fallback, 'SPEC_ENV_PARAM3'))


# Generated at 2022-06-11 01:26:57.142131
# Unit test for function sanitize_keys
def test_sanitize_keys():
    from os.path import abspath, expanduser, expandvars
    from sys import version_info

    no_log_strings = set()

# Generated at 2022-06-11 01:26:59.995479
# Unit test for function env_fallback
def test_env_fallback():
    print(env_fallback('ABC'))
    print(env_fallback('ABC', 'ABC'))
    print(env_fallback('ABC', 'def'))


# Generated at 2022-06-11 01:27:44.683871
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        foo=dict(type='bool', fallback=(env_fallback, 'FOO')),
        baz=dict(type='list', fallback=(env_fallback, 'BAZ', ',')),
        bar=dict(type='str', fallback=(env_fallback, 'BAR')),
    )

    parameters = dict()

    no_log_values = set_fallbacks(argument_spec, parameters)

    assert parameters['foo'] == 'yes'
    assert parameters['baz'] == ['one', 'two']
    assert parameters['bar'] == 'something'

    os.environ['FOO'] = ''
    os.environ['BAR'] = ''
    no_log_values = set_fallbacks(argument_spec, parameters)

    assert parameters['foo'] == ''

# Generated at 2022-06-11 01:27:55.173026
# Unit test for function set_fallbacks
def test_set_fallbacks():
    """Validate functionality of set_fallbacks."""
    params = {'one': '', 'two': '', 'three': '', 'four': '', 'five': '', 'six': '', 'seven': '', 'eight': '', 'nine': '', 'ten': ''}

# Generated at 2022-06-11 01:28:07.302174
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # environment variable based fallback
    os.environ['ANSIBLE_TEST_ENV_VALUE'] = 'my_env_value'

# Generated at 2022-06-11 01:28:11.941457
# Unit test for function sanitize_keys
def test_sanitize_keys():
  from inspect import getfullargspec
  args = {
    'obj': 'obj',
    'no_log_strings': 'no_log_strings',
    'ignore_keys': 'ignore_keys',
  }
  for item in args.items():
    assert getfullargspec(sanitize_keys).args[0] == item[0]


# Generated at 2022-06-11 01:28:22.614043
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ONE'] = 'one'
    assert env_fallback('ANSIBLE_TEST_ONE') == 'one'
    assert env_fallback('ANSIBLE_TEST_TWO') == ''
    assert env_fallback('ANSIBLE_TEST_TWO', 'ANSIBLE_TEST_ONE') == 'one'
    assert env_fallback('ANSIBLE_TEST_TWO', None) == ''
    assert env_fallback('ANSIBLE_TEST_TWO', 'ANSIBLE_TEST_THREE') == ''

# Generated at 2022-06-11 01:28:33.154150
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Test with empty spec
    assert set_fallbacks({}, {}) == set()
    # Test with fallback function
    assert set_fallbacks({'a':{'fallback': (env_fallback, 'TEST')}}, {}) == set()
    os.environ['TEST'] = 'foo'
    assert set_fallbacks({'a':{'fallback': (env_fallback, 'TEST')}}, {}) == {'foo'}
    del os.environ['TEST']
    # Test with no_log fallback
    assert set_fallbacks({'a':{'fallback': (env_fallback, 'TEST'), 'no_log': True}}, {}) == set()
    os.environ['TEST'] = 'foo'

# Generated at 2022-06-11 01:28:44.468931
# Unit test for function env_fallback
def test_env_fallback():
    """Unit test for ``env_fallback``."""

    # Reset environment variables
    try:
        del os.environ['FOO']
        del os.environ['BAR']
        del os.environ['FOOBAR']
    except KeyError:
        pass

    try:
        env_fallback('FOO', 'BAR')
        assert_equal(None, 'env_fallback should have thrown exception')
    except AnsibleFallbackNotFound:
        pass

    os.environ['FOO'] = 'FOO_VALUE'
    assert_equal(env_fallback('FOO', 'BAR'), 'FOO_VALUE')

    os.environ['BAR'] = 'BAR_VALUE'
    assert_equal(env_fallback('BAR', 'FOO'), 'BAR_VALUE')

   

# Generated at 2022-06-11 01:28:54.875418
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'a': {'type': 'str', 'fallback': (env_fallback, 'my_env_var')},
        'b': {'type': 'str', 'fallback': (env_fallback, 'my_env_var2')},
        'c': {'type': 'str', 'fallback': (lambda: 'hello', 'world')},
        'd': {'type': 'str', 'fallback': (lambda: 'hello', {'key': 'world'})},
    }

    parameters = {
        'a': 'a',
        'b': 'b'
    }

    no_log_values = set_fallbacks(argument_spec, parameters)

    assert parameters['a'] == 'a'
    assert parameters['b'] == 'b'
    assert parameters['c']

# Generated at 2022-06-11 01:29:02.163002
# Unit test for function env_fallback
def test_env_fallback():
    test_env = dict(TEST_ENV='TEST', TEST_ENV_NUM='1')
    with patch.dict(os.environ, test_env):
        assert env_fallback('TEST_ENV') == 'TEST'
        assert env_fallback('TEST_ENV_NUM') == '1'
        assert env_fallback('TEST_ENV_NOT_SET') == ''
        assert env_fallback('TEST_ENV_NOT_SET', 'TEST_ENV_NUM') == '1'
        assert env_fallback('TEST_ENV_NOT_SET', 'TEST_ENV') == 'TEST'



# Generated at 2022-06-11 01:29:08.016791
# Unit test for function set_fallbacks