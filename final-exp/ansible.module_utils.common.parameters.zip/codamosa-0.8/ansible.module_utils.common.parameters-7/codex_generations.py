

# Generated at 2022-06-11 01:19:49.613504
# Unit test for function set_fallbacks
def test_set_fallbacks():
    """Unit test for module.set_fallbacks"""
    # Setup
    argument_spec = dict(
        test=dict(
            fallback=(env_fallback, ['TEST_ENV'])
        )
    )
    parameters = dict()
    os.environ['TEST_ENV'] = "FOUND"

    # Execute
    no_log_values = set_fallbacks(argument_spec, parameters)
    # Verify
    assert parameters.get('test') == 'FOUND'
    assert no_log_values == {'FOUND'}



# Generated at 2022-06-11 01:19:59.512899
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert set(set_fallbacks(argument_spec, {})) == set()
    assert set(set_fallbacks(argument_spec, {'name': 'test'})) == set()

    # Test fallback for 'state'
    assert set(set_fallbacks(argument_spec, {'name': 'test'})) == set()
    assert set(set_fallbacks(argument_spec, {'name': 'test', 'state': 'present'})) == set()
    assert set(set_fallbacks(argument_spec, {'name': 'test', 'state': 'absent'})) == set()

    # Test fallback for 'no_log'
    assert set(set_fallbacks(argument_spec, {'name': 'test', 'password': 'pass'})) == set()

    # Test fallback for 'env'

# Generated at 2022-06-11 01:20:10.126794
# Unit test for function set_fallbacks
def test_set_fallbacks():
    """Unit test for function set_fallbacks."""

    # TEST 1: Test function set_fallbacks with env_fallback
    # Set env variable for testing
    os.environ['ANSIBLE_NET_USERNAME'] = 'user'
    os.environ['ANSIBLE_NET_PASSWORD'] = 'pass'

    # Set argument spec

# Generated at 2022-06-11 01:20:14.934014
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_MAGIC'] = 'FAKE_MAGIC'
    assert env_fallback('ANSIBLE_MAGIC') == 'FAKE_MAGIC'

    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('ANSIBLE_LIES')



# Generated at 2022-06-11 01:20:20.658296
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'test_param': {
            'type': 'str',
            'fallback': (env_fallback, ['TEST_PARAM'])
        }
    }
    os.environ['TEST_PARAM'] = 'test'
    parameters = {}
    set_fallbacks(argument_spec, parameters)
    assert parameters.get('test_param') == 'test'



# Generated at 2022-06-11 01:20:25.059117
# Unit test for function remove_values
def test_remove_values():
    value={"key2":"value2", "key1":"value1"}
    no_log_strings=['value1']
    assert remove_values(value, no_log_strings) == {"key2":"value2", "key1":"VALUE_HIDDEN"}



# Generated at 2022-06-11 01:20:37.343894
# Unit test for function set_fallbacks
def test_set_fallbacks():
    import uuid
    parameters = {}
    # test dict fallback
    argument_spec = dict(
        foo=dict(type='int', fallback=(dict, dict(a=1, b=2)), default=42),
        bar=dict(type='str', fallback=(dict, dict(a=1, b=2)), default=uuid.uuid4().hex),
    )
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['foo'] == 42
    assert isinstance(parameters['bar'], str)
    assert parameters['bar']
    assert not no_log_values
    # test dict fallback does not overwrite value in parameters
    parameters['bar'] = 'test_bar'
    parameters['foo'] = 'test_foo'
    no_log_values = set_fallbacks

# Generated at 2022-06-11 01:20:46.864384
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # setup test
    argument_spec = dict(
        one=dict(type='str', fallback=(env_fallback, ('ONE',))),
        two=dict(type='int', fallback=(env_fallback, ('TWO',))),
        three=dict(type='bool', fallback=(env_fallback, ('THREE',))),
    )

    parameters = dict(
        one=None,
        two=None,
        three=None,
    )

    expected_parameters = dict(
        one="env_variable",
        two=42,
        three=False,
    )

    expected_no_log_values = set(expected_parameters.values())

    # execute test
    os.environ['ONE'] = "env_variable"
    os.environ['TWO'] = "42"


# Generated at 2022-06-11 01:20:55.745099
# Unit test for function set_fallbacks
def test_set_fallbacks():
    spec = dict(a=dict(fallback=(env_fallback, 'FOO'), type='str'))
    parameters = {}
    os.environ['FOO'] = 'bar'
    no_log_values = set_fallbacks(spec, parameters)
    assert parameters == dict(a='bar')
    assert no_log_values == set()

    parameters = {}
    del os.environ['FOO']
    no_log_values = set_fallbacks(spec, parameters)
    assert parameters == dict()
    assert no_log_values == set()

    parameters = {'a': 'initial'}
    del os.environ['FOO']
    no_log_values = set_fallbacks(spec, parameters)
    assert parameters == dict(a='initial')
    assert no_log_values == set()

   

# Generated at 2022-06-11 01:21:06.958758
# Unit test for function set_fallbacks
def test_set_fallbacks():
    fallback_test_parameters = {
        'a': '123',
        'b': '456'
    }
    fallback_test_argument_spec = {
        'a': {'type': 'str', 'fallback': (env_fallback, [])},
        'b': {'type': 'str', 'fallback': (env_fallback, [])},
        'c': {'type': 'str', 'fallback': (env_fallback, [])}
    }
    no_log_values = set_fallbacks(fallback_test_argument_spec, fallback_test_parameters)
    if not no_log_values:
        assert fallback_test_parameters.get('c') is None
    else:
        assert fallback_test_parameters.get('c') == os.en

# Generated at 2022-06-11 01:21:31.270757
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert not set_fallbacks({'foo': {'type': 'str'}}, {})
    assert set_fallbacks({'foo': {'type': 'str', 'fallback': (env_fallback, 'FOO')}}, {}) == {'bar'}
    assert set_fallbacks({'foo': {'type': 'str', 'fallback': (env_fallback, 'NO_SUCH_ENV')}}, {}) == set()



# Generated at 2022-06-11 01:21:41.136212
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # default value
    argument_spec = dict(
        foo=dict(type='str', default='xyzzy')
    )
    parameters = dict()
    no_log_values = set_fallbacks(argument_spec, parameters)
    if parameters['foo'] != 'xyzzy':
        raise AssertionError()
    if no_log_values:
        raise AssertionError()

    # fallback from environment variable
    argument_spec = dict(
        foo=dict(type='str', fallback=(env_fallback, 'FOO'))
    )
    parameters = dict()
    os.environ['FOO'] = 'xyzzy'
    no_log_values = set_fallbacks(argument_spec, parameters)
    if parameters['foo'] != 'xyzzy':
        raise AssertionError()

# Generated at 2022-06-11 01:21:51.139845
# Unit test for function set_fallbacks
def test_set_fallbacks():
    parameter = {}
    argument_spec = {'name': {'fallback': ('env_fallback', 'name', 'NAME')}}
    no_log_values = set_fallbacks(argument_spec, parameter)
    assert parameter['name'] == 'env_fallback_value'
    assert no_log_values == {'env_fallback_value'}

    argument_spec = {'name': {'fallback': ('env_fallback', 'name', 'NAME'), 'required': True}}
    with pytest.raises(AnsibleFailJSonException):
        set_fallbacks(argument_spec, parameter)

    argument_spec = {'name': {'fallback': ('env_fallback', 'name', 'NAME'), 'required': True}}

# Generated at 2022-06-11 01:22:00.363372
# Unit test for function env_fallback
def test_env_fallback():
    """
    Test environment variable fallback.
    """
    env_vars = {'ANSIBLE_FOO': 'ANSIBLE_FOO',
                'ANSIBLE_BAR': 'ANSIBLE_BAR'}
    for var in env_vars:
        os.environ[var] = env_vars[var]

    assert env_fallback('ANSIBLE_FOO', 'ANSIBLE_BAR', 'ANSIBLE_BAZ') == env_vars['ANSIBLE_FOO']
    assert env_fallback('ANSIBLE_BAR', 'ANSIBLE_BAZ') == env_vars['ANSIBLE_BAR']

    # Test exception
    os.environ['ANSIBLE_FOO'] = env_vars['ANSIBLE_FOO']
    os.environ['ANSIBLE_BAR'] = env_v

# Generated at 2022-06-11 01:22:11.873474
# Unit test for function set_fallbacks
def test_set_fallbacks():
    fallback_spec = {
        'param1': {
            'required': True,
        },
        'param2': {
            'required': False,
            'fallback': (fallback1, 'arg1', 'arg2'),
        },
        'param3': {
            'required': False,
            'fallback': (fallback1, 'arg1', 'arg2', {'kwarg1': 'kwarg_value'}),
        },
        'param4': {
            'required': False,
            'fallback': (fallback1, {'kwarg1': 'kwarg_value'}),
        },
    }

    params = {}

    no_log_values = set_fallbacks(fallback_spec, params)
    assert len(no_log_values) == 0

    # Test no args

# Generated at 2022-06-11 01:22:21.717429
# Unit test for function set_fallbacks
def test_set_fallbacks():
    """Ensure argument_spec fallback is correctly applied to parameters"""

# Generated at 2022-06-11 01:22:31.866931
# Unit test for function set_fallbacks
def test_set_fallbacks():
    parameter_spec = dict(
        param=dict(required=True, fallback=(env_fallback, "ANSIBLE_PARAM")),
        bool_param=dict(type='bool', fallback=(env_fallback, "ANSIBLE_BOOL_PARAM")),
        dict_param=dict(type='dict', fallback=(dict, {"ANSIBLE_DICT_PARAM": "ANSIBLE_VALUE"})),
        private_param=dict(type='str', no_log=True, fallback=(env_fallback, "ANSIBLE_PRIVATE_PARAM")),
    )
    os.environ['ANSIBLE_PARAM'] = "Env Value"
    os.environ['ANSIBLE_BOOL_PARAM'] = "True"

# Generated at 2022-06-11 01:22:42.917807
# Unit test for function set_fallbacks
def test_set_fallbacks():
    fallback_spec = {
        'fallback_test1': {'fallback': ('env_fallback', ('FALLBACK_TEST1',))},
        'fallback_test2': {'fallback': ('env_fallback', ('FALLBACK_TEST2',))},
        'fallback_test3': {'fallback': ('env_fallback', ('FALLBACK_TEST3',))},
        'fallback_test4': {'fallback': ('env_fallback', ({'fallback2': 'FALLBACK_TEST4'},))},
        'fallback_test5': {'fallback': ({'fallback3': 'FALLBACK_TEST5'},)},
    }
    test_parameters = {}

# Generated at 2022-06-11 01:22:51.920256
# Unit test for function sanitize_keys
def test_sanitize_keys():
    no_log_values = set()
    no_log_values.add('password1')
    no_log_values.add('password2')

    ignore_keys=set()
    ignore_keys.add('_ansible_ignore_errors')

    data = dict(
            MY_KEY='value',
            _ansiblesomething='not value',
            nested_dict=dict(
                    MY_KEY='value'
            ),
            nested_list=dict(
                    MY_KEY='value',
                    other_key='other_value'
            )
    )

    # Test that nested lists and dictionaries are sanitized

# Generated at 2022-06-11 01:23:02.863916
# Unit test for function set_fallbacks
def test_set_fallbacks():
    spec = dict(
        env_var=dict(fallback=(env_fallback, 'TEST_ENV_VAR')),
        env_var_with_defaults=dict(fallback=(env_fallback, 'TEST_ENV_VAR2', 'default_value')),
        env_var_with_kwargs=dict(fallback=(env_fallback, {'default': 'default_value2'}))
    )
    parameters = {}
    no_log_values = set_fallbacks(spec, parameters)
    assert len(no_log_values) == 1
    assert no_log_values == {'ThatIsNotLogged'}

# Generated at 2022-06-11 01:23:23.476985
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['test_env_fallback'] = 'Value'
    result = env_fallback('test_env_fallback')
    assert result == 'Value'



# Generated at 2022-06-11 01:23:28.315405
# Unit test for function sanitize_keys
def test_sanitize_keys():
    test_dict={'str':'str','str_sanitize':'str_sanitize%%','str_sanitize_hidden':'str_sanitize%%','str_not_sanitize':'str_not_sanitize'}
    result_dict={'str':'str','str_sanitize':'[VALUE SANITIZED]','str_sanitize_hidden':'[VALUE SANITIZED]','str_not_sanitize':'str_not_sanitize'}
    assert (sanitize_keys(test_dict,no_log_strings=['sanitize']))==result_dict


# Generated at 2022-06-11 01:23:34.448457
# Unit test for function remove_values
def test_remove_values():
    assert remove_values('password', ['password']) == 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'
    assert remove_values('mypassword', ['password']) == 'mypassword'
    assert remove_values('mypass', ['password']) == 'mypass'
    assert remove_values('mypass', ['secret']) == 'mypass'
    assert remove_values('mypass', ['pass', 'secret']) == 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'
    assert remove_values('mypass', [b'pass', b'secret']) == 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'
    assert remove_values(1234, [1234]) == 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'
    assert remove_values

# Generated at 2022-06-11 01:23:34.996601
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert True

# Generated at 2022-06-11 01:23:45.691215
# Unit test for function set_fallbacks

# Generated at 2022-06-11 01:23:55.278358
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'fallback_value'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'fallback_value'
    del os.environ['ANSIBLE_TEST_ENV_FALLBACK']
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'fallback_value'
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('NOT_FOUND')
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback()



# Generated at 2022-06-11 01:23:59.237761
# Unit test for function set_fallbacks
def test_set_fallbacks():
    spec = dict(a=dict(), b=dict(), c=dict(fallback=env_fallback))
    params = dict(c=None)
    result = set_fallbacks(spec, params)
    assert result == set()
    params = dict()
    result = set_fallbacks(spec, params)
    assert result == set(os.environ.get(spec['c']['fallback'][1]))
    params = dict(c=None)
    result = set_fallbacks(spec, params)
    assert result == set()



# Generated at 2022-06-11 01:24:04.526945
# Unit test for function set_fallbacks
def test_set_fallbacks():
    spec = {'one': dict(type='str', fallback=(env_fallback, 'ONE')),
            'two': dict(type='str', fallback=(env_fallback, 'TWO', 'three')),
            'four': dict(type='str', fallback=(env_fallback, dict(key='FOUR')))}
    params = dict(one='A', two='B', four='D')
    no_log_values = set_fallbacks(spec, params)
    assert params == dict(one='A', two='B', four='D')
    os.environ['ONE'] = 'X'
    os.environ['TWO'] = 'Y'

    with pytest.raises(AnsibleFallbackNotFound):
        os.environ['THREE'] = None
        no_log_values = set

# Generated at 2022-06-11 01:24:07.265079
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback("foo") == os.environ["foo"]
    try:
        env_fallback("bar")
        assert False
    except AnsibleFallbackNotFound:
        pass
    try:
        env_fallback()
        assert False
    except TypeError:
        pass


# Generated at 2022-06-11 01:24:18.143522
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(test=dict(fallback=(env_fallback, 'TEST_VAR')))
    parameters = dict()
    no_log_values = set()
    # Backwards compatibility for plugin writers
    set_fallbacks(argument_spec, parameters)
    assert 'test' in parameters
    assert parameters['test'] == os.environ.get('TEST_VAR')

    no_log_values.update(set_fallbacks(argument_spec, parameters))
    assert 'test' in parameters
    assert parameters['test'] == os.environ.get('TEST_VAR')
    assert no_log_values == set()

    argument_spec = dict(test=dict(fallback=(env_fallback, 'TEST_VAR'), no_log=True))
    parameters = dict()
    no_log

# Generated at 2022-06-11 01:24:54.263565
# Unit test for function env_fallback
def test_env_fallback():
    for value in [True, False]:
        os.environ['ANSIBLE_FOO_BAR'] = '1'
        assert env_fallback('foo_bar') == '1'
        del os.environ['ANSIBLE_FOO_BAR']
        assert env_fallback('foo_bar') == value
    assert env_fallback('foo', 'bar') == 'bar'
    os.environ['ANSIBLE_FOO'] = '1'
    assert env_fallback('foo', 'bar') == '1'
    os.environ['ANSIBLE_BAR'] = '1'
    assert env_fallback('foo', 'bar') == '1'



# Generated at 2022-06-11 01:25:01.675174
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'a':{'type':'str','fallback':(env_fallback,'a_name')}}
    os.environ['a_name'] = 'env_value'
    parameters = {'b':'b'}
    no_log_values = set_fallbacks(argument_spec,parameters)
    parameters['a'] = 'a'
    no_log_values = set_fallbacks(argument_spec,parameters)
    del os.environ['a_name']



# Generated at 2022-06-11 01:25:11.798709
# Unit test for function sanitize_keys
def test_sanitize_keys():
    '''Test the sanitize_keys function'''
    no_log_strings = [to_native("vault"), to_native("password")]
    ignore_keys = set()
    nested_dict_to_sanitize = {u'vault_password_files': [u'vault_password_file'],
                               u'vault_password': u'vault_password',
                               u'vault_password_file': u'password',
                               'password': u'password'}
    sanitized_nested_dict = {u'vault_password_files': [u'?????????_file'],
                             u'vault_password': u'?????????',
                             u'vault_password_file': u'password',
                             'password': u'password'}
    sanitized_nested

# Generated at 2022-06-11 01:25:23.176537
# Unit test for function env_fallback
def test_env_fallback():
    os_environ_backup = os.environ.copy()

# Generated at 2022-06-11 01:25:32.416372
# Unit test for function sanitize_keys
def test_sanitize_keys():
    class sanitize_keys:
        def __init__(self, value):
            self.value = value
    keys = ['key', 'password', 'access_key', 'secret']
    value1 = {'a': 'valid', 'b': 'secret', 'c': {'d': 'no_log'}}
    value2 = {'any': ['key', 'secret']}
    value3 = {'all_valid': 'any'}
    value4 = {'a': {'key': 'no_log'}}
    value5 = {'any': 'secret key'}
    value6 = {'all_valid': 'any'}
    value7 = {'all_valid': 'any'}
    value8 = {'any': {'secret_key': 'no_log'}}

# Generated at 2022-06-11 01:25:38.555821
# Unit test for function set_fallbacks
def test_set_fallbacks():
    params = dict()
    args = "foo=bar"
    argument_spec = dict(
        foo=dict(fallback=(env_fallback, 'FOO')),
        bar=dict(required=True, type='str'),
    )

    set_fallbacks(argument_spec, params)
    assert params.get('foo') is None
    assert params.get('bar') is None
    params['bar'] = args



# Generated at 2022-06-11 01:25:44.157892
# Unit test for function env_fallback
def test_env_fallback():
    tmp_env = os.environ.copy()
    os.environ.update({'BAR': 'BAR_VAL', 'FOO': 'FOO_VAL', 'ZOO': 'ZOO_VAL'})
    assert env_fallback('BAR', 'FOO') == 'BAR_VAL'
    assert env_fallback('ZOO') == 'ZOO_VAL'
    assert env_fallback('MISS') == 'MISS'
    os.environ = tmp_env



# Generated at 2022-06-11 01:25:54.293258
# Unit test for function set_fallbacks
def test_set_fallbacks():
    spec = dict(
        param1=dict(type='str', fallback=(env_fallback, 'ANSIBLE_PARAM1', 'ANSIBLE_PARAM2')),
        param2=dict(type='str'),
    )
    parameters = dict(param2='foo')
    result = dict(param1='baz', param2='foo')

    # Test fallback value is set
    os.environ['ANSIBLE_PARAM1'] = 'baz'
    assert set_fallbacks(spec, parameters) != no_log_values
    assert parameters == result

    # Test fallback value is not set
    os.environ['ANSIBLE_PARAM1'] = 'bar'
    assert set_fallbacks(spec, parameters) != no_log_values
    assert parameters == result

    # Test no_log
    os.en

# Generated at 2022-06-11 01:26:01.326017
# Unit test for function env_fallback
def test_env_fallback():
    os.environ["TEST_FOO"] = "foo"
    os.environ["TEST_BAR"] = "bar"
    test_string = "foo"
    assert env_fallback("TEST_FOO", "TEST_BAR") == test_string
    test_string = "bar"
    assert env_fallback("TEST_BAR", "TEST_FOO") == test_string
    assert env_fallback("TEST_BAZ") == False


# Generated at 2022-06-11 01:26:05.895523
# Unit test for function sanitize_keys
def test_sanitize_keys():
    no_log_strings = [u'FOO', u'BAR']
    ignore_keys = set([u'KEY1', u'KEY2'])


# Generated at 2022-06-11 01:27:19.551258
# Unit test for function set_fallbacks
def test_set_fallbacks():
    """Unit test for function set_fallbacks"""

    argument_spec = {
        'foo': {'type': 'str', 'fallback': (env_fallback, 'FOO')},
        'boo': {'type': 'str', 'fallback': (env_fallback, 'BOO')},
        'goo': {'type': 'str', 'fallback': (env_fallback, 'GOO')},
    }
    parameters = {}

    expected_no_log_values = set()
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert no_log_values == expected_no_log_values

    parameters = {'boo': 'bar'}
    expected_no_log_values = set()
    no_log_values = set_fallbacks(argument_spec, parameters)

# Generated at 2022-06-11 01:27:20.821289
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('foo', 'bar') == 'bar'



# Generated at 2022-06-11 01:27:27.543346
# Unit test for function set_fallbacks
def test_set_fallbacks():
    spec = {
        'foo': {'type': 'str', 'fallback': (env_fallback,)},
        'bar': {'type': 'str', 'fallback': (env_fallback, 'BAR')},
        'baz': {'type': 'str', 'fallback': (env_fallback, 'BAB', 'BAZ')},
        'qux': {'type': 'int', 'fallback': (env_fallback, 'QUX', 'CUX', 5)},
        'qux_no_log': {'type': 'int', 'fallback': (env_fallback, 'QUX', 'CUX', 5), 'no_log': True},
    }

    os.environ['BAZ'] = 'baz'
    os.environ['CUX'] = '24'

    #

# Generated at 2022-06-11 01:27:35.631115
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Test default fallback
    arguments = {
        'a': {
            'type': 'str',
            'default': 'A',
            'fallback': (env_fallback, ['b', 'c'])},
        'b': {'type': 'str', 'default': 'B'},
        'c': {'type': 'str', 'default': 'C'}}
    params = {}

    expected_result = {}
    expected_no_log_values = set()

    result, no_log_values = set_fallbacks(arguments, params)
    assert result == expected_result
    assert no_log_values == expected_no_log_values

    params = {'a': 'A'}
    expected_result = {'a': 'A'}

    result, no_log_values = set_fallbacks

# Generated at 2022-06-11 01:27:43.869328
# Unit test for function set_fallbacks

# Generated at 2022-06-11 01:27:52.061057
# Unit test for function set_fallbacks
def test_set_fallbacks():
    """Set some fallbacks and assert that they are correctly loaded."""
    assert set_fallbacks({'my_param': {'type': 'str', 'fallback': ('env_fallback', 'MY_PARAM_ENV_VAR')}}, {}) == set()

    os.environ['MY_PARAM_ENV_VAR'] = 'my_value'
    assert set_fallbacks({'my_param': {'type': 'str', 'fallback': ('env_fallback', 'MY_PARAM_ENV_VAR')}}, {}) == {'my_value'}
    del os.environ['MY_PARAM_ENV_VAR']



# Generated at 2022-06-11 01:27:56.608713
# Unit test for function env_fallback
def test_env_fallback():
    result = env_fallback('ANSIBLE_TEST_VAR', 'ANSIBLE_TEST_VAR2')
    assert result == 'test_value'

test_value = 'test_value'
os.environ['ANSIBLE_TEST_VAR'] = test_value


# Generated at 2022-06-11 01:28:08.522598
# Unit test for function set_fallbacks

# Generated at 2022-06-11 01:28:15.891578
# Unit test for function set_fallbacks
def test_set_fallbacks():
    fake_connection_user_args = dict(
        ansible_ssh_private_key_file=dict(type='str', fallback=(env_fallback, ['ANSIBLE_SSH_PRIVATE_KEY_FILE'])),
        ansible_ssh_private_key_file2=dict(type='str', fallback=(env_fallback, ['ANSIBLE_SSH_PRIVATE_KEY_FILE2']))
    )
    fake_connection_user_params = dict()
    no_log_values = set_fallbacks(fake_connection_user_args, fake_connection_user_params)

    assert len(fake_connection_user_params) == 2

# Generated at 2022-06-11 01:28:27.326237
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('a') == os.environ.get('a')
    assert env_fallback('a', 'b') == os.environ.get('a')
    assert env_fallback('c', 'd') == os.environ.get('c')
    assert env_fallback('c', 'd', 'e') == os.environ.get('c')
    assert env_fallback('f', 'g', 'h', 'i') == os.environ.get('f')
    assert env_fallback('j', 'k', 'l', 'm', 'n') == os.environ.get('j')
    assert env_fallback('o', 'p', 'q', 'r', 's', 't') == os.environ.get('o')