

# Generated at 2022-06-11 01:20:22.411035
# Unit test for function set_fallbacks
def test_set_fallbacks():
    '''
    Test whether fallback are being set correctly
    '''

    # Test set_fallbacks without fallback
    argument_spec = {
        'a': {'type': 'str', 'default': 'a_x'},
        'b': {'type': 'str', 'default': 'b_x'},
    }
    parameters = {}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert no_log_values == set(), "No values should not be set"
    assert parameters == {'a': 'a_x', 'b': 'b_x'}, 'Parameters should be set'

    # Test set_fallbacks with fallback

# Generated at 2022-06-11 01:20:25.246905
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['TEST_ENV_VAR'] = 'test_value'
    assert env_fallback('TEST_ENV_VAR') == 'test_value'



# Generated at 2022-06-11 01:20:36.698666
# Unit test for function env_fallback
def test_env_fallback():
    os.environ["ANSIBLE_FOO"] = "bar"
    fb = env_fallback("ANSIBLE_FOO", "ANSIBLE_BAR")
    assert fb == "bar"
    fb = env_fallback("ANSIBLE_BAR")
    assert fb == "baz"
    assert os.environ.get("ANSIBLE_BAR") is None
    os.environ["ANSIBLE_BAR"] = "baz"
    os.environ.pop("ANSIBLE_FOO")
    fb = env_fallback("ANSIBLE_FOO", "ANSIBLE_BAR")
    assert fb == "baz"
    assert os.environ.get("ANSIBLE_FOO") is None



# Generated at 2022-06-11 01:20:46.483535
# Unit test for function set_fallbacks
def test_set_fallbacks():
    """Test that set_fallbacks works correctly"""

# Generated at 2022-06-11 01:20:55.489876
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert set_fallbacks({'foo': {'fallback': (env_fallback, 'FOO_ENV_VAR')}}, {}) == set()
    assert set_fallbacks({'foo': {'fallback': (env_fallback, 'FOO_ENV_VAR')}}, {'foo': 'foo'}) == set()
    os.environ['FOO_ENV_VAR'] = 'foobar'

    assert set_fallbacks({'foo': {'fallback': (env_fallback, 'FOO_ENV_VAR')}}, {}) == {'foobar'}
    assert set_fallbacks({'foo': {'fallback': (env_fallback, 'FOO_ENV_VAR'), 'type': 'str'}}, {}) == {'foobar'}

# Generated at 2022-06-11 01:21:06.875975
# Unit test for function set_fallbacks

# Generated at 2022-06-11 01:21:17.185230
# Unit test for function set_fallbacks

# Generated at 2022-06-11 01:21:26.565850
# Unit test for function set_fallbacks

# Generated at 2022-06-11 01:21:36.269003
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        test_fallback=dict(
            type='str',
            fallback=(env_fallback, ['ANSIBLE_TEST'])
        ),
        test_fallback_args=dict(
            type='str',
            fallback=(env_fallback, ['ANSIBLE_TEST_ARGS'], {'key': 'value'})
        ),
        test_fallback_kwargs=dict(
            type='str',
            fallback=(env_fallback, {'key': 'value'})
        ),
    )
    parameters = dict()

    no_log_values = set_fallbacks(argument_spec, parameters)

    assert len(no_log_values) == 0
    assert 'ANSIBLE_TEST' not in os.environ

# Generated at 2022-06-11 01:21:47.148685
# Unit test for function set_fallbacks
def test_set_fallbacks():
    def fallback_call():
        """Returns a list"""
        return [1, 2, 3]
    argument_spec = {
        'test_param': {'type': 'list', 'fallback': [fallback_call]}
    }
    parameters = {}
    set_fallbacks(argument_spec, parameters)
    assert parameters['test_param'] == [1, 2, 3]
    parameters = {'test_param': 'test'}
    set_fallbacks(argument_spec, parameters)
    assert parameters['test_param'] == 'test'
    fallback_spec = {
        'test_param_2': {'type': 'str', 'fallback': [env_fallback, 'ANSIBLE_TEST_ENV_VAR']}
    }
    parameters = {}

# Generated at 2022-06-11 01:22:26.499036
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('PATH') == os.environ['PATH']
    assert env_fallback('HOME') == os.environ['HOME']
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('not_exist')



# Generated at 2022-06-11 01:22:34.941281
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'arg': {'required': True,
                             'fallback': ('env_fallback', ('ARG',))}}
    parameters = {}
    assert set_fallbacks(argument_spec, parameters) == set()
    assert parameters == {}

    # Test fallback with no args
    argument_spec = {'arg': {'required': True,
                             'fallback': (env_fallback,)}}
    parameters = {}
    assert set_fallbacks(argument_spec, parameters) == set()
    assert parameters == {}

    # Test fallback with args
    os.environ['ARG'] = '1000'
    argument_spec = {'arg': {'required': True,
                             'fallback': (env_fallback, ('ARG',))}}
    parameters = {}

# Generated at 2022-06-11 01:22:46.578235
# Unit test for function set_fallbacks
def test_set_fallbacks():
    '''
    Test cases for function set_fallbacks
    '''

    class TestModule(object):
        def __init__(self, params):
            self.params = params

        def __getitem__(self, item):
            return self.params[item]

        def __contains__(self, item):
            return item in self.params

    argument_spec = dict(
        test1=dict(type='str', fallback=(env_fallback, 'TEST_ENV')),
    )
    parameters = dict(test1='test_param')
    parameters_nested = dict(test1='test_param', nested_test=dict(test1='test_param'))
    bad_test_module = TestModule(parameters)
    test_module = TestModule(parameters_nested)


# Generated at 2022-06-11 01:22:56.991077
# Unit test for function set_fallbacks
def test_set_fallbacks():
    """Test functionality of set_fallbacks function."""

    argument_spec = {'foo': {'type': 'str'}}
    parameters = {}
    fallback_val = 'bar'
    original_fallback = Base._fallback_strategy_functions['env_fallback']
    Base._fallback_strategy_functions['env_fallback'] = env_fallback
    environ_val = "bar"

    # Test with no fallback
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert no_log_values == set(), "no_log values were not empty"
    assert parameters == {}

    # Test with fallback
    argument_spec['foo']['fallback'] = ('env_fallback', 'foo')

# Generated at 2022-06-11 01:23:05.807946
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'param': {
            'type': 'str',
            'required': False,
            'fallback': (env_fallback, 'FOO'),
            'default': 'bar'
        }
    }
    parameters = {}
    os.environ['FOO'] = 'baz'

    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['param'] == 'baz'
    assert len(no_log_values) == 0

    parameters = {'param': 'baz'}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['param'] == 'baz'
    assert len(no_log_values) == 0


# Generated at 2022-06-11 01:23:14.886230
# Unit test for function set_fallbacks

# Generated at 2022-06-11 01:23:20.693236
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'ansible_ssh_port': {'type': 'int', 'default': 22, 'fallback': (env_fallback, ['ANSIBLE_SSH_PORT'])}}
    parameters = {'ansible_ssh_port': 22}
    result = set_fallbacks(argument_spec, parameters)
    assert parameters['ansible_ssh_port'] == 22
    parameters = {}
    result = set_fallbacks(argument_spec, parameters)
    assert parameters['ansible_ssh_port'] == '22'
    assert result == set(['22'])



# Generated at 2022-06-11 01:23:26.700654
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(foo=dict(fallback=(env_fallback, 'BAR')),
                         bar=dict(fallback=(env_fallback, 'BAZ')),
                         baz=dict(fallback=(env_fallback, 'FOOBAR')))
    parameters = {}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert len(no_log_values) == 0
    assert dict(parameters) == dict()
    os.environ['BAR'] = 'bar'
    os.environ['BAZ'] = 'baz'
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert len(no_log_values) == 2
    assert dict(parameters) == dict(foo='bar', bar='baz')
    os.environ

# Generated at 2022-06-11 01:23:32.889205
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Ensure we can load dict fallback
    args = dict(
        host=dict(
            type='str',
            fallback=(dict, [dict(key='ansible_host'), 'localhost'])
        )
    )
    parameters = {}
    expected = {'host': 'localhost'}
    no_log_values = set_fallbacks(args, parameters)
    assert not no_log_values
    assert parameters == expected
    # Ensure we can load function fallback
    args = dict(
        host=dict(
            type='str',
            fallback=(env_fallback, 'ANSIBLE_REMOTE_TMP')
        )
    )
    parameters = {}
    expected = {'host': os.environ['ANSIBLE_REMOTE_TMP']}

# Generated at 2022-06-11 01:23:42.543744
# Unit test for function set_fallbacks
def test_set_fallbacks():

    argument_spec = dict(
        cmd_timeout=dict(type='int', fallback=(env_fallback, ['ANSIBLE_NET_SSH_TIMEOUT'])),
        provider=dict(type='dict', fallback=(env_fallback, ['ANSIBLE_NET_USERNAME', 'ANSIBLE_NET_PASSWORD', 'ANSIBLE_NET_AUTHORIZE', 'ANSIBLE_NET_AUTH_PASS'])),
        nxos_use_ssl=dict(type='bool', fallback=(env_fallback, ['ANSIBLE_NET_USE_SSL'])),
    )

    parameters = { }


# Generated at 2022-06-11 01:24:15.303373
# Unit test for function remove_values
def test_remove_values():
    from ansible.module_utils import basic
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_TRUE, BOOLEANS_FALSE
    result = remove_values({'k1': 'v1', 'k2': 'v2', 'k3': 'v3'}, ['v3'])
    result2 = remove_values({'k1': 'v1', 'k2': 'v2', 'k3': 'v3'}, ['v3'])
    assert result == result2
    assert result == {'k1': 'v1', 'k2': 'v2'}
    result = remove_values({'k1': 'v1', 'k2': 'v2', 'k3': 'v3'}, ['v3', 'v2'])
    result2 = remove

# Generated at 2022-06-11 01:24:24.479572
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['TEST_KEY'] = 'TEST_VALUE'
    assert env_fallback('TEST_KEY', 'TEST_KEY_DOES_NOT_EXIST') == 'TEST_VALUE'

    del os.environ['TEST_KEY']
    assert env_fallback('TEST_KEY', 'TEST_KEY_DOES_NOT_EXIST') == 'TEST_KEY_DOES_NOT_EXIST'

    # Test exception handling.
    os.environ = {}
    try:
        env_fallback('NET_URL')
        assert False
    except AnsibleFallbackNotFound:
        assert True



# Generated at 2022-06-11 01:24:36.580148
# Unit test for function remove_values
def test_remove_values():
    t_dict, t_list, t_object, t_tuple_list, t_tuple_dict, t_tuple_object = ({'a':1, 'b':2, 'c':None, 'd':{'a':1, 'b':2}, 'e': {'a':1, 'b':2}, 'f':[1,2,3,4], 'g':[]}, [1,2,3,4], object(), [(1,2,3),(4,5,6)], [{'a':1, 'b':2}, {'c':4, 'd':5}], [object(), object()])
    t_dict['d']['key'] = 'value'
    t_dict['e']['key'] = 'value'

# Generated at 2022-06-11 01:24:46.650652
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert set_fallbacks({'param1': {'fallback': (env_fallback, "global_param")}}, {}) == set()
    assert set_fallbacks({'param1': {'fallback': (env_fallback, "global_param")}}, {'param1': 'value'}) == set()
    assert set_fallbacks({'param1': {'fallback': (env_fallback, "global_param")}}, {'param2': 'value'}) == set()
    assert set_fallbacks({'param1': {'fallback': (env_fallback, "global_param")}}, {'param1': 'value'}) == set(['value'])



# Generated at 2022-06-11 01:24:55.521543
# Unit test for function set_fallbacks
def test_set_fallbacks():
    module_name = 'test_set_fallbacks'
    os.environ['TEST_ENV_VAR'] = 'example_value'
    # no fallback value
    argument_spec = {
        'test_param_1': {
            'type': 'str'
        }
    }
    parameters = {}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert no_log_values is set()
    assert parameters == {}
    # fallback value falls back to env variable
    argument_spec = {
        'test_param_2': {
            'type': 'str',
            'fallback': (env_fallback, 'TEST_ENV_VAR')
        }
    }
    parameters = {}

# Generated at 2022-06-11 01:24:57.530976
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('ANSIBLE_TEST_VALUE') == 'test_value'



# Generated at 2022-06-11 01:25:04.097470
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST'] = '123' # pylint: disable=no-member
    try:
        assert('123' == env_fallback('ANSIBLE_TEST'))
    finally:
        del os.environ['ANSIBLE_TEST'] # pylint: disable=no-member
    assert(env_fallback('NOT_IN_ENV') == AnsibleFallbackNotFound)



# Generated at 2022-06-11 01:25:10.658440
# Unit test for function remove_values
def test_remove_values():
    assert remove_values({'a': 'b', 'c': 'd'}, ['d']) == {'a': 'b', 'c': '***'}
    assert remove_values(['a', 'b'], ['b']) == ['a', '***']
    assert remove_values(('a', 'b'), ['b']) == ['a', '***']
    assert remove_values(set(['a', 'b']), ['b']) == set(['a', '***'])



# Generated at 2022-06-11 01:25:13.692693
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['HELLO'] = 'WORLD'
    assert env_fallback('HELLO') == 'WORLD'
    del os.environ['HELLO']
    assert env_fallback('HELLO') == 'WORLD'



# Generated at 2022-06-11 01:25:25.480952
# Unit test for function set_fallbacks
def test_set_fallbacks():
    spec = dict(
        param1=dict(type='str', fallback=(env_fallback, 'MY_ENV_PARAM')),
        param2=dict(type='str', fallback=(env_fallback, 'MY_ENV_PARAM2'))
    )
    parameters = dict()
    no_log_values = set_fallbacks(spec, parameters)

    assert no_log_values == set()
    assert parameters == dict()

    os.environ['MY_ENV_PARAM'] = 'my_env_value'

    no_log_values = set_fallbacks(spec, parameters)

    assert no_log_values == set()
    assert parameters == dict(param1='my_env_value')



# Generated at 2022-06-11 01:25:55.999330
# Unit test for function set_fallbacks
def test_set_fallbacks():
    parameters = {'param1': {'param2': {'param3': 'value1'}}}
    argument_spec = {'param1': {'type': 'dictionary', 'options': {'param2': {'type': 'dictionary', 'options': {
        'param3': {'type': 'str', 'fallback': (env_fallback, 'FALLBACK_ENV_VAR_VALUE')}}}}}}
    os.environ['FALLBACK_ENV_VAR_VALUE'] = 'value2'
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['param1']['param2']['param3'] == 'value2'
    assert no_log_values == set()

# Generated at 2022-06-11 01:26:05.039883
# Unit test for function set_fallbacks
def test_set_fallbacks():
    args_spec = dict(state=dict(type='str', choices=['present', 'absent'], fallback=(env_fallback, 'ANSIBLE_FOO')),
                     foo=dict(type='str', fallback=(env_fallback, ['ANSIBLE_FOO', 'ANSIBLE_BAR'])))
    parameters = dict()
    no_log_values = set_fallbacks(args_spec, parameters)
    assert 'present' == parameters['state']
    assert 'bar' == parameters['foo']
    assert 2 == len(no_log_values)
    assert 'bar' in no_log_values
    assert 'present' in no_log_values



# Generated at 2022-06-11 01:26:15.696771
# Unit test for function sanitize_keys
def test_sanitize_keys():
    fake_no_log_string = '$ANSIBLE_NET_PASSWORD'

    # Test that we correctly sanitize a `dict`
    itm = {"foo": "bar", "_ansible_bar": "baz", "foo_$ANSIBLE_NET_PASSWORD_bar": "foo"}
    result = sanitize_keys(itm, [fake_no_log_string])
    assert result == {"foo": "bar", "_ansible_bar": "baz", "foo__bar": "foo"}

    # Test that we correctly sanitize a `list`
    itm = ["foo", "_ansible_bar", "foo_$ANSIBLE_NET_PASSWORD_bar"]
    result = sanitize_keys(itm, [fake_no_log_string])

# Generated at 2022-06-11 01:26:24.035431
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {}
    argument_spec['project'] = {'type': 'str', 'required': False, 'no_log': False}
    argument_spec['stack'] = {'type': 'str', 'required': False, 'no_log': False}
    argument_spec['username'] = {'type': 'str', 'required': False, 'no_log': True}

    parameters = {}

    no_log_values = set_fallbacks(argument_spec, parameters)

    assert len(parameters) == 0
    assert len(no_log_values) == 0
    #
    argument_spec['stack'] = {'type': 'str', 'required': False, 'no_log': False, 'fallback': (env_fallback, ['STACK'])}

# Generated at 2022-06-11 01:26:34.248843
# Unit test for function set_fallbacks
def test_set_fallbacks():

    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    # Test that set_fallbacks is working correctly.

# Generated at 2022-06-11 01:26:36.320744
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['FAKE'] = 'fake'
    assert env_fallback('FAKE') == 'fake'
    assert env_fallback('MISSING') == AnsibleFallbackNotFound



# Generated at 2022-06-11 01:26:43.843526
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['A'] = '1'
    assert env_fallback('A') == 1
    os.environ.pop('A')
    assert env_fallback('A', 'B') == 'B'
    assert env_fallback('A', 'B', 'C') == 'C'

    assert env_fallback('A', 'B', required=True, fallback='C') == 'C'

    try:
        env_fallback(required=True)
    except AnsibleFallbackNotFound:
        pass
    else:
        assert False



# Generated at 2022-06-11 01:26:53.887218
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        test=dict(fallback=(env_fallback, 'FOO')),
        test2=dict(fallback=(env_fallback, 'FOO', {'fallback_fail': True})),
        test3=dict(fallback=(env_fallback, 'FOO', {'fallback_fail': True}), required=True),
    )
    for param in argument_spec:
        parameters = os.environ.copy()
        parameters[param] = 'bar'
        assert set_fallbacks(argument_spec, parameters) == set()

        parameters[param] = None
        assert set_fallbacks(argument_spec, parameters) == set()

        parameters.pop(param)

# Generated at 2022-06-11 01:27:04.081109
# Unit test for function set_fallbacks
def test_set_fallbacks():
    test_spec = {
        'foo': {'type': 'str', 'fallback': (env_fallback, 'ANSIBLE_TEST_FOO')},
        'bar': {'type': 'int', 'fallback': (env_fallback, 'ANSIBLE_TEST_BAR')},
        'baz': {'type': 'bool', 'fallback': (env_fallback, 'ANSIBLE_TEST_BAZ')},
        'unfallable': {'type': 'str'},
    }
    test_parameters = {
        'foo': 'foo is string',
        'bar': 'bar is string',
        'baz': 'baz is string',
        'unfallable': 'unfallable is string',
    }


# Generated at 2022-06-11 01:27:14.253471
# Unit test for function remove_values
def test_remove_values():
    asdf = {'a': 'b', 'secret': 'password'}
    bsdf = {'a': 'b', 'secret': 9}
    csdf = [{'a': 'b', 'secret': 'password'}]
    assert remove_values(asdf, ['password']) == {'a': 'b', 'secret': 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'}
    assert remove_values(bsdf, ['password']) == {'a': 'b', 'secret': 9}
    assert remove_values(csdf, ['password']) == [{'a': 'b', 'secret': 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'}]



# Generated at 2022-06-11 01:27:47.142280
# Unit test for function set_fallbacks
def test_set_fallbacks():
    test_spec = {
        'test_param': {
            'type': 'str',
            'fallback': (env_fallback, ['TEST_VAR', 'OTHER']),
        },
        'other_param': {
            'type': 'str',
            'fallback': (env_fallback, ['OTHER_VAR', 'OTHER']),
        },
    }
    test_params = {}
    no_log_values = set_fallbacks(test_spec, test_params)
    assert len(no_log_values) == 0
    assert 'test_param' not in test_params
    assert 'other_param' not in test_params

    os.environ['TEST_VAR'] = 'hello'
    no_log_values = set_fallbacks(test_spec, test_params)
   

# Generated at 2022-06-11 01:27:58.141342
# Unit test for function set_fallbacks
def test_set_fallbacks():
    parameters = dict()
    argument_spec = dict(
        param1=dict(type='str', fallback=(env_fallback, ['PARAM1_ENV'])),
        param2=dict(type='dict', fallback=(dict, dict(a=1, b=2, c=3))),
        param3=dict(type='str', fallback=(env_fallback, ['PARAM3_ENV'])),
        param4=dict(type='str', fallback=(env_fallback, ['PARAM4_ENV'])),
        param5=dict(type='str', fallback=(env_fallback, ['PARAM5_ENV'])),
    )
    fallback_values = set_fallbacks(argument_spec, parameters)

# Generated at 2022-06-11 01:28:04.393456
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'param': {'fallback': (env_fallback, ['PARAM_ENV_VAR']), 'type': 'str'}}
    parameters = {}
    os.environ['PARAM_ENV_VAR'] = 'param_value'
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert 'param_value' in no_log_values


# Generated at 2022-06-11 01:28:14.015336
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'foo': {
            'default': 'valid value 1',
        },
        'bar': {
            'default': 'valid value 2',
            'no_log': True
        },
        'baz': {
            'fallback': (env_fallback, 'FOO_BAZ'),
            'no_log': True
        },
        'boo': {
            'fallback': (env_fallback, 'FOO_BOO')
        },
        'boz': {
            'fallback': (env_fallback, 'FOO_BOZ')
        },
        'bee': {
            'fallback': (lambda: 'bee'),
            'no_log': True
        }
    }

    parameters = {}

# Generated at 2022-06-11 01:28:25.405284
# Unit test for function remove_values
def test_remove_values():
    import warnings
    from ansible.module_utils.six import string_types
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils._text import to_native
    from ansible.module_utils._text import to_text
    import json


# Generated at 2022-06-11 01:28:32.812010
# Unit test for function env_fallback
def test_env_fallback():
    """Test loading value from environment variable"""

    # Set environment variable
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'mock_value'

    # Function call should return environment variable value
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'mock_value'

    # Function call should raise AnsibleFallbackNotFound exception
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('ANSIBLE_TEST_MISSING_ENV_FALLBACK')

# Generated at 2022-06-11 01:28:42.874650
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        dict_argument=dict(type='dict'),
        str_argument=dict(type='str'),
        test_argument=dict(type='str', fallback=(env_fallback, 'TEST'))
    )

    values = dict(
        dict_argument=dict(a=1, b=2),
        str_argument='value'
    )

    result = set_fallbacks(argument_spec, values)
    assert result == set()
    assert values['dict_argument']['a'] == 1
    assert values['dict_argument']['b'] == 2
    assert values['str_argument'] == 'value'
    assert values['test_argument'] == os.environ['TEST']



# Generated at 2022-06-11 01:28:53.150321
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        param1=dict(type='str', fallback=(env_fallback, 'PARAM1')),
        param2=dict(type='str', fallback=(env_fallback, 'PARAM2'), no_log=True),
        param3=dict(type='str', fallback=(env_fallback, 'PARAM3'), no_log=False),
        param4=dict(type='str', fallback=(env_fallback, 'PARAM4', dict(encoding='utf-8'))),
    )

    parameters = dict(
        param1='test'
    )

    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['param1'] == 'test'
    assert parameters['param2'] == 'test2'

# Generated at 2022-06-11 01:28:55.274866
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('doesntexist', b='not_exists') == 'not_exists'



# Generated at 2022-06-11 01:29:03.553324
# Unit test for function env_fallback
def test_env_fallback():
    frozen = frozenset(('A', 'B', 'C'))
    assert env_fallback('A', 'B', 'C') == 'A'
    assert env_fallback('B', 'C') == 'B'
    assert env_fallback('B', 'C', 'D') == 'B'
    assert env_fallback(frozen) == 'A'

    try:
        assert env_fallback('B', 'C', 'D') != 'A' or env_fallback(frozen) != 'C'
    except AnsibleFallbackNotFound:
        pass
    else:
        raise AssertionError("Expected AnsibleFallbackNotFound")

    os.environ['D'] = 'D'
    assert env_fallback('D') == 'D'
