

# Generated at 2022-06-11 01:19:57.303673
# Unit test for function set_fallbacks
def test_set_fallbacks():
    arg_spec = {
        'aws_access_key_id': {
            'type': 'str',
            'required': True,
            'env': [
                {'name': 'AWS_ACCESS_KEY_ID'}
            ]
        }
    }
    parameters = {
    }
    assert set_fallbacks(arg_spec, parameters) == set()
    assert len(parameters) == 0

    arg_spec = {
        'aws_access_key_id': {
            'type': 'str',
            'required': True,
            'env': [
                {'name': 'AWS_ACCESS_KEY_ID'}
            ]
        }
    }
    parameters = {
        'aws_access_key_id': 'foobar'
    }

# Generated at 2022-06-11 01:20:02.479027
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK1') is None
    os.environ['ANSIBLE_TEST_ENV_FALLBACK1'] = 'foo'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK1') == 'foo'



# Generated at 2022-06-11 01:20:12.142700
# Unit test for function set_fallbacks
def test_set_fallbacks():
    params = {'a': 'foo'}

# Generated at 2022-06-11 01:20:22.451540
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Use actual fallback function
    arguments_spec = dict(
        a=dict(fallback=(env_fallback, 'ANSIBLE_TEST_A', dict(fallback=('b',)))),
        b=dict(default='c'),
    )

    parameters = dict(
        a=None,
    )

    no_log_values = set_fallbacks(arguments_spec, parameters)
    assert not no_log_values
    assert parameters['a'] == 'c'

    # Mock fallback function
    class TestException(Exception):
        pass

    def mock_fallback(arg1, arg2, **kwargs):
        if arg1 == 'foo':
            return arg1
        elif arg2 == 'bar':
            return arg2

# Generated at 2022-06-11 01:20:33.914296
# Unit test for function set_fallbacks
def test_set_fallbacks():
    fallback_spec = dict(
        param1=dict(fallback=(env_fallback, 'TEST_PARAM_1', 'TEST_PARAM_2'))
    )
    parameters = dict()

    os.environ['TEST_PARAM_1'] = 'TEST1'
    set_fallbacks(fallback_spec, parameters)
    assert 'TEST1' == parameters['param1']

    del os.environ['TEST_PARAM_1']
    os.environ['TEST_PARAM_2'] = 'TEST2'
    set_fallbacks(fallback_spec, parameters)
    assert 'TEST2' == parameters['param1']

    # Ensure that fallbacks only go one-level deep

# Generated at 2022-06-11 01:20:44.733898
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert set_fallbacks({
        'token': {'required': False, 'type': 'str', 'fallback': (env_fallback, 'CLOUDANT_TOKEN')}},
        {'token': None}
        ) == set()
    assert set_fallbacks({
        'token': {'required': False, 'type': 'str', 'fallback': (env_fallback, 'CLOUDANT_TOKEN')}},
        {}
        ) == {'foo'}
    os.environ['CLOUDANT_TOKEN'] = 'foo'
    assert set_fallbacks({
        'token': {'required': False, 'type': 'str', 'fallback': (env_fallback, 'CLOUDANT_TOKEN')}},
        {}
        ) == {'foo'}



# Generated at 2022-06-11 01:20:54.729301
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'test': {
            'type': 'str',
            'fallback': ('env_fallback', 'TEST'),
        },
        'test2': {
            'type': 'str',
            'fallback': ('env_fallback', 'TEST2'),
        },
        'test3': {
            'type': 'str',
            'fallback': ('env_fallback', 'TEST3'),
        },
    }

    with patch.dict(os.environ, {'TEST': 'hello', 'TEST2': 'world'}):
        parameters = {}
        no_log_values = set_fallbacks(argument_spec, parameters)
        assert parameters['test'] == 'hello'
        assert parameters['test2'] == 'world'
        assert 'test3' not in parameters

# Generated at 2022-06-11 01:21:06.736071
# Unit test for function set_fallbacks

# Generated at 2022-06-11 01:21:17.098136
# Unit test for function set_fallbacks
def test_set_fallbacks():
    test_spec = {
        'param1': {'type': 'str', 'default': 'default1', 'fallback': (env_fallback, ['TEST_DEFAULT'])},
        'param2': {'type': 'str', 'fallback': (env_fallback, ['TEST_DEFAULT'])},
        'param3': {'type': 'str', 'fallback': (env_fallback, ['TEST_DEFAULT', {'fallback_behavior': 'fallback_to_default'}])},
        'param4': {'type': 'str', 'fallback': (env_fallback, [])},
    }

    test_parameters = {
        'param1': 'value',
        'param2': None,
        'param4': 'value4'
    }

    no_log_values

# Generated at 2022-06-11 01:21:26.529306
# Unit test for function set_fallbacks
def test_set_fallbacks():
    param = {'user': {'fallback': (env_fallback, ['ANSIBLE_USER'], {'version': 2})}, 'password': {'fallback': (env_fallback, 'ANSIBLE_PASSWORD')}}
    parameters = {}
    no_log_values = set_fallbacks(param, parameters)
    assert no_log_values == set()
    assert parameters == {}
    parameters['user'] = "admin"
    no_log_values = set_fallbacks(param, parameters)
    assert no_log_values == set()
    assert parameters == {'user': 'admin'}
    os.environ['ANSIBLE_USER'] = 'demo'
    parameters = {}
    no_log_values = set_fallbacks(param, parameters)
    assert no_log_values == set()
    assert parameters

# Generated at 2022-06-11 01:21:51.037211
# Unit test for function env_fallback
def test_env_fallback():  # noqa
    os.environ["FAKE_ENV"] = "fake_env"
    os.environ["FAKE_ENV_2"] = "fake_env_2"
    assert env_fallback("FAKE_ENV") == "fake_env"
    assert env_fallback("FAKE_ENV_2") == "fake_env_2"
    del os.environ["FAKE_ENV"]
    del os.environ["FAKE_ENV_2"]



# Generated at 2022-06-11 01:22:00.281937
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback() == os.environ
    assert env_fallback('ANSIBLE_FALLBACK_ANSIBLE_CONFIG') == os.environ['ANSIBLE_FALLBACK_ANSIBLE_CONFIG']
    assert env_fallback('ANSIBLE_FALLBACK_ANSIBLE_CONFIG', 'ANSIBLE_FALLBACK_ANSIBLE_LOG', 'ANSIBLE_FALLBACK_ANSIBLE_LOG_PATH', 'ANSIBLE_FALLBACK_ANSIBLE_DEBUG') == os.environ['ANSIBLE_FALLBACK_ANSIBLE_CONFIG']
    assert env_fallback('ANSIBLE_FALLBACK_ANSIBLE_FOO', 'ANSIBLE_FALLBACK_ANSIBLE_BAR')
    assert env_fallback('ANSIBLE_FALLBACK_ANSIBLE_FOO')


# Generated at 2022-06-11 01:22:04.193373
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Testing function (private)
    assert 'var_name' in set_fallbacks({'var_name': {'type': 'str', 'fallback': (env_fallback, 'ENV_VAR_NAME')}}, {})



# Generated at 2022-06-11 01:22:14.378438
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        param1=dict(type='str', fallback=(env_fallback, ('MYPARAM1',))),
        param2=dict(type='str', fallback=(env_fallback, ('MYPARAM2', 'MYPARAM3'))),
        param3=dict(type='str', fallback=(env_fallback, ('MYPARAM4', 'MYPARAM5',))),
    )
    parameters = {}

    os.environ['MYPARAM1'] = "MY_PARAM_1"
    expected_result = set(['MY_PARAM_1', 'MY_PARAM_2', 'MY_PARAM_4'])
    os.environ['MYPARAM2'] = "MY_PARAM_2"

# Generated at 2022-06-11 01:22:24.894161
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Setup function argument spec
    argument_spec = dict(
        param_1=dict(type='str', fallback=(env_fallback, 'PARAM_1', 'PARAM_2')),
        param_2=dict(type='str', fallback=(env_fallback, 'PARAM_3', 'PARAM_4')),
        param_3=dict(type='str', fallback=(env_fallback, 'PARAM_5', 'PARAM_6')),
    )
    parameters = {}
    no_log_vals = set()

    # Setup environment variables
    os.environ['PARAM_1'] = 'param_1_fallback'
    os.environ['PARAM_2'] = 'param_2_fallback'

    # Check if function returns a set of no log values when env vars for PARAM

# Generated at 2022-06-11 01:22:33.789132
# Unit test for function set_fallbacks
def test_set_fallbacks():
    parameters = {
        'param1': 'value1',
    }
    argument_spec = {
        'param1': {
            'type': 'int',
            'fallback': ('env_fallback', 'param1_from_env'),
        }
    }
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['param1'] == 'value1'
    assert no_log_values == set()
    os.environ['param1_from_env'] = 'env_value'
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['param1'] == 'env_value'
    assert no_log_values == set()
    del os.environ['param1_from_env']


# Generated at 2022-06-11 01:22:45.357078
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # no fallback specified
    argument_spec = dict(param1=dict(type='int'))
    parameters = dict(param2='foo')
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert no_log_values == set()
    assert parameters == dict(param2='foo')

    # fallback with default
    argument_spec = dict(param1=dict(type='str', fallback=(str, 'default')))
    parameters = dict(param2='foo')
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert 'default' not in no_log_values
    assert parameters == dict(param1='default', param2='foo')

    # fallback with default but param is set

# Generated at 2022-06-11 01:22:50.318057
# Unit test for function env_fallback
def test_env_fallback():
    key = 'TROGDOR_TEST_KEY'
    if key in os.environ:
        del os.environ[key]
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback(key)
    os.environ[key] = 'testing 1234'
    assert env_fallback(key) == 'testing 1234'
    del os.environ[key]



# Generated at 2022-06-11 01:23:01.527296
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # simple case
    argument_spec = {'name': {'type': 'str', 'fallback': ('env', 'foo')}}
    parameters = {}
    os.environ['foo'] = 'bar'
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['name'] == 'bar'
    assert len(no_log_values) == 0

    del os.environ['foo']

    # literal fallback
    argument_spec = {'name': {'type': 'str', 'fallback': ('literal', 'foo')}}
    parameters = {}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['name'] == 'foo'
    assert len(no_log_values) == 0

    # no fallback

# Generated at 2022-06-11 01:23:10.401058
# Unit test for function set_fallbacks
def test_set_fallbacks():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common._collections_compat import Mapping
    spec = {'param1': {'type': 'str', 'fallback': (env_fallback, ['ANSIBLE_PARAM1'])},
            'param2': {'type': 'str', 'fallback': (env_fallback, ['ANSIBLE_PARAM2', 'ANSIBLE_PARAM3'])},
            'param3': {'type': 'str', 'fallback': (env_fallback, 'ANSIBLE_PARAM4')},
            'param4': {'type': 'str', 'fallback': (env_fallback, 'ANSIBLE_PARAM5')},
            'param5': {'type': 'str'}}

# Generated at 2022-06-11 01:23:33.241738
# Unit test for function set_fallbacks

# Generated at 2022-06-11 01:23:42.542934
# Unit test for function set_fallbacks

# Generated at 2022-06-11 01:23:44.749953
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('FOOBAR') == os.environ['FOOBAR']


# Generated at 2022-06-11 01:23:49.990608
# Unit test for function remove_values
def test_remove_values():
    a = dict(a='123', b=dict(c='456', d=dict(e='789', f='abc')))

# Generated at 2022-06-11 01:23:59.524197
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Test 1, no fallback case
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    ret = set_fallbacks({}, module.params)
    assert len(ret) == 0

    # Test 2, fallback case
    module = AnsibleModule(argument_spec={'test': {'fallback': ('env_fallback', 'TEST_ENV_FALLBACK')}})
    ret = set_fallbacks({'test': {'fallback': ('env_fallback', 'TEST_ENV_FALLBACK')}}, module.params)
    assert len(ret) == 0

    # Test 3, fallback case with env vars
    os.environ['TEST_ENV_FALLBACK'] = 'ansible'
    ret = set_fall

# Generated at 2022-06-11 01:24:05.688790
# Unit test for function remove_values
def test_remove_values():
    # setup parameters for testing
    test_set_root_value = frozenset(['root_value1', 'root_value2', 'root_value3'])
    test_dict_root = {'root_value1': 100, 'root_value2': 200, 'root_value3': 300}
    test_list_root = [100, 200, 300]
    test_set_root = set([100, 200, 300])
    test_dict_value = {'value1': 'value1', 'value2': {'value2': 'value2'}, 'value3': [{'value3': 'value3'}]}
    test_list_value = ['value1', 'value2', 'value3']
    test_set_value = set(['value1', 'value2', 'value3'])
    no_log_

# Generated at 2022-06-11 01:24:15.355371
# Unit test for function set_fallbacks
def test_set_fallbacks():
    params = {}
    spec = {'foo': {'type': 'str', 'fallback': (env_fallback, ('FOO',))}}
    os.environ['FOO'] = 'bar'
    assert set_fallbacks(spec, params) == set()
    assert params == {'foo': 'bar'}
    del(os.environ['FOO'])

    params = {'foo': None}
    assert set_fallbacks(spec, params) == set()
    assert params == {'foo': None}

    params = {'foo': 'baz'}
    assert set_fallbacks(spec, params) == set()
    assert params == {'foo': 'baz'}

    params = {}

# Generated at 2022-06-11 01:24:26.781554
# Unit test for function set_fallbacks
def test_set_fallbacks():
    from ansible.module_utils.basic import AnsibleModule
    argument_spec = {
        'param': {
            'type': 'str',
            'fallback': (env_fallback, 'TEST_PARAM', {'key': 'default'}),
        },
        'param_foo': {
            'type': 'str',
            'fallback': (env_fallback, 'TEST_FOO'),
        },
    }

    module = AnsibleModule(argument_spec=argument_spec, no_log=['param'])
    set_fallbacks(argument_spec, module.params)
    assert module.params['param'] == 'default'
    assert 'param' in module.no_log_values
    assert module.params['param_foo'] == ''
    assert 'param_foo' not in module.no

# Generated at 2022-06-11 01:24:38.613984
# Unit test for function set_fallbacks
def test_set_fallbacks():
    param_test_dict = {
        'test_param_1': {
            'type': 'str',
            'fallback': (env_fallback, 'TEST_PARAM_1'),
        },
        'test_param_2': {
            'type': 'str',
            'fallback': (env_fallback, 'TEST_PARAM_2', 'TEST_PARAM_3'),
        },
        'test_param_3': {
            'type': 'str',
            'fallback': (env_fallback, 'TEST_PARAM_4'),
        },
        'test_param_4': {
            'type': 'str',
            'no_log': True,
            'fallback': (env_fallback, 'TEST_PARAM_5'),
        },
    }
   

# Generated at 2022-06-11 01:24:49.850551
# Unit test for function remove_values
def test_remove_values():
    """Unit test for remove_values."""

    # Test container types (dict, list, set)
    test_dict = {
        'unaffected': 'ive',
        'affected': 'sensitive',
        'recursive': ['sensitive', 'sensitive'],
        'sensitive': {
            'leaf_embedded_sensitive': 'sensitive',
            'leaf_unaffected': 'ive',
        },
    }

# Generated at 2022-06-11 01:25:15.365778
# Unit test for function set_fallbacks
def test_set_fallbacks():
    arg_spec = {'param1': {'type': 'str', 'fallback': ['env_fallback', 'param1']},
                'param2': {'type': 'dict', 'fallback': ['env_fallback', 'param2']},
                'param3': {'type': 'dict', 'no_log': True, 'fallback': ['env_fallback', 'param3']},
                'param4': {'type': 'list', 'fallback': ['env_fallback', 'param4']},
                'param5': {'type': 'list', 'no_log': True, 'fallback': ['env_fallback', 'param5']}}

    parameters = {'param1': 'test1', 'param2': {'p1': 'test2'}, 'param4': ['test4']}

    no_log

# Generated at 2022-06-11 01:25:22.183615
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['TEST_ENV_FALLBACK'] = 'test_env_fallback'
    assert(env_fallback('TEST_ENV_FALLBACK') == 'test_env_fallback')
    assert(env_fallback('TEST_ENV_FALLBACK_NOT_SET') == AnsibleFallbackNotFound)
    del(os.environ['TEST_ENV_FALLBACK'])


# Generated at 2022-06-11 01:25:30.474148
# Unit test for function env_fallback
def test_env_fallback():
    import os

    # Test fallback when var is not set
    with testtools.ExpectedException(AnsibleFallbackNotFound):
        env_fallback('NOTSET')

    # Test fallback when var is set but is empty
    os.environ['NOTSET'] = ''
    with testtools.ExpectedException(AnsibleFallbackNotFound):
        env_fallback('NOTSET')
    os.environ.pop('NOTSET')

    # Test success
    os.environ['SET'] = 'value'
    assert env_fallback('SET'), "env_fallback failed"
    os.environ.pop('SET')



# Generated at 2022-06-11 01:25:36.511675
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        foo=dict(type='str', fallback=(env_fallback, 'FOO')),
        bar=dict(type='str'),
        bam=dict(type='str', fallback=(env_fallback, 'BAM', dict(fallback_to_null=True))),
        toomany=dict(type='str', fallback=(env_fallback, 'FOO', 'BAM')),
        optional_arg=dict(type='str', fallback=(env_fallback, dict(other='value', fallback_to_null=True))),
        toofew=dict(type='str', fallback=(env_fallback,)),
    )


# Generated at 2022-06-11 01:25:43.384340
# Unit test for function remove_values
def test_remove_values():
    assert remove_values('sensitive_1', 'sensitive_1') is None
    assert remove_values('sensitive_1 sensitive_2', ['sensitive_1', 'sensitive_2']) is None
    assert remove_values('foo sensitive_1 sensitive_2 bar', ['sensitive_1', 'sensitive_2']) == 'foo  bar'
    assert remove_values(['sensitive_1', 'sensitive_2', 'sensitive_3', 'foo'], ['sensitive_1', 'sensitive_2']) == ['', '', 'sensitive_3', 'foo']
    assert remove_values(['sensitive_1', 'sensitive_2', 'sensitive_3', 'foo'], 'sensitive_1') == ['', 'sensitive_2', 'sensitive_3', 'foo']

# Generated at 2022-06-11 01:25:53.576432
# Unit test for function sanitize_keys
def test_sanitize_keys():
    # pylint: disable=unused-argument
    def collect_arguments(module_name, function_name, arguments):
        # pylint: disable=unused-argument
        # pylint: disable=no-self-use
        # pylint: disable=bare-except
        collected_arguments[function_name].append(arguments)
        try:
            return collected_arguments[function_name][0]
        except:
            return arguments


# Generated at 2022-06-11 01:26:04.389978
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys(1, []) == 1
    assert sanitize_keys('test', []) == 'test'
    assert sanitize_keys('test', ['test']) == '--value %s masked--' % md5('test')
    assert sanitize_keys(['test'], []) == ['test']
    assert sanitize_keys(['test'], ['test']) == ['--value %s masked--' % md5('test')]
    assert sanitize_keys(['test', 'test'], ['test']) == ['--value %s masked--' % md5('test'), '--value %s masked--' % md5('test')]
    assert sanitize_keys({None: 'test'}, []) == {None: 'test'}

# Generated at 2022-06-11 01:26:15.002489
# Unit test for function set_fallbacks

# Generated at 2022-06-11 01:26:20.690271
# Unit test for function env_fallback
def test_env_fallback():
    with patch.dict('os.environ', {'TEST_ENV': 'test_value'}):
        assert env_fallback('TEST_ENV') == 'test_value'
        assert env_fallback('TEST_ENV_1') == None

FALLBACK_STRATEGIES = {
    'env': env_fallback,
}


# Generated at 2022-06-11 01:26:25.669021
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'foo': {'fallback': (env_fallback, 'foo_a', 'foo_b')},
                     'bar': {'fallback': (env_fallback, 'bar_a', 'bar_b')},
                     'baz': {'fallback': (env_fallback, {'vars': ['baz_a', 'baz_b']})},
                     'spam': {'fallback': (), 'required': True},
                     'eggs': {'fallback': (None,)},
                     'ham': {'fallback': [env_fallback, 'ham_a', 'ham_b']},
                     'apple': {'fallback': env_fallback},
                     }
    parameters = {'foo': 'foo_x', 'baz': 'baz_x'}
    no_

# Generated at 2022-06-11 01:26:55.876182
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        host=dict(type='str', required=True, fallback=(env_fallback, ["ANSIBLE_HOST"])),
        passwd=dict(type='str', fallback=(env_fallback, ["ANSIBLE_PASSWD", "PYTHON_MODULE_ARGUMENT_SPEC_PASSWD"]), no_log=True),
    )
    parameters = dict(
        host='fantastic.com',
    )
    result = set_fallbacks(argument_spec, parameters)
    assert parameters == dict(
        host='fantastic.com',
        passwd='reallysecret',
    )
    assert result == set('reallysecret')

    # param not required and item does not exist in os.environ

# Generated at 2022-06-11 01:27:07.345135
# Unit test for function set_fallbacks
def test_set_fallbacks():
    parameters = {}
    fallbacks = [
        {'no_log': True, 'fallback': (env_fallback, ['AWS_SECRET_KEY', 'AWS_SECRET_ACCESS_KEY'])},
        {'fallback': (env_fallback, ['AWS_ACCESS_KEY_ID', 'AWS_ACCESS_KEY'])}
    ]
    for fallback in fallbacks:
        assert parameters.get(fallback.get('fallback')[1][0]) is None
    assert set_fallbacks(dict([(item.get('fallback')[1][0], item) for item in fallbacks]), parameters) == set()
    assert parameters.get(fallbacks[0].get('fallback')[1][0]) is None

# Generated at 2022-06-11 01:27:18.170323
# Unit test for function sanitize_keys

# Generated at 2022-06-11 01:27:26.068585
# Unit test for function set_fallbacks

# Generated at 2022-06-11 01:27:29.449825
# Unit test for function env_fallback
def test_env_fallback():
    name = 'ENV_FALLBACK_TEST'
    value = 'abc123'
    os.environ[name] = value
    assert env_fallback(name) == value



# Generated at 2022-06-11 01:27:33.049785
# Unit test for function env_fallback
def test_env_fallback():
    fake_env = {'ANSIBLE_TEST': 'foo'}
    with patch.dict(os.environ, fake_env):
        assert env_fallback('ANSIBLE_TEST') == 'foo'
        assert env_fallback('BAR') == AnsibleFallbackNotFound


# Generated at 2022-06-11 01:27:35.026536
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('RAX_USERNAME') == os.environ['RAX_USERNAME']



# Generated at 2022-06-11 01:27:39.510274
# Unit test for function env_fallback
def test_env_fallback():
    os.environ.update({
        'FOO': 'BAR'
    })
    assert env_fallback('FOO') == 'BAR'
    assert env_fallback('FOO', 'BAR') == 'BAR'
    assert env_fallback('BAR', 'FOO') == 'FOO'
test_env_fallback()



# Generated at 2022-06-11 01:27:42.805673
# Unit test for function sanitize_keys
def test_sanitize_keys():
    """Function that sanitize the string in the key, so no_logging secret will not be exposed.
    This is to ensure that we have the same behavior with Ansible 2.6
    """
    no_log_values = set(['value1', 'value2'])
    ignore_keys = ('key1',)
    mock = {'key1': 'value1', 'key2': 'value2'}
    assert sanitize_keys(mock, no_log_values, ignore_keys) == {'key1': 'value1', 'key2': 'REDACTED'}



# Generated at 2022-06-11 01:27:46.910685
# Unit test for function env_fallback
def test_env_fallback():
    try:
        env_fallback('ANSIBLE_FOO')
    except AnsibleFallbackNotFound as e:
        assert e is not None
    try:
        env_fallback('ANSIBLE_FOO', 'ANSIBLE_BAR')
    except AnsibleFallbackNotFound as e:
        assert e is not None

_FALLBACKS = dict(
    env=env_fallback,
)


# Generated at 2022-06-11 01:28:47.143401
# Unit test for function sanitize_keys
def test_sanitize_keys():
    no_log_strings = {'asdf', 'bad_password'}
    a = {'bad_password': 'asdf'}
    assert sanitize_keys(a, no_log_strings) == {'asdf': 'asdf'}
    b = {'foo': {'bad_password': {'bad_password': 'bad_password'}}}
    assert sanitize_keys(b, no_log_strings) == {'foo': {'asdf': {'asdf': 'asdf'}}}
    c = 'asdf'
    assert sanitize_keys(c, no_log_strings) == 'asdf'
    d = [{'bad_password': 'asdf'}]

# Generated at 2022-06-11 01:28:49.443071
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['env_arg1'] = 'env_value1'
    os.environ['env_arg2'] = 'env_value2'
    result = env_fallback('env_arg1', 'env_arg2')
    assert result == 'env_value1'


# Generated at 2022-06-11 01:28:59.499083
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        foo=dict(type='str', fallback=(env_fallback, 'FOO')),
        bar=dict(type='str', fallback=(lambda: 'bar',)),
        baz=dict(type='str', fallback=(env_fallback, 'BAZ')),
        zoo=dict(type='str', fallback=(env_fallback, 'ZOO', dict(boo='zoo'))),
        blank_foo=dict(type='str', fallback=(env_fallback, 'BLANK_FOO')),
        none_foo=dict(type='str', fallback=(env_fallback, 'NONE_FOO')),
        int_foo=dict(type='int', fallback=(env_fallback, 'INT_FOO')),
    )


# Generated at 2022-06-11 01:29:06.289504
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert set_fallbacks({'param1': {'fallback': (env_fallback, 'ANSIBLE_TEST_PARAM1')}}, {}) == set()
    assert set_fallbacks({'param1': {'fallback': (env_fallback, 'ANSIBLE_TEST_PARAM1')}}, {'param1': 'param1_value'}) == set()
    assert set_fallbacks({'param1': {'fallback': (env_fallback, 'ANSIBLE_TEST_PARAM1')}}, {'param1': 'param1_value'}) == set()
    assert set_fallbacks({'param1': {'fallback': (env_fallback, 'ANSIBLE_TEST_PARAM1')}}, {}) == set()