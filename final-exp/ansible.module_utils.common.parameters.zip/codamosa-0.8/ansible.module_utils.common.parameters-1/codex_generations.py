

# Generated at 2022-06-11 01:20:02.952142
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ENV_FALLBACK_TEST'] = '20'
    assert env_fallback('ENV_FALLBACK_TEST') == '20'



# Generated at 2022-06-11 01:20:08.359483
# Unit test for function set_fallbacks
def test_set_fallbacks():
    spec = {
        'param1': {
            'default': {'key1': 'value1'}
            },
        'param2': {
            'default': {'key2': 'value2'}
            }
        }
    result = set_fallbacks(spec, {})
    assert {} == result



# Generated at 2022-06-11 01:20:14.958920
# Unit test for function set_fallbacks

# Generated at 2022-06-11 01:20:22.572831
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'param1': {'type': 'str', 'fallback': (env_fallback, ['ANSIBLE_PARAM1'])},
        'param2': {'type': 'int', 'fallback': (42,)},
    }
    parameters = {
        'param2': 84
    }
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['param1'] == os.environ['ANSIBLE_PARAM1']
    assert parameters['param2'] == 84
    assert no_log_values == set()


# Generated at 2022-06-11 01:20:27.044066
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback("FOO") == os.environ["FOO"]
    assert os.environ["FOO"] == "bar"
    assert os.environ["FOO"] == env_fallback("FOO")
    assert env_fallback("BAR") == "BAZ"



# Generated at 2022-06-11 01:20:39.091505
# Unit test for function set_fallbacks

# Generated at 2022-06-11 01:20:46.353397
# Unit test for function env_fallback
def test_env_fallback():
    """Synthesize env variable"""
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'fallback'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'fallback'
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('ANSIBLE_TEST_MISSING')
    assert env_fallback('ANSIBLE_TEST_MISSING', 'default') == 'default'
    del os.environ['ANSIBLE_TEST_ENV_FALLBACK']



# Generated at 2022-06-11 01:20:55.390892
# Unit test for function env_fallback
def test_env_fallback():
    """
    Test env_fallback
    """
    os.environ['ANSIBLE_MODULE_ARGS'] = '{"one": "1", "two": {"three": "4", "five": "6"}}'
    os.environ['ANSIBLE_MODULE_PARAMS'] = '{"one": "1", "two": {"three": "4", "five": "6"}}'
    os.environ['ANSIBLE_MODULE_ONE'] = 'ONE'
    os.environ['ANSIBLE_MODULE_TWO_THREE'] = 'THREE'
    os.environ['ANSIBLE_MODULE_TWO_FIVE'] = 'FIVE'

    data = dict(one='1', two=dict(three='3', five='5'))
    no_log_values = set()
    fallback_

# Generated at 2022-06-11 01:21:06.875129
# Unit test for function set_fallbacks
def test_set_fallbacks():
    data = dict(a='a', b=dict(a='a'))
    args = dict(a=dict(type='str', fallback=(env_fallback, 'FOO')), b=dict(type='dict', options=dict(c=dict(type='str', fallback=(env_fallback, 'FOO'))), fallback=(env_fallback, 'BAR')))
    no_log_values = set_fallbacks(args, data)
    assert data == dict(a='a', b=dict(a='a', c=os.environ.get('FOO', ''))), data
    assert no_log_values == set(), no_log_values

    os.environ['FOO'] = 'foo'
    data = dict()

# Generated at 2022-06-11 01:21:17.260704
# Unit test for function set_fallbacks
def test_set_fallbacks():

    var_spec = dict(
        FOO=dict(type='int', fallback=('env_fallback', 'TEST_FOO')),
        BAR=dict(type='str', fallback=('env_fallback', 'TEST_BAR')),
        BAZ=dict(type='bool', fallback=('env_fallback', 'TEST_BAZ')),
        QUX=dict(type='dict', fallback=('env_fallback', 'TEST_QUX')),
        FIELD=dict(type='str', fallback=(env_fallback, dict(key='TEST_FIELD'))),
        INDEX=dict(type='int', fallback=(env_fallback, dict(index=0, default='', sep=' '))),
    )


# Generated at 2022-06-11 01:21:48.442096
# Unit test for function set_fallbacks

# Generated at 2022-06-11 01:21:55.804800
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert set_fallbacks({'foo': {'type': 'str'}}, {}) == {}
    assert set_fallbacks({'foo': {'type': 'str', 'default': 'bar'}}, {}) == {}
    assert set_fallbacks({'foo': {'type': 'str', 'fallback': ('baz',)}}, {}) == {}
    assert set_fallbacks({'foo': {'type': 'str', 'fallback': ('baz', 'test')}}, {}) == {}
    assert set_fallbacks({'foo': {'type': 'str', 'no_log': True, 'fallback': (env_fallback, 'TEST_FOO')}}, {'foo': None}) == set()

# Generated at 2022-06-11 01:22:02.948125
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('TEST_ENV') == os.environ['TEST_ENV']
    assert env_fallback('TEST_ENV_NOT_SET') == AnsibleFallbackNotFound
    assert env_fallback('TEST_ENV', 'TEST_ENV_NOT_SET') == os.environ['TEST_ENV']
    assert env_fallback('TEST_ENV_NOT_SET', 'TEST_ENV') == os.environ['TEST_ENV']



# Generated at 2022-06-11 01:22:13.811562
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'param1': {'type': 'str'}, 'param2': {'type': 'str', 'fallback': (env_fallback, ['TEST_ENV_VAR'])},
                     'param3': {'type': 'int'}, 'param4': {'type': 'dict'}}
    parameters = {'param1': 'value1'}
    expected_no_log_values = set()
    parameters, no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters.get('param1') == 'value1'
    assert parameters.get('param2') is None
    assert parameters.get('param3') is None
    assert parameters.get('param4') is None
    assert no_log_values == expected_no_log_values


# Generated at 2022-06-11 01:22:24.318243
# Unit test for function set_fallbacks
def test_set_fallbacks():

    arguments = {
        'TEST1': {
            'type': 'str',
            'default': 'some_default',
            'fallback': (env_fallback, ['TESTVAR1', 'TESTVAR2'])
        },
        'TEST2': {
            'type': 'str',
            'default': 'some_default',
            'fallback': (env_fallback, 'TESTVAR1')
        },
        'TEST3': {
            'type': 'str',
            'default': 'some_default',
            'fallback': (env_fallback, 'TESTVAR1', {'fallback_variable': 'TESTVAR2'})
        },
    }

    params = {}
    os.environ['TESTVAR1'] = 'value1'
   

# Generated at 2022-06-11 01:22:33.353463
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert set_fallbacks({"test": {"type": "str", "fallback": (env_fallback, "TEST")}}, {}) == set()
    assert set_fallbacks({"test": {"type": "str", "fallback": (env_fallback, {"var": "TEST"})}}, {}) == set()
    assert set_fallbacks({"test": {"type": "str", "fallback": (env_fallback, "TEST"), "no_log": True}}, {}) == set(["$ANSIBLE_VAULT"])
    assert set_fallbacks({"test": {"type": "str", "fallback": (env_fallback, {"var": "TEST"},)}}, {}) == set()

    invalid_spec = {"test": {"type": "str", "fallback": ()}}

# Generated at 2022-06-11 01:22:36.246018
# Unit test for function env_fallback
def test_env_fallback():
    """Test that env_fallback can return a value"""
    os.environ['mytest'] = 'testvalue'
    assert env_fallback('mytest') == 'testvalue'



# Generated at 2022-06-11 01:22:47.544377
# Unit test for function env_fallback
def test_env_fallback():
    try:
        os.environ['FOO'] = 'bar'
        assert env_fallback('FOO') == 'bar'
    except BaseException: 
        pass  # this is an error condition as well
    finally:
        os.environ.pop('FOO')
    os.environ['ANSIBLE_TEST_FOO'] = 'foo'
    assert env_fallback('ANSIBLE_TEST_FOO') == 'foo'
    os.environ.pop('ANSIBLE_TEST_FOO')
    assert env_fallback('ANSIBLE_TEST_BAR') == 'ANSIBLE_TEST_BAR'
    try:
        env_fallback('ANSIBLE_TEST_BAR', 'ANSIBLE_TEST_PING')
    except AnsibleFallbackNotFound:
        pass
   

# Generated at 2022-06-11 01:22:58.594319
# Unit test for function set_fallbacks
def test_set_fallbacks():
    """Test function `set_fallbacks`"""

# Generated at 2022-06-11 01:23:01.925510
# Unit test for function remove_values
def test_remove_values():
    input_data = {'a': 'a', 'b': 'b'}
    output_data = remove_values(input_data, ['c'])
    assert input_data == output_data


# Generated at 2022-06-11 01:23:27.703308
# Unit test for function remove_values
def test_remove_values():
    assert remove_values('my password', ['password']) == 'my *****'
    assert remove_values('my private key', ['private']) == 'my ****** key'
    assert remove_values('my private key', ['private key']) == 'my *******'
    assert remove_values('my private key', ['private', 'key']) == 'my *******'
    assert remove_values('my private key is foo', ['private', 'key']) == 'my ****** is foo'
    assert remove_values('my private key', ['private key', 'foo']) == 'my *******'
    assert remove_values('my password is foo', ['password', 'foo', '@']) == 'my ***** is *****'

    # Test against issue #24560, maximum recursion depth

# Generated at 2022-06-11 01:23:33.891467
# Unit test for function env_fallback
def test_env_fallback():
    assert_raises(AnsibleFallbackNotFound, env_fallback, 'foo')
    os.environ['foo'] = 'bar'
    assert env_fallback('foo') == 'bar'
    os.environ['Foo'] = 'BAR'
    assert env_fallback('foo') == 'BAR'
    del(os.environ['Foo'])
    assert env_fallback('foo') == 'bar'
    del(os.environ['foo'])
    assert_raises(AnsibleFallbackNotFound, env_fallback, 'foo', 'bar')
    assert_raises(AnsibleFallbackNotFound, env_fallback, 'foo', 'bar')
    os.environ['foo'] = 'bar'
    os.environ['bar'] = 'foo'

# Generated at 2022-06-11 01:23:36.527172
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ENVIRONMENT_VAR'] = 'ENVIRONMENT_VALUE'
    assert env_fallback('ENVIRONMENT_VAR') == 'ENVIRONMENT_VALUE'



# Generated at 2022-06-11 01:23:47.871743
# Unit test for function remove_values
def test_remove_values():
    from ansible.module_utils._text import to_bytes
    assert remove_values('password', ['password']) == 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'
    assert remove_values('no_log', ['password']) == 'no_log'
    assert remove_values(b'password', ['password']) == b'password'
    assert remove_values(['a', 'password'], ['password']) == ['a', 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER']
    assert remove_values(('a', 'password'), ['password']) == ('a', 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER')

# Generated at 2022-06-11 01:23:58.216109
# Unit test for function set_fallbacks
def test_set_fallbacks():
    from ansible.module_utils._text import to_text
    import os

    assert set_fallbacks({}, {}) == set()

    assert set_fallbacks({'a': {'type': 'str'}}, {}) == set()

    varname = 'WHAT_A_NICE_ENV_VARIABLE'
    # make sure the varname is not set
    if varname in os.environ:
        del os.environ[varname]

    assert set_fallbacks({'a': {'type': 'str', 'fallback': (env_fallback, varname)}}, {}) == set()

    # re-run same test, but with env var set
    os.environ[varname] = 'Hello, World!'

# Generated at 2022-06-11 01:24:03.962388
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_FOO'] = 'ANSIBLE_FOO'
    assert 'ANSIBLE_FOO' == env_fallback('ANSIBLE_FOO')
    assert os.environ['ANSIBLE_FOO'] == env_fallback('ANSIBLE_FOO')
    assert os.environ['ANSIBLE_FOO'] == env_fallback('FOO', 'BAR')
    assert os.environ['ANSIBLE_FOO'] == env_fallback('FOO', 'BAR', 'ANSIBLE_FOO')
    assert 'ANSIBLE_FOO' == env_fallback('ANSIBLE_FOO', 'BAR')
    try:
        env_fallback('FOO', 'BAR')
    except AnsibleFallbackNotFound:
        pass


# Generated at 2022-06-11 01:24:11.486254
# Unit test for function set_fallbacks
def test_set_fallbacks():
    parameters = dict()
    argument_spec = dict()
    fallback = (env_fallback, ['ANSIBLE_MODULE_TEST_VALUE'])
    argument_spec['test_value'] = dict(fallback=fallback)
    os.environ['ANSIBLE_MODULE_TEST_VALUE'] = 'TEST_VALUE'
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters.get('test_value') == 'TEST_VALUE'
    assert no_log_values == set()

    argument_spec['test_value2'] = dict(fallback=fallback, no_log=True)
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert no_log_values == {'TEST_VALUE'}
    # Cleanup
    os

# Generated at 2022-06-11 01:24:23.871521
# Unit test for function set_fallbacks
def test_set_fallbacks():
    parameters = {'test1': 1, 'test2': 2}
    data = {'test1': {'type': 'int'},
            'test2': {'type': 'int',
                      'fallback': (env_fallback, 'TEST_VAR'),
                      'no_log': True},
            'test3': {'type': 'int',
                      'fallback': (env_fallback, 'TEST_VAR2', 'TEST_VAR3'),
                      'no_log': True}}
    no_log_values = set_fallbacks(data, parameters)
    assert no_log_values == set()
    assert 'test2' in parameters
    assert parameters['test2'] == 2
    assert parameters['test3'] is None

    os.environ['TEST_VAR3'] = '3'

# Generated at 2022-06-11 01:24:31.389445
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        login=dict(type='str', fallback=(env_fallback, ['USER'])),
    )

    for ds in [
        dict(login='johnd'),
        dict(),
        dict(login=None),
    ]:
        no_log_values = set_fallbacks(argument_spec, ds)
        assert ds['login'] == os.getenv('USER')
        assert no_log_values == set()



# Generated at 2022-06-11 01:24:42.777853
# Unit test for function set_fallbacks

# Generated at 2022-06-11 01:25:11.516988
# Unit test for function set_fallbacks
def test_set_fallbacks():
    os.environ['MY_ENV_VAR'] = 'my env value'

# Generated at 2022-06-11 01:25:22.845650
# Unit test for function set_fallbacks

# Generated at 2022-06-11 01:25:32.231130
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert set_fallbacks({'option': {'type': 'dict', 'fallback': (get_config_value, 'config_key')}}, {'option': {'test': 1}}) == set()
    assert set_fallbacks({'option': {'type': 'dict', 'fallback': (get_config_value, 'config_key')}}, {}) == set()
    assert set_fallbacks({'option': {'type': 'dict', 'fallback': (env_fallback, 'env_key')}}, {}) == set()
    assert set_fallbacks({'option': {'type': 'dict', 'fallback': (env_fallback, 'env_key', {'no_log': True})}}, {}) == {'test'}

# Generated at 2022-06-11 01:25:42.173787
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert set_fallbacks({}, {}) == set()
    assert set_fallbacks({'a': {'type': 'bool'}}, {}) == set()
    assert set_fallbacks({'a': {'type': 'bool', 'fallback': (bool, 'false')}}, {}) == set()
    assert set_fallbacks({'a': {'type': 'bool', 'fallback': (bool, 'true')}}, {}) == set('true')
    assert set_fallbacks({'a': {'type': 'bool', 'fallback': (str, 'false')}}, {}) == set()
    assert set_fallbacks({'a': {'type': 'int', 'fallback': (int, '13')}}, {}) == set('13')

# Generated at 2022-06-11 01:25:52.385670
# Unit test for function sanitize_keys
def test_sanitize_keys():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.clean import module_response_deepcopy
    import copy
    import json

    # func_name, host, task_vars, merge_hash, no_log, no_log_strings, ignore_keys, expected_result, expected_no_log, expected_ignore_keys

# Generated at 2022-06-11 01:25:56.786859
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['test_env_fallback'] = 'testing'
    res = env_fallback('test_env_fallback')
    assert(res == 'testing')
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('ThisEnvVarShouldNotExist')


# Generated at 2022-06-11 01:26:07.217201
# Unit test for function set_fallbacks
def test_set_fallbacks():
    from ansible.module_utils.common.validation import Fallback

    fallback1 = Fallback((env_fallback, "MY_ENV"))
    fallback2 = Fallback((env_fallback, "MY_HTTP_PROXY", "MY_HTTP_PROXY_CHAIN"))
    fallback3 = Fallback((env_fallback, "MY_ENV_URL"))


# Generated at 2022-06-11 01:26:17.609706
# Unit test for function set_fallbacks
def test_set_fallbacks():
    """Test set_fallbacks"""

    # Set up some mock options
    argument_spec = dict(foo=dict(fallback=(env_fallback, 'foo_env')),
                         bar=dict(fallback=(env_fallback, 'bar_env')),
                         baz=dict(fallback=(env_fallback, 'baz_env')),
                         fiz=dict(fallback=(env_fallback, 'fiz_env')),
                         foz=dict(fallback=(env_fallback, 'foz_env')),
                         biz=dict(fallback=(env_fallback, 'biz_env'), no_log=True),
                         )
    test_options = dict(foo=1, bar=2)

    os.environ['foo_env'] = 'bar'

    # Make sure no_log is actually returned

# Generated at 2022-06-11 01:26:26.173936
# Unit test for function set_fallbacks
def test_set_fallbacks():
    parameters = {'name': 'Ansible', 'mylist': [1, 2, 3]}
    argument_spec = dict(
        name=dict(default='YAML', fallback=(env_fallback, 'MY_NAME')),
        mylist=dict(default=[1, 2, 3, 4], fallback=(env_fallback, 'MY_LIST')),
        port=dict(default=8080, fallback=(env_fallback, 'MY_PORT')),
        timeout=dict(default=10, fallback=(env_fallback, 'MY_TIMEOUT')),
    )
    # Make sure we can find the fallback
    os.environ['MY_NAME'] = 'Python'
    os.environ['MY_LIST'] = '[1, 2, 3, 4, 5, 6]'

# Generated at 2022-06-11 01:26:35.949575
# Unit test for function sanitize_keys
def test_sanitize_keys():
    output = sanitize_keys({'a': 1, 'a_long_string': ('b', 'c'), 'c': {'d': 'e'}, 'd': [{'f': 'g'}, {'h': 'i'}, {'j': 'k'}]}, {'b'})
    assert output == {'a_long_string': ('_Ansibullbot_b', 'c'), 'c': {'d': 'e'}, 'd': [{'f': 'g'}, {'h': 'i'}, {'j': 'k'}], 'a': 1}

# Generated at 2022-06-11 01:27:07.951604
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Test with a parameter that has fallback set
    argument_spec = dict(myarg=dict(fallback=(env_fallback, "MY_ENV")))
    parameters = {}
    os.environ["MY_ENV"] = "value1"
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters["myarg"] == "value1"

    # Test with fallback to an attribute on a parameter
    argument_spec = dict(myarg=dict(fallback=(env_fallback, "MY_ENV")),
                         nextarg=dict(fallback=(env_fallback, "MY_NEXT_ENV")),
                         next2arg=dict(fallback=dict(func=getattr, args=["myarg", "upper"])))

# Generated at 2022-06-11 01:27:18.076418
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(foo=dict(fallback=(env_fallback, 'FOO')),
                         bar=dict(default=dict(baz=False)),
                         baz=dict(fallback=(env_fallback, 'BAZ')),
                         qux=dict(default=None))
    parameters = dict(bar=dict(baz=True))
    no_log_values = set_fallbacks(argument_spec, parameters)

    assert parameters['foo'] == os.environ['FOO']
    assert parameters['bar'] == dict(baz=True)
    assert parameters['baz'] == os.environ['BAZ']
    assert parameters['qux'] is None
    assert os.environ['BAZ'] in no_log_values



# Generated at 2022-06-11 01:27:19.509741
# Unit test for function env_fallback
def test_env_fallback():
    """Load value from environment variable"""
    pass

# Generated at 2022-06-11 01:27:24.558170
# Unit test for function env_fallback
def test_env_fallback():
    """Unit test for function env_fallback"""
    os.environ['VAR1'] = 'value1'
    assert env_fallback('VAR1') == 'value1'
    os.environ['VAR2'] = 'value2'
    assert env_fallback('VAR1', 'VAR2') == 'value1'

    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('VAR3')


# Generated at 2022-06-11 01:27:31.165098
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'a': dict(fallback=(env_fallback, 'B')),
        'b': dict(fallback=(env_fallback, 'B')),
    }
    parameters = {'a': 1}
    os.environ['B'] = "2"
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['b'] == "2"
    assert no_log_values == set()



# Generated at 2022-06-11 01:27:40.297934
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # test empty argument_spec
    assert set_fallbacks({}, {}) == set()

    # test no fallback
    assert set_fallbacks({'test': {'type': 'str'}}, {}) == set()
    assert set_fallbacks({'test': {'type': 'str'}}, {'test': 'abc'}) == set()

    # test fallback
    assert set_fallbacks({'test': {'type': 'str', 'fallback': (lambda: 'default',)}}, {}) == set()
    assert set_fallbacks({'test': {'type': 'str', 'fallback': (lambda: 'default',)}}, {'test': 'abc'}) == set()

    # test no_log
    parameters = {}

# Generated at 2022-06-11 01:27:48.661529
# Unit test for function sanitize_keys
def test_sanitize_keys():
    #Common Setup
    no_log_strings = {'u1', 'u2', 'u3'}

    #Common Teardown

    #Test Cases

    #Test: Sanitize a string with no_log keys
    #Expected result: String with no_log values removed
    assert sanitize_keys('u1u2', no_log_strings) == 'u1u2'

    #Test: Sanitize a string with no_log keys
    #Expected result: String with no_log values removed
    assert sanitize_keys('u1u2u3', no_log_strings) == ''

    #Test: Sanitize a string with no_log keys, ignore_keys set
    #Expected result: String with no_log values removed

# Generated at 2022-06-11 01:27:59.662852
# Unit test for function env_fallback
def test_env_fallback():
    '''
    Ensure that env_fallback works as expected
    '''

    try:
        env_fallback('PWD', 'HOME')
    except AnsibleFallbackNotFound:
        assert True, "env_fallback raised AnsibleFallbackNotFound because neither PWD or HOME are set"

    # Set HOME to a known value, then clear it
    home_var = 'HOME'
    old_home = os.environ.get(home_var, None)
    os.environ[home_var] = "/fake/home"
    try:
        tmp = env_fallback('PWD', 'HOME')
        assert tmp == os.environ['HOME'], "env_fallback did not return the correct value"
    finally:
        del os.environ[home_var]
        if old_home:
            os

# Generated at 2022-06-11 01:28:07.101185
# Unit test for function env_fallback
def test_env_fallback():
    """Unit tests for AnsibleModule.env_fallback"""
    os.environ['ANSIBLE_FOO_BAR'] = 'pong'
    assert env_fallback('ANSIBLE_FOO_BAR') == 'pong'
    assert env_fallback('non_existent', 'ANSIBLE_FOO_BAR') == 'pong'
    assert env_fallback('non_existent_1', 'non_existent_2') == None
    return



# Generated at 2022-06-11 01:28:15.209881
# Unit test for function set_fallbacks
def test_set_fallbacks():
    params = {'a': '5', 'c': '5'}
    spec = dict(
        a=dict(required=True, type='str'),
        b=dict(required=True, type='str', fallback=(env_fallback, 'TEST_VAR')),
        c=dict(required=True, type='str', fallback=(env_fallback, 'TEST_VAR'))
    )
    os.environ['TEST_VAR'] = 'foo'
    no_values = set_fallbacks(spec, params)
    assert sorted(params) == ['a', 'b', 'c']
    assert params['b'] == 'foo'
    assert params['c'] == '5'
    assert 'foo' in no_values
    del os.environ['TEST_VAR']



# Generated at 2022-06-11 01:28:44.006476
# Unit test for function sanitize_keys
def test_sanitize_keys():
    no_log_strings = [u'password']
    res = sanitize_keys({u'password': u'secret', u'_ansible_foo': u'bar', u'_ansible_bar': u"value", u'_ansible_no_log': False}, no_log_strings)
    assert res == {u'XXXXXX': u'secret', u'_ansible_foo': u'bar', u'_ansible_bar': u'value'}, res



# Generated at 2022-06-11 01:28:47.367559
# Unit test for function env_fallback
def test_env_fallback():
    assert 'PATH' in os.environ
    assert env_fallback('PATH') == os.environ['PATH']
    with pytest.raises(AnsibleFallbackNotFound):
        assert env_fallback('FOOBAR')



# Generated at 2022-06-11 01:28:57.261796
# Unit test for function sanitize_keys
def test_sanitize_keys():
    """
    This test will make sure that the sanitize_keys function works correctly.
    """
    assert sanitize_keys("Some Value", ["Value"]) == "Some Value"
    assert sanitize_keys({
        "This is a test": "This a test",
        "This value is private": "This value is private",
        "This value is also private": "Password",
        "DONT_CONVERT_THIS_KEY": "DONT_CONVERT_THIS_VALUE"
    }, ["private", "value", "test", "this", "is"]) == {"This a test": "This a test", "REDACTED": "REDACTED", "REDACTED": "Password", "DONT_CONVERT_THIS_KEY": "DONT_CONVERT_THIS_VALUE"}



# Generated at 2022-06-11 01:29:00.880672
# Unit test for function env_fallback
def test_env_fallback():
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('no_such_var')
    with patch.dict(os.environ, {'COWSAY': 'moo'}):
        assert env_fallback('COWSAY') == 'moo'



# Generated at 2022-06-11 01:29:07.207515
# Unit test for function set_fallbacks
def test_set_fallbacks():
    """Test function set_fallbacks"""
    argument_spec = dict(
        state=dict(required=False, choices=['present', 'absent'], type='str', fallback=(env_fallback, 'OS_STATE')),
        ssh_keypair_name=dict(required=False, type='str', fallback=(env_fallback, 'OS_SSH_KEYPAIR_NAME')),
        security_group=dict(required=False, type='str', fallback=(env_fallback, 'OS_SECURITY_GROUP')),
    )
    parameters = {}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert len(parameters) == 2
    assert 'state' in parameters
    assert parameters['state'] == 'present'
    assert 'ssh_keypair_name' in parameters


# Generated at 2022-06-11 01:29:11.859275
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        first=dict(type='str', fallback=(env_fallback, ['FIRST', 'SECOND'])),
        second=dict(type='str', fallback=(env_fallback, 'SECOND')),
        third=dict(type='str', fallback=(env_fallback, ['FIRST', 'SECOND'], dict(fallback_value='third'))),
        fourth=dict(type='str', fallback=(env_fallback, 'SECOND'), no_log=True),
        fifth=dict(type='str', fallback=(env_fallback, ['FIRST', 'SECOND'], dict(fallback_value='fifth')), no_log=True),
    )

    parameters = {}

    no_log_values = set_fallbacks(argument_spec, parameters)
