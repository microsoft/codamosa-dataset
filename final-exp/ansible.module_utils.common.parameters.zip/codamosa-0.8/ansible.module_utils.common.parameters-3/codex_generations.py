

# Generated at 2022-06-11 01:20:19.713076
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert set_fallbacks({'a': {'fallback': (env_fallback, 'a_envvar')}}, {}) == {}
    assert set_fallbacks({'b': {'fallback': (env_fallback, 'b_envvar')}}, {}) == set()
    os.environ['a_envvar'] = 'a_envvar_value'
    assert set_fallbacks({'a': {'fallback': (env_fallback, 'a_envvar')}}, {}) == {'a_envvar_value'}
    os.environ['b_envvar'] = 'b_envvar_value'
    assert set_fallbacks({'b': {'fallback': (env_fallback, 'b_envvar')}}, {}) == {'b_envvar_value'}



# Generated at 2022-06-11 01:20:31.084728
# Unit test for function set_fallbacks
def test_set_fallbacks():
    spec1 = dict(
        anint=dict(type='int', fallback=(env_fallback, 'INT')),
        adict=dict(type='dict', fallback=(env_fallback, 'DICT', {'key': 'value'})),
        abool=dict(type='bool', fallback=(True)),
    )
    args = dict(
        adict=dict(key='value'),
    )

    # Test setup
    os.environ['INT'] = '10'
    os.environ['DICT'] = '{"key": "value"}'
    assert args == set_fallbacks(spec1, args)

    # Test fallback does not overwrite existing value
    del os.environ['INT']
    assert args == set_fallbacks(spec1, args)

    # Test fallback does not overwrite existing value

# Generated at 2022-06-11 01:20:42.607066
# Unit test for function sanitize_keys

# Generated at 2022-06-11 01:20:52.628058
# Unit test for function set_fallbacks

# Generated at 2022-06-11 01:21:04.075371
# Unit test for function set_fallbacks

# Generated at 2022-06-11 01:21:08.282314
# Unit test for function remove_values

# Generated at 2022-06-11 01:21:19.126885
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert (set_fallbacks({
        'param': {
            'type': 'str',
            'fallback': (env_fallback, ['NOT_ENV_VAR'])
        }
    }, {}) == set())

    assert (set_fallbacks({
        'param': {
            'type': 'str',
            'fallback': (env_fallback, ['NOT_ENV_VAR']),
            'no_log': True
        }
    }, {}) == set())

    os.environ['ENV_VAR'] = 'foobar'
    assert (set_fallbacks({
        'param': {
            'type': 'str',
            'fallback': (env_fallback, ['ENV_VAR'])
        }
    }, {}) == set())


# Generated at 2022-06-11 01:21:27.606119
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys('unmatched', ['matched']) == 'unmatched'
    assert sanitize_keys('matched', ['matched']) == '<Sanitized>'
    assert len(sanitize_keys(('matched',), ['matched'])) == 1
    assert sanitize_keys(('matched',), ['matched'])[0] == '<Sanitized>'
    assert len(sanitize_keys(['matched'], ['matched'])) == 1
    assert sanitize_keys(['matched'], ['matched'])[0] == '<Sanitized>'
    assert len(sanitize_keys(['multiple', 'matched'], ['matched'])) == 1
    assert sanitize_keys(['multiple', 'matched'], ['matched'])[0] == '<Sanitized>'

# Generated at 2022-06-11 01:21:37.179727
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert set_fallbacks({}, {}) == set()
    assert set_fallbacks({'test_no_fallback': {}}, {}) == set()
    assert set_fallbacks({'test_args': {'fallback': (lambda x: x, 1)}}, {}) == set()
    assert set_fallbacks({'test_args': {'fallback': (lambda x, y: x + y, 1, 2)}}, {}) == set()
    assert set_fallbacks({'test_kwargs': {'fallback': (lambda: 'foo', {})}}, {}) == set()
    assert set_fallbacks({'test_kwargs': {'fallback': (lambda: 'foo', dict(bar='baz'))}}, {}) == set()

# Generated at 2022-06-11 01:21:48.106711
# Unit test for function remove_values
def test_remove_values():
    import copy
    import json

    # test string:
    s = "test data: no_log_strings"
    assert "data:" not in remove_values(s, ('no_log_strings', 'data:'))

    # test list:
    l = [ "test data: no_log_strings", "test list: no_log_strings" ]
    assert l != remove_values(l, ('no_log_strings', 'data:'))

    # test dict:
    d = {'a': 'no_log_strings'}
    assert d != remove_values(d, ('no_log_strings',))

    # test nested containers
    nd = {'a': {'b': 'no_log_strings'}}
    assert nd != remove_values(nd, ('no_log_strings',))

    # test list

# Generated at 2022-06-11 01:22:23.547926
# Unit test for function set_fallbacks

# Generated at 2022-06-11 01:22:26.503305
# Unit test for function remove_values
def test_remove_values():
    '''
    Basic test to ensure that remove_values does not modify anything if no_log_values is empty
    '''
    result = remove_values('boo', [])
    assert result == 'boo'



# Generated at 2022-06-11 01:22:31.886318
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        test1=dict(fallback=(env_fallback, 'TEST1'))
    )
    parameters = {}
    os.environ['TEST1'] = 'test1_env'
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert len(no_log_values) == 0
    assert parameters['test1'] == os.environ['TEST1']
    assert parameters['test1'] == 'test1_env'



# Generated at 2022-06-11 01:22:42.968726
# Unit test for function env_fallback
def test_env_fallback():
    """Test environment variables fallback mechanism."""
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule()
    spec = {'my_var': {'type': 'str', 'fallback': (env_fallback, ['ANSIBLE_MY_VAR'])}}
    raw_params = {}
    params = set_fallbacks(spec, raw_params, module)

    assert isinstance(params, MutableMapping)
    assert 'my_var' in params
    os.environ['ANSIBLE_MY_VAR'] = 'ANSIBLE_MY_VAR'
    params = set_fallbacks(spec, raw_params, module)

# Generated at 2022-06-11 01:22:51.998518
# Unit test for function sanitize_keys
def test_sanitize_keys():
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.six.moves import StringIO

    assert sanitize_keys({'test_key': 'test_value'}, ['value']) == {'test_key': 'test_value'}
    assert sanitize_keys({'test_value': 'test_value'}, ['value']) == {'test_': 'test_value'}
    assert sanitize_keys({'test_value': 'test_value'}, ['value'], ignore_keys=frozenset(['test_value'])) == {'test_value': 'test_value'}

    assert sanitize_keys({'test_key': 'test'}, ['test']) == {'test_': ''}

# Generated at 2022-06-11 01:23:00.388490
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        foo=dict(type='str', fallback=(env_fallback, 'FOO')),
        bar=dict(type='str', fallback=(unsupported_fallback, 'bar')),
        baz=dict(type='str', fallback=(env_fallback, 'BAZ')),
    )
    parameters = {}

    set_fallbacks(argument_spec, parameters)

    assert parameters['foo'] == 'bar'
    assert 'bar' not in parameters
    assert 'baz' not in parameters



# Generated at 2022-06-11 01:23:09.935573
# Unit test for function set_fallbacks
def test_set_fallbacks():
    args = dict(
        param1=dict(fallback=(env_fallback, 'PARAM1', 'THISISTHEFALLBACK')),
        param2=dict(fallback=(env_fallback, 'PARAM2')),
        param3=dict(fallback=(env_fallback, 'PARAM3', dict(key='val'))),
    )
    os.environ['PARAM1'] = 'THISISAENVVAR'
    os.environ['PARAM2'] = 'THISISAENVVAR'
    os.environ['PARAM3'] = 'THISISAENVVAR'
    params = dict()

    no_log_values = set_fallbacks(args, params)
    assert len(no_log_values) == 0
    assert params['param1'] == 'THISISAENVVAR'

# Generated at 2022-06-11 01:23:19.111350
# Unit test for function sanitize_keys
def test_sanitize_keys():
    class MyStruct(object):
        def __init__(self, value):
            self.my_value = value

    class TestSanitizeKeys(unittest.TestCase):
        """Unit Test the module function _remove_values"""

        def _deep_copy(self, orig):
            new = copy.deepcopy(orig)
            self.assertEqual(orig, new)
            return new

        def test_sanitize_keys_dict_string(self):
            test_dict = {'param1': 'value1', 'param2': 'value2'}
            no_log_strings = ['param1']
            expected_dict = {'param1': 'value1', 'param2': 'value2'}

# Generated at 2022-06-11 01:23:25.326378
# Unit test for function set_fallbacks

# Generated at 2022-06-11 01:23:31.408923
# Unit test for function set_fallbacks

# Generated at 2022-06-11 01:24:27.294623
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'user': {'type': 'str', 'default': 'name', 'fallback': (env_fallback,'env','USER')},
                     'password': {'type': 'str', 'default': 'name', 'fallback': (env_fallback,'env','PASSWORD')},
                     'port': {'type': 'int', 'default': '22', 'fallback': (env_fallback,'env','PORT')}}
    parameters = {'host': 'example.com'}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert len(no_log_values) == 0
    os.environ['USER'] = 'ansible'
    os.environ['PASSWORD'] = 'password'
    os.environ['PORT'] = '22'
    no_log_

# Generated at 2022-06-11 01:24:32.248364
# Unit test for function env_fallback
def test_env_fallback():
    # test with environment variable passed in
    os.environ['FOO'] = 'bar'
    assert env_fallback('FOO') == 'bar'

    # test without environment variable passed in
    assert env_fallback('FOO2') == ''



# Generated at 2022-06-11 01:24:34.664752
# Unit test for function env_fallback
def test_env_fallback():
    if isinstance(env_fallback(), BinaryIO):
        assert True
    else:
        assert False
test_env_fallback()


# Generated at 2022-06-11 01:24:43.293412
# Unit test for function env_fallback
def test_env_fallback():
    '''
    Test for proper handling of environment variables
    '''

    arg = 'TEST_VAR'
    os.environ[arg] = 'test'
    value = env_fallback(arg)
    assert value == 'test'

    del os.environ[arg]
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback(arg)

    arg2 = 'TEST_VAR2'
    os.environ[arg2] = 'test2'
    value = env_fallback(arg, arg2)
    assert value == 'test2'



# Generated at 2022-06-11 01:24:53.670989
# Unit test for function set_fallbacks
def test_set_fallbacks():
    module_utils.basic._ANSIBLE_ARGS = None
    argument_spec = {'env': dict(type='str', fallback=(env_fallback, ['ANSIBLE_NET_USERNAME'])),
                     'no_log_env': dict(type='str', no_log=True, fallback=(env_fallback, ['ANSIBLE_NET_PASSWORD'])),
                     'no_log_string': dict(type='str', no_log=True, fallback='this is a password'),
                     'dict': dict(type='dict', fallback={'a': 'a', 'b': 1}),
                     'dict_with_env': dict(type='dict', fallback={'a': env_fallback, 'b': 1, 'c': 'c'}, fallback_name='fallback_func')}

    parameters = {}

# Generated at 2022-06-11 01:24:56.432123
# Unit test for function env_fallback
def test_env_fallback():
    with mock.patch.object(os.environ, 'get', return_value='foo'):
        assert env_fallback('this', 'that') == 'foo'



# Generated at 2022-06-11 01:25:03.959384
# Unit test for function env_fallback
def test_env_fallback():
    from ansible.module_utils.common._collections_compat import DeepHashable
    assert os.environ.get("PATH") == env_fallback("PATH")
    assert DeepHashable(os.environ.get("PATH"))
    assert os.environ.get("PATH") not in env_fallback("HOME")
    assert isinstance(env_fallback("PATH"), string_types)
    assert not isinstance(env_fallback("HOME"), string_types)  # Path not found


# Generated at 2022-06-11 01:25:13.372187
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # If a parameter is not in the parameters dict but is in argument spec, it needs a default value from the spec
    spec = dict(foo=dict(default=1), bar=dict(default='baz'), pfui=dict(default=2, type='bool'))
    parameters = dict()
    no_log_values = set_fallbacks(spec, parameters)
    assert parameters['foo'] == 1
    assert parameters['bar'] == 'baz'
    assert no_log_values == set()
    assert not parameters['pfui']

    # If a parameter is not in the parameters dict but is in argument spec and has no_log=True, it needs a default value from
    # the spec
    spec = dict(foo=dict(default='foo'), bar=dict(default='baz', no_log=True))
    parameters = dict()

# Generated at 2022-06-11 01:25:19.354744
# Unit test for function set_fallbacks
def test_set_fallbacks():
    parameters = {}
    argument_spec = {'one': {'type': 'str', 'fallback': (env_fallback, ['TEST_ONE'])}}
    os.environ['TEST_ONE'] = 'one'
    assert ({'one'},) == set_fallbacks(argument_spec, parameters)
    assert {'one'} == parameters


# Generated at 2022-06-11 01:25:30.147613
# Unit test for function remove_values
def test_remove_values():

    def assert_equal_after_strip(a, b):
        assert remove_values(a, ['vault:']) == b


# Generated at 2022-06-11 01:26:01.041258
# Unit test for function remove_values
def test_remove_values():
    '''
    Test remove_values()
    '''
    from ansible.module_utils.basic import AnsibleModule


    def test_module_assertion(description, assertions):
        """Run a test of a module assertion, returning a list of results."""

        results = []

        tests = {}
        tests[description] = assertions[:]
        test_args = dict(
            test=tests,
            msg='',
            error=False,
            diff=True,
            )

        result = AnsibleModule._exec_module(
            'test',
            module_args=test_args,
            )

        results.append(result)
        return results


    # Boolean true, no assertion
    data = {'a': 'foo', 'b': 'bar'}

# Generated at 2022-06-11 01:26:11.709994
# Unit test for function set_fallbacks
def test_set_fallbacks():

    argument_spec = {
        'param1': {
            'type': 'str',
            'fallback': (env_fallback, ('ANSIBLE_PARAM1', 'ANSIBLE_PARAM2'))
        },
        'param2': {
            'type': 'str',
            'fallback': (env_fallback, 'ANSIBLE_PARAM3')
        },
        'param3': {
            'type': 'str',
            'fallback': (env_fallback, 'ANSIBLE_PARAM4')
        }
    }

    parameters = {
        'param1': 'not_from_env',
        'param2': 'not_from_env',
        'param3': 'not_from_env'
    }


# Generated at 2022-06-11 01:26:20.803825
# Unit test for function sanitize_keys
def test_sanitize_keys():

    # Temporarily set the sanitization flag to False to assure that
    # sanitization is being done outside of the C module.
    # Otherwise, the C module will determine that the sanitization
    # flag is True and will short-circuit the sanitization process.
    #
    # This technique also works for the remove_values and remove_internal_keys
    # functions.
    old_sanitize_value = default.SANITIZE_KEYS
    default.SANITIZE_KEYS = False

    # Create object with some keys containing sanitized values
    ignore_keys = ['foo', 'b', 'baz']
    no_log_strings = ['x', 'y']

# Generated at 2022-06-11 01:26:25.770989
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        p1=dict(fallback=(env_fallback, 'P1')),
        p2=dict(fallback=(env_fallback, 'P2')),
        p3=dict(fallback=(env_fallback, dict(vars=['P3', 'P3_DEFAULT']), 'default_value')),
        p4=dict(fallback=(env_fallback, dict(vars=['P4', 'P4_DEFAULT']), 'default_value')),
        p5=dict(fallback=(env_fallback, 'P5'), type='str'),
        p6=dict(fallback=(env_fallback, 'P6')),
    )
    parameters = dict(p5='module_value')

# Generated at 2022-06-11 01:26:35.689805
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'param': {
            'type': 'str',
            'fallback': (env_fallback, ('ANSIBLE_TEST_ENV_VAR',)),
            'no_log': True,
        }
    }

    parameters = {}
    os.environ['ANSIBLE_TEST_ENV_VAR'] = 'hello'
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters == {'param': 'hello'}
    assert no_log_values == {'hello'}
    del os.environ['ANSIBLE_TEST_ENV_VAR']

    # Ensure the fallback has precedence over a default value
    argument_spec['param']['default'] = 'world'
    parameters = {}

# Generated at 2022-06-11 01:26:38.310858
# Unit test for function env_fallback
def test_env_fallback():
    # env_fallback is used in some module_utils so we should test it there instead
    # this test is just to make sure it's registered
    assert env_fallback in FALLBACK_HANDLERS



# Generated at 2022-06-11 01:26:49.397091
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'foo': dict(fallback=(env_fallback, 'TEST_FOO')),
        'bar': dict(fallback=(env_fallback, 'TEST_BAR')),
        'baz': dict(fallback=(env_fallback, 'TEST_BAZ')),
        'boo': dict(fallback=(env_fallback, 'TEST_BOO')),
    }
    parameters = dict()
    set_fallbacks(argument_spec=argument_spec, parameters=parameters)
    assert not parameters, "No env variables set"

    parameters = dict()
    os.environ['TEST_FOO'] = 'env_foo'
    set_fallbacks(argument_spec=argument_spec, parameters=parameters)
    assert 'foo' in parameters and parameters['foo']

# Generated at 2022-06-11 01:26:56.995039
# Unit test for function set_fallbacks
def test_set_fallbacks():
    test_spec = {
        'first': {
            'required': True,
            'type': 'str',
        },
        'second': {
            'required': True,
            'type': 'str',
            'fallback': ('env_fallback', 'SECOND'),
        },
        'third': {
            'required': True,
            'type': 'str',
            'fallback': ('env_fallback', {'key': 'FOO'}),
        },
        'fourth': {
            'required': True,
            'type': 'str',
            'fallback': ('env_fallback', ['FOURTH'], {'key': 'BAR'}),
        },
    }
    os.environ['SECOND'] = 'SECOND'

# Generated at 2022-06-11 01:27:06.748595
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(a=dict(fallback=(env_fallback, 'FOO',)), b=dict(fallback=(env_fallback, 'BAR', {'default': 'my_default'})),
                         c=dict(fallback=(env_fallback, 'BAZ', {'default': 'foo_bar'}), no_log=True))
    parameters = dict()
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['a'] == 'foo'
    assert parameters['b'] == 'bar'
    assert parameters['c'] == 'foo_bar'
    assert no_log_values == set()



# Generated at 2022-06-11 01:27:17.567370
# Unit test for function sanitize_keys
def test_sanitize_keys():
    test_string = 'password=password'
    test_dict = {
        'user': 'ansible',
        'password': 'password',
        'private_ssh_key': '-----BEGIN RSA PRIVATE KEY-----'
    }
    test_list = [
        {
            'user': 'ansible',
            'password': 'password',
            'private_ssh_key': '-----BEGIN RSA PRIVATE KEY-----'
        },
        {
            'user': 'ansible',
            'password': 'password',
            'private_ssh_key': '-----BEGIN RSA PRIVATE KEY-----'
        }
    ]

# Generated at 2022-06-11 01:27:42.208556
# Unit test for function env_fallback
def test_env_fallback():
    """Unit test for env_fallback"""

    assert env_fallback('NO_ENV') == 'NO_ENV', 'Unable to load from environment'


# Fallback functions that are allowed to be used
_FALLBACKS = {
    'env_fallback': env_fallback,
}



# Generated at 2022-06-11 01:27:49.425312
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(foo=dict(type='bool'), bar=dict(type='bool', fallback=(env_fallback, 'ANSIBLE_FOO_BAR')),
                         baz=dict(type='bool', fallback=(env_fallback, 'ANSIBLE_BAZ_BAZ', dict(key='ANSIBLE_BAZ_BAZ'))),
                         qux=dict(type='bool', fallback=(env_fallback, ['ANSIBLE_QUX_QUX', 'ANSIBLE_QUUX_QUUX'])),
                         quux=dict(type='bool', fallback=(env_fallback, 'ANSIBLE_QUUX_QUUX', 'ANSIBLE_QUUZ_QUUZ')),
                         fob=dict(type='bool', fallback=(env_fallback, 'fob')), )
    parameters = dict

# Generated at 2022-06-11 01:28:00.689831
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['test_env_fallback_FOO'] = 'bar'
    assert env_fallback('test_env_fallback_FOO') == 'bar'


# The functions in this module can be used directly, such as check_type.
# They can also be used as part of another API, such as validate.
#
# The functions should be able to operate in either environment, but should
# do their best to provide useful error messages.

# Generated at 2022-06-11 01:28:11.634370
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Test with all valid fallbacks
    argument_spec = {'param1': {'type': 'str', 'fallback': (env_fallback, 'ANSIBLE_PARAM1', 'ANSIBLE_PARAM2')},
                     'param2': {'type': 'str', 'fallback': (env_fallback, ['ANSIBLE_PARAM3'])},
                     'param3': {'type': 'str', 'fallback': (env_fallback, ['ANSIBLE_PARAM4'], {'fallback_value': None})}}
    parameters = {'param1': 'foo', 'param2': 'bar'}
    os.environ['ANSIBLE_PARAM3'] = 'bar'
    os.environ['ANSIBLE_PARAM4'] = 'foobar'

# Generated at 2022-06-11 01:28:20.834850
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(baz=dict(type='int', fallback=(env_fallback, 'WONKY')),
                         foo=dict(type='int', fallback=(env_fallback, 'WONKY')),
                         )
    os.environ['WONKY'] = '3'
    parameters = dict(foo=1)

    benchmarks = []
    for _ in range(10000):
        benchmarks.append(timeit(stmt='set_fallbacks(argument_spec, parameters)', setup='from ansible.module_utils.common.validation import set_fallbacks', number=1))
    print(min(benchmarks))
    assert parameters == dict(foo=1, baz=3)



# Generated at 2022-06-11 01:28:31.870515
# Unit test for function set_fallbacks
def test_set_fallbacks():

    # no_log
    parameters = {"string": "zoo"}
    argument_spec = {
        "string": {"type": "str", "no_log": True},
    }
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert no_log_values == {'zoo'}

    # no_log, but fallback is there
    parameters = {"string": "zoo"}
    argument_spec = {
        "string": {"type": "str", "no_log": True, "fallback": (env_fallback, "zoo")},
    }
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert no_log_values == {'zoo'}

    # no_log, but fallback is there and if not env_fallback, then

# Generated at 2022-06-11 01:28:42.037431
# Unit test for function set_fallbacks

# Generated at 2022-06-11 01:28:45.100761
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['TEST_VAR'] = 'FOO'
    assert env_fallback('TEST_VAR') == 'FOO'
    del os.environ['TEST_VAR']


# Generated at 2022-06-11 01:28:55.493807
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'param1': {'fallback': (env_fallback, ('PARAM1',)), 'type': 'str', 'required': True}
    }
    parameters = {
        'param2': 'value2'
    }
    os.environ['PARAM1'] = 'value1'

    _set_fallbacks(argument_spec, parameters)
    assert parameters['param1'] == 'value1'
    assert parameters['param2'] == 'value2'

    # Invalid fallback should still raise exception
    argument_spec = {
        'param1': {'fallback': (env_fallback, ('INVALID_PARAM',)), 'type': 'str', 'required': True}
    }
    parameters = {}
    with pytest.raises(AnsibleFallbackNotFound):
        _

# Generated at 2022-06-11 01:29:03.701862
# Unit test for function remove_values