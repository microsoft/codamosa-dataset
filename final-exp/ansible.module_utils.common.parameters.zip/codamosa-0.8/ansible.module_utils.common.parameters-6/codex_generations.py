

# Generated at 2022-06-11 01:19:57.602543
# Unit test for function sanitize_keys

# Generated at 2022-06-11 01:20:08.052679
# Unit test for function set_fallbacks
def test_set_fallbacks():
    option_spec = {'test': {'type': 'bool', 'fallback': (env_fallback, 'UNIT_TEST_BOOL')}}
    os.environ['UNIT_TEST_BOOL'] = 'true'
    parameters = {}
    no_log_values = set_fallbacks(option_spec, parameters)
    assert len(no_log_values) == 0
    assert parameters['test'] == 'true'
    os.environ['UNIT_TEST_BOOL'] = 'test'
    no_log_values = set_fallbacks(option_spec, parameters)
    assert len(no_log_values) == 0
    assert parameters['test'] == 'test'



# Generated at 2022-06-11 01:20:14.814098
# Unit test for function set_fallbacks

# Generated at 2022-06-11 01:20:24.148228
# Unit test for function env_fallback
def test_env_fallback():
    from ansible.module_utils.six import PY3
    if not PY3:
        import __builtin__ as builtins
    else:
        import builtins

    # Test that we do not error when no fallback is found
    os.environ = {'ANSIBLE_FOO_BAR_KEY': 'myhost.mydomain.tld'}
    assert len(env_fallback('ANSIBLE_FOO_BAR_KEY')) == 1
    assert env_fallback('ANSIBLE_FOO_BAR_KEY')[0] == 'myhost.mydomain.tld'
    assert len(env_fallback('FOO_BAR_KEY', 'ANSIBLE_FOO_BAR_KEY')) == 1

# Generated at 2022-06-11 01:20:36.372745
# Unit test for function remove_values
def test_remove_values():
    assert remove_values('value', ['value']) == 'VALUE'
    assert remove_values('value', ['not value']) == 'value'
    assert remove_values(['value'], ['value']) == ['VALUE']
    assert remove_values(['value'], ['not value']) == ['value']
    assert remove_values(('value',), ['value']) == ('VALUE',)
    assert remove_values(('value',), ['not value']) == ('value',)
    assert remove_values({'value': 'value'}, ['value']) == {'value': 'VALUE'}
    assert remove_values({'value': 'value'}, ['not value']) == {'value': 'value'}
    assert remove_values({'not value': 'value'}, ['value']) == {'not VALUE': 'VALUE'}

# Generated at 2022-06-11 01:20:46.287701
# Unit test for function set_fallbacks
def test_set_fallbacks():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    if not basic.HAS_CRYPTOGRAPHY:
        pytest.skip('Skipping due to missing cryptography module')

    argument_spec = {
        'token': {'type': 'str', 'no_log': True, 'fallback': (env_fallback, ['TOKEN'])},
        'auth': {'type': 'dict', 'no_log': True,
                 'options': {'username': {'type': 'str', 'fallback': (env_fallback, ['USERNAME'])},
                             'password': {'type': 'str', 'fallback': (env_fallback, ['PASSWORD'])}}},
    }


# Generated at 2022-06-11 01:20:53.932157
# Unit test for function env_fallback
def test_env_fallback():
    matching_env_var = "ANSIBLE_TEST_FOO"
    non_matching_env_var = "ANSIBLE_TEST_BAR"
    os.environ[matching_env_var] = "matching_env_var"
    try:
        assert env_fallback(matching_env_var) == "matching_env_var"
        assert env_fallback(non_matching_env_var) == ""
    finally:
        os.environ.pop(matching_env_var, None)
        os.environ.pop(non_matching_env_var, None)


# Generated at 2022-06-11 01:20:59.174927
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST'] = 'abc'
    assert 'abc' == env_fallback('ANSIBLE_TEST')
    assert AnsibleFallbackNotFound == type(env_fallback('ANSIBLE_NONE'))
    del os.environ['ANSIBLE_TEST']



# Generated at 2022-06-11 01:21:02.534192
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('TEST_ENV_FALLBACK_TEST') == os.environ['TEST_ENV_FALLBACK_TEST']



# Generated at 2022-06-11 01:21:11.243506
# Unit test for function set_fallbacks
def test_set_fallbacks():
    from ansible.module_utils.common.collections import ImmutableDict

    test_params = {'switch': 'vswitch', 'not_overridden': 'some_value'}
    test_argument_spec = {'switch': {'type': 'str', 'fallback': (env_fallback, ['ANSIBLE_VSWITCH'])}, 'not_overridden': {'type': 'str', 'fallback': (env_fallback, ['ANSIBLE_NOT_OVERRIDDEN'])}}

    no_log_values = set_fallbacks(test_argument_spec, test_params)
    assert(no_log_values == ImmutableDict())

    assert(test_params == ImmutableDict({'switch': 'vswitch', 'not_overridden': 'some_value'}))


# Generated at 2022-06-11 01:26:49.759997
# Unit test for function sanitize_keys
def test_sanitize_keys():
    pass



# Generated at 2022-06-11 01:26:52.773803
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert set_fallbacks({}, {}) == set()
    assert set_fallbacks({'x': {'type': 'str', 'fallback': (env_fallback, 'FOO')}}, {'x': 'FOO'}) == set()



# Generated at 2022-06-11 01:27:02.097674
# Unit test for function sanitize_keys
def test_sanitize_keys():
    # Test keys are not logged correctly
    assert 'dsa_private_key' == sanitize_keys(dict(key_to_sanitize='dsa_private_key'),
                                              ['private_key'])['key_to_sanitize']

    # Test keys are logged correctly
    assert 'dsa_private_key' == sanitize_keys(dict(key_to_sanitize='dsa_private_key'),
                                              ['private_key'],
                                              ignore_keys=['key_to_sanitize'])['key_to_sanitize']

    # Test keys in nested dicts or lists are not logged correctly

# Generated at 2022-06-11 01:27:12.393420
# Unit test for function set_fallbacks
def test_set_fallbacks():
    spec = dict(foo=dict(type='str', fallback=('env_fallback', ['ANSIBLE_FOO'])))
    params = dict(foo='test')
    assert set_fallbacks(spec, params) == set()
    assert params == dict(foo='test')
    params = dict()
    assert set_fallbacks(spec, params) == set()
    assert params == dict()
    spec = dict(foo=dict(type='str', fallback=('env_fallback', ['ANSIBLE_FOO']), no_log=True))
    params = dict()
    assert set_fallbacks(spec, params) == set(['env_fallback'])
    assert params == dict(foo='env_fallback')


# Generated at 2022-06-11 01:27:21.261103
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert set_fallbacks(dict(), dict()) == set()
    assert set_fallbacks({'a': {'fallback': (env_fallback, 'A')}}, {}) == set(['A'])
    assert set_fallbacks({'a': {'fallback': (env_fallback, 'A', 'B')}}, {}) == set(['B'])
    assert set_fallbacks({'a': {'fallback': (env_fallback, 'A', {'b': 'C'})}}, {}) == set()
    assert set_fallbacks({'a': {'fallback': (env_fallback, {'b': 'C'})}}, {}) == set()



# Generated at 2022-06-11 01:27:32.157142
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        a=dict(type='bool', default=False),
        b=dict(type='bool', default=False, fallback=(env_fallback, ['ANSIBLE_MODULE_BOOL_B'])),
        c=dict(type='dict', options=dict(
            d=dict(type='bool', default=False),
            e=dict(type='bool', default=False, fallback=(env_fallback, ['ANSIBLE_MODULE_BOOL_D'])),
        )),
    )
    parameters = dict()
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters.get('a') is False
    assert parameters.get('b') is False
    assert parameters.get('c').get('d') is False

# Generated at 2022-06-11 01:27:39.765997
# Unit test for function env_fallback
def test_env_fallback():
    try:
        env_fallback('ANSIBLE_TEST')
    except AnsibleFallbackNotFound:
        pass
    else:
        raise AssertionError("env_fallback should have thrown an AnsibleFallbackNotFound exception.")

    assert env_fallback('ANSIBLE_TEST', 'ONE', 'TWO') == 'ONE'

    os.environ['ANSIBLE_TEST'] = 'THREE'
    assert env_fallback('ANSIBLE_TEST', 'ONE', 'TWO') == 'THREE'
    del os.environ['ANSIBLE_TEST']



# Generated at 2022-06-11 01:27:45.240907
# Unit test for function sanitize_keys
def test_sanitize_keys():
    data = {'my_secret': 'password', 'my_user': 'admin', 'my_dict': {'my_secret': 'password', 'my_user': 'admin'}, 'my_list': [{'my_secret': 'password', 'my_user': 'admin'}]}
    no_log_values = [b'password']
    new_data = sanitize_keys(data, no_log_values)
    assert not new_data['my_secret'].startswith(b'PASSWORD')
    assert not new_data['my_dict']['my_secret'].startswith(b'PASSWORD')
    assert not new_data['my_list'][0]['my_secret'].startswith(b'PASSWORD')



# Generated at 2022-06-11 01:27:54.471216
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV'] = 'ABC'
    os.environ['ANSIBLE_TEST_ENV2'] = '123'
    os.environ['ANSIBLE_TEST_ENV3'] = '89'
    # Set some env variables
    assert 'ABC' == env_fallback('ANSIBLE_TEST_ENV')
    assert '123' == env_fallback('ANSIBLE_TEST_ENV2')
    assert '89' == env_fallback('ANSIBLE_TEST_ENV3')
    # Try to get a non existing variable
    assert env_fallback('ANSIBLE_UNKNOWN_ENV') == AnsibleFallbackNotFound


# Generated at 2022-06-11 01:28:03.101158
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'param': {'type': 'str', 'default': 'default', 'fallback': (env_fallback, ['FALLBACK_ENV'])}}
    parameters = {}
    set_fallbacks(argument_spec, parameters)
    assert parameters['param'] == 'default'
    os.environ['FALLBACK_ENV'] = 'environment'
    parameters = {}
    set_fallbacks(argument_spec, parameters)
    assert parameters['param'] == 'environment'
    del os.environ['FALLBACK_ENV']



# Generated at 2022-06-11 01:28:35.006862
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert set_fallbacks({'a': {'fallback': (env_fallback, 'FOO')}}, {}) == set()
    assert set_fallbacks({'a': {'fallback': (env_fallback, 'FOO')}}, {'a': 1}) == set()
    assert set_fallbacks({'a': {'fallback': (env_fallback, 'FOO')}}, {'a': 1, 'b': 2}) == set()
    assert set_fallbacks({'a': {'fallback': (env_fallback, 'FOO')}}, {'b': 2}) == set()
    d = mock.patch.dict('os.environ', {'FOO': 'bar'})
    d.start()

# Generated at 2022-06-11 01:28:46.275396
# Unit test for function set_fallbacks

# Generated at 2022-06-11 01:28:53.983281
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_VAR1'] = 'TEST1'
    os.environ['ANSIBLE_TEST_VAR2'] = 'TEST2'
    assert env_fallback('ANSIBLE_TEST_VAR1') == 'TEST1'
    assert env_fallback('ANSIBLE_TEST_VAR2') == 'TEST2'
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('ANSIBLE_TEST_VAR3')

_FALLBACKS['env'] = env_fallback



# Generated at 2022-06-11 01:29:02.956772
# Unit test for function remove_values
def test_remove_values():
    '''Unit test for function remove_values'''
    assert remove_values('my_password: ABC', no_log_strings=('ABC', 'XYZ')) == 'my_password: ***'
    assert remove_values(dict(a='ABC', kw1='XYZ'), no_log_strings=('ABC', 'XYZ')) == dict(a='***', kw1='***')
    assert remove_values(dict(a=dict(b='ABC'), kw1='XYZ'), no_log_strings=('ABC', 'XYZ')) == dict(a=dict(b='***'), kw1='***')
    assert remove_values(dict(a=dict(b=[dict(c='ABC'), dict(c='XYZ')]), kw1='XYZ'), no_log_strings=('ABC', 'XYZ'))