

# Generated at 2022-06-11 01:20:02.156914
# Unit test for function set_fallbacks
def test_set_fallbacks():
    mod_params = dict(p1='v1', p2='v2')

# Generated at 2022-06-11 01:20:07.677728
# Unit test for function remove_values
def test_remove_values():
    assert remove_values('password', ['password']) == 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'
    assert remove_values({'key': 'value'}, ['password']) == {'key': 'value'}
    assert remove_values([{'a': {'b': {'c': 'password'}}}], ['password']) == [{'a': {'b': {'c': 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'}}}]
    assert remove_values([{'a': {'b': {'c': {'d': 'password'}}}}], ['password']) == [{'a': {'b': {'c': {'d': 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'}}}}]

# Generated at 2022-06-11 01:20:18.132372
# Unit test for function set_fallbacks
def test_set_fallbacks():
    result = []
    def test_fallback(parameter_name, fallback_value):
        result.append([parameter_name, fallback_value])
        return fallback_value
    spec = dict(test1=dict(type='str', fallback=(test_fallback, 'test1_value')),
                test2=dict(type='str', fallback=(test_fallback, ('test2_value',), {'parameter_name': 'test2'})))

    parameters = dict()
    set_fallbacks(spec, parameters)
    assert parameters['test1'] == 'test1_value'
    assert parameters['test2'] == 'test2_value'
    assert result == [['', 'test1_value'], ['test2', 'test2_value']]

    parameters = dict(test1='foo')


# Generated at 2022-06-11 01:20:25.636895
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['TEST_ENV_FALLBACK_FOO'] = 'bar'
    assert env_fallback('TEST_ENV_FALLBACK_FOO') == 'bar'
    assert env_fallback('TEST_ENV_FALLBACK_FOO', 'TEST_ENV_FALLBACK_BAR') == 'bar'
    os.environ['TEST_ENV_FALLBACK_BAR'] = 'foo'
    assert env_fallback('TEST_ENV_FALLBACK_BAR', 'TEST_ENV_FALLBACK_FOO') == 'foo'
    assert env_fallback('TEST_ENV_FALLBACK_MISSING') == _ANSIBLE_FALLBACK_NOT_SET



# Generated at 2022-06-11 01:20:30.868433
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert set_fallbacks({}, {}) == set()
    assert set_fallbacks({'test': {'fallback': ('test',)}}, {}) == set()
    assert set_fallbacks({'test': {'fallback': ('test',), 'no_log': True}}, {}) == {'test'}



# Generated at 2022-06-11 01:20:42.410254
# Unit test for function sanitize_keys

# Generated at 2022-06-11 01:20:52.493770
# Unit test for function set_fallbacks

# Generated at 2022-06-11 01:20:58.849745
# Unit test for function sanitize_keys
def test_sanitize_keys():
    """
    Exercise and validate the 'sanitize_keys' function.
    """
    #
    # Expected values are defined at the end of this function to simplify testing
    #
    # Ensure that we get exceptions when we provide wrong input
    assert_raises(AssertionError, sanitize_keys, None)
    assert_raises(AssertionError, sanitize_keys, None, frozenset())
    assert_raises(AssertionError, sanitize_keys, None, None, frozenset())
    assert_raises(AssertionError, SANITIZE_KEYS_EXPECTED, frozenset())
    assert_raises(AssertionError, SANITIZE_KEYS_EXPECTED, None, frozenset())

# Generated at 2022-06-11 01:21:09.351481
# Unit test for function remove_values
def test_remove_values():
    assert remove_values('$ANSIBLE_NET_USERNAME', ['$ANSIBLE_NET_PASSWORD']) == '$ANSIBLE_NET_USERNAME'

    assert remove_values('$ANSIBLE_NET_PASSWORD', ['$ANSIBLE_NET_PASSWORD']) == 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'

    assert remove_values('some plain text', ['$ANSIBLE_NET_PASSWORD']) == 'some plain text'

    assert remove_values(set(['$ANSIBLE_NET_PASSWORD', '$ANSIBLE_NET_USERNAME']), ['$ANSIBLE_NET_PASSWORD']) == set(['VALUE_SPECIFIED_IN_NO_LOG_PARAMETER', '$ANSIBLE_NET_USERNAME'])


# Generated at 2022-06-11 01:21:15.007155
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'param1': {'required': False, 'type': 'str', 'fallback': (env_fallback, 'default_value')},
                     'param2': {'required': False, 'type': 'str', 'fallback': (env_fallback, 'default_value', {'no_log': True})},
                     'param3': {'required': False, 'type': 'str', 'fallback': (env_fallback, 'default_value')}}

    os.environ['default_value'] = 'env_value'

    parameters = {'param3': 'param3_value'}

    no_log_parameters = set_fallbacks(argument_spec, parameters)

    assert parameters['param1'] == 'env_value'
    assert parameters['param3'] == 'param3_value'

# Generated at 2022-06-11 01:21:48.149880
# Unit test for function set_fallbacks
def test_set_fallbacks():
    parameters = {'hello': 'world'}
    argument_spec = dict(hello=dict(type='str', default='haha'),
                         say=dict(type='str', fallback=(env_fallback, 'SAY')),
                         say2=dict(type='str', fallback=(str, dict(key='SAY2'))))
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['say'] == 'hello'
    assert parameters['say2'] == '{"key": "SAY2"}'
    assert parameters['hello'] == 'world'
    assert no_log_values == set()

    # test when the parameter already has value, the fallback won't be executed
    parameters = {'hello': 'world', 'say': 'hello', 'say2': '{"key": "SAY2"}'}
   

# Generated at 2022-06-11 01:21:56.074374
# Unit test for function remove_values
def test_remove_values():
    assert remove_values('value', ('value',)) == u'VALUE_REDACTED'

    assert remove_values(['value'], ('value',)) == [u'VALUE_REDACTED']

    assert remove_values(('value',), ('value',)) == (u'VALUE_REDACTED',)

    assert remove_values({'a': 'value'}, ('value',)) == {'a': 'VALUE_REDACTED'}

    assert remove_values({'a': 'value'}, ('a',)) == {'a': 'value'}

    assert remove_values({'a': 'value', 'b': 'value'}, ('value',)) == {'a': 'VALUE_REDACTED', 'b': 'VALUE_REDACTED'}


# Generated at 2022-06-11 01:22:07.189006
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(a=dict(type='int', fallback=(env_fallback, 'FOO')),
                         b=dict(type='int', fallback=(env_fallback, 'BAR')),
                         c=dict(type='int', fallback=(env_fallback, 'BAZ')),
                         d=dict(type='int', fallback=(env_fallback, 'QAZ')),
                         e=dict(type='int', fallback=(env_fallback, 'QAZ', dict(default=123))))
    parameters = dict(a=1)
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert len(no_log_values) == 0
    assert parameters['a'] == 1

    os.environ['FOO'] = '4'
    no_log_values = set

# Generated at 2022-06-11 01:22:15.976501
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert set_fallbacks({'a': {'fallback': ('env_fallback', 'A')}}, {}) == set()
    assert set_fallbacks({'a': {'fallback': ('env_fallback', 'A')}}, {'a': ''}) == set()
    assert set_fallbacks({'a': {'fallback': ('env_fallback', 'A')}}, {'b': ''}) == set()
    assert set_fallbacks({'a': {'fallback': ('env_fallback', 'A')}}, {}) == set()

    os.environ['A'] = 'A'
    assert set_fallbacks({'a': {'fallback': ('env_fallback', 'A')}}, {'b': ''}) == set(['A'])

# Generated at 2022-06-11 01:22:26.453692
# Unit test for function set_fallbacks
def test_set_fallbacks():
    module_args = {
        'a': 'one',
        'b': 'two',
        'c': 'three',
    }


# Generated at 2022-06-11 01:22:34.911512
# Unit test for function set_fallbacks

# Generated at 2022-06-11 01:22:46.533162
# Unit test for function set_fallbacks
def test_set_fallbacks():
    fn_sample = {
        'param': {'required': True, 'type': 'str'},
        'otherparam': {'type': 'str', 'no_log': True, 'fallback': (env_fallback, 'OTHER_PARAM', 'OTHER_PARAM2')}
    }
    # Test with no fallbacks
    test_params = dict(param='a')
    no_logs = set_fallbacks(fn_sample, test_params)
    assert no_logs == set()
    assert test_params == dict(param='a')
    assert fn_sample['otherparam'].get('no_log') is True
    # Test with a fallback that raises an exception
    test_params = dict(param='a')
    no_logs = set_fallbacks(fn_sample, test_params)
   

# Generated at 2022-06-11 01:22:51.116762
# Unit test for function set_fallbacks
def test_set_fallbacks():
    arg_spec = {'name': {'type': 'str', 'fallback': (env_fallback, 'IBM_APP_NAME')}}
    os.environ['IBM_APP_NAME'] = 'test_value'
    result = set_fallbacks(arg_spec, {})
    assert result == set(['test_value'])



# Generated at 2022-06-11 01:23:02.273878
# Unit test for function env_fallback
def test_env_fallback():
    """
    env_fallback:
      description:
        - Text that explains the env var fallback
      env:
        - name: ANSIBLE_VAR1
          version_added: '2.5'
        - name: ANSIBLE_VAR2
      type: str
      fallback: (env_fallback, 'ANSIBLE_VAR1', 'ANSIBLE_VAR2')
      ini:
      - key: var1
        section: defaults
      - key: var2
        section: defaults
    """
    env_vars = dict(ANSIBLE_VAR1=12345)

# Generated at 2022-06-11 01:23:10.740516
# Unit test for function set_fallbacks
def test_set_fallbacks():
    if not HAS_PYTHON26:
        raise SkipTest('Python 2.6 or newer is required')
    # Positive test
    param = {'param': {'type': 'dict', 'options': {
        'param': {'type': 'str', 'fallback': (env_fallback, 'TEST_ENV_PARAM', 'TEST_ENV_PARAM_2')}}}}
    module = MagicMock(params=param)

    # Param is already set to value from task
    os.environ['TEST_ENV_PARAM'] = 'env_value'
    no_log_values = set_fallbacks(param['param']['options'], module.params['param'])
    assert len(no_log_values) == 0

# Generated at 2022-06-11 01:23:45.017745
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'test_param': {
            'type': 'str',
            'fallback': [env_fallback, ['TEST_PARAM']]
        },
    }
    os.environ['TEST_PARAM'] = 'test_value'
    parameters = {}
    no_log_values = set_fallbacks(argument_spec, parameters)
    os.environ.pop('TEST_PARAM')
    assert parameters['test_param'] == 'test_value'
    assert 'test_param' not in no_log_values
    assert 'test_value' not in no_log_values


# Generated at 2022-06-11 01:23:53.310831
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('NO_SUCH_VAR') == AnsibleFallbackNotFound
    os.environ['TEST_ENV_FALLBACK'] = 'OK'
    assert env_fallback('TEST_ENV_FALLBACK') == 'OK'
    assert env_fallback('TEST_ENV_FALLBACK', 'OK') == 'OK'
    del os.environ['TEST_ENV_FALLBACK']
    assert env_fallback('TEST_ENV_FALLBACK', 'OK') == 'OK'



# Generated at 2022-06-11 01:24:01.482654
# Unit test for function remove_values
def test_remove_values():
    '''
    Test the functionality of the remove_values function
    '''
    no_log_strings = ['private_string']
    value = 'string_with_private_string_embedded'
    assert remove_values(value, no_log_strings) == 'string_with_*************ed'
    # Numbers and None are not considered strings
    value = 1234
    assert remove_values(value, no_log_strings) == 1234
    value = None
    assert remove_values(value, no_log_strings) is None
    # A dictionary with private string at keys, values and embedded in list

# Generated at 2022-06-11 01:24:07.821305
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert set_fallbacks({'vault_password_file': {'fallback': [env_fallback, '_my_pw_file']}}, {}) == set()
    assert set_fallbacks({'vault_password_file': {'fallback': [env_fallback, '_my_pw_file']}}, {'vault_password_file': 'test'}) == set()
    os.environ['_my_pw_file'] = 'test'
    assert set_fallbacks({'vault_password_file': {'fallback': [env_fallback, '_my_pw_file']}}, {}) == set(['test'])

# Generated at 2022-06-11 01:24:15.146915
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_UNIT_TEST_1'] = 'foo'
    assert env_fallback('ANSIBLE_UNIT_TEST_1', 'ANSIBLE_UNIT_TEST_2') == 'foo'
    del os.environ['ANSIBLE_UNIT_TEST_1']
    assert env_fallback('ANSIBLE_UNIT_TEST_1', 'ANSIBLE_UNIT_TEST_2') == 'ANSIBLE_UNIT_TEST_2'



# Generated at 2022-06-11 01:24:24.294338
# Unit test for function env_fallback
def test_env_fallback():
    # Test successful env variable lookup
    my_var = 'MY_TEST_VAR'
    for value in (123, 'foo', 'bar', True, False, [1, 2, 3], {'foo': 'bar'}, None):
        os.environ[my_var] = json.dumps(value)
        assert env_fallback(my_var) == value
    del os.environ[my_var]
    # Test failed env variable lookup
    caught = False
    try:
        env_fallback('DOES_NOT_EXIST')
    except AnsibleFallbackNotFound:
        caught = True
    assert caught

# Generated at 2022-06-11 01:24:28.301406
# Unit test for function env_fallback
def test_env_fallback():
    os.environ["FOO"] = "test_foo"
    assert env_fallback("FOO") == "test_foo"
    del os.environ["FOO"]
    assert env_fallback("FOO") == None



# Generated at 2022-06-11 01:24:32.026414
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('FOO') == 'BAR'
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('FOO_BAR')



# Generated at 2022-06-11 01:24:39.194368
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert set_fallbacks(dict(foo=dict(type='str', fallback=(env_fallback, ('FOO',)))), {}) == set(os.environ.get('FOO', ''))
    if 'FOO' in os.environ:
        try:
            del os.environ['FOO']
        except KeyError:
            pass
        assert set_fallbacks(dict(foo=dict(type='str', fallback=(env_fallback, ('FOO',)))), {}) == set()



# Generated at 2022-06-11 01:24:50.718407
# Unit test for function set_fallbacks

# Generated at 2022-06-11 01:25:13.916688
# Unit test for function env_fallback
def test_env_fallback():
    # Test default functionality
    assert env_fallback('FOO') == os.environ['FOO']
    # Test fallback functionality
    os.environ['FOO'] = 'bar'
    assert env_fallback('BAR', 'FOO') == 'bar'



# Generated at 2022-06-11 01:25:26.493258
# Unit test for function sanitize_keys
def test_sanitize_keys():
    """Unit test for function ``sanitize_keys``."""

    assert sanitize_keys('foo', set()) == 'foo'
    assert sanitize_keys(1, set()) == 1
    assert sanitize_keys('foo', {'foo'}) == '**VALUE_REDACTED**'
    assert sanitize_keys(1, {'1'}) == '**VALUE_REDACTED**'

    assert sanitize_keys(None, set()) is None
    assert sanitize_keys({'foo': 'bar'}, set()) == {'foo': 'bar'}
    assert sanitize_keys({'foo': 'bar'}, {'foo', 'bar'}) == {'**VALUE_REDACTED**': 'bar'}

# Generated at 2022-06-11 01:25:27.128396
# Unit test for function env_fallback
def test_env_fallback():
    None



# Generated at 2022-06-11 01:25:34.222640
# Unit test for function remove_values
def test_remove_values():
    """This function will test remove values function"""
    assert remove_values('av', {'av'}) == '**'
    assert remove_values(['av'], {'av'}) == ['**']
    assert remove_values('avs', {'av'}) == 'avs'
    assert remove_values(['avs'], {'av'}) == ['avs']
    assert remove_values(['av', [], 'avs'], {'av'}) == ['**', [], 'avs']
    assert remove_values(['av', [], 'avs'], {'av', 'avs'}) == ['**', [], '**']
    assert remove_values({}, {'av'}) == {}

# Generated at 2022-06-11 01:25:37.742075
# Unit test for function env_fallback
def test_env_fallback():
    '''
    We should get env_fallback error if we can not find the environment variable
    '''
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('AnsibleNonExistEnv')


# Generated at 2022-06-11 01:25:45.159101
# Unit test for function remove_values
def test_remove_values():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch

    def _get_secret_data():
        return {
            'password': 'secret password',
            'api_key': 'secret API key'
        }

    class TestRemoveValues(unittest.TestCase):
        @patch.object(os.path, 'exists', return_value=False)
        @patch.object(os, 'environ', new=environ.copy())
        @patch.object(ConfigManager, 'load_config_file', return_value=_get_secret_data())
        def test_no_log_strings_are_set(self, mocker):
            no_log_strings = get_no_log_values()

# Generated at 2022-06-11 01:25:55.545065
# Unit test for function set_fallbacks

# Generated at 2022-06-11 01:26:01.277444
# Unit test for function env_fallback
def test_env_fallback():
    """Unit test for function env_fallback"""
    try:
        env = 'ANSIBLE_TEST_FALLBACK_ENV'
        val = 'foo'
        os.environ[env] = val
        assert env_fallback(env) == val
    finally:
        del os.environ[env]
    assert_raises(AnsibleFallbackNotFound, env_fallback, env)



# Generated at 2022-06-11 01:26:05.841268
# Unit test for function remove_values
def test_remove_values():
    module_args = dict(
        foo='bar',
        bar='bar',
        baz={'a': {'b': 1}, 'd': 'a bc', 'c': [1, 2, 3], 'f': [1, 2, 3]},
        c=[1, 2, 'a', ['a']],
        d=[1, 2, 'a', ['a']],
        e={'a': 'a', 'b': ['a', 'b']},
        f={'a': 'a', 'b': ['a', 'b']},
        g=set(['a', 1, 2]),
        h=set(['a', 1, 2]),
        i=set()
    )
    values_to_mask = set(['bar', 'baz'])

# Generated at 2022-06-11 01:26:16.398017
# Unit test for function set_fallbacks

# Generated at 2022-06-11 01:26:45.040987
# Unit test for function env_fallback
def test_env_fallback():
    """Validate env_fallback function"""

    old_environment = os.environ.copy()
    os.environ['ANSIBLE_TEST_ENVIRONMENT'] = 'my_env'
    if env_fallback('ANSIBLE_TEST_ENVIRONMENT') != 'my_env':
        raise AssertionError('Failed to return environment variable "ANSIBLE_TEST_ENVIRONMENT"')
    os.environ = old_environment
    if env_fallback('ANSIBLE_TEST_ENVIRONMENT_NONE') != 'default':
        raise AssertionError('Failed to fallback to default "default"')


# Generated at 2022-06-11 01:26:48.188195
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('FAIL_TESTING') == 'FAIL_TESTING'
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('FAIL_FAIL_FAIL')


# Generated at 2022-06-11 01:26:54.128485
# Unit test for function remove_values
def test_remove_values():
    # Test for remove_values(value, no_log_strings)

    # Empty no_log_strings
    assert remove_values(1, []) == 1
    assert remove_values(['a', 'b'], []) == ['a', 'b']
    assert remove_values({'a': 'b'}, []) == {'a': 'b'}

    # Single no_log_strings element
    assert remove_values('test_string', ['test']) == '_string'
    assert remove_values(['test_string', 'string_test'], ['test']) == ['_string', 'string_test']
    assert remove_values([['test_string', 'string_test'], ['string_test']], ['test']) == [['_string', 'string_test'], ['string_test']]
    assert remove_

# Generated at 2022-06-11 01:27:04.565348
# Unit test for function set_fallbacks

# Generated at 2022-06-11 01:27:15.666343
# Unit test for function remove_values
def test_remove_values():
    assert remove_values(1, ['1']) == 1

    assert remove_values(b'foo_bar', ['_bar']) == b'foo_bar'
    assert remove_values(b'foo_bar', [b'_bar']) == b'foo'
    assert remove_values('foo_bar', ['_bar']) == 'foo'
    assert remove_values('foo_bar', [u'_bar']) == 'foo'
    assert remove_values(u'foo_bar', ['_bar']) == u'foo'
    assert remove_values(u'foo_bar', [u'_bar']) == u'foo'

    assert remove_values(b'foo_bar', ['foo_bar']) == b'********'
    assert remove_values(b'foo_bar', [b'foo_bar'])

# Generated at 2022-06-11 01:27:24.558343
# Unit test for function remove_values
def test_remove_values():
    data_val = {'a': [1, 2, 'z@c.com'], 'b': {'lol': '!@#$@#$%@#$%^@#$%^&'}}
    string_val = '!@#$%^&*()_+!@#$%^&*(123!@#$%^&*()_+*-)'
    result_val = {'a': [1, 2, 'z@c.com'], 'b': {'lol': '!@#$@#$%@#$%^@#$%^&'}}
    assert remove_values(data_val, ['!@#$%^&*()_+!@#$%^&*(123!@#$%^&*()_+*-)','!@#$@#$%@#$%^@#$%^&']) == result_val

# Generated at 2022-06-11 01:27:34.156231
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Set the environment variable
    os.environ.update({'ANSIBLE_NET_AUTH_PASS': 'ansible_pass'})

    spec = {
        'password': {'type': 'str', 'fallback': (env_fallback, ['ANSIBLE_NET_AUTH_PASS', 'ANSIBLE_NET_PASSWORD'])},
        'other': {'type': 'str', 'default': 'foo', 'fallback': (env_fallback, ['ANSIBLE_NET_AUTH_PASS', 'ANSIBLE_NET_PASSWORD'])},
        'no_log': {'type': 'str', 'default': 'bar', 'fallback': (env_fallback, ['ANSIBLE_NET_AUTH_PASS', 'ANSIBLE_NET_PASSWORD']), 'no_log': True},
    }

    #

# Generated at 2022-06-11 01:27:41.361471
# Unit test for function remove_values
def test_remove_values():  # pragma: no cover
    data = {
        "key1": "value",
        "key2": "value",
        "key3": {"key4": [1, "value", 3]},
        "key5": {"key6": [1, "value", 3]},
        "key7": ["value7", "value"],
        "key8": {"key9": "value", "key10": {"key11": "value"}}
    }

    no_log_strings = ["value"]
    new_data = remove_values(data, no_log_strings)

    from pprint import pprint
    pprint(new_data)



# Generated at 2022-06-11 01:27:47.198934
# Unit test for function set_fallbacks
def test_set_fallbacks():
    spec = {'http_port': {'default': 8080, 'fallback': (env_fallback, ['HTTP_PORT']), 'type': 'int'}}
    parameters = {'http_port': 80}
    expected = set()
    actual = set_fallbacks(spec, parameters)
    assert expected == actual

    parameters = {'http_port': 80}
    os.environ['HTTP_PORT'] = '8888'
    expected = set()
    actual = set_fallbacks(spec, parameters)
    assert expected == actual

    no_log_spec = {'http_port': {'default': 8080, 'fallback': (env_fallback, ['HTTP_PORT']), 'no_log': True, 'type': 'int'}}
    parameters = {'http_port': 80}

# Generated at 2022-06-11 01:27:53.586185
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(foo=dict(type='str', fallback=(env_fallback, 'ANSIBLE_FOO')))
    parameters = {}

    result = set_fallbacks(argument_spec, parameters)
    assert len(result) == 0

    os.environ['ANSIBLE_FOO'] = 'bar'
    result = set_fallbacks(argument_spec, parameters)
    assert len(result) == 0
    assert parameters == dict(foo='bar')

# Generated at 2022-06-11 01:28:44.738376
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'role_name': dict(type='str', required=True),
        'role_password': dict(type='str', no_log=True),
        'role_api_key': dict(type='str', no_log=True, fallback=(env_fallback, 'ROLE_API_KEY')),
        'role_api_key_var': dict(type='str', no_log=True, fallback=(env_fallback, ['ROLE_API_KEY_1', 'ROLE_API_KEY_2'])),
        'role_api_key_env': dict(type='str', no_log=True, fallback=(env_fallback, {'fallback_to': 'ROLE_API_KEY'})),
    }
    parameters = dict(role_name='foo')
    no

# Generated at 2022-06-11 01:28:55.188023
# Unit test for function set_fallbacks
def test_set_fallbacks():
    '''Test set_fallbacks'''
    env_var_name = 'ANSIBLE_TEST_FALLBACK_ENV_VAR'
    os.environ[env_var_name] = 'env_var_value'

# Generated at 2022-06-11 01:28:59.331160
# Unit test for function env_fallback
def test_env_fallback():
    # Check env value exists
    os.environ['ANSIBLE_TEST'] = 'test'
    assert env_fallback('ANSIBLE_TEST') == 'test'

    # Check env value not exists
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('NOT_EXIST')



# Generated at 2022-06-11 01:29:03.638440
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback("NOTDEFINED") == os.environ["NOTDEFINED"]
    assert env_fallback("NOTDEFINED1", "NOTDEFINED2") == os.environ["NOTDEFINED1"]
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback("NOTDEFINED1", "NOTDEFINED2")


# Generated at 2022-06-11 01:29:09.050954
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert set_fallbacks({}, {"a": 1}) == set()
    assert set_fallbacks({"a": {"fallback": (None,)}}, {"a": 1}) == set()
    assert set_fallbacks({"a": {"fallback": (None,)}}, {"b": 1}) == set()
    assert set_fallbacks({"a": {"fallback": (env_fallback,)}}, {"b": 1}) == set()
    assert set_fallbacks({"a": {"fallback": (env_fallback, "FOO")}}, {"b": 1}) == set()
    assert set_fallbacks({"a": {"fallback": (env_fallback, "FOO")}}, {"b": 1}) == set()