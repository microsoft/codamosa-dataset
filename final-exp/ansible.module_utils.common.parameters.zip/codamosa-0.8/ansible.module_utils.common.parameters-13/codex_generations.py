

# Generated at 2022-06-11 01:19:58.348666
# Unit test for function remove_values
def test_remove_values():
    assert remove_values(42, []) == 42
    assert remove_values(42, ['42']) == 42

    # Remove from string
    assert remove_values('password', []) == 'password'
    assert remove_values('password', ['password']) == '********'
    assert remove_values(u'password', ['password']) == u'********'

    # Remove from mapping
    assert remove_values({'key': 'value'}, []) == {'key': 'value'}
    assert remove_values({'key': 'value'}, ['key']) == {'key': '*value'}
    assert remove_values({'key': 'value'}, ['value']) == {'key': '*alue'}

# Generated at 2022-06-11 01:20:02.083792
# Unit test for function env_fallback
def test_env_fallback():
    # Check non existing environment variable
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('VALUE_DOES_NOT_EXIST')


# Loads value from any combination of config files and environment variables

# Generated at 2022-06-11 01:20:08.858066
# Unit test for function set_fallbacks
def test_set_fallbacks():
    parameters = { "param1": "10.10.10.10/27" }
    argument_spec = { "param1": { "type": "str", "fallback": (env_fallback, ("CIDR_MASK",), { "default": "192.168.1.1/24" }) } }
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert "10.10.10.10/27" in no_log_values



# Generated at 2022-06-11 01:20:20.235051
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # simple spec
    spec1 = {'a': {'type': 'str', 'default': 'foo'}, 'b': {'type': 'str', 'fallback': (env_fallback, 'ANSIBLE_FOO')}, 'c': {'type': 'str', 'default': 'foo'},
             'd': {'type': 'str', 'default': 'foo'}}
    # spec with 'options'
    options = {'e': {'default': 'foo'}, 'f': {'type': 'str', 'default': 'bar'}, 'g': {'type': 'str', 'default': 'bar'}}

# Generated at 2022-06-11 01:20:31.848421
# Unit test for function set_fallbacks
def test_set_fallbacks():
    parameter_spec = {
        "param1": {"type": "str"},
        "param2": {"type": "str", "fallback": (env_fallback, ["ENV_VAR"])},
        "param3": {"type": "str", "fallback": (env_fallback, ["ENV_VAR"])},
        "param4": {"type": "str", "fallback": (env_fallback, {"key": "ENV_VAR"})},
        "param5": {"type": "str", "fallback": (env_fallback, ["ENV_VAR"])},
        "param6": {"type": "str", "fallback": (env_fallback, ["ENV_VAR"]), "no_log": True},
    }

# Generated at 2022-06-11 01:20:43.267011
# Unit test for function set_fallbacks
def test_set_fallbacks():
    spec = dict(
        a=dict(type='str', choices=['foo', 'bar', 'baz']),
        b=dict(type='str', fallback=('env_fallback', 'TEST_B', 'TEST_A')),
        c=dict(type='str', default='test'),
        d=dict(type='str', fallback=(env_fallback, 'TEST_C')),
        e=dict(type='str', no_log=True, fallback=(env_fallback, 'TEST_PASSWORD', 'TEST_PASS', 'TEST_SECRET')),
        f=dict(type='str', fallback=(env_fallback,)),
    )
    p = dict(a='foo', b='foo', c='foo', d='foo', e='foo', f='foo')

   

# Generated at 2022-06-11 01:20:53.303827
# Unit test for function set_fallbacks
def test_set_fallbacks():
    fallback_spec = dict(
        fakedata=dict(
            type='str',
            required=False,
            fallback=("ANSIBLE_TEST_FAKEDATA", ["FOO_BAR_TEST_FAKEDATA", {"fallback_value": "baz"}], "ANSIBLE_TEST_FAKEDATA2")
        )
    )
    fallback_params = {}
    # When fallback parameters are available, use them
    assert set_fallbacks(fallback_spec, fallback_params) == set()
    assert fallback_params == dict(fakedata=os.environ['ANSIBLE_TEST_FAKEDATA'])
    # When fallback parameters are not available, do not use them
    assert set_fallbacks(fallback_spec, fallback_params) == set()




# Generated at 2022-06-11 01:20:59.308316
# Unit test for function sanitize_keys
def test_sanitize_keys():
    no_log_strings = set([b'private', u'private'])

    obj = {
        u'private': u'private_value',
        '_ansible_private': 'private_value',
        '_ansible_private_key': u'private_value',
        'public': [
            {u'private': u'private_value'},
            {'private': u'private_value'},
        ]
    }


# Generated at 2022-06-11 01:21:07.453753
# Unit test for function set_fallbacks
def test_set_fallbacks():

    spec = dict()
    spec["username"] = dict(fallback=(env_fallback, "USERNAME"))
    spec["password"] = dict(fallback=(env_fallback, "PASSWORD"))
    spec["Environment"] = dict(fallback=(lenient_fallback, dict(Environment="Environment")))
    spec["Home"] = dict(fallback=(env_fallback, "HOME"))
    spec["None"] = dict(fallback=(env_fallback, "FOO"))
    parameters = dict()
    result = set_fallbacks(spec, parameters)
    assert parameters.get("username") == os.environ.get("USERNAME")
    assert parameters.get("password") == os.environ.get("PASSWORD")
    assert parameters.get("Environment") == os.environ.get("Environment")
    assert parameters.get

# Generated at 2022-06-11 01:21:18.219572
# Unit test for function set_fallbacks
def test_set_fallbacks():
    spec = {
        'name': {'type': 'str'},
        'username': {'type': 'str',
                     'fallback': (env_fallback, 'ANSIBLE_NET_USERNAME')},
        'password': {'type': 'str',
                     'no_log': True,
                     'fallback': (env_fallback, 'ANSIBLE_NET_PASSWORD')},
        'platform': {'type': 'str'}
    }
    parameters = {}
    assert set_fallbacks(spec, parameters) == set()
    assert 'ANSIBLE_NET_USERNAME' not in os.environ
    assert 'ANSIBLE_NET_PASSWORD' not in os.environ
    for param in ('name', 'username', 'password', 'platform'):
        assert param not in parameters
    os.environ

# Generated at 2022-06-11 01:21:51.345942
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'param_one': {'type': 'str', 'no_log': False},
                     'param_two': {'type': 'str', 'no_log': True, 'fallback': (env_fallback, ["FOO"])},
                     'param_three': {'type': 'str',
                                     'no_log': True,
                                     'fallback': (fetch_from_facts, {'fallback': (env_fallback, ["FOO"]), 'fact': 'ansible_default_ipv4'})}}
    parameters = {'param_one': 'foo'}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['param_two'] == 'foo'
    assert len(no_log_values) == 0


# Generated at 2022-06-11 01:22:00.632332
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # pylint: disable=protected-access
    argument_spec = dict(
        foo=dict(type='str', fallback=(env_fallback, 'FOO_ID')),
        bar=dict(type='str', fallback=(env_fallback, 'BAR_ID', 'BAR_NAME')),
        baz=dict(type='str', fallback=(env_fallback, dict(key='BAZ', default='default'))),
        mux=dict(type='list', fallback=(env_fallback, 'MUX')),
    )

    parameters = dict(
        foo='foo',
        bar='bar',
        baz='baz',
        mux=['mux'],
    )

    no_log_values = set_fallbacks(argument_spec, parameters)

    assert no_log_

# Generated at 2022-06-11 01:22:12.158339
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # no fallback
    assert set_fallbacks({'a': {}, 'b': {'fallback': (None,)}}, {'a': 'a'}) == set()
    # fallback from none to a
    assert set_fallbacks({'a': {}, 'b': {'fallback': (None,)}}, {}) == set()
    # fallback from none to b
    assert set_fallbacks({'a': {}, 'b': {'fallback': (None,)}}, {'a': 'a'}) == set()
    # fallback from a to b
    assert set_fallbacks({'a': {'fallback': (None,)}, 'b': {'fallback': (None,)}}, {}) == set()
    # fallbacks when a is present, b is not and fallback b is present
    assert set_

# Generated at 2022-06-11 01:22:21.950290
# Unit test for function set_fallbacks

# Generated at 2022-06-11 01:22:32.106687
# Unit test for function set_fallbacks

# Generated at 2022-06-11 01:22:43.226932
# Unit test for function set_fallbacks

# Generated at 2022-06-11 01:22:52.118375
# Unit test for function set_fallbacks

# Generated at 2022-06-11 01:23:03.045254
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert set_fallbacks({'foo': {'type': 'str', 'fallback': (env_fallback, 'FOO')}}, {}) == set(['bar'])
    assert set_fallbacks({'foo': {'type': 'str', 'fallback': (env_fallback, ('BAR',))}}, {}) == set(['bar'])
    assert set_fallbacks({'foo': {'type': 'str', 'fallback': (env_fallback,)}}, {}) == set()
    assert set_fallbacks({'foo': {'type': 'str', 'fallback': (env_fallback, 'nope')}}, {}) == set()
    assert set_fallbacks({'foo': {'type': 'str', 'fallback': (env_fallback, ('nope',))}}, {}) == set

# Generated at 2022-06-11 01:23:11.065283
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys({"key": "value"}, []) == {"key": "value"}
    assert sanitize_keys({"key": "value"}, ["value"]) == {"key": "VA******"}
    assert sanitize_keys({"key": "value", "ignore_key": "value"}, ["value"], ignore_keys={"ignore_key"}) == {"key": "VA******", "ignore_key": "value"}
    assert sanitize_keys({"key": "value", "_ansible_ignore_key": "value"}, ["value"], ignore_keys={"ignore_key"}) == {"key": "VA******", "_ansible_ignore_key": "value"}
    assert sanitize_keys({"key": "value"}, [u"value"]) == {"key": "VA******"}
    assert sanitize

# Generated at 2022-06-11 01:23:19.863469
# Unit test for function set_fallbacks

# Generated at 2022-06-11 01:23:52.753496
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'yaml_test': {
            'type': 'bool',
            'fallback': (env_fallback, ['ANSIBLE_YAML_TEST']),
            'required': False
        },
        'yaml_test2': {
            'type': 'bool',
            'fallback': (env_fallback, ['ANSIBLE_YAML_TEST2']),
            'required': False,
            'no_log': True
        },
    }

    parameters = {'yaml_test': True}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert sorted(no_log_values) == []
    assert parameters['yaml_test'] == True

    parameters = {'yaml_test2': False}

# Generated at 2022-06-11 01:23:58.531913
# Unit test for function env_fallback
def test_env_fallback():

    # Test with one value
    os.environ['FOO'] = 'bar'
    assert env_fallback('FOO') == 'bar'

    # Test with multiple values and a match
    os.environ['FOO'] = 'baz'
    os.environ['BAR'] = 'qux'
    assert env_fallback('BAR', 'FOO') == 'baz'

    # Test with multiple values and no match
    os.environ.pop('FOO')
    assert env_fallback('BAR', 'FOO') == 'qux'

    # Test with no values
    os.environ.clear()
    try:
        env_fallback()
        assert False, "Did not raise AnsibleFallbackNotFound"
    except AnsibleFallbackNotFound as e:
        pass



# Generated at 2022-06-11 01:24:04.556763
# Unit test for function sanitize_keys
def test_sanitize_keys():
    # Boolean test
    assert sanitize_keys({"no_log": True}, [], ignore_keys=frozenset(("no_log"))) == {"no_log": True}

    # List test
    test_list = [{"no_log": True}]
    assert sanitize_keys(test_list, [], ignore_keys=frozenset(("no_log"))) == test_list

    # Dict test
    test_dict = {"no_log": True}
    assert sanitize_keys(test_dict, [], ignore_keys=frozenset(("no_log"))) == test_dict
    assert sanitize_keys(test_dict, [], ignore_keys=frozenset((u"no_log"))) == test_dict

    # Set test

# Generated at 2022-06-11 01:24:12.159379
# Unit test for function env_fallback
def test_env_fallback():
    """Verify function return expected data required by unit tests."""
    os.environ['ANSIBLE_SUCCESS_DATA'] = 'ANSIBLE_SUCCESS_DATA'
    os.environ['ANSIBLE_FOUND_DATA'] = 'ANSIBLE_FOUND_DATA'
    success_data = {'ANSIBLE_SUCCESS_DATA': 'ANSIBLE_SUCCESS_DATA'}
    found_data = {'ANSIBLE_FOUND_DATA': 'ANSIBLE_FOUND_DATA'}
    test_data = [
        [('ANSIBLE_SUCCESS_DATA',), success_data],
        [('ANSIBLE_FOUND_DATA',), found_data],
        [('ANSIBLE_NONE_DATA',), AnsibleFallbackNotFound],
    ]

# Generated at 2022-06-11 01:24:24.756962
# Unit test for function remove_values
def test_remove_values():
    # Test basic functionality
    assert remove_values('test', ['test']) == 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'
    assert remove_values(['test'], ['test']) == ['VALUE_SPECIFIED_IN_NO_LOG_PARAMETER']
    assert remove_values({'test': 'test'}, ['test']) == {'test': 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'}

    # Test recursion
    assert remove_values(['test', ['test']], ['test']) == ['VALUE_SPECIFIED_IN_NO_LOG_PARAMETER', ['VALUE_SPECIFIED_IN_NO_LOG_PARAMETER']]

# Generated at 2022-06-11 01:24:36.910699
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'user': {'type': 'str', 'fallback': (env_fallback, 'ANSIBLE_NET_USERNAME')},
        'pass': {'type': 'str', 'fallback': (env_fallback, 'ANSIBLE_NET_PASSWORD')},
        'ssh_keyfile': {'type': 'path', 'fallback': (env_fallback, 'ANSIBLE_NET_SSH_KEYFILE'), 'no_log': True}
    }
    # Input with only ssh_keyfile
    parameters = {'ssh_keyfile': '/path/to/ssh/id_rsa'}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['user'] == 'ANSIBLE_NET_USERNAME'

# Generated at 2022-06-11 01:24:48.321548
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Test with missing parameters
    argument_spec = dict(
        param1=dict(type='int', fallback=(env_fallback, 'TEST_PARAM_1')),
        param2=dict(type='dict', fallback=(env_fallback, 'TEST_PARAM_1')),
        param3=dict(type='str', fallback=(env_fallback, 'TEST_PARAM_1')),
    )
    parameters = dict(param2=dict(), param3='present')
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert 'present' not in no_log_values
    assert parameters == dict(param2=dict(), param3='present')
    assert os.environ.get('TEST_PARAM_1') is None

    # Test with present parameters
    argument

# Generated at 2022-06-11 01:24:56.530373
# Unit test for function set_fallbacks

# Generated at 2022-06-11 01:25:07.935397
# Unit test for function set_fallbacks
def test_set_fallbacks():

    # Test fallback for all params
    for fallback_strategy in [env_fallback, None]:
        argument_spec = {'param1': {'type': 'str', 'fallback': (fallback_strategy, ('param1_env',))},
                         'param2': {'type': 'str', 'fallback': (fallback_strategy, ('param2_env',))},
                         'param3': {'type': 'int', 'fallback': (fallback_strategy, (1,))}}

        parameters = {'param1': None,
                      'param2': None,
                      'param3': None}

        os.environ['param1_env'] = "UnitTestValue"

        no_log_values = set_fallbacks(argument_spec, parameters)


# Generated at 2022-06-11 01:25:15.743684
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert set_fallbacks(dict(param=dict(fallback=(env_fallback, 'TEST_FALLBACK_ENV')))
                        , dict()) == set('test-fallback-env')
    assert set_fallbacks(dict(param=dict(fallback=(env_fallback, 'TEST_FALLBACK_ENV')))
                        , dict(param='test')) == set()
    assert set_fallbacks(dict(param=dict(fallback=(env_fallback, 'TEST_FALLBACK_ENV'))
                            , param2=dict(fallback=(env_fallback, 'TEST_FALLBACK_ENV_2')))
                        , dict(param='test')) == set('test-fallback-env-2')

# Generated at 2022-06-11 01:25:58.236032
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'param': {'type': 'str', 'fallback': env_fallback, 'no_log': True}}
    parameters = {}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert len(no_log_values) == 1
    assert no_log_values.pop() == parameters['param']


# Generated at 2022-06-11 01:26:05.038206
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['TEST_ENV_VAR'] = "foo"
    assert env_fallback('TEST_ENV_VAR') == "foo"
    assert env_fallback('TEST_ENV_VAR_NOPE') == "foo"
    try:
        env_fallback('TEST_ENV_VAR_NOPE1','TEST_ENV_VAR_NOPE2')
    except AnsibleFallbackNotFound:
        pass
    else:
        assert False


# Generated at 2022-06-11 01:26:15.700303
# Unit test for function set_fallbacks
def test_set_fallbacks():
    from ansible.module_utils._text import to_text
    from ansible.parsing.yaml.objects import AnsibleMapping

# Generated at 2022-06-11 01:26:20.180860
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        required_arg=dict(type='str', required=True),
        fallback_arg=dict(type='str', fallback=(env_fallback, 'TEST_FALLBACK_ARG_ENV')),
        no_log_arg=dict(type='str', no_log=True, fallback=(env_fallback, 'TEST_NO_LOG_ARG_ENV')),
    )
    parameters = dict(required_arg='required value')
    no_log_values = set_fallbacks(argument_spec, parameters)

    assert parameters['required_arg'] == 'required value'
    assert 'TEST_FALLBACK_ARG_ENV' not in parameters
    assert 'TEST_NO_LOG_ARG_ENV' not in parameters
    assert no_log_values

# Generated at 2022-06-11 01:26:25.101280
# Unit test for function set_fallbacks
def test_set_fallbacks():
    args = {
        'path': {
            'type': 'str',
            'required': True,
        },
        'has_warning': {
            'type': 'str',
            'fallback': (env_fallback, 'WARNING'),
        },
        'has_warning_and_default': {
            'type': 'str',
            'default': 'no_warning',
            'fallback': (env_fallback, 'WARNING'),
        },
        'has_warning_default_and_no_log': {
            'type': 'str',
            'default': 'no_warning',
            'no_log': True,
            'fallback': (env_fallback, 'WARNING'),
        },
    }

    params = {}
    no_log_values = set_fallbacks(args, params)


# Generated at 2022-06-11 01:26:35.217066
# Unit test for function set_fallbacks
def test_set_fallbacks():
    os.environ['ANSIBLE_FOO'] = 'bar'
    os.environ['ANSIBLE_BAR'] = 'baz'
    assert set_fallbacks(dict(), dict()) == set()
    assert set_fallbacks({'foo': {'fallback': (env_fallback, 'ANSIBLE_FOO')}}, dict()) == {'bar'}
    assert set_fallbacks({'foo': {'fallback': (env_fallback, 'ANSIBLE_BAZ')}}, dict()) == set()
    assert set_fallbacks({'foo': {'fallback': (env_fallback, 'ANSIBLE_FOO'), 'no_log': True}}, dict()) == {'bar'}

# Generated at 2022-06-11 01:26:39.021825
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['TEST_VAR'] = 'TEST_VALUE'
    assert env_fallback('TEST_VAR') == 'TEST_VALUE'
    assert env_fallback('NOT_TEST_VAR') == 'NOT_TEST_VALUE'



# Generated at 2022-06-11 01:26:49.924043
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Test that fallbacks "env" and "required" work as expected.
    # Set parameters to an empty dictionary and specify one arg
    # in argument_spec with fallback to "required" and one without.
    # This should raise an error for the missing argument because
    # no default is specified.
    parameters = {}
    argument_spec = {
        'test_arg': {'required': False, 'type': 'str'},
        'test_required': {'fallback': (env_fallback, 'TEST_ARG'), 'type': 'str'},
    }
    with raises(AnsibleFailJson):
        set_fallbacks(argument_spec, parameters)
    assert parameters['test_required'] == 'required'

    # Test that fallback values are not added to no_log_values
    # if log_values isn

# Generated at 2022-06-11 01:26:55.988736
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'foo': {'type': 'str', 'required': True, 'fallback': (env_fallback, 'FOO')}}
    parameters = {}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert no_log_values == set()
    assert parameters['foo'] == 'FOO'
    parameters = {'foo': 'bar'}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['foo'] == 'bar'
    os.environ['FOO'] = 'foo'
    del os.environ['FOO']
    argument_spec = {'foo': {'type': 'str', 'required': True, 'fallback': (env_fallback, 'FOO', 'FOO2')}}
    parameters = {}
   

# Generated at 2022-06-11 01:27:01.885573
# Unit test for function env_fallback
def test_env_fallback():
    """Unit test for function env_fallback"""
    assert env_fallback('FOO') == os.environ['FOO']
    try:
        env_fallback('FOO', 'BAR')
    except AnsibleFallbackNotFound:
        pass
    else:
        fail("env_fallback should raise AnsibleFallbackNotFound")

# Generated at 2022-06-11 01:27:49.446621
# Unit test for function env_fallback
def test_env_fallback():
    """Test loading value from environment variable"""

    import os
    env_var = 'ANSIBLE_TEST_VAR'
    env_val = 'test value'
    os.environ.pop(env_var, None)
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback(env_var)
    # Test with value
    os.environ[env_var] = env_val
    assert env_fallback(env_var) == env_val
    # Test with non-existent value
    os.environ.pop(env_var, None)
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback(env_var)
    # Test with non-existent value and default
    default = 'default value'

# Generated at 2022-06-11 01:27:55.408883
# Unit test for function remove_values
def test_remove_values():
    assert remove_values('', []) == ''
    assert remove_values('hello', []) == 'hello'
    assert remove_values('hello secret', ['secret']) == 'hello *****'
    assert remove_values(None, ['secret']) == None
    assert remove_values('', ['secret']) == ''
    assert remove_values(42, ['secret']) == 42

    # TODO: Add additional unit tests for remove_values



# Generated at 2022-06-11 01:28:07.484068
# Unit test for function set_fallbacks
def test_set_fallbacks():
    """Test that all fallback strategies are being tested"""
    argument_spec = dict(
        a=dict(type='int', fallback=(env_fallback, 'OPT1')),
        b=dict(type='int', fallback=(env_fallback, 'OPT2')),
        c=dict(type='int', fallback=(env_fallback, dict(fallback='OPT3'))),
    )
    parameters = dict(a=None, b=None, c=None)
    os.environ['OPT1'] = '1'
    os.environ['OPT2'] = '2'
    os.environ['OPT3'] = '3'
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['a'] == 1

# Generated at 2022-06-11 01:28:12.439456
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'test_param': {'type': 'dict', 'options': {'test_param2': {'type': 'dict', 'options': {'test_param3': {'default': None}}}}}}
    parameters = {'test_param': {'test_param2': {}}}
    assert parameters == set_fallbacks(argument_spec, parameters)
# End unit tests for function set_fallbacks



# Generated at 2022-06-11 01:28:23.484256
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert set_fallbacks(dict(a=dict(type='int', fallback=(1,))), {}) == {1}
    assert set_fallbacks(dict(a=dict(type='int', fallback=(1, 2))), dict(a=1, b=2)) == set()
    assert set_fallbacks(dict(a=dict(type='int', fallback=(1, 2))), dict(b=2)) == {1}
    assert set_fallbacks(dict(a=dict(type='int', fallback=(env_fallback, 'FOO'))), {}) == {'FOO'}
    assert set_fallbacks(dict(a=dict(type='int', fallback=(env_fallback, 'FOO', 'BAR'))), {}) == {'BAR'}

# Generated at 2022-06-11 01:28:33.338768
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        "param_A": {
            "type": "str",
            "required": True,
            "fallback": (env_fallback, "TEST_ANSIBLE_PARAM_A")
        }
    }

    parameters_A = {}
    parameters_B = {"param_B": "value"}

    no_log_values = set_fallbacks(argument_spec, parameters_A)
    assert len(no_log_values) == 0
    assert len(parameters_A.keys()) == 1

    no_log_values = set_fallbacks(argument_spec, parameters_B)
    assert len(no_log_values) == 0
    assert len(parameters_B.keys()) == 1

# Dynamic imports

# Generated at 2022-06-11 01:28:44.649520
# Unit test for function set_fallbacks

# Generated at 2022-06-11 01:28:55.056085
# Unit test for function set_fallbacks
def test_set_fallbacks():
    f_arg_spec = dict(
        param=dict(type='str', fallback=(env_fallback, ['TEST_ENV_VAR']))
    )
    f_parameters = {}
    try:
        os.environ['TEST_ENV_VAR'] = 'foobar'
        set_fallbacks(f_arg_spec, f_parameters)
    finally:
        del os.environ['TEST_ENV_VAR']
    assert f_parameters == dict(param='foobar')

    g_arg_spec = dict(
        param=dict(type='str', fallback=(env_fallback, ['TEST_ENV_VAR']))
    )
    g_parameters = dict(param='baz')

# Generated at 2022-06-11 01:29:03.432262
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        arg1=dict(fallback=(env_fallback, 'ENV_ARG1')),
        arg2=dict(fallback=(env_fallback, 'ENV_ARG2')),
        arg3=dict(fallback=(env_fallback, 'ENV_ARG3')),
        arg4=dict(fallback=(env_fallback, 'ENV_ARG4')),
    )

    parameters = {'arg1': 'test'}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['arg1'] == 'test'
    assert parameters.get('arg2') is None
    assert parameters.get('arg3') is None
    assert parameters.get('arg4') is None
    assert no_log_values == set()

   

# Generated at 2022-06-11 01:29:12.942186
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'foo'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'foo'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_DEFINED', 'ANSIBLE_TEST_ENV_FALLBACK') == 'foo'
    os.environ.pop('ANSIBLE_TEST_ENV_FALLBACK')
    try:
        env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_DEFINED')
    except AnsibleFallbackNotFound as e:
        assert to_text(e) == 'could not find fallback value(s)'
    else:
        assert False, 'Failed to run test'

_FALLBACK