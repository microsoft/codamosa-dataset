

# Generated at 2022-06-16 22:49:26.862491
# Unit test for function remove_values
def test_remove_values():
    assert remove_values('test', ['test']) == 'VALUE_REMOVED'
    assert remove_values('test', ['test', 'test2']) == 'VALUE_REMOVED'
    assert remove_values('test', ['test2']) == 'test'
    assert remove_values('test', ['test2', 'test3']) == 'test'
    assert remove_values('test', ['test2', 'test3']) == 'test'
    assert remove_values('test', ['test2', 'test3']) == 'test'
    assert remove_values('test', ['test2', 'test3']) == 'test'
    assert remove_values('test', ['test2', 'test3']) == 'test'
    assert remove_values('test', ['test2', 'test3']) == 'test'
    assert remove

# Generated at 2022-06-16 22:49:33.378160
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:49:46.083129
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'foo': {'type': 'str', 'fallback': (env_fallback, 'FOO')}}
    parameters = {}
    os.environ['FOO'] = 'bar'
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['foo'] == 'bar'
    assert no_log_values == set()

    argument_spec = {'foo': {'type': 'str', 'fallback': (env_fallback, 'FOO'), 'no_log': True}}
    parameters = {}
    os.environ['FOO'] = 'bar'
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['foo'] == 'bar'
    assert no_log_values == {'bar'}


# Generated at 2022-06-16 22:49:53.344655
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    del os.environ['ANSIBLE_TEST_ENV_FALLBACK']
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('ANSIBLE_TEST_ENV_FALLBACK')



# Generated at 2022-06-16 22:50:02.612176
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:50:09.024869
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_SET') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_SET', 'ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_SET', 'ANSIBLE_TEST_ENV_FALLBACK_NOT_SET') == 'test'

# Generated at 2022-06-16 22:50:17.905612
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:50:30.775216
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:50:41.066330
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:50:51.016777
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:51:23.960912
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:51:33.832170
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:51:45.781671
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:51:50.002968
# Unit test for function remove_values
def test_remove_values():
    assert remove_values('foo', ['foo']) == 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'
    assert remove_values('foo', ['bar']) == 'foo'
    assert remove_values('foo', ['foo', 'bar']) == 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'
    assert remove_values('foo', ['foo', 'bar', 'baz']) == 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'
    assert remove_values('foo', ['foo', 'bar', 'baz']) == 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'

# Generated at 2022-06-16 22:51:56.779527
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    os.environ.pop('ANSIBLE_TEST_ENV_FALLBACK')
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'



# Generated at 2022-06-16 22:52:03.203038
# Unit test for function remove_values
def test_remove_values():
    assert remove_values('foo', ['foo']) == 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'
    assert remove_values('foo', ['bar']) == 'foo'
    assert remove_values(['foo', 'bar'], ['foo']) == ['VALUE_SPECIFIED_IN_NO_LOG_PARAMETER', 'bar']
    assert remove_values(['foo', 'bar'], ['bar']) == ['foo', 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER']
    assert remove_values(['foo', 'bar'], ['bar', 'foo']) == ['VALUE_SPECIFIED_IN_NO_LOG_PARAMETER', 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER']

# Generated at 2022-06-16 22:52:14.593586
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:52:26.077446
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:52:37.355178
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:52:39.760715
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_SET')



# Generated at 2022-06-16 22:53:19.816131
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:53:29.441408
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:53:41.839885
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:53:51.111191
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:54:03.394369
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'test_param': {
            'type': 'str',
            'fallback': (env_fallback, 'TEST_PARAM')
        }
    }
    parameters = {}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['test_param'] == os.environ['TEST_PARAM']
    assert no_log_values == set()

    argument_spec = {
        'test_param': {
            'type': 'str',
            'fallback': (env_fallback, 'TEST_PARAM'),
            'no_log': True
        }
    }
    parameters = {}
    no_log_values = set_fallbacks(argument_spec, parameters)

# Generated at 2022-06-16 22:54:12.824819
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:54:23.827274
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:54:35.900022
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_1') == 'ANSIBLE_TEST_ENV_FALLBACK_1'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_2') == 'ANSIBLE_TEST_ENV_FALLBACK_2'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_3') == 'ANSIBLE_TEST_ENV_FALLBACK_3'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_4') == 'ANSIBLE_TEST_ENV_FALLBACK_4'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_5') == 'ANSIBLE_TEST_ENV_FALLBACK_5'

# Generated at 2022-06-16 22:54:43.863305
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['TEST_ENV_FALLBACK'] = 'test'
    assert env_fallback('TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('TEST_ENV_FALLBACK_NOT_FOUND') == ''
    assert env_fallback('TEST_ENV_FALLBACK_NOT_FOUND', 'TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('TEST_ENV_FALLBACK_NOT_FOUND', 'TEST_ENV_FALLBACK_NOT_FOUND') == ''

# Generated at 2022-06-16 22:54:50.046951
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test_env_fallback'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test_env_fallback'
    del os.environ['ANSIBLE_TEST_ENV_FALLBACK']
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test_env_fallback'



# Generated at 2022-06-16 22:55:28.596602
# Unit test for function remove_values
def test_remove_values():
    assert remove_values('foo', ['foo']) == 'VALUE_REMOVED_PRIVATE_DATA'
    assert remove_values('foo', ['bar']) == 'foo'
    assert remove_values('foo', ['foo', 'bar']) == 'VALUE_REMOVED_PRIVATE_DATA'
    assert remove_values('foo', ['bar', 'foo']) == 'VALUE_REMOVED_PRIVATE_DATA'
    assert remove_values('foo', ['bar', 'foo', 'baz']) == 'VALUE_REMOVED_PRIVATE_DATA'
    assert remove_values('foo', ['bar', 'baz']) == 'foo'
    assert remove_values('foo', ['bar', 'baz', 'foo']) == 'VALUE_REMOVED_PRIVATE_DATA'

# Generated at 2022-06-16 22:55:35.465039
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    del os.environ['ANSIBLE_TEST_ENV_FALLBACK']
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'



# Generated at 2022-06-16 22:55:44.231020
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:55:54.413087
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:56:03.061709
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:56:10.723384
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    del os.environ['ANSIBLE_TEST_ENV_FALLBACK']
    try:
        env_fallback('ANSIBLE_TEST_ENV_FALLBACK')
        assert False, "env_fallback should have raised AnsibleFallbackNotFound"
    except AnsibleFallbackNotFound:
        pass



# Generated at 2022-06-16 22:56:22.528211
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:56:33.047882
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:56:45.913910
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_FOUND') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_FOUND', 'ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_FOUND', 'ANSIBLE_TEST_ENV_FALLBACK_NOT_FOUND') == 'test'

# Generated at 2022-06-16 22:56:54.459676
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:57:59.354953
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    os.environ.pop('ANSIBLE_TEST_ENV_FALLBACK')
    try:
        env_fallback('ANSIBLE_TEST_ENV_FALLBACK')
        assert False
    except AnsibleFallbackNotFound:
        pass



# Generated at 2022-06-16 22:58:10.740889
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:58:17.958002
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:58:28.894666
# Unit test for function set_fallbacks