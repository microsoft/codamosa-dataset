

# Generated at 2022-06-16 22:49:06.659577
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:49:15.675565
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'foo': {'type': 'str', 'fallback': (env_fallback, 'FOO')},
        'bar': {'type': 'str', 'fallback': (env_fallback, 'BAR')},
        'baz': {'type': 'str', 'fallback': (env_fallback, 'BAZ')},
        'qux': {'type': 'str', 'fallback': (env_fallback, 'QUX')},
    }
    parameters = {'foo': 'foo', 'bar': 'bar'}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters == {'foo': 'foo', 'bar': 'bar', 'baz': 'baz', 'qux': 'qux'}
    assert no_log_values

# Generated at 2022-06-16 22:49:26.513011
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:49:38.039259
# Unit test for function remove_values
def test_remove_values():
    assert remove_values(None, []) is None
    assert remove_values(1, []) == 1
    assert remove_values('foo', []) == 'foo'
    assert remove_values('foo', ['foo']) == 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'
    assert remove_values('foo', ['bar']) == 'foo'
    assert remove_values('foo', ['foo', 'bar']) == 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'
    assert remove_values('foo', ['bar', 'foo']) == 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'
    assert remove_values('foo', ['bar', 'foo', 'baz']) == 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'
    assert remove_

# Generated at 2022-06-16 22:49:51.318693
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:50:01.442476
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:50:06.524767
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'ANSIBLE_TEST_ENV_FALLBACK'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'ANSIBLE_TEST_ENV_FALLBACK'
    del os.environ['ANSIBLE_TEST_ENV_FALLBACK']
    try:
        env_fallback('ANSIBLE_TEST_ENV_FALLBACK')
        assert False
    except AnsibleFallbackNotFound:
        pass



# Generated at 2022-06-16 22:50:12.341406
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:50:19.375443
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:50:32.208116
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:51:04.812929
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:51:17.489867
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:51:29.175198
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_FOUND') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_FOUND', 'ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_FOUND', 'ANSIBLE_TEST_ENV_FALLBACK_NOT_FOUND') == 'test'

# Generated at 2022-06-16 22:51:41.152075
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'foo': {'type': 'str', 'fallback': (env_fallback, 'FOO')},
        'bar': {'type': 'str', 'fallback': (env_fallback, 'BAR')},
        'baz': {'type': 'str', 'fallback': (env_fallback, 'BAZ')},
        'qux': {'type': 'str', 'fallback': (env_fallback, 'QUX')},
    }
    parameters = {'foo': 'foo'}
    os.environ['BAR'] = 'bar'
    os.environ['BAZ'] = 'baz'
    os.environ['QUX'] = 'qux'
    no_log_values = set_fallbacks(argument_spec, parameters)

# Generated at 2022-06-16 22:51:50.915830
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:52:01.709538
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:52:14.158672
# Unit test for function sanitize_keys
def test_sanitize_keys():
    # Test sanitize_keys with a dictionary
    no_log_strings = ['password', 'secret']
    test_dict = {'password': 'secret', 'user': 'admin', 'password_list': ['secret', 'secret2'], 'user_list': ['admin', 'admin2']}
    test_dict_expected = {'user': 'admin', 'password_list': ['secret', 'secret2'], 'user_list': ['admin', 'admin2']}
    test_dict_result = sanitize_keys(test_dict, no_log_strings)
    assert test_dict_result == test_dict_expected

    # Test sanitize_keys with a list

# Generated at 2022-06-16 22:52:25.655385
# Unit test for function remove_values
def test_remove_values():
    assert remove_values('abc', ['a']) == 'bc'
    assert remove_values('abc', ['b']) == 'ac'
    assert remove_values('abc', ['c']) == 'ab'
    assert remove_values('abc', ['d']) == 'abc'
    assert remove_values('abc', ['a', 'b']) == 'c'
    assert remove_values('abc', ['a', 'c']) == 'b'
    assert remove_values('abc', ['b', 'c']) == 'a'
    assert remove_values('abc', ['a', 'b', 'c']) == ''
    assert remove_values('abc', ['d', 'e', 'f']) == 'abc'
    assert remove_values('abc', ['a', 'b', 'c', 'd']) == ''
    assert remove

# Generated at 2022-06-16 22:52:32.340138
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test_env_fallback'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test_env_fallback'
    del os.environ['ANSIBLE_TEST_ENV_FALLBACK']
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test_env_fallback'



# Generated at 2022-06-16 22:52:38.683727
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    del os.environ['ANSIBLE_TEST_ENV_FALLBACK']
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('ANSIBLE_TEST_ENV_FALLBACK')



# Generated at 2022-06-16 22:53:08.095714
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:53:14.833940
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:53:26.664489
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:53:39.673219
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:53:48.319965
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:54:00.533282
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:54:05.219485
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'ANSIBLE_TEST_ENV_FALLBACK'
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_FOUND')



# Generated at 2022-06-16 22:54:14.425646
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:54:25.226166
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:54:37.047220
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK', 'ANSIBLE_TEST_ENV_FALLBACK_2') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_2', 'ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_2') == 'test'

# Generated at 2022-06-16 22:55:03.330438
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:55:15.162309
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:55:26.800332
# Unit test for function sanitize_keys
def test_sanitize_keys():
    # Test sanitize_keys with a dict
    test_dict = {'key1': 'value1', 'key2': 'value2'}
    test_dict_no_log = {'key1': 'value1', 'key2': 'value2'}
    test_dict_no_log_sanitized = {'key1': 'value1', 'key2': 'value2'}
    test_dict_no_log_sanitized_ignore = {'key1': 'value1', 'key2': 'value2'}
    test_dict_no_log_sanitized_ignore_keys = {'key1': 'value1', 'key2': 'value2'}

# Generated at 2022-06-16 22:55:38.629681
# Unit test for function remove_values
def test_remove_values():
    assert remove_values('foo', ['foo']) == 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'
    assert remove_values('foo', ['bar']) == 'foo'
    assert remove_values(['foo', 'bar'], ['foo']) == ['VALUE_SPECIFIED_IN_NO_LOG_PARAMETER', 'bar']
    assert remove_values(['foo', 'bar'], ['bar']) == ['foo', 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER']
    assert remove_values(['foo', 'bar'], ['foo', 'bar']) == ['VALUE_SPECIFIED_IN_NO_LOG_PARAMETER', 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER']
    assert remove_values({'foo': 'bar'}, ['foo'])

# Generated at 2022-06-16 22:55:50.753892
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_FOUND') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_FOUND', 'ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_FOUND', 'ANSIBLE_TEST_ENV_FALLBACK_NOT_FOUND') == 'test'

# Generated at 2022-06-16 22:56:00.008509
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:56:10.862902
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:56:23.159948
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys({'a': 'b'}, ['b']) == {'a': 'b'}
    assert sanitize_keys({'a': 'b'}, ['a']) == {'_ansible_no_log_values': ['a']}
    assert sanitize_keys({'a': 'b', 'c': 'd'}, ['a']) == {'_ansible_no_log_values': ['a'], 'c': 'd'}
    assert sanitize_keys({'a': 'b', 'c': 'd'}, ['a', 'c']) == {'_ansible_no_log_values': ['a', 'c']}

# Generated at 2022-06-16 22:56:34.081815
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:56:40.735789
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    os.environ.pop('ANSIBLE_TEST_ENV_FALLBACK')
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'



# Generated at 2022-06-16 22:57:29.450279
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:57:41.812360
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:57:51.570128
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:57:55.752897
# Unit test for function remove_values
def test_remove_values():
    """Test the remove_values function"""
    # Test with a simple string
    assert remove_values('test', ['test']) == '***'

    # Test with a list of strings
    assert remove_values(['test', 'test2'], ['test']) == ['***', 'test2']

    # Test with a dictionary
    assert remove_values({'test': 'test2'}, ['test']) == {'***': 'test2'}

    # Test with a dictionary of dictionaries
    assert remove_values({'test': {'test2': 'test3'}}, ['test']) == {'***': {'test2': 'test3'}}

    # Test with a dictionary of lists

# Generated at 2022-06-16 22:58:08.001065
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:58:16.459440
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:58:27.994636
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'test_param': {
            'type': 'str',
            'fallback': (env_fallback, ['TEST_PARAM', 'TEST_PARAM_2'])
        }
    }
    parameters = {}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert 'test_param' not in parameters
    assert len(no_log_values) == 0

    os.environ['TEST_PARAM'] = 'test_value'
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['test_param'] == 'test_value'
    assert len(no_log_values) == 0

    os.environ['TEST_PARAM'] = 'test_value'