

# Generated at 2022-06-16 22:49:16.844172
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:49:24.663683
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'param1': {'type': 'str', 'fallback': (env_fallback, 'TEST_PARAM1')}}
    parameters = {}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert 'param1' in parameters
    assert parameters['param1'] == 'TEST_PARAM1'
    assert len(no_log_values) == 0

    argument_spec = {'param1': {'type': 'str', 'fallback': (env_fallback, 'TEST_PARAM1'), 'no_log': True}}
    parameters = {}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert 'param1' in parameters
    assert parameters['param1'] == 'TEST_PARAM1'

# Generated at 2022-06-16 22:49:29.358291
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    del os.environ['ANSIBLE_TEST_ENV_FALLBACK']
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('ANSIBLE_TEST_ENV_FALLBACK')



# Generated at 2022-06-16 22:49:42.528506
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:49:54.896898
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:50:07.150473
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:50:16.252151
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:50:29.129356
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:50:39.884992
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:50:49.920134
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:51:25.951125
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:51:35.047902
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:51:43.196344
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['TEST_ENV_FALLBACK'] = 'test_env_fallback'
    assert env_fallback('TEST_ENV_FALLBACK') == 'test_env_fallback'
    del os.environ['TEST_ENV_FALLBACK']
    try:
        env_fallback('TEST_ENV_FALLBACK')
    except AnsibleFallbackNotFound:
        pass
    else:
        assert False, "env_fallback should have raised AnsibleFallbackNotFound"



# Generated at 2022-06-16 22:51:49.729142
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'ANSIBLE_TEST_ENV_FALLBACK'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'ANSIBLE_TEST_ENV_FALLBACK'
    del os.environ['ANSIBLE_TEST_ENV_FALLBACK']
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'ANSIBLE_TEST_ENV_FALLBACK'



# Generated at 2022-06-16 22:52:01.208477
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:52:13.547453
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:52:25.068961
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys(
        {'a': 'b', 'c': 'd'},
        ['b', 'd']
    ) == {'a': 'b', 'c': 'd'}

    assert sanitize_keys(
        {'a': 'b', 'c': 'd'},
        ['b', 'd'],
        ignore_keys=['c']
    ) == {'a': 'b', 'c': 'd'}

    assert sanitize_keys(
        {'a': 'b', 'c': 'd'},
        ['b', 'd'],
        ignore_keys=['a']
    ) == {'a': 'b', 'c': 'd'}


# Generated at 2022-06-16 22:52:36.756947
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:52:45.501313
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys({'a': 'b', 'c': 'd'}, ['b']) == {'a': 'b', 'c': 'd'}
    assert sanitize_keys({'a': 'b', 'c': 'd'}, ['b', 'd']) == {'a': 'b', 'c': 'd'}
    assert sanitize_keys({'a': 'b', 'c': 'd'}, ['b', 'd'], ignore_keys=['c']) == {'a': 'b', 'c': 'd'}
    assert sanitize_keys({'a': 'b', 'c': 'd'}, ['b', 'd'], ignore_keys=['a']) == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-16 22:52:54.787269
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:53:28.169661
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:53:40.620695
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:53:48.937879
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:53:55.372447
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    del os.environ['ANSIBLE_TEST_ENV_FALLBACK']
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('ANSIBLE_TEST_ENV_FALLBACK')



# Generated at 2022-06-16 22:54:06.728847
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK', 'ANSIBLE_TEST_ENV_FALLBACK2') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK2', 'ANSIBLE_TEST_ENV_FALLBACK') == 'test2'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK2', 'ANSIBLE_TEST_ENV_FALLBACK3') == 'test2'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK3', 'ANSIBLE_TEST_ENV_FALLBACK2') == 'test3'

# Generated at 2022-06-16 22:54:17.774749
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Test with no fallback
    argument_spec = {'param1': {'type': 'str'}}
    parameters = {'param1': 'value1'}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert no_log_values == set()
    assert parameters == {'param1': 'value1'}

    # Test with fallback
    argument_spec = {'param1': {'type': 'str', 'fallback': (env_fallback, 'PARAM1')}}
    parameters = {}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert no_log_values == set()
    assert parameters == {'param1': 'value1'}

    # Test with fallback and no_log

# Generated at 2022-06-16 22:54:27.681375
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:54:39.925756
# Unit test for function remove_values
def test_remove_values():
    """Unit test for function remove_values"""
    # Test case 1:
    #   value: a string
    #   no_log_strings: a list of strings
    #   expected result: a string
    #   expected result: the string with no_log_strings removed
    value = 'abcdefg'
    no_log_strings = ['b', 'd']
    assert remove_values(value, no_log_strings) == 'acefg'

    # Test case 2:
    #   value: a string
    #   no_log_strings: a list of strings
    #   expected result: a string
    #   expected result: the string with no_log_strings removed
    value = 'abcdefg'
    no_log_strings = ['b', 'd', 'g']

# Generated at 2022-06-16 22:54:50.457638
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:55:00.654013
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:55:38.551123
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test_env_fallback'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test_env_fallback'
    del os.environ['ANSIBLE_TEST_ENV_FALLBACK']
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test_env_fallback'



# Generated at 2022-06-16 22:55:50.754000
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_SET') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_SET', 'ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_SET', 'ANSIBLE_TEST_ENV_FALLBACK_NOT_SET') == 'test'

# Generated at 2022-06-16 22:55:59.235397
# Unit test for function sanitize_keys

# Generated at 2022-06-16 22:56:09.747355
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:56:16.600715
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:56:27.413390
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:56:34.418761
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    del os.environ['ANSIBLE_TEST_ENV_FALLBACK']
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('ANSIBLE_TEST_ENV_FALLBACK')



# Generated at 2022-06-16 22:56:47.035617
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:56:55.136446
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:57:05.441054
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:57:50.512531
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_SET') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_SET', 'ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_SET', 'ANSIBLE_TEST_ENV_FALLBACK_NOT_SET') == 'test'

# Generated at 2022-06-16 22:57:57.485857
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys({'a': 'b', 'c': 'd'}, ['b']) == {'a': 'b', 'c': 'd'}
    assert sanitize_keys({'a': 'b', 'c': 'd'}, ['a']) == {'c': 'd'}
    assert sanitize_keys({'a': 'b', 'c': 'd'}, ['a', 'b']) == {'c': 'd'}
    assert sanitize_keys({'a': 'b', 'c': 'd'}, ['a', 'b', 'c']) == {}
    assert sanitize_keys({'a': 'b', 'c': 'd'}, ['a', 'b', 'c', 'd']) == {}

# Generated at 2022-06-16 22:58:09.260338
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:58:17.197757
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:58:28.418281
# Unit test for function set_fallbacks