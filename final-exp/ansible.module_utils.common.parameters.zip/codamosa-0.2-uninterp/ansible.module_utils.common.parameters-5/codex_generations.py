

# Generated at 2022-06-16 22:49:08.820133
# Unit test for function sanitize_keys
def test_sanitize_keys():
    # Test with a dict
    data = {'foo': 'bar', 'baz': 'qux'}
    assert sanitize_keys(data, ['bar']) == {'foo': 'bar', 'baz': 'qux'}
    assert sanitize_keys(data, ['baz']) == {'foo': 'bar', 'baz': 'qux'}
    assert sanitize_keys(data, ['foo']) == {'foo': 'bar', 'baz': 'qux'}
    assert sanitize_keys(data, ['qux']) == {'foo': 'bar', 'baz': 'qux'}
    assert sanitize_keys(data, ['bar', 'qux']) == {'foo': 'bar', 'baz': 'qux'}
    assert sanitize_

# Generated at 2022-06-16 22:49:19.701884
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:49:29.668470
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:49:42.989509
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:49:55.284953
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:50:07.236455
# Unit test for function sanitize_keys
def test_sanitize_keys():
    data = {
        'foo': 'bar',
        'baz': {
            'qux': 'quux',
            'corge': 'grault',
            'garply': {
                'waldo': 'fred',
                'plugh': 'xyzzy',
                'thud': 'bletch',
            },
        },
    }
    no_log_strings = ['bar', 'quux', 'fred', 'xyzzy']
    ignore_keys = ['baz']

# Generated at 2022-06-16 22:50:13.007161
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK', 'ANSIBLE_TEST_ENV_FALLBACK2') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK2', 'ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK2') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK3') == 'test'

# Generated at 2022-06-16 22:50:21.332077
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:50:33.857097
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys({'a': 'b', 'c': 'd'}, ['a']) == {'c': 'd'}
    assert sanitize_keys({'a': 'b', 'c': 'd'}, ['a'], ignore_keys=['c']) == {'c': 'd'}
    assert sanitize_keys({'a': 'b', 'c': 'd'}, ['a'], ignore_keys=['a']) == {'a': 'b', 'c': 'd'}
    assert sanitize_keys({'a': 'b', 'c': 'd'}, ['a'], ignore_keys=['b']) == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-16 22:50:43.030147
# Unit test for function sanitize_keys
def test_sanitize_keys():
    """Unit test for function sanitize_keys"""

    # Test with a simple dictionary
    test_dict = {'foo': 'bar', 'baz': 'qux'}
    new_dict = sanitize_keys(test_dict, ['bar'])
    assert new_dict == {'foo': 'bar', 'baz': 'qux'}

    # Test with a dictionary with a nested dictionary
    test_dict = {'foo': 'bar', 'baz': {'qux': 'quux'}}
    new_dict = sanitize_keys(test_dict, ['bar'])
    assert new_dict == {'foo': 'bar', 'baz': {'qux': 'quux'}}

    # Test with a dictionary with a nested list

# Generated at 2022-06-16 22:51:10.682352
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test_env_fallback'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test_env_fallback'
    del os.environ['ANSIBLE_TEST_ENV_FALLBACK']
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test_env_fallback'



# Generated at 2022-06-16 22:51:23.598742
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:51:33.614648
# Unit test for function sanitize_keys
def test_sanitize_keys():
    # Test sanitize_keys() with a dictionary
    test_dict = {'no_log_value': 'foo', 'log_value': 'bar'}
    assert sanitize_keys(test_dict, ['foo']) == {'_ansible_no_log_value': 'foo', 'log_value': 'bar'}

    # Test sanitize_keys() with a list
    test_list = ['no_log_value', 'log_value']
    assert sanitize_keys(test_list, ['foo']) == ['_ansible_no_log_value', 'log_value']

    # Test sanitize_keys() with a set
    test_set = {'no_log_value', 'log_value'}

# Generated at 2022-06-16 22:51:45.598106
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:51:56.827070
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:52:05.143339
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:52:16.182881
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_SET') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_SET', 'ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_SET', 'ANSIBLE_TEST_ENV_FALLBACK_NOT_SET') == 'test'

# Generated at 2022-06-16 22:52:26.572559
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys({'a': 'b'}, ['b']) == {'a': 'b'}
    assert sanitize_keys({'a': 'b'}, ['a']) == {'a': 'b'}
    assert sanitize_keys({'a': 'b'}, ['a', 'b']) == {'a': 'b'}
    assert sanitize_keys({'a': 'b'}, ['a', 'b', 'c']) == {'a': 'b'}
    assert sanitize_keys({'a': 'b'}, ['a', 'b', 'c'], ignore_keys=['a']) == {'a': 'b'}

# Generated at 2022-06-16 22:52:37.821077
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'param1': {'type': 'str', 'fallback': (env_fallback, 'PARAM1')},
        'param2': {'type': 'str', 'fallback': (env_fallback, 'PARAM2')},
        'param3': {'type': 'str', 'fallback': (env_fallback, 'PARAM3')},
        'param4': {'type': 'str', 'fallback': (env_fallback, 'PARAM4')},
        'param5': {'type': 'str', 'fallback': (env_fallback, 'PARAM5')},
    }
    parameters = {'param1': 'value1'}
    no_log_values = set_fallbacks(argument_spec, parameters)

# Generated at 2022-06-16 22:52:46.209287
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'ANSIBLE_TEST_ENV_FALLBACK'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK', 'ANSIBLE_TEST_ENV_FALLBACK_2') == 'ANSIBLE_TEST_ENV_FALLBACK'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_2', 'ANSIBLE_TEST_ENV_FALLBACK') == 'ANSIBLE_TEST_ENV_FALLBACK_2'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_2', 'ANSIBLE_TEST_ENV_FALLBACK_3') == 'ANSIBLE_TEST_ENV_FALLBACK_2'
   

# Generated at 2022-06-16 22:53:18.230995
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:53:28.448241
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK', 'ANSIBLE_TEST_ENV_FALLBACK_2') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_2', 'ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_2', 'ANSIBLE_TEST_ENV_FALLBACK_3') == 'test'

# Generated at 2022-06-16 22:53:40.861876
# Unit test for function remove_values
def test_remove_values():
    assert remove_values('foo', ['foo']) == 'VALUE_REMOVED_PRIVATE_DATA'
    assert remove_values('foo', ['bar']) == 'foo'
    assert remove_values('foo', ['foo', 'bar']) == 'VALUE_REMOVED_PRIVATE_DATA'
    assert remove_values('foo', ['foo', 'bar', 'baz']) == 'VALUE_REMOVED_PRIVATE_DATA'
    assert remove_values('foo', ['foo', 'bar', 'baz']) == 'VALUE_REMOVED_PRIVATE_DATA'
    assert remove_values('foo', ['foo', 'bar', 'baz']) == 'VALUE_REMOVED_PRIVATE_DATA'

# Generated at 2022-06-16 22:53:49.062526
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:54:01.285276
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'param1': {'type': 'str', 'fallback': (env_fallback, 'PARAM1')},
        'param2': {'type': 'str', 'fallback': (env_fallback, 'PARAM2')},
        'param3': {'type': 'str', 'fallback': (env_fallback, 'PARAM3')},
        'param4': {'type': 'str', 'fallback': (env_fallback, 'PARAM4')},
        'param5': {'type': 'str', 'fallback': (env_fallback, 'PARAM5')},
        'param6': {'type': 'str', 'fallback': (env_fallback, 'PARAM6')},
    }

    parameters = {'param1': 'value1'}

   

# Generated at 2022-06-16 22:54:10.777919
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:54:22.095773
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:54:33.146389
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_SET') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_SET', 'ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_SET', 'ANSIBLE_TEST_ENV_FALLBACK_NOT_SET') == 'test'

# Generated at 2022-06-16 22:54:42.833062
# Unit test for function remove_values

# Generated at 2022-06-16 22:54:52.059408
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:55:31.712187
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys({'a': 'b'}, ['b']) == {'a': 'b'}
    assert sanitize_keys({'a': 'b'}, ['a']) == {'_ansible_no_log_a': 'b'}
    assert sanitize_keys({'a': 'b'}, ['b'], ignore_keys=['a']) == {'a': 'b'}
    assert sanitize_keys({'a': 'b'}, ['a'], ignore_keys=['a']) == {'a': 'b'}
    assert sanitize_keys({'a': 'b'}, ['a'], ignore_keys=['_ansible_no_log_a']) == {'a': 'b'}

# Generated at 2022-06-16 22:55:42.040292
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:55:53.130505
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'param1': {'type': 'str', 'fallback': (env_fallback, 'PARAM1')},
        'param2': {'type': 'str', 'fallback': (env_fallback, 'PARAM2')},
        'param3': {'type': 'str', 'fallback': (env_fallback, 'PARAM3')},
        'param4': {'type': 'str', 'fallback': (env_fallback, 'PARAM4')},
    }
    parameters = {'param1': 'value1'}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['param1'] == 'value1'
    assert parameters['param2'] == 'value2'
    assert parameters['param3'] == 'value3'
   

# Generated at 2022-06-16 22:56:02.279911
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:56:12.717196
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:56:24.553059
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Test with no fallback
    argument_spec = {'param1': {'type': 'str'}}
    parameters = {'param1': 'value1'}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert len(no_log_values) == 0
    assert parameters['param1'] == 'value1'

    # Test with fallback
    argument_spec = {'param1': {'type': 'str', 'fallback': (env_fallback, 'PARAM1')}}
    parameters = {}
    os.environ['PARAM1'] = 'value1'
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert len(no_log_values) == 0
    assert parameters['param1'] == 'value1'

    # Test with fallback

# Generated at 2022-06-16 22:56:31.871627
# Unit test for function remove_values
def test_remove_values():
    # Test that remove_values() removes values from a dictionary
    assert remove_values({'a': 'b', 'c': 'd'}, ['b']) == {'a': '', 'c': 'd'}
    # Test that remove_values() removes values from a list
    assert remove_values(['a', 'b', 'c'], ['b']) == ['a', '', 'c']
    # Test that remove_values() removes values from a set
    assert remove_values(set(['a', 'b', 'c']), ['b']) == set(['a', '', 'c'])
    # Test that remove_values() removes values from a string
    assert remove_values('abc', ['b']) == 'ac'
    # Test that remove_values() removes values from a tuple

# Generated at 2022-06-16 22:56:38.869432
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'test_param': {
            'type': 'str',
            'fallback': (env_fallback, ['TEST_PARAM', 'TEST_PARAM_2'])
        }
    }
    parameters = {}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['test_param'] == 'test_value'
    assert no_log_values == set()



# Generated at 2022-06-16 22:56:50.453294
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:57:02.570556
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:57:45.598213
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys({'foo': 'bar', 'baz': 'qux'}, ['bar']) == {'foo': 'bar', 'baz': 'qux'}
    assert sanitize_keys({'foo': 'bar', 'baz': 'qux'}, ['bar', 'foo']) == {'baz': 'qux'}
    assert sanitize_keys({'foo': 'bar', 'baz': 'qux'}, ['bar', 'baz']) == {'foo': 'bar'}
    assert sanitize_keys({'foo': 'bar', 'baz': 'qux'}, ['bar', 'baz', 'qux']) == {}

# Generated at 2022-06-16 22:57:56.859017
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:58:02.905315
# Unit test for function sanitize_keys
def test_sanitize_keys():
    # Test with a simple dictionary
    data = {'a': 'b', 'c': 'd'}
    assert sanitize_keys(data, ['b']) == {'a': 'b', 'c': 'd'}
    assert sanitize_keys(data, ['b', 'd']) == {'a': 'b', 'c': 'd'}
    assert sanitize_keys(data, ['b', 'd'], ignore_keys=['a']) == {'a': 'b', 'c': 'd'}
    assert sanitize_keys(data, ['b', 'd'], ignore_keys=['c']) == {'a': 'b', 'c': 'd'}
    assert sanitize_keys(data, ['b', 'd'], ignore_keys=['a', 'c'])

# Generated at 2022-06-16 22:58:09.664588
# Unit test for function remove_values
def test_remove_values():
    assert remove_values(None, []) is None
    assert remove_values(1, []) == 1
    assert remove_values('foo', []) == 'foo'
    assert remove_values('foo', ['foo']) == 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'
    assert remove_values(['foo', 'bar'], ['foo']) == ['VALUE_SPECIFIED_IN_NO_LOG_PARAMETER', 'bar']
    assert remove_values(['foo', 'bar'], ['foo', 'bar']) == ['VALUE_SPECIFIED_IN_NO_LOG_PARAMETER', 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER']

# Generated at 2022-06-16 22:58:17.403934
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'param1': {'type': 'str', 'fallback': (env_fallback, 'PARAM1')},
        'param2': {'type': 'str', 'fallback': (env_fallback, 'PARAM2')},
        'param3': {'type': 'str', 'fallback': (env_fallback, 'PARAM3')},
        'param4': {'type': 'str', 'fallback': (env_fallback, 'PARAM4')},
    }
    parameters = {'param1': 'value1'}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['param1'] == 'value1'
    assert parameters['param2'] == 'value2'
    assert parameters['param3'] == 'value3'
   

# Generated at 2022-06-16 22:58:28.550389
# Unit test for function set_fallbacks