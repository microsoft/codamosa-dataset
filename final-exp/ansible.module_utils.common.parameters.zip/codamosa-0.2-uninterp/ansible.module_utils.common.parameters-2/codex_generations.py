

# Generated at 2022-06-16 22:48:59.555852
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys({'foo': 'bar', 'baz': 'qux'}, ['bar']) == {'foo': 'bar', 'baz': 'qux'}
    assert sanitize_keys({'foo': 'bar', 'baz': 'qux'}, ['bar', 'foo']) == {'foo': 'bar', 'baz': 'qux'}
    assert sanitize_keys({'foo': 'bar', 'baz': 'qux'}, ['bar', 'foo', 'baz']) == {'foo': 'bar', 'baz': 'qux'}

# Generated at 2022-06-16 22:49:08.948901
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:49:19.742174
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test_env_fallback'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test_env_fallback'
    del os.environ['ANSIBLE_TEST_ENV_FALLBACK']
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test_env_fallback'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK', 'ANSIBLE_TEST_ENV_FALLBACK') == 'test_env_fallback'

# Generated at 2022-06-16 22:49:29.704511
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:49:43.042343
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_SET') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_SET', 'ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_SET', 'ANSIBLE_TEST_ENV_FALLBACK_NOT_SET') == 'test'

# Generated at 2022-06-16 22:49:55.331325
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:50:07.312567
# Unit test for function remove_values
def test_remove_values():
    assert remove_values('foo', ['foo']) == 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'
    assert remove_values('foo', ['bar']) == 'foo'
    assert remove_values('foo', ['foo', 'bar']) == 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'
    assert remove_values('foo', ['foo', 'bar', 'baz']) == 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'
    assert remove_values('foo', ['foo', 'bar', 'baz', 'qux']) == 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'

# Generated at 2022-06-16 22:50:11.192900
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        test_param=dict(type='str', fallback=(env_fallback, 'TEST_PARAM'))
    )
    parameters = {}
    os.environ['TEST_PARAM'] = 'test_value'
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['test_param'] == 'test_value'
    assert no_log_values == set()
    del os.environ['TEST_PARAM']



# Generated at 2022-06-16 22:50:19.640057
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:50:32.462274
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys({'a': 'b', 'c': 'd'}, ['b']) == {'a': 'b', 'c': 'd'}
    assert sanitize_keys({'a': 'b', 'c': 'd'}, ['b', 'a']) == {'c': 'd'}
    assert sanitize_keys({'a': 'b', 'c': 'd'}, ['b', 'a'], ignore_keys=['c']) == {'c': 'd'}
    assert sanitize_keys({'a': 'b', 'c': 'd'}, ['b', 'a'], ignore_keys=['a']) == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-16 22:51:04.856108
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:51:17.488787
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:51:23.708057
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_FOUND') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_FOUND', 'ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_FOUND', 'ANSIBLE_TEST_ENV_FALLBACK_NOT_FOUND') == 'test'

# Generated at 2022-06-16 22:51:33.686686
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:51:45.643254
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:51:56.919877
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:52:03.286893
# Unit test for function remove_values
def test_remove_values():
    assert remove_values('foo', ['foo']) == 'VALUE_REMOVED_PRIVATE_DATA'
    assert remove_values('foo', ['bar']) == 'foo'
    assert remove_values('foo', ['foo', 'bar']) == 'VALUE_REMOVED_PRIVATE_DATA'
    assert remove_values('foo', ['foo', 'bar'], 'baz') == 'VALUE_REMOVED_PRIVATE_DATA'
    assert remove_values('foo', ['foo', 'bar'], 'baz', 'foo') == 'VALUE_REMOVED_PRIVATE_DATA'
    assert remove_values('foo', ['foo', 'bar'], 'baz', 'foo', 'bar') == 'VALUE_REMOVED_PRIVATE_DATA'

# Generated at 2022-06-16 22:52:14.637067
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    os.environ.pop('ANSIBLE_TEST_ENV_FALLBACK')
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK', 'ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK', 'ANSIBLE_TEST_ENV_FALLBACK', 'ANSIBLE_TEST_ENV_FALLBACK') == 'test'

# Generated at 2022-06-16 22:52:22.851726
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    os.environ.pop('ANSIBLE_TEST_ENV_FALLBACK')
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('ANSIBLE_TEST_ENV_FALLBACK')



# Generated at 2022-06-16 22:52:35.434673
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys({'a': 'b'}, ['b']) == {'a': 'b'}
    assert sanitize_keys({'a': 'b'}, ['a']) == {'a': 'b'}
    assert sanitize_keys({'a': 'b'}, ['b'], ignore_keys=['a']) == {'a': 'b'}
    assert sanitize_keys({'a': 'b'}, ['a'], ignore_keys=['a']) == {'a': 'b'}
    assert sanitize_keys({'a': 'b'}, ['a'], ignore_keys=['b']) == {'a': 'b'}

# Generated at 2022-06-16 22:53:03.167482
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'foo': {'type': 'str', 'fallback': (env_fallback, ['FOO'])},
        'bar': {'type': 'str', 'fallback': (env_fallback, ['BAR'])},
        'baz': {'type': 'str', 'fallback': (env_fallback, ['BAZ'])},
    }
    parameters = {}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert no_log_values == set()
    assert parameters == {}

    os.environ['FOO'] = 'foo'
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert no_log_values == set()
    assert parameters == {'foo': 'foo'}


# Generated at 2022-06-16 22:53:11.602141
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:53:23.873285
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:53:36.348118
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_FOUND') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_FOUND', 'ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_FOUND', 'ANSIBLE_TEST_ENV_FALLBACK_NOT_FOUND') == 'test'

# Generated at 2022-06-16 22:53:46.365844
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:53:57.154431
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:54:07.895585
# Unit test for function remove_values
def test_remove_values():
    assert remove_values('abc', ['abc']) == '***'
    assert remove_values('abc', ['abc', 'def']) == '***'
    assert remove_values('abc', ['def']) == 'abc'
    assert remove_values('abc', []) == 'abc'
    assert remove_values('abc', ['a']) == '***'
    assert remove_values('abc', ['b']) == 'a**'
    assert remove_values('abc', ['c']) == 'ab*'
    assert remove_values('abc', ['d']) == 'abc'
    assert remove_values('abc', ['ab']) == '***'
    assert remove_values('abc', ['bc']) == 'a**'
    assert remove_values('abc', ['ac']) == '*b*'

# Generated at 2022-06-16 22:54:18.669868
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:54:23.207492
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test_env_fallback'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test_env_fallback'
    del os.environ['ANSIBLE_TEST_ENV_FALLBACK']
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test_env_fallback'



# Generated at 2022-06-16 22:54:31.138248
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:55:01.717051
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'foo': {'type': 'str', 'fallback': (env_fallback, 'FOO')},
        'bar': {'type': 'str', 'fallback': (env_fallback, 'BAR')},
        'baz': {'type': 'str', 'fallback': (env_fallback, 'BAZ')},
        'qux': {'type': 'str', 'fallback': (env_fallback, 'QUX')},
    }
    parameters = {'foo': 'foo'}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters == {'foo': 'foo', 'bar': 'bar', 'baz': 'baz', 'qux': 'qux'}
    assert no_log_values == set()



# Generated at 2022-06-16 22:55:13.917823
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:55:22.445270
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'foo'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'foo'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_FOUND') == 'foo'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_FOUND', 'ANSIBLE_TEST_ENV_FALLBACK') == 'foo'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_FOUND', 'ANSIBLE_TEST_ENV_FALLBACK_NOT_FOUND') == 'foo'

# Generated at 2022-06-16 22:55:33.750092
# Unit test for function sanitize_keys
def test_sanitize_keys():
    """Test sanitize_keys function"""
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.collections import ImmutableList
    from ansible.module_utils.common.collections import ImmutableSet
    from ansible.module_utils.common.collections import ImmutableSequence
    from ansible.module_utils.common.collections import ImmutableMapping
    from ansible.module_utils.common.collections import is_immutable_mapping
    from ansible.module_utils.common.collections import is_immutable_sequence
    from ansible.module_utils.common.collections import is_immutable_set
    from ansible.module_utils.common.collections import is_immutable

# Generated at 2022-06-16 22:55:43.311838
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys({'a': 'b', 'c': 'd'}, ['b']) == {'a': 'b', 'c': 'd'}
    assert sanitize_keys({'a': 'b', 'c': 'd'}, ['b', 'd']) == {'a': 'b', 'c': 'd'}
    assert sanitize_keys({'a': 'b', 'c': 'd'}, ['b', 'd'], ignore_keys=['c']) == {'a': 'b', 'c': 'd'}
    assert sanitize_keys({'a': 'b', 'c': 'd'}, ['b', 'd'], ignore_keys=['a']) == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-16 22:55:53.735521
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:56:02.804255
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:56:13.139375
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:56:24.920769
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:56:36.680520
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:57:07.895213
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:57:12.240237
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test_env_fallback'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test_env_fallback'
    del os.environ['ANSIBLE_TEST_ENV_FALLBACK']
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test_env_fallback'



# Generated at 2022-06-16 22:57:23.267866
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:57:31.618561
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:57:43.675352
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:57:54.108706
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:58:06.406611
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK', 'ANSIBLE_TEST_ENV_FALLBACK2') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK2', 'ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK2') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK2', 'ANSIBLE_TEST_ENV_FALLBACK2') == 'test'
    assert env

# Generated at 2022-06-16 22:58:12.882566
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test_env_fallback'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test_env_fallback'
    os.environ.pop('ANSIBLE_TEST_ENV_FALLBACK')
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('ANSIBLE_TEST_ENV_FALLBACK')



# Generated at 2022-06-16 22:58:25.048012
# Unit test for function set_fallbacks