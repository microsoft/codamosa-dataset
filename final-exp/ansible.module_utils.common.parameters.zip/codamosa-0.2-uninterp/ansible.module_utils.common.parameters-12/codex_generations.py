

# Generated at 2022-06-16 22:49:33.048403
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:49:45.923140
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:49:57.826055
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:50:05.588676
# Unit test for function remove_values
def test_remove_values():
    assert remove_values('hello', ['hello']) == 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'
    assert remove_values('hello', ['world']) == 'hello'
    assert remove_values('hello', []) == 'hello'
    assert remove_values(['hello', 'world'], ['hello']) == ['VALUE_SPECIFIED_IN_NO_LOG_PARAMETER', 'world']
    assert remove_values(['hello', 'world'], ['world']) == ['hello', 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER']
    assert remove_values(['hello', 'world'], ['hello', 'world']) == ['VALUE_SPECIFIED_IN_NO_LOG_PARAMETER', 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER']

# Generated at 2022-06-16 22:50:10.445428
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:50:19.104520
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:50:31.899527
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK', 'ANSIBLE_TEST_ENV_FALLBACK_2') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_2', 'ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_2') == 'test'
    del os.environ['ANSIBLE_TEST_ENV_FALLBACK']
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK')

# Generated at 2022-06-16 22:50:41.867355
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:50:51.377077
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:51:03.695005
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:51:35.405774
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:51:46.753180
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:51:58.349902
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:52:05.972127
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:52:16.654192
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK', 'ANSIBLE_TEST_ENV_FALLBACK2') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK2', 'ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK2') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK2', 'ANSIBLE_TEST_ENV_FALLBACK2') == 'test'
    assert env

# Generated at 2022-06-16 22:52:24.348947
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    del os.environ['ANSIBLE_TEST_ENV_FALLBACK']
    try:
        env_fallback('ANSIBLE_TEST_ENV_FALLBACK')
        assert False, "env_fallback should have raised AnsibleFallbackNotFound"
    except AnsibleFallbackNotFound:
        pass



# Generated at 2022-06-16 22:52:36.659583
# Unit test for function remove_values
def test_remove_values():
    assert remove_values('foo', ['foo']) == 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'
    assert remove_values('foo', ['bar']) == 'foo'
    assert remove_values('foo', ['foo', 'bar']) == 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'
    assert remove_values('foo', ['bar', 'foo']) == 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'
    assert remove_values('foo', ['foo', 'foo']) == 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'
    assert remove_values('foo', ['foo', 'foo', 'foo']) == 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'

# Generated at 2022-06-16 22:52:45.434271
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'foo'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'foo'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_FOUND') == 'foo'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_FOUND', 'ANSIBLE_TEST_ENV_FALLBACK') == 'foo'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_FOUND', 'ANSIBLE_TEST_ENV_FALLBACK_NOT_FOUND') == 'foo'

# Generated at 2022-06-16 22:52:54.654589
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:53:05.359229
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:53:39.420472
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:53:47.044916
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys({'a': 'b'}, ['a']) == {'****': 'b'}
    assert sanitize_keys({'a': 'b'}, ['a'], ignore_keys=['a']) == {'a': 'b'}
    assert sanitize_keys({'a': 'b'}, ['a'], ignore_keys=['b']) == {'****': 'b'}
    assert sanitize_keys({'a': 'b'}, ['a'], ignore_keys=['a', 'b']) == {'a': 'b'}
    assert sanitize_keys({'a': 'b'}, ['a'], ignore_keys=['b', 'a']) == {'a': 'b'}

# Generated at 2022-06-16 22:53:58.362092
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys({'a': 'b', 'c': 'd'}, ['b']) == {'a': 'b', 'c': 'd'}
    assert sanitize_keys({'a': 'b', 'c': 'd'}, ['d']) == {'a': 'b', 'c': 'd'}
    assert sanitize_keys({'a': 'b', 'c': 'd'}, ['a']) == {'a': 'b', 'c': 'd'}
    assert sanitize_keys({'a': 'b', 'c': 'd'}, ['c']) == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-16 22:54:03.485018
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['TEST_ENV_FALLBACK'] = 'test'
    assert env_fallback('TEST_ENV_FALLBACK') == 'test'
    del os.environ['TEST_ENV_FALLBACK']
    assert env_fallback('TEST_ENV_FALLBACK') == 'test'



# Generated at 2022-06-16 22:54:09.762400
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test_env_fallback'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test_env_fallback'
    del os.environ['ANSIBLE_TEST_ENV_FALLBACK']
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('ANSIBLE_TEST_ENV_FALLBACK')



# Generated at 2022-06-16 22:54:21.052927
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:54:30.596936
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'param1': {'type': 'str', 'fallback': (env_fallback, 'TEST_PARAM1')}}
    parameters = {}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['param1'] == 'TEST_PARAM1'
    assert no_log_values == set()

    argument_spec = {'param1': {'type': 'str', 'fallback': (env_fallback, 'TEST_PARAM1'), 'no_log': True}}
    parameters = {}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['param1'] == 'TEST_PARAM1'
    assert no_log_values == set(['TEST_PARAM1'])


# Generated at 2022-06-16 22:54:33.358208
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    del os.environ['ANSIBLE_TEST_ENV_FALLBACK']
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'



# Generated at 2022-06-16 22:54:42.939145
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:54:52.113890
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys({"foo": "bar", "baz": "qux"}, ["bar"]) == {"foo": "bar", "baz": "qux"}
    assert sanitize_keys({"foo": "bar", "baz": "qux"}, ["bar", "foo"]) == {"foo": "bar", "baz": "qux"}
    assert sanitize_keys({"foo": "bar", "baz": "qux"}, ["bar", "foo", "baz"]) == {"foo": "bar", "baz": "qux"}
    assert sanitize_keys({"foo": "bar", "baz": "qux"}, ["bar", "foo", "baz", "qux"]) == {"foo": "bar", "baz": "qux"}

# Generated at 2022-06-16 22:55:24.682777
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:55:36.306258
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:55:44.722431
# Unit test for function remove_values
def test_remove_values():
    """
    Test the remove_values function.
    """
    # Test with a string
    assert remove_values('test', ['test']) == '***'
    # Test with a list
    assert remove_values(['test'], ['test']) == ['***']
    # Test with a dict
    assert remove_values({'test': 'test'}, ['test']) == {'test': '***'}
    # Test with a list of dicts
    assert remove_values([{'test': 'test'}], ['test']) == [{'test': '***'}]
    # Test with a dict of dicts
    assert remove_values({'test': {'test': 'test'}}, ['test']) == {'test': {'test': '***'}}
    # Test with a dict of lists
    assert remove_

# Generated at 2022-06-16 22:55:54.868814
# Unit test for function remove_values
def test_remove_values():
    assert remove_values(
        {'a': 'b', 'c': 'd', 'e': 'f'},
        ['b', 'd']
    ) == {'a': '', 'c': '', 'e': 'f'}

    assert remove_values(
        {'a': 'b', 'c': 'd', 'e': 'f'},
        ['b', 'd', 'f']
    ) == {'a': '', 'c': '', 'e': ''}

    assert remove_values(
        {'a': 'b', 'c': 'd', 'e': 'f'},
        ['b', 'd', 'f', 'g']
    ) == {'a': '', 'c': '', 'e': ''}


# Generated at 2022-06-16 22:56:03.594920
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:56:13.707536
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:56:25.409605
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:56:37.339144
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:56:49.686054
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:57:02.106293
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('FOO') == os.environ['FOO']
    assert env_fallback('FOO', 'BAR') == os.environ['FOO']
    assert env_fallback('FOO', 'BAR') == os.environ['FOO']
    assert env_fallback('FOO', 'BAR') == os.environ['FOO']
    assert env_fallback('FOO', 'BAR') == os.environ['FOO']
    assert env_fallback('FOO', 'BAR') == os.environ['FOO']
    assert env_fallback('FOO', 'BAR') == os.environ['FOO']
    assert env_fallback('FOO', 'BAR') == os.environ['FOO']

# Generated at 2022-06-16 22:57:32.203554
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:57:38.073263
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    del os.environ['ANSIBLE_TEST_ENV_FALLBACK']
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'



# Generated at 2022-06-16 22:57:49.235538
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:58:00.530966
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:58:11.667063
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:58:23.779712
# Unit test for function remove_values
def test_remove_values():
    assert remove_values('foo', ['foo']) == 'VALUE_REMOVED_PRIVATE_DATA'
    assert remove_values('foo', ['foo', 'bar']) == 'VALUE_REMOVED_PRIVATE_DATA'
    assert remove_values('foo', ['bar']) == 'foo'
    assert remove_values('foo', ['f', 'o']) == 'VALUE_REMOVED_PRIVATE_DATA'
    assert remove_values('foo', ['f', 'o', 'o']) == 'VALUE_REMOVED_PRIVATE_DATA'
    assert remove_values('foo', ['f', 'o', 'o', 'bar']) == 'VALUE_REMOVED_PRIVATE_DATA'