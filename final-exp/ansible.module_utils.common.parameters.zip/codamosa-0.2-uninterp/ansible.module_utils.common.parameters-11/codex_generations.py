

# Generated at 2022-06-16 22:49:07.509272
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:49:12.930179
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    del os.environ['ANSIBLE_TEST_ENV_FALLBACK']
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('ANSIBLE_TEST_ENV_FALLBACK')



# Generated at 2022-06-16 22:49:24.376289
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:49:32.259483
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:49:45.055164
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'test_param': {
            'type': 'str',
            'fallback': (env_fallback, ['TEST_PARAM']),
        }
    }
    parameters = {}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['test_param'] == os.environ['TEST_PARAM']
    assert no_log_values == set()

    argument_spec = {
        'test_param': {
            'type': 'str',
            'fallback': (env_fallback, ['TEST_PARAM']),
            'no_log': True,
        }
    }
    parameters = {}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['test_param'] == os.en

# Generated at 2022-06-16 22:49:56.946500
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:50:05.054277
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'param1': {'type': 'str', 'fallback': (env_fallback, 'PARAM1')},
        'param2': {'type': 'str', 'fallback': (env_fallback, 'PARAM2')},
        'param3': {'type': 'str', 'fallback': (env_fallback, 'PARAM3')},
        'param4': {'type': 'str', 'fallback': (env_fallback, 'PARAM4')},
        'param5': {'type': 'str', 'fallback': (env_fallback, 'PARAM5')},
    }
    parameters = {'param1': 'value1'}
    no_log_values = set_fallbacks(argument_spec, parameters)

# Generated at 2022-06-16 22:50:08.530872
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_VAR'] = 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_VAR') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_VAR_NOT_SET') == 'test'
    os.environ.pop('ANSIBLE_TEST_ENV_VAR')
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('ANSIBLE_TEST_ENV_VAR')



# Generated at 2022-06-16 22:50:17.427286
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'param1': {'type': 'str', 'fallback': (env_fallback, 'TEST_PARAM1')},
        'param2': {'type': 'str', 'fallback': (env_fallback, 'TEST_PARAM2')},
        'param3': {'type': 'str', 'fallback': (env_fallback, 'TEST_PARAM3')},
        'param4': {'type': 'str', 'fallback': (env_fallback, 'TEST_PARAM4')},
    }
    parameters = {
        'param1': 'value1',
        'param2': 'value2',
        'param3': 'value3',
    }
    no_log_values = set_fallbacks(argument_spec, parameters)

# Generated at 2022-06-16 22:50:30.370125
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:51:02.093276
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:51:10.283915
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:51:23.341196
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:51:33.419947
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:51:45.411799
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_NET_USERNAME'] = 'test_user'
    assert env_fallback('ANSIBLE_NET_USERNAME') == 'test_user'
    del os.environ['ANSIBLE_NET_USERNAME']
    assert env_fallback('ANSIBLE_NET_USERNAME') == 'test_user'
    assert env_fallback('ANSIBLE_NET_USERNAME', 'ANSIBLE_NET_USERNAME') == 'test_user'
    assert env_fallback('ANSIBLE_NET_USERNAME', 'ANSIBLE_NET_PASSWORD') == 'test_user'
    assert env_fallback('ANSIBLE_NET_USERNAME', 'ANSIBLE_NET_PASSWORD', 'ANSIBLE_NET_USERNAME') == 'test_user'

# Generated at 2022-06-16 22:51:53.506961
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_FOUND') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_FOUND', 'ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_FOUND', 'ANSIBLE_TEST_ENV_FALLBACK_NOT_FOUND') == 'test'

# Generated at 2022-06-16 22:52:03.308737
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'foo'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'foo'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK', 'ANSIBLE_TEST_ENV_FALLBACK2') == 'foo'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK2', 'ANSIBLE_TEST_ENV_FALLBACK') == 'foo'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK2') == 'foo'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK2', 'ANSIBLE_TEST_ENV_FALLBACK3') == 'foo'
    assert env

# Generated at 2022-06-16 22:52:14.678911
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:52:26.113029
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:52:33.260888
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:53:03.979118
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:53:12.553344
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:53:24.880592
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:53:37.327026
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:53:43.903410
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:53:53.786052
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:54:05.710819
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys({'a': 'b', 'c': 'd'}, ['b']) == {'a': 'b', 'c': 'd'}
    assert sanitize_keys({'a': 'b', 'c': 'd'}, ['b', 'd']) == {'a': 'b', 'c': 'd'}
    assert sanitize_keys({'a': 'b', 'c': 'd'}, ['b', 'd'], ignore_keys=['c']) == {'a': 'b', 'c': 'd'}
    assert sanitize_keys({'a': 'b', 'c': 'd'}, ['b', 'd'], ignore_keys=['a']) == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-16 22:54:17.623770
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'param1': {'type': 'str', 'fallback': (env_fallback, ['PARAM1'])},
        'param2': {'type': 'str', 'fallback': (env_fallback, ['PARAM2'])},
        'param3': {'type': 'str', 'fallback': (env_fallback, ['PARAM3'])},
        'param4': {'type': 'str', 'fallback': (env_fallback, ['PARAM4'])},
        'param5': {'type': 'str', 'fallback': (env_fallback, ['PARAM5'])},
    }
    parameters = {'param1': 'value1'}
    no_log_values = set_fallbacks(argument_spec, parameters)

# Generated at 2022-06-16 22:54:27.569744
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:54:39.826897
# Unit test for function sanitize_keys
def test_sanitize_keys():
    # Test sanitize_keys
    assert sanitize_keys({'a': 'b'}, ['b']) == {'a': 'b'}
    assert sanitize_keys({'a': 'b'}, ['a']) == {'a': 'b'}
    assert sanitize_keys({'a': 'b'}, ['a', 'b']) == {'a': 'b'}
    assert sanitize_keys({'a': 'b'}, ['a', 'b'], ignore_keys=['a']) == {'a': 'b'}
    assert sanitize_keys({'a': 'b'}, ['a', 'b'], ignore_keys=['b']) == {'a': 'b'}

# Generated at 2022-06-16 22:55:38.944131
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:55:50.844023
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:55:59.300759
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:56:05.102883
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test_env_fallback'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test_env_fallback'
    del os.environ['ANSIBLE_TEST_ENV_FALLBACK']
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test_env_fallback'



# Generated at 2022-06-16 22:56:14.716805
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:56:26.174603
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:56:38.712826
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:56:50.324559
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:57:02.489089
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:57:10.591468
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('foo') == os.environ['foo']
    assert env_fallback('foo', 'bar') == os.environ['foo']
    assert env_fallback('foo', 'bar') == os.environ['foo']
    assert env_fallback('foo', 'bar', 'baz') == os.environ['foo']
    assert env_fallback('foo', 'bar', 'baz') == os.environ['foo']
    assert env_fallback('foo', 'bar', 'baz') == os.environ['foo']
    assert env_fallback('foo', 'bar', 'baz') == os.environ['foo']
    assert env_fallback('foo', 'bar', 'baz') == os.environ['foo']

# Generated at 2022-06-16 22:58:14.874004
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:58:27.182266
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_VAR'] = 'test'
    assert env_fallback('ANSIBLE_TEST_VAR') == 'test'
    assert env_fallback('ANSIBLE_TEST_VAR', 'ANSIBLE_TEST_VAR2') == 'test'
    assert env_fallback('ANSIBLE_TEST_VAR2', 'ANSIBLE_TEST_VAR') == 'test'
    assert env_fallback('ANSIBLE_TEST_VAR2') == 'ANSIBLE_TEST_VAR2'
    assert env_fallback('ANSIBLE_TEST_VAR2', 'ANSIBLE_TEST_VAR2') == 'ANSIBLE_TEST_VAR2'