

# Generated at 2022-06-16 22:49:15.595048
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:49:26.428976
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_SET') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_SET', 'ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_SET', 'ANSIBLE_TEST_ENV_FALLBACK_NOT_SET') == 'test'

# Generated at 2022-06-16 22:49:33.086560
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys({'a': 'b', 'c': 'd'}, ['a']) == {'c': 'd'}
    assert sanitize_keys({'a': 'b', 'c': 'd'}, ['a'], ignore_keys=['c']) == {'c': 'd'}
    assert sanitize_keys({'a': 'b', 'c': 'd'}, ['a'], ignore_keys=['a']) == {'a': 'b', 'c': 'd'}
    assert sanitize_keys({'a': 'b', 'c': 'd'}, ['a'], ignore_keys=['a', 'c']) == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-16 22:49:40.987920
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test_env_fallback'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test_env_fallback'
    del os.environ['ANSIBLE_TEST_ENV_FALLBACK']
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('ANSIBLE_TEST_ENV_FALLBACK')



# Generated at 2022-06-16 22:49:53.944582
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV'] = 'test'
    assert env_fallback('ANSIBLE_TEST_ENV') == 'test'
    del os.environ['ANSIBLE_TEST_ENV']
    assert env_fallback('ANSIBLE_TEST_ENV') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV', 'ANSIBLE_TEST_ENV') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV', 'ANSIBLE_TEST_ENV', 'ANSIBLE_TEST_ENV') == 'test'

# Generated at 2022-06-16 22:50:03.046785
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:50:09.344157
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:50:14.795484
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_SET') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_SET', 'ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_SET', 'ANSIBLE_TEST_ENV_FALLBACK_NOT_SET') == 'test'

# Generated at 2022-06-16 22:50:25.750771
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:50:37.828809
# Unit test for function remove_values
def test_remove_values():
    assert remove_values(
        {'a': 'b', 'c': {'d': 'e', 'f': 'g'}},
        no_log_strings=['b', 'e']
    ) == {'a': '', 'c': {'d': '', 'f': 'g'}}

    assert remove_values(
        {'a': 'b', 'c': {'d': 'e', 'f': 'g'}},
        no_log_strings=['b', 'e', 'g']
    ) == {'a': '', 'c': {'d': '', 'f': ''}}


# Generated at 2022-06-16 22:51:19.423068
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys({'a': 'b', 'c': 'd'}, ['b']) == {'a': 'b', 'c': 'd'}
    assert sanitize_keys({'a': 'b', 'c': 'd'}, ['b', 'd']) == {'a': 'b', 'c': 'd'}
    assert sanitize_keys({'a': 'b', 'c': 'd'}, ['b', 'c']) == {'a': 'b', 'c': 'd'}
    assert sanitize_keys({'a': 'b', 'c': 'd'}, ['b', 'd'], ignore_keys=['c']) == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-16 22:51:30.571361
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:51:42.629491
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:51:48.940642
# Unit test for function remove_values
def test_remove_values():
    assert remove_values('foo', ['foo']) == 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'
    assert remove_values('foo', ['bar']) == 'foo'
    assert remove_values('foo', ['foo', 'bar']) == 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'
    assert remove_values('foo', ['foo', 'bar', 'baz']) == 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'
    assert remove_values('foo', ['foo', 'bar', 'baz', 'qux']) == 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'

# Generated at 2022-06-16 22:52:00.433519
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV'] = 'test_env_fallback'
    assert env_fallback('ANSIBLE_TEST_ENV') == 'test_env_fallback'
    del os.environ['ANSIBLE_TEST_ENV']
    assert env_fallback('ANSIBLE_TEST_ENV') == 'test_env_fallback'
    assert env_fallback('ANSIBLE_TEST_ENV', 'ANSIBLE_TEST_ENV2') == 'test_env_fallback'
    assert env_fallback('ANSIBLE_TEST_ENV2') == 'test_env_fallback'
    assert env_fallback('ANSIBLE_TEST_ENV2', 'ANSIBLE_TEST_ENV') == 'test_env_fallback'
    assert env_

# Generated at 2022-06-16 22:52:12.712206
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:52:21.132801
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:52:33.881541
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:52:43.496253
# Unit test for function remove_values
def test_remove_values():
    assert remove_values(1, []) == 1
    assert remove_values('foo', ['foo']) == '**'
    assert remove_values('foo', ['foo', 'bar']) == '**'
    assert remove_values('foo', ['bar']) == 'foo'
    assert remove_values('foo', ['f']) == '**'
    assert remove_values('foo', ['o']) == 'f**'
    assert remove_values('foo', ['oo']) == 'f*'
    assert remove_values('foo', ['fo']) == '**'
    assert remove_values('foo', ['foo', 'bar']) == '**'
    assert remove_values('foo', ['foo', 'bar', 'baz']) == '**'

# Generated at 2022-06-16 22:52:50.582953
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'ANSIBLE_TEST_ENV_FALLBACK'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'ANSIBLE_TEST_ENV_FALLBACK'
    del os.environ['ANSIBLE_TEST_ENV_FALLBACK']
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'ANSIBLE_TEST_ENV_FALLBACK'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK', 'ANSIBLE_TEST_ENV_FALLBACK') == 'ANSIBLE_TEST_ENV_FALLBACK'

# Generated at 2022-06-16 22:53:27.016904
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'param1': {'type': 'str', 'fallback': (env_fallback, 'TEST_PARAM1')},
        'param2': {'type': 'str', 'fallback': (env_fallback, 'TEST_PARAM2')},
        'param3': {'type': 'str', 'fallback': (env_fallback, 'TEST_PARAM3')},
        'param4': {'type': 'str', 'fallback': (env_fallback, 'TEST_PARAM4')},
        'param5': {'type': 'str', 'fallback': (env_fallback, 'TEST_PARAM5')},
    }
    parameters = {'param1': 'value1'}

# Generated at 2022-06-16 22:53:39.999870
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:53:45.582348
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test_env_fallback'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test_env_fallback'
    del os.environ['ANSIBLE_TEST_ENV_FALLBACK']
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test_env_fallback'



# Generated at 2022-06-16 22:53:56.208698
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:54:07.249371
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:54:16.014932
# Unit test for function remove_values
def test_remove_values():
    assert remove_values('foo', ['foo']) == 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'
    assert remove_values('foo', ['bar']) == 'foo'
    assert remove_values(['foo', 'bar'], ['foo']) == ['VALUE_SPECIFIED_IN_NO_LOG_PARAMETER', 'bar']
    assert remove_values(['foo', 'bar'], ['bar']) == ['foo', 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER']
    assert remove_values(['foo', 'bar'], ['foo', 'bar']) == ['VALUE_SPECIFIED_IN_NO_LOG_PARAMETER', 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER']

# Generated at 2022-06-16 22:54:23.337934
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys({'a': 'b', 'c': 'd'}, ['b']) == {'a': 'b', 'c': 'd'}
    assert sanitize_keys({'a': 'b', 'c': 'd'}, ['b', 'd']) == {'a': 'b', 'c': 'd'}
    assert sanitize_keys({'a': 'b', 'c': 'd'}, ['b', 'd'], ignore_keys=['a']) == {'a': 'b', 'c': 'd'}
    assert sanitize_keys({'a': 'b', 'c': 'd'}, ['b', 'd'], ignore_keys=['c']) == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-16 22:54:35.673760
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:54:43.757370
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'foo': {'type': 'str', 'fallback': (env_fallback, 'FOO')},
        'bar': {'type': 'str', 'fallback': (env_fallback, 'BAR')},
        'baz': {'type': 'str', 'fallback': (env_fallback, 'BAZ')},
        'qux': {'type': 'str', 'fallback': (env_fallback, 'QUX')},
    }
    parameters = {}
    os.environ['FOO'] = 'foo'
    os.environ['BAR'] = 'bar'
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['foo'] == 'foo'
    assert parameters['bar'] == 'bar'

# Generated at 2022-06-16 22:54:52.451306
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:55:26.822383
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:55:38.629656
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:55:50.753918
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:55:59.235608
# Unit test for function sanitize_keys
def test_sanitize_keys():
    # Test with a dict
    data = {'foo': 'bar', 'baz': 'qux'}
    new_data = sanitize_keys(data, ['bar'])
    assert new_data == {'foo': 'bar', 'baz': 'qux'}

    # Test with a list
    data = ['foo', 'bar', 'baz']
    new_data = sanitize_keys(data, ['bar'])
    assert new_data == ['foo', 'bar', 'baz']

    # Test with a set
    data = set(['foo', 'bar', 'baz'])
    new_data = sanitize_keys(data, ['bar'])
    assert new_data == set(['foo', 'bar', 'baz'])

    # Test with a dict containing a dict

# Generated at 2022-06-16 22:56:05.379945
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test_env_fallback'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test_env_fallback'
    del os.environ['ANSIBLE_TEST_ENV_FALLBACK']
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('ANSIBLE_TEST_ENV_FALLBACK')



# Generated at 2022-06-16 22:56:14.862381
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:56:26.298390
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:56:38.916057
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'test_param': {
            'type': 'str',
            'fallback': (env_fallback, ['TEST_PARAM']),
        }
    }
    parameters = {}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert no_log_values == set()
    assert parameters == {}

    os.environ['TEST_PARAM'] = 'test_value'
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert no_log_values == set()
    assert parameters == {'test_param': 'test_value'}


# Generated at 2022-06-16 22:56:50.494241
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    os.environ.pop('ANSIBLE_TEST_ENV_FALLBACK')
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK', 'ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK', 'ANSIBLE_TEST_ENV_FALLBACK', 'ANSIBLE_TEST_ENV_FALLBACK') == 'test'

# Generated at 2022-06-16 22:56:57.091956
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    del os.environ['ANSIBLE_TEST_ENV_FALLBACK']
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'



# Generated at 2022-06-16 22:57:49.099894
# Unit test for function sanitize_keys
def test_sanitize_keys():
    # Test for sanitize_keys
    no_log_strings = ['password', 'secret', 'passwd', 'authorization', 'api_key', 'apikey', 'access_token']
    ignore_keys = ['ansible_facts']
    data = {
        'password': 'secret',
        'passwd': 'secret',
        'authorization': 'secret',
        'api_key': 'secret',
        'apikey': 'secret',
        'access_token': 'secret',
        'ansible_facts': {
            'password': 'secret',
            'passwd': 'secret',
            'authorization': 'secret',
            'api_key': 'secret',
            'apikey': 'secret',
            'access_token': 'secret',
        },
    }

# Generated at 2022-06-16 22:58:00.477733
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:58:11.622316
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:58:18.150126
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test_env_fallback'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test_env_fallback'
    del os.environ['ANSIBLE_TEST_ENV_FALLBACK']
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test_env_fallback'



# Generated at 2022-06-16 22:58:28.985286
# Unit test for function set_fallbacks