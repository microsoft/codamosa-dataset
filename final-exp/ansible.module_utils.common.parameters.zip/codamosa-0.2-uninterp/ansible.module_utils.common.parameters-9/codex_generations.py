

# Generated at 2022-06-16 22:49:13.046670
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:49:24.465998
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:49:31.957425
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    del os.environ['ANSIBLE_TEST_ENV_FALLBACK']
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'



# Generated at 2022-06-16 22:49:44.957044
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:49:56.859360
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:50:05.021621
# Unit test for function sanitize_keys
def test_sanitize_keys():
    # Test sanitize_keys with a dict
    test_dict = {'key1': 'value1', 'key2': 'value2', 'key3': 'value3'}
    test_dict_sanitized = sanitize_keys(test_dict, ['value2'])
    assert test_dict_sanitized == {'key1': 'value1', 'key2': 'REDACTED', 'key3': 'value3'}

    # Test sanitize_keys with a list
    test_list = ['value1', 'value2', 'value3']
    test_list_sanitized = sanitize_keys(test_list, ['value2'])
    assert test_list_sanitized == ['value1', 'REDACTED', 'value3']

    # Test sanitize_keys with a set

# Generated at 2022-06-16 22:50:09.946013
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'param1': {'type': 'str', 'fallback': (env_fallback, 'PARAM1')},
        'param2': {'type': 'str', 'fallback': (env_fallback, 'PARAM2')},
        'param3': {'type': 'str', 'fallback': (env_fallback, 'PARAM3')},
    }
    parameters = {
        'param1': 'value1',
        'param2': 'value2',
    }
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters == {
        'param1': 'value1',
        'param2': 'value2',
        'param3': 'value3',
    }
    assert no_log_values == set()


# Generated at 2022-06-16 22:50:13.990126
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test_env_fallback'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test_env_fallback'
    del os.environ['ANSIBLE_TEST_ENV_FALLBACK']
    try:
        env_fallback('ANSIBLE_TEST_ENV_FALLBACK')
        assert False, 'AnsibleFallbackNotFound not raised'
    except AnsibleFallbackNotFound:
        pass



# Generated at 2022-06-16 22:50:21.679801
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:50:28.446687
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    os.environ.pop('ANSIBLE_TEST_ENV_FALLBACK')
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'



# Generated at 2022-06-16 22:50:58.983135
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:51:08.526574
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Test with a fallback that returns a value
    argument_spec = {'param1': {'type': 'str', 'fallback': (env_fallback, 'TEST_PARAM1')}}
    parameters = {}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['param1'] == 'TEST_PARAM1'
    assert no_log_values == set()

    # Test with a fallback that returns a value and has no_log set
    argument_spec = {'param1': {'type': 'str', 'fallback': (env_fallback, 'TEST_PARAM1'), 'no_log': True}}
    parameters = {}
    no_log_values = set_fallbacks(argument_spec, parameters)

# Generated at 2022-06-16 22:51:21.554799
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys({'a': 'b'}, {'a'}) == {'b': 'b'}
    assert sanitize_keys({'a': 'b'}, {'a'}, ignore_keys=['a']) == {'a': 'b'}
    assert sanitize_keys({'a': {'b': 'c'}}, {'a'}) == {'b': {'b': 'c'}}
    assert sanitize_keys({'a': {'b': 'c'}}, {'a'}, ignore_keys=['a']) == {'a': {'b': 'c'}}

# Generated at 2022-06-16 22:51:32.188615
# Unit test for function remove_values
def test_remove_values():
    assert remove_values(['a', 'b', 'c'], ['b']) == ['a', 'c']
    assert remove_values(['a', 'b', 'c'], ['d']) == ['a', 'b', 'c']
    assert remove_values(['a', 'b', 'c'], ['b', 'd']) == ['a', 'c']
    assert remove_values(['a', 'b', 'c'], ['b', 'c']) == ['a']
    assert remove_values(['a', 'b', 'c'], ['a', 'b', 'c']) == []
    assert remove_values(['a', 'b', 'c'], ['a', 'b', 'c', 'd']) == []

# Generated at 2022-06-16 22:51:44.282280
# Unit test for function sanitize_keys
def test_sanitize_keys():
    no_log_strings = set(['password', 'secret'])
    ignore_keys = frozenset(['_ansible_verbose_always'])
    obj = {'password': 'secret', '_ansible_verbose_always': True}
    new_obj = sanitize_keys(obj, no_log_strings, ignore_keys)
    assert new_obj == {'****': 'secret', '_ansible_verbose_always': True}

    obj = {'password': 'secret', '_ansible_verbose_always': True, 'nested': {'password': 'secret'}}
    new_obj = sanitize_keys(obj, no_log_strings, ignore_keys)

# Generated at 2022-06-16 22:51:52.753607
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:52:02.845147
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:52:14.594484
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:52:22.311071
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_VAR'] = 'test'
    assert env_fallback('ANSIBLE_TEST_VAR') == 'test'
    assert env_fallback('ANSIBLE_TEST_VAR', 'ANSIBLE_TEST_VAR2') == 'test'
    assert env_fallback('ANSIBLE_TEST_VAR2', 'ANSIBLE_TEST_VAR') == 'test'
    assert env_fallback('ANSIBLE_TEST_VAR2') == 'test'
    assert env_fallback('ANSIBLE_TEST_VAR2', 'ANSIBLE_TEST_VAR2') == 'test'
    assert env_fallback('ANSIBLE_TEST_VAR2', 'ANSIBLE_TEST_VAR2', 'ANSIBLE_TEST_VAR2')

# Generated at 2022-06-16 22:52:34.775803
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:53:26.349536
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:53:39.353380
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'foo'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'foo'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK', 'ANSIBLE_TEST_ENV_FALLBACK2') == 'foo'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK2', 'ANSIBLE_TEST_ENV_FALLBACK') == 'foo'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK2') == 'foo'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK2', 'ANSIBLE_TEST_ENV_FALLBACK3') == 'foo'
    assert env

# Generated at 2022-06-16 22:53:46.919749
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:53:57.951475
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:54:04.319450
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    del os.environ['ANSIBLE_TEST_ENV_FALLBACK']
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'



# Generated at 2022-06-16 22:54:13.687481
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:54:24.643739
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'test_param': {
            'type': 'str',
            'fallback': (env_fallback, ['TEST_PARAM'])
        }
    }
    parameters = {}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert len(no_log_values) == 0
    assert len(parameters) == 0

    os.environ['TEST_PARAM'] = 'test_value'
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert len(no_log_values) == 0
    assert len(parameters) == 1
    assert parameters['test_param'] == 'test_value'

    argument_spec['test_param']['no_log'] = True
    no_log_values = set_

# Generated at 2022-06-16 22:54:32.074712
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:54:42.248474
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:54:51.686033
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:55:19.517464
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test_env_fallback'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test_env_fallback'
    del os.environ['ANSIBLE_TEST_ENV_FALLBACK']
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('ANSIBLE_TEST_ENV_FALLBACK')



# Generated at 2022-06-16 22:55:30.793388
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:55:41.444678
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:55:52.829588
# Unit test for function remove_values
def test_remove_values():
    assert remove_values(None, []) is None
    assert remove_values('', []) == ''
    assert remove_values('foo', []) == 'foo'
    assert remove_values('foo', ['foo']) == 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'
    assert remove_values('foo', ['foo', 'bar']) == 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'
    assert remove_values('foo', ['bar']) == 'foo'
    assert remove_values('foo', ['foo', 'bar']) == 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'
    assert remove_values('foo', ['bar', 'foo']) == 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'

# Generated at 2022-06-16 22:56:02.007884
# Unit test for function remove_values
def test_remove_values():
    assert remove_values('foo', ['foo']) == 'VALUE_REMOVED_PRIVATE_DATA'
    assert remove_values('foo', ['bar']) == 'foo'
    assert remove_values('foo', ['foo', 'bar']) == 'VALUE_REMOVED_PRIVATE_DATA'
    assert remove_values('foo', ['foo', 'foo']) == 'VALUE_REMOVED_PRIVATE_DATA'
    assert remove_values('foo', ['foo', 'foo', 'foo']) == 'VALUE_REMOVED_PRIVATE_DATA'
    assert remove_values('foo', ['foo', 'foo', 'foo', 'foo']) == 'VALUE_REMOVED_PRIVATE_DATA'

# Generated at 2022-06-16 22:56:08.582865
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['TEST_ENV_FALLBACK'] = 'test_env_fallback'
    assert env_fallback('TEST_ENV_FALLBACK') == 'test_env_fallback'
    del os.environ['TEST_ENV_FALLBACK']
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('TEST_ENV_FALLBACK')



# Generated at 2022-06-16 22:56:16.129130
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:56:27.214750
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:56:39.705818
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:56:51.065056
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_SET') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_SET', 'ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_SET', 'ANSIBLE_TEST_ENV_FALLBACK_NOT_SET') == 'test'

# Generated at 2022-06-16 22:57:45.038657
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:57:53.792687
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_VAR'] = 'test_value'
    assert env_fallback('ANSIBLE_TEST_VAR') == 'test_value'
    assert env_fallback('ANSIBLE_TEST_VAR', 'ANSIBLE_TEST_VAR2') == 'test_value'
    assert env_fallback('ANSIBLE_TEST_VAR2', 'ANSIBLE_TEST_VAR') == 'test_value'
    assert env_fallback('ANSIBLE_TEST_VAR2') == 'ANSIBLE_TEST_VAR2'
    assert env_fallback('ANSIBLE_TEST_VAR2', 'ANSIBLE_TEST_VAR2') == 'ANSIBLE_TEST_VAR2'

# Generated at 2022-06-16 22:58:02.427888
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'ANSIBLE_TEST_ENV_FALLBACK'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_FOUND') == 'ANSIBLE_TEST_ENV_FALLBACK_NOT_FOUND'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_FOUND') == 'ANSIBLE_TEST_ENV_FALLBACK_NOT_FOUND'



# Generated at 2022-06-16 22:58:09.489754
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:58:14.906295
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test_env_fallback'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test_env_fallback'
    del os.environ['ANSIBLE_TEST_ENV_FALLBACK']
    try:
        env_fallback('ANSIBLE_TEST_ENV_FALLBACK')
        assert False
    except AnsibleFallbackNotFound:
        pass



# Generated at 2022-06-16 22:58:27.177092
# Unit test for function set_fallbacks