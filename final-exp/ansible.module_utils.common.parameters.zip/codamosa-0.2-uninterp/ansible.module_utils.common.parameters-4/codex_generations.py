

# Generated at 2022-06-16 22:49:41.879835
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:49:54.453310
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK', 'ANSIBLE_TEST_ENV_FALLBACK2') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK2', 'ANSIBLE_TEST_ENV_FALLBACK') == 'test2'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK2', 'ANSIBLE_TEST_ENV_FALLBACK3') == 'test2'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK3', 'ANSIBLE_TEST_ENV_FALLBACK2') == 'test3'

# Generated at 2022-06-16 22:50:03.397840
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:50:09.653473
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    os.environ.pop('ANSIBLE_TEST_ENV_FALLBACK')
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK', 'ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK', 'ANSIBLE_TEST_ENV_FALLBACK', 'ANSIBLE_TEST_ENV_FALLBACK') == 'test'

# Generated at 2022-06-16 22:50:18.461107
# Unit test for function sanitize_keys
def test_sanitize_keys():
    # Test sanitize_keys with a dict
    test_dict = {'a': 'b', 'c': 'd', 'e': 'f'}
    test_dict_result = {'a': 'b', 'c': 'd', 'e': 'f'}
    assert sanitize_keys(test_dict, ['b']) == test_dict_result

    # Test sanitize_keys with a list
    test_list = ['a', 'b', 'c']
    test_list_result = ['a', 'b', 'c']
    assert sanitize_keys(test_list, ['b']) == test_list_result

    # Test sanitize_keys with a set
    test_set = {'a', 'b', 'c'}

# Generated at 2022-06-16 22:50:24.977056
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:50:29.955136
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_FOUND')


# Generated at 2022-06-16 22:50:40.411905
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('FOO') == os.environ['FOO']
    assert env_fallback('FOO', 'BAR') == os.environ['FOO']
    assert env_fallback('BAR', 'FOO') == os.environ['BAR']
    assert env_fallback('BAR', 'FOO', 'BAZ') == os.environ['BAR']
    assert env_fallback('BAZ', 'FOO', 'BAR') == os.environ['BAZ']
    assert env_fallback('FOO', 'BAR', 'BAZ') == os.environ['FOO']
    assert env_fallback('FOO', 'BAR', 'BAZ', 'QUX') == os.environ['FOO']

# Generated at 2022-06-16 22:50:46.673998
# Unit test for function remove_values
def test_remove_values():
    assert remove_values('foo', ['foo']) == 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'
    assert remove_values('foo', ['bar']) == 'foo'
    assert remove_values('foo', ['foo', 'bar']) == 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'
    assert remove_values('foo', ['foo', 'bar', 'baz']) == 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'
    assert remove_values('foo', ['foo', 'bar', 'baz', 'qux']) == 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'

# Generated at 2022-06-16 22:50:58.822551
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:51:32.669227
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'test_param': {
            'type': 'str',
            'fallback': (env_fallback, 'TEST_PARAM'),
        },
    }
    parameters = {}
    os.environ['TEST_PARAM'] = 'test_value'
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['test_param'] == 'test_value'
    assert no_log_values == set()



# Generated at 2022-06-16 22:51:44.720356
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:51:52.247716
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'ANSIBLE_TEST_ENV_FALLBACK'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'ANSIBLE_TEST_ENV_FALLBACK'
    del os.environ['ANSIBLE_TEST_ENV_FALLBACK']
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'ANSIBLE_TEST_ENV_FALLBACK'



# Generated at 2022-06-16 22:52:02.515382
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        foo=dict(type='str', fallback=(env_fallback, ['FOO'])),
        bar=dict(type='str', fallback=(env_fallback, ['BAR'])),
        baz=dict(type='str', fallback=(env_fallback, ['BAZ'])),
        qux=dict(type='str', fallback=(env_fallback, ['QUX'])),
    )
    parameters = dict(
        foo='foo',
        bar='bar',
        baz='baz',
    )
    os.environ['QUX'] = 'qux'
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['qux'] == 'qux'
    assert no_log_values == set()


# Generated at 2022-06-16 22:52:14.503409
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['TEST_ENV_FALLBACK'] = 'test_env_fallback'
    assert env_fallback('TEST_ENV_FALLBACK') == 'test_env_fallback'
    del os.environ['TEST_ENV_FALLBACK']
    assert env_fallback('TEST_ENV_FALLBACK') == 'test_env_fallback'
    assert env_fallback('TEST_ENV_FALLBACK', 'TEST_ENV_FALLBACK') == 'test_env_fallback'
    assert env_fallback('TEST_ENV_FALLBACK', 'TEST_ENV_FALLBACK', 'TEST_ENV_FALLBACK') == 'test_env_fallback'

# Generated at 2022-06-16 22:52:22.252019
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_FOUND') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_FOUND', 'ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_FOUND', 'ANSIBLE_TEST_ENV_FALLBACK_NOT_FOUND') == 'test'

# Generated at 2022-06-16 22:52:34.725553
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:52:44.037589
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:52:51.550947
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:53:03.237250
# Unit test for function remove_values
def test_remove_values():
    # Test for a simple string
    assert remove_values('password', ['password']) == 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'

    # Test for a simple list
    assert remove_values(['password', 'secret'], ['password', 'secret']) == ['VALUE_SPECIFIED_IN_NO_LOG_PARAMETER', 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER']

    # Test for a simple dict
    assert remove_values({'password': 'password', 'secret': 'secret'}, ['password', 'secret']) == {'password': 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER', 'secret': 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'}

    # Test for a nested dict

# Generated at 2022-06-16 22:53:29.217195
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['TEST_ENV_FALLBACK'] = 'test'
    assert env_fallback('TEST_ENV_FALLBACK') == 'test'
    os.environ.pop('TEST_ENV_FALLBACK')
    assert env_fallback('TEST_ENV_FALLBACK') == 'test'



# Generated at 2022-06-16 22:53:41.651884
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'param1': {'type': 'str', 'fallback': (env_fallback, 'PARAM1')},
        'param2': {'type': 'str', 'fallback': (env_fallback, 'PARAM2')},
        'param3': {'type': 'str', 'fallback': (env_fallback, 'PARAM3')},
        'param4': {'type': 'str', 'fallback': (env_fallback, 'PARAM4')},
        'param5': {'type': 'str', 'fallback': (env_fallback, 'PARAM5')},
    }
    parameters = {'param1': 'value1'}
    no_log_values = set_fallbacks(argument_spec, parameters)

# Generated at 2022-06-16 22:53:49.559471
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:54:01.814118
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:54:07.249473
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    del os.environ['ANSIBLE_TEST_ENV_FALLBACK']
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('ANSIBLE_TEST_ENV_FALLBACK')



# Generated at 2022-06-16 22:54:12.194101
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    del os.environ['ANSIBLE_TEST_ENV_FALLBACK']
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'



# Generated at 2022-06-16 22:54:16.703470
# Unit test for function env_fallback
def test_env_fallback():
    # Test that env_fallback raises AnsibleFallbackNotFound if no environment variable is found
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('FOO')
    # Test that env_fallback returns the value of the environment variable if found
    os.environ['FOO'] = 'bar'
    assert env_fallback('FOO') == 'bar'
    del os.environ['FOO']



# Generated at 2022-06-16 22:54:26.961466
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:54:39.068218
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:54:50.162603
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'param1': {'type': 'str', 'fallback': (env_fallback, 'PARAM1')},
        'param2': {'type': 'str', 'fallback': (env_fallback, 'PARAM2')},
        'param3': {'type': 'str', 'fallback': (env_fallback, 'PARAM3')},
        'param4': {'type': 'str', 'fallback': (env_fallback, 'PARAM4')},
    }
    parameters = {'param1': 'value1'}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['param1'] == 'value1'
    assert parameters['param2'] == 'value2'
    assert parameters['param3'] == 'value3'
   

# Generated at 2022-06-16 22:55:20.575005
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_EXIST') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_EXIST', 'ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_EXIST', 'ANSIBLE_TEST_ENV_FALLBACK_NOT_EXIST') == 'test'

# Generated at 2022-06-16 22:55:31.712225
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:55:42.040777
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV'] = 'test'
    assert env_fallback('ANSIBLE_TEST_ENV') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV', 'ANSIBLE_TEST_ENV2') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV2', 'ANSIBLE_TEST_ENV') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV2') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV2', 'ANSIBLE_TEST_ENV') == 'test'

# Generated at 2022-06-16 22:55:48.271851
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    del os.environ['ANSIBLE_TEST_ENV_FALLBACK']
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'



# Generated at 2022-06-16 22:55:57.628592
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:56:07.147942
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:56:15.684118
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:56:26.874520
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['FOO'] = 'bar'
    assert env_fallback('FOO') == 'bar'
    assert env_fallback('BAR') == 'bar'
    assert env_fallback('FOO', 'BAR') == 'bar'
    assert env_fallback('BAR', 'FOO') == 'bar'
    assert env_fallback('BAR', 'BAZ') == 'bar'
    assert env_fallback('BAZ', 'BAR') == 'bar'
    assert env_fallback('BAZ') == 'bar'
    assert env_fallback('BAZ', 'BAR', 'FOO') == 'bar'
    assert env_fallback('BAZ', 'BAR', 'FOO', 'BAZ') == 'bar'

# Generated at 2022-06-16 22:56:39.341530
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test_env_fallback'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test_env_fallback'
    del os.environ['ANSIBLE_TEST_ENV_FALLBACK']
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test_env_fallback'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK', 'ANSIBLE_TEST_ENV_FALLBACK') == 'test_env_fallback'

# Generated at 2022-06-16 22:56:50.864417
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:57:24.669967
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys({"a": "b"}, ["b"]) == {"a": "b"}
    assert sanitize_keys({"a": "b"}, ["b"], ignore_keys=["a"]) == {"a": "b"}
    assert sanitize_keys({"a": "b"}, ["b"], ignore_keys=["b"]) == {"a": "b"}
    assert sanitize_keys({"a": "b"}, ["b"], ignore_keys=["a", "b"]) == {"a": "b"}
    assert sanitize_keys({"a": "b"}, ["b"], ignore_keys=["a", "b", "c"]) == {"a": "b"}

# Generated at 2022-06-16 22:57:32.395302
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:57:44.156234
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:57:53.233945
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:58:05.271351
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:58:11.325382
# Unit test for function remove_values

# Generated at 2022-06-16 22:58:15.781462
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'ANSIBLE_TEST_ENV_FALLBACK'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_FOUND') == 'ANSIBLE_TEST_ENV_FALLBACK_NOT_FOUND'



# Generated at 2022-06-16 22:58:27.883703
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'param1': {'type': 'str', 'fallback': (env_fallback, 'TEST_PARAM1')},
        'param2': {'type': 'str', 'fallback': (env_fallback, 'TEST_PARAM2')},
        'param3': {'type': 'str', 'fallback': (env_fallback, 'TEST_PARAM3')},
    }
    parameters = {'param1': 'value1'}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['param1'] == 'value1'
    assert parameters['param2'] == 'value2'
    assert parameters['param3'] == 'value3'
    assert no_log_values == set()

