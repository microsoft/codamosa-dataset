

# Generated at 2022-06-16 22:48:57.024898
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test_env_fallback'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test_env_fallback'
    del os.environ['ANSIBLE_TEST_ENV_FALLBACK']
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('ANSIBLE_TEST_ENV_FALLBACK')



# Generated at 2022-06-16 22:49:07.563289
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:49:18.343903
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:49:26.346246
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:49:33.875133
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:49:46.588338
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:49:58.339824
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:50:08.270517
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:50:11.653805
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    os.environ.pop('ANSIBLE_TEST_ENV_FALLBACK')
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('ANSIBLE_TEST_ENV_FALLBACK')



# Generated at 2022-06-16 22:50:19.962929
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:51:06.505930
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:51:19.520709
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('FOO') == os.environ['FOO']
    assert env_fallback('FOO', 'BAR') == os.environ['FOO']
    assert env_fallback('FOO', 'BAR', 'BAZ') == os.environ['FOO']
    assert env_fallback('FOO', 'BAR', 'BAZ', 'QUX') == os.environ['FOO']
    assert env_fallback('FOO', 'BAR', 'BAZ', 'QUX', 'QUUX') == os.environ['FOO']
    assert env_fallback('FOO', 'BAR', 'BAZ', 'QUX', 'QUUX', 'QUUUX') == os.environ['FOO']

# Generated at 2022-06-16 22:51:30.662330
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:51:42.701589
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:51:51.722544
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys('foo', ['foo']) == 'foo'
    assert sanitize_keys(['foo'], ['foo']) == ['foo']
    assert sanitize_keys({'foo': 'bar'}, ['foo']) == {'foo': 'bar'}
    assert sanitize_keys({'foo': 'bar'}, ['bar']) == {'foo': 'bar'}
    assert sanitize_keys({'foo': 'bar'}, ['foo', 'bar']) == {'foo': 'bar'}
    assert sanitize_keys({'foo': 'bar'}, ['bar', 'foo']) == {'foo': 'bar'}

# Generated at 2022-06-16 22:52:02.290418
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:52:14.362983
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test_env_fallback'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test_env_fallback'
    del os.environ['ANSIBLE_TEST_ENV_FALLBACK']
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test_env_fallback'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK', 'ANSIBLE_TEST_ENV_FALLBACK') == 'test_env_fallback'

# Generated at 2022-06-16 22:52:25.849612
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:52:37.154887
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:52:42.744706
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test_env_fallback'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test_env_fallback'
    del os.environ['ANSIBLE_TEST_ENV_FALLBACK']
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test_env_fallback'



# Generated at 2022-06-16 22:53:11.715338
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('TEST_ENV') == os.environ['TEST_ENV']
    assert env_fallback('TEST_ENV', 'TEST_ENV2') == os.environ['TEST_ENV']
    assert env_fallback('TEST_ENV2', 'TEST_ENV') == os.environ['TEST_ENV']
    assert env_fallback('TEST_ENV2', 'TEST_ENV3') == os.environ['TEST_ENV2']
    assert env_fallback('TEST_ENV3', 'TEST_ENV2') == os.environ['TEST_ENV2']
    assert env_fallback('TEST_ENV3', 'TEST_ENV2', 'TEST_ENV') == os.en

# Generated at 2022-06-16 22:53:23.978078
# Unit test for function sanitize_keys
def test_sanitize_keys():
    # Test for dict
    data = {'a': 'b', 'c': 'd'}
    no_log_strings = ['a']
    new_data = sanitize_keys(data, no_log_strings)
    assert new_data == {'_ansible_no_log_a': 'b', 'c': 'd'}

    # Test for list
    data = ['a', 'b']
    no_log_strings = ['a']
    new_data = sanitize_keys(data, no_log_strings)
    assert new_data == ['_ansible_no_log_a', 'b']

    # Test for set
    data = {'a', 'b'}
    no_log_strings = ['a']

# Generated at 2022-06-16 22:53:36.460652
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:53:46.442816
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys({'foo': 'bar', 'baz': 'qux'}, ['bar']) == {'foo': 'bar', 'baz': 'qux'}
    assert sanitize_keys({'foo': 'bar', 'baz': 'qux'}, ['baz']) == {'foo': 'bar', 'baz': 'qux'}
    assert sanitize_keys({'foo': 'bar', 'baz': 'qux'}, ['qux']) == {'foo': 'bar', 'baz': 'qux'}
    assert sanitize_keys({'foo': 'bar', 'baz': 'qux'}, ['bar', 'qux']) == {'foo': 'bar', 'baz': 'qux'}

# Generated at 2022-06-16 22:53:51.856433
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['TEST_ENV_FALLBACK'] = 'test_env_fallback'
    assert env_fallback('TEST_ENV_FALLBACK') == 'test_env_fallback'
    del os.environ['TEST_ENV_FALLBACK']
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('TEST_ENV_FALLBACK')



# Generated at 2022-06-16 22:54:04.320069
# Unit test for function remove_values
def test_remove_values():
    assert remove_values('foo', ['foo']) == 'VALUE_REMOVED_PRIVATE_DATA'
    assert remove_values('foo', ['bar']) == 'foo'
    assert remove_values('foo', ['foo', 'bar']) == 'VALUE_REMOVED_PRIVATE_DATA'
    assert remove_values('foo', ['foo', 'bar'], ['bar']) == 'foo'
    assert remove_values('foo', ['foo', 'bar'], ['foo']) == 'VALUE_REMOVED_PRIVATE_DATA'
    assert remove_values('foo', ['foo', 'bar'], ['foo', 'bar']) == 'foo'

    assert remove_values(['foo'], ['foo']) == ['VALUE_REMOVED_PRIVATE_DATA']

# Generated at 2022-06-16 22:54:13.686330
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:54:21.178397
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:54:29.752854
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:54:41.357739
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:55:20.455337
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:55:31.582982
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:55:41.968717
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:55:53.142532
# Unit test for function sanitize_keys
def test_sanitize_keys():
    no_log_strings = ['password', 'secret']
    ignore_keys = ['_ansible_verbose_always']

    # Test sanitizing a dictionary
    data = {
        'password': 'secret',
        '_ansible_verbose_always': True,
        'data': {
            'password': 'secret',
            '_ansible_verbose_always': True,
            'data': {
                'password': 'secret',
                '_ansible_verbose_always': True,
            },
        },
    }

# Generated at 2022-06-16 22:56:01.149598
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_FOUND') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_FOUND', 'ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_FOUND', 'ANSIBLE_TEST_ENV_FALLBACK_NOT_FOUND') == 'test'

# Generated at 2022-06-16 22:56:12.222361
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys({'a': 'b', 'c': 'd'}, ['b']) == {'a': 'b', 'c': 'd'}
    assert sanitize_keys({'a': 'b', 'c': 'd'}, ['a']) == {'a': 'b', 'c': 'd'}
    assert sanitize_keys({'a': 'b', 'c': 'd'}, ['a', 'b']) == {'a': 'b', 'c': 'd'}
    assert sanitize_keys({'a': 'b', 'c': 'd'}, ['a', 'b', 'c']) == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-16 22:56:24.124319
# Unit test for function remove_values
def test_remove_values():
    assert remove_values(dict(a=1, b=2, c=3), []) == dict(a=1, b=2, c=3)
    assert remove_values(dict(a=1, b=2, c=3), ['2']) == dict(a=1, b='*' * len('2'), c=3)
    assert remove_values(dict(a=1, b=2, c=3), ['2', '3']) == dict(a=1, b='*' * len('2'), c='*' * len('3'))
    assert remove_values(dict(a=1, b=2, c=3), ['2', '3', '1']) == dict(a='*' * len('1'), b='*' * len('2'), c='*' * len('3'))


# Generated at 2022-06-16 22:56:35.513516
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:56:48.077837
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:56:54.082329
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_SET') == 'test'
    del os.environ['ANSIBLE_TEST_ENV_FALLBACK']
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_SET')



# Generated at 2022-06-16 22:57:48.231026
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:57:59.406692
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:58:10.784316
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:58:22.751734
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_FOUND') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_FOUND', 'ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_FOUND', 'ANSIBLE_TEST_ENV_FALLBACK_NOT_FOUND') == 'test'