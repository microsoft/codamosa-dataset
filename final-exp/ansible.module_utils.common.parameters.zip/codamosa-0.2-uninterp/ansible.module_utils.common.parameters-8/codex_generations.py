

# Generated at 2022-06-16 22:49:17.890701
# Unit test for function remove_values

# Generated at 2022-06-16 22:49:28.216770
# Unit test for function remove_values
def test_remove_values():
    assert remove_values(dict(a=1, b=2, c=3), []) == dict(a=1, b=2, c=3)
    assert remove_values(dict(a=1, b=2, c=3), [2]) == dict(a=1, b='VALUE_SPECIFIED_IN_NO_LOG_PARAMETER', c=3)
    assert remove_values(dict(a=1, b=2, c=3), [2, 3]) == dict(a=1, b='VALUE_SPECIFIED_IN_NO_LOG_PARAMETER', c='VALUE_SPECIFIED_IN_NO_LOG_PARAMETER')

# Generated at 2022-06-16 22:49:35.057837
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_VAR'] = 'test_env_fallback'
    assert env_fallback('ANSIBLE_TEST_ENV_VAR') == 'test_env_fallback'
    del os.environ['ANSIBLE_TEST_ENV_VAR']
    assert env_fallback('ANSIBLE_TEST_ENV_VAR') == 'test_env_fallback'



# Generated at 2022-06-16 22:49:48.159979
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:49:52.282156
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys({'a': 'b', 'c': 'd'}, ['a']) == {'c': 'd'}
    assert sanitize_keys({'a': 'b', 'c': 'd'}, ['a', 'b']) == {'c': 'd'}
    assert sanitize_keys({'a': 'b', 'c': 'd'}, ['a', 'b', 'c']) == {}
    assert sanitize_keys({'a': 'b', 'c': 'd'}, ['a', 'b', 'c', 'd']) == {}
    assert sanitize_keys({'a': 'b', 'c': 'd'}, ['a', 'b', 'c', 'd', 'e']) == {}

# Generated at 2022-06-16 22:50:02.113778
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK', 'ANSIBLE_TEST_ENV_FALLBACK2') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK2', 'ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK2') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK2', 'ANSIBLE_TEST_ENV_FALLBACK3') == 'test'
    assert env

# Generated at 2022-06-16 22:50:08.385142
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_FOUND') == 'test'
    del os.environ['ANSIBLE_TEST_ENV_FALLBACK']
    try:
        env_fallback('ANSIBLE_TEST_ENV_FALLBACK')
        assert False
    except AnsibleFallbackNotFound:
        pass
    try:
        env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_FOUND')
        assert False
    except AnsibleFallbackNotFound:
        pass



# Generated at 2022-06-16 22:50:14.014190
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK', 'ANSIBLE_TEST_ENV_FALLBACK2') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK2', 'ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK2') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK2', 'ANSIBLE_TEST_ENV_FALLBACK2') == 'test'
    assert env

# Generated at 2022-06-16 22:50:23.978620
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:50:36.257673
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:51:06.860482
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:51:19.844713
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys({'foo': 'bar', 'baz': {'qux': 'quux'}}, ['bar']) == {'foo': 'bar', 'baz': {'qux': 'quux'}}
    assert sanitize_keys({'foo': 'bar', 'baz': {'qux': 'quux'}}, ['bar', 'foo']) == {'foo': 'bar', 'baz': {'qux': 'quux'}}
    assert sanitize_keys({'foo': 'bar', 'baz': {'qux': 'quux'}}, ['bar', 'baz']) == {'foo': 'bar', 'baz': {'qux': 'quux'}}

# Generated at 2022-06-16 22:51:30.838258
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:51:42.817026
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:51:49.101063
# Unit test for function remove_values
def test_remove_values():
    assert remove_values('abcdefghijklmnopqrstuvwxyz', ['abc', 'def', 'ghi', 'jkl', 'mno', 'pqr', 'stu', 'vwx', 'yz']) == '***********'
    assert remove_values('abcdefghijklmnopqrstuvwxyz', ['abc', 'def', 'ghi', 'jkl', 'mno', 'pqr', 'stu', 'vwx', 'yz']) == '***********'
    assert remove_values('abcdefghijklmnopqrstuvwxyz', ['abc', 'def', 'ghi', 'jkl', 'mno', 'pqr', 'stu', 'vwx', 'yz']) == '***********'

# Generated at 2022-06-16 22:51:57.955239
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'ANSIBLE_TEST_ENV_FALLBACK'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'ANSIBLE_TEST_ENV_FALLBACK'
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_FOUND')
    del os.environ['ANSIBLE_TEST_ENV_FALLBACK']



# Generated at 2022-06-16 22:52:05.771938
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:52:16.545842
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_SET') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_SET', 'ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_SET', 'ANSIBLE_TEST_ENV_FALLBACK_NOT_SET') == 'test'

# Generated at 2022-06-16 22:52:26.740818
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:52:31.794262
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test_env_fallback'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test_env_fallback'
    del os.environ['ANSIBLE_TEST_ENV_FALLBACK']
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('ANSIBLE_TEST_ENV_FALLBACK')



# Generated at 2022-06-16 22:53:03.677335
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:53:12.038129
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:53:24.383520
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:53:36.842412
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test_env_fallback'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test_env_fallback'
    del os.environ['ANSIBLE_TEST_ENV_FALLBACK']
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test_env_fallback'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK', 'ANSIBLE_TEST_ENV_FALLBACK') == 'test_env_fallback'

# Generated at 2022-06-16 22:53:43.499660
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test_env_fallback'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test_env_fallback'
    del os.environ['ANSIBLE_TEST_ENV_FALLBACK']
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test_env_fallback'



# Generated at 2022-06-16 22:53:53.238816
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:54:05.309932
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:54:10.231042
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    os.environ.pop('ANSIBLE_TEST_ENV_FALLBACK')
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'



# Generated at 2022-06-16 22:54:21.543959
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:54:32.110181
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Test with no fallback
    argument_spec = dict(
        param1=dict(type='str'),
        param2=dict(type='str'),
    )
    parameters = dict(
        param1='value1',
    )
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters == dict(
        param1='value1',
    )
    assert no_log_values == set()

    # Test with fallback
    argument_spec = dict(
        param1=dict(type='str', fallback=(env_fallback, 'PARAM1')),
        param2=dict(type='str', fallback=(env_fallback, 'PARAM2')),
    )
    parameters = dict(
        param1='value1',
    )
    no_log_values = set

# Generated at 2022-06-16 22:55:02.980910
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:55:14.837130
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:55:21.607358
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'test_param': {'type': 'str', 'fallback': (env_fallback, 'TEST_PARAM')},
    }
    parameters = {}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['test_param'] == 'TEST_PARAM'
    assert no_log_values == set()



# Generated at 2022-06-16 22:55:27.095465
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:55:38.858257
# Unit test for function remove_values
def test_remove_values():
    # Test function remove_values
    # Test with a string
    value = 'This is a string'
    no_log_strings = ['string']
    new_value = remove_values(value, no_log_strings)
    assert new_value == 'This is a '
    # Test with a list
    value = ['This is a string', 'This is another string']
    no_log_strings = ['string']
    new_value = remove_values(value, no_log_strings)
    assert new_value == ['This is a ', 'This is another ']
    # Test with a dictionary
    value = {'key1': 'This is a string', 'key2': 'This is another string'}
    no_log_strings = ['string']
    new_value = remove_values(value, no_log_strings)
   

# Generated at 2022-06-16 22:55:45.890529
# Unit test for function sanitize_keys

# Generated at 2022-06-16 22:55:55.959121
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:56:04.402894
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:56:14.264967
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_FOUND') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_FOUND', 'ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_FOUND', 'ANSIBLE_TEST_ENV_FALLBACK_NOT_FOUND') == 'test'

# Generated at 2022-06-16 22:56:25.841784
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    os.environ.pop('ANSIBLE_TEST_ENV_FALLBACK')
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK', 'test') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK', 'test', 'test2') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK', 'test2', 'test3') == 'test2'

# Generated at 2022-06-16 22:57:14.658305
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'foo': {'type': 'str', 'fallback': (env_fallback, ['FOO'])},
        'bar': {'type': 'str', 'fallback': (env_fallback, ['BAR'])},
        'baz': {'type': 'str', 'fallback': (env_fallback, ['BAZ'])},
        'qux': {'type': 'str', 'fallback': (env_fallback, ['QUX'])},
    }
    parameters = {}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert len(no_log_values) == 0
    assert len(parameters) == 0

    os.environ['FOO'] = 'foo'
    os.environ['BAR'] = 'bar'


# Generated at 2022-06-16 22:57:25.689975
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test_env_fallback'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test_env_fallback'
    del os.environ['ANSIBLE_TEST_ENV_FALLBACK']
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test_env_fallback'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK', 'ANSIBLE_TEST_ENV_FALLBACK') == 'test_env_fallback'

# Generated at 2022-06-16 22:57:33.064667
# Unit test for function env_fallback
def test_env_fallback():
    """Test env_fallback"""
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_1') == 'ANSIBLE_TEST_ENV_FALLBACK_1'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_2') == 'ANSIBLE_TEST_ENV_FALLBACK_2'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_3') == 'ANSIBLE_TEST_ENV_FALLBACK_3'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_4') == 'ANSIBLE_TEST_ENV_FALLBACK_4'

# Generated at 2022-06-16 22:57:40.368222
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test_env_fallback'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test_env_fallback'
    del os.environ['ANSIBLE_TEST_ENV_FALLBACK']
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test_env_fallback'



# Generated at 2022-06-16 22:57:50.755249
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:58:02.661620
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:58:09.536979
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK', 'ANSIBLE_TEST_ENV_FALLBACK_2') == 'test'
    os.environ['ANSIBLE_TEST_ENV_FALLBACK_2'] = 'test2'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_2', 'ANSIBLE_TEST_ENV_FALLBACK') == 'test2'
    del os.environ['ANSIBLE_TEST_ENV_FALLBACK']

# Generated at 2022-06-16 22:58:19.394687
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:58:26.565041
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'foo'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'foo'
    os.environ.pop('ANSIBLE_TEST_ENV_FALLBACK')
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('ANSIBLE_TEST_ENV_FALLBACK')

