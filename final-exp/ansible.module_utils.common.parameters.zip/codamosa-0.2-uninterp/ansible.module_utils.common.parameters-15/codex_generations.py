

# Generated at 2022-06-16 22:49:08.897733
# Unit test for function remove_values

# Generated at 2022-06-16 22:49:17.611463
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'ANSIBLE_TEST_ENV_FALLBACK'
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_FOUND')
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_FOUND', 'ANSIBLE_TEST_ENV_FALLBACK_NOT_FOUND_2')


# Generated at 2022-06-16 22:49:25.560627
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:49:37.825612
# Unit test for function remove_values
def test_remove_values():
    # Test for string
    assert remove_values('test', ['test']) == 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'
    assert remove_values('test', ['test', 'test2']) == 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'
    assert remove_values('test', ['test2']) == 'test'
    assert remove_values('test', []) == 'test'
    assert remove_values('test', ['test', 'test2'], ['test']) == 'test'

    # Test for list
    assert remove_values(['test', 'test2'], ['test']) == ['VALUE_SPECIFIED_IN_NO_LOG_PARAMETER', 'test2']
    assert remove_values(['test', 'test2'], ['test', 'test2'])

# Generated at 2022-06-16 22:49:51.124964
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:49:58.042371
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test_env_fallback'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test_env_fallback'
    del os.environ['ANSIBLE_TEST_ENV_FALLBACK']
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test_env_fallback'



# Generated at 2022-06-16 22:50:08.084413
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:50:16.974522
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:50:29.956250
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:50:40.451398
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:51:09.487957
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:51:22.331575
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:51:32.785878
# Unit test for function env_fallback
def test_env_fallback():
    """Unit test for function env_fallback"""

    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    del os.environ['ANSIBLE_TEST_ENV_FALLBACK']
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK', 'ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK', 'ANSIBLE_TEST_ENV_FALLBACK', 'ANSIBLE_TEST_ENV_FALLBACK') == 'test'


# Generated at 2022-06-16 22:51:44.875935
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:51:56.448102
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:52:04.900561
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        test_param=dict(
            type='str',
            fallback=(env_fallback, ['TEST_PARAM'])
        )
    )

    parameters = dict()
    os.environ['TEST_PARAM'] = 'test_value'
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['test_param'] == 'test_value'
    assert no_log_values == set()

    parameters = dict()
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert 'test_param' not in parameters
    assert no_log_values == set()


# Generated at 2022-06-16 22:52:15.981992
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys({'a': 'b'}, ['a']) == {'b': 'b'}
    assert sanitize_keys({'a': 'b'}, ['a'], ignore_keys=['a']) == {'a': 'b'}
    assert sanitize_keys({'a': 'b'}, ['a'], ignore_keys=['b']) == {'b': 'b'}
    assert sanitize_keys({'a': 'b'}, ['a'], ignore_keys=['a', 'b']) == {'a': 'b'}
    assert sanitize_keys({'a': 'b'}, ['a'], ignore_keys=['a', 'c']) == {'b': 'b'}

# Generated at 2022-06-16 22:52:26.429832
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:52:33.513450
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:52:38.220508
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys({'a': 'b'}, ['b']) == {'a': 'b'}
    assert sanitize_keys({'a': 'b'}, ['a']) == {'[VALUE REMOVED]': 'b'}
    assert sanitize_keys({'a': 'b'}, ['a', 'b']) == {'[VALUE REMOVED]': '[VALUE REMOVED]'}
    assert sanitize_keys({'a': 'b', 'c': 'd'}, ['a']) == {'[VALUE REMOVED]': 'b', 'c': 'd'}

# Generated at 2022-06-16 22:53:09.252449
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:53:20.949749
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:53:29.986711
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:53:42.389382
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:53:51.708057
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:54:04.184911
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:54:13.573939
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:54:21.094960
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys({'a': 1, 'b': 2, 'c': 3}, ['a']) == {'b': 2, 'c': 3}
    assert sanitize_keys({'a': 1, 'b': 2, 'c': 3}, ['a', 'b']) == {'c': 3}
    assert sanitize_keys({'a': 1, 'b': 2, 'c': 3}, ['a', 'b', 'c']) == {}
    assert sanitize_keys({'a': 1, 'b': 2, 'c': 3}, ['a', 'b', 'c'], ignore_keys=['c']) == {'c': 3}

# Generated at 2022-06-16 22:54:29.718677
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:54:41.320546
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:55:15.254656
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:55:23.463341
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:55:35.150101
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:55:44.041021
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:55:54.264854
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:55:59.330667
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    del os.environ['ANSIBLE_TEST_ENV_FALLBACK']
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'



# Generated at 2022-06-16 22:56:09.911236
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:56:13.382673
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'test_param': {
            'type': 'str',
            'fallback': (env_fallback, 'TEST_PARAM')
        }
    }
    parameters = {}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters == {'test_param': 'TEST_PARAM'}
    assert no_log_values == set()



# Generated at 2022-06-16 22:56:25.158621
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:56:36.932282
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:57:06.581332
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:57:12.827189
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:57:24.205562
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:57:33.402199
# Unit test for function remove_values
def test_remove_values():
    # Test that remove_values works on a simple string
    assert remove_values('foo', ['foo']) == '***'

    # Test that remove_values works on a list of strings
    assert remove_values(['foo', 'bar'], ['foo']) == ['***', 'bar']

    # Test that remove_values works on a list of lists
    assert remove_values([['foo', 'bar'], ['baz', 'qux']], ['foo']) == [['***', 'bar'], ['baz', 'qux']]

    # Test that remove_values works on a dict of strings
    assert remove_values({'foo': 'bar'}, ['foo']) == {'***': 'bar'}

    # Test that remove_values works on a dict of dicts

# Generated at 2022-06-16 22:57:40.272826
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'test_param': {
            'type': 'str',
            'fallback': (env_fallback, ['TEST_PARAM'])
        }
    }
    parameters = {}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['test_param'] == os.environ['TEST_PARAM']
    assert no_log_values == set()



# Generated at 2022-06-16 22:57:50.715426
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'test_param': {
            'type': 'str',
            'fallback': (env_fallback, ['TEST_PARAM'])
        }
    }
    parameters = {}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters == {}
    assert no_log_values == set()

    os.environ['TEST_PARAM'] = 'test_value'
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters == {'test_param': 'test_value'}
    assert no_log_values == set()

    argument_spec['test_param']['no_log'] = True
    no_log_values = set_fallbacks(argument_spec, parameters)

# Generated at 2022-06-16 22:58:02.663229
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['FOO'] = 'bar'
    assert env_fallback('FOO') == 'bar'
    assert env_fallback('FOO', 'BAR') == 'bar'
    assert env_fallback('BAR', 'FOO') == 'bar'
    assert env_fallback('BAR') == 'BAR'
    assert env_fallback('BAR', 'BAZ') == 'BAR'
    assert env_fallback('BAZ', 'BAR') == 'BAR'
    assert env_fallback('BAZ') == 'BAZ'
    assert env_fallback('BAZ', 'BAR', 'FOO') == 'BAR'
    assert env_fallback('BAZ', 'FOO', 'BAR') == 'FOO'

# Generated at 2022-06-16 22:58:09.535673
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:58:19.395084
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:58:29.627722
# Unit test for function remove_values