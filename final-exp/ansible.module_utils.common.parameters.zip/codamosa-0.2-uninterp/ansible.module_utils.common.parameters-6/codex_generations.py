

# Generated at 2022-06-16 22:49:12.699999
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys({'a': 'b'}, ['b']) == {'a': 'b'}
    assert sanitize_keys({'a': 'b'}, ['a']) == {'b': 'b'}
    assert sanitize_keys({'a': 'b'}, ['a', 'b']) == {'b': 'b'}
    assert sanitize_keys({'a': 'b'}, ['a', 'b', 'c']) == {'b': 'b'}
    assert sanitize_keys({'a': 'b'}, ['a', 'b', 'c'], ignore_keys=['a']) == {'a': 'b'}

# Generated at 2022-06-16 22:49:24.155754
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:49:31.643428
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys({'a': 'b', 'c': 'd'}, ['b']) == {'a': 'b', 'c': 'd'}
    assert sanitize_keys({'a': 'b', 'c': 'd'}, ['b', 'd']) == {'a': 'b', 'c': 'd'}
    assert sanitize_keys({'a': 'b', 'c': 'd'}, ['b', 'd'], ignore_keys=['c']) == {'a': 'b', 'c': 'd'}
    assert sanitize_keys({'a': 'b', 'c': 'd'}, ['b', 'd'], ignore_keys=['a']) == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-16 22:49:44.696993
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:49:56.625752
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_SET') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_SET', 'ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_SET', 'ANSIBLE_TEST_ENV_FALLBACK_NOT_SET') == 'test'

# Generated at 2022-06-16 22:50:04.859852
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'param1': {'type': 'str', 'fallback': (env_fallback, 'PARAM1')},
        'param2': {'type': 'str', 'fallback': (env_fallback, 'PARAM2')},
        'param3': {'type': 'str', 'fallback': (env_fallback, 'PARAM3')},
        'param4': {'type': 'str', 'fallback': (env_fallback, 'PARAM4')},
    }
    parameters = {'param1': 'value1'}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['param1'] == 'value1'
    assert parameters['param2'] == 'value2'
    assert parameters['param3'] == 'value3'
   

# Generated at 2022-06-16 22:50:09.754240
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:50:18.561278
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys({'a': 'b', 'c': 'd'}, ['b']) == {'a': 'b', 'c': 'd'}
    assert sanitize_keys({'a': 'b', 'c': 'd'}, ['b', 'd']) == {'a': 'b', 'c': 'd'}
    assert sanitize_keys({'a': 'b', 'c': 'd'}, ['b', 'd'], ignore_keys=['c']) == {'a': 'b', 'c': 'd'}
    assert sanitize_keys({'a': 'b', 'c': 'd'}, ['b', 'd'], ignore_keys=['a']) == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-16 22:50:25.053465
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys({'a': 'b', 'c': 'd'}, ['b']) == {'a': 'b', 'c': 'd'}
    assert sanitize_keys({'a': 'b', 'c': 'd'}, ['b', 'c']) == {'a': 'b', 'c': 'd'}
    assert sanitize_keys({'a': 'b', 'c': 'd'}, ['b', 'd']) == {'a': 'b', 'c': 'd'}
    assert sanitize_keys({'a': 'b', 'c': 'd'}, ['b', 'd', 'a']) == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-16 22:50:32.105204
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    del os.environ['ANSIBLE_TEST_ENV_FALLBACK']
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('ANSIBLE_TEST_ENV_FALLBACK')



# Generated at 2022-06-16 22:51:07.264678
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:51:20.153223
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    del os.environ['ANSIBLE_TEST_ENV_FALLBACK']
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK', 'ANSIBLE_TEST_ENV_FALLBACK2') == 'test'
    os.environ['ANSIBLE_TEST_ENV_FALLBACK2'] = 'test2'

# Generated at 2022-06-16 22:51:26.682103
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    os.environ.pop('ANSIBLE_TEST_ENV_FALLBACK')
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('ANSIBLE_TEST_ENV_FALLBACK')



# Generated at 2022-06-16 22:51:35.434647
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:51:42.257179
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:51:51.488497
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:52:02.177319
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys({'foo': 'bar'}, ['bar']) == {'foo': 'bar'}
    assert sanitize_keys({'foo': 'bar'}, ['foo']) == {'foo': 'bar'}
    assert sanitize_keys({'foo': 'bar'}, ['bar'], ignore_keys=['foo']) == {'foo': 'bar'}
    assert sanitize_keys({'foo': 'bar'}, ['foo'], ignore_keys=['foo']) == {'foo': 'bar'}
    assert sanitize_keys({'foo': 'bar'}, ['foo']) == {'foo': 'bar'}
    assert sanitize_keys({'foo': 'bar'}, ['bar']) == {'foo': 'bar'}

# Generated at 2022-06-16 22:52:14.362779
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:52:19.247190
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    os.environ.pop('ANSIBLE_TEST_ENV_FALLBACK')
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('ANSIBLE_TEST_ENV_FALLBACK')



# Generated at 2022-06-16 22:52:28.342993
# Unit test for function remove_values
def test_remove_values():
    assert remove_values('foo', ['foo']) == 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'
    assert remove_values('foo', ['bar']) == 'foo'
    assert remove_values('foo', ['foo', 'bar']) == 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'
    assert remove_values('foo', ['foo', 'bar', 'baz']) == 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'
    assert remove_values('foo', ['foo', 'bar', 'baz']) == 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'
    assert remove_values('foo', ['foo', 'bar', 'baz']) == 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'
    assert remove

# Generated at 2022-06-16 22:53:00.154830
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:53:06.628788
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:53:17.943738
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:53:28.314576
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:53:40.766597
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'foo'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'foo'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK', 'ANSIBLE_TEST_ENV_FALLBACK2') == 'foo'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK2', 'ANSIBLE_TEST_ENV_FALLBACK') == 'foo'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK2') == 'foo'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK2', 'ANSIBLE_TEST_ENV_FALLBACK3') == 'foo'
    assert env

# Generated at 2022-06-16 22:53:49.001419
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:54:01.181578
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:54:10.702877
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == os.environ['ANSIBLE_TEST_ENV_FALLBACK']
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK', 'ANSIBLE_TEST_ENV_FALLBACK2') == os.environ['ANSIBLE_TEST_ENV_FALLBACK']
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK2', 'ANSIBLE_TEST_ENV_FALLBACK') == os.environ['ANSIBLE_TEST_ENV_FALLBACK2']
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_SET')



# Generated at 2022-06-16 22:54:22.107050
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:54:26.529241
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'ANSIBLE_TEST_ENV_FALLBACK'
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_FOUND')



# Generated at 2022-06-16 22:54:59.913479
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:55:12.090713
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:55:23.615756
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:55:35.309349
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:55:44.169153
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK', 'ANSIBLE_TEST_ENV_FALLBACK_2') == 'test'
    os.environ['ANSIBLE_TEST_ENV_FALLBACK_2'] = 'test2'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_3', 'ANSIBLE_TEST_ENV_FALLBACK_2') == 'test2'
    del os.environ['ANSIBLE_TEST_ENV_FALLBACK']

# Generated at 2022-06-16 22:55:53.827338
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'param1': {'type': 'str', 'fallback': (env_fallback, 'PARAM1')},
        'param2': {'type': 'str', 'fallback': (env_fallback, 'PARAM2')},
        'param3': {'type': 'str', 'fallback': (env_fallback, 'PARAM3')},
    }
    parameters = {'param1': 'value1'}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['param1'] == 'value1'
    assert parameters['param2'] == 'value2'
    assert parameters['param3'] == 'value3'
    assert no_log_values == set()



# Generated at 2022-06-16 22:56:02.913582
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:56:13.207053
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'ANSIBLE_TEST_ENV_FALLBACK'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK', 'ANSIBLE_TEST_ENV_FALLBACK2') == 'ANSIBLE_TEST_ENV_FALLBACK'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK2', 'ANSIBLE_TEST_ENV_FALLBACK') == 'ANSIBLE_TEST_ENV_FALLBACK'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK2') == 'ANSIBLE_TEST_ENV_FALLBACK2'

# Generated at 2022-06-16 22:56:24.965415
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys({'a': 'b', 'c': 'd'}, ['b']) == {'a': 'b', 'c': 'd'}
    assert sanitize_keys({'a': 'b', 'c': 'd'}, ['b', 'd']) == {'a': 'b', 'c': 'd'}
    assert sanitize_keys({'a': 'b', 'c': 'd'}, ['b', 'd'], ignore_keys=['c']) == {'a': 'b', 'c': 'd'}
    assert sanitize_keys({'a': 'b', 'c': 'd'}, ['b', 'd'], ignore_keys=['a']) == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-16 22:56:36.732809
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:57:31.249891
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys({'a': 'b', 'c': 'd'}, ['b']) == {'a': 'b', 'c': 'd'}
    assert sanitize_keys({'a': 'b', 'c': 'd'}, ['a']) == {'c': 'd'}
    assert sanitize_keys({'a': 'b', 'c': 'd'}, ['a', 'b']) == {'c': 'd'}
    assert sanitize_keys({'a': 'b', 'c': 'd'}, ['a', 'c']) == {}
    assert sanitize_keys({'a': 'b', 'c': 'd'}, ['a', 'c', 'd']) == {}

# Generated at 2022-06-16 22:57:43.418655
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:57:53.852253
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:58:05.837102
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:58:15.451182
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:58:27.660521
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys({'a': 'b', 'c': 'd'}, ['b']) == {'a': 'b', 'c': 'd'}
    assert sanitize_keys({'a': 'b', 'c': 'd'}, ['a']) == {'c': 'd'}
    assert sanitize_keys({'a': 'b', 'c': 'd'}, ['a', 'b']) == {'c': 'd'}
    assert sanitize_keys({'a': 'b', 'c': 'd'}, ['a', 'b', 'c']) == {}
    assert sanitize_keys({'a': 'b', 'c': 'd'}, ['a', 'b', 'c', 'd']) == {}