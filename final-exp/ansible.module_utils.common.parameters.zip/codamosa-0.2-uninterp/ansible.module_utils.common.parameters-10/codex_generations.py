

# Generated at 2022-06-16 22:49:06.851079
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:49:17.562900
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK', 'ANSIBLE_TEST_ENV_FALLBACK2') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK2', 'ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK2') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK2', 'ANSIBLE_TEST_ENV_FALLBACK2') == 'test'
    assert env

# Generated at 2022-06-16 22:49:25.487450
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:49:33.231499
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:49:41.879685
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test_env_fallback'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test_env_fallback'
    del os.environ['ANSIBLE_TEST_ENV_FALLBACK']
    try:
        env_fallback('ANSIBLE_TEST_ENV_FALLBACK')
    except AnsibleFallbackNotFound:
        pass
    else:
        assert False



# Generated at 2022-06-16 22:49:54.454192
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'param1': {'type': 'str', 'fallback': (env_fallback, 'PARAM1')},
        'param2': {'type': 'str', 'fallback': (env_fallback, 'PARAM2')},
        'param3': {'type': 'str', 'fallback': (env_fallback, 'PARAM3')},
        'param4': {'type': 'str', 'fallback': (env_fallback, 'PARAM4')},
        'param5': {'type': 'str', 'fallback': (env_fallback, 'PARAM5')},
    }
    parameters = {'param1': 'value1'}
    no_log_values = set_fallbacks(argument_spec, parameters)

# Generated at 2022-06-16 22:50:03.398671
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        foo=dict(type='str', fallback=(env_fallback, 'FOO')),
        bar=dict(type='str', fallback=(env_fallback, 'BAR')),
        baz=dict(type='str', fallback=(env_fallback, 'BAZ')),
        qux=dict(type='str', fallback=(env_fallback, 'QUX')),
        quux=dict(type='str', fallback=(env_fallback, 'QUUX')),
    )
    parameters = dict(
        foo='foo',
        bar='bar',
        baz='baz',
    )
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['qux'] == 'qux'
    assert 'quux' not in parameters

# Generated at 2022-06-16 22:50:09.681248
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK', 'ANSIBLE_TEST_ENV_FALLBACK_2') == 'test'
    os.environ['ANSIBLE_TEST_ENV_FALLBACK_2'] = 'test2'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_2', 'ANSIBLE_TEST_ENV_FALLBACK') == 'test2'
    del os.environ['ANSIBLE_TEST_ENV_FALLBACK']

# Generated at 2022-06-16 22:50:18.494206
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:50:24.995372
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:50:51.690583
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK', 'ANSIBLE_TEST_ENV_FALLBACK_2') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_2', 'ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_2') == 'test'

# Generated at 2022-06-16 22:51:03.976345
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:51:16.350027
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:51:24.665199
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    del os.environ['ANSIBLE_TEST_ENV_FALLBACK']
    try:
        env_fallback('ANSIBLE_TEST_ENV_FALLBACK')
    except AnsibleFallbackNotFound:
        pass
    else:
        assert False, 'env_fallback did not raise AnsibleFallbackNotFound'



# Generated at 2022-06-16 22:51:34.314056
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'param1': {'type': 'str', 'fallback': (env_fallback, 'TEST_PARAM1')},
                     'param2': {'type': 'str', 'fallback': (env_fallback, 'TEST_PARAM2')},
                     'param3': {'type': 'str', 'fallback': (env_fallback, 'TEST_PARAM3')}}
    parameters = {'param1': 'test'}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['param1'] == 'test'
    assert parameters['param2'] == 'test2'
    assert parameters['param3'] == 'test3'
    assert no_log_values == set(['test2', 'test3'])



# Generated at 2022-06-16 22:51:46.215494
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys({'a': 'b', 'c': 'd'}, ['b']) == {'a': 'b', 'c': 'd'}
    assert sanitize_keys({'a': 'b', 'c': 'd'}, ['b', 'c']) == {'a': 'b', '_ansible_no_log_c': 'd'}
    assert sanitize_keys({'a': 'b', 'c': 'd'}, ['b', 'c'], ignore_keys=['c']) == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-16 22:51:57.604465
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:52:08.456014
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:52:18.388230
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:52:23.939120
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    del os.environ['ANSIBLE_TEST_ENV_FALLBACK']
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'



# Generated at 2022-06-16 22:52:46.273730
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test_env_fallback'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test_env_fallback'
    del os.environ['ANSIBLE_TEST_ENV_FALLBACK']
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test_env_fallback'



# Generated at 2022-06-16 22:52:52.528161
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:53:03.633889
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'ANSIBLE_TEST_ENV_FALLBACK'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_1', 'ANSIBLE_TEST_ENV_FALLBACK_2') == 'ANSIBLE_TEST_ENV_FALLBACK_1'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_1', 'ANSIBLE_TEST_ENV_FALLBACK_2') == 'ANSIBLE_TEST_ENV_FALLBACK_1'

# Generated at 2022-06-16 22:53:12.003749
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:53:24.334488
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:53:36.842421
# Unit test for function remove_values
def test_remove_values():
    # Test for simple values
    assert remove_values('test', ['test']) == '*****'
    assert remove_values('test', ['test', 'test']) == '*****'
    assert remove_values('test', ['test', 'test', 'test']) == '*****'
    assert remove_values('test', ['test', 'test', 'test', 'test']) == '*****'
    assert remove_values('test', ['test', 'test', 'test', 'test', 'test']) == '*****'
    assert remove_values('test', ['test', 'test', 'test', 'test', 'test', 'test']) == '*****'
    assert remove_values('test', ['test', 'test', 'test', 'test', 'test', 'test', 'test']) == '*****'

# Generated at 2022-06-16 22:53:42.998758
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:53:52.337813
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:54:04.772297
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:54:14.023600
# Unit test for function remove_values
def test_remove_values():
    assert remove_values(1, []) == 1
    assert remove_values('foo', ['foo']) == 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'
    assert remove_values('foo', ['bar']) == 'foo'
    assert remove_values('foo', ['foo', 'bar']) == 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'
    assert remove_values('foo', ['foo', 'bar', 'baz']) == 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'
    assert remove_values('foo', ['foo', 'bar', 'baz']) == 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'

# Generated at 2022-06-16 22:54:43.221423
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:54:52.272994
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:54:57.672162
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['TEST_ENV_FALLBACK'] = 'test'
    assert env_fallback('TEST_ENV_FALLBACK') == 'test'
    os.environ.pop('TEST_ENV_FALLBACK')
    assert env_fallback('TEST_ENV_FALLBACK') == 'test'



# Generated at 2022-06-16 22:55:09.305191
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:55:19.187536
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:55:24.297508
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test_env_fallback'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test_env_fallback'
    del os.environ['ANSIBLE_TEST_ENV_FALLBACK']
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('ANSIBLE_TEST_ENV_FALLBACK')



# Generated at 2022-06-16 22:55:35.885025
# Unit test for function remove_values
def test_remove_values():
    assert remove_values('foo', ['o']) == 'f'
    assert remove_values('foo', ['o', 'f']) == ''
    assert remove_values('foo', ['o', 'f', 'x']) == ''
    assert remove_values('foo', ['x']) == 'foo'
    assert remove_values('foo', ['x', 'y']) == 'foo'
    assert remove_values('foo', ['x', 'y', 'z']) == 'foo'
    assert remove_values('foo', ['f', 'o']) == ''
    assert remove_values('foo', ['f', 'o', 'x']) == ''
    assert remove_values('foo', ['f', 'o', 'x', 'y']) == ''

# Generated at 2022-06-16 22:55:44.494911
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:55:54.688303
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:56:03.529445
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:56:39.815129
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:56:51.139728
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:57:02.864926
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys({'a': 'b', 'c': {'d': 'e'}}, ['b']) == {'a': 'b', 'c': {'d': 'e'}}
    assert sanitize_keys({'a': 'b', 'c': {'d': 'e'}}, ['b', 'a']) == {'c': {'d': 'e'}}
    assert sanitize_keys({'a': 'b', 'c': {'d': 'e'}}, ['b', 'a'], ignore_keys=['c']) == {'c': {'d': 'e'}}

# Generated at 2022-06-16 22:57:10.889641
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:57:21.572007
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:57:30.561508
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:57:42.860575
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:57:52.307433
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:58:04.148822
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:58:14.306534
# Unit test for function set_fallbacks