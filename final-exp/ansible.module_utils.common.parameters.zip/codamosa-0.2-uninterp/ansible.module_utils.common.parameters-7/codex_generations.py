

# Generated at 2022-06-16 22:49:37.664394
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:49:50.741143
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:50:01.058236
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:50:10.638917
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:50:19.241787
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:50:32.054093
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:50:41.977106
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:50:51.462863
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys({'a': 'b'}, ['b']) == {'a': 'b'}
    assert sanitize_keys({'a': 'b'}, ['a']) == {'a': 'b'}
    assert sanitize_keys({'a': 'b'}, ['a', 'b']) == {'a': 'b'}
    assert sanitize_keys({'a': 'b'}, ['a', 'b'], ignore_keys=['a']) == {'a': 'b'}
    assert sanitize_keys({'a': 'b'}, ['a', 'b'], ignore_keys=['b']) == {'a': 'b'}

# Generated at 2022-06-16 22:51:03.751829
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:51:15.224746
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        foo=dict(type='str', fallback=(env_fallback, 'FOO')),
        bar=dict(type='str', fallback=(env_fallback, 'BAR')),
        baz=dict(type='str', fallback=(env_fallback, 'BAZ')),
        qux=dict(type='str', fallback=(env_fallback, 'QUX')),
    )
    parameters = dict(
        foo='foo',
        bar='bar',
        baz='baz',
    )
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['foo'] == 'foo'
    assert parameters['bar'] == 'bar'
    assert parameters['baz'] == 'baz'

# Generated at 2022-06-16 22:52:16.760096
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:52:23.827268
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:52:36.266382
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:52:43.004488
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'ANSIBLE_TEST_ENV_FALLBACK'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'ANSIBLE_TEST_ENV_FALLBACK'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_FOUND') == 'ANSIBLE_TEST_ENV_FALLBACK_NOT_FOUND'
    del os.environ['ANSIBLE_TEST_ENV_FALLBACK']



# Generated at 2022-06-16 22:52:46.411157
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    del os.environ['ANSIBLE_TEST_ENV_FALLBACK']
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('ANSIBLE_TEST_ENV_FALLBACK')



# Generated at 2022-06-16 22:52:52.637933
# Unit test for function remove_values
def test_remove_values():
    assert remove_values('foo', ['foo']) == 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER'
    assert remove_values('foo', ['bar']) == 'foo'
    assert remove_values('foo', ['o']) == 'fVALUE_SPECIFIED_IN_NO_LOG_PARAMETER'
    assert remove_values('foo', ['oo']) == 'fVALUE_SPECIFIED_IN_NO_LOG_PARAMETER'
    assert remove_values('foo', ['f']) == 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETERo'
    assert remove_values('foo', ['fo']) == 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETERo'

# Generated at 2022-06-16 22:53:03.719705
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:53:12.072317
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:53:24.431225
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_FOUND') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_FOUND', 'ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK_NOT_FOUND', 'ANSIBLE_TEST_ENV_FALLBACK_NOT_FOUND') == 'test'

# Generated at 2022-06-16 22:53:36.896336
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:55:23.574074
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys({'foo': 'bar', 'baz': 'qux'}, ['bar']) == {'foo': 'bar', 'baz': 'qux'}
    assert sanitize_keys({'foo': 'bar', 'baz': 'qux'}, ['qux']) == {'foo': 'bar', 'baz': 'qux'}
    assert sanitize_keys({'foo': 'bar', 'baz': 'qux'}, ['bar', 'qux']) == {'foo': 'bar', 'baz': 'qux'}
    assert sanitize_keys({'foo': 'bar', 'baz': 'qux'}, ['bar', 'qux', 'foo']) == {'foo': 'bar', 'baz': 'qux'}
    assert sanitize_keys

# Generated at 2022-06-16 22:55:35.257096
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test_env_fallback'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test_env_fallback'
    del os.environ['ANSIBLE_TEST_ENV_FALLBACK']
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test_env_fallback'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK', 'ANSIBLE_TEST_ENV_FALLBACK') == 'test_env_fallback'

# Generated at 2022-06-16 22:55:44.103633
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:55:54.341077
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:56:03.294363
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:56:13.485710
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:56:25.191606
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:56:32.296906
# Unit test for function sanitize_keys
def test_sanitize_keys():
    # Test that sanitize_keys() works with a dict
    data = {'a': 'b', 'c': 'd'}
    new_data = sanitize_keys(data, ['b'])
    assert new_data == {'a': 'b', 'c': 'd'}

    # Test that sanitize_keys() works with a list
    data = ['a', 'b', 'c']
    new_data = sanitize_keys(data, ['b'])
    assert new_data == ['a', 'b', 'c']

    # Test that sanitize_keys() works with a set
    data = set(['a', 'b', 'c'])
    new_data = sanitize_keys(data, ['b'])

# Generated at 2022-06-16 22:56:45.011441
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:56:53.985755
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:57:57.849067
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'param1': {'type': 'str', 'fallback': (env_fallback, 'PARAM1')},
        'param2': {'type': 'str', 'fallback': (env_fallback, 'PARAM2')},
    }
    parameters = {'param1': 'value1'}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['param1'] == 'value1'
    assert parameters['param2'] == 'value2'
    assert no_log_values == set()

    os.environ['PARAM1'] = 'env_value1'
    parameters = {}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['param1'] == 'env_value1'

# Generated at 2022-06-16 22:58:09.587828
# Unit test for function set_fallbacks

# Generated at 2022-06-16 22:58:17.389484
# Unit test for function env_fallback
def test_env_fallback():
    os.environ['ANSIBLE_TEST_ENV_FALLBACK'] = 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK2') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK', 'ANSIBLE_TEST_ENV_FALLBACK2') == 'test'
    assert env_fallback('ANSIBLE_TEST_ENV_FALLBACK2', 'ANSIBLE_TEST_ENV_FALLBACK') == 'test'

# Generated at 2022-06-16 22:58:28.550383
# Unit test for function set_fallbacks