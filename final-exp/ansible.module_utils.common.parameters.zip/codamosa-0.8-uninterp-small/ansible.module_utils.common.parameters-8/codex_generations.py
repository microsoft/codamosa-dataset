

# Generated at 2022-06-24 20:46:53.128724
# Unit test for function set_fallbacks
def test_set_fallbacks():
    spec = {'test_param': {'type': 'str', 'fallback': (env_fallback, ['TEST_ENV_VAR'])}}
    parameters = {'test_param': 'test_value'}
    parameters_with_env = {}

    no_log_values = set_fallbacks(spec, parameters)
    assert 0 == len(no_log_values)

    os.environ['TEST_ENV_VAR'] = 'test_env_value'
    no_log_values = set_fallbacks(spec, parameters_with_env)
    assert 1 == len(no_log_values)
    assert 'test_env_value' in no_log_values
    del os.environ['TEST_ENV_VAR']


# Generated at 2022-06-24 20:46:59.805173
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'name': dict(type='str'), 'test': dict(type='bool', fallback=(env_fallback, 'ANSIBLE_TEST_FALLBACK'))}
    parameters = {}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert set(parameters.keys()) == set(('test',))
    assert parameters['test'] == False, "expected False, got: %s" % parameters['test']
    assert no_log_values == set(), "expected no_log_values to be empty set, got: %s" % no_log_values


# Generated at 2022-06-24 20:47:03.709742
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'fallback': {
                'type': 'dict',
                'fallback': (env_fallback, ['ENV_VAR'])
                }
            }
    parameters = {}
    assert set_fallbacks(argument_spec, parameters) == set()


# Generated at 2022-06-24 20:47:15.152104
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec_0 = {'fallback': (env_fallback, 'ANSIBLE_NET_IFACE')}
    argument_spec_1 = {'fallback': (env_fallback, ['ANSIBLE_NET_IFACE'])}
    argument_spec_2 = {'fallback': (env_fallback, ['ANSIBLE_NET_IFACE'], {'fallback': 'default'})}

    parameters_0 = {}
    parameters_1 = {'param': 'value'}

    # No fallback
    fallback_no = set_fallbacks(argument_spec_0, parameters_1)
    assert fallback_no == set()

    # With fallback with no args
    fallback_no_args = set_fallbacks(argument_spec_0, parameters_0)

# Generated at 2022-06-24 20:47:24.967167
# Unit test for function sanitize_keys
def test_sanitize_keys():
    # Provide access to the module so the test can see what class to check for.
    global _AnsibleModule
    _AnsibleModule = AnsibleModule

    # This test tries to load a module with some parameters removed from
    # the module. The test script runs multiple times and each time it
    # removes different parameters from the module.

    no_log_strings = ['no_log_values', 'no_log_strings']

    module_args = {'no_log_values': 'no_log_values', 'no_log_strings': 'no_log_strings'}

    # Keep track of all the no_log_strings we've seen so far.
    seen_no_log_strings = set(no_log_strings)

    # Get the module parameter specs.

# Generated at 2022-06-24 20:47:30.936360
# Unit test for function remove_values
def test_remove_values():
    assert not hasattr(remove_values, 'arguments')
    assert remove_values('test', ['test']) == '***'
    assert remove_values('', ['test']) == ''
    assert remove_values('test', ['test', 'test']) == '***'
    assert remove_values('test', ['test', '*']) == '***'
    assert remove_values('test', ['test', '*st']) == '***'
    assert remove_values('testtest', ['test', 'test']) == '******'
    assert remove_values('testtest', ['test', '*t']) == '******'
    assert remove_values('testtest', ['test']) == '****test'
    assert remove_values('testtest', ['*']) == '****'

# Generated at 2022-06-24 20:47:37.781397
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(param1=dict(type='str'))
    parameters = dict()

    no_log_values = set_fallbacks(argument_spec, parameters)
    assert no_log_values == set()

    argument_spec = dict(param1=dict(default='default value'))
    parameters = dict()

    no_log_values = set_fallbacks(argument_spec, parameters)
    assert no_log_values == set()

    argument_spec = dict(param1=dict(default='default value', no_log=True))
    parameters = dict()

    no_log_values = set_fallbacks(argument_spec, parameters)
    assert no_log_values == {'default value'}

    parameters['param1'] = 'param value'

# Generated at 2022-06-24 20:47:41.335164
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'argument_name': {'type': 'str', 'fallback': (env_fallback, ('arg_name', 'arg_name1'))}}
    parameters = {}
    set_fallbacks(argument_spec, parameters)


# Generated at 2022-06-24 20:47:42.877537
# Unit test for function env_fallback
def test_env_fallback():
    dict_0 = {}
    var_0 = env_fallback(**dict_0)


# Generated at 2022-06-24 20:47:53.454599
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        "name": {
            'type': 'str',
            'default': None,
            'fallback': ('env', ('ANSIBLE_NET_USERNAME',)),
            'no_log': True
        },
        "password": {
            'type': 'str',
            'default': None,
            'fallback': ('env', ('ANSIBLE_NET_PASSWORD',)),
            'no_log': True
        },
        "enable": {
            'type': 'bool',
            'default': False,
            'fallback': ('env', ('ANSIBLE_NET_ENABLE',)),
            'no_log': True
        }
    }
    parameters = {
        "name": "test",
    }
    no_log_values = set_fallbacks(argument_spec, parameters)


# Generated at 2022-06-24 20:48:38.189381
# Unit test for function set_fallbacks
def test_set_fallbacks():

    # Test for 'dict' type argument
    dict_0 = {}
    dict_0['vault_password_file'] = 'some_value'
    dict_0['aliases'] = 'some_value'
    dict_0['hosts'] = 'some_value'
    dict_1 = get_fallback_dict(dict_0)
    if dict_1 != {'vault_password_file': None, 'aliases': None, 'hosts': None}:
        raise ValueError('Failed assert: set_fallbacks({}) != get_fallback_dict({})'.format(dict(dict_0), dict(dict_1)))

    # Test for 'list' type argument
    dict_0 = {}
    dict_0['roles'] = 'some_value'
    dict_0['hosts'] = 'some_value'

# Generated at 2022-06-24 20:48:38.968908
# Unit test for function env_fallback
def test_env_fallback():
    response = env_fallback()
    assert response == AnsibleFallbackNotFound


# Generated at 2022-06-24 20:48:44.599121
# Unit test for function sanitize_keys
def test_sanitize_keys():
    # Testing var_0
    dict_0 = {}
    var_0 = env_fallback(**dict_0)

    no_log_strings = frozenset()
    ignore_keys = frozenset()

    var_0 = sanitize_keys(var_0, no_log_strings, ignore_keys)
    assert(var_0 == '0')


# Generated at 2022-06-24 20:48:52.969851
# Unit test for function remove_values
def test_remove_values():
    assert remove_values(True, ["a"]) == True
    assert remove_values(1, ["a"]) == 1
    assert remove_values(3.14, ["a"]) == 3.14
    assert remove_values('a', ["a"]) == 'a'
    assert remove_values(b'a', ["a"]) == b'a'
    assert remove_values([], ["a"]) == []
    assert remove_values({}, ["a"]) == {}
    assert remove_values(set([]), ["a"]) == set([])
    assert remove_values(frozenset([]), ["a"]) == frozenset([])

    assert remove_values([1, 'b', 1, True], [1]) == ['b', True]

# Generated at 2022-06-24 20:49:03.863267
# Unit test for function set_fallbacks
def test_set_fallbacks():
    dict_0 = {}

    dict_1 = {}
    dict_1['param'] = 'fallback'
    dict_1['type'] = 'str'
    dict_1['fallback'] = (env_fallback, 'ENV1', {'default': 'ansible_default_value'}, )

    dict_2 = {}
    dict_2['param'] = 'fallback_list'
    dict_2['type'] = 'list'
    dict_2['elements'] = 'str'
    dict_2['fallback'] = (env_fallback, 'ENV_LIST', ['item1', 'item2'])

    dict_3 = {}
    dict_3['param'] = 'fallback_no_log'
    dict_3['type'] = 'str'

# Generated at 2022-06-24 20:49:08.993263
# Unit test for function remove_values
def test_remove_values():
    no_log_strings = frozenset(['remove_me'])

    # Test that remove_values is idempotent when given a simple
    # type with no no_log strings.
    value = 'no_change'
    assert value == remove_values(value, no_log_strings)

    # Test that remove_values works when given a simple type
    # which has a no_log string.
    value = 'test_remove_me'
    assert '' == remove_values(value, no_log_strings)

    # Test that remove_values is idempotent when given a
    # container with no no_log strings.
    value = ['no_change_0', 'no_change_1']
    assert value == remove_values(value, no_log_strings)

    # Test that remove_values works when given a container

# Generated at 2022-06-24 20:49:10.313339
# Unit test for function env_fallback
def test_env_fallback():
    try:
        test_case_0()
    except AnsibleFallbackNotFound:
        pass
    else:
        raise AssertionError("Expected an exception to be raised")

# Generated at 2022-06-24 20:49:18.343100
# Unit test for function sanitize_keys
def test_sanitize_keys():
    dict_0 = {}
    var_0 = env_fallback(**dict_0)
    print("Testing")
    print(var_0)

    dict = {
        "VAR": "This is a word in the string",
        "VAR2": "This is a var in the string"
    }

    new_string = "_VAR_VAR2_This is a word in the string"
    dict = dict.update({
        "VAR": "This is a word in the string",
        "VAR2": "This is a var in the string"
    })
    new_string = "_VAR_VAR2_This is a word in the string"

    if new_string == sanitize_keys(new_string, dict):
        print("test_sanitize_keys: PASSED")

# Generated at 2022-06-24 20:49:25.966872
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        "environment": {
            "type": "str",
            "required": True,
            "fallback": (env_fallback, "ANSIBLE_ENVIRONMENT")
        },
        "password": {
            "type": "str",
            "required": True,
            "no_log": True,
            "fallback": (env_fallback, "ANA_PASS")
        }
    }
    parameters = {}
    assert set_fallbacks(argument_spec, parameters) == {'ANA_PASS'}
    assert parameters['environment'] == 'ANSIBLE_ENVIRONMENT'


# Generated at 2022-06-24 20:49:32.784324
# Unit test for function set_fallbacks
def test_set_fallbacks():
    arguments_spec = {"name": {"aliases": ["resource"], "type": "str", "options": [],}, "state": {"type": "str", "choices": ["absent", "present"], "default": "present", "options": [],},}
    parameter = {"name": "test_1", "state": "present",}
    result = set_fallbacks(arguments_spec, parameter)
    assert result == set()



# Generated at 2022-06-24 20:50:02.789964
# Unit test for function env_fallback
def test_env_fallback():
    assert 'test_case_0' in globals(),\
        "test_case_0 does not exist. Please check your test."
    try:
        assert callable(test_case_0),\
            "test_case_0 is not callable. Please check your test."
        test_case_0()
    except AssertionError as ae:
        print(ae)
        print("Please fix the failing test.")
        raise ae
    except Exception as e:
        print("Error encountered while testing 'env_fallback'.")
        print(to_native(e))
        raise e
    else:
        print("Test 'env_fallback' passed.")



# Generated at 2022-06-24 20:50:06.235043
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Test for absence of argument
    try:
        set_fallbacks()
    except TypeError:
        pass
    else:
        assert False

    # Test for presence of argument but absence of the specific argument
    try:
        set_fallbacks(123)
    except TypeError:
        pass
    else:
        assert False


# Generated at 2022-06-24 20:50:08.279614
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert env_fallback() == None, 'Unit test failed'


# Generated at 2022-06-24 20:50:14.056818
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # construct expected parameters
    expected = dict()
    expected['key_0'] = None

    # construct the argument_spec
    argument_spec = dict()
    argument_spec['key_0'] = {'type': 'str', 'fallback': (env_fallback, ['key_0'])}

    # construct parameters
    parameters = dict()

    # call the function
    no_log_values = set_fallbacks(argument_spec, parameters)

    assert parameters == expected


# Generated at 2022-06-24 20:50:15.723999
# Unit test for function remove_values
def test_remove_values():
    with pytest.raises(AnsibleFallbackNotFound):
        test_case_0()
    var_1 = remove_values(True, [])
    assert var_1 == True

# Generated at 2022-06-24 20:50:24.572477
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        key=dict(fallback=(env_fallback, 'env_key', 'env_key_second')),
        key_dict=dict(fallback=(env_fallback, {'vars': ['env_key_dict', 'env_key_dict_second', 'no_env']})),
        key_with_default=dict(fallback=(env_fallback, 'env_key_default', 'no_env'), default="default"),
    )
    parameters = dict(
        key="value",
        key_no_env="value",
    )
    no_log_values = set()
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters["key"] == "value"
    assert parameters["key_dict"] == "value"

# Generated at 2022-06-24 20:50:34.657857
# Unit test for function set_fallbacks
def test_set_fallbacks():
    """Test for set_fallbacks"""

    ARGUMENT_SPEC = dict(
        param=dict(type='str', fallback=(env_fallback, 'PARAM')),
        param2=dict(type='str', fallback=(env_fallback, 'PARAM2')),
        param3=dict(type='str', fallback=(env_fallback, 'PARAM3'))
    )
    PARAMETERS = dict(param='foo')
    NO_LOG_VALUES = set()

    no_log_values = set_fallbacks(ARGUMENT_SPEC, PARAMETERS)
    assert no_log_values == NO_LOG_VALUES


# Generated at 2022-06-24 20:50:42.973797
# Unit test for function set_fallbacks
def test_set_fallbacks():
    var_0 = env_fallback()
    var_1 = {"var": var_0}
    var_2 = {"var": "OS_AUTH_URL"}
    var_3 = {"type": "str", "fallback": (env_fallback, "OS_AUTH_URL")}
    var_4 = {"type": "str", "fallback": (env_fallback, var_2)}
    var_5 = {"arg_0": var_3}
    var_6 = {"arg_0": var_4}
    var_7 = {"arg_0": var_3, "arg_1": var_4}
    var_8 = {"arg_0": var_4, "arg_1": var_3}
    var_9 = {"arg_0": var_3, "arg_1": var_3}

# Generated at 2022-06-24 20:50:55.076078
# Unit test for function remove_values
def test_remove_values():
    assert remove_values('test', ['test']) == ''
    assert remove_values('test', ['test']) is not None
    assert remove_values('test', ['test']) is not True
    assert remove_values(None, ['test']) is None
    assert remove_values(True, ['test']) is True
    assert remove_values(False, ['test']) is False
    assert remove_values(['test'], ['test']) == []
    assert remove_values(('test',), ['test']) == ()
    assert remove_values({'test': 'test'}, ['test']) == {'test': ''}
    assert remove_values({'test': 'test', 'test2': 'test2'}, ['test', 'test2']) == {}

# Generated at 2022-06-24 20:50:57.223255
# Unit test for function env_fallback
def test_env_fallback():
    # Catch the exception raised if no argument is passed
    with pytest.raises(AnsibleFallbackNotFound):
        test_case_0()


# Generated at 2022-06-24 20:52:04.361429
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {"aliases": {"choices": None, "type": "list", "elements": "str"}}
    parameters = {}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert no_log_values == set()



# Generated at 2022-06-24 20:52:13.871878
# Unit test for function set_fallbacks
def test_set_fallbacks():
    foo = {'bar': {'env': 'FOO', 'required': True, 'fallback': (env_fallback, ['BAR'], {'default': 'DEFAULT_BAR'})}}
    data = {}
    no_log_values = set_fallbacks(foo, data)
    assert 'DEFAULT_BAR' in data
    assert data['bar'] == 'DEFAULT_BAR'
    assert 'DEFAULT_BAR' in no_log_values

    # test all fallback strategies
    data = {}
    no_log_values = set_fallbacks({'bar': dict(
        fallback=(env_fallback, 'BAR'),
        no_log=True,
        required=False,
    )}, data)
    assert 'bar' in data
    assert 'bar' not in no_log_values

# Generated at 2022-06-24 20:52:14.951961
# Unit test for function sanitize_keys
def test_sanitize_keys():
    var_0 = env_fallback()
    assert None not in var_0



# Generated at 2022-06-24 20:52:16.950437
# Unit test for function env_fallback
def test_env_fallback():
    with pytest.raises(AnsibleFallbackNotFound) as error:
        test_case_0()
    assert error.type == AnsibleFallbackNotFound

# Generated at 2022-06-24 20:52:24.178994
# Unit test for function sanitize_keys
def test_sanitize_keys():
    no_log_strings = ['abcabc']
    ignore_keys = ['abcabc']
    obj = {
        'abcabc': [
            "abcabc"
        ],
        'abcabc': [
            "abcabc"
        ],
        'abcabc': {
            'abcabc': "abcabc"
        },
        'abcabc': {
            'abcabc': 'abcabc'
        },
        'abcabc': [
            'abcabc',
            'abcabc',
            {
                'abcabc': 'abcabc',
            }
        ],
    }


# Generated at 2022-06-24 20:52:31.244997
# Unit test for function remove_values
def test_remove_values():
    assert remove_values('abcd', ['ab', 'bc']) == 'cd'
    assert remove_values('', ['ab', 'bc']) == ''
    assert remove_values(None, ['ab', 'bc']) == None
    assert remove_values('c', ['ab', 'bc']) == 'c'
    assert remove_values('abccc', ['ab', 'bc']) == 'ccc'
    assert remove_values('abcd', ['ab', 'bc', 'cd']) == ''
    assert remove_values('abcd', ['cd', 'ab', 'bc']) == ''
    assert remove_values({'a': 'abcd', 'b': 'abcd'}, ['ab', 'bc']) == {'a': 'cd', 'b': 'cd'}

# Generated at 2022-06-24 20:52:32.929494
# Unit test for function remove_values
def test_remove_values():
    var_0 = remove_values(env_fallback(), env_fallback())
    var_1 = remove_values(env_fallback(), env_fallback())
    



# Generated at 2022-06-24 20:52:40.767727
# Unit test for function set_fallbacks
def test_set_fallbacks():
    spec = {
        'var_0': {'required': True, 'type': 'str', 'fallback': (env_fallback, ['var_0'])},
    }
    parameters = {
    }
    try:
        set_fallbacks(spec, parameters)
        if not parameters.get("var_0"):
            raise Exception("Required argument 'var_0' is not present!")
    except Exception as e:
        print("Parameter validation error:", e)
        raise


# Generated at 2022-06-24 20:52:42.859707
# Unit test for function env_fallback
def test_env_fallback():
    with pytest.raises(AnsibleFallbackNotFound):
        test_case_0()



# Generated at 2022-06-24 20:52:46.127849
# Unit test for function env_fallback
def test_env_fallback():
    var_0 = env_fallback()
    assert var_0 is None, "Ensure that the var_0 is of the type None"

    var_1 = env_fallback()
    assert var_1 is None, "Ensure that the var_1 is of the type None"


# Generated at 2022-06-24 20:53:16.317349
# Unit test for function set_fallbacks
def test_set_fallbacks():

    # Test with a valid argument_spec
    argument_spec = {'var_1': {'type': 'str',
                               'required': True,
                               'no_log': True,
                               'fallback': (env_fallback, 'var_1')},
                     'var_2': {'type': 'str',
                               'required': True,
                               'no_log': False,
                               'fallback': (env_fallback, 'var_2')},
                     'var_3': {'type': 'str',
                               'required': True,
                               'no_log': True,
                               'fallback': (env_fallback, 'var_3')}}
    parameters = {'var_1': 'my_value'}


# Generated at 2022-06-24 20:53:26.706285
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Setup mock input parameters
    argument_spec = {
        'hostname': {
            'type': 'str',
            'default': '10.9.8.23'
        },
        'username': {
            'type': 'str',
            'default': 'admin'
        }
    }
    parameters = {
        'hostname': '10.9.8.23',
        'username': 'admin'
    }

    # Run set_fallbacks
    no_log_values = set_fallbacks(argument_spec, parameters)
    expected_no_log_values = set()
    assert no_log_values == expected_no_log_values, 'set_fallbacks produced incorrect results.'


# Generated at 2022-06-24 20:53:29.411565
# Unit test for function env_fallback
def test_env_fallback():
    try:
        env_fallback()
    except Exception:
        assert False,'No exception'
    assert True

if __name__ == "__main__":
    test_env_fallback()

# Generated at 2022-06-24 20:53:32.050190
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'var_0': {'type': 'str', 'fallback': (env_fallback,)}}
    parameters = {'var_0': 'pow'}
    assert set_fallbacks(argument_spec, parameters) == set()


# Generated at 2022-06-24 20:53:42.674417
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Define a dict that will be used as the argument spec
    arg_spec = {}
    # Add the key 'param' to the argument spec
    arg_spec['param'] = ('param_value', {'arg': 'arg_value'})
    # Create fake parameters dict
    params = {'param1': 'param1_value', 'param2': 'param2_value'}
    # Define a set of no_log values
    no_log_values = set()
    # Update the set of no_log values with the value returned by the set_fallbacks function
    no_log_values.update(set_fallbacks(arg_spec, params))
    # Test that the value returned by the set_fallbacks function is what we expect
    assert no_log_values == set()

# Generated at 2022-06-24 20:53:49.462523
# Unit test for function set_fallbacks
def test_set_fallbacks():
    var_0 = AnsibleModule(argument_spec=dict(var_0=dict(type='str')))
    assert var_0 is not None
    # Test with a lambda
    var_0 = AnsibleModule(argument_spec=dict(var_0=dict(type='str', fallback=(lambda: None,))))
    assert var_0 is not None
    # Test with a custom fallback
    var_0 = AnsibleModule(argument_spec=dict(var_0=dict(type='str', fallback=(test_case_0,))))
    assert var_0 is not None



# Generated at 2022-06-24 20:53:50.579801
# Unit test for function env_fallback
def test_env_fallback():
    try:
        env_fallback()
    except AnsibleFallbackNotFound:
        assert True
    else:
        assert False



# Generated at 2022-06-24 20:53:51.527017
# Unit test for function env_fallback
def test_env_fallback():
    try:
        env_fallback()
    except AnsibleFallbackNotFound:
        pass




# Generated at 2022-06-24 20:53:52.632100
# Unit test for function env_fallback
def test_env_fallback():
    with pytest.raises(AnsibleFallbackNotFound):
        test_case_0()



# Generated at 2022-06-24 20:53:55.859265
# Unit test for function set_fallbacks
def test_set_fallbacks():
    arg_spec = {
        'param_0': {
            'type': 'str'
        }
    }
    parameters = {}
    no_log_values = set_fallbacks(arg_spec, parameters)
    assert no_log_values == set()
    assert parameters == {}


# Generated at 2022-06-24 20:54:25.135820
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Test default values
    test_0 = {"fallback": (None,)}
    assert set_fallbacks(test_0, {}) == set()
    test_1 = {"fallback": (None, env_fallback)}
    assert set_fallbacks(test_1, {}) == set()
    test_2 = {"fallback": (None, env_fallback, "var_0")}
    assert set_fallbacks(test_2, {}) == set()
    test_3 = {"fallback": (None, env_fallback, "var_0", {'default': "default"})}
    assert set_fallbacks(test_3, {}) == set()

    # Test when fallback value is None
    test_4 = {"fallback": (env_fallback,)}

# Generated at 2022-06-24 20:54:35.169846
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert callable(set_fallbacks)
    assert isinstance(set_fallbacks(argument_spec={'option': {'type': 'str', 'required': True}}, parameters={}), collection.Set)
    assert set_fallbacks(argument_spec={'option': {'type': 'str', 'required': True}}, parameters={}) == {'fallback_value'}
    assert set_fallbacks(argument_spec={'option': {'type': 'str', 'required': True, 'fallback': ('env_fallback', ('MY_VAR_NAME',))}}, parameters={}) == {'fallback_value'}

# Generated at 2022-06-24 20:54:36.868823
# Unit test for function env_fallback
def test_env_fallback():
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback()



# Generated at 2022-06-24 20:54:46.305534
# Unit test for function set_fallbacks
def test_set_fallbacks():
    from ansible.module_utils.basic import AnsibleModule
    argument_spec = {'with_fallback': {'fallback': (env_fallback,), 'type': 'str'}, 'without_fallback': {'type': 'str'}}

    module = AnsibleModule(argument_spec=argument_spec)
    assert module.params.get('with_fallback') is not None
    assert module.params.get('without_fallback') is None

    module = AnsibleModule(argument_spec=argument_spec, bypass_checks=True)
    parameters = {'without_fallback': 'test'}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert 'test' in no_log_values is False
    assert len(no_log_values) == 1

# Generated at 2022-06-24 20:54:57.173645
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'host': {'required': True, 'type': 'str'}, 'port': {'required': False, 'type': 'int', 'default': 22}}
    parameters = {}
    assert tuple() == set_fallbacks(argument_spec, parameters)
    parameters = {'host': '127.0.0.1'}
    assert tuple() == set_fallbacks(argument_spec, parameters)
    parameters = {'port': 22}
    assert tuple() == set_fallbacks(argument_spec, parameters)
    parameters = {'host': '127.0.0.1', 'port': 22}
    assert tuple() == set_fallbacks(argument_spec, parameters)

# Generated at 2022-06-24 20:55:06.062756
# Unit test for function set_fallbacks
def test_set_fallbacks():
    parameters={
    }

# Generated at 2022-06-24 20:55:13.618283
# Unit test for function sanitize_keys
def test_sanitize_keys():
    print("\nTest sanitize_keys")
    # Various types of objects
    test_list = [[1, 2, 3], True, 'my string', 3.2, b"byte string"]

    # Set up no_log strings
    no_log_strings = set()
    no_log_strings.add(b"byte")

    # Set up ignore_keys
    ignore_keys = set()
    ignore_keys.add("string")

    # Call function
    sanitized_value = sanitize_keys(test_list, no_log_strings, ignore_keys)
    if sanitized_value == test_list:
        print("PASSED")
    else:
        print("FAILED")


# Generated at 2022-06-24 20:55:22.564215
# Unit test for function set_fallbacks
def test_set_fallbacks():
    var_0 = dict(
        option_1 = dict(
            type='str',
            fallback=(env_fallback, 'MY_ENV_VAR', 'MY_ENV_VAR2')
        )
    )
    var_1 = dict(
        option_1 = dict(
            type='int',
            fallback=(env_fallback, ['MY_ENV_VAR3', 'MY_ENV_VAR4'], dict(defaults=10))
        )
    )
    assert len(set_fallbacks(var_0, dict(option_1=None))) == 0
    assert len(set_fallbacks(var_1, dict(option_1=None))) == 1



# Generated at 2022-06-24 20:55:23.400374
# Unit test for function env_fallback
def test_env_fallback():
    assert True == True


# Generated at 2022-06-24 20:55:31.865851
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {}
    argument_spec['test_var_0'] = {'type': 'str', 'fallback': (env_fallback, ), 'no_log': True}
    argument_spec['test_var_1'] = {'type': 'foo', 'fallback': (env_fallback, ), 'no_log': False}
    argument_spec['test_var_2'] = {'type': 'bool', 'fallback': (env_fallback, )}
    argument_spec['test_var_3'] = {'type': 'bool', 'fallback': (env_fallback, )}

    parameters = {}
    parameters['test_var_1'] = 'abc'
    parameters['test_var_2'] = 'abc'

    no_log_values = set_fallbacks(argument_spec, parameters)



# Generated at 2022-06-24 20:55:54.591971
# Unit test for function env_fallback
def test_env_fallback():
    test_case_0()

# Generated at 2022-06-24 20:55:57.209326
# Unit test for function sanitize_keys
def test_sanitize_keys():
    no_log_strings = [b"a", "a"]
    ignore_keys = frozenset()
    obj = list()
    res = sanitize_keys(obj, no_log_strings, ignore_keys)
    assert res == obj
