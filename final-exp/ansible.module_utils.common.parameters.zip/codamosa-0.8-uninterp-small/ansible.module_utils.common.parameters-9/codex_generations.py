

# Generated at 2022-06-24 20:46:40.877426
# Unit test for function env_fallback
def test_env_fallback():

    # Test case for no argument
    try:
        env_fallback()
    except:
        pass



# Generated at 2022-06-24 20:46:43.545639
# Unit test for function env_fallback
def test_env_fallback():
    # Failing when arg is empty
    try:
        test_case_0()
    except Exception:
        pass


# Generated at 2022-06-24 20:46:52.999513
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Define argument specification dictionary
    param_spec = dict(
        param_0  = dict(type='str', required=True),
        param_1  = dict(type='str', required=False),
        param_2  = dict(type='str', required=False),
        param_3  = dict(type='str', required=False),
        param_4  = dict(type='str', required=False)
    )

    # Define sub argument specification dictionary

# Generated at 2022-06-24 20:46:59.629394
# Unit test for function set_fallbacks
def test_set_fallbacks():

    ansible_module = AnsibleModule({'a': {'a': 1}, 'b': {'choices': ['a', 'b', 'c'], 'default': 'a'}, 'c': {'required': True}, 'd': {'type': 'str', 'choices': ['a', 'b', 'c'], 'default': 'a', }})
    parameters = {'a': {'a': 1}, 'b': 'b', 'd': 'b'}
    output = set_fallbacks(ansible_module.argument_spec, parameters)
    assert output == {'c'}


# Generated at 2022-06-24 20:47:01.676733
# Unit test for function env_fallback
def test_env_fallback():
    with pytest.raises(AnsibleFallbackNotFound):
        var = env_fallback()


# Generated at 2022-06-24 20:47:13.317772
# Unit test for function sanitize_keys
def test_sanitize_keys():
    print('Running unit test for sanitize_keys')
    if env_fallback() == 'True':
        return
    obj = {
        'test': 'sanitized',
        'password': 'sanitized',
        'secret': 'sanitized',
        'ssh_secret': 'sanitized',
        'token': 'sanitized',
        'ssl_cert': 'sanitized',
        'ssl_key': 'sanitized',
        'client_key': 'sanitized',
        'client_cert': 'sanitized',
        'private_key': 'sanitized',
        'public_key': 'sanitized',
        'ssh_private_key': 'sanitized',
        'ssh_public_key': 'sanitized'
    }

# Generated at 2022-06-24 20:47:23.182191
# Unit test for function set_fallbacks
def test_set_fallbacks():
    var_0 = {}
    var_0["test"] = dict(fallback=(env_fallback,))
    assert set_fallbacks(var_0, {}) == set()
    var_0["test"] = dict(fallback=(env_fallback, 'abc'), no_log=False)
    assert set_fallbacks(var_0, {}) == set()
    var_0["test"] = dict(fallback=(env_fallback, 'abc', 'def'), no_log=False)
    assert set_fallbacks(var_0, {}) == set()
    var_0["test"] = dict(fallback=(env_fallback, 'abc', dict(key="value")), no_log=False)
    assert set_fallbacks(var_0, {}) == set()

# Generated at 2022-06-24 20:47:23.843343
# Unit test for function env_fallback
def test_env_fallback():
    test_case_0()

# Generated at 2022-06-24 20:47:31.040809
# Unit test for function set_fallbacks
def test_set_fallbacks():
    """Validate arguments and return any errors.

    :arg argument_spec: The argument spec to validate against
    :type argument_spec: dict

    :arg parameters: The parameters passed to the module
    :type parameters: dict

    :returns: A list of errors that were encountered during validation
    :rtype: AnsibleValidationErrorMultiple
    """


# Generated at 2022-06-24 20:47:37.843010
# Unit test for function set_fallbacks
def test_set_fallbacks():
    options = dict(
        param_0=dict(type='str', fallback=(env_fallback, 'ENV_VAR_0'))
    )
    parameters = {}

    # monkeypatch os.environ and test that we got the right fallback value
    with patch.dict('os.environ', dict(ENV_VAR_0='OK')):
        no_log_values = set_fallbacks(options, parameters)
        assert parameters.get('param_0') == 'OK'

    # test param_0 with no fallback specified
    options = dict(
        param_0=dict(type='str')
    )
    parameters = {}

    no_log_values = set_fallbacks(options, parameters)
    assert parameters.get('param_0') is None

    # test param_1 with no fallback specified

# Generated at 2022-06-24 20:48:03.932753
# Unit test for function set_fallbacks
def test_set_fallbacks():
    module_arg_spec = dict(
        a=dict(required=True),
        b=dict(type='str', fallback=(env_fallback, dict(fallback_value='c'), 'ANSIBLE_TEST_B'))
    )
    arguments = dict(
        a='a',
        b='b'
    )
    no_log_values = set_fallbacks(module_arg_spec, arguments)
    assert arguments == dict(
        a='a',
        b='b'
    ), 'arguments = %s\n\n%s' % (arguments, '\n'.join(
        traceback.format_stack(sys._getframe(0))
    ))

# Generated at 2022-06-24 20:48:14.238492
# Unit test for function set_fallbacks
def test_set_fallbacks():
    spec = {
        'argument_1': {
            'type': 'str',
            'required': True,
        },
        'argument_2': {
            'type': 'dict',
            'options': {
                'option_1': {
                    'type': 'str',
                    'required': True,
                },
                'option_2': {
                    'type': 'dict',
                    'options': {
                        'option_1': {
                            'type': 'str',
                            'required': True,
                        },
                    }
                },
            },
        },
        'argument_3': {
            'type': 'list',
            'elements': 'str',
        },
    }
    params = {}
    set_fallbacks(spec, params)

# Generated at 2022-06-24 20:48:21.737082
# Unit test for function set_fallbacks
def test_set_fallbacks():
    var = {}
    no_log_values = set()

# Generated at 2022-06-24 20:48:28.872402
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'first_name': {'type': 'str'},
        'last_name': {'type': 'str', 'fallback': (env_fallback, [('LAST_NAME')])},
        'account_name': {'type': 'str', 'fallback': (env_fallback, [('ACCOUNT_NAME')])}
    }

    parameters = {'first_name': 'John'}

    actual = set_fallbacks(argument_spec, parameters)
    expected = {'John', 'John', 'John'}

    assert expected == actual


# Generated at 2022-06-24 20:48:37.970292
# Unit test for function set_fallbacks
def test_set_fallbacks():
    var_1 = env_fallback('url')
    #set_fallbacks(argument_spec, parameters)
    parameters = {'url':'https://example.com'}
    set_fallbacks(argument_spec, parameters)
    no_log_values = set()
    no_log_values = set_fallbacks(argument_spec, parameters)


# Instantiate argument spec

# Generated at 2022-06-24 20:48:41.572430
# Unit test for function set_fallbacks
def test_set_fallbacks():
    args = ["ansible_password"]
    kwargs = {'argument_spec': {'ansible_password': {'fallback': (env_fallback, 'ANSIBLE_NET_PASSWORD')}}}
    fallback_test = set_fallbacks(**kwargs)
    print(fallback_test)

test_case_0()

# Generated at 2022-06-24 20:48:43.258748
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # print(set_fallbacks())
    assert True


# Generated at 2022-06-24 20:48:47.848539
# Unit test for function env_fallback
def test_env_fallback():
    try:
        test_case_0()
    except AnsibleFallbackNotFound:
        print("No fallback found, success.")
    else:
        print("Found fallback, failure.")


# Generated at 2022-06-24 20:48:56.142196
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {}
    parameters = {}
    set_fallbacks(argument_spec, parameters)

    argument_spec = {'test': {'fallback': (env_fallback, "TEST_ENV")}}
    parameters = {}
    os.environ['TEST_ENV'] = 'true'
    set_fallbacks(argument_spec, parameters)
    assert parameters['test'] == os.environ['TEST_ENV']
    os.environ['TEST_ENV'] = 'false'
    parameters = {}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['test'] == os.environ['TEST_ENV']
    assert 'false' in no_log_values


# Generated at 2022-06-24 20:49:02.411798
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_0 = {'required': True, 'type': 'str'}
    parameters = {}
    # Should fail without fallback
    try:
        set_fallbacks(argument_0, parameters)
    except AnsibleFailJSon:
        pass

    argument_0 = {'fallback': (env_fallback, 'FOO'), 'required': True, 'type': 'str'}
    parameters = {}

    # Should fail without fallback
    set_fallbacks(argument_0, parameters)
    assert parameters['fallback'] == 'FOO'



# Generated at 2022-06-24 20:49:31.485442
# Unit test for function set_fallbacks
def test_set_fallbacks():
    var_0 = {'a': {'type': 'list', 'fallback': (env_fallback, None, {'b': 'this_is_a_b_var', 'c': 'this_is_a_c_var'})}}
    var_2 = set({'this_is_a_b_var', 'this_is_a_c_var'})
    output = set_fallbacks(var_0, {'a': [1, 2]})
    assert output == var_2
    test_case_0()



# Generated at 2022-06-24 20:49:40.311997
# Unit test for function set_fallbacks
def test_set_fallbacks():
    from ansible.module_utils._text import to_text

    argument_spec = {}
    assert len(set_fallbacks(argument_spec, {})) == 0

    argument_spec = {'var_0': {'type': 'list', 'elements': 'str', 'fallback': [env_fallback]}}

    # Expected
    test_0 = {'var_0': [u'A', u'B', u'C']}
    assert set_fallbacks(argument_spec, {'var_0': None}) == set()

    os.environ['var_0'] = to_text('A')
    assert set_fallbacks(argument_spec, {'var_0': None}) == set()

    os.environ['var_0'] = to_text('A,B,C')
    assert set_fall

# Generated at 2022-06-24 20:49:50.884806
# Unit test for function set_fallbacks

# Generated at 2022-06-24 20:49:57.842834
# Unit test for function set_fallbacks
def test_set_fallbacks():
    arg_spec = {
            "hello": {
                "type": "str",
                "fallback": (env_fallback, "hello")
            },
            "goodbye": {
                "type": "str",
                "fallback": (env_fallback, "bye")
            },
        }
    params = {}
    no_log_values = set_fallbacks(arg_spec, params)
    assert params == {'hello': 'hello', 'goodbye': 'bye'}
    assert no_log_values == set()



# Generated at 2022-06-24 20:50:01.558712
# Unit test for function set_fallbacks
def test_set_fallbacks():
    var_1 = dict()
    var_2 = dict()
    var_2['type'] = str()
    var_2['fallback'] = (env_fallback,)
    var_1['var_0'] = var_2
    arg_0 = var_1
    test_case_0()
    assert arg_0 == var_1


# Generated at 2022-06-24 20:50:07.925422
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'var_0': {
            'type': 'str',
            'fallback': (env_fallback,'FOO','BAR')},
        'var_1': {
            'type': 'str',
            'fallback': (env_fallback,'FOO','BAR')},
        'var_2': {
            'type': 'str',
            'fallback': (env_fallback,{'vars': ['FOO','BAR']})},
        'var_3': {
            'type': 'str',
            'fallback': (env_fallback,{'vars': ['FOO','BAR']})},
    }
    parameters = {'var_1': 'test_value_1', 'var_2': 'test_value_2'}
    no_log_

# Generated at 2022-06-24 20:50:16.408226
# Unit test for function remove_values
def test_remove_values():
    arg_0 = ''
    arg_1 = ''
    arg_0 = ''
    arg_1 = ''
    arg_0 = ''
    arg_1 = ''
    arg_0 = ''
    arg_1 = ''
    arg_0 = ''
    arg_1 = ''
    arg_0 = ''
    arg_1 = ''
    arg_0 = ''
    arg_1 = ''

    assert remove_values(arg_0, arg_1) == False, "Expected remove_values() to return %s, but got %s" % (False, remove_values(arg_0, arg_1))


# Generated at 2022-06-24 20:50:21.336583
# Unit test for function remove_values
def test_remove_values():
    var_0 = copy_module()
    var_0.DEFAULT_NO_LOG_VALUES.add("123456")
    var_0.DEFAULT_NO_LOG_VALUES.add("******")
    var_0.DEFAULT_NO_LOG_VALUES.add("<secret>")
    var_0._remove_values_from_keys = False
    var_0._sanitize = False
    var_0._no_log_values = set(var_0.DEFAULT_NO_LOG_VALUES)
    var_0._is_no_log_value.cache_clear()
    var_0._is_no_log_value.cache_info()
    var_0._sanitize_conditions_inner = False
    var_0._sanitize_conditions = False

# Generated at 2022-06-24 20:50:28.191819
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # No module argument provided
    var_0 = dict()
    var_1 = dict()
    result = set_fallbacks(var_0, var_1)
    assert result == set()

    # Environment variable is not set
    test_case_0()
    expected_result_0 = set()
    assert result == expected_result_0

    # Environment variable is set
    os.environ['ANSIBLE_LOG_PATH'] = 'ansible_log.log'
    var_0 = dict()
    var_1 = dict()
    var_1['log_path'] = dict()
    var_1['log_path']['fallback'] = (env_fallback, ('ANSIBLE_LOG_PATH',))
    var_1['log_path']['no_log'] = False

# Generated at 2022-06-24 20:50:32.863390
# Unit test for function sanitize_keys
def test_sanitize_keys():
    # Data to test the function
    data_0 = {'meta': {'src': 'test', 'vars': {'pass': 'clear'}}}
    data_1 = {'meta': {'src': 'test', 'vars': {'pass': 'clear'}}, 'k1': 'v1'}

    # Tests
    assert sanitize_keys(data_0) == data_0
    assert sanitize_keys(data_1) == data_1

    # Assert not implemented correctly
    with pytest.raises(NotImplementedError):
        sanitize_keys(data_1, 'test')



# Generated at 2022-06-24 20:51:20.608231
# Unit test for function env_fallback
def test_env_fallback():
    try:
        var_0 = env_fallback(var)
        var_1 = env_fallback(var, var_name)

    except Exception as err:
        print("Exception in function 'env_fallback': %s" % err)


# Test function env_fallback
test_env_fallback()


# Generated at 2022-06-24 20:51:25.180008
# Unit test for function set_fallbacks
def test_set_fallbacks():
    var_spec_name_0 = {"type": "str"}
    var_name_0 = None
    var_checker_0 = _get_type_checker(var_spec_name_0)
    var_spec_name_1 = {"type": "str", "fallback": ["hello"]}
    var_name_1 = {}
    var_checker_1 = _get_type_checker(var_spec_name_1)
    var_name_1["name"] = var_name_0
    var_checker_1("name", var_name_1, var_spec_name_1)


# Generated at 2022-06-24 20:51:27.696214
# Unit test for function env_fallback
def test_env_fallback():
    try:
        test_case_0()
    except AnsibleFallbackNotFound as e:
        assert True
    else:
        assert False



# Generated at 2022-06-24 20:51:33.291361
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        k1=dict(
            type='str',
            default='foo',
            fallback=['env_fallback', 'FOO']
        ),
        k2=dict(
            type='str',
            default='bar',
            fallback=['env_fallback', 'BAR']
        ),
        k3=dict(
            type='str',
            default='baz',
            fallback=['env_fallback', 'BAZ']
        ),
        k4=dict(
            type='str',
            default='qux',
            fallback=['env_fallback', 'QUX']
        ),
        k5=dict(
            type='str',
            default='quux',
            fallback=['env_fallback', 'QUUX']
        ),
    )


# Generated at 2022-06-24 20:51:37.724593
# Unit test for function remove_values
def test_remove_values():
    data_0 = {"bar": "baz"}
    data_1 = {"foo": ["test", ["a", {"test2": 1}], {"vect": ["a", "b", 1, data_0]}]}

    no_log_list_0 = ["test"]
    no_log_list_1 = ["a"]

    test_case_0(data_0, no_log_list_0)
    test_case_1(data_1, no_log_list_0, no_log_list_1)


# Generated at 2022-06-24 20:51:43.634664
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        auth_url=dict(type='str', fallback=(env_fallback, ['CINDER_URL'])),
        login=dict(type='str', fallback=(env_fallback, ['CINDER_LOGIN'])),
    )
    parameters = dict()
    parameters = set_fallbacks(argument_spec, parameters)
    assert 'auth_url' in parameters and parameters['auth_url'] == 'https://localhost:5000/v2.0'



# Generated at 2022-06-24 20:51:49.257980
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Testing the function without fail.
    try:
        test_case_0()
    except:
        raise AssertionError("Test case 0: Failed.")


# Generated at 2022-06-24 20:51:57.086008
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Given a module argument spec defined with only default values
    argument_spec = {
        "dest": {"default": "/etc", "type": "path"},
        "src": {"default": "/usr/local/bin", "type": "path"},
        "pattern": {"default": "*", "type": "str"},
        "recurse": {"default": "no", "type": "str"},
        "validate": {"default": None, "type": "str"},
        "state": {"default": "file", "type": "str"},
        "tmp_dest": {"default": ".ansible-tmp", "type": "path"},
    }

    # Set the parameters to be empty
    parameters = {}
    no_log_values = set()
    unsupported_parameters = set()

    # When the module is validated
    _validate_sub

# Generated at 2022-06-24 20:52:07.522772
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = argument_spec = dict(
        one = dict(
            type = 'str',
            fallback = (env_fallback, ['TEST_FALLBACK'], dict(fallback='test_fallback'))
        ),
        two = dict(
            type = 'str',
            required = True
        )
    )

    parameters = dict(
        two = 'test 2'
    )

    try:
        os.environ["TEST_FALLBACK"] = 'test 1'
        set_fallbacks(argument_spec, parameters)
        assert parameters == dict(
            one = 'test 1',
            two = 'test 2'
        )
    finally:
        del os.environ["TEST_FALLBACK"]


# Generated at 2022-06-24 20:52:09.381145
# Unit test for function env_fallback
def test_env_fallback():
    with pytest.raises(AnsibleFallbackNotFound):
        test_case_0()

# Generated at 2022-06-24 20:54:03.832739
# Unit test for function set_fallbacks
def test_set_fallbacks():
    parameters = {
        "a_param": None,
        "token": "a_param_default",
    }
    argument_spec = {
        "a_param": dict(type="str", fallback=(env_fallback, "A_PARAM", "TOKEN_ENV_VAR")),
        "token": dict(type="str", no_log=True),
    }
    answer = set_fallbacks(argument_spec, parameters)
    assert isinstance(answer, set)
    assert len(answer) == 1
    assert "a_param_default" in answer



# Generated at 2022-06-24 20:54:09.547391
# Unit test for function set_fallbacks
def test_set_fallbacks():
    from ansible.module_utils.common.validation import _METACLASS_STORE
    for name, cls in _METACLASS_STORE.items():
        del cls._run_validate_param_spec

    set_fallbacks({'test1': {'type': 'str', 'fallback': (env_fallback, 'TEST1')}, 'test2': {'type': 'str'}}, {})

    assert 'TEST1' == os.environ['TEST1']
    del os.environ['TEST1']


# Generated at 2022-06-24 20:54:19.731894
# Unit test for function set_fallbacks
def test_set_fallbacks():

    argument_spec = {'var_0': {'type': 'str', 'fallback': [env_fallback]},
                     'var_1': {'type': 'str', 'fallback': [env_fallback, 'var_1']},
                     'var_2': {'type': 'str', 'fallback': [env_fallback, 'var_2']},
                     'var_3': {'type': 'str', 'fallback': [env_fallback, 'var_3']}}

    parameters = {}
    no_log_values = set()
    no_log_values.update(set_fallbacks(argument_spec, parameters))
    assert len(no_log_values) == 0
    assert len(parameters) == 0

    # Test single env var fallback

# Generated at 2022-06-24 20:54:23.615920
# Unit test for function set_fallbacks
def test_set_fallbacks():
    params = dict(foo="hello")
    spec = dict(foo=dict(type='str', fallback=(env_fallback,)))
    v = set_fallbacks(spec, params)
    assert isinstance(v, set)
    assert len(v) == 0

# Generated at 2022-06-24 20:54:25.130753
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert True == True # TODO: implement your test here


# Generated at 2022-06-24 20:54:35.169053
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
            'greeting': {
                'type': 'str',
                'required': True,
                'fallback': (env_fallback, 'ANSIBLE_MODULE_TEST_FALLBACK')
                }
            }
    parameters = {}
    os.environ['ANSIBLE_MODULE_TEST_FALLBACK'] = 'hello'
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert set(no_log_values) == set()
    assert set(parameters.keys()) == set(['greeting'])
    assert parameters['greeting'] == 'hello'
    del os.environ['ANSIBLE_MODULE_TEST_FALLBACK']

    no_log_values = set_fallbacks(argument_spec, parameters)
    assert set

# Generated at 2022-06-24 20:54:37.879764
# Unit test for function env_fallback
def test_env_fallback():
  try:
    test_case_0()
  except Exception as e:
    assert(e.args[0] == "Unable to find fallback for 'import_tasks'")


# Generated at 2022-06-24 20:54:46.709222
# Unit test for function set_fallbacks
def test_set_fallbacks():
    the_arg_spec = {'required_one_of': {'type': 'list', 'default': [], 'aliases': ['required_together']}, 'description': {'description': 'An optional description for the connection.', 'type': 'str', 'default': '', 'aliases': []}, 'timeout': {'description': 'The socket level timeout in seconds.  This is NOT a connection timeout, but an actual socket level timeout.  If the connection does not respond within the timeout period, the connection will be forcibly closed.', 'type': 'int', 'default': 30, 'aliases': ['ssh_timeout']}}
    the_parameters = {}
    test = set_fallbacks(the_arg_spec, the_parameters)
    assert len(test) == 0


# Generated at 2022-06-24 20:54:52.017435
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        "foo": {
            "type": "str",
            "required": True,
            "fallback": ("env_fallback", "FOO", "BAR")
        }
    }
    parameters = {}
    parameters = set_fallbacks(argument_spec, parameters)


# Generated at 2022-06-24 20:55:00.965463
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'param': dict(type='bool', fallback=(env_fallback, 'ANSIBLE_PARAM'))}

    parameters = {'param': 'value'}
    no_log_values = set_fallbacks(argument_spec, parameters)

    assert no_log_values == set(), 'No log fallback failed'
    assert parameters['param'] == 'value', 'Value wasn\'t set'

    parameters = dict() # type: dict
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert no_log_values == set(), 'No log fallback failed'
    assert parameters['param'] == False, 'Value wasn\'t set'
