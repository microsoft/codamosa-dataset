

# Generated at 2022-06-24 20:46:27.183232
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert callable(sanitize_keys)


# Generated at 2022-06-24 20:46:28.045027
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert TEST_CASE_0 != None, 'No values returned from set_fallbacks function'

# Generated at 2022-06-24 20:46:38.494098
# Unit test for function set_fallbacks
def test_set_fallbacks():
    import json

    # Load dict from list of keys
    argument_spec = dict((k, dict()) for k in ['a', 'b', 'c', 'd', 'e'])

    # Load dict from list of keys and values
    test_parameters = dict((k, k) for k in ['a', 'b', 'c'])

    # Test with all fallbacks
    argument_spec['a']['fallback'] = (env_fallback, 'A')
    argument_spec['b']['fallback'] = (env_fallback, 'B', 'C')
    argument_spec['c']['fallback'] = (env_fallback, 'C', 'D', {'default': 'D'})

# Generated at 2022-06-24 20:46:42.640858
# Unit test for function set_fallbacks
def test_set_fallbacks():
    new_parameters = dict()
    test_case_0()
    arg_spec = dict()
    arg_spec["var_0"] = dict()
    arg_spec["var_0"]["fallback"] = ( env_fallback )
    no_log_values = set_fallbacks(arg_spec, new_parameters)
    assert no_log_values == set()
    assert new_parameters["var_0"] == ""
    assert new_parameters == {"var_0": ""}


# Generated at 2022-06-24 20:46:50.197777
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert callable(set_fallbacks)
    try:
        assert isinstance(set_fallbacks(argument_spec=var_0, parameters=var_0), set)
    except Exception as e:
        if type(e) is not AssertionError:
            print('Exception:')
            print(e)
        try:
            if callable(env_fallback):
                assert False
        except Exception as e:
            if type(e) is not AssertionError:
                print('Exception:')
                print(e)
            print('There is nothing to test')


# Generated at 2022-06-24 20:46:54.722056
# Unit test for function sanitize_keys
def test_sanitize_keys():
    INPUT = dict(
        dict(
            a = dict(
                b = ['foo', 'bar'],
            ),
            c = ['baz', 'quux'],
            d = 'hello',
            e = set(['world']),
            f = frozenset(['planet']),
        ),
        g = 'earth',
    )
    NO_LOG_STRINGS = ['foo', 'bar', 'baz', 'quux', 'hello', 'world', 'planet', 'earth']

# Generated at 2022-06-24 20:47:00.699759
# Unit test for function sanitize_keys
def test_sanitize_keys():
    var_0 = set()
    var_1 = Mapping()
    var_1['s_pw'] = 'secret'
    var_2 = Mapping()
    var_2['s_pw'] = 'secret'
    var_1['options'] = var_2
    var_3 = Mapping()
    var_3['options'] = var_2
    var_3['s_pw'] = 'secret'
    var_3['_ansible_no_log'] = False
    var_3['type'] = 'str'
    var_3['elements'] = 'dict'
    var_3['fallback'] = (env_fallback,)
    var_3['apply_defaults'] = True
    var_4 = Mapping()
    var_4['s_pw'] = 'secret'
   

# Generated at 2022-06-24 20:47:10.554103
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'a': {'type': 'str', 'required': True}, 'b': {'type': 'int', 'default': 10, 'required': True}, 'c': {'type': 'str', 'fallback': (env_fallback, ['B_PATH'])}}
    parameters = {'a': 'a', 'b': 0}
    no_log_values = set()
    no_log_values = set_fallbacks(argument_spec, parameters)
    pprint.pprint(no_log_values[0])
    assert(no_log_values == set())


# Generated at 2022-06-24 20:47:20.973619
# Unit test for function set_fallbacks

# Generated at 2022-06-24 20:47:25.531614
# Unit test for function env_fallback
def test_env_fallback():
    var_0 = env_fallback()
    assert var_0 is None


# Generated at 2022-06-24 20:47:47.177923
# Unit test for function env_fallback
def test_env_fallback():
    # We can't get the dictionary of fallbacks from the validator,
    # so we just do one for now.
    assert env_fallback('TEST_ENV_FALLBACK_ENV') == 'test_env_fallback_value', \
        'Value from env fallback not found.'


# Generated at 2022-06-24 20:47:56.718082
# Unit test for function remove_values
def test_remove_values():
    assert remove_values([1, 2, 3], []) == [1, 2, 3]
    assert remove_values([1, 2, 3], [3]) == [1, 2]
    assert remove_values([1, 2, 3], [1]) == [2, 3]
    assert remove_values([1, 2, 3], [1, 3]) == [2]
    assert remove_values([1, 2, 3], [5]) == [1, 2, 3]
    assert remove_values("hello, world", ["hello"]) == ", world"
    assert remove_values("hello, world", ["hello", "world"]) == ","
    assert remove_values("hello, world", ["hello, worl"]) == "d"


# Generated at 2022-06-24 20:48:07.270758
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Test to ensure that set_fallbacks does not silently fail
    orginal_parameters = dict()
    orginal_parameters['ansible_network_os'] = 'ios'
    argument_spec = dict()
    argument_spec['ansible_network_os'] = dict()
    argument_spec['ansible_network_os']['type'] = 'str'
    argument_spec['ansible_network_os']['choices'] = set(['ios'])
    argument_spec['ansible_network_os']['fallback'] = (env_fallback, 'ANSIBLE_NET_OS')

    try:
        set_fallbacks(argument_spec, orginal_parameters)
    except ValueError:
        pass
    else:
        raise AssertionError('Failed to throw expected exception')


# Generated at 2022-06-24 20:48:16.010354
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Input variables used for the test
    spec_0 = dict(
        test_0 = dict(fallback=(env_fallback, 'TEST_0')),
        test_1 = dict(fallback=(env_fallback, 'TEST_1')),
        test_2 = dict(fallback=(env_fallback, 'TEST_2'))
    )
    parameters_0 = dict(test_2='TEST_2')
    expected_result = set(['TEST_2'])

    # Perform the test
    result = set_fallbacks(spec_0, parameters_0)

    # Verify the result
    assert result == expected_result



# Generated at 2022-06-24 20:48:19.524488
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # our dict
    var_0 = dict()
    # the dict we will set
    var_1 = dict()
    # set the dict to var_1
    set_fallbacks(var_0, var_1)
    # check if the dicts are equal
    print(var_0 == var_1)


# Generated at 2022-06-24 20:48:25.593104
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        test_1 = dict(default = 'bar'),
        host = dict(default = 'baz', fallback = (env_fallback, 'ANSIBLE_HOST',) ),
        port = dict(default = 22, fallback = (env_fallback, ['ANSIBLE_PORT', 'ANSIBLE_NETCONF_PORT'],)),
        username = dict(default = '', fallback = (env_fallback, 'ANSIBLE_NETCONF_USERNAME'))
    )

    parameters = dict()

    os.environ['ANSIBLE_HOST'] = 'localhost'
    os.environ['ANSIBLE_PORT'] = '22'

    no_log_values = set()
    no_log_values.update(set_fallbacks(argument_spec, parameters))


# Generated at 2022-06-24 20:48:33.118087
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(a=1)
    parameters = dict(b=dict(c='test_name', d=0))
    no_log_values = set()
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert no_log_values == []
    assert parameters['b']['c'] == 'test_name'



# Generated at 2022-06-24 20:48:37.012887
# Unit test for function env_fallback
def test_env_fallback():
    try:
        # Test for which arg key is raise
        var_0 = env_fallback()
    except AnsibleFallbackNotFound:
        # Test for which arg key is raise
        assert True


# Generated at 2022-06-24 20:48:46.084214
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert next(iter(env_fallback())) == "http_port"
    assert next(iter(env_fallback())) == "https_port"
    assert next(iter(env_fallback())) == "tui_port"
    assert next(iter(env_fallback())) == "fips_mode"
    assert next(iter(env_fallback())) == "physical_storage"
    assert next(iter(env_fallback())) == "default_storage_pool"
    assert next(iter(env_fallback())) == "ssl_cert"
    assert next(iter(env_fallback())) == "ssl_key"
    assert next(iter(env_fallback())) == "ssl_chain"
    assert next(iter(env_fallback())) == "ssl_ciphers"
    assert next

# Generated at 2022-06-24 20:48:51.817589
# Unit test for function sanitize_keys
def test_sanitize_keys():
    no_log_strings = []
    ignore_keys = 'key_2'
    obj = {'key_1': 'value_1', 'key_2': 'value_2'}
    result = sanitize_keys(obj, no_log_strings, ignore_keys)
    assert result == {'key_1': 'value_1', 'key_2': 'value_2'}


# Generated at 2022-06-24 20:49:15.633290
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'variable_0': {'fallback': (env_fallback, ['variable_0'])}}

    parameters = {'variable_2': 3, 'variable_3': False}
    try:
        set_fallbacks(argument_spec, parameters)
    except Exception as e:
        print("ERROR: Exception calling set_fallbacks: " + str(e))
        return False

    return True


# Generated at 2022-06-24 20:49:19.956677
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        "var_0" : {
            "fallback" : (env_fallback, )
        }
    }
    parameters = {}

    set_fallbacks(argument_spec, parameters)
    assert "var_0" in parameters


# Generated at 2022-06-24 20:49:26.689046
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Use 'assert' here to make sure what you're doing is what you think you're doing
    var_0 = {'test_0': {'required': True, 'type': 'str', 'default': 'test_0_default', 'fallback': (env_fallback, 'test_0_var')}}
    var_1, var_2 = set_fallbacks(var_0, {})
    test_case_0()
    assert var_1 == set()
    assert var_2 == {}


# Generated at 2022-06-24 20:49:33.425468
# Unit test for function set_fallbacks
def test_set_fallbacks():
    args = {'fallback': [env_fallback]}
    assert set_fallbacks(args, {}) == set()
    args = {'fallback': [env_fallback, ['var0']]}
    assert set_fallbacks(args, {}) == set()
    args = {'fallback': [env_fallback, ['var1', 'var2']]}
    assert set_fallbacks(args, {}) == set()


# Generated at 2022-06-24 20:49:35.103791
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # TODO: Fix broken unit test
    # assert not test_case_0()
    pass


# Generated at 2022-06-24 20:49:36.328425
# Unit test for function env_fallback
def test_env_fallback():
    with pytest.raises(AnsibleFallbackNotFound):
        test_case_0()

# Generated at 2022-06-24 20:49:45.496599
# Unit test for function set_fallbacks
def test_set_fallbacks():
    p_parameters = {}
    p_argument_spec = {}
    p_argument_spec = {u'foo': {'fallback': (env_fallback, 'ansible_foo'), u'type': u'str'}, u'bar': {'fallback': (env_fallback, 'ansible_bar'), u'type': u'int'}}
    no_log_values = set_fallbacks(p_argument_spec, p_parameters)
    assert no_log_values == set()
    assert p_parameters == {u'foo': u'ansible_foo', u'bar': u'ansible_bar'}



# Generated at 2022-06-24 20:49:55.326396
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Create an argument spec
    argument_spec = {
        'param_1': {
            'type': 'path',
            'fallback': (env_fallback, 'param_1_env')
        },
        'param_2': {
            'type': 'path',
            'fallback': (env_fallback, 'param_2_env')
        },
        'param_3': {
            'type': 'dict',
            'options': {
                'sub_param_1': {
                    'type': 'path',
                    'fallback': (env_fallback, 'sub_param_1_env')
                }
            }
        }
    }

    # Create test data for parameters
    parameters = {}

    # Set environment variables

# Generated at 2022-06-24 20:49:57.550136
# Unit test for function set_fallbacks
def test_set_fallbacks():
    var_0 = {}
    var_1 = {'test': {'type': 'str', 'fallback': (env_fallback,)}}
    var_2 = set()
    var_2 = set_fallbacks(var_1, var_0)



# Generated at 2022-06-24 20:50:07.248546
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
            'aaa': {
                'fallback': ('no_log_values', [1, 2, 3]),
                'no_log': False
            },
            'bbb': {
                'fallback': ('env_fallback', ['bbb']),
                'no_log': True,
            },
            'ccc': {
                'fallback': ('env_fallback', ['ccc']),
                'no_log': False
            },
            'ddd': {
                'fallback': ('env_fallback', ['ddd']),
                'no_log': True,
            },
            }
    parameters = {
            "aaa": "from_argument_spec",
            "ccc": "from_argument_spec",
            }


# Generated at 2022-06-24 20:51:12.213425
# Unit test for function set_fallbacks
def test_set_fallbacks():
  # This is the original set_fallbacks that you sent me
    set_fallbacks(argument_spec, parameters)


# Generated at 2022-06-24 20:51:14.544815
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'param_0': 'dict'}
    parameters = {}
    set_fallbacks(argument_spec, parameters)
    assert len(parameters) == 0


# Generated at 2022-06-24 20:51:25.406712
# Unit test for function sanitize_keys
def test_sanitize_keys():
    # The object to sanitize
    obj = {
        'key_1': {
            'key_2': [
                'key_3',
                'key_4',
                'key_5',
                {
                    'key_6': 'value',
                },
            ],
        },
    }

    # The keys to remove
    keys = [
        'key_3',
        'key_4',
        'key_5',
        'key_6',
        'key_7',
    ]

    # Apply the sanitization
    sanitized_obj = sanitize_keys(obj, keys)

    # Verify the keys were removed
    assert 'key_3' not in sanitized_obj.keys()

# Generated at 2022-06-24 20:51:28.209336
# Unit test for function env_fallback
def test_env_fallback():
    var_0 = env_fallback("ANSIBLE_STRATEGY", "ANSIBLE_STRATEGY_PLUGINS", "ANSIBLE_CONFIG")
    assert var_0 == "linear"

# Generated at 2022-06-24 20:51:29.710317
# Unit test for function env_fallback
def test_env_fallback():
  assert env_fallback() == os.environ['']


# Generated at 2022-06-24 20:51:35.366858
# Unit test for function set_fallbacks
def test_set_fallbacks():
    with patch('os.environ.__getitem__') as mock_get:
        mock_get.return_value = 'mock_value'
        _set_fallbacks(test_case_0, {}, True)



# Generated at 2022-06-24 20:51:40.009350
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {"var_0" : {"type" :"str", "fallback" : (env_fallback, "var_0")}}
    args = {}
    no_log_values = set_fallbacks(argument_spec, args)
    assert args['var_0'] == os.environ['var_0']
    assert len(no_log_values) == 0


# Generated at 2022-06-24 20:51:41.921079
# Unit test for function env_fallback
def test_env_fallback():
    try:
        var_0 = env_fallback()
    except AnsibleFallbackNotFound as e:
        pass


# Generated at 2022-06-24 20:51:48.447077
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        "parameter_a": {"type": "int", "default": 1},
        "parameter_b": {"type": "str"},
        "parameter_c": {"type": "str", "fallback": (env_fallback, "parameter_c")},
        "parameter_d": {"type": "str", "fallback": (env_fallback, "parameter_d")},
        "parameter_e": {"type": "str", "fallback": (env_fallback, "parameter_e")},
    }
    set_fallbacks(argument_spec, {})



# Generated at 2022-06-24 20:51:52.474022
# Unit test for function set_fallbacks
def test_set_fallbacks():

    # variables with complex values
    argument_spec = {'fallback': {'type': 'int', 'fallback': (env_fallback, ('HOME', 'bar'))}}
    parameters = dict()

    # run test
    set_fallbacks(argument_spec, parameters)

    # assert output
    assert 'fallback' in parameters



# Generated at 2022-06-24 20:53:21.533321
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert env_fallback() == AnsibleFallbackNotFound


# Generated at 2022-06-24 20:53:23.619171
# Unit test for function env_fallback
def test_env_fallback():
    try:
        test_case_0()
    except AnsibleFallbackNotFound as e:
        assert type(e) is AnsibleFallbackNotFound


# Generated at 2022-06-24 20:53:29.894141
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Test case 0
    var_0 = {'a': {}, 'b': {}}
    var_1 = {}
    var_2 = set_fallbacks(var_0, var_1)
    assert not var_2
    del var_1
    del var_2
    del var_0

    # Test case 1
    var_3 = {'a': {'fallback': (env_fallback, 'ANSIBLE_BLAH')}, 'b': {}}
    var_4 = {}
    var_5 = set_fallbacks(var_3, var_4)
    assert not var_5
    del var_3
    del var_4
    del var_5

    # http://docs.pytest.org/en/latest/example/simple.html#writing-well-integrated-assertion-helpers


# Generated at 2022-06-24 20:53:36.044401
# Unit test for function sanitize_keys
def test_sanitize_keys():

    test_cases = []
    test_cases.append((dict(a=1, b=1),{'a': 1, 'b': 1}, {}))
    test_cases.append((dict(a=1, b=1), {'@a': 1, '@b': 1}, {'@'}))
    test_cases.append((dict(a=1, b=1, _ansible_foo='boo'), {'_ansible_foo': 'boo', 'a': 1, 'b': 1}, {'_ansible'}))
    test_cases.append((dict(a=1, b=1, _ansible_foo='boo'), {'_ansible_foo': 'boo', 'a': 1, 'b': 1}, {'_ansible'}))


# Generated at 2022-06-24 20:53:40.423135
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Load the spec
    argument_spec = dict(
        env_var_1=dict(arg_name1='env_var_1', fallback=(env_fallback, ['ENV_VAR_1'])),
    )

    parameters = dict(
        env_var_1=None,
    )



# Generated at 2022-06-24 20:53:40.979767
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert callable(set_fallbacks)
    return

# Generated at 2022-06-24 20:53:43.291659
# Unit test for function env_fallback
def test_env_fallback():
    try:
        var_0 = env_fallback()
    except AnsibleFallbackNotFound:
        with pytest.raises(AnsibleFallbackNotFound):
            test_case_0()
    except Exception as ex:
        assert False, "unexpected exception encountered while running the function: {0}".format(ex)


# Generated at 2022-06-24 20:53:44.633504
# Unit test for function set_fallbacks
def test_set_fallbacks():
    set_fallbacks(argument_spec={}, parameters={})


# Generated at 2022-06-24 20:53:45.670858
# Unit test for function env_fallback
def test_env_fallback():
    var = env_fallback(test_case_0)
    assert var == None


# Generated at 2022-06-24 20:53:53.951366
# Unit test for function set_fallbacks
def test_set_fallbacks():
    arguments = dict(
        var_0=dict(
            fallback=(env_fallback,)
        )
    )
    parameters = dict(
    )
    no_log_values = set()

    assert no_log_values == set_fallbacks(arguments, parameters)
    assert parameters == dict(
        var_0=None
    )

    arguments = dict(
        var_0=dict(
            fallback=(env_fallback, 'var_0_env_var'),
        ),
    )
    parameters = dict(
    )
    no_log_values = set()
    os.environ["var_0_env_var"] = "data_0"

    assert no_log_values == set_fallbacks(arguments, parameters)

# Generated at 2022-06-24 20:55:17.016200
# Unit test for function env_fallback
def test_env_fallback():
    var_0 = env_fallback()


# Generated at 2022-06-24 20:55:26.317535
# Unit test for function remove_values
def test_remove_values():
    no_log_strings = ['no log value']
    var_1 = {'var_1_key_0': 'string with no log value', 'var_1_key_1': {'var_1_value_1_0': 'string with no log value', 'var_1_value_1_1': {'var_1_value_1_1_0': 'string with no log value'}}, 'var_1_key_2': {'var_1_value_2_0': 'string with no log value'}, 'var_1_key_3': 'string with no log value', 'var_1_key_4': 'no log value'}
    var_2 = remove_values(var_1, no_log_strings)

# Generated at 2022-06-24 20:55:28.702182
# Unit test for function env_fallback
def test_env_fallback():
    var_0 = env_fallback(*[])
    assert var_0 is AnsibleFallbackNotFound



# Generated at 2022-06-24 20:55:30.179850
# Unit test for function set_fallbacks
def test_set_fallbacks():
    try:
        test_case_0()
    except Exception as e:
        print(str(e))



# Generated at 2022-06-24 20:55:34.719285
# Unit test for function sanitize_keys
def test_sanitize_keys():
    # mock_0 = MagicMock()
    # mock_1 = MagicMock(name='mock_1', return_value=mock_0)
    # mock_2 = MagicMock(name='mock_2', return_value=mock_1)
    mock_2 = env_fallback
    mock_3 = MagicMock(name='mock_3', return_value=mock_2)
    # mock_4 = MagicMock(name='mock_4', return_value=mock_3)
    # mock_5 = MagicMock(name='mock_5', return_value=mock_4)
    mock_5 = MagicMock(name='mock_5', return_value=mock_3)

# Generated at 2022-06-24 20:55:37.280310
# Unit test for function set_fallbacks
def test_set_fallbacks():
    env_fallback()


# Generated at 2022-06-24 20:55:43.970303
# Unit test for function set_fallbacks
def test_set_fallbacks():
    var_0 = {'wanted': {'type': 'int', 'fallback': (env_fallback, 'ANSIBLE_FOO')}, 'parameters': {}}
    var_1 = {'wanted': {'type': 'int', 'fallback': (env_fallback, 'ANSIBLE_FOO')}, 'parameters': {}}
    os.environ['ANSIBLE_FOO'] = '1'
    assert set_fallbacks(var_0, var_1) == set()
    var_1.pop('parameters', None)
    assert set_fallbacks(var_0, var_1) == set()


# Generated at 2022-06-24 20:55:53.857565
# Unit test for function set_fallbacks
def test_set_fallbacks():
    args = {}
    kwargs = {}