

# Generated at 2022-06-24 20:46:38.645633
# Unit test for function env_fallback
def test_env_fallback():
    with pytest.raises(AnsibleFallbackNotFound) as excinfo:
        assert env_fallback()
    assert excinfo.value.args[0] == 'The Ansible fallback was used, which is always an error.'


# Generated at 2022-06-24 20:46:50.024304
# Unit test for function set_fallbacks
def test_set_fallbacks():
    params = {}
    argument_spec = {}
    no_log_values = set_fallbacks(argument_spec, params)
    assert no_log_values == set()

    params = {}

# Generated at 2022-06-24 20:46:58.470446
# Unit test for function set_fallbacks

# Generated at 2022-06-24 20:47:08.859844
# Unit test for function sanitize_keys
def test_sanitize_keys():
    str_0 = 'P:F.z[o%cFpf'
    str_1 = 'B=Y2uV7.'
    float_0 = float('inf')
    float_1 = float('-inf')
    if isinstance(float_0, float) and isinstance(float_1, float):
        set_0 = set([float_0])
        set_1 = {str_0, str_1, float_1}
        var_0 = sanitize_keys(set_0, set_1, [''])
        var_1 = sanitize_keys(set_1, set_0, [''])
        var_2 = sanitize_keys(set_1, set_0, [''])

# Generated at 2022-06-24 20:47:12.569866
# Unit test for function env_fallback
def test_env_fallback():
    try:
        env_fallback()
    except Exception as err:
        assert err.args[0] == "the required argument 'arg' (pos 1) is missing"
        assert err.args[1] == 1
        assert err.args[2] == "env_fallback()"
    except:
        assert False


# Generated at 2022-06-24 20:47:17.233031
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'user_config': {'type': 'str', 'fallback': (env_fallback, ('USER_CONFIG',))}}
    parameters = {'user_config': 'fake_user_config'}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert not no_log_values



# Generated at 2022-06-24 20:47:21.393062
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(param1=dict(type='str', fallback=(env_fallback, ['TEST_ANSIBLE_PARAM1'])))
    parameters = dict()
    result = set_fallbacks(argument_spec, parameters)
    print(result)

test_set_fallbacks()



# Generated at 2022-06-24 20:47:29.213987
# Unit test for function set_fallbacks

# Generated at 2022-06-24 20:47:32.390599
# Unit test for function set_fallbacks
def test_set_fallbacks():

    # Parameters:
    argument_spec = {"testint": {"type": "int", "fallback": ["int", "1", {"env": "TESTINT_ENV"}]}}
    parameters = {"testint": "9"}

    no_log_values = set_fallbacks(argument_spec, parameters)
    assert no_log_values == set()



# Generated at 2022-06-24 20:47:38.897067
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Test function call with correct arguments
    int_0 = 1538
    float_0 = -282.48
    float_1 = -141.48
    int_1 = 532
    float_2 = -2067.54
    int_2 = -1897
    float_3 = -1241.65
    int_3 = -2078
    float_4 = 556.59
    int_4 = -397
    str_0 = 'C#'
    float_5 = -1893.75
    int_5 = -1628
    int_6 = 1348
    float_6 = -1289.91
    int_7 = -886
    float_7 = -2170.79
    int_8 = -1338
    float_8 = -1694.28
    int_9 = -1283

# Generated at 2022-06-24 20:48:10.033393
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {"argument": {"type": "dict", "options": {"key": {"type": "str"}}}}

    # Test that no error is raised on the successful path
    os.environ['ENV_TEST_VAR'] = 'ENV_TEST_VALUE'
    try:
        parameters = {"argument": {"key": "value", "not_key": "value"}}
        no_log_values = set_fallbacks(argument_spec, parameters)
        assert parameters['argument']['key'] == 'value'
        assert no_log_values == set()
        parameters = {"argument": {"missing": "value"}}
        set_fallbacks(argument_spec, parameters)
        assert 'key' not in parameters['argument']
    finally:
        del os.environ['ENV_TEST_VAR']



# Generated at 2022-06-24 20:48:17.990233
# Unit test for function sanitize_keys
def test_sanitize_keys():
    with open('json/sanitize_keys.json', 'r') as json_file:
        json_dict = json.load(json_file)

    var_1 = json_dict['parameters']
    var_2 = json_dict['no_log_strings']
    var_3 = json_dict['expected']
    func_return_value = sanitize_keys(var_1, var_2)

    assert func_return_value == var_3



# Generated at 2022-06-24 20:48:29.941607
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        name = dict(required = True, type = "str"),
        state = dict(required = False, type = "str", default = "present", choices = ['present', 'absent'], aliases = ['ensure']),
        color = dict(env_fallback = (env_fallback, ['COLOR']), type = "str"),
        age = dict(required = False, type = "int", default = 0),
        food = dict(required = False, type = "list", elements = 'str', default = []),
    )
    params = dict(
        name = "Maya",
        state = "present",
        color = "blue",
        age = 0
    )
    # Should not fail
    set_fallbacks(argument_spec, params)
    assert params["name"] == "Maya"


# Generated at 2022-06-24 20:48:34.836261
# Unit test for function remove_values

# Generated at 2022-06-24 20:48:35.401490
# Unit test for function env_fallback
def test_env_fallback():
    test_case_0()


# Generated at 2022-06-24 20:48:37.023423
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = { 'b' : { 'fallback' : (env_fallback, 'b') } }
    parameters = {}

    set_fallbacks(argument_spec, parameters)

    assert parameters.get('b') is not None

# Generated at 2022-06-24 20:48:39.577302
# Unit test for function env_fallback
def test_env_fallback():
    # If a fallback value is not passed, then the function should raise an error.
    with pytest.raises(AnsibleFallbackNotFound):
        var_0 = env_fallback()


# Generated at 2022-06-24 20:48:48.482153
# Unit test for function set_fallbacks
def test_set_fallbacks():

    var_0 = dict(key_0=True)
    var_1 = dict(key_0=False, key_1=True)
    var_2 = dict(key_0=True, key_1=True, key_2=True)
    var_3 = dict(key_1=False, key_2=False)
    var_4 = dict(key_0=False, key_1=True, key_2=False)
    var_5 = dict(key_0=False, key_2=True)
    var_6 = dict(key_1=True, key_2=False)
    var_7 = dict(key_1=True, key_2=True)


# Generated at 2022-06-24 20:48:56.594855
# Unit test for function set_fallbacks

# Generated at 2022-06-24 20:49:04.198440
# Unit test for function set_fallbacks
def test_set_fallbacks():
    var_0 = {}
    var_1 = {}
    var_1['required'] = True
    var_2 = {}
    var_2['type'] = 'str'
    tmp = {"var_1": var_1, "var_2": var_2}
    var_0['var_0'] = tmp

    var_1 = None
    var_2 = None

    if len(var_2) == 0:
        var_1 = set_fallbacks(var_0, {})
    else:
        var_1 = set_fallbacks(var_0, var_2)

    assert var_1 == set()

    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None

    var_1 = {}

# Generated at 2022-06-24 20:49:38.769148
# Unit test for function set_fallbacks
def test_set_fallbacks():
    ''' This function tests whether the fallback value will be assigned to parameter '''
    argument_spec = {
        "param_1": {
            "type": "dict",
            "default": {},
            "options": {
                "var_1": {
                    "type": "str",
                    "elements": "dict",
                    "fallback": (env_fallback, )
                },
            }
        }
    }
    parameters = {
        "param_1": {
            "var_1": "value 1"
        }
    }
    no_log_values = set()
    set_fallbacks(argument_spec, parameters)
    assert 'value 1' not in no_log_values
    try:
        set_fallbacks(argument_spec, None)
    except Exception as exception:
        assert exception

# Generated at 2022-06-24 20:49:39.762583
# Unit test for function set_fallbacks
def test_set_fallbacks():
    test_case_0()



# Generated at 2022-06-24 20:49:40.558317
# Unit test for function sanitize_keys
def test_sanitize_keys():
    var_0 = env_fallback()


# Generated at 2022-06-24 20:49:44.751804
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {}
    parameters = {}
    no_log_values = set()
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert(no_log_values == set())


# Generated at 2022-06-24 20:49:48.026009
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        "abc": {}
    }
    parameters = {}
    result = set_fallbacks(argument_spec, parameters)
    assert result == set([])

test_case_0()

# Generated at 2022-06-24 20:49:50.614094
# Unit test for function env_fallback
def test_env_fallback():
    try:
        func_return = env_fallback()
    except Exception as e:
        func_return = None

    assert func_return is None


# Generated at 2022-06-24 20:49:53.810589
# Unit test for function env_fallback
def test_env_fallback():

    module_args = {}

    # test default behavior
    env_fallback()

    # test passing arg
    env_fallback('arg')

    # test passing arg
    env_fallback('arg', module_args)


# Generated at 2022-06-24 20:50:02.753511
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'foo_no_log': {'type': 'str', 'fallback': (env_fallback, 'BAR_NO_LOG_VAL')},
                     'foo': {'type': 'str', 'fallback': (env_fallback, 'BAR_VAL')}}
    parameters = {'foo_no_log': None,
                  'foo': None}
    os.environ['BAR_NO_LOG_VAL'] = '123'
    os.environ['BAR_VAL'] = '45'
    no_log_values = set_fallbacks(argument_spec, parameters)
    print (no_log_values)
    assert '123' in no_log_values and '45' not in no_log_values
    assert parameters['foo_no_log'] == '123'

# Generated at 2022-06-24 20:50:09.578557
# Unit test for function set_fallbacks

# Generated at 2022-06-24 20:50:19.074436
# Unit test for function set_fallbacks

# Generated at 2022-06-24 20:50:43.700981
# Unit test for function env_fallback
def test_env_fallback():
    try:
        test_case_0()
    except KeyError:
        logger.info("No KEY ERROR")


# Generated at 2022-06-24 20:50:49.596451
# Unit test for function remove_values
def test_remove_values():
    var_0 = (["This string should not be logged", "This string should be logged"], )
    var_0 = remove_values(var_0, ["This string should not be logged"])
    if var_0 == (["(REDACTED STRING)", "This string should be logged"], ):
        print("Test 1 passed!")
    else:
        print("Test 1 failed!")


# Generated at 2022-06-24 20:50:58.818167
# Unit test for function set_fallbacks

# Generated at 2022-06-24 20:51:06.162944
# Unit test for function remove_values
def test_remove_values():
    """Unit test for function remove_values"""
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    # test Mapping
    assert remove_values({'value1': 'test1', 'value2': 'test2'}, ["1"]) == {'value1': 'te', 'value2': 'test2'}

    # test Sequence
    assert remove_values(['value1', 'value2', 'value3'], ["value"]) == ['1', '2', '3']
    assert remove_values(['value1', 'value2', 'value3'], ["e"]) == ['valu1', 'valu2', 'valu3']

    # test Set

# Generated at 2022-06-24 20:51:14.092376
# Unit test for function set_fallbacks
def test_set_fallbacks():
    yaml_str = """
---
- hosts: localhost
  tasks:
    - name: test0
      shell: /bin/echo "hello world"
      run_once: true
      with_items: [1, 2, 3]
"""
    load_var = load(yaml_str)

    # Test task parameter.
    assert load_var[0]['tasks'][0]['name'] == "test0"



# Generated at 2022-06-24 20:51:16.664712
# Unit test for function sanitize_keys
def test_sanitize_keys():
    a_dict = {'a_key': 'a_value', 'another key': 'another_value'}
    result = sanitize_keys(a_dict, set())
    assert a_dict == result



# Generated at 2022-06-24 20:51:27.652125
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(a=dict(fallback=(env_fallback, 'fallback')),
                         b=dict(fallback=(env_fallback, 'fallback')),
                         c=dict(fallback=(env_fallback, 'fallback')),
                         d=dict(fallback=(env_fallback, 'fallback')),
                         e=dict(fallback=(env_fallback, 'fallback')),
                         f=dict(fallback=(env_fallback, 'fallback')),
                         g=dict(fallback=(env_fallback, 'fallback')),
                         h=dict(fallback=(env_fallback, 'fallback')))

# Generated at 2022-06-24 20:51:29.952977
# Unit test for function env_fallback
def test_env_fallback():
    try:
        # test case
        test_case_0()
    except AnsibleFallbackNotFound:
        pass



# Generated at 2022-06-24 20:51:40.324796
# Unit test for function set_fallbacks
def test_set_fallbacks():
    x = {"p1":{"type":"str"}, "p2":{"type":"int"}, "p3":{"type":"str", "default":"test"}}
    y = {}
    r_fail = set_fallbacks(x, y)
    if "" in r_fail:
        print("test_set_fallbacks: FAIL - 1")
    else:
        print("test_set_fallbacks: PASS - 1")
    y["p1"] = "test"
    r_fail = set_fallbacks(x, y)
    if "test" in r_fail:
        print("test_set_fallbacks: FAIL - 2")
    else:
        print("test_set_fallbacks: PASS - 2")
    y["p2"] = "134"
    r_fail = set_fallbacks(x, y)

# Generated at 2022-06-24 20:51:44.079781
# Unit test for function env_fallback
def test_env_fallback():
    logger.info("test_env_fallback")

    try:
        test_case_0()
    except AnsibleFallbackNotFound:
        logger.info("env_fallback: test case 0: passed")
    else:
        raise AssertionError("env_fallback: test case 0: failed")


# Generated at 2022-06-24 20:52:08.832798
# Unit test for function set_fallbacks
def test_set_fallbacks():

    result = set_fallbacks(dict(a=dict(fallback=(env_fallback,))), dict())

    assert result == set()

    with pytest.raises(TypeError) as exc_info:
        result = set_fallbacks(dict(a=dict(fallback=(env_fallback,))), dict())

    assert 'Incorrect value type' in str(exc_info.value)



# Generated at 2022-06-24 20:52:13.833850
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        x=dict(fallback=(env_fallback, 'x'))
    )
    parameters = dict(
    )
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert len(no_log_values) == 0, "Expected 0 elements, got {0}".format(no_log_values)
    assert os.environ['x'] == parameters['x']



# Generated at 2022-06-24 20:52:14.720683
# Unit test for function env_fallback
def test_env_fallback():
    assert (test_case_0()) == None


# Generated at 2022-06-24 20:52:22.277069
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'a': {
            'required': True,
            'choices': ['foo', 'bar', 'baz'],
            'type': 'str',
        },
        'b': {
            'required': True,
        },
        'c': {
            'required': True,
            'type': 'bool',
        },
        'd': {
            'required': True,
            'type': 'int',
        },
        'e': {
            'required': True,
            'type': 'list',
        },
        'f': {
            'required': True,
            'type': 'dict',
        },
    }


# Generated at 2022-06-24 20:52:28.382737
# Unit test for function sanitize_keys
def test_sanitize_keys():
    errors = []
    keys = ['test_case_0', 'test_case_1']
    for key in keys:
        if not hasattr(sys.modules[__name__], key):
            errors.append('missing function ' + key)
    if len(errors) > 0:
        sys.exit('unit test errors:\n' + "\n".join(errors))


# Generated at 2022-06-24 20:52:30.283328
# Unit test for function sanitize_keys
def test_sanitize_keys():
    print("Test sanitize_keys")
    var_0 = sanitize_keys(env_fallback(), env_fallback())
    assert var_0 is None
    test_case_0()


# Generated at 2022-06-24 20:52:39.585387
# Unit test for function set_fallbacks
def test_set_fallbacks():
    var_0 = 'A'
    arg_0 = var_0
    param_0 = {
        'arg_0': {'type': 'str', 'fallback': (env_fallback, arg_0)},
    }

    with patch.object(AnsibleModule, 'params') as mock_params, \
            patch.object(AnsibleModule, 'params') as mock_params:
        mock_params.__getitem__.side_effect = param_0.get
        mock_params.get.side_effect = param_0.get
        set_fallbacks(mock_params, mock_params)



# Generated at 2022-06-24 20:52:43.803297
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # This test case was taken from test_validate.py at commit bc54928e3125a17cded857f0a2fb2fe4e4c4ec67
    # test case 0
    result = set_fallbacks(argument_spec, parameters)
    assert result == set()


# Generated at 2022-06-24 20:52:54.685481
# Unit test for function set_fallbacks
def test_set_fallbacks():
    valid_fallback = {'type': 'str', 'fallback': (env_fallback, ['ANSIBLE_TEST_SET_FALLBACKS_VALID'])}
    invalid_fallback = {'type': 'str', 'fallback': (env_fallback, ['ANSIBLE_TEST_SET_FALLBACKS_INVALID'])}
    params = {'var_0': None}
    expected_result = {'var_0': 'test_value'}
    spec = {'var_0': valid_fallback}
    returned_result = set_fallbacks(spec, params)
    assert returned_result == set(), "Expected: %s, Actual: %s" % (set(), returned_result)

# Generated at 2022-06-24 20:53:01.459250
# Unit test for function set_fallbacks
def test_set_fallbacks():

    print("[TEST] Testing 'set_fallbacks' function")
    var_0 = env_fallback()

# Generated at 2022-06-24 20:53:27.176434
# Unit test for function set_fallbacks

# Generated at 2022-06-24 20:53:38.439191
# Unit test for function set_fallbacks
def test_set_fallbacks():
    var_0 = None
    environment = {}
    argument_spec = {
        'var_0': {
            'type': 'int',
            'fallback': (env_fallback, 'VAR_0', 1, {'type': 'int'})
        }
    }
    parameters = {
    }

    expected_results = {
        'var_0': 1
    }

    new_no_log_values = set_fallbacks(argument_spec, parameters)
    assert expected_results == parameters
    assert var_0 == parameters.get('var_0')
    assert new_no_log_values == set()

    environment['VAR_0'] = "123456"
    expected_results = {
        'var_0': 123456
    }


# Generated at 2022-06-24 20:53:40.382530
# Unit test for function env_fallback
def test_env_fallback():
    try:
        var_0 = env_fallback()
        if bar.__class__.__name__ == 'NameError':
            raise Exception("Cannot find 'bar' in the globals")
    except AnsibleFallbackNotFound:
        pass


test_case_0()

# Generated at 2022-06-24 20:53:49.792037
# Unit test for function set_fallbacks

# Generated at 2022-06-24 20:53:51.702540
# Unit test for function env_fallback
def test_env_fallback():
    test_case_0()


# Generated at 2022-06-24 20:53:52.842661
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert set_fallbacks == test_case_0


# Generated at 2022-06-24 20:53:54.361252
# Unit test for function env_fallback
def test_env_fallback():
    # Try to run test
    try:
        test_case_0()
    except Exception as e:
        print("Error:", e, "\n")
        return 1

    return 0


# Generated at 2022-06-24 20:53:57.058400
# Unit test for function env_fallback
def test_env_fallback():
    mock_env = {
    }
    with patch.dict('os.environ', mock_env):
        assert test_case_0() == None


# Generated at 2022-06-24 20:54:05.634112
# Unit test for function sanitize_keys
def test_sanitize_keys():
    obj = dict(a=1, b=2, c=3, d=4)
    no_log_strings = {'a'}
    ans = dict(a='', b=2, c=3, d=4)
    assert sanitize_keys(obj, no_log_strings) == ans

    obj = dict(a=1, b=2, c=3, d=4)
    no_log_strings = {'a', 'b'}
    ans = dict(a='', b='', c=3, d=4)
    assert sanitize_keys(obj, no_log_strings) == ans


# Generated at 2022-06-24 20:54:08.129467
# Unit test for function env_fallback
def test_env_fallback():
    AOC_in = [None]
    AOC_out = AnsibleFallbackNotFound
    assert test_case_0() == AOC_out, 'Expected:"%s", but got: "%s"' % (AOC_out, test_case_0())


# Generated at 2022-06-24 20:54:31.196517
# Unit test for function env_fallback
def test_env_fallback():
    with pytest.raises(AnsibleFallbackNotFound):
        test_case_0()


# Generated at 2022-06-24 20:54:32.747782
# Unit test for function remove_values
def test_remove_values():
    assert remove_values(test_case_0()) == test_case_0()


# Generated at 2022-06-24 20:54:36.075332
# Unit test for function env_fallback
def test_env_fallback():
    var_0 = env_fallback('PATH')
    print("hello world:", var_0)

    test_case_0()
    test_case_0()

test_env_fallback()

# Generated at 2022-06-24 20:54:40.491479
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        name=dict(
            type='str',
            fallback=(env_fallback, ['ANSIBLE_NET_USERNAME'])
        )
    )
    parameters = dict(
        name='',
    )
    set_fallbacks(argument_spec, parameters)
    assert type(parameters.get('name')) == str


# Generated at 2022-06-24 20:54:44.129896
# Unit test for function env_fallback
def test_env_fallback():
    # Check no arguments passed
    try:
        test_case_0()
    except TypeError:
        pass
    else:
        raise AssertionError("No exception raised")


# Generated at 2022-06-24 20:54:51.035630
# Unit test for function set_fallbacks
def test_set_fallbacks():
    """Test: function set_fallbacks"""
    # Initialize test data
    argument_spec = {
        'var_0': {
            'type': 'str',
            'fallback': env_fallback,
        },
    }
    parameters = dict()
    no_log_values = set()
    # Pass data to test function
    result = set_fallbacks(argument_spec, parameters)
    # Verify
    assert result == no_log_values



# Generated at 2022-06-24 20:54:53.666576
# Unit test for function sanitize_keys
def test_sanitize_keys():
    var_0 = AnsibleFallbackNotFound()
    test_case_0(var_0)


# Generated at 2022-06-24 20:54:59.114171
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {"var_0": {"default": "test", "fallback": [env_fallback, ["VAR_0"]], "type": "str"}}
    parameters = {"var_1": "test"}

    # Execute the function under test
    no_log_values = set_fallbacks(argument_spec, parameters)

    # Verify the expected result
    assert no_log_values == set()
    assert parameters == {"var_0": "test", "var_1": "test"}



# Generated at 2022-06-24 20:55:00.472763
# Unit test for function env_fallback
def test_env_fallback():
    var_0 = env_fallback()
    assert isinstance(var_0, AnsibleFallbackNotFound)


# Generated at 2022-06-24 20:55:01.649524
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert True == True



# Generated at 2022-06-24 20:55:41.790076
# Unit test for function set_fallbacks
def test_set_fallbacks():
    expected_result = set()
    argument_spec = {}
    parameters = {}

    actual_result = set_fallbacks(argument_spec, parameters)
    assert actual_result == expected_result

# Generated at 2022-06-24 20:55:47.399996
# Unit test for function set_fallbacks
def test_set_fallbacks():
    expected_output = None
    m = mock_open(read_data=expected_output)
    with patch.object(builtins, 'open', m, create=True):
        argument_spec = {"argument_spec": {"param_0": {"fallback": [env_fallback, "env_var_0", {}]}}, "type": "dict"}
        parameters = {"param_0": "value_0"}
        output = set_fallbacks(argument_spec, parameters)
        assert(expected_output == output)



# Generated at 2022-06-24 20:55:49.522015
# Unit test for function remove_values
def test_remove_values():
    test_string = b'foo'
    test_no_log_strings = ['foo']
    assert not remove_values(test_string, test_no_log_strings)


# Generated at 2022-06-24 20:55:56.960995
# Unit test for function sanitize_keys
def test_sanitize_keys():
    argument_spec = {'auth': {'type': 'dict', 'required': True, 'options': {'username': {'required': True, 'type': 'str'}, 'password': {'required': True, 'type': 'str', 'no_log': True}, 'hostname': {'required': True, 'type': 'str'}, 'cache': {'type': 'bool', 'default': False}}}}
    parameters = copy.deepcopy(dict(auth=dict(username='stephen', password='pass', hostname='localhost', cache=False)))
    no_log_values = set()
    try:
        no_log_values.update(_set_defaults(argument_spec, parameters))
    except TypeError as te:
        errors.append(NoLogError(to_native(te)))