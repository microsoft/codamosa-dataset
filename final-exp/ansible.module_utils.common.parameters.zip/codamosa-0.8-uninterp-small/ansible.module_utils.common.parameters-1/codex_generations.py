

# Generated at 2022-06-24 20:46:55.429298
# Unit test for function set_fallbacks
def test_set_fallbacks():
    dict_0 = {'unicode_string': u'n@tive', 'dictionary': {'floating_number': 56.5, 'list': [1, 2, 3], 'boolean': False, 'integer': 4}, 'integer': 123, 'list': [1, 'string', u'unicode', 123, 456, 789], 'float': 56.56, 'string_no_space': 'nospace', 'string': 'str@ing', 'set': set(['set', 'me', 'set']), 'regular_expression': re.compile(r'\d{5}'), 'boolean': False, 'boolean_true': True, 'null': None}

    var_0 = set_fallbacks(dict_0, dict_0)
	
    assert var_0 == set()


# Generated at 2022-06-24 20:47:03.491157
# Unit test for function env_fallback

# Generated at 2022-06-24 20:47:15.112838
# Unit test for function set_fallbacks
def test_set_fallbacks():
    dict_0 = {}
    dict_1 = {'foo': 'bar'}
    dict_2 = {'foo': 'bar', None: None}

    assert set_fallbacks(dict_0, dict_0) == set()
    assert set_fallbacks(dict_1, dict_1) == set()
    assert set_fallbacks(dict_2, dict_2) == set()

    dict_0["bar"] = {"type": "str"}
    dict_0["my_fallback"] = {"type": "str", "fallback": (env_fallback, ["MY_FALLBACK"])}
    dict_0["my_no_log_fallback"] = {"type": "str", "fallback": (env_fallback, ["MY_NO_LOG_FALLBACK"]), "no_log": True}
    dict

# Generated at 2022-06-24 20:47:23.306272
# Unit test for function remove_values
def test_remove_values():
    # Initialize the mock logger
    logger = logging.getLogger()
    logger.manager.loggerDict.clear()
    stream_handler = logging.StreamHandler()
    stream_handler.setLevel(logging.WARNING)
    logger.addHandler(stream_handler)
    warnings_message = 'Private variables were left in "test_case_0": test_case_0\n'

    # Test for correct warning messages
    # Test case 0
    test_case_0()
    captured = capsys.readouterr()
    if captured.out != warnings_message:
        raise AssertionError('Expected: %s\nActual: %s' % (warnings_message, captured.out))


# Generated at 2022-06-24 20:47:24.392779
# Unit test for function env_fallback
def test_env_fallback():
    assert callable(env_fallback), 'Function "env_fallback" is not callable.'


# Generated at 2022-06-24 20:47:28.098581
# Unit test for function set_fallbacks
def test_set_fallbacks():
    dict_0 = {'fallback' : (env_fallback, ['HELLO'])}
    os.environ['HELLO'] = 'hello'
    var_0 = set_fallbacks(dict_0, dict_0)
    os.environ.pop('HELLO')
    assert var_0 == {'hello'}


# Generated at 2022-06-24 20:47:31.122347
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback() == os.environ
    assert env_fallback(None) == os.environ
    assert env_fallback('None') == os.environ


# Generated at 2022-06-24 20:47:32.291619
# Unit test for function env_fallback
def test_env_fallback():
    assert True # TODO: implement your test here


# Generated at 2022-06-24 20:47:41.905592
# Unit test for function remove_values
def test_remove_values():
    buff = [{"name": "foo", "password": "pass"}, {"name": "bar", "password": "notthispass", "secret": "thispass"}]
    ret = remove_values(buff, 'thispass')
    assert len(ret) == 2
    assert ret[0]['password'] == 'pass'
    assert ret[1]['password'] == 'notthispass'
    assert ret[1]['secret'] == '[REDACTED]'
    assert remove_values('this is a test', 'password') == 'this is a test'
    assert remove_values(['this', 'is', 'a', 'test'], 'password') == ['this', 'is', 'a', 'test']
    assert remove_values({"password": "thisisatest"}, 'password') == {"password": "[REDACTED]"}

# Generated at 2022-06-24 20:47:43.111949
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert set_fallbacks({}, {}) == set()



# Generated at 2022-06-24 20:48:10.605047
# Unit test for function env_fallback
def test_env_fallback():
    os.environ["ANSIBLE_TEST_VAR"] = "ANSIBLE_TEST_VAR_VALUE"
    var = env_fallback("ANSIBLE_TEST_VAR", "ANSIBLE_TEST_VAR2")
    assert var == b"ANSIBLE_TEST_VAR_VALUE"
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback("ANSIBLE_TEST_VAR2")
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback("ANSIBLE_TEST_VAR3")


# Generated at 2022-06-24 20:48:12.580168
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Test case 0
    try:
        test_case_0()
    except NotImplementedError:
        assert False



# Generated at 2022-06-24 20:48:18.868225
# Unit test for function set_fallbacks
def test_set_fallbacks():
    dict_0 = {'hello': 'world', 'foo': 'bar'}
    dict_0['type'] = 'dict'
    dict_0['apply_defaults'] = False
    dict_0['options'] = {'option1': {'type': 'str', 'default': ''}, 'option2': {'type': 'str', 'default': ''}, 'option3': {'type': 'str', 'default': ''}}
    var_0 = set_fallbacks(dict_0, dict_0)
    assert(var_0 == set())



# Generated at 2022-06-24 20:48:25.073339
# Unit test for function env_fallback
def test_env_fallback():
    # simple test no args
    try:
        env_fallback()
    except AnsibleFallbackNotFound:
        pass

    # simple test no args
    try:
        env_fallback("bad_key")
    except AnsibleFallbackNotFound:
        pass

    os.environ['test_key'] = 'test_value'
    if env_fallback('test_key') != 'test_value':
        print("Failed")
    os.environ.pop('test_key')

    os.environ['test_key'] = 'test_value'
    if env_fallback('bad_key', 'test_key') != 'test_value':
        print("Failed")
    os.environ.pop('test_key')


# Generated at 2022-06-24 20:48:26.421103
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert test_case_0() is None


# Generated at 2022-06-24 20:48:32.165215
# Unit test for function set_fallbacks
def test_set_fallbacks():
    try:
        test_case_0()
    except NameError as e:
        print(e)
        print('TEST CASE FAILED')
        return -1
    print('TEST CASE PASSED')
    return 0



# Generated at 2022-06-24 20:48:36.744342
# Unit test for function set_fallbacks
def test_set_fallbacks():
    dict_0 = {} # dict
    dict_0['a'] = 'a'
    var_0 = set_fallbacks(dict_0, dict_0)
    assert var_0 == set()


# Generated at 2022-06-24 20:48:45.408149
# Unit test for function set_fallbacks
def test_set_fallbacks():
    """Return a set of values that cannot be logged"""

    # Test case 0
    # test that it returns an empty set when there are no fallbacks
    dict_0 = {}
    var_0 = set_fallbacks(dict_0, dict_0)
    assert var_0 == set()

    # Test case 1
    # test that it returns the correct value when it is a fallback
    dict_1 = {'foo': 'bar'}
    dict_2 = {'foobar': 'baz', 'fallback': env_fallback, 'no_log': True}
    var_1 = set_fallbacks(dict_2, dict_1)
    assert var_1 == {'bar'}



# Generated at 2022-06-24 20:48:48.862695
# Unit test for function set_fallbacks
def test_set_fallbacks():

    print("TEST START: test_set_fallbacks")

    test_case_0()

    print("TEST FINISHED: test_set_fallbacks")



# Generated at 2022-06-24 20:48:56.881181
# Unit test for function set_fallbacks
def test_set_fallbacks():
    dict_0 = {}
    var_0 = set(set_fallbacks(dict_0, dict_0))
    assert type(var_0) == set
    assert len(var_0) == 0
    dict_0 = {'a': 'b'}
    var_0 = set(set_fallbacks(dict_0, dict_0))
    assert type(var_0) == set
    assert len(var_0) == 0
    dict_0 = {'a': {'fallback': ['env_fallback', 'foo']}}
    var_0 = set(set_fallbacks(dict_0, dict_0))
    assert type(var_0) == set
    assert len(var_0) == 0
    dict_0 = {'a': {'fallback': ['env_fallback', 'foo']}}

# Generated at 2022-06-24 20:49:37.636930
# Unit test for function env_fallback
def test_env_fallback():
    # No arguments given, return NoneType
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback()

    # Argument given but not found in environment, return NoneType
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('var')

    # Argument given and found in environment, return value
    assert os.environ.get('HOME') == env_fallback('HOME')


# Generated at 2022-06-24 20:49:43.364790
# Unit test for function set_fallbacks
def test_set_fallbacks():
    dict_0 = {}
    dict_1 = {'param' : 'value'}
    dict_2 = {'param' : 'value2'}
    dict_3 = {'param' : 'value2'}
    dict_4 = {'param' : 'value2'}

    dict_5 = {'type' : 'str', 'param' : 'value2'}
    dict_6 = {'type' : 'str', 'param' : 'value2', 'no_log' : True}
    dict_7 = {'type' : 'str', 'param' : 'value2', 'fallback' : env_fallback}

    dict_8 = {'options' : {'subparam': {'type' : 'str'}}}
    dict_9 = {'param' : [dict_8, dict_8]}

# Generated at 2022-06-24 20:49:52.984909
# Unit test for function set_fallbacks
def test_set_fallbacks():

    # Common test values
    dict_enum = {'param_1': 'str'}
    list_enum = ['str']

    # Test using a dict for argument spec
    dict_0 = {}
    dict_1 = {'param_0': 'value_0'}
    dict_2 = {'param_0': 'env:value_0'}
    with mock.patch.dict('os.environ', {'value_0': 'mock_value_0'}):
        var_0 = set_fallbacks(dict_0, dict_0)
        var_1 = set_fallbacks(dict_1, dict_1)
        var_2 = set_fallbacks(dict_2, dict_2)

    # Test using a list for argument spec
    list_0 = []

# Generated at 2022-06-24 20:49:56.130803
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Test case 0
    dict_0 = {}
    var_0 = set_fallbacks(dict_0, dict_0)
    assert len(var_0) == 0



# Generated at 2022-06-24 20:49:57.376709
# Unit test for function set_fallbacks
def test_set_fallbacks():
    try:
        return
    except:
        pass


# Generated at 2022-06-24 20:50:05.574920
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Run each unit test 10,000 times.
    test_sets = [
        {
            'dict_0': {},
        }
    ]
    for test_set in test_sets:
        for i in range(10000):
            # Unit test for function set_fallbacks
            var_0 = test_set['dict_0']

            # Test function, then assert the result.
            var_1 = set_fallbacks(var_0, var_0)
            assert var_1 == set()
# end


# Generated at 2022-06-24 20:50:10.245293
# Unit test for function set_fallbacks
def test_set_fallbacks():
    print("\nTesting set_fallbacks")
    value = set_fallbacks({'foo': {'fallback': ['bar']}}, {'foo': 'foo'})
    print("Result:")
    print(value)
    print("\n")


# Generated at 2022-06-24 20:50:12.063475
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # set_fallbacks('test_case_0')
    assert test_case_0() == None
    

# Generated at 2022-06-24 20:50:14.929335
# Unit test for function set_fallbacks
def test_set_fallbacks():
    dict_0 = {}
    dict_0['a'] = 0
    dict_0['b'] = 1
    var_0 = set_fallbacks(dict_0, dict_0)
    assert var_0 == set()


# Generated at 2022-06-24 20:50:23.928981
# Unit test for function set_fallbacks

# Generated at 2022-06-24 20:51:09.004661
# Unit test for function env_fallback

# Generated at 2022-06-24 20:51:09.824567
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert test_case_0() == set()

# Generated at 2022-06-24 20:51:19.120696
# Unit test for function set_fallbacks
def test_set_fallbacks():
    dict_0 = {}
    dict_0['pwd'] = '/home/casper'
    dict_1 = {}
    dict_1['pwd'] = '/home/casper'
    dict_0['user'] = 'casper'
    dict_1['user'] = 'casper'
    dict_0['group'] = 'casper'
    dict_1['group'] = 'casper'
    dict_0['mode'] = '0755'
    dict_1['mode'] = '0755'
    dict_0['recurse'] = False
    dict_1['recurse'] = False
    dict_0['dest'] = '/home/casper/test_0'
    dict_1['dest'] = '/home/casper/test_0'

    assert dict_0 == dict_1


# Generated at 2022-06-24 20:51:22.625779
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # TODO: A really good test would provide a mock module, then load it under the appropriate alias and see if the
    #       fallback is correctly loaded
    assert test_case_0() is None



# Generated at 2022-06-24 20:51:31.728316
# Unit test for function remove_values
def test_remove_values():
    """Unit tests for :func:`remove_values`"""

    # Test the basic removal of strings from the value itself
    value = 'the cat sat on the mat'
    no_log_strings = ['cat', 'mat']
    new_value = remove_values(value, no_log_strings)
    assert new_value == 'the  sat on the '

    # Test removal of strings from simple lists
    value = ['the cat sat on the mat', 'there were two cats']
    no_log_strings = ['cat', 'mat']
    new_value = remove_values(value, no_log_strings)
    assert new_value == ['the  sat on the ', 'there were two ']

    # Test removal of strings from complex lists

# Generated at 2022-06-24 20:51:33.492123
# Unit test for function sanitize_keys
def test_sanitize_keys():
    obj = sanitize_keys(dict_0, var_0)


# Generated at 2022-06-24 20:51:38.850124
# Unit test for function set_fallbacks
def test_set_fallbacks():
    dict_0 = {'a': {'fallback': (env_fallback, 'A_VAR')}, 'b': {'fallback': (env_fallback, 'B_VAR')}, 'c': {'fallback': (env_fallback, 'C_VAR')}}
    var_0 = set_fallbacks(dict_0, dict_0)


# Set default values

# Generated at 2022-06-24 20:51:48.990665
# Unit test for function sanitize_keys

# Generated at 2022-06-24 20:51:56.880717
# Unit test for function set_fallbacks
def test_set_fallbacks():
    dict_0 = {'type': 'str', 'required': True}
    dict_1 = {'type': 'str', 'required': True, 'fallback': [(env_fallback, 'foo')]}
    dict_2 = {'type': 'str', 'required': True, 'fallback': [(env_fallback, 'foo')], 'no_log': True}
    dict_3 = {'type': 'str', 'required': True, 'fallback': [(env_fallback, 'foo', {'bar': 'baz'})]}
    dict_4 = {'type': 'str', 'required': True, 'fallback': [(env_fallback, 'foo'), 'bar']}

    dict_0a = {'type': 'str', 'required': True, 'default': 'foo'}

# Generated at 2022-06-24 20:52:02.040647
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Before running and after running the below test cases.
    print("Test case 0 for function set_fallbacks")
    test_case_0()
    print('Unit test for function set_fallbacks: PASSED')

if __name__ == '__main__':
    # Following is only for debugging.
    test_set_fallbacks()

# Generated at 2022-06-24 20:52:54.412464
# Unit test for function set_fallbacks
def test_set_fallbacks():
    try:
        test_case_0()
    except Exception as e:
        print(e)



# Generated at 2022-06-24 20:52:56.112954
# Unit test for function set_fallbacks
def test_set_fallbacks():
    print("Starting test for function set_fallbacks")
    test_case_0()
    print("All test cases for set_fallbacks passed")


# Generated at 2022-06-24 20:53:02.480220
# Unit test for function set_fallbacks
def test_set_fallbacks():
    dict_0 = {'str_1': 'str_1', 'str_2': 'str_2', 'dict_1': {'str_1': 'str_1', 'str_2': 'str_2', 'list_1': ['str_1', 'str_2'], 'list_2': ['str_1', 'str_2']}, 'list_1': ['str_1', 'str_2'], 'list_2': ['str_1', 'str_2']}
    dict_1 = {}
    dict_2 = {'arg_2': '2', 'arg_1': '1'}
    dict_3 = {'arg_1': '1'}
    dict_4 = {'arg_2': '2'}

# Generated at 2022-06-24 20:53:09.547529
# Unit test for function set_fallbacks
def test_set_fallbacks():
    dict_1 = {}
    var_1 = set_fallbacks(dict_1, dict_1)

    dict_2 = {}
    dict_0 = dict(a=1)
    dict_2['a'] = dict_0
    dict_2['a']['b'] = 2
    dict_3 = dict(a=dict(b=3))
    dict_4 = dict(a=dict(b=4))
    dict_2['a']['c'] = dict_4
    dict_4 = dict(a=dict(b=4, c=dict(d=5)))
    var_1 = set_fallbacks(dict_4, dict_2)



# Generated at 2022-06-24 20:53:15.354114
# Unit test for function set_fallbacks
def test_set_fallbacks():
    dict_0 = {}
    dict_0['bogus'] = dict()
    dict_0['bogus']['default'] = 'y'
    dict_0['bogus']['type'] = 'bool'
    dict_0['bogus']['fallback'] = (env_fallback, dict())
    var_0 = set_fallbacks(dict_0, dict_0)


# Generated at 2022-06-24 20:53:23.004888
# Unit test for function env_fallback
def test_env_fallback():
    # Test with no arg
    try:
        env_fallback()
    except AnsibleFallbackNotFound:
        pass

    # Test with single arg
    try:
        env_fallback('ANSIBLE_TEST_ENV_FALLBACK_0')
    except AnsibleFallbackNotFound:
        pass
    os.environ['ANSIBLE_TEST_ENV_FALLBACK_0'] = 'test_0'
    ret = env_fallback('ANSIBLE_TEST_ENV_FALLBACK_0')
    assert ret == 'test_0'
    del os.environ['ANSIBLE_TEST_ENV_FALLBACK_0']

    # Test with multiple args

# Generated at 2022-06-24 20:53:29.362769
# Unit test for function set_fallbacks
def test_set_fallbacks():
    dict_0 = {'key': {'value': {}} }
    dict_0['key']['value']['fallback'] = env_fallback()
    dict_0['key']['value']['no_log'] = False
    os.environ['key'] = 'value'
    var_0 = set_fallbacks(dict_0, dict_0)
    assert 'key' in var_0
    assert var_0['key'] == 'value'
    dict_1 = {'key': { 'value': {}} }
    dict_1['key']['value']['fallback'] = env_fallback()
    dict_1['key']['value']['no_log'] = True
    os.environ['key'] = 'value'

# Generated at 2022-06-24 20:53:35.678122
# Unit test for function env_fallback
def test_env_fallback():
    # Test case 0
    dict_0 = {}
    var_0 = set_fallbacks(dict_0, dict_0)

    # Test case 1
    dict_1 = {}
    var_1 = set_fallbacks(dict_1, dict_1)

    # Test case 2
    dict_2 = {}
    dict_2["hosts"] = "127.0.0.1"
    dict_2["connection"] = "local"
    dict_2["gather_facts"] = "no"
    dict_2["name"] = "testnginx"
    dict_2["state"] = "started"
    dict_2["src"] = "/tmp/nginx"
    dict_2["user"] = "root"
    dict_2["group"] = "root"

# Generated at 2022-06-24 20:53:45.779007
# Unit test for function set_fallbacks
def test_set_fallbacks():
    dict_0 = {}
    var_0 = set_fallbacks(dict_0, dict_0)
    assert var_0 == set()
    dict_1 = {'1': 1, '2': 2}
    dict_2 = {'1': 1, '2': 2}
    var_1 = set_fallbacks(dict_1, dict_2)
    assert var_1 == set()
    dict_3 = {'1': 1, '2': 2, '3': {'default': 3, 'fallback': (env_fallback, '3')}}
    dict_4 = {'1': 1, '2': 2}
    var_2 = set_fallbacks(dict_3, dict_4)
    assert var_2 == set()

# Generated at 2022-06-24 20:53:46.748723
# Unit test for function env_fallback
def test_env_fallback():
    #  Load value from environment variable
    assert env_fallback() == 'abc'

# Generated at 2022-06-24 20:55:11.305334
# Unit test for function set_fallbacks
def test_set_fallbacks():

    var_0 = {}
    var_1 = {}
    var_0 = set_fallbacks(var_0, var_1)


# Generated at 2022-06-24 20:55:18.830981
# Unit test for function set_fallbacks
def test_set_fallbacks():
    dict_0 = {"ansible_network_os": "ios"}
    var_0 = set_fallbacks(dict_0, dict_0)
    assert var_0 == set()

    dict_1 = {"ansible_network_os": "ios"}
    var_1 = set_fallbacks(dict_1, dict_1)
    assert var_1 == set()

    dict_2 = {"ansible_network_os": "ios"}
    var_2 = set_fallbacks(dict_2, dict_2)
    assert var_2 == set()

    dict_3 = {"ansible_network_os": "ios"}
    var_3 = set_fallbacks(dict_3, dict_3)
    assert var_3 == set()

    dict_4 = {"ansible_network_os": "ios"}
    var

# Generated at 2022-06-24 20:55:20.372639
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # test case 0
    test_case_0()
    


# Generated at 2022-06-24 20:55:22.966312
# Unit test for function set_fallbacks
def test_set_fallbacks():
    expected = set()
    actual = set_fallbacks(dict_0, dict_0)
    assert expected == actual, 'Expected: %s, Actual: %s' % (expected, actual)



# Generated at 2022-06-24 20:55:28.889026
# Unit test for function env_fallback
def test_env_fallback():
    cases = [dict(args=['ANYKEY'], kwargs={})], [dict(args=['PATH'], kwargs={})], [dict(args=['PATH', 'HOME', 'USER'], kwargs={})]
    for i, case in enumerate(cases, 1):
        print("Running test case %d" %i)
        # Execute function
        try:
            ret = env_fallback(*case[0]['args'], **case[0]['kwargs'])
        except AnsibleFallbackNotFound:
            ret = 'Raised AnsibleFallbackNotFound'
        # For now we assume that a valid execution of the function returns a string and an invalid one raises an exception
        if not isinstance(ret, string_types):
            print("Got type %s, expected string" %type(ret))
#

# Generated at 2022-06-24 20:55:38.474006
# Unit test for function env_fallback
def test_env_fallback():
    # Unit test for env_fallback
    # Basic test
    dict_0 = {'x': 'abcdefg'}
    var_0 = env_fallback('x')
    assert var_0 == 'abcdefg'
    # Test with multiple values
    dict_0 = {'x': 'foo', 'z': 'bar'}
    var_0 = env_fallback('x', 'z')
    assert var_0 == 'foo'
    # Test not found
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('z')
    with pytest.warns(UserWarning):
        env_fallback('z', warn_only=True)
        # Test warn_only=True
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback

# Generated at 2022-06-24 20:55:39.576875
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # There are 5 branches in the function
    for c_0 in range(5):
        assert test_case_0() == None

# Generated at 2022-06-24 20:55:45.944564
# Unit test for function env_fallback
def test_env_fallback():
    env_vars = os.environ.copy()
    os.environ.update({'FOO': 'FOO', 'BOO': 'BOO'})
    assert env_fallback('FOO', 'BOO') == 'FOO'
    assert env_fallback('BOO') == 'BOO'
    try:
        env_fallback()
    except AnsibleFallbackNotFound:
        pass
    else:
        raise AssertionError("AnsibleFallbackNotFound not raised")
    os.environ.clear()
    os.environ.update(env_vars)



# Generated at 2022-06-24 20:55:53.007006
# Unit test for function sanitize_keys
def test_sanitize_keys():
    dict_0 = {}
    set_0 = set()
    str_0 = str()
    assert sanitize_keys(dict_0, set_0) == dict_0
    assert sanitize_keys(set_0, set_0) == set_0
    assert sanitize_keys(str_0, set_0) == str_0
    assert str(type(sanitize_keys(dict_0, set_0))) == "<class 'dict'>"
    assert str(type(sanitize_keys(set_0, set_0))) == "<class 'set'>"
    assert str(type(sanitize_keys(str_0, set_0))) == "<class 'str'>"
