

# Generated at 2022-06-24 20:46:47.823394
# Unit test for function remove_values
def test_remove_values():
    # Initialize empty values
    my_dict = {}
    my_list = []
    my_tuple = ()
    my_string = ''
    my_int = 0
    my_float = 0.0
    my_none = None
    no_log_strings = ['test']

    # Add values to dict
    my_dict['foo_str'] = 'test'
    my_dict['foo_list'] = ['test', 'test']
    my_dict['foo_tuple'] = ('test', 'test')
    my_dict['foo_dict'] = {'test': 'test'}
    my_dict['foo_int'] = 0
    my_dict['foo_float'] = 0.0
    my_dict['foo_none'] = None

    # Add values to list
    my_list.append('test')

# Generated at 2022-06-24 20:46:48.735719
# Unit test for function remove_values
def test_remove_values():
    assert remove_values(var_0, var_0) == var_0


# Generated at 2022-06-24 20:46:59.856344
# Unit test for function sanitize_keys
def test_sanitize_keys():

    my_kwargs = {}
    my_kwargs["no_log"] = True
    var_1 = env_fallback()
    my_kwargs["password"] = var_1

    my_kwargs["validate_certs"] = False
    my_data = {"test": 2, "data": 3, "test2": {'1': 1, '2': 2}, "tuple": [1, 2, 3], "set": set([1, 2, 3]), "list": [1, 2, 3], "bool": True, "none": None, "dict": {"test": 1, "data": 2}, "string": "hello"}
    my_sub_data = {"test": 1, "data": 2}

    # Test case 0
    my_kwargs["type"] = "dict"

# Generated at 2022-06-24 20:47:06.653601
# Unit test for function env_fallback
def test_env_fallback():

    # AssertionError that is expected
    e = AssertionError('AnsibleFallbackNotFound: No fallback value found for this parameter')

    # Call the function
    with pytest.raises(AssertionError) as excinfo:
        env_fallback()
    assert e.args == excinfo.value.args


# Generated at 2022-06-24 20:47:11.494792
# Unit test for function sanitize_keys
def test_sanitize_keys():
    obj = {'ANSIBLE_CONFIG': '/Users/myname/.ansible.cfg'}
    no_log_strings = set()
    ignore_keys = frozenset()
    expected_result = {'ANSIBLE_CONFIG': '/Users/myname/.ansible.cfg'}
    result = sanitize_keys(obj, no_log_strings, ignore_keys)
    assert result == expected_result


# Generated at 2022-06-24 20:47:14.499767
# Unit test for function sanitize_keys
def test_sanitize_keys():
    var_0 = "Hello World!"
    var_1 = ["Hello World!"]

    assert sanitize_keys(var_0, no_log_strings = []) == "Hello World!"
    assert sanitize_keys(var_1, no_log_strings = []) == ["Hello World!"]



# Generated at 2022-06-24 20:47:15.953340
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert set_fallbacks(None, None) == set()

# The module dependencies are derived from the input and output parameters.

# Generated at 2022-06-24 20:47:24.195829
# Unit test for function set_fallbacks
def test_set_fallbacks():
    arg_spec = dict(
        arg_bool = dict(
            type = "bool",
            fallback = (env_fallback, ('ARG_BOOL',))
        ),
        arg_int = dict(
            type = "int",
            fallback = (env_fallback, ('ARG_INT',))
        ),
        arg_str = dict(
            type = "str",
            fallback = (env_fallback, ('ARG_STR',))
        )
    )

    no_log_values = set_fallbacks(arg_spec, dict(arg_bool = True, arg_int = 2, arg_str = 'str'))
    assert len(no_log_values) == 0


# Generated at 2022-06-24 20:47:26.659553
# Unit test for function set_fallbacks
def test_set_fallbacks():
    """
    Calling function set_fallbacks() should raise a TypeError
    """
    # No arguments passed
    assert test_case_0() is None


# Generated at 2022-06-24 20:47:27.690542
# Unit test for function sanitize_keys
def test_sanitize_keys():
    print('Implement tests for function sanitize_keys')



# Generated at 2022-06-24 20:47:54.410432
# Unit test for function set_fallbacks
def test_set_fallbacks():
    var_0 = {}
    var_1 = {}
    var_2 = {}
    var_3 = {}
    var_4 = {}
    var_5 = {}
    var_6 = {}
    os.environ[u"ANSIBLE_NET_PASSWORD"] = u"ansible"
    os.environ[u"ANSIBLE_NET_USERNAME"] = u"ansible"
    var_5[u"port_security_enabled"] = False
    var_5[u"user"] = env_fallback()
    var_5[u"password"] = env_fallback()
    var_5[u"name"] = "foo"
    var_5[u"authorize"] = False
    var_5[u"state"] = u"absent"

# Generated at 2022-06-24 20:47:58.660237
# Unit test for function set_fallbacks
def test_set_fallbacks():
    var_0 = {'type': 'str', 'fallback': [env_fallback, 'ANSIBLE_SSH_PASS']}
    var_1 = {}
    var_2 = set()
    var_3 = set()
    var_3.add('ansible')
    var_2.add(var_3)
    # TODO : this is not correct
    assert set_fallbacks(var_0, var_1) == var_2
    assert var_1 == {'ANSIBLE_SSH_PASS': 'ansible'}


# Generated at 2022-06-24 20:47:59.824604
# Unit test for function env_fallback
def test_env_fallback():
    var_0 = env_fallback(None)


if __name__ == '__main__':
    main()

# Generated at 2022-06-24 20:48:04.998568
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec_1 = {'delay': {'required': False, 'type': 'int', 'default': 10, 'fallback': (env_fallback, ['delay'])}}
    parameter_1 = {'delay': 0}
    assert set_fallbacks(argument_spec_1, parameter_1) == set()
    assert parameter_1 == {'delay': 10}


# Generated at 2022-06-24 20:48:14.314937
# Unit test for function set_fallbacks
def test_set_fallbacks():

    # Test with empty parameters and argument spec and no fallback
    argument_spec = {}
    parameters = {}
    assert set_fallbacks(argument_spec, parameters) == set()

    # Test with empty parameters and argument spec and fallback
    argument_spec = {
        "foo": {
            "type": "str",
            "fallback": (env_fallback, "ANSIBLE_TEST_FOO")
        }
    }
    parameters = {}
    assert set_fallbacks(argument_spec, parameters) == set()

    # Test with fallback parameters

# Generated at 2022-06-24 20:48:20.232084
# Unit test for function env_fallback
def test_env_fallback():

    # Ensure that env_fallback raises AnsibleFallbackNotFound when all args are missing from os.environ

    try:
        # Test using a tuple
        env_fallback("ANSIBLE_TEST_0", "ANSIBLE_TEST_1")
    except AnsibleFallbackNotFound:
        pass
    else:
        raise AssertionError("Failed to raise AnsibleFallbackNotFound")

    try:
        # Test using a list
        env_fallback(["ANSIBLE_TEST_0", "ANSIBLE_TEST_1"])
    except AnsibleFallbackNotFound:
        pass
    else:
        raise AssertionError("Failed to raise AnsibleFallbackNotFound")


# Generated at 2022-06-24 20:48:21.485005
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Test function behaviour
    # Tests number of assertions in function
    assert 1 == test_case_0()



# Generated at 2022-06-24 20:48:30.138719
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Unit test for function set_fallbacks

    # Example execution one
    argument_spec = {
        "name": {"required": True},
        "state": {"choices": ["absent", "present"], "required": True},
        "extra": {"required": False}}
    parameters = dict()
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['state'] == 'present'
    assert no_log_values == set()

    # Example execution two
    argument_spec = {
        "name": {"required": True},
        "state": {"choices": ["absent", "present"], "required": True},
        "extra": {"required": False}}
    parameters = dict()
    no_log_values = set_fallbacks(argument_spec, parameters)

# Generated at 2022-06-24 20:48:31.179563
# Unit test for function remove_values
def test_remove_values():
    var_0 = remove_values()
    assert isinstance(var_0, )


# Generated at 2022-06-24 20:48:33.305988
# Unit test for function sanitize_keys
def test_sanitize_keys():
    obj = {'foo': 'bar'}
    no_log_strings = ['foo']
    ignore_keys = ['ignore']
    res = sanitize_keys(obj, no_log_strings, ignore_keys=ignore_keys)
    assert res == {'_' + 'foo': 'bar'}



# Generated at 2022-06-24 20:49:09.720890
# Unit test for function env_fallback
def test_env_fallback():
    try:
        test_case_0()
    except Exception as e:
        msg = "There was an exception when calling 'env_fallback'"
        assert False, msg
        return (1)
    else:
        return (0)


# Generated at 2022-06-24 20:49:10.846238
# Unit test for function remove_values
def test_remove_values():
    var_0 = ['123456']
    var_1 = remove_values(var_0, )
    assert var_1 == ['123456']



# Generated at 2022-06-24 20:49:11.421217
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert False


# Generated at 2022-06-24 20:49:16.333392
# Unit test for function set_fallbacks
def test_set_fallbacks():
    var_0 = {'a': {}, 'b': {'a': {}}}
    var_1 = {'a': {'fallback': ['text_fallback']}}
    var_2 = {'b': {'a': {'fallback': ['dict_fallback']}}}
    var_3 = test_set_fallbacks
    test_case_0()


# Generated at 2022-06-24 20:49:19.337850
# Unit test for function env_fallback
def test_env_fallback():
    try:
        test_case_0()
    except AnsibleFallbackNotFound as e:
        assert True, "0: An exception of type AnsibleFallbackNotFound occurred. Arguments:\n{0!r}".format(e.args)
    else:
        assert False, "0: No exception occurred."


# Generated at 2022-06-24 20:49:30.095169
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec_0 = {'fallback': {'type': 'dict'}, 'no_log': {'type': 'bool'}, 'type': {'type': 'str'}}
    parameters_0 = {'variable': 'type', 'fallback': ['test_case_0'], 'no_log': False, 'param': 'test_case_0'}
    assert set_fallbacks(argument_spec_0, parameters_0) == set()
    assert parameters_0 == {'variable': 'type', 'fallback': ['test_case_0'], 'param': 'test_case_0', 'no_log': False, 'type': 'type'}

# Case _1:
# {'fallback': {'type': 'bool', 'required': True}, 'no_log': {'type': 'bool'}, 'type

# Generated at 2022-06-24 20:49:39.699537
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Argument spec generated by using packager tool.
    argument_spec = {
  "my_options": {
    "type": "dict",
    "options": {
      "opt_0": {
        "type": "str",
        "fallback": (
          "env_fallback",
        )
      }
    }
  }
}
    # Function parameters generated by using packager tool.
    parameters = {
  "my_options": {
    "opt_1": "bar"
  }
}
    # Removing module args from parameters, as we want to manually set the fallback value
    parameters = parameters.get('my_options')
    # Create a function scope that we can use to set the environment variable
    variables = {}

# Generated at 2022-06-24 20:49:50.090393
# Unit test for function set_fallbacks
def test_set_fallbacks():
    print("\n--- test_set_fallbacks ---")

    from ansible.module_utils.basic import AnsiibleModule
    from ansible.module_utils.basic import AnsibleFallbackNotFound

    test_specs = dict(
        zz=dict(required=True, type='str'),
        zb=dict(required=False, type='str'),
        zc=dict(required=False, type='str'),
        zd=dict(required=False, type='str')
    )
    test_params = dict(zb='zz')
    test_no_log_values = set_fallbacks(test_specs, test_params)
    print(test_params)
    print(test_no_log_values)
    assert 'zz' in test_params
    assert len(test_no_log_values)

# Generated at 2022-06-24 20:49:56.885292
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # argument_spec = dict(test_case_0)
    # parameters = dict(test_case_0)
    argument_spec = dict()
    parameters = dict()
    no_log_values = set_fallbacks(argument_spec, parameters)
    # Assert if no_log_values is instance of set
    assert isinstance(no_log_values, set)
    assert len(no_log_values) == 0


# Generated at 2022-06-24 20:50:02.733050
# Unit test for function sanitize_keys
def test_sanitize_keys():
    obj = 0
    no_log_strings = {0}
    ignore_keys = set()

    # Calling sanitize_keys(obj, no_log_strings, ignore_keys)
    test_case_0()
    return True



# Generated at 2022-06-24 20:50:35.202220
# Unit test for function set_fallbacks

# Generated at 2022-06-24 20:50:41.531445
# Unit test for function set_fallbacks
def test_set_fallbacks():
    required_args = []
    optional_args = []

    # Initialize the test case
    test_case = test_data.TestCase(
            name='TestCase0',
            args=required_args,
            kwargs=optional_args)

    # Initialize expected result
    test_case.expected_result = None

    # Run the test
    set_fallbacks(test_case.args, test_case.kwargs)

    # Verify the result
    test_case.verify_result()

# Generated at 2022-06-24 20:50:48.583410
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # runs the module
    template_src = '''
#!/usr/bin/python

from ansible.module_utils.basic import *

if __name__ == '__main__':
    argument_spec = {'parameter': {'type': 'str', 'fallback': (env_fallback, 'test')}}
    parameters = {}
    no_log_values = set_fallbacks(argument_spec, parameters)
    module = AnsibleModule(argument_spec=argument_spec, no_log_values=no_log_values)
    module.exit_json(changed=True)
'''

    module = get_module_path(template_src, {})
    args = ['/tmp/test.py']

# Generated at 2022-06-24 20:50:50.877217
# Unit test for function env_fallback
def test_env_fallback():
    var_0 = env_fallback()
    assert var_0 is None
# test_cases:
# ansible-vault encrypt_string "hello" --name 'var_0'
# ansible-vault encrypt_string "['hello', 'world']" --name 'var_1'
# ansible-vault encrypt_string "{'hello': 'world'}" --name 'var_2'


# Generated at 2022-06-24 20:50:57.662206
# Unit test for function set_fallbacks
def test_set_fallbacks():
    var_0 = env_fallback()
    var_1 = {}
    var_2 = {'required': False, 'type': 'str', 'fallback': (env_fallback, 'ANSIBLE_NET_SSH_KEYFILE'), 'no_log': False}
    set_fallbacks({'key_file': var_2}, var_1)
    assert var_1 == {'key_file': var_0}


# Generated at 2022-06-24 20:50:59.853864
# Unit test for function env_fallback
def test_env_fallback():
    assert test_case_0() == None, 'Simple test case, do not change this.'
    print('Test run successfully')



# Generated at 2022-06-24 20:51:01.926709
# Unit test for function sanitize_keys
def test_sanitize_keys():
    print(test_case_0.__annotations__)

    print(sanitize_keys(test_case_0, []))



# Generated at 2022-06-24 20:51:13.265757
# Unit test for function remove_values
def test_remove_values():
    from ansible.defaults import DEFAULT_VAULT_PASSWORD_FILE
    from ansible.module_utils._text import to_text
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import wrap_var


# Generated at 2022-06-24 20:51:14.983744
# Unit test for function env_fallback
def test_env_fallback():
    # TODO: re-implement test case once issue #785 is resolved
    # test_case_0()
    pass

# Generated at 2022-06-24 20:51:19.747079
# Unit test for function env_fallback
def test_env_fallback():
    assert (type(env_fallback()) == bool)
    assert (type(env_fallback()) == dict)



# Generated at 2022-06-24 20:51:48.197342
# Unit test for function env_fallback
def test_env_fallback():
    assert not False


# Generated at 2022-06-24 20:51:50.370916
# Unit test for function env_fallback
def test_env_fallback():
    # Test for no value
    try:
        test_case_0()
    except AnsibleFallbackNotFound:
        pass

# Generated at 2022-06-24 20:51:54.238934
# Unit test for function env_fallback
def test_env_fallback():
    var_0 = env_fallback()
    assert var_0 is None



# Generated at 2022-06-24 20:51:59.695771
# Unit test for function sanitize_keys
def test_sanitize_keys():
    print("testing sanitize_keys")
    var_0 = sanitize_keys(msg, no_log_values, kwargs.get('ignore_errors'))
    assert isinstance(var_0, bool) or var_0 is None
    return True


# Generated at 2022-06-24 20:52:01.093346
# Unit test for function sanitize_keys
def test_sanitize_keys():
    var_1 = env_fallback()



# Generated at 2022-06-24 20:52:10.566292
# Unit test for function set_fallbacks
def test_set_fallbacks():
    """
    Test function set_fallbacks for known parameters
    """

    ar_0 = {"no_log": False, "fallback": ((env_fallback,))}
    ar_1 = {}
    ar_2 = set()
    ar_3 = {"no_log": False, "fallback": ((env_fallback,))}
    ar_4 = {"no_log": False, "fallback": ((env_fallback,))}
    ar_5 = {"no_log": False, "fallback": ((env_fallback,))}
    ar_6 = {"no_log": False, "fallback": ((env_fallback,),)}
    ar_7 = {"no_log": False, "fallback": ((env_fallback,))}

# Generated at 2022-06-24 20:52:14.428574
# Unit test for function set_fallbacks
def test_set_fallbacks():
    var_0 = {'sub_type': {'fallback': (env_fallback,), 'type': 'dict'}, 'type': {'fallback': (env_fallback,), 'type': 'dict'}}
    return_value = set_fallbacks(var_0, {})
    assert return_value == set()


# Generated at 2022-06-24 20:52:18.547861
# Unit test for function set_fallbacks
def test_set_fallbacks():
    var_0 = { "var_0": {"_ansible_no_log": "true", "type": "str"}, "var_1": {"fallback": (env_fallback,), "type": "str"} }
    expected_output = set(["*****"])
    assert set_fallbacks(var_0, {"var_0": "*****", "var_1": "*****"}) == expected_output


# Generated at 2022-06-24 20:52:22.242753
# Unit test for function sanitize_keys
def test_sanitize_keys():
    no_log_strings = ('0' * 4096)
    my_obj = {'a': 1, no_log_strings: 2}
    new_value = sanitize_keys(my_obj, [no_log_strings])
    assert new_value == {'a': 1, '*' * 4096: 2}

test_sanitize_keys()


# Generated at 2022-06-24 20:52:29.257277
# Unit test for function remove_values
def test_remove_values():
    value = {'k1': 'v1', 'k2': 'v2', 'k3': 'v3'}
    assert remove_values(value, ['v2']) == {'k1': 'v1', 'k3': 'v3'}

    value = ['v1', 'v2', 'v3']
    assert remove_values(value, ['v2']) == ['v1', 'v3']

    value = {'k1': 'v1', 'k2': ['v2', 'v3'], 'k3': {'k3.1': 'v3.1'}}
    assert remove_values(value, ['v2']) == {'k1': 'v1', 'k2': ['v3'], 'k3': {'k3.1': 'v3.1'}}

    value

# Generated at 2022-06-24 20:53:00.958410
# Unit test for function set_fallbacks
def test_set_fallbacks():
    test_module_0 = {
        'module_args': {
            'module_0_var_0': '',
        },
        'module_name_0': '',
    }

    test_module_0['module_args']['module_0_var_0'] = 'test_module_0_var_0_0'
    assert set_fallbacks(test_module_0, test_module_0['module_args']) == set(['test_module_0_var_0_0'])

    test_module_0['module_args']['module_0_var_0'] = 'test_module_0_var_0_1'

# Generated at 2022-06-24 20:53:05.035226
# Unit test for function remove_values
def test_remove_values():
    var_0 = ['dont_log_all']

    # Test for private values
    for value in var_0:
        result = remove_values(value, var_0)
        assert result is None


# Generated at 2022-06-24 20:53:12.091071
# Unit test for function set_fallbacks
def test_set_fallbacks():
    var_1 = {
        'alex': {'type': str},
        'bob': {'type': str},
        'carl': {'type': str, 'fallback': ('env_fallback', 'ALEX', 'BOB')}
    }
    var_2 = {'bob': 'common'}
    var_3 = set_fallbacks(var_1, var_2)
    assert var_3 == set()
    del var_1['carl']
    var_3 = set_fallbacks(var_1, var_2)
    assert var_3 == set()
    var_1['carl'] = {'type': str, 'fallback': ('env_fallback', 'ALEX')}
    var_3 = set_fallbacks(var_1, var_2)
    assert var

# Generated at 2022-06-24 20:53:18.865068
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Create a mock argument spec for argument param
    arg_spec = dict()
    # Create a new argument spec for argument param
    arg_spec['param'] = dict()
    # Set the key fallback to the value of the new argument spec
    arg_spec['param']['fallback'] = (env_fallback,)
    # Set the key no_log to the value of the new argument spec
    arg_spec['param']['no_log'] = False
    # Create a mock argument parameters for argument param
    arg_parameters = dict()

    # Call function set_fallbacks, with arg_spec and arg_parameters
    result = set_fallbacks(arg_spec, arg_parameters)

    # Create a new set callable with args
    expected = set()

    # Call assertEqual, with expected and result
    assertE

# Generated at 2022-06-24 20:53:26.283276
# Unit test for function set_fallbacks
def test_set_fallbacks():
    check_set_fallbacks = set_fallbacks(
        {
  "param_1": {"type": "string", "fallback": ["env_fallback", "param_1"]},
  "param_2": {"type": "string", "fallback": ["env_fallback", "param_2"]},
},
        {
  "param_1": "some_value",
  "param_2": "some_other_value",
  "param_3": "even_more_values"
}
    )
    no_log_values = "some_value, some_other_value"
    assert check_set_fallbacks == no_log_values



# Generated at 2022-06-24 20:53:28.148616
# Unit test for function remove_values
def test_remove_values():
    # test 1
    var_2 = test_case_1_with_qiwsir_()

    # test 2
    var_2 = test_case_2_with_qiwsir_()


# Generated at 2022-06-24 20:53:28.853517
# Unit test for function env_fallback
def test_env_fallback():
    return var_0


# Generated at 2022-06-24 20:53:31.502507
# Unit test for function env_fallback
def test_env_fallback():
    var_0 = os.environ
    os.environ.update({'ANSIBLE_CONFIG': 'ansible.cfg'})
    assert var_0 != os.environ
    assert test_case_0() == os.environ['ANSIBLE_CONFIG']
    os.environ = var_0


# Generated at 2022-06-24 20:53:33.037710
# Unit test for function env_fallback
def test_env_fallback():
    myenv = os.environ
    try:
        os.environ = {}
        assert env_fallback() == None
    finally:
        os.environ = myenv


# Generated at 2022-06-24 20:53:34.898108
# Unit test for function sanitize_keys
def test_sanitize_keys():

    # Test with default args.
    test_0 = sanitize_keys(var_0)
    print("sanitize_keys(var_0) returns: ", test_0)



# Generated at 2022-06-24 20:54:03.396692
# Unit test for function env_fallback
def test_env_fallback():
    with pytest.raises(AnsibleFallbackNotFound):
        assert var_0 is None, var_0



# Generated at 2022-06-24 20:54:09.443164
# Unit test for function set_fallbacks
def test_set_fallbacks():

    # Set args
    argument_spec = {"test_var": {
        "type": "str",
        "required": False,
        "fallback": (env_fallback, "tacos")
    }}

    parameters = {"test_var": None}

    # invoke test_case_0
    test_case_0()

    # Set expected results
    expected_result = {"test_var": "tacos"}


    # Call set_fallbacks with args
    result = set_fallbacks(argument_spec, parameters)

    # Verify expected results
    assert result == expected_result


# Generated at 2022-06-24 20:54:11.271295
# Unit test for function set_fallbacks
def test_set_fallbacks():

    # Case 0
    res = set_fallbacks(argument_spec, parameters)
    assert res == no_log_values



# Generated at 2022-06-24 20:54:22.678102
# Unit test for function env_fallback
def test_env_fallback():
    # Try to load from environment variable
    test_var = "ANSIBLE_NET_USERNAME"
    assert 'ANSIBLE_NET_USERNAME' not in os.environ
    os.environ['ANSIBLE_NET_USERNAME'] = 'test_username'
    assert env_fallback() == 'test_username'

    try:
        # Try to load from nonexistent environment variable
        os.environ.pop('ANSIBLE_NET_USERNAME')
        with pytest.raises(AnsibleFallbackNotFound):
            test_case_0()
    finally:
        # Cleanup
        if 'ANSIBLE_NET_USERNAME' in os.environ:
            os.environ.pop('ANSIBLE_NET_USERNAME')
        os.environ.pop('ANSIBLE_DEPRECATION_WARNINGS', None)



# Generated at 2022-06-24 20:54:32.315296
# Unit test for function remove_values
def test_remove_values():
    fixture_2 = { 'password': 'abc123', 'ssh_host_key': 'def456', 'private_key': 'ghi789' }

# Generated at 2022-06-24 20:54:33.430326
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback() == None


# Generated at 2022-06-24 20:54:43.644051
# Unit test for function set_fallbacks
def test_set_fallbacks():
    #create a mock argument spec
    #argument_spec = {'name': { 'fallback': (env_fallback, 'ANSIBLE_MODULE_ARGS_NAME') } }
    argument_spec = {'name': { 'fallback': (env_fallback, 'ANSIBLE_MODULE_ARGS_NAME') } }
    parameters = { 'name': 'test' }
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert len(no_log_values) == 0
    assert parameters['name'] == 'test'

    os.environ['ANSIBLE_MODULE_ARGS_NAME'] = 'env_test'
    parameters = { 'name': 'test' }
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert len(no_log_values)

# Generated at 2022-06-24 20:54:48.056929
# Unit test for function env_fallback
def test_env_fallback():
    try:
        assert test_case_0() == os.environ['ANSIBLE_NET_SSH_KEYFILE']
    except KeyError as ke:
        assert os.environ[ke.args[0]] == ''


# Generated at 2022-06-24 20:54:52.153313
# Unit test for function env_fallback
def test_env_fallback():
    try:
        test_case_0()
    except AnsibleFallbackNotFound as e:
        assert "env_fallback: One of the following is required:" in str(e)



# Generated at 2022-06-24 20:54:53.665693
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert False


# Generated at 2022-06-24 20:55:21.566243
# Unit test for function env_fallback
def test_env_fallback():
    with pytest.raises(AnsibleFallbackNotFound):
        test_case_0()

#
# --- AnsibleModule Helpers ----
#


# Generated at 2022-06-24 20:55:30.022624
# Unit test for function env_fallback
def test_env_fallback():
    try:
        test_case_0()
    except Exception as e:
        print('Exception: {}'.format(e))
        os.environ['TEST_ENV_VAR'] = 'test'
        try:
            test_case_0()
        except AnsibleFallbackNotFound:
            print("No env variable found")
        del os.environ['TEST_ENV_VAR']

if __name__ == '__main__':
    test_env_fallback()


# Generated at 2022-06-24 20:55:36.014234
# Unit test for function env_fallback
def test_env_fallback():
    print(env_fallback.__doc__)
    print('\nFunction "env_fallback" returned:')
    print(env_fallback())
    print('\nFunction "env_fallback" returned:')
    print(env_fallback('1'))
    print('\nFunction "env_fallback" returned:')
    try:
        env_fallback()
    except ValueError as e:
        print(e)
    print('\nFunction "env_fallback" returned:')
    try:
        env_fallback('1')
    except ValueError as e:
        print(e)


# Generated at 2022-06-24 20:55:40.578715
# Unit test for function sanitize_keys
def test_sanitize_keys():
    obj = {'test': 'value'}
    no_log_strings = []
    ignore_keys = frozenset()
    sanitize_keys(obj, no_log_strings, ignore_keys)
    # Example of assert
    assert obj == {'test': 'value'}


# Generated at 2022-06-24 20:55:41.519741
# Unit test for function env_fallback
def test_env_fallback():
    test_case_0()


# Generated at 2022-06-24 20:55:45.370559
# Unit test for function env_fallback
def test_env_fallback():
    if 'ANSIBLE_NET_USERNAME' in os.environ:
        assert os.environ['ANSIBLE_NET_USERNAME'] == 'admin'
    else:
        assert False


# Generated at 2022-06-24 20:55:48.419343
# Unit test for function sanitize_keys
def test_sanitize_keys():
    list_obj = [1, 2, 3, 4]
    ignore_keys = frozenset()
    no_log_strings = ['a']
    assert sanitize_keys(list_obj, no_log_strings, ignore_keys) == list_obj


# Generated at 2022-06-24 20:55:56.001433
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'var_0': {'type': 'str', 'fallback': (env_fallback, ('var_0', 'test_var'))},
        'var_1': {'type': 'str', 'fallback': (env_fallback, ('var_1', 'test_var'))},
        'var_2': {'type': 'str', 'fallback': (env_fallback, ('var_2', 'test_var'))}
     }

    parameters = {
        'var_0': '',
        'var_1': ''
    }

    no_log_values = set_fallbacks(argument_spec, parameters)
    assert 'test_var' == parameters['var_1']
    assert 'test_var' == no_log_values.pop()

