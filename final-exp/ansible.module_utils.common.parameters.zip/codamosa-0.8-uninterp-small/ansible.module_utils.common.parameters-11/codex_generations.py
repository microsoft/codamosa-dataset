

# Generated at 2022-06-24 20:46:43.497670
# Unit test for function set_fallbacks
def test_set_fallbacks():
    file = open("./test_data/test_set_fallbacks.json", "r")
    argument_spec = file.read()
    argument_spec = json.loads(argument_spec)
    file = open("./test_data/test_set_fallbacks1.json", "r")
    parameters = file.read()
    parameters = json.loads(parameters)
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert len(no_log_values) == 1
    assert 'somethingsecret' in no_log_values
    assert 'log_level' not in parameters
    assert 'log_file' in parameters


# Generated at 2022-06-24 20:46:53.045456
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'name': {'required': True, 'type': 'str'}, 
        'list': {'required': True, 'type': 'list', 'elements': 'str', 'no_log': False},
        'dict': {'required': False, 'type': 'dict', 'no_log': False},
        'no_log': {'required': True, 'type': 'bool', 'no_log': False},
        'password': {'required': True, 'type': 'str', 'no_log': True},
        'password_fallback': {'required': False, 'type': 'str', 'fallback': (env_fallback,), 'no_log': True},
    }

# Generated at 2022-06-24 20:47:01.698030
# Unit test for function set_fallbacks
def test_set_fallbacks():
    args = [{'fallback': (env_fallback,)}]
    parameters = {}
    expected_no_log_values = set()
    expected_parameters = {'var_0': 'Test'}

    # Mock the parameter
    os.environ['var_0'] = 'Test'

    # Unit test
    no_log_values = set_fallbacks(args, parameters)
    for k, v in expected_parameters.items():
        if k not in parameters:
            assert False, "key {} not found".format(k)
        if parameters[k] != v:
            assert False, "key {} expected value {}, got {}".format(k, v, parameters[k])


# Generated at 2022-06-24 20:47:07.668231
# Unit test for function set_fallbacks
def test_set_fallbacks():
    global var_0
    if var_0 == 'str':
        print('str')
    elif var_0 == 'int':
        print('int')
    else:
        print('nope')


# Generated at 2022-06-24 20:47:15.378053
# Unit test for function set_fallbacks
def test_set_fallbacks():
    spec_0 = {
        'bool_number': {'type': 'bool'},
        'dict_string': {'type': 'dict', 'suboptions': {'bool_number': {'type': 'bool'}, 'int_number': {'type': 'int'}, 'str_string': {'type': 'str'}}},
        'float_number': {'type': 'float'},
        'int_number': {'type': 'int'},
        'list_string': {'type': 'list', 'elements': 'str', 'fallback': ('env_fallback')},
        'str_string': {'type': 'str'},
    }

# Generated at 2022-06-24 20:47:25.001992
# Unit test for function set_fallbacks

# Generated at 2022-06-24 20:47:32.045189
# Unit test for function set_fallbacks
def test_set_fallbacks():
    var_0 = dict()
    var_0["_terms_path"] = dict()
    var_0["_terms_path"]["type"] = "path"
    var_0["_terms_path"]["fallback"] = (env_fallback, "/usr/share/ansible/plugins/modules/i3/terms")
    var_0["_terms_path"]["no_log"] = False
    var_0["_cli_connection"] = dict()
    var_0["_cli_connection"]["type"] = "bool"
    var_0["_cli_connection"]["default"] = True
    var_0["_cli_connection"]["fallback"] = (env_fallback, False)
    var_0["_cli_connection"]["no_log"] = False

# Generated at 2022-06-24 20:47:34.196491
# Unit test for function env_fallback
def test_env_fallback():
    try:
        func_args = {}
        ret_val_0 = env_fallback(**func_args)
    except AnsibleFallbackNotFound:
        pass
    assert ret_val_0 is None


# Generated at 2022-06-24 20:47:40.128676
# Unit test for function set_fallbacks
def test_set_fallbacks():
    var_0 = {'param_1': {'fallback': (None,)}}
    var_1 = {}
    var_2 = {'param_3': {'fallback': (None,)}}
    var_3 = {}
    var_4 = {}
    var_5 = {'param_1': {'fallback': (None,)}}
    var_6 = {'param_1': 'abc'}
    var_7 = {'param_1': 'abc'}
    var_8 = {}
    var_9 = {}
    var_10 = {'param_1': {'fallback': (None,)}}
    var_11 = {}
    var_12 = {'param_1': {'fallback': (None,)}}
    var_13 = {}
    var_14 = {}

# Generated at 2022-06-24 20:47:41.650120
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {}
    parameters = {}

    set_fallbacks(argument_spec, parameters)


# Generated at 2022-06-24 20:48:03.293662
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert(get_lineno() == test_case_0())


# Generated at 2022-06-24 20:48:10.056251
# Unit test for function remove_values
def test_remove_values():
    var_0 = env_fallback()
    var_1 = 0
    arg_0 = {
        "key1": "value1",
        "key2": "value2",
        "key3": "value3",
        "key4": "value4"
    }
    arg_1 = "value4"
    arg_2 = [
        "value4"
    ]
    ret_1 = remove_values(arg_0, arg_2)
    ret_2 = remove_values(arg_1, arg_2)
    assert ret_1 == {
        "key1": "value1",
        "key3": "value3"
    }
    assert ret_2 == "value4"


# Generated at 2022-06-24 20:48:15.953474
# Unit test for function set_fallbacks
def test_set_fallbacks():
    args = {}
    args['parameters'] = {}
    args['argument_spec'] = {}
    result = set_fallbacks(**args)
    assert result == set()


# Generated at 2022-06-24 20:48:22.816470
# Unit test for function set_fallbacks
def test_set_fallbacks():
    parameter_spec = dict(
        foo=dict(type='str'),
        bar=dict(type='dict', options=dict(
            a=dict(type='str'),
            b=dict(type='list', elements='int'),
        )),
        c_list=dict(type='list', elements='int'),
    )

    parameters = dict(
        foo=None,
        bar=None,
        c_list=[],
    )
    no_log_values = set_fallbacks(parameter_spec, parameters)
    assert no_log_values == set()
    assert parameters['foo'] is None
    assert parameters['bar'] is None
    assert parameters['c_list'] == []


# Generated at 2022-06-24 20:48:25.640485
# Unit test for function remove_values
def test_remove_values():
    a = {1: '5', 2: {1: '5'}, 3: {1: '5', 2: {1: '5'}}, 4: [1, '5']}
    b = {1: '', 2: {1: ''}, 3: {1: '', 2: {1: '5'}}, 4: [1, '']}
    assert remove_values(a, ['5']) == b



# Generated at 2022-06-24 20:48:37.478028
# Unit test for function set_fallbacks
def test_set_fallbacks():
    """Set default values, if possible
    """

    argument_spec = {'param': {'type': 'str', 'required': False, 'default': 'default_value'},
                     'param2': {'type': 'str', 'required': False, 'default': 'default_value', 'no_log': True},
                     'param3': {'type': 'str', 'required': False, 'choices': ['test'], 'default': 'test', 'fallback': (env_fallback, ['test1', 'test2', 'test3'], {'fallback': 'test4'})}}
    parameters = {'param2': 'no_log_value', 'param3': 'not_default'}

    no_log_values = set_fallbacks(argument_spec, parameters)

    assert 'no_log_value' in no_

# Generated at 2022-06-24 20:48:42.197752
# Unit test for function set_fallbacks
def test_set_fallbacks():
    var_0 = {
        'param1': {'fallback': (env_fallback,)},
        'param2': {'fallback': (env_fallback, ('a', 'b'))},
        'param3': {'fallback': (env_fallback, ('a', 'b', {'c': 'd'}))}
    }
    var_1 = {}
    check_set_fallbacks(var_0, var_1)


# Generated at 2022-06-24 20:48:50.320413
# Unit test for function set_fallbacks
def test_set_fallbacks():
    var_0 = {                                                                    # Supporting type
        'type': 'str',
        'fallback': [env_fallback],                                              # Supporting value
    }                                                                            # Supporting type
    var_1 = dict()                                                               # Supporting type
    var_2 = module_common._to_lines(filter_result=False, var=var_1)              # Supporting type
    assert var_2 == var_1                                                        # Assertion error


# Generated at 2022-06-24 20:48:52.624719
# Unit test for function set_fallbacks
def test_set_fallbacks():

    var_0 = {'a': 'b'}
    result = set_fallbacks(var_0, {})
    assert result == set()


# Generated at 2022-06-24 20:48:59.912532
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback(env='ENV1', env1='ENV2') == 'ENV2', "Test case 0 failed"
    assert env_fallback(env1='ENV2', env='ENV1') == 'ENV1', "Test case 1 failed"
    pass



# Generated at 2022-06-24 20:49:25.992788
# Unit test for function env_fallback
def test_env_fallback():
    assert (var_0 == test_case_0()), 'variable var_0 has different value than function test_case_0'


# Generated at 2022-06-24 20:49:28.423113
# Unit test for function sanitize_keys
def test_sanitize_keys():
    var_0 = {"foo": "bar", "baz": "qux"}
    var_1 = sanitize_keys(var_0, set())
    assert var_1 == {"foo": "bar", "baz": "qux"}


# Generated at 2022-06-24 20:49:30.096324
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback() is AnsibleFallbackNotFound


# Generated at 2022-06-24 20:49:39.695565
# Unit test for function set_fallbacks
def test_set_fallbacks():
    var_0 = {
        'fallback': (
            env_fallback,
            'client_id',
        ),
    }

    var_0_expected = {
        'fallback': (
            env_fallback,
            'client_id',
        ),
    }

    var_1 = {
        'fallback': (
            env_fallback,
            'client_id',
        ),
    }

    var_1_expected = {
        'fallback': (
            env_fallback,
            'client_id',
        ),
    }

    var_2 = {
        'fallback': (
            env_fallback,
            'client_id',
        ),
    }


# Generated at 2022-06-24 20:49:50.136065
# Unit test for function set_fallbacks
def test_set_fallbacks():
    var_0 = {'name': {'aliases': [],
                      'apply_defaults': False,
                      'choices': [],
                      'default': 'test_default',
                      'elements': None,
                      'fallback': (env_fallback),
                      'no_log': False,
                      'type': 'str'},
              'state': {'aliases': [],
                        'apply_defaults': False,
                        'choices': ['absent', 'present'],
                        'default': None,
                        'elements': None,
                        'fallback': (env_fallback),
                        'no_log': False,
                        'type': 'str'}}
    var_1 = {}
    var_2 = {}

    set_fallbacks(var_0, var_1)

    # Assert if no

# Generated at 2022-06-24 20:49:55.481874
# Unit test for function remove_values
def test_remove_values():
    args = [ b'foo', {}, [], None, {} ]
    if remove_values(*args) != None:
        raise AssertionError("Test 1 failed")

    args = [ b'baz', { 'foo': b'bar' }, [], None, { 'foo': b'bar' } ]
    if remove_values(*args) != None:
        raise AssertionError("Test 2 failed")

    args = [ {}, { 'foo': b'bar' }, [], None, { 'foo': b'bar' } ]
    if remove_values(*args) != None:
        raise AssertionError("Test 3 failed")

    args = [ b'bar', { 'foo': b'bar' }, [], None, {} ]
    if remove_values(*args) != None:
        raise AssertionError("Test 4 failed")

# Generated at 2022-06-24 20:50:00.805072
# Unit test for function env_fallback
def test_env_fallback():
    # Check function env_fallback
    options = {'ANSIBLE_MODULE_ARGS': {u'arg1': u'val1', u'arg2': u'val2', u'arg3': u'val3'}}
    module_arg_spec = dict(
        arg1=dict(type='str', required=False, default=None),
        arg2=dict(type='str', required=False, default=None),
        arg3=dict(type='str', required=False, default=None),
    )
    no_log = set()
    output = AnsibleValidationErrorMultiple()
    return_value = validate_options(module_arg_spec, options, no_log, output)
    assert return_value == True
    assert output == []

# Generated at 2022-06-24 20:50:06.997138
# Unit test for function set_fallbacks

# Generated at 2022-06-24 20:50:12.615017
# Unit test for function set_fallbacks
def test_set_fallbacks():
    var_1 = {"ansible_host": {"elements": "str", "required": True, "type": "list", "version_added": "2.0"}, "ansible_port": {"default": 22, "description": "The port number of the target host.", "in": ["ssh", "winrm"], "type": "int"}, "ansible_user": {"default": "root", "description": "The default username to connect with.", "version_added": "0.6.1"}}
    var_2 = {}
    result = set_fallbacks(var_1, var_2)
    # Possible problem: the function is too simple so it can not be tested.
    assert True



# Generated at 2022-06-24 20:50:17.853575
# Unit test for function set_fallbacks
def test_set_fallbacks():
    host = {}
    argument_spec = {"hostname": {"type": "str", "required": True}, "fallback": {"type": "str", "fallback": ("test_fallback",)}}
    no_log_values = set_fallbacks(argument_spec, host)
    assert host["fallback"] == "test_fallback"
    assert len(no_log_values) == 0



# Generated at 2022-06-24 20:50:55.862698
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Define the arguments for the spec.
    argument_spec = {
        "arg1": {
            "fallback": ('env', ('TEST1', 'TEST2', {'vars': ['TEST3']})) # Use TEST3 only if the other ones fails
        },
        "arg2": {
            "fallback": ('env', 'HOME')
        },
        "arg3": {
            "fallback": (env_fallback, 'TEST4', 'TEST5')
        },
        "arg4": {
            "fallback": (env_fallback, 'TEST6', 'TEST7')
        },
        "arg5": {
            "fallback": (env_fallback, 'TEST8', 'TEST9')
        }
    }
    parameters = {
    }
   

# Generated at 2022-06-24 20:50:58.462102
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Check that AnsibleFallbackNotFound is raised when no arguments are supplied
    try:
        env_fallback()
        assert False
    except AnsibleFallbackNotFound:
        assert True



# Generated at 2022-06-24 20:51:05.697357
# Unit test for function remove_values

# Generated at 2022-06-24 20:51:15.503352
# Unit test for function set_fallbacks
def test_set_fallbacks():
    spec_0 = {
    }
    parm_0 = {
    }
    returned_0 = set()
    no_log_values_0 = set_fallbacks(spec_0,parm_0)
    assert_equal(no_log_values_0, returned_0)

    spec_1 = {
        'foo': {
            'fallback': (env_fallback, 'foo')
        }
    }
    parm_1 = {
    }
    returned_1 = set()
    no_log_values_1 = set_fallbacks(spec_1,parm_1)
    assert_equal(no_log_values_1, returned_1)


# Generated at 2022-06-24 20:51:21.237619
# Unit test for function remove_values
def test_remove_values():
    assert remove_values({"a": 1, "b": 2}, {"a"}) == {"b": 2}, "Incorrect value in remove_values"
    assert remove_values({"a": 1, "b": 2}, set()) == {"a": 1, "b": 2}, "Incorrect value in remove_values"


# Generated at 2022-06-24 20:51:32.365363
# Unit test for function remove_values
def test_remove_values():
    no_log_strings = ["system password", "configuration file"]
    value = {
        "_ansible_no_log": False,
        "active": True,
        "age": 25,
        "children": [{"name": "system password"}],
        "name": "John",
        "password": "configuration file"
    }

    # The function being tested
    new_value = remove_values(value, no_log_strings)

    # Assert that the function output is valid
    assert new_value == {
        "_ansible_no_log": False,
        "active": True,
        "age": 25,
        "children": [{"name": "*******"}],
        "name": "John",
        "password": "*******"
    }



# Generated at 2022-06-24 20:51:37.120693
# Unit test for function env_fallback
def test_env_fallback():

    # Check if the function raises the expected exception
    var_0 = env_fallback()
    assert type(var_0) == AnsibleFallbackNotFound, "Variable 'var_0' is of type AnsibleFallbackNotFound"
    try:
        test_case_0()
    except AnsibleFallbackNotFound:
        pass




# Generated at 2022-06-24 20:51:47.031000
# Unit test for function set_fallbacks
def test_set_fallbacks():
    var_0 = {}
    var_1 = {'arg_0': {'type': 'str', 'required': False, 'fallback': (env_fallback, )}}
    var_2 = set_fallbacks(var_1, var_0)
    assert var_2 == set()
    var_3 = {'arg_0': 'a'}
    var_4 = set_fallbacks(var_1, var_3)
    assert var_4 == set()
    var_5 = {'arg_0': {'type': 'str', 'required': False, 'fallback': (env_fallback, )}}
    var_6 = {'arg_0': 'a'}
    var_7 = set_fallbacks(var_5, var_6)
    assert var_7 == set()
    os.en

# Generated at 2022-06-24 20:51:48.748964
# Unit test for function env_fallback
def test_env_fallback():
    assert 'env_fallback' in globals(), "Function named 'env_fallback' should be in the global namespace"


# Unit tests for module


# Generated at 2022-06-24 20:51:49.850385
# Unit test for function remove_values
def test_remove_values():
    var_0 = remove_values(var_0, no_log_strings)


# Generated at 2022-06-24 20:52:21.611030
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # stub
    parameters = {}
    # stub

    argument_spec = {
        'var_0': {
            'default': None,
            'type': 'str',
            'fallback': (env_fallback,)
        }
    }

    assert set_fallbacks(argument_spec, parameters) == set()



# Generated at 2022-06-24 20:52:26.121434
# Unit test for function env_fallback
def test_env_fallback():
    res = env_fallback()
    print('The result is: {}'.format(res))


# Generated at 2022-06-24 20:52:28.208529
# Unit test for function remove_values
def test_remove_values():
    value = 'mypassword'
    no_log_strings = ('mypassword')
    assert remove_values(value, no_log_strings) == '******'


# Generated at 2022-06-24 20:52:34.222358
# Unit test for function sanitize_keys
def test_sanitize_keys():

    no_log_strings = set()
    ignore_keys = frozenset()
    obj = env_fallback()

    new_value = sanitize_keys(obj, no_log_strings, ignore_keys)
    assert new_value == obj


# Generated at 2022-06-24 20:52:39.220342
# Unit test for function set_fallbacks
def test_set_fallbacks():
    var_1 = set()
    var_1 = set([])
    var_2 = dict()
    var_2 = dict([])
    var_3 = env_fallback()
    set_fallbacks(var_2, var_2)


# Generated at 2022-06-24 20:52:45.810200
# Unit test for function set_fallbacks
def test_set_fallbacks():
    parameters = {}
    argument_spec = {'var_0': {'fallback': (env_fallback,)}}
    assert parameters == {}
    assert argument_spec == {'var_0': {'fallback': (env_fallback,)}}
    
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters == {'var_0': ""}
    assert argument_spec == {'var_0': {'fallback': (env_fallback,)}}
    assert no_log_values == set()



# Generated at 2022-06-24 20:52:47.070662
# Unit test for function env_fallback
def test_env_fallback():
    var_0 = env_fallback()
    assert var_0 is None


# Generated at 2022-06-24 20:52:48.078049
# Unit test for function env_fallback
def test_env_fallback():
    test_case_0()



# Generated at 2022-06-24 20:52:51.495552
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert set_fallbacks(None, None) == None, "Expected set_fallbacks to return None when given None parameters"
    assert_raises(AnsibleFallbackNotFound, set_fallbacks, {}, {})



# Generated at 2022-06-24 20:53:00.438030
# Unit test for function set_fallbacks
def test_set_fallbacks():
    params = dict({'name': 'unlucky'})

# Generated at 2022-06-24 20:53:29.572791
# Unit test for function env_fallback
def test_env_fallback():
    the_expected_value = argparse.Namespace(
        the_output_is=None,
    )
    the_arguments = argparse.Namespace(
    
    )
    the_function_under_test = test_case_0
    the_actual_value = the_function_under_test(
        the_arguments,
    )
    assert the_actual_value == the_expected_value
    return



# Generated at 2022-06-24 20:53:30.536067
# Unit test for function env_fallback
def test_env_fallback():
    var_0 = env_fallback()
    assert var_0


# Generated at 2022-06-24 20:53:32.760257
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert test_case_0() == 'cd, cd', 'test_case_0() failed'


# Generated at 2022-06-24 20:53:34.138286
# Unit test for function env_fallback
def test_env_fallback():
    try:
        test_0 = test_case_0()
    except Exception as e:
        print("Error is: ", e)



# Generated at 2022-06-24 20:53:39.280269
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {}
    parameters = {'a': True, 'b': False}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert no_log_values == set()
    assert parameters == {'a': True, 'b': False}
    parameters = {}
    argument_spec = {'a': {'fallback': [env_fallback, 'ABC']}, 'b': {'fallback': [env_fallback], 'no_log': True}}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters == {'b': ''}
    assert no_log_values == {''}

# Generated at 2022-06-24 20:53:40.296778
# Unit test for function env_fallback
def test_env_fallback():
    try:
        assert test_case_0() == None
    except NotImplementedError:
        pass


# Generated at 2022-06-24 20:53:44.629875
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Create mock params
    argument_spec = {"fallback": "fallback_0", "parameters": "parameters_0"}

    # Create mock function function
    def fallback_0(*args, **kwargs):
        return "fallback_0"

    set_fallbacks(argument_spec, parameters=variables["parameters_0"])


# Generated at 2022-06-24 20:53:53.156277
# Unit test for function sanitize_keys
def test_sanitize_keys():
    var = {'key_1': 'val_1', 'key_2': 'val_2', "key_3": 'val_3'}
    var = _sanitize_keys_conditions(var, ['val_1', 'val_2'], [], deque())
    assert var == {'key_1': 'val_1', 'key_2': 'val_2', 'val_3': 'val_3'}

    var = {'key_1': 'val_1', 'key_2': 'val_2', "key_3": 'val_3'}
    var = _sanitize_keys_conditions(var, ['val_1', 'val_3'], [], deque())

# Generated at 2022-06-24 20:53:55.939552
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'var_0': {"type": "str", "default": None, "fallback": (env_fallback,)}}
    parameters = {'var_0': None}
    expected = set()
    result = set_fallbacks(argument_spec, parameters)
    assert result == expected

# Method test_set_fallbacks
test_set_fallbacks()



# Generated at 2022-06-24 20:54:04.521876
# Unit test for function set_fallbacks
def test_set_fallbacks():
    data = {
        "new_param": {
            "type": "str",
            "required": True
        },
        "old_param": {
            "type": "str",
            "fallback": (env_fallback, "MYENV")
        },
        "password": {
            "required": True,
            "type": "str",
            "no_log": True,
            "fallback": (env_fallback, "MYPASSWORD")
        }
    }

    args = {}
    no_log_values = set_fallbacks(data, args)
    assert 'MYENV' in args
    assert args['old_param'] == 'MYENV'
    assert 'MYPASSWORD' in no_log_values
    assert len(no_log_values) == 1



# Generated at 2022-06-24 20:54:32.749565
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys(var_0, ignore_keys=frozenset()) == var_0
    assert sanitize_keys(arg_0, no_log_strings=no_log_strings, ignore_keys=frozenset()) == arg_1
    assert sanitize_keys(arg_2, no_log_strings=no_log_strings, ignore_keys=frozenset()) == arg_3


# Generated at 2022-06-24 20:54:38.816873
# Unit test for function env_fallback
def test_env_fallback():
    var_0 = env_fallback(u'PATH', u'ANSIBLE_PATH')
    if var_0 is not AnsibleFallbackNotFound:
        assert type(var_0) == unicode, u"expected type <unicode>, got: %s" % type(var_0)
    else:
        assert var_0 is AnsibleFallbackNotFound, u"expected type <type 'AnsibleFallbackNotFound'>, got: %s" % type(var_0)


# Generated at 2022-06-24 20:54:46.020392
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'a': {
            'no_log': True,
            'fallback': (env_fallback, 'A_VAR')
        },
        'c': {
            'fallback': (env_fallback, 'C_VAR')
        }
    }

    parameters = {'b': 'foo'}

    no_log_values = set_fallbacks(argument_spec, parameters)

    assert no_log_values == set()
    assert parameters == {'a': None, 'b': 'foo', 'c': None}



# Generated at 2022-06-24 20:54:55.489281
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        atoms=dict(
            type='list',
            elements='dict',
            options=dict(
                name=dict(type='str', default='default', fallback=(env_fallback, [('ANSIBLE_TEST_VAR_0',)], {})),
                value=dict(type='str'),
                unit=dict(type='str')
            )
        )
    )
    parameters = dict(
        atom=dict(name='default', value='0', unit='foo')
    )
    no_log_values = set()
    for atom_name in parameters.keys():
        var = 'ANSIBLE_TEST_VAR_%d' % atom_name
        os.environ[var] = 'foo'
        no_log_values.add('foo')
    no_log_

# Generated at 2022-06-24 20:55:01.628449
# Unit test for function env_fallback
def test_env_fallback():
    var_0 = 'ANSIBLE_TEST_ENV_FALLBACK'
    var_1 = ''
    with utils.set_environ(dict(ANSIBLE_TEST_ENV_FALLBACK=var_1)):
        pass


# Generated at 2022-06-24 20:55:04.498978
# Unit test for function remove_values

# Generated at 2022-06-24 20:55:13.352386
# Unit test for function set_fallbacks
def test_set_fallbacks():
    print('TESTING set_fallbacks')
    spec = {
        'param0': {'type': 'str', 'fallback': (env_fallback,)},
        'param1': {'type': 'str', 'fallback': env_fallback},
        'param2': {'type': 'int', 'fallback': (env_fallback, 'foo', 'bar')},
        'param3': {'type': 'str', 'fallback': (env_fallback, 'foo', 'bar')},
        'param4': {'type': 'str', 'fallback': (env_fallback, {'foo': 'bar', 'baz': 'qux'})},
    }
    parameters = {'param0': 'foo'}
    no_log_values = set_fallbacks(spec, parameters)

# Generated at 2022-06-24 20:55:20.247239
# Unit test for function set_fallbacks
def test_set_fallbacks():
    example_parameters = {'WRONG_ARG': 'wrong_value'}
    example_argument_spec = {'param_0': {'type': 'str', 'required': True}}
    no_log_values = set_fallbacks(example_argument_spec, example_parameters)
    assert 'param_0' in example_parameters
    assert example_parameters['WRONG_ARG'] == 'wrong_value'
    assert "param_0" in no_log_values


# Generated at 2022-06-24 20:55:26.604990
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # common tests
    test_case_0()


# Generated at 2022-06-24 20:55:34.814772
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Argument spec
    spec = {
        'param1': {
            'type': 'str',
            'required': 'yes',
            'fallback': ('env_fallback1', ('env1',))
        },
        'param2': {
            'type': 'str',
            'required': 'yes',
            'fallback': ('env_fallback2', ('env2',))
        },
        'param3': {
            'type': 'str',
            'required': 'yes',
            'fallback': ('env_fallback3', ('env3',))
        },
        'param4': {
            'type': 'str',
            'required': 'yes',
            'fallback': ('env_fallback4', ('env4',))
        }
    }
    # Parameters for the module:
    parameters