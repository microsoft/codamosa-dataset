

# Generated at 2022-06-24 20:46:40.305503
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert env_fallback is None, "env_fallback not set"
    assert "set_fallbacks" in globals(), "set_fallbacks not defined"
    assert callable(set_fallbacks), "set_fallbacks not callable"

    argument_spec = {
        'param1': {'fallback': (env_fallback, 'key1',)},
        'param2': {'fallback': (env_fallback, 'key2',)},
    }
    parameters = {
        'param1': None
    }
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert not no_log_values, "no_log_values not set"
    assert parameters['param1'] == 'key1', "'param1' not set"

# Generated at 2022-06-24 20:46:43.015126
# Unit test for function set_fallbacks
def test_set_fallbacks():

# assert set_fallbacks(argument_spec, parameters) == no_log_values
    assert True


# Generated at 2022-06-24 20:46:52.632341
# Unit test for function set_fallbacks
def test_set_fallbacks():
    def test_case_0():
        argument_spec = {}
        parameters = {}
        set_fallbacks(argument_spec, parameters)

    def test_case_1():
        argument_spec = {'argument_spec': {'type': 'int', 'no_log': True, 'fallback': (env_fallback, (1,))}}
        parameters = {}
        set_fallbacks(argument_spec, parameters)

    def test_case_2():
        argument_spec = {'argument_spec': {'type': 'int', 'no_log': True, 'fallback': (env_fallback, (1,), {'argument_spec': 'env_fallback'})}}
        parameters = {}
        set_fallbacks(argument_spec, parameters)

    test_case_0()
    test_case_1()


# Generated at 2022-06-24 20:47:00.988020
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict()
    argument_spec[u'test_set_fallbacks'] = dict(type='str', no_log=True, fallback=(env_fallback, [u'TEST_SET_FALLBACKS_ENV_0']))
    parameters = dict()
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert len(no_log_values) == 0
    assert u'test_set_fallbacks' not in parameters
    # Dictionary of environment variables
    dict_0 = {}
    dict_0[u'TEST_SET_FALLBACKS_ENV_0'] = u'test_set_fallbacks_0'
    # Update environment variables
    os.environ.update(dict_0)

# Generated at 2022-06-24 20:47:06.790285
# Unit test for function set_fallbacks
def test_set_fallbacks():
    import logging
    import sys
    logger = logging.getLogger('set_fallbacks')


# Generated at 2022-06-24 20:47:14.405749
# Unit test for function set_fallbacks
def test_set_fallbacks():
    arg_spec = {
        "test_parameter": {
            "type": "str",
            "fallback": [env_fallback, 'TEST_PARAMETER'],
            "no_log": True
        }
    }
    parameters = {}
    no_log_values = set_fallbacks(arg_spec, parameters)
    assert no_log_values == {env_fallback('TEST_PARAMETER')}

    # Test that fallback doesn't overwrite value already set
    parameters = {
        "test_parameter": "value"
    }
    no_log_values = set_fallbacks(arg_spec, parameters)
    assert no_log_values == set()
    assert parameters == {"test_parameter": "value"}


# Generated at 2022-06-24 20:47:15.866747
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert test_case_0() == set()

# ============================================================================
# Check that all options have the types and values they are supposed to

# Generated at 2022-06-24 20:47:24.456608
# Unit test for function set_fallbacks
def test_set_fallbacks():
    _spec = {
        'foo': {'type': 'dict',
                'options': {'bar': {'type': 'int', 'required': True},
                            'baz': {'type': 'int', 'default': 42},
                            'bam': {'type': 'int', 'required': True, 'fallback':
                                    (env_fallback, 'foo_bam', 'bar_bam')}},
                'required': True,
                'allow_extra': True,
                'apply_defaults': True}
    }
    parameters = {'foo':{'bar': 1, 'bam': 2}}
    set_fallbacks(_spec, parameters)
    assert parameters['foo']['baz'] == 42


# Generated at 2022-06-24 20:47:27.946897
# Unit test for function env_fallback
def test_env_fallback():
    with pytest.raises(AnsibleFallbackNotFound):
        assert var_0

#############################################################################################
# Generic functions for modifying options
#############################################################################################



# Generated at 2022-06-24 20:47:34.404575
# Unit test for function set_fallbacks

# Generated at 2022-06-24 20:47:59.632239
# Unit test for function set_fallbacks
def test_set_fallbacks():
    with pytest.raises(AnsibleFallbackNotFound):
        argument_spec = {'test_parameter': {'type': 'str', 'fallback': (env_fallback,)}}
        base_arg_spec = {'test_parameter': {'type': 'str', 'fallback': (env_fallback,)}}
        parameters = {'test_parameter': 'test_value'}
        set_fallbacks(argument_spec, parameters)


# Generated at 2022-06-24 20:48:04.848344
# Unit test for function set_fallbacks
def test_set_fallbacks():
    """
    Test function set_fallbacks with correct parameters

    :return: None
    """

    # Test with a dictionary of the following format

    # {
    #   'param1': {
    #       'choices': [
    #           'choice1',
    #           'choice2'
    #       ],
    #       'type': 'str'
    #   },
    #   'param2': {
    #       'type': 'str',
    #       'required': True
    #   },
    #   'param3': {
    #       'type': 'dict',
    #       'options': {
    #           'subparam1': {
    #               'type': 'str'
    #           }
    #       }
    #   },
    #   'param4': {
    #       '

# Generated at 2022-06-24 20:48:14.314692
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Unit test for function set_fallbacks
    dict_0 = {}
    dict_1 = {}
    dict_1['type'] = 'dict'
    dict_1['options'] = {}
    dict_2 = {}
    dict_2['type'] = 'str'
    dict_1['options']['data'] = dict_2
    dict_3 = {}
    dict_3['type'] = 'dict'
    dict_3['options'] = {}
    dict_4 = {}
    dict_4['type'] = 'str'
    dict_3['options']['data'] = dict_4
    dict_1['options']['data_list'] = dict_3
    dict_5 = {}
    dict_5['type'] = 'dict'
    dict_5['options'] = {}
    dict_6 = {}

# Generated at 2022-06-24 20:48:20.257382
# Unit test for function set_fallbacks
def test_set_fallbacks():
    dict_0 = {}
    dict_1 = {}
    dict_1['parameters'] = dict_0
    dict_1['argument_spec'] = dict_0
    dict_1['prefix'] = ''
    dict_1['options_context'] = []
    dict_1['no_log_values'] = set()
    dict_1['unsupported_parameters'] = set()
    dict_2 = {}
    dict_3 = {}
    dict_3['elements'] = 'dict'
    dict_3['type'] = 'list'
    dict_2['options'] = dict_3
    dict_2['type'] = 'dict'
    dict_1['argument_spec']['parameters'] = dict_2
    dict_4 = {}
    dict_4['param'] = 'parameters'
    dict_4

# Generated at 2022-06-24 20:48:22.936383
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'param_1': {},
        'param_2': {},
        'param_3': {},
    }
    parameters = {
        'param_1': True,
        'param_2': True,
        'param_3': True,
    }
    set_fallbacks(argument_spec, parameters)
    pass


# Generated at 2022-06-24 20:48:30.223754
# Unit test for function set_fallbacks
def test_set_fallbacks():
    print("Running function name: %s" % (inspect.stack()[0][3]))
    # Test 1
    dict_0 = {}
    dict_1 = {'param0': 'value0', 'param1': {'param2': 'value2'}}
    dict_2 = {'param3': 'value3'}
    var_0 = {'param0': 'value0', 'param1': {'param2': 'value2'}, 'param3': 'value3'}
    result = {}
    result['param0'] = 'value0'
    result['param1'] = {}
    result['param1']['param2'] = 'value2'
    result['param3'] = 'value3'
    real_value_0 = set_fallbacks(dict_0, dict_1)
    real_value

# Generated at 2022-06-24 20:48:38.494725
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict()
    argument_spec['a'] = dict()
    argument_spec['a']['type'] = 'int'
    argument_spec['b'] = dict()
    argument_spec['b']['type'] = 'bool'
    argument_spec['b']['default'] = True
    argument_spec['c'] = dict()
    argument_spec['c']['type'] = 'str'
    argument_spec['c']['default'] = 'a'
    argument_spec['d'] = dict()
    argument_spec['d']['type'] = 'str'
    argument_spec['d']['default'] = 'wtf'
    argument_spec['e'] = dict()
    argument_spec['e']['type'] = 'str'

# Generated at 2022-06-24 20:48:42.627290
# Unit test for function env_fallback
def test_env_fallback():
    dict_0 = {'PATH':'/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/tools/node/bin:/tools/google-cloud-sdk/bin:/opt/ansible/bin'}
    var_0 = env_fallback(**dict_0)
    if var_0 != '/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/tools/node/bin:/tools/google-cloud-sdk/bin:/opt/ansible/bin':
        raise Exception('Failed')
    pass


# Generated at 2022-06-24 20:48:53.735820
# Unit test for function set_fallbacks

# Generated at 2022-06-24 20:49:00.006294
# Unit test for function set_fallbacks
def test_set_fallbacks():
    dict_0 = {}
    dict_0['fallback'] = (env_fallback,)
    dict_0['no_log'] = False

    dict_1 = {}
    dict_1['fallback'] = (env_fallback,)
    dict_1['no_log'] = False

    dict_2 = {}
    dict_2['fallback'] = (env_fallback,)
    dict_2['no_log'] = False
    dict_2['elements'] = 'dict'
    dict_2['type'] = 'list'


    dict_3 = {}
    dict_3['fallback'] = (env_fallback,)
    dict_3['no_log'] = False


    dict_4 = {}
    dict_4['debug'] = dict_0

# Generated at 2022-06-24 20:49:45.640564
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # dict_0 = {}
    dict_0 = None
    argument_spec = {'api_key': {'description': 'Nexpose API key',
         'fallback': (env_fallback, 'NEXPOSE_API_KEY'),
         'no_log': True,
         'required': True,
         'type': 'str'}}

    set_fallbacks(argument_spec, dict_0)



# Generated at 2022-06-24 20:49:55.403090
# Unit test for function set_fallbacks
def test_set_fallbacks():
    dict_0 = {}
    dict_1 = {}
    dict_1['fallback'] = ()
    dict_1['type'] = 'str'
    dict_2 = {}
    dict_2['fallback'] = env_fallback
    dict_2['type'] = 'str'
    dict_3 = {}
    dict_3['fallback'] = (env_fallback, 'test')
    dict_3['no_log'] = False
    dict_3['type'] = 'str'
    dict_4 = {}
    dict_4['fallback'] = (env_fallback, {'param': 'test'})
    dict_4['no_log'] = True
    dict_4['type'] = 'str'
    parameters_0 = {}

# Generated at 2022-06-24 20:50:00.738379
# Unit test for function set_fallbacks
def test_set_fallbacks():
    dict_0 = {}
    dict_1 = {}
    dict_1['fallback'] = ()
    dict_1['type'] = 'str'
    dict_0['name'] = dict_1
    dict_2 = {}
    dict_2['fallback'] = ()
    dict_2['type'] = 'str'
    dict_0['age'] = dict_2
    dict_3 = {}
    dict_3['fallback'] = ()
    dict_3['type'] = 'str'
    dict_0['gender'] = dict_3
    dict_4 = {}
    dict_4['fallback'] = ()
    dict_4['type'] = 'str'
    dict_0['address'] = dict_4
    dict_5 = {}
    dict_5['fallback'] = ()

# Generated at 2022-06-24 20:50:05.542105
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Create argument spec
    arg_spec = dict(
        foo=dict(
            required=True,
            fallback=(env_fallback, 'FOO')
        ),
        bar=dict(
            default='bar'
        )
    )
    # Get the merged result of foo and bar
    parameters, no_log_values = merge_hash(arg_spec, dict(foo='foo', bar='bar'))
    # Do the fallback
    no_log_values.update(set_fallbacks(arg_spec, parameters))
    assert parameters['foo'] == 'foo'
    assert parameters['bar'] == 'bar'


# Generated at 2022-06-24 20:50:06.934778
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert sanitize_keys(var_0, no_log_strings, ignore_keys) == {}

# Generated at 2022-06-24 20:50:10.388832
# Unit test for function sanitize_keys
def test_sanitize_keys():
    # Initialize the class
    test_obj = SanitizeKeys()

    # set up some test data
    data = {'foo': 'bar', 'baz': 'xxx'}
    no_log_values = {'xxx'}
    result = {'foo': 'bar', 'baz': '***'}

    test_obj.assertEqual(sanitize_keys(data, no_log_values), result)


# Generated at 2022-06-24 20:50:17.381655
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'test': {
            'type': 'str',
            'fallback': (env_fallback, "something")
        },
        'test2': {
            'type': 'str',
            'fallback': (env_fallback, {"something": None})
        }
    }
    parameters = {}

    set_fallbacks(argument_spec, parameters)
    assert len(parameters) == 0


# Generated at 2022-06-24 20:50:24.126373
# Unit test for function set_fallbacks
def test_set_fallbacks():
    arg_spec = {
        'a': {
            'type': 'int',
            'fallback': (env_fallback, 'b1', 'b2')
        }
    }
    p = {'b': 1}
    no_log = set_fallbacks(arg_spec, p)



# Generated at 2022-06-24 20:50:30.157453
# Unit test for function set_fallbacks
def test_set_fallbacks():
    from ansible.module_utils.common._collections_compat import Mapping

    param_0 = {}
    param_1 = {}
    _set_defaults = set_fallbacks(param_0, param_1)
    assert isinstance(_set_defaults, set)

    param_0 = {}
    param_1 = {}
    _set_defaults = set_fallbacks(param_0, param_1)
    assert isinstance(_set_defaults, set)

    param_0 = {}
    param_1 = {}
    _set_defaults = set_fallbacks(param_0, param_1)
    assert isinstance(_set_defaults, set)

    param_0 = {}
    param_1 = {}
    _set_defaults = set_fallbacks(param_0, param_1)


# Generated at 2022-06-24 20:50:37.058093
# Unit test for function sanitize_keys
def test_sanitize_keys():
    dict_0 = {"a": 1, "b": 2, "c": 3}
    var_0 = remove_values(dict_0, [], None)
    dict_1 = {}
    var_1 = sanitize_keys(dict_0, dict_1)


# Generated at 2022-06-24 20:51:28.840740
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {"foo": {"type": "str", "fallback": (env_fallback,)}}
    parameters = {}
    no_log_values = set_fallbacks(argument_spec, parameters)
    # Should not raise
    assert parameters['foo'] == os.environ['foo']


# Generated at 2022-06-24 20:51:36.564051
# Unit test for function remove_values
def test_remove_values():
    no_log_strings_0 = set()
    no_log_strings_0.add('foo')
    value_0 = ["Test", "foo", "baz", {}]
    value_1 = remove_values(value_0, no_log_strings_0)
    expected_value_1 = ["Test", "baz", {}]
    assert value_1 == expected_value_1


# Generated at 2022-06-24 20:51:45.427727
# Unit test for function remove_values
def test_remove_values():
  import json
  data_file_path = os.path.join(os.path.dirname(__file__), 'support/vault.json')
  with open(data_file_path) as data_file:
    data = json.load(data_file)

  new_data = remove_values(data, ['password'])

  data_file_path = os.path.join(os.path.dirname(__file__), 'support/vault_removed.json')
  with open(data_file_path) as data_file:
    data = json.load(data_file)

  assert new_data == data


# Generated at 2022-06-24 20:51:48.836621
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {}
    parameters = {}
    set_fallbacks(argument_spec, parameters)


# Generated at 2022-06-24 20:51:50.585614
# Unit test for function env_fallback
def test_env_fallback():
    try:
        test_case_0()
    except NameError:
        pass


# Generated at 2022-06-24 20:51:59.791570
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'a': {
            'default': 'bar',
            'fallback': (env_fallback, 'FOO', {'key': 'value'}),
            'type': 'str'
        }
    }
    parameters = {}

    set_fallbacks(argument_spec, parameters)

    if parameters['a'] != 'value':
        return False

    return True


# Generated at 2022-06-24 20:52:01.880337
# Unit test for function env_fallback
def test_env_fallback():
    dict_0 = {}
    assert env_fallback(**dict_0) == AnsibleFallbackNotFound



# Generated at 2022-06-24 20:52:11.365572
# Unit test for function set_fallbacks
def test_set_fallbacks():
    fallbacks = set_fallbacks(
        {'foo': {'type': 'dict', 'fallback': (env_fallback, {'var': 'FOO'})}},
        {}
    )
    assert not fallbacks
    assert 'foo' not in locals()
    fallbacks = set_fallbacks(
        {'foo': {'type': 'dict', 'fallback': (env_fallback, {'var': 'FOO'})}},
        {'foo': {}}
    )
    assert not fallbacks
    assert 'foo' in locals() and locals()['foo'] == {}
    os.environ['FOO'] = 'bar'

# Generated at 2022-06-24 20:52:16.819431
# Unit test for function remove_values
def test_remove_values():
    # Test string
    assert remove_values('', ['']) == ''
    assert remove_values('test', ['']) == 'test'
    assert remove_values('test', ['test']) == ''
    assert remove_values('test', ['test', 'test']) == ''
    assert remove_values('test', ['test', 'test2']) == ''
    assert remove_values('test', ['test2']) == 'test'
    assert remove_values('test', ['test2', 'test']) == ''
    assert remove_values('test', ['test2', 'test3', 'test4']) == 'test'
    assert remove_values('', ['']) == ''
    assert remove_values('test', ['', '', '']) == ''

# Generated at 2022-06-24 20:52:24.088987
# Unit test for function env_fallback
def test_env_fallback():
    my_vars = {}
    my_vars['env'] = {}
    my_vars['env']['ANSIBLE_CACHE_PLUGIN_CONNECTION'] = 'http'
    my_vars['env']['ANSIBLE_CACHE_PLUGIN_TERM_TIMEOUT'] = '0'
    my_vars['env']['ANSIBLE_CACHE_PLUGIN_TIMEOUT'] = '0'
    my_vars['env']['ANSIBLE_COLLECTIONS_PATHS'] = '/etc/ansible/collections'
    my_vars['env']['ANSIBLE_CONFIG'] = '/etc/ansible/ansible.cfg'
    my_vars['env']['ANSIBLE_DEBUG'] = '1'

# Generated at 2022-06-24 20:53:17.447154
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {"list_0": {"type": "list", "elements": "str", "fallback": (env_fallback, [{"test": "return"}])}}

    parameters = {"list_0": ["abc", "def"]}
    no_log_values = set_fallbacks(argument_spec, parameters)
    
    assert len(parameters) == 1
    assert parameters["list_0"] == ["abc", "def"]

    assert no_log_values == set()

if __name__ == '__main__':
    # Unit test for function set_fallbacks
    test_set_fallbacks()

# Generated at 2022-06-24 20:53:20.957324
# Unit test for function env_fallback
def test_env_fallback():
    pass


# Generated at 2022-06-24 20:53:22.352275
# Unit test for function env_fallback
def test_env_fallback():
    with pytest.raises(AnsibleFallbackNotFound):
        test_case_0()


# Generated at 2022-06-24 20:53:27.419045
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Test list of dicts
    list_0_dict_0 = {}
    list_0_dict_1 = {}
    list_0 = [list_0_dict_0, list_0_dict_1]
    test_case_0()
    # Test with defaults
    dict_1 = {'fallback': (env_fallback, test_case_0, {})}
    list_1 = [dict_1]
    set_fallback_retval = set_fallbacks(list_1, dict_0)
    assert set_fallback_retval == {'1'}

# Generated at 2022-06-24 20:53:38.722741
# Unit test for function set_fallbacks
def test_set_fallbacks():
    from ansible.module_utils import basic
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.six import PY3
    from ansible.parsing.vault import VaultLib
    from ansible.plugins.loader import vault_loader

    # Generate random values
    arg_0 = os.urandom(random.randint(0, 300))
    arg_1 = os.urandom(random.randint(0, 300))
    arg_2 = os.urandom(random.randint(0, 300))
    arg_3 = os.urandom(random.randint(0, 300))

    # Generate string representations of random values
    arg_str_0 = repr(arg_0)
    arg_str_1 = repr(arg_1)
   

# Generated at 2022-06-24 20:53:41.010339
# Unit test for function remove_values
def test_remove_values():
    print("test_remove_values")
    assert isinstance(remove_values([0, 1, 2], [2]), list)


# Generated at 2022-06-24 20:53:50.236219
# Unit test for function set_fallbacks

# Generated at 2022-06-24 20:53:57.971781
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {}
    parameters = {}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert no_log_values == set()
    assert parameters == {}

    argument_spec = {
        'some_param': {
            'type': 'str',
            'fallback': (env_fallback, ['TEST_SOME_PARAM']),
            'default': None,
            'required': True
        },
    }
    parameters = {}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert no_log_values == set()
    assert parameters == {}

    os.environ['TEST_SOME_PARAM'] = 'test_some_param'
    no_log_values = set_fallbacks(argument_spec, parameters)

# Generated at 2022-06-24 20:54:00.428921
# Unit test for function env_fallback
def test_env_fallback():
    dict_0 = {}
    try:
        var_0 = env_fallback(**dict_0)
    except AnsibleFallbackNotFound as e:
        assert var_0 is None


# Generated at 2022-06-24 20:54:08.708245
# Unit test for function remove_values
def test_remove_values():
    fake_str = "*****"
    assert remove_values("blah", (fake_str,)) == "blah"
    assert remove_values("blah", (fake_str, "hello")) == "blah"
    assert remove_values("blah", ("hello",)) == "blah"
    assert remove_values("blah", ("blah",)) == fake_str
    assert remove_values("blah", ("blah", "blah2")) == fake_str
    assert remove_values("blah", ("blah2", "blah")) == fake_str
    assert remove_values("blah", ("blah2", "blagh", "blah")) == fake_str
    assert remove_values("blah", ("blah2", "blah")) == fake_str

# Generated at 2022-06-24 20:55:51.350213
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'foo': {'default': 'bar'}, 'bar': {'default': 'foo'}}
    parameters = {'foo': 'bar', 'baz': 'qux'}
    assert set_fallbacks(argument_spec, parameters) == set()

    parameters = {'baz': 'qux'}
    assert set_fallbacks(argument_spec, parameters) == set()

    argument_spec['qux'] = {'default': 'secret_value', 'no_log': True}
    assert set_fallbacks(argument_spec, parameters) == {'secret_value'}

