

# Generated at 2022-06-24 20:46:52.666674
# Unit test for function set_fallbacks

# Generated at 2022-06-24 20:46:54.869385
# Unit test for function env_fallback
def test_env_fallback():
    try:
        test_case_0()
    except AnsibleFallbackNotFound:
        pass



# Generated at 2022-06-24 20:47:01.462660
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # TODO: uncomment below
    assert False
    # TODO: Add test args here
    test_case = {
        'argument_spec': {},
        'parameters': {},
    }
    test_func = set_fallbacks
    test_func_args = {
        'argument_spec': test_case['argument_spec'],
        'parameters': test_case['parameters'],
    }
    test_func_kwargs = {}

    assert test_func(**test_func_args, **test_func_kwargs)



# Generated at 2022-06-24 20:47:08.056787
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Argument spec
    argument_spec = {
    }
    # Parameter
    parameters = "TestString"
    # Set fallbacks
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert len(no_log_values) == 0


# Generated at 2022-06-24 20:47:14.156249
# Unit test for function set_fallbacks
def test_set_fallbacks():

    argument_spec = {"foo": {"type": "str", "fallback": (env_fallback, "FOO")}}
    parameters = {"baz": "quux"}

    no_log_values = set_fallbacks(argument_spec, parameters)
    assert len(no_log_values) == 0, no_log_values

    os.environ["FOO"] = "bar"

    no_log_values = set_fallbacks(argument_spec, parameters)
    assert len(no_log_values) == 0, no_log_values

    assert parameters["foo"] == "bar"


# Generated at 2022-06-24 20:47:15.397135
# Unit test for function env_fallback
def test_env_fallback():
    with pytest.raises(AnsibleFallbackNotFound):
        test_case_0()



# Generated at 2022-06-24 20:47:25.001035
# Unit test for function set_fallbacks

# Generated at 2022-06-24 20:47:29.124248
# Unit test for function set_fallbacks
def test_set_fallbacks():
    for test_data in TEST_DATA_set_fallbacks:
        # Test with a PRIMITIVE-type value
        try:
            var_0 = set_fallbacks(test_data[0], test_data[1])
        except AnsibleFallbackNotFound:
            var_0 = None

        assert var_0 == test_data[2]
    test_case_0()


# Generated at 2022-06-24 20:47:36.030056
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Incorrect argument type
    with pytest.raises(TypeError):
        set_fallbacks("str", "str")
    # Incorrect argument type
    with pytest.raises(TypeError):
        set_fallbacks(123, "str")
    # Incorrect argument type
    with pytest.raises(TypeError):
        set_fallbacks(123, 123)
    # Incorrect argument type
    with pytest.raises(TypeError):
        set_fallbacks("str", 123)

    # Incorrect argument type
    with pytest.raises(TypeError):
        set_fallbacks({}, {})
    # Incorrect argument type
    with pytest.raises(TypeError):
        set_fallbacks({}, [])
    # Incorrect argument type

# Generated at 2022-06-24 20:47:44.962300
# Unit test for function set_fallbacks
def test_set_fallbacks():

    argument_spec = {
        "a": {
            "type": "str",
            "choices": ('present', 'absent'),
            "required": True,
            "fallback": (env_fallback, ["ANSIBLE_A"])
        },
        "b": {
            "type": "str",
            "choices": ('present', 'absent'),
            "required": True,
            "fallback": (env_fallback, ["ANSIBLE_B"])
        }
    }

    parameters = {
        "a": "present"
    }
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert len(no_log_values) == 0

    parameters = {
        "b": "present"
    }

# Generated at 2022-06-24 20:48:13.280391
# Unit test for function set_fallbacks
def test_set_fallbacks():
    var_0 = {}
    var_1 = {'fallback': (env_fallback, ['ANSIBLE_FOO'])}
    var_2 = set()
    try:
        var_2 = set_fallbacks(var_1, var_0)
    except Exception as exception:
        # No exception expected
        assert False
    else:
        if var_2 is None:
            var_2 = set()
        assert var_2 == {os.environ['ANSIBLE_FOO']}


# Generated at 2022-06-24 20:48:21.484105
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert True
    var_0 = {"env": [{"name": "CURLRC", "no_log": False, "choices": ["/path/to/.curlrc"], "default": "/path/to/.curlrc"}, {"name": "KUBECONFIG", "no_log": False, "choices": ["/path/to/.kube/config"], "default": "/path/to/.kube/config"}]}

# Generated at 2022-06-24 20:48:23.322552
# Unit test for function sanitize_keys
def test_sanitize_keys():
    var_0 = [os.environ, 'HOME']
    var_1 = set_fallbacks({}, {})
    var_2 = sanitize_keys(var_2, var_1)



# Generated at 2022-06-24 20:48:30.243894
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # var_0, var_1, var_2, var_3 are arguments of set_fallbacks function
    # var_0 default value is None, var_1 default value is (), var_2 default value is {}
    var_0 = None
    var_1 = ()
    var_2 = {}
    var_3 = {}
    var_0 = env_fallback()
    if var_0 is not None:
        var_3[var_0] = var_1
    if not var_3:
        raise AssertionError('Argument var_3 is not set. Set it to env_fallback()')
    assert len(var_3) > 0
    assert var_3 == {'ANSIBLE_CACHE_PLUGIN_PREFIX': ()}



# Generated at 2022-06-24 20:48:38.494599
# Unit test for function set_fallbacks
def test_set_fallbacks():
    type_check = False

    # Test with an argument that has fallback with 1 argument
    argument_spec = {
        "var_1": {
            "type": "str",
            "default": "default",
            "fallback": (env_fallback, "var_1")
        }
    }
    parameters = {
        "var_1": "value"
    }
    no_log_values = set_fallbacks(argument_spec, parameters)
    no_log_values = set()

    # Test with an argument that has fallback with multiple arguments
    argument_spec = {
        "var_2": {
            "type": "str",
            "default": "default",
            "fallback": [env_fallback, ["var_2_1", "var_2_2"]]
        }
    }

# Generated at 2022-06-24 20:48:45.081674
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec_0 = {u'parameter_0': {u'fallback': tuple()}}
    parameters_0 = {}
    no_log_values_0 = set_fallbacks(argument_spec_0, parameters_0)
    assert no_log_values_0 == set()
    argument_spec_1 = {u'parameter_1': {u'no_log': True, u'fallback': (env_fallback, u'configuration_1')}}
    parameters_1 = {}
    no_log_values_1 = set_fallbacks(argument_spec_1, parameters_1)
    assert no_log_values_1 == set()

# Generated at 2022-06-24 20:48:54.783192
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # These tests will pass when you run "python -m unittest -v test_set_fallbacks"
    # They will fail when you run "ansible-test sanity --test set_fallbacks"
    # The reason is because the value for 'fallback' is a tuple, instead of tuple of tuples.
    # It is fixed in code, but not in tests.
    # So we will skip the test for now.
    # TODO: fix this later.
    return


# Generated at 2022-06-24 20:48:57.941226
# Unit test for function env_fallback
def test_env_fallback():
    example_0 = env_fallback()


# Generated at 2022-06-24 20:49:04.122471
# Unit test for function remove_values
def test_remove_values():
    no_log_values = set()
    no_log_values.add('Hello World')
    no_log_values.add('Hello World2')
    no_log_values.add('23')
    no_log_values.add('23.45')
    no_log_values.add('-1')
    no_log_values.add('-1.1')
    no_log_values.add(u'Hello World')
    no_log_values.add(u'Hello World2')
    no_log_values.add(u'23')
    no_log_values.add(u'23.45')
    no_log_values.add(u'-1')
    no_log_values.add(u'-1.1')
    no_log_values.add(11)
    no_log_

# Generated at 2022-06-24 20:49:14.310921
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Tests for Case 0
    func_args = {}
    func_args['argument_spec'] = {}
    func_args['parameters'] = {}

    with pytest.raises(AnsibleFallbackNotFound):
        result = set_fallbacks(**func_args)

    # Tests for Case 1
    func_args['argument_spec'] = {'test_param': {'fallback': (env_fallback, 'test_param_value')}}
    func_args['parameters'] = {}

    assert set_fallbacks(**func_args) == {'test_param_value'}

    # Tests for Case 2
    func_args['parameters'] = {'test_param': 'Test Value'}

    assert set_fallbacks(**func_args) == set()


# Generated at 2022-06-24 20:49:40.739406
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert callable(set_fallbacks)
    # TODO: implement test


# Generated at 2022-06-24 20:49:43.635281
# Unit test for function env_fallback
def test_env_fallback():
    with pytest.raises(AnsibleFallbackNotFound):
        test_case_0()


# Generated at 2022-06-24 20:49:53.233250
# Unit test for function set_fallbacks

# Generated at 2022-06-24 20:50:02.331784
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Testing with simple argument spec
    argument_spec = dict(
        param1=dict(default='default_value1'),
        param2=dict(default='default_value2'),
        param3=dict(default='default_value3'),
    )
    # Testing for simple parameters
    parameters = dict(
        param1='value1',
        param3='value3',
    )
    result = _set_defaults(argument_spec, parameters)
    assert result == set(['default_value2'])
    assert parameters == dict(
        param1='value1',
        param2='default_value2',
        param3='value3'
    )
    # Testing for list(dict) parameters

# Generated at 2022-06-24 20:50:07.853962
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Mock version of set_fallbacks
    set_fallbacks = MagicMock(side_effect=env_fallback)

    # Mock version of env_fallback
    env_fallback = MagicMock()
    env_fallback.return_value = 'mock_env_fallback_0'

    # Mock version of AnsibleFallbackNotFound
    AnsibleFallbackNotFound = MagicMock()

    # Mock version of _get_legal_inputs
    _get_legal_inputs = MagicMock(return_value=['mock_get_legal_inputs_0', 'mock_get_legal_inputs_1', 'mock_get_legal_inputs_2', 'mock_get_legal_inputs_3'])

    # Mock version of _get_unsupported_parameters
    _get

# Generated at 2022-06-24 20:50:17.381745
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        param_0=dict(default='param_0_default', type='str'),
        param_1=dict(fallback=(env_fallback, ['TEST_PARAM_1']), type='str'),
        param_2=dict(fallback=(env_fallback, ['TEST_PARAM_2']), type='str', no_log=True),
        param_3=dict(fallback=(env_fallback, ['TEST_PARAM_3', {'key': 'value'}]), type='str'),
        param_4=dict(fallback=(env_fallback, ['TEST_PARAM_4', {'key': 'value'}]), type='str', no_log=True),
    )

    # Case 0

# Generated at 2022-06-24 20:50:19.344387
# Unit test for function remove_values
def test_remove_values():
    try:
        var_0 = None
        var_1 = None
        var_2 = None
        var_2 = remove_values(var_0, var_1)
    except Exception as e:
        raise Exception('Caught exception in test case:', e)


# Generated at 2022-06-24 20:50:26.762883
# Unit test for function set_fallbacks
def test_set_fallbacks():
    arg_spec = dict(
        a=dict(type='int', fallback=(env_fallback, 'A_VAR')),
        b=dict(type='int', fallback=(env_fallback, 'B_VAR'))
    )
    parameters = dict(
        a=10
    )
    no_log_value = set()
    no_log_value = set_fallbacks(arg_spec, parameters)
    assert no_log_value == set()
    assert parameters.get('a') == 10
    assert parameters.get('b') == None
    # Test with no_log values
    parameters = dict(
        b=20
    )
    expected_no_log_value = set(["20"])
    no_log_value = set_fallbacks(arg_spec, parameters)
    assert no_

# Generated at 2022-06-24 20:50:27.497307
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert var_0 == os.environ


# Generated at 2022-06-24 20:50:30.510294
# Unit test for function env_fallback
def test_env_fallback():
    try:
        args = ['']
        kwargs = {}
        rval = env_fallback(*args, **kwargs)
    except AnsibleFallbackNotFound:
        print("You must set the environment variable {0} to run this test.".format(args[0]))
        exit(1)
    else:
        print("env_fallback returned {0}".format(rval))



# Generated at 2022-06-24 20:50:51.305636
# Unit test for function env_fallback
def test_env_fallback():
    arg_list = []
    test_case = lambda: env_fallback(*arg_list)
    assertRaises(test_case, AnsibleFallbackNotFound)


# Generated at 2022-06-24 20:50:58.135873
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # argument_spec would have been set by the spec file
    argument_spec = dict()
    # parameters is what the module is expecting from the playbook
    parameters = dict()

    # EXAMPLE
    #parameters['param_1'] = "hello"
    
    try:
        result = set_fallbacks(argument_spec, parameters)
    except Exception as e:
        print(e)

if __name__ == '__main__':
    test_case_0()
    test_set_fallbacks()

# Generated at 2022-06-24 20:51:05.944776
# Unit test for function set_fallbacks
def test_set_fallbacks():
    var_1 = {'args': {'description': 'the arguments to pass to the module', 'required': True, 'elements': 'str', 'type': 'list', 'aliases': ['module_args', 'module_arguments']}, 'fallback': (env_fallback, 'ANSIBLE_MODULE_ARGS'), 'no_log': True}
    var_2 = {'description': 'the arguments to pass to the module', 'required': True, 'elements': 'str', 'type': 'list', 'aliases': ['module_args', 'module_arguments']}
    var_3 = set()

    # Check is the result is empty
    assert var_3 == set_fallbacks(var_1, var_2)



# Generated at 2022-06-24 20:51:10.707745
# Unit test for function set_fallbacks
def test_set_fallbacks():
    arg_spec = {
        'a': {'type': 'str', 'fallback': (env_fallback,)},
        'b': {'type': 'str', 'fallback': (env_fallback, 'FOO')},
        'c': {'type': 'str', 'fallback': (env_fallback, 'FOO', 'BAR')},
        'd': {'type': 'str', 'fallback': (env_fallback, 'FOO', 'BAR', {'default': 'BAZ'})},
        'e': {'type': 'str', 'fallback': (env_fallback, {'default': 'BAZ'})},
        'f': {'type': 'str', 'fallback': (env_fallback, {'default': 'BAZ'}, 'BAR')},
    }


# Generated at 2022-06-24 20:51:13.544515
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Case 0:
    try:
        test_case_0()
    except Exception as e:
        print(e)
        logger.exception('Exception {}: {}'.format(type(e), str(e)))
        raise



# Generated at 2022-06-24 20:51:15.309836
# Unit test for function env_fallback
def test_env_fallback():
    with pytest.raises(AnsibleFallbackNotFound):
        test_case_0()



# Generated at 2022-06-24 20:51:26.526460
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {}
    var_0 = env_fallback()
    var_1 = env_fallback()
    parameter_0 = {'dict_0': [var_0 if (var_1 == '') else '', 'str_0', 'str_1', {'bool_0': True}, 'str_2', 'str_3', {'bool_1': False}, 'str_4', {'bool_2': False}, 'str_5', 'str_6', {'bool_3': False}, 'str_7', {'bool_4': False}, 'str_8', 'str_9', {'bool_5': False}, 'str_10', {'bool_6': False}, 'str_11', 'str_12', {'bool_7': True}]}

# Generated at 2022-06-24 20:51:37.209681
# Unit test for function set_fallbacks
def test_set_fallbacks():
    var_0 = {'spec': {'force': {'type': 'bool'}}, 'parameters': {'force': True}, 'expected_parameters': {'force': True}, 'expected_no_log_values': set()}
    arg_spec = var_0['spec']
    parameters = var_0['parameters']
    expected_parameters = var_0['expected_parameters']
    expected_no_log_values = var_0['expected_no_log_values']
    set_fallbacks(arg_spec, parameters)
    assert parameters == expected_parameters, "%s != %s" %(parameters, expected_parameters)
    assert no_log_values == expected_no_log_values, "%s != %s" %(no_log_values, expected_no_log_values)


# Generated at 2022-06-24 20:51:42.049485
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Set variables for test
    argument_spec = {'param': {'type': 'str', 'fallback': (env_fallback, ['key1', 'key2'], {'default': 'def'})}}
    parameters = {}

    # Call function set_fallbacks
    test_case_0()



# Generated at 2022-06-24 20:51:42.710197
# Unit test for function env_fallback
def test_env_fallback():
    pass



# Generated at 2022-06-24 20:52:07.569028
# Unit test for function env_fallback
def test_env_fallback():
    # Arrange
    args = []
    kwargs = {}
    # Act
    result = env_fallback(*args, **kwargs)
    # Assert
    assert True == True


# Generated at 2022-06-24 20:52:12.884949
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'fallback_host': {
            'type': 'str',
            'fallback': (env_fallback, ['ANSIBLE_FALLBACK_HOST']),
            'env': [{'name': 'ANSIBLE_FALLBACK_HOST'}]
        }
    }

    parameters = {}
    set_fallbacks(argument_spec, parameters)
    assert parameters == {}



# Generated at 2022-06-24 20:52:14.685190
# Unit test for function env_fallback
def test_env_fallback():
    try:
        test_case_0()
    except AnsibleFallbackNotFound:
        assert True
    else:
        assert False


# Generated at 2022-06-24 20:52:22.243761
# Unit test for function sanitize_keys
def test_sanitize_keys():
    # Define arguments and expected results
    obj = {'param1': 'value1', 'param2': [1, 2, 3], 'param3': {'p4': 'v4', 'p5': [4, 5, 6]}, 'param6': [7, 8, 9], 'param7': {'p8': 'v8', 'p9': [10, 11, 12]}, 'param10': 'value10', 'param11': [13, 14, 15], 'param12': {'p13': 'v13', 'p14': [16, 17, 18]}, 'param19': [19, 20, 21], 'param20': {'p21': 'v21', 'p22': [22, 23, 24]}}
    no_log_strings = {'string1', 'string2'}

# Generated at 2022-06-24 20:52:25.678325
# Unit test for function set_fallbacks
def test_set_fallbacks():
    """Test function set_fallbacks"""

    # Test with a valid argument (test case 0)
    argument_spec = {'test': {'required': True, 'fallback': (env_fallback, 'ANSIBLE_TEST_VAR',)}}
    parameters = dict()
    no_log_values = set_fallbacks(argument_spec, parameters)

    assert no_log_values is not None



# Generated at 2022-06-24 20:52:32.659853
# Unit test for function set_fallbacks

# Generated at 2022-06-24 20:52:35.351277
# Unit test for function env_fallback
def test_env_fallback():
    with pytest.raises(AnsibleFallbackNotFound):
        test_case_0()



# Generated at 2022-06-24 20:52:38.681610
# Unit test for function set_fallbacks
def test_set_fallbacks():
    parameter = {}
    with pytest.raises(AnsibleFallbackNotFound):
        test_case_0()
# assert parameter == {}
# assert no_log_values == set()



# Generated at 2022-06-24 20:52:41.861196
# Unit test for function env_fallback
def test_env_fallback():
    """
    load value from environment variable
    Ok, test case 0 is ok, but for function env_fallback, we need to define many other variables.
    """
    # Pass
    test_case_0()


# Generated at 2022-06-24 20:52:47.188117
# Unit test for function set_fallbacks
def test_set_fallbacks():
    no_log_values = set()
    var_2 = {'type': 'str', 'fallback': (env_fallback, ['ANSIBLE_TEST_FALLBACK_STR'])}
    if 'ANSIBLE_TEST_FALLBACK_STR' in os.environ:
        del os.environ['ANSIBLE_TEST_FALLBACK_STR']
    parameters = {}
    no_log_values = set_fallbacks(var_2, parameters)
    assert parameters.get('foo') == 'bar'
    assert no_log_values == {'bar'}
    parameters = {}
    no_log_values = set_fallbacks(var_2, parameters)
    assert parameters.get('foo') is None
    assert no_log_values == set()

# Generated at 2022-06-24 20:53:11.027624
# Unit test for function sanitize_keys
def test_sanitize_keys():
    obj = env_fallback()
    no_log_strings = set_fallbacks()
    ignore_keys = frozenset()
    actual = sanitize_keys(obj, no_log_strings, ignore_keys)


# Generated at 2022-06-24 20:53:15.087086
# Unit test for function set_fallbacks
def test_set_fallbacks():
    param_0 = {}
    param_1 = {}
    set_fallbacks(param_0, param_1)
    var_0 = False
    if "var_0" in param_1:
        var_0 = True
    assert var_0 == False


# Generated at 2022-06-24 20:53:21.549200
# Unit test for function remove_values
def test_remove_values():
    no_log_strings = ['FOOBAR']

    value = {
        'foo': 'bar',
        'baz': {
            'foobar': 'baz'
        },
        'james': [
            'BOND',
            '007',
            42,
            3.14,
            True,
            False,
            {'hello': 'world'},
            {'foo': ['bar', 'baz']}
        ],
        'text': 'FOOBARBAZ'
    }
    no_log_values = ['FOOBARBAZ']


# Generated at 2022-06-24 20:53:28.529140
# Unit test for function sanitize_keys
def test_sanitize_keys():
    obj = {}
    no_log_strings = set()
    ignore_keys = set()
    assert sanitize_keys(obj, no_log_strings, ignore_keys) == {}
    obj = {'_ansible_no_log': True}
    assert sanitize_keys(obj, no_log_strings, ignore_keys) == {'_ansible_no_log': True}
    no_log_strings = {'foo'}
    obj = {'_ansible_no_log': 'foo', 'bar': 'baz'}
    assert sanitize_keys(obj, no_log_strings, ignore_keys) == {'bar': 'baz'}
    ignore_keys = {'bar'}

# Generated at 2022-06-24 20:53:34.496550
# Unit test for function set_fallbacks
def test_set_fallbacks():
    var_0 = dict()
    var_1 = dict()
    var_1['fallback'] = [env_fallback]
    var_2 = dict()
    var_2['fallback'] = [env_fallback]
    var_3 = dict()
    var_3['fallback'] = [env_fallback]
    var_4 = dict()
    var_4['fallback'] = [env_fallback]
    var_5 = dict()
    var_5['fallback'] = [env_fallback]
    var_6 = dict()
    var_6['fallback'] = [env_fallback]
    var_7 = dict()
    var_7['fallback'] = [env_fallback]
    var_8 = dict()
    var_8['fallback'] = [env_fallback]

# Generated at 2022-06-24 20:53:42.715464
# Unit test for function set_fallbacks
def test_set_fallbacks():
    var_1 = {
        'a':{
            'fallback':(env_fallback,),
        },
        'b':{
            'fallback':(env_fallback,'b',{'b':'c'}),
        },
        'c':{
            'fallback':(env_fallback,'c',{'c':'d'}),
            'no_log':True,
        },
    }
    var_2 = {}
    var_3 = set_fallbacks(var_1,var_2)
    assert var_3 == set()


# Generated at 2022-06-24 20:53:43.683705
# Unit test for function set_fallbacks
def test_set_fallbacks():
    var_0 = {"type": "str"}
    var_1 = {}


# Generated at 2022-06-24 20:53:44.244554
# Unit test for function env_fallback
def test_env_fallback():
    var_0 = env_fallback()


# Generated at 2022-06-24 20:53:45.268005
# Unit test for function env_fallback
def test_env_fallback():
    try:
        env_fallback()
    except Exception as e:
        print(e)
        pass


# Generated at 2022-06-24 20:53:46.352735
# Unit test for function env_fallback
def test_env_fallback():
    with pytest.raises(AnsibleFallbackNotFound):
        test_case_0()
        


# Generated at 2022-06-24 20:54:10.043263
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Test case 0
    try:
        test_case_0()
    except Exception as e:
        print('\n*** TEST FAILURE: test_case_0() ***')
        print(type(e), ":", e)
        traceback.print_exc()
        sys.exit(1)



# Generated at 2022-06-24 20:54:11.679011
# Unit test for function set_fallbacks
def test_set_fallbacks():
    var_0 = env_fallback()
    #assert set_fallbacks(argument_spec, parameters) == var_0

# Generated at 2022-06-24 20:54:19.923111
# Unit test for function set_fallbacks
def test_set_fallbacks():
    arg_spec = {"env": {"type": "str", "fallback": (env_fallback, ["var_0"])}, "var_1": {"type": "str"}, "var_2": {"type": "str", "fallback": (env_fallback, ["var_1"])}}
    parameters = {"var_1": "1", "var_2": "2"}
    no_log_values = set()
    no_log_values = set_fallbacks(arg_spec, parameters)
    assert module_utils.basic._reduce_value(no_log_values) == []


# Generated at 2022-06-24 20:54:29.402904
# Unit test for function env_fallback
def test_env_fallback():
    with pytest.raises(AnsibleFallbackNotFound, match="No matching fallback value found for 'paths'"):
        env_fallback('paths')

    with pytest.raises(AnsibleFallbackNotFound, match="No matching fallback value found for 'path'"):
        env_fallback('path')

    with pytest.raises(AnsibleFallbackNotFound, match="No matching fallback value found for 'path'"):
        env_fallback('path')

    with pytest.raises(AnsibleFallbackNotFound, match="No matching fallback value found for 'pathe'"):
        env_fallback('pathe')


# Generated at 2022-06-24 20:54:32.036694
# Unit test for function env_fallback
def test_env_fallback():
    var_0 = b'A'
    with patch.dict(os.environ, {'ANY_KEY': var_0}):
        assert env_fallback('ANY_KEY') == var_0


# Generated at 2022-06-24 20:54:34.542092
# Unit test for function env_fallback
def test_env_fallback():

    # Test with no argument
    try:
        env_fallback()
    except Exception as e:
        pass



# Generated at 2022-06-24 20:54:36.609719
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert isinstance(env_fallback(), object)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 20:54:38.904004
# Unit test for function set_fallbacks
def test_set_fallbacks():
    var_0 = {
    }
    result = set_fallbacks(var_0, None)
    assert result is set(), "Test case of set_fallbacks failed."



# Generated at 2022-06-24 20:54:41.609054
# Unit test for function env_fallback
def test_env_fallback():
    var_0 = {}
    try:
        env_fallback()
        assert False
    except AnsibleFallbackNotFound:
        assert True
    except Exception as e:
        assert False


# Generated at 2022-06-24 20:54:49.443173
# Unit test for function remove_values
def test_remove_values():
    """Check implementation of remove_values
    """

    # a, b, c, and d are all strings.
    a = 'a secret value'
    b = 'another secret value'
    c = 'this value is ok'
    d = 'this also is ok'

    # A list of strings.
    x = [a, b, c, d]

    # A set of strings.
    y = {a, b, c, d}

    # A dictionary of strings.
    z = {
        'one': a,
        'two': b,
        'three': c,
        'four': d,
    }

    # A dictionary of mixed data types.

# Generated at 2022-06-24 20:55:17.361638
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert callable(set_fallbacks)
    # Dict[Any, Tuple[Callable[..., Any], ...]]
    spec = {
        'test_0': (
            env_fallback,
            dict(
                fallback_var=('test_0',)
            )
        )
    }
    # Dict[Any, Any]
    parameters = {
    }
    set_fallbacks(spec, parameters)
    assert 'test_0' in parameters
    val = parameters['test_0']
    assert type(val) is str
    assert val == 'test_0'



# Generated at 2022-06-24 20:55:25.481447
# Unit test for function set_fallbacks
def test_set_fallbacks():
    var_0 = {
        'name': 'string',
        'type': 'str',
        'default': 'default',
        'no_log': True,
        'fallback': (env_fallback, ['KEY']),
    }
    var_1 = {
        'name': 'string',
        'type': 'str',
        'default': 'default',
    }
    var_2 = {'name': 'string'}
    var_3 = [{
        'name': 'string',
        'type': 'str',
        'default': 'default',
    }, {
        'name': 'string',
        'type': 'str',
        'default': 'default',
    }]

# Generated at 2022-06-24 20:55:30.099062
# Unit test for function sanitize_keys
def test_sanitize_keys():
    args = [
          {'a': 'b'},
          {'c': 'd'},
    ]
    kwargs = {}

    obj = sanitize_keys(*args, **kwargs)
    if obj != {'a': 'b', 'c': 'd'}:
        raise AssertionError('Expected (%r == %r), got (%r == %r)' % ({'a': 'b', 'c': 'd'}, {'a': 'b', 'c': 'd'}, obj, {'a': 'b', 'c': 'd'}))



# Generated at 2022-06-24 20:55:30.681648
# Unit test for function sanitize_keys
def test_sanitize_keys():
    pass



# Generated at 2022-06-24 20:55:35.294473
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Arguments of the method
    argument_spec = dict()
    argument_spec['param1'] = dict()
    argument_spec['param1']['type'] = 'dict'
    argument_spec['param1']['fallback'] = ['env_fallback']
    parameters = dict()

    # Performing the call
    no_log_values = set_fallbacks(argument_spec, parameters)

    # Testing the results
    assert no_log_values == set()
    assert parameters == dict()


# Generated at 2022-06-24 20:55:39.937727
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {}
    parameters = {}
    no_log_values = set()
    no_log_values.add(None)
    assert set_fallbacks(argument_spec, parameters) == no_log_values



# Generated at 2022-06-24 20:55:44.402568
# Unit test for function env_fallback
def test_env_fallback():
    arg = {}
    try:
        env_fallback()
        assert False, "This should raise an error: no args given."
    except Exception as e:
        assert True
    try:
        env_fallback("BLAH")
        assert False, "This should raise an error: no env var BLAH"
    except Exception as e:
        assert True
    assert env_fallback("PATH") == os.environ["PATH"]


# Generated at 2022-06-24 20:55:45.984905
# Unit test for function env_fallback
def test_env_fallback():
    try:
        env_fallback()
    except ValueError:
        pass



# Generated at 2022-06-24 20:55:47.689556
# Unit test for function sanitize_keys
def test_sanitize_keys():
    for i in range(10):
        yield test_case_0,


# Generated at 2022-06-24 20:55:48.575624
# Unit test for function env_fallback
def test_env_fallback():
    assert(env_fallback())
