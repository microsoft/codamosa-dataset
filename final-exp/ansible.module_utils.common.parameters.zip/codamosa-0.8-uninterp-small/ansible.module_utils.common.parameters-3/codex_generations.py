

# Generated at 2022-06-24 20:47:28.354648
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'example': {
            'type': 'str',
            'required': True,
            'fallback': (env_fallback, ['fallback_test'])
        }
    }
    parameters = {}
    set_fallbacks(argument_spec, parameters)
    if 'example' not in parameters:
        raise AssertionError('argument example should be set to fallback but is not')


# Generated at 2022-06-24 20:47:29.023983
# Unit test for function env_fallback
def test_env_fallback():
    test_case_0()

# Generated at 2022-06-24 20:47:37.579897
# Unit test for function set_fallbacks

# Generated at 2022-06-24 20:47:47.607769
# Unit test for function sanitize_keys

# Generated at 2022-06-24 20:47:54.328359
# Unit test for function set_fallbacks
def test_set_fallbacks():
    a_module = 'module_name'
    argument_spec = {'username': {'type': 'str', 'fallback': (env_fallback, 'USERNAME')},
                     'password': {'type': 'str', 'fallback': (env_fallback, 'PASSWORD')},
                     'timeout': {'type': 'int', 'fallback': (get_fallback, 'timeout', 120)},
                     'no_log_values': {'type': 'int', 'fallback': (env_fallback, 'NUMBER'), 'no_log': True}}

    parameters = {'username': 'test', 'password': 'test'}
    no_log_values, parameters = set_fallbacks(argument_spec, parameters, a_module)

    print("PASSED:Test for set_fallbacks")


# Generated at 2022-06-24 20:48:00.373353
# Unit test for function env_fallback
def test_env_fallback():
    from ansible.module_utils import basic

    # Mock the AnsibleModule
    module_mock = basic.AnsibleModule(argument_spec={})

    # Mock the AnsibleModule object
    class AnsibleModuleMock(object):

        # Mock the method
        def __init__(self, argument_spec):
            self.argument_spec = argument_spec
            self.params = {}

    # Instantiate a class using the mock
    module = AnsibleModuleMock(argument_spec={})

    # Mock the actual AnsibleModule class

# Generated at 2022-06-24 20:48:09.048600
# Unit test for function set_fallbacks
def test_set_fallbacks():
    var_0 = env_fallback()
    var_1 = set_fallbacks(argument_spec={'fallback': var_0}, parameters={})
    var_2 = env_fallback()
    var_3 = set_fallbacks(argument_spec={'fallback': var_2}, parameters={})
    var_4 = set_fallbacks(argument_spec={'fallback': var_2}, parameters={})
    var_5 = set_fallbacks(argument_spec={'fallback': var_0}, parameters={})
    var_6 = env_fallback()
    var_7 = set_fallbacks(argument_spec={'fallback': var_6}, parameters={})


# Generated at 2022-06-24 20:48:13.237830
# Unit test for function set_fallbacks
def test_set_fallbacks():
    '''
    Ensure that set_fallbacks works in all cases.
    '''
    # Setup
    argument_spec = {}
    parameters = {}
    no_log_values = set()

    # Test
    assert set_fallbacks(argument_spec, parameters) == no_log_values



# Generated at 2022-06-24 20:48:14.749948
# Unit test for function env_fallback
def test_env_fallback():
    var_0 = env_fallback()


# Generated at 2022-06-24 20:48:18.479568
# Unit test for function env_fallback
def test_env_fallback():
    var_0 = os.environ['USER']
    var_1 = os.getenv('USER')
    if os.environ['USER'] is not None:
        var_0 = os.environ['USER']

    else:
        var_0 = os.getenv('USER')

    assert var_0 == var_1


# Generated at 2022-06-24 20:48:44.607988
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert type(set_fallbacks(var_0)) == dict


# Generated at 2022-06-24 20:48:51.152654
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec_0 = {'type': {'type': 'str', 'required': True, 'choices': ['str', 'int']}, 'name': {'type': 'str', 'required': True}}
    parameters_0 = {'test_str': 'str_value'}
    no_log_values_0 = set()

    try:
        set_fallbacks(argument_spec_0, parameters_0)
    except Exception as e:
        print(e)
    else:
        print('No exception occurred')

    print(no_log_values_0)


# Generated at 2022-06-24 20:48:55.838768
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # If this test causes problems try uncommenting the ANSIBLE_KEEP_REMOTE_FILES environment variable below
    # os.environ['ANSIBLE_KEEP_REMOTE_FILES'] = '1'
    try:
        test_case_0()
    finally:
        try:
            del os.environ['ANSIBLE_KEEP_REMOTE_FILES']
        except KeyError:
            pass


# Generated at 2022-06-24 20:49:02.292371
# Unit test for function remove_values

# Generated at 2022-06-24 20:49:12.417693
# Unit test for function set_fallbacks

# Generated at 2022-06-24 20:49:20.164871
# Unit test for function set_fallbacks

# Generated at 2022-06-24 20:49:31.395994
# Unit test for function set_fallbacks
def test_set_fallbacks():
    var_0 = "foo"
    var_1 = {'fallback': ['bar']}
    var_2 = {'fallback': ['bar'], 'type': 'str'}
    var_3 = {'fallback': [env_fallback], 'type': 'str'}
    var_4 = {'fallback': [env_fallback, 'bar'], 'type': 'str'}
    var_5 = {'fallback': [env_fallback, {'bar': 'foo'}], 'type': 'str'}
    var_6 = {'fallback': [env_fallback, {'bar': 'foo'}, 'baz']}
    var_7 = {'fallback': [env_fallback, [1, 2]], 'type': 'str'}

# Generated at 2022-06-24 20:49:39.095503
# Unit test for function remove_values
def test_remove_values():
    assert remove_values(var_0, no_log_strings=[])
    assert "---" in remove_values(var_1, no_log_strings=[])
    assert remove_values(var_2, no_log_strings=[])
    assert remove_values(var_3, no_log_strings=[])
    assert "*" in remove_values(var_4, no_log_strings=[])
    assert remove_values(var_5, no_log_strings=[])
    assert remove_values(var_6, no_log_strings=[])
    assert remove_values(var_7, no_log_strings=[])
    assert "*" in remove_values(var_8, no_log_strings=[])
    assert "file" in remove_values(var_9, no_log_strings=[])

# Generated at 2022-06-24 20:49:43.928006
# Unit test for function set_fallbacks
def test_set_fallbacks():
    spec = dict(
        bool_opt = dict(type='bool', fallback=(env_fallback, 'ANSIBLE_FOO_BOOL')),
    )
    parameters = dict()

    os.environ['ANSIBLE_FOO_BOOL'] = 'true'

    test_set_fallbacks1(spec, parameters)


#
#    Validate that fallbacks are being set correctly.
#

# Generated at 2022-06-24 20:49:53.565181
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # test for example spec
    example_spec = {
        'apikey': {'required': True, 'type': 'str'},
        'resource': {'required': True, 'type': 'str'},
    }

    # test for example parameters
    example_parameters = {
        'resource': 'hello'
    }

    # test for default parameters
    test_set_fallbacks_default = set()

    # test for example no_log values
    test_set_fallbacks_no_log_values = set()

    # test for example no_log_values
    test_set_fallbacks_no_log_values = set()

    # test for example unsupported parameter
    test_set_fallbacks_unsupported_parameter = set()

    # test for example errors
    test_set_fallbacks_errors = Ans

# Generated at 2022-06-24 20:50:25.500777
# Unit test for function set_fallbacks
def test_set_fallbacks():
    var_0 = {}
    var_1 = {}
    var_1['fallback'] = (env_fallback, "ANSIBLE_ANSIBLE_MODULE_ARGS")
    var_2 = {"arg1": var_1}
    var_3 = ()
    var_4 = set_fallbacks(var_2, var_0)
    assert var_4 == var_3, "Expected {}, Got {}".format(var_3, var_4)


# Generated at 2022-06-24 20:50:35.647085
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # test for no error
    argument_spec = {'test': {}}
    parameters = {}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert len(no_log_values) == 0

    # test for no error
    argument_spec = {'test': {'no_log': False}}
    parameters = {}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert len(no_log_values) == 0

    # test for no error
    argument_spec = {'test': {'no_log': True}}
    parameters = {}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert len(no_log_values) == 0

    # test for no error

# Generated at 2022-06-24 20:50:37.404728
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback() in [None, 'fallback is missing']


# Generated at 2022-06-24 20:50:43.772807
# Unit test for function set_fallbacks
def test_set_fallbacks():
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.common._text import to_native
    a = dict(a=1, b=2, c=3)
    b = dict(a=1, b=2, c=3)
    argument_spec = {'a': {'fallback': (env_fallback, ['booya'])}, 'B': {'fallback': (env_fallback, ['booya'])}}

    try:
        set_fallbacks(argument_spec, a)
    except:
        assert False, to_native(traceback.format_exc())
    assert a == b


# Generated at 2022-06-24 20:50:51.006136
# Unit test for function set_fallbacks
def test_set_fallbacks():
    print ('in main function:')
    argument_spec = {'debug': {'type': 'bool', 'fallback': (env_fallback, ['DEBUG'])}}
    parameters = {}
    position_0 = set_fallbacks(argument_spec, parameters)
    print ('position_0: {0}'.format(position_0))
    assert position_0 == set(['true', 'false', '1', '0'])
    print('unit test for function set_fallbacks succeed')


# Generated at 2022-06-24 20:50:54.113350
# Unit test for function env_fallback
def test_env_fallback():
    assert isinstance(test_case_0(), str)


# Generated at 2022-06-24 20:51:02.642438
# Unit test for function set_fallbacks

# Generated at 2022-06-24 20:51:06.399179
# Unit test for function env_fallback
def test_env_fallback():
    arg_0 = ()
    try:
        var_0 = env_fallback(*arg_0)
    except AnsibleFallbackNotFound:
        pass
    except Exception as e:
        print("An exception occurred in the test")
        print(e)



# Generated at 2022-06-24 20:51:09.240943
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {}
    parameters = {}
    set_fallbacks(argument_spec, parameters)



# Generated at 2022-06-24 20:51:15.309112
# Unit test for function sanitize_keys
def test_sanitize_keys():
    class TestArgs():
        def __init__(self, no_log_strings, ignore_keys):
            self.no_log_strings = no_log_strings
            self.ignore_keys = ignore_keys
    
    test_obj = test_case_0()
    test_args = TestArgs(no_log_strings=test_obj, ignore_keys=test_obj)
    sanitize_keys(test_obj, test_args.no_log_strings, ignore_keys=test_args.ignore_keys)


# Generated at 2022-06-24 20:51:38.994989
# Unit test for function env_fallback
def test_env_fallback():
    var_0 = env_fallback()
    assert var_0 == None


# Generated at 2022-06-24 20:51:45.062237
# Unit test for function remove_values
def test_remove_values():
    print("test_remove_values")
    var_0 = [1,2,3,4,5,6,7]
    var_1 = ['test','test','test',var_0]
    var_2 = {'test':'test', 'test':'test', 'test2':'test2', 'test2':'test2', 'test3':'test3', 'test3':'test3', 'test4':'test4', 'test4':'test4'}
    var_3 = {'test':'test', 'test':'test', 'test2':var_2, 'test2':var_2, 'test3':'test3', 'test3':'test3', 'test4':'test4', 'test4':'test4'}

# Generated at 2022-06-24 20:51:54.824696
# Unit test for function remove_values

# Generated at 2022-06-24 20:52:04.164911
# Unit test for function remove_values
def test_remove_values():
    assert remove_values(test_case_0, []) == {}


# Generated at 2022-06-24 20:52:13.720453
# Unit test for function set_fallbacks

# Generated at 2022-06-24 20:52:22.803418
# Unit test for function set_fallbacks

# Generated at 2022-06-24 20:52:25.512094
# Unit test for function env_fallback
def test_env_fallback():
    import os
    from ansible.module_utils.six.moves import builtins

    with patch.object(os.environ, 'get', return_value='2'):
        assert env_fallback('ANSIBLE_TEST') == '2'

    with patch.object(os.environ, 'get', side_effect=KeyError):
        with pytest.raises(AnsibleFallbackNotFound):
            env_fallback('ANSIBLE_TEST')


# Generated at 2022-06-24 20:52:32.002025
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # No parameters - ensure no exception is raised
    assert set_fallbacks({}, {}) is None
    # No parameter with a fallback defined - ensure no exception is raised
    assert set_fallbacks({'param': {'type': 'bool'}}, {}) is None
    # Parameter with a fallback defined to return value FOO - ensure that the parameter is added to the dictionary
    assert set_fallbacks({'param': {'type': 'bool', 'fallback': env_fallback}}, {}) == set(['FOO'])
    # Ensure that fallback is set to default value if fallback function return value is None
    assert set_fallbacks({'param': {'type': 'bool', 'default': False}}, {}) == set([])

# Generated at 2022-06-24 20:52:43.634567
# Unit test for function set_fallbacks

# Generated at 2022-06-24 20:52:54.599037
# Unit test for function set_fallbacks
def test_set_fallbacks():
    """test_set_fallbacks"""
    with mock.patch('ansible.module_utils.basic.env_fallback', return_value=''):
        assert set_fallbacks(test_case_0) == ''
    with mock.patch('ansible.module_utils.basic.env_fallback', return_value=''):
        assert set_fallbacks(test_case_0) == ''
    with mock.patch('ansible.module_utils.basic.env_fallback', return_value=''):
        assert set_fallbacks(test_case_0) == ''
    with mock.patch('ansible.module_utils.basic.env_fallback', return_value=''):
        assert set_fallbacks(test_case_0) == ''

# Generated at 2022-06-24 20:53:22.063036
# Unit test for function set_fallbacks
def test_set_fallbacks():
    var_1 = []
    var_2 = env_fallback()
    var_3 = []
    var_4 = "value"
    var_5 = "string"
    var_6 = env_fallback()
    var_7 = "value"
    var_8 = "string"
    var_9 = env_fallback()
    var_0 = []
    var_10 = env_fallback()
    var_11 = []
    var_12 = "value"
    var_13 = "string"
    var_14 = env_fallback()
    var_15 = "value"
    var_16 = "string"
    var_17 = env_fallback()
    var_18 = []
    var_19 = env_fallback()
    var_20 = []
    var_21 = "value"

# Generated at 2022-06-24 20:53:26.460171
# Unit test for function set_fallbacks
def test_set_fallbacks():
    var_1 = {'param1': 
                    {
                    'type': 'bool', 
                    'default': True, 
                    'no_log': False, 
                    'choices': [True, False], 
                    'fallback': (env_fallback, 'param3')
                    }
            }
    var_2 = {}
    var_3 = set_fallbacks(var_1, var_2)
    if var_3 is not None:
        assert False



# Generated at 2022-06-24 20:53:29.429282
# Unit test for function sanitize_keys
def test_sanitize_keys():
    var_0 = env_fallback()
    assert (sanitize_keys('test')) == 'test'
    assert (sanitize_keys(sanitize_keys('test', no_log_strings=set(), ignore_keys=set()), no_log_strings=set(), ignore_keys=set())) == 'test'


# Generated at 2022-06-24 20:53:33.662265
# Unit test for function set_fallbacks
def test_set_fallbacks():
    var_0 = dict()
    var_1 = dict()
    var_1 = dict(type = dict(fallback = (env_fallback,)))
    var_0 = dict(a = var_1)
    set_fallbacks(var_0, {})


# Generated at 2022-06-24 20:53:37.001023
# Unit test for function env_fallback
def test_env_fallback():
    """Test function env_fallback and validate its outputs."""

    # this is the inline testcase and it must be exactly named test_<function name>
    # see https://docs.python-guide.org/writing/tests/
    try:
        var_0 = env_fallback()
    except:
        var_0 = None
    assert var_0 == None, "test_env_fallback returned wrong value for var_0"



# Generated at 2022-06-24 20:53:41.278668
# Unit test for function set_fallbacks
def test_set_fallbacks():
    print("start test function test_set_fallbacks")
    # Test if the function raised expected exceptions
    var_0 = env_fallback()
    print("test_set_fallbacks:var_0 ", var_0)
    print("finish test function test_set_fallbacks")


# Generated at 2022-06-24 20:53:50.453297
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        "server": {
            "type": "str",
            "required": True,
            "description": "Server IP/Hostname to connect to",
            "fallback": (env_fallback, ['ANSIBLE_NET_SERVER'], {})
        },
        "password": {
            "type": "str",
            "required": True,
            "description": "Password for authentication",
            "aliases": ['pass', 'pwd'],
            "fallback": (env_fallback, ['ANSIBLE_NET_PASSWORD'], {})
        }
    }
    parameters = {
        "password": "secret"
    }
    options_context = []
    errors = []
    # Set prefix for warning messages
    prefix = ""


# Generated at 2022-06-24 20:53:56.264991
# Unit test for function set_fallbacks
def test_set_fallbacks():
    spec = dict(
        dict_0=dict(
            required=True,
            fallback=(env_fallback, "MYVAR")
        ),
        dict_1=dict(
            required=True,
            fallback=(env_fallback, "MYVAR1", "MYVAR2", {'foo': 'bar'})
        )
    )

    parameters = dict()
    no_log_values = set_fallbacks(spec, parameters)

    assert no_log_values == set()
    assert parameters == dict(
        dict_0=None
    )



# Generated at 2022-06-24 20:54:01.479324
# Unit test for function set_fallbacks
def test_set_fallbacks():
    curr_dir = os.path.dirname(os.path.realpath(__file__))
    os.chdir(curr_dir)
    # args = (arg1, arg2, arg3)
    # arg1 = argument_spec = {'param': {'type': 'dict', 'default': '{}', 'options': {'a': {'type': 'str'}}}}
    # arg2 = parameters = {}
    test_case_0()


# Generated at 2022-06-24 20:54:07.333111
# Unit test for function env_fallback
def test_env_fallback():
    try:
        var_0 = env_fallback()
        print("test_env_fallback passed.")
    except AssertionError as e:
        print("test_env_fallback failed: " + to_native(e))



# Generated at 2022-06-24 20:54:30.771209
# Unit test for function env_fallback
def test_env_fallback():
    try:
        test_case_0()
    except AnsibleFallbackNotFound:
        pass

# Generated at 2022-06-24 20:54:40.237981
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {}
    argument_spec['one'] = {'fallback': (env_fallback, 'ALWAYS_FALLBACK')}
    argument_spec['two'] = {'fallback': (env_fallback, 'ALWAYS_FALLBACK', {'fallback_name': 'SECOND_FALLBACK'})}
    argument_spec['three'] = {'fallback': (env_fallback, ['ALWAYS_FALLBACK', 'SECOND_FALLBACK'])}
    argument_spec['four'] = {'fallback': (env_fallback, 'ALWAYS_FALLBACK', ['OTHER_FALLBACK'])}

# Generated at 2022-06-24 20:54:48.263379
# Unit test for function remove_values

# Generated at 2022-06-24 20:54:55.698420
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'var_0': {
            'fallback': (env_fallback, )
        }
    }
    parameters = {'a': 'b'}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters == {'a': 'b', 'var_0': None}
    assert no_log_values == set()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 20:55:06.389593
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict()
    argument_spec['bool_type'] = dict(type='bool', fallback=(env_fallback, ['BOOL_TYPE']))
    argument_spec['bool_type_true'] = dict(type='bool', fallback=(env_fallback, ['BOOL_TYPE_TRUE']))
    argument_spec['bool_type_false'] = dict(type='bool', fallback=(env_fallback, ['BOOL_TYPE_FALSE']))
    argument_spec['int_type'] = dict(type='int', fallback=(env_fallback, ['INT_TYPE']))
    argument_spec['float_type'] = dict(type='float', fallback=(env_fallback, ['FLOAT_TYPE']))

# Generated at 2022-06-24 20:55:09.404835
# Unit test for function remove_values
def test_remove_values():
    assert remove_values(var_0, 'string_0') == remove_values(var_0, 'string_0')
    assert remove_values(var_0, 'string_1') == remove_values(var_0, 'string_1')
    assert remove_values(var_0, 'string_2') == remove_values(var_0, 'string_2')


# Generated at 2022-06-24 20:55:13.332379
# Unit test for function env_fallback
def test_env_fallback():
    var_0 = env_fallback('(?i)iTx86')
    assert var_0 is not None
    assert var_0 is not False
    assert var_0 is not True
    assert var_0 == 'wWyM'


# Generated at 2022-06-24 20:55:19.921558
# Unit test for function sanitize_keys
def test_sanitize_keys():
    # Use fixture to generate test cases
    test_cases = test_gen_normal_case()
    
    # Test
    for test_case in test_cases:
        obj = test_case[0]
        no_log_strings = test_case[1]
        ignore_keys = test_case[2]
        expected_return = test_case[3]
        ret = sanitize_keys(obj, no_log_strings, ignore_keys)
        assert ret == expected_return, "Expected:\n    %s\nGot:\n    %s" % (expected_return, ret)



# Generated at 2022-06-24 20:55:25.301369
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'a': {'type': 'int', 'fallback': (env_fallback, ['a'])}, 'b': {'type': 'int', 'fallback': (env_fallback, ['b'])}}
    parameters = {}
    no_log_values = set()
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters == {}
    assert no_log_values == set()


# Generated at 2022-06-24 20:55:26.318515
# Unit test for function env_fallback
def test_env_fallback():
    assert var_0 == None


# Generated at 2022-06-24 20:55:54.287198
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        "param1": {
            "type": "str",
            "fallback": (env_fallback, "TEST")
            }
        }
    parameters = {}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert no_log_values == set()
    assert parameters["param1"] == "TEST"

