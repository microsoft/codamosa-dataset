

# Generated at 2022-06-24 20:47:07.586258
# Unit test for function set_fallbacks
def test_set_fallbacks():
    arg_spec = {
        'target_type': {
            'type': 'str',
            'required': False,
            'default': '__target_type_env',
            'choices': ['__target_type_env', '__target_type_1', '__target_type_2'],
            'fallback': (env_fallback, [env_fallback], {})
        }
    }

    param_values = { 'target_type': '__target_type_1' }

    set_fallbacks(arg_spec, param_values)

    assert 'target_type' in param_values
    assert param_values['target_type'] == '__target_type_1'



# Generated at 2022-06-24 20:47:11.731785
# Unit test for function remove_values
def test_remove_values():
    list_2 = []
    var_1 = remove_values(list_2, *list_2)
    assert var_1 == list_2

    list_3 = ['1', '2', '3']
    var_2 = remove_values(list_3, *list_3)
    assert var_2 == list_3

    list_4 = ['1', ['1', '2', '3'], '2']
    var_3 = remove_values(list_4, *list_4)
    assert var_3 == list_4

    list_5 = ['3', '2', '1']
    var_4 = remove_values(list_5, *list_5)
    assert var_4 == list_5


# Generated at 2022-06-24 20:47:16.269643
# Unit test for function set_fallbacks
def test_set_fallbacks():
    f_module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )

    result = set_fallbacks({}, {'test': 'Test'})
    f_module.fail_json(msg="Expected result to be [], but got {}".format(result))


# Generated at 2022-06-24 20:47:25.270757
# Unit test for function set_fallbacks

# Generated at 2022-06-24 20:47:34.050405
# Unit test for function env_fallback
def test_env_fallback():
    try:
        # Try to find fallback in an empty list
        test_case_0()
    except AnsibleFallbackNotFound:
        pass
# Python 2 version compat
if PY2:
    # PyYAML has a bug where literal scalars in strings are not
    # preserved if they have leading whitespace, so we need to
    # add our own loader.
    # https://github.com/yaml/pyyaml/issues/110

    class LiteralLoader(Loader):
        def construct_yaml_str(self, node):
            return self.construct_scalar(node)

    LiteralLoader.add_constructor('tag:yaml.org,2002:str',
                                  LiteralLoader.construct_yaml_str)


# Generated at 2022-06-24 20:47:36.995529
# Unit test for function env_fallback
def test_env_fallback():
    with pytest.raises(AnsibleFallbackNotFound):
        test_case_0()

# Generated at 2022-06-24 20:47:41.329513
# Unit test for function set_fallbacks
def test_set_fallbacks():
    values = [{'fallback': [env_fallback, 'HELLO']}]
    with patch('ansible.module_utils.local.env_fallback', side_effect=test_case_0):
        result = set_fallbacks(values, {})
    assert result == set()


# Generated at 2022-06-24 20:47:49.089603
# Unit test for function set_fallbacks
def test_set_fallbacks():
    wanted_type = type('str')
    param = 'test_param'

    # Setup an argument spec
    argument_spec = {param: {'type': wanted_type, 'no_log': True, 'fallback': [env_fallback, ['test_value']]}}

    # Set environment variable so we don't get the fallback error
    os.environ['test_value'] = 'string'

    parameters = {}

    no_log_values = set_fallbacks(argument_spec, parameters)

    if parameters[param] != 'string':
        raise AssertionError("Expected '%s' to get set to 'string', got: '%s'" % (param, parameters[param]))


# Generated at 2022-06-24 20:47:54.697761
# Unit test for function set_fallbacks
def test_set_fallbacks():
    spec = {'OAUTH_PROVIDER': dict(type='str', required=True, fallback=(env_fallback, ['OAUTH_PROVIDER'])),
            'OAUTH_USERNAME': dict(type='str', required=True, fallback=(env_fallback, ['OAUTH_USERNAME'])),
            'OAUTH_PASSWORD': dict(type='str', required=True, fallback=(env_fallback, ['OAUTH_PASSWORD'])),
            'OAUTH_CLIENT_SECRET': dict(type='str', required=True, fallback=(env_fallback, ['OAUTH_CLIENT_SECRET'])),
            'OAUTH_CLIENT_ID': dict(type='str', required=True, fallback=(env_fallback, ['OAUTH_CLIENT_ID']))}

    parameters = {}

# Generated at 2022-06-24 20:48:00.713440
# Unit test for function set_fallbacks
def test_set_fallbacks():
    option_spec = {"foo": {"fallback": [env_fallback, "FOO"], "type": "str"}}
    parameters = {}
    no_log_values = set_fallbacks(option_spec, parameters)
    assert len(no_log_values) == 0
    assert len(parameters) == 0

    option_spec = {"foo": {"fallback": [env_fallback, "FOO"], "type": "str"}}
    parameters = {"foo": "bar"}
    no_log_values = set_fallbacks(option_spec, parameters)
    assert len(no_log_values) == 0
    assert "foo" in parameters and parameters["foo"] == "bar"


# Generated at 2022-06-24 20:49:19.780696
# Unit test for function sanitize_keys

# Generated at 2022-06-24 20:49:23.213486
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'b':{'default':None}}
    parameters    = {'a':1}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert(no_log_values == set([None]))


# Generated at 2022-06-24 20:49:29.909477
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        "var_0": {"type": "str", "fallback": (env_fallback, "AAA")}
    }
    parameters = {}
    no_log_values = {}
    _set_fallbacks(argument_spec, parameters, no_log_values)
    assert_equals(parameters, {"var_0": "AAA"})
    assert_equals(no_log_values, set())



# Generated at 2022-06-24 20:49:38.851910
# Unit test for function remove_values
def test_remove_values():
    # ----
    var_1 = env_fallback()
    assert remove_values(var_1, [u'pw']) == var_1
    # ----
    var_1 = env_fallback()
    assert remove_values(var_1, [u'pw']) == var_1
    # ----
    var_1 = env_fallback()
    assert remove_values(var_1, [u'pw']) == var_1
    # ----
    var_1 = env_fallback()
    assert remove_values(var_1, [u'pw']) == var_1
    # ----
    var_1 = env_fallback()
    assert remove_values(var_1, [u'pw']) == var_1


# Generated at 2022-06-24 20:49:43.636087
# Unit test for function sanitize_keys
def test_sanitize_keys():
    ignore_keys = frozenset()
    var_0 = 'wsman_password'
    obj = {var_0: 'abc'}
    no_log_strings = ['abc']
    new_value = _sanitize_keys_conditions(obj, no_log_strings, ignore_keys, deferred_removals)
    print(new_value)


# Generated at 2022-06-24 20:49:53.279125
# Unit test for function set_fallbacks
def test_set_fallbacks():
    host_data = {
        'param1': None,
        'param2': None,
        'param3': None,
        'param5': None,
        'param6': None,
    }

    module_arg_spec = {
        'param1': {'type': 'str', 'no_log': True},
        'param2': {'type': 'str', 'no_log': True},
        'param3': {'type': 'str', 'no_log': False},
        'param4': {'type': 'str', 'no_log': False},
        'param5': {'type': 'str', 'no_log': True},
        'param6': {'type': 'str', 'no_log': True},
    }

    no_log_values = set()


# Generated at 2022-06-24 20:49:54.773151
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert set_fallbacks(1,1) == set()



# Generated at 2022-06-24 20:50:03.485748
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'arg1': {
            'type': 'str',
            'fallback': (env_fallback, 'T1'),
            'no_log': True
        },
        'arg2': {
            'type': 'str',
            'fallback': (env_fallback, 'T2', {'true_arg': True}),
            'no_log': True
        },
        'arg3': {
            'type': 'str',
            'fallback': (env_fallback, ('T3', 'T4'), {'true_arg': True}),
            'no_log': True
        },
        'arg4': {
            'type': 'str',
            'no_log': True
        }
    }

# Generated at 2022-06-24 20:50:07.616966
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert set_fallbacks(test_case_0) == set_fallbacks()



# Generated at 2022-06-24 20:50:08.664251
# Unit test for function env_fallback
def test_env_fallback():
    assert var_0 == None


# Generated at 2022-06-24 20:50:57.352807
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        test_param0=dict(type='int', required=True)
    )
    parameters = {}
    no_log_values = set_fallbacks(argument_spec, parameters)
    print(no_log_values)
    assert len(no_log_values) == 0
    assert len(parameters) == 0


# Generated at 2022-06-24 20:51:00.038223
# Unit test for function set_fallbacks
def test_set_fallbacks():
    is_error, error_msg, result = test_case_0()
    assert error_msg == 'NotFound'
    assert is_error == True
    assert result is None



# Generated at 2022-06-24 20:51:05.982874
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        a=dict(type='str', fallback=('env_fallback', 'A')),
        b=dict(type='str'),
        c=dict(type='str', fallback=('env_fallback', 'C'))
    )

    parameters = dict(
        a='a',
        b='b'
    )

    no_log_values = set_fallbacks(argument_spec, parameters)

    assert len(no_log_values) == 0
    assert parameters.get('c') == 'c'



# Generated at 2022-06-24 20:51:06.785132
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert test_case_0()



# Generated at 2022-06-24 20:51:10.576770
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
  )
    parameters = dict()
    no_log_values = set()
    assert set_fallbacks(argument_spec, parameters) == no_log_values
    return


# Generated at 2022-06-24 20:51:18.147351
# Unit test for function set_fallbacks
def test_set_fallbacks():
    MOCK_FALLBACK = {
        'param1': {
            'fallback': (None,)
        },
        'param2': {
            'fallback': (env_fallback, 'ENV_VAR')
        },
        'param3': {
            'fallback': (None,),
            'no_log': True
        },
        'param4': {
            'fallback': (env_fallback, 'ENV_VAR'),
            'no_log': True
        },
        'param5': {
            'fallback': (env_fallback, {'something': 'else'})
        }
    }

# Generated at 2022-06-24 20:51:29.274912
# Unit test for function set_fallbacks
def test_set_fallbacks():
    spec = {
        "param_0": {
            "required": False,
            "no_log": False,
            "choices": [
                "0",
                "1"
            ],
            "type": "str"
        },
        "param_1": {
            "required": False,
            "no_log": False,
            "choices": [
                "0",
                "1"
            ],
            "type": "str",
            "fallback": (
                test_case_0,
            )
        }
    }
    param = {}
    set_fallbacks(spec, param)
    assert param == {"param_1": None}
    param = {}
    param_1 = env_fallback()
    set_fallbacks(spec, param)

# Generated at 2022-06-24 20:51:38.764404
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict()
    argument_spec['var_0'] = dict()
    argument_spec['var_0']['type'] = 'str'
    argument_spec['var_0']['fallback'] = (env_fallback, ['var_1', {'var_2': 'var_3'}])
    argument_spec['var_0']['fallback'][0] = env_fallback
    argument_spec['var_0']['fallback'][1] = tuple(['var_1', {'var_2': 'var_3'}])
    parameter = dict()
    no_log_values = set()
    no_log_values = set_fallbacks(argument_spec, parameter)
    assert no_log_values == set()


# Generated at 2022-06-24 20:51:47.159004
# Unit test for function set_fallbacks

# Generated at 2022-06-24 20:51:55.859719
# Unit test for function set_fallbacks

# Generated at 2022-06-24 20:52:44.141190
# Unit test for function set_fallbacks
def test_set_fallbacks():
    no_log_values = set_fallbacks(argument_spec, parameters)

    assert len(no_log_values) == 3
    assert 'pass' in no_log_values
    assert 'ssh' in no_log_values
    assert 'http' in no_log_values


# Generated at 2022-06-24 20:52:49.549809
# Unit test for function set_fallbacks
def test_set_fallbacks():
    arg_spec = dict(
        some_param=dict(
            fallback=(env_fallback, 'SOME_PARAM'))
    )
    parameters = {}

    assert set_fallbacks(arg_spec, parameters) == set()
    assert dict(some_param=None) == parameters

    os.environ['SOME_PARAM'] = 'foo'
    assert set_fallbacks(arg_spec, parameters) == set()
    assert dict(some_param='foo') == parameters


# Generated at 2022-06-24 20:52:57.681190
# Unit test for function set_fallbacks
def test_set_fallbacks():
    params = {'var1': 'test1', 'var2': 'test2'}
    expected = set()

# Generated at 2022-06-24 20:52:59.467791
# Unit test for function env_fallback
def test_env_fallback():
    ansible_module_argument_spec = {
    }
    test_case_0()


# Generated at 2022-06-24 20:53:02.984560
# Unit test for function set_fallbacks
def test_set_fallbacks():
    try:
        assert test_case_0() == None
    except AssertionError:
        raise Exception('Function set_fallbacks failed its unit test')


# Generated at 2022-06-24 20:53:04.079738
# Unit test for function env_fallback
def test_env_fallback():
    assert callable(env_fallback)


# Generated at 2022-06-24 20:53:07.834851
# Unit test for function set_fallbacks
def test_set_fallbacks():
    params = dict(param1='param1')
    spec = dict(
    param3=dict(), 
    param2=dict(fallback=(env_fallback, 'AN_ENV')))
    set_fallbacks(spec, params)
    assert params == dict(param1='param1', param2='AN_ENV')



# Generated at 2022-06-24 20:53:12.589267
# Unit test for function set_fallbacks
def test_set_fallbacks():
    var_1 = [{'fallback': (env_fallback,)}]
    var_2 = {}
    test_set_fallbacks_0_0 = set_fallbacks(var_1, var_2)
    assert test_set_fallbacks_0_0 == set()



# Generated at 2022-06-24 20:53:19.393935
# Unit test for function remove_values
def test_remove_values():
    # Test for function 'remove_values'
    value1 = {'var_0' : 'value_0', 'var_1' : 'value_1', 'var_2' : 'value_2'}
    value2 = ['var_2']
    value3 = {'var_0' : {'var_0' : 'value_2', 'var_3' : 'value_3'}, 'var_1' : {'var_0' : 'value_0', 'var_1' : 'value_1'}}
    value4 = {'var_0' : ['value_2'], 'var_1' : ['value_1']}

# Generated at 2022-06-24 20:53:23.355194
# Unit test for function remove_values
def test_remove_values():
    value = 'test'
    no_log_strings = {'test'}

    try:
        assert_equal(remove_values(value, no_log_strings), 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER')
        assert_true(remove_values('test', no_log_strings) == 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER')
    except AssertionError as e:
        print('AssertionError: %s' % e)
        traceback.print_exc()
        sys.exit(1)


# Generated at 2022-06-24 20:54:54.915476
# Unit test for function set_fallbacks
def test_set_fallbacks():

    # Call test_case_0
    # validating type of parameter argument_spec
    print("\n" * 1)
    argument_spec = dict()
    # validating type of parameter parameters
    print("\n" * 1)
    parameters = dict()
    print("\n" * 1)
    set_fallbacks(argument_spec, parameters)



# Generated at 2022-06-24 20:55:00.042161
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback() is None


# Generated at 2022-06-24 20:55:04.837546
# Unit test for function set_fallbacks
def test_set_fallbacks():
    var_0 = {u'name': {u'type': u'str', u'apply_defaults': False, u'no_log': True}}
    var_1 = {u'name': u'John Doe'}
    assert set_fallbacks(var_0, var_1) == set()


# Generated at 2022-06-24 20:55:13.512539
# Unit test for function set_fallbacks

# Generated at 2022-06-24 20:55:20.414487
# Unit test for function env_fallback
def test_env_fallback():
  f_i = StringIO()
  with warnings.catch_warnings(record=True) as warned:
    cmd = ['ansible-test', 'units']
    with redirect_stdout(f_i):
      ansible_test._parse_units([], cmd)
    x = f_i.getvalue()
    if ("No testcase_0" in x) or ("any tests" in x):
        msg = "No changes found"
        raise AssertionError(msg)




# Generated at 2022-06-24 20:55:23.031772
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # This is the expected result of running set_fallbacks
    parameters = {}
    var_0 = set_fallbacks(parameter_spec, parameters)
    assert var_0 == set()



# Generated at 2022-06-24 20:55:28.912685
# Unit test for function remove_values
def test_remove_values():
    # Test when value is a dict
    dict_value_0 = {'key_0': 'value_0', 'key_1': 'value_1'}
    no_log_strings_0 = ['value_0']
    assert remove_values(dict_value_0, no_log_strings_0) == {'key_0': 'REDACTED', 'key_1': 'value_1'}
    dict_value_1 = {'key_0': test_case_0, 'key_1': 'value_1'}
    no_log_strings_1 = ['value_1']
    assert remove_values(dict_value_1, no_log_strings_1) == {'key_0': test_case_0, 'key_1': 'REDACTED'}

    # Test when value is a list
    list_value_

# Generated at 2022-06-24 20:55:34.332282
# Unit test for function set_fallbacks
def test_set_fallbacks():
    print("")
    print("Test set_fallbacks function")

    # Test case 0
    print("Test case 0...")
    var_0 = env_fallback()
    try:
        if var_0 == "":
            print("0: Success")
    except:
        print("0: Fail")

    # Test case 1
    print("Test case 1...")
    var_1 = env_fallback(param=2)
    try:
        if var_1 == "":
            print("1: Success")
    except:
        print("1: Fail")


# Generated at 2022-06-24 20:55:44.648625
# Unit test for function remove_values
def test_remove_values():
    var_2 = remove_values("asdf", [])
    assert isinstance(var_2, str)
    assert var_2 == 'asdf'
    var_2 = remove_values("asdf", ["as", "df"])
    assert isinstance(var_2, str)
    assert var_2 == ''
    var_2 = remove_values("asdf", ["as"])
    assert isinstance(var_2, str)
    assert var_2 == 'df'
    var_2 = remove_values("asdf", ["df"])
    assert isinstance(var_2, str)
    assert var_2 == 'as'
    var_2 = remove_values("asdf", ["as", "df", "a"])
    assert isinstance(var_2, str)
    assert var_2 == ''


# Generated at 2022-06-24 20:55:47.693670
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # set_fallbacks "get" call needs to be mocked
    with patch('ansible.module_utils.basic.set_fallbacks', return_value=set()):
        assert test_case_0()
