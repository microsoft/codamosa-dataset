

# Generated at 2022-06-24 20:46:32.766724
# Unit test for function remove_values
def test_remove_values():
    string_0 = '{0}.{1}.{2}'.format(get_certname(), fact('kernel'), fact('processor'))
    if fact('ansible_pkg_mgr') == 'yum':
        string_0 = '{0}.{1}.{2}'.format(get_certname(), fact('kernel'), fact('processor'))
    string_1 = '{0}.{1}.{2}'.format(get_certname(), fact('kernel'), fact('processor'))
    string_2 = '{0}.{1}.{2}'.format(get_certname(), fact('kernel'), fact('processor'))
    string_3 = '{0}.{1}.{2}'.format(get_certname(), fact('kernel'), fact('processor'))
    result = remove_values(string_0, string_1)


# Generated at 2022-06-24 20:46:42.587961
# Unit test for function set_fallbacks
def test_set_fallbacks():
    test_0 = 'fallback_strategy'
    test_1 = 'fallback_args'
    test_2 = 'fallback_kwargs'
    float_0 = 460.683
    var_0 = set_fallbacks(float_0, float_0)
    float_1 = -487.207
    float_2 = 58.44
    dict_0 = dict()
    dict_0['0'] = float_2
    dict_0['1'] = float_2
    dict_0['2'] = float_1
    dict_0['3'] = float_0
    dict_0['4'] = float_0
    dict_0['5'] = float_1
    tuple_0 = {dict_0}
    tuple_1 = (dict_0,)

# Generated at 2022-06-24 20:46:45.198925
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert var_0 == 0.0,\
        'did not return 0.0'

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-24 20:46:47.582752
# Unit test for function set_fallbacks

# Generated at 2022-06-24 20:46:51.872809
# Unit test for function env_fallback
def test_env_fallback():
    """
    Test case for function "env_fallback".
    """

    assert env_fallback(460.683) == 460.683
    assert env_fallback(0) == 0
    assert env_fallback(0) == 0
    assert env_fallback(0) == 0
    assert env_fallback(0) == 0


# Generated at 2022-06-24 20:46:56.812689
# Unit test for function sanitize_keys
def test_sanitize_keys():
    args = [dict(key1=1, key2=2, key3=3, key4=4), ['key1', 'key2', 'key3', 'key4'], 'key1']
    obj = dict(key1=1, key2=2, key3=3, key4=4)
    no_log_strings = ['key1', 'key2', 'key3', 'key4']
    ignore_keys = 'key1'
    output = sanitize_keys(obj, no_log_strings, ignore_keys)

# Generated at 2022-06-24 20:47:00.988260
# Unit test for function set_fallbacks
def test_set_fallbacks():

    assert set_fallbacks(2.0, 2.0) is None
    assert set_fallbacks(2.0, 3.0) is None
    assert set_fallbacks(3.0, 2.0) is None
    assert set_fallbacks(2.0, 3.0) is None
    assert set_fallbacks(3.0, 2.0) is None



# Generated at 2022-06-24 20:47:03.708799
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Test case 0
    float_0 = 460.683
    var_0 = set_fallbacks(float_0, float_0)


# Generated at 2022-06-24 20:47:15.151860
# Unit test for function set_fallbacks

# Generated at 2022-06-24 20:47:24.895396
# Unit test for function set_fallbacks
def test_set_fallbacks():
    module = AnsibleModule(
        argument_spec={
            'arg_1': {"type": "float"},
        }
    )
    res_args = dict(
        changed=False,
        ansible_module_results=dict(
            param_1=module.params['arg_1'],
        )
    )

    # Test with no param, no fallback
    module.params['arg_1'] = None

    with pytest.raises(AnsibleExitJson) as exec_info:
        set_fallbacks(module.arg_spec, module.params)

    assert exec_info.value.args[0] == res_args

    # Test with no param, and fallback
    module.params['fallback_arg'] = 460.683
    module.arg_spec['arg_1']['fallback']

# Generated at 2022-06-24 20:47:47.796150
# Unit test for function env_fallback
def test_env_fallback():
    assert type(env_fallback()) == Undefined


# Generated at 2022-06-24 20:47:52.885166
# Unit test for function env_fallback
def test_env_fallback():
    # Make sure that we're falling back to an environment variable
    # when no fallback is specified in the argument spec
    float_0 = 460.683
    var_0 = set_fallbacks(float_0, float_0)

    # Check that we specified an environment variable that doesn't exist
    with pytest.raises(AnsibleFallbackNotFound):
        env_fallback('not_real_env')

    # Check that we correctly retrieved the value from the environment
    assert env_fallback('ANSIBLE_TEST_fallback') == 'from_env'


# Generated at 2022-06-24 20:47:56.469399
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Check basic behaviour
    float_0 = float(8.5)
    var_1 = set_fallbacks(float_0, float_0)
    # Check that invalid fallback raises exception
    str_0 = str('my_str')
    # AssertionError:
    # In case of invalid fallback_strategy, set_fallbacks should raise AnsibleFallbackNotFound exception
    set_fallbacks(str_0, str_0)


# Generated at 2022-06-24 20:48:02.909188
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback(var_0) == (None, None)
    assert env_fallback(var_0) == (None, None)
    assert env_fallback(var_0) == (None, None)


# Generated at 2022-06-24 20:48:05.551426
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Case 0
    float_0 = 460.683
    var_0 = set_fallbacks(float_0, float_0)
    # Assertion
    assert var_0 == set()



# Generated at 2022-06-24 20:48:16.183457
# Unit test for function set_fallbacks
def test_set_fallbacks():

    # Example 1
    argument_spec = {'param0': {'required': True}}
    parameters = {'param0': 'value'}
    expected = set()
    result = set_fallbacks(argument_spec=argument_spec, parameters=parameters)
    assert result == expected

    # Example 2
    argument_spec = {'param0': {'required': True}}
    parameters = {}
    expected = set()
    result = set_fallbacks(argument_spec=argument_spec, parameters=parameters)
    assert result == expected

    # Example 3
    argument_spec = {'param0': {'required': True}}
    parameters = {'param0': 'value', 'param1': 'value'}
    expected = set()
    result = set_fallbacks(argument_spec=argument_spec, parameters=parameters)

# Generated at 2022-06-24 20:48:17.232444
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert set_fallbacks(float_0, float_0) == set()

# Generated at 2022-06-24 20:48:20.043437
# Unit test for function set_fallbacks
def test_set_fallbacks():
    import argparse
    import random
    parser = argparse.ArgumentParser()
    parser.add_argument('test_case')
    args = parser.parse_args()
    test_case = int(args.test_case)
    globals()['test_case_%d' % test_case]()



# Generated at 2022-06-24 20:48:22.650769
# Unit test for function set_fallbacks
def test_set_fallbacks():
    float_0 = 0.0
    assert (set_fallbacks(float_0, float_0) == set())


# Generated at 2022-06-24 20:48:24.085565
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert test_case_0() is None


# Generated at 2022-06-24 20:48:55.552408
# Unit test for function sanitize_keys
def test_sanitize_keys():
    # Test using a string
    assert sanitize_keys('hello', {'lo'}) == 'he__'
    assert sanitize_keys(u'hello', {'lo'}) == u'he__'
    # Test using a list of strings
    assert sanitize_keys(['world', 'bob'], {'ob'}) == ['w__d', '__b']
    assert sanitize_keys([u'world', u'bob'], {'ob'}) == [u'w__d', u'__b']
    # Test using a list of mixed types
    assert sanitize_keys(['world', 'bob', 5, ['hello', 'world']], {'ob'}) == ['w__d', '__b', 5, ['hello', 'world']]

# Generated at 2022-06-24 20:48:57.461967
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert set_fallbacks(float_0, float_0) == 1.0
    with pytest.raises(AssertionError):
        assert set_fallbacks(float_0, float_0) != 1.0


# Generated at 2022-06-24 20:49:03.922374
# Unit test for function remove_values
def test_remove_values():
    # FIXME: remove portability dirs, only used for local testing
    test_data = '/Users/david/dev/ansible/lib/ansible/module_utils/basic.py'
    with open(test_data, "rt") as f:
        value = f.read()
    no_log_strings = {'bad', 'worse', 'terrible'}
    new_value = remove_values(value, no_log_strings)

# Generated at 2022-06-24 20:49:09.023111
# Unit test for function sanitize_keys
def test_sanitize_keys():
    # Test if the output from sanitize_keys is a string
    # Test if the output from sanitize_keys is a Set
    # Test if the output from sanitize_keys is a list
    # Test if the output from sanitize_keys is a float
    # Test if the output from sanitize_keys is a int
    # Test if the output from sanitize_keys is a dict

    var_0 = "sanitize_keys"
    var_1 = set()
    var_2 = list()
    float_0 = 460.683
    int_0 = 3

    var_3 = sanitize_keys(var_0, var_1, ignore_keys=frozenset())
    var_4 = sanitize_keys(var_1, var_1, ignore_keys=frozenset())


# Generated at 2022-06-24 20:49:18.267623
# Unit test for function sanitize_keys
def test_sanitize_keys():
    print('Running test_sanitize_keys')
    import json

    # Sanitize a dict
    data = {'foo': 'hello', 'bar': 'world'}
    json_data = json.dumps(data)
    json_data_sanitized = sanitize_values(json_data, b'world', is_json=True)
    json_data_sanitized_keys = sanitize_keys(json_data_sanitized, {b'world'}, is_json=True)
    assert json_data_sanitized_keys == b'{"foo": "hello", "bar": "**********"}'

    # Sanitize a list
    data = ['foo', 'hello', 'bar', 'world']
    json_data = json.dumps(data)
    json_data_sanitized = sanitize_values

# Generated at 2022-06-24 20:49:20.809216
# Unit test for function set_fallbacks
def test_set_fallbacks():

    float_0 = 460.683
    var_0 = set_fallbacks(float_0, float_0)

    return var_0


# Generated at 2022-06-24 20:49:22.785767
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # float_assertion
    float_0 = 460.683
    var_0 = set_fallbacks(float_0, float_0)


# Generated at 2022-06-24 20:49:34.287330
# Unit test for function set_fallbacks
def test_set_fallbacks():

    class TestCase(object):
        def __init__(self, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)


# Generated at 2022-06-24 20:49:35.589070
# Unit test for function remove_values
def test_remove_values():
    value = 5
    # valid_types = (list, tuple, dict)
    assert remove_values(value, ["5"]) == 5



# Generated at 2022-06-24 20:49:41.049094
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Setup argument types
    float_0 = 460.683

    # Invoke Method
    set_fallbacks = sut.set_fallbacks(float_0, float_0)



# Generated at 2022-06-24 20:50:03.336373
# Unit test for function env_fallback
def test_env_fallback():
    print('Testing the module env_fallback')
    test_case_0()



# Generated at 2022-06-24 20:50:05.180126
# Unit test for function set_fallbacks
def test_set_fallbacks():
    float_0 = 460.683
    var_0 = set_fallbacks(float_0, float_0)
    assert var_0 == set()


# Generated at 2022-06-24 20:50:15.646445
# Unit test for function set_fallbacks
def test_set_fallbacks():
    float_0 = 1.1
    tuple_0 = (float_0, )
    var_0 = set_fallbacks(float_0, tuple_0)
    assert var_0 == 1.1

    float_1 = 1.1
    tuple_1 = (float_1, )
    var_1 = set_fallbacks(float_1, tuple_1)
    assert var_1 == 1.1

    float_2 = 1.1
    tuple_2 = (float_2, )
    var_2 = set_fallbacks(float_2, tuple_2)
    assert var_2 == 1.1

    float_3 = 1.1
    tuple_3 = (float_3, )
    var_3 = set_fallbacks(float_3, tuple_3)
    assert var_3 == 1.1

# Generated at 2022-06-24 20:50:24.511152
# Unit test for function sanitize_keys
def test_sanitize_keys():
    float_0 = 460.683
    var_0 = sanitize_keys(float_0, float_0)
    
    str_0 = "http://developer.github.com/v3/issues/events/#list-events-for-an-issue"
    str_1 = "http://developer.github.com/v3/issues/labels/#edit-a-label"
    var_1 = sanitize_keys(str_0, str_1)
    
    list_0 = [337, 6408909289.73]
    list_1 = [47, 48]
    var_2 = sanitize_keys(list_0, list_1)
    
    tuple_0 = (451.903, 5)
    tuple_1 = (0.8369, )
    var_3 = sanit

# Generated at 2022-06-24 20:50:28.719998
# Unit test for function env_fallback
def test_env_fallback():
    float_0 = 460.683
    var_0 = env_fallback(float_0)


# Generated at 2022-06-24 20:50:30.115930
# Unit test for function env_fallback
def test_env_fallback():
    float_0 = 460.683
    var_0 = env_fallback()
    print(var_0)



# Generated at 2022-06-24 20:50:35.780342
# Unit test for function set_fallbacks
def test_set_fallbacks():
    float_0 = 460.683
    var_0 = set_fallbacks(float_0, float_0)
    assert var_0 == set()
    bool_0 = False
    set_1 = frozenset(['65535'])
    var_1 = set_fallbacks(bool_0, set_1)
    assert var_1 == set()
    int_0 = 524288
    float_1 = -1.0
    var_2 = set_fallbacks(int_0, float_1)
    assert var_2 == set()
    bytes_0 = b'\x03\x11'
    var_3 = set_fallbacks(bytes_0, bytes_0)
    assert var_3 == set()
    int_1 = 64

# Generated at 2022-06-24 20:50:42.564348
# Unit test for function remove_values
def test_remove_values():
    """
    Test remove_values in ansible/module_utils/basic.py, test_removal_order,
    test_removal_order_in_dict, test_removal_order_in_dict_in_list,
    test_removal_order_in_list, test_removal_order_in_list_in_dict,
    test_removal_order_in_list_in_list, test_removal_order_in_set,
    and test_removal_order_in_set_in_list
    """

    # no-log strings
    no_log_strings = {
        'pass1',
        'pass@123',
        'pass@456',
        'password@123',
        'password@456'
    }

    ###################################################################################
    ### Test removal order
   

# Generated at 2022-06-24 20:50:51.007303
# Unit test for function set_fallbacks
def test_set_fallbacks():
    test_cases = [
            {
                'arguments': [
                    460.683,
                    608.857
                ],
                'exception': None,
                'return': None
            }
    ]
    for test_case in test_cases:
        exception = test_case['exception']
        if exception:
            with pytest.raises(exception):
                set_fallbacks(*test_case['arguments'])
        else:
            assert set_fallbacks(*test_case['arguments']) == test_case['return']


# Generated at 2022-06-24 20:50:57.007427
# Unit test for function env_fallback
def test_env_fallback():
    for arg in [460.683]:
        if arg in os.environ:
            var_0 = os.environ[arg]
            try:
                assert var_0 == var_0
            except AssertionError as e:
                raise AssertionError(str(e) + ' for Input: ' + str(arg))


# Generated at 2022-06-24 20:51:32.130703
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert set_fallbacks(23, 342) is None, "The function should return None"
    assert set_fallbacks() == () and set_fallbacks(1) == (1,) and set_fallbacks(1, 2) == (1, 2), "The function should return None"

# This function has previously been used in a number of custom modules, and
# as such we need to check that it is present and behaves as expected.
# This test was generated using the following code:
#
# import os
# import pytest
# import textwrap
#
# param = 1
# value = 2
#
# def env_fallback(*args, **kwargs):
#     for arg in args:
#         if arg in os.environ:
#             return os.environ[arg]
#     raise AnsibleFallbackNotFound
#
#

# Generated at 2022-06-24 20:51:42.027660
# Unit test for function set_fallbacks
def test_set_fallbacks():
    float_0 = 460.683
    var_0 = set_fallbacks(float_0, float_0)
    float_1 = 812.097
    var_0 = set_fallbacks(float_1, float_1)
    float_2 = 967.816
    var_0 = set_fallbacks(float_2, float_2)
    float_3 = 913.161
    var_0 = set_fallbacks(float_3, float_3)
    float_4 = -906.573
    var_0 = set_fallbacks(float_4, float_4)
    float_5 = -976.988
    var_0 = set_fallbacks(float_5, float_5)
    float_6 = -864.974

# Generated at 2022-06-24 20:51:43.339770
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback('') == os.environ['']


# Generated at 2022-06-24 20:51:49.931199
# Unit test for function env_fallback
def test_env_fallback():
    env_fallback()
    env_fallback(float_0)
    env_fallback(float_0, float_0)
    env_fallback(float_0, float_0, float_0)

# Test cases for function env_fallback
# Test case for function env_fallback, with float_0 being float and float_0 being float

# Generated at 2022-06-24 20:51:53.215797
# Unit test for function set_fallbacks
def test_set_fallbacks():
    try:
        test_case_0()
    except:
        print('failed test_case_0')
    
# Run unit tests for function set_fallbacks
if __name__ == '__main__':
    test_set_fallbacks()


# Generated at 2022-06-24 20:51:55.051255
# Unit test for function set_fallbacks
def test_set_fallbacks():
    float_0 = 460.683
    var_0 = set_fallbacks(float_0, float_0)



# Generated at 2022-06-24 20:52:00.544472
# Unit test for function env_fallback
def test_env_fallback():
    # Check if env_fallback() raises exceptions
    # param 1: kwargs, type: dict
    try:
        env_fallback({'key': 'val'})
    except Exception as e:
        print("Argument 1: {0} Exception raised: {1}".format('kwargs', e))


# Generated at 2022-06-24 20:52:10.050990
# Unit test for function set_fallbacks
def test_set_fallbacks():
    arg_0 = dict(
        host=dict(fallback=(env_fallback, ['ANSIBLE_REMOTE_HOST'])),
        path=dict(fallback=(env_fallback, [('ANSIBLE_REMOTE_TEMP', '/tmp')])),
        password=dict(fallback=(env_fallback, [{'vars': ['ANSIBLE_REMOTE_PASSWORD', 'ANSIBLE_NET_PASSWORD']}]), no_log=True)
    )
    arg_1 = dict(
        host='foo',
        password='bar'
    )
    res_0 = set_fallbacks(arg_0, arg_1)
    assert res_0 == set(['bar'])
    res_1 = set_fallbacks(arg_0, arg_1)

# Generated at 2022-06-24 20:52:11.793229
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert callable(set_fallbacks)
    test_case_0()


# Generated at 2022-06-24 20:52:12.721680
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback() == AnsibleFallbackNotFound

# Generated at 2022-06-24 20:52:37.203402
# Unit test for function set_fallbacks
def test_set_fallbacks():
    test_case_0()


# Generated at 2022-06-24 20:52:39.316635
# Unit test for function set_fallbacks
def test_set_fallbacks():
    float_0 = 460.683
    var_0 = set_fallbacks(float_0, float_0)



# Generated at 2022-06-24 20:52:41.703957
# Unit test for function set_fallbacks
def test_set_fallbacks():
    float_0 = 460.683
    var_0 = set_fallbacks(float_0, float_0)
    print(var_0)


# Generated at 2022-06-24 20:52:46.504587
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Assign value
    float_0 = 460.683
    # Call function
    var_0 = set_fallbacks(float_0, float_0)
    # Check value
    assert var_0 == 0


# Generated at 2022-06-24 20:52:47.695552
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert var_0 == 460.683


# Generated at 2022-06-24 20:52:51.273520
# Unit test for function set_fallbacks
def test_set_fallbacks():
    float_0 = 888.078
    str_0 = "To var_0 unit test"
    var_0 = set_fallbacks(float_0, str_0)
    assert isinstance(var_0, float) == True
    print("Passed set_fallbacks")



# Generated at 2022-06-24 20:53:00.409594
# Unit test for function sanitize_keys
def test_sanitize_keys():
    test_0 = dict(foo=dict(bar=dict(baz='foobarbaz')), baz='foobarbaz')
    answer_0 = dict(foo=dict(bar=dict(baz='foobarbaz')), baz='foobarbaz')
    ignore_keys_0 = ['_ansible_verbose_always', '_ansible_no_log']
    no_log_strings_0 = ['foobarbaz']
    attempt_0 = sanitize_keys(test_0, no_log_strings_0, ignore_keys_0)
    if attempt_0 == answer_0:
        print('Test 0 pass:')
    else:
        print('Test 0 fail:')
        print(attempt_0)
        print(answer_0)



# Generated at 2022-06-24 20:53:05.376634
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'test_param': {'type': 'str'}}
    parameters = {}
    no_log_values = set_fallbacks(argument_spec, parameters)
    if no_log_values:
        print('no_log_values set unexpectedly %s' % no_log_values)


# Generated at 2022-06-24 20:53:11.884626
# Unit test for function env_fallback
def test_env_fallback():
    float_1 = 483.343
    float_2 = 457.9
    tuple_0 = (float_1, float_2)
    float_3 = 442.364
    float_4 = 481.455
    float_5 = 401.279
    set_0 = {float_3, float_4, float_5}
    float_6 = 419.552
    result = env_fallback(tuple_0, set_0, float_6)
    assert result == None


# Generated at 2022-06-24 20:53:20.415816
# Unit test for function set_fallbacks
def test_set_fallbacks():
    test_cases = (
        (460.683, {'ansible_epel_version': 'epel-release-latest-7.noarch.rpm', 'ansible_ssh_host': '192.168.1.3', 'ansible_python_interpreter': '/usr/bin/python', 'ansible_user': 'ansible', 'ansible_distribution': 'CentOS', 'ansible_distribution_major_version': '7', 'ansible_distribution_version': '7.2.1511', 'ansible_distribution_release': 'Core', 'ansible_ssh_user': 'ansible'}),
    )

    for test_case in test_cases:
        assert set_fallbacks(*test_case) == test_case[1]



# Generated at 2022-06-24 20:53:46.149227
# Unit test for function env_fallback
def test_env_fallback():
    env_fallback('test_var_0', 'test_var_1')


# Generated at 2022-06-24 20:53:57.010316
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Test with float_0
    float_0 = 460.683
    assert set_fallbacks(float_0, float_0) == os.environ[float_0]

    # Test with str_0
    str_0 = '!$:(Z4#FwJ+N=@:1N'
    assert set_fallbacks(str_0, str_0) == os.environ[str_0]

    # Test with list_1, list_2
    list_1 = [12, '[]0Wqc%w,xs', [39, 'L-A[F0,s?v', 'xTk-*#^nqZ%']]
    list_2 = ['j"8~e=s,v]*', 46, 'z_N,N>D"pNw']
    assert set

# Generated at 2022-06-24 20:54:05.555689
# Unit test for function remove_values
def test_remove_values():
    print ("in function test_remove_values")
    d = {
        "test": {
            u"a": 1,
            u"b": [1, 2, 3, 'abcd', {u"some": u"thing"}],
            u"c": {u"some": u"thing"},
            "xyz": {u"some": u"thing"},
            u"xyz": {u"some": u"thing"},
            "abcd": 'abcd',
            "1234": '1234'
        }
    }
    result = remove_values(d, ['thing'])

# Generated at 2022-06-24 20:54:06.530407
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # call class set_fallbacks
    test_case_0()



# Generated at 2022-06-24 20:54:08.521346
# Unit test for function set_fallbacks
def test_set_fallbacks():
    float_0 = 460.683
    var_0 = set_fallbacks(float_0, float_0)
    float_1 = float_0
    assert float_1 == var_0


# Generated at 2022-06-24 20:54:09.992746
# Unit test for function env_fallback
def test_env_fallback():
    try:
        env_fallback("test")
    except Exception:
        assert False, "Unable to get env var"


# Generated at 2022-06-24 20:54:20.498676
# Unit test for function set_fallbacks
def test_set_fallbacks():
    float_0 = {u'floats': {u'ansible.builtin.float': {u'apply_defaults': False, u'choices': {u'ansible.builtin.float', u'0.0', u'1.0'}, u'default': u'0.0', u'description': False, u'type': u'float', u'required': False, u'aliases': {u'ansible.builtin.float': u'floats'}}}}

# Generated at 2022-06-24 20:54:22.270939
# Unit test for function set_fallbacks
def test_set_fallbacks():
    float_0 = 460.683
    var_0 = set_fallbacks(float_0, float_0)



# Generated at 2022-06-24 20:54:24.869536
# Unit test for function set_fallbacks
def test_set_fallbacks():
    float_0 = 460.683
    var_0 = set_fallbacks(float_0, float_0)
    assert(var_0 == set())


# Generated at 2022-06-24 20:54:34.849248
# Unit test for function set_fallbacks
def test_set_fallbacks():
    from pytest import raises
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import StringIO

    # Save the builtin open function
    open_builtin = builtins.open
    # Define a mock open function
    def _mock_open_function(file, mode='r', buffering=-1):
        """Mock open() builtin for a given file."""
        # Check if open() is called for the right file
        assert file == 'file_path'

        # Define an StringIO instance
        file_handle = StringIO(u'content')

        # Return the StringIO instance
        return file_handle



# Generated at 2022-06-24 20:55:00.248486
# Unit test for function env_fallback
def test_env_fallback():
    float_0 = 460.683
    var_0 = set_fallbacks(float_0, float_0)
    var_0 = os.getenv('var_0', 'var_0-null')



# Generated at 2022-06-24 20:55:04.638989
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert set_fallbacks(float_0, float_0) == float_0

    try:
        set_fallbacks(float_0, float_0)
    except:
        pass

    assert set_fallbacks(float_0, float_0) == float_0



# Generated at 2022-06-24 20:55:07.236676
# Unit test for function env_fallback
def test_env_fallback():
    with mock.patch('os.environ', new={'var_1': '1'}):
        assert env_fallback('var_1') == '1'



# Generated at 2022-06-24 20:55:16.782940
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Define a argument_spec with no fallbacks
    argument_spec = {
        "b": {
            "default": "",
            "required": False
        },
        "a": {
            "required": True
        }
    }
    # Define a parameters with no b
    parameters = {
        "a": "a"
    }
    # No Fallback should be set.
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert no_log_values == set()
    # Test no_log
    argument_spec = {
        "b": {
            "default": "",
            "required": False,
            "no_log": True
        },
        "a": {
            "required": True
        }
    }

# Generated at 2022-06-24 20:55:18.691325
# Unit test for function set_fallbacks
def test_set_fallbacks():
    var_1 = set_fallbacks("460.683", "460.683")
    assert var_1 == set([])

# Generated at 2022-06-24 20:55:20.555365
# Unit test for function env_fallback
def test_env_fallback():
    float_0 = 376.186
    var_0 = env_fallback(float_0, float_0)
    eq(var_0, float_0)


# Generated at 2022-06-24 20:55:22.804355
# Unit test for function env_fallback
def test_env_fallback():
    # Tests for env_fallback
    float_0 = 460.683
    var_0 = env_fallback(float_0, float_0)


# Generated at 2022-06-24 20:55:26.948612
# Unit test for function set_fallbacks
def test_set_fallbacks():
    float_0 = 460.683
    var_0 = set_fallbacks(float_0, float_0)
    assert var_0 == 0


# unit test for function set_fallbacks

# Generated at 2022-06-24 20:55:33.238716
# Unit test for function set_fallbacks
def test_set_fallbacks():
    float_0 = 460.683
    var_0 = set_fallbacks(float_0, float_0)
    print("\n\n TEST set_fallbacks() \n\n")
    print("\n\n ******** Printing expected result ******** \n\n")
    print(var_0)
    print("\n\n ******** Printing actual result ******** \n\n")
    print(set_fallbacks(float_0, float_0))
    assert var_0 == set_fallbacks(float_0, float_0)



# Generated at 2022-06-24 20:55:37.847513
# Unit test for function set_fallbacks
def test_set_fallbacks():
    float_0 = 1.0
    var_5 = set_fallbacks(float_0, float_0)
    float_1 = float_0
    var_6 = set_fallbacks(float_1, float_1)
    float_2 = float_0
    var_7 = set_fallbacks(float_2, float_2)
    float_3 = float_0
    var_8 = set_fallbacks(float_3, float_3)
    float_4 = float_0
    var_9 = set_fallbacks(float_4, float_4)

