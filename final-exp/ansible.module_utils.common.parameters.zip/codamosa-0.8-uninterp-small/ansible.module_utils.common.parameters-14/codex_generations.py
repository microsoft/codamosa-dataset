

# Generated at 2022-06-24 20:46:40.662261
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {"my_var": {
        "type": "str",
        "default": "hello",
        "fallback": (env_fallback, "my_var"),
        "no_log": True,
    }}
    param = {"my_other_var": "world"}
    no_log = set_fallbacks(argument_spec, param)
    assert param['my_var'] == "hello"
    assert no_log == set()



# Generated at 2022-06-24 20:46:43.497405
# Unit test for function env_fallback
def test_env_fallback():
    var_0_ = env_fallback()
    assert type(var_0_) == AnsibleFallbackNotFound


# Generated at 2022-06-24 20:46:44.797449
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert isinstance(sanitize_keys(obj=var_0, no_log_strings=undefined, ignore_keys=undefined), object)

# Generated at 2022-06-24 20:46:46.756201
# Unit test for function env_fallback
def test_env_fallback():
    # raises exception on failure
    test_case_0()
    test_case_1()



# Generated at 2022-06-24 20:46:52.965177
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # An ad-hoc test format
    case_0 = dict(
        argument_spec=dict(
            foo=dict(fallback=(env_fallback, 'FOO'))
        ),
        parameters=dict(
        )
    )
    os.environ['FOO'] = 'bar'
    no_log_values = set_fallbacks(case_0['argument_spec'], case_0['parameters'])
    del os.environ['FOO']
    assert 'bar' in no_log_values


# Generated at 2022-06-24 20:47:01.330216
# Unit test for function set_fallbacks

# Generated at 2022-06-24 20:47:12.135243
# Unit test for function set_fallbacks
def test_set_fallbacks():
    values_0 = dict()
    values_0['type'] = 'str'
    values_0['fallback'] = (env_fallback, 'CREDENTIALS')
    argument_spec_0 = dict()
    argument_spec_0['credentials'] = values_0
    parameters_0 = dict()
    no_log_values_0 = set_fallbacks(argument_spec_0, parameters_0)
    assert len(no_log_values_0) == 0, 'Expected 0, but got %s' % len(no_log_values_0)
    assert len(parameters_0) == 0, 'Expected 0, but got %s' % len(parameters_0)


# Generated at 2022-06-24 20:47:14.038529
# Unit test for function set_fallbacks
def test_set_fallbacks():
    with pytest.raises(AnsibleFallbackNotFound):
        set_fallbacks()



# Generated at 2022-06-24 20:47:17.304237
# Unit test for function env_fallback
def test_env_fallback():
    var_0 = b'ANSIBLE_WANT_JSON=True'
    with mock.patch.dict(os.environ, {'ANSIBLE_WANT_JSON': 'True'}):
        result = env_fallback(var_0)
        assert result == 'True'
        assert os.environ[b'ANSIBLE_WANT_JSON'.decode('utf-8')] == 'True'


# Generated at 2022-06-24 20:47:21.957023
# Unit test for function env_fallback
def test_env_fallback():
    var_0 = None
    try:
        env_fallback(var_0)
    except AnsibleFallbackNotFound:
        return
    except Exception as e:
        print('Exception raised: {0}'.format(e))
        assert False
    else:
        assert True



# Generated at 2022-06-24 20:47:47.434672
# Unit test for function env_fallback
def test_env_fallback():
    with pytest.raises(AnsibleFallbackNotFound):
        test_case_env_fallback_0()


# Generated at 2022-06-24 20:47:49.401485
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Test with two arguments
    with pytest.raises(AnsibleFallbackNotFound) as exception:
        set_fallbacks('parameter', 'value')


# Generated at 2022-06-24 20:47:59.967034
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'name': {
            'type': 'dict',
            'required': True,
            'options': {
                'key1': {'type': 'str'},
                'key2': {
                    'type': 'str',
                    'fallback': (env_fallback, ['KEY_NAME'])
                }
            }
        },
        'new': {
            'type': 'bool',
            'fallback': (env_fallback, ['NEW']),
        }
    }

    parameters = {
        'key2': 'test-value'
    }

    no_log_value = set_fallbacks(argument_spec, parameters)
    assert no_log_value == set()
    assert parameters == {
        'key2': 'test-value'
    }

    # Test that

# Generated at 2022-06-24 20:48:10.075544
# Unit test for function set_fallbacks

# Generated at 2022-06-24 20:48:20.514949
# Unit test for function set_fallbacks
def test_set_fallbacks():

    var_0 = env_fallback()
    var_1 = env_fallback()
    var_2 = env_fallback(var_1)
    var_3 = env_fallback()
    var_4 = env_fallback(var_3)

# Generated at 2022-06-24 20:48:27.357880
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'var_0': {
            'fallback': (env_fallback, ),
            'required': True,
            'type': 'bool',
        },
    }

    no_log_values = set()
    parameters = {}
    no_log_values.update(set_fallbacks(argument_spec, parameters))

    assert 'var_0' in parameters


# Generated at 2022-06-24 20:48:30.248288
# Unit test for function env_fallback
def test_env_fallback():
    with pytest.raises(AnsibleFallbackNotFound):
        test_case_0()

# Generated at 2022-06-24 20:48:31.055599
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert env_fallback() == AnsibleFallbackNotFound


# Generated at 2022-06-24 20:48:35.351040
# Unit test for function set_fallbacks
def test_set_fallbacks():
    var_0 = {
        'param_0': {
            'type': 'str',
            'fallback': ( env_fallback, ),
        },
    }

    var_1 = {}

    assert set_fallbacks(var_0, var_1) == set()



# Generated at 2022-06-24 20:48:36.044678
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert False


# Generated at 2022-06-24 20:49:11.981301
# Unit test for function env_fallback
def test_env_fallback():
    var_0 = os.environ.copy()
    for key in var_0:
        del os.environ[key]
    result_with_error = None
    try:
        result_with_error = env_fallback()
    except AnsibleFallbackNotFound:
        pass
    assert result_with_error is None
    result_without_error = None
    os.environ['ANSIBLE_STRATEGY'] = 'test'
    result_without_error = env_fallback('ANSIBLE_STRATEGY')
    assert result_without_error == 'test'
    assert os.environ == var_0
    for key in os.environ:
        del os.environ[key]
    result_with_error = None

# Generated at 2022-06-24 20:49:19.877538
# Unit test for function set_fallbacks
def test_set_fallbacks():
    from ansible.module_utils.basic import AnsibleModule

    # Argument spec for parameters
    argument_spec = dict(
        param_1=dict(type='int', required=True, fallback=(env_fallback, 'TEST_VAR_1')),
        param_2=dict(type='int', required=True, fallback=(env_fallback, 'TEST_VAR_2', dict(key_1='test_1', key_2='test_2'))),
        param_3=dict(type='int', required=True),
        param_4=dict(type='str', fallback=(env_fallback, 'TEST_VAR_4'), no_log=True)
    )

    # Dictionary containing parameters

# Generated at 2022-06-24 20:49:23.966997
# Unit test for function env_fallback
def test_env_fallback():
    func_call = env_fallback(2, 2, 3, 2, 2)
    assert func_call == None, f'actual: {func_call}, expected: {env_fallback(2, 2, 3, 2, 2)}'
    print('Test env_fallback successful')


# Generated at 2022-06-24 20:49:34.464235
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Importing parameters from test_set_fallbacks.yaml
    argument_spec = {
        "var_0": {
            "type": "int",
            "fallback": (env_fallback),
        },
        "var_1": {
            "type": "int",
            "default": 1,
            "fallback": (env_fallback),
        },
    }
    parameters = {
        "var_1": 5,
    }
    no_log_values = set_fallbacks(argument_spec, parameters)
    # Should set parameter var_0 to the env variable var_0
    test_case_0()
    assert parameters['var_0'] == os.environ['var_0']


# Generated at 2022-06-24 20:49:38.459874
# Unit test for function env_fallback
def test_env_fallback():
    var_env = os.environ.copy()
    with EnvironmentVars(var_env):
        try:
            assert var_env == os.environ
            # Call function env_fallback
            test_case_0()
        except AnsibleFallbackNotFound as e:
            assert False
        finally:
            del var_env


# Generated at 2022-06-24 20:49:40.185950
# Unit test for function env_fallback
def test_env_fallback():
    try:
        test_case_0()
    except AnsibleFallbackNotFound as e:
        assert True
    else:
        assert False


# Generated at 2022-06-24 20:49:48.847185
# Unit test for function set_fallbacks
def test_set_fallbacks():
    var_1 = {}
    var_2 = {}
    var_3 = {}
    var_4 = {}
    var_1 = {'gather_subset': ['all'], 'gather_timeout': 10, 'gather_facts': 'no'}
    var_2 = set_fallbacks(var_1, var_2)
    var_3 = "gather_subset"
    var_4 = "ansible_gather_subset"
    assert var_3 in var_1, "Test failed. Expected value not found."
    assert var_4 in var_1, "Test failed. Expected value not found."


# Generated at 2022-06-24 20:49:55.186303
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Evaluate an if condition
    var_0 = test_case_0()
    # Assign a value with a type
    var_1 = ""
    # Evaluate a comparison
    var_2 = isinstance(var_0, type(var_1))
    assert var_2


# Generated at 2022-06-24 20:50:03.890414
# Unit test for function remove_values

# Generated at 2022-06-24 20:50:15.753332
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Fetch test data
    with open(TestAnsibleModule.test_data_path + '/set_fallbacks.json', 'r') as data_file:
        test_data = json.loads(data_file.read())

    # Iterate over testcases and run
    for test_case in test_data:
        # Setup test
        if 'arguments' in test_case:
            arguments = test_case['arguments']
        if 'parameters' in test_case:
            parameters = test_case['parameters']

        # Execute function
        result = set_fallbacks(arguments, parameters)

        # Verify result
        if 'expected_results' in test_case:
            expected_results = test_case['expected_results']

# Generated at 2022-06-24 20:51:04.765665
# Unit test for function remove_values
def test_remove_values():
    var_0 = env_fallback()



# Generated at 2022-06-24 20:51:15.335927
# Unit test for function set_fallbacks
def test_set_fallbacks():

    # Verify that the default value is set when environment variable is not set.
    set_fallbacks({"var_0": {'type': 'str', 'fallback': (env_fallback, )}}, {})
    assert "var_0" not in globals()

    # Verify that setting environment variable works.
    os.environ["FOO_BAR_VAR_0"] = "abc"
    set_fallbacks({"var_0": {'type': 'str', 'fallback': (env_fallback, "FOO_BAR_VAR_0")}}, {})
    assert var_0 == "abc"

    # Verify that multiple environment variables are checked.
    os.environ["FOO_BAR_VAR_0"] = "abc"

# Generated at 2022-06-24 20:51:21.361939
# Unit test for function set_fallbacks

# Generated at 2022-06-24 20:51:30.628087
# Unit test for function set_fallbacks
def test_set_fallbacks():
    module_args = {}
    argument_spec = {
        'fallback': {'type': 'fallback', 'force_fallback': True, 'fallback': (env_fallback, ['CUSTOM_ENV'])},
        'fallback2': {'type': 'fallback', 'fallback': (env_fallback, ['CUSTOM_ENV_2'])},
    }
    module_args = {}
    no_log_values = set_fallbacks(argument_spec, module_args)
    assert ('fallback' in module_args) and ('fallback2' not in module_args)


# Generated at 2022-06-24 20:51:33.492312
# Unit test for function env_fallback
def test_env_fallback():
    var_0 = None
    try:
        test_case_0()
    except AnsibleFallbackNotFound:
        var_0 = None
    assert var_0 is None


# Generated at 2022-06-24 20:51:42.959435
# Unit test for function set_fallbacks
def test_set_fallbacks():
    params = {
        "ANOTHER_ONE": "another value",
        "ANOTHER_ONE_TOO": "another value too"
    }

# Generated at 2022-06-24 20:51:54.271611
# Unit test for function set_fallbacks

# Generated at 2022-06-24 20:52:03.845223
# Unit test for function set_fallbacks
def test_set_fallbacks():

    # Set up mock
    argument_spec = {'A': {'fallback': [env_fallback, 'A_FALLBACK']},
                     'B': {'fallback': [env_fallback, 'B_FALLBACK']},
                     'C': {'fallback': [env_fallback, {'key': 'C_FALLBACK'}]},
                     'D': {'fallback': [env_fallback, {'key': 'D_FALLBACK'}]}
    }
    parameters = {}

    no_log_values = set_fallbacks(argument_spec, parameters)

    # Verify the results
    assert len(no_log_values) == 0
    assert len(parameters) == 4
    assert parameters['A'] == 'A_FALLBACK'

# Generated at 2022-06-24 20:52:12.762913
# Unit test for function set_fallbacks
def test_set_fallbacks():
    json_dict = dict()
    json_dict['parameters'] = dict()

    argument_spec = dict()
    argument_spec['test_param'] = dict()
    argument_spec['test_param']['type'] = 'str'
    argument_spec['test_param']['fallback'] = (env_fallback, 'TEST_ENV')

    no_log_values = set_fallbacks(argument_spec, json_dict['parameters'])

    assert 'TEST_ENV' in os.environ
    assert os.environ['TEST_ENV'] == '12345'

    assert no_log_values == set()

    assert json_dict['parameters']['test_param'] == '12345'



# Generated at 2022-06-24 20:52:20.503530
# Unit test for function set_fallbacks

# Generated at 2022-06-24 20:54:20.186198
# Unit test for function env_fallback
def test_env_fallback():
    try:
        var_0 = env_fallback()
        assert type(var_0) == AnsibleFallbackNotFound
    except Exception as exc:
        print(exc)
        return False
    return True


# Generated at 2022-06-24 20:54:23.390346
# Unit test for function set_fallbacks
def test_set_fallbacks():
    args = []
    kwargs = dict()
    kwargs['parameters'] = dict()

    assert set_fallbacks(ARGUMENT_SPEC, dict())
    assert set_fallbacks(ARGUMENT_SPEC, dict())


# Generated at 2022-06-24 20:54:31.398320
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        "param_0": { "fallback": (env_fallback, "param_0") },
        "param_1": {}
    }

    parameters = {
        "param_0": "override",
        "param_1": "override",
        "param_2": "override"
    }

    ansible_module = Mock()
    ansible_module.params = parameters

    no_log_values = set_fallbacks(argument_spec, parameters)

    assert(len(no_log_values) == 1)
    assert("override" not in no_log_values)


# Generated at 2022-06-24 20:54:36.027520
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        "example": {
            "required": False,
            "fallback": (env_fallback, "USERNAME", "USER"),
            "type": "str"
        }
    }

    parameters = {}

    set_fallbacks(argument_spec, parameters)
    assert parameters["example"] == "USERNAME"


# Generated at 2022-06-24 20:54:45.690919
# Unit test for function set_fallbacks

# Generated at 2022-06-24 20:54:55.305603
# Unit test for function set_fallbacks
def test_set_fallbacks():
    spec = {
        'nested': {
            'type': 'dict',
            'options': {
                'module_password': {
                    'type': 'str',
                    'fallback': (env_fallback, 'MODULE_PASSWORD')
                },
                'other': {
                    'type': 'bool',
                    'default': False
                }
            }
        },
        'other': {
            'type': 'bool',
            'default': False
        }
    }

    parameters = {}
    no_log_values = set_fallbacks(spec, parameters)
    assert no_log_values == set([os.environ.get('MODULE_PASSWORD', None)])


# Generated at 2022-06-24 20:55:05.949439
# Unit test for function sanitize_keys
def test_sanitize_keys():
    src_0 = ['no_log_strings'];
    src_1 = ['log_strings'];
    src_2 = ['ignore_keys'];
    src_3 = ['ignore_keys'];

    obj_0 = {'key_0': 'value_0', 'key_1': 'value_1'};
    obj_1 = {'key_0': 'value_0', 'key_1': 'value_1'};
    obj_2 = {'key_0': 'value_0', 'key_1': 'value_1'};
    obj_3 = {'key_0': 'value_0', 'key_1': 'value_1'};

    dest_0 = obj_0;
    dest_1 = obj_1;
    dest_2 = obj_2;
    dest_3 = obj_

# Generated at 2022-06-24 20:55:08.093421
# Unit test for function remove_values
def test_remove_values():
    value = 'This is a test'
    no_log_strings = 'is'
    # Function remove_values should return 'Th a test' in string format
    print(remove_values(value, no_log_strings))


# Generated at 2022-06-24 20:55:17.926412
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Generate test case
    argument_spec = {'var_1': {'type': 'int', 'fallback': (env_fallback, [])}}
    parameters = {'var_0': True}
    expected = {}
    try:
        result = set_fallbacks(argument_spec, parameters)
    except Exception as e:
        assert False, "Calling set_fallbacks with arguments: %s %s\n returns error: %s" % (argument_spec, parameters, e)
    else:
        assert result == expected, "Calling set_fallbacks with arguments: %s %s\n returns: %s, expected: %s" % (argument_spec, parameters, result, expected)


# Generated at 2022-06-24 20:55:20.976316
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'arg_spec': {'fallback': (env_fallback,), 'type': 'dict'}}
    parameters = {}
    set_fallbacks(argument_spec, parameters)

