

# Generated at 2022-06-24 20:46:47.660487
# Unit test for function env_fallback
def test_env_fallback():
    # Test with no value passed
    try:
        test_case_0()
    except AnsibleFallbackNotFound:
        pass


# Generated at 2022-06-24 20:46:53.064606
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'env': {
            'type': 'str',
            'required': True,
            'fallback': (env_fallback, ['ANSIBLE_TEST_VAR_0'])
        }
    }

    parameters = {}
    set_fallbacks(argument_spec, parameters)

    if 'env' not in parameters:
        raise AssertionError("Argument 'env' is not set. Parameters: {0}".format(parameters))


# Generated at 2022-06-24 20:46:57.652727
# Unit test for function sanitize_keys
def test_sanitize_keys():
    test_case_0()
    # deal with parameters
    no_log_strings = '@test'
    ignore_keys = {"this is a test":'asd'}
    # load a var called obj here
    obj = '@test'
    # call the function
    ret = AnsibleUnsafeText('test')
    assert(ret == sanitize_keys(obj, no_log_strings, ignore_keys))


# Generated at 2022-06-24 20:47:04.445323
# Unit test for function set_fallbacks
def test_set_fallbacks():
    """Test for function set_fallbacks"""

    var_0 = {"no_log": False, "type": "bool", "default": True}

# Generated at 2022-06-24 20:47:07.473790
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert type(set_fallbacks(module_argument_spec, {})) is set


# Generated at 2022-06-24 20:47:15.180543
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Setup
    argument_spec = {
        'name': { 
            'type': 'str',
            'fallback': (env_fallback, "ANSIBLE_MODULE_TEST_NAME"),
        },
        'password': {
            'type': 'str',
            'fallback': (env_fallback, "ANSIBLE_MODULE_TEST_PASSWORD"),
            'no_log': True
        }
    }
    parameters = {}

    # Expected result
    expected = {
        'name': 'TEST_NAME',
        'password': 'TEST_PASSWORD'
    }

    os.environ["ANSIBLE_MODULE_TEST_NAME"] = 'TEST_NAME'

# Generated at 2022-06-24 20:47:24.932396
# Unit test for function set_fallbacks

# Generated at 2022-06-24 20:47:28.351234
# Unit test for function sanitize_keys
def test_sanitize_keys():
        arg_0 = env_fallback()
        arg_1 = env_fallback()
        arg_2 = env_fallback()

        # Call function
        retval = sanitize_keys(arg_0, arg_1, arg_2)

        # Check return value
        assert retval == None


# Generated at 2022-06-24 20:47:32.176460
# Unit test for function env_fallback
def test_env_fallback():
    # Generate test_case_0
    global var_0
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    # Generate assertions
    assert True


# Generated at 2022-06-24 20:47:38.733720
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # get this execution file path and change directory to the parent directory of the execution file.
    # The directory change is needed to load the modules and modules data files.
    current_dir = os.path.dirname(os.path.realpath(__file__))
    os.chdir(os.path.join(current_dir, '../..'))
    from ansible.module_utils import basic


# Generated at 2022-06-24 20:48:14.749786
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert('test_case_0' in globals())
    assert(callable(globals()['test_case_0']))



# Generated at 2022-06-24 20:48:22.878879
# Unit test for function set_fallbacks
def test_set_fallbacks():

    # Create an arguments spec that contains no fallbacks
    spec = dict(
        param1=dict(
            type='int'
        ),
        param2=dict(
            type='str'
        )
    )
    params = dict(param1=5, param2='foo')
    no_log_values = set_fallbacks(spec, params)
    assert params == {'param1': 5, 'param2': 'foo'}
    assert no_log_values == set()

    # Create an arguments spec that contains fallbacks
    spec = dict(
        param1=dict(
            type='int',
            fallback=(env_fallback, 'FOO')
        ),
        param2=dict(
            type='str',
            fallback=(env_fallback, 'BAR')
        ),
    )
    os

# Generated at 2022-06-24 20:48:23.666231
# Unit test for function env_fallback
def test_env_fallback():
    assert( test_case_0() == ok )


# Generated at 2022-06-24 20:48:28.315385
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'test': {'type': 'str', 'no_log': True, 'fallback': (env_fallback, 'TEST_VAR1', {'key': 'TEST_VAR2'})}}
    parameters = {}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['test'] == 'foo'
    assert no_log_values == {'foo'}


# Generated at 2022-06-24 20:48:37.663885
# Unit test for function set_fallbacks

# Generated at 2022-06-24 20:48:44.563084
# Unit test for function set_fallbacks
def test_set_fallbacks():
    test_dict = dict()
    test_dict['key_0'] = dict()
    test_dict['key_0']['fallback'] = (env_fallback)
    test_dict['key_1'] = dict()
    test_dict['key_1']['fallback'] = (env_fallback)
    test_dict['key_1']['fallback'].append('variable_str')
    test_dict['key_2'] = dict()
    test_dict['key_2']['fallback'] = (env_fallback)
    test_dict['key_2']['fallback'].append('variable_str')
    test_dict['key_2']['fallback'].append(['1st', '2nd'])

# Generated at 2022-06-24 20:48:54.583117
# Unit test for function set_fallbacks
def test_set_fallbacks():
    params = {}

# Generated at 2022-06-24 20:48:57.514299
# Unit test for function set_fallbacks
def test_set_fallbacks():
    print('in test_set_fallbacks')
    var_0 = {"example": {"type": "str", "fallback": ("bar", "foo")}}
    var_1 = {"example": "foo"}
    var_2 = set_fallbacks(var_0, var_1)
    print('var_2 = {}'.format(var_2))
    print('var_1 = {}'.format(var_1))


# Generated at 2022-06-24 20:48:58.750550
# Unit test for function remove_values
def test_remove_values():
    print("TESTING: remove_values")

    var_0 = test_case_0()



# Generated at 2022-06-24 20:49:04.598174
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert env_fallback('ANSIBLE_HTTPAPI_USE_SSL') == None
    assert env_fallback('ANSIBLE_HTTPAPI_USE_SSL', 'ANSIBLE_HTTPAPI') == None
    assert env_fallback('ANSIBLE_HTTPAPI_USE_SSL', 'ANSIBLE_HTTPAPI_INSECURE', 'ANSIBLE_HTTPAPI') == None
    try:
        env_fallback('ANSIBLE_HTTPAPI_USE_SSL', 'ANSIBLE_HTTPAPI_INSECURE', 'ANSIBLE_HTTPAPI', 'ANSIBLE_HTTPAPI_AUTH')
    except AnsibleFallbackNotFound:
        pass
    else:
        assert False


# Generated at 2022-06-24 20:49:58.895267
# Unit test for function set_fallbacks
def test_set_fallbacks():
    try:
        test_case_0()
    except AnsibleFallbackNotFound:
        pass



# Generated at 2022-06-24 20:50:00.136352
# Unit test for function env_fallback
def test_env_fallback():
    # Testing with empty argument.
    assert test_case_0() == None


# Generated at 2022-06-24 20:50:05.776443
# Unit test for function set_fallbacks
def test_set_fallbacks():
    args = None
    kwargs = {'_ansible_check_mode': False, '_ansible_debug': False, '_ansible_diff': False, '_ansible_keep_remote_files': False, '_ansible_no_log': False, '_ansible_remote_tmp': '~/.ansible/tmp', '_ansible_selinux_special_fs': [], '_ansible_shell_executable': 'sh'}
    spec = {'type': 'path'}
    assert set() == set_fallbacks(spec, {})


# Generated at 2022-06-24 20:50:09.907055
# Unit test for function sanitize_keys
def test_sanitize_keys():
    obj = {'b': 'z', 'a': {'b': 'x', 'a': 'y', 'ignore': ['1']}}
    ignore_keys = {'ignore'}
    no_log_strings = {'secret', 'pass', 'password'}

    sanitize_keys(obj, no_log_strings, ignore_keys)
    #assert obj == {'b': 'z', 'a': {'b': 'x', 'a': 'y', 'ignore': ['1']}}


# Generated at 2022-06-24 20:50:11.356759
# Unit test for function env_fallback
def test_env_fallback():
    assert True == False, "This test needs to be implemented"


# Generated at 2022-06-24 20:50:13.328966
# Unit test for function env_fallback
def test_env_fallback():
    """
    Test case for env_fallback
    """

    # Call the function
    test_case_0()


# Generated at 2022-06-24 20:50:22.410248
# Unit test for function set_fallbacks
def test_set_fallbacks():
    spec = {
        'param1': {'type': 'int', 'default': 3},
        'param2': {'type': 'int', 'default': 5},
        'param3': {'type': 'int'},
        'param4': {'type': 'int'},
        'param5': {'type': 'int', 'fallback': ['test_case_0', {'default': 10}], 'default': 20}
    }
    expected_parameters = {'param1': 3, 'param2': 5, 'param5': 10}

    # Case 1: no parameters
    parameters = {}
    actual_parameters, no_log_values = check_args(spec, parameters)

    assert actual_parameters == expected_parameters
    assert no_log_values == set()

    # Case 2: all parameters set

# Generated at 2022-06-24 20:50:31.617903
# Unit test for function remove_values
def test_remove_values():
    # Test that strings are properly removed
    assert remove_values('This is a test string.', {'t', 'test'}) == 'This is a  string.'

    # Test that tuples work
    assert remove_values(('This is a test.', 'test', 'string'), {'t', 'test'}) == ('This is a .', '', 'string')

    # Test that unicode strings work
    assert remove_values(u'This is a test string', {'t', 'test'}) == u'This is a  string'

    # Test that ints are not affected
    assert remove_values(1, {'t', 'test'}) == 1

    # Test that floats are not affected
    assert remove_values(1.0, {'t', 'test'}) == 1.0

    # Test that bools are not affected


# Generated at 2022-06-24 20:50:35.404892
# Unit test for function env_fallback
def test_env_fallback():
    try:
        test_case_0()
    except AnsibleFallbackNotFound:
        pass
    except Exception as e:
        print("Error: An exception was raised during the testcase test_case_0")
        raise e

# Generated at 2022-06-24 20:50:43.643787
# Unit test for function set_fallbacks

# Generated at 2022-06-24 20:51:13.859046
# Unit test for function set_fallbacks
def test_set_fallbacks():
    var_0 = dict(
        env_fallback=env_fallback)
    test_case_0()
    return True


# Generated at 2022-06-24 20:51:17.387323
# Unit test for function sanitize_keys
def test_sanitize_keys():
    var_0 = {"a":1}
    var_1 = {"b":2}
    var_2 = None
    var_3 = sanitize_keys(var_2, var_0, var_1)



# Generated at 2022-06-24 20:51:20.900402
# Unit test for function sanitize_keys
def test_sanitize_keys():
    obj = var_0
    no_log_strings = var_1
    ignore_keys = var_2
    result = sanitize_keys(obj, no_log_strings, ignore_keys)

    assert(type(result) == type(obj))  


# Generated at 2022-06-24 20:51:23.260461
# Unit test for function env_fallback
def test_env_fallback():
    with pytest.raises(AnsibleFallbackNotFound):
        test_case_0()


# Generated at 2022-06-24 20:51:24.351579
# Unit test for function set_fallbacks
def test_set_fallbacks():

    test_case_0()



# Generated at 2022-06-24 20:51:31.857654
# Unit test for function env_fallback
def test_env_fallback():
    # Each test should have unique instance of ArgumentSpec
    argument_spec = dict(
        a=dict(required=True)
    )

    module = AnsibleModule(
        argument_spec=argument_spec,
        supports_check_mode=True
    )

    result = env_fallback()
    with pytest.raises(AnsibleFallbackNotFound):
        try:
            module.fail_json(msg="Failed")
        except AnsibleFallbackNotFound:
            pass


# Generated at 2022-06-24 20:51:38.770220
# Unit test for function set_fallbacks
def test_set_fallbacks():
    PARAMETERS = {'param2': 'value2'}
    ARGUMENT_SPEC = {'param1': {'required': False, 'type': 'str', 'fallback': (env_fallback, ('vault_param1'))}}
    NO_LOG_VALUES = set_fallbacks(ARGUMENT_SPEC, PARAMETERS)
    assert 'value1' == PARAMETERS['param1']
    assert 'value1' in NO_LOG_VALUES



# Generated at 2022-06-24 20:51:43.210833
# Unit test for function remove_values
def test_remove_values():
    # First test: check that list of lists with integers is modified appropriately
    list_of_lists = [[1], [2], [3]]
    no_log_strings = [2]
    new_value = remove_values(list_of_lists, no_log_strings)
    expected_value = [[1], [], [3]]
    assert new_value == expected_value, 'Error: remove_values should return %s but has returned %s' % (expected_value, new_value)
    # Second test: check that list of lists with strings is modified appropriately
    list_of_lists = [['one'], ['two'], ['three']]
    no_log_strings = ['two']
    new_value = remove_values(list_of_lists, no_log_strings)

# Generated at 2022-06-24 20:51:48.992308
# Unit test for function set_fallbacks
def test_set_fallbacks():
    print("\nTesting function set_fallbacks")
    try:
        richdran.ans.set_fallbacks(var_0)
    except Exception as e:
        print("Unable to run test case set_fallbacks: %s" % e)



# Generated at 2022-06-24 20:51:55.574535
# Unit test for function sanitize_keys
def test_sanitize_keys():
    var_0_0 = env_fallback()

# Generated at 2022-06-24 20:53:11.978699
# Unit test for function env_fallback
def test_env_fallback():

    # Testing with supplied arguments
    assert env_fallback() is None



# Generated at 2022-06-24 20:53:14.035895
# Unit test for function sanitize_keys
def test_sanitize_keys():
    try:
        assert callable(sanitize_keys)
    except AssertionError:
        raise AssertionError('{0} is not callable'.format(sanitize_keys))



# Generated at 2022-06-24 20:53:14.824282
# Unit test for function sanitize_keys
def test_sanitize_keys():
    assert True == True


# Generated at 2022-06-24 20:53:16.842549
# Unit test for function set_fallbacks
def test_set_fallbacks():
    try:
        test_case_0()
    except Exception as e:
        assert str(e) == 'AnsibleFallbackNotFound'


# Generated at 2022-06-24 20:53:25.403580
# Unit test for function set_fallbacks
def test_set_fallbacks():
    spec = dict(
        test_param_0=dict(),
        test_param_1=dict(fallback=(env_fallback,))
    )
    params = dict(
        test_param_0='test_value_0'
    )
    no_log_values = set_fallbacks(spec, params)
    assert len(no_log_values) == 0
    for param, value in spec.items():
        assert params[param] == value.get('default')


# Generated at 2022-06-24 20:53:27.026317
# Unit test for function env_fallback
def test_env_fallback():
    try:
        var_0 = env_fallback()
    except AnsibleFallbackNotFound as e:
        assert True, "Exception raised"


# Generated at 2022-06-24 20:53:38.339931
# Unit test for function sanitize_keys
def test_sanitize_keys():
    def get_sanitized_keys(obj):
        # Get the list of sanitized key names in a container object.
        if isinstance(obj, Mapping):
            return set(obj.keys())
        else:
            return {elem.keys()[0] for elem in obj}

    # Sanitize a string representing a JSON object
    # Test case 1:
    json_str_1 = '{"a": {"b": {"c": "foo"}}}'
    obj_1 = from_json(json_str_1)
    output_1 = get_sanitized_keys(obj_1)
    expected_output_1 = {'a'}

    # Test case 2:
    json_str_2 = '{"a": {"b": {"c": "foo"}, "d": {"e": "bar"}}}'
    obj

# Generated at 2022-06-24 20:53:39.968259
# Unit test for function env_fallback
def test_env_fallback():
    var_0 = None
    try:
        var_0 = env_fallback()
    except AnsibleFallbackNotFound as e:
        var_0 = None
    assert var_0 is None


# Generated at 2022-06-24 20:53:48.527833
# Unit test for function set_fallbacks
def test_set_fallbacks():
    var_0 = dict()
    var_0['name'] = dict()
    var_0['name']['required'] = True
    var_0['name']['description'] = "name of the object you want to create"
    var_0['name']['type'] = "str"
    var_0['name']['no_log'] = True
    var_0['name']['fallback'] = (env_fallback,)
    var_0['name']['env'] = ["ANSIBLE_NET_USERNAME"]

    var_1 = dict()
    var_2 = set()
    var_2 = set_fallbacks(var_0, var_1)



# Generated at 2022-06-24 20:53:56.846314
# Unit test for function env_fallback
def test_env_fallback():
    try:
        var_0 = env_fallback('TESTUNK')
    except AnsibleFallbackNotFound:
        var_0 = None
    if var_0 is not None:
        raise AssertionError("Expected None, got %r" % var_0)
    try:
        var_1 = env_fallback('TESTUNK', 'TESTUNK')
    except AnsibleFallbackNotFound:
        var_1 = None
    if var_1 is not None:
        raise AssertionError("Expected None, got %r" % var_1)

    var_0 = os.environ['TESTUNK'] = '0'
    try:
        var_1 = env_fallback('TESTUNK')
    except AnsibleFallbackNotFound:
        var_1 = None


# Generated at 2022-06-24 20:54:44.787568
# Unit test for function env_fallback
def test_env_fallback():
    # Set up test inputs
    var_0 = None

    # Call function
    var_0 = env_fallback()

    assert var_0 is None


# Generated at 2022-06-24 20:54:46.858935
# Unit test for function env_fallback
def test_env_fallback():
    with pytest.raises(AnsibleFallbackNotFound):
        test_case_0()
#


# Generated at 2022-06-24 20:54:56.840881
# Unit test for function set_fallbacks
def test_set_fallbacks():

    var_0 = env_fallback()
    var_1 = env_fallback('ANSIBLE_NET_USERNAME')
    var_2 = env_fallback('ANSIBLE_NET_USERNAME', 'ANSIBLE_NET_USER')
    var_3 = env_fallback(fallback=('ANSIBLE_NET_USERNAME', 'ANSIBLE_NET_USER'))
    var_4 = env_fallback(fallback=('ANSIBLE_NET_USERNAME', 'ANSIBLE_NET_USER'), default='default')

    assert var_0 == None
    assert var_1 == None
    assert var_2 == None
    assert var_3 == None
    assert var_4 == 'default'



# Generated at 2022-06-24 20:55:00.623523
# Unit test for function env_fallback
def test_env_fallback():
    # If the given environment variable falls back, the function is tested.
    with patch.dict(os.environ, {'ANSIBLE_USERNAME': 'bob'}):
        assert env_fallback('ANSIBLE_USERNAME') == 'bob'


# Generated at 2022-06-24 20:55:04.530928
# Unit test for function env_fallback
def test_env_fallback():
    with pytest.raises(AnsibleFallbackNotFound) as exinfo:
        test_case_0()
    assert "No fallback was found." in exinfo.exconly()


# *************************************************


# Generated at 2022-06-24 20:55:13.354109
# Unit test for function set_fallbacks
def test_set_fallbacks():
    args_list = []
    arg_types = [('argument_spec', dict), ('parameters', dict)]
    arg_values = []

    # Test that behaviour is correct for cases which should be exceptions
    with pytest.raises(Exception) as excinfo:
        set_fallbacks(*args_list)
    assert excinfo.match(r'.*')

    # Test that exception is raised for required param of incorrect type
    for arg, arg_type in zip(args_list, arg_types):
        arg_values.append(gen_arg(arg_type[1]))
        with pytest.raises(Exception):
            set_fallbacks(*arg_values)
        arg_values.pop()
    # Finally, test that function returns expected result
    assert set_fallbacks(*args_list) == None

# Tests for function env

# Generated at 2022-06-24 20:55:19.478207
# Unit test for function sanitize_keys
def test_sanitize_keys():
    obj = {'plain_key': 'value', 'plain_key2': 'value2', 'plain_key_private_value': 'nolog value', 'private_key': 'the_answer'}
    no_log_strings = ['nolog value']

    expected_result = {'plain_key': 'value', 'plain_key2': 'value2', 'plain_key_private_value': 'nolog value'}

    actual_result = sanitize_keys(obj, no_log_strings)
    assert actual_result == expected_result



# Generated at 2022-06-24 20:55:27.651999
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Tests for AnsibleFallbackNotFound

    # Test if valid fallback is found and insert into params
    result = set_fallbacks({"foo" : { "type": "str", "fallback": (env_fallback, 'BAR')}}, {})
    assert len(result) == 0
    assert "foo" in os.environ

    # Test if fallback is not found and does not insert into params
    result = set_fallbacks({"foo" : { "type": "str", "fallback": (env_fallback, 'BAR')}}, {'foo': 1})
    assert len(result) == 0

    # Test if fallback is found, insert into params and then marked as no log

# Generated at 2022-06-24 20:55:38.395862
# Unit test for function set_fallbacks
def test_set_fallbacks():
    var_1 = dict(((k, v) for k, v in os.environ.items() if k == 'k1'))
    # No env var(k1) is set
    var_2 = dict(((k, v) for k, v in os.environ.items() if k == 'k2'))
    # No env var(k2) is set
    var_3 = dict(((k, v) for k, v in os.environ.items() if k == 'k3'))
    # env var(k3) is set to v3
    var_4 = dict(((k, v) for k, v in os.environ.items() if k == 'k4'))
    # env var(k4) is set to v4

# Generated at 2022-06-24 20:55:41.276725
# Unit test for function set_fallbacks
def test_set_fallbacks():
    with pytest.raises(AnsibleFallbackNotFound):
        test_case_0()

