

# Generated at 2022-06-24 20:46:27.948557
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert set_fallbacks == test_case_0


# Generated at 2022-06-24 20:46:29.701621
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Verify that no exception is thrown on the success case
    try:
        set_fallbacks(var_0, var_0)
    except:
        raise Exception('on success case')



# Generated at 2022-06-24 20:46:31.697338
# Unit test for function env_fallback
def test_env_fallback():
    with pytest.raises(AnsibleFallbackNotFound):
        test_case_0()


# Generated at 2022-06-24 20:46:41.659598
# Unit test for function set_fallbacks
def test_set_fallbacks():
    params = {
        'param1': 'from_parameter_1'
    }

    params_empty = {}

    arg_spec = {
        'param1': {
            'default': 'default_parameter',
            'fallback': (env_fallback, [
                'from_environment_1',
            ])
        },
        'param2': {
            'default': 'default_parameter',
            'fallback': (env_fallback, [
                'from_environment_2',
            ])
        },
        'param3': {
            'default': 'default_parameter',
            'fallback': (env_fallback, [
                'from_environment_3',
            ])
        }
    }


# Generated at 2022-06-24 20:46:51.623450
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'fallback_test_1': {'fallback': (env_fallback, 'test_var_1')},
                     'fallback_test_2': {'fallback': (env_fallback, ['fallback_test_1', 'fallback_test_2'])},
                     'fallback_test_3': {'fallback': (env_fallback, ['fallback_test_1', 'fallback_test_2'], {'fallback_test_4': 'fallback_test_5'})},
                     'fallback_test_6': {'fallback': (env_fallback, ['fallback_test_1', 'fallback_test_2'], {'fallback_test_7': 'fallback_test_8'})}
                     }

# Generated at 2022-06-24 20:46:53.251252
# Unit test for function env_fallback
def test_env_fallback():
    ran = False
    try:
        env_fallback()
    except AnsibleFallbackNotFound:
        ran = True
    assert ran


# Generated at 2022-06-24 20:46:58.504090
# Unit test for function set_fallbacks
def test_set_fallbacks():
    global env_fallback
    
    # Test function call
    argument_spec = {"cmd": {"type": "str", "aliases": ["command"]}}
    parameters = {}
    no_log_values = set_fallbacks(argument_spec, parameters)

    # Test function return type
    assert isinstance(no_log_values, set)
    # Test for expected parameter
    assert no_log_values == set()


# Generated at 2022-06-24 20:47:03.376605
# Unit test for function set_fallbacks
def test_set_fallbacks():
    var_0 = 'test_env_fallback'
    var_1 = 0
    os.environ['test_env_fallback'] = str(var_1)

    argument_spec = {
        'arg': {
            'type': 'str',
            'required': True,
            'fallback': (env_fallback, ('test_env_fallback',))
        }
    }

    parameters = {
    }

    set_fallbacks(argument_spec, parameters)
    assert var_1 == parameters['arg']



# Generated at 2022-06-24 20:47:05.131372
# Unit test for function env_fallback
def test_env_fallback():
    obj = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True,
    )

    assert test_case_0() == obj.exit_json()


# Generated at 2022-06-24 20:47:06.476774
# Unit test for function sanitize_keys
def test_sanitize_keys():
    with pytest.raises(AnsibleFallbackNotFound) as excinfo:
        test_case_0()
    assert 'AnsibleFallbackNotFound' in str(excinfo.value)

# Generated at 2022-06-24 20:47:37.339728
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # https://github.com/ansible/ansible-modules-core/pull/4607/checks?check_run_id=329419182#step:8:853
    # Var 0
    var_0 = {'param1': {'type': 'str', 'default': '', 'no_log': False, 'fallback': (env_fallback, ('ANSIBLE_TEST_VAR', 'ANSIBLE_TEST_VAR2'))}}
    params = {}
    no_log_values = set_fallbacks(var_0, params)
    assert(no_log_values == set())
    assert(params == {'param1': ''})

    params['param1'] = 'foo'
    no_log_values = set_fallbacks(var_0, params)

# Generated at 2022-06-24 20:47:44.816284
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'x':
            {'type': 'int'},
        'y':
            {'type': 'str', 'fallback': (env_fallback, 'hello')},
    }
    parameters = {
        'x': '10',
    }
    set_fallbacks(argument_spec, parameters)
    assert(parameters['x'] == 10)
    # In case no environment variable found, fallback does not add parameter to dict
    assert(not parameters.__contains__('y'))
    os.environ['hello'] = 'world'
    set_fallbacks(argument_spec, parameters)
    assert(parameters['y'] == 'world')


# Generated at 2022-06-24 20:47:49.877218
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'my_param': {'type': 'str', 'choices': ['a', 'b']}, 'my_param2': {'type': 'str', 'choices': ['a', 'b'], 'fallback': (env_fallback, 'MY_PARAM')}}
    parameters = {'my_param': 'a'}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters['my_param2'] == 'b'
    assert no_log_values == set()



# Generated at 2022-06-24 20:47:55.517387
# Unit test for function sanitize_keys
def test_sanitize_keys():
    # Basic test
    var_0 = [{'b': '1', 'c': '2', 'd': '3', 'e': '4'}]
    var_1 = sanitize_keys(var_0, no_log_strings=['d'])

    assert var_1 == [{'b': '1', 'c': '2', 'e': '4'}]

    # More complex test
    var_2 = [{'b': '1', 'c': '2', 'd': '3', 'e': '4'}, {'b': '1', 'c': '2', 'd': '3', 'e': '4'}, {'b': '1', 'c': '2', 'd': '3', 'e': '4'}]

# Generated at 2022-06-24 20:47:56.468976
# Unit test for function set_fallbacks
def test_set_fallbacks():
    assert callable(set_fallbacks)


# Generated at 2022-06-24 20:47:59.489443
# Unit test for function set_fallbacks
def test_set_fallbacks():
    print('Testing function set_fallbacks')

    parameters = {}
    set_fallbacks(argument_spec, parameters)

    assert parameters is not None
    assert parameters['fetch_content'] == True
    assert parameters['validate_certs'] == False
    assert parameters['umask'] == '02'
    assert parameters['mode'] == '0777'


# Generated at 2022-06-24 20:48:05.406906
# Unit test for function env_fallback
def test_env_fallback():
    # Test for ModuleNotFoundError
    with pytest.raises(ModuleNotFoundError) as test_error:
        test_case_0()
    assert "No module named 'ansible'" in str(test_error.value)

    # Test for TypeError
    with pytest.raises(TypeError) as test_error:
        env_fallback(1)
    assert "expected string or buffer" in str(test_error.value)


# Generated at 2022-06-24 20:48:10.875085
# Unit test for function set_fallbacks
def test_set_fallbacks():

    # argument spec -> param name -> expected value
    cases = {
        'test_case_0': {

        },
    }

    for case in cases:
        case_function = globals()[case]
        case_parameters = cases[case]
        for parameter, expected_value in case_parameters.items():
            result = case_function()


# Generated at 2022-06-24 20:48:17.097347
# Unit test for function remove_values
def test_remove_values():
    # Remove values in lists and tuples
    test_value_1 = ['test', 'encrypted_value']
    test_value_2 = ('test', 'encrypted_value')
    test_value_3 = ['test', ['encrypted_value']]
    test_value_4 = ['test', ('encrypted_value')]
    test_value_5 = ['test', {'test': 'encrypted_value'}]
    test_value_6 = ['test', {'test': ['encrypted_value']}]
    test_value_7 = ['test', {'test': ('encrypted_value')}]
    test_no_log_values = set('encrypted_value')
    assert remove_values(test_value_1, test_no_log_values) == ['test', 'VALUE_SPECIFIED_IN_NO_LOG_PARAMETER']

# Generated at 2022-06-24 20:48:19.097987
# Unit test for function set_fallbacks
def test_set_fallbacks():
    try:
        test_case_0()
    except AnsibleFallbackNotFound as exc:
        pass
    else:
        fail('The AnsibleFallbackNotFound exception was not raised.')



# Generated at 2022-06-24 20:48:39.574466
# Unit test for function sanitize_keys
def test_sanitize_keys():
    #  call function
    test_case_0()



# Generated at 2022-06-24 20:48:48.481877
# Unit test for function set_fallbacks
def test_set_fallbacks():
    var_0 = env_fallback()
    # Case 1
    var_0 = env_fallback
    var_1 = {}
    argument_spec = {
        "var_0": {
            "type": "str",
            "fallback": (env_fallback, )
        }
    }
    parameters = {
    }
    set_fallbacks(argument_spec, parameters)
    assert parameters["var_0"] == var_0
    # Case 2
    var_0 = env_fallback
    var_1 = {}
    var_1["foo"] = "bar"
    argument_spec = {
        "var_0": {
            "type": "str",
            "fallback": (env_fallback, var_1)
        }
    }
    parameters = {
    }
    set_

# Generated at 2022-06-24 20:48:50.623279
# Unit test for function env_fallback
def test_env_fallback():
    args = []
    kwargs = {}
    try:
        res = env_fallback(**kwargs)
    except Exception as err:
        res = str(err)
    assert isinstance(res, AnsibleFallbackNotFound)


# Generated at 2022-06-24 20:48:55.144673
# Unit test for function set_fallbacks
def test_set_fallbacks():
    var_0 = {'elements': 'dict', 'type': 'list', 'options': {'version': {'type': 'int'}, 'state': {'choices': ['present', 'absent'], 'type': 'str'}}}
    var_1 = {'version': 1}
    expected = set_fallbacks(var_0, var_1)
    assert expected is not None


# Generated at 2022-06-24 20:48:58.541550
# Unit test for function remove_values
def test_remove_values():
    var_1 = 'var_1'
    var_2 = 'var_2'
    arg_1 = dict()
    arg_2 = []
    arg_2.append(var_1)
    arg_1['var_1'] = var_1
    arg_1['var_2'] = var_2
    arg_2.append(arg_1)
    assert remove_values(arg_1,['var_1']) == {'var_2': 'var_2'}
    assert remove_values(arg_2,['var_1', 'var_2']) == [{}, {}]


# Generated at 2022-06-24 20:49:00.733612
# Unit test for function env_fallback
def test_env_fallback():
    try:
        test_case_0()
    except NameError:
        print("Can not test env_fallback()")


# Generated at 2022-06-24 20:49:04.378398
# Unit test for function env_fallback
def test_env_fallback():

    # Ensure that we can convert the fallback to a string
    assert isinstance(env_fallback, string_types)


# Generated at 2022-06-24 20:49:14.571547
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Do it
    # Set up
    argument_spec = {'param_0': {'fallback': (env_fallback,)},
                     'param_1': {'fallback': (env_fallback, 'param_1')},
                     'param_2': {'fallback': (env_fallback, 'param_2', {'fallback_key': 'fallback_value'})}}
    parameters = {}

    # Execute
    no_log_values = set_fallbacks(argument_spec, parameters)

    # Verify
    assert no_log_values == set()
    # Test that not set
    assert 'param_0' not in parameters
    assert 'param_1' not in parameters
    assert 'param_2' not in parameters

    # Set up

# Generated at 2022-06-24 20:49:19.491127
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Expected result:
    specs = dict(argument_spec={'fallback': dict(fallback=(env_fallback,))})
    expected_result = set()
    assert set_fallbacks(specs['argument_spec'], {}) == expected_result


# Generated at 2022-06-24 20:49:30.140504
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Unit test for set_fallbacks
    # Ensure fallback is set for any parameter not in parameters

    argument_spec = {'foo': {'type': 'str', 'fallback': (env_fallback, ['FOO_VAR'])}}
    parameters = {}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert parameters.get('foo') == 'bar'
    assert no_log_values == set()

    parameter_b_value = 'bar'
    argument_spec = {'foo': {'type': 'str', 'fallback': (env_fallback, ['FOO_VAR'])},
                     'bar': {'type': 'str', 'fallback': param_b_value}}
    parameters = {'foo': 'foo'}
    no_log_values = set_fall

# Generated at 2022-06-24 20:50:07.325487
# Unit test for function set_fallbacks
def test_set_fallbacks():
    var_0 = {}
    var_1 = {'param1': {'type': 'str', 'fallback': (env_fallback, 'you should use env var first')}}
    var_2 = {'param2': {'type': 'str', 'fallback': (env_fallback, 'you should use env var first', {'fallback': (env_fallback, 'you should use env var first')})}}
    var_3 = {'param3': {'type': 'str', 'fallback': (env_fallback, 'you should use env var first', {'fallback': (env_fallback, 'you should use env var first', {'fallback': (env_fallback, 'you should use env var first')})})}}

# Generated at 2022-06-24 20:50:16.964150
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'param_0': {'fallback': [env_fallback], 'type': 'str'}}
    parameters = {'param_0': 'value_0'}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert no_log_values == set([])
    assert parameters['param_0'] == 'value_0'

    del(parameters['param_0'])
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert no_log_values == set([])
    assert parameters.get('param_0') is None

    argument_spec = {'param_0': {'fallback': [env_fallback], 'type': 'str', 'no_log': True}}
    parameters = {'param_0': 'value_0'}

# Generated at 2022-06-24 20:50:21.709919
# Unit test for function env_fallback
def test_env_fallback():
    print("Testing env_fallback")
    # Try to load value from an environment variable. We need to do this on a variable which is not set
    try:
        test_case_0()
        assert False, "AnsibleFallbackNotFound not thrown"
    except AnsibleFallbackNotFound:
        pass
    # Return code should be 0
    assert True


# Generated at 2022-06-24 20:50:24.529242
# Unit test for function set_fallbacks
def test_set_fallbacks():
    from ansible.module_utils.common._collections_compat import Mapping
    argument_spec = {'var_0': {'type': 'str', 'no_log': True, 'fallback': (env_fallback,)}}
    expected_result = test_case_0()
    result = set_fallbacks(argument_spec, {})
    assert isinstance(result, Mapping)
    assert_equals(result, expected_result)


# Generated at 2022-06-24 20:50:28.521963
# Unit test for function env_fallback
def test_env_fallback():
    var_0 = env_fallback()


# Generated at 2022-06-24 20:50:33.311416
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'var1': {'default': 'var1_def', 'fallback': (env_fallback, 'VAR1')},
        'var2': {'default': 'var2_def', 'fallback': (env_fallback, 'VAR2')},
        'var3': {'default': 'var3_def', 'fallback': (env_fallback, 'VAR3')},
        'var4': {'default': 'var4_def', 'fallback': (env_fallback, 'VAR4')},
    }
    parameters = {
        'var1': 'v1',
        'var2': 'v2',
        'var3': 'v3',
        'var4': 'v4',
    }

# Generated at 2022-06-24 20:50:40.319927
# Unit test for function set_fallbacks
def test_set_fallbacks():
    fallbacks = {
        'foo': {'fallback': (env_fallback, 'FOO')},
        'bar': {'fallback': (env_fallback, ['BAR_1', 'BAR_2'])},
        'baz': {'fallback': (env_fallback, ['BAZ_1', 'BAZ_2'], {'key': 'value'})}
    }
    no_log_values = set_fallbacks(fallbacks, {})
    assert not len(no_log_values)
    assert 'foo' not in os.environ
    assert 'FOO' in os.environ
    assert 'bar' not in os.environ
    assert 'BAR_1' in os.environ
    assert 'BAZ_2' not in os.environ
    assert 'bar'

# Generated at 2022-06-24 20:50:42.340756
# Unit test for function env_fallback
def test_env_fallback():
    assert test_case_0() == AnsibleFallbackNotFound


# Generated at 2022-06-24 20:50:50.636092
# Unit test for function set_fallbacks
def test_set_fallbacks():
    params = {'hostname': 'localhost'}
    args = {'hostname': {'type': 'str', 'required': True, 'default': 'localhost'}, 'password': {'type': 'str', 'required': True, 'fallback': (env_fallback, ['ANSIBLE_NET_PASSWORD'])}}
    new_params, no_log_values = set_fallbacks(args, params)
    assert new_params['hostname'] == params['hostname']
    assert new_params['password'] == params['password']
    assert no_log_values == set()


# Generated at 2022-06-24 20:50:52.255513
# Unit test for function set_fallbacks

# Generated at 2022-06-24 20:51:53.272330
# Unit test for function set_fallbacks
def test_set_fallbacks():
    mock_module0 = AnsibleModule(argument_spec={'var_0': {'type': 'str', 'fallback': (env_fallback,), 'no_log': True}, 'var_1': {'type': 'str', 'fallback': (env_fallback, {'arg_1': 'mock_env_1'}), 'no_log': True}, 'var_2': {'type': 'str', 'fallback': (env_fallback, ['mock_env_2']), 'no_log': True}})
    test_case_0()


# Generated at 2022-06-24 20:52:03.168741
# Unit test for function set_fallbacks
def test_set_fallbacks():
    """Validate the set_fallbacks function"""

# Generated at 2022-06-24 20:52:12.721986
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = dict(
        foo=dict(type='str', fallback=(env_fallback, 'FOO_VAR', 'FOO_VAR2')),
        bar=dict(type='str', fallback=(env_fallback, 'BAR_VAR'))
    )
    parameters = {
        'foo': 'FOO_VAR_VALUE',
        'baz': 'BAZ_VAR_VALUE'
    }

    no_log_values = set_fallbacks(argument_spec, parameters)

    assert no_log_values == {'FOO_VAR_VALUE', 'BAR_VAR_VALUE'}
    assert parameters['foo'] == 'FOO_VAR_VALUE'
    assert parameters['bar'] == 'BAR_VAR_VALUE'

# Generated at 2022-06-24 20:52:22.765088
# Unit test for function set_fallbacks
def test_set_fallbacks():
    module_args_0 = frozenset()
    module_args_1 = [('key_1', 'val_1')]

    module_args_2 = frozenset()
    module_args_3 = [('key_3', 'val_3')]
    module_args_4 = frozenset()
    module_args_5 = [('key_5', 'val_5')]

    module_args_6 = ('key_6', 'val_6')
    module_args_7 = [('key_7', 'val_7')]
    module_args_8 = [('key_8', 'val_8')]
    module_args_9 = [('key_9', 'val_9')]
    module_args_10 = [('key_10', 'val_10')]

    module_args_

# Generated at 2022-06-24 20:52:25.833352
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Argument spec for function set_fallbacks
    argument_spec = dict(
        argument_spec=dict(type='dict', required=True),
        parameters=dict(type='dict', required=True)
    )

    # Fail due to missing arguments
    with pytest.raises(TypeError):
        set_fallbacks()


# Generated at 2022-06-24 20:52:33.667848
# Unit test for function remove_values

# Generated at 2022-06-24 20:52:35.869382
# Unit test for function remove_values
def test_remove_values():
    for arg0, arg1 in (('arg0', 'arg1'), ('arg0', 'arg1'), (1, 'arg1'), ('arg0', 2)):
        if isinstance(remove_values(arg0, arg1), str):
            print("")


# Generated at 2022-06-24 20:52:39.584903
# Unit test for function env_fallback
def test_env_fallback():
    try:
        # Testing with no arguments.
        test_case_0()
        assert False, 'test case 0 FAILED'
    except AnsibleFallbackNotFound as exception:
        assert True, 'test case 0 PASSED'


# Generated at 2022-06-24 20:52:48.796995
# Unit test for function set_fallbacks
def test_set_fallbacks():
    spec = {
        'param': {'type': 'int'},
        'param2': {'type': 'str', 'fallback' : (env_fallback, ['ANSIBLE_FOO_BAR'])},
        'param3': {'type': 'str', 'fallback' : (env_fallback, ['ANSIBLE_FOO_BAR'])},
        'param4': {'type': 'str', 'fallback' : (env_fallback, [{'default': 'foo', 'somekey': 'somevalue'}])},
        'param5': {'type': 'str', 'fallback' : (env_fallback, [{'default': 'foo'}])}
    }

    params = {'param': 1}
    assert set_fallbacks(spec, params) == set()
    assert params

# Generated at 2022-06-24 20:52:57.004888
# Unit test for function set_fallbacks
def test_set_fallbacks():
    # Set argument spec
    # argument spec
    # dictionary of parameter name and argument type
    # value of None means not present
    argument_spec = dict(
        a=dict(required=True, type='str'),
        c=dict(required=False, type='str', fallback=(env_fallback, ['JUST_A_TEST'], None)),
        c2=dict(required=False, type='str', fallback=(env_fallback, ['NOT_EXISTS'], None)),
        d=dict(required=False, type='str', fallback=(test_case_0, [], None)),
        e=dict(required=False, type='str', fallback=(env_fallback, ['NOT_EXISTS'], dict(arg1='1', arg2='2')))
    )

    # Set parameters
    # dictionary

# Generated at 2022-06-24 20:53:50.740888
# Unit test for function set_fallbacks
def test_set_fallbacks():
    var_0 = env_fallback()
    assert var_0 is None, "did not return the expected value"
    filename = os.path.basename(__file__)
    data = '\n'.join(open(filename).readlines())
    assert re.search(r'\bvar_0\s*=\s*env_fallback\(\)', data, re.DOTALL | re.MULTILINE) is None, "set_fallbacks called without arguments"

# Generated at 2022-06-24 20:53:54.271399
# Unit test for function set_fallbacks
def test_set_fallbacks():
    var_0 = {}
    set_fallbacks(
        [{
            'fallback': {
                'msg': 'Please specify fallback_key',
                'function': env_fallback,
                'args': ['fallback_key']
            }
        }],
        var_0
    )
    assert var_0 == {}


# Generated at 2022-06-24 20:54:02.703544
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {'param1': {'type': 'str', 'fallback': (env_fallback, ['TEST_ENV1'])}, 'param2': {'type': 'str'}}
    parameters = {'param2': 2}
    no_log_values = set()
    no_log_values.update(set_fallbacks(argument_spec, parameters))
    assert(no_log_values == {})



# Generated at 2022-06-24 20:54:12.758251
# Unit test for function remove_values
def test_remove_values():
    list_0 = [0, 'a', 'b', 'c', 'd', 'e', 'f']
    list_1 = ['a', 'b', 'c', 'd', 'e', 'f', 0]
    set_0 = {'a', 0, 'e', 'f', 'd', 'b', 'c'}
    set_1 = {0, 'a', 'b', 'c', 'd', 'e', 'f'}
    dict_0 = {0: 'a', 'f': 'c', 'g': 'b', 'h': 'e', 'i': 'd', 'j': 'f'}
    dict_1 = {'a': 0, 'b': 'g', 'c': 'f', 'd': 'i', 'e': 'h', 'f': 'j'}
    tuple_0

# Generated at 2022-06-24 20:54:15.898997
# Unit test for function env_fallback
def test_env_fallback():
    wanted = AnsibleFallbackNotFound

    try:
        env_fallback()
    except Exception as ex:
        result = type(ex)

    assert(result == wanted)


# Generated at 2022-06-24 20:54:17.100159
# Unit test for function env_fallback
def test_env_fallback():
    assert env_fallback() is None


# Generated at 2022-06-24 20:54:23.149415
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {
        'test': {
            'type': 'str',
            'default': 'no',
            'fallback': (env_fallback, 'TEST_VAR')
        }
    }
    parameters = {}
    no_log_values = set_fallbacks(argument_spec, parameters)
    assert {'no'} == no_log_values
    assert parameters.get('test') == 'no'


# Generated at 2022-06-24 20:54:32.749912
# Unit test for function set_fallbacks

# Generated at 2022-06-24 20:54:34.042378
# Unit test for function env_fallback
def test_env_fallback():
    assert not test_case_0()



# Generated at 2022-06-24 20:54:44.132742
# Unit test for function set_fallbacks
def test_set_fallbacks():
    var_0 = dict(ansible_host=["10.0.0.1"], ansible_timeout=30, ansible_verbosity=None)
    var_1 = dict(ansible_port=None, ansible_user="ansible", ansible_password=None, ansible_become=False, ansible_become_method=None, ansible_become_user=None)
    var_2 = dict(ansible_host=["10.0.0.1"], ansible_port=22, ansible_timeout=30, ansible_user="ansible", ansible_password="password", ansible_become=False, ansible_become_method=None, ansible_become_user=None)

# Generated at 2022-06-24 20:55:35.430255
# Unit test for function env_fallback
def test_env_fallback():
    var_0 = env_fallback()
    env_fallback()
    assert var_0 == None


# Generated at 2022-06-24 20:55:44.972078
# Unit test for function remove_values
def test_remove_values():
    assert remove_values('uhoh', ['uh', 'oh']) == '**'
    assert remove_values('', ['uh', 'oh']) == ''
    assert remove_values([u'this', u'is', u'uhoh', u'', u'nested'], ['uh', 'oh']) == [u'this', u'is', u'**', u'', u'nested']
    assert remove_values(42, ['uh', 'oh']) == 42
    assert remove_values(True, ['uh', 'oh']) == True
    assert remove_values(False, ['uh', 'oh']) == False
    assert remove_values({u'password': u'foobar'}, ['uh', 'oh']) == {u'password': u'**'}

# Generated at 2022-06-24 20:55:46.175216
# Unit test for function set_fallbacks
def test_set_fallbacks():
    set_fallbacks()



# Generated at 2022-06-24 20:55:47.328485
# Unit test for function env_fallback
def test_env_fallback():
    var_0 = env_fallback()


# Generated at 2022-06-24 20:55:51.242331
# Unit test for function set_fallbacks
def test_set_fallbacks():
    argument_spec = {}
    parameters = {}
    no_log_values = set_fallbacks(argument_spec, parameters)
    # isinstance(no_log_values, set)
    print('Test set_fallbacks:')
    print('\tType of no_log_values:', type(no_log_values))

# Main to run test cases

# Generated at 2022-06-24 20:55:58.836963
# Unit test for function env_fallback
def test_env_fallback():
    # Calling env_fallback with no arguments
    assert env_fallback()
    # Test with invalid values for argument 'options'
    var_0 = {"ssh_args": "", "key_file": "", "ssh_user": "root", "bastion": ""}
    for value in var_0:
        with pytest.raises(AnsibleFallbackNotFound):
            env_fallback(value)
    # Test with invalid values for argument 'parameters'
    var_1 = None
    assert env_fallback(var_1)
    # Test with invalid values for argument 'option'
    var_2 = ""
    assert env_fallback(var_2)
