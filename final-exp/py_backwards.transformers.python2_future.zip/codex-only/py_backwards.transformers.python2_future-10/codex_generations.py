

# Generated at 2022-06-23 22:48:21.962927
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-23 22:48:24.039361
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    try:
        Python2FutureTransformer()
    except:
        raise Exception("Unable to create a Python2FutureTransformer")


# Generated at 2022-06-23 22:48:25.405011
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()
    assert t.target == (2, 7)

# Generated at 2022-06-23 22:48:32.579304
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    tr = Python2FutureTransformer()
    tree_src = """\
    def f(x):
        return x
    """
    tree_expect = """\
    from __future__ import absolute_import
    
    from __future__ import division
    
    from __future__ import print_function
    
    from __future__ import unicode_literals
    
    
    def f(x):
        return x
    """
    tree = ast.parse(textwrap.dedent(tree_src))
    tr.visit(tree)
    assert ast.dump(tree) == tree_expect

# Generated at 2022-06-23 22:48:38.000366
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    node = ast.parse('a=1')
    Python2FutureTransformer().visit(node)
    assert ast.dump(node) == \
        dedent('''
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        a=1''')

# Generated at 2022-06-23 22:48:47.368261
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..transpile_function import TranspileFunction

    def test_func(a: int, b: int) -> int:
        pass

    t = TranspileFunction(
        func=test_func, target=target_info(major=2, minor=7), pyversion=target_info(major=3, minor=8)
    )
    t.transpile()
    assert t.source_code.startswith('from __future__ import absolute_import\n'
                                    'from __future__ import division\n'
                                    'from __future__ import print_function\n'
                                    'from __future__ import unicode_literals\n\ndef test_func(')

# Generated at 2022-06-23 22:48:57.166745
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.syntaxtree import SyntaxTree
    from ..utils.source import Source

    source = Source(textwrap.dedent(
    """
    # comment 1
    '''docstring 1'''
    print('Hello World!')
    # comment 2
    '''docstring 2'''
    """
    ))
    syntax_tree = SyntaxTree(source)
    python2_future_transformer = Python2FutureTransformer()

    syntax_tree.root_node = python2_future_transformer.visit(syntax_tree.root_node)
    assert syntax_tree.root_node.body[0].body[0].value.s == 'absolute_import'
    assert syntax_tree.root_node.body[0].body[2].value.s == 'division'



# Generated at 2022-06-23 22:48:58.751472
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__doc__ is not None


# Generated at 2022-06-23 22:49:07.005104
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    source = textwrap.dedent("""
        import typing
        a = 3/2
        print(a)
    """)
    expected_output = textwrap.dedent("""
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

        import typing
        a = 3/2
        print(a)
    """)

    tree = ast.parse(source)
    tree2 = Python2FutureTransformer().visit(tree)

    assert ast.dump(tree) != ast.dump(tree2)
    assert ast.dump(tree2) == ast.dump(ast.parse(expected_output))

# Generated at 2022-06-23 22:49:08.058157
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-23 22:49:16.534035
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    test_Python2FutureTransformer.__name__ = "test_Python2FutureTransformer"
    transformer = Python2FutureTransformer()
    test_file_dir = os.path.dirname(__file__)
    test_file = os.path.join(test_file_dir, 'test_files/two_from_imports.py')
    with open(test_file, 'r') as test_file:
        source_code = test_file.read()
    tree = ast.parse(source_code)
    new_tree = transformer.visit(tree)
    new_source = astunparse.unparse(new_tree)

# Generated at 2022-06-23 22:49:20.058029
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer.target == (2, 7)
    assert Python2FutureTransformer().target == (2, 7)

# Generated at 2022-06-23 22:49:24.597085
# Unit test for constructor of class Python2FutureTransformer

# Generated at 2022-06-23 22:49:30.924780
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.syntax_tree import SyntaxTree
    from textwrap import dedent
    tree = SyntaxTree(dedent('''
        def func():
            pass
    '''), target=(2, 7))
    assert tree.target == (2, 7)
    transformer = Python2FutureTransformer()

    node = tree.module
    transformer.visit(node)
    assert transformer.changed
    assert transformer.target == (2, 7)
    assert tree.target == (2, 7)
    assert isinstance(node, ast.Module)
    assert isinstance(node.body[0], ast.ImportFrom)

    assert transformer._tree_changed
    assert transformer._tree is tree

# Generated at 2022-06-23 22:49:39.982918
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    from .utils import roundtrip, compare_trees

    tree = ast.parse('''
    def func(arg):
        return arg
        
    print(func(1))
    ''')

    tree = roundtrip(tree)
    tree = Python2FutureTransformer().visit(tree) # type: ignore
    compare_trees(tree, ast.parse('''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    def func(arg):
        return arg
        
    print(func(1))
    '''))

# Generated at 2022-06-23 22:49:41.439677
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    trans = Python2FutureTransformer()
    assert trans.target == (2, 7)

# Generated at 2022-06-23 22:49:50.685014
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    transformer = Python2FutureTransformer(target=(2, 7))
    node = ast.Module(body=[
        ast.Print(
            dest=None,
            values=[
                ast.Str(s='Hello\n'),
            ],
            nl=False,
        ),
        ast.Expr(
            value=ast.Call(
                func=ast.Name(id='print', ctx=ast.Load()),
                args=[
                    ast.Str(s='Hello\n'),
                ],
                keywords=[],
                starargs=None,
                kwargs=None,
            ),
        ),
    ])

# Generated at 2022-06-23 22:49:52.296376
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)


# Generated at 2022-06-23 22:49:56.356370
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse('')   # type: ignore
    assert len(node.body) == 0
    node = Python2FutureTransformer().visit(node)  # type: ignore
    assert len(node.body) == 4

# Generated at 2022-06-23 22:50:06.578189
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    node = ast.parse("""
        def f():
            pass
    """)  # type: ast.Module
    Python2FutureTransformer().visit(node)

# Generated at 2022-06-23 22:50:11.313475
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    test_ast = ast.parse('x = 1')
    future_ast = ast.parse(imports.get_source(future='__future__'))
    for i, import_ in enumerate(future_ast.body):
        test_ast.body.insert(i, import_)

    assert test_Python2FutureTransformer_visit_Module.__doc__ == \
        ast.dump(test_ast, include_attributes=True)

# Generated at 2022-06-23 22:50:15.864840
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    import astor
    module = ast.parse('')
    trans = Python2FutureTransformer()
    node = trans.visit(module)
    actual = astor.to_source(node)
    expected = 'from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n'
    assert actual == expected


# Generated at 2022-06-23 22:50:25.729036
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    mod = ast.parse("print('hello')")
    transformed_ = Python2FutureTransformer().visit(mod)
    assert "from future import absolute_import" in ast.dump(mod)
    assert "from future import division" in ast.dump(mod)
    assert "from future import print_function" in ast.dump(mod)
    assert "from future import unicode_literals" in ast.dump(mod)
    assert "from __future__ import absolute_import" in ast.dump(mod)
    assert "from __future__ import division" in ast.dump(mod)
    assert "from __future__ import print_function" in ast.dump(mod)
    assert "from __future__ import unicode_literals" in ast.dump(mod)
    assert "print('hello')" in ast.dump(mod)

# Generated at 2022-06-23 22:50:32.843021
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    tree = ast.parse(imports.template)
    expected = ast.parse('''
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

from future import absolute_import
from future import division
from future import print_function
from future import unicode_literals
    ''')
    transformer = Python2FutureTransformer()
    actual = transformer.visit(tree)
    assert ast.dump(expected) == ast.dump(actual)

# Generated at 2022-06-23 22:50:40.743433
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3
    from typed_ast.ast3 import Module
    from tartiflette.types.exceptions.tartiflette import InvalidIntrospectionQuery
    from tartiflette.types.exceptions.tartiflette import MissingIntrospectionField

    with open('test_Python2FutureTransformer_visit_Module.py') as f:
        test_file_content = f.read()

    module = ast3.parse(test_file_content) # type: ignore

    assert type(module) == Module

    transformer = Python2FutureTransformer()
    module = transformer(module) # type: ignore

    assert module.body[0].value.value == 'absolute_import'
    assert module.body[1].value.value == 'division'

# Generated at 2022-06-23 22:50:46.523634
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    c = Python2FutureTransformer
    assert c.target == (2, 7)
    assert c.__name__ == 'Python2FutureTransformer'
    assert issubclass(c, BaseNodeTransformer)


# Generated at 2022-06-23 22:50:50.754510
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    node = ast.parse('x = 3')
    assert Python2FutureTransformer().visit(node) is not None



# Generated at 2022-06-23 22:50:56.114900
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():

    obj = Python2FutureTransformer()
    test_transformer_class(obj,
                           'Python2FutureTransformer',
                           'Module',
                           'pass\n',
                           [
                            ('Module', 'Module'),
                            ('Pass', 'Pass'),
                            ('Load', 'Load'),
                            ('None', 'None'),
                           ],
    )

# Generated at 2022-06-23 22:50:58.328139
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert str(imports) == "from future import absolute_import\nfrom future import division\nfrom future import print_function\nfrom future import unicode_literals\n"
    

# Generated at 2022-06-23 22:51:03.714178
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    code = """
            import os
            import sys

            def f(a, b, c):
                e = d * (a + b)
                return e

            f(1, 2, 3)
            """
    expected_code = """
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals

            import os
            import sys

            def f(a, b, c):
                e = d * (a + b)
                return e

            f(1, 2, 3)
            """
    tree = ast.parse(code)
    transformer = Python2FutureTransformer()
    tree = transformer.visit(tree)
    assert astor.to_source(tree) == expected_code

# Generated at 2022-06-23 22:51:05.470259
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    src=''
    assert Python2FutureTransformer().visit(ast.parse(src), ()) == src

# Generated at 2022-06-23 22:51:15.378904
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import os.path
    import unittest
    import unittest.mock
    from ..utils import source_to_ast, transform
    transformer = Python2FutureTransformer()

    class Target(unittest.TestCase):
        def test_module(self):
            path = os.path.dirname(__file__)
            file_path = os.path.join(path, '../../snippets/python2/module.py')
            source = open(file_path).read()
            ast_module_source = source_to_ast(source)
            ast_module_target = source_to_ast(transform(transformer, source))
            self.assertEqual(ast_module_source, ast_module_target)

    test = unittest.mock.Mock()
    suite = unittest.Test

# Generated at 2022-06-23 22:51:16.234664
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()


# Generated at 2022-06-23 22:51:20.434776
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from textwrap import dedent
    from typed_ast import ast3 as ast
    from .utils import run_transformer_test

    content = dedent('''
        import sys
        import os
    ''')
    expected = dedent('''
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        import sys
        import os
    ''')
    transformer = Python2FutureTransformer()

    run_transformer_test(transformer, content, expected)

# Generated at 2022-06-23 22:51:23.620581
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.test_utils import transform
    # Note that the first 4 lines are copied from the imports.py snippet

# Generated at 2022-06-23 22:51:24.369646
# Unit test for constructor of class Python2FutureTransformer

# Generated at 2022-06-23 22:51:28.386500
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # given,
    transformer = Python2FutureTransformer()

    # when,
    result = transformer.visit(ast.parse('def foo(): pass'))

    # then,
    assert isinstance(result, ast.Module)
    assert imports.get_code() + '\n' + 'def foo(): pass\n' == compile(result, '<test>', 'exec')



# Generated at 2022-06-23 22:51:33.789527
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    input_txt = """
print("Hello World")
""".strip()
    expected_txt = """
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
print("Hello World")
""".strip()
    assert expected_txt == Python2FutureTransformer().visit(ast.parse(input_txt)).as_string()

# Generated at 2022-06-23 22:51:39.348287
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # Test if imports are prepended to module.
    module = ast.parse("print('hello world')")
    transformer = Python2FutureTransformer(module, (2, 7))
    module = transformer.visit(module)
    assert str(module) == "from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n\nprint('hello world')"

# Generated at 2022-06-23 22:51:42.301973
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # Call the constructor of class Python2FutureTransformer
    python2_future_transformer = Python2FutureTransformer()
    assert isinstance(python2_future_transformer, Python2FutureTransformer)


# Generated at 2022-06-23 22:51:51.985247
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    source = 'import os'
    expected_tree = """Module(body=[ImportFrom(module='__future__', names=[alias(name='absolute_import', asname=None)], level=0), ImportFrom(module='__future__', names=[alias(name='division', asname=None)], level=0), ImportFrom(module='__future__', names=[alias(name='print_function', asname=None)], level=0), ImportFrom(module='__future__', names=[alias(name='unicode_literals', asname=None)], level=0), Import(names=[alias(name='os', asname=None)])])"""
    transformer = Python2FutureTransformer()
    tree = ast.parse(source)
    new_tree = transformer.visit(tree)
    assert dump_tree(new_tree) == expected_

# Generated at 2022-06-23 22:51:57.948812
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    tree = ast.parse('''
import sys
import os''')
    res = ['from __future__ import absolute_import', 'from __future__ import division', 'from __future__ import print_function', 'from __future__ import unicode_literals', 'import sys', 'import os']
    transformed_tree = Python2FutureTransformer().visit(tree)
    transformed_code = astor.to_source(transformed_tree).split('\n')
    assert transformed_code == res



# Generated at 2022-06-23 22:51:59.183502
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    print(transformer)
                

# Generated at 2022-06-23 22:52:00.066940
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)

# Generated at 2022-06-23 22:52:01.720580
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import _ast
    assert isinstance(Python2FutureTransformer(), _ast.NodeTransformer)

# Generated at 2022-06-23 22:52:08.626128
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    module = ast.parse("""
import json
import os
import sys
import time
import traceback
from typing import Any
from typing import List
from typing import Tuple
from typing import Type

import click

from .basic import BasicCommand
from .command import Command
from .context import Context
from .core import Group
from .decorators import command
from .decorators import grouping
from .decorators import pass_context
from .errors import BadParameter
from .errors import Error
from .errors import MissingParameter
from .helpers import get_binary_stream
from .helpers import get_text_stream
from .types import Parameter
from .types import ParameterSource
from .types import ParameterType
from .types import Result
""")
    module_transformed = Python2FutureTransformer().visit(module)


# Generated at 2022-06-23 22:52:13.423145
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():

    source = """def main():
    print('foo')
 
if __name__ == '__main__':
    main()
"""

# Generated at 2022-06-23 22:52:20.320593
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # check that the generated code is correct
    t = Python2FutureTransformer()
    assert t.visit(imports.get_ast(future='__future__')) == ['from __future__ import absolute_import', 'from __future__ import division', 'from __future__ import print_function', 'from __future__ import unicode_literals']
    # check that the generated code is correct
    t = Python2FutureTransformer()
    assert t.visit(imports.get_ast(future='__future__')) == ['from __future__ import absolute_import', 'from __future__ import division', 'from __future__ import print_function', 'from __future__ import unicode_literals']

# Generated at 2022-06-23 22:52:22.932975
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer(): 
    """Test Python2FutureTransformer constructor."""
    obj = Python2FutureTransformer()
    assert obj.target == (2, 7)

# Generated at 2022-06-23 22:52:32.888155
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ast import parse

    class DummyNode:
        pass

    # test imports
    p = Python2FutureTransformer()
    body = p.visit_Module(parse(""))
    assert(body.body[0].names == [ast.alias(name='absolute_import', asname=None)])
    assert(body.body[1].names == [ast.alias(name='division', asname=None)])
    assert(body.body[2].names == [ast.alias(name='print_function', asname=None)])
    assert(body.body[3].names == [ast.alias(name='unicode_literals', asname=None)])

    # test tree_changed
    p = Python2FutureTransformer()
    p.visit(DummyNode())

# Generated at 2022-06-23 22:52:41.578482
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.fake import FakePython2Compiler, FakePython2Tree
    from .common import TestCase
    from .common import TestCaseTree
    from .common import python2
    from .common import python3

    class Python2FutureTransformerTest(TestCase, TestCaseTree):
        target_tree = python2

        def setUp(self) -> None:
            self.compiler = FakePython2Compiler(python2.AST)
            self.tree = FakePython2Tree(python2.AST)
            super(Python2FutureTransformerTest, self).setUp()

        def test_Python2FutureTransformer(self):
            self.transformer = Python2FutureTransformer()
            self.transformer.visit(self.tree)
            self.compiler.generic_visit(self.transformer.tree)

# Generated at 2022-06-23 22:52:42.547327
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()

# Generated at 2022-06-23 22:52:43.386272
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-23 22:52:44.631140
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-23 22:52:52.822041
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    _tree_changed: bool = False
    node: ast.Module = ast.parse("""\
import os    
""")
    _transformer = Python2FutureTransformer()
    _new_node = _transformer.visit(node)
    _tree_changed = _transformer.tree_changed
    assert ast.dump(_new_node) == ast.dump(ast.parse("""\
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

import os
""")), ast.dump(_new_node)
    assert _tree_changed == True

# Generated at 2022-06-23 22:52:54.031718
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()
    assert t.target == (2, 7)

# Generated at 2022-06-23 22:53:04.120034
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .. import transform
    from typed_ast import ast3 as ast
    
    source = """
a = 1
b = 2
"""
    tree = ast.parse(source)
    transformed_tree = transform(tree, Python2FutureTransformer)
    transformed_tree_source = ast.dump(transformed_tree)
    

# Generated at 2022-06-23 22:53:12.345834
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source_code import SourceCode

    python2_code_sample_1 = '''
    # -*- coding: utf-8 -*-

    """
    Example use of Python 2 in which absolute_import division print_function
    and unicode_literals are not imported.
    """
    #
    # A Python 2 comment
    #

    import sys, os
    import pandas as pd

    def main():

        # code using Python 2

        a = 'a'
        print(type(a))
        return 0   # success

    if __name__ == '__main__':
        status = main()
        sys.exit(status)
    '''


# Generated at 2022-06-23 22:53:16.236317
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = ast.parse('assert False')
    new_module = Python2FutureTransformer().visit_Module(module)
    assert format(new_module, '1') == '\n'.join([
        'from __future__ import absolute_import',
        'from __future__ import division',
        'from __future__ import print_function',
        'from __future__ import unicode_literals',
        '',
        'assert False'
    ])

# Generated at 2022-06-23 22:53:18.791721
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert isinstance(Python2FutureTransformer, object)

# Generated at 2022-06-23 22:53:19.352197
# Unit test for constructor of class Python2FutureTransformer

# Generated at 2022-06-23 22:53:22.302778
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from future import absolute_import, division, print_function, unicode_literals
    __transformer__ = Python2FutureTransformer



# Generated at 2022-06-23 22:53:25.746642
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .test_utils import get_node
    
    node = get_node('def func():\n    a = b')

# Generated at 2022-06-23 22:53:33.548657
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # test input
    code = """\
a = ""
"""

    # expected output
    expected_tree = ast.parse(
    """\
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

a = ""
""")

    # do the transform
    trans = Python2FutureTransformer()
    tree = ast.parse(code)
    new_tree = trans.visit(tree)

    # compare
    compare_ast(expected_tree, new_tree)

# Generated at 2022-06-23 22:53:39.642537
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ast_helpers.transformer import ModuleTransformer
    module = ast.parse('print(0)')
    expected = ast.parse('''
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
            print(0)''')
    actual = ModuleTransformer(Python2FutureTransformer).visit(module)
    import astunparse
    assert astunparse.unparse(actual) == astunparse.unparse(expected)

# Generated at 2022-06-23 22:53:47.803874
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test import get_ast
    from ..utils.snippet import snippet
    from ..utils.test import transform
    from ..utils.test import round_trip

    @snippet
    def before(i):
        print(i)

    assert before.get_tree() == get_ast(before)  # sanity check

    after = transform(Python2FutureTransformer, before)
    assert after == round_trip(before)

    @snippet
    def expected(future):
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        print(i)

# Generated at 2022-06-23 22:53:50.199176
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast.ast3 import Module
    transformer = Python2FutureTransformer()
    # test: None
    node = Module(body=[])
    assert transformer.visit_Module(node) == imports.get_ast(future='__future__')

# Generated at 2022-06-23 22:53:55.358997
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    tree = ast.parse("x = 1")
    transformer = Python2FutureTransformer()
    tree = transformer.visit(tree)
    assert transformer._tree_changed is True
    tree = astor.to_source(tree)
    assert tree == imports.get_string(future='__future__') + "x = 1"

# Generated at 2022-06-23 22:54:04.438760
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..test_utils import make_test_ast

    test_input = (
        '#!/usr/bin/python\n'
        '\n'
        'print("Hello, world!")\n'
    )

    expected_output = (
        '#!/usr/bin/python\n'
        'from __future__ import absolute_import\n'
        'from __future__ import division\n'
        'from __future__ import print_function\n'
        'from __future__ import unicode_literals\n'
        '\n'
        'print("Hello, world!")\n'
    )

    tree = make_test_ast(test_input, 'exec')
    transformer = Python2FutureTransformer()
    transformed = transformer.visit(tree)

# Generated at 2022-06-23 22:54:13.187940
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.fake_module import fake_module
    from ..utils.testutils import help_sort_imports
    module = fake_module()

    trans = Python2FutureTransformer()
    module2 = trans.visit(module)  # type: ignore

    assert isinstance(module2, ast.Module)
    assert trans._tree_changed
    assert module.body != module2.body
    assert len(module2.body) == len(module.body) + 4
    help_sort_imports(module2.body)
    for node in module2.body:
        assert isinstance(node, ast.ImportFrom)
        assert node.module == '__future__'
        assert not node.level

# Generated at 2022-06-23 22:54:15.661165
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer(tree=None, filename=None).future_modules == {'__future__'}

# Generated at 2022-06-23 22:54:20.949514
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module = ast.parse('a = 1')
    v = Python2FutureTransformer()
    v.visit(module)

    assert module.body[0].value.s == 'absolute_import'
    assert module.body[1].value.s == 'division'
    assert module.body[2].value.s == 'print_function'
    assert module.body[3].value.s == 'unicode_literals'

# Generated at 2022-06-23 22:54:26.158510
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Module

    module = Module(
        body=[]
    )
    module_out = Python2FutureTransformer().visit_Module(module)
    assert module_out.body == imports.get_body(future='__future__'), repr(module_out.body)

# Generated at 2022-06-23 22:54:32.671011
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    from ..utils.ast_helper import make_module
    transformer = Python2FutureTransformer()
    code = 'Module'
    node = make_module(code, (2, 7))
    transformer.visit(node)
    assert astor.to_source(node) == 'from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n\nModule'

# Generated at 2022-06-23 22:54:33.667303
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-23 22:54:36.280920
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Unit test for constructor of class Python2FutureTransformer"""
    assert hasattr(Python2FutureTransformer, "visit_Module")
    assert callable(Python2FutureTransformer.visit_Module)


# Generated at 2022-06-23 22:54:37.167549
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    for _ in Python2FutureTransformer.__init__.__annotations__:
        assert True


# Generated at 2022-06-23 22:54:41.436095
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor
    tree = ast.parse("print('hello')\n"+"x=10\n"+"print('again')\n")
    tr = Python2FutureTransformer()
    tr.visit(tree)
    source = astor.to_source(tree)
    assert source == "from __future__ import absolute_import\n" + \
        "from __future__ import division\n" + \
        "from __future__ import print_function\n" + \
        "from __future__ import unicode_literals\n" + \
        "print('hello')\n" + \
        "x=10\n" + \
        "print('again')\n"

# Generated at 2022-06-23 22:54:49.865613
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = ast.parse('import sys', mode='exec')


# Generated at 2022-06-23 22:54:59.702013
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    input = """
    def foo(x):
        return x * 2
    """

    expected_output = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    def foo(x):
        return x * 2
    """

    tree = ast.parse(input)

    transformer = Python2FutureTransformer()
    new_tree = transformer.visit(tree)

    assert ast.dump(new_tree) == ast.dump(ast.parse(expected_output)), \
        "Python2FutureTransformer.visit_Module() does not work as expected"

# Generated at 2022-06-23 22:55:10.793015
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from typed_ast import parse
    from .utils import analyse_visitor
    from .utils import roundtrip_visitor

    # Given
    module = parse('''
    import os, sys
    print('Hello world !')
    '''.lstrip())

    # When
    visitor = Python2FutureTransformer()
    transformed_module = visitor.visit(module)  # type: ignore

    # Then
    expected_module = parse('''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    import os, sys
    print('Hello world !')
    '''.lstrip())

    assert isinstance(transformed_module, ast.Module)
    assert analyse_

# Generated at 2022-06-23 22:55:12.229818
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer(None).target == (2, 7)


# Generated at 2022-06-23 22:55:14.929297
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    node = ast.parse('a = 1')
    x = Python2FutureTransformer()
    x.visit(node)
    assert x._tree_changed
    # print(ast.dump(node))

# Generated at 2022-06-23 22:55:23.727804
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # Given
    from ..utils.test_utils import get_test_case
    from ..utils import test_utils
    from typed_astunparse import unparse

    test_case_path = get_test_case('future_imports.py')
    with open(test_case_path, 'r') as f:
        test_case = f.read()
    transformer = Python2FutureTransformer()
    expected_transformed_test_case = get_test_case('future_imports_expected.py')

    # When
    transformed_test_case = transformer.visit(test_utils.parse_string_to_module(test_case))  # type: ignore
    transformed_test_case = unparse(transformed_test_case)

    # Then
    assert expected_transformed_test_case == transformed_test_case

# Generated at 2022-06-23 22:55:33.956736
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    text = """import future
import os
import sys

print(os.__file__)
print(sys.__file__)
# for i in range(1, 2):
#    print(i)
"""
    from ... import parse_string
    from ... import transform
    from ...utils.fix_print import fix_print_with_import

    source_tree = parse_string(text, 'test.py')
    transformed_tree = transform(source_tree, [Python2FutureTransformer])

# Generated at 2022-06-23 22:55:41.620993
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    ast_string = '''
from __future__ import generators
a = 3
'''
    ast_tree = ast.parse(ast_string)
    transformer = Python2FutureTransformer()
    transformer.visit(ast_tree)
    expected_ast_string = '''
from __future__ import generators
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
a = 3
'''
    expected_ast_tree = ast.parse(expected_ast_string)
    assert astor.to_source(ast_tree) == astor.to_source(expected_ast_tree)



# Generated at 2022-06-23 22:55:44.451350
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse('''
import sys

a = 5

b = 7
''')
    transformed = Python2FutureTransformer().visit(node)
    assert transformed.body[0].body[0].name == "absolute_import"

# Generated at 2022-06-23 22:55:48.523755
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Unit test for Python2FutureTransformer"""
    
    # Check the docstring
    assert Python2FutureTransformer.__doc__ is not None

    # Check the constructor
    obj = Python2FutureTransformer()

    # Check the attributes
    assert hasattr(obj, 'target')
    assert hasattr(obj, 'generic_visit')
    assert hasattr(obj, 'visit_Module')

# Generated at 2022-06-23 22:55:55.370814
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    code = """
a = 1
b = 2
"""
    expected_code = """
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

a = 1
b = 2
"""
    tree = ast.parse(code)
    new_tree = Python2FutureTransformer().visit(tree)
    assert ast.dump(new_tree) == ast.dump(ast.parse(expected_code))

# Generated at 2022-06-23 22:56:05.274348
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from six import exec_
    from .tree import NodeTransformerTree

    source = """
    import os

    def func():
        from future import absolute_import, print_function
        import six
    """
    expected = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    import os

    def func():
        from future import absolute_import, print_function
        import six
    """
    tree = NodeTransformerTree(source)
    tree.register_transformer(Python2FutureTransformer)
    tree.apply()
    node = tree.root_node
    assert expected == ast.dump(node, annotate_fields=False)
    exec_(compile(node, '<string>', 'exec'))

# Generated at 2022-06-23 22:56:09.486968
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    code = """print()"""
    expected = r"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
print()
"""
    tree = ast.parse(code)
    Python2FutureTransformer().visit(tree)
    assert ast.dump(tree) == expected

# Generated at 2022-06-23 22:56:12.576730
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as typed_ast
    tree = typed_ast.parse("print('Hello World')").body
    assert isinstance(Python2FutureTransformer().visit(tree), list)

# Generated at 2022-06-23 22:56:22.020482
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_test_module
    from ..utils.visitor import dump_tree_and_code
    from ..utils.ast import loads

    module = ast.Module([])
    transformer = Python2FutureTransformer()
    node = transformer.visit(module)
    assert transformer._tree_changed

    code_lines = []
    code_lines.append('from __future__ import absolute_import')
    code_lines.append('from __future__ import division')
    code_lines.append('from __future__ import print_function')
    code_lines.append('from __future__ import unicode_literals')

    tree, code = dump_tree_and_code(node, transformer)

    # Dump code

# Generated at 2022-06-23 22:56:29.543881
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    import typing
    from .python_base_transformer import PythonBaseTransformer
    from ..visitor import ModuleVisitor
    visitor = ModuleVisitor(PythonBaseTransformer)
    visitor.visit(ast.parse('a = 2', mode='eval'))
    future: typing.Optional[ast.ImportFrom]
    for future in map(type, visitor.tree.body):
        if future is ast.ImportFrom:
            break
    else:
        assert 0, 'Unable to find "from __future__ import" statement in the' \
                  ' transformed tree'
    assert future.module == '__future__'


# Generated at 2022-06-23 22:56:36.741443
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    snippets = [
        """
        print("Hello")
        """,
        """
        from __future__ import print_function
        print("Hello")
        """,
        """
        from __future__ import print_function, division
        print("Hello")
        """
    ]
    for src in snippets:
        tree = ast.parse(src)
        transformer = Python2FutureTransformer()
        transformer.visit(tree)
        actual = ast.dump(tree)
        expected = ast.dump(ast.parse(imports.get_src() + src))
        assert actual == expected

# Generated at 2022-06-23 22:56:46.964833
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from .py23_test_visitor import Py23TestVisitor
    from ..utils import get_test_data

    filename = get_test_data('example_2to3.py')
    with open(filename, 'rt', encoding='utf8') as f:
        source = f.read()
    tree = ast.parse(source)
    visitor = Py23TestVisitor()
    Python2FutureTransformer().visit(tree)
    visitor.visit(tree)
    assert visitor.is_changed()
    assert visitor.stats == {'future__division': 2,
                             'future__absolute_import': 2,
                             'future__print_function': 2,
                             'future__unicode_literals': 2}

# Generated at 2022-06-23 22:56:50.737967
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor
    from ..utils.ast_builder import ast_from_str
    ast_tree = ast_from_str('')
    print(astor.dump(ast_tree))
    ast_tree_new = Python2FutureTransformer().visit(copy.deepcopy(ast_tree))  # type: ignore
    print(astor.dump(ast_tree_new))


if __name__ == "__main__":
    test_Python2FutureTransformer()

# Generated at 2022-06-23 22:56:53.733501
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse('1 + 2')
    tree = Python2FutureTransformer().visit(node)
    assert isinstance(tree.body[0], ast.ImportFrom)


# Generated at 2022-06-23 22:56:58.072404
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from .. import parse
    from .. import dump

    source = 'print("Hello world!")'
    tree = parse(source)

    transformer = Python2FutureTransformer(target=(2, 7))
    transformer.visit(tree)
    actual_source = dump(tree)
    expected_source = imports.strip() + '\n' + source
    assert actual_source == expected_source

# Generated at 2022-06-23 22:57:04.286922
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor

    f = open('tmp.py', 'w')
    f.write('import os')
    f.close()

    with open('tmp.py', 'r') as f:
        tree = astor.parse_file(f)

    node_transformer = Python2FutureTransformer()
    node_transformer.visit(tree)

    with open('tmp.py', 'w') as f:
        f.write(astor.to_source(tree))

    with open('tmp.py', 'r') as f:
        output = f.read()

    import os
    os.remove('tmp.py')

# Generated at 2022-06-23 22:57:05.459547
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    f = Python2FutureTransformer()
    assert isinstance(f, Python2FutureTransformer)



# Generated at 2022-06-23 22:57:13.267621
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def test():
        print("Hello, World!")

    expected = """
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

print(\"Hello, World!\")"""

    node = test.get_ast()  # type: ignore
    Python2FutureTransformer().visit(node)  # type: ignore
    assert ast.dump(node) == expected

# Generated at 2022-06-23 22:57:22.532375
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_transformed_fixture
    from ..utils.source import source_to_unicode
    import sys
    import textwrap
    from os.path import splitext, basename

    def do_test_method(self, method_name, source_filename):
        source_basename = splitext(basename(source_filename))[0]
        source = source_to_unicode(source_filename)
        expected_basename = 'expected/' + source_basename

        transformer = self.transpile_class()
        node = ast.parse(source, filename=source_filename)
        getattr(transformer, method_name)(node)
        result = ast.fix_missing_locations(node)

        expected = self.load_expected_ast(expected_basename + '.ast')

# Generated at 2022-06-23 22:57:30.135998
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astunparse
    node = ast.parse('''
        import sys
        import os
        import json
        from datetime import datetime
        from datetime import date
    ''')

    node = Python2FutureTransformer.run(node)
    assert astunparse.unparse(node) == '''
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        import sys
        import os
        import json
        from datetime import datetime
        from datetime import date
    '''

# Generated at 2022-06-23 22:57:41.353153
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast

    node = ast.parse("x = 1")

    obj = Python2FutureTransformer()
    result = obj.visit(node)

    expected = ast.parse(
        "from __future__ import absolute_import\n"
        "from __future__ import division\n"
        "from __future__ import print_function\n"
        "from __future__ import unicode_literals\n"
        "x = 1")

    assert ast.dump(result) == ast.dump(expected)

    result = Python2FutureTransformer().visit(ast.parse("q = 1\n"))

# Generated at 2022-06-23 22:57:47.762273
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module0 = ast.parse("from __future__ import absolute_import")
    Python2FutureTransformer.reset_tree_changed()
    module1 = Python2FutureTransformer().visit(module0)
    # The transformed module should not be changed.
    assert module1 is module0
    # Python2FutureTransformer should not report the tree has changed.
    assert not Python2FutureTransformer.get_tree_changed()

    module0 = ast.parse("from future import print_function")
    Python2FutureTransformer.reset_tree_changed()
    module1 = Python2FutureTransformer().visit(module0)
    # The transformed module should not be changed.
    assert module1 is module0
    # Python2FutureTransformer should not report the tree has changed.
    assert not Python2FutureTransformer.get_tree_changed()

   

# Generated at 2022-06-23 22:57:49.698915
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils import unit_test_ast

# Generated at 2022-06-23 22:57:50.719481
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    _ = Python2FutureTransformer()

# Generated at 2022-06-23 22:57:53.786198
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Quick test for constructor of class Python2FutureTransformer."""
    t = Python2FutureTransformer()
    assert t


# Generated at 2022-06-23 22:57:55.888062
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    print('\n--- Testing Python2FutureTransformer ---')
    assert(Python2FutureTransformer.target == (2, 7))



# Generated at 2022-06-23 22:57:56.490739
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass

# Generated at 2022-06-23 22:58:01.952116
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    node = ast.parse('hello = "world"\n')
    assert len(node.body) == 1
    transformer = Python2FutureTransformer()
    node1 = transformer.visit(node)
    assert len(node1.body) == 5
    assert isinstance(node1.body[0], ast.ImportFrom)
    assert node1.body[0].module == '__future__'

# Generated at 2022-06-23 22:58:03.356569
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()
    assert t


# Generated at 2022-06-23 22:58:08.707816
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    snippet_code = """
    class MyClass(object):
        pass
    """
    module_ast = ast.parse(snippet_code)
    transformer = Python2FutureTransformer() 
    transformed_ast = transformer.visit(module_ast)
    assert len(transformed_ast.body) == 8
    assert isinstance(transformed_ast.body[0], ast.ImportFrom)
    assert transformed_ast.body[0].module == 'future'

# Generated at 2022-06-23 22:58:16.589852
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import lib2to3
    tree = lib2to3.pgen2.parse("import sys\nprint(sys.version_info)")
    transformer = Python2FutureTransformer()
    new_tree = lib2to3.pgen2.driver.Driver(transformer, tree).process_tree(tree)
    assert str(new_tree) == "import sys\nfrom __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\nprint(sys.version_info)"

# Generated at 2022-06-23 22:58:25.224867
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from textx.exceptions import TextXSyntaxError
    from textx.metamodel import metamodel_from_str
    from textx.export import metamodel_export, model_export
    from textx.model import children_of_type

    python_meta, python_payload = metamodel_from_str("""
    Model: files*=File;
    File: name=ID imports*=ImportStatement stmts*=Statement;

    ImportStatement: 'import' module=(ID|DOT)+;
    Statement: 'pass';
    """)

    class PythonConverter(object):
        def __init__(self, payload_cls):
            self.payload_cls = payload_cls

        def convert(self, model):
            self.model = model