

# Generated at 2022-06-23 22:48:32.265108
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import os
    import astor
    from textwrap import dedent
    from ..utils.ast_inspector import AstInspector
    source = dedent('''\
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals
        
        def f(x):
            return x
        
        print(f(1))
        print('bye')
    ''')
    fn = "script.py"
    with open(fn, "w") as f:
        f.write(source)

# Generated at 2022-06-23 22:48:42.910680
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import sys
    import astor
    from ..autofix_tool import ast_to_source

    sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))
    from autofix.transform.future import Python2FutureTransformer
    from autofix.util.ast_util import load_ast_from_source
    from autofix.util.visitor import dump_tree

    code = "import os\nimport sys"
    ast_tree = load_ast_from_source(code)
    dump_tree.dump_tree("test_python2_future_transformer_visit_module_origin.dot", ast_tree)


# Generated at 2022-06-23 22:48:44.332928
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer().target == (2, 7)



# Generated at 2022-06-23 22:48:45.688001
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-23 22:48:47.011438
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer is not None

# Generated at 2022-06-23 22:48:48.940381
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__doc__ is not None



# Generated at 2022-06-23 22:48:53.930790
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    
    
    transformer = Python2FutureTransformer()
    
    module =  ast.Module()
    
    
    module_ = transformer.visit(module)
    
    assert module_.body[0].module == '__future__'
    assert module_.body[0].names[0].name == 'absolute_import'
    


# Generated at 2022-06-23 22:49:04.508484
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor

# Generated at 2022-06-23 22:49:14.128315
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
  from ..utils import evaluate_ast
  from .simple_transformer import SimpleTransformer
  from .transformers import Python2BoolTransformer
  from .transformers import Python2DivisionTransformer
  from .python2_function_transformer import Python2FunctionTransformer
  from .python2_print_function_transformer import Python2PrintFunctionTransformer
  from .python2_unicode_literal_transformer import Python2UnicodeLiteralTransformer

  source = """print('Hello')"""
  expected_result = """
  from __future__ import absolute_import
  from __future__ import division
  from __future__ import print_function
  from __future__ import unicode_literals
  print('Hello')"""
  tree = ast.parse(source)

# Generated at 2022-06-23 22:49:18.886788
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    field = Python2FutureTransformer.visit_Module.__annotations__['node']
    assert field.__name__ == 'Module'
    assert field.__module__ == 'typed_ast.ast3'



# Generated at 2022-06-23 22:49:23.604819
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    node = ast.parse('print(10)')
    trans = Python2FutureTransformer()
    trans.visit(node)
    assert (str(node) == '\n'.join(['from __future__ import absolute_import', 'from __future__ import division', 'from __future__ import print_function', 'from __future__ import unicode_literals', 'print(10)']))

# Generated at 2022-06-23 22:49:29.550407
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    from .base import BaseNodeTransformer
    from .fstring import Python36FStringTransformer
    from .general import GeneralTransformer
    from .unicode import Python2UnicodeTransformer
    from .wild_import import Python2WildImportTransformer
    code = '''
import os
import sys
import sqlite3
import subprocess

from optparse import OptionParser

input_file = open(sys.argv[1], "r")
output_file = open(sys.argv[2], "w")

print("Hello", file=output_file)

for line in input_file:
    output_file.write(line)

input_file.close()
output_file.close()
    '''

# Generated at 2022-06-23 22:49:33.937060
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from .test_base import get_future_imports
    from .test_base import parse

    node = ast.parse('')
    node = Python2FutureTransformer().visit(node)
    assert node == parse(get_future_imports())

# Generated at 2022-06-23 22:49:35.429674
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    x = Python2FutureTransformer()
    assert x is os

# Generated at 2022-06-23 22:49:40.233312
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .. import dump


# Generated at 2022-06-23 22:49:41.671952
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert isinstance(Python2FutureTransformer(), Python2FutureTransformer)


# Generated at 2022-06-23 22:49:48.582465
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    expected = ast.parse("""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
print("Hello World")
    """).body

    node = ast.Module(body=[ast.Expr(value=ast.Call(func=ast.Name(id='print', ctx=ast.Load()), args=[ast.Str(s='Hello World')], keywords=[]))])
    actual = Python2FutureTransformer().visit(node)
    assert actual.body == expected

# Generated at 2022-06-23 22:49:55.198345
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source
    from ..utils.visitor import compare_ast
    from .example import example_python2

    class Module(ast.Module):
        body = [ast.Expr(value=ast.Str(s="x"))]

    module = Module()
    source_ = source(module, 'python2')
    transforms = [Python2FutureTransformer]
    expected_result = example_python2('from_future')
    compare_ast(transforms, source_, expected_result)

# Generated at 2022-06-23 22:50:05.976985
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Code before transformation
    code = '''
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

from future import standard_library

from six import string_types
from six import text_type
import re
from pkg_resources import resource_filename
'''
    # Expected transformed code

# Generated at 2022-06-23 22:50:08.437858
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()
    assert t
    assert isinstance(t, BaseNodeTransformer)
    assert not t._tree_changed

# Generated at 2022-06-23 22:50:16.341961
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import os
    import sys
    import tempfile
    import textwrap
    from pathlib import Path
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Module
    from typed_ast.nodes import ImportFrom
    from .base import BaseNodeTransformer

    source = textwrap.dedent("""
        # Some comment
        import some_module
        import foo
        import bar
    """)

    expected_source = textwrap.dedent("""
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        # Some comment
        import some_module
        import foo
        import bar
    """)
    
    fd, path = tempfile.mkstemp()

# Generated at 2022-06-23 22:50:17.390828
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass

# Generated at 2022-06-23 22:50:22.928121
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()
    module = ast.parse('print("hello")')
    module = transformer.visit(module)
    assert_equals(astunparse.unparse(module),
                  'from __future__ import absolute_import\n'
                  'from __future__ import division\n'
                  'from __future__ import print_function\n'
                  'from __future__ import unicode_literals\n'
                  '\n'
                  'print("hello")')

# Generated at 2022-06-23 22:50:29.296484
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse('onedit(x)')
    tr = Python2FutureTransformer(target_versions={2, 3})
    updated = tr.visit(node)
    expected_code = '''\
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

onedit(x)
'''
    assert expected_code == astor.to_source(updated)

# Generated at 2022-06-23 22:50:31.041081
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    x = Python2FutureTransformer()
    assert(isinstance(x, BaseNodeTransformer))

# Generated at 2022-06-23 22:50:37.952554
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import transform_snippets
    from .utils import compare_ast
    snippet_before = """
    print("Hello world!")
    """.strip()
    snippet_after = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    print("Hello world!")
    """.strip()
    transform_snippets(Python2FutureTransformer, snippet_before, snippet_after, compare_ast=compare_ast)

# Generated at 2022-06-23 22:50:43.898681
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    code = 'print("test")'
    tree = ast.parse(code)
    expected = 'from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\nprint("test")'
    actual = Python2FutureTransformer(None).visit(tree)
    assert astor.to_source(actual) == expected

# Generated at 2022-06-23 22:50:50.364200
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():

    # Test case 1: imports is prepended to the module body
    module = ast.parse(imports.get_body(future='__future__'))

    # Test case 2: no imports are prepended to an empty module body
    module = ast.parse('')

    # Test case 3: no imports are prepended to a module body with non-import statements
    module = ast.parse('x=1\ny=2\n')

    # Test case 4: imports is prepended to a module body with import statements
    module = ast.parse('import sys\nimport os\n')

# Generated at 2022-06-23 22:50:58.479318
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import get_test_data
    from ..utils.test_utils import parse_source
    import textwrap

    test_data = get_test_data('fixtures/test_python2_future.py')

    expected_ast = parse_source(
        textwrap.dedent("""
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        """ + test_data),
        python_version=(3, 6)
    )

    actual_ast = parse_source(
        test_data,
        python_version=(3, 6),
        transformers={'f': Python2FutureTransformer}
    )

    assert_equal

# Generated at 2022-06-23 22:51:02.683097
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    from ..utils.ast_parser import get_ast

    src = """\
    import os
    """
    tree = get_ast(src)
    transformer = Python2FutureTransformer()
    transformer.generic_visit(tree)
    assert astor.to_source(tree).strip() == imports.get_ast_tree().strip()

# Generated at 2022-06-23 22:51:04.420374
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    f = Python2FutureTransformer(None)
    assert f.target == (2, 7)

# Generated at 2022-06-23 22:51:06.522046
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # type: () -> None
    t = Python2FutureTransformer(None)
    assert t is not None


# Generated at 2022-06-23 22:51:12.300036
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.tree_compare import tree_compare
    from ..utils.tree_to_code import tree_to_code

    tree = ast.parse(imports.get_code(future='__future__'))
    assert tree_compare(
        tree,
        imports.get_tree(future='__future__'),
        ignore_type=['_fields', 'ctx', 'value']
    )

    code = tree_to_code(tree)
    assert code == imports.get_code(future='__future__')

# Generated at 2022-06-23 22:51:18.262828
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils import assert_tree_unchanged

    module = ast.parse('import ast')
    transformer = Python2FutureTransformer()
    new_module = transformer.visit(module)

# Generated at 2022-06-23 22:51:19.682683
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-23 22:51:21.047183
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass

# Research the following methods of class Python2FutureTransformer

# Generated at 2022-06-23 22:51:24.222863
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import unittest

    class TestPython2FutureTransformer(unittest.TestCase):
        def test_constructor(self):
            Python2FutureTransformer()

    unittest.main()

# Generated at 2022-06-23 22:51:30.874516
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3
    import astor
    code = astor.to_source(astor.parse_file(
        __file__,
        ignore_errors=True,
        mode='exec'))
    tree = ast3.parse(code)
    assert isinstance(tree, ast3.Module)
    transformer = Python2FutureTransformer()
    new_tree = transformer.visit(tree)
    assert transformer._tree_changed is True
    assert isinstance(new_tree, ast3.Module)

# Generated at 2022-06-23 22:51:40.637999
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # Given
    tree = ast.parse(code='''
foo = 6
''', mode='exec')

    # When
    node_transformer = Python2FutureTransformer()
    node_transformer.walk(tree)

    # Then

# Generated at 2022-06-23 22:51:45.670510
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    module = ast.parse('''def foo():
    print('baz')
    return


foo()
''')
    node = Python2FutureTransformer().visit(module)

# Generated at 2022-06-23 22:51:55.589229
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_fixture
    from ..utils.source import source

    transformer = Python2FutureTransformer()  # type: ignore
    expected = imports.get_tree(future='__future__')  # type: ignore

    actual = transformer.visit(ast.parse('pass'))
    assert_equal(source(expected), source(actual))

    source_ = 'a = b'
    actual = transformer.visit(make_fixture(source_))
    assert_equal(source(expected) + source_, source(actual))

    source_ = 'a = b\nc = d'
    actual = transformer.visit(make_fixture(source_))
    assert_equal(source(expected) + source_, source(actual))

# Generated at 2022-06-23 22:51:59.919160
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .. import parse

    code = "print(1)"
    node = parse(code)
    py2future = Python2FutureTransformer()
    assert py2future.visit(node) == parse(imports + code)



# Generated at 2022-06-23 22:52:00.510184
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-23 22:52:05.529649
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from tests.utils import assert_ast
    from typed_ast import ast3 as ast
    tree = ast.parse('def f(): pass')
    tr = Python2FutureTransformer()
    tr.visit(tree)
    assert_ast(tree, '''
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        def f():
            pass
    ''')

# Generated at 2022-06-23 22:52:08.975291
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Test for Python2FutureTransformer."""
    # Check whether the class is derived from BaseNodeTransformer
    assert issubclass(Python2FutureTransformer, BaseNodeTransformer)
    # Check whether the class can be instantiated
    assert Python2FutureTransformer(None)

# Generated at 2022-06-23 22:52:14.178050
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast

    source = """
    from future import unicode_literals
    from future import print_function
    from future import division

    print("你好，世界")
    print("Hello.world!")
    """
    tree = ast.parse(source)

    assert i

# Generated at 2022-06-23 22:52:18.686943
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse('# -*- coding: utf-8 -*-\npass')
    assert "from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n# -*- coding: utf-8 -*-\npass" == Python2FutureTransformer().visit(node)

# Generated at 2022-06-23 22:52:25.731406
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse("print('hello world')")
    output = Python2FutureTransformer().visit(node)

    future_module = ast.parse("from future import absolute_import\nfrom future import division\nfrom future import print_function\nfrom future import unicode_literals\n")
    node.body = future_module.body+node.body
    assert isinstance(output, ast.Module)
    assert ast.dump(output) == ast.dump(node)


# Generated at 2022-06-23 22:52:26.706568
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert issubclass(Python2FutureTransformer, BaseNodeTransformer)

# Generated at 2022-06-23 22:52:34.744158
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()
    node = ast.Module()
    t.visit(node)
    assert node.body[0].__class__ == ast.ImportFrom
    assert node.body[0].module == '__future__'
    assert node.body[1].__class__ == ast.ImportFrom
    assert node.body[1].module == '__future__'
    assert node.body[2].__class__ == ast.ImportFrom
    assert node.body[2].module == '__future__'
    assert node.body[3].__class__ == ast.ImportFrom
    assert node.body[3].module == '__future__'

# Generated at 2022-06-23 22:52:36.052972
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert hasattr(Python2FutureTransformer(), 'visit_Module')


# Generated at 2022-06-23 22:52:40.159816
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    code_in = 'print "Hello world"'
    node_in = ast.parse(code_in)
    node_out = Python2FutureTransformer().visit(node_in)  # type: ignore

    assert '__future__' in code_from_ast(node_out)
    assert 'unicode_literals' in code_from_ast(node_out)

# Generated at 2022-06-23 22:52:46.652462
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    code = """
module = 'foo'
    """
    tree = ast.parse(code)
    Python2FutureTransformer({}).visit(tree)

# Generated at 2022-06-23 22:52:52.950583
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    expected_result = '''\
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

print('Test')
'''

    module = ast.parse('''\
print('Test')
''')

    # setting up the transformer
    transformer = Python2FutureTransformer()

    # testing the transformer
    assert transformer.visit(module) == expected_result  # type: ignore

# Generated at 2022-06-23 22:53:00.046551
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3
    tree = ast3.parse('')
    tr = Python2FutureTransformer()
    assert tr.visit(tree).body[0] == ast3.ImportFrom(
        module='__future__', names=[
            ast3.alias(name='absolute_import', asname=None),
            ast3.alias(name='division', asname=None),
            ast3.alias(name='print_function', asname=None),
            ast3.alias(name='unicode_literals', asname=None),
        ], level=0
    )

# Generated at 2022-06-23 22:53:06.494959
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    m = ast.Module()
    result = Python2FutureTransformer().visit(m)
    assert result.body[0].body[0].value.id == 'absolute_import'
    assert result.body[0].body[1].value.id == 'division'
    assert result.body[0].body[2].value.id == 'print_function'
    assert result.body[0].body[3].value.id == 'unicode_literals'

# Generated at 2022-06-23 22:53:11.896815
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    class DummyNode(object):
        pass
    n = DummyNode()
    n.body = [1, 2, 3]
    t = Python2FutureTransformer()
    t.visit_Module(n)
    assert isinstance(n, ast.Module)
    assert isinstance(n.body[0], ast.ImportFrom)
    assert n.body[0].module == '__future__'
    assert n.body[0].names == [ast.alias(name='absolute_import', asname='')]
    assert isinstance(n.body[1], ast.ImportFrom)
    assert n.body[1].module == '__future__'
    assert n.body[1].names == [ast.alias(name='division', asname='')]

# Generated at 2022-06-23 22:53:16.088912
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    def check(input_code, expected_code):
        tree = ast.parse(input_code)
        new_tree = Python2FutureTransformer().visit(tree)
        assert ast.dump(new_tree) == expected_code

    check("", imports.get_code(future='__future__'))
    check("x = [1, 2, 3]", imports.get_code(future='__future__') + "x = [1, 2, 3]")

# Generated at 2022-06-23 22:53:24.230437
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils import compile_source
    transformer = Python2FutureTransformer()
    code = '"""Module docstring"""\n'
    new_code = compile_source(code, tree=transformer.visit)
    assert new_code == ('"""Module docstring"""\n'
                        'from __future__ import absolute_import\n'
                        'from __future__ import division\n'
                        'from __future__ import print_function\n'
                        'from __future__ import unicode_literals\n')

# Generated at 2022-06-23 22:53:34.134748
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ...parser import parse
    from ...pretty_printer import print_ast
    from ...transformer import TransformerSequence
    import ast

    node = parse('def f(): print(1)')
    expected_node = TransformerSequence(Python2FutureTransformer, 
                                        Python2FutureTransformer).transform(node)
    assert len(expected_node.body) == 6
    assert isinstance(expected_node.body[0], ast.ImportFrom)
    assert isinstance(expected_node.body[1], ast.ImportFrom)
    assert isinstance(expected_node.body[2], ast.ImportFrom)
    assert isinstance(expected_node.body[3], ast.ImportFrom)
    assert isinstance(expected_node.body[4], ast.FunctionDef)

# Generated at 2022-06-23 22:53:43.528572
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    class_ = Python2FutureTransformer(None, None)
    assert type(class_) == Python2FutureTransformer
    assert hasattr(class_, 'visit_Module')

# Unit tests for visit_Module()

# Generated at 2022-06-23 22:53:50.112988
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    input_program = 'def foo():\n    print("hello world")\n'
    expected_program = 'from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n\ndef foo():\n    print("hello world")\n'
    visitor = Python2FutureTransformer()
    node = ast.parse(input_program)
    new_node = visitor.visit(node)
    actual_program = astunparse.unparse(new_node)
    assert actual_program == expected_program

# Generated at 2022-06-23 22:53:56.622233
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..transformation_factory import TransformationFactory
    from ..transformation_factory import get_transformation
    from ..transformation_factory import register_transformation
    from ..transformation import Python2FutureTransformer
    from ..transformation import PythonTransformer

    # Test for get_transformation()
    # Without registering a transformation, we will get None
    transformation1 = get_transformation(2, 7)
    assert transformation1 == None
    # After registering a transformation, we will get the registered instance
    register_transformation(Python2FutureTransformer(ruled_out_line_numbers=[]))
    transformation2 = get_transformation(2, 7)
    assert isinstance(transformation2, Python2FutureTransformer)
    # Test for constructor
    tf = TransformationFactory()

# Generated at 2022-06-23 22:53:58.759122
# Unit test for constructor of class Python2FutureTransformer

# Generated at 2022-06-23 22:54:05.867785
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    """
    input:
        print()
    output:
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
    
        print()
    """
    input = ast.parse('''
        print()
    ''')
    output = ast.parse('''
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        print()
    ''')
    assert_equal(Python2FutureTransformer().visit(input), output)

# Generated at 2022-06-23 22:54:07.068706
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__doc__
    Python2FutureTransformer()



# Generated at 2022-06-23 22:54:07.979418
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer


# Generated at 2022-06-23 22:54:12.253114
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import typed_ast.ast3 as ast

    node = ast.Module(
        body=[
            ast.Expr(
                value=ast.Str(
                    s='test'
                )
            )
        ]
    )

    transformer = Python2FutureTransformer(
        node=node
    )

    result = transformer.visit(node)

    assert isinstance(result, ast.Module)
    assert len(result.body) == 4 + 1  # 4 imports + 1 test


if __name__ == '__main__':
    from .base import run_module_suite
    run_module_suite()

# Generated at 2022-06-23 22:54:16.079988
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Test for constructor of class Python2FutureTransformer

    Arguments:
        TestPython2FutureTransformer {[type]} -- [description]
    """
    assert Python2FutureTransformer is not None


# Generated at 2022-06-23 22:54:17.479106
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.target == (2, 7)


# Generated at 2022-06-23 22:54:24.968456
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.source import source_info, source

    # Test transformer with a module that contains only one import
    source_ = 'import sys'
    expected = """
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

import sys
"""
    source_info_ = source_info(source_)
    module = ast.parse(source_)
    transformer = Python2FutureTransformer()
    module = transformer.visit(module)
    assert source(module) + '\n' == expected
    assert module == ast.parse(expected)
    assert transformer.get_source_info() == source_info_

    # Test transformer with a module that contains one import and a print

# Generated at 2022-06-23 22:54:30.743578
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Test that Python2FutureTransformer expects a tuple as the target.
    """
    with pytest.raises(TypeError) as excinfo:
        Python2FutureTransformer(target=3)
    assert "tuple" in str(excinfo.value)
    a = Python2FutureTransformer(target=(2,7))
    assert a.target == (2,7)

# Generated at 2022-06-23 22:54:37.528622
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor

    # Given
    code_snippet = """
        def foo():
            print(1/2)
    """
    tree = ast.parse(code_snippet)

    # When
    transformer = Python2FutureTransformer()
    transformer.visit(tree)

    # Then
    assert astor.to_source(tree) == """
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals


        def foo():
            print(1/2)
    """

# Generated at 2022-06-23 22:54:39.020961
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    x = Python2FutureTransformer()
    assert x.target == (2, 7)

# Generated at 2022-06-23 22:54:42.557110
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source2ast
    from .base import restore_ast_snippet
    from ..utils.source import source2ast
    from .base import restore_ast_snippet
    tree = source2ast(__file__)
    pft = Python2FutureTransformer()
    pft.visit(tree)
    assert restore_ast_snippet(tree, imports)

# Generated at 2022-06-23 22:54:50.711870
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor  # type: ignore
    from nata.transformers.py2 import Python2FutureTransformer  # type: ignore

    def assert_transforms_into(src, expected):
        got = astor.to_source(Python2FutureTransformer().visit(ast.parse(src)))
        assert got == expected

    # source = '''
    #     import astor
    #     from nata.transformers import Python2FutureTransformer
    # '''

    # expected = '''
    #     from __future__ import absolute_import
    #     from __future__ import division
    #     from __future__ import print_function
    #     from __future__ import unicode_literals
    #     import astor
    #     from nata.transformers import Python2FutureTransformer
    # '''

    # assert

# Generated at 2022-06-23 22:54:54.659606
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Unit test for constructor of class Python2FutureTransformer."""

    # Test if class is initialized correctly
    transformer = Python2FutureTransformer()
    assert transformer.new_module_name == 'new_module.py'
    assert transformer.target == (2, 7)

# Generated at 2022-06-23 22:54:56.675782
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = ast.parse("import os\nimport sys")
    transformer = Python2FutureTransformer()
    module = transformer.visit(module)
    code = compile(module, '<string>', 'exec')
    exec(code)

# Generated at 2022-06-23 22:55:04.651051
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    code = "import os\n"
    node = ast.parse(code)
    new_module = Python2FutureTransformer().visit(node)
    assert ast.dump(new_module) == """\
Module(
    body=[
        ImportFrom(
            module='future',
            names=[
                alias(
                    name='absolute_import',
                    asname=None),
                alias(
                    name='division',
                    asname=None),
                alias(
                    name='print_function',
                    asname=None),
                alias(
                    name='unicode_literals',
                    asname=None)],
            level=2),
        Import(
            names=[
                alias(
                    name='os',
                    asname=None)])])"""

# Generated at 2022-06-23 22:55:12.840135
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    t = Python2FutureTransformer()
    node = ast.parse('for i in range(10):\n  print(i)\n')
    t.visit(node)
    print(astor.to_source(node))
    assert astor.to_source(node).strip() == '''
# -*- coding: utf-8 -*-
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
for i in range(10):
    print(i)
'''.strip()

# Generated at 2022-06-23 22:55:20.681962
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ast_analyzer.python_source_tree import PythonSourceTree
    program_text = '''
        def foo(x):
            return x + 1
    '''
    source = PythonSourceTree(program_text, target_versions=[(2, 7)])
    source.apply_transformer(Python2FutureTransformer())
    assert source.program_text == '''
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        def foo(x):
            return x + 1
    '''

# Generated at 2022-06-23 22:55:28.327745
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    from io import StringIO
    from .base import BaseNodeTransformerTest
    from .test_all_transformers import test_all_transformers_cls
    
    class Test(BaseNodeTransformerTest):
        target = (2, 6)
        def test_Module(self):
            self.check_ast(ast.Module([], []), ast.Module([], []))

# Generated at 2022-06-23 22:55:29.260757
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer

# Generated at 2022-06-23 22:55:29.812890
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass

# Generated at 2022-06-23 22:55:31.215582
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer().target == (2, 7)

# Generated at 2022-06-23 22:55:33.411880
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse('a = 1')
    trans_node = Python2FutureTransformer().visit(node)
    assert set([x.name for x in ast.walk(trans_node) if isinstance(x, ast.Name)]) == \
        {'a', 'absolute_import', 'division', 'print_function', 'unicode_literals'}

# Generated at 2022-06-23 22:55:40.505880
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    """Test visit_Module of class Python2FutureTransformer
    
    """
    obj = Python2FutureTransformer()

    # test Module with future import and if statement
    node = ast.parse('from __future__ import absolute_import\nif True:\n    pass\n')
    node = obj.visit(node)
    assert len(node.body) == 4
    assert node.body[0].names[0].name == "absolute_import"
    assert node.body[1].names[0].name == "division"
    assert node.body[2].names[0].name == "print_function"
    assert node.body[3].names[0].name == "unicode_literals"
    assert len(node.body[4].body) == 1

    # test Module without future import and if statement
    node = ast

# Generated at 2022-06-23 22:55:41.230082
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import ast

# Generated at 2022-06-23 22:55:41.738041
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass

# Generated at 2022-06-23 22:55:45.547447
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import_future = Python2FutureTransformer()
    assert import_future.target == (2,7)
    assert import_future.name == 'Python 2 Future imports'
    assert import_future.description == ' Adds imports from future to enable 2->3 compatibility'
    assert import_future.visit_Module == import_future.visit_Module

# Generated at 2022-06-23 22:55:46.961310
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)

# Generated at 2022-06-23 22:55:52.943921
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    from ..utils.messages import *

    node = ast.parse('x = "Hello, World"')
    Python2FutureTransformer().visit(node)
    expected = """
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
x = "Hello, World"
"""
    assert ast.dump(node, include_attributes=True) == expected

# Generated at 2022-06-23 22:55:59.326668
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor
    from typed_ast.ast3 import parse
    from .utils import compare_source

    source = "def foo():\n    print('hello world')"
    expected = imports.format(future='__future__') + source

    tree = parse(source)
    new_tree = Python2FutureTransformer().visit(tree)
    new_source = astor.to_source(new_tree)
    compare_source(expected, new_source)

# Generated at 2022-06-23 22:56:04.691234
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    m = ast.parse('a = 1')
    expected = ast.parse('''from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
a = 1''')
    m = Python2FutureTransformer().visit(m)
    assert astor.to_source(m) == astor.to_source(expected)

# Generated at 2022-06-23 22:56:11.618864
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    transformer = Python2FutureTransformer()

    # Test snippet "def a():\n    pass"
    test_snippet1 = ast.parse("def a():\n    pass")
    assert transformer.visit(test_snippet1) == transformer.visit(imports.get_tree(future='__future__') + test_snippet1.body)
    assert astor.to_source(transformer.visit(test_snippet1)).strip() == astor.to_source(imports.get_tree(future='__future__') + test_snippet1.body).strip()

    # Test snippet "def a(b):\n  pass"
    test_snippet2 = ast.parse("def a(b):\n  pass")

# Generated at 2022-06-23 22:56:12.241678
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()  # should not raise

# Generated at 2022-06-23 22:56:14.144321
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    p2ft = Python2FutureTransformer()
    assert isinstance(p2ft, BaseNodeTransformer)


# Generated at 2022-06-23 22:56:15.003204
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer(2, 7)

# Generated at 2022-06-23 22:56:16.255909
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)

# Generated at 2022-06-23 22:56:27.004121
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    
    node = ast.parse("a = 10")


# Generated at 2022-06-23 22:56:32.025457
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    tree = ast.parse('def f(): pass')
    name = '__future__'
    transformer = Python2FutureTransformer(tree, **{name: True})
    assert transformer._future is True
    assert transformer.target == (2, 7)


# Generated at 2022-06-23 22:56:33.114618
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-23 22:56:35.907330
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    actual = Python2FutureTransformer.__init__.__defaults__
    expect = (None,)
    print('actual  =', actual)
    print('expect  =', expect)
    assert actual == expect

# Generated at 2022-06-23 22:56:38.631072
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer('file').target == (2, 7)
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'

# Generated at 2022-06-23 22:56:41.386539
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils import roundtrip
    tree = ast.parse("import argparse", mode='eval')
    result = roundtrip(Python2FutureTransformer, tree)
    assert result == tree

# Generated at 2022-06-23 22:56:47.474168
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.python_source import python_source

    source = b"""
    def append(self):
        pass
    """
    node = ast.parse(source)
    node = Python2FutureTransformer().visit(node)
    module = ast.parse(python_source(imports.get_body(future='__future__')))
    assert ast.dump(node, include_attributes=True) == ast.dump(module, include_attributes=True)

# Generated at 2022-06-23 22:56:53.079933
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import ast as python_ast
    module = python_ast.parse('x = 1')
    Python2FutureTransformer().visit(module)

# Generated at 2022-06-23 22:56:58.816660
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse("""
    import os
    import sys
    """)
    expected = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    
    
    import os
    import sys
    """
    new_node = Python2FutureTransformer().visit(node)
    assert ast.dump(new_node) == ast.dump(ast.parse(expected))

# Generated at 2022-06-23 22:57:01.567704
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()
    assert t.target == (2, 7)
    assert repr(t) == "<Python2FutureTransformer:target=(2, 7)>"



# Generated at 2022-06-23 22:57:02.490927
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()


# Generated at 2022-06-23 22:57:11.007055
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():

    source = '''
    import os
    import sys
    import typing
    import datetime
    from flask import Flask 
    from flask import request 
    from flask import Response 
    from flask import jsonify 
    from flask import json 
    from google.cloud import bigquery
    from google.cloud import storage
    from google.auth.credentials import AnonymousCredentials

    def hello():
        print('Hello {}'.format('World'))
    '''


# Generated at 2022-06-23 22:57:20.075178
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()

    # Not a module
    assert transformer.visit(ast.Expr(value=ast.Name(id='x', ctx=ast.Load()))) == ast.Expr(value=ast.Name(id='x', ctx=ast.Load()))

    # Empty module
    assert transformer.visit(ast.Module(body=[])) == ast.Module(body=[])

    # Existing module with no body
    module: ast.Module = ast.Module(
        body=[ast.ImportFrom(module='future', names=[ast.alias(name='absolute_import', asname=None)], level=0)])
    expected_module: ast.Module = ast.Module(
        body=imports.get_body(future='__future__') + module.body)
    assert transformer.visit

# Generated at 2022-06-23 22:57:22.771462
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Unit test for constructor of class Python2FutureTransformer"""
    p = Python2FutureTransformer()
    assert p._tree_changed is False

# Generated at 2022-06-23 22:57:32.056494
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse("""
a = 1
    """)
    transformer = Python2FutureTransformer()
    node = transformer.visit(node)
    assert transformer._tree_changed == True
    print(ast.dump(node))

# Generated at 2022-06-23 22:57:33.628257
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    x = Python2FutureTransformer()
    assert isinstance(x, Python2FutureTransformer)


# Generated at 2022-06-23 22:57:43.724951
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source_to_ast as sta
    # TODO: Change to ast.parse()
    module = sta.parse(
        """
        def foo(a, b):
            return a, b
        """
    )
    assert isinstance(module, ast.Module)

# Generated at 2022-06-23 22:57:54.421846
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils import Code
    original_code = '''
        import os
        import shutil
        import sys
        from os import path
        from __future__ import absolute_import

        def copy_dir(dirname, new_dirname):
            shutil.copytree(dirname, new_dirname)

        def main():
            print('copying dir...')
            copy_dir(sys.argv[1], sys.argv[2])
            print('done!')

        if __name__ == '__main__':
            main()
    '''
    code = Code.from_string(original_code)
    code.apply_transform(Python2FutureTransformer)
    assert '__future__' in code.body[0].names[0].id
    assert '__future__' in code.body[0].names

# Generated at 2022-06-23 22:57:55.755071
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)

# Generated at 2022-06-23 22:58:01.953913
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .. import (
        BaseNodeTransformer,
        NullTransformer,
        PythonVersionReducer,
        Python2FutureTransformer,
        Python3PrintFunctionTransformer,
        Python2PrintFunctionTransformer,
        Python3DivisionTransformer,
        Python2DivisionTransformer,
        Python3StringFormattingTransformer,
        Python2StringFormattingTransformer,
    )

    # case: module with no doc string

# Generated at 2022-06-23 22:58:03.709177
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    ast_node = ast.parse("1")
    Python2FutureTransformer.check_tree_unchanged(ast_node)

# Generated at 2022-06-23 22:58:10.277240
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = ast.parse('print("Hello, world!")')
    module = Python2FutureTransformer().visit(module)

    assert module.body[0].lineno == 0
    assert module.body[0].col_offset == 0

    assert module.body[1].lineno == 0
    assert module.body[1].col_offset == 0

    assert module.body[2].lineno == 0
    assert module.body[2].col_offset == 0

    assert module.body[3].lineno == 0
    assert module.body[3].col_offset == 0

    assert module.body[4].lineno == 1
    assert module.body[4].col_offset == 0

# Generated at 2022-06-23 22:58:18.725691
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.fixtures import make_dummy_ast

    # Check imports
    tree = make_dummy_ast(1, 2)
    tree = Python2FutureTransformer()(tree)
    assert '__future__' in tree.body[0].names[0].s
    assert 'absolute_import' in tree.body[0].names[1].s
    assert 'division' in tree.body[0].names[2].s
    assert 'print_function' in tree.body[0].names[3].s
    assert 'unicode_literals' in tree.body[0].names[4].s

# Generated at 2022-06-23 22:58:20.747877
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Given
    from typed_ast import ast3 as ast

# Generated at 2022-06-23 22:58:26.607555
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astunparse
    from typed_ast import ast3 as ast

    #---
    code = """\
print('Hello World!')
"""
    tree = ast.parse(code)
    tree = Python2FutureTransformer().visit(tree)
    out = astunparse.unparse(tree)
    #---
    print(out)
    assert out == """\
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

print('Hello World!')
"""