

# Generated at 2022-06-23 22:48:31.302827
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from . import assert_equal, parse, CaseData
    module = parse('''
        import os
        print('Hello, world!')
    ''')
    transformer = Python2FutureTransformer()
    result = transformer.visit(module)
    assert_equal(
        CaseData(
            node=result,
            code='''
                from __future__ import absolute_import
                from __future__ import division
                from __future__ import print_function
                from __future__ import unicode_literals
                import os
                print('Hello, world!')
            '''
        )
    )

# Generated at 2022-06-23 22:48:40.752840
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .. import test_utils

    code = """\
    from __future__ import a
    from __future__ import b
    
    print(1)
    print(1, flush=True)
    """
    node = test_utils.build_ast(code, 2)
    Python2FutureTransformer(2,7).visit(node)
    code = test_utils.unparse(node)
    exec(code, globals())
    assert code == """\
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    from __future__ import a
    from __future__ import b
    
    print(1)
    print(1, flush=True)
    """

# Generated at 2022-06-23 22:48:49.485434
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    input_source = '''
import sys
import os
if __name__ == "__main__":
    print(sys.version)
    print(os.path)

'''
    output_source = Python2FutureTransformer().transform_source(input_source)
    assert output_source == '''
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

import sys
import os
if __name__ == "__main__":
    print(sys.version)
    print(os.path)

'''

# Generated at 2022-06-23 22:48:50.560806
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    x = Python2FutureTransformer(None)
    assert x is not None

# Generated at 2022-06-23 22:48:54.353642
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast.ast3 import parse
    tree = parse("a = 1")
    # Code before transformation
    print(astor.to_source(tree))
    transformer = Python2FutureTransformer()
    transformer.visit(tree)
    # Code after transformation
    print(astor.to_source(tree))

# Generated at 2022-06-23 22:48:56.808481
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    python_version = (2, 7)

# Generated at 2022-06-23 22:49:06.764800
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import six
    import sys
    from mypy_boto3_builder.utils.class_provider import ClassProvider
    from mypy_boto3_builder.tests.fakes import FakePackage

    class FakeModule(object):
        """Fake module for tests."""

        class Provider(ClassProvider):
            """Fake provider for tests."""

            def build(self):
                """Fake build method for tests."""
                return FakePackage("fake_module", {'fake_class': FakeClass})

        def __init__(self, name):
            self.__name__ = name

        def __getattr__(self, item):
            if item == "Provider":
                return self.Provider()
            raise ImportError("No module named {0}".format(item))

    class FakeClass(object):
        """Fake class for tests."""


# Generated at 2022-06-23 22:49:11.972119
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    actual_result = transform(Python2FutureTransformer, """
        def foo():
            pass
    """)

    expected_result = """
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        def foo():
            pass
   """

    assert_equal(actual_result, expected_result)

# Generated at 2022-06-23 22:49:13.989528
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    p2tf = Python2FutureTransformer()
    assert str(p2tf) == "<Python2FutureTransformer>"

# Generated at 2022-06-23 22:49:17.084891
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()
    assert(t._tree_changed is False)


# Generated at 2022-06-23 22:49:18.978648
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor


# Generated at 2022-06-23 22:49:27.398568
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..transformer.base import BaseNodeTransformer


# Generated at 2022-06-23 22:49:34.080593
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..sdplugins.code_transformers import CodeTransformer
    from ..utils.code_snippet import CodeSnippet

    code = CodeSnippet("""
        print("Hello world.")
        """)
    transformer = Python2FutureTransformer()
    transformer.apply_transformation_on_snippet(code)

    assert code.source == \
        """from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

print("Hello world.")
"""

# Generated at 2022-06-23 22:49:38.507970
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast

    tree = ast.parse('a=1', mode='exec')
    Python2FutureTransformer().visit(tree)
    code = compile(tree, '<unknown>', mode='exec')

# Generated at 2022-06-23 22:49:48.623768
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import ast
    import os
    # Read code from file
    path_of_this_file = os.path.abspath(__file__)
    path_of_this_dir = os.path.split(path_of_this_file)[0]
    test_case_file_path = os.path.join(path_of_this_dir, 'test_cases/test_python2_future_transformer.py')
    with open(test_case_file_path, 'rt') as file:
        file_data = file.read()

    # Construct AST from code
    file_ast = ast.parse(file_data)

    # Get target AST node
    test_node = file_ast.body[0]

    # Construct and run the transformer
    transformer = Python2FutureTransformer()

# Generated at 2022-06-23 22:49:54.791253
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    code = "import six"
    tree = ast.parse(code)
    tree = Python2FutureTransformer().visit(tree)
    code_after_transformation = astunparse.unparse(tree)
    expected_code = """\
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
import six"""
    assert(code_after_transformation == expected_code)

# Generated at 2022-06-23 22:50:00.730001
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    node = ast.parse('print("Hello World!")')
    new_node = transformer.visit(node)
    assert str(new_node) == str(ast.parse("""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

print("Hello World!")
    """))

# Generated at 2022-06-23 22:50:04.672788
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    new_ast = Python2FutureTransformer().visit(snippet.get_ast('pass'))
    assert ast.dump(new_ast) == ast.dump(imports.get_ast(future='__future__') + snippet.get_ast('pass'))

# Generated at 2022-06-23 22:50:13.436141
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    with pytest.raises(TypeError) as exception:
        from typed_ast import ast3 as ast
        from ast_transformer.utils.explain import explain_exception
        from .snippets.python2 import module_func

        tree = ast.parse(module_func)
        transformer = Python2FutureTransformer()
        transformer.visit(tree)
        for node in transformer.modified_nodes:
            print('\n', node._fields)
        print(ast.dump(tree))
    assert 'Expected type ast3.Module, got ast3.FunctionDef' in str(exception.value)

    from typed_ast import ast3 as ast
    from ast_transformer.utils.explain import explain_exception
    from .snippets.python2 import module

    tree = ast.parse(module)
   

# Generated at 2022-06-23 22:50:19.000343
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..testing import assert_transform
    assert_transform(
        Python2FutureTransformer,
        before="",
        after="""from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
""",
        expected_changes=1,
    )

# Generated at 2022-06-23 22:50:19.559621
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass

# Generated at 2022-06-23 22:50:22.927952
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .base import BaseTestTransformer
    from ..common import Registry
    registry = Registry()
    registry.register_transformer(Python2FutureTransformer)
    BaseTestTransformer(registry, globals()).run_test('Python2FutureTransformer_visit_Module',
                                                      'Python2FutureTransformer')

# Generated at 2022-06-23 22:50:29.295256
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import sys

    source = '''
data = "somedata"
'''

    expected = '''
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals


data = "somedata"
'''

    tree = ast.parse(source)
    tree = Python2FutureTransformer().visit(tree)
    assert astunparse.unparse(tree).strip() == expected.strip()

# Generated at 2022-06-23 22:50:38.581284
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformerTest
    import unittest

    class Python2FutureTransformerTest(BaseNodeTransformerTest):
        transformer = Python2FutureTransformer
        target = (2, 7)


        @snippet
        def snippet1():
            pass


        def test_Module1(self):
            snippet = self.snippet1
            tree = snippet.get_tree()
            target_tree = snippet.get_tree()

# Generated at 2022-06-23 22:50:45.438973
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import textwrap
    from typed_ast.ast3 import parse
    from ..utils.helpers import dumb_visit, assert_parse_equal

    code = '''\
    a = 1
    print(a)
    '''
    tree = parse(textwrap.dedent(code))
    tree = dumb_visit(Python2FutureTransformer(), tree)

    assert_parse_equal(tree, imports + code)

# Generated at 2022-06-23 22:50:48.775415
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    # Check the nature of the instances
    obj = Python2FutureTransformer()
    assert isinstance(obj, Python2FutureTransformer)
    assert isinstance(obj, BaseNodeTransformer)
    # --- END ---


# Generated at 2022-06-23 22:50:56.645873
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import textwrap
    from ..utils import assert_ast_transformed, get_ast_for
    from .. import transformers

    source = textwrap.dedent('''\
        def a():
            pass
    ''')
    expected_source = textwrap.dedent('''\
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        def a():
            pass
    ''')

    ast_source = get_ast_for(source)
    ast_expected = get_ast_for(expected_source)
    assert_ast_transformed(ast_source, ast_expected, transformers.all)

# Generated at 2022-06-23 22:50:57.438772
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-23 22:50:59.961692
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3
    node = ast3.parse('')
    Python2FutureTransformer(node)


# Generated at 2022-06-23 22:51:01.552566
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer().__class__.__name__ == "Python2FutureTransformer"

# Generated at 2022-06-23 22:51:02.726061
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()


# Generated at 2022-06-23 22:51:08.799106
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    source = """
    import future

    import past
    import present
    """
    tree = ast.parse(source)
    Python2FutureTransformer().visit(tree)
    print(astor.to_source(tree))
    expected = """
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

import future

import past
import present
"""
    assert astor.to_source(tree) == expected

# Generated at 2022-06-23 22:51:09.610876
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()
    assert t

# Generated at 2022-06-23 22:51:14.691688
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_astunparse import unparse
    src = """x = 1
y = '2'
z = 4
"""
    expected = imports.prepend(src)
    node = ast.parse(src)
    trf = Python2FutureTransformer()
    actual = unparse(trf.visit(node))
    assert actual == expected

# Generated at 2022-06-23 22:51:20.474460
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    from ..utils import parse
    from .common import CommonTransformerMixin

    source = """
a = 42
    """

    class T(CommonTransformerMixin, Python2FutureTransformer):
        pass

    mod = parse(source)
    mod = T.run_on(mod)
    assert astor.to_source(mod) == """
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

a = 42
    """

# Generated at 2022-06-23 22:51:30.921942
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import os
    import sys
    import astor
    from bowling import roll, BowlingGame
    from ..utils.fixtures import standard_test_env  # type: ignore
    from ..utils.fixtures import python_2_file  # type: ignore
    from . import python_2_target  # type: ignore

    test_env = standard_test_env()
    bowling_game_module = BowlingGame()
    code_path = test_env.get_temp_path(python_2_file)
    with open(code_path, 'w') as source_file:
        source_file.write(astor.to_source(bowling_game_module.get_ast()))

    sys.path.append(os.path.dirname(code_path))


# Generated at 2022-06-23 22:51:32.741093
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    node_transformer = Python2FutureTransformer
    node_transformer()


# Generated at 2022-06-23 22:51:42.478898
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Given
    from ..utils.fixtures import make_module_ast
    from ..utils.files import write_to_tempfile

    # Transformer
    tf = Python2FutureTransformer()

    # When
    for ver in (2, 3):
        tree = make_module_ast
        if ver == 2:
            tree = tree('if True: print "foo"\n')

        t = tree('')
        assert not tf.visit(t)
        assert not tf._tree_changed

        t = tree('import sys\nprint sys\n')
        assert not tf.visit(t)
        assert tf._tree_changed

    # When
    t = make_module_ast('import sys\nprint sys\n')
    t = tf.visit(t)
    assert t

    # Then
    #

# Generated at 2022-06-23 22:51:52.091893
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_body = '''\
print("Python", "2")
'''
    expected_body = '''\
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

print("Python", "2")
'''

    module = ast.parse(module_body)
    assert module.body[0].lineno == 1
    assert str(module).strip() == module_body.strip()

    module = Python2FutureTransformer().visit(module)
    assert module.body[0].lineno == 1
    assert module.body[1].lineno == 1
    assert module.body[2].lineno == 1
    assert module.body[3].lineno == 1
    assert str(module).strip() == expected_body.strip

# Generated at 2022-06-23 22:51:53.543525
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .visitor_test import visi

# Generated at 2022-06-23 22:51:56.311136
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .base import BaseNodeTransformer
    from typed_ast import ast3
    from ..typed_ast_unparse import unparse


# Generated at 2022-06-23 22:51:56.850494
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass

# Generated at 2022-06-23 22:52:03.690140
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    tree = ast.parse("print('hello')") 
    t = Python2FutureTransformer()
    new_tree = t.visit(tree)

# Generated at 2022-06-23 22:52:11.022031
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    tree = ast.parse(
"""
from __future__ import foo
# comment
from __future__ import bar
from __future__ import with_statement
""")
    rt = Python2FutureTransformer()
    rt.visit(tree)
    assert rt._tree_changed
    assert ast.dump(tree) == (
"""from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
from __future__ import foo
# comment
from __future__ import bar
from __future__ import with_statement
""")

# Generated at 2022-06-23 22:52:12.405477
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()


# Generated at 2022-06-23 22:52:18.686716
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .test_utils import make_test_tree
    from .test_utils import generate_python_source

    tree = make_test_tree('print("Hello World")')
    transformer = Python2FutureTransformer()
    tree = transformer.visit(tree)
    source = generate_python_source(tree)
    assert source == """from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

print("Hello World")"""



# Generated at 2022-06-23 22:52:19.882040
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.target == (2, 7)

# Generated at 2022-06-23 22:52:26.330345
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse("""\
f = 1
""")

    node = Python2FutureTransformer().visit(node)
    expected = ast.Module(body=[
        ast.ImportFrom(module='__future__', names=[
            ast.alias(name='absolute_import', asname=None),
            ast.alias(name='division', asname=None),
            ast.alias(name='print_function', asname=None),
            ast.alias(name='unicode_literals', asname=None)
        ], level=0),
        ast.Assign(targets=[ast.Name(id='f', ctx=ast.Store())], 
                   value=ast.Num(n=1)),
    ])

    assert ast.dump(node) == ast.dump(expected)

# Generated at 2022-06-23 22:52:31.993295
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import os
    import astor
    import typed_ast.ast3
    from tatsu.tool import compile
    from .. import grammar
    import inspect

    module_name = os.path.splitext(os.path.basename(__file__))[0]
    path_to_this_file = os.path.dirname(os.path.abspath(__file__))
    path_to_grammar_file =  os.path.join(path_to_this_file, '..', '..', 'grammar', 'Python.ebnf')

    with open(path_to_grammar_file, 'r') as f:
        grammar_text = f.read()
    p = compile(grammar_text, asmodel=True)


# Generated at 2022-06-23 22:52:39.384645
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import sys
    import typed_astunparse
    import astor

    # Test that imports are prepended to the module

    module_source = '''
x = 1
print(x+0)
    '''

    module = astor.parse_file(StringIO(module_source))
    Python2FutureTransformer.run(module)

    expected = '''
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

x = 1
print(x+0)
    '''

    assert typed_astunparse.unparse(module) == expected

# Generated at 2022-06-23 22:52:46.239511
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_dummy_file, make_code_snippet
    from ..utils.source import Source
    from ..utils.ast_builder import ASTBuilder
    from ..transformers.python2_future import Python2FutureTransformer

    ast_module = ASTBuilder.parse(make_code_snippet("""\
        import sys
        import datetime
        import this
    """))

    transformer = Python2FutureTransformer()
    transformer.visit(ast_module)

    new_source = Source.from_AST_node(ast_module)
    new_code = new_source.to_code()


# Generated at 2022-06-23 22:52:55.659696
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-23 22:52:56.612964
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer(target=(2, 7))

# Generated at 2022-06-23 22:53:07.014817
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast

    class Test(ast.NodeVisitor):
        def visit_Module(self, node):
            print('mod')

        def generic_visit(self, node):
            print(node.__class__.__name__)

    t = Test()
    t.visit(ast.parse("print('Hello World!');"))
    __qualname__ = 'translators.dst.Python2FutureTransformer'  # type: ignore
    value = '''from future import absolute_import
from future import division
from future import print_function
from future import unicode_literals

print('Hello World!');'''

# Generated at 2022-06-23 22:53:12.455022
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.sample_code import REGRESSION_TEST

    # Test if transformer does not modify a source file if 
    # it does not need to be changed.
    code = REGRESSION_TEST
    ast_tree = ast.parse(code)
    transformer = Python2FutureTransformer()
    transformer.visit(ast_tree)
    assert code == astor.to_source(ast_tree)

    # Test if transformer did insert missing imports
    transformer._tree_changed = False
    code = textwrap.dedent("""

        def f(x):
            return x
        """)
    ast_tree = ast.parse(code)
    transformer.visit(ast_tree)
    assert transformer._tree_changed
    new_code = astor.to_source(ast_tree)

# Generated at 2022-06-23 22:53:16.557847
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import ast
    t = Python2FutureTransformer(ast.parse('x = 1\nprint(x + x)'))
    assert str(t) == 'from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n\nx = 1\nprint(x + x)'

# Generated at 2022-06-23 22:53:18.888702
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    py2ft = Python2FutureTransformer()
    assert py2ft is not None

# Generated at 2022-06-23 22:53:27.554371
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module = ast.parse("""
    import ast
    import six

    if six.PY2:
        import __future__
    """)
    assert (module.body[0].names[0].name == 'ast' and
            module.body[1].names[0].name == 'six' and
            module.body[3].names[0].name == '__future__')
    module = Python2FutureTransformer().visit(module)  # type: ignore
    assert isinstance(module, ast.Module)

# Generated at 2022-06-23 22:53:29.102650
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer


# Generated at 2022-06-23 22:53:35.560808
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    kwargs = {'future': '__future__'}
    expected_output = imports.get_body(**kwargs)
    # Create sample "ast" nodes to be passed to method under test
    module = ast.Module([])
    # Call method under test
    node_transformer = Python2FutureTransformer(inspect.currentframe())
    updated_module = node_transformer.visit_Module(module)
    # Check if the output is expected
    assert expected_output == updated_module.body

# Generated at 2022-06-23 22:53:46.029041
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source2ast
    from ..utils.source import ast2source
    from ..utils.source import assert_same_source
    from ..utils.source import make_module
    from ..utils.source import make_function
    from ..utils.source import make_statement
    from ..utils.source import make_assignment
    from . import patch_sys_modules
    from . import remove_sys_modules_patch

    # Test module without body
    code = make_module([], body=[])
    ast_module = source2ast(code)
    expected_module = source2ast(imports.get_code(future='__future__') + code)
    with patch_sys_modules():
        transformer = Python2FutureTransformer()
        result_module = transformer.visit(ast_module)
        assert_same_source

# Generated at 2022-06-23 22:53:53.822196
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    input = """\
x = 'string'
y = u'string'"""
    expected = """\
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

x = 'string'
y = u'string'"""
    node = ast.parse(input)
    Python2FutureTransformer.run(node)
    actual = ast.unparse(node)
    assert actual == expected


if __name__ == '__main__':
    # from pathlib import Path
    # from pprint import pprint
    from time import time
    from .utils import save_transformed, show_diff

    # path = Path('./tests/resources/Python2FutureTransformer/')
    # for python_file in path.glob('

# Generated at 2022-06-23 22:53:54.717262
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-23 22:54:00.356566
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .test_utils import transform, compare

    compare(
        Python2FutureTransformer,
        """
        def foo():
            pass
        """,
        """
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        def foo():
            pass
        """,
    )



# Generated at 2022-06-23 22:54:01.114450
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-23 22:54:07.495474
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Given
    """
    
    """
    module = ast.Module([
        ast.Import(
            names=[ast.alias(name='os', asname=None)],
            lineno=1,
            col_offset=0,
        )
    ])
    # When
    transformer = Python2FutureTransformer()
    new_module = transformer.visit(module)
    # Then
    assert new_module.body[0].names[0].name == 'future'
    assert new_module.body[0].lineno == 1
    assert new_module.body[1].names[0].name == 'os'
    assert new_module.body[1].lineno == 2

# Generated at 2022-06-23 22:54:13.533454
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Arrange
    module = ast.parse('''
import a
import b as c
from e import f

a = a
b = c
c = f

''')
    
    # Act
    Python2FutureTransformer().visit(module)
    
    # Assert
    expected = ast.parse('''
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
import a
import b as c
from e import f

a = a
b = c
c = f

''')
    assert ast.dump(module) == ast.dump(expected)

# Generated at 2022-06-23 22:54:20.048484
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    s = """
    print('x')
    """
    src = astor.to_source(Python2FutureTransformer().visit(ast.parse(s)))
    expect = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    print('x')
    """
    assert src == expect

# Generated at 2022-06-23 22:54:31.553024
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    tree = ast.parse('print("Hello, world!")')
    Python2FutureTransformer().visit(tree)

# Generated at 2022-06-23 22:54:39.977022
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """ Test for Python2FutureTransformer (pylama_future.transformers.py)"""
    import inspect
    import six
    from pylint.testutils import TestReport
    from pylint.lint import Run
    from . import transformers as tr
    from ..utils.snippet import snippet
    from ..utils.testing import (
        get_file_paths, get_file_string, get_node_object, get_pylama_plugins,
        load_ast_tree, update_linter
    )

    file_paths = get_file_paths()
    if file_paths:

        # AST tree
        ast_tree = load_ast_tree(file_paths)

        # Get instance of Python2FutureTransformer class
        item_name = 'Python2FutureTransformer'

# Generated at 2022-06-23 22:54:46.483022
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    with open('tests/resources/python/src/test_transform_source.py') as f:
        test_source = f.read()
    node = ast.parse(test_source)
    # make sure source is correct
    assert astor.to_source(node) == test_source, 'source must not be changed'
    # transform source
    node = Python2FutureTransformer().visit(node)
    # check source
    assert astor.to_source(node) == transforms['future']['2.7'], 'source must be changed'

# Generated at 2022-06-23 22:54:50.791283
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert (Python2FutureTransformer().target == (2,7))
    import astor
    transformer = Python2FutureTransformer()

# Generated at 2022-06-23 22:54:51.388821
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-23 22:54:55.758157
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_node = ast.parse("a=1\n")
    module_node2 = Python2FutureTransformer().visit(module_node)
    assert(ast.dump(module_node2) == ast.dump(ast.parse(imports().strip()+"\na=1\n")))

# Generated at 2022-06-23 22:55:02.866947
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()
    tree = ast.parse('a = 4 + 6')
    transformer.visit(tree)
    expected_result = 'from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n\na = 4 + 6'  # NOQA
    assert astor.to_source(tree) == expected_result

# Generated at 2022-06-23 22:55:13.552647
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from pytest_descriptions import describe, it, context
    from ..utils import make_snippet, parse_ast
    from ..utils.tree_compare import compare_trees, TreeMismatch
    
    
    with describe('append __future__ imports to the beginning of the module'):
        with context('when no imports present'):
            _snippet = make_snippet('''
                pass
            ''')
            _expected = make_snippet('''
                from __future__ import absolute_import
                from __future__ import division
                from __future__ import print_function
                from __future__ import unicode_literals
                pass
            ''')
            result = Python2FutureTransformer.apply(_snippet)  
            compare_trees(_expected, result)
            pass
            

# Generated at 2022-06-23 22:55:16.866894
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__doc__ is not None
    assert Python2FutureTransformer.target == (2, 7)
    obj = Python2FutureTransformer()
    assert obj is not None


# Generated at 2022-06-23 22:55:22.806914
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast

    node = ast.parse(textwrap.dedent('''
    from __future__ import print_function
    from __future__ import division
    from typed_ast import ast3 as ast

    if __name__ == "__main__":
        pass
    '''), future_features=['division'], mode='exec')
    old_len = len(node.body)
    t = Python2FutureTransformer()
    res = t.visit(node)
    assert len(res.body) == old_len

# Generated at 2022-06-23 22:55:28.326698
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    code = """
    import six
    import future

    def func():
        pass
    """
    expected = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    
    import six
    import future
    
    
    def func():
        pass
    """
    tree = ast.parse(code)
    trans = Python2FutureTransformer()
    new_tree = trans.visit(tree)
    assert ast.dump(new_tree) == expected

# Generated at 2022-06-23 22:55:32.633102
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse('from __future__ import unicode_literals\nfrom future import print_function')
    assert node.body[0].value.id == 'print_function'
    transformer = Python2FutureTransformer()
    transformer.visit(node)
    assert node.body[0].value.id == 'absolute_import'

# Generated at 2022-06-23 22:55:33.434810
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-23 22:55:34.828163
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from asttokens import ASTTokens


# Generated at 2022-06-23 22:55:41.743806
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    print('Testing method visit_Module of class Python2FutureTransformer')
    print('Not yet implemented')

    # test_body_content = [ast.ImportFrom(module='__future__', names=[ast.alias(name='absolute_import', asname=None)], level=0)]
    #
    # test_node = ast.Module(body=test_body_content)
    # test_transformer = Python2FutureTransformer()
    # test_transformer.visit_Module(test_node)
    # assert test_node.body[0] == imports.get_body(future='__future__')[0]



# Generated at 2022-06-23 22:55:42.919914
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert isinstance(Python2FutureTransformer(), Python2FutureTransformer)

# Generated at 2022-06-23 22:55:44.116914
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
  class_ = Python2FutureTransformer()
  assert class_ is not None

# Generated at 2022-06-23 22:55:51.516085
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == "Python2FutureTransformer"
    assert Python2FutureTransformer.__doc__ == "Prepends module with:\n        from __future__ import absolute_import\n        from __future__ import division\n        from __future__ import print_function\n        from __future__ import unicode_literals\n            \n    "
    assert Python2FutureTransformer.target == (2, 7)
    assert Python2FutureTransformer.__module__ == "typed_python.compiler.transforms.Python2FutureTransformer"

# Generated at 2022-06-23 22:55:58.199456
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()
    module = ast.parse('print("Hello world")')
    expected_result = ast.parse(
        'from __future__ import absolute_import\n'
        'from __future__ import division\n'
        'from __future__ import print_function\n'
        'from __future__ import unicode_literals\n'
        '\n'
        'print("Hello world")'
    )
    assert transformer.visit(module) == expected_result

# Generated at 2022-06-23 22:56:07.585937
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    def test_transformer(transformer, code):
        tree = ast.parse(code)
        for node in ast.walk(tree):
            transformer.visit(node)
        return tree

    t = Python2FutureTransformer()
    assert test_transformer(t, 'x = 1') == ast.parse('from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\nx = 1')
    assert test_transformer(t, 'a = 4; b = 5; c = 6') == ast.parse('from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\na = 4; b = 5; c = 6')

# Generated at 2022-06-23 22:56:11.881081
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.tree_changed == False
    assert transformer.target == (2, 7)
    assert transformer.skip_child_visitation == False
    assert transformer.new_code == ""

# Generated at 2022-06-23 22:56:15.834216
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    print(ast.dump(Python2FutureTransformer().visit(imports.get_ast(None))))
    print(Python2FutureTransformer().transform(imports.get_source(None)))


if __name__ == "__main__":
    test_Python2FutureTransformer()

# Generated at 2022-06-23 22:56:21.548405
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor as ast

    node: ast.Module = ast.parse("x = 5")
    node = Python2FutureTransformer().visit(node)
    expected: ast.Module = ast.parse("""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
x = 5""")
    assert ast.dump(node) == ast.dump(expected)

# Generated at 2022-06-23 22:56:23.525870
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass
        

# Generated at 2022-06-23 22:56:24.912964
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    x = Python2FutureTransformer()
    print(x)



# Generated at 2022-06-23 22:56:26.142972
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.target == (2, 7)

# Generated at 2022-06-23 22:56:29.382050
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils import python_to_python_typed as p2pt


# Generated at 2022-06-23 22:56:34.893423
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    transformer = Python2FutureTransformer(
        from_version=(2, 7),
        to_version=(3, 7),
        initial_state=None,
        is_fix=None
    )

    tree = ast.parse("module_body = ''")
    tree = transformer.visit(tree)

    assert tree.body[0].value.s == 'absolute_import'

# Generated at 2022-06-23 22:56:45.917670
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():

    import astor

    from typed_ast import ast3 as ast

    from typed_astunparse import unparse


# Generated at 2022-06-23 22:56:48.711423
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = ast.parse('''
        a = 1
    ''')
    visitor = Python2FutureTransformer(module)
    module = visitor.visit(module)
    assert module.body[0].value.func.value.id == 'print_function'

# Generated at 2022-06-23 22:56:49.686765
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-23 22:56:54.038614
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..example.python_2_7 import module
    transformer = Python2FutureTransformer()
    result = transformer.visit(module.node)
    assert transformer._tree_changed
    assert result.body == imports.get_body(future='__future__') + module.node.body

# Generated at 2022-06-23 22:57:00.780431
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor

    code = "import os\nprint('hello')\n"
    expected = "from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n\nimport os\nprint('hello')\n"
    tree = astor.parse_file(StringIO(code))
    # astor.dump(tree)
    transformer = Python2FutureTransformer()
    tree = transformer.visit(tree)
    result = astor.to_source(tree)
    assert result == expected

# Generated at 2022-06-23 22:57:02.186279
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.target == (2, 7)



# Generated at 2022-06-23 22:57:07.226742
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    source = '''
a = 1
b = 2
c = 3
'''
    expected = '''
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
a = 1
b = 2
c = 3
'''
    module, info = transform(source, Python2FutureTransformer)
    assert(expected == module)



# Generated at 2022-06-23 22:57:18.078121
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Arrange
    import_node = ast.ImportFrom(module='__future__', names=[
                                 ast.alias(name='absolute_import', asname=None),
                                 ast.alias(name='division', asname=None),
                                 ast.alias(name='print_function', asname=None),
                                 ast.alias(name='unicode_literals', asname=None)], level=0)

# Generated at 2022-06-23 22:57:26.045858
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Arrange
    code = 'x = 1\n'
    expected_code = 'from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\nx = 1\n'
    tree = ast.parse(code)
    node_transformer = Python2FutureTransformer()

    # Act
    node_transformer.visit(tree)
    code = astunparse.unparse(tree)

    # Assert
    assert code == expected_code

# Generated at 2022-06-23 22:57:31.821607
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():

    # Given
    node = ast.parse('a=1\n')

    # When
    actual = Python2FutureTransformer().visit(node)

    # Then
    expected = ast.parse("from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n\na=1\n")
    ast.fix_missing_locations(expected)
    assert ast.dump(actual) == ast.dump(expected)

# Generated at 2022-06-23 22:57:34.362943
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'

# Generated at 2022-06-23 22:57:40.799187
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    code = '''
    class Foo:
        pass
    '''
    expected = '''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    class Foo:
        pass
    '''
    result = transform_ast(code, Python2FutureTransformer)
    assert result == expected.strip()
    assert result.code == expected.strip()

# Generated at 2022-06-23 22:57:44.850348
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..testing_utils import make_test_module
    from ..testing_utils import make_test_module_from_transformed
    from ..testing_utils import assert_tree_not_equal
    from ..testing_utils import assert_tree_equal
    module = make_test_module()
    transformer = Python2FutureTransformer(module)
    tr_module = make_test_module_from_transformed(transformer)
    assert_tree_not_equal(tr_module, module)
    assert_tree_equal(tr_module, imports.get_ast(future='__future__')) # type: ignore

# Generated at 2022-06-23 22:57:45.691179
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()



# Generated at 2022-06-23 22:57:48.949169
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_fixtures
    from typed_ast import ast3 as ast


# Generated at 2022-06-23 22:57:59.918914
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .base import BaseTestTransformer

    class Test(BaseTestTransformer):
        transformer = Python2FutureTransformer

        def test_simple(self):
            # Python2:
            #     foo = 1
            #
            # Result:
            #     from __future__ import absolute_import
            #     from __future__ import division
            #     from __future__ import print_function
            #     from __future__ import unicode_literals
            #
            #     foo = 1
            source = 'foo = 1'
            desired = (
                "from __future__ import absolute_import\n"
                "from __future__ import division\n"
                "from __future__ import print_function\n"
                "from __future__ import unicode_literals\n\n"
                "{source}"
            )
            self

# Generated at 2022-06-23 22:58:03.913970
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import check_transformer
    from .python2_compatible_transformer import Python2CompatibleTransformer

    check_transformer(Python2FutureTransformer)
    check_transformer(Python2FutureTransformer, Python2CompatibleTransformer)



# Generated at 2022-06-23 22:58:05.153821
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == "Python2FutureTransformer"

# Generated at 2022-06-23 22:58:08.187067
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    tree = ast.parse(textwrap.dedent(
        """
        def f():
            return 1
        """
    ))
    transformer.visit(tree)
    assert transformer._tree_changed



# Generated at 2022-06-23 22:58:09.800511
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    trans = Python2FutureTransformer()
    assert trans is not None
    assert trans._tree_changed == False

# Generated at 2022-06-23 22:58:13.936625
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    tree = ast.parse("""
            import sys
            from future import absolute_import
            from future import division
            from future import print_function
            from future import unicode_literals
            
            print("hello")
            """)
    transformer = Python2FutureTransformer()
    assert transformer.visit(tree) == tree

# Generated at 2022-06-23 22:58:21.640018
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    tree_Module_0 = ast.Module()
    tree_Module_0.body = []
    transformer = Python2FutureTransformer()
    result = transformer.visit_Module(tree_Module_0)
    assert result.body[0].names[0].name == 'absolute_import'
    assert result.body[0].names[1].name == 'division'
    assert result.body[0].names[2].name == 'print_function'
    assert result.body[0].names[3].name == 'unicode_literals'

# Generated at 2022-06-23 22:58:23.630649
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()
    assert(t.target == (2, 7))
    assert(t._tree_changed == False)
    assert(t.version == (3, 6))

# Generated at 2022-06-23 22:58:28.656633
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    source = '''
    import sys
    if sys.version_info.major < 3:
        raise ValueError("Must be using Python 3")
    '''
    target = '''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    import sys
    if sys.version_info.major < 3:
        raise ValueError("Must be using Python 3")
    '''
    test_transform_module(Python2FutureTransformer, source, target)