

# Generated at 2022-06-23 22:48:23.172600
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass



# Generated at 2022-06-23 22:48:32.615321
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor
    from .test_base import BaseNodeTest
    from .test_base import strip
    from .test_base import yaml_to_ast_and_back

    class Test(BaseNodeTest):
        target = Python2FutureTransformer
        code = """
            import os
            import sys
            import re
            import glob
            import pprint
            """
        result = """
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals

            import os
            import sys
            import re
            import glob
            import pprint
            """

    import sys
    if sys.version_info < Test.target.target:
        Test.skipTest('Functionality not available before Python 3')
    else:
        y

# Generated at 2022-06-23 22:48:33.737607
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer(imports) == imports

# Generated at 2022-06-23 22:48:40.103025
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # given
    transformer = Python2FutureTransformer()

    # when
    transformed = transformer.visit(ast.parse('''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    import os'''))

    # then
    assert ast.dump(transformed) == ast.dump(ast.parse('''
    import os'''))

# Generated at 2022-06-23 22:48:51.145243
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..transformers_tests.test_utils import check_node_changed, check_node_not_changed

    transformer = Python2FutureTransformer()
    check_node_changed(
        transformer,
        'import os',
        'from __future__ import absolute_import\n'
        'from __future__ import division\n'
        'from __future__ import print_function\n'
        'from __future__ import unicode_literals\n\n'
        'import os'
    )

# Generated at 2022-06-23 22:48:52.138634
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()

# Generated at 2022-06-23 22:49:00.134382
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import textwrap
    
    # Setup
    node = ast.parse(textwrap.dedent("""
    # comment one
    def foo():
        print('hello')
    """))
    
    # Exercise
    visitor = Python2FutureTransformer()
    visitor.visit(node)
    
    # Verify

# Generated at 2022-06-23 22:49:02.912768
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .test_transformer_base import check_assertions
    check_assertions(Python2FutureTransformer, Python2FutureTransformer.visit_Module, __file__)


# Generated at 2022-06-23 22:49:11.684158
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    import textwrap
    source = textwrap.dedent(r"""
        def test():
            print('test')
        """)
    tree = ast.parse(source)
    transformer = Python2FutureTransformer()
    result = transformer.visit(tree)
    expected_source = textwrap.dedent(r"""
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        def test():
            print('test')
        """)
    expected_tree = ast.parse(expected_source)
    assert ast_equal(result, expected_tree)

# Generated at 2022-06-23 22:49:18.289254
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3
    from new import classobj
    actual_module = ast3.parse('pass')
    assert isinstance(actual_module, ast3.Module)
    actual_module.body.append(ast3.copy_location(ast3.parse('a: int').body[0], actual_module))
    actual_module.body.append(ast3.copy_location(ast3.parse('b: int').body[0], actual_module))
    actual_module.body.append(ast3.copy_location(ast3.parse('c: int').body[0], actual_module))
    actual_module = classobj('module', (ast3.Module,), {})(body=actual_module.body)
    expected_transformer = Python2FutureTransformer(target=(2, 7))
    assert expected_transformer

# Generated at 2022-06-23 22:49:19.125589
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-23 22:49:20.056283
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-23 22:49:27.585800
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils import roundtrip
    from ..node_visitor import ASTNodeTransformer
    code_out = roundtrip(code='print("hello world")',
                         transformer=ASTNodeTransformer(modules=[Python2FutureTransformer]),
                         stage='specialize',
                         python_version=(2, 7))
    assert_equal(code_out, imports.get_code(future='__future__') + '\nprint("hello world")')
    code_out = roundtrip(code='import foo',
                         transformer=ASTNodeTransformer(modules=[Python2FutureTransformer]),
                         stage='specialize',
                         python_version=(2, 7))
    assert_equal(code_out, imports.get_code(future='__future__') + '\nimport foo')

# Generated at 2022-06-23 22:49:37.876378
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    code = textwrap.dedent('''\
        import gc
        import io
        import json
        import os
        import re
        import subprocess
        import sys
        import tempfile
        import time
        import zlib
        
        def main():
            pass
        
        if __name__ == '__main__':
            main()
    
    ''')

# Generated at 2022-06-23 22:49:38.838443
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-23 22:49:41.149385
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    future = Python2FutureTransformer()
    assert future is not None
    assert future.visit is not None


# Generated at 2022-06-23 22:49:46.600822
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()
    node = ast.parse(textwrap.dedent('''\
        def hello_world():
            return 'Hello World!'
        '''))
    expected = ast.Module(body=imports.get_body(future='__future__') + node.body)  # type: ignore

    actual = transformer.visit(node)
    assert actual == expected

# Generated at 2022-06-23 22:49:48.592372
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    trans = Python2FutureTransformer()
    assert trans._tree_changed == False
    assert trans.target == (2, 7)


# Generated at 2022-06-23 22:49:49.858379
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import ast

# Generated at 2022-06-23 22:49:51.458463
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()
    assert(isinstance(t, BaseNodeTransformer))


# Generated at 2022-06-23 22:49:52.874012
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer is not None


# Generated at 2022-06-23 22:49:53.895038
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import io

# Generated at 2022-06-23 22:49:58.929685
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .base import BaseTestVisitor
    from ..utils import source_conversion, uast

    class UnitTestPython2FutureTransformer(BaseTestVisitor):
        target = Python2FutureTransformer.target
        version = Python2FutureTransformer.version
        transformer = Python2FutureTransformer
    
    UnitTestPython2FutureTransformer().test()

# Generated at 2022-06-23 22:50:00.876679
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)



# Generated at 2022-06-23 22:50:03.854771
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2,7) 
    assert transformer.future_imports == ()
    assert transformer._tree_changed == False



# Generated at 2022-06-23 22:50:12.977509
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from .identity import IdentityTransformer
    from .unparse import UnparseTransformer
    from .visit import visit_transformer

    it = visit_transformer(IdentityTransformer())
    ft = Python2FutureTransformer()
    ut = visit_transformer(UnparseTransformer())

    code = '''
    x = 1
    '''
    x = ast.parse(code)
    x = it.visit(x)
    x = ft.visit(x)
    x = ut.visit(x)
    x = '\n'.join(x.rstrip().split('\n')[1:])


# Generated at 2022-06-23 22:50:24.005581
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    parser = ast.parse
    unparser = compile
    transformer = Python2FutureTransformer(parser, unparser)


# Generated at 2022-06-23 22:50:30.668022
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    inp = """foo = 1
    bar = 2"""

    expected = """from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

foo = 1
    bar = 2"""
    
    tree = ast.parse(inp)
    nt = Python2FutureTransformer()
    new_tree = nt.visit(tree)

    check_transformer(expected, new_tree)




# Generated at 2022-06-23 22:50:32.126066
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer  # avoid warning: unused variable

# Generated at 2022-06-23 22:50:37.536806
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    code = '''
    # comment
    '''
    expected = '''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    # comment
    '''
    node = ast.parse(code)
    Python2FutureTransformer().visit(node)
    result = ast.unparse(node)
    assert result == expected

# Generated at 2022-06-23 22:50:47.944599
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import ast
    class FakeNode:
        def __init__(self) -> None:
            self.body = []  # type: Any

    # x = 1
    body = ast.Expr(ast.Num(1))
    module = FakeNode()
    module.body.append(body)

    transformer = Python2FutureTransformer()
    transformer.visit_Module(module)

    assert len(module.body) == 5
    for value in module.body[:4]:
        assert isinstance(value, ast.ImportFrom)
        assert value.lineno == 1
        assert value.col_offset == 0
        assert value.level == 0
        assert value.module == "__future__"

    assert isinstance(module.body[4], ast.Expr)
    assert module.body[4].value.n == 1

# Generated at 2022-06-23 22:50:54.464615
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor

    # Arrange
    source_code  = '''
x = y
'''
    expected_code = '''
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
x = y
'''

    # Act
    tree = ast.parse(source_code)  # type: ignore
    transformer = Python2FutureTransformer()
    new_tree = transformer.visit(tree)  # type: ignore
    generated_code = astor.to_source(new_tree)

    # Assert
    assert generated_code == expected_code

# Generated at 2022-06-23 22:50:55.934237
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.tree_changed is False
    assert transformer.target == (2, 7)

# Generated at 2022-06-23 22:50:59.593543
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    ast_module = ast.parse('a = 1', mode='exec')
    expected = ast.parse(imports.get_code(future='__future__') + 'a = 1', mode='exec')
    node_transformer = Python2FutureTransformer()
    node_transformer.visit(ast_module)
    assert ast.dump(ast_module) == ast.dump(expected)

# Generated at 2022-06-23 22:51:01.087528
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    print("transformer.target is :", transformer.target)


# Generated at 2022-06-23 22:51:02.151378
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.target is not None

# Generated at 2022-06-23 22:51:03.699704
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer is not None

# Generated at 2022-06-23 22:51:12.701666
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    print('test_Python2FutureTransformer_visit_Module')
    # Python2FutureTransformer.visit_Module
    code = 'x = 1\n'
    mod = ast.parse(code)
    mod2 = Python2FutureTransformer().visit(mod)
    print('Python2FutureTransformer.visit_Module:')
    print(ast.dump(mod2))

# Generated at 2022-06-23 22:51:21.924445
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    from ..utils.ast_inspector import ASTInspector

    source = "assert isinstance(a, b), 'Some Text'"
    tree = ast.parse(source)
    Python2FutureTransformer().visit(tree)

# Generated at 2022-06-23 22:51:23.387209
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer(raise_on_error=True)

# Generated at 2022-06-23 22:51:28.126653
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.source import source2ast

    import_nodes = [n for n in source2ast(imports.get_source(future='__future__')).body]
    tree = source2ast('''
        def f(): 
            pass
        ''')
    new_tree = Python2FutureTransformer().visit(tree)
    assert new_tree.body == import_nodes + tree.body

# Generated at 2022-06-23 22:51:30.097643
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Unit test for constructor of class Python2FutureTransformer"""
    Python2FutureTransformer()


# Generated at 2022-06-23 22:51:34.158561
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from . import parse
    from . import unparse
    from ..utils.testing import assert_code_equal
    code = """
    long_var_name = 3
    for i in range(10):
        print(long_var_name)
    """
    module = parse(code)
    Python2FutureTransformer().visit(module)
    assert_code_equal(code, unparse(module))

# Generated at 2022-06-23 22:51:42.474570
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from pprint import pformat
    from _py2tmp.compiler.testing import assert_equal_with_printing
    from ..type_inference import TypedAstUnparser
    futurize = Python2FutureTransformer.run_on_single_file

    code = """
print('hello')
    """

    expected_code = """from future import absolute_import
from future import division
from future import print_function
from future import unicode_literals

print('hello')"""
    unparser = TypedAstUnparser(show_ast=True)
    assert_equal_with_printing(unparser.unparse_module(futurize(code)), expected_code)

# Generated at 2022-06-23 22:51:43.556689
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass  # Just an existence test

# Generated at 2022-06-23 22:51:49.174075
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = ast.parse('a = 1')
    expected = ast.parse('''from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
a = 1''')
    actual = Python2FutureTransformer().visit(module)
    assert ast.dump(actual) == ast.dump(expected)

# Generated at 2022-06-23 22:51:51.399795
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Test that the constructor was properly initialized."""
    transformer = Python2FutureTransformer()
    assert transformer is not None


# Generated at 2022-06-23 22:51:53.444856
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()
    snippet.test_visitor_class(t)



# Generated at 2022-06-23 22:51:59.223047
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils import get_ast_from_py
    from .python_transformer_test_case import PythonTransformerTestCase
    class TestPython2FutureTransformer(PythonTransformerTestCase):
        target = (2, 7)

        def test_result_tree(self):
            py = '''
                import os
                import sys
            '''
            expected = '''
                from __future__ import absolute_import
                from __future__ import division
                from __future__ import print_function
                from __future__ import unicode_literals
                import os
                import sys
            '''
            tree = get_ast_from_py(py)
            transformer = Python2FutureTransformer()
            tree = transformer.visit(tree)
            self.assertEqualPy(tree, expected)

    t = TestPython2FutureTrans

# Generated at 2022-06-23 22:52:02.759171
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-23 22:52:09.570516
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .. import run_transformer
    from .. import parse_ast

    tree1 = parse_ast.parse_module('''
        def foo():
            print('bar')
    ''')
    tree2 = run_transformer(Python2FutureTransformer, tree1)
    assert_equal_source(tree2, '''
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals


        def foo():
            print('bar')
    ''')

# Generated at 2022-06-23 22:52:15.125289
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast

    node = ast.parse('''
        # comment
        print('hello world!')
    ''')
    visitor = Python2FutureTransformer()
    node = visitor.visit_Module(node)
    assert visitor._tree_changed
    assert isinstance(node, ast.Module)
    assert len(node.body) == 5

# Generated at 2022-06-23 22:52:21.710530
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Tests Python2FutureTransformer.visit_Module() method.
    import typed_ast.ast3
    import dcc_qc.py3_port.utils.snippet
    import dcc_qc.py3_port.transforms.future

    node = typed_ast.ast3.parse('x=1')
    transformer = dcc_qc.py3_port.transforms.future.Python2FutureTransformer()
    result = transformer.visit_Module(node)
    assert transformer._tree_changed == True
    # Unit test for method get_body of class _Snippet
    future = '__future__'
    expected = dcc_qc.py3_port.utils.snippet._snippets['imports'].get_body(future) + node.body  # type: ignore
   

# Generated at 2022-06-23 22:52:22.829756
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer(2, 7, False)


# Generated at 2022-06-23 22:52:25.730449
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse("""import sys""")
    transformer = Python2FutureTransformer(node)
    transformed = transformer.visit(node)
    assert transformer.tree_changed



# Generated at 2022-06-23 22:52:30.579163
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    node = ast.parse('x = 1 + 1')
    assert node.body[0].value.left.id == 'x'
    assert node.body[0].value.op.__class__ == ast.Add
    assert node.body[0].value.right.n == 1

    transformer = Python2FutureTransformer()
    transformer.visit(node)

    assert isinstance(node.body[0], ast.ImportFrom)
    assert node.body[1].value.left.id == 'x'
    assert node.body[1].value.op.__class__ == ast.Add
    assert node.body[1].value.right.n == 1

# Generated at 2022-06-23 22:52:33.647665
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module = ast.parse('print(1)')
    transformer = Python2FutureTransformer()
    new_module = transformer.visit(module)
    assert transformer.tree_changed



# Generated at 2022-06-23 22:52:40.971721
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    tree = ast.parse(
            '''import os, sys
            import logging
            logging.warning('Deprecated')
            print("Hello World")''',
            "", "exec"
    )
    tree = transformer.visit(tree)
    tree_str = ast.unparse(tree)
    expected_output ='''from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
import os, sys
import logging
logging.warning('Deprecated')
print("Hello World")
'''
    assert tree_str == expected_output

# Generated at 2022-06-23 22:52:45.111828
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor
    node = ast.parse("# python code")
    transformer = Python2FutureTransformer()
    transformer.visit(node)
    assert astor.to_source(node).replace("\n", "") == \
        'from __future__ import absolute_import\n' \
        'from __future__ import division\n' \
        'from __future__ import print_function\n' \
        'from __future__ import unicode_literals\n# python code'

# Generated at 2022-06-23 22:52:54.841208
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import parse
    from ..transpile import Transpiler
    from ..utils.snippet import snippet
    
    p2ft = Transpiler(snippet='print("it works")', target=(2, 7))
    p2ft.add_transform(Python2FutureTransformer)
    p2ft.transform()
    
    ast_p2ft = parse(p2ft.snippet)
    ast_source = parse(snippet(imports(future='__future__')))
    ast_source.body.append(parse(snippet('print("it works")')).body[0])
    print("Python2FutureTransformer: ")
    print("Original snippet: ", p2ft.snippet)

# Generated at 2022-06-23 22:52:55.886087
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer(None, None)



# Generated at 2022-06-23 22:52:58.572772
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    x = Python2FutureTransformer()
    assert x._tree_changed == False

# Generated at 2022-06-23 22:53:08.345869
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Setup
    from typed_ast import ast3 as ast
    from ..utils import run_transformer
    transformer = Python2FutureTransformer()
    node = ast.Module([])
    # Exercise
    node = transformer.visit_Module(node)
    # Verify
    assert transformer._tree_changed
    imports1 = imports.get_body(future='__future__')
    expected = ast.Module(imports1)
    assert ast.dump(node) == ast.dump(expected)

if __name__ == '__main__':
    # Setup
    from typed_ast import ast3 as ast
    from ..utils import run_transformer
    transformer = Python2FutureTransformer()

    # Exercise
    node = ast.parse('print("Hello")')

# Generated at 2022-06-23 22:53:09.107820
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer



# Generated at 2022-06-23 22:53:09.491703
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    pass

# Generated at 2022-06-23 22:53:13.068992
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import os
    import sys
    myPath = os.path.dirname(os.path.abspath(__file__))
    sys.path.insert(0, myPath + '/../') 
    from inspect import cleandoc
    from ..utils import run_on_files


# Generated at 2022-06-23 22:53:17.403881
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.fixtures import make_dummy_tree
    from ..utils.visitor import print_nodes
    from ..utils.source import dedent
    tree0 = make_dummy_tree(dedent("""\
    class Spam(object):
        pass
    """))
    assert tree0.body[0].name == 'Spam'
    tree1 = Python2FutureTransformer().visit(tree0)
    print_nodes.print_module(tree1)
    assert tree1.body[0].name == 'absolute_import'

# Generated at 2022-06-23 22:53:18.151881
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass

# Generated at 2022-06-23 22:53:24.837789
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast.ast3 import parse, dump, NodeTransformer
    module_ast = parse("pass")
    module_ast = NodeTransformer().visit(module_ast)
    module_ast = Python2FutureTransformer().visit(module_ast)
    assert dump(module_ast) == '''\
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

pass
'''



# Generated at 2022-06-23 22:53:31.086909
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..example import module_ex3, module_ex3_output
    from .test_transformer import verify_generic_visit, verify_tree_changed

    node = module_ex3.body[0]
    t = Python2FutureTransformer()
    changed_node = t.visit(node)
    verify_tree_changed(t)
    verify_generic_visit(changed_node)
    assert changed_node == module_ex3_output.body[0]

# Generated at 2022-06-23 22:53:39.880087
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .test_utils import assert_equal_ast
    from .test_utils import parse

    s = "def f(x):\n\tprint(x)"
    node = parse(s)
    
    # Visit node and check the output (in string form)
    visitor = Python2FutureTransformer()
    new_node = visitor.visit(node)
    assert_equal_ast(new_node, s, mode=2)
    assert visitor.tree_changed is True
    
    # Visit node again and check if the output is the same as befor
    visitor = Python2FutureTransformer()
    new_node = visitor.visit(node)
    assert_equal_ast(new_node, s, mode=2)
    assert visitor.tree_changed is False

# Generated at 2022-06-23 22:53:42.806510
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    c = Python2FutureTransformer(None, None)
    assert isinstance(c, BaseNodeTransformer)
    assert c.target == (2, 7)


# Generated at 2022-06-23 22:53:47.884599
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast.ast3 import Module
    from typed_ast.ast3 import parse
    from typed_ast.ast3 import Expr
    from typed_ast.ast3 import Call
    from typed_ast.ast3 import Name
    from typed_ast.ast3 import NameConstant
    from typed_ast.ast3 import Load
    from future.utils import PY36
    from future.utils import PY2


# Generated at 2022-06-23 22:53:49.142285
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    instance = Python2FutureTransformer()
    assert isinstance(instance, Python2FutureTransformer)



# Generated at 2022-06-23 22:53:59.316079
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source
    from ..utils.snippet import snippet

    @snippet
    def imports_expected(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals
        try:
            code = source(
                a = 1
            )
        except Exception as e:
            pass
        
    @snippet
    def imports_expected_8(future):
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        try:
            code = source(
                a = 1
            )
        except Exception as e:
            pass
        


# Generated at 2022-06-23 22:54:02.977873
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from .test_base import BaseNodeTest

    class Test(BaseNodeTest):
        target = Python2FutureTransformer.target
        transformer = Python2FutureTransformer
        name = __name__

        @staticmethod
        def get_tree_changed():
            return Python2FutureTransformer._tree_changed



# Generated at 2022-06-23 22:54:11.567032
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import pytest
    from lib2to3.pgen2 import token

    from typed_ast.ast3 import parse
    from typed_ast import ast3 as ast
    from typed_ast.transforms.py2future import Python2FutureTransformer

    with pytest.raises(AssertionError):
        Python2FutureTransformer.visit_Module(Python2FutureTransformer, ast.Module(
            body=[ast.Expr(value=ast.Constant(value='2'))]
        ))

    mod = Python2FutureTransformer.visit_Module(Python2FutureTransformer, parse("1 + 1"))
    assert mod.body[0].value.left == token.PLUS
    assert mod.body[1].value.value == '2'

# Generated at 2022-06-23 22:54:21.903421
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source_helpers import source_to_module, source_to_class_node
    original = '''
    import random
    class MyClass:
        """This is a class"""
        def __init__(self):
            """??"""
            pass
    '''
    expected = '''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    import random
    class MyClass:
        """This is a class"""
        def __init__(self):
            """??"""
            pass
    '''

# Generated at 2022-06-23 22:54:26.207259
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert isinstance(Python2FutureTransformer, type)
    assert issubclass(Python2FutureTransformer, BaseNodeTransformer)
    assert Python2FutureTransformer.__name__ == "Python2FutureTransformer"
    assert Python2FutureTransformer.target == (2,7)

# Generated at 2022-06-23 22:54:36.281079
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.builder import ast_from
    from ..utils.test_utils import round_trip, UnitTestCase
    class Test_Python2FutureTransformer_visit_Module(UnitTestCase):
        def test_one_class(self):
            code = """
            class A:
                pass
            """
            transpiled = """
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
            class A:
                pass"""
            self.assertEqual(ast_from(code, 'fstring', target="2.7"), ast_from(transpiled, 'fstring', target="2.7"))
            self.assertEqual(code, round_trip(code, target="2.7"))
            

# Generated at 2022-06-23 22:54:40.645451
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import ast
    exp = ast.parse("""
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        a=3
        b='s'
    """)
    act = Python2FutureTransformer().visit(ast.parse('a=3\nb="s"'))
    assert ast.dump(exp) == ast.dump(act)

# Generated at 2022-06-23 22:54:41.484155
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer is not None


# Generated at 2022-06-23 22:54:42.396507
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-23 22:54:44.429085
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .utils import make_test
    from .python2_transformer_tests import expected
    make_test(expected, Python2FutureTransformer)()

# Generated at 2022-06-23 22:54:46.950654
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    r = Python2FutureTransformer()
    assert isinstance(r, Python2FutureTransformer)
    assert r._tree_changed is False
    assert r.target == (2, 7)



# Generated at 2022-06-23 22:54:54.605703
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    node = ast.parse('x = 1 + 1')
    Python2FutureTransformer().visit(node)
    module = ast.parse(inspect.getsource(Python2FutureTransformer))
    expected = ast.Module(body=imports.get_body(future='__future__') + node.body)
    assert ast.dump(node, annotate_fields=True) == ast.dump(expected, annotate_fields=True)
    assert ast.dump(module, annotate_fields=True)

# Generated at 2022-06-23 22:54:56.928413
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    translator = Python2FutureTransformer()
    assert translator is not None
    assert isinstance(translator, Python2FutureTransformer)

# Generated at 2022-06-23 22:55:01.882568
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from .base import BaseNodeTest
    from .base import tester
    BaseNodeTest(
        Python2FutureTransformer,
        {'target': (2, 7), '_tree_changed': False},
        (tester.target(2, 7),),
    )

# Generated at 2022-06-23 22:55:12.694619
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from pprint import pprint
    from ..utils.tree_inspector import TreeInspector

    tree = ast.parse('import json')
    module = tree
    Python2FutureTransformer().visit(module)  # type: ignore
    pprint(TreeInspector(module).get_tree_info())
    assert module[0].name == '__future__'

    tree = ast.parse('from __future__ import absolute_import')
    module = tree
    Python2FutureTransformer().visit(module)  # type: ignore
    pprint(TreeInspector(module).get_tree_info())
    assert module[0].name == '__future__'
    assert module[0].names[0].name == 'absolute_import'


# Generated at 2022-06-23 22:55:14.749227
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Unit test for constructor of class Python2FutureTransformer"""
    ext = Python2FutureTransformer()
    assert isinstance(ext, BaseNodeTransformer)

# Generated at 2022-06-23 22:55:20.807086
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()
    tree = ast.parse(imports.get_template(future='future'))
    tree = transformer.visit(tree)
    assert transformer.tree_changed is True
    assert ast.dump(tree) == "from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n"


# Generated at 2022-06-23 22:55:24.826597
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from .base import BaseNodeTransformerTest
    tree = BaseNodeTransformerTest.get_tree_from_code(input_code)
    transformed_tree = Python2FutureTransformer().visit(tree)
    BaseNodeTransformerTest.assert_code_equal(get_code_from_tree(transformed_tree), expected_code)



# Generated at 2022-06-23 22:55:29.034145
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .test_utils import round_trip
    source = 'print(1, 2, end="\\n")'
    tree = ast.parse(source)
    transformer = Python2FutureTransformer()
    result = transformer.visit(tree)
    assert result == round_trip(tree)

# Generated at 2022-06-23 22:55:34.331550
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.fixtures import make_test_module

    import astor
    m = make_test_module(code='''
if __name__ == '__main__':
    pass
''')
    m.show()
    tree = ast.parse(open(m.module.__file__).read())
    tree = Python2FutureTransformer().visit(tree)
    print(astor.to_source(tree))

# Generated at 2022-06-23 22:55:35.319102
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():  # noqa: D103
    Python2FutureTransformer()

# Generated at 2022-06-23 22:55:39.288727
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import assert_transformed_code_equal
    assert_transformed_code_equal(Python2FutureTransformer, '',
                                  '''from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

''')



# Generated at 2022-06-23 22:55:42.695887
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    assert Python2FutureTransformer().visit(ast.parse("print('Hello Python 2')")).body[0].value.func.id == "print"
    assert Python2FutureTransformer().visit(ast.parse("print('Hello Python 2')")).body[0].value.args[0].s == "Hello Python 2"

# Generated at 2022-06-23 22:55:45.825493
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast.ast3 import Module
    from ..utils.compile_source import compile_source
    assert compile_source(imports.dedent(), target=Python2FutureTransformer.target) == compile_source(imports.dedent(), target=Python2FutureTransformer.target)

# Generated at 2022-06-23 22:55:47.634637
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    result = Python2FutureTransformer().transpile('pass')
    assert result.name == 'python2future'


# Generated at 2022-06-23 22:55:57.947181
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor
    node = ast.Module(
        body=[ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())], value=ast.Num(n=1))]
    )
    assert astor.to_source(node) == 'x = 1\n'
    assert not hasattr(node, '_tree_changed')
    transformer = Python2FutureTransformer()
    module = transformer.visit(node)
    assert astor.to_source(module) == 'from __future__ import absolute_import\n'\
                                      'from __future__ import division\n'\
                                      'from __future__ import print_function\n'\
                                      'from __future__ import unicode_literals\n\n'\
                                      'x = 1\n'
   

# Generated at 2022-06-23 22:56:07.352888
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor

# Generated at 2022-06-23 22:56:15.666557
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    module = ast.parse('import ast')
    transform = Python2FutureTransformer(2)
    transform.visit(module)
    assert ast.dump(module) == "Module(body=[ImportFrom(module='__future__', names=[alias(name='absolute_import', asname=None), alias(name='division', asname=None), alias(name='print_function', asname=None), alias(name='unicode_literals', asname=None)], level=0), Import(names=[alias(name='ast', asname=None)])])"

# Generated at 2022-06-23 22:56:26.493701
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast.ast3 import parse
    from typed_ast.ast3 import Module
    from typed_ast import ast3 as ast
    from ...tests.helper_functions import generate_code_snippet
    from .test_BaseNodeTransformer import BaseNodeTransformer_visit_Module

    use_future_imports = False
    if use_future_imports:
        import __future__  # type: ignore

    # Create AST
    code_string = generate_code_snippet(imports.get_body(future='__future__'))
    code_object = compile(code_string, '', 'exec')
    expected_node = parse(code_string)

    # Test
    node = parse('# A comment')
    obj = Python2FutureTransformer()
    actual_node = BaseNodeTransformer_

# Generated at 2022-06-23 22:56:29.819959
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert len(Python2FutureTransformer.__bases__) == 1
    assert issubclass(Python2FutureTransformer, BaseNodeTransformer)

# Generated at 2022-06-23 22:56:31.634822
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    c = Python2FutureTransformer()
    assert c.target == (2, 7)



# Generated at 2022-06-23 22:56:37.986554
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    t = Python2FutureTransformer()
    node = ast.parse('print(1+1)')
    new_node = t.visit(node)
    assert not t._tree_changed
    node = ast.parse('def f(a):\n  return a')
    new_node = t.visit(node)
    assert t._tree_changed
    assert t.target == (2, 7)
    assert str(new_node) == imports.dedent() + str(node)

# Generated at 2022-06-23 22:56:46.555447
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3
    from typed_ast import py36
    from typed_ast.transforms.future import Python2FutureTransformer
    code = 'my_var = 1'
    node = py36.parse(code, mode='exec')
    node = Python2FutureTransformer().visit(node)  # type: ignore
    expected = '''
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

my_var = 1'''.strip()
    ast_string = ast3.dump(node)
    assert ast_string == expected

# Generated at 2022-06-23 22:56:49.893716
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    sample_module_source = """
        import sys
        import os
    """
    sample_module = ast.parse(sample_module_source)  # type: ignore

    transformer = Python2FutureTransformer()
    actual = transformer.visit(sample_module)
    expected = ast.parse(imports.format(future='__future__') + sample_module_source)  # type: ignore
    assert actual == expected

# Generated at 2022-06-23 22:56:51.401679
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()


# Generated at 2022-06-23 22:56:53.386254
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    class_ = Python2FutureTransformer(None)
    assert class_.target == (2, 7)



# Generated at 2022-06-23 22:56:54.648796
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer(None).target == (2, 7)

# Generated at 2022-06-23 22:57:03.618647
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import ast
    import textwrap
    from typing import List, Union

    class Node(ast.AST):
        _fields: List[str] = []

    node0 = Node()
    node1 = Node()
    node2 = Node()
    node3 = Node()
    node0._fields = ['body', 'type_ignores']
    node0.body = [node2]
    node0.type_ignores = None
    node2._fields = ['body', 'orelse', 'test']
    node2.body = [node3]
    node2.orelse = []
    node2.test = node1
    node1.s = ''
    node1._fields = ['s']
    node3._fields = ['body', 'targets']
    node3.body = []
    node3.targets

# Generated at 2022-06-23 22:57:06.614295
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source
    assert source(
        Python2FutureTransformer().visit(
            ast.parse(source(
                imports()
            ))
        )
    ) == source(
        imports(future='__future__')
    )

# Generated at 2022-06-23 22:57:11.566105
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import parse
    from typed_ast import ast3 as ast
    module = parse('print("Hello world!")')
    Python2FutureTransformer().visit(module)

    expected = parse(imports.get_src(future='__future__') + 'print("Hello world!")')
    assert ast.dump(module) == ast.dump(expected)
    assert Python2FutureTransformer().tree_changed == True
    assert Python2FutureTransformer().target == (2, 7)

# Generated at 2022-06-23 22:57:16.946849
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()
    code = "import os"
    module = ast.parse(code)
    module.body = transformer.visit(module.body)  # type: ignore
    assert ast.dump(module) == "from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\nimport os"

# Generated at 2022-06-23 22:57:18.813748
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()

# Generated at 2022-06-23 22:57:21.473559
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Test the constructor of the class Python2FutureTransformer"""
    obj = Python2FutureTransformer()
    assert obj is not None


# Generated at 2022-06-23 22:57:29.117469
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = ast.parse(dedent('''
        def g():
            import a
            import b
            import c
    '''))
    module_ = Python2FutureTransformer().visit(module)
    module_text = dedent('''
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        
        def g():
            import a
            import b
            import c
    ''')
    assert unparse(module_) == module_text

# Generated at 2022-06-23 22:57:38.662309
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..converter import py_to_py
    from ..processor.base import BaseFileProcessor

    simple_code = '''
a = 1
b = 2
'''
    processor = BaseFileProcessor(None, strong=True)
    converted_code_info = py_to_py(
        simple_code,
        processor=processor,
        target=(3, 5),
        transformers=[Python2FutureTransformer]
    )
    assert '''from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

a = 1
b = 2
''' == converted_code_info.code

# Generated at 2022-06-23 22:57:46.679106
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    '''
    Summary: 
        Test that when Python2FutureTransformer.visit_Module is called, 
        the module imports are added to the module if needed.
    
    Expected Results:
        When visit_Module is called on a module that does not have the
        imports, the imports are added to the module.
    '''
    from future.utils import six
    from typed_ast.ast3 import parse
    
    if six.PY2:
        f = __file__
    else:
        f = __file__.encode('utf-8')
    t = parse(f)
    node = Python2FutureTransformer()(t)
    assert node.body[:4] == imports.get_body(future='__future__')
    assert node.body[4:] == t.body
    
    
test

# Generated at 2022-06-23 22:57:47.554338
# Unit test for constructor of class Python2FutureTransformer

# Generated at 2022-06-23 22:57:55.621306
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    tf = Python2FutureTransformer()
    assert tf.target == (2, 7)
    assert Python2FutureTransformer._tree_changed == False
    assert Python2FutureTransformer._should_change_tree == False
    assert Python2FutureTransformer._should_skip_children == False
    assert Python2FutureTransformer._should_skip_siblings == False
    assert Python2FutureTransformer._should_stop == False
    assert Python2FutureTransformer._tree_changed == False
    assert Python2FutureTransformer._tree_changed == False

# Generated at 2022-06-23 22:58:04.051271
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import ast
    import astunparse

    class Dumper(ast.NodeVisitor):
        def generic_visit(self, node):
            print(node)
            ast.NodeVisitor.generic_visit(self, node)

    code = """
print("Hello, World!")
"""

    node = ast.parse(code)
    Python2FutureTransformer().visit(node)
    Dumper().visit(node)

    assert astunparse.unparse(node) == """
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
print("Hello, World!")
"""

# Generated at 2022-06-23 22:58:08.407563
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    try:
        transformer: Python2FutureTransformer = Python2FutureTransformer()
        stream = StringIO()
        node = ast.parse("""
    # comment
        """)
        result = transformer.visit(node)

        if result:
            printer = ast.NodeVisitor()
            printer.visit(result)

        print(stream.getvalue())
        stream.close()
        assert False
    except Exception:
        assert True

# Generated at 2022-06-23 22:58:11.026419
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # Imports
    import astor
    import gast
    # Instantiate Python2FutureTransformer
    python2_ft = Python2FutureTransformer()
    # Create AST

# Generated at 2022-06-23 22:58:13.799744
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()
    assert t.target == (2, 7)
    assert t.tree_changed is False
    assert t._tree_changed is False


# Generated at 2022-06-23 22:58:21.514569
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils import compare_ast

    node = ast.parse('''
        from __future__ import print_function
        
        print('x')
    ''')

    node = Python2FutureTransformer().visit(node)

    result = '''
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        from __future__ import print_function
        
        print('x')
    '''

    assert compare_ast(node, result)

# Generated at 2022-06-23 22:58:22.372242
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer()