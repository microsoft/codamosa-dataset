

# Generated at 2022-06-23 22:48:20.798843
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    node = ast.parse('', mode='exec')
    t = Python2FutureTransformer()
    assert t.visit(node).body == imports.get_body(future='__future__')

# Generated at 2022-06-23 22:48:27.399860
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    import astunparse

    before = ast.parse("""
    a = 1 + 1
    """)
    after = ast.parse("""
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    a = 1 + 1
    """)
    t = Python2FutureTransformer()
    t.visit(before)
    assert(astunparse.unparse(after) == astunparse.unparse(before))

# Generated at 2022-06-23 22:48:32.461116
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source2ast_exact
    from ..utils.ast import ast2source

    # This is what we want to test:
    ast_ = Python2FutureTransformer(source2ast_exact('')).visit(source2ast_exact(''))
    assert ast2source(ast_) == '\n'.join(imports.get_body(future='__future__'))

# Generated at 2022-06-23 22:48:40.009979
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    tests = [
        (
        """
        def f(): 
            return f
        """, 
        """
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
            
        def f(): 
            return f
        """
        ),
    ]
    for test in tests:
        node = ast.parse(test[0])
        Python2FutureTransformer().visit(node)
        assert str(ast.dump(node)).strip() == test[1].strip()

# Generated at 2022-06-23 22:48:41.370400
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast


# Generated at 2022-06-23 22:48:52.422316
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-23 22:49:01.209688
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    tree = ast.parse('module_name = "test"', "test.py")
    module = Python2FutureTransformer().visit(tree)
    assert module.body[0].names[0].name == 'absolute_import'
    assert module.body[0].names[1].name == 'division'
    assert module.body[0].names[2].name == 'print_function'
    assert module.body[0].names[3].name == 'unicode_literals'
    assert module.body[1].targets[0].id == 'module_name'
    assert module.body[1].value.s == 'test'

# Generated at 2022-06-23 22:49:02.382040
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer().target == (2, 7)



# Generated at 2022-06-23 22:49:04.599320
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    node = Python2FutureTransformer(1, 2, 3)
    assert node.target == (2, 7)


# Generated at 2022-06-23 22:49:11.877153
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():

    # Given
    from typed_ast import ast3 as ast
    from ..utils.context import Context
    from .transformer import Transformer

    module = '''\
        def foo():
            pass
        '''
    tree = ast.parse(module)
    context = Context()

    # When
    transformer = Transformer(context, Python2FutureTransformer)
    before_tree = ast.dump(tree)
    tree = transformer.visit(tree)
    after_tree = ast.dump(tree)

    # Then
    assert before_tree != after_tree


# Generated at 2022-06-23 22:49:18.038322
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astunparse

    class Module(ast.Module):
        def __init__(self):
            ast.Module.__init__(self, body=[
                ast.Import(names=[ast.alias(name='argparse', asname=None)]),
            ])

    module = Python2FutureTransformer().visit(Module())  # type: ignore
    result = astunparse.unparse(module)
    assert result == '''
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

import argparse
'''[1:]


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-23 22:49:24.062838
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..test_utils import make_test_function
    from ..visitor import CodeVisitor

    # Arrange
    transformer = Python2FutureTransformer()
    code = 'a = 2'
    
    # Act
    root_node = make_test_function(code)
    result = transformer.visit(root_node)
    visitor = CodeVisitor()
    visitor.visit(result)
    actual = visitor.code

    # Assert

# Generated at 2022-06-23 22:49:29.989340
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast

    pass
    module = ast.parse("""
pass
""", mode='exec')
    visitor = Python2FutureTransformer()
    module = visitor.visit(module)
    _repr = repr(module)
    assert _repr == """Module(body=[<future object at 0x107ef7a20>, <future object at 0x107ef7a20>, <future object at 0x107ef7a20>, <future object at 0x107ef7a20>, <future object at 0x107ef7a20>, Pass()])"""
    assert module.body[0].lineno == 1, "Expected 1, got {}".format(module.body[0].lineno)

# Generated at 2022-06-23 22:49:39.113589
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    code = """
import sys
import os.path
#    Remark: care about spacing here!
import re
# ^ ignore
import math
print('Hello world.')
"""
    expected = """
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
import sys
import os.path
#    Remark: care about spacing here!
import re
# ^ ignore
import math
print('Hello world.')
"""

    tr = Python2FutureTransformer()
    tr.visit(ast.parse(code))  # type: ignore
    assert expected == tr.get_code()

# Generated at 2022-06-23 22:49:39.743154
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass

# Generated at 2022-06-23 22:49:41.197682
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    t = Python2FutureTransformer()

# Generated at 2022-06-23 22:49:42.170447
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer()

# Generated at 2022-06-23 22:49:51.178834
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    class Visitor(ast.NodeVisitor):
        def visit_Module(self, node: ast.Module) -> ast.Module:
            return None

    visitor = Visitor()
    new_tree = visitor.visit(Python2FutureTransformer(None).visit(ast.parse('y=1')))
    assert new_tree.body[0].value.func.id == 'absolute_import'
    assert new_tree.body[1].value.func.id == 'division'
    assert new_tree.body[2].value.func.id == 'print_function'
    assert new_tree.body[3].value.func.id == 'unicode_literals'
    assert new_tree.body[4].value.func.id == 'absolute_import'
    assert new_tree.body[5].value.func.id

# Generated at 2022-06-23 22:49:56.651396
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import typed_ast.ast3 as ast

    tree = ast.parse('print(1)')
    transformer = Python2FutureTransformer(tree)
    new_tree = transformer.transform()
    assert len(new_tree.body) == 5  # type: ignore
    assert new_tree.body[0].names[0] == 'absolute_import'  # type: ignore

# Generated at 2022-06-23 22:49:58.397866
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)
    return transformer


# Generated at 2022-06-23 22:50:03.897645
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3
    node = ast3.parse("""a = 124 + 234""")
    t = Python2FutureTransformer()
    t.visit(node)
    assert ast3.dump(node) == "from future import absolute_import\nfrom future import division\nfrom future import print_function\nfrom future import unicode_literals\n\na = 124 + 234"

# Generated at 2022-06-23 22:50:09.796970
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse("a = 1")
    tr = Python2FutureTransformer()
    node = tr.visit(node)
    assert ast.dump(node) == pprint.pformat(imports.get_body(future='__future__') + [ast.parse("a = 1").body[0]])


# Unit test
if __name__ == '__main__':
    test_Python2FutureTransformer_visit_Module()
    print('All unit tests OK')

# Generated at 2022-06-23 22:50:11.541932
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    from .helpers import check_transformer


# Generated at 2022-06-23 22:50:13.804161
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer(ast.parse(''), ast.parse(''))
    if not isinstance(t, Python2FutureTransformer):
        raise Exception('Failed to create an instance of Python2FutureTransformer')

# Generated at 2022-06-23 22:50:16.988228
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """We just test if class can be initialized: we don't test functionality, that's in a separate test.
    """
    tf = Python2FutureTransformer()
    assert tf.target == (2, 7)
    assert tf.name == 'future'
    assert tf._tree_changed is False
    assert tf.skip is False

# Generated at 2022-06-23 22:50:19.383602
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer(None, None)
    assert transformer.target == (2, 7)
    assert transformer._tree_changed is False


# Generated at 2022-06-23 22:50:20.655854
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert hasattr(Python2FutureTransformer, 'visit_Module')



# Generated at 2022-06-23 22:50:23.966385
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transpiler = Python2FutureTransformer()
    assert isinstance(transpiler, Python2FutureTransformer)
    assert transpiler.target == (2,7)


# Generated at 2022-06-23 22:50:24.554730
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass

# Generated at 2022-06-23 22:50:26.383550
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer()
    assert Python2FutureTransformer.target == (2, 7)

# Generated at 2022-06-23 22:50:34.701441
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():

    source = inspect.cleandoc(
        """
        import os
        
        print("hello world")
        
        """
    )

    expected = inspect.cleandoc(
        """
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        
        import os
        
        print("hello world")
        
        """
    )

    tree = ast.parse(source)
    transformer = Python2FutureTransformer(target=(2, 7))
    transformer.visit(tree)
    
    assert astor.to_source(tree) == expected



# Generated at 2022-06-23 22:50:41.778338
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    print(astor.dump_tree(Python2FutureTransformer(2, 7).visit(ast.parse('print("Hello")'))))
    print(astor.dump_tree(Python2FutureTransformer(2, 7).visit(ast.parse('print("Hello")'))))
    print(astor.dump_tree(Python2FutureTransformer(2, 7).visit(ast.parse('print("Hello")'))))

# Generated at 2022-06-23 22:50:43.700759
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    '''Test the class Python2FutureTransformer
    '''
    # Test Python2FutureTransformer()
    assert Python2FutureTransformer() is not None

# Generated at 2022-06-23 22:50:48.365793
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..transformers.base import BaseNodeTransformer
    from ..transformers.python2 import Python2FutureTransformer
    from .._compat import StringIO
    from ..utils.filters import FilterSet, Filter
    import ast

    code = '''
        #! /usr/bin/env python
        # -*- coding: utf-8 -*-
        """Module docstring.
        """

        __author__ = "Jane Doe <jane@example.com>"
        __copyright__ = "Copyright 2016, John Doe"
        __license__ = "MIT"
        __version__ = "1.0.3"

        print('Hello, world!')
    '''

# Generated at 2022-06-23 22:50:50.003794
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from .utils import roundtrip

# Generated at 2022-06-23 22:50:54.605890
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    snippet_ = snippet.snippet(
       """
       a = 1
       print(a)
       """
    )
    node = ast.parse(source=str(snippet_))  # type: ignore
    node = Python2FutureTransformer().visit(node)  # type: ignore
    assert str(snippet_) == str(snippet(ast.Module(body=node.body).body))

# Generated at 2022-06-23 22:50:55.730740
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor

# Generated at 2022-06-23 22:50:58.215705
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    print('Testing Python2FutureTransformer...')
    module_ast = ast.parse('a = 1\n')
    module_ast = Python2FutureTransformer(module_ast)  # type: ignore
    print(block_statement(module_ast))

# Generated at 2022-06-23 22:50:59.778383
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)


# Generated at 2022-06-23 22:51:07.242460
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    future = '__future__'
    module = ast.parse("""
'''
Will add import from future to module.

'''
a = 'b'
""")
    t = Python2FutureTransformer()
    tree_changed = t.visit(module)
    assert tree_changed == True
    assert t.as_string(module) == """from {} import absolute_import
from {} import division
from {} import print_function
from {} import unicode_literals

'''
Will add import from future to module.

'''
a = 'b'
""".format(future, future, future, future)

# Generated at 2022-06-23 22:51:16.774082
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    code = """
        pass
    """
    root = ast.parse(code)
    Python2FutureTransformer().visit(root)
    assert root.body[0].dumps() == 'import __future__'
    assert root.body[1].dumps() == 'from __future__ import absolute_import'
    assert root.body[2].dumps() == 'from __future__ import division'
    assert root.body[3].dumps() == 'from __future__ import print_function'
    assert root.body[4].dumps() == 'from __future__ import unicode_literals'
    assert root.body[5].dumps() == 'pass'

# Generated at 2022-06-23 22:51:20.274398
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    text = """
        import os
        import sys
        """
    expected_output = """
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        import os
        import sys
        """
    node = ast.parse(text)
    Python2FutureTransformer().visit(node)
    output = astor.to_source(node)
    assert output == expected_output

# Generated at 2022-06-23 22:51:27.394289
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    code = """
            import os
            print('hi')
            """
    ast_tree = ast.parse(code)
    Python2FutureTransformer().visit(ast_tree)
    assert unparse(ast_tree, parse_recovery=True) == '\nfrom __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n\nimport os\nprint(\'hi\')\n'



# Generated at 2022-06-23 22:51:33.271428
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    # Test __doc__ inherited from BaseNodeTransformer
    assert transformer.__doc__ is not None

    # Test of overwritten method visit_Module
    assert transformer.visit_Module('node') == "node.body = imports.get_body(future='__future__') + node.body  # type:\n         ignore\nnode = node  # type: ignore\n return self.generic_visit(node)"

# Generated at 2022-06-23 22:51:34.421245
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    
    transformer = Python2FutureTransformer()


# Generated at 2022-06-23 22:51:35.516478
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    x = Python2FutureTransformer()
    assert x is not None

# Generated at 2022-06-23 22:51:44.277707
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module(): # noqa
    module_node = ast.parse('''
    a = 1
    b = 2
    c = 3
    d = 4
    ''')

    t = Python2FutureTransformer()
    t.visit(module_node)

    assert t._tree_changed
    assert ast.dump(module_node) == ast.dump(ast.parse('''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    a = 1
    b = 2
    c = 3
    d = 4
    '''))



# Generated at 2022-06-23 22:51:50.537515
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .. import transform

    # Arrange
    @snippet
    def test():
        def foo():
            print(4)
            
        def bar():
            print(5)
            

# Generated at 2022-06-23 22:51:52.578042
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)

# Generated at 2022-06-23 22:51:54.405225
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Example of checksum_algorithm__ is as follows."""
    x = Python2FutureTransformer

# Generated at 2022-06-23 22:51:57.009848
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Constructor of class Python2FutureTransformer"""
    transformer = Python2FutureTransformer()
    assert transformer.tree_changed == False
    assert transformer.target == (2, 7)


# Generated at 2022-06-23 22:51:58.146186
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer()

# Generated at 2022-06-23 22:52:03.080801
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    expected = ast.parse(
        "from __future__ import absolute_import\n"
        "from __future__ import division\n"
        "from __future__ import print_function\n"
        "from __future__ import unicode_literals\n"
        "\n"
        "x = 9\n"
        "y = 10\n"
    )
    node = ast.parse("x = 9\ny = 10")
    transformer = Python2FutureTransformer()
    transformer.visit(node)
    assert ast.dump(node) == ast.dump(expected)

# Generated at 2022-06-23 22:52:06.483313
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    sample_mod = ast.parse("""import os, sys\n""")
    trans = Python2FutureTransformer()
    res = trans.visit_Module(sample_mod)
    assert res.body[0].names[0].name == '__future__'



# Generated at 2022-06-23 22:52:15.463750
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    from pprint import pprint
    module = """\
#!/usr/bin/env python3

from math import sqrt

x = {'key': 'value'}

for k, v in x.items():
    print(k, v)

print('Hello, world!')
"""
    node = ast.parse(module)
    node = Python2FutureTransformer().visit(node)
    assert astor.to_source(node).startswith('from __future__ import')
    pprint(astor.to_source(node))

    
if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 22:52:17.942166
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    node = ast.parse("print('hello world')")
    obj = Python2FutureTransformer()
    obj.visit(node)
    assert len(obj.get_tree_changed()) == 1

# Generated at 2022-06-23 22:52:24.783072
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils import round_trip
    from ..exceptions import FileTruncated
    from ..parser import parse_module

    # Test with file not truncated
    source = (
        'import abc\n'
        '\n'
        '\n'
        'if __name__ == "__main__":\n'
        '    pass\n'
    )
    tree = parse_module(source)
    tree = Python2FutureTransformer().visit(tree)


# Generated at 2022-06-23 22:52:33.504321
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..fixer_util import tokenize_and_parse
    from ..fixer_util import untokenize
    from ..fixer_util import is_equal_src

    code = '''\
import os
'''
    expected_code = '''\
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

import os
'''
    node = tokenize_and_parse(code)
    new_node = Python2FutureTransformer().visit(node)
    actual_code = untokenize(new_node)
    assert is_equal_src(actual_code, expected_code)
    actual_code

# Generated at 2022-06-23 22:52:37.970475
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    code = textwrap.dedent(
    """\
    module = 'foo'
    """
    )
    tree = ast.parse(code, mode='exec')
#     tree = ast.parse('f = lambda x: x+1', mode='exec')
    Python2FutureTransformer().visit(tree)
    print(ast.dump(tree))



# Generated at 2022-06-23 22:52:44.566582
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from testing.helpers import assert_source
    from testing.helpers import transform
    from .. import Python2FutureTransformer

    @transform(Python2FutureTransformer)
    def test_Python2FutureTransformer_transformer_is_working():
        import os
        import sys

        cmd = 'print(abs)'

        return cmd

    assert_source(
        test_Python2FutureTransformer_transformer_is_working,
        r'''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    import os
    import sys

    cmd = 'print(abs)'

    ''')

# Generated at 2022-06-23 22:52:48.138581
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()
    node = ast.parse("import sys")
    assert transformer.visit(node) == ast.parse("from __future__ import (absolute_import, division, print_function, unicode_literals)\nimport sys")

# Generated at 2022-06-23 22:52:50.102543
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()
    assert True # TODO: implement your test here



# Generated at 2022-06-23 22:52:53.825247
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..run import run
    from .test_base import BaseNodeTest
    from .test_base import transpile_source
    from .test_base import assert_tree_equality
    from .test_base import assert_tree_not_equal


# Generated at 2022-06-23 22:52:55.514380
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    importer = Python2FutureTransformer()

# Generated at 2022-06-23 22:52:57.378784
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import six
    import astor
    import astunparse


# Generated at 2022-06-23 22:53:07.559246
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast

# Generated at 2022-06-23 22:53:11.288008
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = ast.parse('var = None')
    Python2FutureTransformer().visit(module)  # Returns None
    expected = ast.parse('from __future__ import absolute_import\n'
                         'from __future__ import division\n'
                         'from __future__ import print_function\n'
                         'from __future__ import unicode_literals\n'
                         '\n'
                         'var = None\n')
    assert ast.dump(module) == ast.dump(expected)

# Generated at 2022-06-23 22:53:15.840379
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    expected = ast.parse(dedent('''
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
                                
        def example():
            pass
    '''))

    actual = ast.parse(dedent('''
        def example():
            pass
    '''))
    actual = Python2FutureTransformer().visit(actual)
    assert ast.dump(expected) == ast.dump(actual)

# Generated at 2022-06-23 22:53:19.482958
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    code = """
    # coding: utf-8
    import this
    """
    correct_code = """
    # coding: utf-8
    from future import absolute_import
    from future import division
    from future import print_function
    from future import unicode_literals

    import this
    """
    node = ast.parse(code)
    transformer = Python2FutureTransformer()
    res = transformer.visit(node)
    assert isinstance(res.body[0], (ast.Import, ast.ImportFrom))
    assert ast.dump(res) == ast.dump(ast.parse(correct_code))

# Generated at 2022-06-23 22:53:25.391174
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import ast
    import astor
    test_node = ast.parse("print('Hello World')")
    p2ft = Python2FutureTransformer()
    p2ft.visit(test_node)
    assert astor.to_source(test_node) == \
"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

print('Hello World')
""".strip()

# Generated at 2022-06-23 22:53:29.925053
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import tabulate
    from pprint import pprint
    from .transform_tests_helper import transform_test_dir

    result = transform_test_dir(Python2FutureTransformer, 'future')

    for row in result:
        print(tabulate.tabulate([row], headers='keys', tablefmt='psql'))

# Generated at 2022-06-23 22:53:30.907428
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-23 22:53:36.759581
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    test_dict = {
        'tree': ast.parse('x = 1'), 
        'expected': ast.parse('from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\nx = 1')
    }
    actual = Python2FutureTransformer().visit(test_dict['tree'])
    assert ast.dump(test_dict['expected']) == ast.dump(actual)

# Generated at 2022-06-23 22:53:44.369590
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import textwrap
    from typed_ast import ast3 as ast

    tree = ast.parse(textwrap.dedent("""
    import os
    import sys
    import collections
    import datetime
    import fractions
    import functools
    import itertools
    import typing
    import re
    import numbers
    import abc
    import math
    """))
    assert tree.body  # sanity check
    transformer = Python2FutureTransformer()
    tree = transformer.visit(tree)
    assert tree.body  # sanity check
    assert transformer.tree_changed

# Generated at 2022-06-23 22:53:45.330766
# Unit test for constructor of class Python2FutureTransformer

# Generated at 2022-06-23 22:53:45.719920
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass

# Generated at 2022-06-23 22:53:46.446458
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    p = Python2FutureTransformer()
    assert p.tree is None

# Generated at 2022-06-23 22:53:55.681411
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    code = "\n".join([
        "import re, sys",
        "",
        "PY3 = sys.version_info[0] == 3",
        "",
        "if PY3:",
        "    basestring = str",
        "    unicode = str",
        "    long = int"
    ])
    tree = ast.parse(code)

    transformer = Python2FutureTransformer()

# Generated at 2022-06-23 22:53:56.635719
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass  # TODO: implement unit test

# Generated at 2022-06-23 22:54:05.459596
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # prepare
    from . import get_root

    # execute
    t = Python2FutureTransformer()
    node = get_root(t, 'simple')

    # verify
    assert len(node.body) == 18
    names = [
        'import_', 'import_', 'import_', 'import_',
        'Import', 'ImportFrom', 'ImportFrom', 'ImportFrom',
        'Import', 'ImportFrom', 'ImportFrom', 'ImportFrom',
        'Import', 'ImportFrom', 'ImportFrom', 'ImportFrom',
    ]
    for idx, name in enumerate(names):
        assert isinstance(node.body[idx], ast.Import) == (name == 'import_')
        assert isinstance(node.body[idx], ast.ImportFrom) == (name == 'ImportFrom')

# Generated at 2022-06-23 22:54:06.449456
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import sys
    import ast

# Generated at 2022-06-23 22:54:13.772628
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse('x = 1')
    t = Python2FutureTransformer()
    node = t.visit(node)
    assert ast.dump(node) == "Module(body=[ImportFrom(module='__future__', names=[alias(name='absolute_import', asname=None)], level=0), ImportFrom(module='__future__', names=[alias(name='division', asname=None)], level=0), ImportFrom(module='__future__', names=[alias(name='print_function', asname=None)], level=0), ImportFrom(module='__future__', names=[alias(name='unicode_literals', asname=None)], level=0), Assign(targets=[Name(id='x', ctx=Store())], value=Num(n=1))])"

# Generated at 2022-06-23 22:54:21.280980
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import ast as pyast
    from .utils import parse_to_ast
    class_ast = parse_to_ast("""class C:
    def f(self):
        return self
""")
    node = pyast.Module([class_ast])
    transformer = Python2FutureTransformer()
    new_node = transformer.visit(node)

    assert(transformer._tree_changed == True)
    assert(new_node.body[0].name == '__future__')
    assert(new_node.body[1].name == 'C')

# Generated at 2022-06-23 22:54:25.774300
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    import textwrap
    program_ast = ast.parse(textwrap.dedent("""\
        import os
        import sys
    """))
    Python2FutureTransformer().visit(program_ast)
    print(astor.to_source(program_ast))

# Generated at 2022-06-23 22:54:31.587708
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    node = ast.parse(dedent('''
    def foo():
        pass        
    ''')).body[0]
    node.body[0].body.append(ast.Pass())

    transformer = Python2FutureTransformer()
    assert transformer.visit(node) == imports.get_body(future='__future__') + node.body  # type: ignore



# Generated at 2022-06-23 22:54:37.032219
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3
    from ..utils import roundtrip
    module = ast3.parse("a = 1")
    node = Python2FutureTransformer().visit(module)
    result = roundtrip(node)
    expected = "from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n\na = 1"
    assert result == expected, (result, expected)

# Generated at 2022-06-23 22:54:39.021297
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    p = ast.parse("if 1: pass")
    t = Python2FutureTransformer()
    t.visit(p)
    assert t.tree_changed == True, "Test failed"

# Generated at 2022-06-23 22:54:44.226932
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from . import transforms_test
    tf = transforms_test.TestTransforms(
                     transformer=Python2FutureTransformer(),
                     transform=Python2FutureTransformer.visit_Module)
    tf.test('''
v = 2
    ''', '''
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
v = 2''')

# Generated at 2022-06-23 22:54:45.149196
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer

# Generated at 2022-06-23 22:54:47.599466
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()
    assert isinstance(t, BaseNodeTransformer)
    assert t.target == (2, 7)
    assert t.visit_Module is not None


# Generated at 2022-06-23 22:54:50.702735
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import typed_ast.ast3 as ast
    ast.parse("import sys, os")
    t = Python2FutureTransformer()
    assert t.visit(ast.parse("import sys, os"))
    assert t.visit(ast.parse("from __future__ import *"))


# Generated at 2022-06-23 22:54:52.142027
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer() # noqa


# Generated at 2022-06-23 22:54:54.010151
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == "Python2FutureTransformer"


# Generated at 2022-06-23 22:55:05.905996
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from .sample_asts import python2_module
    from .base import do_test_visitor
    node = do_test_visitor(Python2FutureTransformer(), python2_module)
    imports2 = [
        ast.ImportFrom(module='__future__', names=[
            ast.alias(name='absolute_import', asname=None),
            ast.alias(name='division', asname=None),
            ast.alias(name='print_function', asname=None),
            ast.alias(name='unicode_literals', asname=None),
        ], level=0),
        ast.Import(names=[ast.alias(name='foo', asname='bar')]),
        ast.Import(names=[ast.alias(name='bar', asname='foo')])
    ]
    assert node.body == imports2

# Generated at 2022-06-23 22:55:09.425593
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .test_files.test_Python2FutureTransformer import input, expected
    tree = ast.parse(input)
    Python2FutureTransformer().visit(tree)
    assert ast.dump(tree) == ast.dump(ast.parse(expected))



# Generated at 2022-06-23 22:55:11.412017
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast.ast3 import parse
    node = parse('pass')
    assert Python2FutureTransformer().visit(node) is not None

# Generated at 2022-06-23 22:55:21.547133
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    node = ast.parse('a = 1')
    Python2FutureTransformer().visit(node)
    print(ast.dump(node))

# Generated at 2022-06-23 22:55:24.117339
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse("")
    transformer = Python2FutureTransformer()
    node = transformer.visit(node)
    assert node.body[0].value.s == '__future__'

# Generated at 2022-06-23 22:55:31.012139
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..upgrade_tests import assert_upgrade

    assert_upgrade(Python2FutureTransformer,
    """
    def func():
        x = 1
        return x
    """,
    """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    def func():
        x = 1
        return x
    """,
    pre_parse=False,
    target=(2, 7))

# Generated at 2022-06-23 22:55:39.321160
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from py2to3.pygram.python_symbols import syms
    from py2to3.pgen2 import token as pgen2_tokens
    from py2to3.pytree import Leaf
    from py2to3.pytree import Node
    from py2to3.pgen2 import driver
    from typed_ast import ast3
    import ast
    import sys

    class DumbDriver(driver.Driver):
        def parse_tuple(self, input: str, filename: str, start: str) -> ast3.expr:
            """Returns single ast3.Expr node"""
            node = super().parse_tuple(input, filename, start)[0]
            assert isinstance(node, ast3.Expr)
            return node


# Generated at 2022-06-23 22:55:41.364641
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Test constructor of class Python2FutureTransformer
    """
    # Test with no params
    Python2FutureTransformer()

    # Test with valid params
    Python2FutureTransformer(deep=True)

# Generated at 2022-06-23 22:55:48.157272
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    snippet_ = """
        print("Hello, world!")
    """
    tree = ast.parse(snippet_)
    transformer = Python2FutureTransformer()
    new_tree = transformer.visit(tree)  # type: ignore
    expected_snippet = """
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        print("Hello, world!")
    """
    expected_tree = ast.parse(expected_snippet)  # type: ignore
    assert ast.dump(new_tree) == ast.dump(expected_tree)

# Generated at 2022-06-23 22:55:58.633874
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..ast_parser import AstParser
    from ..transformer import Transformer

    source = '''
        import ast
        import os
        import sys
        from astmonkey import transformers

        class BaseNodeTransformer(ast.NodeTransformer):
            pass

        class Python2FutureTransformer(BaseNodeTransformer):
            pass
    '''

    expected = '''
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        import ast
        import os
        import sys
        from astmonkey import transformers

        class BaseNodeTransformer(ast.NodeTransformer):
            pass

        class Python2FutureTransformer(BaseNodeTransformer):
            pass
    '''

    parser = AstParser()

# Generated at 2022-06-23 22:56:03.547303
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor

    transformer = Python2FutureTransformer()
    node = ast.parse('pass')
    new_node = transformer.visit(node)
    assert astor.to_source(new_node) == 'from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n'


# Generated at 2022-06-23 22:56:11.215563
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils import make_call_node, make_name_node, transform, parse

    # Tests if module was correctly transformed with the following code:
    # # 1.
    # # 2.
    # # 3.
    # # 4.
    # # 5.
    #
    # foo()
    # bar()
    # baz()

    node = parse("""
        # 1.
        # 2.
        # 3.
        # 4.
        # 5.

        foo()
        bar()
        baz()
    """)
    assert node == transform(node, Python2FutureTransformer)

# Generated at 2022-06-23 22:56:14.962309
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = ast.parse("a = 5")
    trans = Python2FutureTransformer()
    result = trans.visit(module)

    assert result.__class__.__name__ == 'Module'
    assert result.body[0].body[0].value.value == 'absolute_import'



# Generated at 2022-06-23 22:56:16.212350
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()
    assert t.target == (2, 7)

# Generated at 2022-06-23 22:56:17.471236
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer is not None

# Generated at 2022-06-23 22:56:19.030143
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert isinstance(Python2FutureTransformer(), Python2FutureTransformer)



# Generated at 2022-06-23 22:56:20.604097
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert isinstance(Python2FutureTransformer(), Python2FutureTransformer)

# Generated at 2022-06-23 22:56:23.834589
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert issubclass(Python2FutureTransformer,BaseNodeTransformer)
    assert isinstance(Python2FutureTransformer(),BaseNodeTransformer)

# Generated at 2022-06-23 22:56:31.143189
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from .. import main
    from .. import settings
    from . import helpers

    source = """
    print("hello world")
    """
    result = main.transform_source(source, settings.default_2to3_flags | {
        'print_function', 'unicode_literals'})
    assert result == helpers.dedent("""
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    print("hello world")
    """)

# Generated at 2022-06-23 22:56:32.738709
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)

# Generated at 2022-06-23 22:56:33.307211
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass

# Generated at 2022-06-23 22:56:41.099259
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    class_name = astor.code_to_ast("from typed_ast import ast3 as ast").body[0].value.id
    Module = getattr(ast, class_name)
    class_name = astor.code_to_ast("from .base import BaseNodeTransformer").body[0].value.id
    BaseNodeTransformer = getattr(ast, class_name)
    class_name = astor.code_to_ast("from ..utils.snippet import snippet").body[0].value.id
    snippet = getattr(ast, class_name)
    module_imports = astor.code_to_ast(imports)
    class_name = astor.code_to_ast("from __future__ import absolute_import").body[0].value.id
    absolute_import = getattr

# Generated at 2022-06-23 22:56:48.393752
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    test_code = "print(1)\nprint(2)"
    test_tree = ast.parse(test_code)
    expected_code = "from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n\nprint(1)\nprint(2)"
    expected_trees = ast.parse(expected_code)
    t = Python2FutureTransformer()
    t.visit(test_tree)
    assert ast.dump(test_tree) == ast.dump(expected_trees)

# Generated at 2022-06-23 22:56:52.440708
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    src = "print('this is a test')"
    exp = ("from __future__ import absolute_import\n"
           "from __future__ import division\n"
           "from __future__ import print_function\n"
           "from __future__ import unicode_literals\n"
           "\nprint('this is a test')\n"
          )
    tree = snippet.from_str(src)
    trans = Python2FutureTransformer()
    trans.visit(tree)
    obs = snippet.to_str(tree)
    assert obs == exp

# Generated at 2022-06-23 22:56:56.130575
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # create module
    module_node = ast.parse( '''# comment\nvar = 1\na = 1+\nvar''') # type: ignore
    # create transformer
    transformer = Python2FutureTransformer()
    # visit module
    transformer.visit_Module(module_node)
    assert transformer.result() == '''from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

# comment
var = 1
a = 1+
var
'''

# Generated at 2022-06-23 22:56:58.003329
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    pt = Python2FutureTransformer()
    pt.version = (2, 7)
    module = ast.parse('print(1/2)')
    pt.visit(module)
    assert pt._tree_changed



# Generated at 2022-06-23 22:57:04.022472
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    """Test to verify that the visit_Module method of class Python2FutureTransformer
    injects the __future__ imports at the beginning of the module body.
    """
    tree = ast.parse(textwrap.dedent("""
        print("Hello World")
        # print("Hello World")
        print("Hello World")
    """))
    transformer = Python2FutureTransformer()
    transformer.visit(tree)
    code = astor.to_source(tree)
    assert code == textwrap.dedent("""
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        print("Hello World")
        # print("Hello World")
        print("Hello World")
    """)

# Generated at 2022-06-23 22:57:13.400678
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from typed_ast.diff import diff_ast
    from .base import BaseNodeTransformerTestCase

    class Test(BaseNodeTransformerTestCase):
        transformer = Python2FutureTransformer
        target_version = (2, 7)

        def test_imports(self):
            tree = ast.parse(r'''
                pass
            ''')
            new_tree = self.transform(tree)
            expected_tree = ast.parse(r'''
                from __future__ import absolute_import
                from __future__ import division
                from __future__ import print_function
                from __future__ import unicode_literals
                pass
            ''')
            self.assertEqual(diff_ast(expected_tree, new_tree), [])  # type: ignore

    return Test

# Generated at 2022-06-23 22:57:22.621681
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():

    # Test no future
    import typed_ast.ast3 as ast
    node = ast.parse("print('Hello, world!')")
    tf = Python2FutureTransformer()
    tf.visit(node)
    assert node.body[0].names[0].id == 'absolute_import'
    assert node.body[1].names[0].id == 'division'
    assert node.body[2].names[0].id == 'print_function'
    assert node.body[3].names[0].id == 'unicode_literals'

    # Test with future
    import typed_ast.ast3 as ast
    node = ast.parse("from __future__ import print_function\nprint('Hello, world!')")
    tf = Python2FutureTransformer()
    tf.visit(node)
    assert node.body

# Generated at 2022-06-23 22:57:23.931066
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import parse
    from ..utils.python_source import Source

# Generated at 2022-06-23 22:57:28.794792
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast

    node = ast.parse("")
    transformer = Python2FutureTransformer()
    node = transformer.visit(node)
    assert str(node) == "from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n\n"

# Generated at 2022-06-23 22:57:33.861184
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = ast.parse("x = 1")
    Python2FutureTransformer().visit(module)
    assert ast.dump(module) == "from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\nx = 1"

# Generated at 2022-06-23 22:57:35.005916
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
  assert Python2FutureTransformer

# Generated at 2022-06-23 22:57:44.595675
# Unit test for constructor of class Python2FutureTransformer

# Generated at 2022-06-23 22:57:55.530416
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    tree = ast.parse("print('hello')")
    trans = Python2FutureTransformer(debug=True)
    trans.visit(tree)

# Generated at 2022-06-23 22:58:05.321670
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    from ast_visitor import ASTNodeFinder
    from .base import BaseNodeTransformer

    class Test1(BaseNodeTransformer):
        def __init__(self):
            self._tree_change = False
            self._node_found = False

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            return self.generic_visit(node)

        def visit_List(self, node: ast.List) -> ast.List:
            self._node_found = True
            return self.generic_visit(node)

        def node_found(self):
            return self._node_found

    class Test2(BaseNodeTransformer):
        def __init__(self):
            self._tree_change = False
            self._node_found

# Generated at 2022-06-23 22:58:10.273194
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    from typed_ast import ast3 as ast
    from ..utils.transformer import get_module_from_source
    from ..utils.transformer import run_transformer_visit_method
    from .python2_future import Python2FutureTransformer

    # Given

# Generated at 2022-06-23 22:58:20.878491
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import ast
    import astor
    from ..transpiler import Transpiler
    from .base import BaseTestTransformers
   
    class Test(BaseTestTransformers):
        transformer = Transpiler.get_transformer(Python2FutureTransformer)
        
        def test_visit_Module(self):
            node = ast.Module([], lineno=1, col_offset=0)
            expected = "from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n"
            new_node = self.transform(node)
            self.assertIsInstance(new_node, ast.Module)
            self.assertEqual(expected, astor.to_source(new_node))
    
    Test.main()