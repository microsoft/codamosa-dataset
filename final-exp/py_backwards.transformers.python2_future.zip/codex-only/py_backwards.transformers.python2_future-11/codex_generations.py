

# Generated at 2022-06-23 22:48:22.092533
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # Set up
    from typed_ast.ast3 import parse
    from ..transforms import Python2FutureTransformer as T
    test_input = """
    def foo():
        return 0
    """

    # Test
    expected_output = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    def foo():
        return 0
    """

    module_node: ast.Module = parse(test_input)
    module_node_transformed = T().visit(module_node)
    actual_output = ast.dump(module_node_transformed)
    actual_output = actual_output.replace('\n', '')

    # Post-test assertions
    assert actual_output.strip() == expected_output

# Generated at 2022-06-23 22:48:25.717383
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import re
    from ..utils.ast import dump, body_or_str
    from ..version import get_target
    from ..utils.transform import transform

    target = get_target(3)
    transformer = Python2FutureTransformer()

# Generated at 2022-06-23 22:48:34.581348
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    import astunparse

    print('Testing Python2FutureTransformer.visit_Module')

    visitor = Python2FutureTransformer()

    module = ast.Module([
        ast.Import(names=[ast.alias(name='os', asname=None)]),
        ast.ImportFrom(module='sys', names=[ast.alias(name='platform', asname=None)], level=0),
        ast.Print(dest=None, values=[], nl=True),
        ])

    visitor.visit(module)

    assert module.body[0].names[0].name == 'os'
    assert module.body[1].names[0].name == 'platform'
    assert module.body[2].values[0].s == 'from __future__ import absolute_import'

# Generated at 2022-06-23 22:48:44.723767
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor
    from typed_ast import ast2 as ast
    from ..utils.testutils import check_transformer
    from .base import BaseNodeTransformer

    class Transformer(BaseNodeTransformer):
        target = (2, 7)
        ignore_missing_imports = True
        
    src = "import os"
    expected = """from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

import os"""
    tree = ast.parse(src)
    tree = Transformer().visit(tree)  # type: ignore
    check_transformer(tree, expected)
    assert str(astor.to_source(tree)) == expected

# Generated at 2022-06-23 22:48:55.248352
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """ Unit testing for Python2FutureTransformer """
    # Create a Python2FutureTransformer object
    transformer = Python2FutureTransformer()

    # Create a fake source code
    source = '''
    print "Hello, World!"
    '''

    # Parse the source code into an AST
    tree = ast.parse(source)

    # Apply transformer to the AST
    new_tree = transformer.visit(tree)

    # Test the result
    assert transformer._tree_changed == True
    assert ast.dump(new_tree) == ast.dump(ast.parse('''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    print "Hello, World!"
    '''))

# Generated at 2022-06-23 22:48:57.221165
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert issubclass(Python2FutureTransformer, BaseNodeTransformer)


# Generated at 2022-06-23 22:48:58.791797
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast


# Generated at 2022-06-23 22:49:04.564069
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    s = '''print("hello")'''
    node = ast.parse(s)  # type: ignore
    Python2FutureTransformer().visit(node)
    assert ast.dump(node) == '''\
Module(body=[
    ImportFrom(module='__future__', names=[
        alias(name='absolute_import', asname=None),
        alias(name='division', asname=None),
        alias(name='print_function', asname=None),
        alias(name='unicode_literals', asname=None)], level=0),
    Expr(value=Call(func=Name(id='print', ctx=Load()), args=[
        Str(s='hello')], keywords=[]))])'''

# Generated at 2022-06-23 22:49:11.827669
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .test_utils import parse_unformatted_code, compare_ast
    node = parse_unformatted_code("""
        def foo(a, b):
            pass
    """)
    Python2FutureTransformer().visit(node)
    expected = parse_unformatted_code("""
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        def foo(a, b):
            pass
    """)
    assert compare_ast(node, expected)

# Generated at 2022-06-23 22:49:15.971938
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import typed_ast.ast3 as ast

    mod = ast.parse("z=2.0", mode='eval')
    Python2FutureTransformer.run_pipeline(mod)
    assert ast.dump(mod) == "from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\nz=2.0"

# Generated at 2022-06-23 22:49:26.133759
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import textwrap
    from ..utils import ast_checker, ast_equals
    from ..utils.ast_fixtures import AST_FIXTURE_DICT
    from typed_ast import ast3, parse

    test_data = {
        'dummy': textwrap.dedent('''def main():
            pass
        ''')
    }
    test_data.update(AST_FIXTURE_DICT)

    for key, value in test_data.items():
        ast_node = parse(value, mode='exec')
        ast_node = Python2FutureTransformer().visit(ast_node)  # type: ignore
        ast_checker.check_ast(ast_node)

# Generated at 2022-06-23 22:49:33.740724
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    code = """
import os

if __name__ == '__main__':
    print(os.name)
    """
    res = """
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
            
import os

if __name__ == '__main__':
    print(os.name)
    """
    t = Python2FutureTransformer()
    new_tree = t.visit(ast.parse(code))
    assert res == astunparse.unparse(new_tree).strip()



# Generated at 2022-06-23 22:49:44.196662
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    before = """\
import sys
from __future__ import annotations
from __future__ import print_function
#!/usr/bin/env python3
from __future__ import unicode_literals
from future.utils import listvalues
from builtins import *

from django.core.exceptions import ImproperlyConfigured
from future import standard_library

from rest_framework import serializers
"""

# Generated at 2022-06-23 22:49:45.191294
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer([]) is not None

# Generated at 2022-06-23 22:49:48.934594
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from .. import transform_source
    assert transform_source('x', target=(2, 7)) == 'from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n\nx'

# Generated at 2022-06-23 22:49:51.330576
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transform = Python2FutureTransformer()
    assert transform.target == (2, 7)
    assert transform.tree_changed == False
    assert transform._tree_changed == False

# Generated at 2022-06-23 22:49:53.147607
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert (Python2FutureTransformer.__module__ ==
            'graal.graal.transformer.python2_future')

# Generated at 2022-06-23 22:49:54.939051
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer

# Unit test of visit_Module

# Generated at 2022-06-23 22:50:01.648212
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast

    module = ast.parse("print('Hello World!')")
    transformer = Python2FutureTransformer()
    
    assert transformer.visit_Module(module) == (
("from __future__ import absolute_import\n"
"from __future__ import division\n"
"from __future__ import print_function\n"
"from __future__ import unicode_literals\n\n"
"print('Hello World!')\n"), True)

# Generated at 2022-06-23 22:50:02.720777
# Unit test for constructor of class Python2FutureTransformer

# Generated at 2022-06-23 22:50:04.032687
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer


# Generated at 2022-06-23 22:50:13.092611
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import json
    import astor
    from ..ast_transformer import AstTransformer
    with open('tests/fixtures/imports.json', 'r') as stream:
        data = json.load(stream)
    expected = data['results']['Python2FutureTransformer']
    expected = expected.replace('    ', '')
    ast1 = astor.code_to_ast.parse_file('tests/fixtures/imports.py')
    ast1 = AstTransformer(ast1, target=(2, 7)).visit(Python2FutureTransformer)
    result = astor.to_source(ast1)
    assert result == expected

    # with open('tests/fixtures/imports.py', 'r') as stream:
    #     data = stream.read()
    # data = json.loads(data)
   

# Generated at 2022-06-23 22:50:14.116516
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer(None).target == (2, 7)

# Generated at 2022-06-23 22:50:19.424499
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ast import parse
    from textwrap import dedent
    from ..utils.astpp import dump

    source = dedent("""\
        def foo(x):
            print(x)
    """)
    expected = dedent("""\
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        def foo(x):
            print(x)
    """)
    module = parse(source)
    Python2FutureTransformer().visit(module)
    actual = dump(module)
    assert expected == actual

# Generated at 2022-06-23 22:50:25.190440
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import ast  # type: ignore
    transformer = Python2FutureTransformer(
        ast.parse(
            '''
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
            a = 1
            print(a)
            '''
        ))
    # Check that the transformer didn't change anything
    assert transformer.tree_changed is False


# Generated at 2022-06-23 22:50:27.810094
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    class Test(unittest.TestCase):
        def test(self):
            transformer = Python2FutureTransformer()

# Generated at 2022-06-23 22:50:29.478504
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    t = Python2FutureTransformer()

# Generated at 2022-06-23 22:50:30.473530
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-23 22:50:35.964001
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor 
    from ..utils.ast_helpers import parse
    from ..utils.snippet import snippet
    from .base import parse_and_transform

    source = "import sys\nprint(sys.version)\n"
    expected = snippet(imports(future='__future__')) + source
    node = parse(source)
    actual = astor.to_source(parse_and_transform(source, Python2FutureTransformer))
    assert actual == expected

# Generated at 2022-06-23 22:50:46.609720
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astunparse
    from typed_ast import ast3 as ast
    from typed_ast import _ast27
    import textwrap

    code = textwrap.dedent("""
        import os
        x = 1
        """)

    expected_code = textwrap.dedent("""
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        import os
        x = 1
        """)

    tree = _ast27.parse(code, mode='exec')
    Python2FutureTransformer().visit(tree)
    actual_code = astunparse.unparse(tree)
    assert actual_code == expected_code

# Generated at 2022-06-23 22:50:50.477164
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():

    import six
    import astor
    # source code to convert

# Generated at 2022-06-23 22:50:51.540158
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer()

# Generated at 2022-06-23 22:50:55.564666
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..test_utils import make_test_tree

    tree = make_test_tree(import_future=False, version='2.7')
    Python2FutureTransformer().visit(tree)
    assert len(tree.body) == 5
    assert isinstance(tree.body[0], ast.ImportFrom)
    assert isinstance(tree.body[1], ast.ImportFrom)
    assert isinstance(tree.body[2], ast.ImportFrom)
    assert isinstance(tree.body[3], ast.ImportFrom)
    assert isinstance(tree.body[4], ast.Expr)

# Generated at 2022-06-23 22:50:56.162344
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer


# Generated at 2022-06-23 22:50:56.883159
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Unit test for constructor of class Python2FutureTransformer"""
    Python2FutureTransformer()

# Generated at 2022-06-23 22:50:57.463545
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__doc__ is not None

# Generated at 2022-06-23 22:51:00.272401
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer.target == (2, 7)



# Generated at 2022-06-23 22:51:01.969903
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == "Python2FutureTransformer"


# Generated at 2022-06-23 22:51:07.330867
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # Given
    module_name = 'tests.samples.python2.sample_1'
    module, target_ast = get_ast(module_name)

    # When
    Python2FutureTransformer().visit(target_ast)

    # Then
    target_source = compile_source_from_ast(target_ast, module_name)
    assert get_source(target_source) == get_source(module)

# Generated at 2022-06-23 22:51:18.391675
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astunparse
    import textwrap

    tree = ast.parse(textwrap.dedent("""\
    from future import absolute_import
    from future import division
    from future import print_function
    from future import unicode_literals
    """))

    node = Python2FutureTransformer().visit(tree)   # type: ignore
    assert astunparse.unparse(node) == textwrap.dedent("""\
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    """)

    tree = ast.parse(textwrap.dedent("""\
    pass
    """))
    node = Python2FutureTransformer().visit(tree)   # type: ignore
    assert astunparse.unparse

# Generated at 2022-06-23 22:51:19.277085
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass

# Generated at 2022-06-23 22:51:29.796951
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()

    node = ast.parse('x=1')
    node = transformer.visit(node)
    src = '\n'.join(['from __future__ import absolute_import', 'from __future__ import division',
                     'from __future__ import print_function', 'from __future__ import unicode_literals', 'x=1']
                    )
    assert ast.dump(node) == ast.dump(ast.parse(src))

    node = ast.parse('')
    node = transformer.visit(node)
    src = '\n'.join(['from __future__ import absolute_import', 'from __future__ import division',
                     'from __future__ import print_function', 'from __future__ import unicode_literals'])
    assert ast.dump(node) == ast.dump

# Generated at 2022-06-23 22:51:36.822339
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from flake8_future_import.tests.utils import get_node
    node = get_node('pass', 'module')
    transformer = Python2FutureTransformer()
    transformed_node = transformer.visit_Module(node)
    transformed_node_body = getattr(transformed_node, 'body', [])
    assert isinstance(transformed_node_body, list)
    assert len(transformed_node_body) == 5
    import_node = transformed_node_body[0]
    assert isinstance(import_node, ast.ImportFrom)
    assert import_node.module == '__future__'
    assert import_node.names[0].name == 'absolute_import'
    assert import_node.names[0].asname is None
    import_node = transformed_node_body[1]

# Generated at 2022-06-23 22:51:46.549949
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    print("\n@Python2FutureTransformer.visit_Module:")
    from ..utils.sample import sample_module
    from typed_ast import ast3 as ast
    from ..utils.astpp import dump
    from ..pysource import PythonSource
    from typing import List

    # Test data
    # Test target.
    target: List[int] = Python2FutureTransformer.target
    # Test Python source.
    src: str = (
        "import os\n"
        "\n"
        "def hello():\n"
        "    print('hello')\n"
    )
    # Test AST.
    tree: ast.Module = sample_module(src)
    # Test AST after transformation.
    output: ast.Module = ast.parse("pass")

    # Test transformation.
    transformer: Python2FutureTrans

# Generated at 2022-06-23 22:51:56.973597
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3
    from typed_ast.ast3 import Module, FunctionDef, arguments, Name, Load, Str, Expr, NameConstant, Call
    from ..utils.source import source

    # Type checks
    assert isinstance(Python2FutureTransformer(), Python2FutureTransformer)
    assert isinstance(Python2FutureTransformer().target, tuple)
    assert isinstance(Python2FutureTransformer().visit_Module(Module(body=[])), ast3.Module)
    assert isinstance(Python2FutureTransformer()._tree_changed, bool)

    # Actual test

# Generated at 2022-06-23 22:51:59.684110
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    py2 = Python2FutureTransformer()
    code = "print('Hello World!')"
    tree = ast.parse(code)
    assert not py2.visit_Module(tree)

# Generated at 2022-06-23 22:52:02.353522
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ...unitutil.file_snippet import check_snippet
    check_snippet(Python2FutureTransformer, 'module', 'module_imports',
                  imports.format(future='__future__'))

# Generated at 2022-06-23 22:52:03.794007
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import parse


# Generated at 2022-06-23 22:52:05.520609
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer('3.6')
    assert transformer.tree_changed == False

# Generated at 2022-06-23 22:52:07.450326
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast

    node = ast.parse("pass")
    Python2FutureTransformer().visit(node)
    assert node

# Generated at 2022-06-23 22:52:15.724871
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast27
    from ..utils.test_transformer import round_trip_unparse

    class Py2FutureTransformer(Python2FutureTransformer):
        pass

    module = ast27.parse('import os, sys', mode='exec')

    module = Py2FutureTransformer().visit(module=module)
    assert round_trip_unparse(module) == '''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    import os
    import sys
    '''

# Generated at 2022-06-23 22:52:20.055425
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from .python2 import Python2UnicodeLiteralsTransformer

    snippet.test_snippet(Python2FutureTransformer)
    
    def test_transformer_functionality(module_string, expected_string):
        tree = ast.parse(module_string)
        tree = Python2FutureTransformer().visit(tree)
        assert ast.dump(tree) == expected_string
        
    # Tests

# Generated at 2022-06-23 22:52:22.147784
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer is not None

# Generated at 2022-06-23 22:52:24.389176
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer(): 
    target = (2, 7)
    t = Python2FutureTransformer(target)
    assert t.target == target


# Generated at 2022-06-23 22:52:25.686823
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Unit test for constructor of class Python2FutureTransformer"""
    Python2FutureTransformer()

# Generated at 2022-06-23 22:52:32.100835
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    class_ = make_python_Transformer_class(Python2FutureTransformer)  # type: ignore
    instance = class_(ast.Module())
    test_cases = [
        (instance.visit, ast.Module),
        (instance.visit, ast.FunctionDef),
        (instance.visit, ast.ClassDef),
    ]

    for method, classinfo in test_cases:
        assert method(classinfo()) is None  # type: ignore
    return

# Generated at 2022-06-23 22:52:41.551767
# Unit test for constructor of class Python2FutureTransformer

# Generated at 2022-06-23 22:52:46.600583
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Given
    transformer = Python2FutureTransformer()
    node = ast.parse('a = 1')

    # When
    node = transformer.visit(node)

    # Then
    assert node is not None
    assert node.body[0].lineno == 1
    assert transformer._tree_changed is True

    # Given
    transformer = Python2FutureTransformer()
    node = ast.parse('from __future__ import print_function')

    # When
    node = transformer.visit(node)

    # Then
    assert node is not None
    assert node.body[0].lineno == 1
    assert transformer._tree_changed is False

# Generated at 2022-06-23 22:52:55.688435
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_snippet, make_fixture
    from ..utils.source import source
    from ..utils.visitor import visit_and_reconstruct
    from . import fixtures

    tree = make_snippet(
        source("""
        a = 1
        """))
    tree = visit_and_reconstruct(Python2FutureTransformer, tree)  # type: ignore
    assert fixtures.python2_future.as_string(tree) == fixtures.python2_future.as_string(make_fixture(
        source("""
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        a = 1
        """)))

# Generated at 2022-06-23 22:53:04.070349
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    source = dedent('''
        def foo():
            pass
    ''')
    expected = dedent('''
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        def foo():
            pass
    ''')
    xformer = Python2FutureTransformer()
    node = ast.parse(source)  # type: ast.AST
    node = xformer.visit(node)  # type: ast.AST
    assert ast.dump(node) == ast.dump(ast.parse(expected))

# Generated at 2022-06-23 22:53:11.969477
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    @snippet
    def target():
        # typed_ast 
        import ast
        import typing
        from typing import List
        if __name__=='__main__':
            print(1)
    @snippet
    def expected():
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals
        # typed_ast 
        import ast
        import typing
        from typing import List
        if __name__=='__main__':
            print(1)
    expected = expected.get_tree()
    assert Python2FutureTransformer().visit(target.get_tree()) == expected  # type: ignore

# Generated at 2022-06-23 22:53:15.652714
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    class MockType(object):
        def __init__(self):
            self.type = 'Module'
            self.body = []

        def __repr__(self):
            return '<MockType {0.type}>'.format(self)

    mock_node = MockType()

    # Unit test ...
    transformer = Python2FutureTransformer()
    assert transformer.visit(mock_node).body != []

# Generated at 2022-06-23 22:53:26.413941
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    from ..utils.visitor import NodeVisitor
    from ..utils.reconstruct import reconstruct
    from ..utils.roundtrip import roundtriptest

    code = "a = 1\n\nb = 2\n"

    class Visitor(NodeVisitor):
        def __init__(self):
            super(Visitor, self).__init__()
            self.count = 0

        def visit_Num(self, node):
            self.count += 1

    expected_code = """\
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

a = 1

b = 2
"""

    expected_tree = ast.fix_missing_locations(ast.parse(expected_code))


# Generated at 2022-06-23 22:53:34.718667
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.mock_ast import MockASTVisitor
    from ..utils.test_utils import get_test_cases
    from ..utils.test_utils import perform_transform_test

    path = 'tests/python2_test_cases/test_future.py'
    test_cases = get_test_cases(path)

    # We need to remove the first test cases since this transofrm prepends the node
    # with the imports
    test_cases = test_cases[1:]

    visitor = Python2FutureTransformer(MockASTVisitor())
    perform_transform_test(visitor, test_cases)

# Generated at 2022-06-23 22:53:39.868399
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()
    node = ast.parse('')
    new_node = transformer.visit_Module(node)
    print(ast.dump(new_node))
    assert transformer._tree_changed is True
    assert imports.to_str(future='__future__') in ast.dump(new_node)

# Generated at 2022-06-23 22:53:45.933794
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import typed_ast.ast3 as ast
    from dffml.util.entrypoint import entrypoint
    from dffml import Source
    from dffml.util.asynctestcase import AsyncTestCase

    class TestPython2FutureTransformer(AsyncTestCase):
        async def test_Python2FutureTransformer_visit_Module(self):
            # Arrange
            class TestPlugin(Python2FutureTransformer):
                pass

            # Act

# Generated at 2022-06-23 22:53:49.466769
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast.ast3 import Module
    from typed_ast.ast3 import parse
    node = parse('x = 2')
    t = Python2FutureTransformer()
    t.visit(node)
    assert isinstance(node, Module)
    assert len(node.body) == 5

# Generated at 2022-06-23 22:53:56.196633
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    code = """print(2/3)"""
    mod = ast.parse(code)
    Python2FutureTransformer().visit(mod)
    gencode = ast.fix_missing_locations(mod)

    assert len(mod.body) == 6

    assert isinstance(mod.body[0], ast.ImportFrom)
    assert mod.body[0].level == 0
    assert mod.body[0].module == 'future'
    assert mod.body[0].names[0].name == 'absolute_import'
    assert mod.body[0].names[0].asname is None

    assert isinstance(mod.body[1], ast.ImportFrom)
    assert mod.body[1].level == 0
    assert mod.body[1].module == 'future'

# Generated at 2022-06-23 22:54:02.276078
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    code = """
    print("Hello, World!")
    """
    
    # When
    tree = ast.parse(code)
    Python2FutureTransformer().visit(tree)
    
    # Then
    assert to_source(tree) == inspect.cleandoc("""
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        print("Hello, World!")
        """)



# Generated at 2022-06-23 22:54:10.164606
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert imports.get_body(future='__future__') == [ast.ImportFrom(module='__future__', names=[ast.alias(name='absolute_import', asname=None)], level=0), ast.ImportFrom(module='__future__', names=[ast.alias(name='division', asname=None)], level=0), ast.ImportFrom(module='__future__', names=[ast.alias(name='print_function', asname=None)], level=0), ast.ImportFrom(module='__future__', names=[ast.alias(name='unicode_literals', asname=None)], level=0)]

# Generated at 2022-06-23 22:54:17.055482
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..testing_utils import assert_source

    t = Python2FutureTransformer()
    assert_source(t,'''
        my_var = 1
    ''','''
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        my_var = 1
    ''')

# Generated at 2022-06-23 22:54:23.309353
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    tree = ast.parse('x = 1', mode='exec')
    check_tree = ast.parse('from __future__ import absolute_import'
                           '\nfrom __future__ import division'
                           '\nfrom __future__ import print_function'
                           '\nfrom __future__ import unicode_literals'
                           '\nx = 1', mode='exec')
    transformer = Python2FutureTransformer()
    ans = transformer.visit(tree)
    assert ast.dump(ans) == ast.dump(check_tree)

# Generated at 2022-06-23 22:54:24.317203
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-23 22:54:31.236005
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    code = "print('hello')"
    transformer = Python2FutureTransformer(code, (2, 7))
    node = ast.parse(code)
    new_node = transformer.visit(node)
    imports_code = '\n'.join(imports.get_body(future='__future__'))
    assert ast.dump(new_node) == ast.dump(ast.parse(imports_code + code))


__all__ = ['Python2FutureTransformer']

# Generated at 2022-06-23 22:54:32.150479
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    constructor_test_helper(Python2FutureTransformer)

# Generated at 2022-06-23 22:54:33.888735
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()

# Generated at 2022-06-23 22:54:35.462830
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert isinstance(transformer, Python2FutureTransformer)

# Generated at 2022-06-23 22:54:36.949435
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    r = Python2FutureTransformer()
    assert r.target == (2, 7)



# Generated at 2022-06-23 22:54:38.356812
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import pytest
    from typed_ast.ast3 import parse

# Generated at 2022-06-23 22:54:39.131267
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-23 22:54:44.914226
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..transformers.python2 import Python2FutureTransformer
    import typed_ast.ast3 as ast

    tree = ast.parse('print(1)', mode='eval')
    tree = Python2FutureTransformer().visit(tree)
    assert ast.dump(tree) == "Module(body=[ImportFrom(module='__future__', names=[alias(name='absolute_import', asname=None), alias(name='division', asname=None), alias(name='print_function', asname=None), alias(name='unicode_literals', asname=None)], level=0), Expr(value=Call(func=Name(id='print', ctx=Load()), args=[Num(n=1)], keywords=[]))])"

# Generated at 2022-06-23 22:54:48.215257
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Arrange
    from typed_ast import ast3
    from .fixtures import Python2Module
    target = Python2FutureTransformer(Python2Module.source)
    expected = ast3.parse(Python2Module.target)
    # Act
    actual = target.visit(target.tree)
    # Assert
    assert ast3.dump(actual) == ast3.dump(expected)

# Generated at 2022-06-23 22:54:53.709485
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import ast
    from ..utils.ast_helpers import parse_ast_tree, compare_ast
    x = Python2FutureTransformer()
    ast1 = parse_ast_tree("")
    ast2 = parse_ast_tree("import sys")
    ast3 = parse_ast_tree("from __future__ import print_function")
    ast4 = parse_ast_tree("""
    from __future__ import print_function
    
    def func():
        pass
    """)
    ast5 = parse_ast_tree("""
    import json as j
    import os.path
    import numpy as np
    """)
    ast6 = parse_ast_tree("""
    import json as j
    import os.path
    import numpy as np
    
    class T:
        pass
    """)
    ast7

# Generated at 2022-06-23 22:54:55.232947
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer(None, None).target == (2, 7)

# Generated at 2022-06-23 22:55:07.163156
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import textwrap
    from typed_ast.ast3 import parse
    source = textwrap.dedent('''\
        import os
        import sys

        print('Hello World')
        ''')
    tree = parse(source)
    Python2FutureTransformer().transform(tree)
    # There is no target version identification in AST; to recover from this,
    # compare the output with a template
    output = textwrap.dedent('''\
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        import os
        import sys

        print('Hello World')
        ''')
    assert output == compile(tree, filename='<ast>', mode='exec')  # type: ignore

# Generated at 2022-06-23 22:55:09.504975
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()
    assert t._tree_changed == False
    assert t.target == (2, 7)

# Generated at 2022-06-23 22:55:11.532343
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    assert isinstance(Python2FutureTransformer(), ast.NodeTransformer)


# Generated at 2022-06-23 22:55:15.922801
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # type checks
    assert issubclass(Python2FutureTransformer, BaseNodeTransformer)
    assert not issubclass(BaseNodeTransformer, Python2FutureTransformer)

    # instance checks
    instance: BaseNodeTransformer = Python2FutureTransformer()
    assert isinstance(instance, BaseNodeTransformer)
    assert isinstance(instance, Python2FutureTransformer)
    assert not isinstance(BaseNodeTransformer, Python2FutureTransformer)

# Generated at 2022-06-23 22:55:22.130616
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    old_module = ast.parse('a = """I am a string"""')
    new_module = Python2FutureTransformer().visit(old_module)
    expected_module = ast.parse(
        'from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\na = """I am a string"""'
    )
    assert ast.dump(new_module) == ast.dump(expected_module)

# Generated at 2022-06-23 22:55:23.302097
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    x = Python2FutureTransformer()
    assert x


# Generated at 2022-06-23 22:55:29.976685
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = ast.parse('')
    visitor = Python2FutureTransformer()
    transformed_module = visitor.visit(module)  # type: ignore
    assert isinstance(transformed_module, ast.Module)
    assert len(transformed_module.body) == len(imports.get_body(future='__future__'))  # type: ignore
    for node, expected_node in zip(transformed_module.body, imports.get_body(future='__future__')):  # type: ignore
        assert isinstance(node, ast.ImportFrom)
        assert isinstance(expected_node, ast.ImportFrom)
        assert node.lineno == expected_node.lineno
        assert node.col_offset == expected_node.col_offset
        assert node.module == expected_node.module

# Generated at 2022-06-23 22:55:31.348686
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer is not None

# Generated at 2022-06-23 22:55:36.485680
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import ast
    import astunparse
    tree = ast.parse('x = 3')
    tree = Python2FutureTransformer().visit(tree)
    source = astunparse.unparse(tree)
    assert source.startswith('from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n\nx = 3')

# Generated at 2022-06-23 22:55:44.945738
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformerTestCase

# Generated at 2022-06-23 22:55:46.229844
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass

# Generated at 2022-06-23 22:55:56.025549
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    mod = ast.parse("print(1)")
    Python2FutureTransformer().visit(mod)
    result = ast.dump(mod, annotate_fields=False, include_attributes=False)

# Generated at 2022-06-23 22:55:58.448171
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)
    assert transformer._tree_changed == False


# Generated at 2022-06-23 22:56:01.778589
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source
    from ast_tools.passes import InlineImportsTransformer

    src = """
    print('Hello')
    """.strip()

# Generated at 2022-06-23 22:56:03.339049
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()
    assert repr(t) == 'Python2FutureTransformer()'


# Generated at 2022-06-23 22:56:05.581896
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()  # type: ignore
    assert transformer.target == (2, 7)


# Generated at 2022-06-23 22:56:11.540572
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse('test')
    new_node = Python2FutureTransformer().visit(node)

    expected_code = """
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

test
    """.strip()

    assert astunparse.unparse(new_node) == expected_code

# Generated at 2022-06-23 22:56:21.015074
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():

    from typed_ast import ast3 as ast
    from typed_ast import convert
    import sys, os
    sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), os.path.pardir)))
    from typed_astunparse import unparse
    from ..transforms import _ast_transformer

    # Test visit_Module() method on empty module
    node = ast.Module([])
    node = ast.fix_missing_locations(node)

    transformer = Python2FutureTransformer()
    transformer.visit(node)
    assert(transformer._tree_changed == True)

# Generated at 2022-06-23 22:56:29.758817
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    tree = ast.parse('''
        import sys
        import os

        
        def f(a):
            return a **2

        def g(x):
            return x*x

        def main():
            print(f(10))
            print(g(10))
    ''')

    Python2FutureTransformer().visit(tree)

    assert tree.body[0].names[0].name == "absolute_import"
    assert tree.body[1].names[0].name == "division"
    assert tree.body[2].names[0].name == "print_function"
    assert tree.body[3].names[0].name == "unicode_literals"

    assert tree.body[6].name == "f"
    assert tree.body[11].name == "main"

# Generated at 2022-06-23 22:56:33.306171
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    tree = ast.parse("x = 2")
    transformer = Python2FutureTransformer(tree)
    assert transformer.tree_changed is False
    transformer.visit(tree)
    assert transformer.tree_changed is True



# Generated at 2022-06-23 22:56:35.733602
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    x = Python2FutureTransformer()
    # print(x.visit_Module(x))
    assert hasattr(x, 'visit_Module')


# Generated at 2022-06-23 22:56:44.174747
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_fake_module
    from ..utils.source import Source
    from .ast_compare import compare_asts
    from .type_comment import TypeAnnotationTransformer
    from .type_stub import TypeStubTransformer

    s = Source(None)
    transformers = [TypeStubTransformer, TypeAnnotationTransformer, Python2FutureTransformer]
    module = make_fake_module(s, transformers)
    source = module.source
    assert source.future == "__future__"

# Generated at 2022-06-23 22:56:50.040828
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    import textwrap
    module = ast.parse(
        textwrap.dedent("""
        def a():
            pass
        def b():
            1 + 1
        def c():
            def a():
                pass
            def b():
                1 + 1
        """)
    )
    module = Python2FutureTransformer().visit(module)
    assert astor.to_source(module) == textwrap.dedent("""
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals


    def a():
        pass


    def b():
        1 + 1


    def c():
        def a():
            pass

        def b():
            1 + 1
    """)

# Generated at 2022-06-23 22:56:52.060213
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)

# Generated at 2022-06-23 22:56:59.218373
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    for version in ('2.7', 'py27'):
        linter = Python2FutureTransformer(version=version)
        output = linter.visit(ast.parse('''
            def f():
                return x
        '''))
        assert isinstance(output, ast.Module)
        assert output.body[0].name == 'absolute_import'
        assert output.body[1].name == 'division'
        assert output.body[2].name == 'print_function'
        assert output.body[3].name == 'unicode_literals'
        assert output.body[4].name == 'f'

# Generated at 2022-06-23 22:57:08.072894
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast

    # Generated AST for the following Python module:
    #
    # import foo
    #
    # def bar():
    #     pass
    #
    # foo.bar()
    #
    # class Foo:
    #     pass


# Generated at 2022-06-23 22:57:12.537869
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.example import ExamplePythonCode
    from ..utils.visitor import dump_ast

    example = ExamplePythonCode.create_example_code(list(range(10)))
    tree = ast.parse(example, filename='<ERROR>')
    tree = Python2FutureTransformer().visit(tree)
    dump_ast(tree)

# Generated at 2022-06-23 22:57:19.973536
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Setup
    code_to_test = "1/2"
    expected_code = """\
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
1/2"""
    # Exercise
    module = ast.parse(code_to_test, "", "exec")
    node_transformer = Python2FutureTransformer()
    module = node_transformer.visit(module)  # type: ignore
    code = astunparse.unparse(module)
    # Verify
    assert code == expected_code
    assert node_transformer._tree_changed is True

# Generated at 2022-06-23 22:57:21.015234
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor

# Generated at 2022-06-23 22:57:21.997352
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer() is not None

# Generated at 2022-06-23 22:57:23.784796
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()
    assert t is not None

# Generated at 2022-06-23 22:57:24.829123
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor

# Generated at 2022-06-23 22:57:31.197079
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .helpers import make_module
    from ..utils.source import source_to_unicode
    
    module = make_module('xxx', """
    print('test')
    """)
    expected = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals


    print('test')
    """
    Python2FutureTransformer(module).run()
    assert source_to_unicode(module) == expected

# Generated at 2022-06-23 22:57:32.079915
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor


# Generated at 2022-06-23 22:57:33.111746
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert inspect.isclass(Python2FutureTransformer)

# Generated at 2022-06-23 22:57:38.963558
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astunparse
    t = Python2FutureTransformer()
    node = ast.parse('')
    updated = t.visit(node)
    assert astunparse.unparse(updated).strip() == '''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    '''.strip()

# Generated at 2022-06-23 22:57:39.955093
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer


# Generated at 2022-06-23 22:57:44.067757
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor

    m = ast.Module(
        body=[
            ast.Import(names=[ast.alias(name='math', asname=None)]),
        ]
    )

    n = Python2FutureTransformer(m).visit(m)
    assert astor.to_source(n) == '''\
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

import math
'''

# Generated at 2022-06-23 22:57:46.534162
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .simple_tree import module as simple_module
    from .simple_tree import fixed as future_fixed_module
    assert Python2FutureTransformer(simple_module).visit(simple_module) == future_fixed_module

# Generated at 2022-06-23 22:57:51.920930
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = ast.parse('print("Hello, World!"')
    t = Python2FutureTransformer()
    t.visit(module)

    expected = ast.parse('''from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
print("Hello, World!")''')

    assert expected == module

# Generated at 2022-06-23 22:57:55.390348
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    class Test(Python2FutureTransformer):
        pass

    t = Test()
    assert t._tree_changed == False
    assert t.target == (2, 7)


# Generated at 2022-06-23 22:58:01.902941
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    """Unit test for method visit_Module of class Python2FutureTransformer"""
    from ast import parse
    from ..utils.test_fixture import make_tree
    from ..utils.test_helpers import get_visitors_results_for
    tree = make_tree(parse("""print('x')"""))
    transformer = Python2FutureTransformer()
    results = get_visitors_results_for(tree, transformer)
    assert results[0].body[0].names[0].name == 'absolute_import'

# Generated at 2022-06-23 22:58:03.652728
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Test for correct constructor of class Python2FutureTransformer"""
    Python2FutureTransformer()



# Generated at 2022-06-23 22:58:11.450895
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astunparse

    snippet1 = '''
    from future import division
    from __future__ import print_function
    from __future__ import unicode_literals

    from future import absolute_import
           
    from __future__ import division
    from future import print_function
    from __future__ import unicode_literals

    from future import division
    from __future__ import print_function
    from __future__ import unicode_literals
    '''

# Generated at 2022-06-23 22:58:21.048025
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .test_base import Tests
    print('\n'+'-'*60)
    print(test_Python2FutureTransformer_visit_Module.__doc__)
    print('-'*60)
    import os
    import sys
    import untokenize
    sys.path.insert(0, os.path.abspath('..'))
    from typed_ast import ast3

    Tests({'mod': _pydev_bundle_extras_future_print_function_pydev_import + """
x = 1
print(x)
"""})
