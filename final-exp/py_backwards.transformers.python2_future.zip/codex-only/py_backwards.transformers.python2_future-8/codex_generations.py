

# Generated at 2022-06-23 22:48:23.286620
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor
    transformer = Python2FutureTransformer()

    # Transformer works on '__future__' before the module
    code = '''
import math
from __future__ import division

a = 2 / 3
    '''
    expected_code = '''
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
import math
from __future__ import division

a = 2 / 3
    '''
    tree = ast.parse(code)
    tree = transformer.visit(tree)
    assert astor.to_source(tree) == expected_code

    # Transformer works on '__future__' in the middle of the module

# Generated at 2022-06-23 22:48:32.727197
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils import run_python_module
    from ..pgen2 import token
    from ..pgen2.grammar import Grammar
    from ..codetransformer import Module
    from ..pgen2.parse import ParseError

    def _get_imports(code):
        try:
            module = run_python_module(code)
            class FutureTransformer(Python2FutureTransformer):
                class _Builder(object):
                    import_module = Module('__future__')
            return FutureTransformer(module)._tree.body
        except ParseError as err:
            parts = err.text.split('\n')
            print('{0} at {1}'.format(parts[0], parts[1]))
            raise


# Generated at 2022-06-23 22:48:39.698133
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    source = 'import pandas\n'
    expected = 'from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n\nimport pandas\n'

    tree = ast.parse(source)  # type: ignore
    Python2FutureTransformer().visit(tree)

    #print(astor.to_source(tree).strip())
    assert astor.to_source(tree).strip() == expected.strip()

# Generated at 2022-06-23 22:48:45.052307
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    code = astor.to_source(Python2FutureTransformer(ast.parse('print(x)')).tree)
    answer = '''\
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

print(x)
'''
    assert code == answer

# Generated at 2022-06-23 22:48:55.513434
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils import bfs_filter
    from ..utils import get_node_names
    from ..utils import parse
    from ..utils import run_transformer_class
    # Construct instance of class Python2FutureTransformer
    transformer = Python2FutureTransformer()
    # Construct tree
    tree = parse('3+3==6')
    tree = run_transformer_class(transformer, tree)
    # Collect results
    body = list(bfs_filter(tree, ast.Module))[0].body
    imports_node = list(bfs_filter(tree, ast.ImportFrom))[0]
    # Assert results are acceptable
    assert get_node_names(body) == ['ImportFrom', 'Expr', 'ImportFrom', 'Expr', 'Expr']
    assert imports_node.module == '__future__'
   

# Generated at 2022-06-23 22:49:00.991409
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import typed_astunparse

    module = typed_astunparse.ast3parse("print('hello')")

    node_transformer = Python2FutureTransformer()
    module = node_transformer.visit(module)

    assert module.body[0].value.s == 'print_function'
    assert isinstance(module.body[0], ast.ImportFrom)



# Generated at 2022-06-23 22:49:06.711932
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import textwrap
    def get_ast_from_snippet(snippet):
        tree = ast.parse(textwrap.dedent(snippet))
        return tree

    tree = get_ast_from_snippet('''
    import datetime
    import os

    def func():
        pass
    ''')
    assert len(tree.body) == 3

    Python2FutureTransformer().visit(tree)
    assert len(tree.body) == 7
    assert tree.body[0].names[0].name == 'absolute_import'
    assert tree.body[1].names[0].name == 'division'
    assert tree.body[2].names[0].name == 'print_function'
    assert tree.body[3].names[0].name == 'unicode_literals'

# Generated at 2022-06-23 22:49:15.646943
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from pprint import pprint
    from typed_ast import ast3 as ast
    from .. import transform_to_target, compose_visitors, Python2FutureTransformer
    from .base import PythonNodeTransformerVisitor
    snippet = '\n'.join([
        'def foo():',
        '    a = 1',
        ''
    ])
    target = (2, 7)
    visitor = compose_visitors([
        PythonNodeTransformerVisitor,
        Python2FutureTransformer,
    ])
    visitor.target = target
    tree = ast.parse(snippet)
    visitor.visit(tree)
    assert not visitor._tree_changed
    tree = ast.parse(snippet)
    tree = transform_to_target(tree, target)
    pprint(tree)
    assert visitor._tree_changed

# Generated at 2022-06-23 22:49:22.193304
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    src = ast.parse("import math")
    m = Python2FutureTransformer(src)
    assert m.get_tree() == ("from __future__ import absolute_import\n"
                    "from __future__ import division\n"
                    "from __future__ import print_function\n"
                    "from __future__ import unicode_literals\n"
                    "\n"
                    "import math")

# Generated at 2022-06-23 22:49:27.251939
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    module_ast_str = """print('hello world!')"""
    module_ast = ast.parse(module_ast_str)
    transformer = Python2FutureTransformer()
    module_ast_changed = transformer.visit(module_ast)
    assert astor.to_source(module_ast_changed).strip() == """from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
print('hello world!')"""

# Generated at 2022-06-23 22:49:37.460343
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast.ast3 import parse
    from typed_ast.ast3 import dump
    from typed_ast.ast3 import Module
    from typed_ast.ast3 import Expr
    from typed_ast.ast3 import Str
    from ..utils.fake_node import FakeNode
    fake_node = FakeNode()
    module = parse('print("hello world")')
    assert isinstance(module, Module), type(module)
    
    visitor = Python2FutureTransformer()
    module_ = visitor.visit(module)
    
    assert visitor.tree_changed
    assert module is not module_
    assert isinstance(module_, Module), type(module_)
    assert len(module_.body) == 5
    assert all(isinstance(e, Expr) for e in module_.body)

# Generated at 2022-06-23 22:49:47.715180
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typing import Dict, List
    from ..transformer import ModuleTransformer
    from ..utils import parse_text, parse_node
    from ..utils.snippet import Snippet
    
    source = '''
    # My module
    "My docstring"
    import sys
    import os
    import math
    import re

    x = sys.argv[1]
    print(x)
    '''
    source = source.strip()
    tree = parse_text(source, parser='python2')
    ctx = ModuleTransformer(tree=tree)
    transformer = Python2FutureTransformer(ctx=ctx)
    new_tree = transformer.visit(tree)

# Generated at 2022-06-23 22:49:53.147894
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    f, t = mock_files('test_module')

    with patch('builtins.open', mock_open(read_data=f.read())):
        tree = astor.parse_file(f.__enter__().name)
        Python2FutureTransformer().visit(tree)

    assert_source_equal(t.read(), astor.to_source(tree))

# Generated at 2022-06-23 22:49:57.833005
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from . import ast_test_fixture

    result = Python2FutureTransformer.construct(ast_test_fixture).visit(ast_test_fixture)
    assert result is not None
    assert hasattr(result, 'body')
    assert type(result.body[0]) == ast.ImportFrom

# Generated at 2022-06-23 22:50:07.898701
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    code = """
import os, sys
print("Hello world")
    """
    expected = imports.get_body(future='__future__') + [ast.Import(
        names=[
            ast.alias(
                name='os',
                asname=None
            ),
            ast.alias(
                name='sys',
                asname=None
            )
        ],
    ), ast.Expr(
        value=ast.Call(
            func=ast.Name(
                id='print',
                ctx=ast.Load()
            ),
            args=[
                ast.Str(
                    s='Hello world'
                )
            ],
            keywords=[
            ],
            starargs=None,
            kwargs=None
        )
    )]
    tree = ast.parse(code)

# Generated at 2022-06-23 22:50:13.942699
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    expected = ("from __future__ import absolute_import\n"
                "from __future__ import division\n"
                "from __future__ import print_function\n"
                "from __future__ import unicode_literals\n"
                "\n"
                "import six\n"
                "from astroid import MANAGER\n"
                "\n"
                "def register(linter):\n"
                "    pass\n")
    module = ast.parse(expected)
    module2 = Python2FutureTransformer().visit(module)
    assert module2.as_string() == expected

# Generated at 2022-06-23 22:50:24.716418
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = ast.parse('from __future__ import print_function\nx=3')
    Python2FutureTransformer().visit(module)

# Generated at 2022-06-23 22:50:30.616748
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    test_module = ast.parse('import os')
    transformer = Python2FutureTransformer()
    transformer.visit(test_module)
    expected = '''
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

import os
'''
    assert astor.to_source(test_module) == dedent(expected)

# Generated at 2022-06-23 22:50:34.537682
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    sut = Python2FutureTransformer()
    node = ast.parse("import sys")
    actual = sut.visit(node)
    assert isinstance(actual, ast.Module)
    assert actual.body[0].names[0].name == "absolute_import"
    


# Generated at 2022-06-23 22:50:39.698249
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import ast as _ast
    mod = _ast.parse('a = 1')
    assert Python2FutureTransformer().transform(mod) == _ast.parse('from __future__ import absolute_import\n' +
                                                                   'from __future__ import division\n' +
                                                                   'from __future__ import print_function\n' +
                                                                   'from __future__ import unicode_literals\n' +
                                                                   'a = 1')

# Generated at 2022-06-23 22:50:42.694834
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast

    node = ast.parse("", "", "exec")
    trf = Python2FutureTransformer()
    node = trf.visit(node)
    assert ast.dump(node) == """"""

# Generated at 2022-06-23 22:50:44.800493
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)

# Unit tests for visit_Module of class Python2FutureTransformer

# Generated at 2022-06-23 22:50:45.739151
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__doc__

# Generated at 2022-06-23 22:50:47.181303
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import_module('.py2_future', 'transmogrifier.transformer.py2_future')

# Generated at 2022-06-23 22:50:52.557691
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse("def f():\n pass")
    node = Python2FutureTransformer().visit(node)
    assert "from __future__ import absolute_import" in ast.dump(node)
    assert "from __future__ import division" in ast.dump(node)
    assert "from __future__ import print_function" in ast.dump(node)
    assert "from __future__ import unicode_literals" in ast.dump(node)

# Generated at 2022-06-23 22:50:59.767911
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():

    from .test_utils import round_trip, dedent
    from typed_ast import parse

    source = dedent('''\
        import os
        def hello(a, b):
            return a + b
        print(hello(1, 2))  # prints 3
    ''')

    module = parse(source)
    module = Python2FutureTransformer.run_pipeline(module)
    assert round_trip(module) == dedent('''\
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        import os
        def hello(a, b):
            return a + b
        print(hello(1, 2))  # prints 3
    ''')

# Generated at 2022-06-23 22:51:03.417354
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    transformer = Python2FutureTransformer()
    module = ast.parse('print("Hello World")')
    transformer.visit(module)
    assert transformer._tree_changed == True  # type: ignore


# Generated at 2022-06-23 22:51:12.265413
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    from pprint import pprint

    class Test:
        """
        The class is used for asserting transformed code
        """
        @staticmethod
        def code(code_string, line_offset=0):
            """
            The method "code" is used for asserting code.

            Parameters
            ----------
            code_string : str
                the code which will be asserted by the method;
            line_offset : int
                the number of lines which need to be skipped while
                asserting code.

            Return
            ------
            Tuple[str, int]
                the tuple, first item is code, second item is number of lines
                which were skipped.

            """
            lines = code_string.split('\n')
            return tuple(map(str.strip, lines[line_offset:]))


# Generated at 2022-06-23 22:51:20.645353
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    input = """#!/usr/bin/env python
# coding=utf-8

'''
docs
'''

a = 1

print(a)
"""
    expected = """#!/usr/bin/env python
# coding=utf-8
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

'''
docs
'''

a = 1

print(a)
"""
    tree = ast3.parse(input)
    Python2FutureTransformer().visit(tree)  # type: ignore
    actual = ast3.unparse(tree)
    assert actual == expected

# Generated at 2022-06-23 22:51:23.981836
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .helper import ast_parse
    node = ast_parse("print('hello')")
    assert len(node.body) == 1
    assert isinstance(node.body[0], ast.Expr)
    transformer = Python2FutureTransformer()
    node = transformer.visit(node)
    assert isinstance(node.body[0], ast.ImportFrom)

# Generated at 2022-06-23 22:51:27.737668
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import typed_astunparse
    source = """
a = 1
print('test')
    """
    expected = imports + source
    tree = ast.parse(source)  # type: ignore
    transformer = Python2FutureTransformer()
    tree = transformer.visit(tree)  # type: ignore
    assert typed_astunparse.unparse(tree) == expected

# Generated at 2022-06-23 22:51:29.756582
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = ast.parse("")

# Generated at 2022-06-23 22:51:36.778851
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-23 22:51:46.524721
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Tests
    import astor
    from .make_module import make_module, make_node_body

    def test_one(str_nodes: str) -> ast.AST:
        module = make_module(str_nodes)
        transformer = Python2FutureTransformer()
        return transformer.visit(module)

    assert astor.to_source(test_one("print('Hello, World!')")) == \
        "from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n\nprint('Hello, World!')\n"

# Generated at 2022-06-23 22:51:56.973402
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.compat import StringIO

    code = StringIO()
    code.write('import builtins')
    code.seek(0)
    code = code.read()
    tree = compile(code, '<string>', 'exec', ast.PyCF_ONLY_AST)
    tree = Python2FutureTransformer().visit(tree)
    compile(tree, '<string>', 'exec')

    code = StringIO()
    code.write('from __future__ import print_function')
    code.seek(0)
    code = code.read()
    tree = compile(code, '<string>', 'exec', ast.PyCF_ONLY_AST)
    tree = Python2FutureTransformer().visit(tree)

# Generated at 2022-06-23 22:52:05.881992
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .base import BaseNodeTransformerTest
    code = BaseNodeTransformerTest.get_source(target=(2, 7))

    from .base import get_ast
    node = get_ast(code).body
    node = Python2FutureTransformer().visit(node)  # type: ignore
    assert ast.dump(node) == ast.dump(Python2FutureTransformer().visit(get_ast(code).body))  # type: ignore  # noqa: E501


# Generated at 2022-06-23 22:52:07.151190
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    trans = Python2FutureTransformer()
    assert trans.target == (2, 7)

# Generated at 2022-06-23 22:52:17.403316
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import unittest
    import astor
    from typed_ast import ast27
    from typedast2ast.transformers.Python2FutureTransformer import Python2FutureTransformer
    from typed_ast import ast3
    from .test_BaseNodeTransformer import BaseNodeTransformerTest


# Generated at 2022-06-23 22:52:21.374579
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    source = snippet.dedent(r'''
        a = 0
        print(a)
    ''')
    expected = snippet.dedent(r'''
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        
        a = 0
        print(a)
    ''')
    actual = snippet(Python2FutureTransformer().visit(ast.parse(source)))
    assert expected == actual

# Generated at 2022-06-23 22:52:31.263587
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3
    import sys
    import astunparse
    import textwrap
    from .unit_test_ast import ast_equal  # from ..unit_test_ast import ast_equal
    from .unit_test_ast import parse_ast

    code = 'def test_method():\n    print("something")'
    node = parse_ast(code)
    node = Python2FutureTransformer().visit(node)
    print(astunparse.unparse(node))

# Generated at 2022-06-23 22:52:33.551873
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.tree_changed == False
    assert transformer.target == (2, 7)


# Generated at 2022-06-23 22:52:34.547713
# Unit test for constructor of class Python2FutureTransformer

# Generated at 2022-06-23 22:52:40.428466
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor
    transformer = Python2FutureTransformer()
    module_node = ast.parse(
        """def bar():
            print('bar')
        """)
    module_node = transformer.visit(module_node)
    assert transformer._tree_changed is True  # pylint: disable=protected-access

# Generated at 2022-06-23 22:52:41.513508
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()

# Generated at 2022-06-23 22:52:47.574116
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import textwrap
    sample_source = textwrap.dedent("""\
        import abc
        import importlib
        import operator
        """)

    expected_output = textwrap.dedent("""\
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        import abc
        import importlib
        import operator
        """)

    from py2to3.main import transform
    from py2to3.pgen2.parse import ParseError
    try:
        actual_output = transform(sample_source, Python2FutureTransformer)
    except ParseError as e:
        print(e.text)
        print(e.msg)
        print(e.lineno)

# Generated at 2022-06-23 22:52:48.567936
# Unit test for constructor of class Python2FutureTransformer

# Generated at 2022-06-23 22:52:49.282832
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    n = Python2FutureTransformer(target=(2, 7))


# Generated at 2022-06-23 22:52:50.235952
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-23 22:52:55.720993
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source
    from ..utils.ast import get_ast
    from typed_ast import ast3 as ast

    transformer = Python2FutureTransformer()
    source_code = source('''
        def foo():
            pass
    ''')

    ast_tree = get_ast(source_code, transformer=transformer, target=(2, 7))
    assert isinstance(ast_tree, ast.Module)
    assert len(ast_tree.body) == 5  # 4 __future__ imports + 1 function definition

# Generated at 2022-06-23 22:53:06.321499
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    readast = Python2Read()

    node = readast.visit(ast.parse('''
    import sys
    print('hello, world!')
    '''))
    assert isinstance(node, ast.Module)
    assert len(node.body) == 2
    assert isinstance(node.body[0], ast.Import)
    assert isinstance(node.body[1], ast.Expr)

    future = Python2FutureTransformer()
    node = future.visit(node)
    assert isinstance(node, ast.Module)
    assert len(node.body) == 8
    assert isinstance(node.body[0], ast.ImportFrom)
    assert isinstance(node.body[1], ast.ImportFrom)
    assert isinstance(node.body[2], ast.ImportFrom)

# Generated at 2022-06-23 22:53:08.454383
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    obj = Python2FutureTransformer()
    assert obj.target == (2, 7)
    assert obj._tree_changed == False
    assert repr(obj) == "<Python2FutureTransformer() target=(2, 7) _tree_changed=False>"


# Generated at 2022-06-23 22:53:10.477821
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Arrange
    node = ast.parse("pass")
    transformer = Python2FutureTransformer()

    # Act
    transformer.visit(node)

    # Assert
    assert "" == str(transformer)
    assert str(transformer) == astunparse.unparse(node)

# Generated at 2022-06-23 22:53:11.059670
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-23 22:53:12.115394
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astunparse

# Generated at 2022-06-23 22:53:12.592787
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass

# Generated at 2022-06-23 22:53:13.609333
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..parser import parse_string


# Generated at 2022-06-23 22:53:15.802276
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)
    assert not transformer._tree_changed
    assert transformer.replacements == {}



# Generated at 2022-06-23 22:53:16.463624
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-23 22:53:19.476860
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import ast
    from ..utils.mock import mock_module

# Generated at 2022-06-23 22:53:23.502244
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    obj = Python2FutureTransformer('', '', '')
    assert obj._tree_changed is False
    assert obj.target == (2, 7)
    assert obj.encoding == ''
    assert obj.future == ''
    assert obj.futurize is False


# Generated at 2022-06-23 22:53:24.182878
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    te = Python2FutureTransformer()

# Generated at 2022-06-23 22:53:30.434821
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    mod = ast.parse(dedent("""
    def f():
        pass
    """))
    transformer = Python2FutureTransformer()
    mod = transformer.visit(mod)
    assert transformer._tree_changed
    assert str(mod) == dedent("""
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    
    
    def f():
        pass
    """)

# Generated at 2022-06-23 22:53:31.921791
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer().target == (2, 7)

# Generated at 2022-06-23 22:53:36.248034
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast.ast3 import parse
    from ..transform import run_transformers

    code = '''def foo(): return "foo"'''

# Generated at 2022-06-23 22:53:46.753225
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.mock_ast import get_target_ast
    node = get_target_ast(r"""
        import math
        print("hello")
        
        def f(x: int) -> int:
            return math.sqrt(x)
    """)
    assert node.body[0].names == [ast.alias("math", None)]
    assert node.body[2].name == "f"
    t = Python2FutureTransformer().visit(node)
    assert t.body[0].names == [ast.alias("absolute_import", None),
                               ast.alias("division", None),
                               ast.alias("print_function", None),
                               ast.alias("unicode_literals", None)]
    assert t.body[1].names == [ast.alias("math", None)]
    assert t

# Generated at 2022-06-23 22:53:47.408001
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert repr(Python2FutureTransformer())

# Generated at 2022-06-23 22:53:48.263016
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-23 22:53:53.727856
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astunparse
    code = """
        def f():
            print('Hello World')
    """
    tree = ast.parse(code)
    future = Python2FutureTransformer().visit(tree)
    assert astunparse.unparse(future).strip() == dedent("""
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals


        def f():
            print('Hello World')
    """).strip()



# Generated at 2022-06-23 22:53:57.489239
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer(None).__class__.__name__ == "Python2FutureTransformer"
    assert Python2FutureTransformer(None).target == (2, 7)
    assert Python2FutureTransformer(None)._tree_changed == False



# Generated at 2022-06-23 22:54:03.057676
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor
    node = ast.parse("""x = "hi"\nprint(x)""")
    transform = Python2FutureTransformer()
    transform.visit(node)
    code = astor.to_source(node)
    assert code == """from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
x = "hi"
print(x)""".lstrip()

# Generated at 2022-06-23 22:54:12.161429
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Arrange
    node = ast.parse('a = 0')
    # Act
    transformer = Python2FutureTransformer(node)
    result = transformer.visit(node)
    # Assert
    assert transformer._tree_changed
    assert len(result.body) == 4
    assert result.body[0].module == '__future__'
    assert result.body[0].names[0].name == 'absolute_import'
    assert result.body[1].module == '__future__'
    assert result.body[1].names[0].name == 'division'
    assert result.body[2].module == '__future__'
    assert result.body[2].names[0].name == 'print_function'
    assert result.body[3].module == '__future__'
    assert result.body[3].names

# Generated at 2022-06-23 22:54:22.385430
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3
    from typed_ast.ast3 import Module

    class ModuleStub(Module):
        def __init__(self, body, type_ignores):
            self.body = body
            self.type_ignores = type_ignores

        def __repr__(self):
            return "Module(body={}, type_ignores={})".format(self.body, self.type_ignores)

        def __eq__(self, other):
            return (
                isinstance(other, ModuleStub) and
                self.body == other.body and
                self.type_ignores == other.type_ignores
            )


# Generated at 2022-06-23 22:54:33.285860
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast

    # Case 1
    tree1 = ast.parse(
        textwrap.dedent("""
        import sys
        def foo() -> bool:
            return True
        """)
    )
    actual = Python2FutureTransformer().visit(tree1)
    assert isinstance(actual, ast.Module)
    assert len(actual.body) == 4
    for i, item in enumerate(actual.body):
        if i == 0:
            assert type(item) is ast.ImportFrom
            assert item.module == "__future__"
            assert item.names[0].name == "absolute_import"
            assert item.level == 0
        elif i == 1:
            assert type(item) is ast.ImportFrom
            assert item.module == "__future__"

# Generated at 2022-06-23 22:54:41.325294
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    transformer = Python2FutureTransformer()
    tree = ast.parse('''
    def f():
        pass
    ''')
    transformer.visit(tree)
    from typed_ast import ast3 as ast

# Generated at 2022-06-23 22:54:47.335639
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast.ast3 import parse
    import unittest

    class TestAST(unittest.TestCase):
        ast = parse("""print(1+1)""")
        print(ast)
        result = parse("""from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
print(1+1)""")
        def test_module(self):
            self.assertEqual(self.ast, self.result)

    unittest.main()

# Generated at 2022-06-23 22:54:48.425328
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()

# Generated at 2022-06-23 22:54:50.105549
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer(target_info=None)
    assert isinstance(t, BaseNodeTransformer)
    assert t.tree_changed == False

# Generated at 2022-06-23 22:54:58.157314
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .. import transform

    # Given
    code = '''
    def foo():
        print(bar)
    '''
    tree = ast.parse(code)
    transformer = Python2FutureTransformer()

    # When
    tree = transformer.visit(tree)

    # Then
    expected = '''
    from future import absolute_import
    from future import division
    from future import print_function
    from future import unicode_literals
        
    def foo():
        print(bar)
    '''
    assert transform(tree) == expected

# Generated at 2022-06-23 22:54:59.755263
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    future = Python2FutureTransformer()
    assert(future.target == (2, 7))

# Generated at 2022-06-23 22:55:10.842945
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils import get_ast

    assert Python2FutureTransformer(get_ast('def a()')).result == \
        'from __future__ import absolute_import\n' \
        'from __future__ import division\n' \
        'from __future__ import print_function\n' \
        'from __future__ import unicode_literals\n' \
        '\ndef a():\n    pass\n'


# Generated at 2022-06-23 22:55:11.373723
# Unit test for constructor of class Python2FutureTransformer

# Generated at 2022-06-23 22:55:21.510316
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3

    node = ast3.parse('a = 1')
    transformer = Python2FutureTransformer()
    transformed = transformer.visit_Module(node)

# Generated at 2022-06-23 22:55:22.420192
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass


# Generated at 2022-06-23 22:55:27.767628
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    py2future = Python2FutureTransformer()

    # The following assertions verify that all methods are
    # implemented in the class Python2FutureTransformer
    assert hasattr(py2future, 'visit_Module')
    assert hasattr(py2future, 'visit_ImportFrom')
    assert hasattr(py2future, 'visit_Import')
    assert hasattr(py2future, 'visit_alias')
    assert hasattr(py2future, 'generic_visit')
    assert hasattr(py2future, 'target')

# Generated at 2022-06-23 22:55:30.133243
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    import typed_ast.ast3
    from typed_ast.transforms.future import Python2FutureTransformer


# Generated at 2022-06-23 22:55:30.711159
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-23 22:55:38.336543
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast27 as ast
    from ..transformers.python2 import Python2FutureTransformer
    from ..utils.snippet import snippet

    code = 'pass\n'
    code_ast = compile(code, filename="<ast>", mode="exec", flags=ast.PyCF_ONLY_AST)
    assert isinstance(code_ast, ast.Module)
    transformer = Python2FutureTransformer()
    code_ast = transformer.visit(code_ast)
    assert code_ast is not None
    expected_code = snippet(imports.format(future='__future__'), from_string=True)
    assert expected_code in code_ast.body

# Generated at 2022-06-23 22:55:39.856634
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target==(2, 7)


# Generated at 2022-06-23 22:55:43.608835
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast

    node = ast.parse("abs(1)", "<test>", "exec")
    Python2FutureTransformer.run_visitor(node)
    assert ast.dump(node) == ast.dump("""\
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

abs(1)""")

# Generated at 2022-06-23 22:55:49.158625
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import string
    import sys
    from ..utils.snippet import snippet
    from ... import Python2FutureTransformer

    @snippet
    def _common():
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        
        s = set("abc")
        print("".join(s))
        r = []
        for c in s:
            r.append(c * 2)
        print("".join(r))
        
    v = Python2FutureTransformer(sys.version_info)

# Generated at 2022-06-23 22:55:59.910929
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast.ast3 import Module
    from typed_ast import ast3 as ast
    from ..utils.source import source
    from ..utils.ast_diff import ast_diff

    transformer = Python2FutureTransformer()

# Generated at 2022-06-23 22:56:04.916411
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = ast.parse('')
    transformer = Python2FutureTransformer()
    module = transformer.visit(module)
    expected = '''
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
        '''
    assert_equals(expected, astor.to_source(module))

# Generated at 2022-06-23 22:56:11.069099
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import ast as ast2
    # Setup
    node = ast.parse('x = 1')
    node.body = [
        ast.Import([ast.alias(name='__future__', asname=None)]),
        ast.ImportFrom(module='__future__', names=[], level=0)
    ]
    expected = ast2.parse(imports(future='__future__')).body
    expected.append(ast.parse('x = 1').body[0])
    # Exercise
    instance = Python2FutureTransformer()
    result = instance.visit_Module(node)
    # Verify
    assert result.body == expected



# Generated at 2022-06-23 22:56:18.209323
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    statement = f'''
        import sys
        import pandas
        import numpy
        import scipy
        print('hello')
    '''
    expected = f'''
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        import sys
        import pandas
        import numpy
        import scipy
        print('hello')
    '''
    module = ast.parse(statement)
    transformer = Python2FutureTransformer()
    transformer.visit(module)
    assert(expected == astor.to_source(module))

# Generated at 2022-06-23 22:56:21.885228
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    tr = Python2FutureTransformer()
    assert tr.target == (2, 7)
    assert tr.target_options['py2.7'] == (2, 7)
    assert not tr._tree_changed



# Generated at 2022-06-23 22:56:25.902017
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast

    tree = ast.parse('a = 5')
    tree = Python2FutureTransformer().visit(tree)

    assert imports.dump_tree() == ast.dump(tree)

# Generated at 2022-06-23 22:56:36.862070
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = ast.parse('x = 1')
    transformer = Python2FutureTransformer(in_place=False)

    _ = transformer.visit(module)  # type: ignore

    assert transformer._tree_changed is True


# Generated at 2022-06-23 22:56:44.265637
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Test the constructor of the class Python2FutureTransformer"""
    target = (2, 7)
    expected_target = target
    expected_results = (expected_target, False)
    actual_results = Python2FutureTransformer(target)
    assert isinstance(actual_results, Python2FutureTransformer)
    assert actual_results.target == expected_target
    assert actual_results._tree_changed == expected_results[1]



# Generated at 2022-06-23 22:56:45.125508
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-23 22:56:49.129688
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    expected = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals


    def foo():
        pass
    """
    node = ast.parse(expected)
    new_node = Python2FutureTransformer().visit(node)
    assert ast.dump(new_node) == ast.dump(node)

# Generated at 2022-06-23 22:56:50.834694
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Unit test for constructor of class Python2FutureTransformer"""
    Python2FutureTransformer()

# Generated at 2022-06-23 22:56:54.170130
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = ast.parse('x = "This is a test"')
    new_module = Python2FutureTransformer().visit(module)
    assert new_module != module
    assert new_module.body[0].module == '__future__'

# Generated at 2022-06-23 22:56:59.226567
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3
    tf = Python2FutureTransformer()
    result = tf.visit(ast3.parse("print('Hello, world!')"))
    assert isinstance(result, ast3.Module)
    assert str(result) == (
        "from __future__ import absolute_import\n"
        "from __future__ import division\n"
        "from __future__ import print_function\n"
        "from __future__ import unicode_literals\n"
        "\n"
        "print('Hello, world!')\n"
    )

# Generated at 2022-06-23 22:57:00.068724
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-23 22:57:08.809467
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    class Test(unittest.TestCase):
        def setUp(self):
            self.maxDiff = None

        def test_normal(self):
            t = ast.parse("print('hello', 'world')")
            Python2FutureTransformer(t).visit(t)

# Generated at 2022-06-23 22:57:09.976053
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()


# Generated at 2022-06-23 22:57:11.271368
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()
    assert isinstance(t, BaseNodeTransformer)

# Generated at 2022-06-23 22:57:15.866452
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import_future = ast.parse('from __future__ import absolute_import').body[0]
    test_ast = ast.Module([import_future])
    transformed_ast = Python2FutureTransformer().visit(test_ast)
    assert isinstance(transformed_ast.body[0], ast.ImportFrom)


# Generated at 2022-06-23 22:57:19.699702
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    python_code = "import foo"
    expected_result = "from __future__ import absolute_import;from __future__ import division;from __future__ import print_function;from __future__ import unicode_literals;import foo"
    result = Python2FutureTransformer(python_code).get_source_without_future()
    assert result == expected_result

# Generated at 2022-06-23 22:57:21.826226
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert isinstance(transformer, Python2FutureTransformer)

# Generated at 2022-06-23 22:57:28.324958
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from .python2futuretransform import Python2FutureTransformer
    

    @snippet
    def main():
        x = 2
        print(x)

    transformer = Python2FutureTransformer()
    root_node: ast.Module = main.get_ast()  # type: ignore
    transformer.visit(root_node)

    @snippet
    def root_node_expected():
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        x = 2
        print(x)

    assert main.get_body() == root_node_expected.get_body() # type

# Generated at 2022-06-23 22:57:38.015482
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from .node_transformer_test_util import NodeTransformerTestCase, transform
    from . import Python2FutureTransformer

    class Test(NodeTransformerTestCase):
        def test(self):
            tree = ast.parse("""
                import os
                import sys
                import time
            """)
            self.check(transform(tree, Python2FutureTransformer), """
                import __future__
                from __future__ import absolute_import
                from __future__ import division
                from __future__ import print_function
                from __future__ import unicode_literals
                import os
                import sys
                import time
            """)

    Test().test()

# Generated at 2022-06-23 22:57:44.347637
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer

    source = """\
    import os
    import json

    def main():
        pass
    """
    tree = ast.parse(source)

    tree = Python2FutureTransformer().visit(tree)

# Generated at 2022-06-23 22:57:45.190867
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-23 22:57:47.634609
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import typed_ast.ast3 as ast
    transformer = Python2FutureTransformer()
    test_node = ast.Module(body=[])
    assert transformer.visit(test_node) == test_node

# Generated at 2022-06-23 22:57:51.296982
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from pytree import TreeBuild
    from typed_ast import ast3 as ast
    from pprint import pprint
    from .base import BaseNodeTransformer

# Generated at 2022-06-23 22:58:02.220762
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()
    node1 = ast.parse('import io\ni = io.StringIO()\n')
    result1 = transformer.visit(node1)

# Generated at 2022-06-23 22:58:07.124572
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    tree = ast.parse('a = 5')
    node: ast.Module = tree.body[0]
    trans = Python2FutureTransformer()
    trans.visit(tree)
    assert str(tree) == '''from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

a = 5'''

# Generated at 2022-06-23 22:58:17.593752
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .. import ast_converter
    from ..utils.source import source_to_unicode
    source = source_to_unicode("""
    a = 2
    b = 3
    print(a + b)
    print("Hello world")
    """)
    tree = ast_converter.parse(source)
    node_transformer = Python2FutureTransformer()
    node_transformer.visit(tree)
    assert node_transformer._tree_changed