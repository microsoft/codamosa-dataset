

# Generated at 2022-06-23 22:48:24.335781
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    x = Python2FutureTransformer()
    assert isinstance(x, Python2FutureTransformer)



# Generated at 2022-06-23 22:48:26.028554
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.__class__.__name__ == 'Python2FutureTransformer'

# Generated at 2022-06-23 22:48:29.004522
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    tree = astor.parse_file(__file__)
    Python2FutureTransformer(tree).visit(tree)
    assert tree == astor.parse_file(__file__)

# Generated at 2022-06-23 22:48:29.581098
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass

# Generated at 2022-06-23 22:48:35.811182
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source_to_ast_str
    from ..utils.source import source_to_node
    from ..utils.source import source_to_nodes
    from ..utils.source import source_to_visit

    # Test 1: imports prepended
    source = """
    from future import absolute_import
    from future import division
    from future import print_function
    from future import unicode_literals
    """
    node = source_to_node(source, transform=Python2FutureTransformer)
    assert ast.dump(node) == source_to_ast_str(imports.get_source())
    assert source_to_visit(node) == source_to_visit(source_to_nodes(source, 'Module')[0])

# Generated at 2022-06-23 22:48:46.735350
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    from .base import BaseNodeTransformerTestCase
    from .snippet import snippet
    from .snippet import SnippetTestCase

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    @snippet
    def test():
        import math
        import sys
        def main():
            print("3 + 5 =", 3 + 5)
            print("3.0 + 5 =", 3.0 + 5)
            print("3 / 5 =", 3 / 5)
            print("3.0 / 5 =", 3.0 / 5)
            print("3 // 5 =", 3 // 5)
            print("3.0 // 5 =", 3.0 // 5)
           

# Generated at 2022-06-23 22:48:51.856540
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # pylint: disable=no-member
    node = ast.parse("")
    transformer = Python2FutureTransformer(node=node)
    # pylint: enable=no-member
    new_tree = transformer.visit(node)
    assert new_tree.body[0] == imports.get_body(future='__future__')[0]

# Generated at 2022-06-23 22:48:58.973775
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import parse_ast

    module = ast.parse(textwrap.dedent('''
        """a
        b
        c"""
        def foo():
            pass
    '''))

    pt = Python2FutureTransformer()
    pt.visit(module)
    module_ = pt.visit(module)

    assert module_ == parse_ast(textwrap.dedent('''
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        """a
        b
        c"""


        def foo():
            pass
    '''))

# Generated at 2022-06-23 22:49:05.305570
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ast_helpers.transforms import Python2FutureTransformer
    from typed_ast import ast3 as ast

    class Arg(ast.AST):
        fields = ('value',)
        _fields = ('s',)

    obj = Arg(value='__future__')
    input_ast = ast.Module(body=[])

    transformer = Python2FutureTransformer()
    result_ast = transformer.visit(input_ast)


# Generated at 2022-06-23 22:49:14.764443
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from typed_astunparse import unparse
    import textwrap

    source = textwrap.dedent('''\
    def foo():
        pass''')

    expected = textwrap.dedent('''\
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals


    def foo():
        pass''')

    transformer = Python2FutureTransformer()
    transformed_tree = transformer.visit(ast.parse(source))
    transformed_source = unparse(transformed_tree).strip()
    assert expected == transformed_source, 'Expected:\n{}\nbut got\n{}'.format(expected, transformed_source)



# Generated at 2022-06-23 22:49:25.626005
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import ast
    import io
    from typed_ast import ast3
    from typed_ast import convert

    tree = ast.parse("x=1")

    transformed = convert(tree, future_features=("absolute_import", "division",
    "print_function", "unicode_literals"))

    print(ast.dump(transformed))

    mystr = io.StringIO()

    ast.dump(transformed, mystr)


# Generated at 2022-06-23 22:49:26.539843
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert inspect.isclass(Python2FutureTransformer)


# Generated at 2022-06-23 22:49:36.573289
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_test_function
    from ..basic_transforms import PrimeTransformer
    from .. import transforms  # noqa

    # Using the same sequence as in main test_full_transform
    seq = [
        transforms.AddFutureImportsTransform,
        Python2FutureTransformer,
        transforms.LocalImportsTransform,
        transforms.AddParamsTransform,
        transforms.AddTypeHintsTransform,
        transforms.RemovePrintFunctionTransform,
        transforms.AddReturnsTypeTransform,
        transforms.AddRaisesTransform,
        transforms.AddYieldsTransform,
        transforms.AddAstroidAnnotationsTransform,
        PrimeTransformer,
    ]

    func = make_test_function(version=2)
    func_expected = make_test_function(version=2, with_future=True)


# Generated at 2022-06-23 22:49:38.449929
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer() is not None

# Unit test: Create a class Python2FutureTransformer

# Generated at 2022-06-23 22:49:40.286315
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    node = ast.parse('')  # type: ignore
    assert Python2FutureTransformer().visit(node) == node

# Generated at 2022-06-23 22:49:43.279019
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    py2F = Python2FutureTransformer("foo.py")
    assert py2F.target == (2, 7)
    assert py2F._future == '__future__'


# Generated at 2022-06-23 22:49:51.886347
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Unit test for constructor of class Python2FutureTransformer"""
    from mypy_boto3_builder.structures.manifest import Module
    from mypy_boto3_builder.structures.table import Table
    from mypy_boto3_builder.structures.service_package import ServicePackage
    from mypy_boto3_builder.type_annotations.fake_annotation import FakeAnnotation

    package = ServicePackage('foo', '1.2.3', 'eu-central-1', 'foo.bar', FakeAnnotation())
    table = Table('foo', 'bar', package)
    module = Module(table)
    transformer = Python2FutureTransformer(module)

    assert not transformer._tree_changed

    module.ast = ast.parse(imports(future='__future__'))

# Generated at 2022-06-23 22:50:02.721328
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_fixtures
    from ..utils.source import source
    from ..utils.tree import dump_ast
    from ..utils.tree import strip_location

    fixtures = make_fixtures('Python2FutureTransformer_visit_Module')
    transformer = Python2FutureTransformer()
    
    for fixture in fixtures:
        source_ast = source(fixture.before).ast()
        target_ast = source(fixture.after).ast()
        result_ast = transformer.visit(source_ast)
        assert strip_location(result_ast) == strip_location(target_ast)
    

#@snippet
#def print_function():
#    print('test')
#
#
## Unit test for method visit_FunctionDef of class Python2FutureTransformer
#def test_Python2Future

# Generated at 2022-06-23 22:50:05.012112
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    trf = Python2FutureTransformer()
    assert trf.__class__.__name__ == 'Python2FutureTransformer'


# Generated at 2022-06-23 22:50:11.497086
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    class ASTCopyer(ast.NodeTransformer):
        def generic_visit(self, node):
            return ast.copy_location(ast.NodeTransformer.generic_visit(self, node), node)

    node = ast.parse("")
    expected_node = ast.parse(imports)
    actual_node = ASTCopyer().transform(Python2FutureTransformer().transform(node))
    actual = ast.dump(actual_node, include_attributes=False)
    expected = ast.dump(expected_node, include_attributes=False)
    assert actual == expected



# Generated at 2022-06-23 22:50:18.580696
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .test_transformer import call_visit
    from ..utils.source import source
    from .test_transformer import transformer_test_case
    from typed_ast import ast3

    class test_Python2FutureTransformer_visit_Module(transformer_test_case):
        transformer = Python2FutureTransformer
        target = (2, 7)
        method = 'visit_Module'

        def test_imports(self):
            t = self.case_imports

            @t(source.module, "def a(): pass")
            def __(self, node):
                self.assertTrue(isinstance(node, ast3.Module))
                self.assertTrue(isinstance(node.body[0], ast3.ImportFrom))

# Generated at 2022-06-23 22:50:22.720549
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source
    from .base import BaseNodeTest
    from .base import get_node_transformer

    class Python2FutureTransformerTest(BaseNodeTest):
        target = (2, 7)
        node_transformer = get_node_transformer(Python2FutureTransformer)

    Python2FutureTransformerTest.test_default_source()

# Generated at 2022-06-23 22:50:32.971769
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source
    from .python2to3 import Python2to3Transformer
    from ..utils.ast import dump_ast

    actual_code = '''
    import os
    import sys'''

    expected_code = '''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    import os
    import sys'''

    actual_tree = ast.parse(source(actual_code))
    actual_tree = Python2FutureTransformer().visit(actual_tree) # type: ignore
    actual_tree = Python2to3Transformer().visit(actual_tree) # type: ignore

    expected_tree = ast.parse(source(expected_code))


# Generated at 2022-06-23 22:50:40.256383
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    ast_ = ast.parse("""
        def f(x):
            pass
    """)
    print("AST before:")
    print(ast.dump(ast_))
    transf = Python2FutureTransformer()
    ast_ = transf.visit(ast_)
    assert transf._tree_changed
    print("AST after:")
    print(ast.dump(ast_))
    assert ast_.body[0].name == 'absolute_import'
    assert ast_.body[1].name == 'division'
    assert ast_.body[2].name == 'print_function'
    assert ast_.body[3].name == 'unicode_literals'
    assert ast_.body[4].name == 'f'


# Generated at 2022-06-23 22:50:47.603912
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import ast
    original_program = ast.parse('print("hello, world!")')
    expected_program  = ast.parse('from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n\nprint("hello, world!")\n')
    assert Python2FutureTransformer().visit(original_program) == expected_program

# Generated at 2022-06-23 22:50:56.418782
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    input = ast.Module(
        body=[
            ast.Assign(
                targets=[ast.Name(id='a', ctx=ast.Store())],
                value=ast.Num(n=1)),
            ast.Expr(value=ast.Call(
                func=ast.Name(id='print', ctx=ast.Load()),
                args=[ast.Str(s='Hello, Python 2')],
                keywords=[])),
        ],
        type_ignores=[]
    )

# Generated at 2022-06-23 22:51:02.247460
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from pytest import raises
    from ..utils.fixtures import make_test_module

    module = make_test_module(
        name='test',
        body=['a = 1\n', 'b = 2\n', 'print(1)\n'],
        target=(2, 7),
    )
    node = module.body[0]
    assert isinstance(node, ast.Assign)

    # Actual test
    transformer = Python2FutureTransformer(module)
    transformed_module = transformer.visit(module)
    assert transformer._tree_changed is True

    # Check that the module's body is changed
    assert len(transformed_module.body) == 5
    for node in transformed_module.body:
        assert isinstance(node, ast.ImportFrom)

    # Check that the module's body is changed

# Generated at 2022-06-23 22:51:07.194548
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)
    assert transformer._tree_changed is False

# Unit tests for will_transform(self, node: ast.AST) -> bool

# Generated at 2022-06-23 22:51:18.397935
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from ..utils.test_utils import BaseAstNodeTestTransformer
    
    @snippet
    def module_with_func():
        def foo():
            pass
        
    tree = module_with_func.get_ast()
    module = Python2FutureTransformer().visit(tree)
    assert module.body[0].module == '__future__'
    assert module.body[1].module == '__future__'
    assert module.body[2].module == '__future__'
    assert module.body[3].module == '__future__'
    assert module.body[4].name == 'foo'
    BaseAstNodeTestTransformer.assert_source_equal(module, module_with_func.source)

# Generated at 2022-06-23 22:51:22.660600
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    from ... import Tree
    
    class_ = Python2FutureTransformer()
    assert class_.target == (2, 7)
    assert class_.visit_Module(Tree()).body == imports.get_body(future='__future__') + []

# Generated at 2022-06-23 22:51:23.981864
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer.get_instance()
    assert isinstance(transformer, Python2FutureTransformer)

# Generated at 2022-06-23 22:51:33.996140
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typing import List

    code = '''
import os
print("Hello")
'''
    tree = ast.parse(code)
    transformer = Python2FutureTransformer()
    tree_changed = transformer.visit(tree)
    assert transformer._tree_changed == True  # type: ignore
    assert tree_changed == True
    assert str(tree) == textwrap.dedent('''
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        import os
        print("Hello")
        ''').strip()
    # Check that all is ok if the import already exists

# Generated at 2022-06-23 22:51:38.878009
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    source = """x = '1'"""
    expected: ast.Module = ast.parse("""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
x = '1'
""")
    actual: ast.Module = transform(source, Python2FutureTransformer)
    assert expected == actual

# Generated at 2022-06-23 22:51:39.876742
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer()

# Generated at 2022-06-23 22:51:45.017423
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    expected = '''
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

print(2/3)
'''
    actual = snippet.parse_module(expected)
    transformer = Python2FutureTransformer()  # type: ignore
    actual = transformer.visit(actual)
    assert snippet.compare(expected, actual)

# Generated at 2022-06-23 22:51:52.774060
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    py_file = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'test_data', 'legacy', 'pythran', 'test_001.py'))
    with open(py_file, 'rt') as fin:
        code = fin.read()
    tree = ast.parse(code)
    trans = Python2FutureTransformer()
    tree = trans.visit(tree)
    assert trans.tree_changed
    assert tree is not None
    

# Generated at 2022-06-23 22:52:01.110269
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    m = ast.parse('print("hello")')
    t = Python2FutureTransformer()
    t.visit(m)
    res = ast.dump(m)
    print(res)

# Generated at 2022-06-23 22:52:01.681589
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass

# Generated at 2022-06-23 22:52:04.134653
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor

# Generated at 2022-06-23 22:52:10.007745
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    def test(source):
        transformer = Python2FutureTransformer()
        node = ast.parse(source)
        node = transformer.visit(node)
        source = argparse.Namespace()
        source.getvalue = lambda: to_source(node)
        return source.getvalue()
    
    # Test case #1
    source = 'module'
    result = test(source)
    assert result == imports.get_body(future='__future__') + [source]

# Generated at 2022-06-23 22:52:19.529661
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():

    from ..parser.python import parse

    class Test(object):
        "some test class"
        def __init__(self, value=0):
            self.value = value

    t = Test(42)
    root = parse(t)
    actual = Python2FutureTransformer().visit(root)
    assert actual.body[0].body[0].value.s == "some test class"
    assert actual.body[0].body[1].body[0].value.s == "some test class"
    assert actual.body[0].body[1].body[1].value.s == "some test class"
    assert actual.body[0].body[1].body[2].value.s == "some test class"
    assert actual.body[0].body[1].body[3].value.s == "some test class"

# Generated at 2022-06-23 22:52:21.264355
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-23 22:52:22.316744
# Unit test for constructor of class Python2FutureTransformer

# Generated at 2022-06-23 22:52:25.601284
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    instance = Python2FutureTransformer()
    assert isinstance(instance, Python2FutureTransformer)
    assert isinstance(instance, BaseNodeTransformer)


# Generated at 2022-06-23 22:52:35.627495
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..conversion import convert
    from .snippets import METHODS_OF_CLASSES
    import astor

    result = convert(textwrap.dedent(METHODS_OF_CLASSES), '2to3')
    tree: ast.AST = result.tree  # type: ignore
    tree = Python2FutureTransformer().visit(tree)  # type: ignore
    print(astor.to_source(tree).strip())
    print(ast.dump(tree))


# Generated at 2022-06-23 22:52:36.846973
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer().target == (2, 7)



# Generated at 2022-06-23 22:52:44.441238
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import transform
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor

    class SampleVisitor(BaseNodeVisitor):
        def visit_Num(self, node):
            return ast.Num(n=node.n*10)

    node = ast.parse('a = 1')
    visitor = SampleVisitor().visit
    node = transform(node, [Python2FutureTransformer, visitor])
    assert node is not None
    assert node.body[0].value.n == 10
    assert node.body[0].targets[0].id == 'a'
    assert node.body[1].value.s == 'absolute_import'
    assert node.body[2].value.s == 'division'

# Generated at 2022-06-23 22:52:47.598170
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Test whether the class was created correctly"""
    p = Python2FutureTransformer()
    
    assert p.target == (2, 7)
    assert p._tree_changed == False
    assert p._file_changed == False

# Generated at 2022-06-23 22:52:52.864822
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils import parse_and_unparse

    node = ast.parse('a = 1')
    result = parse_and_unparse(node)
    expected = '''\
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
a = 1'''

    assert result == expected

# Generated at 2022-06-23 22:52:54.377472
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    fut = Python2FutureTransformer()
    assert isinstance(fut, Python2FutureTransformer)

# Generated at 2022-06-23 22:52:55.129681
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-23 22:53:05.541951
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3
    from darglint.main import main
    import specify  # type: ignore

    # Test to make sure we remove comments after our first insert
    # it requires that we remove the comments during parsing

    code = specify.code(
    """
    # The code here is a comment
    # before the import section
    import sys
    import os

    # And this is a comment after the imports
    def main():
        sys.stdout.write(os.getcwd())

    if __name__ == '__main__':
        main()
    """
    )

    # Test to make sure we remove comments after our first insert
    # it requires that we remove the comments during parsing
    tree = main(['-p', 'Python2FutureTransformer', '--no-comments', '--debug'], code)


# Generated at 2022-06-23 22:53:06.493994
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()


# Generated at 2022-06-23 22:53:13.618339
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    raw_src = """\
    import math
    import sys
    import requests
    import pytest

    def func(arg):
        return math.sqrt(arg)
    """
    expected = """\
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    import math
    import sys
    import requests
    import pytest

    def func(arg):
        return math.sqrt(arg)
    """
    node = ast.parse(raw_src)
    xformer = Python2FutureTransformer(target=(2, 7))
    node = xformer.visit(node)
    assert expected == astor.to_source(node)

# Generated at 2022-06-23 22:53:24.383280
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import typing
    import astunparse

    class NodeVisitor(ast.NodeVisitor):
        def generic_visit(self, node):
            print('generic_visit', type(node))
            ast.NodeVisitor.generic_visit(self, node)

        def visit_Module(self, node: ast.Module):
            print('visit_Module', type(node))
            assert isinstance(node, ast.Module)
            self.generic_visit(node)

    source = """
if __name__ == '__main__':
    import os
"""
    tree = ast.parse(source)
    visitor = NodeVisitor()
    visitor.visit(tree)
    source = astunparse.unparse(tree)
    print(source)

# Generated at 2022-06-23 22:53:34.374276
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Unit test for constructor of class Python2FutureTransformer"""

    node = ast.parse('HERE = 1\nTHERE = 2')
    transformer = Python2FutureTransformer()
    transformed_tree = transformer.visit(node)
    assert transformer._tree_changed is True


# Generated at 2022-06-23 22:53:36.321973
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    print("Unit test for constructor of class Python2FutureTransformer")
    assert Python2FutureTransformer  # to silence pyflakes



# Generated at 2022-06-23 22:53:42.551151
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import typed_ast.ast3 as ast

    tree = ast.parse("print('hello')")
    # print(ast.dump(tree))

    Python2FutureTransformer().visit(tree)
    assert str(tree) == "from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\nprint('hello')"

# Generated at 2022-06-23 22:53:44.885585
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()
    assert t.target == (2, 7)
    assert t.generic_visit(None) is None


# Generated at 2022-06-23 22:53:51.153835
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Arrange
    tree = ast.parse('2')
    transformer = Python2FutureTransformer()

    # Act
    tree = transformer.visit(tree)

    # Assert
    assert isinstance(tree, ast.Module)
    assert isinstance(tree.body[0], ast.ImportFrom)
    assert isinstance(tree.body[1], ast.ImportFrom)
    assert isinstance(tree.body[2], ast.ImportFrom)
    assert isinstance(tree.body[3], ast.ImportFrom)
    assert isinstance(tree.body[4], ast.Expr)

# Generated at 2022-06-23 22:53:56.218165
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.name == "Python2FutureTransformer"
    assert transformer.target == (2, 7)
    assert transformer.description == \
        "Prepends module with: from __future__ import absolute_import, from __future__ import division, from __future__ import print_function, from __future__ import unicode_literals"
    assert transformer._tree_changed is False

# Generated at 2022-06-23 22:53:57.624056
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert isinstance(Python2FutureTransformer(), BaseNodeTransformer)

# Generated at 2022-06-23 22:54:02.549189
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse(textwrap.dedent("""
        import math

        def main():
            return math.sqrt(3)
    """))
    source = source_from_ast(node)

    transformer = Python2FutureTransformer()
    new_node = transformer.visit(node)
    new_source = source_from_ast(new_node)

    assert new_source == textwrap.dedent("""
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        import math

        def main():
            return math.sqrt(3)
    """)

# Generated at 2022-06-23 22:54:11.868123
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    tree= ast.parse("""\
import sys
import os
import datetime
""")

# Generated at 2022-06-23 22:54:19.113918
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ast_tools.transforms import Python2FutureTransformer
    from ast_tools.tests.utils.base import get_ast, compare_asts
    ast_before = get_ast("a = 1")
    ast_after = get_ast("from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\na = 1")
    compare_asts(Python2FutureTransformer().visit(ast_before), ast_after)

# Generated at 2022-06-23 22:54:21.710423
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source_to_nodes
    from ..utils.graph import tree_to_str
    from ..utils.visitor import compare_trees
    import ast


# Generated at 2022-06-23 22:54:22.704346
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    trans = Python2FutureTransformer()

# Generated at 2022-06-23 22:54:30.023707
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Given
    code = '''print "foo"'''
    expected_code = '''from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
print "foo"'''
    tree = ast.parse(code)
    transformer = Python2FutureTransformer()

    # When
    result = transformer.visit(tree)

    # Then
    assert str(result) == expected_code

# Generated at 2022-06-23 22:54:31.339375
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    
    # Test input
    local_dict = locals().copy()
    local_dict.update(globals())

# Generated at 2022-06-23 22:54:33.284624
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)
    
test_Python2FutureTransformer()

# Generated at 2022-06-23 22:54:41.323991
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast

    module = ast.parse('import os\nprint(1)')
    module = Python2FutureTransformer().visit(module)

    # check that the future imports are prepended to the module

# Generated at 2022-06-23 22:54:45.740407
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Arrange
    tree = ast.parse("class Foo: pass")
    transformer = Python2FutureTransformer()
    future_imports = ast.parse(imports.get_body(future='__future__')).body
    # Act
    transformer.visit(tree)
    # Assert
    assert transformer._tree_changed
    assert tree.body == future_imports + tree.body

# Generated at 2022-06-23 22:54:47.526506
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    class_ = Python2FutureTransformer()
    assert class_.target == (2, 7)

test_Python2FutureTransformer()

# Generated at 2022-06-23 22:54:59.272707
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # test standard case
    input = """
a = 1
b = 2
c = 3
""".strip()
    expected = """
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
        
a = 1
b = 2
c = 3
""".strip()
    module = ast.parse(textwrap.dedent(input))
    Python2FutureTransformer.run(module)
    actual = ast.dump(module)
    assert expected == actual

    # test case with docstring
    input = """\"\"\"doc string\"\"\"
a = 1
b = 2
c = 3
""".strip()

# Generated at 2022-06-23 22:55:01.029251
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    x = Python2FutureTransformer()
    assert x._tree_changed == False
    assert x.target == (2, 7)

# Generated at 2022-06-23 22:55:11.216287
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ast_analyzer.src.analyzer.source_code_analyzer import SourceCodeAnalyzer
    file_path = os.path.join(test_data_folder, "test_ast_2_7_0.py")
    with open(file_path, "r") as file:
        sample_code = file.read()
    # Analyze the code to obtain AST
    analyzer = SourceCodeAnalyzer(sample_code, python_version=(2, 7))
    analyzer.parse()
    # Create a Python2FutureTransformer object
    transformer = Python2FutureTransformer()
    # Transform the AST
    transformer.visit(analyzer.module)
    # Check changes
    assert transformer._tree_changed is True


# Generated at 2022-06-23 22:55:21.357214
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import parse
    from types import ModuleType

    from typed_astunparse import astunparse

    statement = "import re"
    tree = parse(statement)
    transformer = Python2FutureTransformer()
    new_tree = transformer.visit(tree)
    nodes_to_compare = tree.body + imports.get_body(future='__future__')
    assert len(nodes_to_compare) == len(new_tree.body)
    for old_node, new_node in zip(nodes_to_compare, new_tree.body):
        if isinstance(new_node, ModuleType):
            assert new_node.kind == 'absolute'
        else:
            assert isinstance(new_node, ast.ImportFrom)

# Generated at 2022-06-23 22:55:22.221197
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer is not None

# Generated at 2022-06-23 22:55:23.483749
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert inspect.isclass(Python2FutureTransformer)


# Generated at 2022-06-23 22:55:28.055198
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse('os.system(cmd)')
    visitor = Python2FutureTransformer()
    actual_code = astor.to_source(visitor.visit(node)).strip()
    expected_code = """
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

os.system(cmd)"""
    assert actual_code == expected_code.lstrip()

# Generated at 2022-06-23 22:55:31.217699
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module = ast.parse("")
    transformer = Python2FutureTransformer()
    new_module = transformer.visit(module.body, module.body)
    assert imports.get_body(future='__future__') == new_module

# Generated at 2022-06-23 22:55:33.950031
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor
    code = """def fn():
    from datetime import date, datetime, time
    from __future__ import print_function
    from __future__ import unicode_literals
    from __future__ import division
    from __future__ import absolute_import
    return True
"""
    tree = ast.parse(code)
    Python2FutureTransformer().visit(tree) # type: ignore
    print(astor.to_source(tree))

# Generated at 2022-06-23 22:55:34.498956
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    pass

# Generated at 2022-06-23 22:55:35.843127
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-23 22:55:36.742541
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-23 22:55:38.001633
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()
    assert(t)

# Generated at 2022-06-23 22:55:43.330221
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast

    source = "def foo():    pass\n"

    tree = ast.parse(source, '<test>', 'exec')
    expected = "from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n\ndef foo():    pass\n"
    expected_tree = ast.parse(expected, '<test>', 'exec')
    Python2FutureTransformer().visit(tree)
    assert ast.dump(tree) == ast.dump(expected_tree)


# Generated at 2022-06-23 22:55:44.533032
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'

# Generated at 2022-06-23 22:55:47.507324
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    
    # Node transformers should inherit from BaseNodeTransformer
    assert issubclass(Python2FutureTransformer, BaseNodeTransformer)
    # __init__ should set the expected target_versions attribute
    assert Python2FutureTransformer().target_versions == {(2, 7)}


# Generated at 2022-06-23 22:55:54.504382
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..transformer import Transformer
    from ..utils.sample import sample_python2_script
    tree = ast.parse(sample_python2_script)
    transformer = Transformer(tree=tree)
    transformer.apply(Python2FutureTransformer)
    assert transformer.tree_changed

# Generated at 2022-06-23 22:55:57.610281
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    tree = ast.parse('')
    Python2FutureTransformer(tree).visit(tree)
    expected = imports.get_body(future='__future__')
    assert expected == tree.body


# Generated at 2022-06-23 22:56:01.301920
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    before = ast.parse("""def foo():\n    pass""")

# Generated at 2022-06-23 22:56:02.213394
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer().target == (2, 7)
    

# Generated at 2022-06-23 22:56:10.430720
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-23 22:56:20.001789
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..mock.python import PythonModule
    from ..mock.python.methods import methods_of_class
    from ..mock.python.types import types_of_class
    
    node = PythonModule(decorators=[])
    node.body = methods_of_class() + types_of_class()
    
    transformer = Python2FutureTransformer()
    node = transformer.visit(node)
    assert transformer._tree_changed == True
    assert node.body[0] == imports.get_body(future='__future__')
    assert node.body[1] == types_of_class()[0]
    assert node.body[2] == types_of_class()[1]
    assert node.body[3] == types_of_class()[2]
    assert node.body[4] == methods

# Generated at 2022-06-23 22:56:22.014710
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils import do_max_transform_test
    do_max_transform_test(Python2FutureTransformer, 2, 7)

# Generated at 2022-06-23 22:56:24.625439
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer is not None

# Generated at 2022-06-23 22:56:29.052395
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from autofuturize.fixes import Python2FutureTransformer
    from typed_ast import ast3 as ast
    node = ast.parse('''
    from abc import ABC
    from abc import abstractmethod
    from __future__ import with_statement

    class Bar(ABC):

        @abstractmethod
        def fun(self):
            pass
    ''')  # type: ast.Module
    assert Python2FutureTransformer().visit(node) is not None

# Generated at 2022-06-23 22:56:33.827207
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    trans = Python2FutureTransformer()
    s = "x = 1 + 2"
    node = ast.parse(s)
    print(ast.dump(node))
    node = trans.visit(node)
    print(ast.dump(node))
    assert node.body[0].value.s == '__future__'


# Generated at 2022-06-23 22:56:36.537451
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    p2f = Python2FutureTransformer()
    p2f.visit(None)
    assert p2f._tree_changed == False
    assert p2f.target == (2, 7)


# Generated at 2022-06-23 22:56:39.315219
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    p1 = re.compile("Python2FutureTransformer")
    assert p1.search(str(Python2FutureTransformer)) is not None

# Generated at 2022-06-23 22:56:46.153302
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast.ast3 import parse
    from typed_ast.ast3 import Module
    from pprint import pprint

    code = '''
    import abc
    '''
    tree = parse(code)
    pprint(tree)

    tf = Python2FutureTransformer()
    new_tree = tf.visit(tree)  # type: ignore
    pprint(new_tree)  # type: ignore
    assert isinstance(new_tree, Module)


# Generated at 2022-06-23 22:56:46.668301
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass

# Generated at 2022-06-23 22:56:49.904902
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from typed_ast import convert
    from .sample_asts import python2_module_sample
    tree = convert(python2_module_sample, is_file=True, future_features=set())
    transformer = Python2FutureTransformer({'__future__'})
    assert transformer.visit(tree)

# Generated at 2022-06-23 22:56:59.659803
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typing import List
    import sys

    from typed_ast import ast3
    from typed_ast.ast3 import Module, Str

    from ..utils.snippet import snippet

    @snippet
    def test():
        this_is_a_python_2_file = True

    file_contents = test.get_file_contents()

    assert isinstance(test.get_ast(), Module)
    assert isinstance(test.get_body()[0], ast3.Assign)

    future_transformer = Python2FutureTransformer()
    transformed_ast = future_transformer.visit(test.get_ast())

# Generated at 2022-06-23 22:57:08.477115
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    """Test for method visit_Module of class Python2FutureTransformer."""
    module = ast.parse('a = 1')
    transformer = Python2FutureTransformer(module)
    expected = ast.Module(body=[
        ast.ImportFrom(module='__future__', names=[        # type: ignore
            ast.alias(name='absolute_import', asname=None),
            ast.alias(name='division', asname=None),
            ast.alias(name='print_function', asname=None),
            ast.alias(name='unicode_literals', asname=None)
        ], level=0),
        ast.Assign(targets=[
            ast.Name(id='a', ctx=ast.Store())
        ], value=ast.Num(n=1))
    ])
    assert transformer.visit_Module

# Generated at 2022-06-23 22:57:12.456529
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .fixture import snippet
    from ..utils import dump

    tree = ast.parse(snippet)
    transformer = Python2FutureTransformer()
    result = transformer.visit(tree)

    assert dump(result) == dump(imports.get_tree(future='__future__') + tree)  # type: ignore

# Generated at 2022-06-23 22:57:18.776177
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_node = ast.parse('import math\nprint(math.sqrt(2))')
    transpiled_module_node = Python2FutureTransformer(module_node).transpile_tree()
    assert transpiled_module_node.body[0].names[0].name == '__future__'
    assert transpiled_module_node.body[1].names[0].name == 'math'
    assert transpiled_module_node.body[2].value.func.id == 'print'

# Generated at 2022-06-23 22:57:19.410417
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass

# Generated at 2022-06-23 22:57:22.977489
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Test the constructor of class Python2FutureTransformer"""
    try:
        Python2FutureTransformer()
    except Exception:
        assert False


# Generated at 2022-06-23 22:57:29.317433
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    before = """
import sys
x = "test"
print(x)
"""
    after = """
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
import sys
x = "test"
print(x)
"""
    tree = ast.parse(before)
    Python2FutureTransformer().visit(tree)
    assert astor.to_source(tree) == after

# Generated at 2022-06-23 22:57:33.755443
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    try:
        assert issubclass(transformer, BaseNodeTransformer)
    except AssertionError:
        raise
    assert transformer._tree_changed is False
    assert transformer.target == (2, 7)



# Generated at 2022-06-23 22:57:42.877151
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Arrange
    from typed_ast.ast3 import Module
    node = Module(body=[])
    sut = Python2FutureTransformer()

    # Act
    actual = sut.visit_Module(node)
    # Assert
    assert(actual.body)
    assert(len(actual.body) == 4)
    assert(actual.body[0].module == "__future__" or actual.body[1].module == "__future__")
    assert(actual.body[0].module == "__future__" or actual.body[2].module == "__future__")
    assert(actual.body[0].module == "__future__" or actual.body[3].module == "__future__")

# Generated at 2022-06-23 22:57:52.156662
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..refactor import RefactoringTool, fixer_names  # needed for doctest
    from .transformer import Transformer2to3  # needed for doctest
            
    tool = RefactoringTool(['lib2to3.fixes.fix_imports'], {'print_function': None}, False, False, False, None)
    tool.refactor_string(
        """\
x = {1, 2, 3}
y = {'a': 1, 'b': 2}
print(y)
""", 'example.py')

    with open('example.py') as f:
        result = f.read()

# Generated at 2022-06-23 22:57:54.078285
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer

# Generated at 2022-06-23 22:57:55.798742
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)


# Generated at 2022-06-23 22:57:58.534320
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
   x = Python2FutureTransformer()
   assert x.target == (2,7)

# unit test for visit_Module method of class Python2FutureTransformer

# Generated at 2022-06-23 22:58:04.045156
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils import ast_test_utils as utils
    from ..utils import ast_test_classes as test_cls

    tree = utils.parse_code(test_cls.simple_class)
    transformer = Python2FutureTransformer()
    tree_out: ast.Module = transformer.visit(tree)

    utils.debug_tree(tree_out, 'simple_class_2.py', '3.5')



# Generated at 2022-06-23 22:58:11.477057
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():  # noqa: E501
    transformer = Python2FutureTransformer()
    module_node_tree = ast.parse('from __future__ import unicode_literals\nprint("Rémi")')
    module_node_tree = module_node_tree._replace(body=[])
    module_node_tree = transformer.visit_Module(module_node_tree)
    expected_code = 'from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\nfrom __future__ import unicode_literals\nprint("Rémi")'
    assert ast.dump(transformer.visit(module_node_tree), include_attributes=False) == (expected_code)

# Generated at 2022-06-23 22:58:20.049645
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = ast.parse(
        '\n'.join([
            'def a():',
            '    def b():',
            '        return 1',
            '    def c():',
            '        return 2',
        ])
    )
    Python2FutureTransformer().visit(module)
    assert astor.to_source(module) == imports.get_body(future='__future__') + '\n'.join([
        'def a():',
        '    def b():',
        '        return 1',
        '    def c():',
        '        return 2',
    ])

# Generated at 2022-06-23 22:58:23.205349
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    def test_future(*args, **kwargs):
        transformer = Python2FutureTransformer(*args, **kwargs)
        transformer.visit(ast.parse("print 'hello world'"))
        assert transformer._tree_changed == True

    test_future()


