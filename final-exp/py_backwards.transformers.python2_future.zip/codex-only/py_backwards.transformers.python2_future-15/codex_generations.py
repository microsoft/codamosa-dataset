

# Generated at 2022-06-23 22:48:32.187919
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.common_tests import method_test
    from ..utils.common_tests import make_VisitorTestCase
    import inspect

    argv = ['self']
    argv.append(inspect.currentframe())
    argv.append(inspect.currentframe().f_code.co_filename)
    argv.append(inspect.currentframe().f_code.co_name)
    Argv = make_VisitorTestCase('Python2FutureTransformer',
                                'visit_Module',
                                method_test,
                                argv)

# Generated at 2022-06-23 22:48:42.772326
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astunparse
    class_source = inspect.getsource(Python2FutureTransformer)
    class_ast = ast.parse(class_source)
    node = class_ast.body[0]
    class_node = Python2FutureTransformer.visit_Module(class_ast, node)
    result = astunparse.unparse(class_node)

# Generated at 2022-06-23 22:48:44.189081
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    trans = Python2FutureTransformer()
    assert trans != None


# Generated at 2022-06-23 22:48:54.393074
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = ast.parse('import os')
    transformer = Python2FutureTransformer()
    module = transformer.visit(module)
    src = astor.to_source(module)
    assert src == imports.get_src(future='__future__') + '\nimport os'


# Unit test

# Generated at 2022-06-23 22:48:59.735719
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astunparse
    import sys
    import typing

    if sys.version_info < (3, 6):
        typing.TYPE_CHECKING = True
        assert astunparse.unparse(Python2FutureTransformer(2, 7).visit(  # type: ignore
            ast.parse('pass'))) == imports + '\npass'

# Generated at 2022-06-23 22:49:03.871869
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import typed_ast.ast3 as ast
    t = Python2FutureTransformer()

    n = ast.parse('x = 1', mode='exec')
    t.visit(n)
    assert t._tree_changed

    s = ast.Module(body=imports.get_body(future='typed_ast.ast3'))
    assert s == n


# Generated at 2022-06-23 22:49:12.702928
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    from ..utils import make_locals
    node = astor.parse_file(r'..\Examples\typed_ast\non_existent_module.py')
    transformer = Python2FutureTransformer()
    new_node = transformer.visit(node)
    module_locals = make_locals(new_node)
    assert module_locals['absolute_import'] == 'typed_ast.ast3'
    assert module_locals['division'] == 'typed_ast.ast3'
    assert module_locals['print_function'] == 'typed_ast.ast3'
    assert module_locals['unicode_literals'] == 'typed_ast.ast3'

# Generated at 2022-06-23 22:49:24.518216
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    tree = ast.parse("""def f():
    return 'hello'""")
    Python2FutureTransformer(tree).visit(tree)

# Generated at 2022-06-23 22:49:25.627151
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    node = Python2FutureTransformer()
    assert isinstance(node, Python2FutureTransformer)
    assert isinstance(node, BaseNodeTransformer)

# Generated at 2022-06-23 22:49:29.872946
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    code = "def a():\n print('Hello')"
    tree = ast.parse(code)
    Python2FutureTransformer().visit(tree)
    assert dumps(tree) == "from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\ndef a():\n print('Hello')"

# Generated at 2022-06-23 22:49:40.577616
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .. import fixer_util, transforms

    # Case 1 when body of module contains zero statements
    test_case = '''
    x = 1
    '''
    result = '''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    x = 1
    '''
    fixer_test_case = fixer_util.parse_string(test_case)
    fixer_result = fixer_util.parse_string(result)
    fixer = Python2FutureTransformer(None)
    fixer.target = (2, 7)
    fixer.visit(fixer_test_case)
    assert fixer_util.unchanged(fixer_result, fixer_test_case)

   

# Generated at 2022-06-23 22:49:45.875971
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = ast.parse('''
a = 2

''')

    Python2FutureTransformer().visit(module)

    assert ast.dump(module) == ast.dump(ast.parse('''
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

a = 2

'''))

# Generated at 2022-06-23 22:49:53.270890
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils import roundtrip
    from .base import BaseNodeTransformer

    class MockTransformer(BaseNodeTransformer):
        _tree_changed = False

        target = (2, 7)

        def visit_Module(self, node):
            # type: (ast.Module) -> ast.Module
            self._tree_changed = True
            node.body = imports.get_body(future='__future__') + node.body  # type: ignore
            return node

    m = ast.parse('pass')
    MockTransformer().visit(m)

# Generated at 2022-06-23 22:50:00.019535
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = ast.parse('x= 1')
    transformer = Python2FutureTransformer()
    module = transformer.visit(module)  # type: ignore
    assert type(module.body[0]) is ast.ImportFrom
    assert type(module.body[1]) is ast.ImportFrom
    assert type(module.body[2]) is ast.ImportFrom
    assert type(module.body[3]) is ast.ImportFrom
    assert type(module.body[4]) is ast.Assign

# Generated at 2022-06-23 22:50:02.220383
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'

# Unit tests for visit_Module() function

# Generated at 2022-06-23 22:50:04.441590
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = ast.parse('a = 1')
    transformer = Python2FutureTransformer()
    module = transformer.visit(module)
    assert transformer._tree_changed is True
    assert isinstance(module, ast.Module)
    for node in module.body:
        assert isinstance(node, ast.ImportFrom)
        assert node.module == '__future__'

# Generated at 2022-06-23 22:50:10.722433
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..unit_test_utils import transform, parse
    tree = parse("""
    def bar():
        pass
    """)
    transformer = Python2FutureTransformer()
    new_tree = transformer.visit(tree)
    assert new_tree != tree
    assert transformer._tree_changed
    assert transformer._changed_nodes == []

# Generated at 2022-06-23 22:50:12.751331
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == "Python2FutureTransformer"
    assert Python2FutureTransformer.target == (2, 7)


# Generated at 2022-06-23 22:50:19.088144
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import sys
    import io

    from typed_ast import ast3 as ast
    from typed_ast.ast3 import parse
    from typed_ast.ast3 import Module

    code = "print('hello')"
    module = parse(code)
    assert isinstance(module, Module)

    sys.stdout = buffer = io.StringIO()
    node_visitor = Python2FutureTransformer()
    node_visitor.visit(module)
    output = buffer.getvalue()
    sys.stdout = sys.__stdout__
    print(output)

    expected = "from __future__ import absolute_import\n"
    expected += "from __future__ import division\n"
    expected += "from __future__ import print_function\n"
    expected += "from __future__ import unicode_literals\n"

# Generated at 2022-06-23 22:50:20.705204
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer().visit(ast.parse("print('Hello World')"))


# Generated at 2022-06-23 22:50:25.490550
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source2ast
    source = source2ast("""
    print('Hello, World!')  # This is a text
    """)
    transformer = Python2FutureTransformer()
    transformer.visit(source)
    assert source.body[0].value.s == 'Hello, World!'

# Generated at 2022-06-23 22:50:35.375581
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    node = ast.parse('print("Hello World!")')
    #print(ast.dump(node))
    #print('**' * 10)
    Python2FutureTransformer().visit(node)

# Generated at 2022-06-23 22:50:41.416743
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    target = (2, 7)
    Python2FutureTransformer_ins = Python2FutureTransformer()
    assert Python2FutureTransformer_ins.target == target
    assert Python2FutureTransformer_ins._tree_changed == False
    assert Python2FutureTransformer_ins.visit_Module(1) == None

# Generated at 2022-06-23 22:50:50.471772
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from .. import run_module_as_main
    from .plugin_testing import get_result_from_function_run

    fut_node = ast.parse(imports.get_code(future='__future__'))
    ast_node = ast.Module(
        body=[
            ast.Expr(value=ast.Num(n=0))
        ],
        type_ignores=[
            ast.Expr,
            ast.Num
        ]
    )
    expected = fut_node.body + [ast.Expr(value=ast.Num(n=0))]

# Generated at 2022-06-23 22:50:51.900739
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer is not None


# Generated at 2022-06-23 22:50:53.276481
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()
    assert "from __future__ import absolute_import" in transformer.translate()

# Generated at 2022-06-23 22:50:59.333404
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # GIVEN
    b = '''
x = 1
y = 2
    '''
    root = ast.parse(b)
    v = Python2FutureTransformer()

    # WHEN
    new_root = v.visit(root)

    # THEN
    a = '''
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
x = 1
y = 2
    '''
    assert ast.dump(root) != ast.dump(new_root)
    assert ast.dump(ast.parse(a)) == ast.dump(new_root)

# Generated at 2022-06-23 22:51:00.507941
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    node = ast.Module([])
    Python2FutureTransformer().visit(node)

# Generated at 2022-06-23 22:51:09.909505
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test import match_nodes
    from ..utils.test import TestCase
    from ..utils.test import test_transformer

    class TestTransformer(TestCase):
        transformer = Python2FutureTransformer

        def test_transformer(self):
            from typed_ast import ast3 as ast

            node = ast.parse(textwrap.dedent(
                """
                # import for later
                import os

                # sanity check
                # x = 2 / 3
                # print(x)
                """
            ))
            output_node = test_transformer(self.transformer, node)

# Generated at 2022-06-23 22:51:14.085799
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    tf = Python2FutureTransformer()
    assert [isinstance(node, ast.ImportFrom) for node in
            tf.visit(ast.Module([], type_ignores=[ast.AST])).body] == [True] * 4

# Generated at 2022-06-23 22:51:23.879461
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    code = """x = "I'm a string"
y = b'I\\'m bytes'
zy = zb'I\\'m zlib bytes'
z = f'I\\'m a formatted string'
"""
    tree = ast.parse(code)
    transformer = Python2FutureTransformer()
    new_tree = transformer.visit(tree)
    new_code = compile(new_tree, '', 'exec')
    ns = {}
    exec(new_code, ns)
    assert ns['x'] == "I'm a string"
    assert ns['y'] == b"I'm bytes"
    assert ns['zy'] == b"I'm zlib bytes"
    assert ns['z'] == "I'm a formatted string"

# Generated at 2022-06-23 22:51:32.474975
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Given
    code = """import sys"""
    expected_code = """from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

import sys"""
    expected_ast = ast.parse(expected_code)

    # When
    node = ast.parse(code)
    t = Python2FutureTransformer()
    new_node = t.visit(node)

    # Then
    assert ast.dump(new_node) == ast.dump(expected_ast)


from typing import List, Optional, Tuple
from ..utils.snippet import snippet



# Generated at 2022-06-23 22:51:35.076660
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    p2ft = Python2FutureTransformer()
    assert isinstance(p2ft, BaseNodeTransformer)
    assert p2ft.target == (2, 7)


# Generated at 2022-06-23 22:51:36.002256
# Unit test for constructor of class Python2FutureTransformer

# Generated at 2022-06-23 22:51:44.421902
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import roundtrip
    from .utils import dedent
    c = Python2FutureTransformer()
    code = dedent('''
    from __future__ import absolute_import
    from __future__ import division
    ''')
    tree0 = c.visit(roundtrip(code))
    code2 = dedent('''
    from __future__ import absolute_import
    from __future__ import division
    ''')
    tree2 = c.visit(roundtrip(code2))
    assert_equal_code(tree0, tree2)

# Generated at 2022-06-23 22:51:55.546954
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse("""
    import abc
    import io
    """)
    transformer = Python2FutureTransformer()
    transformer.visit(node)
    assert transformer.tree_changed

# Generated at 2022-06-23 22:51:57.954691
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    module = ast.parse('def hello():\n    print(\'world\')')

# Generated at 2022-06-23 22:51:59.183016
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    try:
        Python2FutureTransformer()
    except TypeError:
        assert False

# Generated at 2022-06-23 22:52:07.251491
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()
    module = ast.parse('x = 1 + 1')
    transformer.visit(module)

# Generated at 2022-06-23 22:52:13.573499
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse(textwrap.dedent('''
        foo = 1
        bar = "Hi"
        '''))
    node = Python2FutureTransformer().visit(node)
    assert textwrap.dedent('''\
        from future import absolute_import, division, print_function, unicode_literals
        
        foo = 1
        bar = "Hi"
        ''') == astor.to_source(node)

# Generated at 2022-06-23 22:52:20.926073
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from textwrap import dedent
    from typed_ast import ast3 as ast

    tree = ast.parse(
        dedent('''
        def main():
            ...
    '''))
    transformer = Python2FutureTransformer()
    transformer.visit(tree)
    assert transformer.tree_changed

    code_before = dedent('''
        def main():
            ...
    ''')
    code_after = dedent('''
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        def main():
            ...
    ''')
    assert code_after == astor.to_source(tree)

# Generated at 2022-06-23 22:52:25.973735
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_test_module, make_test_module_from_code
    from ..utils.fake_data import FakeData
    from ..ast_manipulation import ASTManipulation
    from .. import module_visitor

    astm = ASTManipulation()
    fake = FakeData()

    # Test 1

# Generated at 2022-06-23 22:52:30.679203
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    mod = ast.parse("1", mode='single')
    mod = Python2FutureTransformer().visit(mod)
    assert unparse(mod) == dedent('''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    1
    ''')

# Generated at 2022-06-23 22:52:40.003545
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    n = compile('print(1)', '<string>', 'exec', ast.PyCF_ONLY_AST)
    t = Python2FutureTransformer()
    node = t.visit(n)
    assert isinstance(node, ast.Module)
    assert len(node.body) == 5
    assert isinstance(node.body[0], ast.ImportFrom)
    assert node.body[0].module == 'future'
    assert node.body[0].names[0].name == 'absolute_import'
    assert node.body[1].names[0].name == 'division'
    assert node.body[2].names[0].name == 'print_function'
    assert node.body[3].names[0].name == 'unicode_literals'

# Generated at 2022-06-23 22:52:41.415154
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)


# Generated at 2022-06-23 22:52:47.669811
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    body = [ast.Import(names=[ast.alias(name='typing', asname=None)], lineno=1, col_offset=0)]
    tree = ast.Module(body=body, lineno=1, col_offset=0)
    node = Python2FutureTransformer().visit(tree)
    #print(ast.dump(node))
    assert node.body[0].names[0].name == 'absolute_import'
    assert node.body[1].names[0].name == 'division'
    assert node.body[2].names[0].name == 'print_function'
    assert node.body[3].names[0].name == 'unicode_literals'
    assert node.body[4].names[0].name == 'typing'

# Generated at 2022-06-23 22:52:56.184617
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .test_utils import compare_nodes
    from typed_ast import ast3 as ast

    code = """
import sys
import difflib

a = 5
b = 6
c = a/b
print(c)
    """
    expected = """
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
import sys
import difflib

a = 5
b = 6
c = a/b
print(c)
    """
    node = ast.parse(code)
    Python2FutureTransformer().visit(node)  # type: ignore
    result = compare_nodes(node, expected)
    assert result is True, result



# Generated at 2022-06-23 22:53:02.779294
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_node = ast.parse('def func(x):\n    return x\n')
    node_transformer = Python2FutureTransformer()
    new_tree = node_transformer.visit(module_node)
    expected = ast.Module(body=imports.get_body(future='__future__') + module_node.body)  # type: ignore
    assert ast.dump(new_tree) == ast.dump(expected)

# Generated at 2022-06-23 22:53:11.269835
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    from ..utils.ast_helpers import get_module_body, dump_python_source
    from ..tests.test_utils import get_fixture_path
    with open(get_fixture_path("import_module_python2.py"), 'r') as fp:
        source = fp.read()
    ast_tree = ast.parse(source)

    transformer = Python2FutureTransformer(ast_tree)

    # call visit_Module method
    module = transformer.visit_Module(ast_tree)

    # get module body
    module_body = get_module_body(module)

    # test the transformer applied
    result = astor.to_source(module_body[0])
    expected = "from __future__ import absolute_import"
    assert result == expected


# Generated at 2022-06-23 22:53:17.759611
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    class Test(Python2FutureTransformer):
        pass

    tree = ast.parse('a = 1')
    Test().visit(tree)
    res = ast.dump(tree)
    assert res == "Module(body=[ImportFrom(module='__future__', names=[alias(name='absolute_import', asname=None)], level=0), ImportFrom(module='__future__', names=[alias(name='division', asname=None)], level=0), ImportFrom(module='__future__', names=[alias(name='print_function', asname=None)], level=0), ImportFrom(module='__future__', names=[alias(name='unicode_literals', asname=None)], level=0), Assign(targets=[Name(id='a', ctx=Store())], value=Num(n=1))])"

# Generated at 2022-06-23 22:53:22.159815
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    g = ast.parse("""
    import sys, os
    def f(a, b):
        return a + b
    """)
    Python2FutureTransformer()(g)
    assert compile(g, '', 'exec')  # If it compiles, the test passed.



# Generated at 2022-06-23 22:53:28.831264
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    mod_ast = ast.parse('my_int=1')
    mod_ast_changed = Python2FutureTransformer().visit(mod_ast)
    assert isinstance(mod_ast_changed, ast.Module)
    assert len(mod_ast_changed.body) == 5
    assert isinstance(mod_ast_changed.body[0], ast.ImportFrom)
    assert mod_ast_changed.body[0].module == '__future__'
    assert mod_ast_changed.body[0].names[0].name == 'absolute_import'
    assert isinstance(mod_ast_changed.body[1], ast.ImportFrom)
    assert mod_ast_changed.body[1].module == '__future__'
    assert mod_ast_changed.body[1].names[0].name == 'division'

# Generated at 2022-06-23 22:53:30.210041
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()
    assert t is not None


# Generated at 2022-06-23 22:53:33.235944
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert set(Python2FutureTransformer()._future_imports) == \
           {'absolute_import', 'division', 'print_function', 'unicode_literals'}


# Generated at 2022-06-23 22:53:36.686652
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)
    assert transformer.name == 'Python2FutureTransformer'
    assert transformer.provides == {'literals'}
    assert transformer.depends == {}



# Generated at 2022-06-23 22:53:42.944171
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Unit test for constructor of class Python2FutureTransformer"""
    node = ast.parse('a=2')  # type: ignore
    assert Python2FutureTransformer().visit(node) == ast.parse("""
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        a=2
        """)


# Generated at 2022-06-23 22:53:43.893260
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()



# Generated at 2022-06-23 22:53:48.222153
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    tree = astor.parse_file('tests/fixtures/python2.py')
    transformer = Python2FutureTransformer()
    new_tree = transformer.visit(tree)
    assert astor.to_source(new_tree).splitlines()[0] == 'from __future__ import absolute_import'
    
    

# Generated at 2022-06-23 22:53:52.129724
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import sys
    import os
    abspath = os.path.abspath(__file__)
    dname = os.path.dirname(abspath)
    os.chdir(dname)
    sys.path.insert(0, dname)
    import test_base

if __name__ == '__main__':
    test_Python2FutureTransformer()

# Generated at 2022-06-23 22:54:01.675002
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = ast.parse("def foo(a):\n    return a")
    p = Python2FutureTransformer(module)
    module = p.visit(module)

# Generated at 2022-06-23 22:54:10.707912
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .base import BaseGenericVisitMixin
    from .transforms import Python2FutureTransformer
    from ..utils.fake_ast import FakeAST
    from .base import BaseNodeTransformer

    class Test_Python2FutureTransformer_visit_Module(BaseNodeTransformer,
                                                     BaseGenericVisitMixin):
        def __init__(self):
            BaseNodeTransformer.__init__(self, target=(2, 7))
            BaseGenericVisitMixin.__init__(self)

            self.ast = FakeAST()

            self._tree_changed = False

            self._tree = FakeAST().module
            self.parent = self.ast.parent

    Test_Python2FutureTransformer_visit_Module().test_visit_Module()

# Generated at 2022-06-23 22:54:19.309623
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast

    t = Python2FutureTransformer()
    node = ast.Module(body=[
        ast.Print(dest=None, values=[ast.Str(s='Hello')], nl=True),
        ast.Print(dest=None, values=[ast.Str(s='World')], nl=True),
    ])
    result = t.visit(node)
    assert result.body[0].args == (ast.Str(s='Hello'),)
    assert result.body[1].args == (ast.Str(s='World'),)

# Generated at 2022-06-23 22:54:23.525055
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..converter import Converter
    conv = Converter(2, 7)
    conv.visit(imports.get_ast())
    assert conv.ast == imports.get_ast([
        'from __future__ import absolute_import',
        'from __future__ import division',
        'from __future__ import print_function',
        'from __future__ import unicode_literals',
    ])

# Generated at 2022-06-23 22:54:24.533641
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():

    import astor

# Generated at 2022-06-23 22:54:35.084525
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    class X:
        tree_changed: bool

    # TODO: A better unit test, with more variants 
    x = X()
    x.tree_changed = False
    node = ast.parse('a = 1')
    transformer = Python2FutureTransformer(None, None)
    transformer.generic_visit = lambda node: node
    transformer._tree_changed = False
    transformer.visit_Module(node)
    assert transformer._tree_changed == True

# Generated at 2022-06-23 22:54:39.669331
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .test_support import check_transformer
    check_transformer(
        Python2FutureTransformer,
        """
        # comment
        import sys
        """,
        """
        # comment
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        import sys
        """)

# Generated at 2022-06-23 22:54:41.277035
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer(None).__class__.__name__ == 'Python2FutureTransformer'

# Generated at 2022-06-23 22:54:48.196879
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor
    _source = """
            #This is a comment
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
            import os
            import sys
            def f(x):
                if x < 5:
                    return x
                else:
                    return x**2
            print(f(3))
            print(f(5))
         """

# Generated at 2022-06-23 22:54:49.136886
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.target == (2,7)

# Generated at 2022-06-23 22:54:53.016752
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor

    tree = ast.parse('') # Empty module
    Python2FutureTransformer().visit(tree)
    result = astor.to_source(tree) 
    assert result == imports.get_source(future='__future__')



# Generated at 2022-06-23 22:54:54.496175
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    x = Python2FutureTransformer()
    print(x)


# Generated at 2022-06-23 22:55:04.186569
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import os
    import sys
    import astunparse
    from ..utils.fixtures import decorator_function, decorator_function_python2
    p = Python2FutureTransformer()
    with open(decorator_function, 'r', encoding='utf-8') as f:
        tree = ast.parse(f.read())
    tree = p.visit(tree)
    with open(decorator_function_python2, 'r', encoding='utf-8') as f:
        expected_python2 = ast.parse(f.read())
    assert astunparse.dump(tree) == astunparse.dump(expected_python2)

# Generated at 2022-06-23 22:55:05.618418
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # arrange
    Python2FutureTransformer()


# Generated at 2022-06-23 22:55:15.369521
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # test with empty file
    input = """
    """
    output = """
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
    """
    assert transform(input, 2, Python2FutureTransformer) == output
    
    # test with file with a single line
    input = """a =1"""
    output = """from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
a =1"""
    assert transform(input, 2, Python2FutureTransformer) == output
    
    # test with file with a multiline
    input = """
a = 1
b = 2"""

# Generated at 2022-06-23 22:55:21.162249
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from tree_format import tree_unparse
    from .. import transform
    source = """
    print(1)
    """
    expected = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    print(1)
    """
    module = transform(Python2FutureTransformer, source)
    assert tree_unparse(module) == expected

# Generated at 2022-06-23 22:55:22.941082
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert issubclass(Python2FutureTransformer, BaseNodeTransformer)
    assert Python2FutureTransformer.target == (2, 7)



# Generated at 2022-06-23 22:55:29.840641
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    from .utils import transform
    """
    This function tests if in method visit_Module, the imports from futurize
    is added on top of the program.
    Returns
    -------
    verify: bool
        True if visit_Module passes the test, False if it fails.
    """
    # Test case #1
    program = '''
    #test
    x = 1
    y = 3
    print(x+y)
    print('hola')
    '''
    expected = '''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    #test
    x = 1
    y = 3
    print(x+y)
    print('hola')
    '''
   

# Generated at 2022-06-23 22:55:31.205777
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    python2_future_transformer = Python2FutureTransformer()
    assert python2_future_transformer is not None


# Generated at 2022-06-23 22:55:36.184669
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    tree = ast.parse("""
    a = 1
    """)
    Python2FutureTransformer().visit(tree)
    assert ast.dump(tree) == ast.dump(ast.parse("""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
a = 1
    """))

# Generated at 2022-06-23 22:55:42.656268
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import assert_source


    target_source = "from __future__ import absolute_import\n"  \
        "from __future__ import division\n"  \
        "from __future__ import print_function\n"  \
        "from __future__ import unicode_literals\n"  \
        "assert True and True\n"

    target_tree = ast.parse(target_source)

    node = ast.parse("assert True and True")
    transformer = Python2FutureTransformer()
    transformer.visit(node)
    assert_source(node, target_source)

# Generated at 2022-06-23 22:55:43.828658
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-23 22:55:49.728567
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor
    code = '''
    x = 1 + 1
    '''
    expected_code = '''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    x = 1 + 1
    '''
    tree = ast.parse(code)
    Python2FutureTransformer().visit(tree)
    print(astor.to_source(tree))

    assert astor.to_source(tree) == expected_code
    assert astor.to_source(tree).strip() == expected_code.strip()

# Generated at 2022-06-23 22:55:51.659252
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer().visit(ast.parse('print(123)'))

# Generated at 2022-06-23 22:55:53.417782
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source
    from .ast3 import dump


# Generated at 2022-06-23 22:55:59.731102
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor  # type: ignore
    import textwrap  # type: ignore
    code = textwrap.dedent('''
        strs = []
        for i in range(10):
            strs.append(str(i))
        ''')

    node = ast.parse(code)
    Python2FutureTransformer().visit(node)
    new_code = astor.to_source(node)
    print(new_code)



# Generated at 2022-06-23 22:56:05.836917
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import parse
    from ..utils import roundtrip

    code = 'a = "hello world"'
    node = parse(code)
    node = Python2FutureTransformer().visit(node)
    code = roundtrip(Python2FutureTransformer(), code)
    assert code == 'from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n\na = "hello world"'

# Generated at 2022-06-23 22:56:10.142038
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .test_utils import transform, assert_equal_ignore_ws 
    code = "print('Hello World')" 
    tr = transform(code, Python2FutureTransformer)
    expected = '''from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

print('Hello World')'''
    assert_equal_ignore_ws(tr, expected)

# Generated at 2022-06-23 22:56:19.674956
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # mypy 0.720 cannot infer type of `tree`
    # this is a bug!
    tree: ast.Module = ast.fix_missing_locations(
        ast.Module([
            ast.Import(names=[ast.alias(name='fut', asname=None)]),
            ast.ImportFrom(module='fut', names=[
                ast.alias(name='abs', asname=None),
                ast.alias(name='div', asname=None),
                ast.alias(name='pr', asname=None),
                ast.alias(name='u', asname=None)],
            level=1),
        ])
    )
    assert Python2FutureTransformer(tree).apply().body[0].names == [
        ast.alias(name='fut', asname=None)]


# Generated at 2022-06-23 22:56:22.016456
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from . import get_node_transformer_test_cases
    for case in get_node_transformer_test_cases(Python2FutureTransformer):
        yield case

# Generated at 2022-06-23 22:56:24.256308
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    x = Python2FutureTransformer()


# Generated at 2022-06-23 22:56:30.693686
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = ast.parse("True")
    transformer = Python2FutureTransformer()
    new_module = transformer.visit(module)
    assert ast.dump(module) != ast.dump(new_module)
    assert ast.dump(new_module) == "from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\nTrue\n"

# Generated at 2022-06-23 22:56:36.985065
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import ast
    x = ast.parse('x = "1"')
    transformer = Python2FutureTransformer()
    result = transformer.visit(x)
    assert isinstance(result, ast.Module)
    assert isinstance(result.body[0], ast.ImportFrom)
    assert result.body[0].module == '__future__'
    assert isinstance(result.body[1], ast.Assign)
    assert isinstance(result.body[1].value, ast.Str)


# Generated at 2022-06-23 22:56:46.291513
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert hasattr(Python2FutureTransformer, "target")
    body = imports.get_body(future='__future__')  # type: ignore
    for x in body:
        #print("type(x) = %s" % (type(x)))
        assert type(x) == ast.ImportFrom # or type(x) == ast.Import
    # The following lines of code are unreachable.
    #assert type(body[0]) == ast.ImportFrom
    #assert type(body[1]) == ast.ImportFrom
    #assert type(body[2]) == ast.ImportFrom
    #assert type(body[3]) == ast.ImportFrom

# Generated at 2022-06-23 22:56:47.897242
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    node = ast.parse('import aa')
    transformer = Python2FutureTransformer()
    transformer.visit(node)
    assert isinstance(transformer, Python2FutureTransformer)

# Generated at 2022-06-23 22:56:56.261089
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils import parse_to_ast_node
    from .base import BaseNodeTest

    class Test(BaseNodeTest):
        target = Python2FutureTransformer.target
        transformer = Python2FutureTransformer
        method = 'visit_Module'
        node = parse_to_ast_node("from __future__ import absolute_import")
        expected_action = 'Removed'
        expected_position = (1, 0)
        expected_message = f"Remove __future__ import on line 1:0"
        expected_node = ast.Module(body=[])

    Test.test_visit_method()
    Test.test_string_representation()



# Generated at 2022-06-23 22:57:01.227324
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import sys
    import unittest
    from typed_ast import ast3

    class TestPython2FutureTransformer(unittest.TestCase):
    
        def test_smoke(self):
            transformer = Python2FutureTransformer(sys.version_info,
                                                   ast3.parse('x=1\n'))
            transformer.visit(transformer.tree)
            self.assertEqual(transformer.tree.body[0].lineno, 1)
            self.assertEqual(transformer.tree.body[0].col_offset, 0)

    unittest.main()

# Generated at 2022-06-23 22:57:03.999065
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    tree = ast.parse('a = 3')
    xformer = Python2FutureTransformer()
    xformer.visit(tree)
    assert xformer.tree_changed == True


# Generated at 2022-06-23 22:57:05.234923
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

if __name__ == '__main__':
    Python2FutureTransformer()

# Generated at 2022-06-23 22:57:05.894136
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-23 22:57:16.657476
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    """Unit test for method visit_Module of class Python2FutureTransformer.
    """
    # pylint: disable=unused-variable

    from typed_ast import ast3 as ast

    from typed_astunparse import unparse
    from .utils import get_child_nodes

    # Create two instances of AST nodes by parsing code snippets
    snippet_import = 'import collections'
    tree_import = ast.parse(snippet_import)
    snippet_body = """
        def f(x):
            return x + 10
    """
    tree_body = ast.parse(snippet_body)

    # Create an instance of class Python2FutureTransformer
    transformer = Python2FutureTransformer()

    # Create an AST node of type module and populate it with the parsed code
    module_node = ast.Module(body=[])


# Generated at 2022-06-23 22:57:28.751637
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse(dedent('''
    import os
    import sys
    '''))
    transformer = Python2FutureTransformer()
    new_node = transformer.visit(node)  # type: ignore
    assert transformer._tree_changed is True
    assert ast.dump(node) == dedent('''
    Module(body=[
        Import(names=[alias(name='os', asname=None)]),
        Import(names=[alias(name='sys', asname=None)])])
    ''')

# Generated at 2022-06-23 22:57:34.748069
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    class_name = "Python2FutureTransformer"
    init_signature = inspect.signature(Python2FutureTransformer.__init__)
    assert init_signature.parameters['self'].default == inspect.Parameter.empty
    assert init_signature.parameters['future'].default == inspect.Parameter.empty
    assert Python2FutureTransformer.target == (2, 7)


# Generated at 2022-06-23 22:57:41.836257
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import convert
    from examples.python2 import func
    # Tested by comparing source code of output with example source code 
    # that fulfills the same specification.
    transformer = Python2FutureTransformer()
    module = convert(func.__doc__)
    module = transformer.visit(module)
    source = astor.to_source(module).splitlines()[4:]
    for line1, line2 in zip(source, func.__doc__.splitlines()[4:]):
        assert line1 == line2

# Generated at 2022-06-23 22:57:46.102199
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils import compare_ast

    # Given
    before = ast.parse("print 'Hello, world!'")

    # When
    after = Python2FutureTransformer().visit(before)  # type: ignore

    # Then
    assert compare_ast(after, ast.parse(
        """
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

print 'Hello, world!'
"""
    ))

# Generated at 2022-06-23 22:57:52.155599
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor

    code = """import ast

    class Sample():
        pass
    """
    tree = ast.parse(code)
    tree = Python2FutureTransformer().visit(tree)

# Generated at 2022-06-23 22:57:59.359005
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    @snippet
    def example():
        pass

    tranformer = Python2FutureTransformer()
    tranformer.visit(example.get_ast())
    expected = """\
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
pass"""
    actual = astor.to_source(example.get_ast(), indent_with=' ' * 4).strip()
    assert expected == actual

# Generated at 2022-06-23 22:58:00.416428
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor


# Generated at 2022-06-23 22:58:06.224305
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils import transforms_to
    
    source = """
    print('hello')
    """
    expected = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    print('hello')
    """
    tree = ast.parse(source)

    result = Python2FutureTransformer().visit(tree)
    
    assert transforms_to(result, expected)

# Generated at 2022-06-23 22:58:11.057451
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    assert_equal(Python2FutureTransformer().visit(ast.parse("")), 
        ast.Module(body=[
            ast.ImportFrom(module='__future__', names=[
                ast.alias(name='absolute_import', asname=None),
                ast.alias(name='division', asname=None),
                ast.alias(name='print_function', asname=None),
                ast.alias(name='unicode_literals', asname=None)
            ], level=0)
        ]))

# Generated at 2022-06-23 22:58:21.681056
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    tree = ast.parse(textwrap.dedent('''\
        print(1)
        '''))
    t = Python2FutureTransformer()
    t.visit(tree)
    # print(ast.dump(tree, annotate_fields=False, include_attributes=False))

# Generated at 2022-06-23 22:58:27.952106
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import sys
    import os

    # Make temporarily our target python interpreter as this python interpreter
    _python_interpreter = sys.executable
    _target_python_interpreter = sys.executable
    sys.executable = _target_python_interpreter
    
    # Make temporarily our target python path as this python path
    _path = os.environ['PATH']
    _python_path = os.path.dirname(_python_interpreter)
    os.environ['PATH'] = os.pathsep.join(_path.split(os.pathsep)+[_python_path])
    
    # Make temporarily our target python home as this python home
    _python_home = os.environ['PYTHONHOME']