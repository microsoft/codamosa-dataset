

# Generated at 2022-06-23 22:48:21.628637
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    instance = Python2FutureTransformer()
    assert isinstance(instance, BaseNodeTransformer)
    assert hasattr(instance, "visit_Module")
    assert hasattr(instance, "_tree_changed")
    assert isinstance(instance.target, tuple)



# Generated at 2022-06-23 22:48:31.218205
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import os
    import sys
    import ast
    import io 
    from contextlib import redirect_stdout
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
    from py2to3.fixes import Python2FutureTransformer
    
    # Arrange
    filepath = os.path.relpath('../../test_files/test_file_6.py')
    with open(filepath, encoding='utf-8') as f:
        tree = ast.parse(f.read())
    
    # Act
    refactored_tree = Python2FutureTransformer().visit(tree)
    output = io.StringIO()
    with redirect_stdout(output):
        ast.fix_missing_

# Generated at 2022-06-23 22:48:32.124410
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-23 22:48:41.681770
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.example import ExamplePythonFile, example_python_file
    example_python_file2 = ExamplePythonFile('def foo(x, y):\n    return x + y',
                                             filename='example_python_file.py',
                                             target=(2, 7))
    result2 = Python2FutureTransformer().transform(example_python_file2)
    expected2 = ExamplePythonFile(
        "from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\ndef foo(x, y):\n    return x + y",
        filename='example_python_file.py',
        target=(2, 7))
    assert result2 == expected2

# Generated at 2022-06-23 22:48:46.592637
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .python2future import Python2FutureTransformer
    node = ast.parse('print(1)')
    transf = Python2FutureTransformer()
    assert transf.visit(node) == ast.parse(imports() + 'print(1)')


# Generated at 2022-06-23 22:48:49.381877
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transpiler = Transpiler()
    transpiler.register_transformer(Python2FutureTransformer)


# Generated at 2022-06-23 22:48:52.236642
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ...utils.source import source
    from ...utils.source import assert_equal

    source = Python2FutureTransformer(source).visit()
    assert_equal(source, 'imports\n')



# Generated at 2022-06-23 22:48:53.803129
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    tree = ast.parse('')
    Python2FutureTransformer().visit(tree)
    assert tree

# Generated at 2022-06-23 22:48:58.397834
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ast import parse
    tree = parse('import sys')
    assert Python2FutureTransformer(tree).visit(tree) == parse(
        'from __future__ import absolute_import\n'
        'from __future__ import division\n'
        'from __future__ import print_function\n'
        'from __future__ import unicode_literals\n'
        'import sys')

# Generated at 2022-06-23 22:49:00.991081
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    with patch.object(Python2FutureTransformer, 'visit_Module',
                      MagicMock(name='visit_Module')):
        Python2FutureTransformer()



# Generated at 2022-06-23 22:49:03.140858
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    class MyMod(MyMod):
        __future__ = __future__  # type: ignore
    my_mod = MyMod()
    assert(my_mod)
    my_mod.Method()



# Generated at 2022-06-23 22:49:08.836357
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # GIVEN
    class FakeFutureTransformer(Python2FutureTransformer):
        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__') + node.body  # type: ignore
            return self.generic_visit(node)  # type: ignore
    transformer = FakeFutureTransformer(0)
    assert transformer != None

# Generated at 2022-06-23 22:49:12.529900
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils import get_ast

    ast_ = get_ast('print("Hello world");print(2+2)')
    ast_.body = Python2FutureTransformer().visit(ast_.body)
    assert ast_.body[0].value.args[0].s == 'Hello world'

# Generated at 2022-06-23 22:49:19.693187
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    node = ast.parse("a = 2\nb = '3'")
    new_node = Python2FutureTransformer(node)
    assert str(new_node).strip() == "from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\na = 2\nb = '3'"

# Generated at 2022-06-23 22:49:25.280999
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..make_visitor import make_visitor
    node = ast.parse('import this')
    expected = """
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
import this
"""
    out = make_visitor(Python2FutureTransformer).visit(node)
    assert ast.dump(out) == ast.dump(ast.parse(expected))


# Generated at 2022-06-23 22:49:28.536859
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor
    # create a python module
    node = ast.parse('print("Hello, Python3!")')
    # create the transformer
    transformer = Python2FutureTransformer()
    # transform the module
    new_node = transformer.visit(node)
    # pretty print the transformed module
    print(astor.to_source(new_node))

# Generated at 2022-06-23 22:49:39.022288
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor
    nodes = [ast.parse(code) for code in [
        "import math",
        "from math import sin, cos",
        "from math import *",
        "",
        "print(math.pow(2, 4))",
    ]]

# Generated at 2022-06-23 22:49:46.944850
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..testing_utils import assert_code_equal
    from .transformers import TransformerSuite
    
    suite = TransformerSuite([Python2FutureTransformer])
    before = (
        "a + b"
    )
    after = (
        "from __future__ import absolute_import\n"
        "from __future__ import division\n"
        "from __future__ import print_function\n"
        "from __future__ import unicode_literals\n"
        "\n"
        "a + b"
    )
    assert_code_equal(before, after, suite)

# Generated at 2022-06-23 22:49:53.465909
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # Instantiation of class Python2FutureTransformer
    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals

        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__') + node.body  # type: ignore
            return self.generic_visit(node)  # type: ignore
    # test for class Python2FutureTransformer
    assert Python2FutureTransformer.target == (2, 7)

# Generated at 2022-06-23 22:49:54.090778
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert True

# Generated at 2022-06-23 22:50:03.248176
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from textwrap import dedent

    class TestTransformer(Python2FutureTransformer):
        def __init__(self):
            Python2FutureTransformer.__init__(self)
            self.counter = 0

        def visit_Assign(self, node: ast.Assign) -> ast.Assign:
            self.counter += 1
            return node

    tree = ast.parse(dedent('''\
        a = b + c
        d = e + f
        '''))
    transformer = TestTransformer()
    assert transformer.counter == 0
    tree = transformer.visit(tree)
    assert transformer.counter == 2

# Generated at 2022-06-23 22:50:06.326019
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    funcdef = ast.parse('def foo(bar):\n    pass')
    t = Python2FutureTransformer()
    t.visit(funcdef)
    assert not t._tree_changed

# Generated at 2022-06-23 22:50:11.698633
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    snippet = ast.parse('print(1)\n')
    expected = ast.parse('from __future__ import absolute_import\n'
                         'from __future__ import division\n'
                         'from __future__ import print_function\n'
                         'from __future__ import unicode_literals\n\n'
                         'print(1)\n')

    transformer = Python2FutureTransformer()
    res = transformer.visit(snippet)
    assert res == expected

# Generated at 2022-06-23 22:50:12.543527
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # Nothing to do.
    pass

# Generated at 2022-06-23 22:50:14.213341
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import typed_ast.ast3 as ast
    from ast_helpers.node_transformer import IdentityTransformer


# Generated at 2022-06-23 22:50:24.993854
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import ast
    import future
    import typed_ast.ast3 as typed_ast
    from typed_ast.ast3 import Module

    node = Module(body=[])
    transformer = Python2FutureTransformer()
    transformed_node = transformer.visit(node)

# Generated at 2022-06-23 22:50:27.954851
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Unit test for constructor of class Python2FutureTransformer"""
    python2_future_transformer = Python2FutureTransformer()
    assert python2_future_transformer is not None


# Generated at 2022-06-23 22:50:37.798167
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from .unpythonic import unpythonic_transformer

    @snippet
    def test():
        from future import unicode_literals
        from future import division
        from future import absolute_import
        from future import print_function

        a = 1
        b = 2
        print(a)

    code = test.get_ast().body
    assert type(code) == ast.Module

# Generated at 2022-06-23 22:50:42.386857
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..converter import PythonConverter
    python_converter = PythonConverter(source='def a(): pass')
    python_converter._ast_tree = ast.parse(python_converter.source, filename='test.py')
    python_converter._ast_tree = Python2FutureTransformer().visit(python_converter._ast_tree)  # type: ignore
    python_converter.run_fixers()

# Generated at 2022-06-23 22:50:48.690838
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    source = """
# coding: utf-8

from __future__ import unicode_literals
import os
import sys
    """
    target = """
# coding: utf-8

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
from __future__ import unicode_literals
import os
import sys
    """
    result = apply_transformer(Python2FutureTransformer, source)
    assert result == target

# Generated at 2022-06-23 22:50:50.003990
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer((2, 7)).visit_Module  # type: ignore

# Generated at 2022-06-23 22:50:57.600335
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import assert_converted_code

    assert_converted_code(
        Python2FutureTransformer,
        """
        import os
        import sys
        
        print('hello world')
        
        if True:
            print('block True')
        else:
            print('block False')
        """,
        """
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        
        
        import os
        import sys
        
        print('hello world')
        
        if True:
            print('block True')
        else:
            print('block False')
        """
    )


# Generated at 2022-06-23 22:51:00.592094
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Test the constructor of class Python2FutureTransformer
    """
    target = (2, 7)
    trf = Python2FutureTransformer(target)
    assert isinstance(trf, BaseNodeTransformer)

# Generated at 2022-06-23 22:51:09.384582
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.fixtures import make_test_module, get_test_ast

    # given
    source = """def sum(a, b):
    return a + b"""
    tree = get_test_ast(source, 2, 7)

    # when
    transformer = Python2FutureTransformer(tree)
    transformed_tree = transformer.visit(tree)

    # then
    assert Python2FutureTransformer in tree.visitor_cls
    assert isinstance(tree, ast.Module)
    assert len(transformed_tree.body) == 6

    module = make_test_module(transformed_tree)
    assert module.sum(1, 2) == 3
    assert module.__file__.endswith('.py')

# Generated at 2022-06-23 22:51:19.778270
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transform = Python2FutureTransformer()
    source = """#!/usr/bin/env python
# -*- coding: utf-8 -*-

#print(1 + 1)
a = 1 + 1
b = a / 2
a = f"Some string: {a}"

"""
    tree = ast.parse(source)
    transform.visit(tree)

    assert tree is not None

    result = astor.to_source(tree)

# Generated at 2022-06-23 22:51:22.041575
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from .test_base import BaseNodeTransformerTest
    class_ = Python2FutureTransformer
    BaseNodeTransformerTest(class_)

# Generated at 2022-06-23 22:51:30.396653
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .common import format_source

    # Setup
    source = 'print("Hello world")'
    tree = ast.parse(source)
    transformer = Python2FutureTransformer()

    # Exercise
    actual = transformer.visit(tree)

    # Verify
    expected = format_source(r'''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    print("Hello world")
    ''')
    assert transformer.tree_changed is True
    assert actual is not tree
    assert format_source(actual) == expected

# Generated at 2022-06-23 22:51:31.211449
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer._tree_changed is False

# Generated at 2022-06-23 22:51:36.564173
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = ast.parse('''
    class Foo(object):
        pass
    print('hello world')
    ''')
    module = Python2FutureTransformer().visit(module)
    expected = '''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    class Foo(object):
        pass
    print('hello world')
    '''
    assert astor.to_source(module) == expected

# Generated at 2022-06-23 22:51:42.258515
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    expected_output = '''from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

assert 5 == 5
'''
    test_input = '''
assert 5 == 5
'''
    test_transformer = Python2FutureTransformer(test_input)
    assert test_transformer.result == expected_output

# Generated at 2022-06-23 22:51:44.088553
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer(target=(2, 7), logger=None)
    assert t is not None

# Generated at 2022-06-23 22:51:50.786549
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    code = 'print(bool(1))'
    tree = ast.parse(code)
    Python2FutureTransformer().visit(tree)
    assert ast.dump(tree) == dedent('''
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        
        print(bool(1))
        ''')

# Generated at 2022-06-23 22:51:57.835596
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    code = '''
        def f():
            return 1
        '''
    transformer = Python2FutureTransformer()
    tree = ast.parse(code)
    transformer.visit(tree)
    assert transformer.tree_changed
    assert astor.to_source(tree) == '''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    def f():
        return 1
        '''



# Generated at 2022-06-23 22:52:04.295488
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..unparse_test import UnparseTestCase
    from ..utils.visitor import NODE_TYPES
    unparse_test_inputs = [
        '',
        '# comment',
        'print("hello world")',
        'def test(arg):\n    print(arg)',
    ]

# Generated at 2022-06-23 22:52:07.404210
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():

    # Test if the transformer is properly initialized
    try:
        transformer = Python2FutureTransformer()
        assert transformer is not None
    except:
        assert False, "Could not initialize the transformer"


# Unit test the imports function

# Generated at 2022-06-23 22:52:12.405790
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    from ..testing import assert_follows
    from .base import BaseNodeTransformerTest

    class Test(BaseNodeTransformerTest):
        def _make_one(self) -> Python2FutureTransformer:
            return Python2FutureTransformer()

    Test(Python2FutureTransformer)


# Generated at 2022-06-23 22:52:19.511778
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ...testing.utils import line_numbers
    from ...testing.data import python2_future
    transformer = Python2FutureTransformer()
    node = python2_future
    res = transformer.visit(node)
    expected = line_numbers("""
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals


    def foo():
        pass


    def bar():
        pass
    """)
    assert ast.dump(res, include_attributes=True) == ast.dump(expected, include_attributes=True)

# Generated at 2022-06-23 22:52:25.884321
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    module = ast.parse('import os')
    transformer = Python2FutureTransformer()
    result = transformer.visit(module)
    expected = ast.parse("""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

import os
""")
    assert ast.dump(result) == ast.dump(expected)

# Generated at 2022-06-23 22:52:35.025783
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    @snippet
    def module() -> ast.Module:
        print("Hello World!")
    
    expected = ast.parse(
"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

print("Hello World!")
"""
    )
    expected.body[0] = imports.get_body(future='__future__')[0]

    actual = (
        Python2FutureTransformer().visit(module.get_body())
    )
    assert ast.dump(actual) == ast.dump(expected)
    assert ast.dump(Python2FutureTransformer().visit(module.get_body())) == ast.dump(expected)

# Generated at 2022-06-23 22:52:44.557472
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    global_namespace = {}
    local_namespace = {}

    # 1. Testing for None
    assert Python2FutureTransformer(node=None, global_namespace=global_namespace, local_namespace=local_namespace).visit_Module() == None

    # 2. node is not a ast.Module
    node = [
        ast.Import(names=[ast.alias(name='*', asname=None)])
        ]
    assert Python2FutureTransformer(node=node, global_namespace=global_namespace, local_namespace=local_namespace).visit_Module() == node

    # 3. _tree_changed is false
    node = ast.Module(
        body=[
            ast.Import(names=[ast.alias(name='*', asname=None)])
            ],
        )
    Python

# Generated at 2022-06-23 22:52:49.158096
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import ast
    import inspect
    module = ast.parse(inspect.getsource(Python2FutureTransformer))
    class_def = list(module.body)[0]
    assert isinstance(class_def, ast.ClassDef)
    assert class_def.name == 'Python2FutureTransformer'

# Generated at 2022-06-23 22:52:52.969812
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    input = """
a = b
"""
    expect = """
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

a = b
"""
    tree = ast.parse(input)
    t = Python2FutureTransformer.from_tree(tree)
    assert t.tree_changed
    assert astor.to_source(t.tree) == expect

# Generated at 2022-06-23 22:52:54.239318
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)

# Generated at 2022-06-23 22:52:55.556361
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer().__class__.__name__ == 'Python2FutureTransformer'

# Generated at 2022-06-23 22:53:02.728007
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # type: () -> None
    s = """\
    import six
    """
    expected = """\
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    
    import six
    """
    transformer = Python2FutureTransformer()
    source = ast.parse(s)
    source = transformer.visit(source)
    assert expected == astor.to_source(source)

# Generated at 2022-06-23 22:53:07.698180
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse("True")
    expected = ast.parse("""
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    True
    """)

    transformer = Python2FutureTransformer()
    actual = transformer.visit(node)

    assert ast.dump(expected) == ast.dump(actual)

# Generated at 2022-06-23 22:53:10.033535
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # type: () -> None
    """Test ast_transformer.Python2FutureTransformer constructor."""

    target_version = (2,7)
    Python2FutureTransformer(target_version)


# Generated at 2022-06-23 22:53:11.612310
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()
    assert t is not None
    assert t._tree_changed is False
    

# Generated at 2022-06-23 22:53:17.201409
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_to_source import ast_to_source

    class NodeMock(ast.AST):
        pass

    node_mock = NodeMock()
    node = ast.Module([node_mock])
    transformer = Python2FutureTransformer()
    node = transformer.visit_Module(node)

    expected =\
"""from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

{}
""".format(ast_to_source(node_mock))

    assert ast_to_source(node) == expected

# Generated at 2022-06-23 22:53:22.631684
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from .test_base import BaseNodeTestCase
    class Test(BaseNodeTestCase): pass
    Test.generate_test(ast.parse('print(1)'),
                       """
                       import __future__
                       print(1)
                       """,
                       Python2FutureTransformer.target)

# Generated at 2022-06-23 22:53:28.871227
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.fixtures import ast_node_fixture
    from ..utils.source import source_fixture
    from .fixtures import python_transformer_fixture

    load_fixtures = python_transformer_fixture(Python2FutureTransformer)

    def test_default():
        class_def, transformer, tree_changed = load_fixtures('class_def')
        module = ast_node_fixture('module', body=[class_def])
        result = transformer.visit(module)
        assert tree_changed is True

# Generated at 2022-06-23 22:53:38.530652
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    snippet = 'import sys\ndef fib(n):\n  a, b = 0, 1\n  while a < n:\n    print(a, end=" ")\n    a, b = b, a+b\n  print()\nfib(10)'
    actual = Python2FutureTransformer().transform(snippet)

# Generated at 2022-06-23 22:53:39.677353
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    x = Python2FutureTransformer()

# Generated at 2022-06-23 22:53:46.839088
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import typed_ast.ast3 as ast
    from typed_ast.transforms import imports
    module: ast.Module = ast.parse('a=10')
    module = imports.Python2FutureTransformer().visit(module)
    expected = ast.parse('from __future__ import absolute_import\n'
                         'from __future__ import division\n'
                         'from __future__ import print_function\n'
                         'from __future__ import unicode_literals\n'
                         '\na=10')
    assert ast.dump(module) == ast.dump(expected)

# Generated at 2022-06-23 22:53:48.373055
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)



# Generated at 2022-06-23 22:53:49.548366
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer((2, 7))



# Generated at 2022-06-23 22:53:57.624997
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast

    transformer = Python2FutureTransformer()
    old_tree = ast.parse('x = 1')
    new_tree = transformer.visit(old_tree)
    expected = "from __future__ import absolute_import\n" \
               "from __future__ import division\n" \
               "from __future__ import print_function\n" \
               "from __future__ import unicode_literals\n" \
               "\n" \
               "x = 1\n"
    assert astor.to_source(new_tree) == expected



# Generated at 2022-06-23 22:54:02.172668
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    node = ast.parse('a = 2')
    node = Python2FutureTransformer().visit(node)
    check = '''\
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
a = 2'''
    assert astunparse.unparse(node) == check, 'Should match'

# Generated at 2022-06-23 22:54:03.370587
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-23 22:54:03.900554
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass

# Generated at 2022-06-23 22:54:12.799356
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()
    module = ast.parse("")

    expected = ast.Module(
        body=[
            ast.ImportFrom(
                module='__future__',
                names=[
                    ast.alias(
                        name='absolute_import',
                        asname=None,
                        ),
                    ast.alias(
                        name='division',
                        asname=None,
                        ),
                    ast.alias(
                        name='print_function',
                        asname=None,
                        ),
                    ast.alias(
                        name='unicode_literals',
                        asname=None,
                        ),
                    ],
                level=0,
                ),
            ],
        type_ignores=[],
        )

    result = transformer.visit(module)
    assert result == expected


"""DisabledContent
"""

# Generated at 2022-06-23 22:54:13.744568
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-23 22:54:22.186627
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..test_utils import load_example_module

    mod = load_example_module('example_1.py')
    Python2FutureTransformer().visit(mod)
    src = ast.dump(mod)
    assert src.startswith(
        "Module(body=["
        "ImportFrom(module='__future__', names=["
        "alias(name='absolute_import', "
        "asname=None),"
        "alias(name='division', asname=None),"
        "alias(name='print_function', asname=None),"
        "alias(name='unicode_literals', asname=None)]"
    )

# Generated at 2022-06-23 22:54:33.112729
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import unittest
    import io
    import sys
    import typed_ast.ast3 as ast
    from typed_ast.transforms.Python2FutureTransformer import Python2FutureTransformer

    class TestPython2FutureTransformer(unittest.TestCase):
        def test_visit_Module(self):
            transformer = Python2FutureTransformer()
            output_stream = io.StringIO()
            sys.stdout = output_stream
            module = ast.parse(code='print(1)\n', mode='eval')
            transformer.visit(module)
            self.assertEqual(output_stream.getvalue(),
                             'from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\nprint(1)\n')

# Generated at 2022-06-23 22:54:39.532140
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # given
    text = "print('Hello, world')"
    tree = ast.parse(text)
    # when
    transformer = Python2FutureTransformer()
    result = transformer.visit(tree)
    # then
    expected = ast.parse("from __future__ import absolute_import\n"
                         "from __future__ import division\n"
                         "from __future__ import print_function\n"
                         "from __future__ import unicode_literals\n"
                         "\n"
                         "print('Hello, world')")
    assert result == expected


__transformer__ = Python2FutureTransformer

# Generated at 2022-06-23 22:54:40.031251
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass

# Generated at 2022-06-23 22:54:45.532093
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    code = """
# coding=utf-8
print('Hello world')
"""
    expected = """
# coding=utf-8
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
print('Hello world')
"""
    tree = ast.parse(code)
    tree = Python2FutureTransformer().visit(tree)
    assert astunparse.unparse(tree) == expected

# Generated at 2022-06-23 22:54:51.327196
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..checker import FileChecker
    from ..utils.snippet import snippet
    from ..utils.ast_parsing import parse_ast

    @snippet
    def code(n):
        from foo import bar

    modified_code = snippet(imports) + code
    code_ast = parse_ast(code)
    modified_code_ast = parse_ast(modified_code)
    checker = FileChecker(code)
    checker.add_transformer(Python2FutureTransformer)
    checker.check()
    assert checker.modified_ast == modified_code_ast

# Generated at 2022-06-23 22:54:53.176209
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # Test for the __init__ function
    transformer = Python2FutureTransformer()
    assert transformer



# Generated at 2022-06-23 22:54:54.227739
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-23 22:55:04.769804
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor

    module = ast.parse(textwrap.dedent('''
        module = 'test'
        a = 1
        b = 2
    '''))

    transformer = Python2FutureTransformer(from_version=(3, 5))
    transformer.visit(module)
    result = astor.to_source(module)

    expected_result = textwrap.dedent('''
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        module = 'test'
        a = 1
        b = 2
    ''').strip()

    assert result.strip() == expected_result

# Generated at 2022-06-23 22:55:09.404248
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from .test_base import TestCase
    import ast
    source = TestCase._get_source(Python2FutureTransformer)
    module = ast.parse(source, "test.py")
    nt = Python2FutureTransformer()
    nt.visit(module)
    assert nt._tree_changed == True

# Generated at 2022-06-23 22:55:19.597728
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    for method in ['assertEqual', 'assertNotEqual', 'assertTrue', 'assertFalse']:
        if not hasattr(unittest.TestCase, method):
            raise RuntimeError("unittest.TestCase doesn't have {} method. Please update unit test module.".format(method))
    global module, source, result_tree, tree
    module = ast.parse("print('Hello World')")
    tree = Python2FutureTransformer().visit(module)
    source = astunparse.unparse(tree)
    result_tree = ast.parse("""from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

print('Hello World')""")

# Generated at 2022-06-23 22:55:21.607829
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    
    f = Python2FutureTransformer()

# Generated at 2022-06-23 22:55:29.055214
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    tree = ast.parse('x = 42')
    tree = Python2FutureTransformer().visit(tree)

# Generated at 2022-06-23 22:55:31.565432
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor
    print(astor.dump_tree(imports.get_ast(future='__future__')))


__transformer__ = Python2FutureTransformer

# Generated at 2022-06-23 22:55:34.205613
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse("print('hello!')")
    node = Python2FutureTransformer().visit(node)
    assert isinstance(node, ast.Module)
    assert len(node.body) == 5

# Generated at 2022-06-23 22:55:42.837738
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils import run_mutation_test, get_node_as_text

    source = """
    #!/usr/bin/env python
    # -*- coding: utf-8 -*-
    
    def greet():
        print('Hello World')

    if __name__ == '__main__':
        greet()
    """
    expected = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    #!/usr/bin/env python
    # -*- coding: utf-8 -*-

    def greet():
        print('Hello World')

    if __name__ == '__main__':
        greet()
    """


# Generated at 2022-06-23 22:55:50.161909
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils import roundtrip
    from ..test_base import BaseTest
    from ... import utils
    from ...utils import python_code
    import os
    import astor
    import inspect
    import ast
    import textwrap
    from .base import BaseNodeTransformer
    from ...utils import utils

    ################################
    # Test Class for Method visit_Module
    ################################
    

# Generated at 2022-06-23 22:56:00.996626
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse('3')
    node2 = Python2FutureTransformer().visit(node)  # type: ignore
    assert ast.dump(node2) == (
        "Module(body=[ImportFrom(module='__future__', names=[alias(name='absolute_import', asname=None)], "
        "level=0), ImportFrom(module='__future__', names=[alias(name='division', asname=None)], level=0), "
        "ImportFrom(module='__future__', names=[alias(name='print_function', asname=None)], level=0), "
        "ImportFrom(module='__future__', names=[alias(name='unicode_literals', asname=None)], level=0), "
        "Expr(value=Num(n=3))])"
    )

# Generated at 2022-06-23 22:56:02.909808
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer(None)._tree_changed == False
    assert Python2FutureTransformer(None).target == (2, 7)

# Generated at 2022-06-23 22:56:10.873403
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast.ast3 import Module
    from ..type_inference_programs.python2 import Python2TypeInferenceProgram
    from ..analysis import TypeInferenceAnalysis
    from ..graphs import ModuleDependencyGraph
    from .. import TypeInferenceEngine
    from .._type_inference_processors import ListTypeInferenceProcessor
    from ..configuration import Configuration
    from ..type_inference_programs.type_inference_programs_factory import TypeInferenceProgramsFactory
    from ..type_inference_programs.type_inference_programs_configuration import TypeInferenceProgramsConfiguration

    # Create a Python2 type inference engine

# Generated at 2022-06-23 22:56:11.882500
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-23 22:56:15.275354
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Unit test for constructor of class Python2FutureTransformer"""
    # Given: a class
    # When : instantiating the class (no arguments)
    # Then : its properties should be the default value
    subject = Python2FutureTransformer()
    assert subject.target == (2, 7)

# Generated at 2022-06-23 22:56:18.892688
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    m = ast.parse('x = "hello world"')
    tt = Python2FutureTransformer()
    y = tt.visit(m)
    exec(compile(y, filename="<ast>", mode="exec"))
    assert x == "hello world"

# Generated at 2022-06-23 22:56:24.255735
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from .base import BaseTransformerTestCase, target

    class t(Python2FutureTransformer, BaseTransformerTestCase): pass
    t.__qualname__ = "t"
    t.__name__ = "t"
    t.__module__ = __name__
    t.target = target
    t().run()

# Generated at 2022-06-23 22:56:32.314653
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()
    node = ast.parse("a = 5")
    node = transformer.visit(node)
    assert node.body[0].value.s == 'absolute_import'
    assert node.body[1].value.s == 'division'
    assert node.body[2].value.s == 'print_function'
    assert node.body[3].value.s == 'unicode_literals'
    assert node.body[4].targets[0].id == 'a'
    assert node.body[4].value.n == 5

# Generated at 2022-06-23 22:56:35.296683
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .transformer_unit_test_template import _test_transformer
    _test_transformer(Python2FutureTransformer, '''
    import math
    print('Hello world')
    ''')

# Generated at 2022-06-23 22:56:46.329803
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .common import generate_code, compile_code
    from typed_ast import ast3 as ast

    # Test transform
    node = ast.parse('print("Hello, World!")')
    node = Python2FutureTransformer().visit(node)
    assert generate_code(node) == \
        """
from __future__ import (
    absolute_import,
    division,
    print_function,
    unicode_literals
)

print("Hello, World!")
"""

    # Test compile to byte code
    node = ast.parse('print("Hello, World!")')
    node = Python2FutureTransformer().visit(node)
    compiled = compile_code(node, filename='', mode='exec')
    exec(compiled)

    # Test that extra imports does not break code

# Generated at 2022-06-23 22:56:47.402472
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert isinstance(Python2FutureTransformer(), BaseNodeTransformer)


# Generated at 2022-06-23 22:56:48.146337
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-23 22:56:51.668353
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Arrange
    import astor
    code_snippet = """def func():
        return 'test'
    """
    ast_module = ast.parse(code_snippet)
    astor.dump_tree(ast_module)

# Generated at 2022-06-23 22:57:00.870288
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    from ..utils.context import Context
    from .base import BaseNodeTransformer
    from .noop import NoOpTransformer
    from .python2 import Python2Transformer
    from ..tools.transformers.python2.generators import Python2GeneratorTransformer
    from ..tools.transformers.python2.types import Python2TypeAnnotationTransformer
    ctx = Context(
        target=(2, 7),
    )
    ctx.tree = ast.parse('print("Hello World")')
    ctx.tool.transforms = [
        Python2FutureTransformer,
        Python2GeneratorTransformer,
        Python2TypeAnnotationTransformer,
        Python2Transformer,
        NoOpTransformer,
    ]
    ctx.transform()
    assert ctx.tree.body

# Generated at 2022-06-23 22:57:09.549862
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Test when __future__ is not present.
    class Transformer(Python2FutureTransformer):
        def __init__(self, root: ast.Node, tree: ast.AST, python_version: tuple):
            self._root = root
            self._tree = tree
            self._tree_changed = False
            self._python_version = python_version

    root = ast.Module()
    root.body = [ast.Import()]
    root = Transformer(root, ast.parse('pass'), (2, 7)).visit(root)
    assert root is not None
    assert isinstance(root, ast.Module)
    assert isinstance(root.body[0], ast.ImportFrom)
    assert isinstance(root.body[0].names[0], ast.alias)
    assert root.body[0].names[0].name

# Generated at 2022-06-23 22:57:10.701925
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-23 22:57:11.604989
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-23 22:57:13.145170
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer(ast.parse(""), ast.Module())

# Generated at 2022-06-23 22:57:18.995056
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from autopep8_quotes.utils import transform, get_ast_tree
    from autopep8_quotes.snippets import func1, module1
    from autopep8_quotes.transformers.base import BaseNodeTransformer
    from typed_ast import ast3 as ast

    class TestTransformer(BaseNodeTransformer):
        target = (2, 7)

        def visit_Name(self, node: ast.Name) -> ast.Name:
            self._tree_changed = True
            return node

    snippet = module1
    node = get_ast_tree(snippet)
    node = transform(node, TestTransformer)
    assert snippet.matches(node)

    snippet = func1.substitute(future='__future__')
    node = get_ast_tree(snippet)
    node = transform

# Generated at 2022-06-23 22:57:26.190768
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    class Sub(Python2FutureTransformer):
        pass

    node = Sub().visit(Sub.parse(imports))
    expected = 'from __future__ import absolute_import\n' \
        'from __future__ import division\n' \
        'from __future__ import print_function\n' \
        'from __future__ import unicode_literals\n'
    assert Sub.dumps(node) == expected




# Generated at 2022-06-23 22:57:31.560541
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import typed_ast.ast3 as ast
    from ..utils.source import source_to_ast, set_source_from_ast
    from ..utils.snippet import snippet
    
    
    @snippet
    def in_module():
        pass
    
    in_module_tree = source_to_ast(in_module)
    transformer = Python2FutureTransformer()
    out_module_tree = transformer.visit(in_module_tree)
    out_module = set_source_from_ast(out_module_tree)
    print(out_module)
    
    @snippet
    def out_module():
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        
        pass

# Generated at 2022-06-23 22:57:36.145928
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from transform import transform_ast


# Generated at 2022-06-23 22:57:45.310355
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.syntax_tree import from_str
    from ..utils.syntax_tree import to_str
    from ..utils.syntax_tree import to_source

    tr = Python2FutureTransformer()
    tr_code = tr.transform_code
    assert tr_code('x = 1') == imports.code + '\nx = 1'
    assert tr_code('x = 1\nx = 2') == imports.code + '\nx = 1\nx = 2'

    node = from_str('x = 1\nx = 2')
    assert to_str(tr.visit(node)) == 'x = 1\nx = 2'
    assert to_source(tr.visit(node)) == imports.code + '\nx = 1\nx = 2'

# Generated at 2022-06-23 22:57:49.981037
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # Arrange
    import typed_astunparse
    # Act
    transformer = Python2FutureTransformer()
    test_node = ast.parse("print 'Hello, world!'")
    actual_output = typed_astunparse.unparse(transformer.visit(test_node))

# Generated at 2022-06-23 22:57:55.104690
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    node = ast.parse('print("hello")')
    assert Python2FutureTransformer().visit(node) == ast.parse('from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\nprint("hello")')

# Generated at 2022-06-23 22:57:57.146280
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer
    assert t.__name__ == 'Python2FutureTransformer'
    assert t.__doc__



# Generated at 2022-06-23 22:58:00.661185
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    python2_ft = Python2FutureTransformer(None, None)
    assert python2_ft.__class__.__name__ == 'Python2FutureTransformer'
    assert isinstance(python2_ft, BaseNodeTransformer)
 

# Generated at 2022-06-23 22:58:09.538953
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    def check(code1: str, code2: str) -> None:
        tree1 = ast.parse(code1)
        tree2 = ast.parse(code2)
        Python2FutureTransformer().visit(tree1)
        assert ast.dump(tree2) == ast.dump(tree1)

    check(
        "import os", """
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        
        import os
        """
    )

# Generated at 2022-06-23 22:58:10.775449
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # just run constructor, error if any
    Python2FutureTransformer()

# Generated at 2022-06-23 22:58:20.005505
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from .test_utils import display_diff_trees, roundtrip_unparse
    from ..utils.test_utils import make_test_fixture
    from future.utils import PY2

    if not PY2:
        return

    input = """x = 1"""
    output = """from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
x = 1"""
    expected_tree = roundtrip_unparse(output)
    tree = make_test_fixture(input, Python2FutureTransformer)
    assert tree == expected_tree, display_diff_trees(tree, expected_tree)