

# Generated at 2022-06-23 22:48:29.094707
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor
    
    t = Python2FutureTransformer()
    node = ast.parse('1 + 1')
    t.check(node)

    expected = '''from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals


1 + 1'''    
    
    assert astor.to_source(node) == expected

# Generated at 2022-06-23 22:48:36.823703
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source2ast
    from ..utils.visitor import compare_ast, print_ast
    from ..utils.source import source
    from .python2_str_format_transformer import Python2StrFormatTransformer
    
    source_code = source('''
        import sys, re
        import math
        import textwrap
        import datetime

        print 'sys.version_info[0]:', sys.version_info[0]
        def hello():
            x = 3
            return 'Hello, world!'
    ''')

# Generated at 2022-06-23 22:48:40.373458
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils import assert_tree

    tree = assert_tree(Python2FutureTransformer, path='q/p/x.py')
    assert tree.body[0].body[0].value.s == '__future__'

# Generated at 2022-06-23 22:48:41.327057
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()


# Generated at 2022-06-23 22:48:43.235705
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # Construct object
    obj = Python2FutureTransformer('test_module')

# Generated at 2022-06-23 22:48:45.781252
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    try:
        Python2FutureTransformer()
    except Exception as e:
        pytest.fail(f'Error when constructing class Python2FutureTransformer.')


# Generated at 2022-06-23 22:48:52.425195
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .util import source_to_AST_str
    AST_str1 = source_to_AST_str(imports)
    transformer = Python2FutureTransformer()
    new_node = transformer.visit(AST_str1)
    AST_str2 = source_to_AST_str(new_node)
    assert AST_str1 != AST_str2
    assert transformer._tree_changed == True
    assert new_node.body[0].names[0] == transformer.FUTURE

# Generated at 2022-06-23 22:48:59.651829
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor
    code = imports.get_source(future='__future__')
    expected_output = astor.to_source(ast.parse(code)).strip()
    
    transformer = Python2FutureTransformer()
    module = ast.Module()
    # Type ignored as else type checker complains
    module = transformer.visit(module)  # type: ignore
    output = astor.to_source(module).strip()
    
    assert output == expected_output, 'Unexpected output.'

# Generated at 2022-06-23 22:49:06.395056
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
        from os import path as p
        from sys import path as sys_path
        sys_path.append(p.abspath(p.join(p.dirname(__file__), '../..')))
        from dtc.transformers.python2 import Python2FutureTransformer as transformer
        import os.path
        import sys
        class TestNodeTransformer(transformer):
            def _get_source_from_file(self):
                """For unittests!"""
                f = open(os.path.join(os.path.dirname(__file__), '../../dtc/agents/algorithm.py'), 'r')
                return f.read()

            def _get_source_from_stdin(self):
                """For unittests!"""
                return sys.stdin.read()
        t = TestNodeTrans

# Generated at 2022-06-23 22:49:11.646045
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils import run_transformer

    code = '''some_var = 1
another_var = 2'''

    expected = '''from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

some_var = 1
another_var = 2'''

    assert expected == run_transformer(Python2FutureTransformer, code)

# Generated at 2022-06-23 22:49:12.958795
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    

# Generated at 2022-06-23 22:49:14.783143
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer(ast.parse(''))



# Generated at 2022-06-23 22:49:21.943474
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = ast.parse('''
        import os
        import sys
    ''')
    Python2FutureTransformer().visit(module)
    assert ast.dump(module) == ast.dump(ast.parse('''
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        import os
        import sys
    '''))

# Generated at 2022-06-23 22:49:26.821242
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    node = ast.parse('print("Hello from Python 2!")')
    node = Python2FutureTransformer().visit(node)
    assert ast.dump(node, include_attributes=False) == textwrap.dedent(
        """
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        print("Hello from Python 2!")
        """
    )

# Generated at 2022-06-23 22:49:31.684131
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source
    
    transformer = Python2FutureTransformer(source('x=1'))
    transformer.transform()
    assert transformer.tree_changed is True
    assert transformer.get_source() == '''\
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
x=1
'''

# Generated at 2022-06-23 22:49:42.363994
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from textwrap import dedent
    from ..utils.visitor import print_python_source
    from ..utils.source import source_to_ast
    from ..utils.source import ast_to_source

    # Initialization
    source = dedent('''
        print(1 + 1)
    ''')
    expected = dedent('''
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals


        print(1 + 1)
    ''')
    tree = source_to_ast(source)

    # Test 1
    print_python_source(tree)
    trans = Python2FutureTransformer()
    assert trans.visit(tree) is None

# Generated at 2022-06-23 22:49:48.789881
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from . import ast_converter
    import io

    class DummyFuture:
        @property
        def body(self):
            return [ast.Str(s='Hello World')]

    dummy_future = DummyFuture()

    class DummyPython2FutureTransformer(Python2FutureTransformer):
        @property
        def tree_changed(self):
            return True

        def generic_visit(self, node):
            return node


# Generated at 2022-06-23 22:49:56.899755
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    @snippet
    def code1():
        if True:
            pass
        if True:
            pass
    
    @snippet
    def code2():
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        if True:
            pass
        if True:
            pass

    tree = ast.parse(code1())
    transformer = Python2FutureTransformer()
    transformer.visit(tree)
    assert code2 == ast.fix_missing_locations(tree)

# Generated at 2022-06-23 22:50:02.380667
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Case: transformation should be performed
    node = ast.parse('a + b')

    transformer = Python2FutureTransformer()
    res = transformer.visit(node)

    assert transformer._tree_changed
    for n in node.body:
        assert n not in res.body

    for n in imports.get_body(future='__future__'):  # type: ignore
        assert n in res.body

# Generated at 2022-06-23 22:50:03.009648
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass

# Generated at 2022-06-23 22:50:09.087853
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():

    module_input = ast.parse('a = 1')
    expected_output = ast.parse(
        """
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

a = 1
        """
    )
    module_output = Python2FutureTransformer(target_info=(2, 7)).visit(module_input)
    assert ast.dump(module_output) == ast.dump(expected_output)

# Generated at 2022-06-23 22:50:13.283100
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # Arrange
    import astor
    from typed_ast import parse
    code = 'import math'
    # Act
    new_code = astor.to_source(Python2FutureTransformer().visit(parse(code).body[0]), indent_with='    ')
    # Assert
    assert new_code == imports.get_snippet(future='__future__') + code

# Generated at 2022-06-23 22:50:22.029303
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import transform, compare_trees
    code = "import math"
    expected_code = """
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
import math
""".lstrip()
    tree = ast.parse(code)  # type: ignore
    tr = Python2FutureTransformer()
    new_tree = tr.visit(tree)  # type: ignore
    assert compare_trees(new_tree, expected_code)
    assert transform(Python2FutureTransformer, code) == expected_code.lstrip()

# Generated at 2022-06-23 22:50:32.324644
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.transform import transform
    from ..utils.message import Messager
    from ..utils.mock_io import StringIO

    transformer = Python2FutureTransformer(Messager(StringIO()), None, None)
    transformed_module = transform(transformer, ast.parse('def foo(): pass'))
    assert len(transformed_module.body) == 5  # type: ignore
    assert transformed_module.body[0].names[0].name == 'absolute_import'  # type: ignore
    assert transformed_module.body[1].names[0].name == 'division'  # type: ignore
    assert transformed_module.body[2].names[0].name == 'print_function'  # type: ignore
    assert transformed_module.body[3].names[0].name == 'unicode_literals'  # type:

# Generated at 2022-06-23 22:50:40.392035
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3, parse
    from typed_ast.ast3 import ssa, stmt, expr, mod
    node = parse('x = 2\nx += 1', mode='eval')
    tree = Python2FutureTransformer().visit(node)
    assert type(tree) == type(node)
    assert type(tree) == ast3.Expression
    assert type(tree.body) == type(node.body)
    assert type(tree.body) == expr.BinOp
    assert type(tree.body.op) == type(node.body.op)
    assert type(tree.body.op) == expr.Add
    assert type(tree.body.left) == type(node.body.left)
    assert type(tree.body.left) == expr.Name

# Generated at 2022-06-23 22:50:43.662325
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer(None)
    assert isinstance(t, Python2FutureTransformer)
    assert isinstance(t, BaseNodeTransformer)
    assert not t._tree_changed
    assert t.target == (2, 7)


# Generated at 2022-06-23 22:50:50.446937
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    code = '''
a = 1
b = 2
c = 3
'''
    expected = '''
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

a = 1
b = 2
c = 3
'''
    module = ast.parse(code)
    node_transformer = Python2FutureTransformer()
    new_module = node_transformer.visit(module)  # type: ignore
    assert (ast.dump(new_module) == ast.dump(ast.parse(expected)))

# Generated at 2022-06-23 22:50:53.626984
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # Arrange
    tree = ast.parse('')
    transformer = Python2FutureTransformer()
    
    # Act
    transformer.visit(tree)

    # Assert
    assert isinstance(transformer, BaseNodeTransformer)
    assert tree is not None
    assert transformer._tree_changed


# Generated at 2022-06-23 22:51:00.745691
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    str_ast = ast.parse("a=5", mode="exec")
    transform = Python2FutureTransformer(str_ast)
    result = ast.dump(transform)
    expected_result = "Module(body=[ImportFrom(module='__future__', names=[alias(name='absolute_import', asname=None)], level=0), ImportFrom(module='__future__', names=[alias(name='division', asname=None)], level=0), ImportFrom(module='__future__', names=[alias(name='print_function', asname=None)], level=0), ImportFrom(module='__future__', names=[alias(name='unicode_literals', asname=None)], level=0), Assign(targets=[Name(id='a', ctx=Store())], value=Num(n=5))])"
   

# Generated at 2022-06-23 22:51:10.134520
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import typed_ast.ast3
    source = """
    #!/usr/bin/env python
    # -*- coding: utf-8 -*-
    def func1():
        x = 1
        print(x)

    def func2():
        x = 1
        print(x)

    def func3():
        x = 1
        print(x)
    """
    tree = typed_ast.ast3.parse(source)
    tree = Python2FutureTransformer().visit(tree)

# Generated at 2022-06-23 22:51:11.609458
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)

# Generated at 2022-06-23 22:51:17.565211
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    code = '''
print("Hello, World!")
'''
    tree = ast.parse(code)
    Python2FutureTransformer().visit(tree)

    expected_ast = ast.parse('''
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

print("Hello, World!")
''')

    assert ast.dump(tree) == ast.dump(expected_ast)

# Generated at 2022-06-23 22:51:24.791807
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    code = 'print("hello world")'
    tree = ast.parse(code)
    Python2FutureTransformer().visit(tree)

# Generated at 2022-06-23 22:51:27.393867
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from .transformer_util import check_module, ua_parse, ua_print

# Generated at 2022-06-23 22:51:28.901816
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer.target == (2, 7)

# Generated at 2022-06-23 22:51:31.115665
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    node = ast.parse('print("hello world")', mode="exec")
    result = Python2FutureTransformer().visit(node)
    assert result == 1

# Generated at 2022-06-23 22:51:37.912134
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source, next_line_num

    source = source(__file__)
    line_num = next_line_num(source, __name__) + 1
    source[line_num] = '    "Placeholder for unit test"\n'

    t = Python2FutureTransformer()
    tree = t.visit(ast.parse(source))

    assert t._tree_changed

    # Check what happened to the body list of nodes
    assert isinstance(tree, ast.Module)
    assert isinstance(tree.body, list)
    assert len(tree.body) == 4
    assert isinstance(tree.body[0], ast.ImportFrom)
    assert isinstance(tree.body[1], ast.ImportFrom)
    assert isinstance(tree.body[2], ast.ImportFrom)

# Generated at 2022-06-23 22:51:47.675088
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == "Python2FutureTransformer"
    expected = ('Python2FutureTransformer', 'BaseNodeTransformer', 'object', 'TransformerMixin')
    actual = Python2FutureTransformer.mro()
    assert expected == actual
    assert 'Transform Python2 code to be more compatible with python3' in Python2FutureTransformer.__doc__
    assert Python2FutureTransformer.target == (2, 7)
    t = Python2FutureTransformer()
    assert not t._tree_changed
    assert t.target == (2, 7)
    assert t.visit_Module.__name__ == 'visit_Module'
    assert t.visit_Module.__doc__ == 'Overrides "visit_Module"\n    '

# Generated at 2022-06-23 22:51:50.288703
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    ver = Python2FutureTransformer.target
    transformer = Python2FutureTransformer()
    assert transformer.target == ver, "transformer.target should be ver"

# Generated at 2022-06-23 22:51:52.332762
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert isinstance(Python2FutureTransformer(None), Python2FutureTransformer)



# Generated at 2022-06-23 22:51:52.920574
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass

# Generated at 2022-06-23 22:52:01.207866
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = ast.parse("print('hello')")
    module_transformer = Python2FutureTransformer()
    module_transformer.visit(module)
    future_stmts = [ast.parse(stmt, "<unknown>", "exec") for stmt in [
        "from __future__ import absolute_import",
        "from __future__ import division",
        "from __future__ import print_function",
        "from __future__ import unicode_literals",
    ]]
    expected_module_body = future_stmts + [ast.Expr(value=ast.Call(
                func=ast.Name(id='print', ctx=ast.Load()),
                args=[ast.Str(s='hello')],
                keywords=[])
            )]
    assert module.body == expected_module_body

# Generated at 2022-06-23 22:52:06.344491
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    actual_module = ast.parse("a = 1")
    expected_module = ast.parse("""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

a = 1""")
    visitor = Python2FutureTransformer()
    actual_module = visitor.visit(actual_module)
    assert astor.to_source(actual_module) == astor.to_source(expected_module)

# Generated at 2022-06-23 22:52:16.687625
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Given
    module = ast.parse('a = None')
    transformer = Python2FutureTransformer()

    # When
    node = transformer.visit(module)

    # Then

# Generated at 2022-06-23 22:52:17.473743
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass

# Generated at 2022-06-23 22:52:27.756306
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import sys
    import os
    import astor
    from textwrap import dedent
    from .tools import assert_equal_code
    from .ast_converters import dump

    class DummyModule(object):
        pass

    module = DummyModule()
    module.__file__ = os.path.abspath(__file__)

    sys.modules[__name__] = module

    source = dedent(r'''
    a = 1
    b = 2
    c = 3
    ''')

    tree = ast.parse(source)
    pt = Python2FutureTransformer()
    tree = pt.visit(tree)
    src = astor.to_source(tree)
    rm_loc = dump(tree)


# Generated at 2022-06-23 22:52:31.080780
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    "Unit test for constructor of class Python2FutureTransformer"
    # Arrange
    test = Python2FutureTransformer(None)
    # Act

    # Assert
    assert test.target == (2, 7)

# 

# Generated at 2022-06-23 22:52:40.274960
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source, ast_from_source
    from ..utils.visitor import dump

    source0 = """
    #!/usr/bin/env python
    # -*- coding: utf-8 -*-
    #
    # Author: Milan Falesnik <mfalesni@redhat.com>
    # Since: 2019

    x = 10
    print("Hello, world!")
    """

# Generated at 2022-06-23 22:52:46.718695
# Unit test for constructor of class Python2FutureTransformer

# Generated at 2022-06-23 22:52:48.430573
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a = Python2FutureTransformer()
    assert a is not None

# Generated at 2022-06-23 22:52:50.055559
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer is not None



# Generated at 2022-06-23 22:52:57.496981
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import json
    import unittest
    from .base import BaseNodeTransformerTest

    class Test(BaseNodeTransformerTest):
        target = (2, 7)
        transform = Python2FutureTransformer

        def test_0(self):
            # Test for empty text
            code = ''
            expect = code
            result = self.transform(code)
            self.assertAST(result, expect)

        def test_1(self):
            # Test for simple text
            code = 'print "hello, world"'
            expect = imports(self.target) + code
            result = self.transform(code)
            self.assertAST(result, expect)


# Generated at 2022-06-23 22:52:59.945451
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.testing import source

    assert source(Python2FutureTransformer()) == imports.get_source(future='__future__')

# Generated at 2022-06-23 22:53:03.389309
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert issubclass(Python2FutureTransformer, BaseNodeTransformer)
    instance = Python2FutureTransformer()
    assert isinstance(instance, BaseNodeTransformer)
    assert isinstance(instance, Python2FutureTransformer)


# Generated at 2022-06-23 22:53:05.096222
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import ast
    from darglint.python_future import Python2FutureTransformer


# Generated at 2022-06-23 22:53:13.090961
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..common_testing import SourceResult

    src, actual_result = SourceResult(
                                            #  module imports                                                           
                                            'pass',
                                            from_version=(3, 7),
                                            to_version=Python2FutureTransformer.target,
                                            transformer_class=Python2FutureTransformer,
                                         )


# Generated at 2022-06-23 22:53:15.721951
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import_node = ast.parse('import sys')
    transformer = Python2FutureTransformer()
    module: ast.Module = transformer.visit(import_node)
    assert isinstance(module, ast.Module)
    assert transformer._tree_changed == True

# Generated at 2022-06-23 22:53:23.196035
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    tree = ast.parse("""
        print("test")
    """)
    result = Python2FutureTransformer().visit(tree)
    expected = """
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        
        print("test")
    """
    assert ast.dump(result) == ast.dump(ast.parse(expected))

# Generated at 2022-06-23 22:53:29.742959
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Arrange
    module = ast.parse("""
    print('')
    """)
    python2futuretransformer = Python2FutureTransformer()

    # Act
    result = python2futuretransformer.visit(module)

    # Assert
    assert result.body[0].names[0].name == "absolute_import"
    assert result.body[1].names[0].name == "division"
    assert result.body[2].names[0].name == "print_function"
    assert result.body[3].names[0].name == "unicode_literals"

# Generated at 2022-06-23 22:53:34.714793
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module = ast.parse("def foo(a, b):\n  return a + b")
    transformer = Python2FutureTransformer(module)
    module = transformer.visit(module)
    assert transformer._tree_changed is True
    assert isinstance(module, ast.Module)
    assert isinstance(module.body[0], ast.ImportFrom)


# Generated at 2022-06-23 22:53:37.540349
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()
    assert isinstance(t, BaseNodeTransformer)
    assert t.target == (2, 7)
    assert t.target_versions == {(2, 7)}


# Generated at 2022-06-23 22:53:38.060946
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass

# Generated at 2022-06-23 22:53:40.273050
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module = ast.parse('import os')
    assert isinstance(Python2FutureTransformer().visit(module), ast.Module)

# Generated at 2022-06-23 22:53:41.649545
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer()



# Generated at 2022-06-23 22:53:43.374595
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .test_utils import _get_ast
    from .test_utils import compare_ast


# Generated at 2022-06-23 22:53:49.993257
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3
    module = ast3.parse('x = 1')
    transformer = Python2FutureTransformer()
    node = transformer.visit(module)
    assert isinstance(node, ast3.Module)
    assert len(module.body) == 1
    assert len(node.body) == 5
    assert isinstance(node.body[0], ast3.ImportFrom)
    assert node.body[0].module == "__future__"
    assert len(node.body[0].names) == 1
    assert node.body[0].names[0].name == "absolute_import"

# Generated at 2022-06-23 22:53:51.829867
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer({})


# Generated at 2022-06-23 22:53:52.711195
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-23 22:53:58.242109
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    code = '''
        # comment
        print(1)
    '''
    module = ast.parse(code)
    assert module.body[0].lineno == 1
    assert module.body[0].col_offset == 0

    module = Python2FutureTransformer().transform(module)
    assert isinstance(module, ast.Module)
    assert module.body[0].lineno == 1
    assert module.body[0].col_offset == 0

# Generated at 2022-06-23 22:53:59.208741
# Unit test for constructor of class Python2FutureTransformer

# Generated at 2022-06-23 22:54:04.132301
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse("")
    transformer = Python2FutureTransformer()
    transformer.visit(node)

    expected = ast.parse(
        "from __future__ import absolute_import\n"
        "from __future__ import division\n"
        "from __future__ import print_function\n"
        "from __future__ import unicode_literals\n"
    )
    assert ast.dump(node) == ast.dump(expected)

# Generated at 2022-06-23 22:54:08.270335
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    tree = ast.parse("", "<string>", "exec")
    trans = Python2FutureTransformer()
    tree_changed, new_tree = trans.transform(tree)

    expected_output = """from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
"""
    assert astor.to_source(new_tree) == expected_output
    assert tree_changed == True

# Generated at 2022-06-23 22:54:08.891126
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-23 22:54:11.184590
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.syntax_tree import syntax_tree
    transformed = syntax_tree('') | Python2FutureTransformer()
    assert transformed.body[:4] == imports.get_body(future='__future__')
    assert transformed.body[4:] == syntax_tree('').body

# Generated at 2022-06-23 22:54:13.086208
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Test for constructor of class Python2FutureTransformer.
    """
    transformer = Python2FutureTransformer()
    assert transformer

# Generated at 2022-06-23 22:54:21.325155
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    code = '''
    time = time.time()
    other_var = 'some value'
    '''

    target_code = '''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    time = time.time()
    other_var = 'some value'
    '''
    tree = ast.parse(code)
    Python2FutureTransformer().visit(tree)
    assert astor.to_source(tree).strip() == target_code.strip()

# Generated at 2022-06-23 22:54:24.707407
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer(tree=None, filename='<test>')
    assert transformer.target == (2, 7)
    assert transformer.tree is None
    assert transformer._tree_changed is False

# Generated at 2022-06-23 22:54:31.542675
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    code = '''"""Foo bar"""
    import json
    import sys
    '''
    expected = '''"""Foo bar"""
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    import json
    import sys
    '''
    result = Python2FutureTransformer().visit(ast.parse(code))
    assert astor.to_source(result) == expected

# Generated at 2022-06-23 22:54:38.207568
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils import parse, compare_ast
    from .python3 import Python3Transformer, Python3UnicodeTransformer
    test_input = """
    print("Hellow World!")
    """
    expected_output = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    
    print("Hellow World!")
    """
    node = parse(test_input)
    Python2FutureTransformer().visit(node)
    compare_ast(node, expected_output)

# Generated at 2022-06-23 22:54:44.626326
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse("""# Python3 code
print(1, 2, 3, 4)
""")
    visitor = Python2FutureTransformer()
    new_node = visitor.visit(node)
    assert new_node.body[0].value.value == 'print_function'
    assert new_node.body[1].value.value == 'absolute_import'
    assert new_node.body[2].value.value == 'division'
    assert new_node.body[3].value.value == 'unicode_literals'
    assert isinstance(new_node.body[4], ast.Expr)
    assert isinstance(new_node.body[4].value, ast.Call)
    assert isinstance(new_node.body[4].value.func, ast.Name)

# Generated at 2022-06-23 22:54:49.202122
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module = ast.parse('print(1)')
    assert module
    module = Python2FutureTransformer().visit(module)
    assert module
    assert module.body[0].names[0].name == 'absolute_import'
    assert module.body[0].names[1].name == 'division'
    assert module.body[0].names[2].name == 'print_function'
    assert module.body[0].names[3].name == 'unicode_literals'
    assert module.body[1].value.id == 'print'

# Generated at 2022-06-23 22:54:50.230668
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer()



# Generated at 2022-06-23 22:54:52.492204
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert hasattr(Python2FutureTransformer, "target")
    assert hasattr(Python2FutureTransformer, "visit_Module")

# Generated at 2022-06-23 22:55:04.296691
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import os
    import sys
    import ast
    from typed_ast import ast3
    from typed_ast.transforms import Python2FutureTransformer
    from ..utils.snippet import snippet
    from ..utils.helpers import get_transformed_ast_from_file

    @snippet
    def fixture(x, y):
        print(x / y)
        print(x // y)

    py_file = os.path.join(
        os.path.dirname(os.path.realpath(__file__)),
        'fixtures',
        'fixture_01.py'
    )
    xformed_tree: ast.AST = get_transformed_ast_from_file(py_file, Python2FutureTransformer)

    #import astor
    #fixture = astor.to_source(x

# Generated at 2022-06-23 22:55:11.291872
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..unit_test_utils import assert_equal_source
    from .unparser import Unparser

    code = """
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        print 'Hello world!'""".lstrip()

    module = Unparser().visit(imports.ast(future='__future__'))
    module.body += Unparser().visit(ast.parse(code)).body  # type: ignore

    assert_equal_source(code, module)

# Generated at 2022-06-23 22:55:13.820734
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import sys
    c = Python2FutureTransformer(sys.maxsize)


if __name__ == '__main__':
    test_Python2FutureTransformer()

# Generated at 2022-06-23 22:55:17.214936
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    tree = ast.parse('x = 1')
    tree = Python2FutureTransformer().visit(tree)
    expected = """
x = 1
"""
    assert astor.to_source(tree) == expected

# Generated at 2022-06-23 22:55:24.665149
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import pathlib
    source_file_path = pathlib.Path('tests/samples/python2_future.py')
    with source_file_path.open('r') as f:
        source_code = f.readlines()
        number_of_lines_in_source_code = len(source_code)
    assert number_of_lines_in_source_code == 1
    tree = ast.parse(source_code[0])
    from ..utils.visitor import print_ast
    print_ast(tree)
    transformer = Python2FutureTransformer()
    transformer.visit(tree)
    assert transformer._tree_changed is True
    from ..utils.visitor import print_ast
    print_ast(tree)
    assert len(imports.get_body(future='__future__')) == 4
    source

# Generated at 2022-06-23 22:55:26.017872
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor

# Generated at 2022-06-23 22:55:36.016296
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from textwrap import dedent
    from .test_base import BaseNodeTest

    class TestPython2FutureTransformer(BaseNodeTest):
        target = (2, 7)
        transformer = Python2FutureTransformer

    test = TestPython2FutureTransformer()

    test.assertEqual(dedent('''
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        def abc():
            assert True
    ''').strip(), test.visit(dedent('''
        def abc():
            assert True
    ''').strip()))


# Generated at 2022-06-23 22:55:41.856937
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    mod = ast.parse(
        """
        import numpy

        def f():
            print('Hello world')
        """
    )
    trans = Python2FutureTransformer()
    mod2 = trans.visit(mod)
    visitor = PrintVisitor()
    visitor.visit(mod2)

# Generated at 2022-06-23 22:55:43.742977
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..klass import TestVisitor
    from ..utils.tree_compare import compare_ast, check_equivalent_code


# Generated at 2022-06-23 22:55:44.615041
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-23 22:55:48.776144
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()
    assert t._tree_changed is False
    assert t.target == (2, 7)
    assert t.is_relevant(target_versions=[(2, 7)])
    assert t.is_relevant(target_versions=[(3, 6)]) is False

# Generated at 2022-06-23 22:55:53.231397
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    module = ast.parse(r""" 
print 'hello world'
    """, '<string>', 'exec')
    module = transformer.visit(module)
    assert transformer._tree_changed
    assert module == imports.get_body(future='__future__') + module.body

# Generated at 2022-06-23 22:55:55.884735
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    ast_tree = parse(imports.get_source(future='__future__'))
    assert ast_tree == Python2FutureTransformer().visit(ast_tree)

# Generated at 2022-06-23 22:56:02.356475
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    tree = ast.parse('x = "abc"')
    assert ast2str(tree) == 'x = "abc"'
    Python2FutureTransformer(tree).visit(tree)
    assert ast2str(tree) == (
        'from __future__ import absolute_import\n'
        'from __future__ import division\n'
        'from __future__ import print_function\n'
        'from __future__ import unicode_literals\n'
        'x = "abc"'
    )

# Generated at 2022-06-23 22:56:09.052851
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .python2_fixer import Python2Fixer

    code = """x = 1"""

    root = ast.parse(code)
    Python2FutureTransformer().visit(root)
    #ast.fix_missing_locations(root)
    Python2Fixer().visit(root)
    stderr = io.StringIO()
    compile(root, '', 'exec', dont_inherit=1, optimize=0, _call_with_frames_removed=False, outputaction="file", file=stderr)
    assert stderr.getvalue() == ''

# Generated at 2022-06-23 22:56:17.796256
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Module
    from ..utils.py3_ast_fixer import fix

    node = ast.parse('''
pass
''')
    node = fix(node)

    node = Python2FutureTransformer().visit(node)
    assert isinstance(node, Module)
    assert '' == node.body[0].s
    assert 'from __future__ import absolute_import' == node.body[1].s
    assert 'from __future__ import division' == node.body[2].s
    assert 'from __future__ import print_function' == node.body[3].s
    assert 'from __future__ import unicode_literals' == node.body[4].s

# Generated at 2022-06-23 22:56:28.180544
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typing import List
    from ..utils.source import source
    from typed_ast import ast3 as ast

    class NodeVisitor(ast.NodeVisitor):
        def __init__(self):
            self.import_from_future_statement: List[ast.ImportFrom] = []

        def visit_ImportFrom(self, node: ast.ImportFrom) -> None:
            self.import_from_future_statement.append(node)

    target = (2, 7)

    source_ = """
print(a)
print(b)
"""

    tree = source_to_AST(source_)

    transformer = Python2FutureTransformer(target=target)
    transformer.visit(tree)

    visitor = NodeVisitor()
    visitor.visit(tree)

    # Check that the transformed tree has a ImportFrom statement that imports

# Generated at 2022-06-23 22:56:34.841865
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    fixer = Python2FutureTransformer()
    node = ast.parse("print(0)")
    fixed = fixer.visit(node)
    assert fixer.tree_changed
    assert ast.dump(fixed) == ast.dump(ast.parse("from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n\nprint(0)"))

# Generated at 2022-06-23 22:56:35.701169
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-23 22:56:39.541200
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    with open(os.path.join(here, 'docstrings.py'), 'r') as f:
        v = Python2FutureTransformer(f.read())

    assert isinstance(v, Python2FutureTransformer)


# Generated at 2022-06-23 22:56:43.618501
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from .base import BaseNodeTransformer
    assert issubclass(Python2FutureTransformer, BaseNodeTransformer)
    assert Python2FutureTransformer.target == (2, 7)



# Generated at 2022-06-23 22:56:50.986066
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    source = """
    from datetime import datetime, timedelta
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    import os
    import sys
    import argparse
    import logging
    def f():
        pass
    """

    transformer = Python2FutureTransformer()
    tree = ast.parse(source)
    tree = transformer.visit(tree)
    assert transformer.tree_changed


# Generated at 2022-06-23 22:56:55.783870
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = ast.parse("a=1")
    expected_module = ast.parse("from __future__ import absolute_import; from __future__ import division; from __future__ import print_function; from __future__ import unicode_literals; a=1")
    transformer = Python2FutureTransformer()
    transformer.visit(module)
    assert expected_module == module # type: ignore

# Generated at 2022-06-23 22:57:00.138048
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    future = '__future__'
    transformer = Python2FutureTransformer(future)
    node = transformer.visit(ast.parse('print(1)'))
    assert ast.dump(node) == ast.dump(ast.Module(body=imports.get_body(future) + [ast.Expr(ast.Call(func=ast.Name(id='print', ctx=ast.Load()), args=[ast.Num(n=1)], keywords=[]))]))

# Generated at 2022-06-23 22:57:08.841172
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import inspect
    import astor
    from flake8_py2.checker import Python2FutureTransformer

    tree = ast.parse(inspect.getsource(Python2FutureTransformer))
    assert tree is not None

    # Test the transformer
    node = Python2FutureTransformer(tree)
    assert node.tree_changed()

    # Test the transformed tree string
    s = astor.to_source(node.get_tree())

# Generated at 2022-06-23 22:57:14.933534
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    from ast_transformer.transformer_visitor import TransformerVisitor
    tree = ast.parse('x = 1')
    transformer = TransformerVisitor(Python2FutureTransformer())
    transformer.visit(tree)
    assert astor.to_source(tree) == "from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n\nx = 1"

# Generated at 2022-06-23 22:57:16.329872
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer is not None

# Generated at 2022-06-23 22:57:17.747241
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    fr = Python2FutureTransformer()

# Generated at 2022-06-23 22:57:28.881380
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from .test_visitor import get_node_value, visit
    from .test_implicit_imports_transformer import build_node
    import os

    tree = ast.parse(
        """
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
from sys import stdout

from math import exp
from math import log
from math import sin
from math import cos

from antlr4 import *
""")
    node = tree.body[1]
    visitor = Python2FutureTransformer()
    node = visitor.visit(node)
    text = get_node_value(node)
    print(text)

# Generated at 2022-06-23 22:57:38.767262
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    python_version = (2, 7)
    source = 'print("This is a test")'
    expected = 'from __future__ import absolute_import\n' \
               'from __future__ import division\n' \
               'from __future__ import print_function\n' \
               'from __future__ import unicode_literals\n' \
               '\n' \
               'print("This is a test")'
    node = parse(source=source, version=python_version)
    visitor = Python2FutureTransformer()
    result = visitor.visit(node)
    assert str(result) == expected
    assert visitor.tree_changed() == True



# Generated at 2022-06-23 22:57:41.348518
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor
    python2_future_transformer = Python2FutureTransformer()
    module = ast.Module([ast.Import(ast.alias('os'))])
    python2_future_transformer.visit(module)
    assert astor.to_source(module) == imports.get_source(future='__future__') + '    import os'

# Generated at 2022-06-23 22:57:47.539148
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    stmt = ast.parse("pass")
    visitor = Python2FutureTransformer()
    visitor.visit(stmt)
    stmt = ast.parse("pass", future_imports={"print_function"})
    visitor = Python2FutureTransformer()
    visitor.visit(stmt)
    base_path = os.path.join(os.path.dirname(__file__), "../../")
    file_name = os.path.join(base_path, "tests/fixtures/future_imports.py")
    with open(file_name) as f:
        stmt = ast.parse(f.read(), filename=file_name)
    visitor = Python2FutureTransformer()
    visitor.visit(stmt)


# Generated at 2022-06-23 22:57:49.231366
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-23 22:57:58.677579
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import parse, roundtrip, assert_equal, compare
    import astor
    text = """a = 1"""
    expected = """
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        a = 1
    """
    node = parse(text)
    new_node = Python2FutureTransformer().visit(node)
    assert_equal(text, astor.to_source(node).strip())
    compare(expected, astor.to_source(new_node).strip())
    roundtrip(new_node, text, Python2FutureTransformer)

# Generated at 2022-06-23 22:58:08.073901
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..ast_utils import get_ast
    from ..utils.diff_ast import diff_ast
    from .base import BaseNodeTransformer
    import astunparse
    source = """
import sys
print("Hi")
    """.strip()
    expected = """
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

import sys
print("Hi")
    """.strip()
    tree = get_ast(source)
    #class_name = 
    #obj = eval(class_name)()
    obj = Python2FutureTransformer()
    tree = obj.visit(tree)
    tree = obj.generic_visit(tree)
    assert ast.dump(tree) == ast.dump(get_ast(expected))


# Generated at 2022-06-23 22:58:08.976965
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-23 22:58:10.233694
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer

# Generated at 2022-06-23 22:58:12.083119
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    tt = Python2FutureTransformer()
    tt.visit(ast.parse("print 2"))

# Generated at 2022-06-23 22:58:14.682583
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    node = ast.parse('1/2')
    assert Python2FutureTransformer().visit(node) == ast.parse('from __future__ import division\n1/2')

# Generated at 2022-06-23 22:58:20.918936
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    source = source_to_ast("print('Hello')")
    checker = Python2FutureTransformer()
    checker.visit(source)
    target = source_to_ast("""
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    
    print('Hello')
    """)
    assert ast_equal(source, target)

# Generated at 2022-06-23 22:58:21.348224
# Unit test for constructor of class Python2FutureTransformer

# Generated at 2022-06-23 22:58:22.005867
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert inspect.isclass(Python2FutureTransformer)

# Generated at 2022-06-23 22:58:24.012209
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer(target_info=(3, 6)).target == (2, 7)
    assert Python2FutureTransformer(target_info=(2, 7)).target == (2, 7)
