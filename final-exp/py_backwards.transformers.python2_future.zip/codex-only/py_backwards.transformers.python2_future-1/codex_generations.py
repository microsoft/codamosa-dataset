

# Generated at 2022-06-23 22:48:31.218427
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    import typed_astunparse
    import astunparse
    module = ast.parse(
        "def func():\n"
        "    print('it works')"
    )
    Python2FutureTransformer().visit(module)
    assert astor.to_source(module) == \
        "from __future__ import absolute_import\n" \
        "from __future__ import division\n" \
        "from __future__ import print_function\n" \
        "from __future__ import unicode_literals\n" \
        "\n" \
        "\n" \
        "def func():\n" \
        "    print('it works')\n"
    assert typed_astunparse.unparse(module) == \
        "from __future__ import absolute_import\n"

# Generated at 2022-06-23 22:48:39.142757
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    ast_ = ast.parse(
        """def foo():
    pass
    """
    )
    obj = Python2FutureTransformer()
    new_ast = obj.visit(ast_)
    assert len(new_ast.body) == 5
    assert isinstance(new_ast.body[0], ast.ImportFrom)
    assert isinstance(new_ast.body[1], ast.ImportFrom)
    assert isinstance(new_ast.body[2], ast.ImportFrom)
    assert isinstance(new_ast.body[3], ast.ImportFrom)
    assert isinstance(new_ast.body[4], ast.FunctionDef)

# Generated at 2022-06-23 22:48:50.157821
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import ast
    import tempfile
    import sys
    from astor import to_source
    from astmonkey import transformers
    from astmonkey.transformers.misc import Python2FutureTransformer, Python3FutureTransformer

    def get_tree(script):
        tree = ast.parse(script)
        return tree

    def transform(script):
        tree = get_tree(script)
        transformer = Python2FutureTransformer()
        return transformer.visit(tree)

    def test_import_future():
        script = "from __future__ import absolute_import"
        assert script == to_source(transform(script))

    def test_import_six():
        script = """import six
from six import u"""
        assert script == to_source(transform(script))


# Generated at 2022-06-23 22:48:51.095055
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer((2, 7))

# Generated at 2022-06-23 22:48:57.429270
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Unit test for Python2FutureTransformer"""
    node = ast.parse("""
    x = 1
    print x
    """)
    Python2FutureTransformer().visit(node)
    print(ast.dump(node))
    # ast.fix_missing_locations(node)
    # exec(compile(node, '<string>', 'exec'))
    # Python2FutureTransformer().visit(node)



if __name__ == '__main__':
    # Unit test
    test_Python2FutureTransformer()

# Generated at 2022-06-23 22:49:04.223768
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # import const, ModuleTransformer
    # from ..utils.snippet import snippet
    # import typed_ast.ast3 as ast

    # Tests that the class Python2FutureTransformer exists in the module.
    assert 'Python2FutureTransformer' in globals()

    # Tests the constructor and it's type.
    transformer = Python2FutureTransformer()

    # Tests that the constructor creates an instance of ModuleTransformer.
    assert isinstance(transformer, ModuleTransformer)


# Unit tests for the method visit_Module in class Python2FutureTransformer

# Generated at 2022-06-23 22:49:08.501751
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ast_analyzer.python_transformer import PythonTransformer
    from ast_analyzer.python_analyzer.analyzer import PythonAnalyzer
    analyzer = PythonAnalyzer('python', PythonTransformer)
    analyzer.visitors = [Python2FutureTransformer]

# Generated at 2022-06-23 22:49:16.073119
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer


    @snippet
    def source(a, b):
        if a:
            z = b
        else:
            z = 0


    module = source.get_ast(a=0, b=0)
    exptected_module = source.get_ast(a=0, b=0)
    exptected_module.body[:0] = imports.get_body(future='__future__')

    assert module != exptected_module

    module = Python2FutureTransformer().visit(module)
    assert module == exptected_module

# Generated at 2022-06-23 22:49:22.623754
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    node = ast.parse('mod = None')
    transformer = Python2FutureTransformer()
    node = transformer.visit(node)
    assert transformer.tree_changed

    # import __future__ is imported
    assert isinstance(node.body[0], ast.ImportFrom)
    assert node.body[0].module == '__future__'

    # mod = None is still there
    assert isinstance(node.body[1], ast.Assign)

# Generated at 2022-06-23 22:49:24.526477
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    from .python2to3 import Python2to3Transformer

# Generated at 2022-06-23 22:49:27.545658
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    test_ast = astor.code_to_ast.parse_file('./tests/python2_future_src.py')
    transformer = Python2FutureTransformer()
    transformer.visit(test_ast)
    assert str(test_ast) == open('./tests/python2_future_exp.py').read()

# Generated at 2022-06-23 22:49:37.828788
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import sys
    from typed_ast.ast3 import parse
    from typed_ast import ast3 as ast
    actual = parse("print 'hello world!'")

# Generated at 2022-06-23 22:49:45.098046
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    tree = ast.parse('import os\nx=10\n')
    visitor = Python2FutureTransformer()
    ast.fix_missing_locations(tree)
    visitor.visit(tree)

    assert 'from __future__ import absolute_import' in astor.to_source(tree)
    assert 'from __future__ import division' in astor.to_source(tree)
    assert 'from __future__ import print_function' in astor.to_source(tree)
    assert 'from __future__ import unicode_literals' in astor.to_source(tree)

# Generated at 2022-06-23 22:49:52.493377
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .test_pipeline import TestCaseWithTransformer
    from typed_ast import ast3 as ast

    code = '''
x = 3  
y = 4  
print(x+y)

'''
    expected_code = '''
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

x = 3  
y = 4  
print(x+y)

'''
    class TestTransformer(TestCaseWithTransformer):
        transformer = Python2FutureTransformer
        target = (2, 7)
        method = 'visit_Module'

    unittest.main(__name__, verbosity=2)

# Generated at 2022-06-23 22:50:03.294407
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ard.utils import load_ast
    from ard.python import Python3to2
    from ard.lint.future import Python2FutureTransformer
    
    # Given the following Python2 function
    code = 'def add(a, b):\n    return a + b'
    tree = load_ast(code)
    assert isinstance(tree, ast.Module)
    
    # and a translator for Python3to2
    translator = Python3to2()
    
    # and a visitor to add __future__ import statements
    visitor = Python2FutureTransformer()
    
    # when I visit the tree
    visitor.visit(tree)
    
    # then the tree is changed
    assert visitor.tree_changed
    
    # and the AST of the translated code is as expected


# Generated at 2022-06-23 22:50:04.486531
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    return None


# Generated at 2022-06-23 22:50:06.196601
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

assert test_Python2FutureTransformer

# snippet imports
assert imports

# Generated at 2022-06-23 22:50:13.663297
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    # given
    node = astor.parse_file('tests/resources/statement_force_ascii.py')
    transformer = Python2FutureTransformer()
    # when
    transformer.visit(node)
    # then
    result = astor.to_source(node).strip()
    expected = '''
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

from future import __division__

print((1 / 2))
print((1 / 2))
print((1 / 2))

print(__division__)
    '''.strip()
    assert result == expected



# Generated at 2022-06-23 22:50:14.523283
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-23 22:50:25.269072
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    from ..utils.test_visitor import GenericTestVisitor
    from ..utils.test_visitor import TestVisitor
    from ..utils.test_visitor import assert_equal_source, assert_equal_tree
    visitor = Python2FutureTransformer()
    source = """print('''
    Hello
    ''')
    """
    module = ast.parse(source, filename='<test>')
    module = visitor.visit(module)
    expect = """from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

print('''
    Hello
    ''')
    """
    assert_equal_source(expect, module)

    # Test that the transformer can be applied twice without problems

    module2

# Generated at 2022-06-23 22:50:25.993396
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass

# Generated at 2022-06-23 22:50:35.652556
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    class_ = Python2FutureTransformer
    import_ = 'import os'
    module = ast.parse(import_)
    tree_changed = class_().visit(module)
    assert tree_changed
    print(ast.dump(module))

# Generated at 2022-06-23 22:50:40.453935
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # fixture
    class TestTransformer(Python2FutureTransformer):
        def visit_BinOp(self, node):
            return node.left
    tree = ast.parse("1 + 2")
    # test
    res = TestTransformer().visit(tree)
    # validation
    assert isinstance(res, ast.Module)
    assert isinstance(res.body[0], ast.ImportFrom)
    assert res.body[1].value.n == 1

# Generated at 2022-06-23 22:50:41.977236
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-23 22:50:42.992747
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    pass


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 22:50:43.819610
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    p = Python2FutureTransformer()


# Generated at 2022-06-23 22:50:44.642685
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer()

# Generated at 2022-06-23 22:50:49.522305
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from astor import to_source
    from fissix.pgen2 import parse, token
    code = '''
#Imports

#Code
'''
    tree = parse(code)
    visitor = Python2FutureTransformer()
    visitor.visit(tree)
    source = to_source(tree).strip()
    assert source == '''
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

#Imports

#Code
'''.lstrip()

# Generated at 2022-06-23 22:50:55.807730
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils import run_transformer_class

    input_code = """
a = 1
b = 2
print(a + b)
"""
    expected_output = """
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

a = 1
b = 2
print(a + b)
"""
    transformer = Python2FutureTransformer()
    run_transformer_class(transformer, input_code, expected_output, target=(2, 7))



# Generated at 2022-06-23 22:51:04.226306
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    """Tests for method visit_Module of class Python2FutureTransformer"""
    import typed_astunparse
    from ..utils.snippet import snippet
    from .fixer_base import BaseFixerTestCase

    @snippet
    def before(future):
        from future import print_function
        a = "A"

        def b():
            pass

    @snippet
    def after(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals
        from future import print_function
        a = "A"

        def b():
            pass

    class Test(BaseFixerTestCase):
        fixer = Python2FutureTransformer()


# Generated at 2022-06-23 22:51:10.622300
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()
    tree = ast.parse("print('test')")
    transformer.visit(tree)
    assert transformer.tree_changed
    
    # TODO: what can I do to improve the following test?
    assert ast_equals(transformer.module, ast.parse("""
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    
    
    print('test')
    """))



# Generated at 2022-06-23 22:51:21.046857
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node_tree = ast.parse('import os')
    transformer = Python2FutureTransformer()
    modified_tree = transformer.visit(node_tree)

# Generated at 2022-06-23 22:51:24.223009
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Unit test for constructor of class Python2FutureTransformer"""

    # Arrange
    transformer = Python2FutureTransformer()

    # Act

    # Assert
    assert transformer is not None



# Generated at 2022-06-23 22:51:29.737786
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .base import BaseNodeTransformerTestCase
    class Test(BaseNodeTransformerTestCase):
        target = (2, 7)
        transformer = Python2FutureTransformer
    
        def test_visit_Module_1(self):
            before = '''
            x = 1
            '''
            after = '''
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
            x = 1
            '''
            self.assertTransform(before, after)
    return Test


# Generated at 2022-06-23 22:51:35.204134
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-23 22:51:44.325400
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    docstring = "\n".join(["Unit test for Python2FutureTransformer.",
                           "",
                           "Attributes:",
                           "    target (tuple): Target versions with major and minor parts.",
                           "",
                           "Methods:",
                           "    visit_Module(self, node): Prepends module with:",
                           "        from __future__ import absolute_import",
                           "        from __future__ import division",
                           "        from __future__ import print_function",
                           "        from __future__ import unicode_literals",
                           ])

    future_transformer = Python2FutureTransformer()
    assert future_transformer.__doc__ == docstring

# Generated at 2022-06-23 22:51:55.546238
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import lib2to3.pytree as pytree
    import lib2to3.pgen2.token as token
    import lib2to3.pgen2.grammar as grammar

    # Define the grammar of the test code snippet

# Generated at 2022-06-23 22:51:56.765496
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-23 22:51:58.233085
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast.ast3 import parse
    from flake8_pyi.checker import PythonICodeChecke

# Generated at 2022-06-23 22:52:01.112660
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast import compare_ast
    from .Python2FutureTransformer import Python2FutureTransformer

# Generated at 2022-06-23 22:52:08.291298
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import os
    import sys
    import tempfile
    import time

    from ..lint import python_lint
    from ..utils import astdump

    temp_name = tempfile.mkstemp()[1]
    with open(temp_name, 'wb') as temp:
        temp.write(b"import os")
    expected = "from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n\nimport os"

    result = python_lint(temp_name, linters=[Python2FutureTransformer],
                            temp_file=temp_name)

    if os.path.exists(temp_name):
        os.remove(temp_name)


# Generated at 2022-06-23 22:52:09.708881
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer().target == (2, 7)

# Generated at 2022-06-23 22:52:14.477623
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import ast
    node = ast.parse('import sys')
    node = Python2FutureTransformer().visit(node)
    assert [child.name for child in node.body if isinstance(child, ast.Import)] == imports.get_imports()  # type: ignore



# Generated at 2022-06-23 22:52:15.608248
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer().__class__.__name__ == 'Python2FutureTransformer'


# Generated at 2022-06-23 22:52:17.472478
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)
    assert transformer.checking_future
    assert transformer.checking_future == (2, 7)



# Generated at 2022-06-23 22:52:18.474198
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()
    assert t is not None


# Generated at 2022-06-23 22:52:28.774011
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from . import simple_AST

    #-- GIVEN ---------------------------------------------------------------
    tree = simple_AST.build()
    transformer = Python2FutureTransformer()

    #-- WHEN ---------------------------------------------------------------
    transformer.visit(tree)

    #-- THEN ---------------------------------------------------------------
    node = transformer.tree
    assert isinstance(node, ast.Module)
    assert len(node.body) == 6
    assert isinstance(node.body[0], ast.ImportFrom)
    assert isinstance(node.body[1], ast.ImportFrom)
    assert isinstance(node.body[2], ast.ImportFrom)
    assert isinstance(node.body[3], ast.ImportFrom)
    assert isinstance(node.body[4], ast.FunctionDef)
    assert isinstance(node.body[5], ast.FunctionDef)



# Generated at 2022-06-23 22:52:34.692430
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..testing import FileBasedTesting
    from . import _make_simple_function
    from .python2_future import Python2FutureTransformer

    code = _make_simple_function.snippet().get_code()
    code = Python2FutureTransformer(code, target=(3, 6)).visit()
    test = FileBasedTesting(code, root=_make_simple_function.filename, test_name="Python2FutureTransformer")
    test.test()

# Generated at 2022-06-23 22:52:38.293499
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():

    from typed_ast import ast3
    from typed_ast import parse

    source = 'def g(): pass'
    tree = ast3.parse(source)
    visitor = Python2FutureTransformer(source)
    visitor.visit(tree)

    assert parse('import __future__\n' + source) == tree

# Generated at 2022-06-23 22:52:40.468492
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    nodeTransformer = Python2FutureTransformer()
    assert hasattr(nodeTransformer, '_tree_changed')
    assert hasattr(nodeTransformer, 'target')

# Generated at 2022-06-23 22:52:41.797498
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer('dummy')
    assert t.target == (2, 7)


# Generated at 2022-06-23 22:52:45.842761
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import Source

    source = Source("a = 5")
    transformer = Python2FutureTransformer()
    tree = transformer.transform_source(source)
    
    assert "from __future__ import absolute_import" in source.source

    assert "from __future__ import division" in source.source
    assert "from __future__ import print_function" in source.source
    assert "from __future__ import unicode_literals" in source.source

# Generated at 2022-06-23 22:52:55.343462
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ... import helpers
    from ... import nodes

    # Arrange
    root = helpers.parse('''
        pass
    ''')
    transformer = Python2FutureTransformer(root)
    node = root.body[0]

    # Act
    result = transformer.visit_Module(node)

    # Assert
    expected = nodes.Module(body=[
        nodes.ImportFrom(module='__future__', names=[
            nodes.alias(name='absolute_import', asname=None),
            nodes.alias(name='division', asname=None),
            nodes.alias(name='print_function', asname=None),
            nodes.alias(name='unicode_literals', asname=None),
        ], level=0),
        nodes.Pass()
    ])
    assert helpers.compare(result, expected)

# Generated at 2022-06-23 22:52:57.124383
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    switch = Python2FutureTransformer()

    # Test constructor
    assert switch.targets == (2, 7)

# Generated at 2022-06-23 22:53:00.924434
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()
    result = transformer.visit(
        ast.parse("""import math, urllib\nprint("Hello World")"""))
    assert '__future__' in ast.dump(result)



# Generated at 2022-06-23 22:53:06.932559
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse(textwrap.dedent("""
    print('Hello, Python2!')
    """))
    node = Python2FutureTransformer().visit(node)
    assert node is not None
    check_equal(node, """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    print('Hello, Python2!')
    """)

# Generated at 2022-06-23 22:53:07.491948
# Unit test for constructor of class Python2FutureTransformer

# Generated at 2022-06-23 22:53:09.592920
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    classes = [Python2FutureTransformer]
    for class_ in classes:
        cls = class_()
        assert cls.target == (2, 7)
        assert cls.node_type == ast.Module


# Generated at 2022-06-23 22:53:14.385541
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source_to_node
    
    sample = """\
    import os

    x = 1
    """
    expected = """\
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    
    import os

    x = 1
    """
    node = source_to_node(sample)
    node = Python2FutureTransformer().visit(node)
    result = node_to_source(node)
    assert result == expected

# Generated at 2022-06-23 22:53:25.392583
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Given
    module = ast.parse("x = b''")
    assert module._fields == ('body',)

    # When
    transformer = Python2FutureTransformer()
    transformer.visit(module)

    # Then
    assert list(map(type, module.body)) == [ast.ImportFrom, ast.ImportFrom, ast.ImportFrom, ast.ImportFrom, ast.Assign]

    assert list(map(lambda x: x.lineno, module.body)) == [1, 1, 1, 1, 2]
    assert list(map(lambda x: x.col_offset, module.body)) == [0, 0, 0, 0, 0]

    assert module.body[0].module == "__future__"    # type: ignore

# Generated at 2022-06-23 22:53:26.242129
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    _ = Python2FutureTransformer

# Generated at 2022-06-23 22:53:28.303178
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__doc__


# Generated at 2022-06-23 22:53:38.080676
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import py2to3.tests.test_target_python27.test_python27_future_transformer

    source = inspect.getsource(py2to3.tests.test_target_python27.test_python27_future_transformer)
    tree = ast.parse(source)
    Python2FutureTransformer().visit(tree)

# Generated at 2022-06-23 22:53:42.985082
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    t = Python2FutureTransformer()
    node = ast.parse("1 + 1")
    node = t.visit(node)
    assert str(node) == """\
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

1 + 1
"""

# Generated at 2022-06-23 22:53:47.759632
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..simplify_ast import SimplifyAst
    node = ast.parse('''
foo = 1
''')
    node = SimplifyAst().visit(node)
    Python2FutureTransformer().visit(node)
    assert __stringify_ast(node) == """
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

foo = 1
"""

# Generated at 2022-06-23 22:53:48.940186
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert inspect.isclass(Python2FutureTransformer)


# Generated at 2022-06-23 22:53:51.956313
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    source = """
    from module import calc_something
    print(calc_something(123))
    """

# Generated at 2022-06-23 22:53:53.174135
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'

# Generated at 2022-06-23 22:53:54.410214
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()
    assert t is not None

# Generated at 2022-06-23 22:53:58.242392
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast

    tree = ast.parse("print('hello world')")
    trans = Python2FutureTransformer()
    trans.visit(tree)
    expected = ast.parse(imports)
    assert compare_ast(tree, expected)

# Generated at 2022-06-23 22:54:03.901656
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast27
    tree = ast27.parse("import urllib", mode="exec")
    tree = Python2FutureTransformer().visit(tree)
    assert type(tree) == ast27.Module
    assert len(tree.body) == 5
    for stmt in tree.body:
        assert type(stmt) == ast27.ImportFrom
    assert tree.body[0].module == '__future__'
    assert tree.body[0].names[0].name == 'absolute_import'
    assert tree.body[1].names[0].name == 'division'
    assert tree.body[2].names[0].name == 'print_function'
    assert tree.body[3].names[0].name == 'unicode_literals'

# Generated at 2022-06-23 22:54:05.900861
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    x = Python2FutureTransformer()
    assert repr(x) == '<Python2FutureTransformer()>'
    assert type(x) == Python2FutureTransformer

# Generated at 2022-06-23 22:54:13.078605
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    """Test case for method visit_Module of class Python2FutureTransformer"""
    import astor

    class Python2FutureTransformerMock(Python2FutureTransformer):
        def __init__(self):
            self._tree_changed = False

    src = "print('hello world')"
    exp = """
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        print('hello world')
    """
    tree = ast.parse(src)
    transformer = Python2FutureTransformerMock()
    tree = transformer.visit(tree)
    assert transformer._tree_changed is True
    assert astor.to_source(tree) == exp

# Generated at 2022-06-23 22:54:23.010124
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    tree = ast.parse("print('hello')")
    transformer = Python2FutureTransformer()
    module_node = transformer.visit(tree)
    assert transformer._tree_changed == True

    # Assert that the new module_node.body has been set to:
    # [<_ast.ImportFrom at 0x2c6b350>,
    #  <_ast.ImportFrom at 0x2c6b390>,
    #  <_ast.ImportFrom at 0x2c6b3d0>,
    #  <_ast.ImportFrom at 0x2c6b410>,
    #  <_ast.Expr at 0x2c6b450>]

    assert module_node.body[0].module == '__future__'

# Generated at 2022-06-23 22:54:27.600492
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer(())
    assert transformer.visit(ast.parse("import sys")) == ast.parse("from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\nimport sys")

# Generated at 2022-06-23 22:54:30.836156
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.from_version == (2, 7)
    assert transformer.to_version == (3, 7)



# Generated at 2022-06-23 22:54:37.065519
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_ast = ast.parse(textwrap.dedent(
        """
        def main():
            pass
        
        if __name__ == "__main__":
            main()
        """
    ))
    module_ast_transformed = Python2FutureTransformer.run_pipeline(module_ast)
    assert ast.dump(module_ast_transformed) == textwrap.dedent(
        """
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        def main():
            pass

        if __name__ == "__main__":
            main()
        """)

# Generated at 2022-06-23 22:54:41.393423
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = ast.parse('print(1)')
    transformed = Python2FutureTransformer().visit(module)
    assert transformed.body[0].module == '__future__'
    assert transformed.body[0].names[0].name == 'absolute_import'
    assert transformed.body[1].module == '__future__'
    assert transformed.body[1].names[0].name == 'division'
    assert transformed.body[2].module == '__future__'
    assert transformed.body[2].names[0].name == 'print_function'
    assert transformed.body[3].module == '__future__'
    assert transformed.body[3].names[0].name == 'unicode_literals'

# Generated at 2022-06-23 22:54:46.794487
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    actual = transformer.visit(ast.parse("import numpy"))
    expected = ast.parse("from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\nimport numpy")
    assert ast.dump(actual,include_attributes=False) == ast.dump(expected,include_attributes=False)


# Generated at 2022-06-23 22:54:57.037267
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    original_code = dedent('''\
        import matplotlib as mpl
        import matplotlib.pyplot as plt
        import numpy as np
        ''')

    expected_code = dedent('''\
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        import matplotlib as mpl
        import matplotlib.pyplot as plt
        import numpy as np
        ''')

    tree = ast.parse(original_code)
    Python2FutureTransformer(tree)
    assert astor.to_source(tree) == expected_code

# Generated at 2022-06-23 22:55:06.482031
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    py_ast = ast.parse('def foo(b):\n    a = b\n    return a')

    transformer = Python2FutureTransformer()
    py_ast = transformer.visit(py_ast)
    generator = ast.NodeVisitor()
    future_ast = generator.visit(py_ast)
    
    assert future_ast == 'def foo(b):\n    from __future__ import absolute_import\n    from __future__ import division\n    from __future__ import print_function\n    from __future__ import unicode_literals\n    a = b\n    return a'

# Generated at 2022-06-23 22:55:15.711122
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    mod = Python2FutureTransformer().visit_Module(ast.parse("a = 1"))  # type: ignore

# Generated at 2022-06-23 22:55:20.806844
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils import compare_nodes
    module = imports.get_ast(future='__future__')
    module.body.append(ast.Expr(value=ast.Str('Testing')))
    module2 = Python2FutureTransformer().visit(module)
    compare_nodes(module2, module)
    assert Python2FutureTransformer().target == (2, 7)

# Generated at 2022-06-23 22:55:28.469947
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import parse, ast3
    from typed_ast.ast3 import Assign, FunctionDef, Name, Num
    import astor

    source = "a = 1\n"
    class_def = ast.ClassDef(name='Test', body=[ast.FunctionDef(name='__init__', args=ast.arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[])), ast.FunctionDef(name='test', args=ast.arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[ast.Assign(targets=[ast.Name(id='a', ctx=ast.Store())], value=ast.Num(n=1))]), ])
   

# Generated at 2022-06-23 22:55:33.150640
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()
    test_module = ast.parse('def f():\n  print "hello!"\n')
    transformed_module = transformer.visit(test_module)  # type: ignore
    assert transformer._tree_changed
    assert isinstance(transformed_module, ast.Module)
    assert len(transformed_module.body) == 5

# Generated at 2022-06-23 22:55:38.923814
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.test_utils import assert_ast_equal

    assert_ast_equal(Python2FutureTransformer.visit(ast.parse(imports.get_code(future='__future__'))),
                     ast.parse(imports.get_code(future='__future__')))

    assert_ast_equal(Python2FutureTransformer.visit(ast.parse(imports.get_code(future='__future__'))),
                     ast.parse(imports(future='__future__')))

# Generated at 2022-06-23 22:55:40.098858
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    filename = "tmp.py"

# Generated at 2022-06-23 22:55:46.293192
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    node = ast.parse('pass')
    assert len(node.body) == 1

    node = Python2FutureTransformer(node)

    assert len(node.body) == 5
    assert node.body[0] == ast.ImportFrom('__future__', [ast.alias('absolute_import', None)], 0)
    assert node.body[1] == ast.ImportFrom('__future__', [ast.alias('division', None)], 0)
    assert node.body[2] == ast.ImportFrom('__future__', [ast.alias('print_function', None)], 0)
    assert node.body[3] == ast.ImportFrom('__future__', [ast.alias('unicode_literals', None)], 0)
    assert node.body[4] == ast.Pass()



# Generated at 2022-06-23 22:55:50.401389
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert inspect.isclass(Python2FutureTransformer)
    xformer = Python2FutureTransformer()
    assert isinstance(xformer, BaseNodeTransformer)
    assert xformer._tree_changed == False
    assert xformer.target == (2, 7)
    assert xformer.generic_visit != BaseNodeTransformer.generic_visit


# Generated at 2022-06-23 22:56:01.128128
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from pyflakes._ast3 import Module as Module3
    from ...definitions.python2 import python2
    from ...utils import source
    transformer = Python2FutureTransformer('foo.py', python2)
    node = Module3(body=[
        ast.Import(names=[ast.alias(name='foo', asname=None)]),
        ast.ImportFrom(module='foo.bar', names=[ast.alias(name='baz', asname=None)], level=0)
    ])
    transformer.visit(node)

# Generated at 2022-06-23 22:56:02.105294
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer().tree_changed is False


# Generated at 2022-06-23 22:56:04.957510
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    filename = inspect.getfile(inspect.currentframe())
    t = Python2FutureTransformer.get_default(filename=filename, future='__future__')
    assert isinstance(t, Python2FutureTransformer)

# Generated at 2022-06-23 22:56:05.881141
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-23 22:56:07.427716
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer(None, None).__class__.__name__ == 'Python2FutureTransformer'

# Generated at 2022-06-23 22:56:15.044838
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()
    node = ast.parse("a == 1")
    new_node = transformer.visit(node)

    assert "from __future__ import absolute_import" in astor.to_source(new_node)
    assert "from __future__ import unicode_literals" in astor.to_source(new_node)
    assert "from __future__ import division" in astor.to_source(new_node)
    assert "from __future__ import print_function" in astor.to_source(new_node)

# Generated at 2022-06-23 22:56:25.943332
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse('x=1', filename='<unknown>')
    node = Python2FutureTransformer().visit_Module(node)
    import pprint
    pprint.pprint(ast.dump(node, annotate_fields=False, include_attributes=False))
    assert ast.dump(node, annotate_fields=False, include_attributes=False) == \
           "Module(body=[_ast.ImportFrom(module='__future__', names=[alias(_ast.alias(name='absolute_import', asname=None), _ast.alias(name='division', asname=None), _ast.alias(name='print_function', asname=None), _ast.alias(name='unicode_literals', asname=None))], level=0)], type_ignores=[])"
    # The parser adds a comment

# Generated at 2022-06-23 22:56:31.144222
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    def check(src, dst):
        node = ast.parse(src)
        Python2FutureTransformer().visit(node)
        result = compile(node, "<test>", "exec")
        ns = {}
        exec(result, ns)
        assert ns['a'] == dst

    check("a = 1", 1)

# Generated at 2022-06-23 22:56:33.450949
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Test for Python2FutureTransformer."""
    trans = Python2FutureTransformer()
    assert trans.target == (2, 7)


# Generated at 2022-06-23 22:56:38.375801
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()
    module = ast.parse('print(1)')
    module = transformer.visit(module)
    assert transformer._tree_changed is True
    assert transformer.get_tree() == dedent('''\
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    print(1)
    ''')

# Generated at 2022-06-23 22:56:41.524403
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()
    assert t.visit_Module == Python2FutureTransformer.visit_Module
    assert t.target == (2, 7)
    assert t._tree_changed == False

# Generated at 2022-06-23 22:56:50.246663
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import sys
    
    transformed_src = "from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n\nc = [1, 2, 3]\n"
    src = "c = [1, 2, 3]\n"
    tree = ast.parse(src)
    # Test:
    transf = Python2FutureTransformer()
    transf.visit(tree)
    assert isinstance(transf, Python2FutureTransformer)
    # Test
    assert repr(tree) == transformed_src
    # Test
    assert ast.dump(tree) == transformed_src
    # Test
    exec(compile(tree, filename="<ast>", mode="exec"), globals())

# Generated at 2022-06-23 22:56:57.365705
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    node = ast.parse("def test(): pass")
    t = Python2FutureTransformer()
    t.visit(node)
    assert len(t.tree.body) == 4 and\
        t.tree.body[0].name == "absolute_import" and\
        t.tree.body[1].name == "division" and\
        t.tree.body[2].name == "print_function" and\
        t.tree.body[3].name == "unicode_literals" and\
        t.tree.body[4].name == "test"

# Generated at 2022-06-23 22:56:59.262569
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    p2ft = Python2FutureTransformer()
    assert p2ft.tree_changed is False


# Generated at 2022-06-23 22:57:04.464338
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():

    utils.assert_source_equal(
        Python2FutureTransformer.run_visitor('def f(x):\n    return (1, x + 1)\n'),
        'from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n\ndef f(x):\n    return (1, x + 1)\n')

# Generated at 2022-06-23 22:57:06.451486
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer.target == (2, 7)

# Generated at 2022-06-23 22:57:17.241298
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    assert ast.dump(Python2FutureTransformer(None, None).visit(ast.parse('pass'))) == \
        u'Module(body=[ImportFrom(module=\'__future__\', names=[alias(name=\'absolute_import\', asname=None)], level=0), ImportFrom(module=\'__future__\', names=[alias(name=\'division\', asname=None)], level=0), ImportFrom(module=\'__future__\', names=[alias(name=\'print_function\', asname=None)], level=0), ImportFrom(module=\'__future__\', names=[alias(name=\'unicode_literals\', asname=None)], level=0), Pass()])'


# Generated at 2022-06-23 22:57:28.837430
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    source = """
    a = 1
    b = 2
    if (a == 0) or (b == 0):
        print('0 is not allowed')
    """
    tr = Python2FutureTransformer()
    module = ast.parse(source)
    module = tr.visit(module)

# Generated at 2022-06-23 22:57:34.472740
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert repr(Python2FutureTransformer) == "<class 'pynsource.transformer.python2future.Python2FutureTransformer'>"
    assert Python2FutureTransformer().__class__.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer().target == (2, 7)
    assert Python2FutureTransformer()._tree_changed == False


# Generated at 2022-06-23 22:57:44.238273
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    """Unit test for method visit_Module of class Python2FutureTransformer."""

    # Some imports
    import ast as pyast
    from flake8_future_import.visitors.ast2to3.python2 import Python2FutureTransformer

    # Define the code to transform by the transformer
    code = (
        "print('Hello world!')\n"
    )

    # Get the AST of the code
    tree = pyast.parse(code)

    # Get instance of Python2FutureTransformer()
    transformer = Python2FutureTransformer()

    # Visit the tree
    tree = transformer.visit(tree)

    # Check the tree changed
    assert transformer.tree_changed

    # Check the result

# Generated at 2022-06-23 22:57:47.391957
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    p2ft = Python2FutureTransformer()
    test_module = ast.parse('import os')
    assert p2ft.visit(test_module)
    test_module = ast.parse('from os import path')
    assert p2ft.visit(test_module)

# Generated at 2022-06-23 22:57:49.417675
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    print("Testing Python2FutureTransformer")


# Generated at 2022-06-23 22:57:53.735468
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    x = Python2FutureTransformer()
    assert x.visit_Module(ast.Module(body=[])) == ast.Module(body=imports.get_body(future='__future__'))

# Generated at 2022-06-23 22:58:03.699547
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformerTest

    class Python2FutureTransformerTest(BaseNodeTransformerTest):
        transformer = Python2FutureTransformer
        target = Python2FutureTransformer.target

        def test_simple_module(self):
            code = '\n'.join([
                '# This is a comment',
                'import os',
                'print("Hello world!")'
            ])
            expected_code = '\n'.join([
                'from __future__ import absolute_import',
                'from __future__ import division',
                'from __future__ import print_function',
                'from __future__ import unicode_literals',
                'import os',
                'print("Hello world!")'
            ])

            tree = ast.parse(code)

# Generated at 2022-06-23 22:58:04.940983
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    ntt = Python2FutureTransformer()
    return ntt

# Generated at 2022-06-23 22:58:05.965179
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-23 22:58:10.643770
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    @snippet
    def before():
        import os

    @snippet
    def after():
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals
        import os

    visitor = Python2FutureTransformer()
    visitor.visit(before.get_ast())
    assert before.get_ast() == after.get_ast()
    assert visitor._tree_changed



# Generated at 2022-06-23 22:58:20.226329
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .. import from_python
    from .. import to_python

    before = """
with open('spam.txt', 'w') as f:
    f.write('eggs')
    """
    after = """
from future import absolute_import
from future import division
from future import print_function
from future import unicode_literals

with open('spam.txt', 'w') as f:
    f.write('eggs')
    """
    source = from_python(before)
    tree = source._as_tree()  # type: ignore
    transformer = Python2FutureTransformer()
    new = transformer.visit(tree)  # type: ignore
    assert to_python(new) == after

# Generated at 2022-06-23 22:58:26.184869
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    tree = ast.parse("""
a = 'a'
print(a)
b = 3
""", filename="example.py", mode="exec")
    Python2FutureTransformer().visit(tree)
    expected = ast.parse("""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
a = 'a'
print(a)
b = 3
""", filename="example.py", mode="exec")
    assert ast.dump(tree) == ast.dump(expected)