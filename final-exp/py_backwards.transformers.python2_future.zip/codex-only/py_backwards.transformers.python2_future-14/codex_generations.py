

# Generated at 2022-06-23 22:48:26.644919
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .. import tree
    from ast_tools.passes import PrintTree
    from ast_tools.passes import RemoveCommentsAndDocstrings
    source = """
        #!/usr/bin/env python
        x = 3

        def f():
            return x

        def g():
            return x
    """
    node = tree.build(source)
    node = Python2FutureTransformer().visit(node)
    node = PrintTree().visit(node)
    node = RemoveCommentsAndDocstrings().visit(node)
    assert tree.compare(source, node) == []

# Generated at 2022-06-23 22:48:33.016578
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    node = ast.parse('x=1')  # type: ignore
    transformer = Python2FutureTransformer()
    new_node = transformer.visit(node)
    assert str(new_node) == "from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\nx=1"
    assert transformer.tree_changed is True
    assert transformer.target == (2, 7)
    assert transformer.name == 'Python2FutureTransformer'

# Generated at 2022-06-23 22:48:40.991096
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    ast_tree = compile('x = "haha"', 'filename', 'exec', ast.PyCF_ONLY_AST)
    Python2FutureTransformer().visit(ast_tree)
    import io
    import astunparse
    f = io.StringIO()
    astunparse.unparse(ast_tree, f)
    assert f.getvalue() == textwrap.dedent("""
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        x = "haha"
    """).lstrip()

# Generated at 2022-06-23 22:48:41.553106
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass

# Generated at 2022-06-23 22:48:51.469919
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor

    method_source = "import builtins\nfoo = 2.3"
    expected_source = ("from __future__ import absolute_import\nfrom __future__ "
                       "import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n"
                       "import builtins\nfoo = 2.3")

    class_ast = ast.parse(method_source)  # type: ignore
    class_ast = Python2FutureTransformer().visit(class_ast)  # type: ignore
    class_source = astor.to_source(class_ast)  # type: ignore
    assert class_source == expected_source



# Generated at 2022-06-23 22:48:59.714930
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import typed_ast.ast3 as ast
    from typed_ast.ast3 import (
        Assign,
        FunctionDef,
        Name,
        Num,
        Return,
        Str,
        Subscript,
        Tuple,
        Load,
        Module,
        Store,
    )
    transformer = Python2FutureTransformer()

# Generated at 2022-06-23 22:49:06.396284
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    m = ast.parse("import numpy as np")

    result = Python2FutureTransformer(line_offset=0).visit(m)

    # Module should have been changed
    assert Python2FutureTransformer._tree_changed is True
    Python2FutureTransformer._tree_changed = False

    # Body should have 4 extra lines
    assert len(m.body) == 1
    assert len(result.body) == 5

    # These should be the same
    expected = imports.get_body(future='__future__')
    assert result.body[0] == expected[0]
    assert result.body[1] == expected[1]
    assert result.body[2] == expected[2]
    assert result.body[3] == expected[3]
    assert result.body[4] == m.body[0]

# Generated at 2022-06-23 22:49:08.189719
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..type_inference.visitor import TypeInferer

# Generated at 2022-06-23 22:49:09.135553
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()

# Generated at 2022-06-23 22:49:14.360080
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .visitors.ast_unparse import AstUnparseVisitor
    from ..models.module import PythonModule
    from .test_utils import TEST_IMPORT_RELATIVE_NAMESPACES
    for path in TEST_IMPORT_RELATIVE_NAMESPACES:
        module = PythonModule(path)
        Python2FutureTransformer().visit(module.tree)
        print(AstUnparseVisitor(module.tree).get_code())

# Generated at 2022-06-23 22:49:22.840733
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    test_code = "print('hello from class Python2FutureTransformer')"
    result_code = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    print('hello from class Python2FutureTransformer')
    """
    m = Python2FutureTransformer().visit(ast.parse(test_code))
    result = ast.parse(result_code)
    assert ast.dump(m) == ast.dump(result)

# Generated at 2022-06-23 22:49:29.401864
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    code = "print('Hello, world!')"
    node = ast.parse(code)
    
    # make sure it's Python 2.7 code
    assert isinstance(node, ast.Module)
    assert node.body[0].value.s == "Hello, world!"

    # test constructor of class Python2FutureTransformer
    transformer = Python2FutureTransformer()
    new_node = transformer.visit(node)

    # make sure it's Python 3 code
    assert isinstance(new_node, ast.Module)
    assert new_node.body[0].value.s == "Hello, world!"
    assert len(new_node.body) == 5

    # make sure it adds the import statements at the beginning
    assert isinstance(new_node.body[1], ast.ImportFrom)

# Generated at 2022-06-23 22:49:31.637763
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer(target=(2, 7))
    assert transformer.target == (2, 7)


# Generated at 2022-06-23 22:49:37.923333
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .test_transformer_base import run_on_string
    code = 'import sys'
    expected_code = """\
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

import sys\
"""
    result = run_on_string(Python2FutureTransformer, code)
    assert result == expected_code



# Generated at 2022-06-23 22:49:42.507371
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    tree = ast.parse('print("Hello, world")')
    assert isinstance(tree, ast.Module)
    Python2FutureTransformer().visit(tree)
    assert isinstance(tree, ast.Module)
    # noinspection PyUnresolvedReferences
    assert len(tree.body) == 5


__transformer__ = Python2FutureTransformer

# Generated at 2022-06-23 22:49:48.257800
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor
    transformer = Python2FutureTransformer()
    tree = transformer.visit(ast.parse('''from future import print_function, division'''))
    assert astor.to_source(tree) == '''from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals\nfrom future import print_function, division\n'''

# Generated at 2022-06-23 22:49:53.939799
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast

    class DummyTransformer(Python2FutureTransformer):
        _tree_changed = False

    transformer = DummyTransformer()
    
    tree = ast.parse('pass')
    transformer.visit(tree)
    assert transformer._tree_changed  # type: ignore
    assert tree.body == imports.get_body(future='__future__') + [ast.Pass()]

# Generated at 2022-06-23 22:50:02.268779
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    tree = ast.parse("""
        def a():
            print(1)
        def b():
            print(2)

    """)
    v = Python2FutureTransformer()
    v.visit(tree)
    assert "from __future__ import absolute_import" in astor.to_source(tree)
    assert "from __future__ import division" in astor.to_source(tree)
    assert "from __future__ import print_function" in astor.to_source(tree)
    assert "from __future__ import unicode_literals" in astor.to_source(tree)

# Generated at 2022-06-23 22:50:03.670658
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-23 22:50:10.199462
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .... import ast as ast3

    tree3: ast3.Module = ast3.parse("""
        def foo():
            pass
    """)

    transformer = Python2FutureTransformer()
    expected_tree: ast3.Module = ast3.parse("""
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals


        def foo():
            pass
    """)

    assert transformer.visit(tree3) == expected_tree

# Generated at 2022-06-23 22:50:13.881971
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source
    from .transformer_test import TransformerTest

    transformer = TransformerTest(Python2FutureTransformer())
    assert transformer.visit(source(
        'print("Hello world!")'
    )) == imports.get_source(future='__future__') + "\nprint('Hello world!')"  # type: ignore

# Generated at 2022-06-23 22:50:18.707044
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.Module(body=[])
    t = Python2FutureTransformer()
    node = t.visit_Module(node)
    assert len(node.body) == 4
    assert node.body[0].names[0].name == 'absolute_import'

# Generated at 2022-06-23 22:50:19.603716
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-23 22:50:20.870350
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer is not None

# Generated at 2022-06-23 22:50:22.069959
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass

# Generated at 2022-06-23 22:50:26.280641
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor
    import ast
    module = astor.code_to_ast.parse_file('tests/transforms/data/fibonacci.py')
    transformer = Python2FutureTransformer()
    assert transformer.generic_visit(module) == Python2FutureTransformer().visit(module)

# Generated at 2022-06-23 22:50:33.959002
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor

    source = """
if __name__ == '__main__':
    future = __future__
"""
    expected = """
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
if __name__ == '__main__':
    future = __future__
"""
    tree = ast.parse(source)
    transformer = Python2FutureTransformer()
    new_tree = transformer.visit(tree)
    result = astor.to_source(new_tree)
    assert result == expected

# Generated at 2022-06-23 22:50:36.087568
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-23 22:50:41.617610
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    trans = Python2FutureTransformer()
    assert trans.target == (2, 7)
    assert trans.visit_Module.__name__ == 'visit_Module'
    assert not trans._tree_changed


# Generated at 2022-06-23 22:50:47.434622
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from darglint.transformer import Python2FutureTransformer

    input_ast_tree = ast.parse('''def test(): pass''')
    expected_ast_tree = ast.parse('''
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        def test(): pass''')
    assert Python2FutureTransformer().visit(input_ast_tree) == expected_ast_tree

# Generated at 2022-06-23 22:50:56.315237
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .. import untangle, remove_imports
    from ..types import TreeChanged

    code = '''
    import os
    import sys
    from collections import namedtuple
    from future import print_function
    from __future__ import unicode_literals

    def main():
        print("Hello, world!")
    if __name__ == '__main__':
        main()
    '''
    tree = untangle(code)
    assert not Python2FutureTransformer(tree).visit(tree)
    tree = untangle(code)
    assert isinstance(Python2FutureTransformer(tree).visit(tree), TreeChanged)
    tree = remove_imports(untangle(code))
    assert isinstance(Python2FutureTransformer(tree).visit(tree), TreeChanged)
    assert tree.body[0] == imports

# Generated at 2022-06-23 22:50:57.076354
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    print()
    print('-' * 70)
    Python2FutureTransformer()

# Generated at 2022-06-23 22:51:02.770788
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # This test performs a c-code style  compilation to check if
    # the code generated by the snippet match the code after visiting the class
    # Python2FutureTransformer
    # To make this test running, the snippet must be complete (no <...>)
    # and must not contain any <*var*>
    # The snippet imports is used for testing the method visit_Module of the class
    # Python2FutureTransformer.
    from ..utils.snippet import compile_snippet
    from .helpers import target_ast
    snippet_imports = compile_snippet(imports, 'imports')
    snippet_imports.body = target_ast(snippet_imports.body, 2)

    #Compile the target code to get an ast
    #target_code = compile_snippet('<# imports #>', '

# Generated at 2022-06-23 22:51:09.463496
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import typed_astunparse
    source_code = 'print("Hello, world!")'
    expected_source_code = 'from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n\nprint("Hello, world!")'
    tree = ast.parse(source_code)
    Python2FutureTransformer().visit(tree)
    actual_source_code = typed_astunparse.unparse(tree)
    assert actual_source_code == expected_source_code

# Generated at 2022-06-23 22:51:19.876707
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    root = ast.parse('''\
        import os
        import sys
        import math 
        from typing import Dict
    ''')
    transformer = Python2FutureTransformer()
    root = transformer.visit(root)
    assert transformer._tree_changed is True

# Generated at 2022-06-23 22:51:21.247937
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()

# Generated at 2022-06-23 22:51:26.368506
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    tf = Python2FutureTransformer()
    node = ast.parse('import os')
    module = tf.visit_Module(node)  # type: ignore
    assert str(module) == 'from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n\nimport os\n'

# Generated at 2022-06-23 22:51:35.956850
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_tree = ast.parse('foo = 1')
    tree_changed, module_tree = Python2FutureTransformer(module_tree).transform()
    assert tree_changed
    assert ast.dump(module_tree) == '''Module(body=[ImportFrom(module='future', names=[alias(name='absolute_import', asname=None)], level=0), ImportFrom(module='future', names=[alias(name='division', asname=None)], level=0), ImportFrom(module='future', names=[alias(name='print_function', asname=None)], level=0), ImportFrom(module='future', names=[alias(name='unicode_literals', asname=None)], level=0), Assign(targets=[Name(id='foo', ctx=Store())], value=Num(n=1))])'''




# Generated at 2022-06-23 22:51:40.134246
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    node = ast.parse(imports.example_py2)
    actual_transformer = Python2FutureTransformer()

    actual_tree = actual_transformer.visit(node)

    assert imports.example_py3 == astunparse.unparse(actual_tree)



# Generated at 2022-06-23 22:51:47.675089
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    from typed_ast import ast3 as ast

    source = """
for i in range(6):
    print(i)
"""
    expected = """
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

for i in range(6):
    print(i)
"""
    node = ast.parse(source)
    transformer = Python2FutureTransformer()
    node = transformer.visit(node)
    assert astor.to_source(node) == expected
    assert transformer.tree_changed is True

# Generated at 2022-06-23 22:51:49.479371
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)

# Generated at 2022-06-23 22:51:50.489536
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-23 22:51:52.132523
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer(2.7).target == (2, 7)

# Generated at 2022-06-23 22:51:57.448657
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor
    source = """class Foo:
    pass
"""
    tree = ast.parse(source, mode='exec')
    tree = Python2FutureTransformer().visit(tree)
    code = astor.to_source(tree)

# Generated at 2022-06-23 22:52:04.063860
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # Check that no imports are added if parent is not a module
    assert Python2FutureTransformer.visit(ast.FunctionDef(lineno=4, col_offset=4, name='foo', body=[
        ast.Return(value=ast.List(elts=[ast.Num(n=0)], ctx=ast.Load()), lineno=4, col_offset=4),
    ])
    ) == ast.FunctionDef(lineno=4, col_offset=4, name='foo', body=[
        ast.Return(value=ast.List(elts=[ast.Num(n=0)], ctx=ast.Load()), lineno=4, col_offset=4),
    ])

    # Check that no imports are added if __future__ imports are already present

# Generated at 2022-06-23 22:52:13.726404
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..mock_ast import get_ast

    a = """
    import os
    import sys
    print('Hello from a')
    print(os)
    print(sys)
    
    """
    b = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    
    import os
    import sys
    print('Hello from a')
    print(os)
    print(sys)
    
    """
    node = get_ast(a)
    t = Python2FutureTransformer(tree=node)
    t.transformation()
    assert ast.dump(node) == ast.dump(get_ast(b))

# Generated at 2022-06-23 22:52:17.747970
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    t = Python2FutureTransformer()
    assert t.visit_Module(ast.parse('a = 1')) == ast.parse(
        'from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import '
        'print_function\nfrom __future__ import unicode_literals\na = 1'
    )

# Generated at 2022-06-23 22:52:22.279399
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    code = """\
    import sys, os
    """

    expected_code = """\
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    import sys, os
    """

    node = ast.parse(code, mode='exec')
    tr = Python2FutureTransformer()
    tr.visit(node)
    assert expected_code == astunparse.unparse(node)

# Generated at 2022-06-23 22:52:23.268518
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-23 22:52:24.305193
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()
    assert True

# Generated at 2022-06-23 22:52:28.671582
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # construct a fake node
    node = ast.Module(body=[])
    # construct a Python2FutureTransformer object
    t = Python2FutureTransformer(node)  # type: ignore
    # test if the result is as expected
    assert 'from __future__ import absolute_import' in t._tree_changed
    assert 'from __future__ import division' in t._tree_changed
    assert 'from __future__ import print_function' in t._tree_changed
    assert 'from __future__ import unicode_literals' in t._tree_changed

# Generated at 2022-06-23 22:52:30.111119
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer is not None

# Generated at 2022-06-23 22:52:31.531470
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-23 22:52:37.096300
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    s = """a = 5
print(a)
"""
    t = """from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

a = 5
print(a)
"""
    tree = ast.parse(s)
    tree = Python2FutureTransformer().visit(tree)
    assert astor.to_source(tree) == t

# Generated at 2022-06-23 22:52:42.365564
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # Test construction of class Python2FutureTransformer
    obj = Python2FutureTransformer()
    assert isinstance(obj.target, tuple)
    assert isinstance(obj.target[0], int)
    assert isinstance(obj.target[1], int)

    assert isinstance(obj.visit_Module, types.FunctionType)

    assert isinstance(obj.generic_visit, types.FunctionType)

# Generated at 2022-06-23 22:52:46.230082
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    tree = ast.parse('print("Hello World!")')
    Python2FutureTransformer().visit(tree)
    expected_output = ast.parse('''
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        print("Hello World!")''')
    assert ast.dump(expected_output) == ast.dump(tree)

# Generated at 2022-06-23 22:52:51.774894
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fake import fake_module

    assert str(Python2FutureTransformer().visit(fake_module('from __future__ import absolute_import'))) ==\
        'from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\nfrom __future__ import absolute_import'



# Generated at 2022-06-23 22:52:58.341144
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # Create an instance of Python2FutureTransformer
    obj = Python2FutureTransformer()
    # Represents the source code that we want to analyze
    source_code = """print(0)"""
    # Get the AST tree in binary format
    root = ast.parse(source_code)
    # Print the tree
    # ast.dump(root)
    # Analyze the code
    obj.visit(root)
    # Save the AST tree in binary format
    with open('unit_test_Python2FutureTransformer.bin', 'wb') as f:
        pickle.dump(root, f)
    # Open the AST tree
    with open('unit_test_Python2FutureTransformer.bin', 'rb') as f:
        root = pickle.load(f)
    # Print the tree
    # ast.dump(root)

# Generated at 2022-06-23 22:53:08.185479
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import ast
    import typed_ast.ast3 as ast3
    from .base import BaseNodeTransformerTest
    from .base import BaseNodeTransformerTest

    class Test(BaseNodeTransformerTest):
        target_class = Python2FutureTransformer
        target_method = 'visit_Module'
        visit_only_targets = True

        def get_ast(self, node):
            return ast.parse(textwrap.dedent(node))


# Generated at 2022-06-23 22:53:09.035934
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    obj = Python2FutureTransformer()
    assert obj._tree_changed is False

# Generated at 2022-06-23 22:53:12.700622
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    t = Python2FutureTransformer()
    m = ast.parse("print(1)")
    assert t.visit(m) == ast.parse(
        """
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        print(1)
        """
    )

# Generated at 2022-06-23 22:53:19.325723
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()
    module = ast.parse('def foo():\n    return 123')
    updated = transformer.visit(module)

    assert updated.body[0].name == "absolute_import"
    assert updated.body[1].name == "division"
    assert updated.body[2].name == "print_function"
    assert updated.body[3].name == "unicode_literals"
    assert updated.body[4].name == "foo"

# Generated at 2022-06-23 22:53:20.731386
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer

# Generated at 2022-06-23 22:53:26.215252
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from stubs import Future

    test_ast = ast.parse("""
        import future
        
        print('abc')
    """)

    transformer = Python2FutureTransformer()
    transformer.visit(test_ast)
    assert test_ast == ast.parse("""
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

        import future

        print('abc')
    """)

# Generated at 2022-06-23 22:53:33.278727
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    code = """
    assert True
    """
    tree = ast.parse(code)
    t = Python2FutureTransformer()
    t.visit(tree)
    assert t._tree_changed
    new_code = astor.to_source(tree)
    expected = """
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

assert True
    """.strip()
    assert new_code.strip() == expected

# Generated at 2022-06-23 22:53:35.428571
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.source import source

# Generated at 2022-06-23 22:53:37.736807
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()
    # print(t) # debug



# Generated at 2022-06-23 22:53:44.715346
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    node = astor.parse_file(r'..\examples\python2.py')
    transformer = Python2FutureTransformer()
    transformer.visit(node)
    lines = astor.to_source(node).splitlines()
    assert lines[0] == "from __future__ import absolute_import"
    assert lines[1] == "from __future__ import division"
    assert lines[2] == "from __future__ import print_function"
    assert lines[3] == "from __future__ import unicode_literals"

# Generated at 2022-06-23 22:53:47.269312
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()

    result = transformer.visit(ast.parse(""))

    import astor
    expected = imports.get_ast(future='__future__') + ast.parse("")  # type: ignore
    assert astor.to_source(result) == astor.to_source(expected)

# Generated at 2022-06-23 22:53:49.838432
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast.ast3 import Module 
    tree = Module(body=[])
    new_tree = Python2FutureTransformer(future='foo', version=(3, 5)).visit(tree)  # type: ignore
    assert new_tree.body[0].module == 'foo'

# Generated at 2022-06-23 22:53:52.629698
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer._tree_changed == False
    assert transformer.target == (2, 7)


# Generated at 2022-06-23 22:53:54.542597
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    py2FutureTransf = Python2FutureTransformer()
    assert py2FutureTransf.target == (2, 7)


# Generated at 2022-06-23 22:53:55.725230
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-23 22:53:57.104920
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer(target_info=(2,7))

# Generated at 2022-06-23 22:54:05.800416
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    import unittest
    import unittest.mock

    # Patch BaseNodeTransformer:generic_visit
    m_generic_visit = unittest.mock.Mock()
    m_generic_visit.return_value = None
    with unittest.mock.patch('typed_astunparse.transforms.base.BaseNodeTransformer.generic_visit', return_value=m_generic_visit):
        # Test
        # Define test-class
        class Test(unittest.TestCase):
            def test(self):
                x = ast.Module()
                obj = Python2FutureTransformer()
                obj.visit_Module(x)
               

# Generated at 2022-06-23 22:54:12.541985
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Fixing the test with mypy:
    #   all type hints must be specified in the signature of each function, 
    #   so the signature of visit_Module is: visit_Module(self, node) -> ast.Module
    #   but in the body of visit_Module node is used as: node: ast.Module, 
    #   which is a type hint, so mypy complains.  
    #   Fixed by adding: -> ast.Module  to the signature of visit_Module.

    transformer = Python2FutureTransformer()
    module = ast.Module(body=[])  # type: ast.Module
    module = transformer.visit_Module(module)
    assert len(module.body) == 4

# Generated at 2022-06-23 22:54:15.366185
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import parse
    from ..utils.ast_tester import transform, compare_asts

# Generated at 2022-06-23 22:54:16.169145
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass

# Generated at 2022-06-23 22:54:23.464455
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    _tree = '''
    def f():
        pass
    '''
    _orig = ast.parse(_tree)
    _transformer = Python2FutureTransformer()
    _transformer.visit(_orig)
    _expected = '''
    # -*- coding: utf-8 -*-
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    def f():
        pass
    '''
    _expected = ast.parse(_expected)
    assert ast.dump(_orig, include_attributes=False) == ast.dump(_expected, include_attributes=False)

# Generated at 2022-06-23 22:54:34.127366
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    def test_method(code):
        node = ast.parse(code, feature_version=3)
        Python2FutureTransformer().visit(node)
        assert code == imports.get_body(future='__future__') + ast.unparse(node).splitlines()[1:]

    test_method("")
    test_method("def f(): return True\n")
    test_method("f = lambda x: x**2\n")
    test_method("print(9)\n")
    test_method("for i in range(10): print(i)\n")
    test_method("if True: print(1)\n")
    test_method("import numpy as np\n")
    test_method("import numpy\n")
    test_method("import numpy, os\n")

# Generated at 2022-06-23 22:54:36.046038
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer((2, 7)).__class__.__name__ == 'Python2FutureTransformer'


# Generated at 2022-06-23 22:54:41.229695
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3
    from typed_ast import parse

    tree = parse(
'''
x = 100
''')
    result = Python2FutureTransformer().visit(tree)
    expected = ast3.parse(
'''
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
x = 100
'''
    )

    assert ast3.dump(result) == ast3.dump(expected)



# Generated at 2022-06-23 22:54:46.635802
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    source = """
a = 2
b = 3
    """
        
    expected = """
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

a = 2
b = 3
    """
    node = ast.parse(source)
    result = Python2FutureTransformer().visit(ast.parse(source))
    assert astunparse.unparse(result) == expected

# Generated at 2022-06-23 22:54:50.331428
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-23 22:54:55.547891
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast.ast3 import Module
    from typed_ast import ast3 as ast
    trans_cls = Python2FutureTransformer
    assert trans_cls(Module(body=[])).target == (2, 7)
    assert trans_cls(Module(body=[]), options={'target': (2, 7)}).target == (2, 7)



# Generated at 2022-06-23 22:54:59.002658
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    """Method visit_Module of class Python2FutureTransformer."""

    # Arrange
    # Act
    # Assert
    ast.parse("a = 1")

# Generated at 2022-06-23 22:55:02.617481
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    new_node = Python2FutureTransformer().visit(ast.parse('print(1)'))
    assert ast.dump(new_node, annotate_fields=False) == ast.dump(ast.parse(imports + '\nprint(1)'),
                                                                 annotate_fields=False)



# Generated at 2022-06-23 22:55:03.702792
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()

# Generated at 2022-06-23 22:55:04.346574
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass

# Generated at 2022-06-23 22:55:10.627254
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    code = 'print (1)\n'
    module_stmt_list = ast.parse(code)
    transformer = Python2FutureTransformer()
    module_stmt_list_2 = transformer.visit(module_stmt_list)
    module_stmt_list_2 = ast.fix_missing_locations(module_stmt_list_2)
    code2 = compile(module_stmt_list_2, filename='<string>', mode='exec')
    exec(code2)

# Generated at 2022-06-23 22:55:14.281562
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse("x = 3")
    transformer = Python2FutureTransformer()
    node = transformer.visit(node)
    assert(str(node) == "from __future__ import (absolute_import, division, print_function, unicode_literals) \nx = 3")

# Generated at 2022-06-23 22:55:21.317770
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    source = """\
a = 1
b = 2
"""
    expected_source = """\
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
a = 1
b = 2
"""
    compiler = Compiler()
    node = compiler.ast_from_string(source)
    transformer = Python2FutureTransformer()
    transformer.visit_Module(node)
    assert expected_source == compiler.code_from_ast(node)

# Generated at 2022-06-23 22:55:27.668280
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    code = """
        def func(x):
            return x
    """
    expected_code = """
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        
        def func(x):
            return x
    """
    from ..utils.transform_utils import run_transform_class
    node, expected = run_transform_class(Python2FutureTransformer, code, expected_code)
    assert node.body[0] == expected.body[0]
    assert node.body[1] == expected.body[1]

# Generated at 2022-06-23 22:55:30.834968
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Unit test for constructor of class Python2FutureTransformer"""
    transformer = Python2FutureTransformer()
    assert transformer is not None
    assert transformer.target == (2, 7)
    assert transformer._tree_changed is False


# Generated at 2022-06-23 22:55:39.773970
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .test_utils import make_fixture
    from .test_utils import run_test_nodes
    from .test_utils import make_node
    import ast

    class ModuleFixture(make_fixture.ModuleFixture):
        target = (2, 7)

        def make_node(self):
            return make_node.make_body_node()

        def check_transformer(self, transformer):
            assert transformer.tree_changed == True

        def run(self):
            node = self.node
            transformer = Python2FutureTransformer()
            result = transformer.visit(node)
            self.check_result(result)
            self.check_transformer(transformer)


# Generated at 2022-06-23 22:55:47.615465
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .utils import run_module_suite, transform

    code = '''
x = 1
y = 2
        '''
    module = ast.parse(code)
    module2 = transform(module, Python2FutureTransformer)
    # from __future__ import absolute_import; from __future__ import division; from __future__ import print_function; from __future__ import unicode_literals; x = 1; y = 2
    code2 = compile(module2, '', 'exec')
    module3 = run_module_suite(code2)
    assert module3.x == 1
    assert module3.y == 2


if __name__ == "__main__":
    import doctest
    doctest.testmod(optionflags=doctest.ELLIPSIS)

# Generated at 2022-06-23 22:55:57.946145
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    tree = ast.parse('''
    my_var = 42
    def my_func(x, y):
        return x + y
    ''')
    transformer = Python2FutureTransformer(tree)
    result = transformer.visit(tree)

# Generated at 2022-06-23 22:56:04.544908
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.source import source_info

    source_ = source_info(__file__) / '..' / 'code' / 'python2future-import.py'
    tree = ast.parse(source_)
    Python2FutureTransformer().visit(tree)
    print(dump(tree))
    print(source(tree))


if __name__ == '__main__':
    test_Python2FutureTransformer_visit_Module()

# Generated at 2022-06-23 22:56:08.981962
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    original_tree = ast.parse('print("Hello world!")')
    correct_tree = ast.parse('from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n\nprint("Hello world!")')
    assert ast.dump(original_tree) == ast.dump(correct_tree)

# Generated at 2022-06-23 22:56:15.750457
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..parse import parse
    from ..unparse import unparse
    from ..transforms import Python2FutureTransformer
    src = "from foo.bar import Baz"
    result = unparse(Python2FutureTransformer().visit(parse(src)))
    expected = unparse(parse("from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\nfrom foo.bar import Baz"))  # noqa: E501
    assert result == expected

# Generated at 2022-06-23 22:56:25.303699
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_test_module, transform_test_module

    source = """
        #
        # Hello world in Python
        #
        def hello(word):
            print("Hello {}!".format(word))

        if __name__ == "__main__":
            hello("world")
            hello("Python")
    """
    expected_tree = make_test_module(source, target=(3, 7))

    tree = make_test_module(source, target=(2, 7))
    transformer = Python2FutureTransformer()
    actual_tree = transform_test_module(transformer, tree)
    assert expected_tree == actual_tree

# Generated at 2022-06-23 22:56:28.725447
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    '''Unit test for constructor of class Python2FutureTransformer'''
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)



# Generated at 2022-06-23 22:56:37.986893
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3, parse
    from .utils import roundtrip

    #without changes
    source = '''
    def test():
        pass
    '''
    tree = ast3.parse(source)
    Python2FutureTransformer().visit(tree)
    assert roundtrip(tree) == source

    #with changes
    source = '''
    def test():
        print(2)
        print(2 / 6)
    '''
    tree = ast3.parse(source)
    Python2FutureTransformer().visit(tree)

# Generated at 2022-06-23 22:56:45.004398
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..python_tool_test import PythonToolTest
    args = ['--no-debug']
    test = PythonToolTest(Python2FutureTransformer(args), args=args)
    test.test('''
x = 1
print(x)
''', '''
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

x = 1
print(x)
''')

# Generated at 2022-06-23 22:56:51.763723
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.testutils import GenericTest
    g = GenericTest(Python2FutureTransformer)
    g.test('#', '#')
    a = g.test('0', '0')
    assert isinstance(a, ast.Module), type(a)
    g.test('''
print(1)
x = 2
    ''', '''
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

print(1)
x = 2
    ''')

# Generated at 2022-06-23 22:56:57.236666
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    transformer = Python2FutureTransformer({})
    node = ast.Module(body=[ast.Expr(value=ast.Str(s='comment'))])
    expected_module = ast.Module(body=[imports.create_ast(future='__future__')] + node.body)
    transformer.visit(node)
    assert transformer.tree_changed is True
    assert node == expected_module

# Generated at 2022-06-23 22:57:03.099913
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_input = ast.parse('import json')
    module_actual = Python2FutureTransformer.run_pipeline(module_input)
    module_expected = ast.parse('''
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        
        import json''')
    assert ast.dump(module_actual) == ast.dump(module_expected)  # noqa: S101

# Generated at 2022-06-23 22:57:04.270797
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()
    assert t



# Generated at 2022-06-23 22:57:05.459926
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    trans = Python2FutureTransformer()
    assert trans.target == (2, 7)


# Generated at 2022-06-23 22:57:06.825146
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == "Python2FutureTransformer"
    assert callable(Python2FutureTransformer)


# Generated at 2022-06-23 22:57:16.454754
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..visitor import visit
    from .. import parse

    code = """print(123)"""
    node = parse(code)
    visit(Python2FutureTransformer(), node)
    assert node.body[0].value.s == '__future__'  # type: ignore
    assert node.body[1].value.s == '__future__'  # type: ignore
    assert node.body[2].value.s == '__future__'  # type: ignore
    assert node.body[3].value.s == '__future__'  # type: ignore
    assert node.body[4].body[0].values[0].value == 123  # type: ignore

# Generated at 2022-06-23 22:57:21.578433
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ast_tools.transformers.future import Python2FutureTransformer
    node = ast.parse('print(1)')
    Python2FutureTransformer().visit(node)
    assert node == ast.parse('from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\nprint(1)')

# Generated at 2022-06-23 22:57:25.123942
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()
    # pylint: disable=no-member
    assert isinstance(t, Python2FutureTransformer)
    assert t.target == (2, 7)


# Generated at 2022-06-23 22:57:26.252420
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    obj = Python2FutureTransformer()
    assert isinstance(obj, Python2FutureTransformer)



# Generated at 2022-06-23 22:57:27.311783
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-23 22:57:29.244411
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert issubclass(Python2FutureTransformer, BaseNodeTransformer)
    assert isinstance(Python2FutureTransformer(), BaseNodeTransformer)


# Generated at 2022-06-23 22:57:33.392390
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..testing_utils import make_test_module

    test_module = make_test_module(__file__, Python2FutureTransformer.__name__)

    assert test_module.__dict__[Python2FutureTransformer.__name__]._tree_changed == True
    assert test_module.__dict__[Python2FutureTransformer.__name__]._future == '__future__'

# Generated at 2022-06-23 22:57:40.749401
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse(textwrap.dedent("""
        import os
        import sys
        
        class Example:
            pass
    """))
    assert ast.dump(Python2FutureTransformer(node).visit(node)) == ast.dump(ast.parse(textwrap.dedent("""
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        import os
        import sys

        class Example:
            pass
    """)))

# Generated at 2022-06-23 22:57:42.118564
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    node = ast.parse('class C: pass')
    print(astor.to_source(Python2FutureTransformer.run(node)))

# Generated at 2022-06-23 22:57:43.100943
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor
    

# Generated at 2022-06-23 22:57:53.441194
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils import make_test_tree
    module = make_test_tree()
    res = Python2FutureTransformer().visit(module)  # type: ignore

# Generated at 2022-06-23 22:58:03.435973
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3
    from typed_ast import convert

    # Set up the node to be tested
    module = ast.Module(
        body=[
            ast.Expr(
                value=ast.Str(
                    s='S'
                )
            )
        ]
    )

    # Set up the expected node.

# Generated at 2022-06-23 22:58:04.344814
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()


# Generated at 2022-06-23 22:58:05.709631
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    trans = Python2FutureTransformer()
    assert trans is not None


# Generated at 2022-06-23 22:58:11.945647
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import unittest
    import sys
    from types import ModuleType
    from astor import codegen
    from six import PY2

    from ast_converter import pyconv
    from ast_converter.node_recipes import ModuleRecipe

    class Test(unittest.TestCase):
        def test_nonpy3(self):
            if PY2:
                pyconv.register(Python2FutureTransformer)
                result = pyconv.to_target(target_version=sys.version_info)
                self.assertIsInstance(result, ModuleType)
                self.assertIn("from __future__ import print_function", codegen.to_source(result))

    return Test



# Generated at 2022-06-23 22:58:18.770070
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source

    _source = source(__file__)
    _source = _source.replace(
        '@snippet', '# @snippet'
    ).replace(
        'from ..utils.snippet import snippet', ''
    ).replace(
        'from ..utils.source import source', ''
    )

    assert Python2FutureTransformer(_source).result == _source.replace('# @snippet', '@snippet')

# Generated at 2022-06-23 22:58:19.715223
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer # Using just to test constructor

# Generated at 2022-06-23 22:58:22.904237
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..testing import check_visitor_method
    check_visitor_method(Python2FutureTransformer,
                         'visit_Module',
                         expected_method_name='Python2FutureTransformer.visit_Module',
                         context_key='store_new_context')