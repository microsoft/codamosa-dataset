

# Generated at 2022-06-23 22:48:25.985662
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .test_utils import _test_visit_Module
    _test_visit_Module([
        '''
        import itertools, math
        import random
        '''
    ],
        [
            '''
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
            
        import itertools, math
        import random
        '''
        ],
        Python2FutureTransformer)



# Generated at 2022-06-23 22:48:30.346792
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from api import transform

    transformer = Python2FutureTransformer()

    with open('snippets/api.py') as f:
        tree = ast.parse(f.read())

    assert not transformer._tree_changed
    tree = transformer.visit(tree)
    assert transformer._tree_changed



# Generated at 2022-06-23 22:48:35.734118
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # method visit_Module should prepend module with:
    #     from __future__ import absolute_import
    #     from __future__ import division
    #     from __future__ import print_function
    #     from __future__ import unicode_literals
    from typed_ast import ast3 as ast
    from .utils import parse, roundtrip, compare_ast
    tree = parse("pass")
    old = Python2FutureTransformer().visit(tree)

# Generated at 2022-06-23 22:48:37.363696
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    x = Python2FutureTransformer(2, 7, {}, {})
    assert isinstance(x, Python2FutureTransformer)
    assert isinstance(x, BaseNodeTransformer)

# Generated at 2022-06-23 22:48:48.415414
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse('import os')
    transformer = Python2FutureTransformer()
    transformer.visit(node)
    assert transformer.tree_changed
    assert ast.dump(node) == \
"""
Module(body=[
    ImportFrom(module='__future__', names=[
        alias(
            name='absolute_import',
            asname=None),
        alias(
            name='division',
            asname=None),
        alias(
            name='print_function',
            asname=None),
        alias(
            name='unicode_literals',
            asname=None)],
        level=0),
    Import(names=[alias(
        name='os',
        asname=None)])])
"""

# Generated at 2022-06-23 22:48:53.890358
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    """Snippet:
        import os

    Expected result:
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        import os
    """
    tree = ast.parse('import os')
    Python2FutureTransformer().visit(tree)
    dump_tree(tree)


# Generated at 2022-06-23 22:48:55.471244
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer().target == (2, 7)

# Generated at 2022-06-23 22:49:01.967561
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    node = ast.parse("""\
        # comment line
        import os, sys

        print(__name__)
    """)
    assert Python2FutureTransformer().visit(node) == ast.parse("""\
        # comment line
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        import os, sys

        print(__name__)
    """)

# Generated at 2022-06-23 22:49:11.934305
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Given
    from ..Case import Case
    from .. import transforms

    # When
    case = Case(transforms=[Python2FutureTransformer])
    case.load_code('''
    from __future__ import annotations
    from __future__ import bar as xyz
    bar = 3
    if bar:
        bar = 6
    bar += 3
    bar()
    bar.baz
    ''')
    case.transform()

    # Then
    assert case.module.body[0].value.args[0].value.id == '__future__'
    assert case.module.body[1].value.id == '__future__'
    assert case.module.body[2].target.id == 'bar'
    assert case.module.body[3].test.id == 'bar'
    assert case.module.body

# Generated at 2022-06-23 22:49:16.981559
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    
    import astor
    from typed_ast import ast2 as ast2  # type: ignore
    
    src = """
print 1, 2
"""
    expected = """
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

print 1, 2
"""
    tree = ast.parse(src)
    tree2 = Python2FutureTransformer().visit(tree)
    result = astor.to_source(tree2)
    assert result == expected

# Generated at 2022-06-23 22:49:21.610435
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    trans: Python2FutureTransformer = Python2FutureTransformer()
    assert trans.visit_Module
    
    
from ..utils import (
    run_transformer,
    mock_file_system,
    compare_ast,
)

# Unit test Python2FutureTransformer.visit_Module()

# Generated at 2022-06-23 22:49:22.925592
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.target == (2, 7)

# Generated at 2022-06-23 22:49:25.741865
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .. import test_util
    from ast_utils.transformers import transform
    var_a = ast.Name('a', ast.Load())
    var_b = ast.Name('b', ast.Load())


# Generated at 2022-06-23 22:49:30.274663
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    source = """print('Hello World!')"""
    source_code = compile(source, '<string>', 'exec', ast.PyCF_ONLY_AST)
    tree = ast.parse(source_code)

    # Act
    p2ft = Python2FutureTransformer()
    p2ft.visit(tree)
    result = astor.to_source(tree)

    # Assert
    expected = """\
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

print('Hello World!')
"""
    assert result == expected



# Generated at 2022-06-23 22:49:40.133036
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ast_tools import ast_to_source
    module = ast.parse(textwrap.dedent('''
    import numpy as np
    import os.path as op
    np.random.seed(42)
    '''))
    transformer = Python2FutureTransformer()
    transformer.visit(module)
    source = ast_to_source(module)
    expected = textwrap.dedent('''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    import numpy as np
    import os.path as op
    np.random.seed(42)
    ''')
    assert source == expected

# Generated at 2022-06-23 22:49:45.048956
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    '''
    Check if the constructor of class Python2FutureTransformer creates a 
    object of class Python2FutureTransformer
    '''
    # Arrange
    # Nothing to arrange

    # Act
    python2_future_transformer = Python2FutureTransformer()

    # Assert
    assert isinstance(python2_future_transformer, Python2FutureTransformer)


# Generated at 2022-06-23 22:49:51.308795
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    sample = """\
        for i in range(10):
           print(i)
    """
    expected = """\
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        for i in range(10):
           print(i)
    """
    t = Python2FutureTransformer()
    tree_changed = t.visit(ast.parse(sample))
    assert tree_changed == True
    code = t.to_source()
    assert code == expected

# Generated at 2022-06-23 22:50:02.004030
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.test_utils import _assert_tree_equal
    from .test_utils import transform, _compare_source

    _compare_source(
        Python2FutureTransformer,
        "from __future__ import print_function, division\na = 1\nprint(a)",
        "from __future__ import print_function, division\na = 1\nprint(a)"
    )
    _compare_source(
        Python2FutureTransformer,
        "a = 1\nprint(a)",
        "from future import absolute_import\nfrom future import division\nfrom future import print_function\nfrom future import unicode_literals\na = 1\nprint(a)"
    )

# Generated at 2022-06-23 22:50:05.563077
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Tests for method Python2FutureTransformer.__init__"""
    p2ft = Python2FutureTransformer()
    #assert(p2ft.target == (2, 7))
    assert(p2ft.target == (3, 6))

# Generated at 2022-06-23 22:50:12.112676
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    class Test(unittest.TestCase):
        def test_simple(self):
            tree = ast.parse("print(1, 2, True)\n")
            transformer = Python2FutureTransformer()
            transformer.visit(tree)

            self.assertEqual("""from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
print(1, 2, True)
""", tree_to_str(tree))

    unittest.main()

# Generated at 2022-06-23 22:50:17.802352
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from pprint import pprint
    from typed_ast import ast3 as ast

    transformer = Python2FutureTransformer(tree=None)
    node = ast.Module(body=[
        ast.Import(names=[ast.alias(name='six', asname=None)]),
        ast.ImportFrom(module='__future__',
                       names=[ast.alias(name='unicode_literals', asname=None)],
                       level=0)
    ])
    result = transformer.visit_Module(node)

# Generated at 2022-06-23 22:50:26.427019
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import textwrap
    from .ast_converter import ast_to_text
    from .bakery_test_case import BakeryTestCase

    source = textwrap.dedent("""
    import os
    import sys
    
    def main():
        pass

    if __name__ == "__main__":
        main()        
    """)
    target = textwrap.dedent("""
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    
    import os
    import sys
    
    def main():
        pass

    if __name__ == "__main__":
        main()        
    """)


# Generated at 2022-06-23 22:50:29.927168
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    '''
    It tests the constructor of Python2FutureTransformer.
    '''
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)
    assert transformer._tree_changed == False


# Generated at 2022-06-23 22:50:39.123970
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import_1 = ast.ImportFrom(module='__future__',
                              names=[ast.alias(name='absolute_import', asname=None)], level=0)
    import_2 = ast.ImportFrom(module='__future__',
                              names=[ast.alias(name='division', asname=None)], level=0)
    import_3 = ast.ImportFrom(module='__future__',
                              names=[ast.alias(name='print_function', asname=None)], level=0)
    import_4 = ast.ImportFrom(module='__future__',
                              names=[ast.alias(name='unicode_literals', asname=None)], level=0)
    module = ast.Module([import_1, import_2, import_3, import_4])
    assert Python2FutureTransformer

# Generated at 2022-06-23 22:50:47.386091
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from .base import BaseTestCase
    from .base import node
    from .base import python2

    expected = '''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    a = 1
    '''

    class Test(BaseTestCase):
        target = python2(2, 7)
        transform = Python2FutureTransformer
        goal = {'a': 1}

    assert Test({'a': 1}) == expected

# Generated at 2022-06-23 22:50:51.111555
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    x = Python2FutureTransformer()
    assert x.target == (2,7)  # target should be a tuple (2,7)
    assert x.visit_Module # visit_Module should be defined
    # assert x.generic_visit # generic_visit should NOT be defined

# Generated at 2022-06-23 22:50:53.330294
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import sys
    from astor import to_source
    from astmonkey import transformers
    import ast

    x = __file__.replace("\\", '/').split('/')[-1].split('.')[0]

# Generated at 2022-06-23 22:50:53.950283
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-23 22:51:00.155447
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    method_test_data = [
        ('print_function', ('print_function',)),
        ('print_function;unicode_literals', ('print_function', 'unicode_literals')),
        ('absolute_import,print_function', ('absolute_import', 'print_function')),
        ('print_function,unicode_literals', ('print_function', 'unicode_literals')),
        ('absolute_import;division;print_function;unicode_literals', ('absolute_import', 'division', 'print_function', 'unicode_literals'))
    ]

    for test_data in method_test_data:
        module = ast.parse('pass', mode='exec')
        transformer = Python2FutureTransformer(module)
        future_arg_string = test_data[0]

# Generated at 2022-06-23 22:51:07.332577
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()
    node = ast.parse(textwrap.dedent('''\
    def f():
        pass
    '''), '<file>', 'exec')
    res = transformer.visit(node)
    expected = textwrap.dedent('''\
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    
    
    def f():
        pass
    ''')
    assert astor.to_source(res) == expected

# Generated at 2022-06-23 22:51:14.138060
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import ast
    node = ast.parse('')
    res = Python2FutureTransformer().visit_Module(node)
    import textwrap
    assert textwrap.dedent('''
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        ''').strip() == ast.unparse(res).strip()

# Generated at 2022-06-23 22:51:22.280559
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Python2FutureTransformer should prepend a module with the following future imports:
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
    """
    # Arrange
    from ..utils.source import source
    from ..utils.ast import get_ast
    target_ast = get_ast(
        """
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        import sys
        """
    )
    original_ast = get_ast(source("""
    import sys
    """))
    transformer = Python2FutureTransformer()

    # Act
    new_ast = transformer.visit(original_ast)

# Generated at 2022-06-23 22:51:23.779901
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-23 22:51:29.645054
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    source = 'import os'
    expected = 'from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n\nimport os'
    node = ast.parse(source)
    python2_future = Python2FutureTransformer()
    result = astor.to_source(python2_future.visit(node))
    assert result == expected

# Generated at 2022-06-23 22:51:31.562098
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    class SampleTransformer1(Python2FutureTransformer):
        pass

    assert SampleTransformer1.target == (2, 7)
    assert SampleTransformer1._version_info == (2, 7)



# Generated at 2022-06-23 22:51:34.946414
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    mod = ast.parse("x = 1 + 2")
    t = Python2FutureTransformer()
    mod = t.visit(mod)
    future_imports = mod.body[0:4]
    assert len(future_imports) == 4
    assert future_imports[0].module == "future"
    assert future_imports[1].module == "future"
    assert future_imports[2].module == "future"
    assert future_imports[3].module == "future"

# Generated at 2022-06-23 22:51:45.060024
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    node=ast.parse('def f(): pass')
    
    c = Python2FutureTransformer()
    c.visit(node)
    

# Generated at 2022-06-23 22:51:46.242609
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    tr = Python2FutureTransformer()
    assert tr

# Generated at 2022-06-23 22:51:47.219986
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-23 22:51:48.801193
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert isinstance(Python2FutureTransformer, object)


# Generated at 2022-06-23 22:51:51.544986
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    x = Python2FutureTransformer()
    assert isinstance(x, Python2FutureTransformer)
    assert isinstance(x, BaseNodeTransformer)



# Generated at 2022-06-23 22:51:54.306627
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from . import test_utils
    test_utils.mock_future_for_test(Python2FutureTransformer)


# vim: ts=4 sw=4 sts=4 expandtab

# Generated at 2022-06-23 22:52:02.059838
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from .unary_module import UnaryModuleTransformer
    from .unary_class import UnaryClassTransformer
    from .unary_function import UnaryFunctionTransformer
    from .unary_statement import UnaryStatementTransformer
    from .unary_expression import UnaryExpressionTransformer
    from .unary_operator import UnaryOperatorTransformer
    from .unary_attribute import UnaryAttributeTransformer
    from .unary_argument import UnaryArgumentTransformer
    from .unary_subscript import UnarySubscriptTransformer
    from .unary_except import UnaryExceptTransformer
    from .unary_keyword import UnaryKeywordTransformer
    from .unary_slice import UnarySliceTransformer
    from .unary_alias import UnaryAliasTransformer
    from .unary_with import Un

# Generated at 2022-06-23 22:52:07.064809
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # Test constructed Python2FutureTransformer
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer.target == (2, 7)
    assert Python2FutureTransformer.pkg_name == 'nuitka_future'
    assert Python2FutureTransformer.version == '0.0.1'
    assert Python2FutureTransformer.dependencies == []

# Generated at 2022-06-23 22:52:17.324294
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import typing
    from typed_ast import ast3
    if typing.TYPE_CHECKING:
        import astor
    class TestVisitor1(ast3.NodeVisitor):
        def visit_Module(self, node: ast3.Module) -> ast3.Module:
            return self.visit_body(node)
    visitor = TestVisitor1()
    trans = Python2FutureTransformer()
    mod = trans.visit(ast3.parse('''
# Comments here
a = 1
b = 1 + 2 * 3
c = 'str'
'''))
    assert isinstance(mod, ast3.Module)
    # astor.dump(mod)  # use this method to see the details of the AST object
    visitor.visit(mod)  # just to see no exception is raised

# Generated at 2022-06-23 22:52:27.767469
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    node = ast.parse("test")
    transformer = Python2FutureTransformer()
    result = transformer.visit(node)
    assert isinstance(node, ast.Module)
    assert transformer._tree_changed is True
    assert isinstance(result, ast.Module)
    assert isinstance(result.body[0], ast.ImportFrom)
    assert result.body[0].module == "future"
    assert result.body[0].names[0].name == "absolute_import"
    assert result.body[1].module == "future"
    assert result.body[1].names[0].name == "division"
    assert result.body[2].module == "future"
    assert result.body[2].names[0].name == "print_function"

# Generated at 2022-06-23 22:52:29.404563
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    return isinstance(transformer, Python2FutureTransformer)


# Generated at 2022-06-23 22:52:37.294812
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    from typed_ast.ast3 import parse
    from ..utils.ast_inspector import AstInspector

    python2_code = """
    # Some Python code
    if a:
        print(a)
    """
    transformed = Python2FutureTransformer().visit(parse(python2_code))
    ast_lines = astor.to_source(transformed).split('\n')
    print(astor.to_source(transformed))
    assert AstInspector(transformed).get_imports() == {'__future__': ['absolute_import', 'division', 'print_function', 'unicode_literals']}

# Generated at 2022-06-23 22:52:42.821362
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    input = u'''\
# -*- coding: utf-8 -*-
abc
def
'''
    output = u'''\
# -*- coding: utf-8 -*-
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
abc
def
'''
    assert Python2FutureTransformer(input).result == output

# Generated at 2022-06-23 22:52:53.825591
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typing import List, Tuple

    import pytest
    from typed_ast.ast3 import parse, Module, ImportFrom
    from flake8_future_import.utils import normalize_code

    # Transformer
    transformer = Python2FutureTransformer(tree=None)

    # Input: No __future__ import
    old_code = """
print('test')
"""
    # Expected output: 
    expected_code = """
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

print('test')
"""
    old_tree = parse(old_code)
    new_tree = transformer.visit(old_tree)  # type: ignore

# Generated at 2022-06-23 22:53:03.927166
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # create instance
    t = Python2FutureTransformer()

    # check its name
    assert t.__class__.__name__ == 'Python2FutureTransformer'

    # check its docstring
    assert t.__doc__ == """Prepends module with:
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
    """

    # check the value of target
    assert t.target == (2, 7)

    # check that visit_Module is defined
    assert callable(getattr(t, 'visit_Module', None))

    # check that generic_visit is defined
    assert callable(getattr(t, 'generic_visit', None))

    # check that visit_Module is callable
    assert call

# Generated at 2022-06-23 22:53:08.704695
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():  # noq: F811
    class _MockNode(object):
        def __init__(self, body=None):
            self.body = body
    node = _MockNode()
    t = Python2FutureTransformer()
    t.visit_Module(node)
    imports_body = imports.get_body(future='__future__')
    assert node.body == imports_body


# Generated at 2022-06-23 22:53:10.069805
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    x = Python2FutureTransformer()
    assert x.target == (2, 7)


# Generated at 2022-06-23 22:53:15.105846
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor
    from typed_ast import ast3 as ast
    
    source = """
with x, y as z:
    pass
    """
    tree = ast.parse(source)
    Python2FutureTransformer().visit(tree)
    assert astor.to_source(tree) == '\n'.join([
        'from __future__ import absolute_import',
        'from __future__ import division',
        'from __future__ import print_function',
        'from __future__ import unicode_literals',
        '',
        'with x, y as z:',
        '    pass',
    ])

# Generated at 2022-06-23 22:53:25.712154
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.source import source

    # Python 2 code
    s = source('''
        def foo():
            return 0
        ''')
    tr = Python2FutureTransformer()
    root = ast.parse(s)
    tr.visit(root)
    assert s == 'def foo():\n    return 0\n'
    assert ast.dump(root) == imports.get_ast(future='__future__') + \
                             '''\
Module(body=[FunctionDef(name='foo', args=arguments(args=[], vararg=None, kwarg=None, defaults=[]), body=[Return(value=Num(n=0))], decorator_list=[], returns=None)])
'''


# Generated at 2022-06-23 22:53:32.381986
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():  # noqa
    from typed_ast import ast3 as ast
    source = """del abc"""
    tree = ast.parse(source)
    Python2FutureTransformer().visit(tree)

    expected = """from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals


del abc"""
    assert(expected == astor.to_source(tree))  # type: ignore



# Generated at 2022-06-23 22:53:34.986991
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a = Python2FutureTransformer()
    assert(isinstance(a, Python2FutureTransformer))
    assert(isinstance(a, BaseNodeTransformer))


# Generated at 2022-06-23 22:53:45.392281
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    m = ast.parse("""\
import pycuda.autoinit
import pycuda.driver as drv
import numpy

if False:
    print("This is a dummy if block, as we do not want to to the initialization when running this test") # pylint disable=C0325
""")

    transformer = Python2FutureTransformer()
    transformer.visit(m)
    m = transformer.get_module()


# Generated at 2022-06-23 22:53:50.273861
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    s = """x = [1, 2, 3]"""
    expected = """from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

x = [1, 2, 3]"""
    actual = Python2FutureTransformer().visit(ast.parse(s))
    assert ast.dump(ast.parse(expected)) == ast.dump(actual)

# Generated at 2022-06-23 22:53:57.295132
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from .. import transform
    from . import sample_transformed_source
    source = """
        def foo():
            import os
    """
    expected = """
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        def foo():
            import os
    """
    transformed = sample_transformed_source(source, transform(source, Python2FutureTransformer))
    assert transformed == expected

# Generated at 2022-06-23 22:54:05.901460
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from six import exec_
    from astmonkey import transformers
    from ..utils.tree_compare import compare_ast
    import sys
    import os
    import tempfile
    import shutil

    class_file_path = os.path.join(sys.path[0], 'templates', 'class.py')
    with open(class_file_path, 'r') as class_file:
        class_source = class_file.read()

    node = ast.parse(class_source)
    transformer = Python2FutureTransformer()
    transformer.visit(node)
    expected_node = ast.Module(body=transformers.ParentChildNodeTransformer(Python2FutureTransformer.imports()).visit(node.body))
    print(ast.dump(node))
    print(ast.dump(expected_node))
   

# Generated at 2022-06-23 22:54:12.160772
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()
    src = dedent(
        """\
        print("Hello World")
        """
    )
    expected_dst = dedent(
        """\
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        print("Hello World")
        """
    )
    transformer.visit(ast.parse(src))
    dst = astunparse.unparse(transformer.module)  # type: ignore
    assert dst == expected_dst

# Generated at 2022-06-23 22:54:20.526307
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer.__doc__ == \
        'Prepends module with:\n' +\
        '    from __future__ import absolute_import\n' +\
        '    from __future__ import division\n' +\
        '    from __future__ import print_function\n' +\
        '    from __future__ import unicode_literals\n' +\
        '        \n' +\
        '    '
    assert Python2FutureTransformer.target == (2, 7)


# Generated at 2022-06-23 22:54:22.314435
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Test case: check if the instance of class Python2FutureTransformer can be initialized"""
    Python2FutureTransformer()

# Generated at 2022-06-23 22:54:22.921145
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    pass

# Generated at 2022-06-23 22:54:30.221328
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor
    vtransformer = Python2FutureTransformer()
    valid_ast = ast.parse("")
    vtransformer.visit(valid_ast)
    code = astor.to_source(valid_ast)
    assert "from __future__ import absolute_import" in code
    assert "from __future__ import division" in code
    assert "from __future__ import print_function" in code
    assert "from __future__ import unicode_literals" in code

# Generated at 2022-06-23 22:54:33.241494
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Unit test for constructor of `Python2FutureTransformer` class."""
    node = ast.parse("class Test(object): pass")
    transformer = Python2FutureTransformer(target_version=(2, 7))
    transformer.visit(node)

# Generated at 2022-06-23 22:54:36.949560
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()
    node = ast.parse('pass')
    result = transformer.visit(node)
    imports_node = ast.Module(body=imports.get_body(future='__future__'))
    expected = imports_node
    assert result == expected


# Generated at 2022-06-23 22:54:40.941387
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .test_utils import make_test_data
    from .test_utils import transform_snippets
    
    source, expected_source = make_test_data(__file__, 0)
    tree = ast.parse(source)
    new_tree = transform_snippets(tree, Python2FutureTransformer)

    assert ast.dump(new_tree) == expected_source



# Generated at 2022-06-23 22:54:45.379118
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    from ..utils.fixtures import UnittestCase
    from ..utils.source import source
    from ..utils.ast_compare import compare_nodes
    from ..utils.source import parse

    class TestCase(UnittestCase):
        def test(self):
            super(TestCase, self).setUp()

# Generated at 2022-06-23 22:54:48.718985
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import typed_ast.ast3 as ast
    tree = ast.parse(imports)
    node = Python2FutureTransformer().visit(tree)
    expected = ast.parse(imports)
    assert ast.dump(node, include_attributes=True) == ast.dump(expected, include_attributes=True)

# Generated at 2022-06-23 22:54:55.549317
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.test_utils import assert_source
    source = 'x = 1\n'
    expected = 'from __future__ import absolute_import\n' \
               'from __future__ import division\n' \
               'from __future__ import print_function\n' \
               'from __future__ import unicode_literals\n' \
               '\n' \
               'x = 1\n'
    assert_source(source, expected, Python2FutureTransformer)


# Generated at 2022-06-23 22:55:00.413839
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    target = (2, 7)
    transformer = Python2FutureTransformer(target=target)
    tree = transformer.visit(transformer.parse_snippet('a = 1 + 2\n'))
    assert transformer._tree_changed == True
    assert transformer.get_tree_string(tree) == ('from __future__ import '
        'absolute_import\nfrom __future__ import division\nfrom __future__ imp'
        'ort print_function\nfrom __future__ import unicode_literals\n\na = 1 '
        '+ 2\n')




# Generated at 2022-06-23 22:55:05.028010
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor 
    mod = ast.parse("print('hello world')")
    mod.body = Python2FutureTransformer().visit(mod).body # type: ignore
    code = astor.to_source(mod)
    assert code.startswith('from __future__ import absolute_import')

# Generated at 2022-06-23 22:55:06.213732
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()


# Generated at 2022-06-23 22:55:06.965432
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-23 22:55:14.527258
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()
    tree = ast.parse(textwrap.dedent("""\
        from future import absolute_import

        import mypackage.mymodule
        import mypackage.myothermodule
    """))
    transformer.visit(tree)

    assert tree == ast.parse(textwrap.dedent("""\
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        from future import absolute_import

        import mypackage.mymodule
        import mypackage.myothermodule
    """))

# Generated at 2022-06-23 22:55:15.266080
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass

# Generated at 2022-06-23 22:55:23.836109
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast

    t = Python2FutureTransformer()
    node = ast.parse('a = 1')  # type: ignore
    t.visit(node)
    assert t._tree_changed == True

# Generated at 2022-06-23 22:55:34.082350
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    input = """\
            from __future__ import nested_scopes
            from __future__ import generators
            from __future__ import division 
            from __future__ import absolute_import
            from __future__ import print_function
            from __future__ import with_statement
            from __future__ import unicode_literals
            """
    output = """\
            from future import nested_scopes
            from future import generators
            from future import division 
            from future import absolute_import
            from future import print_function
            from future import with_statement
            from future import unicode_literals"""
    node = astor.parse_file(input)
    tree = Python2FutureTransformer().visit(node)
    assert astor.code_gen.to_source(tree) == output



# Generated at 2022-06-23 22:55:35.757625
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # type: () -> None
    t = Python2FutureTransformer()
    assert t is not None

# Generated at 2022-06-23 22:55:37.362764
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import ast
    import astor


# Generated at 2022-06-23 22:55:40.217713
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    t = Python2FutureTransformer()
    module = ast.parse('print("hello!")')
    t.visit(module)
    assert t._tree_changed == True


# Generated at 2022-06-23 22:55:42.747042
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.visitor_test import visit_test
    from .python2 import Python2Transformer
    from .remove_u import RemoveUTransformer

    transformer = Python2FutureTransformer(Python2Transformer(RemoveUTransformer()))
    visit_test(transformer)

# Generated at 2022-06-23 22:55:48.490800
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    futur = ast.parse('from __future__ import absolute_import')
    mod = ast.parse('pass')
    transformer = Python2FutureTransformer()
    new_mod = transformer.visit(mod)
    assert isinstance(new_mod, ast.Module)
    assert len(new_mod.body) == 5
    assert new_mod.body[0] == futur.body[0]
    for node in new_mod.body[1:]:
        assert isinstance(node, ast.ImportFrom)
        assert node.module == '__future__'


# Generated at 2022-06-23 22:55:55.691888
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast.ast3 import parse
    tree = parse("""mode = "tree"
print(mode)
""")
    v = Python2FutureTransformer()
    res = v.visit(tree)
    expected = parse("""from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
mode = "tree"
print(mode)
""")
    assert ast.dump(res) == ast.dump(expected)



# Generated at 2022-06-23 22:55:56.261385
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert 1 == 1

# Generated at 2022-06-23 22:55:57.898305
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer


# Generated at 2022-06-23 22:55:59.731162
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    p2tf = Python2FutureTransformer()
    assert p2tf.target == (2, 7)



# Generated at 2022-06-23 22:56:00.713326
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer()


# Generated at 2022-06-23 22:56:04.213697
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # Test that the target versions are correct
    assert Python2FutureTransformer.target == (2, 7)

    # Test that the transformer for this version is selected
    transformer = Python2FutureTransformer.factory(2, 7)
    assert isinstance(transformer, Python2FutureTransformer)

# Generated at 2022-06-23 22:56:05.538475
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()

# Generated at 2022-06-23 22:56:11.931028
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast

    node = ast.Module([
        ast.FunctionDef(
            name='foo',
            args=ast.arguments(
                args=[
                    ast.arg(arg='bar', annotation=None),
                ],
                vararg=None,
                kwarg=None,
                kwonlyargs=[],
                kw_defaults=[],
                defaults=[],
            ),
            body=[
                ast.Return(value=ast.Num(n=1)),
            ],
            decorator_list=[],
            returns=None,
        ),
    ], type_ignores=[])

    result = Python2FutureTransformer().visit(node)

    assert isinstance(result, ast.Module)
    assert isinstance(result.body[0], ast.ImportFrom)



# Generated at 2022-06-23 22:56:15.884402
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils import compare_ast
    from .. import snippets

    module = ast.parse(snippets.MODULE)
    module_transformed = ast.parse(snippets.MODULE_FUTURE_PY2)
    node_transformer = Python2FutureTransformer()
    assert node_transformer(module) != module
    assert compare_ast(node_transformer(module), module_transformed)

# Generated at 2022-06-23 22:56:17.471716
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.tester import assert_node


# Generated at 2022-06-23 22:56:19.030826
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import six
    # Get code object

# Generated at 2022-06-23 22:56:21.673325
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-23 22:56:26.023202
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    class_ = Python2FutureTransformer(2.7)
    assert class_.target == (2, 7)
    assert not class_._tree_changed
    class_.visit(ast.Module)
    assert class_._tree_changed

# Generated at 2022-06-23 22:56:28.725417
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    return (
        Python2FutureTransformer()
        is not None
    )


# Generated at 2022-06-23 22:56:29.820283
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer

# Generated at 2022-06-23 22:56:34.893352
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    s = {
        '__future__': 'from __future__ import absolute_import',
        'print_function': 'from __future__ import print_function',
        'division': 'from __future__ import division',
        'unicode_literals': 'from __future__ import unicode_literals'
    }

# Generated at 2022-06-23 22:56:39.680113
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    p = Python2FutureTransformer()
    t = astor.code_to_ast(
        """
        def t():
            pass
    """.strip()
    )
    t = p.visit(t)

# Generated at 2022-06-23 22:56:46.404370
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    T = Python2FutureTransformer()
    # case 1 with empty module
    root = ast.parse('', '<string>', 'exec')
    nroot = T.visit(root)
    assert len(nroot.body) == 4

    # case 2 with module with one node
    root = ast.parse('class Foo:\n    pass', '<string>', 'exec')
    nroot = T.visit(root)
    assert len(nroot.body) == 5

# Generated at 2022-06-23 22:56:50.632618
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = ast.parse('gibberish', mode='eval')
    transformer = Python2FutureTransformer()
    module = transformer.visit(module)
    assert isinstance(module, ast.Module)
    assert isinstance(module.body[0], ast.ImportFrom)
    assert isinstance(module.body[1], ast.ImportFrom)
    assert isinstance(module.body[2], ast.ImportFrom)
    assert isinstance(module.body[3], ast.ImportFrom)
    assert isinstance(module.body[4], ast.Expr)

# Generated at 2022-06-23 22:56:52.145642
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    x = Python2FutureTransformer(2, 7, 'mock')
    assert x.target == (2, 7)

# Generated at 2022-06-23 22:57:01.388546
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    code = '''
a = 1
b = 2
c = 3
'''
    node = ast.parse(code)

    transformer = Python2FutureTransformer(None)
    new_node = transformer.visit(node)

    # from future import absolute_import
    # from future import division
    # from future import print_function
    # from future import unicode_literals

    # a = 1
    # b = 2
    # c = 3

    # The output code should include __future__ imports
    assert len(new_node.body) == 8, 'The number of body elements is wrong'
    assert isinstance(new_node.body[0], ast.ImportFrom), 'The fist body element is not an ast.ImportFrom'

# Generated at 2022-06-23 22:57:09.855814
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    from typing import List
    from ..utils import evaluate_transformation

    source = '''
if True:
    def f(x) -> int:
        return x + 1
    '''
    tree = ast.parse(source)

    module, _, _ = evaluate_transformation(Python2FutureTransformer, tree)
    assert isinstance(module, ast.Module)
    assert "from __future__ import absolute_import" in astor.to_source(module)
    assert "from __future__ import division" in astor.to_source(module)
    assert "from __future__ import print_function" in astor.to_source(module)
    assert "from __future__ import unicode_literals" in astor.to_source(module)

# Generated at 2022-06-23 22:57:19.179403
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .. import util
    from .. import parse
    from . import python_future

    module = parse.parse(util.example_path(python_future.__file__, 'future_module.py'))
    assert len(module.body) == 1
    assert isinstance(module.body[0], ast.Expr)

    transformer = Python2FutureTransformer()
    transformer.visit(module)
    assert len(module.body) == 5
    assert isinstance(module.body[0], ast.ImportFrom)
    assert isinstance(module.body[1], ast.ImportFrom)
    assert isinstance(module.body[2], ast.ImportFrom)
    assert isinstance(module.body[3], ast.ImportFrom)
    assert isinstance(module.body[4], ast.Expr)
    assert transformer._tree_

# Generated at 2022-06-23 22:57:22.595964
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()
    assert t.target == (2, 7)
    assert t.context is None
    assert t._tree_changed == False


# Generated at 2022-06-23 22:57:23.633011
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()  # no err

# Generated at 2022-06-23 22:57:27.490256
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # test_ast
    source = """
a = 1
b = 'a'
c = a + b
    """
    node = ast.parse(source)
    new_node = Python2FutureTransformer().visit(node)
    assert isinstance(new_node, ast.Module)

# Generated at 2022-06-23 22:57:31.867766
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .test_base_node_transformer import \
        sample_module, assert_module_equal, \
        expected, copy_of

    original_ast = sample_module()
    new_ast = copy_of(original_ast)
    transformer = Python2FutureTransformer()
    transformer.visit(new_ast)
    expected_ast = expected()

    assert_module_equal(expected_ast, new_ast)

# Generated at 2022-06-23 22:57:43.157674
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    code = "from __future__ import division\n" +\
           "print(1/2)\n"
    tree = ast.parse(code)
    result = Python2FutureTransformer().visit(tree)
    assert result.body[0].import_name == '__future__'
    assert result.body[0].import_as_name == None
    assert result.body[0].names[0].name == 'absolute_import'
    assert result.body[0].names[0].asname == None
    assert result.body[0].names[1].name == 'division'
    assert result.body[0].names[1].asname == None
    assert result.body[0].names[2].name == 'print_function'
    assert result.body[0].names[2].asname == None

# Generated at 2022-06-23 22:57:45.381616
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)
    assert transformer._tree_changed == False
    assert transformer.generic_visit == ast.NodeTransformer.generic_visit

# Generated at 2022-06-23 22:57:56.441860
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module = ast.parse('x = 1')
    t = Python2FutureTransformer()
    result = t.visit(module)
    assert isinstance(result, ast.Module)
    assert isinstance(result.body[0], ast.ImportFrom)
    assert result.body[0].module == '__future__'
    assert isinstance(result.body[1], ast.ImportFrom)
    assert result.body[1].module == '__future__'
    assert isinstance(result.body[2], ast.ImportFrom)
    assert result.body[2].module == '__future__'
    assert isinstance(result.body[3], ast.ImportFrom)
    assert result.body[3].module == '__future__'
    assert isinstance(result.body[4], ast.Assign)

# Generated at 2022-06-23 22:58:02.693985
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Arrange
    module = ast.parse('print(0)')
    transformer = Python2FutureTransformer()
    expected_module = ast.parse('''
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

print(0)
''')

    # Act
    actual_module = transformer.visit(module)

    # Assert
    assert actual_module == expected_module

# Generated at 2022-06-23 22:58:10.891620
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from . import example
    from . import inspect_ast
    from ..utils.source_code import source_code
    import astor

    inspect_ = inspect_ast.InspectAST()
    for node, class_name in example.examples:
        print('=' * 80)
        print('Example {} class {}'.format(example.examples.index((node, class_name)), class_name))

        source_ = source_code(node)
        print(astor.to_source(node))

        Python2FutureTransformer_visit_Module_examples_ = Python2FutureTransformer()
        Python2FutureTransformer_visit_Module_examples_.visit(node)
        print(astor.to_source(node))

# Generated at 2022-06-23 22:58:21.514278
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module = ast.parse("print(123)")
    transformer = Python2FutureTransformer()
    new_module = transformer.visit(module)
    assert transformer._tree_changed
    assert transformer.target == (2, 7)
    assert isinstance(new_module, ast.Module)
    assert isinstance(new_module.body[0], ast.ImportFrom)
    assert new_module.body[0].module == '__future__'
    assert new_module.body[0].names[0].name == 'absolute_import'
    assert isinstance(new_module.body[1], ast.ImportFrom)
    assert new_module.body[1].module == '__future__'
    assert new_module.body[1].names[0].name == 'division'