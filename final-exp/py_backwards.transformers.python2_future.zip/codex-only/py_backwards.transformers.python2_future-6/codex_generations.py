

# Generated at 2022-06-23 22:48:21.516105
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()
    assert t.target == (2, 7)


# Generated at 2022-06-23 22:48:22.637522
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer().target == (2, 7)


# Generated at 2022-06-23 22:48:29.004728
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    code = dedent("""
        print('Hello, World!')
    """)

    node = ast.parse(code)
    Python2FutureTransformer().visit(node)

    expected_source = dedent("""
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        print('Hello, World!')
    """)
    assert astor.to_source(node) == expected_source

# Generated at 2022-06-23 22:48:32.456093
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_with_printing
    node = ast.parse('x = 1')
    visitor = Python2FutureTransformer()
    visitor.visit(node)
    expected = ast.parse(imports.str(future='__future__'))
    expected.body.extend(node.body)    
    assert_equal_with_printing(node, expected)

# Generated at 2022-06-23 22:48:34.403190
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-23 22:48:42.570907
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import copy
    from ..utils.matchers import JsonLike, Regex
    from ..utils.fixtures import make_dummy_tree
    node0 = make_dummy_tree()
    node0.body = []
    node1 = copy.deepcopy(node0)
    node1.body.extend(imports.get_body(future='__future__'))
    assert Python2FutureTransformer().visit(node0) \
        == JsonLike({'body': Regex(r'.*from __future__ import absolute_import.*')})



# Generated at 2022-06-23 22:48:47.839160
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor
    program_text = '''
    i=0;print(i)
    '''
    tree = ast.parse(program_text)
    print('original: {}'.format(astor.to_source(tree)))
    tree = Python2FutureTransformer(tree).visit(tree)
    print('after: {}'.format(astor.to_source(tree)))

# Generated at 2022-06-23 22:48:55.336842
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    src = """
    x = "abc"
    y = 100
    z = None
    
    """.strip()

    expected_src = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    x = "abc"
    y = 100
    z = None

    """.strip()

    t = Python2FutureTransformer()
    tree = astor.parse_file(src)
    t.visit(tree)

    # print(astor.to_source(tree))
    assert astor.to_source(tree).strip() == expected_src

# Generated at 2022-06-23 22:49:05.814126
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from .test_utils import _make_module_from_source
    from ..utils.visitor import dump_tree

    code = '''
        a = 1
        b = 2
    '''

# Generated at 2022-06-23 22:49:15.043888
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module(): 
    from typed_ast.ast3 import parse
    from typed_ast import ast3 as ast
    from typed_ast.transforms.type_comment import TypeCommentTransformer
    from typed_ast.transforms.future import Python2FutureTransformer

    class TestTransformer(TypeCommentTransformer, Python2FutureTransformer):
        pass

    module = parse(r'''
    print('Hello, World!')
    ''')
    module.type_ignores.append(ast.Name('NameError', ctx=ast.Load()))
    TestTransformer().visit(module)

# Generated at 2022-06-23 22:49:23.906517
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    assert Python2FutureTransformer().visit(ast.parse('x = 42; print ("Hello world!")')).body == imports.get_body(future='__future__') + [
        ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())], value=ast.Num(n=42)),  # type: ignore
        ast.Expr(value=ast.Call(
            func=ast.Name(id='print', ctx=ast.Load()),
            args=[ast.Str(s='Hello world!')],
            keywords=[]
        ))
    ]


# Generated at 2022-06-23 22:49:24.757065
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-23 22:49:25.190209
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer()

# Generated at 2022-06-23 22:49:30.644961
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from . import default_transformer_ctx
    from ..utils.load_fixture_ast import load_fixture_ast

    fixture_ast = load_fixture_ast(default_transformer_ctx,
                                   'Python2FutureTransformer_visit_Module')
    transformer = Python2FutureTransformer(default_transformer_ctx)
    result = transformer.visit(fixture_ast)
    assert transformer._tree_changed, f'Expect tree to be changed: {result}'

# Generated at 2022-06-23 22:49:41.345862
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    """Test :meth:`Python2FutureTransformer.visit_Module` for
    :class:`Python2FutureTransformer`
    """
    import astor
    from ..utils.sample import sample_2_module
    from ..utils.visitor import NodeVisitor
    from .remove_comments import RemoveCommentsTransformer

    module = sample_2_module
    module_no_comments = RemoveCommentsTransformer.run(module)
    module_no_comments = module_no_comments.body[0]
    visitor = NodeVisitor()
    visitor.visit(module)
    assert len(visitor.nodes) == 1
    visitor.visit(module_no_comments)
    assert len(visitor.nodes) == 2
    module_future = Python2FutureTransformer.run(module_no_comments)
   

# Generated at 2022-06-23 22:49:42.705383
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__doc__


# Generated at 2022-06-23 22:49:44.434457
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)



# Generated at 2022-06-23 22:49:45.003277
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass # TODO

# Generated at 2022-06-23 22:49:49.630799
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    snippet = \
        """
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        """
    builder = CodeBuilder(snippet)
    builder.add_transformer(Python2FutureTransformer)
    assert_equals(snippet, builder.stringify())

# Generated at 2022-06-23 22:49:50.834931
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()
    assert isinstance(t, BaseNodeTransformer)

# Generated at 2022-06-23 22:49:59.021067
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    source = """
        import math
        import sys
        print(sys.version_info)
        """
    expected_result = """
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        import math
        import sys
        print(sys.version_info)
        """

    tree = ast.parse(source)
    tree = Python2FutureTransformer().visit(tree)
    result = compile(tree, filename="<ast>", mode="exec")

    assert expected_result == result

# Generated at 2022-06-23 22:50:08.926179
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast

    source = inspect.cleandoc('''
    """Module docstring."""
    import re
    ''')
    tree = ast.parse(source)
    tree = Python2FutureTransformer().visit(tree) # type: ignore
    assert tree.body[0].s == '"""Module docstring."""\n'
    assert isinstance(tree.body[1], ast.ImportFrom)
    assert tree.body[1].module == '__future__'
    assert tree.body[1].names[0].name == 'absolute_import'
    assert isinstance(tree.body[2], ast.ImportFrom)
    assert tree.body[2].module == '__future__'
    assert tree.body[2].names[0].name == 'division'

# Generated at 2022-06-23 22:50:14.853558
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pt = Python2FutureTransformer()
    pt.target
    pt.indent
    pt.level
    pt.is_in_loop
    pt.loop_level
    pt.is_in_try
    pt.try_level
    pt.is_in_with
    pt.with_level
    pt.is_in_with_except
    pt.with_except_level
    pt.is_topdoc
    pt.topdoc_level
    pt.is_multiline
    pt.multiline_level
    imports.get_body(future='__future__')

# Generated at 2022-06-23 22:50:15.920123
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer(target=(2,7))

# Generated at 2022-06-23 22:50:25.755349
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    # test to raise exception
    with pytest.raises(NotImplementedError):
        transformer.visit_Module(ast.Module([]))
    assert transformer._tree_changed == False
    # test
    transformer = Python2FutureTransformer()
    node = ast.Module([])
    node = transformer.visit_Module(node)
    assert transformer._tree_changed == True
    assert len(node.body) == 4
    assert isinstance(node.body[0], ast.ImportFrom)
    assert node.body[0].module == '__future__'
    assert len(node.body[0].names) == 1
    assert node.body[0].names[0].name == 'absolute_import'
    assert isinstance(node.body[1], ast.ImportFrom)


# Generated at 2022-06-23 22:50:26.380131
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-23 22:50:28.527445
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-23 22:50:34.619777
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
   import ast
   import inspect
   from textwrap import dedent

   # Build AST from code string
   node = ast.parse(dedent(inspect.getsource(test_Python2FutureTransformer)))
   
   # Create transformer instance and visit Module node
   node = Python2FutureTransformer().visit(node)
   
   # Generate code from AST
   rv = compile(node, filename='<ast>', mode='exec')

   # Execute code
   exec(rv)

# Generated at 2022-06-23 22:50:36.186513
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()

# Generated at 2022-06-23 22:50:43.700640
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    t = Python2FutureTransformer()
    tree = astor.parse_file("""
print("Hello, world!")
    """)
    tree = t.visit(tree)
    assert astor.to_source(tree) == """\
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

print("Hello, world!")"""

# Generated at 2022-06-23 22:50:48.366022
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.compat import unicode
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from .python2_unicode_transformer import Python2UnicodeTransformer
    
    
    
    @snippet
    def module():
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals
        pass
    
    
    
    n = ast.parse(module.getsource())
    Python2UnicodeTransformer().visit(n)
    assert isinstance(n, ast.Module)
    assert len(n.body) == 5
    assert isinstance(n.body[0], ast.ImportFrom)

# Generated at 2022-06-23 22:50:53.443551
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():

    def _test_module(module: ast.Module) -> None:
        transformer = Python2FutureTransformer()
        module = transformer.visit(module)
        assert isinstance(module, ast.Module)
        assert isinstance(module.body[0], ast.ImportFrom)
        assert module.body[0].module == '__future__'

    _test_module(astor.parse_file('samples/v2/python2_future.py'))

# Generated at 2022-06-23 22:50:56.452763
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import ast
    import typed_ast.ast3
    from typed_ast import ast3 as ast
    from typed_ast_pprint import pprint
    
    tree = ast.parse("print(1)")
    Python2FutureTransformer().visit(tree)
    assert isinstance(tree, ast.Module)
    pprint(tree)


# Generated at 2022-06-23 22:50:57.107266
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()
    assert t

# Generated at 2022-06-23 22:50:59.085016
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    with pytest.raises(TypeError):
        Python2FutureTransformer()



# Generated at 2022-06-23 22:50:59.998749
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer



# Generated at 2022-06-23 22:51:02.917106
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    trans = Python2FutureTransformer()
    assert trans.target == (2, 7)
    assert not trans._tree_changed
    assert hasattr(trans, 'generic_visit')


# Generated at 2022-06-23 22:51:03.887718
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-23 22:51:13.244585
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    tree = ast.parse("a = 0")
    tree = Python2FutureTransformer.visit(tree)

    expected = ast.Module([
        ast.ImportFrom(module="__future__", names=[
            ast.alias(name="absolute_import", asname=None),
            ast.alias(name="division", asname=None),
            ast.alias(name="print_function", asname=None),
            ast.alias(name="unicode_literals", asname=None),
        ], level=0),
        ast.Assign(targets=[ast.Name(id="a", ctx=ast.Store())], value=ast.Num(n=0)),
    ])

    assert ast.dump(tree) == ast.dump(expected)

########################################################################################################################


# Generated at 2022-06-23 22:51:21.954655
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()
    tree = ast.parse('1')

# Generated at 2022-06-23 22:51:27.788121
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import_text = 'from __future__ import absolute_import\n' \
                  'from __future__ import division\n' \
                  'from __future__ import print_function\n' \
                  'from __future__ import unicode_literals\n'
    expected = ast.parse(import_text)
    module = ast.Module([])  # empty module
    Python2FutureTransformer().visit(module)
    assert module.body == expected.body

# Generated at 2022-06-23 22:51:32.473852
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .fixtures.python2futuretransformer import module
    node = module.body[0]
    assert isinstance(node, ast.Module)
    visitor = Python2FutureTransformer()
    result = visitor.visit_Module(node)
    assert result is not None
    assert result.body[0].value == '__future__'

# Generated at 2022-06-23 22:51:42.216488
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    assert imports.get_source(future='__future__') == \
        'from __future__ import absolute_import\n' \
        'from __future__ import division\n' \
        'from __future__ import print_function\n' \
        'from __future__ import unicode_literal\n'

    tree = ast.parse('''\
import re
import os
''')
    Python2FutureTransformer().visit(tree)
    source = Python2FutureTransformer.compile(tree)

# Generated at 2022-06-23 22:51:43.260108
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor

# Generated at 2022-06-23 22:51:44.934402
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    with pytest.raises(TypeError):
        Python2FutureTransformer()


# Generated at 2022-06-23 22:51:50.040310
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import ast
    import six
    if six.PY2:
        return
    class a:
        pass
    class b:
        pass
    assert not Python2FutureTransformer(a) is a
    assert not Python2FutureTransformer(b) is b

if __name__ == '__main__':
    test_Python2FutureTransformer()

# Generated at 2022-06-23 22:51:57.873045
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import Source
    from ..utils.ast import ast_to_source
    @snippet
    def source():
        def foo():
            pass
    assert ast_to_source(Source(source).ast).strip() == 'def foo():\n    pass'
    #
    transformer = Python2FutureTransformer().visit(Source(source).ast)
    assert ast_to_source(transformer).strip() == 'from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\ndef foo():\n    pass'

# Generated at 2022-06-23 22:52:04.966388
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astunparse
    source = """\
x = "Hello Python 2"
    """
    tree = ast.parse(source)
    transformer = Python2FutureTransformer()
    new_tree = transformer.visit(tree)
    new_source = astunparse.unparse(new_tree)
    print(new_source)
    assert new_source == """\
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

x = "Hello Python 2"
"""


if __name__ == "__main__":
    test_Python2FutureTransformer()

# Generated at 2022-06-23 22:52:15.377181
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import copy
    import yaml
    from typed_ast import ast3 as ast

    old_tree = yaml.load("""\
        Module:
            body: []
        """)
    new_tree = copy.deepcopy(old_tree)
    Python2FutureTransformer().visit(new_tree)
    assertion.eq(ast.dump(new_tree), """\
        Module(
            body=
            [
                ImportFrom(
                    module='future',
                    names=[
                        alias(name='absolute_import', asname=None),
                        alias(name='division', asname=None),
                        alias(name='print_function', asname=None),
                        alias(name='unicode_literals', asname=None)
                    ],
                    level=0
                )
            ]
        )""")


# Generated at 2022-06-23 22:52:17.789901
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_tree = ast.parse("pass")
    tr = Python2FutureTransformer()
    tr.visit(module_tree)
    assert isinstance(module_tree.body[0], ast.ImportFrom)

# Generated at 2022-06-23 22:52:26.391172
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import ast
    filename = 'test.py'
    source = '''
x = "Hello World!"
'''
    parsed = ast.parse(source)
    result = Python2FutureTransformer().visit(parsed)
    assert type(result) == ast.Module
    assert result.body[0].names[0].name == 'absolute_import'
    assert result.body[2].names[0].name == 'division'
    assert result.body[4].names[0].name == 'print_function'
    assert result.body[6].names[0].name == 'unicode_literals'
    assert result.body[8].value.s == 'Hello World!'

# Generated at 2022-06-23 22:52:36.308045
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    '''Test Python2FutureTransformer'''
    from ..utils.test_utils import transform_snippet
    from .base import BaseNodeTransformerTest
    from ..utils.test_utils import assert_equal_ignore_ws, assert_equal

    with BaseNodeTransformerTest(Python2FutureTransformer) as test:
        test.assert_transformation('''
            A = 1
            B = '2'
        ''','''
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals

            A = 1
            B = '2'
        ''')


# Generated at 2022-06-23 22:52:38.755288
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = ast.parse(imports.code, mode='exec')
    node = Python2FutureTransformer().visit(module)
    assert node is not None
    assert ast.dump(node) == ast.dump(module)

# Generated at 2022-06-23 22:52:42.250208
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_visitor import assert_source

    tree = ast.parse("""
        pass
    """)
    assert_source(tree, """
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        pass
    """)

# Generated at 2022-06-23 22:52:44.630982
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast

    parse_tree = ast.parse("")
    Python2FutureTransformer().visit(parse_tree)
    assert ast.dump(parse_tree) == imports.get_ast(future='__future__')

# Generated at 2022-06-23 22:52:54.470116
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    mod = """
from __future__ import division as div
from __future__ import print_function as p
""".strip()
    mod = ast.parse(mod)
    mod = Python2FutureTransformer().visit(mod)
    assert mod is not None
    assert isinstance(mod, ast.Module)
    assert isinstance(mod.body, list)
    assert len(mod.body) == 4
    assert isinstance(mod.body[0], ast.ImportFrom)
    assert isinstance(mod.body[1], ast.ImportFrom)
    assert isinstance(mod.body[2], ast.ImportFrom)
    assert isinstance(mod.body[3], ast.ImportFrom)
    assert mod.body[0].module == '__future__'
    assert mod.body[1].module == '__future__'

# Generated at 2022-06-23 22:53:02.068867
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_tree = ast.parse("""""")
    transformer = Python2FutureTransformer()
    transformed_tree = transformer.visit(module_tree)
    assert transformed_tree.body[0] == ast.parse("from __future__ import absolute_import")
    assert transformed_tree.body[1] == ast.parse("from __future__ import division")
    assert transformed_tree.body[2] == ast.parse("from __future__ import print_function")
    assert transformed_tree.body[3] == ast.parse("from __future__ import unicode_literals")

# Generated at 2022-06-23 22:53:08.106297
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():

    from textwrap import dedent  # noqa
    from typed_ast import ast3 as ast

    from typed_astunparse import unparse  # noqa
    from typed_astunparse import dump  # noqa
    
    node = ast.parse(dedent('''
        import os
        import sys

        def func():
            pass
    '''))

    node = Python2FutureTransformer().visit(node)

    print(unparse(node))
    print(dump(node))



# Generated at 2022-06-23 22:53:09.236781
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    with pytest.raises(TypeError, match='missing 2 required positional arguments'):
        Python2FutureTransformer()



# Generated at 2022-06-23 22:53:15.702583
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    from . import type_inference
    from . import function_signature_transformer
    from . import error_transformer
    from . import print_transformer
    from . import exec_transformer
    from . import raise_transformer
    from . import unicode_transformer
    from . import import_transformer

    tree = compile('RootClass = object', 'test_module', mode='exec',
                   flags=ast.PyCF_ONLY_AST,
                   dont_inherit=True)
    type_inference.TypeInferer().visit(tree)
    Python2FutureTransformer().visit(tree)
    function_signature_transformer.FunctionSignatureTransformer().visit(tree)
    error_transformer.ErrorTransformer().visit(tree)
    print

# Generated at 2022-06-23 22:53:22.440409
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    before = ast.parse("# comment")
    after = ast.parse("""# comment
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    """)
    assert Python2FutureTransformer().visit(before) == after



# Generated at 2022-06-23 22:53:29.635680
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    some_string = "some string"
    x = 5
    sample_tree = ast.parse(f"{some_string}\nx = 5")
    Python2FutureTransformer().visit(sample_tree)
    assert str(sample_tree) == ("from __future__ import absolute_import\n"
                                "from __future__ import division\n"
                                "from __future__ import print_function\n"
                                "from __future__ import unicode_literals\n"
                                f"{some_string}\n"
                                "x = 5")

# Generated at 2022-06-23 22:53:30.570269
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-23 22:53:36.794645
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()
    i1 = ast.Import([ast.alias('os', None)])
    i2 = ast.Import([ast.alias('os.path', None)])
    m_node = ast.Module(body=[i1, i2])
    expected_body = imports.get_body(future='__future__') + [i1, i2]
    m_transformed = transformer.visit_Module(m_node)
    assert m_transformed.body == expected_body

# Generated at 2022-06-23 22:53:41.803829
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    tree = ast.parse('print("Hello world!")')
    transformer = Python2FutureTransformer()
    transformer.visit(tree)
    assert ''.join(astor.to_source(tree).splitlines(True)[:2]) == \
        ''.join(imports.get_source(future='__future__').splitlines(True)[:2])

# Generated at 2022-06-23 22:53:48.957084
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..parsers.python.ast_parser import ast_parse
    from ..utils.source_set import source_set

    # source = source_set('tests/samples/simplest_function.py')
    source = source_set('tests/samples/function_with_docstring.py')
    # source = source_set('tests/samples/function_with_default_arguments.py')
    # source = source_set('tests/samples/function_with_multiline_docstring.py')
    # source = source_set('tests/samples/function_with_multiline_docstring_and_multiline_arguments.py')
    # source = source_set('tests/samples/function_with_multiline_docstring_and_multiline_arguments_and_multil

# Generated at 2022-06-23 22:53:55.990065
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast.ast3 import parse as ast_parse

    code = r'''
# comment
import os
print('test')
'''
    expected_code = r'''
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
# comment
import os
print('test')
'''
    module = ast_parse(code)
    Python2FutureTransformer().visit(module)
    assert ast_parse(expected_code).body == module.body

# Generated at 2022-06-23 22:53:57.771629
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    trans = Python2FutureTransformer()
    assert type(trans) == Python2FutureTransformer


# Generated at 2022-06-23 22:53:59.855114
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Test the constructor of the class."""
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'


# Generated at 2022-06-23 22:54:07.647599
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    @snippet
    def target(python):
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

    node = ast.parse(target.code)  # type: ignore

    expected_result = """
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        """

    transformer = Python2FutureTransformer()
    actual_result = transformer.visit(node)
    assert dedent(expected_result) == astunparse.unparse

# Generated at 2022-06-23 22:54:09.643613
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    from typed_ast import ast3 as ast


# Generated at 2022-06-23 22:54:10.937375
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer


# Generated at 2022-06-23 22:54:21.785014
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    snippet.filename = 'python2_to_python3.py'
    snippet.imports = {'typed_ast': 'typed_ast'}
    # snippet.print = True
    """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    import sys
    import re
    """

    optional_semicolons = [
        'from __future__ import absolute_import',
        'from __future__ import division',
        'from __future__ import print_function',
        'from __future__ import unicode_literals',
        'import sys',
        'import re'
    ]

    assert imports.get_module() == optional_semicolons

# Generated at 2022-06-23 22:54:31.675883
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse('foo = 1')
    node = Python2FutureTransformer().visit(node)
    assert node.body == [
        ast.ImportFrom(module='__future__', names=[  # type: ignore
            ast.alias(name='absolute_import', asname=None),
            ast.alias(name='division', asname=None),
            ast.alias(name='print_function', asname=None),
            ast.alias(name='unicode_literals', asname=None)], level=0),
        ast.Assign(targets=[ast.Name(id='foo', ctx=ast.Store())], value=ast.Num(n=1))
    ]

# Generated at 2022-06-23 22:54:36.477495
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    code = '''
    def func():
        print('hello')
    '''

    # Create an AST object from the code
    tree = ast.parse(code)

    # Apply Python2FutureTransformer
    py2_transformer = Python2FutureTransformer()
    py2_transformer.visit(tree)
    assert py2_transformer._tree_changed, "Tree did not change"

# Generated at 2022-06-23 22:54:42.459582
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import typed_ast.ast3 as ast
    from ..utils.node_utils import print_node
    from ..utils.ast_utils import new_module
    module = new_module('module.py', '''
    def foo():
        return None
    ''')
    transformer = Python2FutureTransformer()
    new_module = transformer.visit(module)
    expected = '''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    def foo():
        return None
    '''
    assert print_node(new_module) == expected

# Generated at 2022-06-23 22:54:44.810755
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    node_transformer = Python2FutureTransformer()
    assert node_transformer.tree_changed is False
    assert node_transformer.target == (2, 7)



# Generated at 2022-06-23 22:54:46.035365
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer().target == (2, 7)

# Generated at 2022-06-23 22:54:52.141241
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = ast.parse("x + y")
    transformer = Python2FutureTransformer()
    node = transformer.visit(module)
    print(ast.dump(node))
    assert node.body[0].body[0].name == "absolute_import"
    assert node.body[0].body[1].name == "division"
    assert node.body[0].body[2].name == "print_function"
    assert node.body[0].body[3].name == "unicode_literals"
    assert isinstance(node.body[1].value.left, ast.Name)
    assert isinstance(node.body[1].value.right, ast.Name)



# Generated at 2022-06-23 22:54:54.869076
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    if not __debug__:
        pytest.skip('Must be run in debug mode')

    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)

# Generated at 2022-06-23 22:54:59.818121
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():

    module = ast.parse(textwrap.dedent('''\
    def x():
        pass'''))

    expected = ast.parse(textwrap.dedent('''\
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    def x():
        pass
    '''))
    
    actual = Python2FutureTransformer().visit(module)

    assert ast.dump(expected, annotate_fields=False) == ast.dump(actual, annotate_fields=False)
    

# Generated at 2022-06-23 22:55:00.951363
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-23 22:55:03.434887
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils import roundtrip
    code = """print('Hello World')"""
    roundtrip(code, Python2FutureTransformer)

# Generated at 2022-06-23 22:55:14.024757
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import typing
    import astor

    with open('examples/code-snippets/with_future.py', 'r') as f:
        code = f.read()

    node = ast.parse(code)
    assert isinstance(node, ast.Module)

    t = Python2FutureTransformer()
    new_node = t.visit(node)

    assert isinstance(new_node, ast.Module)
    assert len(new_node.body) == 6
    assert isinstance(new_node.body[0], ast.ImportFrom)
    assert isinstance(new_node.body[1], ast.ImportFrom)
    assert isinstance(new_node.body[2], ast.ImportFrom)
    assert isinstance(new_node.body[3], ast.ImportFrom)

# Generated at 2022-06-23 22:55:15.510217
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()
    assert t is not None



# Generated at 2022-06-23 22:55:22.368745
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Module

    tree = Module(body=[])
    transformer = Python2FutureTransformer()
    new_tree = transformer.visit(tree)
    print(ast.dump(new_tree))
    new_tree = ast.parse(str(ast.dump(new_tree)))
    assert transformer.tree_changed
    assert isinstance(new_tree, Module)
    from future import absolute_import
    from future import division
    from future import print_function
    from future import unicode_literals

# Generated at 2022-06-23 22:55:23.594622
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer

# Generated at 2022-06-23 22:55:30.523292
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    node = ast.parse('import math')  # type: ignore
    visitor = Python2FutureTransformer()
    visitor.visit(node)  # type: ignore
    assert astor.to_source(node) == '\n'.join([
        'from __future__ import absolute_import',
        'from __future__ import division',
        'from __future__ import print_function',
        'from __future__ import unicode_literals',
        'import math',
    ])

# Generated at 2022-06-23 22:55:32.628784
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)
    assert isinstance(transformer, BaseNodeTransformer)

# Generated at 2022-06-23 22:55:37.431971
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source, source_clean
    from ..utils.ast import ast_equal, parse
    from .transformers import transform

    source_code = source('Python2FutureTransformer-visit_Module')
    expected_code = source_clean('Python2FutureTransformer-visit_Module-expected')
    transform(Python2FutureTransformer).visit(parse(source_code))
    assert ast_equal(parse(expected_code), parse(source_code))

# Generated at 2022-06-23 22:55:38.963099
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-23 22:55:40.472772
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    p = Python2FutureTransformer()
    # test that __init__ sets target correctly
    assert p.target == (2, 7)

# Generated at 2022-06-23 22:55:46.615355
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast

    source = """
    import future
    from __future__ import unicode_literals
    from future import generators
    from future import absolute_import
    from future.builtins import *

    print(True)
    """
    expected_source = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    import future
    from __future__ import unicode_literals
    from future import generators
    from future import absolute_import
    from future.builtins import *

    print(True)
    """
    tree = ast.parse(source)
    tree_transformer = Python2FutureTransformer()
    tree_transformer.visit(tree)

# Generated at 2022-06-23 22:55:48.057264
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass

if __name__ == '__main__':
    test_Python2FutureTransformer()

# Generated at 2022-06-23 22:55:53.641033
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_node = ast.parse("x=1")
    transformer = Python2FutureTransformer()
    transformer.visit(module_node)
    expected_result = "from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\nx=1"
    assert expected_result == ast.unparse(module_node)

# Generated at 2022-06-23 22:55:54.600471
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-23 22:56:00.474633
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    tree = ast.parse("""
    class B(A): pass
    """)
    transformer = Python2FutureTransformer(tree)
    transformer.visit(tree)
    assert len(tree.body) == 3
    assert isinstance(tree.body[0], ast.ImportFrom)
    assert isinstance(tree.body[1], ast.ImportFrom)
    assert isinstance(tree.body[2], ast.ClassDef)

# Generated at 2022-06-23 22:56:07.186508
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet

    tree = snippet.get_tree('''
        #!/usr/bin/env python3
        def function():
            pass
    ''')
    new_tree = Python2FutureTransformer().visit(tree)

    assert isinstance(new_tree, ast.Module)
    assert new_tree.body[0:4] == imports.get_body(future='__future__')
    assert new_tree.body[4].body[0].value.id == 'function'

# Generated at 2022-06-23 22:56:17.553743
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    p2ft = Python2FutureTransformer()
    test_node1 = ast.Module(body=[])
    test_node2 = ast.Module(body=[ast.Import(names=[ast.alias(name='foo.bar', asname=None)])])
    test_node3 = ast.Module(body=[ast.Import(names=[ast.alias(name='foo.bar', asname='barf')])])
    
    result1 = p2ft.visit(test_node1)
    assert result1.body[0].names[0].name == 'absolute_import'
    assert result1.body[1].names[0].name == 'division'
    assert result1.body[2].names[0].name == 'print_function'

# Generated at 2022-06-23 22:56:26.338722
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import sys
    import astor
    from ..extensions import Python2FutureExtension

    test_code = '''
x = 1
print(x)
    '''

    tree = ast.parse(test_code)
    Python2FutureExtension(sys.argv).transform(tree)

    expected_code = '''
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

x = 1
print(x)
    '''
    assert astor.to_source(tree) == expected_code

# Generated at 2022-06-23 22:56:32.593849
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer.__doc__ == """Prepends module with:
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
            
    """


# Generated at 2022-06-23 22:56:40.640216
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    body_before = [ast.ImportFrom(
        module='typed_ast',
        names=[ast.alias(
            name='ast3',
            asname='ast')],
        level=0)]  # type: ignore
    module = ast.Module(body=body_before)  # type: ignore
    transformator = Python2FutureTransformer()
    module = transformator.visit(module)  # type: ignore
    assert len(module.body) == 5
    assert module.body[0].module == '__future__'
    assert module.body[0].names[0].name == 'absolute_import'
    assert module.body[1].module == '__future__'
    assert module.body[1].names[0].name == 'division'
    assert module.body[2].module == '__future__'


# Generated at 2022-06-23 22:56:46.291556
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils import round_trip, round_trip_load
    from typed_ast import parse

    # Test for change
    tree = parse("")
    new_tree = Python2FutureTransformer().visit(tree)
    assert new_tree.body[0].names[0].name == 'absolute_import'

    # Test for no change
    round_trip(Python2FutureTransformer, 'foo = 42\n')

# Generated at 2022-06-23 22:56:50.336093
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import sys
    import sysconfig
    python_version = sys.version_info[:2]
    target = (2, 7)
    assert (python_version is not target)
    assert (sysconfig.get_python_version() is not target)

    transformer = Python2FutureTransformer()
    assert (transformer.target is target)
    assert (transformer.source is python_version)
    assert (transformer._tree_changed is False)

# Generated at 2022-06-23 22:56:52.102391
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    '''
    Unit test for constructor of class Python2FutureTransformer
    '''
    Python2FutureTransformer()

# Generated at 2022-06-23 22:56:53.776922
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)

# Generated at 2022-06-23 22:56:54.691175
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-23 22:56:55.610035
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()



# Generated at 2022-06-23 22:56:59.862716
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    module = astor.parse_file('examples/python_3_code/fixtures/package.py')
    for node in module.body:
        assert not isinstance(node, ast.ImportFrom)
    Python2FutureTransformer().visit(module)
    for node in module.body[0:4]:
        assert isinstance(node, ast.ImportFrom)

# Generated at 2022-06-23 22:57:08.644543
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    sample = '''
    import sys
    import os
    
    
    def foo():
        pass
    
    
    def bar():
        pass
    '''
    expected = '''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    import sys
    import os
    
    
    def foo():
        pass
    
    
    def bar():
        pass
    '''
    source = ast.parse(sample, filename='<input>', mode='exec')
    tree = Python2FutureTransformer().visit(source)

    assert ast.dump(tree) == ast.dump(ast.parse(expected, filename='<output>', mode='exec'))


# Generated at 2022-06-23 22:57:18.446809
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import sys
    import ast
    import textwrap
    from python_modernizer.transformer import Python2FutureTransformer
    from python_modernizer.utils.snippet import snippet
    from python_modernizer.utils.utils import get_ast

    text = snippet(imports)
    tree = ast.parse(text)

    transformer = Python2FutureTransformer()
    transformer.generic_visit(tree)

    code = textwrap.dedent('''\
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals
    ''')

# Generated at 2022-06-23 22:57:20.276261
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast


# Generated at 2022-06-23 22:57:29.475321
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import ast
    test_tree = ast.parse("""
    a = 1
    b = 2
    """)
    tree = Python2FutureTransformer().visit(test_tree)
    assert isinstance(tree, ast.Module)
    assert len(tree.body) == 8
    assert isinstance(tree.body[0], ast.ImportFrom)
    assert isinstance(tree.body[1], ast.ImportFrom)
    assert isinstance(tree.body[2], ast.ImportFrom)
    assert isinstance(tree.body[3], ast.ImportFrom)
    assert isinstance(tree.body[4], ast.Assign)
    assert isinstance(tree.body[5], ast.Assign)

# Generated at 2022-06-23 22:57:31.383357
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Test for Python2FutureTransformer"""

    transformer = Python2FutureTransformer()
    assert transformer is not None



# Generated at 2022-06-23 22:57:33.703905
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transpiler = Python2FutureTransformer()
    assert transpiler is not None

# Generated at 2022-06-23 22:57:36.088196
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    x = Python2FutureTransformer()
    assert x._tree_changed is False
    assert x.target == (2, 7)

# Generated at 2022-06-23 22:57:45.279818
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast.ast3 import parse
    from tests.test_transformer_base import compare_ast, run_transformer_test
    from .base import BaseNodeTransformer
    from .python2_print_function import Python2PrintFunctionTransformer

    def transform(node):
        BaseNodeTransformer.reset_tree_changed()
        transformer = Python2PrintFunctionTransformer()
        tree = transformer.visit(node)
        assert transformer.tree_changed() == (True, True)
        assert tree is not node

        BaseNodeTransformer.reset_tree_changed()
        transformer = Python2FutureTransformer()
        tree = transformer.visit(tree)
        assert transformer.tree_changed() == (True, True)
        assert tree is not node
        return tree

    # Single print statement

# Generated at 2022-06-23 22:57:49.231783
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)
    assert isinstance(transformer._tree_changed, bool)
    assert transformer._tree_changed == False
    assert isinstance(transformer._log, list)
    assert transformer._log == []

# Generated at 2022-06-23 22:57:50.618028
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer is not None

# Generated at 2022-06-23 22:57:57.099881
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    tree = ast.parse('print(1,2)')
    Python2FutureTransformer().visit(tree)
    module, _ = snippets.load_module(tree)
    assert module.__name__ == '__future__'
    assert module.absolute_import # type: ignore
    assert module.division # type: ignore
    assert module.print_function # type: ignore
    assert module.unicode_literals # type: ignore

# Generated at 2022-06-23 22:58:02.916884
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Arrange
    import astor
    node = ast.parse('def func():\n    pass')
    # Act
    new_node = Python2FutureTransformer().visit(node)
    # Assert

# Generated at 2022-06-23 22:58:04.556423
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert hasattr(Python2FutureTransformer, 'target') and Python2FutureTransformer.target == (2, 7)

# Generated at 2022-06-23 22:58:06.609284
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Unit test for Python2FutureTransformer using pytest."""
    x = Python2FutureTransformer()
    assert x is not None

# Generated at 2022-06-23 22:58:12.812588
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = ast.parse('''
        """\n
        TEST\n
        """\n
        x = 1
    ''')
    transformer = Python2FutureTransformer()
    transformer.visit(module)

# Generated at 2022-06-23 22:58:14.584401
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)


# Generated at 2022-06-23 22:58:22.750241
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    import astor
    module_node = ast.parse('x = 1')

    expected_output = '''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    x = 1
    '''
    expected_ast = ast.parse(expected_output)

    visitor = Python2FutureTransformer()
    transformed = visitor.visit(module_node)
    assert transformed is not module_node
    assert astor.to_source(expected_ast) == astor.to_source(transformed)