

# Generated at 2022-06-23 22:48:18.676025
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pft = Python2FutureTransformer()
    assert pft.target == (2, 7)

# Generated at 2022-06-23 22:48:22.880991
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse('str = "hello" + " world"')

    transformer = Python2FutureTransformer()
    node = transformer.visit(node)
    assert transformer._tree_changed

    # print(ast.dump(node))
    assert node.body[0].value.s == "hello"
    assert node.body[1].value.s == " world"

# Generated at 2022-06-23 22:48:29.920502
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor
    import textwrap

    source = textwrap.dedent('''
        print(1)
        print(2)
        ''')
    node = ast.parse(source)
    tree = Python2FutureTransformer().visit(node)
    expected = '''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    print(1)
    print(2)
    '''
    assert astor.to_source(tree) == expected

# Generated at 2022-06-23 22:48:30.634129
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()


# Generated at 2022-06-23 22:48:35.154958
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()
    tree = ast.parse("import os")
    transformer.visit(tree)
    assert "from __future__ import absolute_import" in astor.to_source(tree)
    assert "from __future__ import division" in astor.to_source(tree)
    assert "from __future__ import print_function" in astor.to_source(tree)
    assert "from __future__ import unicode_literals" in astor.to_source(tree)



# Generated at 2022-06-23 22:48:38.299120
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    input = """print('foo')"""
    expected = """from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

print('foo')"""
    tree = ast.parse(input)
    tree = Python2FutureTransformer().visit(tree)  # type: ignore
    assert astunparse.unparse(tree) == expected

# Generated at 2022-06-23 22:48:40.702930
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from .test_utils import transform_snippets
    from typed_ast import ast3 as ast
    from .test_utils import build_module, compare_ast


# Generated at 2022-06-23 22:48:49.832559
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor

    input_ = """\
import sys

print("hello world!")
    """
    expected_output = """\
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

import sys

print("hello world!")
    """
    tree = ast.parse(input_)
    transformer = Python2FutureTransformer()
    transformed_tree = transformer.visit(tree)
    transformed_source = astor.to_source(transformed_tree)
    assert expected_output == transformed_source
    assert transformed_tree is not tree

# Generated at 2022-06-23 22:48:52.286125
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    node = ast.parse("def fn(): pass")
    node = Python2FutureTransformer().visit(node)
    assert node.body[0].names[0] == "absolute_import"

# Generated at 2022-06-23 22:48:55.143615
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from . import get_test_ast
    from . import compare_nodes

    class_ = Python2FutureTransformer
    compare_nodes(class_, get_test_ast(class_))

# Generated at 2022-06-23 22:49:02.419132
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import typed_astunparse
    string = ''' 
import x
    '''
    my_ast = typed_astunparse.parse(string)
    my_ast2 = Python2FutureTransformer().visit(my_ast)
    string_result = typed_astunparse.unparse(my_ast2)
    assert(string_result == '''from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

import x
    ''')

# Generated at 2022-06-23 22:49:08.188614
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    tree = ast.parse('''
some_code()
''')
    transformer.visit(tree)
    # print(transformer.output_text)
    assert transformer.output_text == '''
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
some_code()
'''

# Generated at 2022-06-23 22:49:09.586276
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert(Python2FutureTransformer is not None)


# Generated at 2022-06-23 22:49:10.906640
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert isinstance(Python2FutureTransformer().visit(None), ast.NodeTransformer)

# Generated at 2022-06-23 22:49:12.691969
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()
    assert isinstance(t, Python2FutureTransformer)

# Generated at 2022-06-23 22:49:24.516844
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    code = "def foo():\n    print('foo')"
    expected = imports.get_body(future='__future__') + imports.get_body(from_='astor', import_='ast') + [
        ast.FunctionDef(
            name='foo',
            args=ast.arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]),
            body=[ast.Expr(ast.Call(
                func=ast.Name(id='print', ctx=ast.Load()),
                args=[ast.Str(s='foo')], keywords=[]))],
            decorator_list=[], returns=None)]

    tree = ast.parse(code)
    Python2FutureTransformer().visit(tree)

    assert tree.body == expected

# Generated at 2022-06-23 22:49:30.296755
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import sys
    import ast
    from ..analysers.line_length import MaxLineLengthAnalyser
    
    code = '''
        # This is a good comment
        import os
    '''
    root = ast.parse(code)
    t = Python2FutureTransformer(sys.modules[__name__])

    t.visit(root)

    analyser = MaxLineLengthAnalyser(80)
    analyser.visit(root)

    code = compile(root, '<string>', 'exec')
    exec(code)

    assert type(root) is ast.Module

# Generated at 2022-06-23 22:49:36.166102
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    tree = ast.parse("from __future__ import absolute_import")
    tree = Python2FutureTransformer().visit(tree)
    assert ast.dump(tree) == '''
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
from __future__ import absolute_import
'''

# Generated at 2022-06-23 22:49:39.114142
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    nodes = ast.parse("pass")
    transformer = Python2FutureTransformer()
    transformer.visit(nodes)
    assert str(nodes) == 'import __future__\npass'

# Generated at 2022-06-23 22:49:49.123326
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()
    tree = ast.parse(
        """import os
        import sys
        """
    )
    tree = transformer.visit(tree)
    assert isinstance(tree, ast.Module)
    assert len(tree.body) == 7
    assert isinstance(tree.body[0], ast.ImportFrom)
    f = tree.body[0]
    assert f.module == '__future__'
    assert f.names[0].name == 'absolute_import'
    assert f.names[0].asname == None
    assert f.names[1].name == 'division'
    assert f.names[1].asname == None
    assert f.names[2].name == 'print_function'
    assert f.names[2].asname == None

# Generated at 2022-06-23 22:49:51.415756
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Unit test for constructor of class Python2FutureTransformer
    """
    assert Python2FutureTransformer.__name__ == "Python2FutureTransformer"

# Generated at 2022-06-23 22:50:02.174083
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse('def main():\n    pass')
    
    tr = Python2FutureTransformer()
    new_node = tr.visit(node)

    assert isinstance(new_node, ast.Module)
    assert(len(new_node.body) == 7)
    assert isinstance(new_node.body[1], ast.ImportFrom)
    assert new_node.body[1].module == 'future'
    assert new_node.body[1].names[0].name == 'absolute_import'
    assert isinstance(new_node.body[2], ast.ImportFrom)
    assert new_node.body[2].module == 'future'
    assert new_node.body[2].names[0].name == 'division'

# Generated at 2022-06-23 22:50:11.578729
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from .. import Python2FutureTransformer, Python2CleanupTransformer
    from ..utils.test_utils import assert_equal_source
    from ..utils.ast_utils import module_body
    from typed_ast import ast3 as ast

    module_source = 'a = 1\nb = 2'
    module_tree = ast.parse(module_source)
    module_tree = Python2FutureTransformer().visit(module_tree)  # type: ignore
    module_tree = Python2CleanupTransformer().visit(module_tree)  # type: ignore
    module_body(module_tree, offset=4)

# Generated at 2022-06-23 22:50:16.320507
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    source = "\nprint('hello')"
    expected = "from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\nprint('hello')"
    tree = ast.parse(source)  # type: ignore
    transformer = Python2FutureTransformer()
    result = transformer.visit(tree)  # type: ignore
    assert ast.dump(result) == ast.dump(ast.parse(expected))  # type: ignore

# Generated at 2022-06-23 22:50:17.384493
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():  # noqa
    pass

# Generated at 2022-06-23 22:50:22.928071
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():

    from ..transformer import Transformer

    import sys
    import astor
    from astor.code_gen import to_source

    class DummyTransformer(Transformer):
        pass

    tree = DummyTransformer.get_ast(
        '# This is a comment\nclass Foo(object):\n    pass'
    )

    transformer = Python2FutureTransformer()
    transformer.visit(tree)
    source = transformer.get_source()
    assert 'from __future__ import' in source

# Generated at 2022-06-23 22:50:23.586811
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
        pass

# Generated at 2022-06-23 22:50:24.553633
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer is not None

# Generated at 2022-06-23 22:50:34.497938
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    module = ast.Module([
        ast.Import([ast.alias("foo", None)]),
        ast.FunctionDef("foo", ast.arguments([], [], [], [], None, [], []), [], [], None)
    ])
    transformer = Python2FutureTransformer()
    module = transformer.visit(module)
    module_source = ast.fix_missing_locations(module)
    assert ast.dump(module_source, include_attributes=True) == \
        'Module(body=[ImportFrom(module="__future__", names=[alias(name="absolute_import", asname=None)], level=0), ' \
        'ImportFrom(module="__future__", names=[alias(name="division", asname=None)], level=0), ' \
       

# Generated at 2022-06-23 22:50:35.306882
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer().target == (2, 7)

# Generated at 2022-06-23 22:50:40.624119
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    class TestPython2FutureTransformer(Python2FutureTransformer):
        """
        Unit test for constructor of class Python2FutureTransformer
        """
        VERSION = (2, 7)
        def transform_tree(self, tree: ast.AST):
            pass

# Generated at 2022-06-23 22:50:49.358562
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast

    code = """
    import os
    import sys
    import numpy as np
    
    import pandas as pd
    import scipy as sp
    import matplotlib.pyplot as plt
    """
    tree = ast.parse(code)
    visitor = Python2FutureTransformer()
    visitor.visit(tree)
    assert tree.body[0].names[0].name == 'absolute_import'
    assert tree.body[0].names[1].name == 'diivision'
    assert tree.body[0].names[2].name == 'print_function'
    assert tree.body[0].names[3].name == 'unicode_literals'
    assert tree.body[1].names[0].name == 'os'

# Generated at 2022-06-23 22:50:53.120428
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = ast.parse("")
    forward_compat.Python2FutureTransformer().visit(module)
    assert ast.dump(module) == "from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n"

# Generated at 2022-06-23 22:50:55.227229
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    trans = Python2FutureTransformer()
    node = trans.visit(ast.parse("x = 1"))
    assert '__future__' in ast.dump(node)

# Generated at 2022-06-23 22:51:01.885288
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..tests.utils import check_ast
    from .transformer_2to3 import Python2to3Transformer
    from .transformer_3to2 import Python3to2Transformer
    from .transformer_annotate import PythonAnnotateTransformer
    from .transformer_autopep8 import PythonAutopep8Transformer
    from .transformer_drop_print import PythonDropPrintTransformer
    from .transformer_drop_star import PythonDropStarTransformer
    from .transformer_future import PythonFutureTransformer
    from .transformer_inline import PythonInlineTransformer
    from .transformer_numpy import PythonNumpyTransformer
    from .transformer_print import PythonPrintTransformer
    from .transformer_type import PythonTypeTransformer
    from .transformer_unwrap import PythonUnwrapTransformer

    class_test

# Generated at 2022-06-23 22:51:11.032896
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    """Unit test for method visit_Module of class Python2FutureTransformer"""
    # Test 1: a simple module
    module = ast.parse("""
    def foo():pass
    """)
    module_visited = Python2FutureTransformer().visit(module)
    assert module_visited.body[0].id == 'absolute_import'
    assert module_visited.body[1].id == 'division'
    assert module_visited.body[2].id == 'print_function'
    assert module_visited.body[3].id == 'unicode_literals'
    assert module_visited.body[4].name == 'foo'
    # Test 2: module with docstring
    module = ast.parse("""
    '''A simple module'''
    def foo():pass
    """)
    module_vis

# Generated at 2022-06-23 22:51:12.424916
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()
    assert t is not None

# Generated at 2022-06-23 22:51:14.886658
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Unit test for constructor of class Python2FutureTransformer."""
    t = Python2FutureTransformer()
    assert isinstance(t, Python2FutureTransformer)

# Generated at 2022-06-23 22:51:16.961108
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer().target == (2, 7)
    # Test that the target is assigned correctly to the target property


# Generated at 2022-06-23 22:51:17.568534
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()
    assert t.target == (2, 7)

# Generated at 2022-06-23 22:51:19.326666
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__doc__ is not None



# Generated at 2022-06-23 22:51:27.684603
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node_class = ast.Module

    code = '''
    a = 1
    b = 2
    c = 3
    '''
    expected = '''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    a = 1
    b = 2
    c = 3
    '''
    tree = ast.parse(code)
    tree = Python2FutureTransformer().visit(tree)
    result = astunparse.unparse(tree)

    assert result == expected
    assert isinstance(tree, node_class)

# Generated at 2022-06-23 22:51:29.243089
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()
    assert t.target == (2, 7)

# Generated at 2022-06-23 22:51:29.924303
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # can be constructed
    Python2FutureTransformer()

# Generated at 2022-06-23 22:51:33.516888
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..base import PYTHON_VERSION_INFO

    if PYTHON_VERSION_INFO < Python2FutureTransformer.target:
        pytest.skip('not applicable to python version: {}'.format(PYTHON_VERSION_INFO))
    trans = Python2FutureTransformer()
    module = ast.parse('print("hello world")')
    print(ast.dump(module))
    trans.visit(module)
    print(ast.dump(module))

# Generated at 2022-06-23 22:51:43.309302
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Setup
    target, tree = create_parsed_tree_for(
        '''
        import os
        import sys
        import math
        import re

        class MyClass:
            pass
        '''
    )
    transformer = Python2FutureTransformer(target)
    # Exercise
    result = transformer.visit_Module(tree)
    # Verify
    result = parse_ast_node(result)
    assert str(result) == \
        '''
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        import os
        import sys
        import math
        import re
        class MyClass:
            pass
        '''


Python2FutureTransformer.add_to_registry()

# Generated at 2022-06-23 22:51:49.921340
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import unittest.mock
    import astroid
    module = unittest.mock.MagicMock(spec=astroid.scoped_nodes.Module)
    node = ast.Module([], type_ignores=[])
    module.body.return_value = node.body
    transformer = Python2FutureTransformer()
    result = transformer.visit_Module(node)
    assert result is node
    assert transformer.tree_changed()
    assert result.body == \
        imports.get_body(future='__future__')

# Generated at 2022-06-23 22:51:59.303743
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    
    mod = ast.parse('''
    import inspect
    import os
    import sys
    import unittest 
    ''')
    visitor = Python2FutureTransformer()
    new_mod = visitor.visit(mod)
    assert new_mod.body[0].names[0].name == "absolute_import"
    assert new_mod.body[1].names[0].name == "division"
    assert new_mod.body[2].names[0].name == "print_function"
    assert new_mod.body[3].names[0].name == "unicode_literals"
    assert new_mod.body[4].names[0].name == "inspect"
    assert new_mod.body[5].names[0].name == "os"


# Generated at 2022-06-23 22:52:01.802294
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Test if constructor works without errors"""
    t = Python2FutureTransformer()
    assert t

# Unit tests for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-23 22:52:08.671958
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    x = Python2FutureTransformer()
    module = ast.parse('1+1')
    module = x.visit(module)
    assert ast.dump(module) == '''Module(body=[ImportFrom(module='__future__', names=[alias(name='absolute_import', asname=None)], level=0), ImportFrom(module='__future__', names=[alias(name='division', asname=None)], level=0), ImportFrom(module='__future__', names=[alias(name='print_function', asname=None)], level=0), ImportFrom(module='__future__', names=[alias(name='unicode_literals', asname=None)], level=0), Expr(value=BinOp(left=Num(n=1), op=Add(), right=Num(n=1)))])'''


# Generated at 2022-06-23 22:52:18.611205
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    example1 = """
    import math
    import os
    import math
    """

    example2 = """
    import math
    import os
    import math
    import random
    """

    example3 = """
    import math
    import os
    import math
    import random

    def function_name():
        i = 0
        j = i + 1
        return j
    """

    example4 = """
    import math
    import os
    import math
    import random

    class DummyClass:
        def __init__(self):
            pass

        def __call__(self):
            pass
    """


# Generated at 2022-06-23 22:52:25.343851
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from ..utils.snippet import snippet
    from .Python2FutureTransformer import Python2FutureTransformer

    tree = ast.parse('k = 10')
    transformer = Python2FutureTransformer()
    transformer.visit(tree)
    assert any('from __future__ import absolute_import' in line for line in ast.dump(tree, include_attributes=False).split('\n'))
    assert any('from __future__ import division' in line for line in ast.dump(tree, include_attributes=False).split('\n'))
    assert any('from __future__ import print_function' in line for line in ast.dump(tree, include_attributes=False).split('\n'))

# Generated at 2022-06-23 22:52:35.341903
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-23 22:52:40.747085
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from nb2py.transformers.python2 import Python2FutureTransformer
    transformer = Python2FutureTransformer()
    node = ast.parse("print('hello')")
    transformer.visit(node)
    assert len(ast.dump(node)) > len(ast.dump(ast.parse("print('hello')")))

# Generated at 2022-06-23 22:52:45.603901
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    code = '''
    i = 0
    j = 1
    '''
    
    expected_code = '''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    
    i = 0
    j = 1
    '''
    module = ast.parse(code)
    Python2FutureTransformer().visit(module)
    transformed_code = astor.to_source(module).strip()
    assert transformed_code == expected_code, transformed_code

# Generated at 2022-06-23 22:52:51.870152
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module(): 
    from ..utils.utils import generate_code 
    example_code = "print(test)"
    node = ast.parse(example_code)
    transformer = Python2FutureTransformer()
    result = transformer.visit(node)
    assert generate_code(result) == \
"""from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

print(test)"""

# Generated at 2022-06-23 22:53:00.974262
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast27 as ast

    node1 = ast.Module(
        body=[
            ast.Import(
                names=[
                    ast.alias(
                        name='typing',
                        asname=None
                    )
                ]
            )
        ]
    )


# Generated at 2022-06-23 22:53:05.851595
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse("from __future__ import print_function\nfrom __future__ import unicode_literals\nimport sys\nprint(1, 'foo')", mode='exec')
    node_new = Python2FutureTransformer().visit(node)
    assert ast.dump(node, include_attributes=False) == ast.dump(node_new, include_attributes=False)

# Generated at 2022-06-23 22:53:08.783443
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ... import transform
    from . import tree

    py2tree = tree()
    py2tree.body.extend(imports.get_body(future='__future__'))
    assert transform(py2tree, Python2FutureTransformer) == tree()

# Generated at 2022-06-23 22:53:10.142965
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    node = ast.parse('print("hello world")')
    node = Python2FutureTransformer.run(node)
    print(ast.dump(node))

# Generated at 2022-06-23 22:53:11.135505
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import ast
    from asttokens import asttokens


# Generated at 2022-06-23 22:53:16.654165
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    old_node = ast.parse("print('Hi')")
    new_node = Python2FutureTransformer().visit(old_node)

# Generated at 2022-06-23 22:53:22.209464
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    class_ = Python2FutureTransformer
    tree = ast.parse(x)
    expected = ast.parse(y)
    t = class_()
    new_tree = t.visit(tree)
    assert ast.dump(new_tree) == ast.dump(expected)



# Generated at 2022-06-23 22:53:25.097587
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from .rewriter_test_framework import assert_equivalent_tree
    from .rewriter_test_framework import assert_tree_unchanged
    from .rewriter_test_framework import rewrite_one


# Generated at 2022-06-23 22:53:25.847890
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()

# Generated at 2022-06-23 22:53:28.214274
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils import run_transformer_on_string


# Generated at 2022-06-23 22:53:29.246464
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-23 22:53:38.750657
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .. import parse
    from .base import BaseNodeTransformerTest
    from .base import BaseNodeVisitor

    class MyVisitor(BaseNodeVisitor):
        def generic_visit(self, node):
            BaseNodeVisitor.generic_visit(self, node)
            return 'ok'

    class MyTest(BaseNodeTransformerTest):
        def test(self):
            tree = parse("a = {1, 2, 3}")
            MyVisitor().visit(tree)
            transformer = Python2FutureTransformer()
            transformer.visit(tree)
            return tree, transformer

    tree, transformer = MyTest().test()
    assert tree.body[0].value.args[0].elts[0].n == 2

# Generated at 2022-06-23 22:53:44.423920
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = ast.parse('a=1')
    actual = str(Python2FutureTransformer().visit(module))
    assert (actual ==
        'from __future__ import absolute_import\n'
        'from __future__ import division\n'
        'from __future__ import print_function\n'
        'from __future__ import unicode_literals\n'
        'a = 1')

# Generated at 2022-06-23 22:53:50.315821
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    node = ast.parse('print(a, b, c)')
    Python2FutureTransformer().visit(node)  # type: ignore
    assert isinstance(node, ast.Module)
    assert isinstance(node.body[0], ast.ImportFrom)
    assert node.body[0].module == '__future__'
    assert isinstance(node.body[1], ast.Expr)
    assert isinstance(node.body[1].value, ast.Call)
    assert node.body[1].value.func.id == 'print'

# Generated at 2022-06-23 22:53:52.419816
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'

# Generated at 2022-06-23 22:54:00.529314
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    transformer = Python2FutureTransformer()
    simple_module = ast.Module()
    simple_module.body = []
    assert transformer.visit(simple_module) == \
        ast.Module(body=[
            ast.ImportFrom(module='__future__',
                           names=[ast.alias(name='absolute_import', asname=None),
                                  ast.alias(name='division', asname=None),
                                  ast.alias(name='print_function', asname=None),
                                  ast.alias(name='unicode_literals', asname=None)],
                           level=0),
        ])

# Generated at 2022-06-23 22:54:05.244746
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    expected_out_ast = ast.parse('from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n')
    out_ast = Python2FutureTransformer().visit(ast.parse('a = 1\n'))
    assert ast.dump(out_ast) == ast.dump(expected_out_ast)



# Generated at 2022-06-23 22:54:06.768026
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # This shows how to construct the class.
    Python2FutureTransformer(None, None)

# Generated at 2022-06-23 22:54:10.884236
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = ast.parse('')
    transformer = Python2FutureTransformer(module)
    module = transformer.visit(module)
    assert isinstance(module, ast.Module)
    assert len(module.body) == 4
    assert isinstance(module.body[0], ast.ImportFrom)
    assert module.body[0].module == '__future__'

# Generated at 2022-06-23 22:54:17.478895
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from . import assert_source_equal

    assert_source_equal(Python2FutureTransformer().visit(ast.parse("""
        print("Hello world!")
    """)), """
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        print("Hello world!")
    """)


# Generated at 2022-06-23 22:54:23.994442
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .common import build_ast
    from .common import transform_and_compare
    tree = build_ast('', 2)
    trans = Python2FutureTransformer()
    tree = trans.visit(tree)
    orig = '''
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
        '''.strip()
    new = ''.join([t.strip() for t in ast.dump(tree).splitlines()])
    assert new == orig, transform_and_compare(orig, new)



# Generated at 2022-06-23 22:54:34.597413
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typing import List

    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Future, AST, Module

    from . import python2_7
    from .base import BaseNodeTransformer

    from ..utils.transformers.node_visitor import NodeVisitor

    from ..utils.snippet import snippet
    from ..utils.transformers.base import BaseNodeTransformer

    from .python2_future import Python2FutureTransformer

    code = """
    import sys
    """

    module = ast.parse(code)
    visitor = NodeVisitor(module, Python2FutureTransformer())

    node = visitor.visit()
    assert isinstance(node, AST)

    # check if node is modified
    assert isinstance(node, Module)

    # check if node body is list of Future and Import nodes

# Generated at 2022-06-23 22:54:36.792483
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    before = module_from_file('python2_before.py')
    after = module_from_file('python2_after.py')
    assert Python2FutureTransformer(before) == after

# Generated at 2022-06-23 22:54:39.794264
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor
    tree = (ast.parse(imports.get_body(future='__future__') +
                      'from typing import List'))
    assert (astor.to_source(tree) ==
            'from future import absolute_import\n'+
            'from future import division\n'+
            'from future import print_function\n'+
            'from future import unicode_literals\n'+
            'from typing import List\n')

# Generated at 2022-06-23 22:54:48.112830
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    from typing import List
    from .base import CodegenState
    from .base import PythonVersionInfo
    tree = ast.parse('''
    class Klass(object):
        def __init__(self):
            pass
    ''')
    expected_tree = ast.parse('''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    class Klass(object):
        def __init__(self):
            pass
    ''')
    for item in Python2FutureTransformer(CodegenState(PythonVersionInfo(2, 7))).visit(tree).body:
        assert item == expected_tree.body[1]

# Generated at 2022-06-23 22:54:49.545431
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Test for snippet"""
    assert isinstance(Python2FutureTransformer(), BaseNodeTransformer)

# Generated at 2022-06-23 22:54:52.640751
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import logging
    logger = logging.getLogger(__name__)
    logger.info('Test Python2FutureTransformer')
    import astor
    import typed_astunparse

# Generated at 2022-06-23 22:54:54.783617
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer((2, 7))
    assert hasattr(transformer, 'target')
    assert hasattr(transformer, 'visit_Module')

# Generated at 2022-06-23 22:54:56.115725
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3
    assert type(Python2FutureTransformer().visit(ast3.Module(body=[]))) is ast3.Module

# Generated at 2022-06-23 22:54:58.001997
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7), "should be (2, 7), but is {0}".format(transformer.target)


# Generated at 2022-06-23 22:55:04.874881
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    initial_code = "b = 10"
    expected_code = """\
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

b = 10"""

    tree = ast.parse(initial_code)
    Python2FutureTransformer().visit(tree)
    actual_code = astor.to_source(tree)

    assert actual_code == expected_code

# Generated at 2022-06-23 22:55:06.235372
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer is not None


# Generated at 2022-06-23 22:55:11.211689
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    orig = """
a = 1
"""
    expected = """
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

a = 1
"""
    transformer = Python2FutureTransformer()
    new_src = transformer.transform_source(orig, target=(2, 7))
    assert new_src == expected

# Generated at 2022-06-23 22:55:13.740810
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Unit test for constructor of class Python2FutureTransformer"""
    Python2FutureTransformer().visit(ast.parse(imports.get_code()))


# Generated at 2022-06-23 22:55:19.906773
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from _fixtures import as_module
    tree = as_module(
        ''
    )
    result = Python2FutureTransformer().visit(tree)
    assert result == as_module(
        '''
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        '''
    )



# Generated at 2022-06-23 22:55:24.786597
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = ast.parse("")
    transformer = Python2FutureTransformer()
    module_visited = transformer.visit(module)
    assert transformer._tree_changed is True
    assert module_visited.body[0].name == "__future__"
    assert module_visited.body[1].name == "__future__"
    assert module_visited.body[2].name == "__future__"
    assert module_visited.body[3].name == "__future__"

# Generated at 2022-06-23 22:55:25.366806
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer

# Generated at 2022-06-23 22:55:30.711339
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    assert Python2FutureTransformer.visit_Module.get_expected_tree() == \
            ast.parse('from __future__ import absolute_import\n'
                      'from __future__ import division\n'
                      'from __future__ import print_function\n'
                      'from __future__ import unicode_literals\n\n'
                      'x = 5')

# Generated at 2022-06-23 22:55:36.388718
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    code = """def add_numbe(a, b):
    return a + b"""
    tree = ast.parse(code)
    Python2FutureTransformer().visit(tree)
    assert ast.dump(tree).strip() == \
    """from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    def add_numbe(a, b):
        return a + b"""

# Generated at 2022-06-23 22:55:43.209165
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    from astor.code_gen import to_source
    from ..transformer_factory import get_transformer
    node = ast.parse('x = 1')
    t = get_transformer(Python2FutureTransformer)
    result = t.visit(node)
    expected = 'from __future__ import absolute_import\n' \
        'from __future__ import division\n' \
        'from __future__ import print_function\n' \
        'from __future__ import unicode_literals\n' \
        'x = 1\n'
    assert to_source(result) == expected

# Generated at 2022-06-23 22:55:44.407337
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-23 22:55:46.801190
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()
    assert isinstance(t, BaseNodeTransformer)
    assert t.target == (2, 7)
    assert not t.generic_visit(object())


# Generated at 2022-06-23 22:55:49.220436
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = ast.parse("import foo\nx = 0")
    module = Python2FutureTransformer().visit(module)
    assert module.body[0].value.s == '__future__'

# Generated at 2022-06-23 22:55:50.756750
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    mod = Python2FutureTransformer()
    assert mod is not None

# Generated at 2022-06-23 22:55:51.617169
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    pass

# Generated at 2022-06-23 22:55:58.348284
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from .samples import python2_function_def

    source = python2_function_def.source
    tree = ast.parse(source)
    new_tree = Python2FutureTransformer().visit(tree)
    assert ast.dump(tree, annotate_fields=False) != ast.dump(new_tree, annotate_fields=False)
    assert ast.dump(new_tree, annotate_fields=False) == python2_function_def.future_transformed_source

# Generated at 2022-06-23 22:56:05.317897
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    src = """
import sys

print("Hello World!!!")
"""
    expected_src = """
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
import sys

print("Hello World!!!")
"""
    expected_ast = ast.parse(expected_src)

    tree = ast.parse(src)
    transformer = Python2FutureTransformer()
    tree = transformer.visit(tree)

    assert ast.dump(tree) == ast.dump(expected_ast)

# Generated at 2022-06-23 22:56:08.132910
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast

    t = Python2FutureTransformer()

    assert isinstance(t, Python2FutureTransformer)
    assert isinstance(t, BaseNodeTransformer)
    assert isinstance(t, ast.NodeTransformer)

# Generated at 2022-06-23 22:56:18.293975
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import sys
    import io

    tree = ast.parse("print('hello world')")
    node_transformer = Python2FutureTransformer(tree, sys.stdout)
    tree = node_transformer.visit(tree)
    
    assert(node_transformer._tree_changed)

    node_transformer = Python2FutureTransformer(tree, sys.stdout)
    tree = node_transformer.visit(tree)
    
    assert(not node_transformer._tree_changed)

    file_obj = io.StringIO()
    node_transformer.print_tree(tree, file_obj=file_obj)
    file_obj.seek(0)
    output = file_obj.read()


# Generated at 2022-06-23 22:56:21.547964
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-23 22:56:27.381979
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    tree = ast.parse('''
        from __future__ import unicode_literals
    ''')
    Python2FutureTransformer().visit(tree)
    assert ast.dump(tree) == '''Module(body=[ImportFrom(module='__future__', names=[alias(name=unicode_literals, asname=None)], level=0)])'''
    
    
    



# Generated at 2022-06-23 22:56:37.022514
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    sample_module = '''
    import os
    import sys

    if __name__ == '__main__':
        print(1)
    '''

    module_tree = ast.parse(sample_module)
    p2tf = Python2FutureTransformer()
    p2tf.visit(module_tree)

    assert ast.dump(module_tree) == ast.dump(ast.parse(
        '''
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        import os
        import sys

        if __name__ == '__main__':
            print(1)
        '''
    ))

# Generated at 2022-06-23 22:56:40.910031
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer() 
    node = ast.parse("")
    assert_equals(imports.get_body(future='__future__') + [], transformer.visit_Module(node))

# Generated at 2022-06-23 22:56:45.284890
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()
    tree = ast.parse("x = 2")
    new_tree = transformer.visit(tree)
    assert new_tree != tree
    my_compile(new_tree, filename='<string>', mode='exec')



# Generated at 2022-06-23 22:56:50.933490
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_test_module, make_test_module_from_block
    module = make_test_module(
        '''from __future__ import with_statement
        import os'''
    )
    result = make_test_module_from_block(Python2FutureTransformer(module).body)
    expected = '''from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals


    from __future__ import with_statement
    import os'''

    assert expected == result, f"{result!r}"

# Generated at 2022-06-23 22:56:56.001735
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast.ast3 import parse
    from typed_ast.transforms.futurize import future_builtins
    from typed_ast.transforms.futurize import Python2FutureTransformer
    body_of_module = parse('foo(1, 2)').body
    tree = Python2FutureTransformer().visit(body_of_module[0])
    assert tree.value.func.id == 'print'

# Generated at 2022-06-23 22:56:59.926112
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor
    from ..utils.ast_helpers import ast_equal, load_ast

    source = """
    def f(x):
        return x + 1
    """
    expected = """
    from future import absolute_import
    from future import division
    from future import print_function
    from future import unicode_literals
    
    def f(x):
        return x + 1
    """
    tree = load_ast(source)
    Python2FutureTransformer().visit(tree)
    source = astor.to_source(tree)
    assert ast_equal(expected, source)

# Generated at 2022-06-23 22:57:02.752169
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast.ast3 import Module
    transformer = Python2FutureTransformer()
    assert transformer.visit(Module()) == Module(body=imports.get_body(future='__future__'))

# Generated at 2022-06-23 22:57:03.660661
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-23 22:57:05.871533
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # arrange
    from ..utils import get_ast
    from ..utils.dummy_context import DummyContext
    

# Generated at 2022-06-23 22:57:07.181206
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)

# Generated at 2022-06-23 22:57:08.738819
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert True

# Generated at 2022-06-23 22:57:10.983786
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # type: () -> None
    assert isinstance(Python2FutureTransformer(), (BaseNodeTransformer, ast.NodeTransformer))

# Generated at 2022-06-23 22:57:11.804853
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-23 22:57:12.660457
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()



# Generated at 2022-06-23 22:57:14.008830
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer(None, None).target == (2, 7)
    

# Generated at 2022-06-23 22:57:17.731044
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # Given
    node = ast.parse('x = 1')
    transformer = Python2FutureTransformer()

    # When
    node = transformer.visit(node)

    # Then
    assert transformer.tree_changed
    expected = ast.parse(imports.get_snippet(future='__future__') + 'x = 1')
    assert ast.dump(node, include_attributes=False) == ast.dump(expected, include_attributes=False)

# Generated at 2022-06-23 22:57:28.190711
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    code = """
        import logging
        import os
        import pickle
        import random
        import re

        def f():
            pass
    """
    expected_code = """
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        
        import logging
        import os
        import pickle
        import random
        import re

        def f():
            pass
    """
    root_node = ast.parse(code)
    transformer = Python2FutureTransformer()
    transformer.visit(root_node)
    actual_code = ast.unparse(root_node)
    assert actual_code == expected_code

# Generated at 2022-06-23 22:57:39.014205
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast.ast3 import Module, Str, FunctionDef, arguments
    from typed_ast import ast3
    class MyVisitor(ast.NodeVisitor):
        def visit_FunctionDef(self, node):
            return node
        def visit_Import(self, node):
            return node
    visitor = MyVisitor()

# Generated at 2022-06-23 22:57:46.840847
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()
    tree = ast.parse("X = 1")
    transformer.visit(tree)
    res = ast.dump(tree, AnsiToHTMLMatcher())

# Generated at 2022-06-23 22:57:49.556855
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)
    assert transformer.name == 'Python2FutureTransformer'

# Generated at 2022-06-23 22:57:56.111209
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    code = "def foo(): pass"
    tree = ast.parse(code)
    trans = Python2FutureTransformer()
    tree.body = trans.visit(tree.body)
    assert ast.dump(tree, include_attributes=True) == ast.dump(
        imports.get_tree(future='__future__')
        + ast.parse(code).body,
        include_attributes=True
    )



# Generated at 2022-06-23 22:57:57.424899
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer(): 
    assert Python2FutureTransformer is not None


# Generated at 2022-06-23 22:58:03.652426
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    code = "print('hello')"
    node = ast.parse(code, mode='eval')
    transformer = Python2FutureTransformer()
    transformer.visit(node)
    result = ast.unparse(node)
    target = """
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
print('hello')
"""
    assert result == target

# Generated at 2022-06-23 22:58:09.236561
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    node = ast.parse("pass")
    transformer = Python2FutureTransformer()
    transformer.visit(node)
    print(astor.to_source(node))
    assert astor.to_source(node).strip() == """\
from __future__ import absolute_import        # type: ignore
from __future__ import division               # type: ignore
from __future__ import print_function         # type: ignore
from __future__ import unicode_literals       # type: ignore
pass"""

# Generated at 2022-06-23 22:58:11.483434
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    try:
        Python2FutureTransformer(None)
    except TypeError:
        pytest.fail("test_Python2FutureTransformer() raised unexpectedly")


# Generated at 2022-06-23 22:58:13.572662
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..transformer import from_source
    from . import run_test_ast


# Generated at 2022-06-23 22:58:14.584543
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert repr(Python2FutureTransformer()) != ""

# Generated at 2022-06-23 22:58:24.265477
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from asttokens import AstTokens
    from ..utils.source import Source
    source = Source('def foo():\n\tpass\n')
    atok = AstTokens(source.read(), parse=True)
    module = atok.tree
    old_module_str = atok.get_text()
    transformer = Python2FutureTransformer()
    new_module = transformer.visit(module)
    new_astok = AstTokens(module=new_module, split_lines=True)
    new_module_str = new_astok.get_text()
    print('-' * 20)
    print(old_module_str)
    print('-' * 20)
    print(new_module_str)
    print(transformer.pformat_messages())
    assert transformer._tree_changed

