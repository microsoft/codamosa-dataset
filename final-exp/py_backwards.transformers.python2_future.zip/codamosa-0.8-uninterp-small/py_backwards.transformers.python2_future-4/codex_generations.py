

# Generated at 2022-06-25 22:18:16.714644
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import typed_ast._ast3 as module_0
    import ast
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    python2_future_transformer_0.visit_Module(ast.Module())

# Generated at 2022-06-25 22:18:19.030853
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)


# Generated at 2022-06-25 22:18:26.036842
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    #python 2
    source_Code_0 = "print(\"Hello world\")"
    a_s_t_0 = ast.parse(source_Code_0)
    python2_future_transformer_0 = Python2FutureTransformer()
    python2_future_transformer_0.visit(a_s_t_0)
    code_obj_0 = compile(a_s_t_0, "<string>", mode="exec")
    with captured_output() as (out, err):
        exec(code_obj_0)
    output = out.getvalue().strip()
    assert outpu

# Generated at 2022-06-25 22:18:30.049642
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    # TODO: Write test case
    assert False


# Generated at 2022-06-25 22:18:37.840766
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST(
        body=[module_0.ImportFrom(module='__future__', names=[module_0.alias(name='absolute_import', asname=None)], level=0)])
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_1 = module_0.Module(body=[module_0.ImportFrom(module='__future__', names=[module_0.alias(name='absolute_import', asname=None)], level=0)])
    python2_future_transformer_0.visit_Module(module_1)
    assert python2_future_transformer_0._tree_changed == True

    # TODO: test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-25 22:18:43.943006
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_1 = a_s_t_0.Module([
    ], 0, 0)
    module_2 = python2_future_transformer_0.visit_Module(module_1)
    assert module_2.body[0].value.value == '__future__'

# Generated at 2022-06-25 22:18:48.112283
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    ast_node_0 = module_0.Module()
    python2_future_transformer_0.visit_Module(ast_node_0)

# Generated at 2022-06-25 22:18:57.510629
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
  # Setup
  a_s_t_0 = module_0.AST()
  python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)

  # Invocation
  result_0 = python2_future_transformer_0.visit_Module(a_s_t_0)

  # Assertions
  if not result_0:
    raise AssertionError()

# Generated at 2022-06-25 22:19:07.926716
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import ast
    import sys
    a_s_t_0 = ast.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    a_s_t_1 = ast.AST()
    python2_future_transformer_1 = Python2FutureTransformer(a_s_t_1)
    a_s_t_2 = ast.AST()
    python2_future_transformer_2 = Python2FutureTransformer(a_s_t_2)
    python2_future_transformer_2._tree_changed = python2_future_transformer_0._tree_changed
    a_s_t_3 = ast.AST()
    python2_future_transformer_3 = Python2FutureTransformer(a_s_t_3)
    python

# Generated at 2022-06-25 22:19:14.709607
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)

    module_1 = module_0.Module()
    python2_future_transformer_0._tree_changed = False

    module_1 = python2_future_transformer_0.visit_Module(module_1)
    assert python2_future_transformer_0._tree_changed
    assert len(module_1.body) == 1
    assert type(module_1.body[0]) == module_0.ImportFrom


# Generated at 2022-06-25 22:19:19.509685
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    m_0 = module_0.Module()
    python2_future_transformer_0.visit(m_0)

# Generated at 2022-06-25 22:19:24.698402
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    a_s_t_0.body = []
    a_s_t_0 = python2_future_transformer_0.visit_Module(a_s_t_0)
    assert not hasattr(a_s_t_0, 'body')

# Generated at 2022-06-25 22:19:31.024952
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_1 = module_0.Module()
    module_1.body = []
    module_1.col_offset = 0
    module_1.lineno = 1
    module_1.end_col_offset = 0
    module_1.end_lineno = 1
    module_1.type_ignores = []
    python2_future_transformer_0.visit_Module(module_1)

# Generated at 2022-06-25 22:19:35.510314
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_0_0 = module_0.Module(body=())
    python2_future_transformer_0.visit_Module(module_0_0)

# Generated at 2022-06-25 22:19:37.767138
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)


# Generated at 2022-06-25 22:19:41.725711
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_0 = module_0.Module([], lineno=0, col_offset=0)
    module_0 = python2_future_transformer_0.visit_Module(module_0)

# Generated at 2022-06-25 22:19:47.723988
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_1 = module_0.Module([])
    module_1 = python2_future_transformer_0.visit_Module(module_1)
    assert module_1 is not None


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-25 22:19:57.268623
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    assert (1 == len(module_0.ImportFrom(module="__future__",names=[module_0.alias(name="unicode_literals",asname=None)],level=0).names))
    module_0_1 = module_0.Module(body=[module_0.ImportFrom(module="__future__",names=[module_0.alias(name="unicode_literals",asname=None)],level=0)])
    python2_future_transformer_0.visit(module_0_1)

# Generated at 2022-06-25 22:20:00.943784
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_0_0 = module_0.Module()
    python2_future_transformer_0.visit_Module(module_0_0)


# Generated at 2022-06-25 22:20:03.865905
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_1 = module_0.Module()
    module_2 = python2_future_transformer_0.visit_Module(module_1)

# Generated at 2022-06-25 22:20:17.369229
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_1 = module_0.Module([], [])
    module_2 = python2_future_transformer_0.visit_Module(module_1)
    assert python2_future_transformer_0._tree_changed is True, 'Expected tree changed'
    assert isinstance(module_2, module_0.Module), 'Expected result type is module_0.Module'
    assert len(module_2.body) == 4, 'Expected result length is 4'
    assert isinstance(module_2.body[0], module_0.ImportFrom), 'Expected result type is module_0.ImportFrom'

# Generated at 2022-06-25 22:20:21.294652
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_2 = module_0.Module([])
    module_3 = python2_future_transformer_0.visit_Module(module_2)

# Generated at 2022-06-25 22:20:24.062242
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.Module([], _fields={})
    python2_future_transformer_0 = Python2FutureTransformer._create_empty_object(a_s_t_0)
    method_test_0 = python2_future_transformer_0.visit_Module(a_s_t_0)


# Generated at 2022-06-25 22:20:27.910094
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_1 = a_s_t_0.Module(body=[])
    python2_future_transformer_0.visit_Module(module_1)

# Generated at 2022-06-25 22:20:36.732938
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_1 = module_0.Module()
    python2_future_transformer_0._tree_changed = False
    module_2 = python2_future_transformer_0.visit_Module(module_1)
    assert module_2.body[0] == module_0.ImportFrom(module=None, names=[module_0.alias(name='absolute_import', asname=None)], level=0)
    assert module_2.body[1] == module_0.ImportFrom(module=None, names=[module_0.alias(name='division', asname=None)], level=0)

# Generated at 2022-06-25 22:20:46.209246
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    a_s_t_1 = module_0.AST()
    a_s_t_2 = module_0.Module()
    a_s_t_2.body = a_s_t_1.copy_body()
    a_s_t_3 = python2_future_transformer_0.visit_Module(a_s_t_2)
    assert a_s_t_3 is a_s_t_2
    assert a_s_t_2.body == a_s_t_1.copy_body()
    assert python2_future_transformer_0._tree_changed == True
    assert a_s_t

# Generated at 2022-06-25 22:20:50.392763
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_0 = module_0.Module()
    module_0.body = [module_0.Expr(value=module_0.Name(id='a', ctx=module_0.Load()))]
    python2_future_transformer_0.visit_Module(module_0)

# Generated at 2022-06-25 22:20:55.606017
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_1 = module_0.AST()
    python2_future_transformer_1 = Python2FutureTransformer(a_s_t_1)

if __name__ == "__main__":
    test_case_0()
    test_Python2FutureTransformer_visit_Module()

# Generated at 2022-06-25 22:21:04.247419
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    a_m_0 = module_0.Module()
    python2_future_transformer_0.visit_Module(a_m_0)
    assert python2_future_transformer_0._tree_changed == True
    assert python2_future_transformer_0._base_tree.type_and_name == "Module()"
    assert python2_future_transformer_0._base_tree.id == 1
    assert python2_future_transformer_0._base_tree.parent == None
    assert python2_future_transformer_0._base_tree.children == [a_m_0]
    a_m_1 = module_

# Generated at 2022-06-25 22:21:13.098716
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    a_s_t_1 = module_0.Module(body=[])
    python2_future_transformer_0.visit_Module(a_s_t_1)


# Generated at 2022-06-25 22:21:24.189189
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass


# Generated at 2022-06-25 22:21:28.966730
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    m_0 = module_0.Module()
    python2_future_transformer_0.visit_Module(m_0)

# Generated at 2022-06-25 22:21:32.217497
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    assert Python2FutureTransformer.visit_Module is Python2FutureTransformer.visit_Module
    Python2FutureTransformer.visit_Module(Python2FutureTransformer)
    Python2FutureTransformer.visit_Module(Python2FutureTransformer)


# Generated at 2022-06-25 22:21:40.864026
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():

    # Python3 code
    # def foo():
    #     pass
    #
    # print 1, 2, 3

    _module_0 = Python2FutureTransformer.get_ast('def foo():\n    pass\n\nprint(1, 2, 3)\n') # type: ast.Module
    python2_future_transformer_0 = Python2FutureTransformer(_module_0)

    module_1 = python2_future_transformer_0.visit_Module(_module_0) # type: ast.Module

    # Python2 code
    # from __future__ import absolute_import
    # from __future__ import division
    # from __future__ import print_function
    # from __future__ import unicode_literals
    #
    # def foo():
    #     pass
    #
    # print(1,

# Generated at 2022-06-25 22:21:44.325578
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_1 = module_0.Module()
    module_2 = python2_future_transformer_0.visit_Module(module_1)

# Generated at 2022-06-25 22:21:47.585581
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_1 = a_s_t_0.Module()
    module_2 = python2_future_transformer_0.visit_Module(module_1)

# Generated at 2022-06-25 22:21:48.300310
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass


# Generated at 2022-06-25 22:21:52.860699
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_0 = module_0.Module()
    python2_future_transformer_0.visit_Module(module_0)

if __name__ == "__main__":
    test_case_0()
    test_Python2FutureTransformer_visit_Module()

# Generated at 2022-06-25 22:22:01.961790
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_0_0 = module_0.Module(body=list([]))
    python2_future_transformer_0.visit_Module(module_0_0)
    assert 'from __future__ import absolute_import' in str(module_0_0)
    assert 'from __future__ import division' in str(module_0_0)
    assert 'from __future__ import print_function' in str(module_0_0)
    assert 'from __future__ import unicode_literals' in str(module_0_0)

# Generated at 2022-06-25 22:22:07.865971
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():

    a_s_t_0 = ast.parse('print(1)')
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_0 = ast.Module([ast.Print(ast.Name('1', ast.Load()), [], True)])
    python2_future_transformer_0.visit_Module(module_0)


if __name__ == '__main__':
    test_case_0()
    test_Python2FutureTransformer_visit_Module()

# Generated at 2022-06-25 22:22:20.470515
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Params (method args only)
    module_x_var_0 = module_0.Module()
    # Set up context
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    # Invoke method
    module_x = python2_future_transformer_0.visit_Module(module_x_var_0)
    # Check return type
    assert type(module_x) == module_0.Module
    # Check return value

# Generated at 2022-06-25 22:22:24.670718
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    assert module_x_var_1 is module_x_var_0

# Generated at 2022-06-25 22:22:30.636712
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    with patch('typed_astunparse.unparse.Python2FutureTransformer._tree_changed', new_callable=PropertyMock) as mock_tree_changed:
        module_0.Module()
        python2_future_transformer_0 = Python2FutureTransformer(module_0.AST())
        python2_future_transformer_0.visit_Module(module_0.Module())
        assert mock_tree_changed.call_args_list[0] == call(python2_future_transformer_0)



# Generated at 2022-06-25 22:22:34.580598
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:22:40.708164
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    print(python2_future_transformer_0)
    # check that instance attributes are set correctly
    assert python2_future_transformer_0._tree_changed == False
    assert python2_future_transformer_0._mapping is None
    assert python2_future_transformer_0._future is None
    assert python2_future_transformer_0.future_gen_nodes is None



# Generated at 2022-06-25 22:22:44.486216
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:22:52.365500
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    python2_future_transformer_1 = Python2FutureTransformer(a_s_t_0)
    python2_future_transformer_2 = Python2FutureTransformer(a_s_t_0)
    python2_future_transformer_3 = Python2FutureTransformer(a_s_t_0)
    python2_future_transformer_4 = Python2FutureTransformer(a_s_t_0)
    python2_future_transformer_5 = Python2FutureTransformer(a_s_t_0)

    # Test with non-existant attribute
   

# Generated at 2022-06-25 22:22:57.778299
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import typed_ast._ast3 as module_0
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    assert type(module_x_var_1) == module_0.Module


# Generated at 2022-06-25 22:22:58.557781
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer()

# Generated at 2022-06-25 22:23:07.576395
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    assert isinstance(python2_future_transformer_0, Python2FutureTransformer)
    assert hasattr(python2_future_transformer_0, '_tree_changed')
    assert hasattr(python2_future_transformer_0, '_gen')
    assert hasattr(python2_future_transformer_0, '_ast')
    assert hasattr(python2_future_transformer_0, 'target')
    assert callable(getattr(python2_future_transformer_0, 'visit_Module', None))


# Generated at 2022-06-25 22:23:30.248249
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Test ast with given object of class Module.
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

    # Test that _tree_changed is True
    assert python2_future_transformer_0._tree_changed == True
    # Test that python2_future_transformer_0.future is equal to '__future__'
    assert python2_future_transformer_0.future == '__future__'
    # Test that module_x_var_1 is a Module

# Generated at 2022-06-25 22:23:34.100157
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    python2_future_transformer_0.visit_Module(module_x_var_0)


# Generated at 2022-06-25 22:23:35.152823
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    test_case_0()


# Generated at 2022-06-25 22:23:42.404938
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_0 = python2_future_transformer_0.visit_Module(module_x_var_0)
    module_x_var_1 = module_x_var_0.body
    subimport_0 = module_x_var_1[0]
    subimport_1 = module_x_var_1[1]
    subimport_2 = module_x_var_1[2]
    subimport_3 = module_x_var_1[3]

# Generated at 2022-06-25 22:23:46.701842
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    try:
        module_x_var_0 = module_0.Module()
        module_x_var_1 = module_0.AST()
        module_x_var_2 = Python2FutureTransformer(module_x_var_1)
        assert module_x_var_2 is not None
    except Exception as e:
        raise Exception(str(e)) from None


# Generated at 2022-06-25 22:23:49.713105
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    python2_future_transformer_0 = Python2FutureTransformer(module_0.AST())
    module_0_0 = module_0.Module()
    python2_future_transformer_0.visit_Module(module_0_0)

# Generated at 2022-06-25 22:23:54.204051
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    assert python2_future_transformer_0._tree_changed is True
    # this test fails because the line has been commented out
    # trying to figure out why gilles todo/fixme
    # assert python2_future_transformer_0._ast is a_s_t_0
    

# Generated at 2022-06-25 22:23:57.786947
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    # constructors: Python2FutureTransformer(tree: AST) -> Python2FutureTransformer
    # constructors: Python2FutureTransformer() -> Python2FutureTransformer


# Generated at 2022-06-25 22:24:01.958045
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:24:09.274989
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:24:46.528152
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

from typing import List, Dict, Any
import datetime

from typed_ast import ast3 as ast
from ..utils.snippet import snippet
from .base import BaseNodeTransformer

from ..utils.node_utils import collect_nodes



# Generated at 2022-06-25 22:24:51.847997
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    assert module_x_var_1 == None

import typed_ast._ast3 as module_1
from tyrell.transformer import BaseNodeTransformer as class_1


# Generated at 2022-06-25 22:24:55.577634
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:25:00.752070
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    print(module_x_var_1)
    return module_x_var_1

# Generated at 2022-06-25 22:25:01.489189
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    test_case_0()

# Generated at 2022-06-25 22:25:02.246871
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    assert test_case_0() == None

# Generated at 2022-06-25 22:25:03.195877
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    test_case_0()

# Generated at 2022-06-25 22:25:08.095140
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Branch 0
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    if (module_x_var_0 is not module_x_var_1):
        raise Exception("Failed")
    else:
        pass


# Generated at 2022-06-25 22:25:12.701836
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)


test_Python2FutureTransformer_visit_Module()
test_case_0()

# Generated at 2022-06-25 22:25:14.159409
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert hasattr(Python2FutureTransformer, '__init__')
    assert hasattr(Python2FutureTransformer, '__call__')


# Generated at 2022-06-25 22:26:29.611096
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_1 = Python2FutureTransformer(a_s_t_0)


# Generated at 2022-06-25 22:26:30.382109
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert 'a' > 'b'


# Generated at 2022-06-25 22:26:38.127339
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    assert type(module_x_var_1) == module_0.Module
    assert module_x_var_1.body[0].names[0].id == "absolute_import"
    assert module_x_var_1.body[1].names[0].id == "division"
    assert module_x_var_1.body[2].names[0].id == "print_function"

# Generated at 2022-06-25 22:26:45.181870
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    import ast
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    print(ast.dump(module_x_var_1, include_attributes=True, annotate_fields=False, include_dynamic_node_descriptors=True, indent='  '))
    print("\n")

if __name__ == '__main__':
    test_case_0()
    test_Python2FutureTransformer()

# Generated at 2022-06-25 22:26:48.629290
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:26:49.504418
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    test_case_0()

# Unit test generator for class Python2FutureTransformer

# Generated at 2022-06-25 22:26:52.339349
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:26:55.804110
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    assert module_x_var_1 is not None


# Generated at 2022-06-25 22:26:58.820121
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:26:59.937545
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    test_case_0()


if __name__ == '__main__':
    test_case_0()