

# Generated at 2022-06-25 22:18:18.193137
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    while True:
        if True:
            python2_future_transformer_0.visit_Module(module_0.Module())
            break

        if True:
            python2_future_transformer_0.visit_AST(module_0.AST())
            break


# Generated at 2022-06-25 22:18:24.139821
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    a_s_t_1 = module_0.Module()
    a_s_t_2 = module_0.Module()
    python2_future_transformer_0.visit(a_s_t_1)
    python2_future_transformer_0.visit(a_s_t_2)


# Generated at 2022-06-25 22:18:27.741279
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    python2_future_transformer_0.visit_Module(a_s_t_0)

# Generated at 2022-06-25 22:18:33.829628
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():

    # Setup:
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)

    # Preparation:
    # Note: preparation code is not required.
    # Test:
    # Note: test code is not required.
    try:
        python2_future_transformer_0.visit_Module(module_0.Module())
    except BaseException:
        pass

# Generated at 2022-06-25 22:18:39.785144
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Arrange
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)

    # Act
    python2_future_transformer_0.visit_Module(None)

    # Assert


# Generated at 2022-06-25 22:18:44.159267
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_0_0 = module_0.Module()
    python2_future_transformer_0.visit_Module(module_0_0)

# Generated at 2022-06-25 22:18:49.424415
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_1 = module_0.Module()
    expected_0 = module_1
    actual_0 = python2_future_transformer_0.visit_Module(module_1)
    assert actual_0 == expected_0

# Generated at 2022-06-25 22:18:52.934963
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_1 = ast.Module()

    python2_future_transformer_1 = Python2FutureTransformer()
    python2_future_transformer_1.visit(module_1)

#
from typing import List

from ..utils.snippet import snippet
from .base import BaseNodeTransformer
from .unpacking import UnpackingTransformer



# Generated at 2022-06-25 22:18:53.565136
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    pass

# Generated at 2022-06-25 22:19:03.858352
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_1 = module_0.AST()
    python2_future_transformer_1 = Python2FutureTransformer(a_s_t_1)
    a_s_t_2 = module_0.Module(body=[])
    a_s_t_3 = python2_future_transformer_1.visit(a_s_t_2)
    assert isinstance(a_s_t_3, module_0.Module)
    assert a_s_t_3.body[0] == module_0.ImportFrom(module="__future__", names=[module_0.alias(name="absolute_import", asname=None)], level=0)

# Generated at 2022-06-25 22:19:15.025600
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_0 = None
    i_var_0 = None
    for x_var_0 in a_s_t_0.iter_fields(module_x_var_0):
        i_var_0 = x_var_0
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    a_s_t_0.copy_location(module_x_var_1, module_x_var_0)
    i_var_0 = None

# Generated at 2022-06-25 22:19:17.549808
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_0 = None
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:19:21.454127
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_1 = module_0.AST()
    python2_future_transformer_1 = Python2FutureTransformer(a_s_t_1)
    module_x_var_2 = None
    module_x_var_3 = python2_future_transformer_1.visit_Module(module_x_var_2)

# Generated at 2022-06-25 22:19:30.419095
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    a_s_t_1 = module_0.AST()
    a_s_t_2 = module_0.AST()
    a_s_t_3 = module_0.AST()
    a_s_t_4 = module_0.AST()
    a_s_t_5 = module_0.AST()
    a_s_t_6 = module_0.AST()
    a_s_t_7 = module_0.AST()
    a_s_t_8 = module_0.AST()
    a_s_t_9 = module_0.AST()

# Generated at 2022-06-25 22:19:39.528423
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    
    a_s_t_0 = ast.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_0 = ast.Module([ast.Pass()])
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    assert module_x_var_1 is not module_x_var_0
    assert len(module_x_var_1.body) == 5
    assert isinstance(module_x_var_1.body[0], ast.ImportFrom)
    assert isinstance(module_x_var_1.body[1], ast.ImportFrom)

# Generated at 2022-06-25 22:19:44.386932
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_0 = None
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)


import typed_ast._ast3 as module_1

# Generated at 2022-06-25 22:19:48.380646
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_0 = None
    python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:19:52.651294
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
  a_s_t_0 = module_0.AST()
  python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
  module_x_var_0 = None
  python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:19:57.397478
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_0 = None
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    assert python2_future_transformer_0._tree_changed

# Generated at 2022-06-25 22:20:02.789644
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Prepare
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    # Assert pre-conditions
    # Execute
    module_x_var_0 = None
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    # Assert post-conditions
    assert python2_future_transformer_0._tree_changed is True

# Generated at 2022-06-25 22:20:13.449352
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # prepare
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_0 = None
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    # verify final state
    assert python2_future_transformer_0._tree_changed is True
    assert module_x_var_1 is not None

# Generated at 2022-06-25 22:20:16.272906
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # Return type of constructor of class Python2FutureTransformer
    x = Python2FutureTransformer()


if __name__ == "__main__":
    test_case_0()
    test_Python2FutureTransformer()

# Generated at 2022-06-25 22:20:24.253444
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_0 = None
    python2_future_transformer_0.visit_Module(module_x_var_0)
    module_x_var_0.body = [None]
    module_x_var_0.body[0] = None
    module_x_var_0.body[0] = module_0.Module(body=[])
    module_x_var_0.body[0].body[0] = None

# Generated at 2022-06-25 22:20:28.134908
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    assert python2_future_transformer_0 is not None, 'Unable to create instance of Python2FutureTransformer'

    # Unit test for visit_Module

# Generated at 2022-06-25 22:20:28.956344
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():

    # Module test case 0

    test_case_0()

# Generated at 2022-06-25 22:20:31.266430
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_x_var_0 = None
    python2_future_transformer_0 = Python2FutureTransformer(module_x_var_0)


# Generated at 2022-06-25 22:20:34.807433
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    assert (python2_future_transformer_0 != None), 'empty test'


# Generated at 2022-06-25 22:20:35.659259
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    test_case_0()


# Generated at 2022-06-25 22:20:40.655840
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_0 = None
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)


# Generated at 2022-06-25 22:20:44.789525
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_0 = None
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:20:55.999055
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    

# Generated at 2022-06-25 22:21:03.224758
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_var_2 = module_0.AST()
    python2_future_transformer_var_2 = Python2FutureTransformer(a_s_t_var_2)
    module_var_2 = None
    module_var_3 = python2_future_transformer_var_2.visit_Module(module_var_2)
    if True:
        python2_future_transformer_var_2.visit_Module(module_var_3)
    module_var_4 = python2_future_transformer_var_2.visit_Module(module_var_3)

# Generated at 2022-06-25 22:21:11.987067
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_0 = None
    # State before method call
    assert python2_future_transformer_0.a_s_t == a_s_t_0
    assert python2_future_transformer_0._tree_changed == False

    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

    # State after method call
    assert python2_future_transformer_0._tree_changed == True
    assert python2_future_transformer_0.a_s_t == a_s_t_0



# Generated at 2022-06-25 22:21:13.056051
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    test_case_0()

# Generated at 2022-06-25 22:21:18.373468
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():

    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_0 = None
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    return None

# Generated at 2022-06-25 22:21:26.263348
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_0 = None
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    assert module_x_var_1 is not None
    assert module_x_var_1 is not None

# Generated at 2022-06-25 22:21:29.774715
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as module_0
    a_s_t_0 = module_0.AST()
    assert isinstance(Python2FutureTransformer(a_s_t_0), Python2FutureTransformer)

# Generated at 2022-06-25 22:21:38.432257
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_2 = module_0.AST()
    python2_future_transformer_1 = Python2FutureTransformer(a_s_t_2)
    a_s_t_3 = module_0.AST()
    python2_future_transformer_2 = Python2FutureTransformer(a_s_t_3, 2)
    a_s_t_4 = module_0.AST()
    python2_future_transformer_3 = Python2FutureTransformer(a_s_t_4, 2, "foo")
    a_s_t_5 = module_0.AST()
    python2_future_transformer_4 = Python2FutureTransformer(a_s_t_5, 2, "foo", "bar")
    a_s_t_6 = module_0.AST()


# Generated at 2022-06-25 22:21:39.562425
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert hasattr(Python2FutureTransformer, '__init__')


# Generated at 2022-06-25 22:21:42.718034
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    assert isinstance(python2_future_transformer_0, Python2FutureTransformer)


# Generated at 2022-06-25 22:22:05.891420
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from typed_ast._ast3 import Module
    import typing
    module_var_0 = Module([])
    a_s_t_var_0 = ast.AST()
    python2_future_transformer_var_0 = Python2FutureTransformer(a_s_t_var_0)
    module_x_var_0 = None
    module_x_var_1 = python2_future_transformer_var_0.visit_Module(module_x_var_0)
    typing.get_type_hints(module_x_var_1)

# Generated at 2022-06-25 22:22:08.090636
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)

# Generated at 2022-06-25 22:22:08.619899
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass

# Generated at 2022-06-25 22:22:12.132637
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_1 = module_0.AST()
    python2_future_transformer_1 = Python2FutureTransformer(a_s_t_1)
    assert python2_future_transformer_1 != None

if __name__ == '__main__':
    test_case_0()
    test_Python2FutureTransformer()

# Generated at 2022-06-25 22:22:16.931048
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_1 = module_0.AST()
    python2_future_transformer_1 = Python2FutureTransformer(a_s_t_1)

if __name__ == "__main__":
    # Unit test for method visit_Module of class Python2FutureTransformer
    test_case_0()
    test_Python2FutureTransformer()

# Generated at 2022-06-25 22:22:20.841362
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_0 = None
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:22:22.202482
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    test_case_0()

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 22:22:24.954809
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    assert isinstance(python2_future_transformer_0, Python2FutureTransformer)


# Generated at 2022-06-25 22:22:33.268378
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_0 = None
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    assert isinstance(module_x_var_1, module_0.Module)

    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_3 = None
    module_x_var_4 = python2_future_transformer_0.visit_Module(module_x_var_3)

# Generated at 2022-06-25 22:22:37.343784
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # No exception raised
    import typed_ast._ast3 as module_0
    try:
        a_s_t_0 = module_0.AST()
        python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    except TypeError as e:
        assert False
    else:
        assert True


# Generated at 2022-06-25 22:23:11.728900
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)


# Generated at 2022-06-25 22:23:18.134611
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # __main__.module_0.Module
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_0 = None
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    assert module_x_var_1 == None
    assert python2_future_transformer_0._tree_changed == True

test_cases = [
    test_case_0,
]


# Generated at 2022-06-25 22:23:18.942052
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass


# Generated at 2022-06-25 22:23:22.185311
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # manually defined constructor arguments
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    assert python2_future_transformer_0 is not None


# Generated at 2022-06-25 22:23:27.041115
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_0 = None
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:23:31.113561
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_0 = None
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    assert 1 == 1


# Generated at 2022-06-25 22:23:35.299002
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_3 = None
    module_x_var_4 = python2_future_transformer_0.visit_Module(module_x_var_3)


# Generated at 2022-06-25 22:23:39.156993
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_0 = None
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    assert module_x_var_1 == None


# Generated at 2022-06-25 22:23:40.238152
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert True


# Generated at 2022-06-25 22:23:43.773175
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_0 = None
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)



# Generated at 2022-06-25 22:25:04.664684
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_var_0 = module_0.AST()
    python2_future_transformer_var_0 = Python2FutureTransformer(a_s_t_var_0)
    module_x_var_2 = None
    assert python2_future_transformer_var_0.visit_Module(module_x_var_2) is None


# Generated at 2022-06-25 22:25:07.531525
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # Arrange
    a_s_t_0 = module_0.AST()

    # Act
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)

    # Assert
    assert python2_future_transformer_0 is not None


# Generated at 2022-06-25 22:25:11.586958
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_0 = None
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    assert module_x_var_1 is not None

# Generated at 2022-06-25 22:25:14.931401
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_0 = None
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:25:18.181085
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_0 = None
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:25:21.981115
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_var_0 = module_0.AST()
    python2_future_transformer_var_0 = Python2FutureTransformer(a_s_t_var_0)
    a_s_t_var_1 = python2_future_transformer_var_0._tree
    print((a_s_t_var_1))


# Generated at 2022-06-25 22:25:25.917476
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_0 = None
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)


# -------------------------

import typed_ast._ast3 as module_0


# Generated at 2022-06-25 22:25:27.802716
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_2 = module_0.AST()
    Python2FutureTransformer(a_s_t_2)

# Generated at 2022-06-25 22:25:29.691462
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)

# Generated at 2022-06-25 22:25:32.585885
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    try:
        test_case_0()
    except AssertionError as e:
        print('AssertionError raised for unit test for method Python2FutureTransformer.visit_Module')
        raise
    except Exception as e:
        print("Exception raised for unit test for method Python2FutureTransformer.visit_Module")
        raise