

# Generated at 2022-06-25 22:18:12.448783
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    assert not hasattr(python2_future_transformer_0, '_tree_changed')


# Generated at 2022-06-25 22:18:22.783769
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    from typed_ast import ast3 as a_s_t_1
    import typed_ast._ast3 as module_1
    module_1.AST()
    module_1.Module(body=[])
    module_1.Store()
    module_1.Load()
    module_1.Load()
    module_1.Load()
    module_1.Load()
    module_1.Load()
    module_1.Load()
    module_1.Load()
    module_1.Load()
    module_1.Load()
    module_1.Load()
    module_1.Load()
    module_1.Load()
    module_1

# Generated at 2022-06-25 22:18:30.495538
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    import sys
    import unittest
    from unittest.mock import patch

    class TestPython2FutureTransformerClass(unittest.TestCase):
        def test_visit_Module(self):
            with patch('sys.stdout', new=io.StringIO()) as mock_stdout:
                tree_0 = ast.parse(
                    """
                    def foo():
                      pass
                      return
                    """
                )
                python2_future_transformer_0.visit(tree_0)

# Generated at 2022-06-25 22:18:31.572544
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    _test_case_0(test_case_0)


# Generated at 2022-06-25 22:18:33.254099
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    test_case_0()

# Generated test for Python2FutureTransformer.visit_ImportFrom

# Generated at 2022-06-25 22:18:40.370218
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    a_s_t_1 = module_0.Module([], [])
    a_s_t_2 = python2_future_transformer_0.visit_Module(a_s_t_1)


# Generated at 2022-06-25 22:18:50.308775
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    # Test case where module.body is None
    module_0 = module_0.Module(body=None, type_ignores=[])
    try:
        module_0 = python2_future_transformer_0.visit_Module(module_0)
    except Exception:
        pass
    else:
        raise AssertionError

    # Test case where module.body is non-empty
    module_0 = module_0.Module(body=snippet.get_body(), type_ignores=[])

# Generated at 2022-06-25 22:18:55.000807
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_1 = module_0.Module()
    python2_future_transformer_0._tree_changed = False
    module_2 = python2_future_transformer_0.visit_Module(module_1)

    # Assert type of parameter node of method visit_Module of class Python2FutureTransformer
    assert isinstance(module_1, module_0.Module)



# Generated at 2022-06-25 22:19:01.451089
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_1 = python2_future_transformer_0.visit(module_0.Module([module_0.Expr(module_0.Num(23))]))
    assert isinstance(module_1, module_0.Module)
    assert len(module_1.body) == 16


# Generated at 2022-06-25 22:19:07.604865
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    try:
        module_1 = module_0.Module()
        python2_future_transformer_0.visit_Module(module_1)
    except Exception as returned:
        raised = returned

    assert raised is None

# Generated at 2022-06-25 22:19:12.651116
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    assert python2_future_transformer_0 is not None


# Generated at 2022-06-25 22:19:14.050270
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    assert True # TODO: implement your test here


# Generated at 2022-06-25 22:19:17.569260
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_0_0 = module_0.Module()
    python2_future_transformer_0.visit_Module(module_0_0)


# Generated at 2022-06-25 22:19:21.151333
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    test_0 = module_0.Module()
    python2_future_transformer_0.visit_Module(test_0)

# Generated at 2022-06-25 22:19:25.792189
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    assert python2_future_transformer_0 is not None
    assert isinstance(python2_future_transformer_0, Python2FutureTransformer)
test_Python2FutureTransformer()


# Generated at 2022-06-25 22:19:26.647745
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    test_case_0()

# Generated at 2022-06-25 22:19:34.336387
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = ast.parse("from __future__ import absolute_import")
    a_s_t_0.body[0].lineno = 1
    a_s_t_0.body[0].col_offset = 0
    a_s_t_0 = ast.Module(body=(a_s_t_0.body[0],))
    
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    python2_future_transformer_0.visit_Module(a_s_t_0)
    assert a_s_t_0.body[0].lineno == 3


# Generated at 2022-06-25 22:19:39.024323
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # Test whether the constructor of class Python2FutureTransformer instantiates a_s_t_0 and python2_future_transformer_0
    a_s_t_1 = module_0.AST()
    python2_future_transformer_1 = Python2FutureTransformer(a_s_t_1)

if __name__ == '__main__':
    import pytest
    pytest.main()

# Generated at 2022-06-25 22:19:48.303140
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    i_m_p_0 = module_0.ImportFrom(module='__future__', names=[module_0.alias(name='unicode_literals', asname=None)], level=0)
    i_m_p_1 = module_0.ImportFrom(module='__future__', names=[module_0.alias(name='print_function', asname=None)], level=0)
    i_m_p_2 = module_0.ImportFrom(module='__future__', names=[module_0.alias(name='division', asname=None)], level=0)

# Generated at 2022-06-25 22:19:49.564984
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    assert True


# Generated at 2022-06-25 22:19:54.843160
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    assert python2_future_transformer_0._tree_changed == False


# Generated at 2022-06-25 22:19:55.646877
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    test_case_0()



# Generated at 2022-06-25 22:20:01.169297
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)


if __name__ == '__main__':
    test_case_0()
    test_Python2FutureTransformer_visit_Module()

# Generated at 2022-06-25 22:20:06.135430
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():

    # Create module
    module_x_var_0 = module_0.Module()

    # Create AST
    a_s_t_0 = module_0.AST()

    # Create instance of class Python2FutureTransformer with param AST
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)

    # Call method visit_Module of class Python2FutureTransformer instance with param module_x_var_0
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

    # Assert
    assert type(module_x_var_1) == module_0.Module

# Generated at 2022-06-25 22:20:07.103939
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    test_case_0()

# Generated at 2022-06-25 22:20:11.701928
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)


# Generated at 2022-06-25 22:20:17.366208
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)


# Generated at 2022-06-25 22:20:21.295804
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    assert isinstance(python2_future_transformer_0, Python2FutureTransformer) and python2_future_transformer_0._tree_changed == False 


# Generated at 2022-06-25 22:20:22.738852
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Set up
    test_cases = [
        # TODO add test cases
    ]

    for test_case in test_cases:
        pass # TODO run test case

# Generated at 2022-06-25 22:20:24.873260
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)



# Generated at 2022-06-25 22:20:31.025106
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    try:
        test_case_0()
    except AssertionError:
        raise AssertionError("Test case failed")
    


# Generated at 2022-06-25 22:20:32.095513
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    test_case_0()

# Generated at 2022-06-25 22:20:38.334543
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Supply arguments that result in a specific internal state for the target object
    module_1 = module_0.Module()

    # Invoke method
    method_result_0 = Python2FutureTransformer.visit_Module(module_1)

    # Check return type
    assert isinstance(method_result_0, module_0.Module)
    # Check return value
    assert method_result_0 == module_0.Module()
    # Compare internal state of target object after method invocation
    assert module_1 == module_0.Module()

# Generated at 2022-06-25 22:20:40.075633
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert isinstance(python2_future_transformer_0, Python2FutureTransformer)



# Generated at 2022-06-25 22:20:40.882221
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # pass
    pass



# Generated at 2022-06-25 22:20:49.070064
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Test fixture for visit_Module

    # Test case for visit_Module

    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

if __name__ == '__main__':
    import sys

    if sys.argv[1] == '-v':
        print("test_case_0():")
        test_case_0()
        print("test_Python2FutureTransformer_visit_Module():")
        test_Python2FutureTransformer_visit_Module()
    else:
        import py

# Generated at 2022-06-25 22:20:56.815018
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Arrange
    module_x_var_0 = module_0.Module()

    # Act
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

    # Assert
    assert module_x_var_1 == module_x_var_0

# Generated at 2022-06-25 22:20:59.991282
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)

# Generated at 2022-06-25 22:21:04.082702
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_x_var_2 = module_0.Module()
    a_s_t_1 = module_0.AST()
    python2_future_transformer_1 = Python2FutureTransformer(a_s_t_1)
    python2_future_transformer_1.visit_Module(module_x_var_2)


# Generated at 2022-06-25 22:21:07.419635
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass

# Generated at 2022-06-25 22:21:16.799346
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass



# Generated at 2022-06-25 22:21:24.365821
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:21:34.151362
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():

    source = inspect.getsource(test_case_0)

# Generated at 2022-06-25 22:21:35.066936
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer(tree=None)

# Generated at 2022-06-25 22:21:39.295373
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    try:
        module_5 = module_0
        a_s_t_4 = module_5.AST()
        python2_future_transformer_6 = Python2FutureTransformer(a_s_t_4)
    except:
        python2_future_transformer_6 = None
    assert python2_future_transformer_6 is not None


# Generated at 2022-06-25 22:21:43.882104
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    assert hasattr(Python2FutureTransformer, '__init__')
    assert hasattr(Python2FutureTransformer, 'visit_Module')


# Generated at 2022-06-25 22:21:48.235560
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_2 = module_0.Module()
    a_s_t_1 = module_0.AST()
    python2_future_transformer_1 = Python2FutureTransformer(a_s_t_1)
    module_x_var_3 = python2_future_transformer_1.visit_Module(module_x_var_2)
    assert module_x_var_3 is not None
    assert module_x_var_3.body is not None

# Generated at 2022-06-25 22:21:53.908067
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Test fixture
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    # Test
    assert module_x_var_1 == module_x_var_0

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 22:21:55.584084
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
	test_case_0()

if __name__ == '__main__':
    import unittest
    unittest.main()

# Generated at 2022-06-25 22:22:04.743815
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_0_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_0_1 = python2_future_transformer_0.visit_Module(module_0_0)
    assert("""# PYTHON2""".encode() in module_0_1.body[0])
    assert("""# PYTHON2""".encode() in module_0_1.body[1])
    assert("""# PYTHON2""".encode() in module_0_1.body[2])
    assert("""# PYTHON2""".encode() in module_0_1.body[3])

# Generated at 2022-06-25 22:22:25.417513
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    python2_future_transformer_0.visit_Module(module_x_var_0)

test_case_0()
test_Python2FutureTransformer()

# Generated at 2022-06-25 22:22:33.716788
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import itertools
    import sys
    module_x_var_0 = module_0.Module()
    module_x_var_0.body = []
    module_x_var_1 = module_0.Module()
    module_x_var_1.body = []
    module_x_var_2 = module_0.Module()
    module_x_var_2.body = []
    module_x_var_3 = module_0.Module()
    module_x_var_3.body = []
    module_x_var_4 = module_0.Module()
    module_x_var_4.body = []
    module_x_var_5 = module_0.Module()
    module_x_var_5.body = []
    module_x_var_6 = module_0.Module()

# Generated at 2022-06-25 22:22:36.946701
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    test_case_0()



# Generated at 2022-06-25 22:22:42.632775
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # Instance created from constructor:
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    
    # Attribute node_mapping has type: typing.Dict[str, typing.Any]
    assert False
    # Attribute _tree_changed has type: bool
    assert False
    # Attribute _tree has type: typed_ast.ast3.AST
    assert False


# Generated at 2022-06-25 22:22:47.859750
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    try:
        module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    except:
        module_x_var_1 = None
    assert module_x_var_1 is None

# Generated at 2022-06-25 22:22:54.143300
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # module_0.Module()
    module_x_var_0 = module_0.Module()
    # module_0.AST()
    a_s_t_0 = module_0.AST()
    # Python2FutureTransformer(a_s_t_0)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    # python2_future_transformer_0.visit_Module(module_x_var_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    
    assert True

# Generated at 2022-06-25 22:22:56.433091
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():    
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)


# Generated at 2022-06-25 22:23:01.906743
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_0
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    assert python2_future_transformer_0._ast is a_s_t_0
    assert python2_future_transformer_0._tree_changed is True
    assert python2_future_transformer_0._warnings == []
    


# Generated at 2022-06-25 22:23:11.008414
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals


    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True

# Generated at 2022-06-25 22:23:13.034131
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    """Test None"""
    print("exception thrown")
    assert True

if __name__ == '__main__':
    test_Python2FutureTransformer_visit_Module()

# Generated at 2022-06-25 22:23:50.731370
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    test_case_0()

# Generated at 2022-06-25 22:23:55.224708
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

if __name__ == '__main__':
    test_case_0()
    test_Python2FutureTransformer()

# Generated at 2022-06-25 22:23:55.942270
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    #TODO: Add tests here
    pass

# Generated at 2022-06-25 22:24:01.063850
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)

    assert python2_future_transformer_0._tree_changed is None
    assert python2_future_transformer_0._tree_changed is None
    assert python2_future_transformer_0._tree_changed is None
    assert python2_future_transformer_0._tree_changed is None

# Generated at 2022-06-25 22:24:05.335365
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_1 = ast.AST()
    python2_future_transformer_1 = Python2FutureTransformer(a_s_t_1)
    assert python2_future_transformer_1._tree_changed == False
    assert python2_future_transformer_1._tree == a_s_t_1

from . import node_classes
from .node_classes import NodeClass


# Generated at 2022-06-25 22:24:09.114691
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    assert False # FIXME

# Generated at 2022-06-25 22:24:17.847948
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    variables = {} # type: Dict[str, Any]
    variables['module_0'] = importlib.import_module('typed_ast._ast3')
    variables['module_x_var_0'] = variables['module_0'].Module()
    variables['a_s_t_0'] = variables['module_0'].AST()
    variables['python2_future_transformer_0'] = Python2FutureTransformer(variables['a_s_t_0'])
    test_case_0(variables)
    variables['module_x_var_1'] = variables['python2_future_transformer_0'].visit_Module(variables['module_x_var_0'])

# Generated at 2022-06-25 22:24:18.737532
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
	test_case_0()

# Generated at 2022-06-25 22:24:21.837993
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    assert python2_future_transformer_0


# Generated at 2022-06-25 22:24:28.325841
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import typing
    from typed_ast import ast3 as ast

    from typed_ast import _ast3 as module_0
    def test_case_0():
        module_x_var_0 = module_0.Module()
        a_s_t_0 = module_0.AST()
        python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
        module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:26:02.136176
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:26:05.325842
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    test_case_0()

if __name__ == '__main__':
    import sys
    import xmlrunner
    runner = xmlrunner.XMLTestRunner(output=sys.path[0], outsuffix='.xml')
    runner.run(test_Python2FutureTransformer())

# Generated at 2022-06-25 22:26:11.207934
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    assert Python2FutureTransformer.visit_Module(module_0)
    assert Python2FutureTransformer.visit_Module(module_x_var_1)

# Generated at 2022-06-25 22:26:12.865682
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer('a_s_t_2') is not None, "Constructor test failed"
    

# Generated at 2022-06-25 22:26:14.075811
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass


# Generated at 2022-06-25 22:26:14.800574
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    test_case_0()


# Generated at 2022-06-25 22:26:23.782241
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    assert module_x_var_0 != module_x_var_1
    print(module_x_var_1)
    import sys; print('%s: %s' % (sys.argv[1], sys.getsizeof(module_x_var_1)))
    from . import Python2FutureTransformer

if __name__ == '__main__':
    test_Python2FutureTransformer_visit_Module()

# Generated at 2022-06-25 22:26:28.803511
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    python2_future_transformer_0 = Python2FutureTransformer(None)
    assert python2_future_transformer_0._tree_changed == False


# Generated at 2022-06-25 22:26:32.072419
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    assert python2_future_transformer_0.ast is a_s_t_0


# Generated at 2022-06-25 22:26:36.797150
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    assert module_x_var_1 == module_0.Module()