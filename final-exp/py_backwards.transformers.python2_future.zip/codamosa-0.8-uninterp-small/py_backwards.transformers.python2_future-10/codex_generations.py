

# Generated at 2022-06-25 22:18:19.888855
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_1 = a_s_t_0.Module([], a_s_t_0.Load())
    try:
        python2_future_transformer_0.visit_Module(module_1)
    except:
        return False
    return True

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 22:18:30.130513
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_1 = module_0.Module(body=[])
    python2_future_transformer_0.visit(module_1)

# Generated at 2022-06-25 22:18:34.064451
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    a_s_t_1 = module_0.Module()
    python2_future_transformer_0.visit_Module(a_s_t_1)

# Generated at 2022-06-25 22:18:40.973157
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_1 = module_0.AST()
    python2_future_transformer_1 = Python2FutureTransformer(a_s_t_1)
    module_1 = module_0.Module([])
    module_1 = python2_future_transformer_1.visit_Module(module_1)


if __name__ == '__main__':
    test_Python2FutureTransformer_visit_Module()

# Generated at 2022-06-25 22:18:45.906577
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():

    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_1 = module_0.Module([], lineno=0, col_offset=0)
    module_2 = python2_future_transformer_0.visit_Module(module_1)

# Generated at 2022-06-25 22:18:50.732868
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_1 = module_0.Module()
    module_1.body = None
    python2_future_transformer_0.visit_Module(module_1)
    

# Generated at 2022-06-25 22:18:52.839601
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a = 1
    b = 2
    assert a+b == 3


# Generated at 2022-06-25 22:19:03.196788
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    python2_future_transformer_0 = Python2FutureTransformer(ast)

    # Test with valid parameter values
    a_s_t_0 = ast.Module(body = [ast.FunctionDef(name = 'f', args = ast.arguments(args = [], vararg = None, kwarg = None, defaults = []), body = [ast.Expr(ast.Call(func = ast.Name(id = 'div', ctx = ast.Load()), args = [], keywords = [])), ast.Return(value = ast.Num(n = 2))], decorator_list = [])], type_ignores = [])
    python2_future_transformer_0.visit_Module(node = a_s_t_0)
    # Test with invalid parameter values
    #

# Generated at 2022-06-25 22:19:09.873524
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node_0 = module_0.Str('snippets/test_snippet_1.py')
    module_5 = module_0.Module(body=[node_0])
    a_s_t_6 = module_0.AST()
    python2_future_transformer_1 = Python2FutureTransformer(a_s_t_6)
    module_7 = python2_future_transformer_1.visit(module_5)

# Generated at 2022-06-25 22:19:14.985916
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    node = module_0.Module([])
    python2_future_transformer_0.visit_Module(node)
    # Check field body
    assert len(node.body) == 0


import typed_ast._ast3 as module_1


# Generated at 2022-06-25 22:19:20.950229
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_0 = module_0.Module()
    module_0.body = [module_0.Print()]
    python2_future_transformer_0.visit_Module(module_0)

# Generated at 2022-06-25 22:19:25.095249
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    module_1 = a_s_t_0.parse("pass")
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)

    python2_future_transformer_0.visit_Module(module_1)

# Generated at 2022-06-25 22:19:29.812498
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    code = "a = 2\nimport b\nclass c:\n    pass"
    node = ast.parse(code)
    Python2FutureTransformer().visit(node)

# Generated at 2022-06-25 22:19:34.471638
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_1 = module_0.AST()
    python2_future_transformer_1 = Python2FutureTransformer(a_s_t_1)
    module_1 = python2_future_transformer_1.visit(module_0.Module())
    python2_future_transformer_1.visit_Module(module_1)

# Generated at 2022-06-25 22:19:40.018996
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_0_0 = module_0.Module([module_0.Expr(module_0.Str('sample string'))], [module_0.Name(id='module_0_0', ctx=module_0.Load())])
    python2_future_transformer_0.visit_Module(module_0_0)

# Generated at 2022-06-25 22:19:44.610776
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    m_0 = module_0.Module([])
    python2_future_transformer_0.visit(m_0)
    assert m_0 is not None


# Generated at 2022-06-25 22:19:47.050764
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)

# Generated at 2022-06-25 22:19:52.969944
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    def visit_Module(module):
        return python2_future_transformer_0.visit_Module(module)
    node_0 = module_0.Module(
    )
    python2_future_transformer_0.visit(node_0)

# Generated at 2022-06-25 22:19:55.154311
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import inspect
    import ast
    m = ast.parse('print(1)')
    p = Python2FutureTransformer()
    p.visit(m)

# Generated at 2022-06-25 22:19:59.148803
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    a_s_t_1 = module_0.Module()
    python2_future_transformer_0.visit_Module(a_s_t_1)

# Generated at 2022-06-25 22:20:02.375515
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)

# Generated at 2022-06-25 22:20:08.070301
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)

if __name__ == "__main__":
    import logging
    logging.basicConfig(filename="tests/logs/object_oriented/test_python_2_future_transformer.log", filemode='w', level=logging.DEBUG)
    test_case_0()
    test_Python2FutureTransformer()

# Generated at 2022-06-25 22:20:18.233779
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    a_s_t_0_node_10 = module_0.Module()
    a_s_t_0_node_10_body_0 = [module_0.Print(dest=None, values=[], nl=True)]
    a_s_t_0_node_10.body = a_s_t_0_node_10_body_0
    python2_future_transformer_0._tree_changed = False
    python2_future_transformer_0.visit_Module(a_s_t_0_node_10)
    a_s_t_0_node_11 = module_0.Module()
    a_

# Generated at 2022-06-25 22:20:22.508088
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    try:
        python2_future_transformer_0.visit_Module(a_s_t_0)
    except Exception as e:
        print(e)


import typed_ast._ast3 as module_1


# Generated at 2022-06-25 22:20:25.968622
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    str_0 = "def f():\n    return 1\n"
    python2_future_transformer_0._tree_changed = True
    python2_future_transformer_0.visit_Module(str_0)

    assert str_0 == "def f():\n    return 1\n"

# Generated at 2022-06-25 22:20:33.317905
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    
    # Create AST
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.Module()
    
    # Add body to Module
    a_s_t_1.body = ['foo']
    
    # Create Python2FutureTransformer
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    
    # Visit Module
    python2_future_transformer_0.visit_Module(a_s_t_1)
    
    # Check
    assert a_s_t_1.body == imports.get_body(future='__future__')

# Generated at 2022-06-25 22:20:39.160912
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    source_code_0 = '# test file for class Python2FutureTransformer\n'
    module_1 = module_0.parse(source_code_0)
    node_0 = python2_future_transformer_0.visit_Module(module_1)

# Generated at 2022-06-25 22:20:44.907630
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    assert (python2_future_transformer_0 is not None)


import typed_ast._ast3 as module_0
import typing as tp_0

a_s_t_0 = module_0.AST()
python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)


# Generated at 2022-06-25 22:20:48.301196
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_0_0 = module_0.Module()
    python2_future_transformer_0.visit_Module(module_0_0)


# Generated at 2022-06-25 22:20:56.366068
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Setup
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_1 = a_s_t_0.Module([], [], [])

    # Exercise
    module_1 = python2_future_transformer_0.visit_Module(module_1)
    
    # Verification
    assert isinstance(module_1, module_0.Module) is True

# Generated at 2022-06-25 22:21:03.150854
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_1 = module_0.AST()
    python2_future_transformer_1 = Python2FutureTransformer(a_s_t_1)
    assert_equals(python2_future_transformer_1.target, (2, 7))


# Generated at 2022-06-25 22:21:08.430743
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)

# Generated at 2022-06-25 22:21:11.708093
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)


# Generated at 2022-06-25 22:21:14.333250
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)

# Generated at 2022-06-25 22:21:18.244862
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    ast_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(ast_0)


if __name__ == '__main__':
    test_Python2FutureTransformer()

# Generated at 2022-06-25 22:21:24.589179
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    a_s_t_0 = module_0.AST()
    python2_future_transformer_1 = Python2FutureTransformer(a_s_t_0)

# Generated at 2022-06-25 22:21:34.331168
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    python2_future_transformer_0 = Python2FutureTransformer()
    a_s_t_0 = python2_future_transformer_0.a_s_t
    input_node = """
    # coding: utf-8
    from __future__ import print_function


    def foo():
        print('foo')

    """
    expected_output_node = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    # coding: utf-8
    from __future__ import print_function


    def foo():
        print('foo')

    """
    input_node = a_s_t_0.parse(input_node)
    output_node = python2_future_transformer

# Generated at 2022-06-25 22:21:41.212990
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import ast
    a_s_t_2 = ast.Module()
    assert a_s_t_2.body == []
    a_s_t_1 = ast.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_1)
    python2_future_transformer_0._tree_changed = False
    assert python2_future_transformer_0._tree_changed == False
    assert python2_future_transformer_0.visit(a_s_t_2, a_s_t_1) == None
    assert a_s_t_2.body != []

# Generated at 2022-06-25 22:21:43.461782
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():

    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)


# Generated at 2022-06-25 22:21:46.252580
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    python2_future_transformer_0 = Python2FutureTransformer(None)
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0.visit_Module(a_s_t_0)


# Generated at 2022-06-25 22:21:56.948326
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    # python2_future_transformer_0.visit_Module()


# Generated at 2022-06-25 22:21:59.496862
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    test_case_0()


# Generated at 2022-06-25 22:22:08.824967
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Set up context
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)

    module_1 = module_0.Module([], [module_0.Expr(module_0.Call(module_0.Name('print', module_0.Load()), [module_0.Str('Hello, World!')], [], None, None))], [])

# Generated at 2022-06-25 22:22:09.913148
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    python2_future_transformer_0 = Python2FutureTransformer(None)


# Generated at 2022-06-25 22:22:13.132071
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_1 = module_0.Module([])
    python2_future_transformer_1 = Python2FutureTransformer(a_s_t_1)
    a_s_t_1 = python2_future_transformer_1.visit(a_s_t_1)

# Generated at 2022-06-25 22:22:18.657866
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_1 = module_0.Module([], [])
    module_2 = python2_future_transformer_0.visit_Module(module_1)
    module_2 = None


if __name__ == "__main__":
    main()

# Generated at 2022-06-25 22:22:20.841257
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)

# Generated at 2022-06-25 22:22:22.740173
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)


# Generated at 2022-06-25 22:22:25.729605
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    snippet
    module_0 = ast.Module()
    # 'Module' object has no attribute 'body'
    assert False

    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)

# Generated at 2022-06-25 22:22:30.047998
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    try:
        python2_future_transformer_0.visit(a_s_t_0)
    except Exception:
        pass

# Generated at 2022-06-25 22:22:39.191967
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    Python2FutureTransformer().visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:22:41.277494
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    Python2FutureTransformer.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:22:44.110816
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # Try to call function with incorrect input parameters
    try:
        Python2FutureTransformer(target)
    except TypeError:
        pass
    except Exception:
        raise Exception("Python2FutureTransformer() fails with incorrect input parameters")



# Generated at 2022-06-25 22:22:45.696206
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x = Python2FutureTransformer.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:22:47.328648
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    target = (2, 7)
    python2_future_transformer_var_0 = Python2FutureTransformer(target=target)


# Generated at 2022-06-25 22:22:50.044440
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    module_x_var_1 = BaseNodeTransformer()
    module_x_var_1.visit_Module(module_x_var_0)
    pass

# Generated at 2022-06-25 22:22:51.170166
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_x_var_0 = Python2FutureTransformer()


# Generated at 2022-06-25 22:22:53.149542
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    arg0 = module_x_var_0
    transformer = Python2FutureTransformer()
    assert transformer.visit_Module(arg0) is module_x_var_0

# Generated at 2022-06-25 22:22:54.347946
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_x_var_0 = Python2FutureTransformer()

# Generated at 2022-06-25 22:22:57.195977
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    """
    Tests Python2FutureTransformer visit_Module method
    """
    module_x_empty_0 = module_0.Module()
    module_x_empty_0 = Python2FutureTransformer().visit_Module(module_x_empty_0)


# Generated at 2022-06-25 22:23:12.848217
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from typed_ast._ast3 import Module

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__') + node.body  # type: ignore
            return self.generic_visit(node)  # type: ignore

    mod = ast.Module()

# Generated at 2022-06-25 22:23:16.093516
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    module_x_obj_0 = Python2FutureTransformer()
    module_x_var_1 = module_x_obj_0.visit(module_x_var_0)
    return module_x_var_1

# Generated at 2022-06-25 22:23:24.507384
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x = module_0
    module_x_var_0 = module_x.Module()
    module_x_var_0_var_0 = module_x_var_0.body
    module_x_var_0_var_0_var_0 = module_x.ImportFrom()
    module_x_var_0_var_0_var_0_var_0 = module_x_var_0_var_0_var_0.module
    module_x_var_0_var_0_var_0_var_1 = module_x_var_0_var_0_var_0.names
    module_x_var_0_var_0_var_0_var_1_var_0 = module_x.alias()
    module_x_var_0_var_0_var_0

# Generated at 2022-06-25 22:23:27.557932
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    module_0_var_0 = Python2FutureTransformer.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:23:28.632508
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # Tests with no arguments
    test_case_0()


# Generated at 2022-06-25 22:23:33.176345
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Sample
    from typed_ast import ast3 as ast
    tree = ast.parse("foo = 'original'")
    Python2FutureTransformer().visit(tree)
    test_case_0()
    # assert False, "TODO: Add Python2FutureTransformer.visit_Module test case"
    # Test
    # tree = ast.parse("foo = 'original'")
    # Python2FutureTransformer().visit(tree)

# Generated at 2022-06-25 22:23:34.316602
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_x_var_0 = Python2FutureTransformer()

# Generated at 2022-06-25 22:23:35.875128
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert_equals(Python2FutureTransformer().target, (2, 7))


# Generated at 2022-06-25 22:23:36.932809
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_x_var_0 = Python2FutureTransformer()

# Generated at 2022-06-25 22:23:37.992611
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_x_var_0 = Python2FutureTransformer()

# Generated at 2022-06-25 22:23:57.709811
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    module_x_var_0.body = []
    module_x_var_1 = Python2FutureTransformer()
    module_x_var_2 = module_x_var_1.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:24:05.693648
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = module_x_var_0
    transformer = Python2FutureTransformer()
    transformer.visit_Module(node)
    assert transformer._tree_changed
    assert transformer.target == (2, 7)
    assert transformer.column_offset == 0
    assert transformer.line_offset == 0
    assert transformer._lineno == 0
    assert transformer._col_offset == 0
    assert node.body[0] == ast.ImportFrom(module='__future__', names=(ast.alias(name='absolute_import', asname=None), ast.alias(name='division',asname=None), ast.alias(name='print_function',asname=None), ast.alias(name='unicode_literals',asname=None)), level=0)

# Generated at 2022-06-25 22:24:07.890812
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a = Python2FutureTransformer()
    module_x_var_0 = module_0.Module()
    module_x_var_1 = a.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:24:13.270260
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # Make an instance of the class
    args = []
    kwargs = {}
    transformer = Python2FutureTransformer(*args, **kwargs)
    # Ensure type of instance
    assert isinstance(transformer, Python2FutureTransformer)
    # unit test for method visit_Module
    node = module_x_var_0
    method_name = 'visit_Module'
    method = getattr(transformer, method_name)
    output = method(node)

# Generated at 2022-06-25 22:24:14.291021
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_x_var_0 = Python2FutureTransformer()


# Generated at 2022-06-25 22:24:17.462112
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer(module=module_x_var_0, debug=False)
    assert isinstance(transformer, Python2FutureTransformer)
    assert isinstance(transformer.module, module_0.Module)
    assert transformer.debug == False

# Generated at 2022-06-25 22:24:19.929021
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()
    result = transformer.visit(module_x_var_0)
    match_ast(result, module_0.Module(body=[], type_ignores=[]))

# Generated at 2022-06-25 22:24:22.318694
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    python2_future_transformer_var_0 = Python2FutureTransformer()
    python2_future_transformer_var_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:24:24.062013
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_x_var_0 = Python2FutureTransformer()


# Generated at 2022-06-25 22:24:28.779300
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Test Case 0
    module_x_var_0 = ast.Module()
    visitor = Python2FutureTransformer()
    visitor.visit_Module(module_x_var_0)
    """
    # If a testcase code is not passed, the test assertion below will fail with an error message saying 
    # "AttributeError: 'Python2FutureTransformer' object has no attribute '_tree_changed'"
    """

# Generated at 2022-06-25 22:25:05.615075
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    module_x_var_1 = module_0.Module()

# Generated at 2022-06-25 22:25:07.115426
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x = Python2FutureTransformer()
    module_x.visit_Module(module_x_var_0)


# Generated at 2022-06-25 22:25:10.021270
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    try:
        Python2FutureTransformer_var_0 = Python2FutureTransformer(2, 7)
    except (NameError, TypeError, AttributeError) as e:
        print('Error, cannot instantiate Python2FutureTransformer: {}'.format(e))


# Generated at 2022-06-25 22:25:12.223960
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()

    # Argument is 'self'
    # Argument is 'node'
    node = module_x_var_0
    transformer.visit_Module(node)

# Generated at 2022-06-25 22:25:17.077913
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Setup
    test_Python2FutureTransformer = Python2FutureTransformer()
    test_Python2FutureTransformer._tree_changed = False
    module_x_var_0 = module_0.Module()
    # Invoke method
    module_x_var_0 = test_Python2FutureTransformer.visit_Module(module_x_var_0)
    # Verify
    assert test_Python2FutureTransformer._tree_changed is True
    assert isinstance(module_x_var_0, module_0.Module)
       

# Generated at 2022-06-25 22:25:24.483825
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from . import ast_utils
    import typed_ast._ast3 as ast

    obj = Python2FutureTransformer(None)

    # test 1
    case_1 = test_case_0()
    obj.visit(case_1)
    case_1_expected = ast.Module()
    statement_0_0 = ast.Assign(targets=[ast.Name(id='absolute_import', ctx=ast.Store())], value=ast.Attribute(value=ast.Name(id='future', ctx=ast.Load()), attr='absolute_import', ctx=ast.Load()))

# Generated at 2022-06-25 22:25:26.059366
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    Python2FutureTransformer(module_x_var_0).visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:25:31.818632
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # Test if the object Python2FutureTransformer is of type Python2FutureTransformer
    assert isinstance(Python2FutureTransformer(), Python2FutureTransformer)
    # Test if the object Python2FutureTransformer is of type BaseNodeTransformer
    assert isinstance(Python2FutureTransformer(), BaseNodeTransformer)
    # Test __init__ of class Python2FutureTransformer.
    module_x_var_0 = Python2FutureTransformer()
    assert isinstance(module_x_var_0, Python2FutureTransformer)
    assert module_x_var_0.tree_changed is False
    assert module_x_var_0.target == (2, 7)

# Generated at 2022-06-25 22:25:32.764604
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_x_var_0 = Python2FutureTransformer()


# Generated at 2022-06-25 22:25:33.754030
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    test_case_0()

# Generated at 2022-06-25 22:26:48.307750
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-25 22:26:49.876786
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_y_var_0 = Python2FutureTransformer()
    module_y_var_1 = module_y_var_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:26:51.605042
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    test_case_0()

if __name__ == '__main__':
    import sys
    import doctest
    failure_count, _ = doctest.testmod()
    sys.exit(failure_count)

# Generated at 2022-06-25 22:26:54.678829
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_x_var_0 = Python2FutureTransformer()
    # Note: we convert to int here to avoid problems with python 2.x / 3.x
    assert int(module_x_var_0.target[0]) == 2 # type: ignore
    assert int(module_x_var_0.target[1]) == 7 # type: ignore


# Generated at 2022-06-25 22:26:55.515384
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_x_var_0 = Python2FutureTransformer()


# Generated at 2022-06-25 22:26:56.319620
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_x_var_0 = Python2FutureTransformer()

# Generated at 2022-06-25 22:26:57.573381
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # Test instantiation of class Python2FutureTransformer
    module_x_var_1 = Python2FutureTransformer()


# Generated at 2022-06-25 22:26:59.881761
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_x_var_0 = Python2FutureTransformer()
    assert isinstance(module_x_var_0, Python2FutureTransformer) == True
    assert module_x_var_0.target == (2, 7)



# Generated at 2022-06-25 22:27:01.716690
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()
    module_1 = module_x_var_0
    module_2 = transformer.visit_Module(module_1)
    assert module_2 == module_1
    assert transformer.tree_changed == False

# Generated at 2022-06-25 22:27:04.516391
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_1 = Python2FutureTransformer()
    module_x_var_0 = module_0.Module()
    module_x_var_0_copy, = module_x_var_1.visit_Module(module_x_var_0)
    assert module_x_var_0_copy == module_0.Module(body=imports.get_body(future='__future__'))