

# Generated at 2022-06-25 22:18:09.401512
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    pass

# Generated at 2022-06-25 22:18:20.530478
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    a_s_t_1 = module_0.Module([])
    a_s_t_1 = python2_future_transformer_0.visit_Module(a_s_t_1)

# Generated at 2022-06-25 22:18:25.499584
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)

    try:
        python2_future_transformer_0.visit_Module()
    except NotImplementedError as e:
        assert "this method must be overriden" in str(e)


# Generated at 2022-06-25 22:18:35.256411
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    
    # test arguments
    a_s_t_1 = module_0.Module()
    a_s_t_2 = python2_future_transformer_0.visit_Module(a_s_t_1)
    assert a_s_t_2 is None
    assert a_s_t_1.body[0].module == 'future'
    assert a_s_t_1.body[1].module == 'future'
    assert a_s_t_1.body[2].module == 'future'
    assert a_s_t_1.body[3].module == 'future'

# Generated at 2022-06-25 22:18:39.425534
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    python2_future_transformer_0 = Python2FutureTransformer(None)
    module_0 = ast.parse('')
    python2_future_transformer_0.visit_Module(module_0)

# Generated at 2022-06-25 22:18:49.536425
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ......programs.python2 import test_programs_py2 as test_programs
    from ......utils import program_analyser as program_analyser_0
    from ......data.programs.python2 import program_evaluator_py2 as program_evaluator_0
    for p in test_programs.TEST_PROGRAMS_API:
        with p.set_mode():
            program_evaluator_0.evaluate(p)
            a_s_t_0 = program_analyser_0.get_ast(p)
            python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
            assert python2_future_transformer_0.visit(python2_future_transformer_0.ast) == None # TODO: test returned value


# Generated at 2022-06-25 22:18:54.424921
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    a_s_t_1 = module_0.Module(body=[])
    a_s_t_1_0 = module_0.Module(body=[])
    python2_future_transformer_0(a_s_t_1)
    a_s_t_1 = module_0.Module(body=[])
    python2_future_transformer_0(a_s_t_1)

# Generated at 2022-06-25 22:19:05.637594
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    class_1 = module_0.ClassDef()
    name_1 = module_0.Identifier()
    name_1.name = 'Class 1'
    class_1.name = name_1
    body_1 = []
    body_1.append(class_1)
    python2_future_transformer_0 = Python2FutureTransformer()
    module_1 = module_0.Module()
    module_1.body = body_1
    python2_future_transformer_0.visit_Module(module_1)
    assert(1 == len(module_1.body))
    assert(module_1.body[0].name.__class__ == module_0.Identifier)
    assert(module_1.body[0].name.name == 'Class 1')

# Generated at 2022-06-25 22:19:14.749213
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    source_code_0 = """
    print(1)
    """
    module_1 = ast.parse(source_code_0)
    module_2 = python2_future_transformer_0.visit(module_1)
    a_s_t_2 = ast.dump(module_2, include_attributes=False)

# Generated at 2022-06-25 22:19:19.563314
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)

    # Assign values to variables to simulate values coming from a program
    current_node_0 = None

    # Call visit_Module code with simulated input
    python2_future_transformer_0._visit_Module(current_node_0)
    # Check that visit_Module code did not fail
    assert True
    # Check that visit_Module code did what it was supposed to do
    assert False, 'Test failed because expected code did not run'

# Generated at 2022-06-25 22:19:30.341849
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_x_var_3 = module_0.Module()
    module_x_var_4 = module_0.Import()
    module_x_var_5 = module_0.alias(
        name='typed_ast',
        asname=None
    )
    module_x_var_4.names.append(module_x_var_5)
    module_x_var_6 = module_0.ImportFrom(
        module='typed_ast._ast3',
        names=[
            module_0.alias(
                name='AST',
                asname=None
            )
        ],
        level=0
    )
    module_x_var_3.body.append(module_x_var_4)
    module_x_var_3.body.append(module_x_var_6)


# Generated at 2022-06-25 22:19:39.452782
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    python2_future_transformer_0 = Python2FutureTransformer()
    module_x_var_0 = module_0.Module()
    module_x_var_0.lineno = 0
    import_0 = module_0.Import()
    name_0 = module_0.Name()
    name_0.id = "name_1"
    alias_0 = module_0.alias()
    alias_0.name = "name_2"
    alias_0.asname = "name_3"
    import_0.names = [alias_0]
    import_0.lineno = 0
    from_0 = module_0.ImportFrom()
    from_0.module = "module_1"
    name_1 = module_0.Name()
    name_1.id = "name_4"
   

# Generated at 2022-06-25 22:19:43.942583
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Arrange
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_0 = module_0.Module()
    module_x_var_0.body = []
    module_x_var_0.type_ignores = []

    # Act
    actual_0 = python2_future_transformer_0.visit_Module(module_x_var_0)

    # Assert
    assert len(actual_0.body) == 4
    assert actual_0.body[0].names[0].name == 'absolute_import'
    assert actual_0.body[1].names[0].name == 'division'

# Generated at 2022-06-25 22:19:53.330809
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_0 = module_0.Module()
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    module_x_var_2 = python2_future_transformer_0.visit_Module(module_x_var_1)
    module_x_var_3 = python2_future_transformer_0.visit_Module(module_x_var_2)
    assert module_x_var_3 is not None

# Generated at 2022-06-25 22:20:01.685323
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_0 = module_0.Module()
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    assert module_0.Module == type(module_x_var_1)
    assert 4 == len(module_x_var_1.body)
    assert module_0.ImportFrom == type(module_x_var_1.body[0])
    assert '__future__' == module_x_var_1.body[0].module
    assert 'absolute_import' == module_x_var_1.body[0].names[0].name


# Generated at 2022-06-25 22:20:03.438833
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)


# Generated at 2022-06-25 22:20:09.821085
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_0 = module_0.Module()
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    module_x_var_2 = python2_future_transformer_0.visit_Module(module_x_var_1)

# Generated at 2022-06-25 22:20:12.755146
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)

# Generated at 2022-06-25 22:20:18.279895
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_3 = module_0.Module()
    module_x_var_4 = Python2FutureTransformer(module_x_var_3)
    assert (module_x_var_4.visit_Module(module_x_var_3))

if (__name__ == '__main__'):
    pass


import typing
from typing import Callable
from collections import Counter



# Generated at 2022-06-25 22:20:22.577968
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    try:
        a_s_t_0 = module_0.AST()
        python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
        test_case_0()
    except:
        print("Exception in test_Python2FutureTransformer()")
    else:
        print("Test for constructor of class Python2FutureTransformer() passed")


# Generated at 2022-06-25 22:20:32.176067
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    pass
    # a_s_t_0 = module_0.AST()
    # python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    # module_x_var_0 = module_0.Module()
    # module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    # module_x_var_2 = python2_future_transformer_0.visit_Module(module_x_var_1)
    return

# Generated at 2022-06-25 22:20:39.362464
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_5 = module_0.AST()
    python2_future_transformer_5 = Python2FutureTransformer(a_s_t_5)
    module_x_var_5 = module_0.Module()
    module_x_var_6 = python2_future_transformer_5.visit_Module(module_x_var_5)
    del module_x_var_5
    del a_s_t_5
    del python2_future_transformer_5
    del module_x_var_6


# Generated at 2022-06-25 22:20:45.950414
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_0 = module_0.Module()
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    module_x_var_2 = python2_future_transformer_0.visit_Module(module_x_var_1)
    # Verify that the visit_Module method worked as expected
    pass


# Generated at 2022-06-25 22:20:52.060734
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from typed_ast import ast3 as module_0
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_0 = module_0.Module()
    module_x_var_0_body_0 = module_0.Import()
    module_x_var_0_body_0.names = [('abc', None)]
    module_x_var_0.body = [module_x_var_0_body_0]
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:21:02.103883
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_1 = module_0.AST()
    python2_future_transformer_1 = Python2FutureTransformer(a_s_t_1)
    module_x_var_3 = module_0.Module()
    module_x_var_4 = python2_future_transformer_1.visit_Module(module_x_var_3)
    if (not (isinstance(module_x_var_4, module_0.Module))):
        raise AssertionError()
    if (module_x_var_4.col_offset != 0):
        raise AssertionError()
    if (module_x_var_4.lineno != 1):
        raise AssertionError()
    if (module_x_var_4.end_lineno != 1):
        raise AssertionError

# Generated at 2022-06-25 22:21:07.224068
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    assert isinstance(Python2FutureTransformer(a_s_t_0), Python2FutureTransformer)


# Generated at 2022-06-25 22:21:11.053366
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = None
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)

# Generated at 2022-06-25 22:21:15.589599
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_var_0 = module_0.AST()
    assert (a_s_t_var_0 != None)
    python2_future_transformer_var_0 = Python2FutureTransformer(a_s_t_var_0)
    assert (python2_future_transformer_var_0 != None)


# Generated at 2022-06-25 22:21:22.449661
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_0 = module_0.Module()
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    module_x_var_2 = python2_future_transformer_0.visit_Module(module_x_var_1)
    
    __tracebackhide__ = True

# Generated at 2022-06-25 22:21:30.077169
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_0 = module_0.Module()
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    module_x_var_2 = python2_future_transformer_0.visit_Module(module_x_var_1)

# Generated at 2022-06-25 22:21:45.659299
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a = module_0.AST()
    python2_future_transformer = Python2FutureTransformer(a)
    m = module_0.Module()
    result = python2_future_transformer.visit_Module(m)

# Generated at 2022-06-25 22:21:48.905278
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_0 = module_0.Module()
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    module_x_var_2 = python2_future_transformer_0.visit_Module(module_x_var_1)

# Generated at 2022-06-25 22:21:55.766621
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_0 = module_0.Module()
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    module_x_var_2 = python2_future_transformer_0.visit_Module(module_x_var_1)
    assert python2_future_transformer_0._tree_changed
    assert isinstance(module_x_var_1, module_0.Module)


# Generated at 2022-06-25 22:21:56.650866
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    test_case_0()

# Generated at 2022-06-25 22:21:58.620845
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_3 = module_0.AST()
    python2_future_transformer_1 = Python2FutureTransformer(a_s_t_3)


# Generated at 2022-06-25 22:22:04.922226
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_0 = module_0.Module()
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    module_x_var_2 = python2_future_transformer_0.visit_Module(module_x_var_1)

# Generated at 2022-06-25 22:22:09.877242
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    assert python2_future_transformer_0.ast == a_s_t_0
    assert python2_future_transformer_0.is_tree_changed() == False
    assert python2_future_transformer_0.visit_count == 0
    

# Generated at 2022-06-25 22:22:13.092442
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    custom_ast_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(custom_ast_0)
    assert python2_future_transformer_0 is not None
    assert python2_future_transformer_0.ast is custom_ast_0


# Generated at 2022-06-25 22:22:16.039803
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)

# Generated at 2022-06-25 22:22:20.295448
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    
    assert a_s_t_0.__class__ is module_0.AST
    assert python2_future_transformer_0.__class__ is Python2FutureTransformer
    

# Generated at 2022-06-25 22:22:43.266423
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_0 = module_0.Module()
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    module_x_var_2 = python2_future_transformer_0.visit_Module(module_x_var_1)
    assert list(python2_future_transformer_0._tree_changed) == [True]

if __name__ == '__main__':
    test_case_0()
    test_Python2FutureTransformer_visit_Module()

# Generated at 2022-06-25 22:22:45.340819
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)


# Generated at 2022-06-25 22:22:48.592387
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # Test with argument `ast` equal to module `typed_ast._ast3`
    test_case_0()


if __name__ == '__main__':

    # Test with argument `ast` equal to module `typed_ast._ast3`
    test_Python2FutureTransformer()

# Generated at 2022-06-25 22:22:56.468381
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_0 = module_0.Module()
    module_x_var_1 = module_0.Module()
    module_x_var_2 = module_0.Module()
    module_x_var_3 = module_0.Module()
    module_x_var_6 = module_0.Module()
    module_x_var_7 = module_0.Module()
    module_x_var_8 = module_0.Module()
    module_x_var_9 = module_0.Module()
    module_x_var_10 = module_0.Module()

# Generated at 2022-06-25 22:23:05.867270
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_2 = module_0.Module()
    python2_future_transformer_0.tree_changed = False
    module_x_var_3 = python2_future_transformer_0.visit_Module(module_x_var_2)
    if (python2_future_transformer_0.tree_changed != True): raise RuntimeError()
    if (len(module_x_var_3.body) != len(imports.get_body(future='__future__'))): raise RuntimeError()

# Generated at 2022-06-25 22:23:14.717151
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_0 = module_0.Module()
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    module_x_var_2 = python2_future_transformer_0.visit_Module(module_x_var_1)
    function_def_0 = module_0.FunctionDef(name='test', body=[], decorator_list=[])
    module_x_var_1 = module_x_var_2

# Generated at 2022-06-25 22:23:21.542478
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_0 = module_0.Module()
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    module_x_var_2 = python2_future_transformer_0.visit_Module(module_x_var_1)


if __name__ == '__main__':
    import sys
    sys.exit(pytest.main(["--doctest-modules", __file__]))

# Generated at 2022-06-25 22:23:28.242450
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_0 = module_0.Module()
    python2_future_transformer_0.visit_Module(module_x_var_0)
    assert module_x_var_0.body[0].dest == 'absolute_import'
    assert module_x_var_0.body[0].absolute is True


# Generated at 2022-06-25 22:23:34.284644
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    """
    Tests the method visit_Module of Python2FutureTransformer
    """
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_0 = module_0.Module()
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    module_x_var_2 = python2_future_transformer_0.visit_Module(module_x_var_1)


# Generated at 2022-06-25 22:23:37.323509
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    variables_dict = locals()
    for variable_name in variables_dict:
        value = variables_dict.get(variable_name)
        if variable_name == 'constant_0':
            assert value.get_future() == '__future__'


# Generated at 2022-06-25 22:24:15.769423
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_0 = module_0.Module()
    python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:24:22.050620
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_0 = module_0.Module()
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    module_x_var_2 = python2_future_transformer_0.visit_Module(module_x_var_1)
    module_x_var_3 = python2_future_transformer_0.visit_Module(module_x_var_2)

# Generated at 2022-06-25 22:24:24.069936
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    python2_future_transformer_0 = Python2FutureTransformer(None)


# Generated at 2022-06-25 22:24:33.255711
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_1 = module_0.AST()
    python2_future_transformer_1 = Python2FutureTransformer(a_s_t_1)
    module_var_0 = module_0.Module()
    module_var_0.body = [module_0.ImportFrom(module_0.Name('typed_ast', module_0.Load()), [module_0.alias(module_0.Name('foo', module_0.Load()), 'foo')], 0)]
    module_var_1 = python2_future_transformer_1.visit_Module(module_var_0)
    assert type(module_var_1.body[0]) == module_0.ImportFrom
    assert type(module_var_1.body[0].names[0].name) == module_0.Name
   

# Generated at 2022-06-25 22:24:35.645627
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    module_x_var_1 = Python2FutureTransformer().visit_Module(module_x_var_0)
    assert isinstance(module_x_var_1, module_0.Module)


# Generated at 2022-06-25 22:24:41.466452
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_0 = module_0.Module()
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    module_x_var_2 = python2_future_transformer_0.visit_Module(module_x_var_1)

# Generated at 2022-06-25 22:24:43.232610
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)


# Generated at 2022-06-25 22:24:48.683531
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Simple test, just check that it runs without error
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_0 = module_0.Module()
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    module_x_var_2 = python2_future_transformer_0.visit_Module(module_x_var_1)

# Generated at 2022-06-25 22:24:49.310551
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    pass



# Generated at 2022-06-25 22:24:52.305901
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    assert isinstance(python2_future_transformer_0, Python2FutureTransformer)

# Generated at 2022-06-25 22:26:08.608231
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    return None


# Generated at 2022-06-25 22:26:10.315880
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST(
        a_s_t_0
    )


# class TestPython2FutureTransformer(unittest.TestCase):

# Generated at 2022-06-25 22:26:12.726299
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)

# Generated at 2022-06-25 22:26:16.549314
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_1 = module_0.AST()
    python2_future_transformer_1 = Python2FutureTransformer(a_s_t_1)
    assert python2_future_transformer_1.target == (2, 7)


# Generated at 2022-06-25 22:26:22.359910
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_0 = module_0.Module()
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    module_x_var_2 = python2_future_transformer_0.visit_Module(module_x_var_1)

# Generated at 2022-06-25 22:26:24.042456
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)


# Generated at 2022-06-25 22:26:29.574256
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    python2_future_transformer_0 = Python2FutureTransformer(module_0.AST())
    assert isinstance(python2_future_transformer_0, Python2FutureTransformer)


# Generated at 2022-06-25 22:26:31.931137
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    a_s_t_0 = ast.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)


# Generated at 2022-06-25 22:26:38.079162
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
  def test_snippet():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_0 = module_0.Module()
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    module_x_var_2 = python2_future_transformer_0.visit_Module(module_x_var_1)
  test_snippet()


# Generated at 2022-06-25 22:26:43.526811
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_0 = module_0.Module()
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    module_x_var_2 = python2_future_transformer_0.visit_Module(module_x_var_1)