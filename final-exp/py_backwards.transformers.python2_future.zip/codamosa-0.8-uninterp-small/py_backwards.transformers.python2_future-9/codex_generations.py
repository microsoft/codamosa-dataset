

# Generated at 2022-06-25 22:18:11.498747
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_10 = module_0.AST()
    python2_future_transformer_10 = Python2FutureTransformer(a_s_t_10)

    module_11 = module_0.Module()
    a_s_t_12 = module_0.AST()
    node_13 = module_0.Module()
    module_11.body = [module_0.Expr(None)]
    python2_future_transformer_10.visit(module_11)
    #print(module_11.body)
    assert module_11.body == imports.get_body(future='__future__') + [module_0.Expr(None)]



# Generated at 2022-06-25 22:18:14.291460
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)

# Generated at 2022-06-25 22:18:20.209365
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    a_s_t_0_0 = module_0.Module()
    module_0_1 = module_0.Module()
    python2_future_transformer_0._tree_changed = True

# Generated at 2022-06-25 22:18:28.593413
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    script_0_0 = ""
    module_0_0 = module_0.parse(script_0_0)
    python2_future_transformer_0.visit(module_0_0)
    script_0_1 = ""
    module_0_1 = module_0.parse(script_0_1)
    python2_future_transformer_0.visit(module_0_1)
    script_0_2 = ""
    module_0_2 = module_0.parse(script_0_2)
    python2_future_transformer_0.visit(module_0_2)

# Generated at 2022-06-25 22:18:37.406295
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    a_s_t_1 = module_0.Module([], lineno=(0), col_offset=(0))
    a_s_t_2 = python2_future_transformer_0.visit_Module(a_s_t_1)
    assert a_s_t_2
    assert a_s_t_2.body[0].value.s == 'absolute_import'
    assert a_s_t_2.body[1].value.s == 'division'
    assert a_s_t_2.body[2].value.s == 'print_function'

# Generated at 2022-06-25 22:18:45.669109
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    class Module_t(ast.Module):
        def __init__(self):
            self.body = 0

    node_0 = Module_t()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    python2_future_transformer_0._tree_changed = 0
    python2_future_transformer_0.visit_Module(node_0)

    int_0 = 0

    assert node_0.body == int_0
    assert python2_future_transformer_0._tree_changed == 0

# Generated at 2022-06-25 22:18:47.842232
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    test_case_0()
    test_case_1()
    test_case_2()


# Generated at 2022-06-25 22:18:57.140347
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_0_0 = module_0.Module([], module_0.syms.module)
    python2_future_transformer_0.visit_Module(module_0_0)

# Generated at 2022-06-25 22:19:03.116963
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    python2_future_transformer_0._tree_changed = module_0.AST()
    python2_future_transformer_0.target = module_0.AST(1, 1)
    module_1 = module_0.Module()
    python2_future_transformer_0.visit_Module(module_1)

# Generated at 2022-06-25 22:19:13.372577
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import sys
    import shutil
    import typed_ast.ast3
    import unittest

    from convert_to_typed import Python2FutureTransformer

    '''test_Python2FutureTransformer_visit_Module'''

    class Tmp:
        def test_tmp(self):
            '''tmp.py'''
            with open('tmp.py', 'w') as f:
                f.write('''
import bs4
import requests

foo = '2'
print(True)
''')

            # replace the second argument with 'tmp.py' to test
            from convert_to_typed import main
            main.main(['', '-t', '3', 'tmp.py'])

            with open('tmp.py', 'r') as f:
                lines = f.readlines()
               

# Generated at 2022-06-25 22:19:17.777243
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)


from typed_ast import ast3 as module_1


# Generated at 2022-06-25 22:19:26.815982
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_1 = module_0.Module([module_0.Import([module_0.alias('mod1', None)], 0)], [module_0.Expr(module_0.Name('a', 0))])
    f_p_w_0 = open("Unit Test/test_data/test_case_0.txt", "r")
    inp_0 = f_p_w_0.read()
    f_p_w_0.close()
    out_0 = python2_future_transformer_0.visit_Module(module_1)
    assert(str(out_0) == inp_0)

import typed_ast

# Generated at 2022-06-25 22:19:32.460454
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    a_s_t_1 = module_0.Module([])
    a_s_t_2 = python2_future_transformer_0.visit(a_s_t_1)
    assert isinstance(a_s_t_2, module_0.Module)


# Generated at 2022-06-25 22:19:39.576250
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_0 = object()
    module_1 = python2_future_transformer_0.visit_Module(module_0)
    assert module_1 is not None  # Type hint for python3
    # assert isinstance(module_1, ast.Module)
    assert python2_future_transformer_0._tree_changed == True
    assert module_0 is module_1  # Type hint for python3
    # assert isinstance(module_0, ast.Module)

# Generated at 2022-06-25 22:19:41.051400
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
  a_s_t_0 = module_0.AST()
  python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)


# Generated at 2022-06-25 22:19:43.397968
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_1 = module_0.AST()
    python2_future_transformer_1 = Python2FutureTransformer(a_s_t_1)

# Generated at 2022-06-25 22:19:48.006792
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = ast.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    # assert python2_future_transformer_0.tree == a_s_t_0
    # assert python2_future_transformer_0._tree_changed == False

# Generated at 2022-06-25 22:19:51.761362
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import typed_ast.ast3 as ast
    from transpyle.ast_processor.transformer.python2_future_transformer import Python2FutureTransformer

    python2_future_transformer_0 = Python2FutureTransformer(ast)


# Generated at 2022-06-25 22:19:56.287249
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_1 = python2_future_transformer_0.visit_Module(a_s_t_0.parse("#!/usr/bin/env python\n# encoding: utf-8\n\npass").body[0])

# Generated at 2022-06-25 22:19:58.597076
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)

# Generated at 2022-06-25 22:20:06.976656
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    a_s_t_1 = module_0.Module()
    python2_future_transformer_0.visit_Module(a_s_t_1)


# Generated at 2022-06-25 22:20:10.096531
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    try:
        a_s_t_0 = module_0.AST()
        python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    except Exception as e:
        raise e


# Generated at 2022-06-25 22:20:13.048207
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)

# Generated at 2022-06-25 22:20:21.976908
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_1 = module_0.Module(body=[module_0.Expr(value=module_0.Num(n=1)), module_0.Expr(value=module_0.Str(s='str'))])
    module_1 = python2_future_transformer_0.visit_Module(module_1)
    python2_future_transformer_0.generic_visit(module_1)
    assert Python2FutureTransformer._tree_changed == True
    Python2FutureTransformer._tree_changed = False

# Generated at 2022-06-25 22:20:26.909759
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    assert python2_future_transformer_0._future_imports is True, "Attribute _future_imports not set properly"
    #TODO: check typed_ast_equal()
    # assert python2_future_transformer_0._symbols_table is symbols_table, "Attribute _symbols_table not set properly"


# Generated at 2022-06-25 22:20:28.994032
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)


# Generated at 2022-06-25 22:20:33.904374
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    a_s_t_1 = module_0.AST()
    module_ast_0 = a_s_t_1.Module([])
    module_0 = python2_future_transformer_0.visit(module_ast_0)

# Generated at 2022-06-25 22:20:36.139508
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_1 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_1)

# Generated at 2022-06-25 22:20:41.188995
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_0_0 = module_0.Module()
    a_s_t_0_1 = python2_future_transformer_0.visit_Module(module_0_0)

# Generated at 2022-06-25 22:20:44.628466
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    python2_future_transformer_0 = Python2FutureTransformer(None)
    module_0 = module_0.Module([], None)
    module_0.body = []
    python2_future_transformer_0.visit_Module(module_0)



# Generated at 2022-06-25 22:20:55.686579
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    test_case_0()


# Generated at 2022-06-25 22:21:04.312462
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # Case 1:
    # Create variable a_s_t_0
    a_s_t_0 = module_0.AST()
    # Create variable python2_future_transformer_0
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    assert python2_future_transformer_0.target == (2, 7), "Variable python2_future_transformer_0.target should be (2, 7), got {}".format(python2_future_transformer_0.target)
    a_s_t_1 = module_0.AST()
    # Create variable python2_future_transformer_1
    python2_future_transformer_1 = Python2FutureTransformer(a_s_t_1)

# Generated at 2022-06-25 22:21:14.218598
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)

    module_1 = module_0.Module([], None)
    assert module_1 == python2_future_transformer_0.visit_Module(module_1)

    node_1 = module_1
    assert node_1 == python2_future_transformer_0.generic_visit(node_1)

# Generated at 2022-06-25 22:21:18.766519
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    assert_equals(python2_future_transformer_0.tree, a_s_t_0)

# Generated at 2022-06-25 22:21:21.973378
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)


# Generated at 2022-06-25 22:21:33.008865
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert not hasattr(Python2FutureTransformer, "visit_Module")
    assert not hasattr(Python2FutureTransformer, "visit_FunctionDef")
    assert not hasattr(Python2FutureTransformer, "visit_AsyncFunctionDef")
    assert not hasattr(Python2FutureTransformer, "visit_ClassDef")
    assert not hasattr(Python2FutureTransformer, "visit_Return")
    assert not hasattr(Python2FutureTransformer, "visit_Delete")
    assert not hasattr(Python2FutureTransformer, "visit_Assign")
    assert not hasattr(Python2FutureTransformer, "visit_AugAssign")
    assert not hasattr(Python2FutureTransformer, "visit_AnnAssign")
    assert not hasattr(Python2FutureTransformer, "visit_For")


# Generated at 2022-06-25 22:21:41.588106
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_0_0 = a_s_t_0.Module()
    body_node_0 = a_s_t_0.Expr()
    body_0 = [a_s_t_0.copy_location(a_s_t_0.Pass(), body_node_0)]
    module_0_0.body = body_0
    module_0_0.type_ignores = []
    __tracebackhide__ = True
    try:
        module_1 = python2_future_transformer_0.visit_Module(module_0_0)
    except:
        stypy_exception = PythonParserException()
       

# Generated at 2022-06-25 22:21:49.188371
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():

    target = (2, 7)

    # Test with module.
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    # Check the target version is as expected.
    assert python2_future_transformer_0.target == target, "Expected (2, 7), got %s" % str(python2_future_transformer_0.target)
    # Check that the tree_changed is as expected.
    assert python2_future_transformer_0._tree_changed == False, "Expected False, got %s" % str(python2_future_transformer_0._tree_changed)
    # Check that the line_map is as expected.
    assert python2_future_transformer_0._line_map

# Generated at 2022-06-25 22:21:52.587295
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    print("Make sure it has all the fields")
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    print("Make sure it has all the methods")
    print("Pass")


# Generated at 2022-06-25 22:21:55.655118
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    ast_0 = module_0.AST()
    try:
        pyt2ft_0 = Python2FutureTransformer(ast_0)
        assert pyt2ft_0 is not None
    except AttributeError:
        print('Failed to instantiate Python2FutureTransformer')

# Generated at 2022-06-25 22:22:14.358838
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    assert python2_future_transformer_0.tree is a_s_t_0
    assert python2_future_transformer_0._tree_changed is False


# Generated at 2022-06-25 22:22:18.746218
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_1 = module_0.Module()
    module_1 = python2_future_transformer_0.visit_Module(module_1)
    assert type(module_1) == module_0.Module


# Generated at 2022-06-25 22:22:20.320505
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer
    assert Python2FutureTransformer.target == (2, 7)


# Generated at 2022-06-25 22:22:20.806008
# Unit test for constructor of class Python2FutureTransformer

# Generated at 2022-06-25 22:22:22.988074
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    a_s_t_0 = ast.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)

# Generated at 2022-06-25 22:22:29.565461
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_1 = a_s_t_0.Module()
    module_1.body = (module_0.Expr(value=module_0.Str(s='')), module_0.ImportFrom(module='typed_ast._ast3', names=(module_0.alias(name='AST', asname=None),), level=0))
    python2_future_transformer_0.visit_Module(module_1)

# Generated at 2022-06-25 22:22:32.634182
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_0 = module_0.Module()
    python2_future_transformer_0.visit_Module(module_0)

# Generated at 2022-06-25 22:22:41.087772
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_1 = python2_future_transformer_0.visit_Module(module_0.Module([], type_ignores=[None, None]))

# Generated at 2022-06-25 22:22:49.191412
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    # Setup
    node_0 = a_s_t_0.Module()
    node_1 = a_s_t_0.Assert()
    node_3 = a_s_t_0.DictComp()
    node_2 = a_s_t_0.AnnAssign()
    node_5 = a_s_t_0.arguments()
    node_4 = a_s_t_0.arguments()
    node_7 = a_s_t_0.arguments()
    node_6 = a_s_t_0.arguments()
    node_9 = a_s_t_0.Assign()

# Generated at 2022-06-25 22:22:57.064773
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)

# Generated at 2022-06-25 22:23:12.772466
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert issubclass(Python2FutureTransformer, BaseNodeTransformer)

# Generated at 2022-06-25 22:23:13.550580
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
  test_case_0()


# Generated at 2022-06-25 22:23:18.348261
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_x_var_0 = module_0.Module()
    list_0 = []
    a_s_t_0 = module_0.AST(*list_0)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    assert python2_future_transformer_0 is not None
    assert isinstance(python2_future_transformer_0, Python2FutureTransformer)


# Generated at 2022-06-25 22:23:18.830911
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    assert True

# Generated at 2022-06-25 22:23:22.408468
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_x_var_0 = module_0.Module()
    list_0 = []
    a_s_t_0 = module_0.AST(*list_0)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)


# Generated at 2022-06-25 22:23:31.422003
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    list_2 = []
    a_s_t_1 = module_0.AST(*list_2)
    python2_future_transformer_1 = Python2FutureTransformer(a_s_t_1)
    copy_reg_var_1 = None
    _pickle_var_1 = None
    module_1 = module_0.Module(body=[copy_reg_var_1, _pickle_var_1])
    copy_reg_var_2 = None
    _pickle_var_2 = None
    module_2 = python2_future_transformer_1.visit_Module(module_1)
    list_3 = []
    a_s_t_2 = module_0.AST(*list_3)

# Generated at 2022-06-25 22:23:32.179970
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    test_case_0()


# Generated at 2022-06-25 22:23:35.264900
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    list_0 = []
    a_s_t_0 = module_0.AST(*list_0)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)


# Generated at 2022-06-25 22:23:42.969988
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    
    module_x_var_0 = module_0.Module()
    list_0 = []
    a_s_t_0 = module_0.AST(*list_0)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)

    def test_case_0():
        module_x_var_0 = module_0.Module()
        list_0 = []
        a_s_t_0 = module_0.AST(*list_0)
        python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
        module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

    return test_case_0


# Generated at 2022-06-25 22:23:48.678755
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_x_var_0 = module_0.Module()
    list_0 = []
    a_s_t_0 = module_0.AST(*list_0)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    assert python2_future_transformer_0 != 'Python2FutureTransformer(a_s_t_0)'
    assert python2_future_transformer_0 != 'Python2FutureTransformer()'
    assert python2_future_transformer_0 != 'Python2FutureTransformer'


# Generated at 2022-06-25 22:24:25.512047
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # Create instance of class Python2FutureTransformer
    python2_future_transformer_0 = Python2FutureTransformer()
    test_case_0()

# def main():
#     test_Python2FutureTransformer()

# Generated at 2022-06-25 22:24:32.671182
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # Test for constructor of class Python2FutureTransformer
    module_x_var_0 = module_0.Module()
    list_0 = []
    a_s_t_0 = module_0.AST(*list_0)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)


if __name__ == '__main__':
    # test_case_0()
    test_Python2FutureTransformer()

# Generated at 2022-06-25 22:24:35.157584
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_x_var_0 = module_0.Module()
    list_0 = []
    a_s_t_0 = module_0.AST(*list_0)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)

# Generated at 2022-06-25 22:24:35.819717
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    test_case_0()




# Generated at 2022-06-25 22:24:41.173115
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_x_var_0 = module_0.Module()
    list_0 = []
    a_s_t_0 = module_0.AST(*list_0)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)

if __name__ == '__main__':
    test_case_0()

    # Constructor test
    test_Python2FutureTransformer()

# Generated at 2022-06-25 22:24:43.704159
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    list_0 = []
    a_s_t_0 = module_0.AST(*list_0)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)


# Generated at 2022-06-25 22:24:45.070694
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    test_case_0()

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 22:24:47.186322
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    python2_future_transformer_0 = Python2FutureTransformer(module_0.AST())
    assert type(python2_future_transformer_0) == Python2FutureTransformer


# Generated at 2022-06-25 22:24:48.158870
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_0 = Python2FutureTransformer()


# Generated at 2022-06-25 22:24:52.141567
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import typed_ast._ast3 as module_0
    list_0 = []
    module_x_var_0 = module_0.Module(*list_0)
    python2_future_transformer_0 = Python2FutureTransformer(module_x_var_0)
    assert python2_future_transformer_0.tree == module_0.Module()


# Generated at 2022-06-25 22:26:12.976986
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    ##
    ## @snippet
    ## def imports(future):
    ##     from future import absolute_import
    ##     from future import division
    ##     from future import print_function
    ##     from future import unicode_literals
    ##
    ##

    ##
    ## class Python2FutureTransformer(BaseNodeTransformer):
    ##     """Prepends module with:
    ##         from __future__ import absolute_import
    ##         from __future__ import division
    ##         from __future__ import print_function
    ##         from __future__ import unicode_literals
    ##
    ##     """
    ##     target = (2, 7)
    ##
    ##     def visit

# Generated at 2022-06-25 22:26:16.293017
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # A test showing that the code to be converted has not been changed
    test_case_0()
    # Make the assertions
    assert module_x_var_1 == module_x_var_0

# Generated at 2022-06-25 22:26:21.141005
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_x_var_1 = module_0.Module()
    list_0 = []
    a_s_t_0 = module_0.AST(*list_0)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    python2_future_transformer_1 = Python2FutureTransformer(a_s_t_0)


# Generated at 2022-06-25 22:26:29.032192
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_0 = ast.Module()
    list_0 = []
    a_s_t_0 = module_0.AST(*list_0)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    python2_future_transformer_1 = Python2FutureTransformer(a_s_t_0)
    module_1 = ast.Module()
    python2_future_transformer_1.visit_Module(module_1)

# Generated at 2022-06-25 22:26:34.330586
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    list_0 = []
    a_s_t_0 = module_0.AST(*list_0)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    assert not python2_future_transformer_0.tree_changed
    assert module_x_var_1 == module_x_var_0

# Generated at 2022-06-25 22:26:37.814521
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    assert repr(python2_future_transformer_0) == "Python2FutureTransformer(Module(body=[]))"


# Generated at 2022-06-25 22:26:42.614286
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_x_var_0 = module_0.Module()
    list_0 = []
    a_s_t_0 = module_0.AST(*list_0)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    assert isinstance(python2_future_transformer_0, Python2FutureTransformer) is True


# Generated at 2022-06-25 22:26:43.299407
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert True



# Generated at 2022-06-25 22:26:47.719515
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    list_0 = []
    a_s_t_0 = module_0.AST(*list_0)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    module_x_var_2 = python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:26:52.711274
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    try:
        module_0.Module()
        list_0 = []
        a_s_t_0 = module_0.AST(*list_0)
        python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
        # Test type of ``python2_future_transformer_0``
        assert isinstance(python2_future_transformer_0, Python2FutureTransformer)
        assert isinstance(python2_future_transformer_0, BaseNodeTransformer)
    except Exception as e:
        print ('Exception: {}'.format(e))
    else:
        print ('Success!')
