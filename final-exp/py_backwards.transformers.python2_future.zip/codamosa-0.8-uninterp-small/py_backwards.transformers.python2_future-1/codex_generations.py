

# Generated at 2022-06-25 22:18:10.332368
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():

    # TODO: Ransom:2020-09-26: Add assertions here.
    print("\n\nUnit test for constructor of class Python2FutureTransformer")


# Generated at 2022-06-25 22:18:21.153574
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    a_s_t_0 = ast.Module()
    import_0 = ast.ImportFrom(module='future', names=[ast.alias(name='absolute_import', asname=None), ast.alias(name='division', asname=None), ast.alias(name='print_function', asname=None), ast.alias(name='unicode_literals', asname=None), ], level=0)
    a_s_t_0.body = [import_0, ]
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    python2_future_transformer_0.visit_Module(a_s_t_0)
    assert isinstance(python2_future_transformer_0._tree_changed, bool)
   

# Generated at 2022-06-25 22:18:25.175375
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_0 = module_0.Module()
    module_0 = python2_future_transformer_0.visit_Module(module_0)

# Generated at 2022-06-25 22:18:30.709252
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    a_s_t_1 = module_0.Module([], [], [], [])
    a_s_t_1.body = []
    python2_future_transformer_0.visit_Module(a_s_t_1)
    return_value_0 = python2_future_transformer_0.visit_Module(a_s_t_1)
    assert return_value_0 is None
    assert len(return_value_0.body) == 4

# Generated at 2022-06-25 22:18:38.247745
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    ast_0 = module_0.AST()
    python2_future_transformer_1 = Python2FutureTransformer(ast_0)
    assert python2_future_transformer_1.ast == ast_0
    assert python2_future_transformer_1._tree_changed is False
    assert python2_future_transformer_1._simple_nodes is (
        module_0.BinOp,
        module_0.Dict,
        module_0.List,
        module_0.Name,
        module_0.Num,
        module_0.Str,
    )
    assert python2_future_transformer_1._simple_node_convertions == set()
    assert python2_future_transformer_1._assignments_to_delete is ()
    assert python2_future_transformer_1

# Generated at 2022-06-25 22:18:48.565559
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)

    str_0 = "__future__"
    module_1 = module_0.Module(body=(module_0.ImportFrom(module=str_0, names=(module_0.alias(name='unicode_literals', asname=None), module_0.alias(name='absolute_import', asname=None), module_0.alias(name='division', asname=None), module_0.alias(name='print_function', asname=None)), level=0),), type_ignores=())

    python2_future_transformer_0._tree_changed = False
    python2_future_transformer_0.visit(module_1)

# Generated at 2022-06-25 22:18:53.385976
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    assert module_0.AST == type(python2_future_transformer_0._tree)
    assert None == python2_future_transformer_0._tree_changed
    assert None == python2_future_transformer_0._future
    python2_future_transformer_0._python_target_version = (2, 6)


# Generated at 2022-06-25 22:19:01.845826
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    a_s_t_1 = module_0.Module(
        body=[
            module_0.ImportFrom(
                module='typed_ast._ast3',
                names=[
                    module_0.alias(
                        name='AST',
                        asname=None
                    )
                ],
                level=0
            )
        ]
    )
    python2_future_transformer_0.visit_Module(a_s_t_1)
    

# Generated at 2022-06-25 22:19:02.810735
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    test_case_0()

# Generated at 2022-06-25 22:19:07.926902
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-25 22:19:17.898484
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    line_number_0 = 1
    col_offset_0 = 1
    context_0 = [None]
    module_1 = module_0.Module(body=[None], type_ignores=[None])
    module_0_0 = python2_future_transformer_0.visit_Module(module_1)
    assert python2_future_transformer_0.tree_changed_() == False
    a_s_t_0 = module_0.AST()
    python2_future_transformer_1 = Python2FutureTransformer(a_s_t_0)
    line_number_1 = 1
    col_offset_1 = 1


# Generated at 2022-06-25 22:19:20.163849
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)

# Generated at 2022-06-25 22:19:22.326096
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)


# Generated at 2022-06-25 22:19:31.331205
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)


if __name__ == '__main__':
    # Unit test for imports
    if False:
        for future in ('__future__',):
            print(imports.get_body(future))

    import argparse

    parser = argparse.ArgumentParser()
    group = parser.add_mutually_exclusive_group()
    group.add_argument('-i', '--in-place', action='store_true')
    group.add_argument('-o', '--output', action='store', default=None)
    parser.add_argument('target', nargs='+', action='store', default=None)
    args = parser.parse_args()

# Generated at 2022-06-25 22:19:36.640057
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_1 = module_0.Module()
    module_1 = python2_future_transformer_0.visit_Module(module_1)
    assert_equal(python2_future_transformer_0._tree_changed, True)

# Generated at 2022-06-25 22:19:38.475826
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module = ast.parse("module = ast3.parse('module = ast3.parse('')')")
    Python2FutureTransformer(module)

# Generated at 2022-06-25 22:19:40.566408
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    python2_future_transformer_0 = Python2FutureTransformer(None)
    assert python2_future_transformer_0 is not None


# Generated at 2022-06-25 22:19:42.707592
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)



# Generated at 2022-06-25 22:19:45.453634
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)


# Generated at 2022-06-25 22:19:50.479934
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    assert python2_future_transformer_0._target == (2, 7)

import typed_ast._ast3 as module_0
import typing as module_1


# Generated at 2022-06-25 22:20:01.978366
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    i_m_p_0 = module_0.Import()
    i_m_p_0.names.append(None)
    i_m_p_0.names[0].name = "ast"
    i_m_p_0.names[0].asname = None
    i_m_p_0.lineno = None
    i_m_p_0.col_offset = None
    i_m_p_0.level = None
    a_s_t_1 = module_0.AST()
    i_m_p_0.module = a_s_t_1
    i_m_p_1 = module_

# Generated at 2022-06-25 22:20:06.057873
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)

if __name__ == '__main__':
    import sys
    import pytest

    errno = pytest.main(__file__)
    sys.exit(errno)

# Generated at 2022-06-25 22:20:07.067119
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # See below
    pass


# Generated at 2022-06-25 22:20:17.093855
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_0_0 = module_0.Module([module_0.Assign([module_0.Name('a_2', module_0.Store())], module_0.Num(0))])
    module_0_1 = python2_future_transformer_0.visit(module_0_0)

# Generated at 2022-06-25 22:20:19.577202
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)

# Generated at 2022-06-25 22:20:25.009735
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    # TODO: When is this test supposed to fail? Can you find any combination of inputs that will fail it?
    #       If so, use that to create a regression test.
    a_s_t_0_Module_0 = module_0.Module([])
    result = python2_future_transformer_0.visit_Module(a_s_t_0_Module_0)
    assert type(result) == module_0.Module
    assert len(result.body) == 4
    a_s_t_0_Module_1 = module_0.Module([])

# Generated at 2022-06-25 22:20:34.122117
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    a_s_t_1 = module_0.Module(body = [])
    a_s_t_1 = python2_future_transformer_0.visit(a_s_t_1)
    assert isinstance(a_s_t_1, module_0.Module)
    assert isinstance(a_s_t_1.body, list)
    assert len(a_s_t_1.body) == 4

# Generated at 2022-06-25 22:20:43.419707
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    a_s_t_1 = module_0.Module()
    a_s_t_2 = module_0.FunctionDef()
    a_s_t_2.name = 'test_Python2FutureTransformer_visit_Module'
    a_s_t_1.body.append(a_s_t_2)
    python2_future_transformer_0.visit(a_s_t_1)
    return

if (__name__ == '__main__'):
    test_case_0()
    test_Python2FutureTransformer_visit_Module()
    pass

# Generated at 2022-06-25 22:20:44.303182
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass


# Generated at 2022-06-25 22:20:48.338043
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    node_0 = ast.Module()

    node_result_0 = python2_future_transformer_0.visit_Module(node_0)

    return (node_result_0, python2_future_transformer_0._tree_changed)

# Generated at 2022-06-25 22:20:52.991288
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass



# Generated at 2022-06-25 22:21:01.017911
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    dict_0 = {}
    module_x_var_0 = module_0.Module(**dict_0)
    str_0 = 'm5G\x0c'
    dict_1 = {str_0: str_0, str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_1)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:21:06.417057
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    dict_0 = {}
    module_x_var_0 = module_0.Module(**dict_0)
    str_0 = 'm5G\x0c'
    dict_1 = {str_0: str_0, str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_1)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    test_case_0()


# Generated at 2022-06-25 22:21:14.628954
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    dict_0 = {}
    module_x_var_0 = module_0.Module(**dict_0)
    str_0 = 'm5G\x0c'
    dict_1 = {str_0: str_0, str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_1)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)


# Generated at 2022-06-25 22:21:18.888124
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert python2_future_transformer_0
    assert callable(python2_future_transformer_0)
    assert module_x_var_1
    assert callable(module_x_var_1)
    assert test_case_0()


# Generated at 2022-06-25 22:21:21.609626
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    result = test_case_0()

if __name__ == '__main__':
    test_Python2FutureTransformer_visit_Module()

# Generated at 2022-06-25 22:21:23.000504
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    test_case_0()

# Generated at 2022-06-25 22:21:24.589019
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    test_case_0()

# Generated at 2022-06-25 22:21:32.368573
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    dict_0 = {}
    module_x_var_0 = module_0.Module(**dict_0)
    str_0 = 'm5G\x0c'
    dict_1 = {str_0: str_0, str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_1)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:21:39.255600
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    dict_0 = {}
    module_x_var_0 = module_0.Module(**dict_0)
    str_0 = 'm5G\x0c'
    dict_1 = {str_0: str_0, str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_1)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)


# Generated at 2022-06-25 22:21:48.885640
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    dict_0 = {}
    module_x_var_0 = module_0.Module(**dict_0)
    str_0 = 'm5G\x0c'
    dict_1 = {str_0: str_0, str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_1)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)


# Generated at 2022-06-25 22:21:49.926526
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    python2_future_transformer_1 = Python2FutureTransformer(1)

# Generated at 2022-06-25 22:21:57.880159
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Instantiating an instance of the class
    module_x_var_0 = module_0.Module()
    str_0 = 'm5G\x0c'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_0)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    # Calling the method
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    try:
        assert module_x_var_1 == None
    except AssertionError:
        raise AssertionError

# Generated at 2022-06-25 22:22:05.446174
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    dict_0 = {}
    module_0 = module_0.Module(**dict_0)
    str_0 = 'm5G\x0c'
    dict_1 = {str_0: str_0, str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_1)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    python2_future_transformer_0.visit_Module(module_0)
    python2_future_transformer_0._tree_changed


# Generated at 2022-06-25 22:22:07.751473
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # test constructor
    try:
        test_case_0()
        assert False, 'can not construct an instance of Python2FutureTransformer'
    except Exception:
        pass

# Generated at 2022-06-25 22:22:12.944089
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    dict_0 = {}
    module_x_var_0 = module_0.Module(**dict_0)
    str_0 = 'm5G\x0c'
    dict_1 = {str_0: str_0, str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_1)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)


# Generated at 2022-06-25 22:22:21.991486
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    dict_0 = {}
    module_x_var_0 = module_0.Module(**dict_0)
    str_0 = 'm5G\x0c'
    dict_1 = {str_0: str_0, str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_1)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    # assert that the value of the transformed tree is as expected

# Generated at 2022-06-25 22:22:26.698462
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    dict_0 = {}
    module_x_var_0 = module_0.Module(**dict_0)
    str_0 = 'm5G\x0c'
    dict_1 = {str_0: str_0, str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_1)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)

# Generated at 2022-06-25 22:22:33.611173
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    dict_0 = {}
    module_x_var_0 = module_0.Module(**dict_0)
    str_0 = 'm5G\x0c'
    dict_1 = {str_0: str_0, str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_1)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:22:40.574337
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    dict_0 = {}
    module_x_var_0 = module_0.Module(**dict_0)
    str_0 = 'm5G\x0c'
    dict_1 = {str_0: str_0, str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_1)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:22:54.942818
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    test_case_0()

# Generated at 2022-06-25 22:23:03.988291
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    dict_0 = {}
    module_x_var_0 = module_0.Module(**dict_0)
    str_0 = 'm5G\x0c'
    dict_1 = {str_0: str_0, str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_1)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    assert module_x_var_0 == module_x_var_1

str_0 = 'm5G\x0c'

# Generated at 2022-06-25 22:23:05.690528
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    """Test method visit_Module of class Python2FutureTransformer"""
    test_case_0()

# Generated at 2022-06-25 22:23:11.118140
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    str_0 = 'm5G\x0c'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_0)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    assert (python2_future_transformer_0 is not None)


# Generated at 2022-06-25 22:23:18.046293
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert isinstance(Python2FutureTransformer, object)
assert __name__ == '__main__'

_main()

# python2.7 -m typed_ast.transforms.future
# -*- coding: utf-8 -*-
#
# Copyright (c) 2017, Magenta ApS
#
# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.
#
#
# Author: Jakob Winther (jakob@magenta-aps.dk)


# Generated at 2022-06-25 22:23:27.485061
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # Raise error if the constructor takes more than 1 argument
    with pytest.raises(TypeError):
        Python2FutureTransformer(ast, ast)
    # Test that instance attribute tree_changed is initialized to False
    python2_future_transformer_0 = Python2FutureTransformer(ast)
    assert python2_future_transformer_0.tree_changed == False
    # Test that instance attribute target is initialized to (2, 7)
    assert python2_future_transformer_0.target == (2, 7)
    # Test that instance attribute _tree_changed is initialized to False
    assert python2_future_transformer_0._tree_changed == False
    # Test that instance attribute target_type is initialized to target
    assert python2_future_transformer_0.target_type == python2_future_transformer_0.target

# Generated at 2022-06-25 22:23:34.353182
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    dict_0 = {}
    module_x_var_0 = module_0.Module(**dict_0)
    str_0 = 'm5G\x0c'
    dict_1 = {str_0: str_0, str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_1)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    assert module_x_var_1 == module_x_var_0

# Generated at 2022-06-25 22:23:41.224794
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    dict_0 = {}
    module_x_var_0 = module_0.Module(**dict_0)
    str_0 = 'm5G\x0c'
    dict_1 = {str_0: str_0, str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_1)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    module_x_var_1

# Generated at 2022-06-25 22:23:47.444804
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    dict_0 = {}
    module_x_var_0 = module_0.Module(**dict_0)
    str_0 = 'm5G\x0c'
    dict_1 = {str_0: str_0, str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_1)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:23:55.323909
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    dict_0 = {}
    module_x_var_0 = module_0.Module(**dict_0)
    str_0 = 'm5G\x0c'
    dict_1 = {str_0: str_0, str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_1)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    str_1 = 'm5G\x0c'

# Generated at 2022-06-25 22:24:26.613455
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert True


# Generated at 2022-06-25 22:24:29.504714
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    python2_future_transformer_0 = Python2FutureTransformer(None)
    assert python2_future_transformer_0.version == (2, 7)
    assert python2_future_transformer_0.visit_Module is Python2FutureTransformer.visit_Module

# Generated at 2022-06-25 22:24:36.025935
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    dict_0 = {}
    module_x_var_0 = module_0.Module(**dict_0)
    str_0 = 'm5G\x0c'
    dict_1 = {str_0: str_0, str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_1)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:24:44.646441
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    dict_0 = {'body': [], 'type_ignores': []}
    module_x_var_0 = module_0.Module(**dict_0)
    dict_0 = {'body': [], 'type_ignores': []}
    module_x_var_1 = module_0.Module(**dict_0)
    dict_0 = {'body': [], 'type_ignores': []}
    module_x_var_2 = module_0.Module(**dict_0)
    dict_0 = {'body': [], 'type_ignores': []}
    module_x_var_3 = module_0.Module(**dict_0)
    dict_0 = {'body': [], 'type_ignores': []}

# Generated at 2022-06-25 22:24:45.423708
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    test_case_0()

# Generated at 2022-06-25 22:24:46.197725
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    test_case_0()

# Generated at 2022-06-25 22:24:46.645936
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass

# Generated at 2022-06-25 22:24:47.863629
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    node_var = Module()
    python2_future_transformer_var = Python2FutureTransformer(node_var)

# Generated at 2022-06-25 22:24:53.056100
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    dict_0 = {}
    module_x_var_0 = module_0.Module(**dict_0)
    str_0 = 'm5G\x0c'
    dict_1 = {str_0: str_0, str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_1)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)


# Generated at 2022-06-25 22:24:54.040094
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    python2_future_transformer_0 = Python2FutureTransformer()

# Generated at 2022-06-25 22:26:02.958313
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    test_case_0()

# Generated at 2022-06-25 22:26:14.967626
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    dict_0 = {}
    module_x_var_0 = module_0.Module(**dict_0)
    str_0 = 'm5G\x0c'
    dict_1 = {str_0: str_0, str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_1)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    assert module_x_var_1

if __name__ == '__main__':
    test_Python2FutureTransformer_visit_Module()

# Generated at 2022-06-25 22:26:16.778735
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass # TODO: implement your test here


# Generated at 2022-06-25 22:26:17.483125
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    test_case_0()


# Generated at 2022-06-25 22:26:24.278624
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    dict_0 = {}
    module_x_var_0 = module_0.Module(**dict_0)
    str_0 = 'm5G\x0c'
    dict_1 = {str_0: str_0, str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_1)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:26:32.010106
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    dict_0 = {}
    module_x_var_0 = module_0.Module(**dict_0)
    str_0 = 'm5G\x0c'
    dict_1 = {str_0: str_0, str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_1)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)


# Generated at 2022-06-25 22:26:38.397272
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    dict_0 = {}
    module_x_var_0 = module_0.Module(**dict_0)
    str_0 = 'm5G\x0c'
    dict_1 = {str_0: str_0, str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_1)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:26:45.187347
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    dict_0 = {}
    module_x_var_0 = module_0.Module(**dict_0)
    str_0 = 'm5G\x0c'
    dict_1 = {str_0: str_0, str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_1)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    assert (module_x_var_1 == module_0.Module())

# Generated at 2022-06-25 22:26:48.660061
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    s = "print(123)"
    tree = ast.parse(s)
    Python2FutureTransformer(tree).visit_Module(tree)
    out = ast.dump(tree)
    assert out == "Module(body=[Expr(value=Call(func=Name(id='print', ctx=Load()), args=[Num(n=123)], keywords=[]))])"

# Generated at 2022-06-25 22:26:53.482801
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    dict_0 = {}
    module_x_var_0 = module_0.Module(**dict_0)
    str_0 = 'm5G\x0c'
    dict_1 = {str_0: str_0, str_0: str_0, str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_1)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)