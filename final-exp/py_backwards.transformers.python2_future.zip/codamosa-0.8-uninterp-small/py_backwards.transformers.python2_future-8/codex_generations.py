

# Generated at 2022-06-25 22:18:19.561811
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = None
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    python2_future_transformer_0.visit(a_s_t_0)
    python2_future_transformer_0.generic_visit(a_s_t_0)

# Generated at 2022-06-25 22:18:31.296954
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = ast.parse('# foo')
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    try:
        python2_future_transformer_0.visit_Module(a_s_t_0)
    except:
        assert False


if __name__ == '__main__':
    test_case_0()
    test_Python2FutureTransformer_visit_Module()

# Generated at 2022-06-25 22:18:36.883527
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    ast_0 = ast.ClassDef(name='', bases=[], keywords=[], body=[], decorator_list=[])
    python2_future_transformer_0 = Python2FutureTransformer(ast_0)
    assert python2_future_transformer_0._tree_changed is False
    assert python2_future_transformer_0._tree is not None
    assert python2_future_transformer_0._tree is ast_0

# Unit tests for static method Python2FutureTransformer.get_docstring

# Generated at 2022-06-25 22:18:41.798270
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = None
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    assert python2_future_transformer_0.target == (2, 7)
    assert python2_future_transformer_0._tree_changed == False


# Generated at 2022-06-25 22:18:45.788407
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_module_0 = ast.Module()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_module_0)
    python2_future_transformer_0.visit_Module(a_s_t_module_0)
    pass

# Generated at 2022-06-25 22:18:49.424656
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = None
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    return (python2_future_transformer_0)


# Generated at 2022-06-25 22:18:50.197757
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    test_case_0()

# Generated at 2022-06-25 22:18:52.076382
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = None
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)


# Generated at 2022-06-25 22:18:53.264228
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    pass


# Generated at 2022-06-25 22:19:03.544351
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # It should return the same node if its not a Python 2 module
    node = ast.parse('x = 1')
    python2_future_transformer_0 = Python2FutureTransformer(node)
    assert python2_future_transformer_0.visit(node) == node

    # It should prepend the module with these imports if it is a Python 2 module
    node = ast.parse('x = 1', future_imports='division')
    python2_future_transformer_1 = Python2FutureTransformer(node)
    assert isinstance(python2_future_transformer_1.visit(node), ast.Module)

# Generated at 2022-06-25 22:19:09.675941
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    assert isinstance(python2_future_transformer_0, Python2FutureTransformer)


# Generated at 2022-06-25 22:19:17.971416
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    assert(module_x_var_1.body[0].names[0].id == 'absolute_import')
    assert(module_x_var_1.body[1].names[0].id == 'division')
    assert(module_x_var_1.body[2].names[0].id == 'print_function')
    assert(module_x_var_1.body[3].names[0].id == 'unicode_literals')

# Generated at 2022-06-25 22:19:24.249614
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    import typed_ast.ast3 as module_0
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:19:29.617828
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    assert isinstance(module_x_var_1, module_0.Module)


# Generated at 2022-06-25 22:19:32.838315
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    assert python2_future_transformer_0 is not None

# Generated at 2022-06-25 22:19:35.603066
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)


# Generated at 2022-06-25 22:19:40.056737
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
   module_x_var_0 = module_0.Module()
   a_s_t_0 = module_0.AST()
   python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
   module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
   

# Generated at 2022-06-25 22:19:40.754800
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    test_case_0()

# Generated at 2022-06-25 22:19:46.642859
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    assert module_x_var_1 is not None
    assert module_x_var_1 is not None

# Generated at 2022-06-25 22:19:47.692007
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    test_case_0()



# Generated at 2022-06-25 22:19:54.205616
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    print(type(python2_future_transformer_0))


# Generated at 2022-06-25 22:20:02.438044
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = ast.Module()
    a_s_t_0 = typed_ast.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    assert python2_future_transformer_0._tree_changed == True
    assert module_x_var_1.body[0].value.id == 'absolute_import'
    assert module_x_var_1.body[1].value.id == 'division'
    assert module_x_var_1.body[2].value.id == 'print_function'

# Generated at 2022-06-25 22:20:03.520734
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    test_case_0()

a3 = ast.parse('')

# Generated at 2022-06-25 22:20:13.854083
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    def test_case_1():
        module_x_var_0 = module_0.Module()
        a_s_t_0 = module_0.AST()
        python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
        module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    module_x_var_0

# Generated at 2022-06-25 22:20:18.452242
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.Module()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_0 = module_0.Module()
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    assert True

# Generated at 2022-06-25 22:20:22.155266
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:20:25.846091
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    __tracebackhide__ = True

# Generated at 2022-06-25 22:20:31.851888
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    assert isinstance(python2_future_transformer_0, BaseNodeTransformer)
    assert hasattr(python2_future_transformer_0, 'visit_Module')
    assert hasattr(python2_future_transformer_0, 'generic_visit')


# Generated at 2022-06-25 22:20:41.366486
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    import typed_ast._ast3 as module_0
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    module_x_var_2 = module_x_var_1
    # Assert body of module_x_var_2 is equal to imports.get_body(future='__future__')
    # Assert body of module_x_var_0 is equal to module

# Generated at 2022-06-25 22:20:46.864780
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import unittest

    class TestVisit_Module(unittest.TestCase):
        def test_1(self):
            module_x_var_0 = module_0.Module()
            a_s_t_0 = module_0.AST()
            python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
            module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)




# Generated at 2022-06-25 22:20:56.365744
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    arg_1_var = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(arg_1_var)

# Generated at 2022-06-25 22:21:01.063782
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:21:04.697105
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:21:08.099818
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    test_case_0()

# Generated at 2022-06-25 22:21:10.780243
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    node = Node0()
    python2_future_transformer_0 = Python2FutureTransformer(node)


# Generated at 2022-06-25 22:21:14.518540
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    assert isinstance(python2_future_transformer_0, Python2FutureTransformer)

# Generated at 2022-06-25 22:21:18.420860
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert isinstance(Python2FutureTransformer(ast.AST()), Python2FutureTransformer)
    instance0 = Python2FutureTransformer(ast.AST())
    assert isinstance(instance0, Python2FutureTransformer)


# Generated at 2022-06-25 22:21:21.265645
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    """
    Visit module node
    """
    test_case_0()

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 22:21:22.678584
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    test_case_0()

# Generated at 2022-06-25 22:21:29.257544
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)


# Generated at 2022-06-25 22:21:45.490066
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert True


# Generated at 2022-06-25 22:21:51.479756
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_2 = module_0.Module()
    a_s_t_1 = module_0.AST()
    python2_future_transformer_1 = Python2FutureTransformer(a_s_t_1)
    module_x_var_3 = python2_future_transformer_1.visit_Module(module_x_var_2)
    if python2_future_transformer_1._tree_changed == True:
        raise ValueError()



if __name__ == '__main__':
    test_case_0()
    test_Python2FutureTransformer_visit_Module()

# Generated at 2022-06-25 22:21:55.546466
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:22:00.334659
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    assert module_x_var_1 is not None


# Generated at 2022-06-25 22:22:03.017235
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    test_case_0()
    # "Python2FutureTransformer.visit_Module" is not yet implemented.
    # assert False


# Generated at 2022-06-25 22:22:03.854520
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    test_case_0()

# Generated at 2022-06-25 22:22:07.712982
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:22:08.544017
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    assert not module_x_var_1

# Generated at 2022-06-25 22:22:12.752593
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)


# Generated at 2022-06-25 22:22:20.359399
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # . . . . . . . . . . . . . . . . . . .
    # Setup test data and expected result
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    # TODO: Assert result
    # . . . . . . . . . . . . . . . . . . .

# Generated at 2022-06-25 22:22:55.891993
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

# Unit test snippet for snippet imports

# Generated at 2022-06-25 22:23:05.174224
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():

    # python2future needs a typed_ast for this test to run
    try:
        from typed_ast import ast3 as typed_ast
        from typed_ast import _ast3 as module_1
    except:
        return

    module_y_var_0 = module_1.Module()
    module_y_var_1 = module_1.Name('a', _ctx=module_1.Load())
    module_y_var_2 = module_1.Assign(targets=[module_y_var_1], value=None)
    module_y_var_3 = module_1.Str('a')
    module_y_var_4 = module_1.Expr(value=module_y_var_3)

# Generated at 2022-06-25 22:23:06.627203
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_ast__AST_0 = module_0.AST()
    test_case_0()



# Generated at 2022-06-25 22:23:11.442356
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_2 = module_0.Module()
    a_s_t_1 = module_0.AST()
    python2_future_transformer_1 = Python2FutureTransformer(a_s_t_1)
    module_x_var_3 = python2_future_transformer_1.visit_Module(module_x_var_2)

from numbers import Real


# Generated at 2022-06-25 22:23:17.777686
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Test for method Python2FutureTransformer.visit_Module(module)
    assert test_case_0() == module_0.Module(body=[
        module_0.ImportFrom(module='__future__', names=[
            module_0.alias(name='absolute_import', asname=None),
            module_0.alias(name='division', asname=None),
            module_0.alias(name='print_function', asname=None),
            module_0.alias(name='unicode_literals', asname=None)],
                                          level=0)], type_ignores=[])

# Generated at 2022-06-25 22:23:20.650439
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():

    # Create instance of class Python2FutureTransformer
    python2_future_transformer_0 = Python2FutureTransformer()

if __name__ == '__main__':
    test_Python2FutureTransformer()
    test_case_0()

# Generated at 2022-06-25 22:23:21.463103
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Call function
    test_case_0()

# Generated at 2022-06-25 22:23:27.004765
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)


# Generated at 2022-06-25 22:23:29.321619
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    ducktyping_0 = Python2FutureTransformer(None)

if __name__ == '__main__':
    test_case_0()
    test_Python2FutureTransformer()

# Generated at 2022-06-25 22:23:33.456434
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_x_var_2 = module_0.Module()
    a_s_t_1 = module_0.AST()
    python2_future_transformer_1 = Python2FutureTransformer(a_s_t_1)
    module_x_var_3 = python2_future_transformer_1.visit_Module(module_x_var_2)


# Generated at 2022-06-25 22:24:44.778679
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Run test
    test_case_0()

# Generated at 2022-06-25 22:24:52.274850
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():

    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    assert isinstance(module_x_var_1, module_0.Module)

    assert module_x_var_1.body
    print(len(module_x_var_1.body))
    assert len(module_x_var_1.body) == 4
    assert isinstance(module_x_var_1.body[0], module_0.ImportFrom)

# Generated at 2022-06-25 22:24:54.184518
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)


# Generated at 2022-06-25 22:24:57.143828
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)

# Generated at 2022-06-25 22:25:00.280754
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    test_case_0()

if __name__ == '__main__':
    import sys, os
    sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
    main()

# Generated at 2022-06-25 22:25:02.094587
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)


# Generated at 2022-06-25 22:25:05.478246
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:25:06.838102
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    test_case_0()

if __name__ == '__main__':
    import nose

    nose.runmodule()

# Generated at 2022-06-25 22:25:07.275392
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass

# Generated at 2022-06-25 22:25:09.916346
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)


# Generated at 2022-06-25 22:28:03.792749
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    module_x_var_2 = python2_future_transformer_0.visit_Module(module_x_var_1)
    python2_future_transformer_0.visit_Module(module_x_var_2)

if __name__ == '__main__':
    test_case_0()
    #test_Python2FutureTransformer_visit_Module()

# Generated at 2022-06-25 22:28:09.342587
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    parsed_0 = ast.parse("\nx = 1")
    python2_future_transformer_0 = Python2FutureTransformer(parsed_0)
    # Test attribute "ast_tree" of class Python2FutureTransformer.
    assert isinstance(python2_future_transformer_0.ast_tree, ast.AST)
    assert python2_future_transformer_0.ast_tree == parsed_0
    # Test attribute "tree_changed" of class Python2FutureTransformer.
    assert python2_future_transformer_0.tree_changed == False

# Generated at 2022-06-25 22:28:15.454196
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .. import ast_parser
    from . import py_to_py__test_resources
    from . import python2_future_transformer
    module_0_var_0 = python2_future_transformer.Python2FutureTransformer(ast_parser.ast_parser_var_0)
    module_0_var_1 = ast_parser.ast_parser_var_0.parse(py_to_py__test_resources.module_0_var_0)
    module_0_var_2 = module_0_var_0.visit_Module(module_0_var_1)