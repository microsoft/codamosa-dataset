

# Generated at 2022-06-25 22:18:12.389858
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer


    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals
    a_s_t_0 = ast.AST()
    python2_future_transformer_0 = Python2FutureTransformer(tree=a_s_t_0)
    module_x_var_0 = ast.Module()
    python2_future_transformer_1 = Python2FutureTransformer(tree=module_x_var_0)

# Generated at 2022-06-25 22:18:18.554233
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    a_s_t_0 = module_0.AST()
    python2_future_transformer_1 = Python2FutureTransformer(a_s_t_0)
    return python2_future_transformer_1


# Generated at 2022-06-25 22:18:20.843208
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)


# Generated at 2022-06-25 22:18:26.153353
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_0 = module_0.Module()
    python2_future_transformer_0.visit(module_x_var_0)
    # assert False # TODO: implement your test here
    assert True # TODO: implement your test here


# Generated at 2022-06-25 22:18:30.431071
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    assert not hasattr(module_x_var_0.body, 'insert')
    python2_future_transformer_0.visit_Module(module_x_var_0)
    assert hasattr(module_x_var_0.body, 'insert')

# Generated at 2022-06-25 22:18:32.361404
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)

# Generated at 2022-06-25 22:18:37.001364
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    assert isinstance(python2_future_transformer_0, Python2FutureTransformer)
    # assert python2_future_transformer_0.a_s_t is a_s_t_0


# Generated at 2022-06-25 22:18:47.659864
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_0 = module_0.Module()
    python2_future_transformer_x_var_0 = python2_future_transformer_0.visit_Module(module_x_var_0)
    assert isinstance(python2_future_transformer_x_var_0, module_0.Module)
    assert hasattr(python2_future_transformer_x_var_0, 'body')
    assert len(python2_future_transformer_x_var_0.body) == 4

# Generated at 2022-06-25 22:18:55.213778
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    assert type(python2_future_transformer_0) == Python2FutureTransformer


# Generated at 2022-06-25 22:19:03.409936
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    python2_future_transformer_0.target = (2, 7)
    module_x_var_0 = module_0.Module()
    python2_future_transformer_0.visit_Module(module_x_var_0)
    python2_future_transformer_0.generic_visit(module_x_var_0)
    python2_future_transformer_0.generic_visit(module_x_var_0)


# Generated at 2022-06-25 22:19:06.313782
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()


# Generated at 2022-06-25 22:19:07.442979
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # TODO: Implement.
    pass

# Generated at 2022-06-25 22:19:11.959215
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    expected = 'from __future__ import absolute_import\n' + \
        'from __future__ import division\n' + \
        'from __future__ import print_function\n' + \
        'from __future__ import unicode_literals\n' + \
        '\n' + \
        'insert'
    actual = test_case_0.__code__
    assert expected == actual

# Generated at 2022-06-25 22:19:19.412392
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-25 22:19:19.944906
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert True

# Generated at 2022-06-25 22:19:20.868769
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    str_0 = 'insert'


# Generated at 2022-06-25 22:19:21.430579
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass

# Generated at 2022-06-25 22:19:23.876916
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from .base import BaseNodeTransformer
    py2futuretransformer = Python2FutureTransformer()
    assert isinstance(py2futuretransformer, BaseNodeTransformer)


# Generated at 2022-06-25 22:19:31.524422
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer(2, 7)
    input_value = ast.parse("insert")
    expected_value = ast.parse("\nfrom __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n\ninsert")
    actual_value = transformer.visit(input_value)
    assert actual_value.body[0].body == expected_value.body[0].body
    assert actual_value.body[0].names == expected_value.body[0].names


if __name__ == "__main__":
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-25 22:19:40.639550
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_0 = ast.parse(test_case_0)
    module_1 = Python2FutureTransformer(2, 7).visit(module_0)
    print(ast.dump(module_1))

# Generated at 2022-06-25 22:19:52.732046
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    #Test module.py:2:
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    list_0 = []
    a_s_t_0 = module_0.AST(*list_0)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    #Test module.py:4:
    list_1 = []
    module_x_var_0 = module_0.Module(*list_1)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    #Test module.py:1:
    list_2 = []

# Generated at 2022-06-25 22:19:56.640920
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # constructor with argument
    expr_ast = module_0.Expr(module_0.Name("a", module_0.Load()))
    python2_future_transformer_0 = Python2FutureTransformer(expr_ast)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_0.Module())

# Generated at 2022-06-25 22:19:57.538962
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    test_case_0()

# Generated at 2022-06-25 22:19:58.436903
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    test_case_0()

# Generated at 2022-06-25 22:20:02.613046
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    list_0 = []
    a_s_t_0 = module_0.AST(*list_0)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:20:03.353561
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():

    test_case_0()

# Generated at 2022-06-25 22:20:05.458793
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # testing for matching the target version
    assert Python2FutureTransformer.target == (2, 7)

# Generated at 2022-06-25 22:20:08.958435
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_x_var_0 = module_0.Module()
    list_0 = []
    a_s_t_0 = module_0.AST(*list_0)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)


# Generated at 2022-06-25 22:20:16.591585
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    try:
        module_0.Module()
    except SystemError as class_0:
        python2_future_transformer_0 = Python2FutureTransformer(class_0)
    else:
        try:
            module_0.Module()
        except SystemError as class_0_1:
            python2_future_transformer_1 = Python2FutureTransformer(class_0_1)
        else:
            python2_future_transformer_2 = Python2FutureTransformer(module_0)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 22:20:18.617097
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # This method is not firing up the generic_visit of class BaseNodeTransformer
    # so I am not testing it
    pass

# Generated at 2022-06-25 22:20:29.031583
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Prepare function environment
    import typed_ast._ast3 as module_0
    module_x_var_0 = module_0.Module()
    list_0 = []
    a_s_t_0 = module_0.AST(*list_0)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)

    # Call function to test
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

    # Check for expected results
    assert module_x_var_1 == module_x_var_0
    module_0.Module().body = 0

import typed_ast._ast3 as module_0


# Generated at 2022-06-25 22:20:30.323950
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    test_case_0()


# Generated at 2022-06-25 22:20:32.766786
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    python2_future_transformer_0 = Python2FutureTransformer(None)
    assert isinstance(python2_future_transformer_0, Python2FutureTransformer)


# Generated at 2022-06-25 22:20:42.299768
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast._ast3 import AST
    t_0 = AST()
    python2_future_transformer_0 = Python2FutureTransformer(t_0)
    # assert python2_future_transformer_0.future == '__future__'
    # assert python2_future_transformer_0.target == (2, 7)
    # assert python2_future_transformer_0.python_2_unicode_compatible == True
    # assert python2_future_transformer_0._current_future_imports == {'__future__', 'absolute_import', 'division', 'print_function', 'unicode_literals'}
    # assert python2_future_transformer_0._current_imports == set()

if __name__ == '__main__':
    test_case_0()
    test_

# Generated at 2022-06-25 22:20:47.281388
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # method visit_Module
    module_x_var_0 = module_0.Module()
    list_0 = []
    a_s_t_0 = module_0.AST(*list_0)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)



# Generated at 2022-06-25 22:20:54.825964
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    list_0 = []
    a_s_t_0 = module_0.AST(*list_0)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:20:58.693960
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_x_var_0 = module_0.Module()
    list_0 = []
    a_s_t_0 = module_0.AST(*list_0)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)

# Generated at 2022-06-25 22:20:59.529584
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    test_case_0()

# Generated at 2022-06-25 22:21:03.952882
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    list_0 = []
    a_s_t_0 = module_0.AST(*list_0)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    python2_future_transformer_0.visit_Module(module_x_var_0)
    assert True

# Generated at 2022-06-25 22:21:13.872401
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..base import BaseNodeTransformer
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    module_x_var_0 = module_0.Module()
    list_0 = []
    a_s_t_0 = module_0.AST(*list_0)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)

# Generated at 2022-06-25 22:21:30.002443
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_x_var_0 = module_0.Module()
    list_0 = []
    a_s_t_0 = module_0.AST(*list_0)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    assert python2_future_transformer_0._targets == {(2, 7)}
    assert python2_future_transformer_0._tree_changed == False
    assert python2_future_transformer_0._tree is a_s_t_0


# Generated at 2022-06-25 22:21:31.089171
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer(a_s_t_0) == None

# Generated at 2022-06-25 22:21:32.443253
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_x_var_0 = module_0.Modu

# Generated at 2022-06-25 22:21:33.313446
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert True


# Generated at 2022-06-25 22:21:40.936867
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_x_var_0 = module_0.Module()
    list_0 = []
    a_s_t_0 = module_0.AST(*list_0)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    assert isinstance(python2_future_transformer_0, module_0.NodeTransformer)
    assert isinstance(python2_future_transformer_0, Python2FutureTransformer)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    assert isinstance(module_x_var_1, module_0.Module)

# Generated at 2022-06-25 22:21:43.534852
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x = module_0.Module()
    python2_future_transformer = Python2FutureTransformer()
    module_x = python2_future_transformer.visit_Module(module_x)

# Generated at 2022-06-25 22:21:44.623332
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    pass


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 22:21:48.364331
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    list_0 = []
    a_s_t_0 = module_0.AST(*list_0)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:21:49.747470
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Input parameters

    # Return type: None

    # Call method
    test_case_0()

# Generated at 2022-06-25 22:21:54.544390
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():

    # test method visit_Module
    module_x_var_0 = module_0.Module()
    list_0 = []
    a_s_t_0 = module_0.AST(*list_0)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:22:17.712691
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    with open('test/test_modules/test_module_ast_0.py') as f:
        a_s_t_0 = ast.parse(f.read())
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)


# Generated at 2022-06-25 22:22:25.523285
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    with pytest.raises(TypeError) as err:
        # Compare type only, do not compare value
        assert isinstance(Python2FutureTransformer(copy.copy('')), Python2FutureTransformer)
    assert str(err.value) == 'Argument tree of <class \'typed_ast._ast3.AST\'> is not supported'

    import ast as module_0
    module_x_var_0 = module_0.Module()
    python2_future_transformer_0 = Python2FutureTransformer(module_x_var_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    assert isinstance(python2_future_transformer_0, Python2FutureTransformer)
    assert python2_future_transformer_0

# Generated at 2022-06-25 22:22:26.281520
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    test_case_0()


# Generated at 2022-06-25 22:22:28.617644
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    try:
        test_case_0()
    except:
        print("An exception occurred")
    else:
        print("OK")

# Generated at 2022-06-25 22:22:29.668854
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    test_case_0()


# Generated at 2022-06-25 22:22:31.504202
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t = module_0.AST(*[])
    python2_future_transformer = Python2FutureTransformer(a_s_t)


# Generated at 2022-06-25 22:22:36.084247
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    list_0 = []
    a_s_t_0 = module_0.AST(*list_0)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

test_case_0()

# Generated at 2022-06-25 22:22:39.407614
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    python2_future_transformer_0 = Python2FutureTransformer(module_0.AST())
    assert python2_future_transformer_0 != None
    assert python2_future_transformer_0._tree_changed == False
    assert python2_future_transformer_0._futures_added == True

# Generated at 2022-06-25 22:22:44.408925
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    list_0 = []
    a_s_t_0 = module_0.AST(*list_0)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)


# Generated at 2022-06-25 22:22:45.235447
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    test_case_0()

# Generated at 2022-06-25 22:23:19.382174
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    list_0 = []
    a_s_t_0 = module_0.AST(*list_0)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:23:24.062381
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    list_0 = []
    a_s_t_0 = module_0.AST(*list_0)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:23:25.941303
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # Run test
    test_case_0()

# Generated at 2022-06-25 22:23:29.853860
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    tree_0 = module_0.Module()  # pylint: disable=redefined-variable-type
    assert type(tree_0) is module_0.Module
    python2_future_transformer_0 = Python2FutureTransformer(tree_0)
    assert type(python2_future_transformer_0) is Python2FutureTransformer


# Generated at 2022-06-25 22:23:37.787499
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_x_var_0 = module_0.Module()
    list_0 = []
    a_s_t_0 = module_0.AST(*list_0)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    python2_future_transformer_1 = Python2FutureTransformer(a_s_t_0)
    assert python2_future_transformer_0._tree_changed == None
    assert python2_future_transformer_0._tree == a_s_t_0
    assert python2_future_transformer_0.target == (2, 7)
    # We cannot compare string representation of AST objects for testing,
    # as isinstance does not work for them.
    # print(python2_future_transformer_0._tree == python2

# Generated at 2022-06-25 22:23:39.709041
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    if isinstance(Python2FutureTransformer(module_0.AST()), BaseNodeTransformer):
        assert True
    else:
        assert False


# Generated at 2022-06-25 22:23:45.467260
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Create an instance of the class
    module_x_var_2 = module_0.Module()
    list_1 = []
    a_s_t_1 = module_0.AST(*list_1)
    python2_future_transformer_1 = Python2FutureTransformer(a_s_t_1)
    module_x_var_3 = python2_future_transformer_1.visit_Module(module_x_var_2)
    assert True

# Unit tests for class Python2FutureTransformer

# Generated at 2022-06-25 22:23:51.612311
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    list_0 = []
    a_s_t_0 = module_0.AST(*list_0)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

if __name__ == '__main__':
    test_case_0()
    test_Python2FutureTransformer_visit_Module()

# Generated at 2022-06-25 22:23:58.427692
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast._ast3 import Module
    from .base import BaseNodeTransformer

    import sys
    python2_future_transformer_0 = Python2FutureTransformer(Module())
    assert isinstance(python2_future_transformer_0, BaseNodeTransformer)
    assert python2_future_transformer_0.future == '__future__'
    assert python2_future_transformer_0.target == (2, 7)
    assert python2_future_transformer_0.target >= sys.version_info
    assert isinstance(python2_future_transformer_0.target, tuple)
    assert isinstance(python2_future_transformer_0.target, collections.abc.Hashable)
    assert python2_future_transformer_0.imports == imports
    assert python2_future_transformer_0

# Generated at 2022-06-25 22:24:01.761221
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor

    try:
        # Call the constructor
        module_x_var_0 = Python2FutureTransformer()
    except (TypeError, ValueError) as err:
        print(err)


# Generated at 2022-06-25 22:25:17.336083
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    module_0 = ast.Module()
    python2_future_transformer_0 = Python2FutureTransformer(module_0)
    assert python2_future_transformer_0 is not None


# Generated at 2022-06-25 22:25:21.163413
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    list_0 = []
    a_s_t_0 = module_0.AST(*list_0)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:25:24.232225
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    assert python2_future_transformer_0 != None


# Generated at 2022-06-25 22:25:29.384178
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_x_var_0 = module_0.Module()
    list_0 = []
    a_s_t_0 = module_0.AST(*list_0)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    assert(python2_future_transformer_0.target == (2, 7))
    assert(python2_future_transformer_0._tree_changed == False)
    assert(python2_future_transformer_0._top_level_module == a_s_t_0)



# Generated at 2022-06-25 22:25:30.088034
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    test_case_0()



# Generated at 2022-06-25 22:25:33.751049
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    list_0 = []
    a_s_t_0 = module_0.AST(*list_0)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    python2_future_transformer_0.visit_Module(module_x_var_0)


# Generated at 2022-06-25 22:25:35.131748
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    test_case_0()

# Generated at 2022-06-25 22:25:38.414935
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    list_0 = []
    a_s_t_0 = module_0.AST(*list_0)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:25:39.995424
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # Test for __init__()
    python2_future_transformer_0 = Python2FutureTransformer()


# Generated at 2022-06-25 22:25:47.855796
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    list_0 = []
    a_s_t_0 = module_0.AST(*list_0)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    assert module_x_var_1.body[0].names[0].name == 'absolute_import'
    assert module_x_var_1.body[0].names[1].name == 'division'
    assert module_x_var_1.body[0].names[2].name == 'print_function'