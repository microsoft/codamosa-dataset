

# Generated at 2022-06-25 22:18:09.019627
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    type_store = TypeStore()
    module_0 = ModuleType(name='test_case_0')
    python2_future_transformer_0 = Python2FutureTransformer(module_0)
    python2_future_transformer_0 = Python2FutureTransformer(module_0)
    module_0 = ModuleType(name='test_case_0')

# Generated at 2022-06-25 22:18:13.222216
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = None
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)

    python2_future_transformer_0.visit_Module(a_s_t_0)


# Generated at 2022-06-25 22:18:17.782205
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = None
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_0 = None
    # python2_future_transformer_0.visit_Module(module_0)

# Generated at 2022-06-25 22:18:21.113701
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = None
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    with pytest.raises(TypeError):
        python2_future_transformer_0.visit_Module(None)

# Generated at 2022-06-25 22:18:23.094284
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    assert True


if __name__ == '__main__':
    test_case_0()
    test_Python2FutureTransformer_visit_Module()

# Generated at 2022-06-25 22:18:30.603497
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = None
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    a_s_t_1 = None
    a_s_t_2 = ast.Module()
    try:
        a_s_t_3 = python2_future_transformer_0.visit_Module(a_s_t_2)
        msg_0 = "Target: python-2.7, Type: ast.Module(), Value: "
        assert msg_0 in repr(a_s_t_3)
    except Exception:
        msg_0 = "Target: python-2.7, Type: ast.Module(), Value: "
        a_s_t_4 = str(traceback.format_exc())

# Generated at 2022-06-25 22:18:35.943594
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = None
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    # first call to visit_Module
    module_0 = None
    try:
        python2_future_transformer_0.visit_Module(module_0)
    except Exception as exception_0:
        print("Exception when calling visit_Module: " + str(exception_0))
        raise
        

# Generated at 2022-06-25 22:18:40.142934
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = None
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_0 = None
    python2_future_transformer_0.visit_Module(module_0)

# Generated at 2022-06-25 22:18:45.153794
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = None
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    # Fails because method is not implemented
    with pytest.raises(NotImplementedError):
        python2_future_transformer_0.visit_Module(a_s_t_0)


# Generated at 2022-06-25 22:18:49.424870
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = None
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_0 = None
    python2_future_transformer_0.visit_Module(module_0)
    return None


# Generated at 2022-06-25 22:19:02.409134
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    str_0 = "'D]p}f8L\\cH*ug%$H07 "
    dict_0 = {str_0: str_0}
    module_x_var_0 = module_0.Module(**dict_0)
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    func_0 = module_x_var_1.body[0].func.value
    assert (isinstance(func_0, module_0.Name))
    str_1 = "'D]p}f8L\\cH*ug%$H07 "

# Generated at 2022-06-25 22:19:08.535543
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    str_0 = "'D]p}f8L\\cH*ug%$H07 "
    dict_0 = {str_0: str_0}
    module_x_var_0 = module_0.Module(**dict_0)
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)

# Generated at 2022-06-25 22:19:10.446724
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    test_case_0()

# ++++++++++------------------------------------------+
import typed_ast._ast3 as module_0


# Generated at 2022-06-25 22:19:17.501870
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    def test_Python2FutureTransformer_0():
        # Nothing to assert
        # test_case_0
        str_0 = "'D]p}f8L\\cH*ug%$H07 "
        dict_0 = {str_0: str_0}
        module_x_var_0 = module_0.Module(**dict_0)
        a_s_t_0 = module_0.AST()
        python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
        module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)


# Generated at 2022-06-25 22:19:20.390717
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    args_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(args_0)
    module_x_var_0 = python2_future_transformer_0.target


# Generated at 2022-06-25 22:19:28.183475
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    str_0 = "'D]p}f8L\\cH*ug%$H07 "
    dict_0 = {str_0: str_0}
    module_x_var_0 = module_0.Module(**dict_0)
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    python2_future_transformer_0.generic_visit(module_x_var_1)

# Generated at 2022-06-25 22:19:34.383724
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    str_0 = "'D]p}f8L\\cH*ug%$H07 "
    dict_0 = {str_0: str_0}
    module_x_var_0 = module_0.Module(**dict_0)
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:19:43.046607
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    str_0 = "Z~U{%cUW-6_B:6>/a2["
    dict_0 = {str_0: str_0}
    module_x_var_0 = module_0.Module(**dict_0)
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    str_1 = "JsQ}n!^_#TlR+B%T)^2z"
    dict_1 = {str_1: module_x_var_1}

# Generated at 2022-06-25 22:19:44.009579
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    test_case_0()

# Generated at 2022-06-25 22:19:52.292890
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    str_0 = "'D]p}f8L\\cH*ug%$H07 "
    dict_0 = {str_0: str_0}
    module_x_var_0 = module_0.Module(**dict_0)
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    python2_future_transformer_0.visit_Module(module_x_var_0)

if __name__ == '__main__':
    test_Python2FutureTransformer()
    test_case_0()

# Generated at 2022-06-25 22:19:57.886473
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert True

if __name__ == '__main__':
    test_case_0()

    test_Python2FutureTransformer()

# Generated at 2022-06-25 22:20:02.932932
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    str_0 = "m}"
    dict_0 = {str_0: str_0}
    module_x_var_0 = module_0.Module(**dict_0)
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)


# Generated at 2022-06-25 22:20:07.562944
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    try:
        test_case_0()
    except SystemExit:
        pass
    except AttributeError:
        pass
    except ValueError:
        pass
    except TypeError:
        pass
    else:
        raise Exception('Expected one of Exception')

if __name__ == '__main__':
    test_Python2FutureTransformer_visit_Module()

# Generated at 2022-06-25 22:20:14.719551
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    str_0 = "'D]p}f8L\\cH*ug%$H07 "
    dict_0 = {str_0: str_0}
    module_x_var_0 = module_0.Module(**dict_0)
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    python2_future_transformer_0.visit_Module(module_x_var_0)


# Generated at 2022-06-25 22:20:16.728796
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    print("Start: Constructor test for Python2FutureTransformer")
    print("End: Constructor test for Python2FutureTransformer")

# Generated at 2022-06-25 22:20:19.877262
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source_code import SourceCode


# Generated at 2022-06-25 22:20:24.677485
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    str_0 = 'lW5q5f-LQ@}b{0'
    dict_0 = {str_0: str_0}
    module_x_var_0 = module_0.Module(**dict_0)
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:20:25.844907
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    test_case_0()


# Generated at 2022-06-25 22:20:31.852483
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    str_0 = "'D]p}f8L\\cH*ug%$H07 "
    dict_0 = {str_0: str_0}
    module_x_var_0 = module_0.Module(**dict_0)
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:20:34.114217
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    try:
        test_case_0()
    except:
        raise Exception('Exception raised in function test_Python2FutureTransformer_visit_Module')


# Generated at 2022-06-25 22:20:42.825932
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    assert Python2FutureTransformer.visit_Module(module_x_var_0) == module_x_var_1

# Generated at 2022-06-25 22:20:45.654593
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    assert python2_future_transformer_0


# Generated at 2022-06-25 22:20:49.516989
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast.ast3 import Module
    from typed_ast.ast3 import AST
    from future_cleaner.transforms.python2_future_transformer import Python2FutureTransformer
    module_x_var_0 = Module(body=[])
    a_s_t_0 = AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)

# Generated at 2022-06-25 22:20:50.933732
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    test_case_0()

# Generated at 2022-06-25 22:20:52.815844
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass # TODO: implement your test here


# Generated at 2022-06-25 22:20:54.472165
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    test_case_0()

# Generated at 2022-06-25 22:20:59.953042
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    assert 'transformer' == python2_future_transformer_0.transformer
    assert '_tree_changed' == python2_future_transformer_0._tree_changed
    assert 'visit_Module' == python2_future_transformer_0.visit_Module


# Generated at 2022-06-25 22:21:05.416336
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    str_0 = "'D]p}f8L\\cH*ug%$H07 "
    dict_0 = {str_0: str_0}
    module_x_var_0 = module_0.Module(**dict_0)
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)


# Generated at 2022-06-25 22:21:15.897788
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    str_0 = "qj5]7V'IyEu0F^gx}=jKH"
    dict_0 = {str_0: str_0}
    module_x_var_0 = module_0.Module(**dict_0)
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)


# Generated at 2022-06-25 22:21:20.168420
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = ast.Module()
    a_s_t_0 = ast.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:21:35.738260
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    try:
        test_case_0()
    except Exception as inst:
        print(inst)
        assert False

# Generated at 2022-06-25 22:21:37.812498
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    for i in range(10):
        test_case_0()

if __name__ == '__main__':
    test_Python2FutureTransformer()

# Generated at 2022-06-25 22:21:38.944573
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    method_0 = test_case_0
    method_0()

# Generated at 2022-06-25 22:21:41.509796
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    print('test_Python2FutureTransformer_visit_Module')
    test_case_0()
    test_case_1()
    print('Test case for Python2FutureTransformer.visit_Module executed')


# Generated at 2022-06-25 22:21:47.130080
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Test with Input Type
    str_0 = "9yc%*"
    dict_0 = {str_0: str_0}
    module_x_var_0 = module_0.Module(**dict_0)
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)


# Generated at 2022-06-25 22:21:51.191528
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.snippet import snippet

    @snippet
    def before(future):
        pass
    @snippet
    def after(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    transpile(before.get_ast(), Python2FutureTransformer) == after.get_ast()

# Generated at 2022-06-25 22:21:57.509255
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    str_0 = "'D]p}f8L\\cH*ug%$H07 "
    dict_0 = {str_0: str_0}
    module_x_var_0 = module_0.Module(**dict_0)
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    print(module_x_var_1)

# Generated at 2022-06-25 22:22:04.993417
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    backingField_str_0 = "\\b_2Z-LX^H>}j%"
    backingField_dict_0 = {backingField_str_0: backingField_str_0}
    module_x_var_0 = module_0.Module(**backingField_dict_0)
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:22:05.779740
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    test_case_0()

# Generated at 2022-06-25 22:22:11.548337
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():

    str_0 = "'D]p}f8L\\cH*ug%$H07 "
    dict_0 = {str_0: str_0}
    module_x_var_0 = module_0.Module(**dict_0)
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:22:44.849090
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    str_0 = 'aN'
    dict_0 = {str_0: str_0}
    module_x_var_0 = module_0.Module(**dict_0)
    python2_future_transformer_1 = Python2FutureTransformer(module_0.AST())
    python2_future_transformer_0 = Python2FutureTransformer(module_0.AST(), module_x_var_0)


# Generated at 2022-06-25 22:22:45.883938
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    test_case_0()

# Generated at 2022-06-25 22:22:46.969000
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_x_var_0 = Python2FutureTransformer()


# Generated at 2022-06-25 22:22:47.720750
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert True

# Generated at 2022-06-25 22:22:48.890970
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    node = ast.Module()
    Python2FutureTransformer(node)
    assert True

# Generated at 2022-06-25 22:22:54.347848
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    str_0 = "'D]p}f8L\\cH*ug%$H07 "
    dict_0 = {str_0: str_0}
    module_x_var_0 = module_0.Module(**dict_0)
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:22:56.327247
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    variables = []
    test_case_0()
    assert variables == [], "Expected variables to be #{}, but got #{}".format([], variables)
    return True

# Generated at 2022-06-25 22:22:57.716794
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    print('test_Python2FutureTransformer_visit_Module')
    test_case_0()

# Generated at 2022-06-25 22:23:07.179060
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """
    Test for __init__(self, tree: ast.AST)
    """
    python2_future_transformer_0 = Python2FutureTransformer(module_0.AST())
    assert hasattr(python2_future_transformer_0, 'visit_Module')
    assert hasattr(python2_future_transformer_0, 'visit_FunctionDef')
    assert hasattr(python2_future_transformer_0, 'visit_AsyncFunctionDef')
    assert hasattr(python2_future_transformer_0, 'visit_ClassDef')
    assert hasattr(python2_future_transformer_0, 'visit_Return')
    assert hasattr(python2_future_transformer_0, 'visit_Delete')

# Generated at 2022-06-25 22:23:08.146058
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    test_case_0()

# Generated at 2022-06-25 22:24:16.944357
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    str_0 = "'D]p}f8L\\cH*ug%$H07 "
    dict_0 = {str_0: str_0}
    module_x_var_2 = module_0.Module(**dict_0)
    a_s_t_0 = module_0.AST()
    python2_future_transformer_1 = Python2FutureTransformer(a_s_t_0)
    module_x_var_3 = python2_future_transformer_1.visit_Module(module_x_var_2)

# Generated at 2022-06-25 22:24:23.773989
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    str_0 = "'D]p}f8L\\cH*ug%$H07 "
    dict_0 = {str_0: str_0}
    module_x_var_0 = module_0.Module(**dict_0)
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    assert module_x_var_1.body == module_x_var_0.body

# Generated at 2022-06-25 22:24:26.575998
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    a_s_t_0 = ast.AST()
    #test_Python2FutureTransformer()
    #test_case_0()


# Generated at 2022-06-25 22:24:34.863139
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    str_0 = "'_yhA1wD~W:@[!l(p1+x"
    dict_0 = {str_0: str_0}
    module_x_var_0 = module_0.Module(**dict_0)
    str_1 = "}\'{3F^:2zc%"
    dict_1 = {str_1: str_1}
    module_x_var_1 = module_0.Module(**dict_1)
    assert module_x_var_1.__dict__ == python2_future_transformer_0.visit_Module(module_x_var_0).__dict__

# Generated at 2022-06-25 22:24:41.650415
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    str_0 = "'D]p}f8L\\cH*ug%$H07 "
    dict_0 = {str_0: str_0}
    module_x_var_0 = module_0.Module(**dict_0)
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    str_1 = 'Python2FutureTransformer'
    str_2 = type(python2_future_transformer_0).__name__
    assert (str_1 == str_2)

# Generated at 2022-06-25 22:24:46.295304
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    str_0 = "'D]p}f8L\\cH*ug%$H07 "
    dict_0 = {str_0: str_0}
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    python2_future_transformer_1 = Python2FutureTransformer(a_s_t_0)


# Generated at 2022-06-25 22:24:48.915432
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    assert isinstance(python2_future_transformer_0, Python2FutureTransformer)


# Generated at 2022-06-25 22:24:57.083986
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    str_0 = "module"
    module_0 = __import__(str_0)
    str_1 = "visit_Module"
    str_2 = "future"
    str_3 = "__future__"
    method_0 = getattr(module_0, str_1)
    method_1 = getattr(method_0, str_2)
    module_1 = getattr(method_1, str_3)
    str_4 = "absolute_import"
    str_5 = "division"
    str_6 = "print_function"
    str_7 = "unicode_literals"
    str_8 = "absolute_import"
    str_9 = "division"
    str_10 = "print_function"
    str_11 = "unicode_literals"
    int_x_

# Generated at 2022-06-25 22:24:59.309387
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .test_files.test_Python2FutureTransformer import test_case_0
    test_case_0()


# Generated at 2022-06-25 22:25:06.232395
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    str_0 = "'D]p}f8L\\cH*ug%$H07 "
    dict_0 = {str_0: str_0}
    module_x_var_0 = module_0.Module(**dict_0)
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)


str_0 = 'import typed_ast._ast3 as module_0'
str_1 = 'module_0 = module_0'
str_2 = '_ = module_0'
str_3 = 'a = module_0.AST()'

# Generated at 2022-06-25 22:27:48.697291
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    test_case_0()


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 22:27:54.361625
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    str_0 = "'D]p}f8L\\cH*ug%$H07 "
    dict_0 = {str_0: str_0}
    module_x_var_0 = module_0.Module(**dict_0)
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    pass


# Generated at 2022-06-25 22:28:00.849315
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    str_0 = "'D]p}f8L\\cH*ug%$H07 "
    dict_0 = {str_0: str_0}
    module_0_var_0 = module_0.Module(**dict_0)
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    python2_future_transformer_0.generic_visit(module_0_var_0)
    python2_future_transformer_0.visit(module_0_var_0)


# Generated at 2022-06-25 22:28:07.873210
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    str_0 = "'D]p}f8L\\cH*ug%$H07 "
    dict_0 = {str_0: str_0}
    module_x_var_0 = module_0.Module(**dict_0)
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    python2_future_transformer_1 = Python2FutureTransformer()
    module_x_var_2 = python2_future_transformer_1.visit_Module(module_x_var_0)
    python2_future_transformer_2 = Python2