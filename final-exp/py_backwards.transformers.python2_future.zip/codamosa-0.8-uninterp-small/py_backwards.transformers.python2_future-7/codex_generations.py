

# Generated at 2022-06-25 22:18:09.636983
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_0.AST()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    python2_future_transformer_1 = Python2FutureTransformer(a_s_t_0)
    python2_future_transformer_0.generic_visit(a_s_t_0)
    python2_future_transformer_1.target = (2, 7)
    return


# Generated at 2022-06-25 22:18:15.670107
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)

# Generated at 2022-06-25 22:18:20.213519
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)

    a_s_t_0.Module = module_0.Module
    python2_future_transformer_0.visit_Module()


# Generated at 2022-06-25 22:18:23.582688
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    assert isinstance(python2_future_transformer_0.tree, module_0.AST)


# Generated at 2022-06-25 22:18:28.012343
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from future import absolute_import
    from future import division
    from future import print_function
    from future import unicode_literals

    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)



# Generated at 2022-06-25 22:18:30.994690
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)



# Generated at 2022-06-25 22:18:34.014519
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # Python2 future transformer has no constructor, so raise error
    with pytest.raises(TypeError):
        Python2FutureTransformer()

if __name__ == '__main__':
    pytest.main([__file__])

# Generated at 2022-06-25 22:18:40.932236
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    a_s_t_1 = module_0.AST()
    module_0_0 = python2_future_transformer_0.visit(a_s_t_1)
    assert isinstance(module_0_0, module_0.Module)
    pass

# Generated at 2022-06-25 22:18:44.243408
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    pass



# Generated at 2022-06-25 22:18:46.378626
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)


# Generated at 2022-06-25 22:19:01.770812
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    python2_future_transformer_0 = Python2FutureTransformer()

    source = """
        from __future__ import absolute_import                                                                                           
        from __future__ import division                                                                                           
        from __future__ import print_function                                                                                           
        from __future__ import unicode_literals                                                                                           

        def f(): # pass comment
            pass        
    """

# Generated at 2022-06-25 22:19:05.937776
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Arrange
    python2_future_transformer_0 = Python2FutureTransformer()
    node = ast.Module()
    # Act
    python2_future_transformer_0.visit_Module(node)

# Generated at 2022-06-25 22:19:07.154431
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer


# Generated at 2022-06-25 22:19:15.821967
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import ast
    import os
    import sys

    real_import = __import__  # type: Callable

    def mock_import(name: str, globals: Optional[Dict] = None, locals: Optional[Dict] = None,  # type: ignore
                    fromlist: Optional[List] = None, level: int = 0) -> ast:
        if name in ('future.utils',):
            if os.path.basename(__file__) not in sys.path:
                sys.path.insert(0, os.path.dirname(__file__))
            module = real_import('typed_ast.ast3', globals, locals, fromlist, level)
        else:
            module = real_import(name, globals, locals, fromlist, level)
        return module



# Generated at 2022-06-25 22:19:20.215157
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    snippet_0 = snippet()
    snippet_0.result = 0
    python2_future_transformer_0 = Python2FutureTransformer()
    assert isinstance(python2_future_transformer_0, Python2FutureTransformer)
    assert isinstance(python2_future_transformer_0, BaseNodeTransformer)


# Generated at 2022-06-25 22:19:25.874859
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    python2_future_transformer_1 = Python2FutureTransformer()
    x: Module = Module(body=[])
    y = python2_future_transformer_1.visit_Module(x)
    assert isinstance(y, Module) == True
    assert y.body[0].value.args[0].s == '__future__'


if __name__ == '__main__':
    test_case_0()
    test_Python2FutureTransformer_visit_Module()

# Generated at 2022-06-25 22:19:29.116765
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    tree = ast.parse('a = 1')
    python2_future_transformer_0 = Python2FutureTransformer()


if __name__ == '__main__':
    import pytest
    pytest.main(['test_python2_future_transformer.py'])

# Generated at 2022-06-25 22:19:29.925494
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass # No constructor exists


# Generated at 2022-06-25 22:19:32.037505
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    global python2_future_transformer_0
    python2_future_transformer_0 = Python2FutureTransformer()


# Generated at 2022-06-25 22:19:34.381553
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    try:
        python2_future_transformer_0 = Python2FutureTransformer()
        assert python2_future_transformer_0 is not None
    except:
        assert False

# Generated at 2022-06-25 22:19:38.333281
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    test_case_0()
    
    


if __name__ == '__main__':
    import unittest
    unittest.main()

# Generated at 2022-06-25 22:19:41.649020
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_x_var_1 = 4
    module_x_var_0 = Python2FutureTransformer(module_x_var_1)
    expected_0 = module_x_var_1
    actual_0 = module_x_var_0.ast
    assert actual_0 == expected_0


# Generated at 2022-06-25 22:19:46.189377
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:19:51.164141
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:19:53.691966
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_x_var_0 = None
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()


# Generated at 2022-06-25 22:19:58.000274
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_1 = None
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_1)



# Generated at 2022-06-25 22:20:00.059962
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_2 = module_0.AST()
    python2_future_transformer_1 = Python2FutureTransformer(a_s_t_2)

# Generated at 2022-06-25 22:20:00.904998
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert True


# Generated at 2022-06-25 22:20:01.682672
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert True


# Generated at 2022-06-25 22:20:05.230649
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # Test for constructor
    '''
    test_obj_0 = Python2FutureTransformer(a_s_t_0)
    assert isinstance(test_obj_0, Python2FutureTransformer)
    '''
    # Test for constructor
    '''
    test_obj_3 = Python2FutureTransformer(None)
    assert isinstance(test_obj_3, Python2FutureTransformer)
    '''



# Generated at 2022-06-25 22:20:18.928901
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.mock_tree import mock_tree
    from ...utils.python import Source
    
    # Check that the transformer doesn't do anything for python 3.
    py_src = Source("def func():\n    pass")
    mock_tree_1 = mock_tree(py_src, version=(3, 6))
    python2_future_transformer_0 = Python2FutureTransformer(mock_tree_1)
    python2_future_transformer_0.visit(mock_tree_1)
    # TODO: Check that the tree hasn't changed
    
    # Check that the transformer doesn't do anything for python 2.7
    py_src = Source("def func():\n    pass")
    mock_tree_1 = mock_tree(py_src, version=(2, 7))
    python2_future

# Generated at 2022-06-25 22:20:21.021582
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:20:23.969001
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    assert isinstance(python2_future_transformer_0, Python2FutureTransformer)
    assert python2_future_transformer_0._tree_changed == False


# Generated at 2022-06-25 22:20:29.032372
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_2 = None
    a_s_t_1 = module_0.AST()
    python2_future_transformer_1 = Python2FutureTransformer(a_s_t_1)
    module_x_var_3 = python2_future_transformer_1.visit_Module(module_x_var_2)
    assert module_x_var_3 == None


import typed_ast._ast3 as module_1


# Generated at 2022-06-25 22:20:29.971036
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass


# Generated at 2022-06-25 22:20:33.094761
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)


# Generated at 2022-06-25 22:20:36.986780
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:20:40.996311
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    try:
        # TODO: write the unit test
        assert True == False
    except AssertionError as e:
        print(str(e))
        print("TEST test_Python2FutureTransformer FAILED")
        assert(False)


# Generated at 2022-06-25 22:20:41.598744
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    assert True

# Generated at 2022-06-25 22:20:46.468569
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

test_case_0()


test_Python2FutureTransformer_visit_Module()

# Generated at 2022-06-25 22:20:57.865080
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:21:01.103679
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import typed_ast._ast3 as module_0
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)


# Generated at 2022-06-25 22:21:03.438945
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)

# Generated at 2022-06-25 22:21:11.797607
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import nbformat
    from nbconvert.preprocessors import ExecutePreprocessor
    # create preprocessor
    ep = ExecutePreformer()
    # preprocess cell
    ep.preprocess(nb, {"metadata": {"path": "."}})


# Generated at 2022-06-25 22:21:12.970151
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-25 22:21:21.394162
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # these are not really needed in this case but just in case,
    # we would want to add a test for some additional attributes
    module_x_var_2 = None
    # test for code
    module_x_var_3 = None
    # test for future
    module_x_var_4 = None
    a_s_t_1 = module_0.AST(module_x_var_3, module_x_var_4)
    python2_future_transformer_1 = Python2FutureTransformer(a_s_t_1)
    # test for _get_code
    module_x_var_5 = python2_future_transformer_1.get_code()
    # test for _get_future
    module_x_var_6 = python2_future_transformer_1.get_future()


# Generated at 2022-06-25 22:21:27.121275
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:21:30.633505
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)


# Generated at 2022-06-25 22:21:39.340119
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # No code in module.
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

    # No code in module.
    import_0 = module_0.Import(
        names=[
            module_0.alias(
                name='typed_ast',
                asname=None,
            )
        ]
    )
    module_x_var_0 = module_0.Module(
        body=[import_0],
    )
    a_s_t_0 = module_0.AST()
    python2_future

# Generated at 2022-06-25 22:21:42.498085
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    pass
    # TODO -- implement test case for method Python2FutureTransformer.visit_Module
    # assert python2_future_transformer_0.visit_Module() # <== add real assertion here

# vim: set ts=4 sw=4 tw=0 et :

# Generated at 2022-06-25 22:22:02.839184
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    assert True

if __name__ == "__main__":
    test_case_0()
    test_Python2FutureTransformer_visit_Module()

# Generated at 2022-06-25 22:22:11.143962
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    assert module_x_var_1 is not None
    assert module_x_var_1.body[0].names[0].name == 'absolute_import'
    assert module_x_var_1.body[1].names[0].name == 'division'
    assert module_x_var_1.body[2].names[0].name == 'print_function'

# Generated at 2022-06-25 22:22:12.249251
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.target == (2, 7)



# Generated at 2022-06-25 22:22:16.747856
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:22:22.668909
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    assert module_x_var_0 == python2_future_transformer_0.ast
    assert module_x_var_0 == python2_future_transformer_0.orig_tree
    assert module_x_var_0 == python2_future_transformer_0.tree

from .test_cases.test_python2_future import *

# Generated at 2022-06-25 22:22:24.252297
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = None
    assert test_case_0() == module_x_var_0


# Generated at 2022-06-25 22:22:28.982409
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
import typed_ast._ast3 as module_0


# Generated at 2022-06-25 22:22:30.148891
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    test_case_0()

# Generated at 2022-06-25 22:22:35.799718
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    import typed_ast.ast3 as module_1
    module_x_var_2 = module_1.Module()
    module_x_var_3 = python2_future_transformer_0.visit_Module(module_x_var_2)
    module_x_var_4 = python2_future_transformer_0.target


# Generated at 2022-06-25 22:22:39.577852
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = None

    a_s_t_0 = module_0.AST()

    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)

    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:23:09.261413
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass

# Generated at 2022-06-25 22:23:12.168118
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)


# Generated at 2022-06-25 22:23:18.494932
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    
    # Test for a line in the method visit_Module
    assert python2_future_transformer_0._tree_changed == True
    # Test for a line in the method visit_Module
    assert module_x_var_1 is None


# Generated at 2022-06-25 22:23:22.373095
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:23:23.151394
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert True == True


# Generated at 2022-06-25 22:23:26.514444
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_x_var_0 = None
    module_x_var_1 = Python2FutureTransformer(module_x_var_0)


# Generated at 2022-06-25 22:23:30.352999
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)


# Generated at 2022-06-25 22:23:35.955218
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    python2_future_transformer_1 = Python2FutureTransformer.__new__(Python2FutureTransformer, a_s_t_0)
    python2_future_transformer_2 = Python2FutureTransformer.__init__(python2_future_transformer_1, a_s_t_0)


# Generated at 2022-06-25 22:23:40.109537
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

import typed_ast.ast3 as module_0


# Generated at 2022-06-25 22:23:42.504630
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # TODO: This line is needed to pass the test
    module_0 = __import__('typed_ast._ast3', {}, {}, [], 0)
    test_case_0()

# Generated at 2022-06-25 22:24:51.364464
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert True


# Generated at 2022-06-25 22:24:55.172697
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Test case with Python2FutureTransformer.visit_Module()
    module_x_var_1 = None
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_2 = python2_future_transformer_0.visit_Module(module_x_var_1)

# Generated at 2022-06-25 22:24:58.868069
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)


# Generated at 2022-06-25 22:25:00.511423
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)


# Generated at 2022-06-25 22:25:01.725760
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_0.AST()
    Python2FutureTransformer(module_0.AST())



# Generated at 2022-06-25 22:25:03.898190
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0_var = module_0.AST()
    python2_future_transformer_0_var = Python2FutureTransformer(a_s_t_0_var)


# Generated at 2022-06-25 22:25:06.231553
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_x_var_2 = None
    a_s_t_1 = module_0.AST()
    python2_future_transformer_1 = Python2FutureTransformer(a_s_t_1)


# Generated at 2022-06-25 22:25:09.620768
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:25:13.369133
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_0 = None
    python2_future_transformer_0 = Python2FutureTransformer(module_0)
    python2_future_transformer_0.visit_Module(module_0)
    python2_future_transformer_0.generic_visit(module_0)


if __name__ == '__main__':
    test_case_0()
    test_Python2FutureTransformer()

# Generated at 2022-06-25 22:25:16.913744
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:27:59.955161
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = None
    a_s_t_1 = module_0.AST()
    python2_future_transformer_1 = Python2FutureTransformer(a_s_t_1)
    module_x_var_1 = python2_future_transformer_1.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:28:00.665875
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    test_case_0()

# Generated at 2022-06-25 22:28:03.036860
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_x_var_0 = None
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
