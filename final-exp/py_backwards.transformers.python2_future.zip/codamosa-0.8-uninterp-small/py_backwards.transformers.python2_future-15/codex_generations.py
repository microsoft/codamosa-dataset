

# Generated at 2022-06-25 22:18:12.105792
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Prepare
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    
    # Run
    result = python2_future_transformer_0.visit_Module(module_0.Module())

    # Verify
    assert result is not None
    assert True # TODO: add more assertions

# Generated at 2022-06-25 22:18:20.764963
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    a_s_t_1 = module_0.Module([])
    # Access attribute _tree_changed of class Python2FutureTransformer
    assert python2_future_transformer_0._tree_changed == False
    python2_future_transformer_0.visit_Module(a_s_t_1)
    # Access attribute _tree_changed of class Python2FutureTransformer
    assert python2_future_transformer_0._tree_changed == True

# Generated at 2022-06-25 22:18:29.847746
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    node = module_0.Module()
    result = python2_future_transformer_0.visit_Module(node)

# Generated at 2022-06-25 22:18:35.217187
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)

    # Testing no docstring case
    module_1 = module_0.Module(body=[])
    try:
        transformed_tree_0 = python2_future_transformer_0.visit_Module(module_1)
        assert False
    except NotImplementedError:
        assert True


# Generated at 2022-06-25 22:18:42.471691
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_1 = a_s_t_0.Module()
    module_1.body = [a_s_t_0.Expr(value=a_s_t_0.Str(s='py2'))]
    python2_future_transformer_0.visit_Module(module_1)

# Generated at 2022-06-25 22:18:51.511760
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_0.Module
    module_0.Assign
    module_0.Compare
    module_0.Expr
    module_0.Str
    module_0.BinOp
    module_0.Assign
    module_0.Expr
    module_0.Str
    module_0.Expr
    module_0.BoolOp
    module_0.Module
    module_0.Assign
    module_0.Compare
    module_0.Expr
    module_0.Str
    module_0.BinOp
    module_0.Assign
    module_0.Expr
    module_0.Str
    module

# Generated at 2022-06-25 22:18:56.806681
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    source_code_0 = """""a"""
    source_code_1 = """""a""".encode()
    source_code_2 = """""a""".encode(encoding='UTF-8')
    source_code_3 = """""a""".encode(encoding='UTF-8', errors='strict')
    source_code_4 = """""a""".encode(encoding='UTF-8', errors='replace')
    source_code_5 = """""a""".encode(encoding='UTF-8', errors='xmlcharrefreplace')

# Generated at 2022-06-25 22:19:01.652649
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():

    print('\n**********************************************************')
    print('Testing: Python2FutureTransformer.visit_Module')
    print('**********************************************************')

    # Test case 0:
    print('\n\nTest case 0: ')
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)

# Generated at 2022-06-25 22:19:07.155307
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    a_s_t_2 = module_0.Module()
    python2_future_transformer_0.visit_Module(a_s_t_2)

# Generated at 2022-06-25 22:19:09.361984
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    method_0 = Python2FutureTransformer.visit_Module

    method_0(Python2FutureTransformer(module_0.AST()), module_0.Module())


# Generated at 2022-06-25 22:19:17.732648
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    print("Test method visit_Module of Python2FutureTransformer")
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    a_s_t_0 = module_0.Module(body=[])
    python2_future_transformer_0.visit_Module(a_s_t_0)

# Generated at 2022-06-25 22:19:20.395901
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    test_case_0()


# Generated at 2022-06-25 22:19:29.427330
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_1 = module_0.AST()
    python2_future_transformer_1 = Python2FutureTransformer(a_s_t_1)
    module_1 = module_0.Module()
    module_1.body = [module_0.FunctionDef(name='f', body=[module_0.Return(value=module_0.Str(s=''))])]
    module_2 = python2_future_transformer_1.visit_Module(module_1)
    assert type(module_2) == module_0.Module
    assert len(module_2.body) == 5

# Generated at 2022-06-25 22:19:35.195301
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_0_0 = a_s_t_0.Module(body=[])
    result = python2_future_transformer_0.visit_Module(module_0_0)
    assert result is not None
    assert python2_future_transformer_0._tree_changed == True

# Generated at 2022-06-25 22:19:43.848320
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.snippet import snippet
    import sys
    import ast

    @snippet
    def f(a):
        pass
    
    @snippet
    def f(b):
        pass
    
    @snippet
    def f(c):
        pass
    
    t = ast.parse(f)
    Python2FutureTransformer(t).visit(t)
    print(ast.dump(t))

# Generated at 2022-06-25 22:19:48.051521
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)

if __name__ == "__main__":
    test_case_0()
    test_Python2FutureTransformer()

# Generated at 2022-06-25 22:19:51.163854
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)

# Generated at 2022-06-25 22:19:55.915736
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # Call constructor
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)

    # Call method visit_Module on object python2_future_transformer_0 with arguments: None

# Generated at 2022-06-25 22:20:03.838121
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    python2_future_transformer_0 = Python2FutureTransformer(module_0.AST())
    python2_future_transformer_1 = Python2FutureTransformer(inherit=base_0.BaseNodeTransformer(module_0.AST()))
    python2_future_transformer_2 = Python2FutureTransformer(module_0.AST(), inherit=base_0.BaseNodeTransformer(module_0.AST()))
    python2_future_transformer_3 = Python2FutureTransformer(module_0.AST(), (1, 0), inherit=base_0.BaseNodeTransformer(module_0.AST()))
    python2_future_transformer_4 = Python2FutureTransformer(module_0.AST(), (1, 0))

# Generated at 2022-06-25 22:20:06.724880
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)

# Generated at 2022-06-25 22:20:19.990076
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_0_0 = module_0.Module([], lineno=0, col_offset=0)
    module_0_0_1 = python2_future_transformer_0.visit_Module(module_0_0)

# Generated at 2022-06-25 22:20:20.782209
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer(): assert True == True


# Generated at 2022-06-25 22:20:23.473620
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    assert isinstance(python2_future_transformer_0, Python2FutureTransformer)

# Generated at 2022-06-25 22:20:25.520909
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)


# Generated at 2022-06-25 22:20:30.981639
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    a_s_t_2 = module_0.Module(body=[])
    a_s_t_3 = python2_future_transformer_0.visit_Module(a_s_t_2)
    assert not a_s_t_3.body
    assert python2_future_transformer_0._tree_changed

# Generated at 2022-06-25 22:20:33.401885
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_1 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_1)

# Generated at 2022-06-25 22:20:42.254275
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_1 = module_0.Module([]) # type: Module
    module_2 = python2_future_transformer_0.visit_Module(module_1) # type: Module
    a_s_t_1 = module_0.AST()
    python2_future_transformer_1 = Python2FutureTransformer(a_s_t_1)
    module_3 = module_0.Module([]) # type: Module
    module_4 = python2_future_transformer_1.visit_Module(module_3) # type: Module

# Generated at 2022-06-25 22:20:44.627831
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)

# Generated at 2022-06-25 22:20:46.025709
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)

# Generated at 2022-06-25 22:20:52.081042
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_1 = module_0.Module(["pass"])
    module_1 = Python2FutureTransformer(2.7).visit_Module(module_1)
    assert module_1 == module_0.Module(
        [
            module_0.ImportFrom(
                "__future__",
                [
                    module_0.alias(
                        "absolute_import",
                        None,
                    ),
                    module_0.alias(
                        "division",
                        None,
                    ),
                    module_0.alias(
                        "print_function",
                        None,
                    ),
                    module_0.alias(
                        "unicode_literals",
                        None,
                    ),
                ],
                0,
            ),
            module_0.Pass(),
        ],
    )


# Generated at 2022-06-25 22:21:02.564158
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)


# Generated at 2022-06-25 22:21:11.770510
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_0 = module_0.Module()
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    list_0 = [python2_future_transformer_0, python2_future_transformer_0]
    python2_future_transformer_1 = Python2FutureTransformer(a_s_t_0)
    a_s_t_1 = module_0.AST(*list_0)
    python2_future_transformer_2 = Python2FutureTransformer(a_s_t_1)

# Generated at 2022-06-25 22:21:13.259453
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    print("Test visit_Module")
    test_case_0()


# Generated at 2022-06-25 22:21:21.541167
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import typed_ast.ast3 as ast
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer


    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals


    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body

# Generated at 2022-06-25 22:21:27.589449
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_0 = module_0.Module()
    python2_future_transformer_0.visit_Module(module_x_var_0)



# Generated at 2022-06-25 22:21:36.872314
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    python2_future_transformer_1 = Python2FutureTransformer(a_s_t_0)
    python2_future_transformer_2 = Python2FutureTransformer(a_s_t_0)
    python2_future_transformer_3 = Python2FutureTransformer(a_s_t_0)
    module_x_var_0 = module_0.Module()
    module_x_var_1 = python2_future_transformer_1.visit_Module(module_x_var_0)
    list_0 = [python2_future_transformer_2, python2_future_transformer_3]
    a_

# Generated at 2022-06-25 22:21:45.304405
# Unit test for constructor of class Python2FutureTransformer

# Generated at 2022-06-25 22:21:46.525144
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)


# Generated at 2022-06-25 22:21:48.754444
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_0 = module_0.Module()
    python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:21:49.533407
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert True == True

# Generated at 2022-06-25 22:22:14.833283
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_0 = module_0.Module()
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    list_0 = [python2_future_transformer_0, python2_future_transformer_0]
    python2_future_transformer_1 = Python2FutureTransformer(a_s_t_0)
    a_s_t_1 = module_0.AST(*list_0)
    python2_future_transformer_2 = Python2FutureTransformer(a_s_t_1)

# Generated at 2022-06-25 22:22:22.850168
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_0 = module_0.Module()
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    list_0 = [python2_future_transformer_0, python2_future_transformer_0]
    python2_future_transformer_1 = Python2FutureTransformer(a_s_t_0)
    a_s_t_1 = module_0.AST(*list_0)
    python2_future_transformer_2 = Python2FutureTransformer(a_s_t_1)

# Generated at 2022-06-25 22:22:31.076424
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_0 = module_0.Module()
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    list_0 = [python2_future_transformer_0, python2_future_transformer_0]
    python2_future_transformer_1 = Python2FutureTransformer(a_s_t_0)
    a_s_t_1 = module_0.AST(*list_0)
    python2_future_transformer_2 = Python2FutureTransformer(a_s_t_1)

# Generated at 2022-06-25 22:22:31.541000
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    pass

# Generated at 2022-06-25 22:22:39.700970
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_0 = module_0.Module()
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    module_x_var_2 = python2_future_transformer_0.visit_Module(module_x_var_1)
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_3 = module_0.Module()
    module_x_var_4 = python2_future_transformer_

# Generated at 2022-06-25 22:22:47.473170
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    #Assume
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_0 = module_0.Module()
    module_x_var_0.body = []
    #Act
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    list_0 = [True, module_0.Module()]
    #Assert
    assert python2_future_transformer_0._tree_changed == list_0[0]
    assert module_x_var_1 == list_0[1]


# Generated at 2022-06-25 22:22:55.382083
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    a_s_t_1 = module_0.AST()
    python2_future_transformer_1 = Python2FutureTransformer(a_s_t_1)
    python2_future_transformer_1.visit_Module(module_0.Module())
    target_0 = (1, 0)
    python2_future_transformer_0.target = target_0
    python2_future_transformer_1.target = target_0
    target_1 = (2, 0)
    python2_future_transformer_0.target = target_1
    python2_future_transformer_1.target = target_1
    python

# Generated at 2022-06-25 22:23:02.650161
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    python2_future_transformer_1 = Python2FutureTransformer(a_s_t_0)
    python2_future_transformer_2 = Python2FutureTransformer(a_s_t_0)
    assert python2_future_transformer_0._tree_changed == False
    assert python2_future_transformer_1._tree_changed == False
    assert python2_future_transformer_2._tree_changed == False


# Generated at 2022-06-25 22:23:05.137651
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)


# Generated at 2022-06-25 22:23:09.402861
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_0 = module_0.Module()
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:23:52.815223
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    python2_future_transformer_0 = Python2FutureTransformer(module_0.AST())

    # Unit test for visit_Module
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_0 = module_0.Module()
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    list_0 = [python2_future_transformer_0, python2_future_transformer_0]
    python2_future_transformer_1 = Python2FutureTransformer(a_s_t_0)
    a_s_t_1 = module_0.AST(*list_0)
    python

# Generated at 2022-06-25 22:23:59.684800
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_0 = module_0.Module()
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    list_0 = [python2_future_transformer_0, python2_future_transformer_0]
    python2_future_transformer_1 = Python2FutureTransformer(a_s_t_0)
    a_s_t_1 = module_0.AST(*list_0)
    python2_future_transformer_2 = Python2FutureTransformer(a_s_t_1)

# Generated at 2022-06-25 22:24:07.763560
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_0 = module_0.Module()
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    list_0 = [python2_future_transformer_0, python2_future_transformer_0]
    python2_future_transformer_1 = Python2FutureTransformer(a_s_t_0)
    a_s_t_1 = module_0.AST(*list_0)
    python2_future_transformer_2 = Python2FutureTransformer(a_s_t_1)

# Generated at 2022-06-25 22:24:14.256213
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    list_0 = [python2_future_transformer_0, python2_future_transformer_0]
    python2_future_transformer_1 = Python2FutureTransformer(a_s_t_0)
    a_s_t_1 = module_0.AST(*list_0)
    python2_future_transformer_2 = Python2FutureTransformer(a_s_t_1)


# Generated at 2022-06-25 22:24:19.283027
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # __init__
    list_0 = [1, 2]
    a_s_t_0 = module_0.AST(*list_0)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    assert hasattr(python2_future_transformer_0, '_tree_changed')
    assert hasattr(python2_future_transformer_0, 'visit_Module')


# Generated at 2022-06-25 22:24:28.105123
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_0 = module_0.Module()
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    list_0 = [python2_future_transformer_0, python2_future_transformer_0]
    python2_future_transformer_1 = Python2FutureTransformer(a_s_t_0)
    a_s_t_1 = module_0.AST(*list_0)
    python2_future_transformer_2 = Python2FutureTransformer(a_s_t_1)

# Generated at 2022-06-25 22:24:35.997666
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import ast
    from .Python2FutureTransformer import Python2FutureTransformer
    from .Python2FutureTransformer import Python2FutureTransformer

    module = """
    a = 1
    if b:
        c = 1
    print(d)
    d = {'e': 1}
    """
    parsed_ast = ast.parse(module)
    transformer = Python2FutureTransformer(parsed_ast)
    transformer.visit(parsed_ast)
    result = ast.dump(parsed_ast)
    print(result)

# Generated at 2022-06-25 22:24:44.646103
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_0 = module_0.Module()
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    list_0 = [python2_future_transformer_0, python2_future_transformer_0]
    python2_future_transformer_1 = Python2FutureTransformer(a_s_t_0)
    a_s_t_1 = module_0.AST(*list_0)
    python2_future_transformer_2 = Python2FutureTransformer(a_s_t_1)

# Generated at 2022-06-25 22:24:52.175917
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_0 = module_0.Module()
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    list_0 = [python2_future_transformer_0, python2_future_transformer_0]
    python2_future_transformer_1 = Python2FutureTransformer(a_s_t_0)
    a_s_t_1 = module_0.AST(*list_0)
    python2_future_transformer_2 = Python2FutureTransformer(a_s_t_1)

# Generated at 2022-06-25 22:25:00.408715
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import typed_ast
    import textwrap
    from typed_ast.ast3 import parse
    from ..utils.case import CaseAST
    from ..utils.case import CaseNodeTransformer

    CaseNodeTransformer.register(Python2FutureTransformer)

    cases = [
        CaseAST(
            textwrap.dedent(
                '''
                x = 3
                y = 4
                '''
            ),
            Python2FutureTransformer,
            textwrap.dedent(
                '''
                from __future__ import absolute_import
                from __future__ import division
                from __future__ import print_function
                from __future__ import unicode_literals

                x = 3
                y = 4
                '''
            ),
            parse=parse,
        ),
    ]


# Generated at 2022-06-25 22:26:36.546641
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_0 = module_0.Module()
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    a_s_t_1 = module_0.AST()
    python2_future_transformer_1 = Python2FutureTransformer(a_s_t_1)
    module_x_var_2 = python2_future_transformer_1.visit_Module(module_x_var_1)
    expected_x_var_0 = module_0.Module()
    assert module_x_var_2 == expected_x_var_0

# Generated at 2022-06-25 22:26:37.324304
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    test_case_0()

# Generated at 2022-06-25 22:26:45.006676
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Setup
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_0 = module_0.Module()
    # Exercise
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    # Verify
    assert type(module_x_var_1) == module_0.Module
    # Cleanup
    list_0 = [python2_future_transformer_0, python2_future_transformer_0]
    python2_future_transformer_1 = Python2FutureTransformer(a_s_t_0)
    a_s_t_1 = module_0.AST(*list_0)

# Generated at 2022-06-25 22:26:45.829196
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # TODO: add more test cases
    test_case_0()

# Generated at 2022-06-25 22:26:47.804243
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_x_var_0 = module_0.Module()
    module_x_var_1 = test_case_0()
    module_x_var_2 = test_case_

# Generated at 2022-06-25 22:26:53.938436
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_0 = module_0.Module()
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    list_0 = [python2_future_transformer_0, python2_future_transformer_0]
    python2_future_transformer_1 = Python2FutureTransformer(a_s_t_0)
    a_s_t_1 = module_0.AST(*list_0)
    python2_future_transformer_2 = Python2FutureTransformer(a_s_t_1)

# Generated at 2022-06-25 22:26:59.801057
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import typed_ast._ast3 as module_0
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_0 = module_0.Module()
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    list_0 = [python2_future_transformer_0, python2_future_transformer_0]
    python2_future_transformer_1 = Python2FutureTransformer(a_s_t_0)
    a_s_t_1 = module_0.AST(*list_0)

# Generated at 2022-06-25 22:27:02.073018
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_0 = python2_future_transformer_0.visit_Module(module_0.Module())


# Generated at 2022-06-25 22:27:07.550019
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_0 = ast.Module()

    python2_future_transformer_0 = Python2FutureTransformer(module_0)

    module_x_var_0 = ast.Module()
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    assert module_x_var_1.body == [
        imports.get_body(future='__future__')[0],
        imports.get_body(future='__future__')[1],
        imports.get_body(future='__future__')[2],
        imports.get_body(future='__future__')[3]
    ]

    python2_future_transformer_1 = Python2FutureTransformer(module_0)

    module_x_var_2 = python2_future

# Generated at 2022-06-25 22:27:12.698325
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    assert_equals(python2_future_transformer_0._tree_changed, True)
    assert_equals(python2_future_transformer_0._target_version, (2, 7))
    assert_equals(python2_future_transformer_0._tree, a_s_t_0)
    assert_equals(python2_future_transformer_0._generic_visit, module_0.NodeTransformer.generic_visit)
    a_s_t_1 = module_0.AST()
    python2_