

# Generated at 2022-06-25 22:18:10.230026
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_1 = module_0.AST()
    python2_future_transformer_1 = Python2FutureTransformer(a_s_t_1)
    module_node_0 = module_0.Module()
    python2_future_transformer_1._tree_changed = False
    python2_future_transformer_1.generic_visit = lambda x : x
    module_1 = python2_future_transformer_1.visit_Module(module_node_0)
    python2_future_transformer_1.generic_visit = lambda x : x

# Generated at 2022-06-25 22:18:13.165117
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)

# Generated at 2022-06-25 22:18:17.731565
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__doc__ == "Prepends module with:\\n        from __future__ import absolute_import\\n        from __future__ import division\\n        from __future__ import print_function\\n        from __future__ import unicode_literals\\n            "

# Generated at 2022-06-25 22:18:21.643026
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import sys
    import typed_ast._ast3 as module_0
    future_1 = (1, 2, 3, 4)
    python2_future_transformer_0 = Python2FutureTransformer(future_1)
    assert python2_future_transformer_0 is not None
    test_case_0()


# Generated at 2022-06-25 22:18:24.218353
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)


# Generated at 2022-06-25 22:18:27.464589
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    assert python2_future_transformer_0 is not None

# Generated at 2022-06-25 22:18:31.923433
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_alias_0 = module_0.Module(body=[])
    python2_future_transformer_0.visit_Module(module_alias_0)

# Generated at 2022-06-25 22:18:36.894759
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    a_s_t_1 = module_0.AST()
    module_0_0 = module_0.Module(body=[])
    module_0_1 = python2_future_transformer_0.visit_Module(module_0_0)


# Generated at 2022-06-25 22:18:41.215803
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_1 = module_0.Module()
    python2_future_transformer_0.visit_Module(module_1)

# Generated at 2022-06-25 22:18:44.829712
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    python2_future_transformer_0 = Python2FutureTransformer(None)
    module_0 = module_0.Module([])
    module_0 = python2_future_transformer_0.visit_Module(module_0)


# Generated at 2022-06-25 22:18:58.190730
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    list_0 = []
    list_1 = [list_0]
    module_x_var_0 = module_0.Module(*list_1)
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:19:05.481729
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    list_0 = []
    list_1 = [list_0]
    module_x_var_0 = module_0.Module(*list_1)
    list_2 = [module_x_var_0]
    module_x_var_1 = module_0.Module(*list_2)
    a_s_t_0 = module_0.AST()
    assert repr(module_x_var_0) == "Module(body=[])"
    test_case_0()
    test_case_0()

# Generated at 2022-06-25 22:19:06.529932
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert(True)


# Generated at 2022-06-25 22:19:15.489333
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    snippet_0 = """
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

a = 1
"""
    list_0 = []
    list_1 = [list_0]
    module_x_var_0 = module_0.Module(*list_1)
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    if snippet_0 != ast.unparse(module_x_var_1):
        assert False


# Generated at 2022-06-25 22:19:16.842608
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    global python2_future_transformer_0
    test_case_0()
    assert python2_future_transformer_0._tree_changed == True

# Generated at 2022-06-25 22:19:23.005486
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Arrange
    list_0 = []
    list_1 = [list_0]
    module_x_var_0 = module_0.Module(*list_1)
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)

    # Act
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

    # Assert
    assert len(module_x_var_1.body) == 4



# Generated at 2022-06-25 22:19:30.459964
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    list_0 = []
    list_1 = [list_0]
    module_x_var_0 = module_0.Module(*list_1)
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    if (python2_future_transformer_0._tree_changed != False):
        print('Result failed')
    else:
        if (python2_future_transformer_0._module is not None):
            print('Result failed')
        else:
            print('Result succeeded')


# Generated at 2022-06-25 22:19:37.687776
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    list_0 = []
    list_1 = [list_0]
    module_x_var_0 = module_0.Module(*list_1)
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

if __name__ == '__main__':
    test_case_0()
    test_Python2FutureTransformer_visit_Module()

# Generated at 2022-06-25 22:19:43.126822
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    list_0 = []
    list_1 = [list_0]
    module_x_var_0 = module_0.Module(*list_1)
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    test_case_0()

# Generated at 2022-06-25 22:19:44.668090
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer(a_s_t_0)


# Generated at 2022-06-25 22:19:49.611288
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass


# Generated at 2022-06-25 22:19:53.932869
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:19:59.149781
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    list_0 = []
    list_1 = [list_0]
    module_x_var_0 = module_0.Module(*list_1)
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    test_case_0()

if __name__ == '__main__':
    test_Python2FutureTransformer_visit_Module()

# Generated at 2022-06-25 22:20:02.128309
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    assert(python2_future_transformer_0.tree_changed == False)


# Generated at 2022-06-25 22:20:02.896911
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert True


# Generated at 2022-06-25 22:20:06.717485
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Prepare inputs
    list_0 = []
    list_1 = [list_0]
    module_x_var_0 = module_0.Module(*list_1)
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    
    # Execute the method
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    
    # Verify results
    assert module_x_var_1 is not None


# Generated at 2022-06-25 22:20:12.020727
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    try:
        a_s_t_0 = module_0.AST()
        python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
        assert python2_future_transformer_0._tree_changed == False
        assert python2_future_transformer_0._ast == a_s_t_0
    except:
        raise RuntimeError('An error has occurred!')


# Generated at 2022-06-25 22:20:20.365795
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    list_0 = []
    list_1 = [list_0]
    module_x_var_0 = module_0.Module(*list_1)
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    assert not python2_future_transformer_0._tree_changed
    # assert python2_future_transformer_0._version == (2, 7)
    python2_future_transformer_0.visit_Module(module_x_var_0)
    # assert python2_future_transformer_0._version == (2, 7)

# Generated at 2022-06-25 22:20:25.882889
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Setup
    list_0 = []
    list_1 = [list_0]
    module_x_var_0 = module_0.Module(*list_1)
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    # Exercise
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    # Verify
    assert (len(module_x_var_1.body) == 4)
    assert (len(module_x_var_1.body[0].body) == 4)


# Generated at 2022-06-25 22:20:27.986530
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)



# Generated at 2022-06-25 22:20:41.680996
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    list_0 = []
    list_1 = [list_0]
    module_x_var_0 = module_0.Module(*list_1)
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-25 22:20:42.643416
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    test_case_0()


# Generated at 2022-06-25 22:20:47.547091
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    list_0 = []
    list_1 = [list_0]
    module_x_var_0 = module_0.Module(*list_1)
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:20:57.749162
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    list_0 = []
    list_1 = [list_0]
    module_x_var_0 = module_0.Module(*list_1)
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    python2_future_transformer_0.visit_Module(module_x_var_0)
    '''
    python2futureTransformer_0.visit_Module(module_x_var_0)
    python2futureTransformer_0.visit_Module(module_x_var_0)
    '''


# Generated at 2022-06-25 22:20:58.994999
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    assert test_case_0() == None

# Generated at 2022-06-25 22:21:02.339117
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert python2_future_transformer_0.generic_visit == python2_future_transformer_0.visit_Module
    assert python2_future_transformer_0.replace is False
    assert python2_future_transformer_0.tree_changed is True


# Generated at 2022-06-25 22:21:09.049957
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    args_0 = None
    # test constructor
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    # test attributes
    assert python2_future_transformer_0._tree_changed == False


# Generated at 2022-06-25 22:21:10.870919
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Test case where module is empty
    test_case_0()

# Generated at 2022-06-25 22:21:17.855813
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # Make a dummy "module" for test_case_0
    module_x_var_1 = test_case_0()
    
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    assert python2_future_transformer_0._tree_changed == False
    assert python2_future_transformer_0._ast == a_s_t_0



# Generated at 2022-06-25 22:21:21.206959
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = ast.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)

# Generated at 2022-06-25 22:21:38.391614
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    assert isinstance(python2_future_transformer_0, Python2FutureTransformer)


# Generated at 2022-06-25 22:21:43.610410
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    list_0 = []
    list_1 = [list_0]
    module_x_var_0 = module_0.Module(*list_1)
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:21:45.552802
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # TestCase 0
    test_case_0()

if __name__ == '__main__':
    test_Python2FutureTransformer_visit_Module()

# Generated at 2022-06-25 22:21:49.110576
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    list_0 = []
    list_1 = [list_0]
    module_x_var_0 = module_0.Module(*list_1)
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    if ((python2_future_transformer_0.a_s_t != a_s_t_0) or (python2_future_transformer_0.tree_changed != False)):
        raise RuntimeError("Failed")


# Generated at 2022-06-25 22:21:54.814500
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    list_0 = []
    list_1 = [list_0]
    module_x_var_0 = module_0.Module(*list_1)
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    return python2_future_transformer_0._tree_changed


# Generated at 2022-06-25 22:21:56.948940
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)


# Generated at 2022-06-25 22:22:01.421105
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    assert python2_future_transformer_0 is not None
    assert python2_future_transformer_0.target == (2, 7)


# Generated at 2022-06-25 22:22:02.382273
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    test_case_0()

# Generated at 2022-06-25 22:22:04.228346
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    list_0 = []
    list_1 = [list_0]

# Generated at 2022-06-25 22:22:04.995886
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    test_case_0()

# Generated at 2022-06-25 22:22:33.576285
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    test_case_0()


# Generated at 2022-06-25 22:22:34.651667
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    test_case_0()


# Generated at 2022-06-25 22:22:35.164520
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    pass

# Generated at 2022-06-25 22:22:40.313127
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    list_0 = []
    list_1 = [list_0]
    module_x_var_0 = module_0.Module(*list_1)
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    python2_future_transformer_0.visit_Module(module_x_var_0)



# Generated at 2022-06-25 22:22:45.341678
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    list_0 = []
    list_1 = [list_0]
    module_x_var_0 = module_0.Module(*list_1)
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)


# Generated at 2022-06-25 22:22:47.148782
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    test_case_0()
    
if __name__ == '__main__':
    test_Python2FutureTransformer_visit_Module()

# Generated at 2022-06-25 22:22:48.519218
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    snippet.test_snippets([Python2FutureTransformer, Python2FutureTransformer.visit_Module])

# Generated at 2022-06-25 22:22:54.308659
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # Test for class Python2FutureTransformer
    # Test for method visit_Module
    # Test for method generic_visit
    list_0 = []
    list_1 = [list_0]
    module_x_var_0 = module_0.Module(*list_1)
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:23:00.622516
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    list_0 = []
    list_1 = [list_0]
    module_x_var_0 = module_0.Module(*list_1)
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    assert module_x_var_1 == module_x_var_0

# Generated at 2022-06-25 22:23:09.368714
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import ast
    import typed_ast._ast3 as module_0
    
    list_0 = []
    list_1 = [list_0]
    module_x_var_0 = module_0.Module(*list_1)
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    assert isinstance(module_x_var_1, module_0.Module)
    assert module_x_var_1.body == [importFutureNode]
    
    list_2 = []
    list_3 = [list_2]

# Generated at 2022-06-25 22:24:12.578860
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    assert test_case_0()


# Generated at 2022-06-25 22:24:13.377356
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    assert True == True

test_case_0()

# Generated at 2022-06-25 22:24:17.912445
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    list_0 = []
    list_1 = [list_0]
    module_x_var_0 = module_0.Module(*list_1)
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:24:22.284771
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Module
    from .base import BaseNodeTransformer

    a_s_t_var_0 = ast.AST()
    python2_future_transformer_var_0 = Python2FutureTransformer(a_s_t_var_0)
    assert isinstance(python2_future_transformer_var_0, BaseNodeTransformer)


# Generated at 2022-06-25 22:24:24.026426
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    try:
        pass
    except:
        pass


# Generated at 2022-06-25 22:24:24.506561
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert True == True

# Generated at 2022-06-25 22:24:25.552098
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    test_case_0()


# Generated at 2022-06-25 22:24:27.028988
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    test_case_0()

# Unit tests for class Python2FutureTransformer

# Generated at 2022-06-25 22:24:32.923842
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    list_0 = []
    list_1 = [list_0]
    module_x_var_0 = module_0.Module(*list_1)
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    # assert python2_future_transformer_0.visit_Module(module_x_var_0).body[0].value.values[0].value == '__future__'

# Generated at 2022-06-25 22:24:33.649323
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    test_case_0()


print("Test Complete")

# Generated at 2022-06-25 22:27:06.359747
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    list_0 = []
    list_1 = [list_0]
    module_x_var_0 = module_0.Module(*list_1)
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    assert module_x_var_1 == python2_future_transformer_0.visit_Module(module_x_var_0)

if __name__ == "__main__":
    from common import update_test_spec

    update_test_spec(__file__, [Python2FutureTransformer])

# Generated at 2022-06-25 22:27:09.375957
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)

    assert True
    assert python2_future_transformer_0.get_tree_changed() is False
    assert python2_future_transformer_0.target == (2, 7)
    assert type(
        python2_future_transformer_0) == Python2FutureTransformer


# Generated at 2022-06-25 22:27:10.620634
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    target = (2, 7)
    python2_future_transformer_0 = Python2FutureTransformer(None)
    python2_future_transformer_0.target

# Generated at 2022-06-25 22:27:12.503805
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
  o = Python2FutureTransformer()

if __name__ == "__main__":
    test_case_0()
    test_Python2FutureTransformer()

# Generated at 2022-06-25 22:27:14.929307
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    a_s_t_0 = ast.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    assert python2_future_transformer_0 is not None


# Generated at 2022-06-25 22:27:20.194948
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    list_0 = []
    list_1 = [list_0]
    module_x_var_0 = module_0.Module(*list_1)
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    assert(isinstance(module_x_var_1, module_0.Module))
    assert(len(module_x_var_1.body) == 4)
    assert(isinstance(module_x_var_1.body[0], module_0.ImportFrom))

# Generated at 2022-06-25 22:27:25.798058
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    list_0 = []
    list_1 = [list_0]
    module_x_var_0 = module_0.Module(*list_1)
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    if (len(module_x_var_1.body) != 4):
        raise RuntimeError
    if (module_x_var_1.body[0].names[0].name != 'absolute_import'):
        raise RuntimeError
    if (module_x_var_1.body[1].names[0].name != 'division'):
        raise Runtime

# Generated at 2022-06-25 22:27:32.111188
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    global module_x_var_0
    global module_x_var_1
    global module_x_var_2
    global a_s_t_0
    global python2_future_transformer_0
    global module_x_var_1
    module_x_var_0 = module_0.Module()
    list_0 = []
    module_x_var_0.body = list_0
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    list_0 = []
    list_1 = [list_0]
    module_x_var

# Generated at 2022-06-25 22:27:33.930202
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # see if there are any exceptions raised
    # assert test_case_0(), "test_case_0 failed"
    print("Python2FutureTransformer.__init__: PASSED")
    return True


# Generated at 2022-06-25 22:27:39.819592
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    list_0 = []
    list_1 = [list_0]
    module_x_var_0 = module_0.Module(*list_1)
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    assert python2_future_transformer_0._tree_changed == True
    assert len(module_x_var_1.body) == 4
    assert isinstance(module_x_var_1.body[0], module_0.ImportFrom)
    assert isinstance(module_x_var_1.body[1], module_0.ImportFrom)
   