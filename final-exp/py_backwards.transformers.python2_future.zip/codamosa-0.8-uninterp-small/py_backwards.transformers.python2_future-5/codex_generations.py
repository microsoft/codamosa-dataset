

# Generated at 2022-06-25 22:18:19.383302
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    a_1 = module_0.Module(body=[], type_ignores=[])
    a_2 = module_0.Module(body=[], type_ignores=[])
    assert python2_future_transformer_0.visit_Module(a_1) is a_2
    for a_3 in module_0.Module(body=[], type_ignores=[]).body:
        assert False
    for a_4 in a_2.body:
        assert not all(a_4, [])


# Generated at 2022-06-25 22:18:22.744747
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    python2_future_transformer_1 = Python2FutureTransformer()


# Generated at 2022-06-25 22:18:30.439296
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import _ast
    a_s_t_1 = _ast.AST()
    python2_future_transformer_1 = Python2FutureTransformer(a_s_t_1)
    module_1 = _ast.Module()
    a_s_t_2 = python2_future_transformer_1.visit_Module(module_1)
    assert a_s_t_2 is not module_1
    assert a_s_t_2.body[0].names[0].name == 'absolute_import'
    assert a_s_t_2.body[0].names[0].asname == None
    assert a_s_t_2.body[1].names[0].name == 'division'
    assert a_s_t_2.body[1].names[0].asname == None

# Generated at 2022-06-25 22:18:31.817066
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    try:
        test_case_0()
    except:
        assert False


# Generated at 2022-06-25 22:18:38.399283
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_0_0 = module_0.Module()
    # using methods of class AST
    module_0_1 =  python2_future_transformer_0.visit(module_0_0)
    assert module_0_1 == module_0_1
    # using method of class Python2FutureTransformer
    module_0_1 = python2_future_transformer_0.visit_Module(module_0_0)
    assert module_0_1 == module_0_1
    
    

# Generated at 2022-06-25 22:18:46.339089
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # template: sample/sample.py

    i0 = typed_ast.ast3.parse(template, mode='exec')

    a_s_t_0 = typed_ast.ast3.AST()

    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)

    python2_future_transformer_0.visit(i0)

    #snippet: sample/sample.py
    expected = typed_ast.ast3.parse(snippet, mode='exec')

    assert typed_ast.ast3.dump(i0) == typed_ast.ast3.dump(expected)

# Generated at 2022-06-25 22:18:51.349263
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    # Tests constructor of class Python2FutureTransformer
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    assert isinstance(python2_future_transformer_0, Python2FutureTransformer)
    assert python2_future_transformer_0.ast == a_s_t_0


# Generated at 2022-06-25 22:18:53.160207
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)


# Generated at 2022-06-25 22:18:59.846285
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    python2_future_transformer_1 = Python2FutureTransformer(a_s_t_0)

    assert(python2_future_transformer_0.target == (2, 7))
    assert(python2_future_transformer_1.target == (2, 7))


# Generated at 2022-06-25 22:19:06.581151
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_Module_0 = module_0.Module()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_Module_0)
    a_s_t_Module_0 = python2_future_transformer_0.visit_Module(a_s_t_Module_0)
    assert a_s_t_Module_0 is not None
    assert len(a_s_t_Module_0.body) == 4

# Generated at 2022-06-25 22:19:13.452007
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.Module()
    python2_future_transformer_0 = Python2FutureTransformer()
    python2_future_transformer_0.visit_Module(a_s_t_0)

# Generated at 2022-06-25 22:19:17.329356
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_1 = module_0.Module()
    module_2 = python2_future_transformer_0.visit_Module(module_1)
    assert isinstance(module_2, module_0.Module)

# Generated at 2022-06-25 22:19:21.502871
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)

    assert isinstance(python2_future_transformer_0, module_0.NodeTransformer)
    assert isinstance(python2_future_transformer_0, Python2FutureTransformer)


# Generated at 2022-06-25 22:19:27.071160
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_0_0 = module_0.Module()
    python2_future_transformer_0._tree_changed = None
    module_0_1 = python2_future_transformer_0.visit_Module(module_0_0)
    assert module_0_1 is not None

# Generated at 2022-06-25 22:19:30.948384
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Set up
    module = ast.parse('''
print('a')
print('b')
    ''')

    # Exercise
    result = Python2FutureTransformer().visit(module)

    # Verify
    assert [node.lineno for node in result.body] == [1, 2, 3, 4, 5, 6]



# Generated at 2022-06-25 22:19:35.022274
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_s_t_0 = module_0.Module()
    python2_future_transformer_0 = Python2FutureTransformer()
    result = python2_future_transformer_0.visit_Module(module_s_t_0)
    assert result == module_s_t_0

# Generated at 2022-06-25 22:19:39.566310
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_1 = module_0.Module()
    output_0 = python2_future_transformer_0.visit_Module(module_1)
    assert isinstance(output_0, module_0.Module)


# Generated at 2022-06-25 22:19:49.659094
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():

    # constructor arguments
    from typed_ast import ast3 as ast
    a_s_t_0 = ast.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_0 = ast.Module()
    python2_future_transformer_0.visit(module_0)
    module_1 = ast.Module()
    python2_future_transformer_0.visit(module_1)
    python2_future_transformer_0.visit_Str()
    python2_future_transformer_0.visit_Module()
    python2_future_transformer_0.visit_Module()
    python2_future_transformer_0.visit_Tuple()
    python2_future_transformer_0.visit_Tuple

# Generated at 2022-06-25 22:19:58.400019
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    def test_case_1():
        assert python2_future_transformer_0._tree is a_s_t_0
    test_case_1()


# Generated at 2022-06-25 22:20:05.297513
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import ast as ast_0
    import typing as typing_0
    a_s_t_0 = ast_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module = ast_0.Module(body=[])
    module_target = typing_0.cast(ast_0.Module, module)
    assert (python2_future_transformer_0.visit_Module(module) == module_target)
    expected = ast_0.Module(body=imports.get_body(future='__future__'))
    asserts = [node.value.func.id == "print" for node in module_target.body if isinstance(node, ast_0.Expr)]
    assert all(asserts)

# Generated at 2022-06-25 22:20:10.143331
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass

# Generated at 2022-06-25 22:20:16.181061
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    assert isinstance(module_x_var_1, module_0.Module)

# Generated at 2022-06-25 22:20:18.888677
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    var0 = module_0.Module()
    var1 = module_0.AST()
    var2 = Python2FutureTransformer(var1)
    var3 = var2.visit_Module(var0)

# Generated at 2022-06-25 22:20:20.656926
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)


# Generated at 2022-06-25 22:20:23.376255
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    assert isinstance(python2_future_transformer_0, Python2FutureTransformer)


# Generated at 2022-06-25 22:20:24.032961
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    pass # TODO


# Generated at 2022-06-25 22:20:26.910789
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_1 = Python2FutureTransformer(a_s_t_0)

# Generated at 2022-06-25 22:20:27.714801
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    test_case_0()


# Generated at 2022-06-25 22:20:32.134732
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:20:36.425397
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:20:46.504692
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)


# Generated at 2022-06-25 22:20:48.370050
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_0 = Python2FutureTransformer(module_0.AST(),)


# Generated at 2022-06-25 22:20:50.402780
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_0.Module()
import unittest


# Generated at 2022-06-25 22:20:56.580964
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    typed_ast.ast3 = module_0
    module_x_var_2 = module_0.Module()
    a_s_t_1 = module_0.AST()
    python2_future_transformer_1 = Python2FutureTransformer(a_s_t_1)
    module_x_var_3 = python2_future_transformer_1.visit_Module(module_x_var_2)

# Generated at 2022-06-25 22:21:04.954207
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Set up context
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    # Invoke Method_visit_Module with uninitialized instance of Python2FutureTransformer
    method_result_0 = python2_future_transformer_0.visit_Module(module_x_var_0)
    # Check method results
    assert isinstance(method_result_0,module_0.Module)
    assert method_result_0.col_offset == None
    assert method_result_0.lineno == None
    assert method_result_0.body == []
    assert method_result_0.type_ignores == []

# Generated at 2022-06-25 22:21:13.139421
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:21:18.467976
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_2 = module_0.Module()
    a_s_t_1 = module_0.AST()
    python2_future_transformer_1 = Python2FutureTransformer(a_s_t_1)
    module_x_var_3 = python2_future_transformer_1.visit_Module(module_x_var_2)

# Generated at 2022-06-25 22:21:24.707658
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    #Variables
    ast_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(ast_0)
    assert python2_future_transformer_0 is not None
    python2_future_transformer_1 = Python2FutureTransformer()
    assert python2_future_transformer_1 is not None

# Generated at 2022-06-25 22:21:30.714032
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    assert(module_x_var_1 == module_x_var_0)

# Generated at 2022-06-25 22:21:33.739990
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_var_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_var_0)
    assert python2_future_transformer_0


# Generated at 2022-06-25 22:21:50.695512
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    python2_future_transformer_0 = Python2FutureTransformer()
    test_case_0()


# Generated at 2022-06-25 22:21:55.365911
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    assert isinstance(module_x_var_1, module_0.Module)

# Generated at 2022-06-25 22:22:04.561527
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:22:05.409258
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert True


# Generated at 2022-06-25 22:22:09.986917
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    

# Generated at 2022-06-25 22:22:12.285797
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_var_0 = module_0.AST()
    python2_future_transformer_var_0 = Python2FutureTransformer(a_s_t_var_0)



# Generated at 2022-06-25 22:22:14.658229
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.utils import run_test_case
    run_test_case(test_case_0)

# Generated at 2022-06-25 22:22:15.477536
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer(module_0.AST())

# Generated at 2022-06-25 22:22:17.452659
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # Test with: typed_ast
    # Test with: typed_ast._ast3.AST
    # Test with: typed_ast._ast3.Module
    assert True



# Generated at 2022-06-25 22:22:19.078420
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    test_case_0()

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 22:22:51.699430
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    test_case_0()

# Generated at 2022-06-25 22:23:00.545781
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Constants
    module_x_var_2 = None
    module_x_var_3 = None
    module_x_var_4 = None
    module_x_var_5 = None
    module_x_var_6 = None
    module_x_var_7 = None
    module_x_var_8 = None
    a_s_t_1 = None
    a_s_t_2 = None
    a_s_t_3 = None
    a_s_t_4 = None
    a_s_t_5 = None
    a_s_t_6 = None
    a_s_t_7 = None
    python2_future_transformer_1 = None
    python2_future_transformer_2 = None
    python2_future_transformer_3 = None
   

# Generated at 2022-06-25 22:23:01.348522
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    test_case_0()

# Generated at 2022-06-25 22:23:05.787988
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_0 = module_0.Module()
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:23:11.515870
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import typed_ast._ast3 as module_0
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    print("module_x_var_1: ", module_x_var_1)

# Generated at 2022-06-25 22:23:16.931587
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    # assert that result matches "test_case_0"
    assert test_case_0() == module_x_var_1

# Generated at 2022-06-25 22:23:17.449122
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass

# Generated at 2022-06-25 22:23:21.541028
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:23:27.374706
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    python2_future_transformer_0._tree_changed

# Generated at 2022-06-25 22:23:34.817647
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    python3_future_transformer_0 = Python3FutureTransformer(a_s_t_0)
    module_x_var_2 = python3_future_transformer_0.visit_Module(module_x_var_0)
    assert (len(module_x_var_2.body) == len(module_x_var_1.body))

# Generated at 2022-06-25 22:24:51.574914
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    try:
        test_case_0()
    except:
        print("Exception in test case 0")

from typed_ast import ast3 as ast

from .base import BaseNodeTransformer
from ..utils.snippet import snippet

TRAILING_COMMA_MESSAGE = """\
Found trailing comma in %s,
trailing comma is not supported in Python 2.7
"""


# Generated at 2022-06-25 22:24:52.306734
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    test_case_0()

# Generated at 2022-06-25 22:24:53.980076
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    python2_future_transformer_0 = Python2FutureTransformer(module_0.AST())
    test_case_0()

# Generated at 2022-06-25 22:24:55.286540
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    check_results(test_case_0,
                  [({'future': '__future__'}, 4)])

# Generated at 2022-06-25 22:24:59.813646
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:25:06.777517
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    assert module_x_var_1.body[0].names[0].name == 'absolute_import'
    assert module_x_var_1.body[1].names[0].name == 'division'
    assert module_x_var_1.body[2].names[0].name == 'print_function'
    assert module_x_var_1.body[3].names[0].name == 'unicode_literals'
    assert python2

# Generated at 2022-06-25 22:25:11.113170
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Call to visit_Module(...):
    Module_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    # Call to visit_Module(...):
    module_x_var_1 = python2_future_transformer_0.visit_Module(Module_0)

# Generated at 2022-06-25 22:25:11.882837
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert (Python2FutureTransformer)


# Generated at 2022-06-25 22:25:12.602510
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    test_case_0()

# Generated at 2022-06-25 22:25:14.866822
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
