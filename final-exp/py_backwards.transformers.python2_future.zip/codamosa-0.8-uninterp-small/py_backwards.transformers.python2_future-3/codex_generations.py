

# Generated at 2022-06-25 22:18:10.876330
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass


# Generated at 2022-06-25 22:18:21.681033
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():

    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_1 = module_0.Module(body=[])
    module_2 = python2_future_transformer_0.visit_Module(module_1)

    assert python2_future_transformer_0._tree_changed
    assert len(module_2.body) == 4
    # 'from __future__ import absolute_import'
    assert module_2.body[0].names[0].name == 'absolute_import'
    # 'from __future__ import division'
    assert module_2.body[1].names[0].name == 'division'
    # 'from __future__ import print_function'

# Generated at 2022-06-25 22:18:26.336638
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_0_0 = python2_future_transformer_0._ast.parse(
        "x = 1")
    python2_future_transformer_0.visit(module_0_0)

# Generated at 2022-06-25 22:18:35.980263
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)

    # Setup:
    a_s_t_0.mod = module_1 = module_0.Module([])
    module_1.body = []
    python2_future_transformer_0._tree_changed = False

    # Test:
    module_0.Module.visit(python2_future_transformer_0, module_1)

    # Assert:
    assert module_1.body[0].value.func.value.id == 'print_function'
    assert module_1.body[1].value.func.value.id == 'absolute_import'

# Generated at 2022-06-25 22:18:39.091740
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_1 = module_0.AST()
    assert isinstance(Python2FutureTransformer(a_s_t_1), Python2FutureTransformer)


# Generated at 2022-06-25 22:18:41.617302
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)

# Generated at 2022-06-25 22:18:51.154874
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    a_s_t_0.body = [ast.Pass()]
    a_s_t_0.body[0].lineno = a_s_t_0.body[0].col_offset = 1
    python2_future_transformer_0.transformed_ast = a_s_t_0
    python2_future_transformer_0.visit(a_s_t_0)
    assert python2_future_transformer_0._tree_changed == True
    assert python2_future_transformer_0.transformed_ast.body[0].lineno == 5
    assert python2_future_transformer_0.transformed

# Generated at 2022-06-25 22:18:59.178816
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_0 = module_0.Module()
    module_0_0 = python2_future_transformer_0.visit_Module(module_0)


if __name__ == '__main__':
    import pytest
    pytest.main(['--tu', '--un', '-q', '-x', 'test_Python2FutureTransformer.py'])

# Generated at 2022-06-25 22:19:09.481285
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    def_0 = module_0.FunctionDef()
    a_s_t_0.body.append(def_0)
    arg_0 = module_0.arguments()
    def_0.args = arg_0
    python2_future_transformer_0.visit(a_s_t_0)
    assert a_s_t_0.body[0].args._fields == ('args', 'vararg', 'varargannotation', 'kwonlyargs', 'kwarg', 'kwargannotation', 'defaults', 'kw_defaults', 'annotations')
    a

# Generated at 2022-06-25 22:19:15.221341
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    try:
        a_s_t_1 = module_0.Module()
    except Exception as inst:
        print(inst)
    try:
        a_s_t_2 = python2_future_transformer_0.visit_Module(a_s_t_1)
    except Exception as inst:
        print(inst)

# Generated at 2022-06-25 22:19:21.242544
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    dict_0 = {}
    module_x_var_0 = module_0.AST(**dict_0)
    python2_future_transformer_0 = Python2FutureTransformer(module_x_var_0)
    a_s_t_0 = module_0.AST(**dict_0)
    python2_future_transformer_1 = Python2FutureTransformer(a_s_t_0)

# Generated at 2022-06-25 22:19:27.509665
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    python2_future_transformer_0 = Python2FutureTransformer(**{})
    module_x_var_0 = module_0.Module()
    module_x_var_1 = module_0.Module()
    module_x_var_2 = python2_future_transformer_0.visit_Module(module_x_var_0)
    assert set([id(module_x_var_1.body), id(module_x_var_2.body)]) == {id(module_x_var_1.body)}


# Generated at 2022-06-25 22:19:34.568063
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    dict_0 = {}
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST(**dict_0)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    a_s_t_1 = module_0.AST(**dict_0)
    python2_future_transformer_1 = Python2FutureTransformer(a_s_t_1)

# Generated at 2022-06-25 22:19:40.493042
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    dict_0 = {}
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST(**dict_0)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    python2_future_transformer_1 = Python2FutureTransformer(a_s_t_0)
    assert python2_future_transformer_0 is not None
    assert python2_future_transformer_1 is not None


# Generated at 2022-06-25 22:19:43.440169
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    dict_0 = {}
    a_s_t_0 = module_0.AST(**dict_0)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)


# Generated at 2022-06-25 22:19:49.802390
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    dict_0 = {}
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST(**dict_0)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)


# Generated at 2022-06-25 22:19:51.123552
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    dict_0 = {}
    assert(dict_0 == {})


# Generated at 2022-06-25 22:19:58.729684
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ast import Module
    from typed_ast import AST
    from ..transpilers.python2_future import Python2FutureTransformer
    dict_0 = {}
    module_x_var_0 = Module()
    a_s_t_0 = AST(**dict_0)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    a_s_t_1 = AST(**dict_0)
    python2_future_transformer_1 = Python2FutureTransformer(a_s_t_1)

# Generated at 2022-06-25 22:20:02.863186
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    dict_0 = {}
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST(**dict_0)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:20:04.883760
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    try:
        test_case_0()
    except Exception as err:
        print('Caught exception: ' + repr(err))
        import traceback
        print(traceback.format_exc())
        assert False


# Generated at 2022-06-25 22:20:16.500990
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    dict_0 = {}
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST(**dict_0)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    a_s_t_1 = module_0.AST(**dict_0)
    python2_future_transformer_1 = Python2FutureTransformer(a_s_t_1)

# Generated at 2022-06-25 22:20:24.399738
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    dict_0 = {}
    dict_0['__name__'] = '__main__'
    dict_0['__doc__'] = None
    dict_0['__package__'] = None
    dict_0['__loader__'] = None
    dict_0['__spec__'] = None
    dict_0['__annotations__'] = None
    dict_0['__builtins__'] = None
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST(**dict_0)
    module_x_var_1 = a_s_t_0.parse(imports.get_def('__future__'))
    module_x_var_0.body = module_x_var_1.body
    python2_future_transformer_0 = Python

# Generated at 2022-06-25 22:20:28.022259
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    dict_0 = {}
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST(**dict_0)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)


# Generated at 2022-06-25 22:20:32.808660
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    dict_0 = {}
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST(**dict_0)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:20:38.408918
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    dict_0 = {}
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST(**dict_0)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    assert python2_future_transformer_0.visit_Module(module_x_var_0) == module_x_var_0

# Generated at 2022-06-25 22:20:42.167071
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    dict_0 = {}
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST(**dict_0)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)


# Generated at 2022-06-25 22:20:47.511319
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    dict_0 = {}
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST(**dict_0)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

test_case_0()
test_Python2FutureTransformer_visit_Module()

# Generated at 2022-06-25 22:20:49.365125
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # TODO: Improve test case
    return


# Generated at 2022-06-25 22:20:51.291536
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():

    import typed_ast.ast3 as typed_ast


# Generated at 2022-06-25 22:20:56.202578
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    dict_0 = {}
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST(**dict_0)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)


# Generated at 2022-06-25 22:21:11.144921
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    dict_0 = {}
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST(**dict_0)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    assert module_x_var_1 == module_x_var_0
    python2_future_transformer_0.generic_visit(module_x_var_0)


# Generated at 2022-06-25 22:21:14.482218
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)

test_case_0()
test_Python2FutureTransformer()

# Generated at 2022-06-25 22:21:20.527771
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    dict_0 = {}
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST(**dict_0)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    python2_future_transformer_1 = Python2FutureTransformer(a_s_t_0)
    python2_future_transformer_2 = Python2FutureTransformer(a_s_t_0)


# Generated at 2022-06-25 22:21:31.997618
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    dict_0 = {}
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST(**dict_0)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    assert type(module_x_var_1) == module_0.Module
    assert type(module_x_var_1.body[0]) == module_0.ImportFrom
    assert module_x_var_1.body[1].body[0].name == 'absolute_import'
    assert type(module_x_var_1.body[2]) == module_0.ImportFrom
    assert module

# Generated at 2022-06-25 22:21:36.576804
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    dict_0 = {}
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST(**dict_0)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    assert isinstance(python2_future_transformer_0, Python2FutureTransformer)
    

# Generated at 2022-06-25 22:21:45.025802
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    dict_0 = {}
    module_2_var_0 = module_0.Module()
    a_s_t_2 = module_0.AST(**dict_0)
    python2_future_transformer_2 = Python2FutureTransformer(a_s_t_2)
    module_2_var_1 = python2_future_transformer_2.visit_Module(module_2_var_0)
    module_2_var_1.body
    module_2_var_1.body[0].__class__
    module_2_var_1.body[0].module
    module_2_var_1.body[0].names[0]
    module_2_var_1.body[0].level
    module_2_var_1.body[1].__class__
    module_

# Generated at 2022-06-25 22:21:52.588857
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    dict_0 = {}
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST(**dict_0)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    assert module_x_var_1

    assert python2_future_transformer_0._tree_changed
    assert python2_future_transformer_0._tree_changed == python2_future_transformer_1._tree_changed


# Generated at 2022-06-25 22:21:53.320116
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass

# Generated at 2022-06-25 22:21:54.135915
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    test_case_0()

# Generated at 2022-06-25 22:21:57.173433
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    dict_0 = {}
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST(**dict_0)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)

# Generated at 2022-06-25 22:22:17.042245
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    dict_0 = {}
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST(**dict_0)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    print(module_x_var_1)

# Generated at 2022-06-25 22:22:20.052064
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    dict_0 = {}
    a_s_t_0 = module_0.AST(**dict_0)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    pass


# Generated at 2022-06-25 22:22:25.939816
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    dict_0 = {}
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST(**dict_0)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    a_s_t_1 = module_0.AST(**dict_0)
    python2_future_transformer_1 = Python2FutureTransformer(a_s_t_1)

# Generated at 2022-06-25 22:22:31.340978
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    python2_future_transformer_0 = Python2FutureTransformer()
    a_s_t_0 = module_0.AST(**dict_0)
    python3_future_transformer_0 = Python3FutureTransformer(a_s_t_0)
    module_x_var_0 = module_0.Module()
    module_x_var_1 = python3_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:22:39.452960
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    set_0 = {'key_0'}
    python2_future_transformer_0 = Python2FutureTransformer(set_0)
    assert python2_future_transformer_0 is not None
    python2_future_transformer_0.upgrade_tree()
    python2_future_transformer_0.upgrade_tree(None)
    set_1 = ({},)
    python2_future_transformer_1 = Python2FutureTransformer(set_1)
    assert python2_future_transformer_1 is not None
    list_0 = []
    python2_future_transformer_2 = Python2FutureTransformer(list_0)
    assert python2_future_transformer_2 is not None
    tuple_0 = (python2_future_transformer_0,)
    python2_future_

# Generated at 2022-06-25 22:22:40.530634
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    test_case_0()

# Generated at 2022-06-25 22:22:44.033839
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    dict_0 = {}
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST(**dict_0)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)

# Generated at 2022-06-25 22:22:45.412525
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    python2_future_transformer_0 = Python2FutureTransformer(ast.AST())
    pass


# Generated at 2022-06-25 22:22:53.223485
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    dict_0 = {}
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST(**dict_0)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    module_x_var_2 = python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:23:01.460486
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    dict_0 = {}
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST(**dict_0)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    a_s_t_1 = module_0.AST(**dict_0)
    python2_future_transformer_1 = Python2FutureTransformer(a_s_t_1)
    pass



if __name__ == '__main__':
    import pytest
    pytest.main()

# Generated at 2022-06-25 22:23:37.467556
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    dict_0 = {}
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST(**dict_0)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    assert type(module_x_var_1) == module_0.Module
    assert module_x_var_1.body == []
    assert module_x_var_1.type_ignores == []
    assert module_x_var_1.lineno == 0
    assert module_x_var_1.col_offset == 0

# Generated at 2022-06-25 22:23:45.570612
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import copy
    import sys
    import types
    import typing
    import unittest
    import unittest.mock as mock

    import _ast

    from textwrap import dedent

    class Dummy_Python2FutureTransformer(
        Python2FutureTransformer
    ):
        _tree_changed = False

        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        @property
        def tree_changed(self):
            return self._tree_changed

        @tree_changed.setter
        def tree_changed(self, value):
            self._tree_changed = value

        def generic_visit(self, node):
            return self.generic_visit(node)


# Generated at 2022-06-25 22:23:50.146119
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    dict_0 = {}
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST(**dict_0)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:23:54.071052
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    dict_0 = {}
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST(**dict_0)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:23:57.385138
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    dict_0 = {}
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST(**dict_0)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    a_s_t_1 = module_0.AST(**dict_0)


# Generated at 2022-06-25 22:24:05.368513
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    global a_s_t_0, module_x_var_0
    # Assign values to local variables
    a_s_t_0 = module_0.AST()
    module_x_var_0 = module_0.Module()
    # Create an instance of class 'Python2FutureTransformer'
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    # Assign to 'a_s_t' field of 'python2_future_transformer_0' instance
    python2_future_transformer_0.a_s_t = a_s_t_0
    # Assign to 'python_version' field of 'python2_future_transformer_0' instance
    python2_future_transformer_0.python_version = python2_future_transformer

# Generated at 2022-06-25 22:24:09.114854
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    dict_0 = {}
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST(**dict_0)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:24:15.914032
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    dict_0 = {}
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST(**dict_0)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    a_s_t_1 = module_0.AST(**dict_0)
    python2_future_transformer_1 = Python2FutureTransformer(a_s_t_1)

# Generated at 2022-06-25 22:24:19.349310
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    dict_0 = {}
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST(**dict_0)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    test_case_0()

# Generated at 2022-06-25 22:24:28.143533
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = None
    try:
        python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    except Exception as exception_0:
        assert type(exception_0) is AssertionError
    assert type(python2_future_transformer_0.tree) is module_0.AST
    assert type(python2_future_transformer_0._tree_changed) is bool

# Unit tests for visit_Module()
test_case_0()

# Unit tests for visit_Assign()

# Unit tests for visit_AugAssign()

# Unit tests for visit_For()

# Unit tests for visit_While()

# Unit tests for visit_If()

# Unit tests for visit_With()

# Unit tests for visit_Raise()

# Generated at 2022-06-25 22:25:42.677760
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    try:
        test_case_0()
    except Exception as e:
        raise Exception(str(e)) from e

# Unit testing for transformer

# Generated at 2022-06-25 22:25:48.553844
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    dict_0 = {}
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST(**dict_0)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    a_s_t_1 = module_0.AST(**dict_0)
    python2_future_transformer_1 = Python2FutureTransformer(a_s_t_1)


# Generated at 2022-06-25 22:25:51.711275
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    dict_0 = {}
    a_s_t_0 = module_0.AST(**dict_0)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)


# Generated at 2022-06-25 22:25:56.534519
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    dict_0 = {}
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST(**dict_0)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    assert module_x_var_1.body[0].names[0].name == 'absolute_import'

# Generated at 2022-06-25 22:26:00.699805
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    dict_0 = {}
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST(**dict_0)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    assert isinstance(module_x_var_1, module_0.Module)


# Generated at 2022-06-25 22:26:02.853988
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert isinstance(Python2FutureTransformer
                      (
                          typed_ast._ast3.AST
                      ), Python2FutureTransformer)

# Built-in fixtures
# test_case_0()
# test_Python2FutureTransformer()

# Generated at 2022-06-25 22:26:11.312029
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    dict_0 = {}
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST(**dict_0)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:26:14.213726
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    dict_0 = {}
    a_s_t_0 = module_0.AST(**dict_0)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)


# Generated at 2022-06-25 22:26:20.211262
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    dict_0 = {}
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST(**dict_0)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    a_s_t_1 = module_0.AST(**dict_0)
    python2_future_transformer_1 = Python2FutureTransformer(a_s_t_1)


# Generated at 2022-06-25 22:26:29.322272
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    dict_0 = {}
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST(**dict_0)
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    a_s_t_1 = module_0.AST(**dict_0)
    python2_future_transformer_1 = Python2FutureTransformer(a_s_t_1)