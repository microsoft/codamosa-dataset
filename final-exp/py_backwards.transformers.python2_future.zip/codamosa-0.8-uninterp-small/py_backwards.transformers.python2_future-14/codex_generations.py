

# Generated at 2022-06-25 22:18:17.359815
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_1 = module_0.Module()
    python2_future_transformer_1 = Python2FutureTransformer(a_s_t_1)
    python2_future_transformer_1.visit_Module(a_s_t_1)

# Generated at 2022-06-25 22:18:26.444538
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Imports
    import typed_ast._ast3 as module_0
    import typed_ast.ast3 as module_1
    import astor.code_gen as module_2
    import pprint as module_3
    import sys as module_4
    import io as module_5
    import random as module_6
    import unittest as module_7
    from io import StringIO as class_0
    from unittest import mock as class_1
    from unittest.mock import patch as class_2
    from unittest import TestCase as class_3
    # Declaration of variables
    a_s_t_0 = module_0.AST()
    node_0 = module_1.Module()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)

   

# Generated at 2022-06-25 22:18:27.492267
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert 1 == 1


# Generated at 2022-06-25 22:18:36.756464
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    assert 'target' in dir(python2_future_transformer_0)
    assert 'checks_applied' in dir(python2_future_transformer_0)
    assert 'summary' in dir(python2_future_transformer_0)
    assert 'visit_Module' in dir(python2_future_transformer_0)
    assert 'visit' in dir(python2_future_transformer_0)
    assert 'generic_visit' in dir(python2_future_transformer_0)
    assert 'visit_dict' in dir(python2_future_transformer_0)

# Generated at 2022-06-25 22:18:42.744323
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    python2_future_transformer_0.visit_Module(a_s_t_0.Module(body=[a_s_t_0.Expr(value=a_s_t_0.Str(s='hello'))]))

# Generated at 2022-06-25 22:18:45.071828
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)

# Generated at 2022-06-25 22:18:53.460328
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_0_0 = module_0.Module([], module_0.FixMe)
    module_0_1 = python2_future_transformer_0.visit(module_0_0)
    assert len(module_0_1.body) == 4
    module_0_2 = module_0_1.body[0]
    assert type(module_0_2) is module_0.ImportFrom
    assert module_0_2.module == '__future__'
    assert len(module_0_2.names) == 1
    assert module_0_2.names[0].name == 'absolute_import'
    assert module_0_

# Generated at 2022-06-25 22:18:58.743892
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    another_s_t_0 = module_0.AST()
    python2_future_transformer_1 = Python2FutureTransformer(another_s_t_0)


# Generated at 2022-06-25 22:19:01.769980
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 22:19:06.358876
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # Case 1:
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 22:19:13.008124
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Setup
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    # Exercise
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    # Verify
    assert True

# Generated at 2022-06-25 22:19:15.634184
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    def test_case_0():
        a_s_t_0 = module_0.AST()
        python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)

# Generated at 2022-06-25 22:19:18.941992
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_0 = module_0.Module()
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    asse

# Generated at 2022-06-25 22:19:21.910774
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)



# Generated at 2022-06-25 22:19:26.528343
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:19:29.771524
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # Code fragment to test constructor
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)


# Generated at 2022-06-25 22:19:35.931622
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Create instance
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    # Call method
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    # Check results
    assert isinstance(module_x_var_1, ast.Module)

# Generated at 2022-06-25 22:19:44.799237
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import typed_ast._ast3 as module_0
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    assert len(module_x_var_1.body) == len(imports.get_body(future='__future__'))
    assert imports.get_body(future='__future__')[0] == module_x_var_1.body[0]
    assert imports.get_body(future='__future__')[1] == module_x_var_1.body[1]
   

# Generated at 2022-06-25 22:19:52.251711
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    assert module_x_var_1 is not None
    assert module_x_var_1.body is not None
    assert len(module_x_var_1.body) == 4

# Generated at 2022-06-25 22:19:54.483304
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)



# Generated at 2022-06-25 22:20:01.793391
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:20:10.792131
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
  from typed_ast._ast3 import Module
  from typed_ast.tests import test_future_transformer
  from typed_ast import ast3 as ast
  module = Module()
  a_s_t_0 = ast.AST()
  python2_future_transformer = test_future_transformer.Python2FutureTransformer(a_s_t_0)
  module_1 = python2_future_transformer.visit_Module(module)
  assert isinstance(module_1, ast.Module) and isinstance(module_1.body, ast.stmt) and module_1.body.__class__.__name__ == 'ImportFrom' and isinstance(module_1.body.names, ast.expr) and len(module_1.body.names) == 4 and module_1.body.names[0].__class__

# Generated at 2022-06-25 22:20:14.245663
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_var_0 = module_0.AST()
    python2_future_transformer_var_0 = Python2FutureTransformer(a_s_t_var_0)

# Generated at 2022-06-25 22:20:18.452174
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
  Python2FutureTransformer_0 = Python2FutureTransformer(None)
  module_x_var_0 = module_0.Module()
  module_x_var_1 = Python2FutureTransformer_0.visit_Module(module_x_var_0)
  assert module_x_var_1 == module_x_var_0

# Generated at 2022-06-25 22:20:25.512755
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Assign
    module_x = 'from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\nfrom future import generators\n\nclass Foo: pass\n'
    expected = 'from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\nfrom future import absolute_import\nfrom future import division\nfrom future import print_function\nfrom future import unicode_literals\nfrom future import generators\n\nclass Foo: pass\n'
    # Act
    actual = Python2FutureTransformer(ast.parse(module_x)).visit(ast.parse(module_x))
    # Assert

# Generated at 2022-06-25 22:20:29.526692
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_0 = module_0.Module()
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:20:34.394362
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    test_case_0()


# Generated at 2022-06-25 22:20:37.800352
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_1 = module_0.AST()
    python2_future_transformer_1 = Python2FutureTransformer(a_s_t_1)
    assert python2_future_transformer_1 is not None, "instance was not created"

# Generated at 2022-06-25 22:20:43.717755
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    assert python2_future_transformer_0.tree == a_s_t_0
    assert python2_future_transformer_0.target == (2, 7)
    assert python2_future_transformer_0.__class__.__name__ == 'Python2FutureTransformer'


# Generated at 2022-06-25 22:20:46.394621
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)


# Generated at 2022-06-25 22:20:57.293734
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # test that an exception is raised if the ast argument to the constructor is not a typed_ast.ast3.AST
    with pytest.raises(TypeError):
        Python2FutureTransformer(a_s_t_0=module_0.Module())


# Generated at 2022-06-25 22:21:03.583369
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    # module_0.Module.body (line 5)
    assert_equal(len(module_x_var_1.body), len(imports.get_body(future='__future__')))

# Generated at 2022-06-25 22:21:08.099675
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass



# Generated at 2022-06-25 22:21:14.060902
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:21:14.852081
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    test_case_0()

# Generated at 2022-06-25 22:21:20.168891
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)


# Generated at 2022-06-25 22:21:31.769508
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    with pytest.raises(AssertionError):
        module_x_var_2 = python2_future_transformer_0.visit_Module(module_x_var_1)
    try:
        module_x_var_2 = python2_future_transformer_0.visit_Module(module_x_var_1)
    except AssertionError:
        module_x_var_2 = module_0.Module()


# Generated at 2022-06-25 22:21:32.293820
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass

# Generated at 2022-06-25 22:21:35.773670
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    assert python2_future_transformer_0._future_imports is None
    assert python2_future_transformer_0._tree_changed is False

# Generated at 2022-06-25 22:21:36.722306
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert True


# Generated at 2022-06-25 22:21:55.293132
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    assert python2_future_transformer_0._tree_changed == False
    assert python2_future_transformer_0.tree == a_s_t_0


# Generated at 2022-06-25 22:22:00.110176
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import ast
    # Test init without any param
    python2_future_transformer_0 = Python2FutureTransformer()
    assert type(python2_future_transformer_0._tree) == ast.AST
    # Test init with a param ast.AST
    python2_future_transformer_1 = Python2FutureTransformer(ast.AST())
    assert type(python2_future_transformer_1._tree) == ast.AST


# Generated at 2022-06-25 22:22:04.374202
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    try:
        test_case_0()
    except:
        return False
    else:
        return True

if __name__ == '__main__':
    if test_Python2FutureTransformer_visit_Module():
        print('Test passed')
    else:
        print('Test failed')

# Generated at 2022-06-25 22:22:08.580923
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:22:09.424828
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    test_case_0()

# Generated at 2022-06-25 22:22:10.205343
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    pass



# Generated at 2022-06-25 22:22:13.135191
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    with raises(ValueError):
        python2_future_transformer_0 = Python2FutureTransformer(python2_future_transformer_0)

if __name__ == '__main__':
    import sys
    sys.exit(pytest.main(args=[__file__]))

# Generated at 2022-06-25 22:22:17.962564
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:22:21.627220
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    assert(python2_future_transformer_0.tree == a_s_t_0)

# Generated at 2022-06-25 22:22:25.487540
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)


# Generated at 2022-06-25 22:23:00.173658
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)

# Generated at 2022-06-25 22:23:01.043850
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    test_case_0()

# Generated at 2022-06-25 22:23:03.951374
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)


# Generated at 2022-06-25 22:23:08.346595
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # arrange
    module_x_0 = ast.Module()
    
    # act
    python2_future_transformer_0 = Python2FutureTransformer()
    module_x_1 = python2_future_transformer_0.visit_Module(module_x_0)
    
    # assert
    assert module_x_1 == module_x_0

# Generated at 2022-06-25 22:23:11.371445
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)


# Generated at 2022-06-25 22:23:18.905576
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    module_x_var_2 = module_0.Module()
    a_s_t_1 = module_0.AST()
    python2_future_transformer_1 = Python2FutureTransformer(a_s_t_1)
    module_x_var_3 = python2_future_transformer_1.visit_Module(module_x_var_2)

# Generated at 2022-06-25 22:23:19.949695
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass



# Generated at 2022-06-25 22:23:26.433459
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    assert isinstance(module_x_var_0, ast.Module)
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)
    assert isinstance(module_x_var_1, ast.Module)

# Generated at 2022-06-25 22:23:27.227704
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    test_case_0()



# Generated at 2022-06-25 22:23:28.314408
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Do something
    # test_case_0()
    pass

# Generated at 2022-06-25 22:24:39.000843
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_0.Module()
    module_0.AST()
    Python2FutureTransformer()
    test_case_0()

import sys


# Generated at 2022-06-25 22:24:40.480343
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    test_case_0()

# vim: set tabstop=8 softtabstop=0 expandtab ai shiftwidth=4 smarttab

# Generated at 2022-06-25 22:24:44.239261
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():

    # Arrange
    module_x_var_1 = module_0.Module()
    a_s_t_0 = module_0.AST()

    # Act
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)

    # Assert
    assert python2_future_transformer_0 is not None


# Generated at 2022-06-25 22:24:45.284200
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    test_case_0()
    
    

# Generated at 2022-06-25 22:24:46.295876
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    test_case_0()

import unittest


# Generated at 2022-06-25 22:24:47.831551
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a = ast.Module()
    b = Python2FutureTransformer(a)
    c = b.visit_Module(a)

# Generated at 2022-06-25 22:24:48.552348
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    test_case_0()

# Generated at 2022-06-25 22:24:56.513294
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Setup
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    method_test_0 = python2_future_transformer_0.visit_Module(module_x_var_0)
    method_test_1 = module_0.Module()
    
    
    # Testing if the returned value from the method equals to the expected
    assert method_test_0 == method_test_1
    
    # Testing the type of the returned value from the method
    assert isinstance(method_test_0, module_0.Module)

import typed_ast.ast3 as module_0


# Generated at 2022-06-25 22:24:59.080417
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
	a_s_t_0 = module_0.AST()
	python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)


# Generated at 2022-06-25 22:25:02.336504
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

# Generated at 2022-06-25 22:27:44.970225
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a_s_t_var_0 = module_0.AST()
    python2_future_transformer_var_0 = Python2FutureTransformer(a_s_t_var_0)
    assert((python2_future_transformer_var_0._tree_changed) == False)
    assert((python2_future_transformer_var_0._tree) == a_s_t_var_0)
    assert((python2_future_transformer_var_0.target) == (2, 7))


# Generated at 2022-06-25 22:27:45.556162
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # Test case 0
    test_case_0()

# Generated at 2022-06-25 22:27:49.804048
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():

    # Assert isinstance(<object>, <type>)
    assert isinstance(Python2FutureTransformer, type)

    # Assert hasattr(<object>, <attribute>)
    assert hasattr(Python2FutureTransformer, "visit_Module")


# Generated at 2022-06-25 22:27:57.669830
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import typed_ast._ast3 as module_0
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    assert python2_future_transformer_0 is not None
    module_0_var_0 = module_0.Module()
    assert module_0_var_0 is not None
    module_x_var_0 = python2_future_transformer_0.visit_Module(module_0_var_0)
    assert module_x_var_0 is not None
    assert len(module_x_var_0.body) == 4
    assert isinstance(module_x_var_0.body[0], module_0.ImportFrom)

# Generated at 2022-06-25 22:27:58.529184
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass


# Generated at 2022-06-25 22:28:02.197549
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

test_c

# Generated at 2022-06-25 22:28:04.357221
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    ast = module_0.AST()
    node = module_0.Module()
    transformer = Python2FutureTransformer(ast)
    transformer.visit_Module(node)
    assert transformer._tree_changed

# Generated at 2022-06-25 22:28:06.102360
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    python2_future_transformer_0 = Python2FutureTransformer()
    python2_future_transformer_0 = Python2FutureTransformer(typed_ast.AST())


# Generated at 2022-06-25 22:28:10.847224
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import typed_ast._ast3 as module_0
    module_x_var_0 = module_0.Module()
    a_s_t_0 = module_0.AST()
    python2_future_transformer_0 = Python2FutureTransformer(a_s_t_0)
    module_x_var_1 = python2_future_transformer_0.visit_Module(module_x_var_0)

import unittest
