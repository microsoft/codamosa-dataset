

# Generated at 2022-06-12 03:39:50.060679
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    class CustomNodeTransformer(Python2FutureTransformer):
        _tree_changed = False
        _changed_trees = []
        _orig_tree = None

        def generic_visit(self, node):
            if self._tree_changed:
                self._changed_trees.append(copy.deepcopy(node))

            return ast.NodeTransformer.generic_visit(self, node)

        def __init__(self, orig_tree):
            self._tree_changed = False
            self._orig_tree = copy.deepcopy(orig_tree)
            self._changed_trees = []

    target = (2, 7)

# Generated at 2022-06-12 03:39:51.646956
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor

# Generated at 2022-06-12 03:40:00.288610
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Case 1: already has future imports
    code = "from __future__ import division\n1 / 2 == 0.5\n"
    tree = ast3.parse(code)
    Python2FutureTransformer().visit(tree)
    assert(ast3.dump(tree) == code)

    # Case 2: just add imports
    code = "1 / 2 == 0.5\n"
    tree = ast3.parse(code)
    Python2FutureTransformer().visit(tree)
    assert(ast3.dump(tree) == imports.get_code(future='__future__') + code)

# Generated at 2022-06-12 03:40:06.213766
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..loader import CodeLoader

    input = """
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        def foo(): pass
    """
    loader = CodeLoader(StringIO(input))
    tree = loader.get_ast(2)
    new_tree = Python2FutureTransformer().visit(tree)
    assert Python2FutureTransformer._tree_changed is True
    assert Python2FutureTransformer._tree_changed is True

# Generated at 2022-06-12 03:40:09.684812
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast

    transformer = Python2FutureTransformer()
    source = """def foo(): pass\n"""

# Generated at 2022-06-12 03:40:10.873613
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    # Code before transform must be:

# Generated at 2022-06-12 03:40:19.641863
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_test_module
    from ..utils.generic import pretty_format_ast

    source = """
    module_body_1
    module_body_2
    """
    expected = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    
    
    module_body_1
    module_body_2
    """
    target_2_7 = Python2FutureTransformer.target_version
    target_ast = make_test_module(source, version=target_2_7)

    target_ast_2 = Python2FutureTransformer().visit(target_ast)

    expected_ast = make_test_module(expected, version=target_2_7)


# Generated at 2022-06-12 03:40:24.727782
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse('assert True')
    o = Python2FutureTransformer()
    o.visit(node)
    assert ast.dump(node) == ast.dump(ast.parse('''
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

assert True
    '''))

# Generated at 2022-06-12 03:40:26.007885
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor

# Generated at 2022-06-12 03:40:36.080659
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import parse
    from .testutils import get_visitor_results
    from .base import BaseNodeTransformer, TransformError, PythonCompatibilityVisitor
    from .trace_line import LineTraceTransformer

    code = 'a = 1\nprint(a)\n'
    expected_code = 'from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n\na = 1\nprint(a)\n'
    expected_compat_result = BaseNodeTransformer.TransformResult(
        changed = True,
        code = expected_code,
        tree = parse(expected_code, '<test>')
    )

    node = parse(code)

# Generated at 2022-06-12 03:40:46.070026
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast

    actual_input = ast.Module(
        body=[
            ast.Expr(value=ast.Str(s='Hello world!')),
        ]
    )
    expected_output = ast.Module(
        body=[
            ast.ImportFrom(
                module='__future__',
                names = [
                    ast.alias(name='absolute_import', asname=None),
                    ast.alias(name='division', asname=None),
                    ast.alias(name='print_function', asname=None),
                    ast.alias(name='unicode_literals', asname=None),
                ],
                level=0,
            ),
            ast.Expr(value=ast.Str(s='Hello world!')),
        ]
    )
    actual_output = Python2Future

# Generated at 2022-06-12 03:40:51.453336
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a = ast.parse("x = 1")
    t = Python2FutureTransformer()
    t.visit(a)
    assert ast.dump(a) == "from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n\nx = 1\n"

# Generated at 2022-06-12 03:40:52.411147
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-12 03:40:56.842297
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast.ast3 import parse
    from typed_ast.ast3 import dump

    a = Python2FutureTransformer()
    a.visit(parse('x=0'))
    assert dump(a.root)=='from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n\nx = 0'

# Generated at 2022-06-12 03:41:06.418451
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # Given
    transformer = Python2FutureTransformer()
    # When
    result = transformer.transpile_path('./programs/python2.py')
    # Then
    assert result == 'from __future__ import absolute_import\n'\
                     'from __future__ import division\n'\
                     'from __future__ import print_function\n'\
                     'from __future__ import unicode_literals\n'\
                     '\n'\
                     'test_variable = 100\n'\
                     '\n'\
                     'print(test_variable)\n'\
                     'print(test_variable / 2)\n'\
                     'print(int(test_variable / 2))\n'

# Generated at 2022-06-12 03:41:07.935738
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    btt = Python2FutureTransformer()
    assert btt



# Generated at 2022-06-12 03:41:09.681469
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Unit test for constructor of class Python2FutureTransformer."""
    assert Python2FutureTransformer(None, None, None)

# Generated at 2022-06-12 03:41:19.671734
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    """Unit test for method visit_Module of class Python2FutureTransformer"""
    import sys
    import io
    import ast
    from python2to3.utils.auto_namedtuple import auto_namedtuple
    from python2to3.utils.source_code_generator import SourceCodeGenerator
    from python2to3.utils.source_code_reader import SourceCodeReader
    from python2to3.utils.visitor_generator import VisitorGenerator
    
    source_code_reader = SourceCodeReader()
    source_code_generator = SourceCodeGenerator()
    visitor_generator = VisitorGenerator()

    source_code_generator.indentation = '    '
    source_code_generator.backslash = True

    visitor_generator.indentation = '    '

    source_code

# Generated at 2022-06-12 03:41:24.411958
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor
    code = """def x():
            pass"""
    tree = astor.parse_file(code)
    node_transformer = Python2FutureTransformer(tree)
    res = astor.to_source(node_transformer.tree)

# Generated at 2022-06-12 03:41:30.114681
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    print("test_Python2FutureTransformer")
    transformer = Python2FutureTransformer()
    tree = ast.parse('print("hello")')
    transformed_tree = transformer.visit(tree)
    assert transformed_tree != tree
    code = compile(transformed_tree, '<string>', 'exec')
    assert code is not None
    print(code)


if __name__ == "__main__":
    test_Python2FutureTransformer()

# Generated at 2022-06-12 03:41:38.370535
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Module, Assign, Load, Name
    
    transformer = Python2FutureTransformer()
    node = Module(body=[])
    result = transformer.visit(node)
    expected = Module(body=imports.get_body(future='__future__'))
    assert ast.dump(result) == ast.dump(expected)

# Generated at 2022-06-12 03:41:44.656141
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    source = """\
# -*- coding: utf-8 -*-
# comment
print('hello')
"""
    expected = """\
# -*- coding: utf-8 -*-
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
# comment
print('hello')
"""
    result = Python2FutureTransformer().visit(ast.parse(source))
    assert expected == astor.to_source(result)

# Generated at 2022-06-12 03:41:48.174612
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()

    module = ast.Module(body=[])
    expected = ast.Module(body=imports.get_body())  # type: ignore

    actual = transformer.visit_Module(module)  # type: ignore

    assert_equal(actual, expected)

# Generated at 2022-06-12 03:41:57.300867
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor
    import ast

# Generated at 2022-06-12 03:42:06.878422
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse('')
    tf = Python2FutureTransformer()
    result = tf.visit_Module(node)
    expected = ast.Module(body=[
        ast.ImportFrom(module='__future__', names=[
            ast.alias(name='absolute_import', asname=None),
            ast.alias(name='division', asname=None),
            ast.alias(name='print_function', asname=None),
            ast.alias(name='unicode_literals', asname=None)
        ], level=0)
    ])
    assert are_ast_nodes_deep_equal(result, expected)

    # Test that body is prepended, not appended
    tf = Python2FutureTransformer()
    node = ast.parse('a = 1')

# Generated at 2022-06-12 03:42:09.131384
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    trans = Python2FutureTransformer()
    assert trans._tree_changed == False
    assert trans.visit(None) is None


# Generated at 2022-06-12 03:42:14.311747
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.unparse import Unparser
    from .test_base import BaseAstNodeTest
    from .test_base import BaseSnippetTest


    class Python2FutureTransformerTest(BaseAstNodeTest, BaseSnippetTest):
        transformer = Python2FutureTransformer

    code = """
    class a(object):
        pass
    """
    Python2FutureTransformerTest.test(code)

# Generated at 2022-06-12 03:42:16.293393
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert(isinstance(transformer, Python2FutureTransformer))


# Generated at 2022-06-12 03:42:17.249228
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-12 03:42:26.316807
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = ast.Module()
    module.body = []
    transformer = Python2FutureTransformer()
    module = transformer.visit(module)
    assert isinstance(module, ast.Module)
    assert len(module.body) == 4
    assert isinstance(module.body[0], ast.ImportFrom)
    assert module.body[0].module == '__future__'
    assert module.body[0].names[0].name == 'absolute_import'
    assert isinstance(module.body[1], ast.ImportFrom)
    assert module.body[1].module == '__future__'
    assert module.body[1].names[0].name == 'division'
    assert isinstance(module.body[2], ast.ImportFrom)
    assert module.body[2].module == '__future__'
    assert module

# Generated at 2022-06-12 03:42:38.792412
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = ast.parse("x = 3")
    transformer = Python2FutureTransformer()
    module = transformer.visit(module)
    assert transformer._tree_changed == True    # type: ignore
    assert transformer.target == (2, 7)
    assert module == ast.parse('''\
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
x = 3''')

# Generated at 2022-06-12 03:42:48.620900
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()
    tree = transformer.visit(ast.parse(DUMMY_PYTHON_CODE))
    expected = ast.parse(EXPECTED_PYTHON_CODE)
    assert ast.dump(tree) == ast.dump(expected)


DUMMY_PYTHON_CODE = \
"""
import tensorflow as tf

if __name__ == '__main__':
    hello = tf.constant('Hello, TensorFlow!')
    sess = tf.Session()
    print(sess.run(hello))
"""


# Generated at 2022-06-12 03:42:56.856271
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse('var = 1')
    transformer = Python2FutureTransformer()
    new_node = transformer.visit(node)
    assert transformer._tree_changed

    expected = [
        ast.ImportFrom(module='future', names=[
            ast.alias(name='absolute_import', asname=None),
            ast.alias(name='division', asname=None),
            ast.alias(name='print_function', asname=None),
            ast.alias(name='unicode_literals', asname=None)
        ], level=0),
        ast.Assign(targets=[ast.Name(id='var', ctx=ast.Store())], value=ast.Num(n=1))
    ]
    assert list(new_node.body) == expected

# Generated at 2022-06-12 03:42:57.821686
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()


# Generated at 2022-06-12 03:43:05.604638
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import textwrap
    source = textwrap.dedent("""
    import pandas as pd
    """)
    target = textwrap.dedent("""
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    import pandas as pd
    """)
    fake_file = io.StringIO(source)
    fake_file.name = '<fake input>'
    tree = ast.parse(fake_file.read())
    result = Python2FutureTransformer().visit(tree)
    assert astunparse.unparse(result).strip() == target.strip()

# Generated at 2022-06-12 03:43:07.768803
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)
    assert transformer.generic_visit

# Generated at 2022-06-12 03:43:11.267123
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """
    Creates an instance of Python2FutureTransformer and verifies that it is not None.
    """
    transformer = Python2FutureTransformer()
    assert transformer is not None

# Unit tests for transformation of import statements

# Generated at 2022-06-12 03:43:20.823345
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():

    def check(node: ast.AST, expected: ast.AST):
        t = Python2FutureTransformer()
        t.visit(node)
        assert t._tree_changed is True
        assert ast.dump(node, include_attributes=False) == ast.dump(expected, include_attributes=False)

    node = ast.Module(body=[])

# Generated at 2022-06-12 03:43:25.208940
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from .test_helpers import pretty
    from ..utils.common import get_test_data

    filename = get_test_data('data/sample2.py')
    with open(filename) as f:
        sample = f.read()

    print(sample)
    tree = ast.parse(sample)
    tree = Python2FutureTransformer().visit(tree)
    print(pretty(tree))

# Generated at 2022-06-12 03:43:27.111906
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import ast
    import sys
    from typed_ast import encode_file, decode_file


# Generated at 2022-06-12 03:43:43.492438
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    print("\n### Testing constructor of class Python2FutureTransformer ###\n")
    py2_future = Python2FutureTransformer()
    print("instance of Python2FutureTransformer created")

# Generated at 2022-06-12 03:43:50.926890
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    actual = """\
    def foo():
        return 2
    """.strip()
    expected = """\
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    def foo():
        return 2
    """.strip()

    actual_ast = ast.parse(actual)
    expected_ast = ast.parse(expected)
    Python2FutureTransformer().visit(actual_ast)
    assert ast.dump(expected_ast) == ast.dump(actual_ast)


# Generated at 2022-06-12 03:43:52.197891
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.target == (2, 7)


# Generated at 2022-06-12 03:43:54.220484
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor

# Generated at 2022-06-12 03:43:55.518166
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-12 03:44:02.353096
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from tests.utils import roundtrip
    from typed_ast.ast3 import Module
    from typed_ast.ast3 import parse
    tree = parse('print(None)')
    transformer = Python2FutureTransformer()
    tree = transformer.visit(tree)  # type: ignore
    assert isinstance(tree, Module)
    expected_source = """from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    print(None)
    """
    assert roundtrip(tree, target_version=transformer.target) == expected_source

# Generated at 2022-06-12 03:44:08.426062
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Given
    node = ast.parse('''
    print("Hello")
    ''')

    # When
    transformer = Python2FutureTransformer()
    module      = transformer.visit(node)

    # Then
    assert transformer.tree_changed is True
    expected = ast.parse('''
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
print("Hello")
''')
    assert ast.dump(module) == ast.dump(expected)

# Generated at 2022-06-12 03:44:17.070421
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import unittest
    import astor
    import sys
    import ast
    from python_modernizer.transformers import Python2FutureTransformer

    class MockModule(ast.Module):
        def __init__(self, body: list, **kwargs):
            super().__init__(body=body, **kwargs)

    class TestPython2FutureTransformer(unittest.TestCase):
        def setUp(self):
            self.transformer = Python2FutureTransformer()

        def test_simple(self):
            node = MockModule([ast.Expr(
                value=ast.Call(
                    func=ast.Name(id='print', ctx=ast.Load()),
                    args=[ast.Str(s='Hello')],
                    keywords=[]
                )
            )], type_ignores=[ast.Node])


# Generated at 2022-06-12 03:44:25.683785
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    engine = Python2FutureTransformer()
    code_to_transform = """\
import sys
print(sys.version)
"""
    node = ast.parse(code_to_transform)
    new_node = engine.visit(node)

# Generated at 2022-06-12 03:44:30.093400
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    x = Python2FutureTransformer()
    # print("x =", x)


# Unit test:
# python3 -m unittest codetransformer.transformers.backports.python2.test_Python2FutureTransformer
if __name__ == "__main__":
    import unittest
    unittest.main()

# Generated at 2022-06-12 03:45:02.012822
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..unparse import Unparser
    module = ast.parse("")
    assert Unparser(module) == ''
    transformer = Python2FutureTransformer(module)
    result = transformer.visit(module)
    assert Unparser(result) == '''\
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
'''

# Generated at 2022-06-12 03:45:07.942142
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from bark.runtime.commons.visitor import BaseNodeVisitor
    
    class MockTransformer(BaseNodeTransformer):
        def __init__(self):
            pass

        def visit_Module(self, node):
            return 'test'

    transformer = MockTransformer()
    node = ast.parse('a = 1')

    result = transformer.visit(node)

    assert result == 'test'


# Generated at 2022-06-12 03:45:12.758334
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..convert import CONVERTERS
    from ..convert import PythonCode

    code = PythonCode.from_string('print(1+1)')
    trans = CONVERTERS[(2, 7)]
    assert isinstance(trans, Python2FutureTransformer)
    assert trans.target == (2, 7)
    code.ast = trans.visit(code.ast)
    print(code.to_source())

# Generated at 2022-06-12 03:45:13.596687
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor

# Generated at 2022-06-12 03:45:16.440565
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'

if __name__ == '__main__':
    import pytest  # type: ignore
    pytest.main([__file__])

# Generated at 2022-06-12 03:45:21.360580
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..transformer import Transformer
    from ..transformers import list_transformers
    from ..utils.fixtures import AST_FUTURE, AST_FUTURE_2
    from ..utils.visitor import dump

    t = Transformer(list_transformers(range(3)))
    t.register_transformer(3, Python2FutureTransformer)
    assert dump(t.visit(AST_FUTURE)) == dump(AST_FUTURE_2)

# Generated at 2022-06-12 03:45:26.521320
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    code = '''
            def f():
                pass
            '''
    expected_code = '''
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
            
            
            def f():
                pass
            '''
    assert Python2FutureTransformer().visit(code) == expected_code

# Generated at 2022-06-12 03:45:34.271956
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    node = ast.parse('')
    transformer = Python2FutureTransformer()
    res = transformer.visit(node)

# Generated at 2022-06-12 03:45:36.539956
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    obj = Python2FutureTransformer()
    assert obj.target == (2, 7)
    assert obj._tree_changed is False


# Generated at 2022-06-12 03:45:37.205529
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass

# Generated at 2022-06-12 03:46:48.888475
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import typed_ast.ast3 as ast
    from python.snippet.transformation import Python2FutureTransformer
    from python.snippet.utils.snippet import snippet
    from python.snippet.utils.codegen import to_source
    
    @snippet
    def test_source():
        print('abc')

    expected_source = """\
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

print('abc')
"""
    def verify(node: ast.AST) -> str:
        node = Python2FutureTransformer().visit(node)  # type: ignore
        source = to_source(node)
        assert source == expected_source
        return source
    

# Generated at 2022-06-12 03:46:50.013046
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer(None, None)

# Generated at 2022-06-12 03:46:57.354687
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import sys
    import os
    sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
    from utils.ast_builder import build_ast
    from utils.snippet import snippet_to_str
    
    node = build_ast("x = 2")
    transformer = Python2FutureTransformer()
    new_node = transformer.visit(node)
    assert snippet_to_str(new_node.body) == snippet_to_str(imports.get_body(future='__future__') + node.body)

# Generated at 2022-06-12 03:47:05.025061
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..type_inference_programs.good_programs import hello_world_program

    # Create an instance of Python2FutureTransformer
    transformer = Python2FutureTransformer()

    # Call visit_Module on hello_world_program
    hello_world_program_transformed = transformer.visit(hello_world_program)

    # Check if hello_world_program_transformed has changed
    assert transformer._tree_changed == True

    # Check if imported features have been added
    assert hello_world_program_transformed.body[0].names[0].name == 'absolute_import'
    assert hello_world_program_transformed.body[1].names[0].name == 'division'
    assert hello_world_program_transformed.body[2].names[0].name == 'print_function'
    assert hello_world_

# Generated at 2022-06-12 03:47:10.977304
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import typed_ast.ast3 as ast

    from typed_astunparse import unparse

    from typed_python._internal.unparse import Unparser

    from .helpers import _parse, _format

    module = _parse('def foo():\n    pass\n')

    transformer = Python2FutureTransformer()
    transformer.visit(module)

    assert _format(module) == _format(_parse(imports(future='__future__') + 'def foo():\n    pass\n'))

# Generated at 2022-06-12 03:47:15.993989
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # NodeTransformer.visit_Module() should prepend module body with:
    # - four "from future import ..." statements
    # - an empty line
    # - a comment
    from .samples.python2 import fibonacci
    from .samples.python2_future import fibonacci_future
    transformer = Python2FutureTransformer()
    transformer.visit(fibonacci)
    assert transformer.get_tree() == fibonacci_future

# Generated at 2022-06-12 03:47:21.043128
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    try:
        instance = Python2FutureTransformer()
    except Exception as e:
        print(e)
        assert False
    try:
        instance.visit(None)
    except AttributeError as e:
        print(e)
        assert False
    try:
        instance.visit_Module(None)
    except AttributeError as e:
        print(e)
        assert False

# Generated at 2022-06-12 03:47:22.101945
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    x = Python2FutureTransformer()
    assert isinstance(x, BaseNodeTransformer)

# Generated at 2022-06-12 03:47:22.883850
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-12 03:47:23.958077
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()
    assert t is not None