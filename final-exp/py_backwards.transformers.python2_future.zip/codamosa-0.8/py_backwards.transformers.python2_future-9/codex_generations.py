

# Generated at 2022-06-12 03:39:49.893503
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    code = """
    def test():
        print("hello world")
    """
    tree = ast.parse(code)
    res = Python2FutureTransformer().visit(tree)
    s = astor.to_source(res)
    assert "from __future__ import absolute_import" in s

# Generated at 2022-06-12 03:39:52.770290
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer(target=(2, 7)).target == (2, 7)


# Generated at 2022-06-12 03:40:03.204018
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = ast.parse(
        "from __future__ import absolute_import\n"
        "from __future__ import division\n"
        "from __future__ import print_function\n"
        "from __future__ import unicode_literals\n"
        "\n"
        "r'''\n"
        "abc\n"
        "'''\n"
        "\n"
        "def f(x):\n"
        "    x = x + 2\n"
        "    return x\n"
        "print (f(2))"
    )
    transformer = Python2FutureTransformer()
    new_module = transformer.visit(module)
    assert transformer._tree_changed is True
    assert ast.dump(module) == ast.dump(new_module)

# Generated at 2022-06-12 03:40:04.892960
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    trans = Python2FutureTransformer()
    assert trans._tree_changed is False
    assert trans.target == (2, 7)



# Generated at 2022-06-12 03:40:12.539725
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..transforms import Transformers
    from ..utils import CompileError
    from ..utils.transformed import Transformed
    from ..utils.source import Source

    transforms = Transformers()
    transforms.add(Python2FutureTransformer)
    @transforms(Python2FutureTransformer)
    def transform_print(node: ast.Print) -> ast.FunctionDef:
        raise CompileError("trying to transform print()")

    ctx = transform_print.pytransformer.context

    source = '''
    print("hello") 

    print("hello again")
    '''
    src = Source(source)
    output = ctx.transform_source(source)
    module = output.get_ast(mode='exec')
    assert module.body[1].value.s == 'hello'

# Generated at 2022-06-12 03:40:20.696146
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import os.path
    from ..utils.utils import get_data
    from ..utils.utils import get_visitor
    from nuitka import Options

    # Set env var for nuitka options
    os.environ['NUITKA_COMPILE_STANDALONE_EXECUTABLE'] = '1'

    # Create nuitka options
    nuitka_option = Options.NuitkaOptions()

    # Get testfile
    filename = get_data(__file__, "test_sample.py")
    source_code = open(filename, 'r').read()

    # Get tree and visitor
    tree = compile(source_code, filename, "exec",
                   ast.PyCF_ONLY_AST)
    visitor = get_visitor(Python2FutureTransformer, nuitka_option)


# Generated at 2022-06-12 03:40:28.561018
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source

    class TestNodeTransformer(BaseNodeTransformer):
        @staticmethod
        def visit_Name(node: ast.Name) -> ast.Name:
            node = ast.copy_location(node, node)  # type: ignore
            node.id = node.id + "suffix"
            return node  # type: ignore

    tree = ast.parse(source)
    TestNodeTransformer().visit(tree)
    assert ast.dump(tree) == source.replace('bar', 'barsuffix').replace('baz', 'bazsuffix')



# Generated at 2022-06-12 03:40:38.375938
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .. import python_to_python
    import typed_ast.ast3 as ast

    to_strip = '\n' + ' ' * 8

    def test(s: str, expected: str) -> None:
        tree = ast.parse(s)
        visitor = Python2FutureTransformer()
        new_tree = visitor.visit(tree)
        assert python_to_python(new_tree) == (
            f'from __future__ import absolute_import, division, print_function, unicode_literals\n{expected}'
        ).replace(to_strip, '')

    test('a = 4',
         'a = 4')
    test('def f():\n    a = 4\n    print(a)',
         'def f():\n    a = 4\n    print(a)')
    test

# Generated at 2022-06-12 03:40:39.230005
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transform = Python2FutureTransformer()


# Generated at 2022-06-12 03:40:40.198209
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert not Python2FutureTransformer()._tree_changed

# Generated at 2022-06-12 03:40:42.698444
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert(True)

# Generated at 2022-06-12 03:40:43.038710
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass

# Generated at 2022-06-12 03:40:46.075987
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast

    # Given
    node = ast.Module([])
    transformer = Python2FutureTransformer()

    # When
    result = transformer.visit_Module(node)

    # Then
    assert isinstance(result, ast.Module)
    assert transformer._tree_changed
    assert len(result.body) == 4

# Generated at 2022-06-12 03:40:51.452852
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module = ast.parse("x = 1\n")
    transformer = Python2FutureTransformer()
    transformer.visit(module)
    assert str(module) == "from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\nx = 1\n"

# Generated at 2022-06-12 03:40:56.569439
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast

    # noinspection PyMethodParameters
    class Python2FutureTransformer0(Python2FutureTransformer):
        def __init__(self):
            super().__init__()
            self._tree_changed = False

    transformer = Python2FutureTransformer0()
    assert transformer._tree_changed is False
    module = ast.parse('print("Hello world")')
    module = transformer.visit(module)
    assert transformer._tree_changed is True
    assert module.body[0].value.s == '__future__'
    print(ast.dump(module))

# Generated at 2022-06-12 03:40:59.400644
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = ast.parse(
        '''
import os
hello = 'hello'
        ''')
    transformer = Python2FutureTransformer()
    transformer.visit(module)
    print(ast.dump(module))

# Generated at 2022-06-12 03:41:02.225817
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()
    module = ast.parse('print(2)')
    assert transformer.visit(module).body == imports.get_body(future='__future__') + module.body

# Generated at 2022-06-12 03:41:09.252002
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import copy
    node = ast.parse('pass')
    node1 = copy.deepcopy(node)
    Python2FutureTransformer().visit(node)  # type: ignore
    assert node1 != node
    assert ast.dump(node) == ast.dump(ast.parse('from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\npass'))

# Generated at 2022-06-12 03:41:19.300845
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module_name = 'testing'
    tree = ast.parse('')  # type: ignore
    tree.body = []
    tree.body.append(
        ast.Expr(
            ast.Call(
                ast.Name(id='print', ctx=ast.Load()),
                [ast.Str('Hello world!')],
                [],
                None,
                None
            )
        )
    )


# Generated at 2022-06-12 03:41:20.068764
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-12 03:41:25.334979
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    result = Python2FutureTransformer().visit(imports.get_ast(future='__future__'))  # type: ignore
    assert ast.dump(imports.get_ast(future='__future__')) == ast.dump(result)  # type: ignore



# Generated at 2022-06-12 03:41:27.041256
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    result = Python2FutureTransformer()
    assert isinstance(result, Python2FutureTransformer)


# Generated at 2022-06-12 03:41:34.716010
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor

    code = '''
x = 2
n = 2
while n < x:
    print(n)
    n *= 2
'''

    expected = '''
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

x = 2
n = 2
while n < x:
    print(n)
    n *= 2
'''
    tree = ast.parse(code)
    Python2FutureTransformer().visit(tree)
    result = astor.to_source(tree)
    asser

# Generated at 2022-06-12 03:41:43.906308
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .common import code_to_ast
    from ..utils.astdiff import diff
    from ..utils.snippet import snippet
    
    code_before = snippet(
        'import sys',
        '',
        '# some comment',
        'def test():',
        '    return 1',
    )
    code_after = snippet(
        'from __future__ import absolute_import',
        'from __future__ import division',
        'from __future__ import print_function',
        'from __future__ import unicode_literals',
        '',
        'import sys',
        '',
        '# some comment',
        'def test():',
        '    return 1',
    )
    node_before = code_to_ast(code_before)

# Generated at 2022-06-12 03:41:46.681621
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor
    a = ast.parse('')
    b = Python2FutureTransformer(a).visit(a)
    assert astor.to_source(b) == imports(future='__future__')

# Generated at 2022-06-12 03:41:49.059865
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    c = Python2FutureTransformer()
    assert(isinstance(c, ast.NodeTransformer))


# Generated at 2022-06-12 03:41:58.417268
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .. import ast3_transformer

    # Compile given snippet and return ast.Module
    def compile_source(source: str) -> ast.Module:
        module = compile(source, '<test_Python2FutureTransformer_visit_Module>', 'exec')
        source_code = ast3_transformer._dump_code(module)
        node = ast.parse(source_code)
        return node

    # original snippet
    source = """
    x = 1
    y = 2
    z = x + y
    """

    # transformed snippet
    # from __future__ import absolute_import
    # from __future__ import division
    # from __future__ import print_function
    # from __future__ import unicode_literals
    # x = 1
    # y = 2
    # z = x + y
   

# Generated at 2022-06-12 03:42:07.491388
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    
    module = ast.parse("print('Hello world')")

# Generated at 2022-06-12 03:42:09.066868
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)

# Generated at 2022-06-12 03:42:18.988672
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    input = ast.parse(
     """
     import sys
     
     import os
     from os.path import join, dirname
     
     print(sys.version)
     
     import future
     from future.backports import *
     
     def main():
     \tprint('Hello, World!')
     
     if __name__ == '__main__':
     \tmain()
     """
    )

# Generated at 2022-06-12 03:42:23.697318
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()
    assert t.target == (2, 7)
    assert not t._tree_changed

# Generated at 2022-06-12 03:42:28.697174
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor
    code = """
a = 1
b = 2
    """
    tree = astor.parse_file(StringIO(code))
    Python2FutureTransformer().visit(tree)
    print(astor.dump_tree(tree))
    assert astor.dump_tree(tree) == """
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
a = 1
b = 2
    """

# Generated at 2022-06-12 03:42:31.643699
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    source = '''def f():
    pass
'''

# Generated at 2022-06-12 03:42:39.194381
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import parse
    from ..compat import iter_fields, get_docstring

    tree = parse('''
    import sys

    def main():
        print("Hello world")

    if __name__ == "__main__":
        main()
    ''')
    transformer = Python2FutureTransformer()
    transformer.visit(tree)
    assert transformer.tree_changed

    # Assert that the future imports have been prepended
    tree_fields = [f for f in iter_fields(tree)]
    assert tree_fields[0][1] == imports.get_body(future='__future__')
    assert get_docstring(tree) == None

# Generated at 2022-06-12 03:42:40.031573
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()


# Generated at 2022-06-12 03:42:41.205357
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer().target == (2, 7)


# Generated at 2022-06-12 03:42:47.029780
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()
    tree = ast.parse('1+1')
    tree = transformer.visit(tree)
    expected_tree = ast.parse('''
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
1+1''')
    assert dumpAst(tree) == dumpAst(expected_tree)

# Generated at 2022-06-12 03:42:48.424766
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer._tree_changed is False

# Generated at 2022-06-12 03:42:49.679045
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()
    assert t is not None

# Generated at 2022-06-12 03:42:56.487446
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import sys
    if sys.version_info < (3, 0):
        raise ImportError("This test is only supported on Python 3")

    import astor
    input = "print('hello world')"
    transformed_to = """
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

print('hello world')
"""
    expected_ast = ast.parse(input).body
    expected_ast = Python2FutureTransformer().visit(expected_ast)
    assert astor.to_source(expected_ast).strip() == transformed_to.strip()

# Generated at 2022-06-12 03:43:10.099384
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    tree = ast.parse("print(42)")
    from ..convert import BaseConverter
    b = BaseConverter(tree)
    Python2FutureTransformer(b).visit(tree)
    assert ast.dump(tree) == imports.get_ast(future='__future__') + """Module(body=[Expr(value=Call(func=Name(id='print', ctx=Load()), args=[Num(n=42)], keywords=[]))])"""

# Generated at 2022-06-12 03:43:10.704573
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    x = Python2FutureTransformer()
    assert x  # use x

# Generated at 2022-06-12 03:43:19.803888
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import ast
    import sys
    import inspect
    import _ast as ast_original
    #from typed_ast import ast3 as ast
    import astor
    module_name = __name__
    #from ..utils.code_gen import code_gen
    from ..utils.code_gen import ident_from_module_name
    from ..utils.snippet import snippet
    
    class ModuleSnippet(snippet):
        def get_ident(self):
            return ident_from_module_name(module_name)

# Generated at 2022-06-12 03:43:25.785693
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # GIVEN
    tree = ast.parse('''\
print('Hello World!')
''')
    expected_tree = ast.parse('''\
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
print('Hello World!')
''')

    # WHEN
    transformer = Python2FutureTransformer()
    transformer.visit(tree)

    # THEN
    assert transformer._tree_changed == True
    assert ast.dump(tree) == ast.dump(expected_tree)

# Generated at 2022-06-12 03:43:34.272361
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor

    src = '''
    import os
    import sys
    print(os)
    '''

    tree = ast.parse(src)
    transformer = Python2FutureTransformer()
    tree = transformer.visit(tree)

    expected = '''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    import os
    import sys
    print(os)
    '''

    assert astor.to_source(tree) == expected

# Generated at 2022-06-12 03:43:36.243179
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.visitor import compare_ast
    from . import remove_comments_and_docstrings

    transformer = Python2FutureTransformer()

# Generated at 2022-06-12 03:43:37.077645
# Unit test for constructor of class Python2FutureTransformer

# Generated at 2022-06-12 03:43:39.572129
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()
    assert t.target == (2, 7)
    assert t.auto_prefix is False
    assert t.target_node_type is 'Module'


# Generated at 2022-06-12 03:43:44.663578
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()
    source = '# comment\n'\
             'import os\n'\
             'import sys\n'
    tree = ast.parse(source)
    transformer.visit(tree)
    expected_source = 'import __future__\n'\
                      'import os\n'\
                      'import sys\n'
    assert ast.dump(tree) == expected_source

# Generated at 2022-06-12 03:43:46.435220
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3
    # Python 3 compatible code

# Generated at 2022-06-12 03:44:03.099965
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-12 03:44:12.119041
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.fix_missing_locations(ast.parse("a = 1\nprint(a)"))
    transformer = Python2FutureTransformer()
    new_node = transformer.visit(node)
    assert transformer._tree_changed == True

# Generated at 2022-06-12 03:44:13.174234
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor

# Generated at 2022-06-12 03:44:18.080233
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .helper import get_tree
    from .helper import print_tree
    
    tree = get_tree("a = 1\n")
    transformer = Python2FutureTransformer(tree)
    transformer.visit(tree)
    
    print_tree(tree)
    assert transformer._tree_changed
    assert tree.body == imports.get_body(future='__future__') + [ast.Assign(targets=[ast.Name(id='a', ctx=ast.Store())], value=ast.Num(n=1))]

# Generated at 2022-06-12 03:44:18.896649
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer

# Generated at 2022-06-12 03:44:24.952079
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    code1 = compile('import os', 'test', 'exec')
    tree1 = ast.parse(code1)

    code2 = compile(imports.get_source(future='__future__'), 'test', 'exec')
    tree2 = ast.parse(code2)

    transformer = Python2FutureTransformer()
    assert transformer._tree_changed is False
    transformer.visit(tree1)
    assert transformer._tree_changed is True
    # tree1 has been modified inplace
    assert ast.dump(tree1) == ast.dump(tree2)

# Generated at 2022-06-12 03:44:32.579764
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ast_analyzer.parsers import parse_expr
    from ast_analyzer.transformer import ast_wrapper

    code = \
        """
        foo = 5
        bar = 4711
        """
    node = parse_expr(code)
    node_wrapper = ast_wrapper.ASTNodeWrapper(node)
    transformer = Python2FutureTransformer()
    transformed = transformer.visit(node_wrapper)
    assert_equal(code, transformed.get_snippet(
        start_line=transformer.imports.get_start_line(),
        end_line=transformer.imports.get_end_line()
    ))

# Generated at 2022-06-12 03:44:33.831682
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'

# Generated at 2022-06-12 03:44:35.107828
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer(None).target == (2, 7)

# Generated at 2022-06-12 03:44:37.232469
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)
    assert transformer.future is None


# Generated at 2022-06-12 03:45:12.130571
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    from ..utils.fixtures import ast_module
    transformer = Python2FutureTransformer()
    node = ast_module()
    assert transformer.visit(node)

# Generated at 2022-06-12 03:45:17.484437
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    node = ast.parse(textwrap.dedent(
        """
        def foo():
            """
    ))
    expected = ast.parse(textwrap.dedent(
        """
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        def foo():
            """
    ))
    assert Python2FutureTransformer().visit(node) == expected

# Generated at 2022-06-12 03:45:26.799182
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from .base import BaseNodeTransformer
    import ast
    import textwrap

# Generated at 2022-06-12 03:45:28.173130
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    x = Python2FutureTransformer()
    assert x.target == (2, 7)



# Generated at 2022-06-12 03:45:31.647686
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    tree = ast.parse(
        "print('hello, world!')"
    )
    transformer.visit(tree)

    assert transformer.tree_changed() == True
    assert ast.dump(tree) == imports.get_tree(future='__future__') + ast.dump(tree)

# Generated at 2022-06-12 03:45:38.210567
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor

    node = ast.parse('print(42)')
    expected_node = ast.parse(textwrap.dedent(r'''
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        print(42)'''))

    tree_changed, node_transformed = Python2FutureTransformer().visit(node)

    assert astor.to_source(node_transformed) == astor.to_source(expected_node)

# Generated at 2022-06-12 03:45:47.794258
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import os
    import sys
    # Make sure to run the tests from the root directory of the project!
    sys.path.append(os.getcwd() + '/python-upgrader')
    import python_upgrader.utils.snippet_ext as snippet_ext
    snippet_ext.reload()

    import typed_ast.ast3 as ast
    import python_upgrader.visitors.Python2FutureTransformer as Python2FutureTransformer
    # Test module without docstring
    node = ast.parse(textwrap.dedent("""\
    def hi():
        print("Hello World")
    """))
    visitor = Python2FutureTransformer.Python2FutureTransformer()
    visitor.visit(node)

# Generated at 2022-06-12 03:45:54.088599
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse('x = 5')
    transformer = Python2FutureTransformer()
    output = transformer.visit(node)

    imports = ast.parse('from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n', mode='exec')
    assert ast.dump(output) == ast.dump(ast.Module(body=imports.body + node.body))
    # Make sure node has actually changed
    assert transformer._tree_changed == True

# Generated at 2022-06-12 03:45:54.883359
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor

# Generated at 2022-06-12 03:46:03.378836
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils import run_all_nodes
    from ..utils import collect_variables
    from ..utils import optimize_ast

    module = ast.parse("""\
x = 4 # A simple assignment
y = 5
""")
    module_ = run_all_nodes(
        module,
        [
            Python2FutureTransformer
        ]
    )

    expected = """\
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
x = 4 # A simple assignment
y = 5
"""
    expected = expected.split("\n")

    assert len(module_.body) == 7
    module_body = [node.body[0] for node in module_.body[:4]]

# Generated at 2022-06-12 03:47:17.824333
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module = ast.parse("print(1)")
    assert module.body[0].__class__ == ast.Expr
    module = Python2FutureTransformer.run_pipeline(module)
    assert module.body[0].__class__ == ast.ImportFrom
    assert module.body[1].__class__ == ast.ImportFrom
    assert module.body[2].__class__ == ast.ImportFrom
    assert module.body[3].__class__ == ast.ImportFrom
    assert module.body[4].__class__ == ast.ImportFrom
    assert module.body[5].__class__ == ast.Expr

# Generated at 2022-06-12 03:47:25.983268
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import_future = ast.ImportFrom(
        module='__future__',
        names=[ast.alias(name='absolute_import', asname=None)],
        level=0
    )
    import_future2 = ast.ImportFrom(
        module='__future__',
        names=[ast.alias(name='division', asname=None)],
        level=0
    )
    import_future3 = ast.ImportFrom(
        module='__future__',
        names=[ast.alias(name='unicode_literals', asname=None)],
        level=0
    )
    import_future4 = ast.ImportFrom(
        module='__future__',
        names=[ast.alias(name='print_function', asname=None)],
        level=0
    )


# Generated at 2022-06-12 03:47:31.030846
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    code = """print('hello world!')"""

    # Python 2.7
    tree = ast.parse(code)
    assert Python2FutureTransformer().visit(tree)

    # Python 3.6: should work the same, but transformer is not applied
    tree = ast.parse(code)
    assert Python2FutureTransformer().visit(tree)


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 03:47:33.888745
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from astor import to_source
    from ..utils.fixtures import future_imports  # noqa
    from ..utils.fixtures import module_tree  # noqa
    import ast

    with future_imports() as future:
        assert to_source(Python2FutureTransformer().visit(module_tree)) == future

# Generated at 2022-06-12 03:47:34.787107
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer().target == (2, 7)


# Generated at 2022-06-12 03:47:37.275066
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = ast.parse('from string import ascii_letters')
    node = Python2FutureTransformer.visit(module)
    assert isinstance(node, ast.Module)
    assert len(node.body) == 5
    assert node.body[0].names[0].name == 'absolute_import'

# Generated at 2022-06-12 03:47:40.738320
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    source = '''
x = 1
'''
    expected = '''from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

x = 1
'''
    node = ast.parse(source)
    node = Python2FutureTransformer().visit(node)
    result = astor.to_source(node)
    assert result == expected

# Generated at 2022-06-12 03:47:43.163739
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    tree = ast.parse(dedent('''
    from __future__ import division
    '''))
    Python2FutureTransformer().visit(tree)

# Generated at 2022-06-12 03:47:45.046024
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    my_transformer = Python2FutureTransformer()
    assert isinstance(my_transformer, BaseNodeTransformer)
    assert my_transformer.tree_changed == False


# Generated at 2022-06-12 03:47:52.094448
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # Arrange
    input_snippet = u'''
evens = [2,4,6,8,10]
for i in evens:
  print(i)
'''
    expected_output = u'''from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

evens = [2,4,6,8,10]
for i in evens:
  print(i)
'''
    # Act
    actual_output = Python2FutureTransformer().transform(input_snippet)

    # Assert
    assert actual_output == expected_output