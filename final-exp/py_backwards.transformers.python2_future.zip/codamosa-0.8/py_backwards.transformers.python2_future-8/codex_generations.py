

# Generated at 2022-06-12 03:39:45.608214
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():

    from ..utils.test_utils import get_test_input_output, sniffer_visit_Module
    func = Python2FutureTransformer.visit_Module.__func__
    get_test_input_output(func, module=sys.modules[__name__],
                          test_visitor=sniffer_visit_Module)

    assert Python2FutureTransformer.visit_Module.__doc__

# Generated at 2022-06-12 03:39:51.827595
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node1 = parse(imports.get_source(future='__future__'),
                  mode='exec')
    node2 = parse('import sys',
                  mode='exec')
    node3 = parse('\nprint(sys.version)',
                  mode='exec')
    init_module = ast.Module(
        body=[
            node1,
            node2,
            node3
        ]
    )
    transformer = Python2FutureTransformer(target=(2, 7))
    transformer.visit(init_module)
    assert transformer.tree_changed
    final_module = ast.Module(
        body=[
            node1,
            node2,
            node3
        ]
    )
    assert final_module == init_module

# Generated at 2022-06-12 03:39:55.288644
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import literal_eval
    from ..utils.fix_code import fix_code
    from ..transforms.fix_missing_locations import FixMissingLocations


# Generated at 2022-06-12 03:39:56.422720
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-12 03:40:01.459958
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils import round_trip
    import astunparse
    x = astunparse.unparse(round_trip(imports.get_ast(future='__future__')))
    y = astunparse.unparse(round_trip(Python2FutureTransformer.visit_Module(Python2FutureTransformer, imports.get_ast())))
    assert x == y


# Generated at 2022-06-12 03:40:04.244895
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import cStringIO
    from typed_ast import parse

    snippet = cStringIO.StringIO()
    s = snippet.getvalue()
    tree = parse(s)
    print(tree)

# Generated at 2022-06-12 03:40:12.536694
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import copy
    tree = ast.parse("for i in range(10):\n    print(i)")
    transformer = Python2FutureTransformer()
    transformer.visit(tree)
    assert transformer._tree_changed
    assert tree.body[0].__class__.__name__ == "ImportFrom"
    assert ast.dump(tree.body[0]) == (
        "ImportFrom("
        "module='__future__',"
        "names=[alias("
        "name='unicode_literals', "
        "asname=None)], "
        "level=0)"
        )

# Generated at 2022-06-12 03:40:20.695955
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast.ast3 import Module, Str
    module = Module(body=[])
    transformer = Python2FutureTransformer()
    result = transformer.visit_Module(module)
    assert transformer._tree_changed is True
    assert isinstance(result, Module)
    assert len(result.body) == 4
    assert isinstance(result.body[0], ast.ImportFrom)
    assert isinstance(result.body[1], ast.ImportFrom)
    assert isinstance(result.body[2], ast.ImportFrom)
    assert isinstance(result.body[3], ast.ImportFrom)
    assert isinstance(result.body[0].module, Str)
    assert isinstance(result.body[1].module, Str)
    assert isinstance(result.body[2].module, Str)

# Generated at 2022-06-12 03:40:27.267901
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast

    code = """
      a = 1
      b = 2
      c = 3
    """
    tree = ast.parse(code)
    tree_changed = False
    Python2FutureTransformer().visit(tree)
    for node in ast.walk(tree):
        if isinstance(node, ast.ImportFrom):
            assert node.level == 0
            assert node.module == '__future__'
            tree_changed = True
    assert tree_changed

# Generated at 2022-06-12 03:40:37.430143
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    class ModuleNode(ast.Module):
        def __init__(self):
            super().__init__()
            self.body = [None]
    module_node = ModuleNode()
    expected_result = ast.Module(
        body=[
            ast.ImportFrom(
                module='future',
                names=[
                    ast.alias(
                        name='absolute_import',
                        asname=None
                    ),
                    ast.alias(
                        name='division',
                        asname=None
                    ),
                    ast.alias(
                        name='print_function',
                        asname=None
                    ),
                    ast.alias(
                        name='unicode_literals',
                        asname=None
                    )
                ],
                level=0
            ),
            None
        ],
    )


# Generated at 2022-06-12 03:40:44.912021
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor

    simple_code = '''print()'''
    expected_result = '''from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
print()'''

    tree = ast.parse(simple_code)
    tree = Python2FutureTransformer().visit(tree)
    result = astor.to_source(tree).rstrip()

    print(result)

    assert result == expected_result

# Generated at 2022-06-12 03:40:52.078281
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = ast.parse('''
    import sys
    import os
    import string
    a = 5
    b = "Python"
    ''')
    transformer = Python2FutureTransformer()
    module = transformer.visit(module)
    assert_equal(
        ast2str(module).strip(),
        '''from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
import sys
import os
import string
a = 5
b = "Python"
''')

# Generated at 2022-06-12 03:40:55.156657
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import typed_ast.ast3 as ast
    from .utils import round_trip, get_future_body
    from .test_transformer_visit_Module import check_node_unchanged
    future_body = get_future_body()

# Generated at 2022-06-12 03:41:01.535331
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = ast.parse('x=2\na=4', mode='exec')
    trans = Python2FutureTransformer()
    trans.visit(module)
    assert trans.tree_changed
    assert ast.dump(module) == dedent('''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    x = 2
    a = 4
    ''').lstrip()

# Generated at 2022-06-12 03:41:09.294969
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Given
    tree = ast.parse("""
    class Bar(object):
        pass
    """)

    # When
    transformer = Python2FutureTransformer()
    transformer.visit_Module(tree)

    # Then
    expected = ast.parse("""
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    class Bar(object):
        pass
    """)
    assert ast.dump(tree) == ast.dump(expected)

# Generated at 2022-06-12 03:41:12.075492
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import parse
    from ..utils.ast_visitor import ASTVisitor  # type: ignore
    from ..utils.transformer_visitor import TransformerVisitor  # type: ignore

# Generated at 2022-06-12 03:41:18.466830
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_node = ast.parse('''
x = 2
y = 2
    ''')

    visitor = Python2FutureTransformer()
    module_node = visitor.visit(module_node)

    source = ast.unparse(module_node)

    assert source == '''
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

x = 2
y = 2
    '''

# Generated at 2022-06-12 03:41:27.461598
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    tree = astor.parse_file(__file__)
    t = Python2FutureTransformer()
    t.visit(tree)


# Generated at 2022-06-12 03:41:36.371086
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()
    tree = ast.parse("class Foo:\n    pass")
    transformer.visit(tree)
    assert transformer._tree_changed
    assert transformer.result[0].body[0].names[0].asname is None
    assert transformer.result[0].body[0].names[0].name == 'absolute_import'
    assert transformer.result[0].body[0].names[1].asname == 'division'
    assert transformer.result[0].body[0].names[1].name == 'division'
    assert transformer.result[0].body[0].names[2].asname == 'print_function'
    assert transformer.result[0].body[0].names[2].name == 'print_function'
    assert transformer.result[0].body[0].names[3].asname

# Generated at 2022-06-12 03:41:44.668026
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    from tree_transformer.transformers.base import BaseNodeTransformer
    source = '''if __name__ == "__main__":
        pass
        '''
    module = ast.parse(source)
    transformer = Python2FutureTransformer(module)
    result = transformer.visit(module)
    #print(astor.to_source(result))
    expected = '''from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
if __name__ == "__main__":
    pass
'''
    assert astor.to_source(result) == expected

# Generated at 2022-06-12 03:41:47.905734
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer(ast.parse('')).is_changed()

# Generated at 2022-06-12 03:41:52.058476
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    r'''Unit test for Python2FutureTransformer.__init__.'''
    version = (3, 8)
    target = (2, 7)
    assert Python2FutureTransformer(version, target).__repr__() == \
        "Python2FutureTransformer(version=(3, 8), target=(2, 7))"



# Generated at 2022-06-12 03:42:02.286547
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    input_target_module_filename = '/python/path/to/module.py'
    input_target_module_str = 'def f():\n\tdef _g(a, b):\n\t    return a + b\n\n'
    expected_output_target_module_str = "from future import absolute_import\nfrom future import division\nfrom future import print_function\nfrom future import unicode_literals\ndef f():\n\tdef _g(a, b):\n\t    return a + b\n\n"

    class MockNodeTransformer(BaseNodeTransformer):
        def _transform(self, node: ast.AST, target: Optional[tuple] = None) -> str:
            return astor.to_source(node).strip()

    mock_node_transformer = MockNode

# Generated at 2022-06-12 03:42:07.433469
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    source = '''
    def hello():
        pass
    '''

    expected = '''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    def hello():
        pass
    '''

    tree = ast.parse(source)
    tree = Python2FutureTransformer().visit(tree)

    assert astor.to_source(tree) == expected




# Generated at 2022-06-12 03:42:13.664677
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet

    transpiled_code = Python2FutureTransformer(2, 7).visit(snippet.get_ast(
    """def foo():
    pass
"""
    ))

# Generated at 2022-06-12 03:42:18.924275
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transpiler = Python2FutureTransformer(source_path='test/fixtures/dummy_code.py', target=(2, 7))
    assert type(transpiler).__name__ == 'Python2FutureTransformer'
    assert transpiler.source_path == 'test/fixtures/dummy_code.py'
    assert transpiler.target == (2, 7)


# Generated at 2022-06-12 03:42:20.815143
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pftt = Python2FutureTransformer()
    assert pftt is not None


# Generated at 2022-06-12 03:42:23.782367
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..yatyping import type_inference, YACLITypeVisitor
    from ..yatyping.visitor import YAASTTypeVisitor
    from ..utils.ast import pretty_ast


# Generated at 2022-06-12 03:42:28.509033
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor  # type: ignore
    tree = ast.parse("print(2/3)")
    transformer = Python2FutureTransformer()
    transformer.visit(tree)

# Generated at 2022-06-12 03:42:35.009696
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from .utils import make_fake_expr, transform
    from .base import BaseNodeTransformer
    t = Python2FutureTransformer()
    BaseNodeTransformer.generic_visit = lambda x, y: y  # type: ignore
    t._tree_changed = False
    t._changed = False
    assert t.visit(ast.Module(body=[make_fake_expr()])) == ast.Module(body=[make_fake_expr(), imports.ast])
    assert t._tree_changed
    assert t._changed



# Generated at 2022-06-12 03:42:39.311836
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-12 03:42:40.466634
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)

# Generated at 2022-06-12 03:42:43.903062
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .fixtures.py2_print_function import module, expected
    from .utils import roundtrip

    tree = roundtrip(module, Python2FutureTransformer)
    assert tree == expected



# Generated at 2022-06-12 03:42:49.561505
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    node = ast.parse('a = 1')
    transformer = Python2FutureTransformer()
    node = transformer.visit(node)  # type: ignore
    code = compile(node, filename='<ast>', mode='exec')
    assert hasattr(code, 'co_flags') and code.co_flags & 0x2000
    exec(code)
    assert 'a' in globals() and globals()['a'] == 1



# Generated at 2022-06-12 03:42:56.673421
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    from ..fixer_applier import FixerApplier
    from .utils import transform, assert_transformed_tree

    applier = FixerApplier([Python2FutureTransformer])
    code = """
    x = 3
    print(x)
    """
    expected = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    x = 3
    print(x)
    """
    actual = astor.to_source(transform(code, applier)).strip()
    assert_transformed_tree(actual, expected)

# Generated at 2022-06-12 03:43:01.758194
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from lib2to3.pgen2 import token
    from typed_python import ast3 as typed_ast

    module = ast.Module(body=[])
    transformer = Python2FutureTransformer()
    module = transformer.visit_Module(module)
    assert module == typed_ast.parse(imports.get_source(future='__future__'))



# Generated at 2022-06-12 03:43:08.263805
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    sample = "import pytest\nassert 1 == 2\n"
    expected = "from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n\nimport pytest\nassert 1 == 2\n"
    tree = ast.parse(sample)
    transformer = Python2FutureTransformer()
    tree = transformer.visit(tree)
    result = ast.unparse(tree)
    assert result == expected

# Generated at 2022-06-12 03:43:14.405174
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils import roundtrip_unparse
    from ..utils import dedent

    code = dedent("""\
        def f():
            pass
        """)
    expected_code = dedent("""\
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals
        def f():
            pass
        """)
    ast_tree = ast.parse(code)
    new_ast_tree = Python2FutureTransformer().visit(ast_tree)
    new_code = roundtrip_unparse(new_ast_tree)
    assert new_code == expected_code

# Generated at 2022-06-12 03:43:23.723318
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import ast
    import inspect

    example_code = ast.parse(inspect.getsource(test_Python2FutureTransformer_visit_Module))
    assert str(example_code) == (
        "Module(body=[Assign(targets=[Name(id='test_Python2FutureTransformer_visit_Module', ctx=Store())], "
        "value=Call(func=Attribute(value=Name(id='inspect', ctx=Load()), attr='getsource', ctx=Load()), "
        "args=[Name(id='test_Python2FutureTransformer_visit_Module', ctx=Load())], keywords=[]))])"
    )

    actual_code = Python2FutureTransformer().visit(example_code)

# Generated at 2022-06-12 03:43:26.833052
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Unit test for constructor of class Python2FutureTransformer"""
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)
    assert transformer._tree_changed == False



# Generated at 2022-06-12 03:43:38.344086
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    init_node = ast.Module(
        body=[ast.Expr(
            value=ast.Str(s='Sample Python 2 code')
        )]
    )
    expected = ast.Module(
        body=imports.get_body(future='__future__') + [
            ast.Expr(
                value=ast.Str(s='Sample Python 2 code')
            )
        ]
    )
    actual = Python2FutureTransformer().visit(init_node)
    assert ast.dump(expected) == ast.dump(actual)

# Generated at 2022-06-12 03:43:47.679468
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # arrange
    from ..utils.ast_builder import build
    from ..utils.source import Source
    from ..utils.asserts import assert_node
    from . import Python2FutureTransformer

    statements = ['from datetime import datetime\n',
                'def foo(x):\n',
                '    print(x)\n',
                'foo(1)\n']
    source = Source(''.join(statements))
    transformer = Python2FutureTransformer()

    # act
    tree = build(source)
    transformer.visit(tree)

    # assert
    source.body = ['from __future__ import absolute_import\n',
                'from __future__ import division\n',
                'from __future__ import print_function\n',
                'from __future__ import unicode_literals\n'] + statements


# Generated at 2022-06-12 03:43:58.737688
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()
    tree = ast.parse(
        textwrap.dedent("""\
        a = 1
        b = 2
        """))
    transformed = transformer.visit(tree)
    from future import __doc__
    expected_code = textwrap.dedent(
        rf"""\
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        a = 1
        b = 2
        """)
    assert ast.dump(expected_code) == ast.dump(transformed), transformer.future_import
    assert transformer.future_import == '__future__'
    assert transformer.tree_changed == True

# Generated at 2022-06-12 03:44:02.204653
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast

    # Given
    transformer = Python2FutureTransformer()

    # When
    visitor = transformer.visit
    node = ast.Module(body=[])
    visitor(node)

    # Then
    assert transformer is not None
    assert transformer.target == (2, 7)
    assert transformer._tree_changed is True




# Generated at 2022-06-12 03:44:11.277719
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from python_modernizer.node_transforms.tests import test_code_generator
    from python_modernizer.utils.compat import get_ast
    transformer = Python2FutureTransformer()
    tree = get_ast(test_code_generator)
    tree = transformer.visit(tree)  # type: ignore
    assert 'from __future__ import absolute_import\n' == test_code_generator[0:39]
    assert 'from __future__ import division\n' == test_code_generator[39:66]
    assert 'from __future__ import print_function\n' == test_code_generator[66:94]
    assert 'from __future__ import unicode_literals\n' == test_code_generator[94:122]
    assert 'for i in range(10):' == test

# Generated at 2022-06-12 03:44:15.940999
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import typed_ast.ast3 as ast
    sources = imports.get_sources(future='__future__')
    for source in sources:
        tree = ast.parse(source)
        mod = Python2FutureTransformer().visit(tree)
        assert mod is not None
        code = compile(mod, 'console', 'exec')
        assert code is not None
        exec(code)  # type: ignore

# Generated at 2022-06-12 03:44:23.765707
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import unittest.mock
    from typed_ast.ast3 import Module
    from typed_ast.ast3 import parse
    from typed_ast.ast3 import fix_missing_locations
    from typed_ast import ast3
    from typed_ast import ast27

    # Arrange
    input_ast = parse('ast', mode='exec')
    transformer = Python2FutureTransformer()

    # Act
    with unittest.mock.patch.object(transformer, '_visit_child_nodes'):
        transformer.visit(input_ast)

    # Assert
    assert hasattr(input_ast, 'body')
    assert isinstance(input_ast, ast3.Module)
    assert isinstance(input_ast, ast27.Module)
    assert isinstance(input_ast, Module)

# Generated at 2022-06-12 03:44:29.146149
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()
    node = ast.parse('x = 1')
    assert transformer.visit_Module(node) == \
        ast.parse('from __future__ import absolute_import\n'
                  'from __future__ import division\n'
                  'from __future__ import print_function\n'
                  'from __future__ import unicode_literals\n'
                  'x = 1')

# Generated at 2022-06-12 03:44:30.774935
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from .test_base import BaseNodeTransformerTest
    BaseNodeTransformerTest(Python2FutureTransformer)

# Generated at 2022-06-12 03:44:37.753397
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..conftest import get_ast
    source = """\
print('a')
"""
    expected = """\
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
print('a')
"""
    expected_ast = get_ast(expected)
    tree = get_ast(source)
    Python2FutureTransformer().visit(tree)
    assert ast.dump(expected_ast, include_attributes=False) == ast.dump(tree, include_attributes=False)

# Generated at 2022-06-12 03:44:55.100973
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    p = Python2FutureTransformer(None, None)
    assert p.tree_changed is False
    assert p.target == (2, 7)
    assert p._target == (2, 7)

# Generated at 2022-06-12 03:45:00.008494
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()
    node = ast.parse('')
    expected = ast.parse('from __future__ import absolute_import\n'
                         'from __future__ import division\n'
                         'from __future__ import print_function\n'
                         'from __future__ import unicode_literals\n'
                         )
    actual = transformer.visit_Module(node)
    assert ast.dump(expected) == ast.dump(actual)


# Generated at 2022-06-12 03:45:01.243348
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    from . import transformer_test_utils as ttu


# Generated at 2022-06-12 03:45:10.952370
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Given
    module_name = 'test'
    src = "with open('test.py', 'w') as f:\n    pass"
    tree = ast.parse(src, filename=module_name, mode='exec')
    transformer = Python2FutureTransformer(module_name, src, tree)

    # When
    new_tree = transformer.visit_Module(tree)  # type: ignore

    # Then
    expected = ast.parse(
        "from __future__ import absolute_import\n"
        "from __future__ import division\n"
        "from __future__ import print_function\n"
        "from __future__ import unicode_literals\n"
        "\n"
        "with open('test.py', 'w') as f:\n"
        "    pass")
    assert ast.dump

# Generated at 2022-06-12 03:45:19.166408
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from py2typer.type_inference.infer import infer_types
    from .slow_ast import parse, dump
    tree = parse('t=None;a=1+t')
    infer_types(tree)
    new_tree = Python2FutureTransformer().visit(tree)
    assert parse(dump(new_tree)) == parse(
        'from __future__ import absolute_import;from __future__ import division;from __future__ import print_function;from __future__ import unicode_literals;t=None;a=1+t')
    assert parse(dump(tree)) == parse('t=None;a=1+t')

# Generated at 2022-06-12 03:45:25.771359
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module(): 
    # set up the test case
    transformer = Python2FutureTransformer()
    expected_tree = ast.parse("from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n\npass")

    # invoke the method
    root = ast.parse("pass")
    transformer.visit(root)

    # verify the results
    assert transformer._tree_changed
    assert ast.dump(expected_tree) == ast.dump(root)



# Generated at 2022-06-12 03:45:33.577239
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    """Test method visit Module of class Python2FutureTransformer."""
    t = Python2FutureTransformer(2, 7)
    node = ast.parse("x = 5\nprint(x)")
    new_node = t.visit(node)

# Generated at 2022-06-12 03:45:44.808523
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse('1+1')
    Python2FutureTransformer().visit(node)
    assert ast.dump(node) == \
        "Module(body=[ImportFrom(module='__future__', names=[alias(name='absolute_import', asname=None)], level=0), ImportFrom(module='__future__', names=[alias(name='division', asname=None)], level=0), ImportFrom(module='__future__', names=[alias(name='print_function', asname=None)], level=0), ImportFrom(module='__future__', names=[alias(name='unicode_literals', asname=None)], level=0), Expr(value=BinOp(left=Num(n=1), op=Add(), right=Num(n=1)))])"



# Generated at 2022-06-12 03:45:53.011119
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    from textwrap import dedent

    # Prepares test
    module_snippet = dedent("""
        import locale
        import os
        import sys
        
        def main():
            print(sys.version)
    """)
    expected_snippet = dedent("""
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        import locale
        import os
        import sys
        
        def main():
            print(sys.version)
    """)
    expected_tree = astor.parse_module(expected_snippet)
    module_tree = astor.parse_module(module_snippet)
    transformer = Python2FutureTransformer()

    # Executes test


# Generated at 2022-06-12 03:45:54.636536
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer()._tree_changed == False, \
        'Unexpected default value for field "_tree_changed"'

# Generated at 2022-06-12 03:46:28.446188
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-12 03:46:33.569146
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse("def foo():\n  return 1")
    # The result of parsing will be the body of a Module
    assert isinstance(node, ast.Module)
    assert len(node.body) == 1
    #
    t = Python2FutureTransformer()
    t.visit(node)
    #
    assert len(node.body) == 5

# The following test must be the last one in the file

# Generated at 2022-06-12 03:46:42.442405
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import ast
    import sys
    import tokenize
    from typing import List

    # Given
    code = """class Foo:
    def foo():
        pass
"""
    # When
    node = ast.parse(code)
    transformer = Python2FutureTransformer(
        code=code,
        filename="test.py",
        future=True
    )
    new_node = transformer.visit(node)

    # Then
    assert transformer._tree_changed

    assert isinstance(new_node, ast.Module)

    #First element of the body must be module imports
    assert isinstance(new_node.body[0], ast.ImportFrom)
    assert isinstance(new_node.body[1], ast.ImportFrom)
    assert isinstance(new_node.body[2], ast.ImportFrom)
    assert isinstance

# Generated at 2022-06-12 03:46:44.705378
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    class_ = Python2FutureTransformer()
    assert class_.target == (2, 7)
    assert isinstance(class_.target, tuple)


# Generated at 2022-06-12 03:46:45.589986
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-12 03:46:51.750824
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor

    node = ast.parse('')
    node = Python2FutureTransformer().visit(node)
    assert 'from __future__ import' in astor.to_source(node)
    assert 'from __future__ import absolute_import' not in astor.to_source(node)

    node = ast.parse('''from __future__ import absolute_import''')
    node = Python2FutureTransformer().visit(node)
    assert 'from __future__ import absolute_import' not in astor.to_source(node)

# Generated at 2022-06-12 03:46:59.826912
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast.ast3 import parse
    from typed_ast.ast3 import dump
    from ..utils.snippet import test_snippet
    from .base import transform
    
    source = '''
st = 2+3
    '''
    expected = '''
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

st = 2+3
    '''
    actual = test_snippet(source, Python2FutureTransformer)
    actual_tree = parse(actual)
    expected_tree = parse(expected)
    assert dump(expected_tree) == dump(actual_tree)

# Generated at 2022-06-12 03:47:06.636537
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    """
    Unit test to verify that some transformation is applied to module body
    """
    
    m = ast.Module(
        body=[
            ast.FunctionDef(
                name='foo', args=ast.arguments(args=[], vararg=None, kwonlyargs=[],
                                               kw_defaults=[], kwarg=None, defaults=[]),
                body=[ast.Expr(value=ast.Num(n=2))],
                decorator_list=[], returns=None, type_comment=None
            )
        ]
    )
    t = Python2FutureTransformer()
    t.visit(m)
    assert t._tree_changed == True  # pylint: disable=protected-access
    assert isinstance(m, ast.Module)

# Generated at 2022-06-12 03:47:14.121079
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    import sys

    if sys.version_info[:2] < (3, 6):
        from typed_ast import _ast3 as ast # type:ignore
    module = ast.parse('a = b + c')
    transformer = Python2FutureTransformer()
    new_module = transformer.visit(module)

    names = [n.name for n in new_module.body]
    expected = [
        'absolute_import',
        'division',
        'print_function',
        'unicode_literals',
        'a',
    ]
    assert names == expected

# Generated at 2022-06-12 03:47:15.362442
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'

# Generated at 2022-06-12 03:48:46.930257
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    node = ast.parse('x = "a string"')
    transformer = Python2FutureTransformer()
    new_node = transformer.visit(node)
    assert transformer._tree_changed == True
    import token
    import tokenize
    from io import BytesIO
    out = BytesIO()
    tokenize.tokenize(BytesIO(compile(new_node, filename="<test>", mode="exec")).readline, out.write)
    tokens = tokenize.untokenize(out.getvalue())
    assert tokens == b'from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n\nx = "a string"\n'

# Generated at 2022-06-12 03:48:48.440970
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer._tree_changed is False



# Generated at 2022-06-12 03:48:50.175144
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .test_transformer_base import transform

    transformer = Python2FutureTransformer()

# Generated at 2022-06-12 03:48:58.811529
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils import get_ast, dump_ast
    #from ..Python2Python3Transformer import Python2Python3Transformer

    source = '''
        print('Hello')
        print("Hi")
    '''
    print("===[ Source ]===================================================================")
    print(source)
    print("===[ Expected ]===================================================================")
    print('''
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        print('Hello')
        print("Hi")
    ''')
    print("===[ Before ]===================================================================")
    module = get_ast(source)
    print(dump_ast(module))
    Python2FutureTransformer().visit(module)

# Generated at 2022-06-12 03:49:00.158253
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-12 03:49:03.062392
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    class _Test1(ast.AST):
        pass
    
    t = Python2FutureTransformer()
    n = ast.Module(body=[_Test1()])
    assert isinstance(t.visit(n), ast.Module)

# Generated at 2022-06-12 03:49:09.197828
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .utils import roundtrip

    pt = ast.parse("print('Hi'); a = 1")
    pt = Python2FutureTransformer().visit(pt)  # type: ignore
    pt = roundtrip(pt)
    assert pt.body[0].value.s == '__future__'
    assert pt.body[1].value.s == 'absolute_import'
    assert pt.body[2].value.s == 'division'
    assert pt.body[3].value.s == 'print_function'
    assert pt.body[4].value.s == 'unicode_literals'

# Generated at 2022-06-12 03:49:09.985059
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer((2, 7))

# Generated at 2022-06-12 03:49:17.730041
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    code = """
my_list = [1, 2, 3]
my_list.append(4)
print(my_list)
"""
    expected_code = """
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals


my_list = [1, 2, 3]
my_list.append(4)
print(my_list)
"""
    tree = ast.parse(textwrap.dedent(code))
    node_transformer = Python2FutureTransformer()
    node_transformer.visit(tree)
    assert expected_code == astor.to_source(tree)

# Generated at 2022-06-12 03:49:23.410389
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # assert Python2FutureTransformer().generic_visit == BaseNodeTransformer.generic_visit
    module = ast.parse('a = 0')
    node = Python2FutureTransformer().visit(module)
    assert len(node.body) == 6
    assert isinstance(node.body[1], ast.ImportFrom)
    assert node.body[1].module == '__future__'
    assert node.body[1].names[0].name == 'absolute_import'
    assert node.body[1].level == 0