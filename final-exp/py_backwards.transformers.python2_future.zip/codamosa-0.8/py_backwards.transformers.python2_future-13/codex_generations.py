

# Generated at 2022-06-12 03:39:52.907697
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import ast
    from typed_ast import ast3
    from pylama.lint import Linter as Linter_original
    from pylama.lint import Python3FutureTransformer

    Linter = Linter_original.mixin(Python3FutureTransformer)
    Linter.MAX_CONTEXT_SHOW = 0

    module = ast.parse('def f():\n    1/2\n')
    Python2FutureTransformer().visit(module)
    import astunparse

# Generated at 2022-06-12 03:39:58.302332
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor

    module = ast.parse("import logging")
    node = Python2FutureTransformer().visit(module)
    assert astor.to_source(node).strip() == '''\
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

import logging
'''

# Generated at 2022-06-12 03:40:03.493823
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Given
    transformer = Python2FutureTransformer()
    node = ast.parse('')  # type: ignore
    assert node.body == []
    # When
    result = transformer.visit_Module(node)
    # Then
    assert result is node
    assert transformer._tree_changed
    assert result.body == imports.get_body(future='__future__')


# Generated at 2022-06-12 03:40:11.343845
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast

    from tatsu.util import asjson
    from tatsu import parse
    code = """
        a = True
        b = False
        c = 10
        d = 'Hello World!'
        """

    expected_ast = parse(code)
    ast_result = ast.parse(code)
    Python2FutureTransformer().visit(ast_result)
    expected_ast.body.insert(0, import_from('future', 'absolute_import', lineno=1, col_offset=0))
    expected_ast.body.insert(0, import_from('future', 'division', lineno=1, col_offset=0))
    expected_ast.body.insert(0, import_from('future', 'print_function', lineno=1, col_offset=0))
    expected_

# Generated at 2022-06-12 03:40:16.476980
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    tree = ast.parse("print(2 + 2)")
    Python2FutureTransformer().visit(tree)
    assert astor.to_source(tree) == """\
# coding=utf-8
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
print(2 + 2)
"""

# Generated at 2022-06-12 03:40:17.625067
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-12 03:40:22.479281
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    """Test that imports have been prepended.
    """
    assert Python2FutureTransformer.visit_Module(None, ast.parse("pass")).body[:2] == imports.get_body(future='__future__')  # type: ignore
    assert Python2FutureTransformer.visit_Module(None, ast.parse("pass")).body[:2] != imports.get_body(future='futur')  # type: ignore

# Generated at 2022-06-12 03:40:30.406133
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Given
    transformer = Python2FutureTransformer()
    node = ast.parse('print(2)', '<test>', 'exec')
    # When
    node = transformer.visit(node)
    # Then
    assert node.body[0].value.func.attr == 'absolute_import'
    assert node.body[1].value.func.attr == 'division'
    assert node.body[2].value.func.attr == 'print_function'
    assert node.body[3].value.func.attr == 'unicode_literals'
    assert isinstance(node.body[4], ast.Expr)

# Generated at 2022-06-12 03:40:30.975478
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    pass

# Generated at 2022-06-12 03:40:38.169064
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor, textwrap
    node = astor.parse_module(textwrap.dedent("""
        def foo():
            pass

        def bar():
            pass
    """))
    Python2FutureTransformer().visit(node)
    assert(astor.to_source(node) == textwrap.dedent("""
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    def foo():
        pass


    def bar():
        pass
    """))

# Generated at 2022-06-12 03:40:47.290653
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from . import unparse
    from .base import BaseNodeTransformer
    
    class DummyTransformer(BaseNodeTransformer):
        def visit_Module(self, node):
            node.body.insert(0, ast.parse('x=1').body[0])
            return node
    
    tr = Python2FutureTransformer(None)
    tr2 = DummyTransformer(tr)
    
    result = unparse(tr2.visit(ast.parse('''\
if 1:
    print(1)''')))
    
    assert result == '''\
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
x=1

if 1:
    print(1)'''

# Generated at 2022-06-12 03:40:50.967697
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse('a = 1')
    assert len(node.body)==1
    Python2FutureTransformer().visit(node)
    assert len(node.body)==5


# Generated at 2022-06-12 03:40:57.256092
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .helper import get_ast, node_at_succeed
    from .helper import string_ast, fix_indent
    from ..utils.node_visitor import NodeVisitor
    from ..utils.transform_visitor import TransformVisitor   
    from .helper import transform_visitor_helper
    import textwrap
    
    # Test snippet
    @snippet
    def source():
        foo = 1
        baz = 2

    # Setup to transform the source snippet
    source_node = get_ast(source)
    target_node = get_ast(source)
    source_str_without_future = string_ast(source_node)
    target_str_with_future = string_ast(Python2FutureTransformer().visit(target_node))

    # Get the string that contains future imports using the

# Generated at 2022-06-12 03:40:58.629505
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import typed_ast.ast3

# Generated at 2022-06-12 03:41:09.491683
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    test_ast = ast.parse("""
from __future__ import generators
from __future__ import division
""")
    transformer = Python2FutureTransformer()
    transformer.visit(test_ast)
    result = ast.dump(test_ast)

# Generated at 2022-06-12 03:41:11.575427
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import expect_source
    from typed_ast import ast3

# Generated at 2022-06-12 03:41:21.083806
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    code = 'x = "unicode_literals"'
    tree = ast.parse(code)
    Python2FutureTransformer().visit(tree)

# Generated at 2022-06-12 03:41:22.183788
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    from typed_ast import ast3 as ast


# Generated at 2022-06-12 03:41:29.165072
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..transpile import Transpiler
    from ast import parse
    t = Transpiler()
    c = t.transpile_snippet(
        parse('''if 1:
        def f(a):
            return a + 1
        ''', mode='exec'),  # type: ignore
        target_version=(2, 7),
    )

# Generated at 2022-06-12 03:41:30.939151
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():

    # Arrange
    transformer = Python2FutureTransformer()

# Generated at 2022-06-12 03:41:43.429083
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .. import ast_transforms
    from typed_ast import ast3, misc
    from . import base
    from . import ctx
    from . import imports
    from itertools import chain
    tree = ast3.parse('''
        import os
        import sys
        import logging
        import asyncio
        import aiohttp
        import sqlalchemy
    ''')
    t = Python2FutureTransformer(ctx.DirectoryCtx('/this/is/irrelevant'))
    t.visit(tree)
    imports = imports.get_body(future='__future__')
    assert isinstance(tree.body, list)
    assert tree.body[:len(imports)] == imports  # type: ignore

# Generated at 2022-06-12 03:41:50.981689
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ...utils.fixtures import make_dummy_future_import
    from ...utils.fixtures import make_dummy_absolute_import
    from ...utils.fixtures import make_dummy_division
    from ...utils.fixtures import make_dummy_print_function
    from ...utils.fixtures import make_dummy_unicode_literals
    mod = ast.Module([make_dummy_future_import(), make_dummy_absolute_import(), make_dummy_division(), 
                      make_dummy_print_function(), make_dummy_unicode_literals()])
    assert Python2FutureTransformer().visit(mod) is mod

# Generated at 2022-06-12 03:41:54.111930
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse("")
    transformer = Python2FutureTransformer()
    transformer.visit_Module(node)

    tree = ast.parse(imports.get(future='__future__'))  # type: ignore
    assert node.body == tree.body

# Generated at 2022-06-12 03:42:01.600345
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    from .utils import transform, compare_source

    source = '''
# The Zen of Python, by Tim Peters

    import this

'''
    expected = '''
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

# The Zen of Python, by Tim Peters

    import this

'''
    module, _ = transform(source, Python2FutureTransformer)
    compare_source(astor.to_source(module), expected)

# Generated at 2022-06-12 03:42:05.919283
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fake import FakeVisitor

    class _(_(Python2FutureTransformer)): pass
    module = ast.Module([])
    obj = _()  # type: ignore
    obj.visit(module)
    assert obj._tree_changed is True
    assert isinstance(obj.visit(module), ast.Module)  # type: ignore



# Generated at 2022-06-12 03:42:13.281893
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    from ..utils.snippet import snippet

    @snippet
    def test():
        import not_a_future
        import sys
        import sys as future
        from __future__ import absolute_import

    expected = '''
from future import absolute_import
from future import division
from future import print_function
from future import unicode_literals

import not_a_future
import sys
import sys as future
from future import absolute_import
    '''.strip()

    node = ast.parse(test.get_source())
    assert astor.to_source(node) == expected

# Generated at 2022-06-12 03:42:20.358500
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import check_transformation

    check_transformation(
        Python2FutureTransformer,
        """
        i = 0
        print("{}".format(i))
        """,
        """
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        i = 0
        print("{}".format(i))
        """,
        'visit_Module'
    )



# Generated at 2022-06-12 03:42:28.544593
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-12 03:42:30.058666
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typing import List
    import astor


# Generated at 2022-06-12 03:42:37.819195
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()
    tree = ast.parse('print("Hello World!")')
    transformer.visit(tree)
    assert transformer._tree_changed
    assert tree.body == imports.get_body(future='__future__') + [ast.Expr(ast.Call(func=ast.Name(id='print', ctx=ast.Load()), args=[ast.Str(s='Hello World!')], keywords=[])), ast.Expr(ast.Call(func=ast.Name(id='print', ctx=ast.Load()), args=[ast.Str(s='Hello World!')], keywords=[]))]

# Generated at 2022-06-12 03:42:52.188101
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from typed_ast.transforms import Python2FutureTransformer
    from .test_parser import parse_string, parse_string_module
    from .utils import assert_node
    from ..utils import TestCase

    class Test(TestCase):
        def test_equal(self):
            code = '''
            x = type([])
            assert isinstance(x, type)
            '''
            node = parse_string(code)
            Python2FutureTransformer().visit(node)
            self.assertEqual(node, parse_string_module(code))
            node = parse_string(code, filename='<test>')
            node = Python2FutureTransformer().visit(node)

# Generated at 2022-06-12 03:42:57.750513
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = ast.parse("from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n", filename="<test>")
    
    visitor = Python2FutureTransformer()
    module = visitor.visit(module)
    assert module == ast.parse("from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n", filename="<test>")

# Generated at 2022-06-12 03:43:07.415740
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from .transformer_test_case import TransformerTestCase, run_transformer_test_cases

    class Test(TransformerTestCase):
        def test_empty_module(self):
            self.transformer = Python2FutureTransformer()

            with self.subTest(line=2):
                code = '''\
                from __future__ import absolute_import
                from __future__ import division
                from __future__ import print_function
                from __future__ import unicode_literals\
                '''
                node = self.transform(code=code)
                self.assertIsInstance(node, ast.Module)
                self.assertEqual(node.body[0], self.parse_module(code).body[0])

                with self.subTest(line=3):
                    self

# Generated at 2022-06-12 03:43:08.621622
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils import roundtrip

# Generated at 2022-06-12 03:43:11.458685
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    raw_code = """def f():
    print("Hello")
"""

# Generated at 2022-06-12 03:43:20.077777
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():

    @snippet
    def module():
        import inspect

    transformer = Python2FutureTransformer()
    node = module.get_ast()
    new_node = transformer.visit_Module(node)
    assert transformer._tree_changed is True
    assert new_node.body[0].names[0].name == "absolute_import"
    assert new_node.body[1].names[0].name == "division"
    assert new_node.body[2].names[0].name == "print_function"
    assert new_node.body[3].names[0].name == "unicode_literals"
    assert new_node.body[4].names[0].name == "inspect"

# Generated at 2022-06-12 03:43:27.335532
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import sys
    import astor
    from ..transpile import Transpiler
    node = ast.parse("x = 1 + 2")
    transpiler = Transpiler()
    transpiler.targets = [2, 7]
    new_tree = transpiler.visit(node)
    print(astor.to_source(new_tree))
    expected_output = """\
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

x = 1 + 2\
"""
    if sys.version_info < (3, 0):
        expected_output = expected_output.encode('ascii')
    assert astor.to_source(new_tree) == expected_output



# Generated at 2022-06-12 03:43:37.246888
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = Python2FutureTransformer.run_single(single_input="")
    assert module.body[0]._fields == ('module',)  # type: ignore
    assert module.body[0]._attributes == ()  # type: ignore
    assert module.body[0].module == '__future__'  # type: ignore
    assert module.body[1]._fields == ('name',)  # type: ignore
    assert module.body[1]._attributes == ()  # type: ignore
    assert module.body[1].name == 'absolute_import'  # type: ignore
    assert module.body[2]._fields == ('name',)  # type: ignore
    assert module.body[2]._attributes == ()  # type: ignore
    assert module.body[2].name == 'division'  # type: ignore

# Generated at 2022-06-12 03:43:46.477460
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from os.path import join, dirname
    from cobe.brain import Brain
    from nlppln.utils import create_dirs, out_file_name
    import sys

    sys.path.insert(0, join(dirname(__file__), '..', '..', '..'))

    brain = Brain(join(dirname(__file__), '..', '..', '..', 'cobe.brain'))

    data = join(dirname(__file__), 'data')
    in_dir = join(data, 'python27')
    out_dir = create_dirs(out_file_name(in_dir, out_dir_name='py2to3'))

# Generated at 2022-06-12 03:43:53.864283
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    tr = Python2FutureTransformer()
    tree = ast.parse(dedent(
        """
        import os
        import sys
        def f():
            return None
        """
    ))
    result = tr.visit(tree)
    assert result == ast.parse(dedent(
        """
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        import os
        import sys
        def f():
            return None
        """
    ))

# Generated at 2022-06-12 03:44:25.719769
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast

    code = """
        import os
        import sys
        
        print("Hello world")
    """
    tree = ast.parse(code)
    Python2FutureTransformer().visit(tree)

# Generated at 2022-06-12 03:44:29.733211
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Arrange
    from typed_ast import parse

    # Act
    from typed_ast import ast3
    node = ast3.parse("x = 2")

    transformer = Python2FutureTransformer()
    actual = transformer.visit(node)

    assert actual is not None


# Generated at 2022-06-12 03:44:31.041419
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer((2,7)) != None


# Generated at 2022-06-12 03:44:31.953715
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-12 03:44:41.250327
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    def test_child_node(node):
        assert node.__class__.__name__ in ['ImportFrom', 'Module', 'Import']
        return True

    source = """
    def a_fun():
        pass
    """
    expected_source = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    
    
    def a_fun():
        pass
    """

    tr = Python2FutureTransformer()
    tr.visit(ast.parse(source))
    if tr.tree_changed:
        result = ast.fix_missing_locations(tr.root)  # type: ignore
        generated_source = compile(result, filename="<ast>", mode="exec")


# Generated at 2022-06-12 03:44:44.827791
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_future_transformer_test_case
    from asttokens import ASTTokens
    
    make_future_transformer_test_case(
        ASTTokens(source=imports.source),
        Python2FutureTransformer
    )



# Generated at 2022-06-12 03:44:53.542150
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = ast.parse('''
        import sys
        import os
        import test
        import future
        import test2
        import test3
    ''')

    expected = '''
        import sys
        import os
        
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        
        import test
        import future
        import test2
        import test3
    '''

    # ## Act ##
    transformer = Python2FutureTransformer()
    new_module = transformer.visit(module)  # type: ignore

    # ## Assert ##
    assert transformer._tree_changed

    assert ast.dump(new_module) == ast.dump(ast.parse(expected))  # type: ignore

# Generated at 2022-06-12 03:44:55.107976
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == "Python2FutureTransformer"


# Generated at 2022-06-12 03:44:56.479835
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast.ast3 import parse
    from ..transformers import TransformerSuite
    from ..parsers import PythonParser


# Generated at 2022-06-12 03:45:02.084263
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import textwrap
    before = textwrap.dedent("""
    def f():
        pass
    """)
    after = textwrap.dedent("""
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    def f():
        pass
    """)

    code = ast.parse(before)
    trf = Python2FutureTransformer()
    trf.visit(code)  # type: ignore
    res = ast.unparse(code)
    assert res == after

# Generated at 2022-06-12 03:45:33.338684
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.name == 'Python2FutureTransformer'
    assert transformer.target == (2, 7)
    assert transformer.generic_visit == BaseNodeTransformer.generic_visit

# Generated at 2022-06-12 03:45:41.408072
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast

    code = """
        # this is a comment
        a = 2
    """
    tree = ast.parse(code)
    Python2FutureTransformer(2.7).visit(tree)

    expected_code = """
        # this is a comment
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        a = 2
    """
    assert ast.dump(tree) == ast.dump(ast.parse(expected_code))

# Generated at 2022-06-12 03:45:48.947794
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    assert Python2FutureTransformer.visit_Module.__doc__

    def test(target, module, expected):
        module = ast.parse(module)
        module = Python2FutureTransformer(target).visit(module)
        module = ast.fix_missing_locations(module)
        module = compile(module, filename='<string>', mode='exec')
        expected = ast.parse(expected)
        expected = ast.fix_missing_locations(expected)
        expected = compile(expected, filename='<string>', mode='exec')

        ns = {}
        exec(module, ns)
        expected_ns = {}
        exec(expected, expected_ns)

        assert ns == expected_ns


# Generated at 2022-06-12 03:45:50.875107
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    """Test whether visit_Module is correct."""

# Generated at 2022-06-12 03:45:51.328281
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    pass

# Generated at 2022-06-12 03:45:57.275141
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..migrate import Migrate
    transformer = Migrate().get_transformer('typed_ast')
    tree = ast.parse("""def f(a, b=2) -> None:
        pass""")
    ntree = transformer.visit(tree)
    result = compile(ntree, filename='<ast>', mode='exec')
    ns = {}
    exec(result, ns)
    assert ns['f'].__code__.co_argcount == 2  # argument b has default value

# Generated at 2022-06-12 03:45:59.604020
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # target = (2, 7)
    # tree_changed = True
    # node_changed = True
    # node.body = imports('__future__')
    assert True



# Generated at 2022-06-12 03:46:09.887381
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    from ..utils import roundtrip
    ft = Python2FutureTransformer()

    mod = roundtrip(ft, """\
    class Foo:
        def foo(self):
            return 42
    """)
    mod = roundtrip(ft, """\
    class Foo:
        def foo(self):
            return 42
    """)

# Generated at 2022-06-12 03:46:16.456857
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    @snippet
    def code():
        pass

    expected_ast = ast.parse('from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n\npass\n')
    tree = code.get_ast()
    Python2FutureTransformer().visit(tree)
    # Use ast.dump to show the difference between trees
    print(ast.dump(tree))
    print('-' * 40)
    print(ast.dump(expected_ast))
    # Use ast.interpreter to compare trees
    compare_ast(tree, expected_ast)




# Generated at 2022-06-12 03:46:21.696549
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse('x = "abc"')
    transformer = Python2FutureTransformer()
    new_node = transformer.visit(node)
    expected = ast.parse('from __future__ import absolute_import\n\nfrom __future__ import division\n\nfrom __future__ import print_function\n\nfrom __future__ import unicode_literals\n\nx = "abc"')
    assert new_node == expected

# Generated at 2022-06-12 03:47:24.738094
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    tree = ast.parse('from ast import *')
    transformer = Python2FutureTransformer()
    tree = transformer.visit(tree)  # type: ignore
    assert len(tree.body) == 5

# Generated at 2022-06-12 03:47:32.308422
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor  # noqa
    source = """
#!/usr/bin/env python
if True:
    print(1)
    import sys
    print(2)
    """
    expected = """
#!/usr/bin/env python
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
if True:
    print(1)
    import sys
    print(2)
    """
    ast_tree = ast.parse(source)
    Python2FutureTransformer().visit(ast_tree)
    print(astor.to_source(ast_tree))
    assert astor.to_source(ast_tree) == expected

# Generated at 2022-06-12 03:47:34.816502
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module = ast.parse("import sys", "", "exec")
    module = Python2FutureTransformer().visit(module)
    module.body.pop(0)
    assert module == imports.get_snippet(future='__future__')

# Generated at 2022-06-12 03:47:35.461783
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer()

# Generated at 2022-06-12 03:47:41.335502
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module_name = '__main__'
    import_name = '__future__'
    star_import_name = 'ast'
    module_ast = ast.parse('''\
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
from __future__ import *
import ast as ast
''')

# Generated at 2022-06-12 03:47:42.835985
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer().target == (2, 7)

# Generated at 2022-06-12 03:47:43.592971
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer(2, 7)

# Generated at 2022-06-12 03:47:51.815019
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    class Test(unittest.TestCase):
        def check(self, code, result):
            module = ast.parse(code)
            Python2FutureTransformer().visit(module)
            self.assertEqual(code, result)

    t = Test()
    t.check("""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

from . import mod
""", """
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals


from . import mod
""")

# Generated at 2022-06-12 03:47:55.013236
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    node = ast.parse('a = 1')
    transformer = Python2FutureTransformer()
    new_node = transformer.visit(node)
    assert transformer.tree_changed
    assert ast.dump(new_node) == ast.dump(ast.parse(imports() + 'a = 1'))

# Generated at 2022-06-12 03:48:03.070482
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert imports.get_body(future='__future__') == [
        ast.ImportFrom(module='future', names=[
            ast.alias(name='absolute_import', asname=None),
            ast.alias(name='division', asname=None),
            ast.alias(name='print_function', asname=None),
            ast.alias(name='unicode_literals', asname=None)
        ], level=0)
    ]


if __name__ == '__main__':
    from pprint import pprint
    from astunparse import unparse
