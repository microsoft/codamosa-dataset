

# Generated at 2022-06-12 03:39:52.494125
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..basic import BasicTransformer


# Generated at 2022-06-12 03:39:53.916591
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer().target == (2, 7)

# Generated at 2022-06-12 03:40:00.452830
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor
    from ..utils.ast_maker import make_module
    mod: ast.Module = make_module()
    py2 = Python2FutureTransformer()
    py2.visit(mod)
    assert astor.to_source(mod) == "from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n\n\n\n\n"

# Generated at 2022-06-12 03:40:08.286758
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast.ast3 import parse
    from ..converter import Converter
    from .common import get_python_source
    import sys
    import os
    import textwrap

    code = u"a = 1\n"

    options = {'target_version': (2, 7), 'future_imports': True}
    src = get_python_source(code, options)
    sys.path.append(os.path.dirname(src))
    module_name = os.path.splitext(os.path.basename(src))[0]
    module = __import__(module_name)  # type: ignore
    ast_tree = parse(code, future_imports=True)


# Generated at 2022-06-12 03:40:12.342305
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import parse
    from ..utils.source_code import SourceCode
    
    module_node = parse('foo()')
    
    SourceCode.of(module_node).print(assert_output=True)
    module_node = Python2FutureTransformer().visit(module_node)
    SourceCode.of(module_node).print()

# Generated at 2022-06-12 03:40:13.689036
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)

# Generated at 2022-06-12 03:40:15.205086
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()
    assert t is not None


# Generated at 2022-06-12 03:40:15.771804
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass

# Generated at 2022-06-12 03:40:19.933649
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast

    from typed_astunparse import unparse

    assert unparse(Python2FutureTransformer.run(ast.parse("""
    a = 1
    """))) == """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals


    a = 1
    """

# Generated at 2022-06-12 03:40:24.213622
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    assert Python2FutureTransformer().visit(ast.parse("b = 2 * 3")) == ast.parse("from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\nb = 2 * 3")

# Generated at 2022-06-12 03:40:28.204043
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert issubclass(Python2FutureTransformer, BaseNodeTransformer)
    assert Python2FutureTransformer().target == (2, 7)


# Generated at 2022-06-12 03:40:34.874007
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..unittest_tools import assert_code_equal
    code = 'print("Hello World")'
    tree = ast.parse(code)
    tr = Python2FutureTransformer()
    tree = tr.visit(tree)
    assert_code_equal(tr.get_code(), 'from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n\nprint("Hello World")', dedent=False)

# Generated at 2022-06-12 03:40:35.441702
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    return True

# Generated at 2022-06-12 03:40:44.246821
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ast_tools.passes import Inliner
    from ast_tools.utils import copy_node
    import ast

    class Future(ast.AST):
        """A custom AST node."""
        _fields = ('module',) # type: Tuple[str, ...]

    future_module = ast.parse(textwrap.dedent('''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    ''')).body
    print(ast.dump(future_module, annotate_fields=False))

    module = ast.Module(
        body=[
            ast.ImportFrom(module='typing', names=[]),
        ]
    )
    print(ast.dump(module, annotate_fields=False))



# Generated at 2022-06-12 03:40:45.377428
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from .. import transform, parse

# Generated at 2022-06-12 03:40:52.931737
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    before = """
import sys
print("Hi")
    """

    after = """
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
import sys
print("Hi")
    """

    tree = parse(before)
    Python2FutureTransformer().visit(tree)
    result = astor.to_source(tree)

    # Parse again to make sure the result is valid
    result_tree = parse(result)
    assert result_tree is not None
    # Check the difference between before and after
    assert result == after

# Generated at 2022-06-12 03:40:54.751298
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    instance = Python2FutureTransformer()
    assert instance.target == (2, 7)
    assert instance._tree_changed is False


# Generated at 2022-06-12 03:40:55.934005
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast.ast3 import parse


# Generated at 2022-06-12 03:40:57.419412
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()
    assert isinstance(t, BaseNodeTransformer)

# Generated at 2022-06-12 03:40:58.397591
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()  # should not raise an exception

# Generated at 2022-06-12 03:41:02.585110
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass

# Generated at 2022-06-12 03:41:08.527752
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    node = ast.parse("a = 1")
    trans = Python2FutureTransformer()
    new_node = trans.visit(node)
    assert ast.dump(new_node, include_attributes=True) == ast.dump(ast.parse(imports.get_code(future='__future__') + "a = 1"), include_attributes=True)

# Generated at 2022-06-12 03:41:10.657903
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer is not None
    assert transformer._tree_changed is False



# Generated at 2022-06-12 03:41:18.963206
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..tools import as_tuple
    from ..utils import compare_ast
    from ..test_utils import source_to_ast
    
    c = Python2FutureTransformer
    
    assert as_tuple(c.target) == (2, 7)
    
    ast1 = source_to_ast("print('Hello world!')")
    compare_ast(c.visit(ast1), source_to_ast("""
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    print('Hello world!')"""))

# Generated at 2022-06-12 03:41:26.623035
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .testutils import assert_ast
    from ..utils.snippet import snippet
    
    @snippet
    def sample():
        abc = 1
    
    expected = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    abc = 1
    """

    transformer = Python2FutureTransformer()
    transformer.transform()  # initialize
    # print(ast.dump(sample.get_ast()))
    actual = transformer.visit(sample.get_ast())
    assert_ast(actual, expected)



# Generated at 2022-06-12 03:41:29.955185
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    node = ast.parse("pass\n")
    t = Python2FutureTransformer([])
    t.visit(node)
    assert node.body[0].lineno == 1
    assert node.body[1].lineno == 2
    assert node.body[2].lineno == 3
    assert node.body[3].lineno == 4
    assert isinstance(node.body[0], ast.ImportFrom)
    assert node.body[0].module == '__future__'
    assert node.body[0].names[0].name == 'absolute_import'
    assert isinstance(node.body[1], ast.ImportFrom)
    assert node.body[1].module == '__future__'
    assert node.body[1].names[0].name == 'division'

# Generated at 2022-06-12 03:41:35.884724
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse(dedent('''
    import io
    import pickle
    '''))
    t = Python2FutureTransformer()
    t.visit(node)
    assert node == ast.parse(dedent('''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    import io
    import pickle
    '''))
# END: Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-12 03:41:36.694471
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer(ast.parse(''))

# Generated at 2022-06-12 03:41:38.573320
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import transform


# Generated at 2022-06-12 03:41:42.122392
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    x = Python2FutureTransformer()
    assert isinstance(x, BaseNodeTransformer)
    assert x.target == (2, 7)

# This test is not good. It's duplicating the functionality of the transformer and the test
# may hence have the same problem as the transformer

# Generated at 2022-06-12 03:41:51.936235
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    
    transformer = Python2FutureTransformer()
    node = ast.parse('pass')
    node = transformer.visit(node)
    assert node.body[0].value.s == "absolute_import"

# Generated at 2022-06-12 03:41:56.783982
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    node = ast.parse('a = 1')
    res = Python2FutureTransformer.run(node)
    assert res.body[0].value.s == 'absolute_import'
    assert res.body[1].value.s == 'division'
    assert res.body[2].value.s == 'print_function'
    assert res.body[3].value.s == 'unicode_literals'

# Generated at 2022-06-12 03:41:57.950039
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-12 03:41:58.569303
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass

# Generated at 2022-06-12 03:41:59.821999
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)

# Generated at 2022-06-12 03:42:01.455630
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-12 03:42:02.075169
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass

# Generated at 2022-06-12 03:42:07.516978
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse('''
        def bar():
            return 1
        def foo():
            return 2
    ''')
    node = Python2FutureTransformer().visit(node)
    assert ast.dump(node) == textwrap.dedent('''
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        def bar():
            return 1
        def foo():
            return 2
    ''').strip()

# Generated at 2022-06-12 03:42:14.927424
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    input_src = '''
        a = 5
        print(a)
    '''
    expected_src = '''
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        a = 5
        print(a)
    '''
    nodes = ast.parse(input_src)
    transformer = Python2FutureTransformer()
    nodes = transformer.visit(nodes)
    assert ast.dump(nodes) == ast.dump(ast.parse(expected_src))

# Generated at 2022-06-12 03:42:16.814980
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    xformer = Python2FutureTransformer()
    assert xformer.target == (2, 7)


# Generated at 2022-06-12 03:42:39.940779
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    node = ast.parse('a=1')
    transformer = Python2FutureTransformer()
    transformer.visit(node)
    assert transformer._tree_changed
    assert ast.dump(node) == \
        "Module(body=[import_from(module='future', names=[alias(name='absolute_import', asname=None)], level=0), import_from(module='future', names=[alias(name='division', asname=None)], level=0), import_from(module='future', names=[alias(name='print_function', asname=None)], level=0), import_from(module='future', names=[alias(name='unicode_literals', asname=None)], level=0), Assign(targets=[Name(id='a', ctx=Store())], value=Num(n=1))])"

# Generated at 2022-06-12 03:42:45.526431
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    input = '''
        x = "test"
        y = 2
    '''
    expected = '''import __future__
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

x = "test"
y = 2
'''
    assert_me(Python2FutureTransformer, input, expected)

# Generated at 2022-06-12 03:42:52.805053
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse("print('Hi')")
    node = Python2FutureTransformer().visit(node)  # type: ignore

# Generated at 2022-06-12 03:42:54.770703
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer._tree_changed is False
    assert Python2FutureTransformer.target == (2, 7)


# Generated at 2022-06-12 03:42:55.447692
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    del Python2FutureTransformer

# Generated at 2022-06-12 03:43:04.178123
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from .print_function import Python2PrintFunctionTransformer
    from .unicode_literals import Python2UnicodeLiteralsTransformer
    from .absolute_import import Python2AbsoluteImportTransformer
    from .division import Python2DivisionTransformer
    code_chunk = '''
print("Simple print statement")
print("Print statement with formatting.", end="")
print("Print statement with a keyword argument.", file=sys.stderr)
'''
    tree = ast.parse(code_chunk)
    tree = Python2PrintFunctionTransformer().visit(tree)
    tree = Python2UnicodeLiteralsTransformer().visit(tree)
    tree = Python2AbsoluteImportTransformer().visit(tree)
    tree = Python2DivisionTransformer().visit(tree)
    assert Python2FutureTransformer().visit

# Generated at 2022-06-12 03:43:08.306101
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast

    transformer = Python2FutureTransformer(None, None)
    node = ast.parse('a = 2')
    node = transformer.visit_Module(node)
    assert node.body[0].body[0].names[0].name == 'absolute_import'

# Generated at 2022-06-12 03:43:13.737434
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    source = """
    import os
    import sys
    def myfunc():
        pass

    """
    oldtree = ast.parse(source)
    newtree = Python2FutureTransformer().visit(oldtree)
    source_ = astor.to_source(newtree)
    print(source_)

# Generated at 2022-06-12 03:43:23.275153
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    node = ast.parse('1+1', 'exec')
    node = Python2FutureTransformer().visit(node)
    assert ast.dump(node) == "Module(body=[ImportFrom(module='__future__', names=[alias(name='absolute_import', asname=None)], level=0), ImportFrom(module='__future__', names=[alias(name='division', asname=None)], level=0), ImportFrom(module='__future__', names=[alias(name='print_function', asname=None)], level=0), ImportFrom(module='__future__', names=[alias(name='unicode_literals', asname=None)], level=0), Expr(value=BinOp(left=Num(n=1), op=Add(), right=Num(n=1)))])"

# Generated at 2022-06-12 03:43:29.210049
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils import build_ast
    node = build_ast(2, 7, """
        def foo():
            return 1""")

    transformer = Python2FutureTransformer(2, 7)
    new_module = transformer.visit(node)
    assert transformer.needs_update

    assert new_module.body[0].names[0].name == 'absolute_import'
    assert new_module.body[1].names[0].name == 'division'


# Generated at 2022-06-12 03:44:02.619437
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    mod = ast.parse("x = 0")
    Python2FutureTransformer().visit(mod)
    code = compile(mod, "ast", 'exec')
    mod = {}
    eval(code, mod)
    assert mod['__future__'].absolute_import
    assert mod['__future__'].division
    assert mod['__future__'].print_function
    assert mod['__future__'].unicode_literals

# Generated at 2022-06-12 03:44:11.696286
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .. import dumps
    from . import python_node
    from . import dumps

    # Python 2.7
    m_ast27 = python_node("""\
        from __future__ import absolute_import, division, print_function

        import os
        import logging
        import sys
    """, version=(2, 7))

    transformed_ast27 = Python2FutureTransformer().visit(m_ast27)
    assert dumps(transformed_ast27) == dumps("""\
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        import os
        import logging
        import sys
    """, version=(2, 7))

    # Python 2.6

# Generated at 2022-06-12 03:44:17.872832
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    class MockVisitor(BaseNodeTransformer):
        def visit_ImportFrom(self, node: ast.ImportFrom):
            return ast.ImportFrom(node.module, node.names, 0)


    pt = ast.parse('def foo():\n\tpass')
    pt = MockVisitor().visit(pt)
    transformed_tree = Python2FutureTransformer().visit(pt)
    expected_tree = ast.parse(imports.get_ast(future='__future__') + 'def foo():\n\tpass')  # type: ignore
    assert ast.dump(transformed_tree) == ast.dump(expected_tree)

# Generated at 2022-06-12 03:44:23.348469
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..node_util import node_to_str, parse

    future = '__future__'
    result = parse(Python2FutureTransformer(future=future).visit(parse('''\
for i in range(10):
    print(i)
 
'''
    ))
    )
    assert node_to_str(result) == '''\
from future import absolute_import
from future import division
from future import print_function
from future import unicode_literals
for i in range(10):
    print(i)
'''

# Generated at 2022-06-12 03:44:25.720097
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..tests.test_transformers import run_test_visit_module
    run_test_visit_module(Python2FutureTransformer)

# Generated at 2022-06-12 03:44:26.914993
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer().__class__ == Python2FutureTransformer

# Generated at 2022-06-12 03:44:32.890415
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    tr = Python2FutureTransformer()
    module = ast.Module([ast.Expr(value=ast.Num(n=1))], type_ignores=[])
    tr.visit(module)
    assert tr.tree_changed is True
    assert_ast(module, """
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        
        1
        
    """)

# Generated at 2022-06-12 03:44:42.066186
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3
    node = ast3.parse('a = 1')
    transformer = Python2FutureTransformer()
    res = transformer.visit(node)
    assert isinstance(res, ast3.Module)
    assert len(res.body) == 5
    assert isinstance(res.body[0], ast3.ImportFrom)
    assert res.body[0].module == '__future__'
    assert res.body[0].names[0].name == 'absolute_import'
    assert isinstance(res.body[1], ast3.ImportFrom)
    assert res.body[1].module == '__future__'
    assert res.body[1].names[0].name == 'division'
    assert isinstance(res.body[2], ast3.ImportFrom)

# Generated at 2022-06-12 03:44:42.934542
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()



# Generated at 2022-06-12 03:44:45.489568
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astunparse
    from typed_ast import ast3 as ast
    node = ast.parse('a=1')
    node = Python2FutureTransformer(node)
    print(astunparse.unparse(node))

# Generated at 2022-06-12 03:45:55.435972
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from .. import TranspileTestCase
    
    class TestClass(TranspileTestCase):
        def setup_method(self, method):
            self.transpiler = Python2FutureTransformer

        def test_basic(self):
            from .. import FutureTransformerTestCase
            class TestClass(FutureTransformerTestCase):
                def setup_method(self, method):
                    self.transpiler = Python2FutureTransformer

                def _test_code(self, src: str, expected: str, **kwargs): # pylint: disable=unused-argument
                    result = self.transpile(src)
                    self.assertBlock(result, expected)

                def test_basic(self):
                    src = 'print("Hello, World!")'
                    result = self.transpile(src)

# Generated at 2022-06-12 03:45:57.808261
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # Test for constructor
    try:
        obj = Python2FutureTransformer()
    except Exception as e:
        assert False , "Unexpected error:" + str(e)
    else:
        assert True

# Generated at 2022-06-12 03:45:58.901999
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer



# Generated at 2022-06-12 03:46:00.083518
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert isinstance(Python2FutureTransformer(), ast.NodeTransformer)



# Generated at 2022-06-12 03:46:00.946364
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-12 03:46:11.347091
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    visitor = Python2FutureTransformer()

    # By default, module begin with:
    tree = ast.parse("""
        print("Hello world")
        """)

    tree = visitor.visit(tree)
    assert visitor.tree_changed

    # But now with "from __future__ import ..."
    expected_tree = ast.parse("""
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        print("Hello world")
        """)
    ast.fix_missing_locations(expected_tree)

    assert ast.dump(tree, annotate_fields=False, include_attributes=True) == ast.dump(expected_tree, annotate_fields=False, include_attributes=True)

# Generated at 2022-06-12 03:46:17.775078
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    x = ast.Module(body=[ast.Expr(value=ast.Str(s='airfow_dags'))])

# Generated at 2022-06-12 03:46:22.106667
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    parameters = {
        'tree': ast.parse('1/2'),
        'version': (2, 7)
    }
    expected = ast.parse(imports(future='__future__') + '1/2')
    result = Python2FutureTransformer().transform(**parameters)
    assert ast.dump(expected) == ast.dump(result)

# Generated at 2022-06-12 03:46:23.452807
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor

# Generated at 2022-06-12 03:46:31.569811
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    tests = [
        ('if True: pass', 'if True: pass'),
        ('from __future__ import absolute_import', 'from __future__ import absolute_import'),
        ('from __future__ import division', 'from __future__ import division'),
        ('from __future__ import print_function', 'from __future__ import print_function'),
        ('from __future__ import unicode_literals', 'from __future__ import unicode_literals'),
    ]
    for code, expected in tests:
        node = ast.parse(code)
        Python2FutureTransformer().visit(node)  # type: ignore
        node = ast.fix_missing_locations(node)
        assert ast.dump(node) == expected



# Generated at 2022-06-12 03:49:09.254410
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    btt = Python2FutureTransformer()
    assert btt

# Generated at 2022-06-12 03:49:15.953256
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .test_helpers import assert_parsed_tree
    from . import tree_builder

    assert_parsed_tree(
        transformer=Python2FutureTransformer,
        original_tree=tree_builder.build(2, '''
        def func():
            pass
        '''),
        expected_tree=tree_builder.build(2, '''
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        def func():
            pass
        '''))

# Generated at 2022-06-12 03:49:17.223226
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer is not None



# Generated at 2022-06-12 03:49:21.765493
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    class TestTransformer(object):
        def __init__(self):
            self._tree_changed = False

    tt = TestTransformer()
    node = ast.Module()
    assert node.body == []
    node = Python2FutureTransformer(tt).visit_Module(node)
    assert tt._tree_changed == True
    assert len(node.body) == 4

# Generated at 2022-06-12 03:49:23.210545
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # create a fake module
    module = ast.parse("")
    # initialize node transformer
    Python2FutureTransformer()

# Generated at 2022-06-12 03:49:24.903684
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)


# Generated at 2022-06-12 03:49:29.423829
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    tree = ast.parse("print('Hello world!')")
    assert Python2FutureTransformer(tree).changed() == True and \
           Python2FutureTransformer(tree).get_tree() == ast.parse("""
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        print('Hello world!')""")

# Generated at 2022-06-12 03:49:30.805674
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-12 03:49:33.426066
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import ast as test_ast
    test_node = test_ast.Module()
    cls = Python2FutureTransformer
    instance = cls.__new__(cls)
    assert isinstance(instance, Python2FutureTransformer)

# Generated at 2022-06-12 03:49:40.388922
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():

    def check_module(tree: ast.Module, future: str = '__future__'):
        """This method check that it appends the future imports to the tree.body"""

        assert tree.body[0].names[0].name == "absolute_import"
        assert tree.body[0].names[0].value == future
        assert tree.body[0].names[1].name == "division"
        assert tree.body[0].names[1].value == future
        assert tree.body[0].names[2].name == "print_function"
        assert tree.body[0].names[2].value == future
        assert tree.body[0].names[3].name == "unicode_literals"
        assert tree.body[0].names[3].value == future

    import astor