

# Generated at 2022-06-12 03:39:45.544706
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor

# Generated at 2022-06-12 03:39:52.202867
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import parse
    from .ast_utils import compare_ast
    from .fix_grammar_scoping import scoping_fixes

    class Dummy(Python2FutureTransformer):
        pass
    # example 1
    src1 = '''
    class A:
        pass
    @classmethod
    def f():
        pass
    '''
    expected1 = '''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    class A:
        pass
    @classmethod
    def f():
        pass
    '''
    tree1 = parse(src1)
    tree1 = scoping_fixes(tree1)
    new_tree1 = Dummy().visit(tree1)
   

# Generated at 2022-06-12 03:40:02.839726
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = ast.parse('for i in range(5): print(i)')
    assert ast.dump(module) == \
        "Module(body=[For(target=Name(id='i', ctx=Store()), iter=Call(func=Name(id='range', ctx=Load()), " \
        "args=[Num(n=5)], keywords=[]), body=[Expr(value=Call(func=Name(id='print', ctx=Load()), args=[Name(id='i', " \
        "ctx=Load())], keywords=[]))], orelse=[])])"
    Python2FutureTransformer().visit(module)

# Generated at 2022-06-12 03:40:07.889992
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils import get_ast
    node = get_ast("""
a = 1
b = 2
print(a + b)
""")
    transformer = Python2FutureTransformer()
    node = transformer.visit(node)

    from ..utils import compare_ast
    compare_ast(node, """
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
a = 1
b = 2
print(a + b)
""")

# Generated at 2022-06-12 03:40:17.689133
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast.ast3 import parse
    import ast
    import textwrap
    transformer = Python2FutureTransformer()
    node = parse(textwrap.dedent("""\
        pass
        """))
    node = transformer.visit(node)
    assert node.body[0].value.left.id == '__future__'
    assert node.body[1].value.left.id == '__future__'
    assert node.body[2].value.left.id == '__future__'
    assert node.body[3].value.left.id == '__future__'
    assert node.body[4].value.left.id == 'future'
    assert node.body[5].value.left.id == 'future'
    assert node.body[6].value.left.id == 'future'
    assert node

# Generated at 2022-06-12 03:40:18.767567
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor

# Generated at 2022-06-12 03:40:28.606448
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import get_single_node_of_type

    tree = ast.parse("def f(a, b): return a + b")
    transformer = Python2FutureTransformer()
    tree = transformer.visit(tree)
    assert len(tree.body) == imports().count('\n') + 1
    
    module_node = get_single_node_of_type(transformer.tree, ast.Module)
    assert module_node.body[0].value.s == 'absolute_import'
    assert module_node.body[1].value.s == 'division'
    assert module_node.body[2].value.s == 'print_function'
    assert module_node.body[3].value.s == 'unicode_literals'

# Generated at 2022-06-12 03:40:33.434753
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    visitor = Python2FutureTransformer()
    module = ast.parse('print(1, 2)')
    visitor.visit(module)
    assert visitor.tree_changed == True
    expected = ast.parse(imports('__future__') + 'print(1, 2)')
    assert ast.dump(module) == ast.dump(expected)

# Generated at 2022-06-12 03:40:42.550177
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer(None)

    print("\n" + transformer.__class__.__name__)
    print("-" * len(transformer.__class__.__name__))
    print("Unit test for method visit_Module of class Python2FutureTransformer")

    module_ast = ast.parse("""\
import future
from future import absolute_import
from future import division
from future import print_function
from future import unicode_literals

module_constant = True
""")
    module_ast = transformer.visit(module_ast)


# Generated at 2022-06-12 03:40:48.420674
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ... import ast_convert
    from ...tests import data
    from ...utils import six
    from ...visitors.code_gen import to_source

    tree = ast_convert(data.code_sample_module)
    tree = Python2FutureTransformer().visit(tree)

    if six.PY2:
        # If we are running in Python 2, we just want to make sure the
        # transformation doesn't fail
        _ = to_source(tree)

# Generated at 2022-06-12 03:40:55.520573
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # test_tree = ast.parse("print('0')")
    test_tree = ast.parse("if True: print('0')")
    transformer = Python2FutureTransformer()
    transformer.visit(test_tree)
    expected_tree = ast.parse("from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n\nif True: print('0')")
    assert ast.dump(test_tree) == ast.dump(expected_tree)

# Generated at 2022-06-12 03:41:05.607887
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    from ..utils.ast_transformer_test_case import ASTTransformerTestCase, transform_source

    class Test(ASTTransformerTestCase):
        TRANSFORMER = Python2FutureTransformer
        FILES = {}
        SOURCE = """
            x = 'x'
            print('hello')
            x = 1
        """
        EXPECTED_SOURCE = """
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
            
            x = 'x'
            print('hello')
            x = 1
        """

    transform_source(Test)
    assert isinstance(Test.RESULT, ast.Module)

# Generated at 2022-06-12 03:41:12.684327
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    tree = ast.parse('''
        class Foo(object):
            pass
    ''')
    transformer = Python2FutureTransformer()
    transformer.visit(tree)
    assert transformer._tree_changed
    expected = ast.parse('''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals


    class Foo(object):
        pass
    ''')
    assert tree == expected



# Generated at 2022-06-12 03:41:17.274414
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import sys
    import os

    sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
    import autofuture
    import astunparse


# Generated at 2022-06-12 03:41:19.262549
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # GIVEN
    transformer = Python2FutureTransformer
    # WHEN
    # THEN
    assert transformer is not None



# Generated at 2022-06-12 03:41:24.496362
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    node = ast.parse('import sys', mode='exec')
    t = Python2FutureTransformer()
    t.visit(node)

    # from __future__ import absolute_import
    # from __future__ import division
    # from __future__ import print_function
    # from __future__ import unicode_literals
    # 
    # import sys

# Generated at 2022-06-12 03:41:25.864352
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)

# Generated at 2022-06-12 03:41:32.869981
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = """
    def foo(x, y):
        return 2 * x + 2 * y
    """
    tree = ast.parse(module)
    node_transformer = Python2FutureTransformer()
    tree = node_transformer.visit(tree)
    print(astunparse.unparse(tree))

# Generated at 2022-06-12 03:41:36.851325
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    """Test case for method visit_Module of class Python2FutureTransformer. """
    from ast_helpers.tests.base.test_base_transformer import source_to_AST
    from ast_helpers.tests.base.test_base_transformer import AST_to_source

    futurize_path = 'ast_helpers.transformers.py2_future.Python2FutureTransformer'


# Generated at 2022-06-12 03:41:45.533073
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3
    from .transformer import Transformer
    # Get AST of class Python2FutureTransformer from source code.
    from astor import to_source
    source = to_source(Python2FutureTransformer)
    tree = astor.parse_file(io.StringIO(source))
    node = tree.body[0]  # class Python2FutureTransformer
    assert isinstance(node, ast3.ClassDef)
    assert node.name == 'Python2FutureTransformer'
    # Instantiate Python2FutureTransformer
    transformer = Transformer
    constructor = Transformer.__dict__['__init__']
    transformer = constructor(node)
    #print(transformer)

# Generated at 2022-06-12 03:41:58.367791
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    
    # Test code
    code = ("from __future__ import absolute_import\nfrom __future__ import "
            "division\nfrom __future__ import print_function\nfrom __future__ "
            "import unicode_literals\nanother_imports = 'bla'")

    # Target
    target = (2, 7)

    # Expected result
    expected = ("from __future__ import absolute_import\nfrom __future__ import "
                "division\nfrom __future__ import print_function\nfrom __future__ "
                "import unicode_literals\nanother_imports = 'bla'")

    # Unit test
    node = ast.parse(code)
    Python2FutureTransformer(target).visit(node)
    result = compile(node, "<test>", "exec")


# Generated at 2022-06-12 03:41:58.944535
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-12 03:42:03.183527
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    module = ast.parse("")
    transformer.visit(module)
    output = ast.dump(module, annotate_fields=False, include_attributes=False)
    imports.load(output, '__future__')

# Generated at 2022-06-12 03:42:05.121535
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    t = Python2FutureTransformer()
    print(t.visit(ast.parse('def f(): return 1')))


# Generated at 2022-06-12 03:42:13.239536
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astunparse
    x = """
    1 + 2
    """
    tree = ast.parse(x)
    # print(astunparse.unparse(tree))

    transformer = Python2FutureTransformer()
    new_tree = transformer.visit(tree)
    new_source = astunparse.unparse(new_tree)

    assert transformer.tree_changed is True
    # The 'from typed_ast import ast3' above will also be replaced.
    assert """
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

1 + 2
""" == new_source

# Generated at 2022-06-12 03:42:15.065330
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()
    assert t.target == (2, 7)



# Generated at 2022-06-12 03:42:15.651439
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass

# Generated at 2022-06-12 03:42:18.577163
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    future = '__future__'
    transformer = Python2FutureTransformer()
    node = ast.parse('')
    node = transformer.visit(node)
    assert node.body == imports.get_body(future)

# Generated at 2022-06-12 03:42:21.974665
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import typed_ast.ast3 as ast
    node = ast.parse('import sys')
    Python2FutureTransformer().visit(node)
    assert str(node) == imports.get() + 'import sys\n'  # type: ignore

# Generated at 2022-06-12 03:42:23.185292
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer is not None

# Generated at 2022-06-12 03:42:30.373725
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass

# Generated at 2022-06-12 03:42:35.647205
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse("a = 1\nprint('hello')")
    result = Python2FutureTransformer().visit(node)
    assert result.body[0].value.s == "absolute_import"
    assert result.body[3].value.s == "unicode_literals"
    assert result.body[4].value.s == "a"
    assert result.body[4].value.s == "a"

# Generated at 2022-06-12 03:42:37.704377
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.tree_changed is False
    assert transformer.target == (2, 7)

# Generated at 2022-06-12 03:42:39.210373
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)



# Generated at 2022-06-12 03:42:40.671673
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'


# Generated at 2022-06-12 03:42:45.967823
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse('p = 1')
    Python2FutureTransformer().visit(node)
    assert ast.dump(node) == ast.dump(ast.parse('''
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

p = 1
    '''))

# Generated at 2022-06-12 03:42:50.265953
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    node = ast.parse('if True: pass')
    transformer = Python2FutureTransformer()
    assert astor.to_source(transformer.visit(node)) == """\
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

if True: pass"""

# Generated at 2022-06-12 03:42:55.139624
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.testing import assert_equal_source
    assert_equal_source(
        Python2FutureTransformer,
        '''
        def foo():
            pass
        ''',
        '''
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        
        def foo():
            pass
        '''
    )

# Generated at 2022-06-12 03:43:00.657374
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    result = Python2FutureTransformer().visit(ast.parse(dedent("""
        # some single-line comment
        a = 42
        b = a * 2
        print(b)
    """)))
    assert result == ast.parse(dedent("""
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
            
        # some single-line comment
        a = 42
        b = a * 2
        print(b)
    """))

# Generated at 2022-06-12 03:43:01.919041
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert True, "Unit test not implemented"

# Generated at 2022-06-12 03:43:18.631571
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    global c
    c = Python2FutureTransformer()
    assert c._tree_changed == False
    assert c.target == (2, 7)
    assert c.visit_Module.__name__ == 'visit_Module'

# Generated at 2022-06-12 03:43:26.701078
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast

    code = "print('Hello world!')"
    tree = ast.parse(code)
    Python2FutureTransformer().visit(tree)

# Generated at 2022-06-12 03:43:33.959527
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    body = [
        ast.Expr(ast.Name('foo', ast.Store())),
        ast.Expr(ast.Name('bar', ast.Store()))
    ]
    module = ast.Module(body)
    node = Python2FutureTransformer(module).visit(module)
    assert node == ast.copy_location(ast.Module(imports.get_body(future='__future__') + body), module)



# Generated at 2022-06-12 03:43:36.013096
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Unit test for constructor of class Python2FutureTransformer"""

    # It should show the right target version
    assert Python2FutureTransformer.target == (2, 7)



# Generated at 2022-06-12 03:43:40.169646
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    node = ast.parse('print(1)')
    assert Python2FutureTransformer().visit(node) == ast.parse(
        '''from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
print(1)''', mode='exec'
    )

# Generated at 2022-06-12 03:43:41.524735
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils import make_module


# Generated at 2022-06-12 03:43:47.768573
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor
    code = """\
# comment
from __future__ import print_function
import sys
"""
    module = ast.parse(code)
    module = Python2FutureTransformer().visit(module)
    code = astor.to_source(module)
    assert code == """\
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

# comment
from __future__ import print_function
import sys
"""

# Generated at 2022-06-12 03:43:48.793811
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__doc__ is not None

# Generated at 2022-06-12 03:43:53.943375
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .fixtures import py2_future_module_node, py2_future_module_node_expected
    py2_future_transformer = Python2FutureTransformer()
    assert py2_future_transformer.visit(py2_future_module_node) == py2_future_transformer.generic_visit(py2_future_module_node_expected)



# Generated at 2022-06-12 03:43:58.149442
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = ast.parse("")
    transformer = Python2FutureTransformer(module)
    new_module = transformer.visit(module)
    assert new_module.body[0].value.args[0].s == '__future__'

# Generated at 2022-06-12 03:44:36.271770
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    from ..utils.source_transform import SourceTransform
    from .utils.test_visitor import TestVisitor
    from .utils.test_utils import get_test_files

    for filename in get_test_files('test_python2_future.py'):
        source_transform = SourceTransform(filename)
        tree = source_transform.tree
        visitor = TestVisitor()

        visitor.visit(tree)
        assert '[python2_future] visit_Module\n' \
            == visitor.trace

        visitor = Python2FutureTransformer()
        result = visitor.visit(tree)

# Generated at 2022-06-12 03:44:40.457358
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.visitor import dump
    from ..utils.fixtures import ast_module
    from ..utils.examples import module_ex

    for source in module_ex():
        node = ast_module(source)
        expected = Python2FutureTransformer(node).visit(node)
        assert dump(node) == dump(expected)

# Generated at 2022-06-12 03:44:41.289831
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-12 03:44:50.025301
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Future


# Generated at 2022-06-12 03:44:53.578044
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-12 03:44:54.815567
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert isinstance(Python2FutureTransformer(), BaseNodeTransformer)

# Generated at 2022-06-12 03:45:02.274630
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from textx.exceptions import TextXSyntaxError
    from textx import metamodel_from_str
    from .. import utils
    from ..utils import _ast2dot

    python_mm = metamodel_from_str(utils.python_meta_model,
                                   global_repository=utils.python_global_repository,
                                   debug=False,
                                   classes=[Python2FutureTransformer])

    #check that it is working
    assert isinstance(python_mm, Python2FutureTransformer)

    #test without a syntax error
    code = import_("typed_ast")
    code = python_mm.model_from_str(code)
    code = python_mm.model_to_str(code)
    assert 'from __future__ import absolute_import' in code

    #test

# Generated at 2022-06-12 03:45:03.240173
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-12 03:45:12.996639
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import os.path
    import sys
    import astor
    from python_to_python.transformers.python2_future import Python2FutureTransformer
    from ..utils.ast_builder import build_ast_from_str
    from ..utils.ast_comparator import AstComparator

    # Arrange
    transformer = Python2FutureTransformer()
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), '../_testdata/print_hello.py')
    with open(path, 'r') as f:
        input_ast_str = f.read()
    
    reference_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), '../_testdata/future.py')

# Generated at 2022-06-12 03:45:18.459662
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer(): # unit test for class Python2FutureTransformer
    # Arguments
    node = ast.Module()
    # Expectations
    expectations = {'tree_changed': True}  # type: Dict[str, Any]
    # Execution
    transformer = Python2FutureTransformer()
    result = transformer.visit_Module(node)  # type: ignore
    # Checking
    assert transformer._tree_changed == expectations['tree_changed']
    assert len(result.body) == 4  # type: ignore


# Generated at 2022-06-12 03:46:29.334780
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    snippet_imports = (
        "import sys\n"
        "if sys.version_info < (3, 0):\n"
        "    from __future__ import absolute_import\n"
        "    from __future__ import division\n"
        "    from __future__ import print_function\n"
        "    from __future__ import unicode_literals\n"
    )
    assert Python2FutureTransformer().visit(ast.parse('import json')).body[0].lineno == 6
    assert Python2FutureTransformer().visit(ast.parse('import json')).body[0].col_offset == 7
    assert ast.dump(Python2FutureTransformer().visit(ast.parse('import json'))) == ast.dump(ast.parse(snippet_imports + 'import json'))

# Generated at 2022-06-12 03:46:32.864844
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    s = """\
print("Hello, world!") 
"""
    nodes = ast.parse(s)
    t = Python2FutureTransformer()
    t.visit(nodes)
    assert astunparse.unparse(nodes) == imports.get_text(future='__future__') + s

# Generated at 2022-06-12 03:46:41.478564
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # Code to test:
    code = '''print sub(2, 3)'''
    # Desired output:
    # from __future__ import absolute_import
    # from __future__ import division
    # from __future__ import print_function
    # from __future__ import unicode_literals
    # print sub(2, 3)
    module = ast.parse(code)
    Python2FutureTransformer().visit(module)
    expected = '''from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

print sub(2, 3)'''
    actual = astunparse.unparse(module)
    assert expected == actual
    return

# Generated at 2022-06-12 03:46:42.834276
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    ntt = Python2FutureTransformer()
    #assert isinstance(ntt, BaseNodeTransformer)

# Generated at 2022-06-12 03:46:44.783984
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    def get_in_out():
        return ((),
                Python2FutureTransformer())

    check_transformer(*get_in_out())

# Generated at 2022-06-12 03:46:48.440303
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast

    module = ast.parse("print(\"Hello, world!\")")
    visitor = Python2FutureTransformer()
    module = visitor.visit(module)
    assert isinstance(module, ast.Module)
    assert visitor._tree_changed

# Generated at 2022-06-12 03:46:57.565061
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    class Dummy(Python2FutureTransformer):
        def _init_options(self):
            self.module_body = ast.parse(
                "print('hello world')\n" +
                "print(2 // 3)\n" +
                "print(2 / 3)\n" +
                "print('{}'.format('hello', 'world'))")  # noqa

    transformer = Dummy()
    module = transformer.visit(ast.Module())  # type: ignore
    body = module.body  # type: ignore
    # Check that there are 4 additional statements added to the body
    assert len(body) - len(transformer.module_body.body) == 4
    assert isinstance(body[0], ast.ImportFrom)
    assert isinstance(body[1], ast.ImportFrom)

# Generated at 2022-06-12 03:47:01.228309
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import parse
    node = parse('def foo(x): return x+1')
    tr = Python2FutureTransformer()
    result = tr.visit(node)
    assert result == parse(imports(future='__future__') + '\ndef foo(x): return x+1')
    assert tr._tree_changed

# Generated at 2022-06-12 03:47:04.476407
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import TreeTestCase
    from .. import example_files

    class TestCase(TreeTestCase):
        transformer = Python2FutureTransformer
        target = (2, 7)
        target_tree = example_files.future
        expected_tree = example_files.future

    test = TestCase()
    test.test()

# Generated at 2022-06-12 03:47:05.519109
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    x = Python2FutureTransformer()
    assert x is not None


# Generated at 2022-06-12 03:49:40.108607
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast.transforms.Python2Future import Python2FutureTransformer
    Python2FutureTransformer(None, None)



# Generated at 2022-06-12 03:49:40.752193
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-12 03:49:41.510017
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-12 03:49:47.218281
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer.__doc__ == \
           "Prepends module with:\n" \
           "    from __future__ import absolute_import\n" \
           "    from __future__ import division\n" \
           "    from __future__ import print_function\n" \
           "    from __future__ import unicode_literals\n" \
           "        \n" \
           "    "
