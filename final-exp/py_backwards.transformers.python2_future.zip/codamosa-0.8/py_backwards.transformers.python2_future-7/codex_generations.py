

# Generated at 2022-06-12 03:39:49.116962
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    Method = ast.parse('def method():\n      pass')
    transformed = Python2FutureTransformer().visit(Method)
    compare(transformed.body[0], Method.body[0])
    compare(transformed, expected='\n'.join(imports.get_body(future='__future__')) + expected)



# Generated at 2022-06-12 03:39:50.516330
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-12 03:39:59.697179
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    ctx = {'_tree_changed': False}
    source = """x = 1"""
    expected = """from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

x = 1\n"""
    tree = ast.parse(source)
    node = Python2FutureTransformer(ctx).visit(tree)
    result = compile(node, '<string>', 'exec')
    code = result.co_consts[0]
    assert code == expected
    assert ctx['_tree_changed']

# Generated at 2022-06-12 03:40:07.809101
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = ast.parse('print("aaa")')
    Python2FutureTransformer().visit(module)

# Generated at 2022-06-12 03:40:17.650366
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    from ...transformer.python2 import Python2FutureTransformer
    transformer = Python2FutureTransformer()
    node = ast.parse('x = True')
    result = transformer.visit(node)

# Generated at 2022-06-12 03:40:21.377347
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    class TestTransformer(Python2FutureTransformer):
        def __init__(self, tree):
            super(TestTransformer, self).__init__(tree)
            self.str = ''
        def visit_Num(self, node: ast.Num) -> None:
            self.str += str(node.n)

# Generated at 2022-06-12 03:40:29.904030
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    test_code = textwrap.dedent("""
        def my_func():
            print 'hello'
    """)

    expected_code = textwrap.dedent('''\
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        def my_func():
            print 'hello'
    ''')

    tree = ast.parse(test_code)
    transformer = Python2FutureTransformer()
    transformer.visit(tree)
    assert ast.dump(tree) == ast.dump(ast.parse(expected_code)), "Transformed tree didn't match expected tree."

# Generated at 2022-06-12 03:40:39.679512
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse('a = 1')
    transformer = Python2FutureTransformer()
    transformer.visit(node)
    assert ast.dump(node) == '''Module(body=[ImportFrom(module='future', names=[alias(name='absolute_import', asname=None)], level=0), ImportFrom(module='future', names=[alias(name='division', asname=None)], level=0), ImportFrom(module='future', names=[alias(name='print_function', asname=None)], level=0), ImportFrom(module='future', names=[alias(name='unicode_literals', asname=None)], level=0), Assign(targets=[Name(id='a', ctx=Store())], value=Num(n=1))])'''  # noqa: E501

# Generated at 2022-06-12 03:40:47.127035
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    import ast
    module = ast.Module()
    module.body = [ast.Expr(ast.Str(s='Hello World'))]
    print(module)
    transformer = Python2FutureTransformer()
    module = transformer.visit(module)
    print(module)
    print(astor.to_source(module))

# import ast
# import astor
# from typing import List
# from ..utils.snippet import snippet
# from .base import BaseNodeTransformer

# @snippet
# def imports(future):
#     from future import absolute_import
#     from future import division
#     from future import print_function
#     from future import unicode_literals


# class Python2FutureTransformer(BaseNodeTransformer):
#     """Prepends module with:
#        

# Generated at 2022-06-12 03:40:48.790548
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    print(Python2FutureTransformer('', ()).visit(ast.parse("print('hello world')", mode='exec')))

# Generated at 2022-06-12 03:40:52.037068
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer is not None

# Generated at 2022-06-12 03:40:52.994158
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    p2ft = Python2FutureTransformer()
    print(p2ft)

# Generated at 2022-06-12 03:40:54.481116
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-12 03:40:55.564776
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()

    assert transformer is not None

# Generated at 2022-06-12 03:40:57.019620
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer() is not None


# Generated at 2022-06-12 03:41:00.009757
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    tree = imports.get_ast(future='__future__')

    class TestTransformer(Python2FutureTransformer):
        pass

    assert TestTransformer().visit(tree) == tree



# Generated at 2022-06-12 03:41:09.682204
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()
    module = ast.Module()

    func = ast.FunctionDef("function", ast.arguments(), [], [], None)

    module.body = [func]

    module = transformer.visit(module)

    assert isinstance(module, ast.Module)
    assert isinstance(module.body, list)
    assert isinstance(module.body[0], ast.ImportFrom)
    assert isinstance(module.body[1], ast.ImportFrom)
    assert isinstance(module.body[2], ast.ImportFrom)
    assert isinstance(module.body[3], ast.ImportFrom)
    assert isinstance(module.body[4], ast.FunctionDef)


# Generated at 2022-06-12 03:41:15.370147
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse("# Module1\n")
    new_node = Python2FutureTransformer(None).visit(node)
    code = ast.unparse(new_node)
    assert code == "# Module1\nfrom __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n"



# Generated at 2022-06-12 03:41:22.908979
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():

    class MockTransformer(Python2FutureTransformer):
        def __init__(self):
            self._visited_nodes = []
            super(MockTransformer, self).__init__()

        def generic_visit(self, node: ast.AST) -> ast.AST:
            """Mock for generic_visit method of BaseNodeTransformer"""
            self._visited_nodes.append(node)
            return node

    # Mocking an AST node
    tree = ast.parse('def my_func():\n    pass', mode='exec')
    mock_ast = tree.body[0]

    # Checking state of method visited_nodes before calling method visit_Module of MockTransformer
    mock_transformer = MockTransformer()
    assert mock_transformer._visited_nodes == []
    assert mock_transformer

# Generated at 2022-06-12 03:41:32.812835
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor  # type: ignore
    test_ast = astor.parse_file('tests/samples/python2future01.py')
    assert isinstance(test_ast, ast.Module)
    transformer = Python2FutureTransformer()
    transformed = transformer.visit(test_ast)
    assert isinstance(transformed, ast.Module)

    # Test that the correct number of statements are prepended
    assert len(transformed.body) == 5
    assert isinstance(transformed.body[0], ast.ImportFrom)
    assert transformed.body[0].module == '__future__'
    assert transformed.body[0].names[0].name == 'absolute_import'
    assert isinstance(transformed.body[1], ast.ImportFrom)
    assert transformed.body[1].module == '__future__'
   

# Generated at 2022-06-12 03:41:42.039635
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    print('Testing Python2FutureTransformer.visit_Module')
    module = """
    @decorator
    def func():
        print('Hello World')
        return 'Success'
    """

# Generated at 2022-06-12 03:41:42.887159
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer([])


# Generated at 2022-06-12 03:41:44.446534
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    p2ft = Python2FutureTransformer()
    assert p2ft.target == (2, 7)

# Generated at 2022-06-12 03:41:46.872255
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Unit test for constructor of class Python2FutureTransformer.
    """
    obj = Python2FutureTransformer()
    assert obj is not None


# Generated at 2022-06-12 03:41:48.220226
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer is not None



# Generated at 2022-06-12 03:41:55.524099
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils import run_transformer
    from .fake import fake

    source = """
    def somefunc():
        print('Hello, world!')
    """

    tree = fake.get_ast(source)
    run_transformer(Python2FutureTransformer, tree)

    import astor
    printed = astor.dump_tree(tree)
    expected = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    def somefunc():
        print('Hello, world!')"""
    assert printed.strip() == expected.strip()

# Generated at 2022-06-12 03:42:01.457816
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import python_modernize
    s = StringIO()
    imports.write_to_stream(s, future='__future__')
    expected = s.getvalue() + '1 / 2\n'
    actual = ''.join(
        python_modernize.convert(
            '1 / 2',
            stage=2,
            write=True,
        )
    )
    assert expected == actual

# Generated at 2022-06-12 03:42:04.316855
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast

    obj = Python2FutureTransformer()

    node = ast.Module([])
    new_node = obj.visit_Module(node)

    a

# Generated at 2022-06-12 03:42:07.899185
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    node = ast.parse('x=1')
    result = imports.get_body(future='__future__') + node.body  # type: ignore
    #print(result)
    transformer = Python2FutureTransformer()
    new_tree = transformer.visit(node)
    assert transformer._tree_changed == True

# Generated at 2022-06-12 03:42:17.971795
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import copy
    import sys
    import types
    import astor

    sys.modules['__main__'] = types.ModuleType('__main__')
    node = ast.parse("class Foo:\n    pass\n", mode='exec')  # type: ignore
    node = copy.deepcopy(node)

    transformer = Python2FutureTransformer()  # noqa
    new_node = transformer.visit(node)

# Generated at 2022-06-12 03:42:34.695971
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse('import os')
    transformer = Python2FutureTransformer()
    node = transformer.visit(node)
    assert transformer._tree_changed is True
    assert ast.dump(node) == '''Module(body=[ImportFrom(module='__future__', names=[alias(name='absolute_import', asname=None)], level=0), ImportFrom(module='__future__', names=[alias(name='division', asname=None)], level=0), ImportFrom(module='__future__', names=[alias(name='print_function', asname=None)], level=0), ImportFrom(module='__future__', names=[alias(name='unicode_literals', asname=None)], level=0), Import(names=[alias(name='os', asname=None)])])'''

# Generated at 2022-06-12 03:42:39.597102
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    t = Python2FutureTransformer()
    tree = ast.parse("")
    t.visit(tree)
    assert ast.dump(tree) == "Module(body=[Import(names=[alias(name='absolute_import', asname=None)]), Import(names=[alias(name='division', asname=None)]), Import(names=[alias(name='print_function', asname=None)]), Import(names=[alias(name='unicode_literals', asname=None)])])"

# Generated at 2022-06-12 03:42:46.728537
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse(textwrap.dedent('''\
        def sample(a):
            return a
        '''))
    visitor = Python2FutureTransformer()
    result = visitor.visit(node)
    assert result.body[0].names[0].name == 'absolute_import'
    assert result.body[0].names[1].name == 'division'
    assert result.body[0].names[2].name == 'print_function'
    assert result.body[0].names[3].name == 'unicode_literals'

# Generated at 2022-06-12 03:42:48.774488
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer is not None
    assert callable(transformer) is False


# Generated at 2022-06-12 03:42:53.896137
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    """
    Test visit_Module of Python2FutureTransformer.
    """
    from ..utils.node_utils import nodes_equal
    from ..utils.source_utils import source_to_node

    source = """\
print(1)
"""
    node = source_to_node(source)

    result = nodes_equal(
        node,
        Python2FutureTransformer().visit(node)  # type: ignore
    )

    assert result

# Generated at 2022-06-12 03:42:57.748591
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    py2futuretran = Python2FutureTransformer()
    ast_tree = ast.parse("")
    ast_tree = py2futuretran.visit(ast_tree)
    imports_ = imports.get_body()
    expected_ast = ast.parse("".join(imports_))
    assert ast.dump(ast_tree) == ast.dump(expected_ast)

# Generated at 2022-06-12 03:43:02.204246
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # init transformer
    transformer = Python2FutureTransformer()
    # construct snippet
    code = """\
print('foo')
    """
    code_ast = ast.parse(code)
    # run transformation
    transformer.visit(code_ast)
    # check result
    assert str(code_ast) == imports.get_source(future='__future__') + code

# Generated at 2022-06-12 03:43:07.979012
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast

    tree = ast.parse('''a = 1''')
    python2_future_transformer = Python2FutureTransformer()
    assert python2_future_transformer.visit(tree) == ast.parse('''from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\na = 1''')

# Generated at 2022-06-12 03:43:10.535910
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    mod = ast.parse('1 + 2')
    new_mod = Python2FutureTransformer().visit(mod)
    assert ast.dump(mod) == ast.dump(new_mod)


# Generated at 2022-06-12 03:43:11.131108
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-12 03:43:36.081248
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as _ast
    from ..test_utils import transform_test
    

# Generated at 2022-06-12 03:43:45.103014
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    tests = [
        ('a = 5',
         'from __future__ import absolute_import\n'
         'from __future__ import division\n'
         'from __future__ import print_function\n'
         'from __future__ import unicode_literals\n'
         'a = 5'),
        ('',
         'from __future__ import absolute_import\n'
         'from __future__ import division\n'
         'from __future__ import print_function\n'
         'from __future__ import unicode_literals\n'),
    ]
    for source, expected in tests:
        module = parse(source, '<string>')
        visitor = Python2FutureTransformer()
        module = visitor.visit(module)  # type: ignore

        # assert that we successfully imported future into module

# Generated at 2022-06-12 03:43:51.320261
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    from textwrap import dedent

    node = ast.parse(dedent('''
    start = 7
    '''))
    Python2FutureTransformer().visit(node)
    assert astor.to_source(node).strip() == dedent('''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    start = 7
    ''').strip()

# Generated at 2022-06-12 03:43:58.338831
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    sample_code = 'import sys'
    expected_transformation = 'from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n\nimport sys\n'
    actual_transformation = source_to_source_transformation(
        sample_code, Python2FutureTransformer)

    assert actual_transformation == expected_transformation

# Generated at 2022-06-12 03:44:03.957753
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # type: () -> None
    code = dedent('''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    
    
    
    def foo():
        pass
    ''')
    expected = dedent('''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    
    def foo():
        pass
    ''')
    node = ast.parse(code)
    Python2FutureTransformer().visit(node)
    assert astunparse.unparse(node) == expected

# Generated at 2022-06-12 03:44:05.554003
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()
    assert isinstance(t, BaseNodeTransformer)


# Generated at 2022-06-12 03:44:11.814626
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ...testing_utils.python2 import parse_python2_source


# Generated at 2022-06-12 03:44:12.780150
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-12 03:44:18.869875
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils import ast_parse, ast_dump
    result = ast_dump(Python2FutureTransformer().visit(ast_parse(
        'a = 1\n'
        '\n'
        'def f():\n'
        '    return 2\n'
    )))
    expected = ast_dump(ast_parse(
        'from __future__ import absolute_import\n'
        'from __future__ import division\n'
        'from __future__ import print_function\n'
        'from __future__ import unicode_literals\n'
        'a = 1\n'
        '\n'
        'def f():\n'
        '    return 2\n'
    ))
    assert result == expected

# Generated at 2022-06-12 03:44:27.663169
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from astroid import parse

    # testing Python3 structure, which should not change
    code = """\
    def my_func():
        pass
    """

    node = parse(code)
    Python2FutureTransformer().visit(node)
    assert str(node) == code
    assert Python2FutureTransformer._tree_changed is False

    # testing Python2 structure
    code = """\
    def my_func():
        pass
    """
    node = parse(code, version='2.7')
    Python2FutureTransformer().visit(node)

    assert str(node) == """\
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals


    def my_func():
        pass
    """


# Generated at 2022-06-12 03:45:01.084980
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse('A=1')
    result = Python2FutureTransformer().visit(node).body[0]
    expected = ast.Assign(targets=[ast.Name(id='A', ctx=ast.Store())],  # type: ignore
                          value=ast.Num(n=1))
    assert ast.dump(result) == ast.dump(expected)

# Generated at 2022-06-12 03:45:06.715705
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast.ast3 import parse
    module = 'a=1+2\nprint("Hello")'
    expected = '''from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

a=1+2
print("Hello")'''
    assert Python2FutureTransformer(parse(module)).visit(parse(module)) == parse(expected)

# Generated at 2022-06-12 03:45:15.842809
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_builder import build
    from ..utils.source_factory import source

    t = Python2FutureTransformer()
    original = build(ast.Module, [
        ast.FunctionDef(
            name='f',
            args=ast.arguments(args=[ast.arg(arg='x', annotation=None)],
                               vararg=None,
                               kwonlyargs=[],
                               kw_defaults=[],
                               kwarg=None,
                               defaults=[]),
            body=[ast.Print(dest=None, values=[ast.Num(n=1)], nl=True)],
            decorator_list=[],
            returns=None)
    ])


# Generated at 2022-06-12 03:45:21.850197
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor
    from python_modernize import transformer_factory, walker_factory
    from textwrap import dedent

    source = dedent("""
        import time
        import urlparse

        def f(n):
            return n+1
    """)

    tree = astor.parse_tree(source)
    tree = walker_factory.make_default_walker(source, tree).walk()
    tree = transformer_factory.make_transformer(source, tree,
                                                Python2FutureTransformer).walk()

    d = ast.dump(tree)

# Generated at 2022-06-12 03:45:26.868479
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    tree = ast.parse('x=1')
    t = Python2FutureTransformer()
    t.visit(tree)
    assert t._tree_changed
    assert str(tree) == '''from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n\nx = 1\n'''



# Generated at 2022-06-12 03:45:33.508360
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import ast as pyast
    from .base import BaseNodeTest
    class Python2FutureTransformerTest(BaseNodeTest):
        target = (2, 7)
        NodeTransformer = Python2FutureTransformer
        def test_prepends_module_with_from_future_imports(self):
            code = 'a = 42'
            module = pyast.parse(code)
            tree = Python2FutureTransformer().visit(module)  # type: ignore
            self.compare_source(tree, 'from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\na = 42')

# Generated at 2022-06-12 03:45:37.464540
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    error_msg = """Module has wrong type, expected <class 'typed_ast.ast3.Module'> but got <class 'typed_ast.ast3.FunctionDef'>"""
    with pytest.raises(TypeError, match=error_msg):
        Python2FutureTransformer(tree=ast.FunctionDef())



# Generated at 2022-06-12 03:45:40.680414
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)
    assert transformer._tree_changed is False


# Generated at 2022-06-12 03:45:48.646517
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from mypy import api
    from future import absolute_import
    from future import division
    from future import print_function
    from future import unicode_literals

    # Loads modules from string
    result = api.parse('''
    from future import _extra
    from future import arithmetic
    from future import builtins
    from future import comments
    from future import generators
    from future import iterations
    from future import library
    from future import misc
    from future import standard_library
    from future import strings
    from future import utils
    from future import tests

    def foo():
        pass
    ''')
    
    # Sends it to the transformer and gets the result
    result = Python2FutureTransformer().visit(result)

    # Checks the result
    assert isinstance(result, ast.Module)

# Generated at 2022-06-12 03:45:52.706850
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    tree = ast.parse('''if True:
    print('hello')
    ''')

    tree = Python2FutureTransformer().visit(tree)    # type: ignore
    assert tree.body[0].test.left.value == True       # type: ignore
    assert tree.body[0].body[0].value.s == 'hello'    # type: ignore

# Generated at 2022-06-12 03:47:01.370650
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    code = 'print("hello")'
    tree = ast.parse(code)
    trans = Python2FutureTransformer()
    tree = trans.visit(tree)
    assert compile(tree, '<test>', 'exec')

# Generated at 2022-06-12 03:47:07.225384
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    class MyTransformer(Python2FutureTransformer):
        pass
    tree = ast.parse(textwrap.dedent("""\
    import os

    def foo():
        pass """))
    result = MyTransformer().visit(tree)
    assert isinstance(result, ast.Module)
    expected = ast.parse(textwrap.dedent("""\
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    import os

    def foo():
        pass """))
    assert ast.dump(tree, annotate_fields=False, include_attributes=False) == ast.dump(expected, annotate_fields=False, include_attributes=False)

# Generated at 2022-06-12 03:47:15.070145
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    node = ast.parse("""if __name__ == '__main__':
    x = 1
    print(x)
    x += 1
    print(x)
""")
    expected_node = ast.parse("""from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

if __name__ == '__main__':
    x = 1
    print(x)
    x += 1
    print(x)
""")
    actual_node = Python2FutureTransformer().visit(node)
    assert ast.dump(actual_node) == ast.dump(expected_node)

# Generated at 2022-06-12 03:47:21.043186
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils import proper_indentation, tree_to_str
    tree = ast.parse("def main():\n    pass")
    transformer = Python2FutureTransformer()
    transformer.visit(tree)
    assert tree_to_str(tree) == proper_indentation('''
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        def main():
            pass
        ''')

# Generated at 2022-06-12 03:47:25.984632
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse('print(1)')
    expected_node = ast.parse(
        dedent('''\
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        print(1)'''))
    transformer = Python2FutureTransformer()
    actual_node = transformer.visit(node)
    assert ast.dump(actual_node) == ast.dump(expected_node)

# Generated at 2022-06-12 03:47:30.160622
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transpiler = Python2FutureTransformer()
    tree = transpiler.visit(ast.parse('a = 1'))
    assert str(tree) == '''\
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
a = 1'''

# Generated at 2022-06-12 03:47:36.475264
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    from ..utils.ast_builder import code_to_ast
    from ..fixers.python2 import Python2FutureTransformer

    code = '''
    import requests
    def main():
        return 1
    '''
    ast_ = code_to_ast(code)
    t = Python2FutureTransformer()
    result = t.visit(ast_)
    astor.dump(result)
    output = astor.to_source(result)
    assert output == "from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n\n\nimport requests\n\ndef main():\n    return 1\n\n"

# Generated at 2022-06-12 03:47:39.764189
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """ Test constructor of class Python2FutureTransformer """
    import inspect
    source = '''
    class Foo:
        
        def bar(self):
            return
            '''
    node = ast.parse(source)
    transformer = Python2FutureTransformer()
    transformer.visit(node)
    transformer.generic_visit(node)
    assert inspect.getsource(transformer) == source

# Generated at 2022-06-12 03:47:41.376957
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.target == (2, 7)
    assert Python2FutureTransformer._tree_changed == False
    instance = Python2FutureTransformer()
    assert instance._tree_changed == False


# Generated at 2022-06-12 03:47:49.483848
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .codegen import to_source
    from .generate_random_ast import generate_random_ast
    from ..utils.visitor import print_node
    import random
    for _ in range(100):
        module = generate_random_ast(allowed_types=[ast.Module], version=2)
        print_node(module, version=2)
        random_module = Python2FutureTransformer().visit(module)  # type: ignore
        source = to_source(random_module, version=2)
        print(source)
        assert Python2FutureTransformer.target == ast.parse(source).body[0].value.args[0].n
        assert source.startswith('from __future__ import absolute_import')
        assert source.startswith('from __future__ import division')