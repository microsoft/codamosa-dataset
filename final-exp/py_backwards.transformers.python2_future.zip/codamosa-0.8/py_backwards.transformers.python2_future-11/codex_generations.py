

# Generated at 2022-06-12 03:40:01.013342
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..snippet import snippet
    from ..utils.visitor import NodeVisitor
    import inspect
    import copy

    with open("test.py") as f:
        src_code = f.read()
    tree = ast.parse(src_code)
    visitor = NodeVisitor()
    visitor.visit(tree)
    for node in visitor.nodes:
        assert(isinstance(node, ast.Module))
        copy_tree = copy.deepcopy(node)
        trs = Python2FutureTransformer()
        trs.visit_Module(copy_tree)
        assert(trs._tree_changed)
        assert(len(copy_tree.body) == len(node.body) + 4)

# Generated at 2022-06-12 03:40:08.577653
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from astor import to_source
    from pprint import pprint
    from coalaipy.transformer.constants import LANGUAGE_MAP
    from coalaipy.transformer.context import TransformerContext
    from coalaipy.exceptions import TransformerException
    import os
    import sys

    # Python 2.7.17
    sys.version_info = (2, 7, 17)

    transformer = LANGUAGE_MAP[2][7].transformer
    transformer_context = TransformerContext(
        'transformer.visitor.math.MathVisitor',
        'test_Python2FutureTransformer_visit_Module',
        2,
        7,
        2
    )
    transformer = Python2FutureTransformer(transformer_context)

# Generated at 2022-06-12 03:40:13.561558
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    source = """
x = 1
"""
    tree = ast.parse(source)
    Python2FutureTransformer().visit(tree)
    new_source = astor.to_source(tree)
    expected_source = """
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
x = 1
"""
    assert new_source == expected_source

# Generated at 2022-06-12 03:40:16.175077
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    from mypy_boto3_builder.structures.method import Method
    
    mock_method = Method()

# Generated at 2022-06-12 03:40:16.635539
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    pass

# Generated at 2022-06-12 03:40:25.828617
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    class MockNode:
        def __init__(self, body: list) -> None:
            self.body = body
    node = MockNode(
        [
            ast.Print(),  # type: ignore
        ]
    )
    transformer = Python2FutureTransformer()
    transformer.visit_Module(node)
    assert node.body[0] == ast.ImportFrom(
        module='__future__',  # type: ignore
        names=[ast.alias(name='absolute_import', asname=None)],  # type: ignore
    )
    assert node.body[1] == ast.ImportFrom(
        module='__future__',  # type: ignore
        names=[ast.alias(name='division', asname=None)],  # type: ignore
    )
    assert node.body[2] == ast.Import

# Generated at 2022-06-12 03:40:28.069681
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    trans = Python2FutureTransformer()
    node = ast.parse('def f(): pass')
    assert trans.visit(node) is node

# Generated at 2022-06-12 03:40:35.093830
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    code = "import os"
    expected_code = "from __future__ import absolute_import\n" \
                    "from __future__ import division\n" \
                    "from __future__ import print_function\n" \
                    "from __future__ import unicode_literals\n\n" \
                    "import os"
    tree = ast.parse(code)
    result = Python2FutureTransformer().visit(tree)
    assert ast.dump(result, include_attributes=False) == expected_code



# Generated at 2022-06-12 03:40:39.867277
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    code = ''

    tree = ast.parse(code)
    transformer = Python2FutureTransformer()
    transformer.visit(tree)

    assert transformer._tree_changed is True
    assert ast.dump(tree) == "from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n\n"

# Generated at 2022-06-12 03:40:47.244391
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    tree = ast.parse('''
    x = 5
    def foo():
        pass
    ''')
    Python2FutureTransformer().visit(tree)

# Generated at 2022-06-12 03:40:56.901201
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .base import BaseNodeTransformerTest
    from .base import BaseNodeTransformerTestWithNode
    from ..examples import (
        TEST_MODULE_WITH_IMPORTS,
        TEST_MODULE_WITH_IMPORTS_OUTPUT,
        TEST_MODULE_WITH_TWO_IMPORTS,
        TEST_MODULE_WITH_TWO_IMPORTS_OUTPUT,
        TEST_MODULE_WITH_MULTIPLE_IMPORTS,
        TEST_MODULE_WITH_MULTIPLE_IMPORTS_OUTPUT,
        TEST_MODULE_WITH_FUTURE_IMPORT,
        TEST_MODULE_WITH_FUTURE_IMPORT_OUTPUT,
    )

# Generated at 2022-06-12 03:41:06.465764
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    lines = [
        "import os",
        "import sys",
        "print('Hello, world!')"
    ]
    expected_output = [
        "from __future__ import absolute_import",
        "from __future__ import division",
        "from __future__ import print_function",
        "from __future__ import unicode_literals",
        "import os",
        "import sys",
        "print('Hello, world!')"
    ]
    source = '\n'.join(lines)
    tree = ast.parse(source)
    tree = Python2FutureTransformer().visit(tree)
    output = astunparse.unparse(tree).split('\n')
    assert output == expected_output

# Generated at 2022-06-12 03:41:08.024629
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target==(2,7)

# Generated at 2022-06-12 03:41:10.131754
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer(None)
    assert t.target == (2, 7)
    assert t.visit


# Generated at 2022-06-12 03:41:12.166835
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer(None)
    assert transformer.target == (2, 7)

# Unit tests for imports

# Generated at 2022-06-12 03:41:14.136618
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer().target == (2, 7)


# Generated at 2022-06-12 03:41:17.332889
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..converter import pgen2_gen

    ast_tree = pgen2_gen.parse('print("Hello, world")')
    transformer = Python2FutureTransformer()
    transformer.visit(ast_tree)
    assert transformer._tree_changed

# Generated at 2022-06-12 03:41:22.191092
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()
    code_input = """
import sys
x = 1
"""
    expected_output = """
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
import sys
x = 1
"""
    node = ast.parse(code_input)
    transformer.visit(node)
    output = codegen.to_source(node)
    assert output == expected_output

# Generated at 2022-06-12 03:41:25.954519
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()
    tree = future_imports.get_ast(future='__future__')
    tree = transformer.visit(tree)
    code = future_imports.get_source(future='__future__')
    source = astor.to_source(tree)
    assert source == code

# Generated at 2022-06-12 03:41:27.320365
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'

# Generated at 2022-06-12 03:41:34.184491
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    @snippet
    def module():
        x = 5
        
    importer = Python2FutureTransformer()
    importer.visit(module.get_ast())
    assert ast.dump(importer.tree) == module.get_ast_modified_with(imports)

# Generated at 2022-06-12 03:41:43.313587
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from textwrap import dedent as trim
    from ..utils.source import source_to_unicode

    class MockAST(ast.AST): pass

    source = source_to_unicode(trim("""
    a = 1
    """))

    expected = source_to_unicode(trim("""
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    
    a = 1
    """))

    # Mock module node
    node = MockAST()
    node.body = [MockAST()]
    node.lineno = 0
    node.col_offset = 0

    t = Python2FutureTransformer()
    r = t.visit_Module(node)
    
    assert t._tree_changed

# Generated at 2022-06-12 03:41:48.263595
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils import run_transformer_on_function, compile_function_ast
    from ..example import hello_world
    
    code = run_transformer_on_function(hello_world, Python2FutureTransformer)
    func = compile_function_ast(code)
    result = func()
    assert result == 'Hello world'
    assert 'from __future__ import' in code


# Generated at 2022-06-12 03:41:54.693478
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    code = 'print("hello")'
    tree = ast.parse(code)
    tree_new = Python2FutureTransformer(code=code).visit(tree)
    # is expected after visiting: imports + print("hello")
    tree_exp = ast.parse('''
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
print("hello")
    ''')
    diff = ast.dump(tree_new) != ast.dump(tree_exp)
    assert diff is False

# Generated at 2022-06-12 03:42:00.030868
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Given
    node = ast.parse('''
        pass
    ''')

    transformer = Python2FutureTransformer()

    # When
    updated_node = transformer.visit(node)

    # Then
    assert isinstance(updated_node, ast.Module)
    assert updated_node.body[0].value.s == '__future__'
    assert len(updated_node.body) == 5

# Generated at 2022-06-12 03:42:06.130282
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast.ast3 import parse
    program = """print("Python version:", sys.version)"""
    expected = """from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

print("Python version:", sys.version)"""
    tree = parse(program)
    node = Python2FutureTransformer().visit(tree)
    assert astor.to_source(node) == expected

# Generated at 2022-06-12 03:42:13.547163
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    source = textwrap.dedent("""
    # python
    import requests
    import os
    """)
    expected_source = textwrap.dedent("""
    # python
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    import requests
    import os
    """)
    tree = ast.parse(source)
    Python2FutureTransformer().visit(tree)  # type: ignore
    result = astunparse.unparse(tree).strip()
    assert result == expected_source

# Generated at 2022-06-12 03:42:15.649856
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from astor import to_source
    pl2 = Python2FutureTransformer()

# Generated at 2022-06-12 03:42:17.200868
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer is not None

# Generated at 2022-06-12 03:42:20.944243
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    old_code = '''def x():
    pass
    '''

# Generated at 2022-06-12 03:42:29.034185
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Test for Python2FutureTransformer."""
    assert Python2FutureTransformer

# Generated at 2022-06-12 03:42:34.922770
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    module = ast.Module([ast.Expr(ast.Num(42))])
    assert 'from __future__ import absolute_import' in module.dump()
    assert 'from __future__ import division' in module.dump()
    assert 'from __future__ import print_function' in module.dump()
    assert 'from __future__ import unicode_literals' in module.dump()
    assert '42' in module.dump()

# Generated at 2022-06-12 03:42:37.381518
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    node = ast.parse('print("hello world")')
    transformer.visit(node)
    print(ast.dump(node))

# Generated at 2022-06-12 03:42:38.903431
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer
    assert transformer._tree_changed is False


# Generated at 2022-06-12 03:42:40.346573
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()
    assert t.name == 'Python2FutureTransformer'



# Generated at 2022-06-12 03:42:45.238358
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ...tests.transformer import transform, ASSERT

    # Modules
    ASSERT.equal(transform(imports('__future__'), Python2FutureTransformer).body,
                 imports('__future__').get_body())
    ASSERT.equal(transform(imports(), Python2FutureTransformer).body,
                 imports('__future__').get_body())

# Generated at 2022-06-12 03:42:46.133994
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-12 03:42:50.788662
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor
    code = "def f():\n  pass"
    tree = ast.parse(code)
    new_tree = Python2FutureTransformer().visit(tree)
    assert astor.to_source(new_tree) == 'from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n\ndef f():\n    pass'

# Generated at 2022-06-12 03:42:51.970467
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    x = Python2FutureTransformer()
    assert x.target == (2, 7)

# Generated at 2022-06-12 03:42:57.814678
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    
    source = '''"""Module docstring"""
    a = 1
    b = 2
    '''
    result = '''"""Module docstring"""
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    a = 1
    b = 2
    '''
    node = ast.parse(source)
    compiler = Python2FutureTransformer()
    compiler.visit(node)
    out = ast.unparse(node)
    assert out == result

# Generated at 2022-06-12 03:43:16.589565
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .ast_transformer_test_case import ASTTransformerTestCase
    from typed_ast import ast3 as ast
    from ..utils.ast_importer import AstImporter

    class Test(ASTTransformerTestCase):
        @property
        def transformer(self):
            return Python2FutureTransformer

        @property
        def code(self):
            return """
            import os
            """

        @property
        def expected_tree(self):
            tree = AstImporter().import_('from typed_ast import ast3 as ast')
            body = imports.get_body(future='__future__')
            body += tree.parse("""
            import os
            """)
            return tree.Module(body=body)

    Test().run()

# Generated at 2022-06-12 03:43:17.636114
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-12 03:43:19.570952
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert isinstance(Python2FutureTransformer(), (Python2FutureTransformer,))



# Generated at 2022-06-12 03:43:22.523776
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # create instance of class Python2FutureTransformer
    instance = Python2FutureTransformer()
    # check if instance is created successfully
    assert instance is not None
    assert instance._tree_changed is False

# Generated at 2022-06-12 03:43:32.144893
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # Arrange
    import ast
    import typed_ast.ast3 as typed_ast

    module = ast.parse('a = 1')
    expected_value = ast.parse('import __future__\n\na = 1')

    # Act
    transformer = Python2FutureTransformer()
    new_tree = transformer.visit(module)  # type: ignore

    # Assert
    assert typed_ast.dump(new_tree) == typed_ast.dump(expected_value)

    # Act
    transformer = Python2FutureTransformer()
    new_tree = transformer.visit(new_tree)  # type: ignore

    # Assert
    assert typed_ast.dump(new_tree) == typed_ast.dump(expected_value)

# Generated at 2022-06-12 03:43:36.144553
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.Module([])
    act = Python2FutureTransformer().visit(node)
    exp = astor.to_source(ast.Module(imports.get_body(future='__future__')))  # type: ignore
    assert astor.to_source(act) == exp

# Generated at 2022-06-12 03:43:45.191920
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    source = textwrap.dedent("""\
    hello = 'world'
    """)
    tree = ast.parse(source)
    Python2FutureTransformer().visit(tree)

# Generated at 2022-06-12 03:43:48.479266
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .__fixtures__.snippets import Python2FutureTransformer_visit_Module
    from .. import node_visit
    node_visit(Python2FutureTransformer_visit_Module, Python2FutureTransformer)

# Generated at 2022-06-12 03:43:49.836400
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()
    assert isinstance(t, BaseNodeTransformer)

# Generated at 2022-06-12 03:44:00.428987
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from . import fixture

    transformer = Python2FutureTransformer(fixture.__file__)
    transformer.visit(fixture.program)
    assert transformer._tree_changed
    assert transformer.tree is not None

    assert fixture.program.body != transformer.tree.body
    assert isinstance(transformer.tree.body[0], ast.ImportFrom)
    assert transformer.tree.body[0].module == '__future__'
    assert transformer.tree.body[0].names[0].name == 'absolute_import'
    assert transformer.tree.body[1].module == '__future__'
    assert transformer.tree.body[1].names[0].name == 'division'
    assert transformer.tree.body[2].module == '__future__'

# Generated at 2022-06-12 03:44:28.919353
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer(None)

# Generated at 2022-06-12 03:44:30.905520
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer is not None
    assert transformer.target == (2, 7)


# Generated at 2022-06-12 03:44:33.330068
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import sys
    sys.version_info = (3, 6, 1)
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)

# Generated at 2022-06-12 03:44:39.225790
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    tree = ast.parse('a = 1')
    new_tree = Python2FutureTransformer().visit(tree)
    assert str(new_tree) == (
        'from __future__ import absolute_import\n'
        'from __future__ import division\n'
        'from __future__ import print_function\n'
        'from __future__ import unicode_literals\n'
        '\n'
        'a = 1'
    )

# Generated at 2022-06-12 03:44:42.711203
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast.ast3 import parse
    from .example import examples
    # remove the ensure_future lines and convert the rest of the file to python 2
    node = parse(examples['ensure_future'])
    Python2FutureTransformer(node).visit(node)
    print(ast.dump(node))

# Generated at 2022-06-12 03:44:51.536174
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    """unit test for method visit_Module of class Python2FutureTransformer"""
    from typed_ast.ast3 import Module
    from typed_ast import ast3 as ast
    from typing import List
    from .base import BaseNodeTransformer

    transformer = Python2FutureTransformer()
    node = Module(body=[
        ast.Import(names=[ast.alias(name='os', asname=None)]),
        ast.Import(names=[ast.alias(name='sys', asname=None)])
    ])
    assert node.body == [
        ast.Import(names=[ast.alias(name='os', asname=None)]),
        ast.Import(names=[ast.alias(name='sys', asname=None)])
    ]
    assert isinstance(node.body, List)
    assert transformer.visit_Module(node)

# Generated at 2022-06-12 03:44:58.665794
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import ast
    from lib2to3.pgen2 import token
    from typed_ast import ast3 as ast
    from ..utils import source
    from .base import BaseNodeTransformer
    
    node = ast.Module(body=[])
    mytest = Python2FutureTransformer()
    node = mytest.visit(node)
    assert source(node) == 'from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n', 'Failed assertion in lib2to3_fixer.py: Python2FutureTransformer_visit_Module'


# Generated at 2022-06-12 03:45:00.271639
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a = Python2FutureTransformer()
    assert a.target == (2, 7)
    assert isinstance(a, BaseNodeTransformer)

# Generated at 2022-06-12 03:45:02.777201
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from typed_ast import parse
    
    tree = ast.parse(""""""
"""
print("Hello, World!")
""")
    
    tree = Python2FutureTransformer().visit(tree)
    assert isinstance(tree, ast.Module)



# Generated at 2022-06-12 03:45:06.817244
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from unittest import TestCase
    from typed_ast.ast3 import parse

    class Test(TestCase):
        def test_Python2FutureTransformer(self):
            node = parse('a = 2')
            Python2FutureTransformer().visit(node)

# Generated at 2022-06-12 03:46:07.962884
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer()


# Generated at 2022-06-12 03:46:09.925886
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import tempfile
    from typed_ast.ast3 import parse


# Generated at 2022-06-12 03:46:13.031579
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..generator import Transformer
    
    xformer = Transformer([Python2FutureTransformer()])
    tree = xformer.transform('empty')
    assert tree.children == ('', 0)

# Generated at 2022-06-12 03:46:14.890104
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer is not None
    assert transformer.target == (2, 7)
    assert transformer.future == '__future__'



# Generated at 2022-06-12 03:46:22.829349
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import_node = ast.parse(imports.get_source(future='__future__'))

    module_node = ast.parse("""
       def one(var):
           return var

       def two(var):
           return var
    """)
    module_node.body = import_node.body + module_node.body  # type: ignore

    # only a module
    node = ast.parse("")
    result = Python2FutureTransformer().visit(node)
    assert ast.dump(result) == ast.dump(node)

    # a module with a function def
    result = Python2FutureTransformer().visit(module_node)
    assert ast.dump(result) == ast.dump(module_node)

# Generated at 2022-06-12 03:46:23.656598
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-12 03:46:24.881425
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-12 03:46:33.805130
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast

    expected = """
body = future.get_body(future='__future__') + body
    """.strip()


# Generated at 2022-06-12 03:46:42.572610
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .common import assert_convert, assert_not_convert, assert_transformer

    assert_transformer(Python2FutureTransformer)

    assert_convert(Python2FutureTransformer, "pass", """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    
    pass
    """)
    assert_convert(Python2FutureTransformer, "from __future__ import (print_function, division)", """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    
    from __future__ import (print_function, division)
    """)

# Generated at 2022-06-12 03:46:48.553884
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from .base import BaseNodeTransformerTester
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer

    class Tester(BaseNodeTransformerTester):
        transformer = Python2FutureTransformer(target=(2, 7))
        expected_class = Python2FutureTransformer
        methodname = 'visit_Module'

        def make_node(self):
            node = ast.Module()
            node.body = []
            return node

    t = Tester()
    t.test()

# Generated at 2022-06-12 03:49:24.309889
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Test if imports are prepended when module is empty
    transformer = Python2FutureTransformer()
    module = ast.Module([])
    new_module = transformer.visit(module)
    assert transformer._tree_changed
    assert new_module.body[0].value.s == 'absolute_import'
    assert new_module.body[1].value.s == 'division'
    assert new_module.body[2].value.s == 'print_function'
    assert new_module.body[3].value.s == 'unicode_literals'
    # Test if imports are prepended when module is not empty
    transformer = Python2FutureTransformer()
    module = ast.Module([ast.Pass()])
    new_module = transformer.visit(module)
    assert transformer._tree_changed

# Generated at 2022-06-12 03:49:25.160939
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer is not None

# Generated at 2022-06-12 03:49:29.387959
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    test_input = '''def f(a):
    return a + 1'''
    
    result = Python2FutureTransformer().visit(ast.parse(test_input))
    expected = ast.parse(imports(future='__future__') + test_input)
    assert astor.to_source(result) == astor.to_source(expected)

# Generated at 2022-06-12 03:49:30.250071
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-12 03:49:37.208818
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # Empty module
    transformer = Python2FutureTransformer(ast.parse('# coding: utf-8'))
    assert transformer._tree_changed is False
    node = transformer.root_node
    assert isinstance(node.body[0], ast.ImportFrom)
    assert isinstance(node.body[1], ast.ImportFrom)
    assert isinstance(node.body[2], ast.ImportFrom)
    assert isinstance(node.body[3], ast.ImportFrom)
    assert node.body[0].module == '__future__'
    assert node.body[1].module == '__future__'
    assert node.body[2].module == '__future__'
    assert node.body[3].module == '__future__'

# Generated at 2022-06-12 03:49:37.685407
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass

# Generated at 2022-06-12 03:49:40.379237
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Unit test for constructor of class Python2FutureTransformer"""
    # Test instantiation of object
    obj = Python2FutureTransformer()
    assert(obj.name=='Python2FutureTransformer')

# Generated at 2022-06-12 03:49:47.034401
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    code = dedent('''
    import this
    import os
    import sys
    ''')
    tree = ast.parse(code)
    Python2FutureTransformer().visit(tree)

    code_expected = dedent('''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    import this
    import os
    import sys
    ''')
    tree_expected = ast.parse(code_expected)

    assert are_ast_trees_equal(tree, tree_expected)

# Generated at 2022-06-12 03:49:52.742517
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3
    assert Python2FutureTransformer.visit_Module(
        Python2FutureTransformer(),
        ast3.Module([], type_ignores=[])
    ).body[:4] == [
        ast3.ImportFrom(
            module='__future__',
            names=[
                ast3.alias(name='absolute_import', asname=None),
                ast3.alias(name='division', asname=None),
                ast3.alias(name='print_function', asname=None),
                ast3.alias(name='unicode_literals', asname=None),
            ],
            level=0,
        ),
    ]