

# Generated at 2022-06-12 03:40:00.238071
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    pft = Python2FutureTransformer(None, None)
    mt, sc = ast.parse(''), ast.fix_missing_locations
    mt = pft.visit(mt)  # type: ignore
    assert mt.body == [ast.ImportFrom(module='__future__', names=[
        ast.alias(name='absolute_import', asname=None),
        ast.alias(name='division', asname=None),
        ast.alias(name='print_function', asname=None),
        ast.alias(name='unicode_literals', asname=None)
    ], level=0)], 'method visit_Module of class Python2FutureTransformer failed'



# Generated at 2022-06-12 03:40:07.492473
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # type: () -> None
    from typed_ast import ast3
    from .base import BaseNodeTransformerTest
    ast_tree = ast3.parse("""
import sys
""")
    class_ = Python2FutureTransformer
    class Test(BaseNodeTransformerTest):
        target_class = class_
        function_name = 'visit_Module'
        class Test(BaseNodeTransformerTest):
            target_class = class_
            function_name = 'visit_Module'
    result = Test.run_visitor(ast_tree)
    assert result == Test.expected("""
from __future__ import absolute_import, division, print_function, unicode_literals

import sys
""")

# Generated at 2022-06-12 03:40:13.931350
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer(None)
    node = ast.parse(
'''
import sys
import os
'''
    )
    expected = \
'''
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

import sys
import os
'''
    result = transformer.visit(node)
    assert ast.dump(result) == ast.dump(ast.parse(expected))

# Generated at 2022-06-12 03:40:21.309525
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a = ast.parse(u'import os\nprint(ast.dump(ast.parse("1")))')
    mod = Python2FutureTransformer()
    tree = mod.visit(ast.Module(body=[a]))
    # Check imports were added
    assert tree.body[0].body[0].name == 'absolute_import'
    assert tree.body[0].body[1].name == 'division'
    assert tree.body[0].body[2].name == 'print_function'
    assert tree.body[0].body[3].name == 'unicode_literals'
    # Check parse was preserved
    assert tree.body[0].body[4].func.id == 'print'
    assert tree.body[0].body[4].args[0].func.id == 'ast'
    assert tree.body

# Generated at 2022-06-12 03:40:26.402584
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    code = astor.to_source(Python2FutureTransformer().visit(ast.parse("print('Hello, world!')")))
    assert code == "from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n\nprint('Hello, world!')"

# Generated at 2022-06-12 03:40:36.442167
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = ast.parse('')
    transformer = Python2FutureTransformer(module)
    new_module = transformer.visit_Module(module)
    imp_nodes = new_module.body[:4]
    assert imp_nodes[0].names[0].name == '__future__'
    assert imp_nodes[0].names[1].name == 'absolute_import'
    assert imp_nodes[1].names[0].name == '__future__'
    assert imp_nodes[1].names[1].name == 'division'
    assert imp_nodes[2].names[0].name == '__future__'
    assert imp_nodes[2].names[1].name == 'print_function'
    assert imp_nodes[3].names[0].name == '__future__'
   

# Generated at 2022-06-12 03:40:44.494900
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import sys
    import unittest
    from typed_ast import ast3 as ast
    from ..main import parse

    class Python2FutureTransformerTest(unittest.TestCase):
        def test_visit_Module(self):
            from .gen import Python2FutureTransformerTestCase

            for test_case in Python2FutureTransformerTestCase.test_cases:
                # I wasn't able to mock sys.version_info, so I just simply skip this test under Python 3.
                if sys.version_info.major == 3:
                    continue
                ast_node = parse(test_case.input)
                self.assertEqual(test_case.output, str(Python2FutureTransformer().visit(ast_node)))

# Generated at 2022-06-12 03:40:47.435498
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils import make_test_module
    from ..utils.ast_compare import check_ast_equality
    from .codegen import PythonCodeGenerator
    from .node_visitor import NodeVisitor


# Generated at 2022-06-12 03:40:53.383428
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..codegen import to_source
    from .unittest_utils import assert_node

    code = to_source(Python2FutureTransformer().visit(ast.parse("import os")))
    assert_node(code, """
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        import os
    """)

# Generated at 2022-06-12 03:40:59.320255
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..visitor import to_source

    code = '''x = 1'''
    tree = ast.parse(code)  # type: ignore
    visitor = Python2FutureTransformer()
    new_tree = visitor.visit(tree)  # type: ignore
    assert to_source(new_tree) == '''
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
x = 1
'''

# Generated at 2022-06-12 03:41:08.025022
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = ast.parse('pass')
    transformer = Python2FutureTransformer()
    module_changed = transformer.visit(module)
    assert str(module_changed) == (
        'from __future__ import absolute_import\n'
        'from __future__ import division\n'
        'from __future__ import print_function\n'
        'from __future__ import unicode_literals\n'
        'pass'
    )

# Generated at 2022-06-12 03:41:18.185400
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    from typing import List

    src = """
a = 1
b = 2
    """.strip()

    src_expected = """
from future import absolute_import
from future import division
from future import print_function
from future import unicode_literals

a = 1
b = 2
    """.strip()

    module = ast.parse(src)
    module_expected = ast.parse(src_expected)

    transformer = Python2FutureTransformer()
    module_transformed = transformer.visit(module)  # type: ignore

    assert isinstance(module_transformed, ast.Module)

    src_transformed = astor.to_source(module_transformed).strip()
    src_expected = astor.to_source(module_expected).strip()

    assert src_transformed == src_expected

# Generated at 2022-06-12 03:41:22.298862
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from .test_base import BaseNodeTransformerTest
    from typed_ast import ast3 as ast
    from .helpers import build_module, compare_source

    tree = build_module('1/0')
    Python2FutureTransformer().visit(tree)
    tree = ast.fix_missing_locations(tree)
    BaseNodeTransformerTest().generic_visit(tree)
    compare_source(__file__, 1, tree)

# Generated at 2022-06-12 03:41:24.497983
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from src.python2to3.translators.transformers.base import NodeTransformer

    assert issubclass(Python2FutureTransformer, NodeTransformer)


# Generated at 2022-06-12 03:41:25.869471
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer  # using this to silence pylint warning

# Generated at 2022-06-12 03:41:32.859199
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    node = astor.parse_file(
        root_dir.joinpath("tests/fixtures/xrange.py"))
    node = Python2FutureTransformer().visit(node)
    source = astor.to_source(node)
    assert source.strip() == """
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

for x in xrange(10):
    print(x)
""".strip()

# Generated at 2022-06-12 03:41:38.864513
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..testing import as3

    assert as3('def f(): pass') == 'def f(): pass'
    assert as3('def f(): \n    pass') == 'def f(): \n    pass'
    assert as3('class C(): pass') == 'class C(): pass'
    assert as3('class C(object): pass') == 'class C(object): pass'
    assert as3('class C(object): \n    pass') == 'class C(object): \n    pass'
    assert as3('a = 0') == 'a = 0'
    assert as3('a = 1') == 'a = 1'
    assert as3('a = 1.0') == 'a = 1.0'
    assert as3('a = 1.0') == 'a = 1.0'

# Generated at 2022-06-12 03:41:46.633966
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.parsing import parse
    from .. import AstroidBuildingMixin
    from ..utils.snippet import snippet

    tree = parse(ast.Module, 'import os\nprint(os.path)')
    trans = Python2FutureTransformer()
    trans.visit(tree)
    assert str(tree) == str(parse(ast.Module, '''
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        import os
        print(os.path)'''))

# Generated at 2022-06-12 03:41:55.771219
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.testutils import assert_ast_equal, new_module, new_program
    from typed_ast import ast3 as ast
    program = new_program(
        "from __future__ import absolute_import",
        "from __future__ import division",
        "from __future__ import print_function",
        "from __future__ import unicode_literals",
        "var = 1")
    program = ast.fix_missing_locations(program)
    expected = new_program(
        "import __future__",
        "from __future__ import absolute_import",
        "from __future__ import division",
        "from __future__ import print_function",
        "from __future__ import unicode_literals",
        "var = 1")
    expected = ast.fix_missing_locations(expected)
    #

# Generated at 2022-06-12 03:42:02.814486
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3

    class NodeVisitor(ast3.NodeVisitor):
        def __init__(self):
            self.generic_visit = lambda node: node

    def x():
        pass

    visitor = NodeVisitor()
    x = Python2FutureTransformer().visit(x)
    assert x.__code__.co_filename.startswith("<future_")
    visitor.visit(x.__code__.co_consts[1]) == imports.get_body()

# Generated at 2022-06-12 03:42:13.102562
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3
    from aiida_codtools.utils.future import Python2FutureTransformer
    node = ast3.parse(dedent('''\
        def hello_world():
            print('Hello World!')
        '''
    ))
    trans = Python2FutureTransformer()
    trans.visit(node)
    result = compile(node, '<string>', mode='exec')
    glob_dict={}
    exec(result, glob_dict)
    assert glob_dict['hello_world']() == None

# Generated at 2022-06-12 03:42:22.983415
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typing import List
    from typed_ast import ast3 as ast

    source = "a=1"
    expected_module_body = [
        ast.ImportFrom(
            module='__future__',
            names=[
                ast.alias(name='absolute_import', asname=None),
                ast.alias(name='division', asname=None),
                ast.alias(name='print_function', asname=None),
                ast.alias(name='unicode_literals', asname=None)
            ],
            level=0
        ),
        ast.Assign(targets=[ast.Name(id='a', ctx=ast.Store())], value=ast.Num(n=1))
    ]  # type: List[ast.AST]

    module = ast.parse(source)
    transformer = Python2Future

# Generated at 2022-06-12 03:42:24.863611
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert imports.get_ast(future='__future__').body == Python2FutureTransformer().visit(ast.parse('pass')).body

# Generated at 2022-06-12 03:42:34.265634
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():

    input_ast = ast.parse('a = 1\nb = 2')
    assert input_ast.body

    transformer = Python2FutureTransformer()
    output_ast = transformer.visit(input_ast)
    assert input_ast.body != output_ast.body
    assert len(output_ast.body) == 6
    assert output_ast.body[0].names[0].name == 'absolute_import'
    assert output_ast.body[1].names[0].name == 'division'
    assert output_ast.body[2].names[0].name == 'print_function'
    assert output_ast.body[3].names[0].name == 'unicode_literals'
    assert output_ast.body[5].targets[0].id == 'b'

# Generated at 2022-06-12 03:42:35.602036
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer is not None


# Generated at 2022-06-12 03:42:37.961571
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import random
    import ast

    class MockFuture(str):
        pass


# Generated at 2022-06-12 03:42:39.480886
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    inst = Python2FutureTransformer()
    assert isinstance(inst, Python2FutureTransformer)


# Generated at 2022-06-12 03:42:43.537439
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert issubclass(Python2FutureTransformer, BaseNodeTransformer)
    assert Python2FutureTransformer.target == (2, 7)
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)
    assert transformer.specialized is None


# Generated at 2022-06-12 03:42:48.621766
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    tree = ast.parse("x = 1")
    transformer = Python2FutureTransformer()
    tree = transformer.visit(tree)
    expected = dedent("""
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        x = 1
    """).strip()
    assert to_source(tree) == expected

# Generated at 2022-06-12 03:42:57.140355
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    code = """
    a = 3
    b = 4
    c = 5
    """
    node = ast.parse(code)
    node = Python2FutureTransformer().visit(node) # type: ignore

# Generated at 2022-06-12 03:43:13.367948
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..ast_manipulation import get_ast, get_source, set_source
    source = '''
    def foo():
        pass
        
    '''

    module = get_ast(source)
    assert isinstance(module, ast.Module)

    transformer = Python2FutureTransformer()
    module = transformer.visit(module)  # type: ignore

    assert isinstance(module, ast.Module)
    assert transformer._tree_changed is True
    assert get_source(module) == '''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    
    def foo():
        pass
        
    '''
    set_source(module, source)

# Generated at 2022-06-12 03:43:23.046452
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    root = ast.parse(textwrap.dedent('''
        from __future__ import print_function
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import unicode_literals

        print 2 / 3
        print "hello world"
    '''))
    transformer = Python2FutureTransformer()
    transformed_root = transformer.visit(root)

# Generated at 2022-06-12 03:43:26.918259
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    source_code = '''def fun():
    print('Hello world')
    '''

# Generated at 2022-06-12 03:43:36.771045
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    """Test for method visit_Module of class Python2FutureTransformer."""
    from ..testing_utils import assert_source_equal

    # Empty module.
    source = '''\
"""This is a module docstring."""
'''
    tree = ast.parse(source, mode='exec')
    result = Python2FutureTransformer().visit(tree)
    expected = '''\
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

"""This is a module docstring."""
'''
    assert_source_equal(expected, result)

    # Module with imports.

# Generated at 2022-06-12 03:43:38.663184
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    print('Testing Python2FutureTransformer.visit_Module ...') 
    # Given
    import astor

# Generated at 2022-06-12 03:43:39.803766
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer is not None


# Generated at 2022-06-12 03:43:49.072675
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    mod = ast.parse('a = 1')
    Python2FutureTransformer().visit(mod)
    assert ast.dump(mod) == """\
Module(body=[ImportFrom(module='__future__', names=[alias(name='absolute_import', asname=None)], level=0), ImportFrom(module='__future__', names=[alias(name='division', asname=None)], level=0), ImportFrom(module='__future__', names=[alias(name='print_function', asname=None)], level=0), ImportFrom(module='__future__', names=[alias(name='unicode_literals', asname=None)], level=0), Assign(targets=[Name(id='a', ctx=Store())], value=Num(n=1))])
    """

# Generated at 2022-06-12 03:43:52.197988
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    node = ast.parse("pass")
    t = Python2FutureTransformer()
    new_node = t.visit(node)
    assert new_node != node
    assert imports.get_body(future='__future__') == new_node.body

# Generated at 2022-06-12 03:43:59.144932
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transform = Python2FutureTransformer()
    source = """
m = 1
"""
    expected = """
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
m = 1
"""
    tree = ast.parse(source)
    transform.visit(tree)
    actual = astor.to_source(tree).strip()
    assert actual == expected

# Generated at 2022-06-12 03:44:02.490326
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .test_utils import make_test_tree, assert_equal_modulo_whitespace

    module = make_test_tree()
    transformer = Python2FutureTransformer()
    result = transformer.visit(module)

    assert_equal_modulo_whitespace(
        result,
        module,
        tree_transformer=Python2FutureTransformer()
    )

# Generated at 2022-06-12 03:44:18.788490
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    print(Python2FutureTransformer())


# Generated at 2022-06-12 03:44:23.650242
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    """Unit test for method visit_Module of class Python2FutureTransformer"""
    # Given
    input = """
print("hello")
"""
    expected = """
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

print("hello")
"""

    # When
    actual = Python2FutureTransformer.run(input, filename=__file__)

    # Then
    assert expected == actual

# Generated at 2022-06-12 03:44:28.782289
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = ast.Module()
    module.body = [ast.Pass()]
    transformer = Python2FutureTransformer()
    assert transformer._tree_changed is False
    new_module = transformer.visit(module)
    assert transformer._tree_changed is True
    assert imports.get_body(future='__future__') + module.body == new_module.body

# Generated at 2022-06-12 03:44:35.596758
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()
    code = '''
x = 1
y = x + 2
print(y)
'''
    tree = ast.parse(code)
    t.visit(tree)
    expected = '''
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

x = 1
y = x + 2
print(y)
'''
    code1 = astor.to_source(tree).strip()
    assert code1 == expected

# Generated at 2022-06-12 03:44:38.476077
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()

    assert t._tree_changed is False
    assert t.target == (2, 7)
    assert len(t.generic_visit.__doc__) > 0

# Generated at 2022-06-12 03:44:39.388391
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-12 03:44:47.953468
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor

    transformer = Python2FutureTransformer(
        ast.parse(
            textwrap.dedent(
                """
                import os
                print('hello world')
                """
            )
        )
    )


# Generated at 2022-06-12 03:44:53.630126
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .basic_transformer_examples import example_code, example_code_transformed

    orig_code = example_code(2)
    expected_code = example_code_transformed(2)

    ft = Python2FutureTransformer()
    tree = ast.parse(orig_code)
    ft.visit(tree)
    code = compile(tree, "<string>", mode='exec')

    ns = {}
    exec(code, ns)
    assert ns['foo'] == eval(expected_code)

# Generated at 2022-06-12 03:45:00.512417
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..codegen import to_source
    from .test_base import patch_ast_to_source
    import astor
    patch_ast_to_source()

    tree = astor.parse_file(imports.__code__)  # type: ignore
    tree = Python2FutureTransformer().visit(tree)
    assert to_source(tree).strip() == """
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
from future import absolute_import
from future import division
from future import print_function
from future import unicode_literals
""".strip()

# Generated at 2022-06-12 03:45:01.463928
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert isinstance(Python2FutureTransformer(), Python2FutureTransformer)

# Generated at 2022-06-12 03:45:44.179744
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    import astunparse
    import textwrap
    from astmonkey import transformers

    code = textwrap.dedent(r"""
    import os

    class ClassA(object):
        pass
    """)

    expected_code = textwrap.dedent(r"""
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    import os

    class ClassA(object):
        pass
    """)

    node = ast.parse(code)
    transformer = Python2FutureTransformer()
    new_node = transformer.visit(node)
    assert transformer.tree_changed is True
    assert astor.to_source(transformers.ParentNodeTransformer().visit(new_node)) == expected_code

# Generated at 2022-06-12 03:45:48.441382
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()
    
    sample = ast.parse('pass')
    sample = transformer.visit(sample)  # type: ignore
    expected = ast.parse('from __future__ import absolute_import\n'
                         'from __future__ import division\n'
                         'from __future__ import print_function\n'
                         'from __future__ import unicode_literals\n'
                         'pass\n')
    assert ast.dump(sample) == ast.dump(expected)

# Generated at 2022-06-12 03:45:53.987167
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    module = ast.Module([
        ast.Import(names=[ast.alias(
            name='re', 
            asname=None)])
    ])
    expected = '''from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

import re'''
    module = Python2FutureTransformer().visit(module)
    code = astor.to_source(module)
    assert code == expected

# Generated at 2022-06-12 03:45:54.485364
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass

# Generated at 2022-06-12 03:45:59.226261
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from sixer import Sixer
    from sixer.transformers.future import Python2FutureTransformer

    code = "print('Hello')"
    sixer = Sixer()
    sixer.register_target(Python2FutureTransformer)
    assert sixer.sixify(code) == "from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\nprint('Hello')"

# Generated at 2022-06-12 03:46:09.597333
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .. import transform  # noqa: F401
    from ..transformer import Transformer
    from ..transformer.python2 import Python2Transformer
    from ..transformer.syntax import SyntaxTransformer
    from ..transformer.undefined import UndefinedTransformer
    import sys

    file = os.path.join(os.path.dirname(__file__), '../..', 'test_data/test_python2.py')
    with open(file) as f:
        x = f.read()

    # Test the method visit_Module of class Python2FutureTransformer
    tree = ast.parse(x)
    trans = Transformer([SyntaxTransformer, UndefinedTransformer, Python2Transformer, Python2FutureTransformer])
    tree = trans.visit(tree)
    from .test_python2 import test_print

# Generated at 2022-06-12 03:46:17.015554
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import sys
    import os
    import ast
    import tempfile
    from .backport_helper.backport import backport_node
    from .backport_helper.snippet import visit_Module

    # Python 2 / Python 3 compatibility
    if sys.version_info[0] == 2:
        import __builtin__ as builtins
    else:
        import builtins

    # create a temporary directory for testing.
    TEST_DIR = tempfile.TemporaryDirectory()
    TEST_FILE = os.path.join(TEST_DIR.name, 'test_Python2FutureTransformer_visit_Module.py')

    # Put these statements in the temporary test file.

# Generated at 2022-06-12 03:46:22.305472
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    test_code = "__version__"
    node = ast.parse(test_code)
    result = ast.parse("from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n__version__")
    assert ast.dump(Python2FutureTransformer().visit(node)) == ast.dump(result)


# Generated at 2022-06-12 03:46:25.413661
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    from typed_ast import ast3 as ast
    transformer = Python2FutureTransformer()
    tree = ast.parse(source="x = 1")
    transformer.visit(tree)
    print(astor.to_source(tree))

# Generated at 2022-06-12 03:46:25.968548
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass

# Generated at 2022-06-12 03:47:37.720666
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.target == (2, 7)

# Generated at 2022-06-12 03:47:42.936196
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    text = 'invalid'
    tree = ast.parse(text)
    new_tree = Python2FutureTransformer().visit(tree)
    future_imports = new_tree.body[:4]
    assert [type(x) for x in future_imports] == [ast.ImportFrom, ast.ImportFrom, ast.ImportFrom, ast.ImportFrom]
    assert [x.lineno for x in future_imports] == [1, 2, 3, 4]
    assert [x.col_offset for x in future_imports] == [0, 0, 0, 0]
    assert [x.module for x in future_imports] == ['__future__', '__future__', '__future__', '__future__']

# Generated at 2022-06-12 03:47:47.165615
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # class Python2FutureTransformer(BaseNodeTransformer):
    assert issubclass(Python2FutureTransformer, BaseNodeTransformer)

    # def __init__(self):
    transformer = Python2FutureTransformer()

    # self.target = (2, 7)
    assert transformer.target == (2, 7)

    # self._tree_changed = False
    assert transformer._tree_changed is False


# Generated at 2022-06-12 03:47:55.144701
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from numba_pytest_transformer.utils.utils import run_transformer_test
    from .test_data import snippets_to_test

# Generated at 2022-06-12 03:48:02.925960
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    code = '''
import os
'''
    node = astor.parse_file(code)
    Python2FutureTransformer().visit(node)
    new_code = astor.to_source(node)  # type: ignore
    expected = "\nfrom __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n\nimport os\n"
    assert new_code == expected, 'Wrong output for Python2FutureTransformer'

# Generated at 2022-06-12 03:48:08.497743
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import sys
    from pathlib import Path
    from ..logger import logger
    import astunparse

    transformer = Python2FutureTransformer(sys.path, logger)
    source = Path(__file__).parent / '../../tests/data/python2.py'
    source_code = source.read_text()
    tree = ast.parse(source_code)
    new_tree = transformer.visit(tree)
    print(astunparse.unparse(new_tree))


# Generated at 2022-06-12 03:48:11.110390
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor

    node = ast.parse('import os')
    tr = Python2FutureTransformer()
    tr.visit(node)
    assert astor.to_source(node) == '''
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

import os
    '''.strip()

# Generated at 2022-06-12 03:48:13.293676
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    tree = ast.parse("")
    tree = Python2FutureTransformer(tree).visit(tree)
    assert ast.dump(tree) == imports.get_indented()

# Generated at 2022-06-12 03:48:14.451629
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert(Python2FutureTransformer)




# Generated at 2022-06-12 03:48:17.257310
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    source = """\
x = 5
"""
    expected = """\
from __future__ import absolute_import, division, print_function, unicode_literals

x = 5
"""
    result = Python2FutureTransformer().transform(source)
    assert result == expected

