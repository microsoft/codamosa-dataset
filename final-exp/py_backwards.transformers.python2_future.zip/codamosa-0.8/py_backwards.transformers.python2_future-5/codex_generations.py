

# Generated at 2022-06-12 03:39:57.990630
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    import tempfile
    import traceback

    emitter = astor.CodeEmitter()
    module = ast.parse('')
    visitor = Python2FutureTransformer()
    visitor.visit(module)
    # print(astor.to_source(module))
    assert astor.to_source(module) == """\
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
"""

# Generated at 2022-06-12 03:40:01.631880
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()
    #assert t.unambiguous_target_version() == (2, 7)
    assert t.target == (2, 7)
    #assert t.context == 'single'
    assert t.context == ''
    assert t._tree_changed is False

# Generated at 2022-06-12 03:40:06.967992
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .utils import roundtrip
    source = """
import sys
print("Hello world")
""".strip()
    expected = """
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

import sys
print("Hello world")
""".strip()
    tree = ast.parse(source)
    tree = Python2FutureTransformer().visit(tree)
    result = roundtrip(tree)
    assert result == expected



# Generated at 2022-06-12 03:40:13.098643
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import ast
    from ..ast_utils import get_ast
    from .base import BaseNodeTransformerTest
    node = get_ast('''
        class Test(object):
            pass
        print('Hello, world')
    ''')
    cls = Python2FutureTransformer(target_ast=ast.parse('''
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
    '''))
    cls.generic_visit(node)
    class Test(BaseNodeTransformerTest):
        target_ast = node
        transform = Python2FutureTransformer

# Generated at 2022-06-12 03:40:16.822245
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from tests.fixtures.imports_parser import python2_7_futures
    from ..utils import run_transformer

    assert python2_7_futures == run_transformer(Python2FutureTransformer,
                                                python2_7_futures)

# Generated at 2022-06-12 03:40:21.417728
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()
    program = "a = None"
    tree = ast.parse(program)
    result = transformer.visit(tree)
    expected = """from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

a = None"""
    assert astor.to_source(result).strip() == expected



# Generated at 2022-06-12 03:40:29.615378
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    """Check that method removes parentheses from print statements."""
    tree = ast.parse('print 1')
    trans = Python2FutureTransformer(verbose=True)
    with raises(visitor.StopTraversal) as excinfo:
        trans.visit(tree)
    assert trans._tree_changed == True
    ref_value = """from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

print 1"""
    assert ref_value == astunparse.unparse(tree)
    assert 'StopTraversal' in str(excinfo.value)


# Generated at 2022-06-12 03:40:35.566996
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # Instantiation of class Python2FutureTransformer
    node = ast.parse(textwrap.dedent('''\
    from __future__ import absolute_import, print_function
    from __future__ import division
    from __future__ import unicode_literals
    import lib2to3.fixes.fix_all
    from lib2to3.main import main
    '''))
    assert node == Python2FutureTransformer().visit(node)

# Generated at 2022-06-12 03:40:36.438512
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer()

# Generated at 2022-06-12 03:40:37.009516
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass

# Generated at 2022-06-12 03:40:46.649238
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..get_target_versions import get_target_versions
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)
    assert transformer.__module__ == Python2FutureTransformer.__module__
    assert transformer.get_target_versions() == get_target_versions(Python2FutureTransformer)

    transformer = Python2FutureTransformer(target=(2, 7))
    assert transformer.target == (2, 7)
    assert transformer.__module__ == Python2FutureTransformer.__module__
    assert transformer.get_target_versions() == get_target_versions(Python2FutureTransformer)
    assert transformer.get_target_versions(target=(2, 7)) == (2, 7)

    transformer = Python2FutureTransformer(target=(3, 6))
    assert transformer.target == (3, 6)

# Generated at 2022-06-12 03:40:54.659600
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from . import _utils
    tree = ast.parse(_utils.SOURCE_CODE)
    transformer = Python2FutureTransformer(tree)
    result = transformer.visit(tree)
    assert isinstance(result, ast.Module) == True
    imports_ = [
        'from __future__ import absolute_import',
        'from __future__ import division',
        'from __future__ import print_function',
        'from __future__ import unicode_literals',
    ]
    actual_imports = [node.value.s for node in result.body[:4]]
    assert all(import_ in actual_imports for import_ in imports_)



# Generated at 2022-06-12 03:41:04.958242
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..fixtures import make_test_case, expected, root_dir
    from ..utils.models import NodeTestCase
    from .visit_Module import test_cases as visit_Module_cases

    for case in visit_Module_cases:
        node = ast.parse(case.input_source).body[0]  # type: ast.Module
        # Create a Python2FutureTransformer object
        transformer = Python2FutureTransformer(root_dir)
        # Call method visit_Module with parameter node
        transformed_node = transformer.visit_Module(node)
        

# Generated at 2022-06-12 03:41:06.647517
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()
    assert t



# Generated at 2022-06-12 03:41:15.137485
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source
    from ..common import tokens

    source_ = """print("hahaha")"""
    expected_ = """from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

print("hahaha")"""
    node = ast.parse(source_)
    Python2FutureTransformer().visit(node)
    actual = source(node, tokens=tokens)
    print("Expected: %s" % expected_)
    print("Actual  : %s" % actual)
    assert expected_ == actual

# Generated at 2022-06-12 03:41:21.557892
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    checker = Python2FutureTransformer()
    module = ast.parse(textwrap.dedent("""
    def test_function():
        pass
    """))
    checker.visit(module)
    expected = textwrap.dedent("""
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    def test_function():
        pass
    """)
    assert astunparse.unparse(module).strip() == expected.strip()
    assert not checker.is_changed

# Generated at 2022-06-12 03:41:26.327553
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # Instantiating an object of class Python2FutureTransformer
    snippet = Python2FutureTransformer()
    # snippet.generic_visit() has not yet been defined
    assert snippet.generic_visit is None
    assert snippet.target == (2, 7)
    assert snippet._tree_changed is False
    assert snippet.visit_Module(ast.parse('')) == ast.parse('')

# Generated at 2022-06-12 03:41:32.543670
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import typed_astunparse
    import astunparse
    node = typed_astunparse.parse('def f(): return 42')
    new_node = Python2FutureTransformer().visit(node)
    print(astunparse.unparse(new_node))

# Generated at 2022-06-12 03:41:33.161201
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass

# Generated at 2022-06-12 03:41:40.330183
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import sys
    import os.path

    sys.path.append(os.path.join(os.path.dirname(__file__), '../..'))
    from python_to_python.transformers.python2_future_transformer import Python2FutureTransformer
    from python_to_python.transformers.base import BaseNodeTransformer
    from python_to_python.transformers.base import CodeGenerationError
    from ..utils.source_code_to_ast import source_code_to_ast
    from ..utils.ast_to_source_code import ast_to_source_code


# Generated at 2022-06-12 03:41:50.125751
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import parse
    
    src = '''
    def my_func(x, y):
        return x + y
    '''
    node = parse(src)
    
    transformer = Python2FutureTransformer()
    new_tree = transformer.visit(node)
    transformer.assert_changed()
    

# Generated at 2022-06-12 03:41:51.025504
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer()

# Generated at 2022-06-12 03:41:57.790897
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Test for constructor of class Python2FutureTransformer"""
    from ..utils.sample import Sample
    from ..visitors.scope import ScopedSearch
    from ..visitors.search import FQNExtractor
    scope = ScopedSearch()
    scope.visit(Sample.CLASS_FUNCTION_METHOD_SAMPLE_CODE)
    before = ast.parse(Sample.CLASS_FUNCTION_METHOD_SAMPLE_CODE)
    after = Python2FutureTransformer().visit(before)
    FQNExtractor(scope=scope).visit(after)
    assert after is not None

# Generated at 2022-06-12 03:42:04.268850
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor

    node = ast.parse("print(1)")
    transformer = Python2FutureTransformer()
    transformer.visit(node)
    result = astor.to_source(node)
    expected = 'from __future__ import absolute_import\n\
    from __future__ import division\n\
    from __future__ import print_function\n\
    from __future__ import unicode_literals\n\
    print(1)\n'
    assert expected == result

# Generated at 2022-06-12 03:42:05.486522
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.target == (2, 7)


# Generated at 2022-06-12 03:42:15.113669
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from astmonkey import transformers

    ast_tree = ast.parse('x = 2\ny = 3\nprint(x+y)')
    t = transformers.ParentChildNodeTransformer()
    t.visit_Module(ast_tree)
    assert Python2FutureTransformer().visit_Module(ast_tree).body[0].names[0] == 'absolute_import'
    assert Python2FutureTransformer().visit_Module(ast_tree).body[0].names[1] == 'division'
    assert Python2FutureTransformer().visit_Module(ast_tree).body[0].names[2] == 'print_function'
    assert Python2FutureTransformer().visit_Module(ast_tree).body[0].names[3] == 'unicode_literals'


# Generated at 2022-06-12 03:42:18.879084
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.fixtures import get_test_cases
    from .. import transform

    test_cases = get_test_cases(__file__, 'Python2FutureTransformer.test')
    for test_case in test_cases:
        transform(Python2FutureTransformer, test_case)

# Generated at 2022-06-12 03:42:27.587800
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from .. import astng
    from .transformers import _transformers
    from .transformers import ModuleTransformer

    # test 1
    more_future_incorrect = '''
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    def f():
        return
        '''
    tree = ast.parse(more_future_incorrect)
    expected_tree = ast.parse('''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    def f():
        return
        ''')

# Generated at 2022-06-12 03:42:28.876732
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer is not None


# Generated at 2022-06-12 03:42:37.337564
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse('a = 3')
    tranformer = Python2FutureTransformer()
    assert type(tranformer.visit(node)) is ast.Module
    assert len(tranformer.visit(node).body) == 5
    assert type(tranformer.visit(node).body[0]) is ast.ImportFrom
    assert type(tranformer.visit(node).body[1]) is ast.ImportFrom
    assert type(tranformer.visit(node).body[2]) is ast.ImportFrom
    assert type(tranformer.visit(node).body[3]) is ast.ImportFrom
    assert type(tranformer.visit(node).body[4]) is ast.Assign

# Generated at 2022-06-12 03:42:49.260377
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    tree = ast.parse("""
    import six

    """)

    expected = ast.parse("""
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    
    import six

    """)

    Python2FutureTransformer().visit(tree)

    compare_ast(tree, expected)

# Generated at 2022-06-12 03:42:51.764392
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    code = "print(2/3)"
    assert Python2FutureTransformer(code).visit(ast.parse(code)).body[0].dest == "__future__"

# Generated at 2022-06-12 03:42:56.820508
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    tree = ast.parse("#this is a test\nprint('hello')")
    visitor = Python2FutureTransformer()
    visitor.visit(tree)
    expected_tree = ast.parse("from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n#this is a test\nprint('hello')")
    assert_tree_equals(tree, expected_tree)

# Generated at 2022-06-12 03:43:05.634264
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils import get_ast_diff, check_equal_ast
    from .base import BaseTransformerVisitorTestCase

    class Test(BaseTransformerVisitorTestCase):
        transformer = Python2FutureTransformer
        target = (2, 7)

        def test_Module(self):
            ast_in = """
            pass
            """
            ast_out = """
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals

            pass
            """
            self.check(ast_in, ast_out)

    t = Test()
    import sys
    t.test(sys.modules[__name__])

# Generated at 2022-06-12 03:43:12.912144
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    tree = ast.parse('pass')
    Python2FutureTransformer().visit(tree)
    assert ast.dump(tree) == "Module(body=[ImportFrom(module='__future__', names=[alias(name='absolute_import', asname=None)], level=0), ImportFrom(module='__future__', names=[alias(name='division', asname=None)], level=0), ImportFrom(module='__future__', names=[alias(name='print_function', asname=None)], level=0), ImportFrom(module='__future__', names=[alias(name='unicode_literals', asname=None)], level=0), Pass()])"

# Generated at 2022-06-12 03:43:13.892667
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    

# Generated at 2022-06-12 03:43:22.120596
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3
    from typed_ast import codegen

    node = ast3.parse('foo = 1')
    # type: ast3.Module

    module = Python2FutureTransformer().visit(node)
    # type: ast3.Module

    lines = codegen.to_source(module).splitlines()
    assert lines[0] == "from __future__ import absolute_import"
    assert lines[1] == "from __future__ import division"
    assert lines[2] == "from __future__ import print_function"
    assert lines[3] == "from __future__ import unicode_literals"
    assert lines[4] == "foo = 1"

# Generated at 2022-06-12 03:43:27.172934
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse(dedent('''\
    import re
    '''))

    from ..utils import run_transformer
    transformer = Python2FutureTransformer()
    node = run_transformer(transformer, node)

    node2 = ast.parse(dedent('''\
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    import re
    '''))

    assert ast.dump(node) == ast.dump(node2)



# Generated at 2022-06-12 03:43:31.317250
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
  source = inspect.getsource(imports)
  expected = ast.parse(source)
  node = Python2FutureTransformer(None).visit(ast.parse("")).body[0]
  assert_equals(node, expected)

# Generated at 2022-06-12 03:43:36.862414
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    src = 'print("hello")'
    node = ast.parse(src)
    node = transformer.visit(node)
    src_after = astor.to_source(node).strip()
    expected = '''\
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
print("hello")\
'''
    assert src_after == expected

# Generated at 2022-06-12 03:43:56.008625
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-12 03:44:03.474416
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    code = 'print("hi")'
    expected_code =\
'''from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals


print("hi")
'''
    tree = ast.parse(code)
    transformer = Python2FutureTransformer(tree)
    assert transformer.tree_changed is False
    # Fix code
    transformer.visit(tree)
    assert transformer.tree_changed is True
    code_fixed = astor.to_source(tree).rstrip()
    assert code_fixed == expected_code
    # No change
    transformer = Python2FutureTransformer(tree)
    assert transformer.tree_changed is False
    transformer.visit(tree)
    assert transformer.tree_changed is False

# Generated at 2022-06-12 03:44:07.372270
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    result = Python2FutureTransformer().visit(ast.parse("print('hello')"))
    assert ast.dump(result) == ast.dump(ast.parse("from __future__ import absolute_import;from __future__ import division;from __future__ import print_function;from __future__ import unicode_literals;print('hello')"))

# Generated at 2022-06-12 03:44:15.175462
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast

    class TestVisitor(ast.NodeVisitor):
        def generic_visit(self, node):
            for field, value in ast.iter_fields(node):
                if isinstance(value, list):
                    for item in value:
                        if isinstance(item, ast.AST):
                            self.visit(item)
                elif isinstance(value, ast.AST):
                    self.visit(value)

    m = ast.parse('1+1')
    t = Python2FutureTransformer()
    t.visit(m)
    v = TestVisitor()
    v.visit(m)

# Generated at 2022-06-12 03:44:17.121001
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    temp = Python2FutureTransformer()
    assert temp._tree_changed == False
    assert temp.target == (2, 7)
    assert temp.visit_Module.__name__ == 'visit_Module'

# Generated at 2022-06-12 03:44:21.382305
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import parse
    from .utils import roundtrip
    from .compat import _ast_to_ast
    from .visitor import to_source
    node = parse("print('Hello World!')")
    Python2FutureTransformer().visit(node)
    assert to_source(node) == to_source(imports.get_body(future='__future__')) + to_source(roundtrip(node))

# Generated at 2022-06-12 03:44:24.623318
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import_statements_string = "from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals"

# Generated at 2022-06-12 03:44:29.284417
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import ast as _ast
    import astor
    original = astor.parse_file('tests/resources/long_tuple.py')
    intended = astor.parse_file('tests/resources/future/long_tuple.py')
    actual = Python2FutureTransformer().visit(original)
    assert _ast.dump(actual) == _ast.dump(intended)

# Generated at 2022-06-12 03:44:36.868388
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast.ast3 import parse
    from ..utils.ast_converter import AstConverter
    from ..utils.compare_ast import compare_ast
    tree = parse(u'''
tree = None
''')
    converter = AstConverter()
    node = converter(tree)
    transformer = Python2FutureTransformer()
    transformed = transformer(node)
    expected = parse(u'''
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
tree = None
''')
    assert compare_ast(converter(expected), transformed)

# Generated at 2022-06-12 03:44:45.646406
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import os
    import tempfile
    from flake8_future_import.transformation import Python2FutureTransformer
    assert Python2FutureTransformer()
    assert Python2FutureTransformer()

# Generated at 2022-06-12 03:45:21.791667
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import transform
    sample_code = """
    from future import absolute_import
    from future import division
    from future import print_function
    from future import unicode_literals

    from abc import ABCMeta
    from collections import Counter
    from concurrent.futures import ThreadPoolExecutor
    from itertools import product
    from operator import mul
    from os import path, listdir
    from sys import stderr
    from time import time

    def main():
        print("Hello World")

    if __name__ == "__main__":
        main()
    """


# Generated at 2022-06-12 03:45:23.972053
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # type: () -> None
    transformer = Python2FutureTransformer()
    assert transformer is not None

# Generated at 2022-06-12 03:45:30.587228
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import typed_ast.ast3
    from typed_ast.ast3 import Module, Str, FunctionDef, arguments

    node = Module(body=[
        FunctionDef(name='foo', args=arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[], decorator_list=[], returns=None), 
        FunctionDef(name='bar', args=arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[], decorator_list=[], returns=None), 
    ])

    transformed = Python2FutureTransformer().visit(node)

# Generated at 2022-06-12 03:45:31.914419
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert isinstance(Python2FutureTransformer(), Python2FutureTransformer)

# Generated at 2022-06-12 03:45:33.102803
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    test_case = Python2FutureTransformer()
    assert test_case is not None

# Generated at 2022-06-12 03:45:37.091561
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3
    module = ast.Module()
    transformer = Python2FutureTransformer(module)
    assert isinstance(transformer, Python2FutureTransformer)
    assert isinstance(transformer, BaseNodeTransformer)
    assert isinstance(transformer._tree, ast3.Module)

# Generated at 2022-06-12 03:45:39.014520
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()
    assert t.target == (2, 7)

# Generated at 2022-06-12 03:45:46.374129
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    global_namespace = {'__future__': ast.parse('import __future__', mode='exec').body[0]}
    transformer = Python2FutureTransformer(global_namespace)
    node = ast.parse('a = 1')
    transformer.visit(node)
    assert ast.dump(node) == ast.dump(ast.parse('''
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        a = 1
        '''))

# Generated at 2022-06-12 03:45:55.097360
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import get_ast_string
    future_transformer = Python2FutureTransformer(None, None, None)
    module = ast.Module([ast.Print(dest=None, values=[ast.Str(s='Hello World')], nl=True)])

# Generated at 2022-06-12 03:46:03.591967
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from .test_base import BaseNodeTransformerTestCase
    # Create AST for:
    #   x = 1
    #   y = 2
    root = ast.Module([
        ast.Assign([ast.Name('x', ast.Store())], ast.Num(1)),
        ast.Assign([ast.Name('y', ast.Store())], ast.Num(2))
    ])

    # Create transformer and apply it to the AST
    transformer = Python2FutureTransformer()
    new_root = root.__copy__()
    transformer.visit(new_root)

    # Get the new AST and compare it to the one we want
    new_ast = ast.dump(new_root)

# Generated at 2022-06-12 03:47:11.912821
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    code = '''a = b'''

    expected = '''
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals


a = b'''

    tree = ast.parse(code)
    Python2FutureTransformer().visit(tree)
    result = astor.to_source(tree)
    assert result == expected

# Generated at 2022-06-12 03:47:13.501949
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-12 03:47:16.921159
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    code = 'print("hello")'
    actual_code = transform(ast.parse(code), Python2FutureTransformer(target_versions={}))
    expected_code = """from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

print("hello")"""  # noqa
    assert actual_code == expected_code

# Generated at 2022-06-12 03:47:25.099876
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    '''
    >>> src = '''
    ... # this is a comment

# Generated at 2022-06-12 03:47:26.195632
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # TODO: implement
    raise NotImplementedError()

# Generated at 2022-06-12 03:47:29.213991
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    obj = Python2FutureTransformer()
    assert obj.target == (2, 7)
    assert obj._tree_changed == False
    assert isinstance(obj, BaseNodeTransformer)


# Generated at 2022-06-12 03:47:30.607002
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.transform_test import transform_test
    transform_test(Python2FutureTransformer)

# Generated at 2022-06-12 03:47:32.373696
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert type(transformer) == Python2FutureTransformer
    assert transformer.target == (2, 7)


# Generated at 2022-06-12 03:47:33.122139
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-12 03:47:33.856510
# Unit test for method visit_Module of class Python2FutureTransformer