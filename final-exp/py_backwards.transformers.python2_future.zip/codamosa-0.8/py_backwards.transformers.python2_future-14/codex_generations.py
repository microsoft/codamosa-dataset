

# Generated at 2022-06-12 03:39:58.304250
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    '''Visit module node'''
    import sys
    import textwrap

    from typed_ast.ast3 import parse
    from ..utils.tree import tree_to_str
    from .base import BaseNodeTransformer
    from .Python2FutureTransformer import Python2FutureTransformer

    class TestNodeTransformer(BaseNodeTransformer):
        '''A test transformer implementing visit_Module method'''
        target = (2, 7)

        def visit_Module(self, node):  # pylint: disable=missing-docstring
            self._tree_changed = True

# Generated at 2022-06-12 03:40:07.038837
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = snippet.get_ast_node(imports)
    transformer = Python2FutureTransformer()
    res = transformer.visit(module)
    assert isinstance(res, ast.Module)
    assert len(res.body) == 4
    assert isinstance(res.body[0], ast.ImportFrom)
    assert isinstance(res.body[1], ast.ImportFrom)
    assert isinstance(res.body[2], ast.ImportFrom)
    assert isinstance(res.body[3], ast.ImportFrom)
    assert res.body[0].module == res.body[1].module == res.body[2].module == res.body[3].module == '__future__'
    assert res.body[0].names == [ast.alias(name='absolute_import', asname=None)]
    assert res.body

# Generated at 2022-06-12 03:40:12.537332
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    sample_python_code = 'print("Hello, world!")'
    future_imports = '\n'.join([
        'from __future__ import absolute_import',
        'from __future__ import division',
        'from __future__ import print_function',
        'from __future__ import unicode_literals'])

    expected_python_code = '\n'.join([future_imports, sample_python_code])
    expected_ast = ast.parse(expected_python_code)

    sample_ast = ast.parse(sample_python_code)
    transformer = Python2FutureTransformer()
    assert transformer.visit(sample_ast) == expected_ast

# Generated at 2022-06-12 03:40:13.134934
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-12 03:40:19.557844
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..basic_visitor_mixin import BasicVisitorMixin

    class TestClass(BasicVisitorMixin):
        python_version = (2, 7)

    transformer = TestClass()
    tree = ast.parse("print 1, 2, 3")
    expected = ast.Module(body=transformer.prepend_with_future_imports(tree.body))
    tree = transformer.visit(tree)
    print(ast.dump(tree, include_attributes=True))
    print(ast.dump(expected, include_attributes=True))

    assert tree == expected

# Generated at 2022-06-12 03:40:23.444282
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()
    module = ast.parse('')
    module.body = transformer.visit(module.body)  # type: ignore
    assert transformer.tree_changed
    assert module.body == imports.get_body(future='__future__')



# Generated at 2022-06-12 03:40:33.916661
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    import textwrap
    from ..utils.source_code import SourceCode
    from ..utils.snippet import snippet

    code = textwrap.dedent('''
    class Class1:
        pass
    
    class Class2:
        pass
    ''')
    expected_code = textwrap.dedent('''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    class Class1:
        pass
    
    class Class2:
        pass
    ''')
    tree = ast.parse(code)
    transformer = Python2FutureTransformer()
    transformer.visit(tree)
    actual_code = SourceCode.from_tree(tree)


# Generated at 2022-06-12 03:40:38.993051
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = ast.parse("print('test')")
    
    Python2FutureTransformer().visit(module)  # type: ignore
    
    expected = \
        """
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

print('test')
"""
    assert astor.to_source(module).rstrip() == expected.rstrip()

# Generated at 2022-06-12 03:40:45.637614
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source_code import SourceCode
    from .base import make_call_node
    source = SourceCode.from_statement("""
        import foo
        import bar
        import baz
        """)
    new_tree = Python2FutureTransformer().visit(source.tree)
    # print(ast.dump(new_tree))
    expected_tree = make_call_node("""
        import __future__
        import __future__
        import __future__
        import __future__
        import foo
        import bar
        import baz
        """)
    assert ast.dump(new_tree) == ast.dump(expected_tree)

# Generated at 2022-06-12 03:40:49.311045
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_code_equal
    node = ast.Module(body=[])
    transformer = Python2FutureTransformer()
    actual = transformer.visit(node)
    assert_code_equal(actual, import_statements)

# Generated at 2022-06-12 03:40:51.910530
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-12 03:40:54.658677
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    """Test functionality of method visit_Module of class
    Python2FutureTransformer
    """

# Generated at 2022-06-12 03:41:00.188762
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    test_tree = ast.parse('x=0')
    expected_tree = ast.parse("""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

x=0
    """)
    test_tree = Python2FutureTransformer().visit(test_tree)
    assert ast.dump(test_tree) == ast.dump(expected_tree)

# Generated at 2022-06-12 03:41:10.931730
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Test empty module
    module = ast.Module(body=[])
    module_transformer = Python2FutureTransformer()
    module_transformed = module_transformer.visit(module)
    assert len(module_transformed.body) == 4
    assert module_transformed.body[0].names[0].name == 'absolute_import'
    assert module_transformed.body[0].names[0].asname is None
    assert module_transformed.body[1].names[0].name == 'division'
    assert module_transformed.body[1].names[0].asname is None
    assert module_transformed.body[2].names[0].name == 'print_function'
    assert module_transformed.body[2].names[0].asname is None

# Generated at 2022-06-12 03:41:20.621688
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .base import BaseNodeTransformerTester
    from typed_ast import ast3 as ast
    from ..utils.compare import compare

    # Prepare
    source = '''pass'''
    expected = '''from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

pass
'''
    BaseNodeTransformerTester.test_visit_generic_node(Python2FutureTransformer(), source, expected)
    # Test with no body
    tree = ast.parse(source)
    tree.body.pop()
    actual = compare(tree, tree)
    assert actual is None
    # Test with existing __future__
    source = '''from __future__ import absolute_import
from __future__ import absolute_import
pass'''
   

# Generated at 2022-06-12 03:41:27.509381
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    tests = [
        "\n",
        "x = 1  #\n",
        "# comment\n",
        "\n" + "print(1)\n"
    ]
    for test in tests:
        tree = ast.parse(test)
        Python2FutureTransformer().visit(tree)
        assert(ast.dump(tree).startswith('Module(body=[import_from'))
        # transform back
        tree = ast.parse(test)
        tree = Python2FutureTransformer().visit(tree)
        assert(ast.dump(tree) == ast.dump(ast.parse(test)))

# Generated at 2022-06-12 03:41:36.390830
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    node = astor.parse_file(__file__)

# Generated at 2022-06-12 03:41:46.067631
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from astor.source_repr import to_source
    from os import sep
    from io import StringIO
    filename = 'FakeFile'
    future = '__future__'

    output1 = StringIO()
    ast1 = ast.parse(to_source(imports.get_body(future=future)))
    Python2FutureTransformer(filename).visit(ast1)
    astor.codegen.to_source(ast1, output1)
    source1 = output1.getvalue()

    output2 = StringIO()
    ast2 = ast.parse('')
    Python2FutureTransformer(filename).visit(ast2)
    astor.codegen.to_source(ast2, output2)
    source2 = output2.getvalue()

    # test

# Generated at 2022-06-12 03:41:49.333679
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    tree = ast.parse('a=1')
    t = Python2FutureTransformer()
    tree = t.visit(tree)
    assert tree.body[0].name == 'absolute_import'

# Generated at 2022-06-12 03:41:56.222262
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    code = '''x = "Jirka"
    print("Ahoj", x)'''
    py2_module = astor.parse_file(code)
    transformer = Python2FutureTransformer()
    updated_module = transformer.visit(py2_module)
    assert astor.to_source(updated_module) == '''from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

x = "Jirka"
print("Ahoj", x)
'''

# Generated at 2022-06-12 03:41:59.122154
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    print(Python2FutureTransformer())

# Generated at 2022-06-12 03:42:06.497046
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .test_utils import make_test_module
    from ..utils import code
    
    module = make_test_module(
        source='module_test', 
        path='Dummy/module_test.py',
        source_code="module_test = 3",
    )
    transformer = Python2FutureTransformer()
    module = transformer.visit(module)
    assert code(module) == '''from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

module_test = 3'''

# Generated at 2022-06-12 03:42:15.201875
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from .fixer_util import unit_test
    import random
    import string
    random_string = ''.join(random.choice(string.ascii_lowercase) for _ in range(random.randint(1, 100)))
    tree = ast.parse(random_string)
    actual = unit_test(Python2FutureTransformer, tree)
    expected = 'from __future__ import absolute_import' + '\n' + 'from __future__ import division' + '\n' + 'from __future__ import print_function' + '\n' + 'from __future__ import unicode_literals' + '\n' + random_string
    assert expected == actual

# Generated at 2022-06-12 03:42:16.684305
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer().target == (2, 7)


# Generated at 2022-06-12 03:42:17.653699
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-12 03:42:21.808940
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .test_utils import make_future_node, make_module_node

    node = make_future_node()
    transformer = Python2FutureTransformer()
    result = transformer.visit(node)
    expected = make_module_node([make_future_node()])
    assert result == expected

# Generated at 2022-06-12 03:42:29.441620
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .common import truncate_module_body, transform
    from ..common import get_body
    
    @transform(Python2FutureTransformer)
    def test():
        print(123)
    
    assert test.__doc__ == '\n    print(123)\n'  # type: ignore
    
    module, = get_body(test)  # type: ignore
    module.body = truncate_module_body(module.body)  # type: ignore

# Generated at 2022-06-12 03:42:35.318742
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    tree_before = ast.parse("print('Hello World!')")

    transformer = Python2FutureTransformer()
    transformer.visit(tree_before)

    tree_after = ast.parse("from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\nprint('Hello World!')")

    assert compare_ast(tree_after, tree_before)

# Generated at 2022-06-12 03:42:37.704204
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    instance = Python2FutureTransformer()
    assert isinstance(instance, BaseNodeTransformer)
    assert instance.target == (2, 7)


# Generated at 2022-06-12 03:42:45.880444
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.testutils import assert_node
    from ..utils.testutils import get_node
    from ..utils.testutils import to_source_code
    node = get_node('"TEST"', target=python_version)
    Python2FutureTransformer(target=python_version).visit(node)
    node = get_node(to_source_code(node), target=python_version)
    assert_node(node, '''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    "TEST"
    ''', target=python_version)

# Generated at 2022-06-12 03:42:50.741960
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
  # Test case 1: class Python2FutureTransformer should exists
  Python2FutureTransformer()

# Generated at 2022-06-12 03:42:56.223492
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    expected_tree = ast.parse(
        """from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

print("hello")
"""
    )
    tree = ast.parse("print('hello')")
    tree = NodeTransformer(tree, target_version=(2, 7)).visit()
    assert ast.dump(tree, include_attributes=False) == ast.dump(expected_tree, include_attributes=False)

# Generated at 2022-06-12 03:43:05.268159
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3
    # noinspection PyUnresolvedReferences
    from darglint.transforms.p3_future import Python2FutureTransformer
    module = ast3.parse(
        "def foo(): pass"
    )
    transformer = Python2FutureTransformer('test')
    module = transformer.visit(module)

    assert transformer._tree_changed is True
    assert len(module.body) == 5
    assert all(isinstance(node, ast3.ImportFrom) for node in module.body)
    assert all(node.names[0].name == 'unicode_literals' for node in module.body)
    assert all(node.module == 'future' for node in module.body)
    assert all(node.level == 0 for node in module.body)

# Generated at 2022-06-12 03:43:06.814173
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert isinstance(Python2FutureTransformer(), Python2FutureTransformer)

# Generated at 2022-06-12 03:43:14.633291
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # type: () -> None
    source1 = textwrap.dedent("""\
        a = 1
        """)
    source2 = textwrap.dedent("""\
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        a = 1
        """)
    tree1 = astor.parse_file(io.StringIO(source1))
    tree2 = astor.parse_file(io.StringIO(source2))
    Python2FutureTransformer().visit(tree1)
    print(astor.to_source(tree1).rstrip())
    print(astor.to_source(tree2).rstrip())

# Generated at 2022-06-12 03:43:23.906176
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils import make_test_tree

    transform = Python2FutureTransformer.from_string
    assert transform('print(1)') == 'from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n\nprint(1)\n'
    assert transform('x=1\nprint(x)') == 'from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n\nx=1\nprint(x)\n'

    tree, source = make_test_tree(transform)

# Generated at 2022-06-12 03:43:35.155598
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
        #
        # Given a ModuleNode to be transformed
        #
        node = ast.parse('''\
        def f():
            pass
        class A:
            pass
        ''')
        #
        # When we instantiate a Python2FutureTransformer and call visit_Module
        # with that node
        #
        transformer = Python2FutureTransformer()
        transformer.visit(node)
        #
        # Then the tree should have been transformed appropriately
        #
        expected = '''\
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        def f():
            pass
        class A:
            pass'''
        assert expected == astor.to_source(node).strip()

# Generated at 2022-06-12 03:43:36.045599
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer(None)


# Generated at 2022-06-12 03:43:36.856084
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-12 03:43:40.822112
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert 'Python2FutureTransformer' in globals()
    assert 'BaseNodeTransformer' in globals()
    assert isinstance(Python2FutureTransformer(), Python2FutureTransformer)
    assert isinstance(Python2FutureTransformer(), BaseNodeTransformer)
    assert Python2FutureTransformer.target == (2,7)


# Generated at 2022-06-12 03:43:58.852681
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    """Unit test for method visit_Module of class Python2FutureTransformer
    """
    import autopep8

    t = Python2FutureTransformer
    def f(tree, *args):
        t.target = (2, 7)
        t.visit(tree, *args)
        return tree
    #
    a = f(
        autopep8.parse("print 'hello world'\n")
    )
    assert type(a) == ast.Module
    assert len(a.body) == 4
    assert type(a.body[0]) == ast.ImportFrom
    assert type(a.body[1]) == ast.ImportFrom
    assert type(a.body[2]) == ast.ImportFrom
    assert type(a.body[3]) == ast.ImportFrom

# Generated at 2022-06-12 03:43:59.711159
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    trans = Python2FutureTransformer()


# Generated at 2022-06-12 03:44:01.887776
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert isinstance(transformer, BaseNodeTransformer)
    assert (transformer.target == (2, 7))


# Generated at 2022-06-12 03:44:09.999903
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    input_code = """l = [1, 2, 3]"""
    expected_output = """from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals


l = [1, 2, 3]"""

    tree = ast.parse(input_code)  # type: ignore
    transformer = Python2FutureTransformer()
    tree = transformer.visit(tree)  # type: ignore
    assert transformer._tree_changed
    tree = ast.fix_missing_locations(tree)  # type: ignore
    out_code = compile(tree, filename="<ast>", mode="exec")
    assert expected_output == out_code

# Generated at 2022-06-12 03:44:17.675593
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    tree = ast.parse('pass', mode='exec')
    transformed_tree = Python2FutureTransformer().visit(tree)
    assert len(transformed_tree.body) == 6
    assert isinstance(transformed_tree.body[0], ast.ImportFrom)
    assert transformed_tree.body[0].module == 'future'
    assert transformed_tree.body[0].names[0].name == 'absolute_import'
    assert transformed_tree.body[1].names[0].name == 'division'
    assert transformed_tree.body[2].names[0].name == 'print_function'
    assert transformed_tree.body[3].names[0].name == 'unicode_literals'
    assert isinstance(transformed_tree.body[4], ast.Pass)

# Generated at 2022-06-12 03:44:23.765012
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    from ast_helpers import get_module
    from .support.samples import given_pymodule

    module = get_module(given_pymodule.source)
    module = Python2FutureTransformer().visit(module)

    assert astor.to_source(module).splitlines()[:4] == \
        ['from __future__ import absolute_import',
         'from __future__ import division',
         "from __future__ import print_function",
         "from __future__ import unicode_literals"]


Python2FutureTransformer.__test__ = False  # type: ignore

# Generated at 2022-06-12 03:44:30.910332
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ._utils import round_trip
    from .. import type_aliases as ta

    code = """\
    def func():
        pass

    def func2():
        pass
    """
    expected_code = imports.format(
        future='__future__', 
    ) + code
    ast_tree = round_trip(code, ta.AST)
    actual_ast_tree = Python2FutureTransformer().visit(ast_tree)
    actual_code = round_trip(actual_ast_tree, ta.Code)
    assert actual_code == expected_code

# Generated at 2022-06-12 03:44:35.159356
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from .test_utils import transform_snippet

    snippet = """x = 42"""
    module, info = transform_snippet(snippet, Python2FutureTransformer)
    assert str(module) == "\n".join((
        imports.get_source(future='__future__'),
        "x = 42"
    ))



# Generated at 2022-06-12 03:44:40.888499
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astunparse
    source = """\
a = 1
b = 2
"""
    expected = """\
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

a = 1
b = 2
"""
    node = ast.parse(source)
    Python2FutureTransformer().visit(node)  # type: ignore
    assert astunparse.unparse(node) == expected

# Generated at 2022-06-12 03:44:41.723935
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():  # type: ignore
    Python2FutureTransformer()

# Generated at 2022-06-12 03:45:00.698911
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils import transform_from_ast
    expected = 'from __future__ import absolute_import\n' + \
               'from __future__ import division\n' + \
               'from __future__ import print_function\n' + \
               'from __future__ import unicode_literals\n\n' + \
               'def some_function():\n' + \
               '    pass\n'

# Generated at 2022-06-12 03:45:05.567207
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # Test that a simple module transforms
    module = ast.parse("a")
    trans = Python2FutureTransformer()
    trans.visit(module)

    # Test that imports are added to the module
    assert str(module) == "from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n\na"

# Generated at 2022-06-12 03:45:11.114613
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast

    node = ast.parse('pass')
    actual = Python2FutureTransformer().visit(node)
    expected = ast.parse('from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n\npass\n')
    assert ast.dump(actual) == ast.dump(expected)

# Generated at 2022-06-12 03:45:11.994536
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Unit test

# Generated at 2022-06-12 03:45:19.877038
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast

# Generated at 2022-06-12 03:45:21.937784
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Unit test for constructor of class Python2FutureTransformer"""
    print(Python2FutureTransformer(target=(2, 7)))


# Generated at 2022-06-12 03:45:23.792474
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)

# Generated at 2022-06-12 03:45:30.499078
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    tree = ast.parse('''\
a = 1
b = 2
''')
    tree_changed, tree = Python2FutureTransformer().visit(tree)
    assert tree_changed

# Generated at 2022-06-12 03:45:33.458757
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    fruit = Python2FutureTransformer()
    assert fruit.__class__.__name__ == 'Python2FutureTransformer'
    assert fruit._tree_changed is False
    assert fruit.target == (2, 7)


# Generated at 2022-06-12 03:45:40.346973
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3
    c = Python2FutureTransformer()
    tree = ast3.parse('x = 1')
    tree = c.visit(tree)
    assert str(tree) == "from __future__ import absolute_import" \
                        "\nfrom __future__ import division" \
                        "\nfrom __future__ import print_function" \
                        "\nfrom __future__ import unicode_literals" \
                        "\nx = 1"

# Generated at 2022-06-12 03:46:05.333505
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast.ast3 import parse
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet

    def transform(code):
        tree = parse(code)
        transformer = Python2FutureTransformer()
        tree = transformer.visit(tree)  # type: ignore
        code_after = compile(tree, '<string>', 'exec')

        return (tree, code_after)

    # No change
    _, code_after = transform('')
    assert code_after == compile('', '<string>', 'exec')

    # No change
    _, code_after = transform('from __future__ import absolute_import')
    assert code_after == compile('from __future__ import absolute_import', '<string>', 'exec')

    # No change

# Generated at 2022-06-12 03:46:15.376786
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():

    code = """
from future import absolute_import
from future import division
from future import print_function
from future import unicode_literals
print(0)
"""
    tree = ast.parse(code)  # type: ignore
    node = Python2FutureTransformer().visit(tree)  # type: ignore
    assert ast.dump(node) == ast.dump(tree)

    code = """
import os
print(os)
"""
    expected = """
import os
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
print(os)
"""
    tree = ast.parse(code)  # type: ignore
    node = Python2FutureTransformer().visit(tree)  # type: ignore

# Generated at 2022-06-12 03:46:21.523363
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer(None)
    # 1. Transforming a module with one empty node
    module = ast.Module([])
    module_transformed = transformer.visit_Module(module)
    assert len(module_transformed.body) == 4
    # 2. Transforming a module with one non-empty node
    module = ast.Module([ast.Expr(ast.Str('Hello'))])
    module_transformed = transformer.visit_Module(module)
    assert len(module_transformed.body) == 5

# Generated at 2022-06-12 03:46:27.979742
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transform = Python2FutureTransformer()
    assert isinstance(transform, BaseNodeTransformer)
    assert transform._tree_changed is False

    node = ast.parse('import os')
    node = transform.visit(node)
    assert isinstance(node, ast.Module)
    assert transform._tree_changed is True

    assert ast.dump(node, include_attributes=False) == ast.dump(imports.get_ast(future='__future__') + ast.parse('import os'),
                                                                include_attributes=False)



# Generated at 2022-06-12 03:46:34.121859
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    from textwrap import dedent
    code = dedent('''\
    def foo():
        print('hello')

    class Bar():
        pass
    ''')
    tree = ast.parse(code)
    t = Python2FutureTransformer()
    assert 'from __future__' not in code
    t.visit(tree)  # type: ignore
    code_transformed = astor.to_source(tree)

    assert 'from __future__' in code_transformed



# Generated at 2022-06-12 03:46:35.309331
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor

# Generated at 2022-06-12 03:46:41.811287
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ast import parse
    from .tests.utils import transform

    source = 'module_body()'
    expected = ('from __future__ import absolute_import\n'
                'from __future__ import division\n'
                'from __future__ import print_function\n'
                'from __future__ import unicode_literals\n'
                'module_body()')
    tree = parse(source)
    new_tree = transform(tree, Python2FutureTransformer)
    assert ast.dump(new_tree) == ast.dump(parse(expected))

# Generated at 2022-06-12 03:46:42.870825
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__doc__ is not None


# Generated at 2022-06-12 03:46:49.478648
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    """Unit test for method visit_Module of class Python2FutureTransformer."""
    # Input and expected output
    input = """x = 5"""
    expected_output = """from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
x = 5"""
    # Perform test
    node = ast.parse(input)
    node = Python2FutureTransformer().visit(node)
    actual_output = astunparse.unparse(node)
    # Assertions
    assert actual_output == expected_output

# Generated at 2022-06-12 03:46:50.833180
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()

    assert transformer.target == (2, 7)

# Generated at 2022-06-12 03:47:31.193361
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    """
    Python2FutureTransformer
    visit_Module
    """
    print(Python2FutureTransformer.visit_Module.__doc__)
    code_in = "import datetime"
    code_out = "from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\nimport datetime\n"
    mod_in = ast.parse(code_in)
    mod_out = ast.parse(code_out)
    Python2FutureTransformer().visit(mod_in)
    assert ast.dump(mod_in) == ast.dump(mod_out)

# Generated at 2022-06-12 03:47:35.916586
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from textwrap import dedent
    from .test_transformer import transform
    # Check that the transformer is created correctly and performs the expected transfor
    code = dedent("""
    def foo():
        return 'import test'
    """)
    result = dedent("""
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    def foo():
        return 'import test'
    """)
    assert transform(code, Python2FutureTransformer) == result

# Generated at 2022-06-12 03:47:39.404123
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.fixtures import make_dummy_future_tree, make_dummy_future_tree_string
    dummy_tree = make_dummy_future_tree()
    dummy_tree_string = make_dummy_future_tree_string()
    dummy_tree_result = Python2FutureTransformer().transform(dummy_tree)
    assert astunparse.unparse(dummy_tree_result) == dummy_tree_string

# Generated at 2022-06-12 03:47:40.709739
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Unit test for constructor of class Python2FutureTransformer"""
    transformer = Python2FutureTransformer()
    assert transformer is not None

# Generated at 2022-06-12 03:47:42.030903
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer


# Generated at 2022-06-12 03:47:47.352339
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    old_source = """
    import os
    import sys

    os.getcwd()
    """
    expected_source = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    import os
    import sys

    os.getcwd()
    """
    transformer = Python2FutureTransformer()
    source = transformer.transform_source(old_source)
    assert source == expected_source

# Generated at 2022-06-12 03:47:52.032993
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from .bake import bake

    # Unit test for constructor of class Python2FutureTransformer
    def test_Python2FutureTransformer():
        from .bake import bake
        node = ast.parse('import os')
        node = bake(node, Python2FutureTransformer)
        assert len(node.body) == 5
        for i in node.body:
            assert i.lineno == 1
            assert i.col_offset == 0

# Generated at 2022-06-12 03:47:52.885991
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-12 03:48:02.704580
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Basic code tree
    tree = ast.parse(textwrap.dedent(
        """
        def foo():
            print(6/5)
            print('reformatted_text')
        """
    ))

    # Create an instance of Python2FutureTransformer class
    transformer = Python2FutureTransformer()
    # Transform the code tree
    tree = transformer.visit(tree)
    # Convert the transformed (or untouched if not transformed) code tree back to source code
    src = astunparse.unparse(tree)

    # Transform back to abstract syntax tree
    new_tree = ast.parse(src)

    # Check that the tree is changed
    assert transformer._tree_changed

    # Create an instance of Python2FutureTransformer class
    transformer = Python2FutureTransformer()
    # Transform the code tree
    new_tree = transformer

# Generated at 2022-06-12 03:48:05.817921
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    
    # test if constructor creates correct object
    assert hasattr(transformer, 'target')
    assert isinstance(transformer.target, tuple)
    assert isinstance(transformer.target[0], int)
    assert isinstance(transformer.target[1], int)
    assert transformer.target == (2, 7)


# Generated at 2022-06-12 03:49:26.282443
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)
    assert transformer.visit_Module is Python2FutureTransfor

# Generated at 2022-06-12 03:49:29.314390
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    root = ast.parse('x = 0', mode="exec")
    new_root = transformer.visit(root)
    assert new_root != root
    assert transformer._tree_changed is True



# Generated at 2022-06-12 03:49:36.923896
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # Test with good input
    m = ast.parse("""
    class Test(object):
        pass
    """, "", "exec")
    Python2FutureTransformer().visit(m)
    assert 'from __future__ import absolute_import' in ast.dump(m)
    assert 'from __future__ import division' in ast.dump(m)
    assert 'from __future__ import print_function' in ast.dump(m)
    assert 'from __future__ import unicode_literals' in ast.dump(m)
    # Test with bad input
    with pytest.raises(AttributeError):
        m = ast.parse("""
        class Test(object):
            pass
        """, "", "exec")
        Python2FutureTransformer().visit(m)
    # Test with bad input

# Generated at 2022-06-12 03:49:45.374998
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import os
    import textwrap
    import typed_ast.ast3 as ast3
    import astunparse
    from typed_ast.ast3 import parse

    class Python2FutureTransformer_visit_Module(unittest.TestCase):

        def test_Python2FutureTransformer_visit_Module(self):
            test_input = """
            # A comment
            a = 1
            print('Hello')
            """
            expected_output = """
            # A comment
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
            a = 1
            print('Hello')
            """
            test_input_ast3 = parse(test_input, mode='exec')