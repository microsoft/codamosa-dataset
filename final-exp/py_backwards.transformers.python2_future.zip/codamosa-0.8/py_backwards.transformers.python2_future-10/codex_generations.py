

# Generated at 2022-06-12 03:39:49.276797
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..tests.utils import compile_
    from ..tests.utils import strip_
    tree = compile_(r"""from typing import List""", 'exec', 'single', 6)
    tree = strip_(Python2FutureTransformer.__qualname__, tree)
    tree.body = tree.body[1:]
    output = compile_(tree, 'exec', 'single', 2)
    assert output == imports.get_body(future='__future__') + [tree.body[0]]

# Generated at 2022-06-12 03:39:58.985449
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils import _get_sample_file
    from ..utils.ast_tools import ast_from_file, compare_ast

    source_file = _get_sample_file('Python2FutureTransformer/source/visit_Module/source.py')
    source_ast = ast_from_file(source_file)

    target_file = _get_sample_file('Python2FutureTransformer/target/visit_Module/target.py')
    target_ast = ast_from_file(target_file)

    transformer = Python2FutureTransformer()
    transformer.visit(source_ast)
    assert compare_ast(source_ast, target_ast)

# Generated at 2022-06-12 03:40:05.305295
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .. import test_utils # pylint: disable=import-outside-toplevel
    node = test_utils.build_ast("""
        print("hello world")
    """, '2to3')
    assert Python2FutureTransformer().visit(node) == ast.parse(
        """
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        print("hello world")
        """
    )

# Generated at 2022-06-12 03:40:08.191192
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source2ast_visit
    tree = source2ast_visit(Python2FutureTransformer, __name__)
    print(ast.dump(tree))



# Generated at 2022-06-12 03:40:13.822197
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_dummy_future_module_ast
    code = '''def f(x, y, z=None):
    if z is None:
        z = x + y
    return z
'''
    body = make_dummy_future_module_ast(code).body
    exp = imports.get_body('__future__') + body
    future = Python2FutureTransformer()
    future.visit(body)
    assert exp == future.module

# Generated at 2022-06-12 03:40:21.268303
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import autoflake

    future_transformer = Python2FutureTransformer()
    tree = future_transformer.visit(autoflake.__ast__)
    body = tree.body
    future_nodes = body[:4] # type: ignore

    assert future_nodes[0] == ast.ImportFrom(module='__future__', names=[
        ast.alias(name='absolute_import', asname=None),
        ast.alias(name='division', asname=None),
        ast.alias(name='print_function', asname=None),
        ast.alias(name='unicode_literals', asname=None),
    ], level=0)
    assert future_nodes[1] == ast.Import(names=[ast.alias(name='ast', asname=None)])

# Generated at 2022-06-12 03:40:24.543950
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():

    module = ast.parse('import os\nprint("Hello world")')
  
    node = Python2FutureTransformer().visit(module)

    assert node.body[0].module == '__future__'

# Generated at 2022-06-12 03:40:30.041273
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..fixers import fixer_factory
    from typed_ast import ast3
    import astor
    factory = fixer_factory(2, 7)
    fixer = factory.create_fixer(Python2FutureTransformer)
    tree = astor.parse_file("test.py", future_unicode=True)
    tree = fixer.visit(tree)
    print(astor.to_source(tree))

# Generated at 2022-06-12 03:40:36.921739
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    class DummyNode(object):
        def __init__(self, body):
            self.body = body

    dummy_node = DummyNode([1, 2, 3])

# Generated at 2022-06-12 03:40:44.879147
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # type: () -> None
    code = ast.parse(textwrap.dedent('''
    def f():
        pass
    '''))
    xformer = Python2FutureTransformer()
    xformer.visit_Module(code)
    assert ast.dump(code, include_attributes=True) == textwrap.dedent('''
    <Module lineno="1" col_offset="0">
      <FunctionDef name="f" lineno="1" col_offset="0">
        <arguments lineno="1" col_offset="4">
        </arguments>
        <Pass lineno="2" col_offset="4">
        </Pass>
      </FunctionDef>
    </Module>
    ''')

# Generated at 2022-06-12 03:40:56.542550
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast

    class ExtractImports(ast.NodeVisitor):
        def __init__(self):
            self.imports: List[str] = []

        def visit_Import(self, node: ast.Import):
            self.imports.extend(alias.name for alias in node.names)

        def visit_ImportFrom(self, node: ast.ImportFrom):
            self.imports.append(node.module)

    def _test(node: ast.Module, expected_imports: List[str]):
        node = Python2FutureTransformer().visit(node)
        actual_imports = ExtractImports().visit(node)
        assert actual_imports == expected_imports


# Generated at 2022-06-12 03:41:05.420942
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from textwrap import dedent
    from ..testing_utils import assert_equivalent_node
    code = dedent(r"""
    if True:
        pass
    """)
    expected = dedent(r"""
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    if True:
        pass
    """)
    result = Python2FutureTransformer(code).visit()
    expected = (Python2FutureTransformer(expected)
                        .visit()
                        .body[0])
    assert_equivalent_node(result.body[0], expected)

# Generated at 2022-06-12 03:41:09.584346
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse("")
    assert node.body == []

    visitor = Python2FutureTransformer(tree=node)
    node = visitor.visit(node)

    assert node.body == imports.get_body(future='__future__')

# Generated at 2022-06-12 03:41:16.420808
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = ast.Module()
    module.body = [
        ast.Assign([ast.Name('x', ast.Store())], ast.Num(2))
    ]

    transformer = Python2FutureTransformer()
    assert transformer.visit(module) == ast.parse(
        '''
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        x = 2
        ''')



# Generated at 2022-06-12 03:41:23.358736
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    """Test for method visit_Module of class Python2FutureTransformer."""
    # expected = ast.Module(
    #     body=[
    #         ast.ImportFrom(
    #             module="__future__",
    #             names=[
    #                 ast.alias(
    #                     name="unicode_literals",
    #                     asname=None
    #                 ),
    #                 ast.alias(
    #                     name="print_function",
    #                     asname=None
    #                 ),
    #                 ast.alias(
    #                     name="division",
    #                     asname=None
    #                 ),
    #                 ast.alias(
    #                     name="absolute_import",
    #                     asname=None
    #                 )
    #             ],
    #             level=0
    #         )


# Generated at 2022-06-12 03:41:26.126458
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse(imports.get_text(future='__future__'))
    assert ast.dump(node) == ast.dump(Python2FutureTransformer().visit(node))



# Generated at 2022-06-12 03:41:31.547091
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = ast.parse("""\
x = 5
y = 6
""")
    expected = ast.parse("""\
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

x = 5
y = 6
""")
    transformer = Python2FutureTransformer()
    assert transformer.visit(module) == expected

# Generated at 2022-06-12 03:41:37.252083
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = ast.parse("print(1)")

    transformer = Python2FutureTransformer()
    actual_ast = transformer.visit(module)

    expected_ast = ast.parse(
        "from __future__ import absolute_import\n"
        "from __future__ import division\n"
        "from __future__ import print_function\n"
        "from __future__ import unicode_literals\n"
        "\n"
        "print(1)"
    )

    assert ast.dump(expected_ast, include_attributes=True) == ast.dump(actual_ast, include_attributes=True)

# Generated at 2022-06-12 03:41:42.519851
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .transformer import transform_string
    from .python3 import Python3Transformer
    from .docstring import DocstringTransformer
    from .formatting import FormattingTransformer
    from .renames import RenameTransformer
    from .parent import ParentTransformer
    from .typing import TypingTransformer
    from ..codegen import to_source


# Generated at 2022-06-12 03:41:47.774040
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_source

    e = ast.parse('1')
    e = Python2FutureTransformer().visit(e)
    assert_source(e, '''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    1''')

# Generated at 2022-06-12 03:41:51.893810
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-12 03:41:54.396023
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    class1 = Python2FutureTransformer(import_future=True)
    assert class1 != None
    class2 = Python2FutureTransformer(import_future=False)
    assert class2 != None


# Generated at 2022-06-12 03:42:04.844756
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast

    transformer = Python2FutureTransformer()
    tree = ast.parse(textwrap.dedent(
        """
        def f(x, y):
            return x + y
        """
    ))
    transformer.visit(tree)


# Generated at 2022-06-12 03:42:06.057367
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer is not None


# Generated at 2022-06-12 03:42:06.884742
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer() is not None

# Generated at 2022-06-12 03:42:11.719575
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    node = ast.parse("print(1)")
    transformer = Python2FutureTransformer()
    module = transformer.visit(node)
    assert str(module) == "from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\nprint(1)\n"

# Generated at 2022-06-12 03:42:13.547479
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module = ast.parse("a = 10")
    assert Python2FutureTransformer().visit(module)

# Generated at 2022-06-12 03:42:14.495476
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-12 03:42:21.074326
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..testing_utils import assert_tree_equality

    before = """\
a = 1
b = 2
"""
    after = """\
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
a = 1
b = 2
"""
    tree = ast.parse(before)
    Python2FutureTransformer().visit(tree)
    assert_tree_equality(tree, ast.parse(after))

# Generated at 2022-06-12 03:42:22.684926
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)



# Generated at 2022-06-12 03:42:32.767917
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from py2py3.transformers.tests.test_fixtures.imports import \
        imports_fixture as fixture

    transformer = Python2FutureTransformer()  # type: ignore
    result = transformer.visit(fixture.node())  # type: ignore
    assert fixture.compare(result)

# Generated at 2022-06-12 03:42:40.689961
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Arrange
    from typed_ast.ast3 import Module, Subscript, Name, Store, Num, ImportFrom, Tuple, Str
    from typed_ast.ast3 import Assign, FunctionDef, arguments, comper

# Generated at 2022-06-12 03:42:50.364110
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from astroid import builder
    from astroid import parse
    from ..common import Future
    from ..transformers import TransformRegistry, Python2FutureTransformer

    ast_module = builder.parse(imports(), __name__)
    ast_module_2to3 = parse(imports(), __name__)
    node_module = ast.Module(name=__name__, body=ast_module.body)
    node_module_2to3 = ast.Module(name=__name__, body=ast_module_2to3.body)
    assert Python2FutureTransformer().visit(node_module) == node_module_2to3

    registry = TransformRegistry()
    registry.register(Python2FutureTransformer(target=(2, 7)), Future)

    result = registry.apply(ast_module, __name__)

# Generated at 2022-06-12 03:42:58.313377
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    import pprint
    visitor = Python2FutureTransformer()
    code = 'pass'
    node = ast.parse(code)
    new_node = visitor.visit(node)
    pp = pprint.PrettyPrinter(indent=4)
    pp.pprint(ast.dump(new_node))

# Generated at 2022-06-12 03:43:02.609937
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import sys
    import ast
    t = ast.parse('''
    import sys
    import ast
    def test():
      print(1)
    ''')
    t2 = Python2FutureTransformer().visit(t)
    assert isinstance(t2, ast.Module)
    print(ast.dump(t2))

# Generated at 2022-06-12 03:43:08.944885
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer().visit_Module(ast.parse('''
    from __future__ import unicode_literals
    
    
    
    
    
    
    
    x = 1
    ''')) == ast.parse('''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    
    
    
    
    
    
    
    x = 1
    ''')

# Generated at 2022-06-12 03:43:10.535544
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert isinstance(transformer, BaseNodeTransformer)

# Generated at 2022-06-12 03:43:16.435887
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    from ast_helpers.visitor import run_visitor
    from ast_helpers.node_utils import print_tree
    from ast_helpers.transformers import Python2FutureTransformer
    from ast_helpers.transformers import Python2WriterTransformer

    code = """
        import os # noqa
        def main():
            print('hello world')
    """
    tree = ast.parse(code)
    tree = run_visitor(Python2FutureTransformer, tree)  # type: ignore
    tree = run_visitor(Python2WriterTransformer, tree)  # type: ignore

# Generated at 2022-06-12 03:43:24.370407
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast

    source = '''
x = "1"
print(x)
'''

    tree = ast.parse(source)
    assert source == ast.unparse(tree)
    tr = Python2FutureTransformer()
    result = tr.visit(tree)
    assert result is not tree
    assert tr._tree_changed is True

    expected = '''from future import absolute_import
from future import division
from future import print_function
from future import unicode_literals


x = "1"
print(x)
'''
    result_unparsed = ast.unparse(result)
    assert expected == result_unparsed

# Generated at 2022-06-12 03:43:32.259455
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    node = ast.parse('')
    node = Python2FutureTransformer(node).visit(node)
    assert len(node.body) == 4
    for i in range(4):
        assert isinstance(node.body[i], ast.ImportFrom) and node.body[i].module == '__future__'
        assert isinstance(node.body[i].names[0], ast.alias) and node.body[i].names[0].name == ('absolute_import', 'division', 'print_function', 'unicode_literals')[i]

# Generated at 2022-06-12 03:43:46.391285
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    class_ = Python2FutureTransformer()
    assert class_.target == (2, 7)

# Generated at 2022-06-12 03:43:48.167627
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    c = Python2FutureTransformer()
    assert c.target == (2, 7)


# Generated at 2022-06-12 03:43:49.117550
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__doc__ is not None

# Generated at 2022-06-12 03:43:59.885710
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    from ast_transformer.transformers.python3_future import Python3FutureTransformer
    from ast_transformer.transformers.python2_future import Python2FutureTransformer

    example_tree = ast.parse('')

    expected_tree = ast.parse(imports.get_source(future='__future__'))  # type: ignore
    expected_tree = ast.Module(body=expected_tree.body)  # type: ignore

    tree_transformer = Python2FutureTransformer()
    transformed_tree = tree_transformer.visit(example_tree)

    assert astor.to_source(transformed_tree).strip() == astor.to_source(expected_tree).strip()  # type: ignore
    assert tree_transformer.tree_changed()


# Generated at 2022-06-12 03:44:05.597657
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..case import to_source

    tree = ast.parse(r"""
f = 1
print(f)
""")
    new = Python2FutureTransformer().visit(tree)  # type: ignore
    source = to_source(new)
    print(source)
    assert source == r"""from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

f = 1
print(f)
""".lstrip()

# Generated at 2022-06-12 03:44:06.770510
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert type(Python2FutureTransformer.visit_Module) is type

# Generated at 2022-06-12 03:44:15.867372
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor, ast
    from transpyle.utils.ast_builder import AstBuilder
    from transpyle.analyze import FileAnalyser
    from transpyle.general import python2future_transformer
    source_code = (
        'def hello_world():\n'
        '    print("Hello, world!")\n'
    )
    module = astor.parse_file(source_code)
    transformer = python2future_transformer.create()
    module = transformer.visit(module)  # type: ignore
    assert transformer._tree_changed is True
    # Check body

# Generated at 2022-06-12 03:44:22.338983
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import sys
    from typed_ast import ast3 as ast
    from typed_ast import parse

    source = """
    print('Hello, world!')
    """

    expected = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    
    print('Hello, world!')
    """

    tree = parse(source)
    result = Python2FutureTransformer(
        tree, filename='', target_version=sys.version_info).visit(tree)
    actual = ast.unparse(result, indentation='    ')
    assert actual == expected

# Generated at 2022-06-12 03:44:24.988157
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    """Test method visit_Module of class Python2FutureTransformer."""
    from asttokens import ASTTokens
    from ..utils.source import source2ast


# Generated at 2022-06-12 03:44:29.652339
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import typed_ast.ast3
    import astor
    snippet.assert_snippet(Python2FutureTransformer, '2to3',
                           typed_ast.ast3.parse(imports.get_code()),
                           astor.to_source(imports.get_ast()),
                           imports.get_body(future='__future__').body)

# Generated at 2022-06-12 03:45:00.847526
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = ast.parse(textwrap.dedent("""
    def foo():
        pass
    """))
    
    translator = Python2FutureTransformer()
    translator.visit(module)

    module = ast.parse(textwrap.dedent("""
    from future import absolute_import
    from future import division
    from future import print_function
    from future import unicode_literals
    
    def foo():
        pass
    """))

    assert ast.dump(module) == ast.dump(translator.module)

# Generated at 2022-06-12 03:45:01.624390
# Unit test for constructor of class Python2FutureTransformer

# Generated at 2022-06-12 03:45:11.353812
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():  # noqa
    from .base import get_node_of_class
    from .base import get_tuple_of_nodes_of_class
    from .base import NodeTestCase
    from typed_ast import ast3 as ast

    class TestCase(NodeTestCase):
        target_cls = ast.Module
        module_path = __name__
        transformer = Python2FutureTransformer

        def create_node(self):  # noqa
            return ast.parse(source=self.source)


# Generated at 2022-06-12 03:45:19.458245
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
   """Unit test for Python2FutureTransformer"""

# Generated at 2022-06-12 03:45:24.147320
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    source = 'print("hello")'
    expected = """\
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

print("hello")
"""
    result = Python2FutureTransformer().visit(source)
    assert result == expected

# Generated at 2022-06-12 03:45:26.237752
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Unit test for constructor of class Python2FutureTransformer."""
    obj = Python2FutureTransformer()
    assert isinstance(obj, BaseNodeTransformer)


# Generated at 2022-06-12 03:45:33.966911
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils import byteplay
    from ..utils import parse
    from ..utils import Source

    source = '''
    import os
    import sys

    a = 1
    b = 2
    c = 3
    '''

    ast_tree = parse(source)
    Python2FutureTransformer(debug=False).visit(ast_tree)
    ast_tree = Python2FutureTransformer.visit(ast_tree)
    result = Python2FutureTransformer.visit(ast_tree)
    code = compile(result, 'test', 'exec')
    c = byteplay.Code.from_code(code)
    source = Source(c)
    source.lines.insert(0, 'from __future__ import absolute_import')
    source.lines.insert(1, 'from __future__ import division')
    source.lines

# Generated at 2022-06-12 03:45:37.697056
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-12 03:45:44.996032
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import typed_ast.ast3 as ast
    # Define the module to be tested
    module_to_be_tested = ast.parse('def test(a):\n    return a + 1')
    # Instantiate the transformer
    transformer = Python2FutureTransformer()
    # Apply the method
    transformer.visit(module_to_be_tested)
    # Test if the imports have been added
    assert len(module_to_be_tested.body) == 4

# Generated at 2022-06-12 03:45:45.934470
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer(source='', target=(2, 7))

# Generated at 2022-06-12 03:46:51.476310
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    source1 = '''
x=1
if True:
    print('hello')
'''
    source2 = '''
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

x=1
if True:
    print('hello')
'''
    tree1 = ast.parse(source1)
    tree2 = ast.parse(source2)
    t = Python2FutureTransformer()
    new_tree = t.visit(tree1)
    assert ast.dump(new_tree) == ast.dump(tree2)

# Generated at 2022-06-12 03:46:55.822786
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    tree = ast.parse('x = 2')
    transformer = Python2FutureTransformer('snippet')
    with patch('typed_astunparse.unparse', return_value='code') as unparse:
        assert transformer.visit(tree) == 'code'
        unparse.assert_called_once()

# Generated at 2022-06-12 03:47:03.723578
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import Source
    transformer = Python2FutureTransformer()
    source2 = """
a = 2
print(a)
"""
    transformer.visit(ast.parse(source2))
    assert transformer._tree_changed
    assert list(ast.walk(ast.parse(str(transformer))))[0] == ast.parse(str(transformer))
    source3 = """
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

a = 3
print(a)
"""
    transformer.visit(ast.parse(source3))
    assert not transformer._tree_changed
    assert list(ast.walk(ast.parse(str(transformer))))[0] == ast.parse(source3)

# Generated at 2022-06-12 03:47:04.533488
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer is not None


# Generated at 2022-06-12 03:47:14.192324
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from .python2future import Python2FutureTransformer
    from .utils import clean_whitespaces, get_ast_node, _print
    from .codeconv import Codeconv

    @snippet
    def before():
        def module():
            pass

    @snippet
    def expected():
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        def module():
            pass

    node = get_ast_node(before)
    transformer = Python2FutureTransformer(Codeconv(debug=True))
    result = transformer.visit(node)
    result

# Generated at 2022-06-12 03:47:15.905561
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils import py27_transformer_fixture
    # Given
    transformer = Python2FutureTransformer()

# Generated at 2022-06-12 03:47:21.920047
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # No error should be issued for Python 2 source code
    source = """
import sys
import os

x = 1 + 2
    """
    import astor
    try:
        tree = ast.parse(source)
        transformer = Python2FutureTransformer()
        new_tree = transformer.visit(tree)
        assert transformer.tree_changed  # Make sure transformation did actually happen
        print(astor.to_source(new_tree))
    except (ValueError, SyntaxError):
        assert False



# Generated at 2022-06-12 03:47:27.297766
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    tree = ast.parse("a = 1\nb = 3", mode='exec')
    transformer = Python2FutureTransformer()
    tree = transformer.visit(tree)
    assert transformer.has_changed()
    assert transformer.count == 1
    assert ast.dump(tree) == textwrap.dedent("""\
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        a = 1
        b = 3""")

# Generated at 2022-06-12 03:47:30.428789
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from .base import BaseNodeTransformer
    assert issubclass(Python2FutureTransformer, BaseNodeTransformer)
    assert Python2FutureTransformer.target == (2, 7)

# Test for visit_Module of class Python2FutureTransformer

# Generated at 2022-06-12 03:47:35.023428
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import ast
    import textwrap
    from library.python2_future.transformer import Python2FutureTransformer
    module = ast.parse("print('Hello')")
    Python2FutureTransformer().visit(module)
    code = textwrap.dedent("""
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        print('Hello')
    """)
    assert code == astunparse.unparse(module)