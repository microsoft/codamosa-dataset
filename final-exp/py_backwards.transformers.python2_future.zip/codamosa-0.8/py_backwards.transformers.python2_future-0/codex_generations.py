

# Generated at 2022-06-12 03:39:50.551059
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    from makefun import with_signature
    from ..utils.accelerator_ast import make_accelerator_ast

    orig_code = "def foo():\n    pass"
    mod = astor.parse_file(orig_code)

    trnsfmr = Python2FutureTransformer()
    node = trnsfmr.visit(mod)

    expected_mod = astor.parse_file(imports(future='__future__'))
    expected_mod.body.append(mod.body[0])

    assert astor.to_source(node) == astor.to_source(expected_mod)
    assert node == expected_mod

# Generated at 2022-06-12 03:39:59.749743
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source
    from ..utils.experimental_visitor import ExperimentalNodeVisitor
    from ..utils.helper import string_to_ast as ast_parse

    class PrintVisitor(ExperimentalNodeVisitor):
        def visit_Module(self, node):
            print(ast.dump(node, annotate_fields=False, include_attributes=False))


    tree = ast_parse(source)
    transformer = Python2FutureTransformer()
    ast.fix_missing_locations(transformer.visit(tree))
    PrintVisitor().visit(tree)
    assert transformer._tree_changed

# Generated at 2022-06-12 03:40:01.013010
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()
    assert t is not None



# Generated at 2022-06-12 03:40:04.126450
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    print("TEST")
    tree = ast.parse("print(1+1)")
    print(ast.dump(tree))
    t = Python2FutureTransformer()
    print(ast.dump(t.visit(tree)))
    print(t)

# Generated at 2022-06-12 03:40:04.592563
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-12 03:40:09.920567
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """
    Test for `Python2FutureTransformer`
    """
    #Arrange
    #Act
    cls = Python2FutureTransformer()
    #Assert
    assert cls._future is None
    assert cls._tree_changed is False
    assert cls._in_top_stmt is False
    assert cls.target == (2, 7)
    assert cls.visit_Module != None

# Generated at 2022-06-12 03:40:11.431594
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    x = Python2FutureTransformer()
    assert isinstance(x, Python2FutureTransformer)

# Generated at 2022-06-12 03:40:12.575944
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer is not None


# Generated at 2022-06-12 03:40:19.877503
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    class ModuleVisitor(BaseNodeTransformer):
        """prints out body of ast.Module as a list of statements"""
        def visit_Module(self, node: ast.Module) -> ast.Module:
            print(node.body)
            return node
    module_visitor = ModuleVisitor()
    module = ast.parse("print('hi')")
    module_visitor.visit(module)
    python2_future = Python2FutureTransformer()
    module = ast.parse("print('hi')")
    print(type(module))
    print(type(python2_future.visit(module)))
    module_visitor.visit(python2_future.visit(module))

# Generated at 2022-06-12 03:40:29.783178
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import sys
    import copy
    from typed_ast import ast3 as ast

    # This is the module for which the test will be run.
    # The attribute '_fields' has to be a tuple of strings.
    # The attributes '_astname' and '_fields' are required.
    # The rest are optional.
    module = type('FakeModule', (ast.Module,), {'_astname': 'Module', '_fields': ('body', )})

    # This will be the list of nodes attached to the module as body.
    # Each of the nodes has to be in the form (name, value).
    nodes_body = [('dummy_node', None)]

    # Build the module.
    module_ = module(body=nodes_body)

    # Instantiate class Python2FutureTransformer.
    transformer = Python2Future

# Generated at 2022-06-12 03:40:33.148773
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()


# Generated at 2022-06-12 03:40:35.267606
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 03:40:39.268419
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse("y = 'string'\nx  = 2")
    transformer = Python2FutureTransformer()
    transformer.visit(node)
    assert transformer.changed == True
    assert transformer._tree_changed == True
    #assert ast.dump(node) == "import sys\nimport ast\n\n"



# Generated at 2022-06-12 03:40:43.992842
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    node = ast.parse("print 'You can do it'")
    # Apply Python2FutureTransformer to node.
    node = Python2FutureTransformer().visit(node)
    # Compile the AST to code
    code = compile(node, '<string>', 'exec')
    import sys
    sys.modules.pop('builtins', None)
    exec(code, globals())
    assert True

# Generated at 2022-06-12 03:40:45.554573
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    '''Test if transformer is properly initialized.'''
    transformer = Python2FutureTransformer()
    assert transformer._tree_changed is False



# Generated at 2022-06-12 03:40:46.272929
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor

# Generated at 2022-06-12 03:40:55.321086
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixturedir import FixtureDir
    from ..utils.syntax import parse

    with FixtureDir(os.path.join(os.path.dirname(__file__), '..', 'fixtures')) as f:
        f.write('typing.py', '''
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals

            from typing import *
            ''')

        tree = Python2FutureTransformer().visit(parse(f.file('typing.py')))
        print(ast.dump(tree))

# Generated at 2022-06-12 03:40:56.751129
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    snippet.test_snippet(Python2FutureTransformer, imports, '__future__')

# Generated at 2022-06-12 03:40:59.679592
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = ast.Module([])
    options = {}
    Python2FutureTransformer.transform(module, options)
    assert isinstance(module.body, list) and len(module.body) == 4

# Generated at 2022-06-12 03:41:10.466333
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..transformers import Python2FutureTransformer
    from ..transformers import generic_visit
 
    class DummyVisitor(Python2FutureTransformer):

        def generic_visit(self, node: ast.Module) -> ast.Module:
            return ast.copy_location(generic_visit(self, node, 'body'), node)

    module = ast.parse('''
        class C:
            pass
    ''')  # type: ast.AST
    module = ast.fix_missing_locations(module)
    module = DummyVisitor().visit(module)
    assert len(module.body) == 5
    assert module.body[0].lineno == 1
    assert module.body[1].lineno == 1
    assert module.body[2].lineno == 1

# Generated at 2022-06-12 03:41:20.655318
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast

    node = ast.parse("def foo(): pass\n")
    transformer = Python2FutureTransformer()
    new_node = transformer.visit(node)

    assert new_node.body[0].value.s == '__future__'
    assert new_node.body[1].value.s == '__future__'
    assert new_node.body[2].value.s == '__future__'
    assert new_node.body[3].value.s == '__future__'
    assert isinstance(new_node.body[4], ast.FunctionDef)

# Generated at 2022-06-12 03:41:24.503779
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    class TF(Python2FutureTransformer):

        def visit_Module(self, node: ast.Module) -> ast.Module: 
            self._tree_changed = True
            node.body = [self.result] + node.body  # type: ignore
            return self.generic_visit(node)  # type: ignore


# Generated at 2022-06-12 03:41:27.366863
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast.ast3 import parse
    tree = parse("x = 1")
    print(tree)
    transformer = Python2FutureTransformer()
    tree = transformer.visit(tree)
    print(tree)

# Generated at 2022-06-12 03:41:28.492266
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer(None)


# Generated at 2022-06-12 03:41:29.482516
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    obj = Python2FutureTransformer()
    assert obj

# Generated at 2022-06-12 03:41:32.169346
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Unit test for constructor of class Python2FutureTransformer"""
    x = Python2FutureTransformer()
    assert x.target == (2, 7)


# Generated at 2022-06-12 03:41:35.436571
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    x = importlib.import_module('typed_ast.ast3')
    node = x.parse('x=1')
    t = Python2FutureTransformer(target=(2, 7))
    res = t.visit(node)
    assert 'from __future__ import absolute_import' in str(res)

# Generated at 2022-06-12 03:41:44.097596
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import generate_dummy_code_with_target

    code = generate_dummy_code_with_target(target=(2, 7))
    module_node = ast.parse(code)
    visitor = Python2FutureTransformer()
    module_node = visitor.visit(module_node)
    assert visitor._tree_changed

    # check if signature of function is not changed
    function_node = module_node.body[2]
    sig = function_node.args
    assert sig.args[0].arg == 'i'
    assert sig.args[1].arg == 'j'
    assert sig.vararg.arg == 'args'



# Generated at 2022-06-12 03:41:51.648225
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    tree = ast.parse('pass')
    transformed_tree = Python2FutureTransformer().visit(tree)
    expected_tree = ast.parse('from __future__ import absolute_import\nfrom __future__ import division\n'
                              'from __future__ import print_function\nfrom __future__ import unicode_literals\n\npass')
    assert isinstance(transformed_tree, ast.Module)
    # since the trees are not identical, have to compare them as strings
    assert astor.to_source(transformed_tree) == astor.to_source(expected_tree)



# Generated at 2022-06-12 03:41:52.822920
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer is not None


# Generated at 2022-06-12 03:42:01.741802
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer is not None

# Generated at 2022-06-12 03:42:08.766545
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    """It prepends module with from __future__ import absolute_import,
    from __future__ import division, from __future__ import print_function,
    from __future__ import unicode_literals
    """
    src = 'print("hello")'
    mod = ast.parse(src)
    transformed = Python2FutureTransformer().visit(mod)

# Generated at 2022-06-12 03:42:13.195720
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils import run_on_lines
    source = 'def f(): pass'
    assert run_on_lines(source, Python2FutureTransformer) == 'from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n\ndef f(): pass'

# Generated at 2022-06-12 03:42:16.684949
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from_py2 = "def foo(): pass"

# Generated at 2022-06-12 03:42:22.941269
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.tree_builder import build_ast_tree

    code = '''
        pass
    '''
    parsed_tree = build_ast_tree(code, (2, 7))
    Python2FutureTransformer().visit(parsed_tree)

    assert str(parsed_tree) == '''
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        pass
    '''

# Generated at 2022-06-12 03:42:23.864313
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-12 03:42:25.064226
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()
    assert t


# Generated at 2022-06-12 03:42:27.108485
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from .Python2FutureTransformer import Python2FutureTransformer

    assert Python2FutureTransformer.target == (2, 7)

# Generated at 2022-06-12 03:42:34.177384
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    """Unit test for method visit_Module of class Python2FutureTransformer
    """
    from ..test_utils.test_ast_transformer import compare_trees
    from .python2_test_helpers import assert_correct_ast

    source = """print(next(list(list())), next(list(list())))"""
    module = assert_correct_ast(source)
    expected_module = assert_correct_ast(f"""
{imports}
print(next(list(list())), next(list(list())))""")
    compare_trees(Python2FutureTransformer().visit(module), expected_module)

# Generated at 2022-06-12 03:42:41.208477
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..misc import remove_files
    from ..parsing import parse_module
    from ..writing import ModuleWriter
    import os
    import tempfile
    
    src = b"""\
    # This is a sample python file
    
    
    
    
    def hello() -> None:
        print('hello')""".decode('utf-8')
    src_path = tempfile.mkstemp()[1]
    with open(src_path, 'w') as f:
        f.write(src)
    tree = parse_module(src_path)
    transformer = Python2FutureTransformer()
    tree = transformer.visit(tree)
    assert transformer._tree_changed
    dest_path = src_path + '.dest'
    writer = ModuleWriter(dest_path)
    writer.visit(tree)


# Generated at 2022-06-12 03:42:58.918082
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.get_tree_changed() is False
    assert Python2FutureTransformer.get_lineno() == -1
    assert Python2FutureTransformer.get_col_offset() == -1
    Python2FutureTransformer.reset()
    assert Python2FutureTransformer.get_tree_changed() is False
    assert Python2FutureTransformer.get_lineno() == -1
    assert Python2FutureTransformer.get_col_offset() == -1

# Generated at 2022-06-12 03:43:08.142441
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.node_tools import get_source
    from ..utils.source_tools import assert_source_equal
    module_name = '_test_imports_2'
    script = """
    import os
    def f():
        print('hello')
    """
    expected_script = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    import os
    def f():
        print('hello')
    """
    module = ast.parse(script)
    Python2FutureTransformer().visit(module)
    assert_source_equal(get_source(module), expected_script)

# Generated at 2022-06-12 03:43:12.803177
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()

    tree = ast.parse("from __future__ import print_function\nx = 8")
    transformer.visit(tree)

    assert str(tree) == "from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\nfrom __future__ import print_function\nx = 8"



# Generated at 2022-06-12 03:43:22.481265
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_module, make_body_node, make_import_module, make_print_node
    from ..utils.visitor import NodeVisitor
    from ..utils.messages import Message

    class FindModule(NodeVisitor):
        def __init__(self):
            self.module_node = None

        def visit_Module(self, node):
            self.module_node = node

    class FindFuture(NodeVisitor):
        def __init__(self):
            self.future_node = None

        def visit_ImportFrom(self, node):
            if node.module == '__future__':
                self.future_node = node

    visitor = Python2FutureTransformer()
    assert visitor.get_tree_changed() is False


# Generated at 2022-06-12 03:43:24.053244
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import sys
    module_name = sys.modules[__name__].__file__
    Python2FutureTransformer(module_name)

# Generated at 2022-06-12 03:43:35.227255
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # type: () -> None
    code_in = """
    # Hello Gherkin
    import os
    import sys
    
    print('Hello World')
    
    
    
    
    
    
    
    """
    code_out = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    # Hello Gherkin
    import os
    import sys
    
    print('Hello World')
    
    
    
    
    
    
    
    """
    py2 = Python2FutureTransformer(code_in, (2, 7))
    py2.transform()
    print(py2.target_code)
    assert py2.target_code == code_out
    #assert False

# Generated at 2022-06-12 03:43:36.398538
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert isinstance(Python2FutureTransformer(), BaseNodeTransformer)


# Generated at 2022-06-12 03:43:38.240962
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert hasattr(Python2FutureTransformer, 'target')
    assert callable(Python2FutureTransformer.visit_Module)

# Generated at 2022-06-12 03:43:47.553312
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from . import build_ast

    ast_tree = build_ast("# coding: utf-8\nx = 3.14159\n")
    node = ast_tree.body[0]
    assert isinstance(node, ast.Assign)
    transformer = Python2FutureTransformer()
    transformer.visit(ast_tree)
    assert transformer._tree_changed
    result = ast.dump(ast_tree)

# Generated at 2022-06-12 03:43:55.456488
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Unit test for Python2FutureTransformer.
    """
    # pylint: disable=too-many-locals,unused-argument
    from .samples import code_sample_2, code_ast_2

    tree = ast.parse(code_sample_2)
    ftransformer = Python2FutureTransformer()
    tree1 = ftransformer.visit(tree)

    # Compare with sample ast
    assert ast.dump(tree1) == ast.dump(code_ast_2)
    # pylint: enable=too-many-locals,unused-argument

# Generated at 2022-06-12 03:44:25.331774
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer is not None


# Generated at 2022-06-12 03:44:31.200856
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.fixtures import make_dummy_tree
    dummy_tree = make_dummy_tree()
    dummy_tree_copy = copy.deepcopy(dummy_tree)
    t = Python2FutureTransformer(dummy_tree)
    assert dummy_tree is t.tree
    assert dummy_tree_copy is not t.tree
    # assert that tree was not modified after creation of instance
    # of class Python2FutureTransformer
    assert dummy_tree == dummy_tree_copy

# Generated at 2022-06-12 03:44:32.938279
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a = Python2FutureTransformer()
    # The class should be initialized successfully
    assert a is not None

# Generated at 2022-06-12 03:44:37.656382
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    tree = ast.parse('''#with_future
        a = 2
    ''')

    # Execute the constructor
    transformer = Python2FutureTransformer()
    # Execute the visit method, it modifies the AST
    transformer.visit(tree)

    # Each transformer should leave the tree unchanged
    assert transformer.tree_changed is True



# Generated at 2022-06-12 03:44:42.558661
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    node = ast.parse("import math")
    assert Python2FutureTransformer.is_target(node)
    Python2FutureTransformer().visit(node)
    assert str(node) == "from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\nimport math"



# Generated at 2022-06-12 03:44:44.196195
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # Transformer successfully created
    transformer = Python2FutureTransformer()
    assert transformer is not None


# Generated at 2022-06-12 03:44:50.917141
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    tree = ast.parse("import sys")
    transformer = Python2FutureTransformer()
    actual = transformer.visit(tree)
    assert isinstance(actual, ast.Module)
    assert transformer._tree_changed is True
    assert len(actual.body) == 5
    assert isinstance(actual.body[0], ast.ImportFrom)
    assert isinstance(actual.body[1], ast.ImportFrom)
    assert isinstance(actual.body[2], ast.ImportFrom)
    assert isinstance(actual.body[3], ast.ImportFrom)
    assert isinstance(actual.body[4], ast.Import)

# Generated at 2022-06-12 03:44:52.419666
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    trans = Python2FutureTransformer()
    assert trans.target == (2, 7)
    assert trans.source is None

# Generated at 2022-06-12 03:44:54.981132
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.target == (2, 7), (
        'Python2FutureTransformer.target should be (2, 7)')
    Python2FutureTransformer()
    

# Generated at 2022-06-12 03:44:58.300212
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    assert astunparse.unparse(Python2FutureTransformer().visit(ast.parse('pass'))) == \
        'from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\npass'

# Generated at 2022-06-12 03:46:08.238547
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor

    class DummyFutureTransformer(BaseNodeTransformer):
        pass

    dft = DummyFutureTransformer()
    assert astor.to_source(dft.visit(ast.parse('pass'))) == 'pass'
    assert astor.to_source(dft.visit(ast.parse('pass'))) == 'pass'

    class DummyFutureTransformer2(BaseNodeTransformer):
        target = (2, 5)

    dft2 = DummyFutureTransformer2()
    assert astor.to_source(dft2.visit(ast.parse('pass'))) == 'pass'
    assert astor.to_source(dft2.visit(ast.parse('pass'))) == 'pass'

    dft3 = Python2FutureTransformer()
    assert astor.to_

# Generated at 2022-06-12 03:46:14.304608
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import ast
    import astunparse
    import sys
    node = ast.parse('string = "hello"')
    Python2FutureTransformer(sys.version_info).visit(node)
    actual = astunparse.unparse(node)
    expected = "from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n\nstring = \"hello\""
    assert actual == expected

# Generated at 2022-06-12 03:46:15.588828
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer('').target == (2, 7)

# Generated at 2022-06-12 03:46:22.065138
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .utils import round_trip_visit

    source = '\n'.join([
        "q = 1"
    ])

    expected = '\n'.join([
        "from __future__ import absolute_import",
        "from __future__ import division",
        "from __future__ import print_function",
        "from __future__ import unicode_literals",
        "",
        "q = 1"
    ])

    module, = round_trip_visit(ast.parse(source), Python2FutureTransformer)
    assert expected == astor.to_source(module)

# Generated at 2022-06-12 03:46:25.818771
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # Check that Python2FutureTransformer is python 2 and 7 compatable
    assert Python2FutureTransformer().python_versions == (2, 7)
    # Check that the instance is of type Python2FutureTransformer
    assert isinstance(Python2FutureTransformer(), Python2FutureTransformer)


# Generated at 2022-06-12 03:46:26.359922
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-12 03:46:33.567636
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from nbgae.snippets.future import imports
    from typed_ast import ast3 as ast
    from nbgae.transformers.python2future import Python2FutureTransformer
    
    tree = ast.parse("""
    class Foo:
        """ + imports.get_body(future='__future__') +
    """
        def bar(self, x: object, y: object) -> str:
            return str(x) + str(y)
    """)

    transformer = Python2FutureTransformer()
    transformer.visit(tree)


# Generated at 2022-06-12 03:46:35.380741
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.tree is None
    assert transformer._tree_changed is False


# Generated at 2022-06-12 03:46:37.965741
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Unit test for constructor of class Python2FutureTransformer
    """
    assert Python2FutureTransformer is not None


# Generated at 2022-06-12 03:46:41.743309
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    trans = Python2FutureTransformer.from_string(code='')
    trans.visit(trans.module)
    assert trans.is_changed()
    assert trans.module.body[0].names[0].name == 'absolute_import'
    assert trans.module.body[0].names[3].name == 'unicode_literals'

# Generated at 2022-06-12 03:49:17.336009
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Unit test for constructor of class Python2FutureTransformer"""
    obj = Python2FutureTransformer()
    assert obj._tree_changed == False


# Generated at 2022-06-12 03:49:25.321789
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    mod = ast.parse('def foo():\n    pass')
    mod = Python2FutureTransformer().visit(mod)  # type: ignore

# Generated at 2022-06-12 03:49:33.484689
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.parse import parse
    from .python_to_python import PythonToPythonTransformer
    from .remove_head_comments import RemoveHeadCommentsTransformer
    from .add_head_comments import AddHeadCommentsTransformer


# Generated at 2022-06-12 03:49:34.305821
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-12 03:49:35.787411
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)


# Generated at 2022-06-12 03:49:37.049740
# Unit test for constructor of class Python2FutureTransformer

# Generated at 2022-06-12 03:49:45.515922
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import parse, ast3