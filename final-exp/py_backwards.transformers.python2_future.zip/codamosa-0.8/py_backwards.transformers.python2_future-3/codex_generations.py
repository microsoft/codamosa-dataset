

# Generated at 2022-06-12 03:39:53.871129
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ...utils.source import source
    from ...utils.tree import tree, code  # type: ignore

    source = source(imports)
    tree = tree(source)
    py2ft = Python2FutureTransformer()
    new_tree = py2ft.visit(tree)  # type: ignore
    assert new_tree.body[0].body[0].value.value == "__future__"  # type: ignore
    assert code(new_tree) == source

# Generated at 2022-06-12 03:40:02.665100
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():

    s = '''
src = '''
    node = ast.parse(s)
    visitor = Python2FutureTransformer()
    node = visitor.visit(node)
    node = ast.fix_missing_locations(node)
    assert ast.dump(node) == '''
Module(body=[
    ImportFrom(
        module='future',
        names=[
            alias(name='absolute_import', asname=None),
            alias(name='division', asname=None),
            alias(name='print_function', asname=None),
            alias(name='unicode_literals', asname=None)],
        level=0),
])'''

# Generated at 2022-06-12 03:40:09.166670
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    from ..definitions import definitions
    from ..utils.expression import parse_ast
    from ..utils.module import module_info

    transformer = Python2FutureTransformer()
    tree = parse_ast(definitions.all_definitions)
    transformer.visit(tree)
    assert module_info(tree, '__future__') == ('absolute_import', 'division', 'print_function', 'unicode_literals')
    assert module_info(tree, 'typed_ast') == ()
    transformer.visit(tree)
    assert module_info(tree, '__future__') == ('absolute_import', 'division', 'print_function', 'unicode_literals')
    assert module_info(tree, 'typed_ast') == ()

# Generated at 2022-06-12 03:40:16.565943
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from .utils import _get_symbol

    transformer = Python2FutureTransformer()
    expected_code = "from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\nfrom __future__ import (absolute_import,\n                        division, print_function, unicode_literals)\n"
    parsed = ast.parse(expected_code)
    transformer.visit(parsed)
    assert _get_symbol(transformer._module).get_code() == expected_code



# Generated at 2022-06-12 03:40:25.783438
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .snippets import CLASS_DEFINITION
    from .snippets import empty_module
    from .snippets import function_definition
    from .snippets import module_str
    from .snippets import imports
    from .snippets import print_function

    # Test with empty module
    module_node = empty_module.get_ast()
    modification = Python2FutureTransformer().visit(module_node)
    assert module_str(modification).strip() == imports.get_str(future='__future__')

    # Test with empty module with print_function
    module_node = empty_module.get_ast()
    modification = Python2FutureTransformer().visit(module_node)
    module_node = print

# Generated at 2022-06-12 03:40:35.860454
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import ast
    from ..utils.ast_builder import ASTBuilderMixin

    c = ASTBuilderMixin()

    node = c.module(
        c.empty(),
        c.empty(),
        c.empty(),
        c.empty(),
        c.class_('Sample'),
        c.func('sample', suite=[c.empty()]),
    )

    # Test imports()
    # Test visit_Module()

    transformer = Python2FutureTransformer()
    tree = transformer.visit(node)

    assert isinstance(tree, ast.Module)

    (first, last) = (tree.body[0], tree.body[-1])
    assert isinstance(first, ast.ImportFrom)
    assert first.module == '__future__'
    assert first.names[0].name == 'absolute_import'


# Generated at 2022-06-12 03:40:37.560170
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.test_fixture import check_transformer
    check_transformer(Python2FutureTransformer)

# Generated at 2022-06-12 03:40:42.092347
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    tree = ast.parse("print(1/2)")
    node = Python2FutureTransformer()
    node.visit(tree)
    assert str(tree) == "from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\nprint(1/2)"

# Generated at 2022-06-12 03:40:46.402336
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    source = 'a = 1 + 1'
    expected = 'from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\na = 1 + 1'
    tree = ast.parse(source)  # type: ignore
    t = Python2FutureTransformer()
    new_tree = t.visit(tree)
    assert astor.to_source(new_tree) == expected

# Generated at 2022-06-12 03:40:47.618892
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import ast
    Python2FutureTransformer(ast.parse('x = 1'))

# Generated at 2022-06-12 03:40:55.549047
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = ast.parse("1")
    module_2 = Python2FutureTransformer().visit(module)
    assert ast.dump(module) != ast.dump(module_2)  # The AST tree changed
    assert "from __future__ import absolute_import" in ast.dump(module_2)
    assert "from __future__ import division" in ast.dump(module_2)
    assert "from __future__ import print_function" in ast.dump(module_2)
    assert "from __future__ import unicode_literals" in ast.dump(module_2)

# Generated at 2022-06-12 03:41:05.655818
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import os
    import astor
    from astor.code_gen import to_source
    from ..utils.read import read_file
    from .python2 import Python2Transformer

    transformer = Python2Transformer()
    filepath = os.path.join(os.path.dirname(__file__), '../../', 'examples', 'amuse.py')
    source, mod = read_file(filepath, transformer)

    transformer = Python2FutureTransformer()
    mod = transformer.visit(mod)

    print(to_source(mod, indent_with=' '*4))
    assert transformer._tree_changed
    assert astor.to_source(mod) == to_source(mod, indent_with=' '*4)
    assert transformer.targets_met()

# Generated at 2022-06-12 03:41:10.931879
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    tree = ast.parse('a = "A"\nprint(a)')  # type: ignore
    transformer = Python2FutureTransformer()
    transformed_tree = transformer.visit(tree)
    if transformer._tree_changed:
        code = compile(transformed_tree, '<>', 'exec')  # type: ignore
        print(code)
        exec(code)

# Generated at 2022-06-12 03:41:12.639380
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass
#     transformer = Python2FutureTransformer(None)
#     assert transformer._tree_changed == False

# Generated at 2022-06-12 03:41:21.019779
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    """Test for method visit_Module of class Python2FutureTransformer"""
    from .base import BaseNodeTransformer, ast_equal
    from typed_ast import ast3 as ast, parse
    from textwrap import dedent

    src = dedent('''
        import sys
        import os
    ''')
    expected = dedent('''
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        import sys
        import os
    ''')
    node = parse(src, mode='exec')
    tree = Python2FutureTransformer().visit(node)
    assert ast_equal(expected, tree)

# Generated at 2022-06-12 03:41:26.428992
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = ast.parse('print("Hello world!")')
    transformer = Python2FutureTransformer(module)
    transformer.visit(module)
    assert transformer._tree_changed
    assert ast.dump(module) == textwrap.dedent('''\
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals


        print("Hello world!")
        ''')

# Generated at 2022-06-12 03:41:35.368439
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.sample_snippets import sample_snippets
    sample_snippet = sample_snippets[2]

    expected_ast = imports.ast() + sample_snippet.original_ast.body  # type: ignore
    expected_source = imports.format(future='__future__') + sample_snippet.original_source  # type: ignore

    assert expected_source == Python2FutureTransformer().visit(sample_snippet.original_ast).as_string()
    assert expected_ast == Python2FutureTransformer().visit(sample_snippet.original_ast).body
    assert sample_snippet.original_ast.__class__ == Python2FutureTransformer().visit(sample_snippet.original_ast).__class__

# Generated at 2022-06-12 03:41:37.969624
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast

    result = Python2FutureTransformer().visit_Module(ast.Module(body=[]))
    assert len(result.body) == 4

# Generated at 2022-06-12 03:41:43.907044
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import parse
    
    before = """
a = 1 + 2
    """
    after = """
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
    
a = 1 + 2
    """

    expected = Python2FutureTransformer().visit(parse(before))
    result = parse(after)
    assert ast.dump(expected) == ast.dump(result)



# Generated at 2022-06-12 03:41:53.058564
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():   # pragma: no cover
    from ..transforms.future import Python2FutureTransformer
    from ..transforms.unpacking import Python2ParameterUnpackingTransformer
    from .test_unpacking import test_source1, test_source2
        
    t = SNAKEOIL_TRANSFORMERS.get(Python2FutureTransformer, None)
    assert t is not None
    assert t.target == Python2FutureTransformer.target
    
    t = SNAKEOIL_TRANSFORMERS.get(Python2ParameterUnpackingTransformer, None)
    assert t is not None
    assert t.target == Python2ParameterUnpackingTransformer.target
    assert t.name == Python2ParameterUnpackingTransformer.name
    
    tree = ast.parse(test_source1)
    print(ast.dump(tree))
    


# Generated at 2022-06-12 03:41:57.577164
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from .. import Transformation
    import astor
    tr = Transformation(Python2FutureTransformer())

# Generated at 2022-06-12 03:42:06.496266
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .utils import assert_transformation

    assert_transformation(Python2FutureTransformer, 'print(10)')

    assert_transformation(Python2FutureTransformer, """
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

print(10)
""", """
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
print(10)
""")



# Generated at 2022-06-12 03:42:13.664675
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .base import BaseNodeTest

    class Test(BaseNodeTest):
        target = Python2FutureTransformer.target
        transformer = Python2FutureTransformer
        before = 'a = 1'
        after = 'from __future__ import absolute_import\n' \
                'from __future__ import division\n' \
                'from __future__ import print_function\n' \
                'from __future__ import unicode_literals\n' \
                '\n' \
                'a = 1'

    test = Test()
    test.test_visit_Module()

# Generated at 2022-06-12 03:42:14.585934
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor

# Generated at 2022-06-12 03:42:15.563160
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-12 03:42:17.473940
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Unit test for constructor of class Python2FutureTransformer"""
    Python2FutureTransformer()


# Generated at 2022-06-12 03:42:25.307950
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import TypeIgnore
    module = ast.parse('# -*- coding: utf-8 -*-\ndef f(): pass')
    module = Python2FutureTransformer().visit(module)
    assert isinstance(module, ast.Module)
    assert len(module.body) == 5
    assert isinstance(module.body[0], ast.ImportFrom)
    assert isinstance(module.body[1], ast.ImportFrom)
    assert isinstance(module.body[2], ast.ImportFrom)
    assert isinstance(module.body[3], ast.ImportFrom)
    assert isinstance(module.body[4], ast.FunctionDef)

# Generated at 2022-06-12 03:42:32.223701
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    class Test(BaseNodeTransformer):
        def visit_call(self, node: ast.Call) -> ast.Module:
            return self.generic_visit(node)
    tree = ast.parse("x = 1")
    tree = Test().visit(tree)
    result = ast.dump(tree)
    assert result == 'Module(body=[Assign(lineno=1, col_offset=0, targets=[Name(lineno=1, col_offset=0, id=\'x\', ctx=Store())], value=Num(lineno=1, col_offset=4, n=1))])'

# Generated at 2022-06-12 03:42:40.415266
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    test = """x = 4"""
    matrix = [
        {'code': test, 'result': "from __future__ import absolute_import ;\nfrom __future__ import division ;\nfrom __future__ import print_function ;\nfrom __future__ import unicode_literals ;\nx = 4"},
        {'code': test, 'result': "from __future__ import absolute_import \nfrom __future__ import division \nfrom __future__ import print_function \nfrom __future__ import unicode_literals \nx = 4"},
        {'code': test, 'result': "from __future__ import absolute_import \nfrom __future__ import division \nfrom __future__ import print_function \nfrom __future__ import unicode_literals \nx = 4"},
    ]

# Generated at 2022-06-12 03:42:42.675925
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    p = Python2FutureTransformer()
    assert isinstance(p, Python2FutureTransformer)

# Generated at 2022-06-12 03:42:48.343380
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    p2ft = Python2FutureTransformer()
    assert p2ft is not None
    assert p2ft._tree_changed == False

# Generated at 2022-06-12 03:42:49.295963
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer().target == (2, 7)

# Generated at 2022-06-12 03:42:51.430607
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Unit test for constructor of class Python2FutureTransformer."""
    future = Python2FutureTransformer()
    assert future is not None

# Generated at 2022-06-12 03:42:57.103390
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast

    tree = ast.parse(
        '''
        import sys
        import os
        import non_existing
        '''
    )
    Python2FutureTransformer().visit(tree)
    assert ast.dump(tree) == imports.dump() + '''Module(body=[Import(names=[alias(name='sys', asname=None)]), Import(names=[alias(name='os', asname=None)]), Import(names=[alias(name='non_existing', asname=None)])])'''

# Generated at 2022-06-12 03:43:06.076878
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # test that Python2FutureTransformer.visit_Module prepends module with:
    #     from __future__ import absolute_import
    #     from __future__ import division
    #     from __future__ import print_function
    #     from __future__ import unicode_literals

    # Arrange #
    node = ast.parse("a = 1", mode='eval')
    node = ast.fix_missing_locations(node)

    expected_node = ast.parse("from __future__ import absolute_import\n"
                              "from __future__ import division\n"
                              "from __future__ import print_function\n"
                              "from __future__ import unicode_literals\n"
                              "\na = 1", mode='eval')

# Generated at 2022-06-12 03:43:14.483130
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    tree = ast.parse(
        """
if True:
    print("test")
"""
    )
    transformer = Python2FutureTransformer()
    tree = transformer.visit(tree)

# Generated at 2022-06-12 03:43:23.798266
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor
    code = """
if __name__ == '__main__':
    print(2 / 3) # should be 0.666..
    print(True) # should be True
    print('É') # should be É
    print('Æ') # should be Æ (due to `from __future__ import unicode_literals`)
    """
    tree = ast.parse(code)
    Python2FutureTransformer().visit(tree)  # type: ignore
    result = astor.to_source(tree).strip()

# Generated at 2022-06-12 03:43:35.045953
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    import astor
    from typed_ast.ast3 import Module, Assign, Num, Call, Name
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from ..utils.snippet import snippet
    from ..utils.unparse import Unparser
    from ..utils.unparse import IndentationMixin
    t = Python2FutureTransformer()
    u = Unparser()
    root = Module(body=[Assign(targets=[Name(id='a', ctx=ast.Store())], value=Num(n=1))])
    root = t.visit(root)
    # astor.dump(root)
    # print(u.visit(root))
    # t.visit(ast.parse(imports.get_source(future

# Generated at 2022-06-12 03:43:43.918438
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast.ast3 import Module, Name, Load, ImportFrom
    from typed_ast.ast3 import parse, fix_missing_locations
    from ..transformers import add_future_import

    src = """
!@#$%^&*()_+=-`~1234567890,./<>?;':"{}|[]\\
name = ''       # type: str
"""
    tree = parse(src)
    fix_missing_locations(tree)
    transformer = Python2FutureTransformer()
    transformer.visit(tree)
    add_future_import(tree)


# Generated at 2022-06-12 03:43:51.013827
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..testing.utils import check_visitor
    Python2FutureTransformer.set_context(AST_FUTURE)
    check_visitor(Python2FutureTransformer, """
    (Module
        (Expr
            (Str "hello"))
    )
    """, """
    (Module
        (ImportFrom future absolute_import)
        (ImportFrom future division)
        (ImportFrom future print_function)
        (ImportFrom future unicode_literals)
        (Expr
            (Str "hello"))
    )
    """)


# Generated at 2022-06-12 03:44:01.683385
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    code = ast.parse(imports.get_source(future='__future__')+'pass\n')
    visitor = Python2FutureTransformer()
    visitor.visit(code)
    assert ast.dump(code, annotate_fields=False) == ast.dump(ast.parse('pass\n'), annotate_fields=False)

# Generated at 2022-06-12 03:44:08.460676
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # Arrange
    file = """
print('hello from python 2')
for x in range(0, 10):
    print(x)
"""
    tree = ast.parse(file)

    # Act
    Python2FutureTransformer().visit(tree)

    # Assert
    expected = """from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
print('hello from python 2')
for x in range(0, 10):
    print(x)
"""
    actual = ast.unparse(tree)

    assert expected == actual

# Generated at 2022-06-12 03:44:17.069716
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast.ast3 import parse
    from typed_ast.ast3 import Module
    from typed_ast.ast3 import Name
    from typed_ast.ast3 import Store
    from typed_ast.ast3 import Assign
    from typed_ast.ast3 import Str
    from typed_ast.ast3 import Call
    from typed_ast.ast3 import Attribute
    assert parse('print("Hello World!")') == Python2FutureTransformer().visit(parse('print("Hello World!")'))

# Generated at 2022-06-12 03:44:19.108263
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from .fixtures import Python2FutureTransformer_test
    from .. import transform
    Python2FutureTransformer_test(transform, [Python2FutureTransformer])


# Generated at 2022-06-12 03:44:24.825715
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .test_utils import make_test_module_tree
    from .test_utils import run_node_transformer_test
    from .test_utils import test_tree as old_tree
    from .test_utils import expected_tree as new_tree

    transformer = Python2FutureTransformer()
    tree = make_test_module_tree(old_tree)
    new_tree = make_test_module_tree(new_tree)
    run_node_transformer_test(transformer, tree, new_tree)

# Generated at 2022-06-12 03:44:25.331882
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass

# Generated at 2022-06-12 03:44:34.781369
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    from ast_inspectors import Python2FutureTransformer
    actual = Python2FutureTransformer()(ast.Module(
        body=[ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())],
                          value=ast.Num(n=10))]
    ))

# Generated at 2022-06-12 03:44:35.460529
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass

# Generated at 2022-06-12 03:44:40.455431
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.test_utils import assert_node_equals
    from ..utils.test_utils import assert_patch_equals

    t = Python2FutureTransformer()
    assert_node_equals(imports.get_node(future='__future__'), t.module)
    assert_patch_equals(imports.get_patch(future='__future__'), t)


# Generated at 2022-06-12 03:44:49.116043
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Module
    from typed_ast.ast3 import Expr
    from typed_ast.ast3 import Name
    from typed_ast.ast3 import Load
    from typed_ast.ast3 import Str
    from typed_ast.ast3 import Call
    from typed_ast.ast3 import Attribute
    from typed_ast.ast3 import arguments
    from typed_ast.ast3 import FunctionDef
    from typed_ast.ast3 import arguments
    from typed_ast.ast3 import Name
    from typed_ast.ast3 import Store
    from typed_ast.ast3 import FunctionDef
    from typed_ast.ast3 import Return
    from typed_ast.ast3 import Num
    from typed_ast.ast3 import Assign

# Generated at 2022-06-12 03:45:13.387412
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast

# Generated at 2022-06-12 03:45:15.840443
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    trans = Python2FutureTransformer()
    assert trans.target == (2, 7)
    assert trans._tree_changed == False
    assert trans.import_future == False

# Generated at 2022-06-12 03:45:16.747626
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    x = Python2FutureTransformer()


# Generated at 2022-06-12 03:45:17.608597
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    x = Python2FutureTransformer()
    assert x is not None

# Generated at 2022-06-12 03:45:24.834807
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import ast
    import astor
    m = ast.Module()
    m.body = [ast.Import(names=[ast.alias(name='collections', asname=None)])]
    transformer = Python2FutureTransformer()
    m = transformer.visit(m)
    code = astor.to_source(m)
    print(code)
    expected = """\
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

import collections"""
    assert code == expected

# Generated at 2022-06-12 03:45:29.714205
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor  # type: ignore
    
    source = 'print 2 + 2'
    expected = "from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n\nprint 2 + 2"
    tree = astor.parse_file(io.BytesIO(source.encode()))  # type: ignore
    
    transformer = Python2FutureTransformer()
    transformer.visit(tree)
    
    result = astor.to_source(tree)
    assert result == expected

# Generated at 2022-06-12 03:45:31.959097
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-12 03:45:34.954239
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    mod = ast.parse('print(1)')
    res = Python2FutureTransformer().visit(mod)
    assert res.body[0].value.unicode_literals == True, res.body[0].value.unicode_literals

# Generated at 2022-06-12 03:45:36.035159
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-12 03:45:46.571778
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    # The visit methods don't return anything meaningful
    assert transformer.visit_Module(ast.parse(dedent('''
        import sys
        
        print('Hello, world!')
    '''))) == None
    # Check that the source code was changed:
    assert transformer.changed_source == dedent('''
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        
        import sys
        
        print('Hello, world!')
    ''')
    # Check that the AST was changed:
    tree = ast.parse(dedent('''
        import sys
        
        print('Hello, world!')
    '''))

# Generated at 2022-06-12 03:46:28.359597
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transform = Python2FutureTransformer()
    assert isinstance(transform, BaseNodeTransformer)
    assert transform.target == (2, 7)
    
    source = """
    import os
    import sys

    class Node:
        pass
    """
    expected = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    import os
    import sys

    class Node:
        pass
    """
    root_node = ast.parse(source)
    transformed_root_node = transform.transform(root_node)
    transformed_source = prettier.format_file(transformed_root_node)
    assert transformed_source == expected

# Generated at 2022-06-12 03:46:37.717932
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-12 03:46:39.886846
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse('x = "text"\nprint(x)')
    Python2FutureTransformer().visit(node)

# Generated at 2022-06-12 03:46:42.441830
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # out = Python2FutureTransformer()
    # We can't test this class
    # since it prepends the module
    # which is the tree root,
    # and there is no way to create
    # an instance of it.
    pass

# Generated at 2022-06-12 03:46:49.373183
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import sys
    from ..testing_utils import assert_with_message

    t = Python2FutureTransformer()
    m = ast.Module(body=[])
    new_module = t.visit_Module(m)
    t.leave(m)
    assert str(new_module) == (
        "from __future__ import absolute_import\n"
        "from __future__ import division\n"
        "from __future__ import print_function\n"
        "from __future__ import unicode_literals\n"
        ""
    )
    assert t.tree_changed


# Generated at 2022-06-12 03:46:51.344057
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    x = Python2FutureTransformer(target=(2, 7))
    assert isinstance(x, Python2FutureTransformer)

# Generated at 2022-06-12 03:46:58.707783
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_module_with_future
    module = make_module_with_future('division', target=(2, 7))
    assert len(module.body) == 1
    assert module.body[0].targets[0].id == 'division'
    Python2FutureTransformer().visit(module)
    assert len(module.body) == 7
    assert [node.value.func.id for node in module.body[:4]] == ['absolute_import', 'division', 'print_function', 'unicode_literals']
    assert module.body[4].targets[0].id == 'division'

# Generated at 2022-06-12 03:47:05.624182
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3
    from typed_ast import ast27

    from ..transform import Python2FutureTransformer
    from ..transform import Python2ModuleDocstringTransformer
    from ..transform import Python2FunctionDocstringTransformer
    from ..utils.context import Context

    c = Context.from_code('''
    "Docstring"
    def foo():
        """Docstring"""
        pass
    ''')

    a = Python2ModuleDocstringTransformer(c).visit(Python2FutureTransformer(c).visit(c.tree))
    b = ast3.parse(c.code)
    ast27.fix_missing_locations(b)

    assert ast3.dump(a) == ast27.dump(b)

# Generated at 2022-06-12 03:47:14.438482
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from textwrap import dedent
    # test_input
    input = dedent("""\
    def func():
        pass
    """)

    # test_output
    output = dedent("""\
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    def func():
        pass
    """)
    # test_ast
    expected_ast = ast.parse(output)

    # test_apply
    module = ast.parse(input)
    Python2FutureTransformer().visit(module)

    # test_assert
    assert ast.dump(module) == ast.dump(expected_ast)

# Generated at 2022-06-12 03:47:23.026382
# Unit test for constructor of class Python2FutureTransformer

# Generated at 2022-06-12 03:48:50.733089
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor
    from .test_utils import roundtrip
    with roundtrip(Python2FutureTransformer) as transformer:
        code = "print('hello')"
        tree = astor.parse_file(code)
        tree = transformer.visit(tree)
        assert code != astor.to_source(tree).strip()
        assert astor.to_source(tree).strip() == '''\
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

print('hello')'''

# Generated at 2022-06-12 03:48:55.314714
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor
    tree = astor.parse_file(__file__)
    tree = Python2FutureTransformer().visit(tree)
    python_code = astor.to_source(tree)
    print(python_code)

if __name__ == "__main__":
    test_Python2FutureTransformer()

# Generated at 2022-06-12 03:49:02.935517
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast

    # Arrange
    node = ast.Module([
        ast.Import(names=[ast.alias(name='typed_ast', asname=None)]),
        ast.Import(names=[ast.alias(name='typing', asname=None)])
    ])
    expected_ast = ast.Module([
        ast.Import(names=[ast.alias(name='typed_ast', asname=None)]),
        ast.Import(names=[ast.alias(name='typing', asname=None)])
    ])
    sut = Python2FutureTransformer()

    # Act
    result = sut.visit(node)

    # Assert
    assert ast.dump(expected_ast) == ast.dump(result)

# Generated at 2022-06-12 03:49:10.796591
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor  # type: ignore
    import gast  # type: ignore
    node = gast.parse(
        """
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        
        import functools

        @functools.lru_cache()
        def test():
            return 'foo'
        """
    )
    t = Python2FutureTransformer()
    t.visit(node)
    assert astor.to_source(node) == (
        """
        import functools

        @functools.lru_cache()
        def test():
            return 'foo'
        """
    )

# Generated at 2022-06-12 03:49:18.583856
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import parse
    from ..utils.test_utils import assert_ast

    python_code = """\
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
print("already have the __future__ stuff")
"""
    target_ast = parse(python_code)
    pft = Python2FutureTransformer()
    pft.visit(parse(''))
    trans_ast = pft.visit(parse(''))
    assert_ast(trans_ast, target_ast)

# Generated at 2022-06-12 03:49:25.970282
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3
    # Test 1: empty node
    node = ast3.parse('#')
    node = Python2FutureTransformer().visit(node)

# Generated at 2022-06-12 03:49:27.267866
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer is not None

# Generated at 2022-06-12 03:49:30.666283
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from . import test_support
    from ..utils.visitor import Visitor
    test_support.run_doctest(Future, globs=globals())
    test_support.run_doctest(Python2FutureTransformer, globs=globals())
    doctest_visitor(Visitor)

# Generated at 2022-06-12 03:49:33.863684
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    mod = ast.parse('mod = 2')
    mod2 = Python2FutureTransformer().visit(mod)
    assert mod2 is not mod
    import_test = mod2.body[0].value.targets[0].id
    assert import_test == "__future__"


# Generated at 2022-06-12 03:49:38.958269
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import py2to3 as py23
    @snippet
    def module():
        f = Foo()
    source_ast, source_code = py23.parse_snippet(module)
    transformer = py23.Python2FutureTransformer()
    transformer.visit(source_ast)
    print(ast.dump(source_ast))
    assert transformer._tree_changed is True
    module_stmts = module.get_module_body()
    module_stmts.pop(0)
    assert module_stmts == source_ast.body