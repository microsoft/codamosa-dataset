

# Generated at 2022-06-12 03:39:44.603791
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-12 03:39:45.805542
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer



# Generated at 2022-06-12 03:39:51.355945
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module = ast.parse("")
    assert len(module.body) == 0

    trans = Python2FutureTransformer()
    new_module = trans.visit(module)
    assert len(new_module.body) == 4

    assert new_module.body[0].value.args[0].s == 'absolute_import'
    assert new_module.body[1].value.args[0].s == 'division'
    assert new_module.body[2].value.args[0].s == 'print_function'
    assert new_module.body[3].value.args[0].s == 'unicode_literals'


# Generated at 2022-06-12 03:39:59.031321
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from tests.utils import check_transformation, test_transformer
    source = """
    def hello():
        print("hello world")
    hello()
    """

    expected = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
        
    def hello():
        print("hello world")
    hello()
    """
    check_transformation(test_transformer(source, Python2FutureTransformer), expected)

# Generated at 2022-06-12 03:40:05.341991
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse('''
from a import b
from c import d
from e import f
from g import h
''')
    Python2FutureTransformer.visit(node)
    expected = ast.parse('''
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
from a import b
from c import d
from e import f
from g import h
''')
    assert ast.dump(node) == ast.dump(expected)

# Generated at 2022-06-12 03:40:07.562226
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    obj = Python2FutureTransformer()
    assert obj.target == (2, 7)
    assert obj.get_tree_changed() == False

# Generated at 2022-06-12 03:40:09.593667
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    module = ast.parse("")
    Python2FutureTransformer(module)

# Generated at 2022-06-12 03:40:18.572403
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3
    from .base import BaseNodeTransformerTest
    from ..utils.source import source

    class Python2FutureTransformerTest(BaseNodeTransformerTest):
        target = Python2FutureTransformer.target
        transformer = Python2FutureTransformer
        # Method visit_Module of class Python2FutureTransformer.
        def test_visit_Module(sefl):
            node = ast3.parse(source("3 / 2"))
            self.check_visit(node, 'from __future__ import absolute_import\n'
                                   'from __future__ import division\n'
                                   'from __future__ import print_function\n'
                                   'from __future__ import unicode_literals\n\n'
                                   '3 / 2')
    return Python2FutureTransformerTest

Python2Future

# Generated at 2022-06-12 03:40:22.571915
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.test_utils import transform, expect_error
    from typed_ast.ast3 import parse

    expect_error(Python2FutureTransformer, parse('print("hello")'))
    assert len(list(transform(
        Python2FutureTransformer, parse('print("hello")')))) == 1



# Generated at 2022-06-12 03:40:29.219816
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    py2_tree = ast.parse(imports.get_code(future='__future__'), filename='<none>')
    assert type(py2_tree) == ast.Module

    py2_transformer = Python2FutureTransformer()
    py2_future_tree = py2_transformer.visit(py2_tree)
    py2_future_code = astor.to_source(py2_future_tree)
    assert py2_future_code == imports.get_code(future='__future__')

# Generated at 2022-06-12 03:40:37.846471
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .. import utils
    tree = utils.parse_code_snippet('f = 2; a = 2; print(a)')
    expected_tree = utils.parse_code_snippet('''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    f = 2; a = 2; print(a)
    ''')
    assert Python2FutureTransformer(tree).visit(tree) == expected_tree

# Generated at 2022-06-12 03:40:46.013267
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_inspector import ASTInspector
    from ..utils.eval_minifier import EvalMinifier
    import pprint  # more readable print

    # test code
    code = """
a = 1
print(a)
    """

    # expected output
    expected_code = """
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
a = 1
print(a)
    """

    # minify
    minifier = EvalMinifier(ast.parse(code), Python2FutureTransformer())
    min_node = minifier.get_minified_ast()
    
    # assert

# Generated at 2022-06-12 03:40:46.801575
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor

# Generated at 2022-06-12 03:40:47.749449
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer

# Generated at 2022-06-12 03:40:56.236837
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import typed_ast.ast3 as ast
    import typing
    from tree_transformer.python2.future import Python2FutureTransformer
    module = ast.parse('def foo(x): return x * 2')
    result = Python2FutureTransformer().visit_Module(module)

# Generated at 2022-06-12 03:40:58.894828
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = ast.parse("1 + 1")
    Python2FutureTransformer().visit(module)
    print(ast.dump(module))


# Generated at 2022-06-12 03:41:08.250239
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    from textwrap import dedent 
    tree = ast.parse(dedent('''\
        x = 1
        y = 2
        z = x + y
        print(z)'''))
    Python2FutureTransformer().visit(tree)
    expected = dedent('''\
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        x = 1
        y = 2
        z = x + y
        print(z)''')
    assert astor.to_source(tree).strip() == expected.strip()

# Generated at 2022-06-12 03:41:18.386473
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    a = Python2FutureTransformer()

    # Baseline without imports
    module = ast.parse('x = 1')
    a.visit(module)  # type: ignore
    assert(ast.dump(module) == "Module(body=[Assign(targets=[Name(id='x', ctx=Store())], value=Num(n=1))])")

    # __future__ imports should be prepended:
    module = ast.parse('x = 1')
    a.visit(module)

# Generated at 2022-06-12 03:41:20.756102
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # Compilation flags for different versions of python
    flags = {
        (2, 7): 0,
    }
    # Source code that will be transformed by Python3FutureTransformer

# Generated at 2022-06-12 03:41:30.110703
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import ast
    sut = Python2FutureTransformer()
    tree = ast.parse("a = 10")
    sut.visit(tree)
    assert len(tree.body) == 5
    tree = ast.parse("from __future__ import division\na = 10")
    sut.visit(tree)
    assert len(tree.body) == 5
    tree = ast.parse("from __future__ import division\nfrom __future__ import division\na = 10")
    sut.visit(tree)
    assert len(tree.body) == 6
    tree = ast.parse("from __future__ import division\nfrom __future__ import division\nfrom __future__ import division\na = 10")
    sut.visit(tree)
    assert len(tree.body) == 7

# Generated at 2022-06-12 03:41:32.949249
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer()


# Generated at 2022-06-12 03:41:38.592743
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    code = '''
        my_module = ...
        def my_function():
            ...
    '''
    module_node = ast.parse(code)
    expected_module_node = ast.parse('''
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        my_module = ...
        def my_function():
            ...
    ''')

    transformer = Python2FutureTransformer()
    new_module_node = transformer.visit(module_node)  # type: ignore
    
    assert transformer._tree_changed == True
    assert ast.dump(new_module_node) == ast.dump(expected_module_node)

# Generated at 2022-06-12 03:41:47.817786
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    from flake8_aaa.example_code import python2

    # some whitespace issues that should be fixed
    src = """    
import os

print('hi')
"""
    code = astor.code_to_ast.parse_string(src)
    src2 = astor.to_source(code)
    print(src2)

    # modified version to support python2.7
    code = astor.code_to_ast.parse_string(python2.src)
    src2 = astor.to_source(code)
    print(src2)
    code2 = Python2FutureTransformer().transform(code)
    src3 = astor.to_source(code2)
    print(src3)
    assert src2 != src3



# Generated at 2022-06-12 03:41:56.958369
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.base import BaseNodeTest
    from ..utils.source import source_to_unicode
    from typed_ast import ast3 as ast

    class Test(BaseNodeTest):
        target = Python2FutureTransformer.target
        transform = Python2FutureTransformer
        transform_name = 'future'
        filename = __file__

        def test_simple_division(self):
            tree = ast.parse(source_to_unicode('''
                a = 1/2
            '''))
            self.check(tree, '''\
                from __future__ import absolute_import
                from __future__ import division
                from __future__ import print_function
                from __future__ import unicode_literals

                a = 1/2
            ''')

        def test_integer_division(self):
            tree = ast

# Generated at 2022-06-12 03:41:58.158467
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer()



# Generated at 2022-06-12 03:42:07.346558
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ...common import parse_python_source

    tree = parse_python_source(Python2FutureTransformer.__doc__)
    assert isinstance(tree, ast.Module)

    node = tree

    visitor = Python2FutureTransformer()
    tree = visitor.visit(node)
    assert tree != node
    assert isinstance(tree, ast.Module)
    assert visitor._tree_changed is True

    from ...common import dump_python_source
    lines = dump_python_source(tree).splitlines()

    assert lines[0] == 'from __future__ import absolute_import'
    assert lines[1] == 'from __future__ import division'
    assert lines[2] == 'from __future__ import print_function'
    assert lines[3] == 'from __future__ import unicode_literals'

# Generated at 2022-06-12 03:42:08.434710
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer()


# Generated at 2022-06-12 03:42:16.874970
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module(): 
    from .test_helpers import get_node, compare_source

    source = """#!/usr/bin/env python
import sys

print(sys.version_info)
"""
    tree = get_node(source, 2, 7)
    Python2FutureTransformer().visit(tree)
    result = compile(tree, '<test>', 'exec')  # type: ignore

    compare_source(result, source, """\
#!/usr/bin/env python
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
import sys

print(sys.version_info)
""")

# Generated at 2022-06-12 03:42:20.985375
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    tree = astor.parse_file(__file__)
    tree = Python2FutureTransformer().visit(tree)
    print(astor.to_source(tree))


if __name__ == '__main__':
    test_Python2FutureTransformer_visit_Module()

# Generated at 2022-06-12 03:42:28.959070
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    tree = ast.parse('print(1)')
    transformer = Python2FutureTransformer()
    transformer.visit(tree)

# Generated at 2022-06-12 03:42:33.684612
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-12 03:42:38.439825
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    data = []
    '''
    @snippet
    def test_alias_names(a):
        pass
    
    '''
    tree = ast.parse(dedent(data[0]))
    Python2FutureTransformer().visit(tree)
    new_tree = ast.parse(dedent(data[1]))
    assert ast.dump(tree) == ast.dump(new_tree)

# Generated at 2022-06-12 03:42:48.344568
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    source_1 = """
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

s = 1 + 2"""
    
    expected_1 = """
from future import absolute_import
from future import division
from future import print_function
from future import unicode_literals

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

s = 1 + 2"""
    
    source = source_1
    expected = expected_1
    node = ast.parse(source)
    Python2FutureTransformer().visit(node)
    result = astor.to_source(node)
    print(result)
    assert result == expected

    source

# Generated at 2022-06-12 03:42:56.820377
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from .base import BaseNodeTransformer
    assert issubclass(Python2FutureTransformer, BaseNodeTransformer)
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer.target == (2, 7)
    assert Python2FutureTransformer.visit_Module.__name__ == 'visit_Module'
    assert inspect.isfunction(Python2FutureTransformer.visit_Module)
    assert Python2FutureTransformer.visit_Module.__doc__ == \
           'Prepends module with:\n' \
           '    from __future__ import absolute_import\n' \
           '    from __future__ import division\n' \
           '    from __future__ import print_function\n' \
           '    from __future__ import unicode_literals\n'

# Generated at 2022-06-12 03:42:58.060786
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    x = Python2FutureTransformer()
    assert x is not None


# Generated at 2022-06-12 03:43:04.904541
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    test_case = """
        # some comment
        import ast
        import math
        import sys

        print(sys.version_info)
    """
    expected = """
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        import ast
        import math
        import sys

        print(sys.version_info)
    """
    actual = Python2FutureTransformer().transform_code(test_case)
    assert actual == expected, actual

# Generated at 2022-06-12 03:43:11.036577
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    """
    Transforms Python 2 module
    """
    target = (2, 7)
    module = ast.parse("x = 1+2")
    module = Python2FutureTransformer(target).visit(module)
    source = astor.to_source(module).strip()
    assert source == "from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\nx = 1 + 2"

# Generated at 2022-06-12 03:43:20.311125
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():

    # Given
    input_python_fragment = """
    import os, sys
    def my_func(a, b):
        pass

    """

    expected_python_fragment = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    import os, sys
    def my_func(a, b):
        pass
    """

    # When
    node = ast.parse(input_python_fragment)
    transformer = Python2FutureTransformer()
    new_node = transformer.visit(node)
    transformer.generic_visit(new_node)
    output_python_fragment = ast.dump(new_node, include_attributes=False)

    # Then

# Generated at 2022-06-12 03:43:25.399278
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_visitor import TestVisitor
    
    target = """
x = 1
""".strip()
    expected = """
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
x = 1
""".strip()
    nt = Python2FutureTransformer()
    tv = TestVisitor(target, expected, nt)
    tv.test()

# Generated at 2022-06-12 03:43:28.085686
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    python2futuretransformer=Python2FutureTransformer()
    assert python2futuretransformer.tree_changed is False
    assert python2futuretransformer.target == (2, 7)

# Generated at 2022-06-12 03:43:36.627429
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert isinstance(transformer, Python2FutureTransformer)


# Generated at 2022-06-12 03:43:42.368795
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()
    tree = ast.parse("""
a = 1
print(a)
""")
    expected_tree = ast.parse("""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
a = 1
print(a)
""")
    transformer.visit(tree)
    assert ast.dump(tree) == ast.dump(expected_tree)



# Generated at 2022-06-12 03:43:45.951060
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert isinstance(transformer, Python2FutureTransformer)
    assert isinstance(transformer, BaseNodeTransformer)
    assert transformer._tree_changed == False
    assert transformer.target == (2, 7)


# Generated at 2022-06-12 03:43:55.400399
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = ast.parse("")
    t = Python2FutureTransformer()
    module = t.visit(module)
    assert len(module.body) == 7
    assert module.body[3].module == '__future__'
    assert module.body[3].name == 'absolute_import'
    assert module.body[4].module == '__future__'
    assert module.body[4].name == 'division'
    assert module.body[5].module == '__future__'
    assert module.body[5].name == 'print_function'
    assert module.body[6].module == '__future__'
    assert module.body[6].name == 'unicode_literals'

# Generated at 2022-06-12 03:43:56.724084
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()
    assert t is not None


# Generated at 2022-06-12 03:44:02.381533
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .utils import round_trip
    from typed_ast.ast3 import parse
    from .snippet import snippet

    source = snippet.get_body(future='__future__') + os.linesep + \
        '''if True:
            print('test')'''

    source_tree = parse(source)
    expected_tree = parse(source)
    transformer = Python2FutureTransformer()
    result_tree = transformer.visit(source_tree)
    assert round_trip(result_tree) == round_trip(expected_tree)

# Generated at 2022-06-12 03:44:04.967319
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import parse
    from asttokens import ASTTokens
    from .fixer_utils import get_fixer_names

    # Given

# Generated at 2022-06-12 03:44:06.897917
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer()._tree_changed == False

# Unit tests for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-12 03:44:13.987603
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    src = textwrap.dedent("""\
    def add(a, b):
        return a + b
    """)
    expected = textwrap.dedent("""\
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    
    
    def add(a, b):
        return a + b
    """)

    t = Python2FutureTransformer(2, 7)
    t.futurize(src)
    actual = t.futurize(src)
    assert expected == actual

# Generated at 2022-06-12 03:44:19.214008
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    node = ast.parse('a = 1; b = 2')
    t = Python2FutureTransformer(node)
    t.run()
    print(ast.dump(t.tree))
    body = t.tree.body
    assert body[0].value.args[0].s == '__future__'
    assert body[1].value.args[0].s == '__future__'
    assert body[2].value.args[0].s == '__future__'
    assert body[3].value.args[0].s == '__future__'
    assert body[4].targets[0].id == "a"
    assert body[5].targets[0].id == "b"

# Generated at 2022-06-12 03:44:38.918057
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    class DummyModule(ast.Module):
        def __init__(self):
            super().__init__()
            self.body = [ast.Import(names=[ast.alias(name='os', asname=None)])] # noqa

    d = DummyModule()
    node = Python2FutureTransformer().visit(d)
    assert '__future__' in node.body[0].names[0].name

# Generated at 2022-06-12 03:44:43.414395
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    tree = ast.parse("print(1, 2)")
    Python2FutureTransformer().visit(tree)
    expected = ast.parse("""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
print(1, 2)
    """)
    assert ast.dump(tree) == ast.dump(expected)

# Generated at 2022-06-12 03:44:52.176363
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    a = ast.parse("print('hello world')")
    Python2FutureTransformer().visit(a)
    assert ast.dump(a) == "Module(body=[ImportFrom(module='__future__', names=[alias(name='absolute_import', asname=None)], level=0), ImportFrom(module='__future__', names=[alias(name='division', asname=None)], level=0), ImportFrom(module='__future__', names=[alias(name='print_function', asname=None)], level=0), ImportFrom(module='__future__', names=[alias(name='unicode_literals', asname=None)], level=0), Expr(value=Call(func=Name(id='print', ctx=Load()), args=[Str(s='hello world')], keywords=[]))])"

# Generated at 2022-06-12 03:44:57.622956
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils import ELLIPSIS, assert_equal
    transformer = Python2FutureTransformer()
    module = importlib.import_module(transformer.__module__)
    tree = ast.parse(inspect.getsource(module))
    expected_tree = ast.parse(inspect.getsource(module).replace(ELLIPSIS, imports.get_code(future='__future__')))
    transformed_tree = transformer.visit(tree)
    assert_equal(expected_tree, transformed_tree)

# Generated at 2022-06-12 03:45:00.566361
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.Module(body=[])
    actual = Python2FutureTransformer().visit_Module(node)
    expected = ast.Module(body=imports.get_body('__future__'))  # type: ignore
    assert ast.dump(actual) == ast.dump(expected)

# Generated at 2022-06-12 03:45:08.928192
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Unit test for constructor of class Python2FutureTransformer."""

    # Arrange
    expected = ast.Module(
        body=[
            ast.ImportFrom(module='__future__', names=[
                ast.alias(name='absolute_import', asname=None),
                ast.alias(name='division', asname=None),
                ast.alias(name='print_function', asname=None),
                ast.alias(name='unicode_literals', asname=None),
            ], level=0)
        ])

    # Act
    actual = Python2FutureTransformer()(ast.parse('pass'))

    # Assert
    assert ast.dump(expected) == ast.dump(actual)

# Generated at 2022-06-12 03:45:12.334607
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse("def foo():\n    return True")
    tformer = Python2FutureTransformer()
    result = tformer.visit_Module(node)
    assert len(result.body) == 8
    assert isinstance(result.body[0], ast.ImportFrom)

# Generated at 2022-06-12 03:45:13.851962
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # Arrange

    # Act
    transformer = Python2FutureTransformer()

    # Assert
    assert transformer is not None

# Generated at 2022-06-12 03:45:20.956459
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
  from typed_ast import ast3 as ast
  from ..driver import Driver
  from ..utils.snippet import snippet
  from .test_utils import assert_code_equal, transform, parse

  @snippet
  def source(a):
      return a + 1

  @snippet
  def expected(a):
      from __future__ import absolute_import
      from __future__ import division
      from __future__ import print_function
      from __future__ import unicode_literals
      return a + 1

  # Test it
  ast_module = parse(source.get_ast(), version=2)
  driver = Driver(parso_version='0.5.1')
  node_transformer = Python2FutureTransformer()
  actual_module = driver.run_ast(ast_module, node_transformer)
 

# Generated at 2022-06-12 03:45:29.376815
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    code = textwrap.dedent(u"""
    class A(object):
        def __init__(self, x):
            self.x = x
        @classmethod
        def class_meth(cls, y):
            return cls(y)
        @staticmethod
        def static_meth(z):
            return "foo" + z
    class B(A):
        pass
    """)
    tree = ast.parse(code)
    Python2FutureTransformer().visit(tree)

# Generated at 2022-06-12 03:46:11.386911
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ...arguments import create_argument_parser
    from ...errors import SnippetError
    from ...main import main
    from ..utils import get_node_as_string
    from .base import get_transformed_program_string

    code = 'def test(a, b):\n    c = a + b\n    return a\n'
    new_code = get_transformed_program_string(code, Python2FutureTransformer, 2)
    assert new_code == 'from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n\ndef test(a, b):\n    c = a + b\n    return a\n', 'Wrong transformed code.'



# Generated at 2022-06-12 03:46:17.788905
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    code = """
        print()
    """
    module = ast.parse(code)
    Python2FutureTransformer().visit(module)
    print(ast.dump(module))

# Generated at 2022-06-12 03:46:19.661655
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)


# Generated at 2022-06-12 03:46:26.824461
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor
    code = 'print(1 + 1)'
    tree = ast.parse(code)
    transformer = Python2FutureTransformer
    new_tree = transformer().visit(tree)
    new_code = astor.to_source(new_tree)

    assert transformer.__name__ in repr(transformer)
    assert new_code == '\n'.join([
        "from __future__ import absolute_import",
        "from __future__ import division",
        "from __future__ import print_function",
        "from __future__ import unicode_literals",
        "print(1 + 1)"
    ])

# Generated at 2022-06-12 03:46:35.058264
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # source
    from typed_ast import ast3 as ast
    from typed_ast import simple_parse
    node = simple_parse('''
        a = 1
        print(a)
    ''')

    # target
    from typed_ast import ast3 as ast
    from typed_ast import simple_parse
    target = simple_parse('''
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        a = 1
        print(a)
    ''')

    # test
    from ..transformer import PythonTransformer
    transformer = PythonTransformer()
    transformer.transform_tree(node)
    assert equals(node, target)

# Generated at 2022-06-12 03:46:37.132318
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert '__futurize__' in transformer.imports

# Generated at 2022-06-12 03:46:38.198640
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    python2futuretransformer = Python2FutureTransformer()

# Generated at 2022-06-12 03:46:39.576544
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.target == (2, 7)

# Generated at 2022-06-12 03:46:48.136496
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import python_modernize
    from python_modernize.fixer_base import BaseFix
    from .base import BaseParseTestCase

    code = '''import os'''

    expected_code = '''from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

import os'''

    class ModuleTestFixer(BaseFix):
        BM_compatible = True
        PATTERN = 'import_name< any* >'

        def transform(self, node, results) -> None:
            pass

    class ParseTest(BaseParseTestCase):
        module_name = __name__ + '.ParseTest.' + ParseTest.__name__

    ParseTest.setUpModule()

# Generated at 2022-06-12 03:46:53.895453
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..merge import merge
    from .fixtures import transformer_unit_test
    from .fixtures import sample_source
    from typing import List

    source = sample_source(2, 7)
    tree = ast.parse(source)
    expected = sample_source(3, 6)
    mod = ast.parse(expected)
    
    t = Python2FutureTransformer()
    new = t.visit(tree)
    assert t._tree_changed
    assert merge(new, mod)

# Generated at 2022-06-12 03:48:12.958740
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor, ast

    source = """print('Python version 2.7')"""
    tree = ast.parse(source)
    transformer = Python2FutureTransformer()
    new_tree = transformer.visit(tree)

    assert transformer._tree_changed is True
    assert astor.to_source(new_tree) == """\
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
print('Python version 2.7')"""

# Generated at 2022-06-12 03:48:17.591960
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    imps = set(imports().get_body(future='__future__'))
    assert imps.pop().func.id == 'absolute_import'
    assert imps.pop().func.id == 'division'
    assert imps.pop().func.id == 'print_function'
    assert imps.pop().func.id == 'unicode_literals'
    assert len(imps) == 0
    assert not imports().body[-1].value.s.strip('\n')

# Generated at 2022-06-12 03:48:18.202432
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-12 03:48:19.996148
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer() is not None


# Generated at 2022-06-12 03:48:25.781581
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast

    m = ast.Module([ast.Expr(ast.Name('x'))])
    t = Python2FutureTransformer()
    new_m = t.visit(m)
    assert len(new_m.body) == 5

# Generated at 2022-06-12 03:48:26.334724
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass

# Generated at 2022-06-12 03:48:29.633411
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    tree = ast.parse("x=2\nprint(x)")
    assert tree.body[0].col_offset == 0
    t = Python2FutureTransformer(tree)
    t.visit_Module(tree)
    assert tree.body[0].col_offset == 8

# Generated at 2022-06-12 03:48:38.616354
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-12 03:48:40.848607
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer(target=2)
    assert transformer.version == (2, 7)
    assert transformer.target == (2, 7)


# Generated at 2022-06-12 03:48:41.925134
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    pass
# vim: et sw=4 ts=4