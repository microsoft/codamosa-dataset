

# Generated at 2022-06-12 03:39:51.459966
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source2ast
    from ..utils.ast import ast2source

    source_code = '''
    import sys


    def func():
        pass


    class A(object):
        pass
    '''
    actual = ast2source(Python2FutureTransformer(verbose=False).visit(source2ast(source_code)))
    expected = '''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals


    import sys


    def func():
        pass


    class A(object):
        pass
    '''
    assert actual == expected

# Generated at 2022-06-12 03:39:58.804508
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module1 = ast.Module([])
    module2 = ast.Module(imports.get_body(future='__future__'))
    transformer = Python2FutureTransformer()
    assert transformer.visit(module1) == module2
    a = ast.Assign()
    b = ast.BinOp()
    c = ast.Module([a, b])
    d = ast.Module(imports.get_body(future='__future__') + [a, b])
    assert transformer.visit(c) == d

# Generated at 2022-06-12 03:39:59.927496
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-12 03:40:00.492946
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-12 03:40:08.311073
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    """transform

    :param tree: AST
    :type tree: ast.AST
    """
    import astor
    from pathlib import Path
    import textwrap
    # test_fucntion
    test_function = """
    def foo():
        pass
    """
    tree_origin = ast.parse(test_function)
    tree_transformed = ast.parse(test_function)
    transformer = Python2FutureTransformer()
    tree_transformed = transformer.visit(tree_transformed)
    source_origin = astor.to_source(tree_origin)
    source_transformed = astor.to_source(tree_transformed)

# Generated at 2022-06-12 03:40:14.808281
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    original = """
if a < b:
    a = 0
else:
    a = 1"""
    expected = """
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

if a < b:
    a = 0
else:
    a = 1"""
    root = ast.parse(original)
    Python2FutureTransformer().generic_visit(root)  # type: ignore
    assert expected == astor.to_source(root)

# Generated at 2022-06-12 03:40:21.631510
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.base_test_visitor import BaseTestVisitor
    from ..utils.visitor import StringNodeVisitor

    class Test(BaseTestVisitor):

        def test_no_changes(self):
            checker = self._check(
                'a = 1',
                'a = 1',
                (2, 7)
            )
            self.assertFalse(checker.transformer._tree_changed)
            self.assertFalse(checker.transformer._imports_added)


# Generated at 2022-06-12 03:40:26.096615
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    tree = ast.parse("print('hello world')")
    tr = Python2FutureTransformer()
    tr.visit(tree)
    assert tr._tree_changed is True
    assert isinstance(tree.body[0], ast.ImportFrom)
    assert tree.body[0].module == '__future__'

# Generated at 2022-06-12 03:40:36.160250
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..test_utils import make_test_transformer
    from ..test_utils import parse_ast
    from .python2_print_function_transformer import Python2PrintFunctionTransformer
    # Arrange
    transformer = make_test_transformer(Python2FutureTransformer)
    # Act
    result = transformer.visit(
        # Arrange
        parse_ast('''
        print("Hello World")
        ''')
    )
    # Assert

# Generated at 2022-06-12 03:40:44.844754
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import c_ast_to_ast
    from ..testing_utils import compile_snippet
    from .base import BaseNodeTransformerTestCase
    from .base import patch_ast_to_source

    class Test(BaseNodeTransformerTestCase):
        target = (2, 7)

        def snippet(self, node: ast.AST, target: Any=target) -> str:
            self.transformer = Python2FutureTransformer(target)
            new_node = self.transform_node(node)
            with patch_ast_to_source():
                return compiler.ast_to_source(new_node)


# Generated at 2022-06-12 03:40:52.524428
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from tests.utils.transformers import assert_transformation
    assert_transformation(
        Python2FutureTransformer,
        before_source="a = 1",
        after_source="from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\na = 1",
    )


# Generated at 2022-06-12 03:40:56.447894
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse("x = 1")
    transformer = Python2FutureTransformer(target_info=(2, 7))
    assert transformer.visit(node) == ast.parse("from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n\nx = 1")

# Generated at 2022-06-12 03:41:02.855439
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    tree = ast.parse("a = 1\nprint('hello, world')")
    Python2FutureTransformer().visit(tree)
    assert(str(tree) == "from __future__ import absolute_import\n"
                       "from __future__ import division\n"
                       "from __future__ import print_function\n"
                       "from __future__ import unicode_literals\n"
                       "\n"
                       "a = 1\n"
                       "print('hello, world')\n")

# Generated at 2022-06-12 03:41:07.519706
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    m = ast.parse('''
__builtins__ = open
m = print
''')
    Python2FutureTransformer().visit(m)
    assert ast.dump(m) == '''<_ast.Module object at 0x7f0e9bcbac88>'''

# Generated at 2022-06-12 03:41:17.833619
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .transpile_test_base import TranspileTestBase
    from asttokens import ASTTokens

    class Test(TranspileTestBase):
        def __init__(self):
            from .transpile_test_base import Tracer
            TranspileTestBase.__init__(self)
            self.tracer = Tracer()

        def test_Python2FutureTransformer(self):
            code = 'a = 1\n'

            atok = ASTTokens(code, parse=True)
            node = atok.tree

            transformer = Python2FutureTransformer()
            transformed = transformer.visit(node)

            self.tracer.trace(self, atok, transformed, 'visit_Module')
            return atok, transformed
    
    test = Test()
    atok, transformed = test.test_

# Generated at 2022-06-12 03:41:21.340694
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source
    from .test_base import BaseNodeTest

    # Transformed
    code = source(imports)
    expected_code = f"{imports.get_body(future='__future__')}{code}"  # type: ignore
    # Test
    assert BaseNodeTest(Python2FutureTransformer, code).test(expected_code)

# Generated at 2022-06-12 03:41:30.806996
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast.ast3 import Module
    from typed_ast.ast3 import parse
    from typed_astunparse import unparse
    from typed_astunparse import dump

# Generated at 2022-06-12 03:41:38.030266
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    """Visit method test"""
    import ast
    from textwrap import dedent
    from typed_ast.ast3 import Module
    from ..utils.snippet import snippet

    ast_tree = ast.parse(dedent('''
    print('Hello world!')
    '''))

    transformer = Python2FutureTransformer()
    result = transformer.visit(ast_tree)

# Generated at 2022-06-12 03:41:43.584268
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    source = "print('hello world')\n"
    correct = "from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n\nprint('hello world')\n"
    node = ast.parse(source)
    new_node = Python2FutureTransformer().visit(node)
    assert ast.dump(new_node) == ast.dump(ast.parse(correct))

# Generated at 2022-06-12 03:41:52.834168
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse('def f(x):\n    return 2 * x')
    et = Python2FutureTransformer()
    et.visit(node)

# Generated at 2022-06-12 03:42:05.084252
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # Arrange
    tree: ast.Module = ast.parse(textwrap.dedent("""
        print('foo')
    """))
    transformer = Python2FutureTransformer(tree)
    
    # Act
    tree = transformer.visit_Module(tree)
    
    # Assert
    assert isinstance(tree, ast.Module)
    assert len(tree.body) == 1
    
    assert isinstance(tree.body[0], ast.ImportFrom)
    assert tree.body[0].module == '__future__'

# Generated at 2022-06-12 03:42:14.766000
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    import sys
    import os
    path = os.path.dirname(os.path.realpath(__file__))
    sys.path.insert(0, path + "/../../")
    from Python2to3.transformers.python2_future_transformer import Python2FutureTransformer
    import astunparse


# Generated at 2022-06-12 03:42:20.944152
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()
    module_node = ast.parse('''
x = 1
''')

    new_module_node = transformer.visit(module_node)
    assert ast.dump(new_module_node) == ast.dump(ast.parse('''
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
x = 1
'''))

# Generated at 2022-06-12 03:42:28.442643
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .. import example
    from ..pythran_types import PythranSyntaxError
    code = example.fib_neat.source
    from ..loader import get_python_ast
    module = get_python_ast(code)

    transformer = Python2FutureTransformer()
    transformer.visit(module)
    for line in transformer.output().split('\n'):
        assert line == line.rstrip()
    assert transformer.output() == imports.get_source(future='__future__') + '\n' + code

    test_code = code.replace('/', '//')
    module = get_python_ast(test_code)
    with pytest.raises(PythranSyntaxError):
        transformer.visit(module)

# Generated at 2022-06-12 03:42:37.857176
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..snippets import PYTHON_2_SOURCE_CODE
    from .insert_future_import import Python2InsertFutureImportTransformer
    from . import NodeTransformerTestCase

    # NodeTransformerTestCase
    class Test(NodeTransformerTestCase):
        target = (2, 7)
        transformer = Python2FutureTransformer

# Generated at 2022-06-12 03:42:39.108766
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor

# Generated at 2022-06-12 03:42:48.962663
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    
    _imports = [
        ast.ImportFrom(module='__future__', 
                       names=[
                           ast.alias(name='absolute_import', asname=None),
                           ast.alias(name='division', asname=None),
                           ast.alias(name='print_function', asname=None),
                           ast.alias(name='unicode_literals', asname=None)
                       ], 
                       level=0)
    ]


# Generated at 2022-06-12 03:42:53.112606
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    result = astor.to_source(Python2FutureTransformer().visit(ast.parse("x = 1")))
    assert(result == "from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\nx = 1")

# Generated at 2022-06-12 03:42:58.856106
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()
    example = '''import os

print(os.path.exists("./"))
'''
    expected = '''from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

import os

print(os.path.exists("./"))
'''
    tree = ast.parse(example)
    transformer.visit(tree)
    fixed_example = astor.to_source(tree).strip()
    assert fixed_example == expected



# Generated at 2022-06-12 03:43:08.102407
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = ast.parse("print(1)")
    transformed = Python2FutureTransformer().visit(module)

    assert transformed is not module
    assert transformed.body is not module.body
    assert len(transformed.body) == 7
    assert transformed.body[0].value.s == '__future__'
    assert transformed.body[1].value.s == '__future__'
    assert transformed.body[2].value.s == '__future__'
    assert transformed.body[3].value.s == '__future__'
    assert transformed.body[4].value.s == '__future__'
    assert transformed.body[5].value.s == 'print'
    assert transformed.body[6].value.n == 1



# Generated at 2022-06-12 03:43:17.998257
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    input = """
    a = 1
    """
    expected_output = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    a = 1
    """
    transformer = Python2FutureTransformer()
    transformed_tree = transformer.visit(ast.parse(input))
    transformed_output = astor.to_source(transformed_tree)
    assert transformed_output == expected_output

# Generated at 2022-06-12 03:43:21.448797
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from .test_BaseNodeTransformer import _test_transform_to_target
    _test_transform_to_target(Python2FutureTransformer, 
            'test_data/test_Python2FutureTransformer_visit_Module.py')

# Generated at 2022-06-12 03:43:27.445115
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    code = '''
    def a():
        pass

    def b():
        pass
    '''

    expected = '''
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

    def a():
        pass

    def b():
        pass
    '''

    tree = ast.parse(code)
    Python2FutureTransformer().visit(tree)
    gen_code = compile(tree, '<string>', 'exec')
    gen_code = '\n'.join(gen_code.co_consts[0].co_lnotab)

    assert gen_code == expected

# Generated at 2022-06-12 03:43:37.299734
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ...tests.transformer_test_case import TransformerTestCase
    import astor

    class TestPython2FutureTransformer(TransformerTestCase):
        transformer = Python2FutureTransformer

        def test_visit_Module(self):
            code = '''
            print(1)
            '''
            tree = self.parse_text(code)
            tree = self.transform_single_node(tree)
            code = astor.to_source(tree)
            expected = '''
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
            print(1)
            '''
            self.assertEqual(code, expected)

    test_case = TestPython2FutureTransformer()

# Generated at 2022-06-12 03:43:44.702076
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast

    modules = [
        "pass",
        "import os",
        "import os; print(os.getcwd())"
    ]
    expected = [
        imports.strip(),
        imports.strip() + "\nimport os",
        imports.strip() + "\nimport os; print(os.getcwd())"
    ]

    for module, expected in zip(modules, expected):
        s = ast.parse(module)
        tree = Python2FutureTransformer().visit(s)
        source = compile(tree, filename="<ast>", mode="exec")
        assert source == expected  # type: ignore

# Generated at 2022-06-12 03:43:55.156121
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test import parse_to_node

    # Arrange
    ast_tree = parse_to_node("# test\nprint(2+3)")

    # Act
    node = Python2FutureTransformer(target_version=(2, 7)).visit(ast_tree)

    # Assert
    # print(node)

# Generated at 2022-06-12 03:44:00.395373
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ... import ast_util

    src = """def foo():
                bar()
    """
    tree = ast.parse(src, "??")
    trans = Python2FutureTransformer(tree)
    trans.visit(tree)

# Generated at 2022-06-12 03:44:09.508398
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-12 03:44:15.904299
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = ast.parse("print('hello')")
    transformer = Python2FutureTransformer()
    new_module = transformer.visit(module)
    (first_stmt, second_stmt) = new_module.body
    assert (
        transformer.get_source(first_stmt)
        ==
        """from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals"""
    )
    assert transformer.get_source(second_stmt) == "print('hello')"

# Generated at 2022-06-12 03:44:21.782538
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module(): 
    source = '''
    def example():
        name = 'Alice'
        return name

    print(example())
    '''
    tree = ast.parse(source)
    Python2FutureTransformer(tree).visit(tree)
    expected = ast.parse('''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    def example():
        name = 'Alice'
        return name

    print(example())
    ''')
    assert ast.dump(tree) == ast.dump(expected)

# Generated at 2022-06-12 03:44:27.234696
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    instance = Python2FutureTransformer()
    assert isinstance(instance, Python2FutureTransformer)

# Generated at 2022-06-12 03:44:28.497992
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    pass



# Generated at 2022-06-12 03:44:37.981585
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    module = ast.parse('print(1/0)')
    Python2FutureTransformer().visit(module)
    assert ast.dump(module) == '''Module(body=[ImportFrom(module=\'future\', names=[alias(name=\'absolute_import\', asname=None)], level=0), ImportFrom(module=\'future\', names=[alias(name=\'division\', asname=None)], level=0), ImportFrom(module=\'future\', names=[alias(name=\'print_function\', asname=None)], level=0), ImportFrom(module=\'future\', names=[alias(name=\'unicode_literals\', asname=None)], level=0), Expr(value=BinOp(left=Num(n=1), op=Div(), right=Num(n=0)))])'''

# Generated at 2022-06-12 03:44:42.227011
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():

    tree = ast.parse("def f():\n    pass", mode='exec')
    transformer = Python2FutureTransformer()
    transformer.visit(tree)
    assert transformer._tree_changed == True

# Generated at 2022-06-12 03:44:44.828301
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-12 03:44:53.541503
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    import unittest

    class Test(unittest.TestCase):
        def test_visit_Module(self):
            tree = ast.parse('import sys')

            transformer = Python2FutureTransformer()
            node = transformer.visit(tree)

            self.assertTrue(transformer.is_changed)
            self.assertIsInstance(node, ast.Module)

# Generated at 2022-06-12 03:44:54.734709
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    # TODO: write test
    pass



# Generated at 2022-06-12 03:44:56.240349
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    x = Python2FutureTransformer()
    assert isinstance(x, BaseNodeTransformer)



# Generated at 2022-06-12 03:44:58.130616
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transpiler = Python2FutureTransformer([
        "from __future__ import unicode_literals"
    ])
    transpiler.visit(
    ast.parse("from __future__ import unicode_literals"))
    assert transpiler._tree_changed == False

# Generated at 2022-06-12 03:45:02.800977
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    from typed_ast import ast3 as ast

    node = ast.parse('a = 2')
    tree = Python2FutureTransformer().visit(node)
    assert astor.to_source(tree) == (
        'from __future__ import absolute_import\n'
        'from __future__ import division\n'
        'from __future__ import print_function\n'
        'from __future__ import unicode_literals\n'
        '\na = 2\n'
    )


# Generated at 2022-06-12 03:45:18.620590
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import (
        create_module_then_visit_it,
        assert_expression,
        assert_modules_equal,
    )
    from typed_ast import ast3 as ast

    # when module is empty
    module_node = ast.Module(body=[])
    module_node = Python2FutureTransformer().visit(module_node)
    expected_module_node = ast.Module(body=imports.get_body(future='__future__'))  # type: ignore
    assert_modules_equal(expected=expected_module_node, actual=module_node)

    # when module has 1 line expression
    module_node = ast.Module(body=[ast.Expr(value=ast.Num(n=1))])

# Generated at 2022-06-12 03:45:25.221356
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3

    module_ast = ast3.parse("x = 1")
    transformer = Python2FutureTransformer()
    transformer.visit(module_ast)

    assert transformer._tree_changed is True

    assert ast3.dump(module_ast) == ast3.dump(
        ast3.parse("""
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    x = 1""")
    )

# Generated at 2022-06-12 03:45:32.867486
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import os
    import astor
    path = os.path.dirname(os.path.realpath(__file__))
    sys.path.insert(0, os.path.join(path, '..', '..'))
    from .. import test_generator as TG

    test_generator = TG.TestGenerator(
        TG.TestGenerator.TEST_TYPE_UNIT,  # type
        'Python2FutureTransformer',  # module name
        'Python2FutureTransformer.visit_Module',  # function name
        'Python2FutureTransformer'  # class name
    )

    # Test case data

# Generated at 2022-06-12 03:45:40.814755
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    source = textwrap.dedent("""
        # Example of comment
        if True:
            pass
        """)
    expected = textwrap.dedent("""
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        # Example of comment
        if True:
            pass
        """)
    node = ast.parse(source)
    Python2FutureTransformer.run(node)
    result = astunparse.unparse(node)
    assert expected == result

# Generated at 2022-06-12 03:45:47.084185
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    input = """
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

print('Hello world')
"""

    result = """
print('Hello world')
"""

    tree = ast.parse(input)
    trans = Python2FutureTransformer()
    new_tree = trans.visit(tree)
    assert ast.dump(new_tree) == ast.dump(ast.parse(result))  # type: ignore


# Generated at 2022-06-12 03:45:55.895713
# Unit test for constructor of class Python2FutureTransformer

# Generated at 2022-06-12 03:46:00.692515
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from os import path as path_
    from .test_fixtures.classes import Python2FutureTransformer_visit_Module as test_class

    def test_func(test_self):
        test_self.assertTrue(path_.exists('Python2FutureTransformer_visit_Module.py'))

    test_class.test_func = test_func
    globals().update(vars(test_class('test_func')))



# Generated at 2022-06-12 03:46:11.105020
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    from ..tests.utils import get_introspection_data
    from ..utils import python_targets

    target = python_targets[2]

# Generated at 2022-06-12 03:46:15.571787
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    transformer = Python2FutureTransformer()
    node = ast.Module(
        [ast.Str(s='This is a doc string')], 
        type_ignores=[ast.Str]
    )
    assert node == transformer.visit(node)
    assert transformer.tree_changed is True
    assert node.body[:5] == imports.get_body(future='__future__')  # type: ignore

# Generated at 2022-06-12 03:46:20.613001
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from toolz import get_in
    from ..utils.ast_builder import build_ast_from_snippet
    class_ = get_in(['body', 0], build_ast_from_snippet(Python2FutureTransformer, snippet), {})
    assert class_['name'] == 'Class'
    assert get_in(['body', 0], class_, {})['name'] == 'FunctionDef'  # check that the class has a method

# Generated at 2022-06-12 03:46:40.573164
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse('x = 1')
    assert ('from __future__ import absolute_import\n'
            'from __future__ import division\n'
            'from __future__ import print_function\n'
            'from __future__ import unicode_literals\nx = 1') == Python2FutureTransformer.visit_Module(None, node).body


# Generated at 2022-06-12 03:46:41.641634
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer is not None

# Generated at 2022-06-12 03:46:43.346251
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    instance = Python2FutureTransformer()
    for attr in ['generic_visit']:
        assert attr in dir(instance)


# Generated at 2022-06-12 03:46:52.161990
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    to_source = Python2FutureTransformer(target=(2, 7)).to_source

    assert to_source('pass') == 'from __future__ import absolute_import\n' \
                                'from __future__ import division\n' \
                                'from __future__ import print_function\n' \
                                'from __future__ import unicode_literals\n\n' \
                                'pass\n'
    assert to_source('pass\npass\n') == 'from __future__ import absolute_import\n' \
                                       'from __future__ import division\n' \
                                       'from __future__ import print_function\n' \
                                       'from __future__ import unicode_literals\n\n' \
                                       'pass\n' \
                                       'pass\n\n'


# Generated at 2022-06-12 03:47:01.415116
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    case = ast.parse('''
        print('Python2FutureTransformer works!')
    ''')
    expected = ast.Module(body=[
        ast.ImportFrom(
            module='__future__',
            names=[ast.alias(name='absolute_import', asname=None),
                   ast.alias(name='division', asname=None),
                   ast.alias(name='print_function', asname=None),
                   ast.alias(name='unicode_literals', asname=None)],
            level=0),
        ast.Expr(value=ast.Call(
            func=ast.Name(id='print', ctx=ast.Load()),
            args=[ast.Str(s='Python2FutureTransformer works!')],
            keywords=[]))])

    a = Python2FutureTransformer()
   

# Generated at 2022-06-12 03:47:07.428924
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse('\nprint("foo")')
    transformer = Python2FutureTransformer()
    node = transformer.visit(node)
    assert isinstance(node, ast.Module), 'node is not an ast.Module instance'
    assert isinstance(node.body, list), 'node.body is not a list'
    assert len(node.body) == 6, 'node.body does not have a len of 6'
    assert isinstance(node.body[0], ast.ImportFrom), 'node.body[0] is not an ast.ImportFrom instance'
    assert node.body[0].module == '__future__', 'node.body[0].module has not been modified'
    assert isinstance(node.body[1], ast.ImportFrom), 'node.body[1] is not an ast.ImportFrom instance'
   

# Generated at 2022-06-12 03:47:16.143138
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # Arrange
    import typed_ast.ast3 as ast
    input_node = ast.Module([
        ast.Assign([ast.Name('x', ast.Store())], ast.Num(32))
    ])
    transformer = Python2FutureTransformer()

    # Act
    result = transformer.visit(node=input_node)

    # Assert

# Generated at 2022-06-12 03:47:21.083310
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.test_utils import transform

    @transform(Python2FutureTransformer)
    def test():
        """
        print('hello')
        """

    _test = test()

    assert _test == """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    print('hello')
    """

# Generated at 2022-06-12 03:47:22.740912
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)
    assert not transformer._tree_changed



# Generated at 2022-06-12 03:47:31.063942
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # Test the constructor of class Python2FutureTransformer
    f = Python2FutureTransformer()
    assert isinstance(f, BaseNodeTransformer)
    assert f.target == (2, 7)
    assert f.get_name() == 'Python2FutureTransformer'
    assert f.get_version() == '0.0.1'
    assert f.get_target_version() == (2, 7)
    assert f.get_code_snippet() == 'from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals'

# Generated at 2022-06-12 03:48:20.105432
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    node = ast.parse('x = 1')
    assert ast.dump(node) == "Module(body=[Assign(targets=[Name(id='x', ctx=Store())], value=Num(n=1))])"  # type: ignore

    t = Python2FutureTransformer()
    t.visit(node)


# Generated at 2022-06-12 03:48:25.116554
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    node = ast.parse(textwrap.dedent("""\
        from future import print_function
        from __future__ import division


        def foo():
            print(3 / 2)
    """))

    node = Python2FutureTransformer().visit(node)

    assert ast.dump(node) == textwrap.dedent("""\
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        from future import print_function
        from __future__ import division


        def foo():
            print(3 / 2)
    """)

# Generated at 2022-06-12 03:48:33.614257
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast.ast3 import parse
    tree = parse("print('Hello from Python 2')")
    Python2FutureTransformer().transform(tree)

# Generated at 2022-06-12 03:48:35.902765
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.name == 'Python2FutureTransformer'
    assert transformer.target == (2, 7)
    assert transformer._tree_changed is False

# Generated at 2022-06-12 03:48:46.071239
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    class_name = 'Python2FutureTransformer'
    visit_name = 'visit_Module'
    source = inspect.getsource(Python2FutureTransformer)
    func = getattr(Python2FutureTransformer, visit_name, None)
    if func is None:
        message = f'Could not find method {visit_name} in class {class_name}'
        raise AssertionError(message)
    assert ast.get_docstring(func) is not None, (
        f'Method {class_name}.{visit_name} has no docstring')

    base_node = ast.parse('a = True\nb = "bar"\n')
    visitor = Python2FutureTransformer(base_node)
    node = visitor.visit(base_node)


# Generated at 2022-06-12 03:48:54.089643
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    source = inspect.cleandoc('''
    """Docstring.

    Multi-line docstring.

    """
    print('Hello World!')
    # comment
    ''')
    expected = inspect.cleandoc('''
    """Docstring.

    Multi-line docstring.

    """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    print('Hello World!')
    # comment
    ''')

    node = ast.parse(source)
    node = Python2FutureTransformer().visit(node)
    actual = astunparse.unparse(node)
    print(actual)

    assert actual == expected

# Generated at 2022-06-12 03:48:54.923360
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-12 03:48:55.645470
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-12 03:49:02.743610
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # type: () -> None
    source = dedent("""
        def foo(bar):
            return bar + 1
    """.lstrip())
    expected = dedent("""
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals


        def foo(bar):
            return bar + 1
    """.lstrip())
    tree = ast.parse(source)  # type: ignore
    t = Python2FutureTransformer()
    t.visit(tree)  # type: ignore
    assert ast.dump(tree) == ast.dump(ast.parse(expected))  # type: ignore

# Generated at 2022-06-12 03:49:03.963713
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer(None).target == (2, 7)