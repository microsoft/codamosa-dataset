

# Generated at 2022-06-18 00:08:22.158141
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_source_equal
    from .base import BaseNodeTransformer
    from .python2_future import Python2FutureTransformer
    from .python3_print import Python3PrintTransformer
    from .python3_division import Python3DivisionTransformer
    from .python3_absolute_import import Python3AbsoluteImportTransformer
    from .python3_unicode_literals import Python3UnicodeLiteralsTransformer
    from .python3_raise import Python3RaiseTransformer
    from .python3_nonzero import Python3NonzeroTransformer
    from .python3_metaclass import Python3MetaclassTransformer
    from .python3_with_statements import Python3WithStatementsTransformer

# Generated at 2022-06-18 00:08:31.812257
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_source_equal
    from .base import BaseNodeTransformer
    from .python2_future import Python2FutureTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__') + node.body  # type: ignore
            return self.generic_visit(node)  # type: ignore

    transformer = TestTransformer()
    source = '''
    def foo():
        pass
    '''

# Generated at 2022-06-18 00:08:34.775066
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    from ..utils.ast_helpers import get_ast
    from ..utils.ast_helpers import compare_ast


# Generated at 2022-06-18 00:08:40.403948
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.ast_helper import compare_ast
    from ..utils.ast_helper import get_ast
    from ..utils.ast_helper import get_source
    from ..utils.ast_helper import parse_ast
    from ..utils.ast_helper import parse_source
    from ..utils.ast_helper import run_ast


# Generated at 2022-06-18 00:08:51.583226
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import transform_and_compare
    from ..utils.test_utils import get_ast_node
    from ..utils.test_utils import get_ast_node_name
    from ..utils.test_utils import get_ast_node_type

    # Test 1
    module = get_ast_node(ast.parse("""
    def foo():
        pass
    """))
    assert get_ast_node_name(module) == 'Module'
    assert get_ast_node_type(module) == 'Module'
    assert len(module.body) == 1
    assert get_ast_node_name(module.body[0]) == 'FunctionDef'
    assert get_ast_node_type(module.body[0]) == 'FunctionDef'
    assert module.body[0].name == 'foo'

# Generated at 2022-06-18 00:09:03.459756
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import assert_ast_equal
    from .base import BaseNodeTransformer
    from .python2_future import Python2FutureTransformer
    from .utils import transform_and_compare

    class TestTransformer(BaseNodeTransformer):
        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = [ast.Expr(ast.Str('test'))]
            return self.generic_visit(node)  # type: ignore


# Generated at 2022-06-18 00:09:13.217064
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_module
    from ..utils.source import source_to_code
    from ..utils.source import source_to_function
    from ..utils.source import source_to_class
    from ..utils.source import source_to_expression
    from ..utils.source import source_to_statement
    from ..utils.source import source_to_interactive
    from ..utils.source import source_to_suite
    from ..utils.source import source_to_ast_tree
    from ..utils.source import source_to_ast_node
    from ..utils.source import source_to_ast_nodes
    from ..utils.source import source_to_ast_trees

# Generated at 2022-06-18 00:09:23.143143
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from .python2future import Python2FutureTransformer
    from .python2future import imports
    from ..utils.ast_helper import get_ast_from_source
    from ..utils.ast_helper import get_source_from_ast

    @snippet
    def source():
        pass

    @snippet
    def expected():
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        pass

    source_ast = get_ast_from_source(source.get_source())

# Generated at 2022-06-18 00:09:34.239606
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
           

# Generated at 2022-06-18 00:09:44.398579
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__')

# Generated at 2022-06-18 00:09:51.779076
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from .python2future import Python2FutureTransformer
    from .python3future import Python3FutureTransformer

    @snippet
    def code():
        pass

    tree = ast.parse(code.get_source())
    tree = Python2FutureTransformer().visit(tree)
    tree = Python3FutureTransformer().visit(tree)
    assert ast_to_str(tree) == code.get_source()

# Generated at 2022-06-18 00:10:00.805845
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_ast_node
    from ..utils.source import ast_node_to_source
    from ..utils.source import ast_to_source
    from ..utils.source import ast_node_to_source
    from ..utils.source import source_to_ast_node

    source = source_to_unicode('''
    def f(x):
        return x + 1
    ''')
    tree = source_to_ast(source)
    node = source_to_ast_node(source)
    transformer = Python2FutureTransformer()
    tree = transformer.visit(tree)
    node = transformer.visit(node)
    assert ast_to_source(tree)

# Generated at 2022-06-18 00:10:05.157875
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.snippet import snippet

    @snippet
    def code():
        pass

    node = code.get_ast()
    transformer = Python2FutureTransformer()
    transformer.visit(node)
    assert ast_to_str(node) == '''\
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

pass
'''

# Generated at 2022-06-18 00:10:06.395276
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer.target == (2, 7)


# Generated at 2022-06-18 00:10:13.526990
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_source_equal
    from .test_base import BaseNodeTransformerTest

    class Test(BaseNodeTransformerTest):
        transformer = Python2FutureTransformer
        target = (2, 7)
        code = '''
        import os
        import sys
        '''
        expected_code = '''
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        import os
        import sys
        '''

    assert_source_equal(Test)

# Generated at 2022-06-18 00:10:24.151577
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from .base import BaseNodeTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__') + node.body  # type: ignore
            return self.generic_visit(node)  # type: ignore

    code = """
    def foo():
        pass
    """
    expected = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    def foo():
        pass
    """

# Generated at 2022-06-18 00:10:35.025334
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source
    from ..utils.ast import get_ast, compare_asts


# Generated at 2022-06-18 00:10:45.522945
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source_to_ast
    from ..utils.ast_helpers import ast_to_source
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_tokens
    from ..utils.source import source_to_token_types
    from ..utils.source import source_to_token_names
    from ..utils.source import source_to_token_mapping
    from ..utils.source import source_to_tokens_mapping
    from ..utils.source import source_to_tokens_types
    from ..utils.source import source_to_tokens_names
    from ..utils.source import source_to_tokens_mapping
    from ..utils.source import source_to_tokens_mapping
    from ..utils.source import source

# Generated at 2022-06-18 00:10:52.864548
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.test_utils import assert_node_equal
    from ..utils.test_utils import get_node
    from ..utils.test_utils import get_node_module
    from ..utils.test_utils import get_node_class
    from ..utils.test_utils import get_node_function
    from ..utils.test_utils import get_node_method
    from ..utils.test_utils import get_node_decorator

    # Test module
    module = get_node_module('''
        pass
    ''')
    module = Python2FutureTransformer().visit(module)

# Generated at 2022-06-18 00:11:00.525189
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_fixtures
    from ..utils.source import source
    from ..utils.source import source_after
    from ..utils.tree import tree
    from ..utils.tree import tree_after
    from .test_base import TestBase

    class Test(TestBase):
        target = (2, 7)
        transformer = Python2FutureTransformer
        method = 'visit_Module'

        fixtures = make_fixtures(__file__, ('.py', '.pyi'),
                                 (source, source_after),
                                 (tree, tree_after))

    test = Test()
    test.test()

# Generated at 2022-06-18 00:11:07.569393
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # Test that the constructor of class Python2FutureTransformer
    # raises a TypeError if called with the wrong number of arguments
    with pytest.raises(TypeError):
        Python2FutureTransformer(1)

# Generated at 2022-06-18 00:11:17.745646
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from .base import BaseNodeTransformer
    from .python2_future import Python2FutureTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = [ast.parse('print("Hello World!")').body[0]]
            return self.generic_visit(node)  # type: ignore

    transformer = TestTransformer()
    transformer.visit(ast.parse('pass'))
    assert ast_to_str(transformer.root) == 'print("Hello World!")'

    transformer = Python2FutureTransformer()
    transformer.visit(ast.parse('pass'))


# Generated at 2022-06-18 00:11:29.129290
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor
    from ..utils.ast_helpers import dump_ast
    from ..utils.ast_helpers import parse_ast
    from ..utils.ast_helpers import get_ast_node_name
    from ..utils.ast_helpers import get_ast_node_type
    from ..utils.ast_helpers import get_ast_node_fields
    from ..utils.ast_helpers import get_ast_node_field_names
    from ..utils.ast_helpers import get_ast_node_field_values
    from ..utils.ast_helpers import get_ast_node_field_value
    from ..utils.ast_helpers import get_ast_node_field_value_names
    from ..utils.ast_helpers import get_ast_node_field_value_types

# Generated at 2022-06-18 00:11:35.604363
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_source
    from .base import BaseNodeTransformer
    from .python2_future import Python2FutureTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__') + node.body  # type: ignore
            return self.generic_visit(node)  # type: ignore

    source = '''
    def foo():
        pass
    '''

# Generated at 2022-06-18 00:11:37.715141
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    # Test that the class can be instantiated
    Python2FutureTransformer()

# Generated at 2022-06-18 00:11:44.339530
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source
    from ..utils.ast import get_ast, compare_asts
    from ..utils.visitor import dump_ast
    from ..utils.fixtures import get_test_data

    source_ = source(imports(future='__future__'))
    expected_ast = get_ast(source_)

    source_ = source(imports(future='__future__'))
    source_ = source_ + '\n' + source(get_test_data('python2_future_transformer.py'))
    actual_ast = get_ast(source_)
    actual_ast = Python2FutureTransformer().visit(actual_ast)
    assert compare_asts(actual_ast, expected_ast)

# Generated at 2022-06-18 00:11:53.677025
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source
    from ..utils.ast import dump_ast
    from ..utils.visitor import dump_visitor
    from ..utils.compare import compare_ast
    from ..utils.future import future_imports


# Generated at 2022-06-18 00:11:59.101714
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source
    from ..utils.ast import dump
    from ..utils.ast import parse
    from ..utils.ast import equal

    source = source(imports)
    expected = parse(source)
    actual = parse(source)
    transformer = Python2FutureTransformer()
    actual = transformer.visit(actual)
    assert equal(expected, actual)

# Generated at 2022-06-18 00:12:05.414086
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def code():
        pass

    node = code.get_ast()
    transformer = Python2FutureTransformer()
    transformer.visit(node)
    assert ast_to_str(node) == """
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

pass
"""

# Generated at 2022-06-18 00:12:15.913894
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_inspector import AstInspector
    from ..utils.source_code import SourceCode
    from ..utils.snippet import snippet

    @snippet
    def source_code():
        def foo():
            pass

    source = source_code.get_source()
    tree = ast.parse(source)
    transformer = Python2FutureTransformer()
    transformer.visit(tree)
    assert AstInspector(tree).get_source() == SourceCode(
        '''
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        def foo():
            pass
        '''
    ).get_source()

# Generated at 2022-06-18 00:12:28.630069
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer.target == (2, 7)
    assert Python2FutureTransformer.__doc__ == """Prepends module with:
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
            
    """
    assert Python2FutureTransformer.visit_Module.__doc__ == """Prepends module with:
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
            
    """
    assert Python2FutureTransformer.visit_Module.__name__ == 'visit_Module'


# Generated at 2022-06-18 00:12:37.370748
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer.target == (2, 7)
    assert Python2FutureTransformer.__doc__ is not None
    assert Python2FutureTransformer.visit_Module.__doc__ is not None
    assert Python2FutureTransformer.visit_Module.__annotations__ == {'node': ast.Module, 'return': ast.Module}
    assert Python2FutureTransformer.visit_Module.__module__ == __name__
    assert Python2FutureTransformer.visit_Module.__name__ == 'visit_Module'


# Generated at 2022-06-18 00:12:39.985420
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer.target == (2, 7)


# Generated at 2022-06-18 00:12:50.039969
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer.target == (2, 7)
    assert Python2FutureTransformer.__doc__ == 'Prepends module with:\n    from __future__ import absolute_import\n    from __future__ import division\n    from __future__ import print_function\n    from __future__ import unicode_literals\n        \n    '
    assert Python2FutureTransformer.visit_Module.__doc__ == 'Prepends module with:\n        from __future__ import absolute_import\n        from __future__ import division\n        from __future__ import print_function\n        from __future__ import unicode_literals\n             \n        '

# Generated at 2022-06-18 00:12:57.838867
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source_to_ast
    from ..utils.source import ast_to_source
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_unicode

# Generated at 2022-06-18 00:13:07.153745
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from .python2future import Python2FutureTransformer
    from ..utils.source import source

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    @snippet
    def code():
        print(1)

    node = ast.parse(source(code))
    Python2FutureTransformer().visit(node)
    assert source(node) == source(imports) + source(code)

# Generated at 2022-06-18 00:13:09.174044
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import transform_and_compare
    transform_and_compare(Python2FutureTransformer, 'from __future__ import absolute_import')

# Generated at 2022-06-18 00:13:15.839639
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)
    assert transformer.visit_Module.__name__ == 'visit_Module'
    assert transformer.visit_Module.__doc__ == 'Prepends module with:\n        from __future__ import absolute_import\n        from __future__ import division\n        from __future__ import print_function\n        from __future__ import unicode_literals\n            \n    '


# Generated at 2022-06-18 00:13:23.566586
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.fixtures import make_dummy_tree
    from ..utils.source import source
    from ..utils.ast import dump_ast
    from ..utils.ast import parse_module
    from ..utils.ast import compare_ast
    from ..utils.ast import dump_source
    from ..utils.ast import dump_tokens
    from ..utils.ast import dump_tree
    from ..utils.ast import dump_visitors
    from ..utils.ast import dump_visitors_tree
    from ..utils.ast import dump_visitors_source
    from ..utils.ast import dump_visitors_tokens
    from ..utils.ast import dump_visitors_tree_source
    from ..utils.ast import dump_visitors_tree_tokens
    from ..utils.ast import dump_visitors_source_tokens

# Generated at 2022-06-18 00:13:33.602781
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__')

# Generated at 2022-06-18 00:13:55.686027
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from .python2_future import Python2FutureTransformer
    from .python2_future import imports
    from .python2_future import test_Python2FutureTransformer_visit_Module
    from .python2_future import test_Python2FutureTransformer_visit_Module_1
    from .python2_future import test_Python2FutureTransformer_visit_Module_2
    from .python2_future import test_Python2FutureTransformer_visit_Module_3
    from .python2_future import test_Python2FutureTransformer_visit_Module_4
    from .python2_future import test_Python2FutureTransformer_visit_Module_5

# Generated at 2022-06-18 00:14:04.587758
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_tree_changed
    from ..utils.test_utils import assert_tree_unchanged
    from ..utils.test_utils import parse_ast_tree

    tree = parse_ast_tree('''
    def foo():
        pass
    ''')
    transformer = Python2FutureTransformer()
    new_tree = transformer.visit(tree)
    assert_tree_changed(transformer)
    assert_equal_ast(
        new_tree,
        parse_ast_tree('''
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        def foo():
            pass
        ''')
    )

# Generated at 2022-06-18 00:14:13.001759
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.test_utils import assert_node_equal
    from ..utils.test_utils import get_node
    from ..utils.test_utils import get_node_as_string
    from ..utils.test_utils import get_tree
    from ..utils.test_utils import get_tree_as_string
    from ..utils.test_utils import parse_string
    from ..utils.test_utils import parse_string_as_module
    from ..utils.test_utils import parse_string_as_suite
    from ..utils.test_utils import parse_string_as_expr
    from ..utils.test_utils import parse_string_as_stmt
    from ..utils.test_utils import parse_string_as_interactive
    from ..utils.test_utils import parse_string_as_single

# Generated at 2022-06-18 00:14:14.726230
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)


# Generated at 2022-06-18 00:14:24.646504
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from .python2future import Python2FutureTransformer
    from .python2future import imports
    from .python2future import test_Python2FutureTransformer_visit_Module
    from .python2future import test_Python2FutureTransformer_visit_Module_1
    from .python2future import test_Python2FutureTransformer_visit_Module_2
    from .python2future import test_Python2FutureTransformer_visit_Module_3
    from .python2future import test_Python2FutureTransformer_visit_Module_4
    from .python2future import test_Python2FutureTransformer_visit_Module_5
    from .python2future import test_Python2FutureTransformer_

# Generated at 2022-06-18 00:14:30.588147
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.snippet import snippet

    @snippet
    def code():
        def f():
            pass

    tree = ast.parse(code.get_source())
    transformer = Python2FutureTransformer()
    transformer.visit(tree)
    assert ast_to_str(tree) == code.get_source(future='__future__')

# Generated at 2022-06-18 00:14:34.097917
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer.target == (2, 7)
    assert Python2FutureTransformer.__doc__ == """Prepends module with:
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
            
    """


# Generated at 2022-06-18 00:14:44.466254
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_inspector import ASTInspector
    from ..utils.ast_inspector import assert_ast_equal

    source = '''
    import os
    '''
    expected = '''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    import os
    '''
    tree = ast.parse(source)
    inspector = ASTInspector()
    inspector.visit(tree)
    transformer = Python2FutureTransformer()
    transformer.visit(tree)
    inspector.visit(tree)
    assert_ast_equal(inspector.dump(), expected)

# Generated at 2022-06-18 00:14:55.951788
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from .python2_future import Python2FutureTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    @snippet
    def module():
        import sys
        import os
        import re
        import math
        import random
        import datetime
        import time
        import calendar
        import collections
        import itertools
        import functools
        import operator
        import threading
        import multiprocessing
        import subprocess
        import socket
        import json
        import c

# Generated at 2022-06-18 00:15:07.567476
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.ast_helper import compare_ast
    from ..utils.ast_helper import get_ast
    from ..utils.ast_helper import get_source
    from ..utils.ast_helper import parse_ast
    from ..utils.ast_helper import parse_source
    from ..utils.ast_helper import print_ast
    from ..utils.ast_helper import print_source
    from ..utils.ast_helper import source_to_ast
    from ..utils.ast_helper import source_to_str
    from ..utils.ast_helper import str_to_ast
    from ..utils.ast_helper import str_to_source

# Generated at 2022-06-18 00:15:44.087978
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer.target == (2, 7)
    assert Python2FutureTransformer.__doc__ is not None
    assert Python2FutureTransformer.visit_Module.__doc__ is not None
    assert Python2FutureTransformer.visit_Module.__annotations__ == {'node': ast.Module, 'return': ast.Module}
    assert Python2FutureTransformer.generic_visit.__doc__ is not None
    assert Python2FutureTransformer.generic_visit.__annotations__ == {'node': ast.AST, 'return': ast.AST}
    assert Python2FutureTransformer._tree_changed is False
    assert Python2FutureTransformer._changed_targets == set()
    assert Python2FutureTransformer._changed

# Generated at 2022-06-18 00:15:55.499666
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from .python2_future import Python2FutureTransformer
    from ..utils.source import source

    @snippet
    def module():
        import sys
        import os
        import re
        import math
        import random
        import urllib
        import urllib2
        import urlparse
        import datetime
        import time
        import calendar
        import base64
        import hashlib
        import hmac
        import struct
        import binascii
        import csv
        import json
        import xml.etree.ElementTree
        import xml.dom.minidom
        import xml.sax.saxutils
        import socket
        import ssl
        import smtplib


# Generated at 2022-06-18 00:15:56.710082
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'

# Generated at 2022-06-18 00:16:01.605537
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.ast_helper import compare_ast
    from ..utils.ast_helper import parse_ast
    from ..utils.ast_helper import parse_source
    from ..utils.ast_helper import source_to_ast
    from ..utils.ast_helper import source_to_str


# Generated at 2022-06-18 00:16:07.247039
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals


    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True

# Generated at 2022-06-18 00:16:17.111791
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from .python2future import Python2FutureTransformer
    from .python2future import imports
    from .python2future import test_Python2FutureTransformer_visit_Module
    from .python2future import test_Python2FutureTransformer_visit_Module_without_future
    from .python2future import test_Python2FutureTransformer_visit_Module_with_future
    from .python2future import test_Python2FutureTransformer_visit_Module_with_future_and_import
    from .python2future import test_Python2FutureTransformer_visit_Module_with_future_and_import_from
    from .python2future import test_Python2FutureTransformer_visit_Module

# Generated at 2022-06-18 00:16:23.365051
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True

# Generated at 2022-06-18 00:16:30.359852
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__')

# Generated at 2022-06-18 00:16:40.192735
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source
    from ..utils.ast import get_ast, compare_asts


# Generated at 2022-06-18 00:16:45.606480
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source
    from ..utils.ast import get_ast, compare_asts
    from ..utils.visitor import NodeVisitor
    from ..utils.snippet import snippet

    @snippet
    def before():
        def f():
            pass

    @snippet
    def after():
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        def f():
            pass

    visitor = NodeVisitor()
    visitor.add_transformer(Python2FutureTransformer)
    ast_before = get_ast(source(before))
    ast_after = get_ast(source(after))
    visitor.visit(ast_before)

# Generated at 2022-06-18 00:18:09.558018
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.snippet import snippet

    @snippet
    def code():
        def f():
            pass

    expected = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    def f():
        pass
    """

    tree = ast.parse(code.get_code())
    Python2FutureTransformer().visit(tree)
    assert ast_to_str(tree) == expected

# Generated at 2022-06-18 00:18:17.414540
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_inspector import ASTInspector
    from ..utils.ast_inspector import ast_inspector
    from ..utils.ast_inspector import ast_inspector_visit
    from ..utils.ast_inspector import ast_inspector_visit_children
    from ..utils.ast_inspector import ast_inspector_visit_children_recursive
    from ..utils.ast_inspector import ast_inspector_visit_recursive
    from ..utils.ast_inspector import ast_inspector_visit_recursive_with_children
    from ..utils.ast_inspector import ast_inspector_visit_with_children
    from ..utils.ast_inspector import ast_ins