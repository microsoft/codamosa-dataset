

# Generated at 2022-06-18 00:08:08.797741
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)


# Generated at 2022-06-18 00:08:18.949777
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from .python2future import Python2FutureTransformer
    from .python2future import imports
    import astor
    import textwrap
    import unittest

    class TestPython2FutureTransformer(unittest.TestCase):
        def test_visit_Module(self):
            @snippet
            def module():
                def f():
                    pass
            module_node = ast.parse(module.get_source())
            transformer = Python2FutureTransformer()
            module_node = transformer.visit(module_node)
            self.assertTrue(transformer._tree_changed)

# Generated at 2022-06-18 00:08:29.251639
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_test_module
    from ..utils.visitor import dump_ast
    from ..utils.visitor import dump_source
    from ..utils.visitor import dump_tokens
    from ..utils.visitor import dump_types
    from ..utils.visitor import dump_symbols
    from ..utils.visitor import dump_symbols_by_lineno
    from ..utils.visitor import dump_symbols_by_type
    from ..utils.visitor import dump_symbols_by_scope
    from ..utils.visitor import dump_symbols_by_scope_type
    from ..utils.visitor import dump_symbols_by_scope_type_and_lineno
    from ..utils.visitor import dump_symbols_by_scope_type_and

# Generated at 2022-06-18 00:08:39.385996
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_code
    from ..utils.source import source_to_tokens
    from ..utils.source import source_to_tree
    from ..utils.source import source_to_visit
    from ..utils.visitor import print_visit
    from ..utils.visitor import visit_ast
    from ..utils.visitor import visit_tree


# Generated at 2022-06-18 00:08:50.608383
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source
    from ..utils.compare_ast import compare_ast
    from ..utils.visitor import dump_tree

    source = source('''
        def foo():
            pass
    ''')
    tree = ast.parse(source)
    Python2FutureTransformer().visit(tree)
    print(dump_tree(tree))

# Generated at 2022-06-18 00:08:51.895395
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'

# Generated at 2022-06-18 00:09:02.404796
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import get_ast
    from ..utils.test_utils import get_ast_node
    from ..utils.test_utils import get_source
    from ..utils.test_utils import get_source_node

    source = get_source(Python2FutureTransformer)
    expected = get_source(imports) + source
    tree = get_ast(source)
    node = get_ast_node(tree, Python2FutureTransformer)
    transformer = Python2FutureTransformer()
    new_node = transformer.visit(node)
    assert_equal_ast(new_node, get_ast(expected))

# Generated at 2022-06-18 00:09:10.347711
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.ast_helper import str_to_ast

    tree = str_to_ast("""
    def foo():
        pass
    """)
    transformer = Python2FutureTransformer()
    transformer.visit(tree)
    assert ast_to_str(tree) == """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    def foo():
        pass
    """

# Generated at 2022-06-18 00:09:20.639100
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer.target == (2, 7)
    assert Python2FutureTransformer.__doc__ == """Prepends module with:
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
            
    """
    assert Python2FutureTransformer.visit_Module.__doc__ == """Prepends module with:
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
            
    """
    assert Python2FutureTransformer.visit_Module.__name__ == 'visit_Module'
    assert Python2FutureTrans

# Generated at 2022-06-18 00:09:32.444410
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source
    from ..utils.ast import get_ast, compare_asts
    from ..utils.visitor import dump_ast

    source_1 = """
    import os
    import sys
    """
    source_2 = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    import os
    import sys
    """
    module_1 = get_ast(source_1)
    module_2 = get_ast(source_2)
    transformer = Python2FutureTransformer()
    new_module = transformer.visit(module_1)
    assert compare_asts(module_1, module_2)
    assert transformer.tree_changed is True

# Generated at 2022-06-18 00:09:42.719140
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from ..utils.source import source
    from ..utils.ast import compare_ast

    @snippet
    def before(future):
        pass

    @snippet
    def after(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    source_ = source(before)
    tree = ast.parse(source_)

    transformer = Python2FutureTransformer()
    new_tree = transformer.visit(tree)

    expected_tree = ast.parse(source(after))

    assert compare_ast(new_tree, expected_tree)

# Generated at 2022-06-18 00:09:50.996973
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from .base import BaseNodeTransformer
    from .python2_future import Python2FutureTransformer
    from .python2_print import Python2PrintTransformer
    from .python2_unicode import Python2UnicodeTransformer
    from .python2_division import Python2DivisionTransformer
    from .python2_absolute_import import Python2AbsoluteImportTransformer
    from .python2_relative_import import Python2RelativeImportTransformer
    from .python2_raise import Python2RaiseTransformer
    from .python2_non_keyword_arguments import Python2NonKeywordArgumentsTransformer
    from .python2_metaclass import Python2MetaclassTransformer
    from .python2_long import Python

# Generated at 2022-06-18 00:09:52.866753
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer.target == (2, 7)
    assert Python2FutureTransformer.__doc__ is not None


# Generated at 2022-06-18 00:09:58.227346
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer.target == (2, 7)
    assert Python2FutureTransformer.__doc__ == """Prepends module with:
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
            
    """


# Generated at 2022-06-18 00:10:05.337061
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from .python2_future import Python2FutureTransformer
    from ..utils.source import source

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    @snippet
    def module():
        import os
        import sys

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)


# Generated at 2022-06-18 00:10:14.235999
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer.target == (2, 7)
    assert Python2FutureTransformer.__doc__ is not None
    assert Python2FutureTransformer.visit_Module.__doc__ is not None
    assert Python2FutureTransformer.generic_visit.__doc__ is not None
    assert Python2FutureTransformer.visit_Module.__annotations__ == {'node': ast.Module, 'return': ast.Module}
    assert Python2FutureTransformer.generic_visit.__annotations__ == {'node': ast.AST, 'return': ast.AST}
    assert Python2FutureTransformer.visit_Module.__module__ == Python2FutureTransformer.__module__

# Generated at 2022-06-18 00:10:24.233870
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_test_module
    from ..utils.visitor import dump_ast
    from ..utils.visitor import dump_source
    from ..utils.visitor import visit_and_dump
    from ..utils.visitor import visit_and_dump_source
    from ..utils.visitor import visit_and_dump_source_and_ast
    from ..utils.visitor import visit_and_dump_source_and_ast_and_code
    from ..utils.visitor import visit_and_dump_source_and_code
    from ..utils.visitor import visit_and_dump_source_and_code_and_ast
    from ..utils.visitor import visit_and_dump_source_and_code_and_ast_and_source
    from ..utils.visitor import visit_and_dump_source

# Generated at 2022-06-18 00:10:28.138027
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer.target == (2, 7)
    assert isinstance(Python2FutureTransformer(), Python2FutureTransformer)


# Generated at 2022-06-18 00:10:32.123814
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer.target == (2, 7)
    assert isinstance(Python2FutureTransformer(), Python2FutureTransformer)


# Generated at 2022-06-18 00:10:40.311595
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals


    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True

# Generated at 2022-06-18 00:10:51.999107
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source
    from ..utils.ast import get_ast

    source_code = source(imports)
    tree = get_ast(source_code)
    transformer = Python2FutureTransformer()
    new_tree = transformer.visit(tree)
    assert transformer._tree_changed is True
    assert len(new_tree.body) == 8
    assert new_tree.body[0].names[0].name == 'absolute_import'
    assert new_tree.body[1].names[0].name == 'division'
    assert new_tree.body[2].names[0].name == 'print_function'
    assert new_tree.body[3].names[0].name == 'unicode_literals'

# Generated at 2022-06-18 00:10:57.717837
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer.target == (2, 7)
    assert Python2FutureTransformer.__doc__ == 'Prepends module with:\n    from __future__ import absolute_import\n    from __future__ import division\n    from __future__ import print_function\n    from __future__ import unicode_literals\n        \n    '


# Generated at 2022-06-18 00:11:05.858998
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def code(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals
        print('hello')

    @snippet
    def expected(future):
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        print('hello')

    tree = ast.parse(code.get_source())
    transformer = Python2FutureTransformer()
    tree = transformer.visit(tree)
    assert ast_to_

# Generated at 2022-06-18 00:11:16.018425
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.ast_helper import compare_ast
    from ..utils.ast_helper import get_ast
    from ..utils.ast_helper import get_source
    from ..utils.ast_helper import parse_ast
    from ..utils.ast_helper import parse_source
    from ..utils.ast_helper import run_ast
    from ..utils.ast_helper import run_source
    from ..utils.ast_helper import transform_ast
    from ..utils.ast_helper import transform_source
    from ..utils.ast_helper import visit_ast
    from ..utils.ast_helper import visit_source
    from ..utils.ast_helper import wrap_ast

# Generated at 2022-06-18 00:11:25.760161
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from .python2future import Python2FutureTransformer
    from ..utils.source import source

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    @snippet
    def module():
        pass

    node = ast.parse(source(module))
    transformer = Python2FutureTransformer()
    transformer.visit(node)
    assert source(node) == source(imports(future='__future__')) + source(module)

# Generated at 2022-06-18 00:11:32.486039
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import assert_source_equal
    from ..utils.test_utils import get_ast

    source = """
    import os
    import sys
    """
    expected = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    import os
    import sys
    """
    tree = get_ast(source)
    transformer = Python2FutureTransformer()
    new_tree = transformer.visit(tree)
    assert_source_equal(expected, new_tree)

# Generated at 2022-06-18 00:11:42.447620
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.visitor import visit
    from ..utils.visitor import visit_children
    from ..utils.visitor import visit_children_with_parent
    from ..utils.visitor import visit_with_parent
    from ..utils.visitor import visit_with_parents
    from ..utils.visitor import visit_with_parents_and_siblings
    from ..utils.visitor import visit_with_siblings
    from ..utils.visitor import visit_with_siblings_and_parent
    from ..utils.visitor import visit_with_siblings_and_parents
    from ..utils.visitor import visit_with_siblings_parents_and_children
    from ..utils.visitor import visit_with_siblings_parents_and_children_

# Generated at 2022-06-18 00:11:53.228204
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    from ..utils.ast_builder import build_ast
    from ..utils.ast_visitor import ASTVisitor
    from ..utils.ast_transformer import ASTTransformer
    from ..utils.ast_transformer import ASTTransformerError
    from ..utils.ast_transformer import ASTTransformerTypeError
    from ..utils.ast_transformer import ASTTransformerValueError
    from ..utils.ast_transformer import ASTTransformerRecursionError
    from ..utils.ast_transformer import ASTTransformerIndexError
    from ..utils.ast_transformer import ASTTransformerKeyError
    from ..utils.ast_transformer import ASTTransformerAttributeError
    from ..utils.ast_transformer import ASTTransformerRuntimeError
    from ..utils.ast_transformer import ASTTransformerNotImplementedError


# Generated at 2022-06-18 00:11:56.787590
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer.target == (2, 7)
    assert isinstance(Python2FutureTransformer(), Python2FutureTransformer)


# Generated at 2022-06-18 00:11:58.769571
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer(None).target == (2, 7)


# Generated at 2022-06-18 00:12:15.484259
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source
    from ..utils.visitor import dump_AST
    from ..utils.visitor import dump_source

    source_code = source(
        """
        def foo():
            pass
        """
    )
    tree = ast.parse(source_code)
    assert dump_AST(tree) == dump_source(source_code)

    transformer = Python2FutureTransformer()
    transformer.visit(tree)
    assert dump_AST(tree) == dump_source(
        """
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        def foo():
            pass
        """
    )

# Generated at 2022-06-18 00:12:24.678008
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
           

# Generated at 2022-06-18 00:12:35.518940
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from ..utils.ast_helper import ast_to_source
    from .base import BaseNodeTransformer
    from .python2future import Python2FutureTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    @snippet
    def test_module():
        pass

    @snippet
    def test_module_with_imports():
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals


# Generated at 2022-06-18 00:12:41.457189
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.snippet import snippet

    @snippet
    def code():
        print('Hello world!')

    tree = ast.parse(code.get_source())
    Python2FutureTransformer().visit(tree)
    assert ast_to_str(tree) == imports.get_source(future='__future__') + code.get_source()

# Generated at 2022-06-18 00:12:51.690344
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_tree_changed
    from ..utils.test_utils import assert_tree_not_changed
    from ..utils.test_utils import get_ast
    from ..utils.test_utils import get_source
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import parse_source

    # Test constructor
    transformer = Python2FutureTransformer()
    assert_equal_source(transformer.target, (2, 7))

    # Test visit_Module
    source = '''
    import os
    import sys
    import math
    '''

# Generated at 2022-06-18 00:13:02.215881
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
           

# Generated at 2022-06-18 00:13:12.561927
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__')

# Generated at 2022-06-18 00:13:19.217629
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer.target == (2, 7)
    assert Python2FutureTransformer.__doc__ == """Prepends module with:
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
            
    """


# Generated at 2022-06-18 00:13:25.048290
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source
    from ..utils.visitor import print_python_source
    from ..utils.visitor import visit_ast

    source_code = source('''
    def foo():
        pass
    ''')
    tree = ast.parse(source_code)
    visit_ast(tree)
    transformer = Python2FutureTransformer()
    transformer.visit(tree)
    print_python_source(tree)

# Generated at 2022-06-18 00:13:34.198056
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import get_ast
    from ..utils.test_utils import get_source
    from ..utils.test_utils import get_tree
    from ..utils.test_utils import parse_ast

    source = get_source(__file__)
    tree = get_tree(__file__)
    ast_module = parse_ast(source)
    assert_equal_ast(ast_module, tree)

    transformer = Python2FutureTransformer()
    ast_module = transformer.visit(ast_module)
    assert transformer._tree_changed
    assert_equal_ast(ast_module, get_ast(__file__, '2'))

    source = get_source(__file__, '2')

# Generated at 2022-06-18 00:13:53.916250
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    from ..utils.source import source
    from ..utils.ast_factory import ast_factory
    from ..utils.ast_source import ast_source
    from ..utils.ast_dump import ast_dump
    from ..utils.ast_compare import ast_compare

    source_code = source(
        """
        def foo():
            pass
        """
    )

# Generated at 2022-06-18 00:13:56.904688
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.test_utils import check_node_transformer
    check_node_transformer(Python2FutureTransformer)

# Generated at 2022-06-18 00:14:07.385041
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.source import source_to_ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def source():
        a = 1
        b = 2
        c = 3

    @snippet
    def expected():
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        a = 1
        b = 2
        c = 3

    node = source_to_ast(source)
    transformer = Python2FutureTransformer()
    transformer.visit(node)
    assert ast.dump(node) == ast.dump(source_to_ast(expected))

# Generated at 2022-06-18 00:14:09.419982
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source

    source = source(imports)
    assert source == '''\
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
'''

# Generated at 2022-06-18 00:14:20.195207
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals


    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True

# Generated at 2022-06-18 00:14:29.922166
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from .python2_future_transformer import Python2FutureTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    @snippet
    def code():
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        def foo():
            pass

    tree = ast.parse(code.get_source())
    transformer = Python2FutureTransformer()
    transformer.visit(tree)
    assert transformer._tree_changed
    assert ast.dump

# Generated at 2022-06-18 00:14:40.790366
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_inspector import ASTInspector
    from ..utils.ast_inspector import assert_ast_equal
    from ..utils.ast_inspector import assert_ast_not_equal

    # Test 1:
    #   module = ast.Module(body=[ast.Expr(value=ast.Str(s='Hello'))])
    #   Python2FutureTransformer().visit(module)
    #   module.body[0].value.s == 'Hello'
    #   module.body[1].value.s == 'Hello'
    module = ast.Module(body=[ast.Expr(value=ast.Str(s='Hello'))])
    Python2FutureTransformer().visit(module)

# Generated at 2022-06-18 00:14:44.121976
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source

    source = source(imports)
    assert source == '''
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
'''

# Generated at 2022-06-18 00:14:53.446076
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet

    @snippet
    def test_module():
        pass

    transformer = Python2FutureTransformer()
    module = test_module.get_ast()
    transformer.visit(module)
    assert transformer.tree_changed
    assert module.body[0].value.s == '__future__'
    assert module.body[1].value.s == '__future__'
    assert module.body[2].value.s == '__future__'
    assert module.body[3].value.s == '__future__'

# Generated at 2022-06-18 00:14:59.790737
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer.target == (2, 7)
    assert Python2FutureTransformer.__doc__ is not None
    assert Python2FutureTransformer.visit_Module.__doc__ is not None
    assert Python2FutureTransformer.visit_Module.__annotations__ == {'node': ast.Module, 'return': ast.Module}
    assert Python2FutureTransformer.visit_Module.__module__ == __name__
    assert Python2FutureTransformer.visit_Module.__name__ == 'visit_Module'
    assert Python2FutureTransformer.visit_Module.__qualname__ == 'Python2FutureTransformer.visit_Module'


# Generated at 2022-06-18 00:15:36.955912
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    from ..utils.source import source
    from ..utils.ast import dump_ast
    from ..utils.snippet import snippet

    @snippet
    def source_code():
        print("Hello, world!")

    tree = ast.parse(source_code.get_source())
    Python2FutureTransformer().visit(tree)
    assert source(dump_ast(tree)) == source(imports(future='__future__') + source_code)

# Generated at 2022-06-18 00:15:38.512509
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)
    assert transformer.visit_Module(ast.parse('pass')) == ast.parse(imports.get_source(future='__future__') + 'pass')

# Generated at 2022-06-18 00:15:40.267820
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)
    assert transformer.visit_Module(ast.parse('pass')) == ast.parse(imports.get_source(future='__future__') + 'pass')

# Generated at 2022-06-18 00:15:47.504951
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_code
    from ..utils.source import source_to_tokens
    from ..utils.source import source_to_token_types
    from ..utils.source import source_to_token_names
    from ..utils.source import source_to_token_values
    from ..utils.source import source_to_token_start_positions
    from ..utils.source import source_to_token_end_positions
    from ..utils.source import source_to_token_line_numbers
    from ..utils.source import source_to_token_column_numbers
    from ..utils.source import source_to_token_line_offsets
    from ..utils.source import source_to_token_column_offsets

# Generated at 2022-06-18 00:15:57.400883
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__')

# Generated at 2022-06-18 00:16:02.587492
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals


    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True

# Generated at 2022-06-18 00:16:14.636652
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
           

# Generated at 2022-06-18 00:16:15.821986
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'

# Generated at 2022-06-18 00:16:22.707383
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import get_ast
    from ..utils.test_utils import get_ast_node
    from ..utils.test_utils import get_source
    from ..utils.test_utils import get_source_node
    from ..utils.test_utils import get_target_ast
    from ..utils.test_utils import get_target_source

    source = get_source(__file__, 'test_Python2FutureTransformer_visit_Module')
    target = get_target_source(__file__, 'test_Python2FutureTransformer_visit_Module')
    source_ast = get_ast(source)
    target_ast = get_target_ast(target)
    transformer = Python2FutureTransformer()
    result_ast = transformer.vis

# Generated at 2022-06-18 00:16:29.764456
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source
    from ..utils.ast import get_ast, compare_asts

    source = source('''
        import os
        import sys
        import math
        import random
    ''')
    expected = source('''
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        import os
        import sys
        import math
        import random
    ''')

    module = get_ast(source)
    module = Python2FutureTransformer().visit(module)
    expected = get_ast(expected)

    assert compare_asts(module, expected)

# Generated at 2022-06-18 00:18:01.603431
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from .python2future import Python2FutureTransformer
    from .python2future import imports
    from .python2future import test_Python2FutureTransformer_visit_Module
    from .python2future import test_Python2FutureTransformer_visit_Module_1
    from .python2future import test_Python2FutureTransformer_visit_Module_2
    from .python2future import test_Python2FutureTransformer_visit_Module_3
    from .python2future import test_Python2FutureTransformer_visit_Module_4
    from .python2future import test_Python2FutureTransformer_visit_Module_5
    from .python2future import test_Python2FutureTransformer_

# Generated at 2022-06-18 00:18:05.014459
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Test for constructor of class Python2FutureTransformer"""
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer.target == (2, 7)
