

# Generated at 2022-06-18 00:08:15.227170
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_test_module
    from ..utils.visitor import dump_ast
    from ..utils.visitor import dump_source
    from ..utils.visitor import visit_and_dump_ast
    from ..utils.visitor import visit_and_dump_source

    module = make_test_module()
    module = visit_and_dump_ast(module, Python2FutureTransformer)
    module = visit_and_dump_source(module, Python2FutureTransformer)
    module = visit_and_dump_ast(module, Python2FutureTransformer)
    module = visit_and_dump_source(module, Python2FutureTransformer)

# Generated at 2022-06-18 00:08:20.703683
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_source_equal
    from .test_base import BaseNodeTransformerTestCase

    class Test(BaseNodeTransformerTestCase):
        transformer = Python2FutureTransformer

        def test_simple(self):
            tree = ast.parse("print('Hello, world!')")
            self.check_tree(tree)

    test = Test()
    test.test_simple()

# Generated at 2022-06-18 00:08:29.544728
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_source_equal
    from ..utils.test_utils import get_ast

    source = '''
    def foo():
        pass
    '''
    expected = '''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    def foo():
        pass
    '''
    tree = get_ast(source)
    transformer = Python2FutureTransformer()
    new_tree = transformer.visit(tree)  # type: ignore
    assert_source_equal(expected, new_tree)

# Generated at 2022-06-18 00:08:38.229380
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.fake import fake
    from ..utils.source import source
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    @snippet
    def module():
        pass

    node = ast.parse(source(module))
    transformer = Python2FutureTransformer()
    transformer.visit(node)
    assert source(node) == source(imports(future='__future__') + module)

# Generated at 2022-06-18 00:08:45.584332
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import assert_source

    source = """
    import os
    import sys
    """
    expected = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    import os
    import sys
    """
    tree = ast.parse(source)
    Python2FutureTransformer().visit(tree)
    assert_source(tree, expected)

# Generated at 2022-06-18 00:08:54.458546
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    import astor
    import textwrap
    import sys
    import io
    from contextlib import redirect_stdout
    from contextlib import redirect_stderr
    from contextlib import contextmanager
    from contextlib import ExitStack
    from contextlib import suppress
    from contextlib import nullcontext
    from contextlib import closing
    from contextlib import AbstractContextManager
    from contextlib import AbstractAsyncContextManager
    from contextlib import asynccontextmanager
    from contextlib import redirect_stdout
    from contextlib import redirect_stderr
    from contextlib import suppress
    from contextlib import nullcontext
    from contextlib import closing
    from contextlib import AbstractContextManager
    from contextlib import AbstractAsync

# Generated at 2022-06-18 00:09:04.075162
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_test_module
    from ..utils.visitor import dump_ast
    from ..utils.visitor import dump_source
    from ..utils.visitor import dump_tokens
    from ..utils.visitor import dump_types
    from ..utils.visitor import dump_symbols
    from ..utils.visitor import dump_scope
    from ..utils.visitor import dump_scope_tree
    from ..utils.visitor import dump_scope_tree_graph
    from ..utils.visitor import dump_scope_tree_graph_svg
    from ..utils.visitor import dump_scope_tree_graph_png
    from ..utils.visitor import dump_scope_tree_graph_pdf
    from ..utils.visitor import dump_scope_tree_graph_dot

# Generated at 2022-06-18 00:09:09.348666
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from ..utils.source import source

    @snippet
    def code():
        pass

    node = ast.parse(source(code))
    Python2FutureTransformer().visit(node)
    assert source(node) == source(imports) + source(code)

# Generated at 2022-06-18 00:09:19.586085
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    from ..utils.ast_helper import ast_load, ast_dump
    from ..utils.ast_helper import ast_store, ast_equal
    from ..utils.ast_helper import ast_load_code, ast_dump_code
    from ..utils.ast_helper import ast_store_code, ast_equal_code

    code = """
    def foo():
        pass
    """
    expected = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    def foo():
        pass
    """
    tree = ast_load_code(code)
    transformer = Python2FutureTransformer()
    tree = transformer.visit(tree)
    assert transformer._tree_changed
   

# Generated at 2022-06-18 00:09:30.713253
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__')

# Generated at 2022-06-18 00:09:44.138460
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    from ..utils.source import source
    from ..utils.ast_factory import ast_factory
    from ..utils.source import source
    from ..utils.ast_factory import ast_factory
    from ..utils.source import source
    from ..utils.ast_factory import ast_factory
    from ..utils.source import source
    from ..utils.ast_factory import ast_factory
    from ..utils.source import source
    from ..utils.ast_factory import ast_factory
    from ..utils.source import source
    from ..utils.ast_factory import ast_factory
    from ..utils.source import source
    from ..utils.ast_factory import ast_factory
    from ..utils.source import source
    from ..utils.ast_factory import ast

# Generated at 2022-06-18 00:09:51.551107
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import transform, compare_ast
    from .base import BaseNodeTransformer
    from .python2_future import Python2FutureTransformer
    from ..utils.snippet import snippet

    @snippet
    def code():
        a = 1
        b = 2
        c = 3

    @snippet
    def expected():
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        a = 1
        b = 2
        c = 3

    tree = ast.parse(code.get_source())
    tree = transform(tree, Python2FutureTransformer)
    compare_ast(tree, expected.get_ast())

# Generated at 2022-06-18 00:10:00.541445
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__')

# Generated at 2022-06-18 00:10:06.498790
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from .test_base import BaseNodeTransformerTestCase
    from .test_base import wrap_in_module

    class Test(BaseNodeTransformerTestCase):
        transformer = Python2FutureTransformer
        target = (2, 7)
        code_before = """
            x = 1
            y = 2
        """
        code_after = """
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
            x = 1
            y = 2
        """

    wrap_in_module(Test)

# Generated at 2022-06-18 00:10:11.461565
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source
    from ..utils.ast import get_ast, compare_ast
    from ..utils.future import future

    source_ = source(imports(future='__future__'))
    ast_ = get_ast(source_)
    Python2FutureTransformer().visit(ast_)
    assert compare_ast(ast_, get_ast(future(2, 7)))

# Generated at 2022-06-18 00:10:21.567095
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.ast_helper import get_ast_from_snippet
    from ..utils.ast_helper import get_ast_from_source
    from ..utils.ast_helper import get_source_from_ast
    from ..utils.ast_helper import get_source_from_snippet
    from ..utils.ast_helper import get_source_from_source
    from ..utils.ast_helper import get_ast_from_ast
    from ..utils.ast_helper import get_source_from_source
    from ..utils.ast_helper import get_source_from_source
    from ..utils.ast_helper import get_source

# Generated at 2022-06-18 00:10:24.990933
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import assert_ast_equal
    from ..utils.ast_helper import get_ast
    from ..utils.ast_helper import get_source


# Generated at 2022-06-18 00:10:35.243740
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_builder import build_ast
    from ..utils.source import source
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from .python2future import Python2FutureTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    @snippet
    def module():
        pass

    @snippet
    def module_with_imports():
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    @snippet
    def module_with_imports_and_code():
        from future import absolute

# Generated at 2022-06-18 00:10:45.569009
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__')

# Generated at 2022-06-18 00:10:52.864532
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_dummy_future_transformer
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_module
    from ..utils.source import source_to_code
    from ..utils.source import source_to_function
    from ..utils.source import source_to_class
    from ..utils.source import source_to_expression
    from ..utils.source import source_to_interactive
    from ..utils.source import source_to_suite
    from ..utils.source import source_to_statement
    from ..utils.source import source_to_annassign
    from ..utils.source import source_to_arguments
    from ..utils.source import source_to_arg
    from ..utils.source import source_to_alias

# Generated at 2022-06-18 00:11:02.963565
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_test_module
    from ..utils.visitor import dump_ast

    module = make_test_module(
        """
        def foo():
            pass
        """,
        target=(2, 7)
    )
    transformer = Python2FutureTransformer()
    transformer.visit(module)

# Generated at 2022-06-18 00:11:13.078092
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
           

# Generated at 2022-06-18 00:11:24.003354
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source_to_ast
    from ..utils.visitor import print_ast
    from ..utils.visitor import compare_ast
    from ..utils.source import source_to_code
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_code
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_code
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_code
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_code
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_code
    from ..utils.source import source_to_ast

# Generated at 2022-06-18 00:11:32.485979
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    @snippet
    def module():
        pass

    node = ast.parse(module.get_source())
    transformer = Python2FutureTransformer()
    transformer.visit(node)
    assert ast_to_str(node) == imports.get_source(future='__future__') + module.get_source()

# Generated at 2022-06-18 00:11:33.669424
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.target == (2, 7)


# Generated at 2022-06-18 00:11:42.041953
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source
    from ..utils.ast import get_ast, compare_asts

    source_1 = """
    def foo():
        pass
    """
    expected_1 = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    def foo():
        pass
    """
    tree_1 = get_ast(source_1)
    new_tree_1 = Python2FutureTransformer().visit(tree_1)
    assert compare_asts(new_tree_1, get_ast(expected_1))

# Generated at 2022-06-18 00:11:53.194815
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from ..utils.source import source
    from ..utils.source import SourceMap
    from ..utils.source import SourceRange
    from ..utils.source import SourcePosition

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    @snippet
    def module():
        pass

    source_map = SourceMap()
    source_map.add_snippet(imports, 'imports')
    source_map.add_snippet(module, 'module')
    source_map.add_source(source(__file__))


# Generated at 2022-06-18 00:11:54.953295
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)

# Generated at 2022-06-18 00:12:04.308889
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_test_module
    from ..utils.visitor import dump_ast
    from ..utils.visitor import dump_source
    from ..utils.visitor import dump_tokens
    from ..utils.visitor import dump_types
    from ..utils.visitor import dump_symbols
    from ..utils.visitor import dump_scope
    from ..utils.visitor import dump_scope_tree
    from ..utils.visitor import dump_scope_tree_graph
    from ..utils.visitor import dump_scope_tree_graph_png
    from ..utils.visitor import dump_scope_tree_graph_svg
    from ..utils.visitor import dump_scope_tree_graph_pdf
    from ..utils.visitor import dump_scope_tree_graph_dot

# Generated at 2022-06-18 00:12:11.051902
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.ast_helper import compare_ast
    from ..utils.ast_helper import parse_ast
    from ..utils.ast_helper import get_ast_node_name
    from ..utils.ast_helper import get_ast_node_type
    from ..utils.ast_helper import get_ast_node_lineno
    from ..utils.ast_helper import get_ast_node_col_offset
    from ..utils.ast_helper import get_ast_node_end_lineno
    from ..utils.ast_helper import get_ast_node_end_col_offset
    from ..utils.ast_helper import get_ast_node_body

# Generated at 2022-06-18 00:12:25.343515
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source
    from ..utils.ast import get_ast, compare_asts
    from ..utils.visitor import dump_tree
    from ..utils.snippet import snippet

    @snippet
    def source_code():
        import os
        import sys
        import math
        import random
        import string

    expected_code = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    import os
    import sys
    import math
    import random
    import string
    """

    source_ast = get_ast(source(source_code))
    expected_ast = get_ast(source(expected_code))
    transformer = Python2FutureTransformer()

# Generated at 2022-06-18 00:12:35.647750
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source
    from ..utils.ast import get_ast, compare_asts

    source_1 = """
    import os
    import sys
    import math
    """
    expected_1 = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    import os
    import sys
    import math
    """
    source_2 = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    import os
    import sys
    import math
    """

# Generated at 2022-06-18 00:12:46.069446
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.ast_helper import compare_ast
    from ..utils.ast_helper import get_ast
    from ..utils.ast_helper import get_source

    source = """
    def f(x):
        return x + 1
    """
    expected = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    
    def f(x):
        return x + 1
    """
    tree = get_ast(source)
    transformer = Python2FutureTransformer()
    tree = transformer.visit(tree)

# Generated at 2022-06-18 00:12:52.119863
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)
    assert transformer.visit_Module.__name__ == 'visit_Module'
    assert transformer.visit_Module.__doc__ == 'Prepends module with:\n        from __future__ import absolute_import\n        from __future__ import division\n        from __future__ import print_function\n        from __future__ import unicode_literals\n            \n    '
    assert transformer._tree_changed == False


# Generated at 2022-06-18 00:12:56.328149
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source
    from ..utils.ast import dump
    from ..utils.visitor import NodeVisitor

    src = source(imports)
    tree = ast.parse(src)
    visitor = NodeVisitor()
    visitor.visit(tree)
    transformer = Python2FutureTransformer()
    transformer.visit(tree)
    print(dump(tree))
    assert transformer._tree_changed is True

# Generated at 2022-06-18 00:12:57.705466
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'


# Generated at 2022-06-18 00:13:08.374109
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from .python2future import Python2FutureTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    @snippet
    def module():
        import os
        import sys

    @snippet
    def expected():
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        import os
        import sys

    node = ast.parse(module.get_source())
   

# Generated at 2022-06-18 00:13:18.326471
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__')

# Generated at 2022-06-18 00:13:23.126090
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)
    assert transformer.visit_Module(ast.parse('a = 1')) == ast.parse(imports.get_source(future='__future__') + 'a = 1')

# Generated at 2022-06-18 00:13:32.319376
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_code
    from ..utils.source import source_to_tokens
    from ..utils.source import source_to_tree

    source = """
    def foo():
        pass
    """
    expected = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    
    def foo():
        pass
    """
    tree = source_to_tree(source)
    assert tree is not None
    transformer = Python2FutureTransformer()
    new_tree = transformer.visit(tree)
    assert new_tree is not None
    assert transformer._tree_changed is True

# Generated at 2022-06-18 00:13:54.625020
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_test_module
    from ..utils.source import source_to_unicode

    module = make_test_module(
        """
        def foo():
            pass
        """,
        target=(2, 7),
    )
    transformer = Python2FutureTransformer()
    transformer.visit(module)
    assert source_to_unicode(module) == source_to_unicode(
        """
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        def foo():
            pass
        """
    )

# Generated at 2022-06-18 00:14:00.532094
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer.target == (2, 7)
    assert Python2FutureTransformer.__doc__ == 'Prepends module with:\n    from __future__ import absolute_import\n    from __future__ import division\n    from __future__ import print_function\n    from __future__ import unicode_literals\n        \n    '


# Generated at 2022-06-18 00:14:07.385124
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source

    code = """
    def foo():
        pass
    """
    tree = ast.parse(code)
    Python2FutureTransformer().visit(tree)
    assert source(tree) == """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    def foo():
        pass
    """

# Generated at 2022-06-18 00:14:11.611758
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer.target == (2, 7)
    assert Python2FutureTransformer.__doc__ == """Prepends module with:
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
            
    """


# Generated at 2022-06-18 00:14:13.191966
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.target == (2, 7)


# Generated at 2022-06-18 00:14:23.181780
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_test_module
    from ..utils.visitor import dump_ast

    module = make_test_module(
        """
        def f():
            pass
        """,
        target=(2, 7),
    )
    transformer = Python2FutureTransformer()
    transformer.visit(module)
    assert transformer._tree_changed

# Generated at 2022-06-18 00:14:31.945409
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.test_utils import assert_ast_equal

    @snippet
    def before():
        pass

    @snippet
    def after():
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        pass

    node = before.get_ast()
    expected = after.get_ast()
    transformer = Python2FutureTransformer()
    actual = transformer.visit(node)
    assert_ast_equal(expected, actual)
    assert transformer._tree_changed == True

# Generated at 2022-06-18 00:14:43.299031
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.test_utils import assert_source


# Generated at 2022-06-18 00:14:48.418666
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
           

# Generated at 2022-06-18 00:14:57.840458
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
           

# Generated at 2022-06-18 00:15:35.694912
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import assert_source

    source = """
    def foo():
        pass
    """
    expected = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    def foo():
        pass
    """
    tree = ast.parse(source)
    Python2FutureTransformer().visit(tree)
    assert_source(tree, expected)

# Generated at 2022-06-18 00:15:37.105085
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'


# Generated at 2022-06-18 00:15:38.339388
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'

# Generated at 2022-06-18 00:15:41.383118
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.source import source
    from ..utils.ast_source import ast_source
    from ..utils.ast_compare import compare_ast

    source_code = source(imports)
    expected_ast = ast.parse(source_code)
    actual_ast = ast.parse(source_code)
    actual_ast = Python2FutureTransformer().visit(actual_ast)
    assert compare_ast(expected_ast, actual_ast)

# Generated at 2022-06-18 00:15:43.253712
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)


# Generated at 2022-06-18 00:15:51.074337
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)
    assert transformer.visit_Module.__name__ == 'visit_Module'
    assert transformer.visit_Module.__doc__ == 'Prepends module with:\n    from __future__ import absolute_import\n    from __future__ import division\n    from __future__ import print_function\n    from __future__ import unicode_literals\n        \n'


# Generated at 2022-06-18 00:16:00.063996
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
           

# Generated at 2022-06-18 00:16:10.030354
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from .python2futuretransformer import Python2FutureTransformer
    from .python2futuretransformer import imports
    import astor
    import textwrap
    import unittest

    class TestPython2FutureTransformer(unittest.TestCase):
        def test_visit_Module(self):
            @snippet
            def test_snippet():
                import sys
                import os
                import re
                import time
                import datetime
                import math
                import random
                import base64
                import binascii
                import json
                import hashlib
                import hmac
                import collections
                import contextlib
                import functools
                import itertools
                import operator
               

# Generated at 2022-06-18 00:16:18.733492
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__')

# Generated at 2022-06-18 00:16:19.921604
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer(None).target == (2, 7)

# Generated at 2022-06-18 00:17:48.455855
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer.target == (2, 7)
    assert Python2FutureTransformer.__doc__ is not None
    assert Python2FutureTransformer.visit_Module.__doc__ is not None
    assert Python2FutureTransformer.generic_visit.__doc__ is not None
    assert Python2FutureTransformer.visit_Module.__annotations__ == {'node': ast.Module, 'return': ast.Module}
    assert Python2FutureTransformer.generic_visit.__annotations__ == {'node': ast.AST, 'return': ast.AST}
    assert Python2FutureTransformer.visit_Module.__module__ == 'typed_astunparse.unparser.Python2FutureTransformer'
    assert Python2Future

# Generated at 2022-06-18 00:17:58.639987
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer.target == (2, 7)
    assert Python2FutureTransformer.__doc__ == 'Prepends module with:\n' \
                                              '    from __future__ import absolute_import\n' \
                                              '    from __future__ import division\n' \
                                              '    from __future__ import print_function\n' \
                                              '    from __future__ import unicode_literals\n' \
                                              '        \n' \
                                              '    '
    assert Python2FutureTransformer.visit_Module.__name__ == 'visit_Module'
    assert Python2FutureTransformer.visit_Module.__doc__ == 'Prepends module with:\n' \
                

# Generated at 2022-06-18 00:18:08.611991
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_source_equal
    from .test_base import BaseNodeTransformerTestCase

    class Test(BaseNodeTransformerTestCase):
        target = (2, 7)
        transformer = Python2FutureTransformer

        def test_simple(self):
            tree = ast.parse("""
                import os
                import sys
                import math
                """)
            expected = ast.parse("""
                from __future__ import absolute_import
                from __future__ import division
                from __future__ import print_function
                from __future__ import unicode_literals

                import os
                import sys
                import math
                """)
            self.check_tree(tree, expected)

    test = Test()
    test.test_simple()