

# Generated at 2022-06-18 00:08:13.596040
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import assert_source

    source = '''
        import sys
        import os
    '''
    expected = '''
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        import sys
        import os
    '''
    tree = ast.parse(source)
    Python2FutureTransformer().visit(tree)
    assert_source(tree, expected)

# Generated at 2022-06-18 00:08:19.493969
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import assert_source

    source = """
    import os
    import sys
    """
    expected = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    import os
    import sys
    """
    tree = ast.parse(source)
    Python2FutureTransformer().visit(tree)
    assert_source(tree, expected)

# Generated at 2022-06-18 00:08:29.799005
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.source import source
    from ..utils.ast import compare_ast
    from ..utils.snippet import snippet

    @snippet
    def snippet0():
        pass

    @snippet
    def snippet1():
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

    @snippet
    def snippet2():
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        pass

    @snippet
    def snippet3():
        from __future__ import absolute_import
        from __future__ import division

# Generated at 2022-06-18 00:08:39.865305
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_test_module
    from ..utils.visitor import dump_tree
    from ..utils.visitor import dump_tree_diff
    from ..utils.visitor import dump_tree_diff_stats

    source = '''
    def foo():
        pass
    '''
    expected = '''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    def foo():
        pass
    '''
    module = make_test_module(source)
    transformer = Python2FutureTransformer()
    module = transformer.visit(module)
    assert dump_tree(module) == expected
    assert dump_tree_diff(module) == ''

# Generated at 2022-06-18 00:08:51.099490
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_test_module
    from ..utils.visitor import dump_ast
    from ..utils.visitor import dump_source

    module = make_test_module()

# Generated at 2022-06-18 00:08:56.350790
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from .base import BaseNodeTransformer
    from .python2_future import Python2FutureTransformer
    from ..utils.snippet import snippet
    from ..utils.ast_helper import ast_to_str
    from ..utils.ast_helper import str_to_ast
    from ..utils.ast_helper import compare_ast
    from ..utils.ast_helper import get_ast_diff
    from ..utils.ast_helper import get_ast_diff_str
    from ..utils.ast_helper import get_ast_diff_str_color
    from ..utils.ast_helper import get_ast_diff_str_color_html
    from ..utils.ast_helper import get_ast_diff

# Generated at 2022-06-18 00:09:05.359045
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_module
    from ..utils.source import source_to_code
    from ..utils.source import source_to_tokens
    from ..utils.source import source_to_token_list
    from ..utils.source import source_to_token_generator
    from ..utils.source import source_to_token_stream
    from ..utils.source import source_to_token_sequence
    from ..utils.source import source_to_token_iterable
    from ..utils.source import source_to_token_iterator
    from ..utils.source import source_to_token_enumerate
    from ..utils.source import source_to_token_zip
    from ..utils.source import source_to_token_chain

# Generated at 2022-06-18 00:09:11.259022
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    code = """
    import os
    import sys
    """
    expected = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    import os
    import sys
    """
    tree = ast.parse(code)
    Python2FutureTransformer().visit(tree)
    assert astor.to_source(tree) == expected

# Generated at 2022-06-18 00:09:20.867187
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def code():
        print('Hello world!')

    @snippet
    def expected():
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        print('Hello world!')

    node = ast.parse(code.get_source())
    transformer = Python2FutureTransformer()
    node = transformer.visit(node)
    assert ast_to_str(node) == expected.get_source()

# Generated at 2022-06-18 00:09:32.444859
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
           

# Generated at 2022-06-18 00:09:44.399099
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_source_equal
    from ..utils.test_utils import get_ast


# Generated at 2022-06-18 00:09:51.723087
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
           

# Generated at 2022-06-18 00:09:58.454883
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source
    from ..utils.ast import get_ast, compare_asts

    source = source('''
        import os
        import sys
    ''')
    expected_ast = get_ast('''
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        import os
        import sys
    ''')

    tree = get_ast(source)
    new_tree = Python2FutureTransformer().visit(tree)

    assert compare_asts(expected_ast, new_tree)

# Generated at 2022-06-18 00:10:05.407632
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_test_module
    from ..utils.visitor import dump_AST
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_AST

    source = '''
    def foo():
        pass
    '''
    module = make_test_module(source)
    module.visit(Python2FutureTransformer())
    assert source_to_unicode(module) == u'''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    def foo():
        pass
    '''

# Generated at 2022-06-18 00:10:14.753907
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_test_module
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_ast_node
    from ..utils.source import source_to_code
    from ..utils.source import ast_to_source
    from ..utils.source import ast_node_to_source
    from ..utils.source import code_to_ast
    from ..utils.source import code_to_source
    from ..utils.source import code_to_ast_node
    from ..utils.source import ast_to_code
    from ..utils.source import ast_node_to_code
    from ..utils.source import ast_node_to_source
    from ..utils.source import source_to_ast_node

# Generated at 2022-06-18 00:10:21.941226
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from .python2_future import Python2FutureTransformer
    from ..utils.source import source

    @snippet
    def module():
        pass

    node = module.get_ast()
    transformer = Python2FutureTransformer()
    transformer.visit(node)
    assert source(node) == '''\
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

pass
'''

# Generated at 2022-06-18 00:10:28.238857
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_builder import build_ast
    from ..utils.source_snippets import source_snippets
    from .base import BaseNodeTransformer
    from .python2future import Python2FutureTransformer

    source = source_snippets['Python2FutureTransformer_visit_Module']
    expected = source_snippets['Python2FutureTransformer_visit_Module_expected']
    tree = build_ast(source)
    transformer = Python2FutureTransformer()
    transformer.visit(tree)
    assert ast.dump(tree) == expected

# Generated at 2022-06-18 00:10:33.651617
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.source import source
    from ..utils.ast import compare_ast

    source_ = source(imports)
    expected = ast.parse(source_)

    node = ast.parse('')
    node = Python2FutureTransformer().visit(node)

    assert compare_ast(node, expected)

# Generated at 2022-06-18 00:10:41.176406
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals


    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True

# Generated at 2022-06-18 00:10:50.445136
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.test_utils import assert_ast_equal
    from .base import BaseNodeTransformer

    @snippet
    def code():
        pass

    @snippet
    def expected():
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

    node = code.get_ast()
    expected_node = expected.get_ast()
    transformer = Python2FutureTransformer()
    transformer.visit(node)
    assert_ast_equal(node, expected_node)

# Generated at 2022-06-18 00:11:03.086215
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_test_module
    from ..utils.visitor import dump_ast
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_ast


# Generated at 2022-06-18 00:11:13.290055
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from .python2future import Python2FutureTransformer
    from .python2future import imports
    from .python2future import test_Python2FutureTransformer_visit_Module
    import astor
    import textwrap
    import unittest

# Generated at 2022-06-18 00:11:19.876513
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor

    source = '''
    def foo():
        pass
    '''
    expected = '''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    def foo():
        pass
    '''
    tree = ast.parse(source)
    Python2FutureTransformer().visit(tree)
    result = astor.to_source(tree)
    assert result == expected

# Generated at 2022-06-18 00:11:30.830442
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source
    from ..utils.ast import get_ast, compare_asts

    source_1 = source('''
        import os
        import sys
        import math
        import random
    ''')
    expected_1 = source('''
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        import os
        import sys
        import math
        import random
    ''')

    source_2 = source('''
        import os
        import sys
        import math
        import random
        import numpy as np
    ''')

# Generated at 2022-06-18 00:11:38.457598
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.snippet import snippet

    @snippet
    def code(a, b):
        a = 1
        b = 2

    node = ast.parse(code.get_source())
    Python2FutureTransformer().visit(node)
    assert ast_to_str(node) == imports.get_source(future='__future__') + code.get_source()

# Generated at 2022-06-18 00:11:43.788820
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import assert_ast_equal
    from ..utils.test_utils import get_test_data
    from ..utils.test_utils import get_ast

    source = get_test_data('python2', 'future', 'source.py')
    expected = get_test_data('python2', 'future', 'expected.py')

    source_ast = get_ast(source)
    expected_ast = get_ast(expected)

    transformer = Python2FutureTransformer()
    actual_ast = transformer.visit(source_ast)

    assert_ast_equal(expected_ast, actual_ast)

# Generated at 2022-06-18 00:11:50.653840
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from .python2future import Python2FutureTransformer
    from .python2future import imports
    from ..utils.source import source
    from ..utils.source import Source
    from ..utils.source import SourceArg
    from ..utils.source import SourceArgType
    from ..utils.source import SourceArgValue
    from ..utils.source import SourceArgs
    from ..utils.source import SourceLine
    from ..utils.source import SourceLines
    from ..utils.source import SourceModule
    from ..utils.source import SourceModules
    from ..utils.source import SourceSnippet
    from ..utils.source import SourceTree
    from ..utils.source import SourceTrees
    from ..utils.source import SourceValue


# Generated at 2022-06-18 00:11:59.771150
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_source_equal
    from .test_base import BaseNodeTransformerTest

    class Test(BaseNodeTransformerTest):
        transformer = Python2FutureTransformer
        target = (2, 7)
        code = '''
        def foo():
            pass
        '''
        expected_code = '''
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        def foo():
            pass
        '''

    assert_source_equal(Test)

# Generated at 2022-06-18 00:12:01.602584
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source
    from ..utils.ast import get_ast, compare_asts


# Generated at 2022-06-18 00:12:06.711510
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.source import source
    from ..utils.ast import dump_ast
    from ..utils.ast import equal_ast
    from ..utils.source import assert_source

    source_ = source(imports)
    tree = ast.parse(source_)
    transformer = Python2FutureTransformer()
    new_tree = transformer.visit(tree)
    assert_source(dump_ast(new_tree), source_)
    assert equal_ast(new_tree, tree)

# Generated at 2022-06-18 00:12:23.787438
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.ast_helper import get_ast_node_name
    from ..utils.ast_helper import get_ast_node_type
    from ..utils.ast_helper import get_ast_node_value
    from ..utils.ast_helper import get_ast_node_lineno
    from ..utils.ast_helper import get_ast_node_col_offset
    from ..utils.ast_helper import get_ast_node_end_lineno
    from ..utils.ast_helper import get_ast_node_end_col_offset
    from ..utils.ast_helper import get_ast_node_children
    from ..utils.ast_helper import get_ast_node_fields


# Generated at 2022-06-18 00:12:32.713683
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str

    source = """
    def foo():
        pass
    """
    tree = ast.parse(source)
    transformer = Python2FutureTransformer()
    transformer.visit(tree)
    assert ast_to_str(tree) == """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    
    def foo():
        pass
    """

# Generated at 2022-06-18 00:12:42.572554
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
           

# Generated at 2022-06-18 00:12:52.693171
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__')

# Generated at 2022-06-18 00:13:03.117721
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from .python2future import Python2FutureTransformer
    from .python2future import imports
    from .python2future import test_Python2FutureTransformer_visit_Module
    from .python2future import test_Python2FutureTransformer_visit_Module_1
    from .python2future import test_Python2FutureTransformer_visit_Module_2
    from .python2future import test_Python2FutureTransformer_visit_Module_3
    from .python2future import test_Python2FutureTransformer_visit_Module_4
    from .python2future import test_Python2FutureTransformer_visit_Module_5
    from .python2future import test_Python

# Generated at 2022-06-18 00:13:06.519928
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_source_equal
    from ..utils.test_utils import get_ast


# Generated at 2022-06-18 00:13:16.178334
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__')

# Generated at 2022-06-18 00:13:23.854814
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_test_module
    from ..utils.visitor import dump_ast
    from ..utils.visitor import dump_source
    from ..utils.visitor import dump_tokens
    from ..utils.visitor import dump_tree
    from ..utils.visitor import dump_type_comments
    from ..utils.visitor import dump_type_inference

    module = make_test_module(
        """
        def foo():
            pass
        """,
        target=(2, 7),
    )
    transformer = Python2FutureTransformer()
    module = transformer.visit(module)
    assert transformer._tree_changed is True

# Generated at 2022-06-18 00:13:33.989320
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_module
    from ..utils.source import source_to_code
    from ..utils.source import source_remove_future_imports
    from ..utils.source import source_remove_comments
    from ..utils.source import source_remove_docstrings
    from ..utils.source import source_remove_blank_lines
    from ..utils.source import source_remove_trailing_whitespace
    from ..utils.source import source_normalize
    from ..utils.source import source_to_tokens
    from ..utils.source import source_remove_imports
    from ..utils.source import source_remove_decorators
    from ..utils.source import source_remove_classes
    from ..utils.source import source_remove_functions
   

# Generated at 2022-06-18 00:13:43.753477
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__')

# Generated at 2022-06-18 00:14:04.143636
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)
    assert transformer.visit_Module.__name__ == 'visit_Module'
    assert transformer.visit_Module.__doc__ == 'Prepends module with:\n        from __future__ import absolute_import\n        from __future__ import division\n        from __future__ import print_function\n        from __future__ import unicode_literals\n            \n    '


# Generated at 2022-06-18 00:14:12.791734
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.test_utils import assert_node_equal
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node

# Generated at 2022-06-18 00:14:19.939016
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source
    from ..utils.visitor import print_python_source
    from ..utils.visitor import visit_ast

    source_code = source(
        """
        def foo():
            pass
        """
    )
    tree = ast.parse(source_code)
    visit_ast(tree)
    print_python_source(tree)
    transformer = Python2FutureTransformer()
    visit_ast(tree, transformer)
    print_python_source(tree)
    assert transformer.tree_changed is True

# Generated at 2022-06-18 00:14:29.705753
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor
    from ..utils.ast_helpers import dump_ast
    from ..utils.ast_helpers import get_ast
    from ..utils.ast_helpers import get_source
    from ..utils.ast_helpers import parse_ast

    source = """
    def foo():
        pass
    """
    expected = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals


    def foo():
        pass
    """
    tree = parse_ast(source)
    transformer = Python2FutureTransformer()
    new_tree = transformer.visit(tree)
    assert astor.to_source(new_tree) == expected
    assert transformer.tree_changed is True

# Generated at 2022-06-18 00:14:32.138232
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer.target == (2, 7)
    assert isinstance(Python2FutureTransformer(), Python2FutureTransformer)


# Generated at 2022-06-18 00:14:43.199245
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.source import source
    from ..utils.ast import compare_ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def before():
        import sys
        print(sys.version)

    @snippet
    def after():
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        import sys
        print(sys.version)

    tree = ast.parse(source(before))
    transformer = Python2FutureTransformer()
    new_tree = transformer.visit(tree)
    assert compare_ast(new_tree, source(after))

# Generated at 2022-06-18 00:14:48.368219
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from .python2future import Python2FutureTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    @snippet
    def module():
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        x = 1

    @snippet
    def module_with_imports():
        import os
        import sys

        x = 1


# Generated at 2022-06-18 00:14:49.273024
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer()

# Generated at 2022-06-18 00:14:55.423238
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    from ..utils.source import source
    from ..utils.ast import dump_ast

    source_code = source(imports)
    tree = ast.parse(source_code)
    transformer = Python2FutureTransformer()
    new_tree = transformer.visit(tree)
    assert transformer._tree_changed
    assert dump_ast(new_tree) == dump_ast(tree)

# Generated at 2022-06-18 00:15:06.824251
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source
    from ..utils.ast import get_ast, dump_ast
    from ..utils.compare import compare_ast

    source = source('''
        def foo():
            pass
    ''')
    expected = source('''
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        def foo():
            pass
    ''')

    tree = get_ast(source)
    new_tree = Python2FutureTransformer().visit(tree)
    assert compare_ast(expected, new_tree)
    assert dump_ast(new_tree) == dump_ast(get_ast(expected))

# Generated at 2022-06-18 00:15:44.571759
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__')

# Generated at 2022-06-18 00:15:55.501825
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_code
    from ..utils.source import source_to_tokens
    from ..utils.source import source_to_tokens_with_comments
    from ..utils.source import source_to_tokens_with_comments_and_newlines
    from ..utils.source import source_to_tokens_with_newlines
    from ..utils.source import source_to_tokens_with_whitespace
    from ..utils.source import source_to_tokens_without_comments
    from ..utils.source import source_to_tokens_without_comments_and_newlines
    from ..utils.source import source_to_tokens_without_newlines
    from ..utils.source import source_to_

# Generated at 2022-06-18 00:16:03.752068
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__')

# Generated at 2022-06-18 00:16:15.072911
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    from ..utils.ast_helpers import get_ast, compare_asts
    from ..utils.source import source_to_unicode
    from ..utils.snippet import snippet

    @snippet
    def before():
        import sys
        print(sys.version)

    @snippet
    def after():
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        import sys
        print(sys.version)

    source = source_to_unicode(before.get_source())
    expected_source = source_to_unicode(after.get_source())
    tree = get_ast(source)
    expected_tree = get_ast(expected_source)

    transformer = Python2

# Generated at 2022-06-18 00:16:25.387225
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer.target == (2, 7)
    assert Python2FutureTransformer.__doc__
    assert Python2FutureTransformer.visit_Module.__doc__
    assert Python2FutureTransformer.visit_Module.__annotations__
    assert Python2FutureTransformer.visit_Module.__annotations__['node'] == ast.Module
    assert Python2FutureTransformer.visit_Module.__annotations__['return'] == ast.Module
    assert Python2FutureTransformer.visit_Module.__annotations__['return'] == ast.Module
    assert Python2FutureTransformer.visit_Module.__annotations__['return'] == ast.Module
    assert Python2FutureTransformer.visit_Module.__annotations

# Generated at 2022-06-18 00:16:32.187622
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source_to_ast
    from ..utils.visitor import print_ast
    from ..utils.source import source_to_ast
    from ..utils.visitor import print_ast

    source = """
    import os
    import sys
    """
    tree = source_to_ast(source)
    print_ast(tree)
    transformer = Python2FutureTransformer()
    transformer.visit(tree)
    print_ast(tree)

# Generated at 2022-06-18 00:16:40.644579
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from .base import BaseNodeTransformer
    from .python2_future import Python2FutureTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = [ast.parse('print("Hello World")').body[0]]
            return self.generic_visit(node)  # type: ignore

    test_transformer = TestTransformer()
    test_transformer.visit(ast.parse('pass'))
    assert ast_to_str(test_transformer.root) == 'print("Hello World")'

    test_transformer = Python2FutureTransformer()
    test_trans

# Generated at 2022-06-18 00:16:44.862674
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_test_module
    from ..utils.visitor import dump_ast

    source = '''
    import os
    import sys
    import json
    '''
    expected = '''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    import os
    import sys
    import json
    '''
    module = make_test_module(source)
    Python2FutureTransformer().visit(module)
    assert dump_ast(module) == expected

# Generated at 2022-06-18 00:16:50.556145
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    from ..utils.source import source
    from ..utils.ast_factory import ast_factory
    from ..utils.source_factory import source_factory
    from ..utils.snippet import snippet

    @snippet
    def code():
        pass

    node = ast_factory(code)
    assert isinstance(node, ast.Module)
    assert len(node.body) == 0

    transformer = Python2FutureTransformer()
    transformer.visit(node)
    assert transformer._tree_changed is True

    assert len(node.body) == 4
    assert isinstance(node.body[0], ast.ImportFrom)
    assert node.body[0].module == '__future__'

# Generated at 2022-06-18 00:16:58.616463
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source
    from ..utils.ast import get_ast, dump_ast
    from ..utils.compare_ast import compare_ast
    from ..utils.visitor import dump_visitor
