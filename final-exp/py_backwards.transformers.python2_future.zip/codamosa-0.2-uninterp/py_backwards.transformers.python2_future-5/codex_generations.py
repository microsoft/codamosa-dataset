

# Generated at 2022-06-18 00:08:18.872298
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import get_ast
    from ..utils.test_utils import get_node_of_class
    from ..utils.test_utils import get_source_code
    from ..utils.test_utils import get_transformed_source_code
    from ..utils.test_utils import get_transformed_ast
    from ..utils.test_utils import get_transformed_node_of_class
    from ..utils.test_utils import get_transformed_source_code_of_class
    from ..utils.test_utils import get_transformed_ast_of_class
    from ..utils.test_utils import get_transformed_node_of_class

    source = """
    import os
    import sys
    import math
    """

# Generated at 2022-06-18 00:08:26.469354
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source
    from ..utils.ast import dump
    from ..utils.ast import parse

    source_ = source('''
    def foo():
        pass
    ''')
    tree = parse(source_)
    transformer = Python2FutureTransformer()
    new_tree = transformer.visit(tree)
    assert dump(new_tree) == source('''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    def foo():
        pass
    ''')

# Generated at 2022-06-18 00:08:33.903033
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from .python2future import Python2FutureTransformer
    from .python2future import imports
    from ..utils.source import source
    from ..utils.source import Source
    from ..utils.source import SourceArg
    from ..utils.source import SourceArgType
    from ..utils.source import SourceArgValue
    from ..utils.source import SourceArgs
    from ..utils.source import SourceLine
    from ..utils.source import SourceLines
    from ..utils.source import SourceModule
    from ..utils.source import SourceSnippet
    from ..utils.source import SourceTree
    from ..utils.source import SourceValue
    from ..utils.source import SourceValues
    from ..utils.source import SourceVisitor
   

# Generated at 2022-06-18 00:08:44.762545
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__')

# Generated at 2022-06-18 00:08:51.762429
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source
    from ..utils.ast import ast_equal, dump

    source = source('''
    def foo():
        pass
    ''')
    expected = source('''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    
    def foo():
        pass
    ''')
    tree = ast.parse(source)
    tree = Python2FutureTransformer().visit(tree)
    assert ast_equal(expected, tree)

# Generated at 2022-06-18 00:09:03.528173
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from ..utils.source import source
    from ..utils.ast import dump
    from ..utils.ast import compare_ast
    from ..utils.ast import parse
    from ..utils.ast import get_ast
    from ..utils.ast import get_source
    from ..utils.ast import get_source_without_imports
    from ..utils.ast import get_source_without_comments
    from ..utils.ast import get_source_without_imports_and_comments
    from ..utils.ast import get_source_without_decorators
    from ..utils.ast import get_source_without_decorators_and_imports
    from ..utils.ast import get_source_without_decorators_and_comments

# Generated at 2022-06-18 00:09:06.363359
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import assert_source_equal
    from ..utils.test_utils import get_ast


# Generated at 2022-06-18 00:09:14.167529
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_test_module
    from ..utils.visitor import dump_ast
    from ..utils.source import source_to_unicode

    source = source_to_unicode('''
    def foo():
        pass
    ''')
    tree = make_test_module(source, target=(2, 7))
    transformer = Python2FutureTransformer()
    tree = transformer.visit(tree)
    assert transformer.tree_changed is True
    assert dump_ast(tree) == source_to_unicode('''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    def foo():
        pass
    ''')

# Generated at 2022-06-18 00:09:23.668431
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source
    from ..utils.ast import get_ast, compare_asts
    from ..utils.visitor import dump_tree


# Generated at 2022-06-18 00:09:34.536737
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_source_equal
    from .base import BaseNodeTransformer

    class DummyTransformer(BaseNodeTransformer):
        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__') + node.body  # type: ignore
            return self.generic_visit(node)  # type: ignore


# Generated at 2022-06-18 00:09:47.276073
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__')

# Generated at 2022-06-18 00:10:17.418430
# Unit test for constructor of class Python2FutureTransformer

# Generated at 2022-06-18 00:10:26.985134
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_test_module
    from ..utils.visitor import dump_ast
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_ast_node
    from ..utils.source import source_to_code
    from ..utils.source import source_to_code_object
    from ..utils.source import source_to_function
    from ..utils.source import source_to_function_object
    from ..utils.source import source_to_module
    from ..utils.source import source_to_module_object
    from ..utils.source import source_to_eval
    from ..utils.source import source_to_exec
    from ..utils.source import source_to_interactive

# Generated at 2022-06-18 00:10:32.636390
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.test_utils import assert_source

    source = """
    print('hello world')
    """
    expected = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    print('hello world')
    """
    assert_source(Python2FutureTransformer, source, expected)

# Generated at 2022-06-18 00:10:40.631568
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from .python2_future import Python2FutureTransformer
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_module
    from ..utils.source import source_to_code
    from ..utils.source import source_to_function
    from ..utils.source import source_to_class
    from ..utils.source import source_to_expression
    from ..utils.source import source_to_statement
    from ..utils.source import source_to_interactive
    from ..utils.source import source_to_suite
    from ..utils.source import source_to_ast_tree
    from ..utils.source import source_to_ast_node

# Generated at 2022-06-18 00:10:50.546758
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_dummy_future_node
    from ..utils.fixtures import make_dummy_module_node
    from ..utils.fixtures import make_dummy_print_node
    from ..utils.fixtures import make_dummy_pass_node
    from ..utils.fixtures import make_dummy_assign_node
    from ..utils.fixtures import make_dummy_name_node
    from ..utils.fixtures import make_dummy_num_node
    from ..utils.fixtures import make_dummy_binop_node
    from ..utils.fixtures import make_dummy_arg_node
    from ..utils.fixtures import make_dummy_call_node
    from ..utils.fixtures import make_dummy_function_def_node

# Generated at 2022-06-18 00:10:55.805952
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.test_utils import assert_source

    assert_source(
        Python2FutureTransformer,
        """
        import os
        import sys
        """,
        """
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        import os
        import sys
        """
    )

# Generated at 2022-06-18 00:11:04.039819
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_equal_tree
    from ..utils.test_utils import assert_equal_trees
    from ..utils.test_utils import assert_equal_trees_ignore_ws
    from ..utils.test_utils import assert_equal_trees_ignore_ws_and_order
    from ..utils.test_utils import assert_equal_trees_ignore_ws_and_order_and_lineno
    from ..utils.test_utils import assert_equal_trees_ignore_ws_and_order_and_lineno_and_col_offset
    from ..utils.test_utils import assert_equal_trees

# Generated at 2022-06-18 00:11:09.252663
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)
    assert transformer.visit_Module(ast.parse("1")) == ast.parse("from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n1")

# Generated at 2022-06-18 00:11:19.624737
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source
    from ..utils.ast import get_ast, compare_asts


# Generated at 2022-06-18 00:11:32.451963
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_module
    from ..utils.source import source_to_code
    from ..utils.source import source_to_function
    from ..utils.source import source_to_class
    from ..utils.source import source_to_method
    from ..utils.source import source_to_expression
    from ..utils.source import source_to_statement
    from ..utils.source import source_to_interactive
    from ..utils.source import source_to_suite
    from ..utils.source import source_to_future
    from ..utils.source import source_to_alias
    from ..utils.source import source_to_arguments
    from ..utils.source import source_to_keyword
    from ..utils.source import source_to_compre

# Generated at 2022-06-18 00:11:39.368658
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer.target == (2, 7)
    assert Python2FutureTransformer.__doc__ == 'Prepends module with:\n    from __future__ import absolute_import\n    from __future__ import division\n    from __future__ import print_function\n    from __future__ import unicode_literals\n        \n    '


# Generated at 2022-06-18 00:11:40.461429
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)
    assert transformer._tree_changed == False


# Generated at 2022-06-18 00:11:50.032284
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source
    from ..utils.ast import get_ast, dump_ast
    from ..utils.compare import compare_ast

    source_ = source(imports)
    expected_ast = get_ast(source_)

    tree = get_ast(source_)
    actual_ast = Python2FutureTransformer().visit(tree)

    assert compare_ast(actual_ast, expected_ast)
    assert dump_ast(actual_ast) == dump_ast(expected_ast)

# Generated at 2022-06-18 00:11:55.929819
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_source_equal
    from ..utils.test_utils import get_visitor
    from ..utils.test_utils import parse_ast

    source = """
    def foo():
        pass
    """
    expected = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    def foo():
        pass
    """
    module = parse_ast(source)
    visitor = get_visitor(Python2FutureTransformer, module)
    module = visitor.visit(module)
    assert_source_equal(expected, module)

# Generated at 2022-06-18 00:12:05.144156
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
           

# Generated at 2022-06-18 00:12:06.777639
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import transform_and_compare

# Generated at 2022-06-18 00:12:17.252628
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source
    from ..utils.ast import get_ast, compare_asts


# Generated at 2022-06-18 00:12:24.887106
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals


    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True

# Generated at 2022-06-18 00:12:35.562377
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_builder import build_ast
    from ..utils.source_code import SourceCode
    from ..utils.visitor import NodeVisitor
    from ..utils.visitor import visit_children
    from ..utils.visitor import visit_children_with_self
    from ..utils.visitor import visit_children_with_self_and_parent
    from ..utils.visitor import visit_children_with_self_and_parents
    from ..utils.visitor import visit_children_with_self_parent_and_grandparent
    from ..utils.visitor import visit_children_with_self_parent_and_grandparents
    from ..utils.visitor import visit_children_with_self_parent_grandparent_and_greatgrandparent
    from ..utils.visitor import visit_

# Generated at 2022-06-18 00:12:51.556630
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_source_equal
    from ..utils.test_utils import generate_source
    from ..utils.test_utils import get_ast

    source = """
    def foo():
        pass
    """
    expected = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    def foo():
        pass
    """
    tree = get_ast(source)
    transformer = Python2FutureTransformer()
    new_tree = transformer.visit(tree)
    assert_source_equal(generate_source(new_tree), expected)

# Generated at 2022-06-18 00:13:01.927886
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__')

# Generated at 2022-06-18 00:13:12.259229
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True

# Generated at 2022-06-18 00:13:22.407268
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source
    from ..utils.ast import get_ast, compare_asts
    from ..utils.visitor import dump_visitor
    from ..utils.codegen import to_source
    from ..utils.snippet import snippet

    @snippet
    def before():
        print('Hello World')

    @snippet
    def after():
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        print('Hello World')

    source_ast = get_ast(source(before))
    expected_ast = get_ast(source(after))
    visitor = Python2FutureTransformer()
    visitor.visit(source_ast)
    assert compare_asts(source_ast, expected_ast)

# Generated at 2022-06-18 00:13:27.385758
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)
    assert transformer.visit_Module(ast.parse('pass')) == ast.parse(
        'from __future__ import absolute_import\n'
        'from __future__ import division\n'
        'from __future__ import print_function\n'
        'from __future__ import unicode_literals\n'
        'pass')

# Generated at 2022-06-18 00:13:34.302047
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_source_equal
    from ..utils.test_utils import generate_visitor_test
    from .base import BaseNodeTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__') + node.body  # type: ignore
            return self.generic_visit(node)  # type: ignore


# Generated at 2022-06-18 00:13:41.631832
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source
    from ..utils.ast import get_ast, get_source

    source = source('''
    def foo():
        pass
    ''')
    tree = get_ast(source)
    transformer = Python2FutureTransformer()
    transformer.visit(tree)
    assert get_source(tree) == '''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    def foo():
        pass
    '''

# Generated at 2022-06-18 00:13:45.193404
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.test_utils import assert_node
    from ..utils.test_utils import get_node
    from ..utils.test_utils import parse_ast

    node = parse_ast(imports.get_source(future='__future__'))
    assert_node(node, Python2FutureTransformer)

# Generated at 2022-06-18 00:13:52.274137
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from .python2future import Python2FutureTransformer
    from ..utils.source import source

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    @snippet
    def module():
        import os
        import sys
        import re
        import json
        import time
        import datetime
        import logging
        import argparse
        import subprocess
        import multiprocessing
        import threading
        import queue
        import collections
        import itertools
        import functools
        import operator
        import contextlib
        import tempfile
        import shutil

# Generated at 2022-06-18 00:14:02.055576
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
           

# Generated at 2022-06-18 00:14:26.250426
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import assert_ast_equal
    from ..utils.test_utils import get_ast
    from ..utils.test_utils import get_ast_node
    from ..utils.test_utils import get_source
    from ..utils.test_utils import get_source_node

    source = """
    import os
    import sys
    import math
    """
    expected = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    import os
    import sys
    import math
    """
    source_ast = get_ast(source)
    expected_ast = get_ast(expected)
    transformer = Python2FutureTransformer()
    actual_ast = transformer.visit(source_ast)

# Generated at 2022-06-18 00:14:33.786550
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__')

# Generated at 2022-06-18 00:14:35.646730
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer(None).target == (2, 7)

# Generated at 2022-06-18 00:14:42.270874
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_fixtures
    from ..utils.source import source

    make_fixtures(__file__,
                  lambda: [Python2FutureTransformer(target=(2, 7))],
                  globals(),
                  )

    source_before = source(__file__)
    source_after = source(__file__, suffix='after')

    assert source_before == source_after

# Generated at 2022-06-18 00:14:43.209817
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor
    from ..utils.ast_builder import build_ast


# Generated at 2022-06-18 00:14:45.672908
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)
    assert transformer._tree_changed == False
    assert transformer.visit_Module(ast.Module(body=[])) == ast.Module(body=imports.get_body(future='__future__'))

# Generated at 2022-06-18 00:14:56.410667
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from .python2_future import Python2FutureTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    @snippet
    def module():
        import sys
        import os
        import math
        import random
        import datetime
        import time
        import calendar
        import re
        import json
        import xml
        import csv
        import urllib
        import urllib2
        import urlparse
        import requests
        import collections
        import itertools
        import fun

# Generated at 2022-06-18 00:15:06.346304
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import assert_source_equal
    from ..utils.test_utils import get_node
    from ..utils.test_utils import get_source

    source = """
    def foo():
        pass
    """
    expected = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    def foo():
        pass
    """
    node = get_node(source, 2)
    Python2FutureTransformer().visit(node)
    assert_source_equal(get_source(node), expected)

# Generated at 2022-06-18 00:15:12.942003
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import assert_node_equal
    from typed_ast import ast3 as ast
    from typed_ast import parse
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    @snippet
    def code():
        pass

    node = parse(code.get_source())
    transformer = Python2FutureTransformer()
    node = transformer.visit(node)
    assert_node_equal(node, imports.get_ast(future='__future__'))

# Generated at 2022-06-18 00:15:24.982968
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.source import source
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from .base import BaseNodeVisitor
    from .base import TransformerError
    from .base import TransformerVisitorError
    from .base import visit_Module
    from .base import visit_body
    from .base import visit_body_or_else
    from .base import visit_iter_fields
    from .base import visit_iter_fields_or_else
    from .base import visit_stmt
    from .base import visit_stmt_or_else
    from .base import visit_expr
    from .base import visit_expr_or_else
    from .base import visit_slice
    from .base import visit_slice_or_else

# Generated at 2022-06-18 00:15:56.376268
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer.target == (2, 7)
    assert isinstance(Python2FutureTransformer(), Python2FutureTransformer)


# Generated at 2022-06-18 00:16:04.437798
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source
    from ..utils.ast import get_ast, compare_asts

    source = source('''
        import os
        import sys
    ''')
    expected_ast = get_ast('''
        import os
        import sys
    ''')
    expected_ast.body.insert(0, imports.get_body(future='__future__')[0])
    expected_ast.body.insert(0, imports.get_body(future='__future__')[1])
    expected_ast.body.insert(0, imports.get_body(future='__future__')[2])
    expected_ast.body.insert(0, imports.get_body(future='__future__')[3])
    actual_ast = Python2FutureTransformer().visit(get_ast(source))


# Generated at 2022-06-18 00:16:12.150637
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import assert_source

    source = """
    print('Hello, world!')
    """
    expected = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    print('Hello, world!')
    """
    tree = ast.parse(source)
    Python2FutureTransformer().visit(tree)
    assert_source(tree, expected)

# Generated at 2022-06-18 00:16:17.527975
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import assert_source

    source = """
    def foo():
        pass
    """
    expected = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    def foo():
        pass
    """
    tree = ast.parse(source)
    Python2FutureTransformer().visit(tree)
    assert_source(tree, expected)

# Generated at 2022-06-18 00:16:27.339388
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.test_utils import assert_source


# Generated at 2022-06-18 00:16:36.141512
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_test_module
    from ..utils.visitor import dump_ast

# Generated at 2022-06-18 00:16:39.388279
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor
    from ..utils.ast_helpers import get_ast
    from ..utils.source_helpers import get_source

    source = get_source(Python2FutureTransformer)
    tree = get_ast(source)
    Python2FutureTransformer().visit(tree)
    assert astor.to_source(tree).strip() == get_source(imports).strip()

# Generated at 2022-06-18 00:16:45.055754
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_test_module
    from ..utils.visitor import dump_ast
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_code
    from ..utils.source import source_to_ast_and_code
    from ..utils.source import ast_to_source
    from ..utils.source import ast_to_code
    from ..utils.source import ast_to_source_and_code
    from ..utils.source import code_to_ast
    from ..utils.source import code_to_source
    from ..utils.source import code_to_ast_and_source
    from ..utils.source import source_to_ast_and_code
    from ..utils.source import ast_to_source_

# Generated at 2022-06-18 00:16:50.479350
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def code():
        a = 1
        b = 2
        c = 3

    @snippet
    def expected():
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        a = 1
        b = 2
        c = 3

    node = ast.parse(code.get_source())
    transformer = Python2FutureTransformer()
    transformer.visit(node)
    assert ast_to_str(node) == expected.get_source()

# Generated at 2022-06-18 00:16:51.842553
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)
