

# Generated at 2022-06-18 00:08:22.362674
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_test_module
    from ..utils.visitor import dump_ast
    from ..utils.source import source_to_unicode

    source = '''
    def foo():
        pass
    '''
    module = make_test_module(source, target=(2, 7))
    transformer = Python2FutureTransformer()
    module = transformer.visit(module)
    assert transformer._tree_changed
    assert source_to_unicode(dump_ast(module)) == source_to_unicode('''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    
    def foo():
        pass
    ''')

# Generated at 2022-06-18 00:08:32.004888
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import assert_source_equal
    from ..utils.test_utils import get_ast


# Generated at 2022-06-18 00:08:41.891629
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer.target == (2, 7)
    assert Python2FutureTransformer.__doc__ == """Prepends module with:
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
            
    """
    assert Python2FutureTransformer.visit_Module.__doc__ == """Prepends module with:
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
            
    """
    assert Python2FutureTransformer.visit_Module.__name__ == 'visit_Module'
    assert Python2FutureTrans

# Generated at 2022-06-18 00:08:52.958249
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_module
    from ..utils.source import source_to_code
    from ..utils.source import source_to_tokens
    from ..utils.source import source_to_token_names
    from ..utils.source import source_to_comments
    from ..utils.source import source_to_fixers
    from ..utils.source import source_to_visitors
    from ..utils.source import source_to_format
    from ..utils.source import source_to_format_options
    from ..utils.source import source_to_format_options_with_comments
    from ..utils.source import source_to_format_options_with_comments_and_newlines
    from ..utils.source import source_to_format_options_with_comments

# Generated at 2022-06-18 00:09:03.184392
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer.target == (2, 7)
    assert Python2FutureTransformer.__doc__ == """Prepends module with:
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
            
    """
    assert Python2FutureTransformer.visit_Module.__doc__ == """Prepends module with:
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
            
    """


# Generated at 2022-06-18 00:09:05.246716
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import assert_source


# Generated at 2022-06-18 00:09:14.432975
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer.target == (2, 7)
    assert Python2FutureTransformer.visit_Module.__name__ == 'visit_Module'
    assert Python2FutureTransformer.visit_Module.__doc__ == 'Prepends module with:\n        from __future__ import absolute_import\n        from __future__ import division\n        from __future__ import print_function\n        from __future__ import unicode_literals\n            \n    '
    assert Python2FutureTransformer.visit_Module.__module__ == 'future.transforms.fix_future_standard_library'
    assert Python2FutureTransformer.visit_Module.__defaults__ == (None,)
    assert Python2FutureTransformer.visit_

# Generated at 2022-06-18 00:09:23.820374
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_builder import build_ast
    from ..utils.source import source_to_unicode
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_ast_node
    from ..utils.source import source_to_ast_nodes
    from ..utils.source import source_to_code
    from ..utils.source import source_to_tokens
    from ..utils.source import source_to_token_list
    from ..utils.source import source_to_token_types
    from ..utils.source import source_to_token_type_list
    from ..utils.source import source_to_token_names
    from ..utils.source import source_to_token_name_list
    from ..utils.source import source_to

# Generated at 2022-06-18 00:09:34.635788
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_module
    from ..utils.source import source_to_code
    from ..utils.source import source_to_function
    from ..utils.source import source_to_class
    from ..utils.source import source_to_statement
    from ..utils.source import source_to_expression
    from ..utils.source import source_to_interactive
    from ..utils.source import source_to_suite
    from ..utils.source import source_to_ast_and_code
    from ..utils.source import source_to_ast_and_module
    from ..utils.source import source_to_ast_and_function
    from ..utils.source import source_to_ast_and_class
   

# Generated at 2022-06-18 00:09:38.075959
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source
    from ..utils.ast import dump_ast

    source = source(imports)
    tree = ast.parse(source)
    tree = Python2FutureTransformer().visit(tree)
    dump_ast(tree)

# Generated at 2022-06-18 00:10:15.608489
# Unit test for method visit_Module of class Python2FutureTransformer

# Generated at 2022-06-18 00:10:25.384439
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__')

# Generated at 2022-06-18 00:10:35.470214
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils import run_transformer_on_single_file
    from ..utils import assert_tree_unchanged
    from ..utils import assert_tree_changed

    # Test that the transformer does not change the tree when the target version is not 2.7

# Generated at 2022-06-18 00:10:41.090598
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helpers import assert_equal_ast
    from .base import BaseNodeTransformer
    from .python2_future import Python2FutureTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__') + node.body  # type: ignore
            return self.generic_visit(node)  # type: ignore


# Generated at 2022-06-18 00:10:47.462235
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source
    from ..utils.compare_ast import compare_ast
    from ..utils.visitor import dump_tree

    source = source(imports)
    tree = ast.parse(source)
    new_tree = Python2FutureTransformer().visit(tree)
    assert compare_ast(tree, new_tree)
    assert dump_tree(new_tree) == source

# Generated at 2022-06-18 00:10:58.796436
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import assert_ast_equal
    from ..utils.test_utils import assert_tree_changed
    from ..utils.test_utils import assert_tree_unchanged
    from ..utils.test_utils import get_test_data
    from ..utils.test_utils import load_module_from_file
    from ..utils.test_utils import load_module_from_source
    from ..utils.test_utils import parse_ast_tree

    test_data = get_test_data('future_transformer_test_data.py')
    tree = parse_ast_tree(test_data)
    transformer = Python2FutureTransformer()
    new_tree = transformer.visit(tree)
    assert_tree_changed(transformer)

# Generated at 2022-06-18 00:11:06.655330
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
           

# Generated at 2022-06-18 00:11:16.852833
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source_to_ast
    from ..utils.visitor import print_ast
    from ..utils.source import source_to_code
    from ..utils.source import source_to_ast
    from ..utils.visitor import print_ast
    from ..utils.source import source_to_code
    from ..utils.source import source_to_ast
    from ..utils.visitor import print_ast
    from ..utils.source import source_to_code
    from ..utils.source import source_to_ast
    from ..utils.visitor import print_ast
    from ..utils.source import source_to_code
    from ..utils.source import source_to_ast
    from ..utils.visitor import print_ast
    from ..utils.source import source_to_code
    from ..utils.source import source_

# Generated at 2022-06-18 00:11:28.302657
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_builder import build_ast
    from ..utils.ast_visitor import AstVisitor
    from ..utils.ast_transformer import AstTransformer
    from ..utils.ast_source import ast_to_source
    from ..utils.ast_source import source_to_ast
    from ..utils.ast_source import source_to_ast_tree
    from ..utils.ast_source import ast_tree_to_source
    from ..utils.ast_source import ast_tree_to_source_tree
    from ..utils.ast_source import source_tree_to_ast_tree
    from ..utils.ast_source import source_tree_to_source
    from ..utils.ast_source import source_to_source_tree
    from ..utils.ast_source import source_

# Generated at 2022-06-18 00:11:33.664627
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source
    from ..utils.ast import get_ast, compare_asts

    source = """
    def foo():
        pass
    """
    expected = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    def foo():
        pass
    """
    tree = get_ast(source)
    new_tree = Python2FutureTransformer().visit(tree)
    assert compare_asts(expected, new_tree)

# Generated at 2022-06-18 00:11:44.399030
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from .base import BaseNodeTransformer
    from .python2_future_transformer import Python2FutureTransformer
    from .python2_future_transformer import imports
    from ..utils.snippet import snippet
    from ..utils.snippet import snippet_to_ast
    from ..utils.snippet import snippet_to_str
    from ..utils.snippet import snippet_to_str_ast
    from ..utils.snippet import snippet_to_str_ast_ast
    from ..utils.snippet import snippet_to_str_ast_ast_ast

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function

# Generated at 2022-06-18 00:11:53.707347
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import transform, compare_ast
    from .base import BaseNodeTransformer
    from .python2_future import Python2FutureTransformer
    from .python3_future import Python3FutureTransformer
    from .python3_types import Python3TypesTransformer
    from .python3_print import Python3PrintTransformer
    from .python3_division import Python3DivisionTransformer
    from .python3_unicode import Python3UnicodeTransformer
    from .python3_absolute_import import Python3AbsoluteImportTransformer
    from .python3_raise import Python3RaiseTransformer
    from .python3_non_local import Python3NonLocalTransformer
    from .python3_metaclass import Python3MetaclassTransformer

# Generated at 2022-06-18 00:11:59.109572
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.source import source

    source_code = source(imports)
    tree = ast.parse(source_code)
    transformer = Python2FutureTransformer()
    transformer.visit(tree)
    assert transformer._tree_changed
    assert ast.dump(tree) == source(imports, future='__future__')

# Generated at 2022-06-18 00:12:07.104478
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals


    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True

# Generated at 2022-06-18 00:12:15.757827
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_inspector import AstInspector
    from ..utils.ast_transformer import AstTransformer
    from ..utils.ast_visitor import AstVisitor
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def code():
        pass

    tree = code.get_ast()
    transformer = AstTransformer(Python2FutureTransformer)
    tree = transformer.visit(tree)
    assert AstInspector(tree).dump() == AstInspector(imports.get_ast(future='__future__')).dump()

# Generated at 2022-06-18 00:12:23.732539
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    from ..utils.ast_helpers import get_ast
    from ..utils.ast_helpers import get_source
    from ..utils.ast_helpers import get_source_from_ast
    from ..utils.ast_helpers import get_source_from_node
    from ..utils.ast_helpers import get_source_from_visitor

    source = """
    import os
    import sys
    import re
    """
    expected = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    import os
    import sys
    import re
    """
    ast_tree = get_ast(source)
    visitor = Python2FutureTransformer()

# Generated at 2022-06-18 00:12:33.448225
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source
    from ..utils.ast import dump
    from ..utils.ast import parse

    source_ = source('''
    def f():
        pass
    ''')
    tree = parse(source_)
    transformer = Python2FutureTransformer()
    new_tree = transformer.visit(tree)
    assert transformer._tree_changed is True
    assert dump(new_tree) == source('''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    def f():
        pass
    ''')

# Generated at 2022-06-18 00:12:39.358219
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import transform_and_compare
    transform_and_compare(Python2FutureTransformer, 'def foo(): pass',
                          'from __future__ import absolute_import\n'
                          'from __future__ import division\n'
                          'from __future__ import print_function\n'
                          'from __future__ import unicode_literals\n'
                          'def foo(): pass')

# Generated at 2022-06-18 00:12:45.351023
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.source import source
    from ..utils.ast import compare_ast

    source_ = source(imports)
    tree = ast.parse(source_)
    transformer = Python2FutureTransformer()
    new_tree = transformer.visit(tree)
    assert transformer.tree_changed
    assert compare_ast(ast.parse(source(imports, future='__future__')), new_tree)

# Generated at 2022-06-18 00:12:54.507831
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_module
    from ..utils.source import source_to_code
    from ..utils.source import source_to_tokens
    from ..utils.source import source_to_token_list
    from ..utils.source import source_to_token_generator
    from ..utils.source import source_to_token_stream
    from ..utils.source import source_to_token_sequence
    from ..utils.source import source_to_token_iterator
    from ..utils.source import source_to_token_iterable
    from ..utils.source import source_to_token_iter
    from ..utils.source import source_to_token_list_generator
    from ..utils.source import source_to_token_list_stream

# Generated at 2022-06-18 00:13:02.834313
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'

# Generated at 2022-06-18 00:13:13.098693
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from .base import BaseNodeTransformer
    from .python2_future import Python2FutureTransformer
    from .python2_print import Python2PrintTransformer
    from .python3_print import Python3PrintTransformer
    from .python3_raise import Python3RaiseTransformer
    from .python3_unicode import Python3UnicodeTransformer
    from .python3_division import Python3DivisionTransformer
    from .python3_absolute_import import Python3AbsoluteImportTransformer
    from .python3_non_iterator_unpacking import Python3NonIteratorUnpackingTransformer
    from .python3_metaclass import Python3MetaclassTransformer
    from .python3_raise_from import Python3RaiseFrom

# Generated at 2022-06-18 00:13:21.891953
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import transform, assert_equal_ast
    from ..utils.test_utils import assert_equal_code

    code = '''
    print("Hello world!")
    '''
    expected_code = '''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    print("Hello world!")
    '''
    tree = ast.parse(code)
    tree = transform(tree, Python2FutureTransformer)
    assert_equal_ast(tree, expected_code)
    assert_equal_code(tree, expected_code)

# Generated at 2022-06-18 00:13:28.872329
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_source_equal
    from ..utils.test_utils import get_ast

    source = """
    def foo():
        pass
    """
    expected = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    def foo():
        pass
    """
    tree = get_ast(source)
    transformer = Python2FutureTransformer()
    new_tree = transformer.visit(tree)
    assert_source_equal(expected, new_tree)

# Generated at 2022-06-18 00:13:31.365530
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)
    assert transformer.visit_Module(None) is None


# Generated at 2022-06-18 00:13:40.804311
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_test_module
    from ..utils.visitor import dump_tree
    from ..utils.visitor import visit_tree
    from ..utils.visitor import assert_tree
    from ..utils.visitor import assert_tree_unchanged

    # Test: no change
    module = make_test_module(
        """
        def foo():
            pass
        """)
    assert_tree_unchanged(module, Python2FutureTransformer)

    # Test: change
    module = make_test_module(
        """
        def foo():
            pass
        """)

# Generated at 2022-06-18 00:13:41.707101
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-18 00:13:49.951256
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__')

# Generated at 2022-06-18 00:13:58.674294
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source
    from ..utils.ast import get_ast, compare_asts


# Generated at 2022-06-18 00:14:03.871887
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import transform_and_compare
    transform_and_compare(
        Python2FutureTransformer,
        '''
        def foo():
            pass
        ''',
        '''
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        def foo():
            pass
        '''
    )

# Generated at 2022-06-18 00:14:27.749578
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__')

# Generated at 2022-06-18 00:14:34.446259
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import assert_source


# Generated at 2022-06-18 00:14:44.981630
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source
    from ..utils.visitor import dump
    from ..utils.visitor import visit
    from ..utils.visitor import visit_children
    from ..utils.visitor import visit_children_with_parents
    from ..utils.visitor import visit_with_parents
    from ..utils.visitor import visit_with_parents_and_children
    from ..utils.visitor import visit_with_parents_and_children_and_siblings
    from ..utils.visitor import visit_with_parents_and_siblings
    from ..utils.visitor import visit_with_siblings
    from ..utils.visitor import visit_with_siblings_and_children
    from ..utils.visitor import visit_with_siblings_and_children_and_parents
    from ..utils.visitor import visit_with

# Generated at 2022-06-18 00:14:56.092747
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from .python2future import Python2FutureTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body

# Generated at 2022-06-18 00:15:03.398086
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.test_utils import assert_equal_ast
    assert_equal_ast(Python2FutureTransformer, '''
    def f():
        pass
    ''', '''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    def f():
        pass
    ''')

# Generated at 2022-06-18 00:15:12.021220
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor
    from ..utils.ast_builder import build_ast
    from ..utils.ast_visitor import ASTVisitor
    from ..utils.ast_visitor import visit_ast
    from ..utils.ast_visitor import visit_ast_recursive

    # Test constructor
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)
    assert transformer._tree_changed is False
    assert transformer._visitor is None

    # Test visit_Module
    node = build_ast('def foo(): pass')
    node = transformer.visit(node)
    assert transformer._tree_changed is True
    assert transformer._visitor is None

# Generated at 2022-06-18 00:15:24.736689
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals


    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True

# Generated at 2022-06-18 00:15:34.712743
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import assert_equal_source
    from ..utils.test_utils import assert_equal_tree
    from ..utils.test_utils import assert_equal_tokens
    from ..utils.test_utils import assert_equal_types

    # Test constructor
    transformer = Python2FutureTransformer()
    assert_equal_types(transformer, Python2FutureTransformer)

    # Test visit_Module
    source = '''
    def foo():
        pass
    '''

# Generated at 2022-06-18 00:15:43.253599
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.source import source
    from ..utils.snippet import snippet
    from ..utils.ast import compare_ast

    @snippet
    def before(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    @snippet
    def after(future):
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    node = ast.parse(source(before))
    Python2FutureTransformer().visit(node)
    expected

# Generated at 2022-06-18 00:15:50.690510
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer.target == (2, 7)
    assert Python2FutureTransformer.__doc__ == 'Prepends module with:\n    from __future__ import absolute_import\n    from __future__ import division\n    from __future__ import print_function\n    from __future__ import unicode_literals\n        \n'


# Generated at 2022-06-18 00:16:21.375064
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer.target == (2, 7)
    assert isinstance(Python2FutureTransformer(), Python2FutureTransformer)


# Generated at 2022-06-18 00:16:29.754306
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import get_node
    from ..utils.test_utils import get_node_module

    code = """
    def foo():
        pass
    """
    node = get_node(code)
    node = Python2FutureTransformer().visit(node)
    assert_equal_code(node, """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    def foo():
        pass
    """)

    code = """
    def foo():
        pass
    """
    node = get_node_module(code)
    node = Python2FutureTransformer().visit(node)

# Generated at 2022-06-18 00:16:33.952565
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer.target == (2, 7)
    assert Python2FutureTransformer.__doc__ == """Prepends module with:
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
            
    """


# Generated at 2022-06-18 00:16:39.297795
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import assert_source_equal
    from ..utils.test_utils import get_ast

    source = """
    def foo():
        pass
    """
    expected = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    
    def foo():
        pass
    """
    tree = get_ast(source)
    transformer = Python2FutureTransformer()
    new_tree = transformer.visit(tree)
    assert_source_equal(expected, new_tree)

# Generated at 2022-06-18 00:16:40.746356
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import assert_source_equal
    from ..utils.test_utils import get_ast


# Generated at 2022-06-18 00:16:48.419682
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.ast_helper import compare_ast
    from ..utils.ast_helper import parse_ast
    from ..utils.ast_helper import parse_source
    from ..utils.ast_helper import source_to_ast

    source = '''
    def f():
        pass
    '''
    expected = '''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    def f():
        pass
    '''
    tree = parse_source(source)
    transformer = Python2FutureTransformer()
    new_tree = transformer.visit(tree)
    assert compare_ast

# Generated at 2022-06-18 00:16:55.178406
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source
    from ..utils.compare_ast import compare_ast
    from ..utils.visitor import dump_tree

    source = source('''
    def foo():
        pass
    ''')
    tree = ast.parse(source)
    tree = Python2FutureTransformer().visit(tree)
    print(dump_tree(tree))
    assert compare_ast(ast.parse(imports.get_source(future='__future__') + source), tree)

# Generated at 2022-06-18 00:16:59.868729
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source2ast
    from ..utils.source import ast2source
    from ..utils.source import source2source
    from ..utils.source import source2source_transformed
    from ..utils.source import source2source_transformed_with_imports
    from ..utils.source import source2source_transformed_with_imports_and_future
    from ..utils.source import source2source_transformed_with_future
    from ..utils.source import source2source_transformed_with_future_and_imports
    from ..utils.source import source2source_transformed_with_future_and_imports_and_typing
    from ..utils.source import source2source_transformed_with_future_and_typing
    from ..utils.source import source2source_transformed_with_imports

# Generated at 2022-06-18 00:17:00.627633
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer(None).target == (2, 7)

# Generated at 2022-06-18 00:17:02.081709
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)
