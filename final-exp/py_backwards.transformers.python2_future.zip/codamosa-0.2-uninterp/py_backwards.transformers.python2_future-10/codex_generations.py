

# Generated at 2022-06-18 00:08:17.531754
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__')

# Generated at 2022-06-18 00:08:24.280054
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_node
    from ..utils.source import source_to_nodes
    from ..utils.source import source_to_tokens
    from ..utils.source import source_to_token_values
    from ..utils.source import source_to_token_types
    from ..utils.source import source_to_token_names
    from ..utils.source import source_to_token_start_pos
    from ..utils.source import source_to_token_end_pos
    from ..utils.source import source_to_token_line
    from ..utils.source import source_to_token_column
    from ..utils.source import source_to_token_line_col

# Generated at 2022-06-18 00:08:33.249433
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__')

# Generated at 2022-06-18 00:08:38.949376
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_test_module
    from ..utils.visitor import dump_ast
    from ..utils.visitor import dump_source
    from ..utils.visitor import visit_and_dump_ast
    from ..utils.visitor import visit_and_dump_source

    module = make_test_module()
    visit_and_dump_ast(module, Python2FutureTransformer)
    visit_and_dump_source(module, Python2FutureTransformer)

# Generated at 2022-06-18 00:08:50.157527
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True

# Generated at 2022-06-18 00:08:57.226240
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
           

# Generated at 2022-06-18 00:09:05.973425
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__')

# Generated at 2022-06-18 00:09:07.323454
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import assert_source


# Generated at 2022-06-18 00:09:14.892503
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import generate_code
    from ..utils.test_utils import generate_code_expected
    from ..utils.test_utils import generate_ast
    from ..utils.test_utils import generate_ast_expected
    from ..utils.test_utils import generate_source_info
    from ..utils.test_utils import generate_source_info_expected
    from ..utils.test_utils import generate_tokens
    from ..utils.test_utils import generate_tokens_expected
    from ..utils.test_utils import generate_tokens_source_info
    from ..utils.test_utils import generate_tokens_source_info_expected
    from ..utils.test_utils import generate_source
    from ..utils.test_utils import generate_source_expected


# Generated at 2022-06-18 00:09:23.846408
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from .python2_future import Python2FutureTransformer

    @snippet
    def code():
        def f():
            pass

    @snippet
    def expected():
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        def f():
            pass

    node = ast.parse(code.get_source())
    expected_node = ast.parse(expected.get_source())
    transformer = Python2FutureTransformer()
    transformer.visit(node)
    assert ast_to_str(node)

# Generated at 2022-06-18 00:09:28.386214
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer(None).target == (2, 7)


# Generated at 2022-06-18 00:09:34.977146
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from .python2_future import Python2FutureTransformer
    from ..utils.source import source

    @snippet
    def module():
        def f():
            pass
    
    tree = module.get_ast()
    transformer = Python2FutureTransformer()
    transformer.visit(tree)

# Generated at 2022-06-18 00:09:45.028520
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source
    from ..utils.ast import get_ast, compare_asts
    from .base import BaseNodeTransformerTestCase

    class Test(BaseNodeTransformerTestCase):
        target = (2, 7)
        transformer = Python2FutureTransformer
        results = {
            'empty_module': {
                'target': source(''),
                'transformed': source(imports.get_source(future='__future__'))
            },
            'simple_module': {
                'target': source('''
                    def foo():
                        pass
                '''),
                'transformed': source(imports.get_source(future='__future__') + '''
                    def foo():
                        pass
                ''')
            }
        }

    compare_asts(Test)

# Generated at 2022-06-18 00:09:47.092292
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Unit test for constructor of class Python2FutureTransformer"""
    # pylint: disable=unused-variable
    transformer = Python2FutureTransformer()
    assert True


# Generated at 2022-06-18 00:10:17.233159
# Unit test for constructor of class Python2FutureTransformer

# Generated at 2022-06-18 00:10:22.874135
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)
    assert transformer.visit_Module(ast.parse('pass')) == ast.parse(
        'from __future__ import absolute_import\n'
        'from __future__ import division\n'
        'from __future__ import print_function\n'
        'from __future__ import unicode_literals\n'
        'pass'
    )

# Generated at 2022-06-18 00:10:27.717324
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer.target == (2, 7)
    assert Python2FutureTransformer.__doc__ == """Prepends module with:
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
            
    """


# Generated at 2022-06-18 00:10:35.089732
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.fixtures import make_dummy_tree
    from ..utils.source import source

    tree = make_dummy_tree(source("""
        def foo():
            pass
    """))

    transformer = Python2FutureTransformer()
    transformer.visit(tree)

    assert transformer._tree_changed is True
    assert source(tree) == source("""
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        def foo():
            pass
    """)

# Generated at 2022-06-18 00:10:35.868578
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer()

# Generated at 2022-06-18 00:10:46.595919
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_test_module
    from ..utils.visitor import dump
    from ..utils.source import source

    module = make_test_module(
        """
        import os
        import sys
        import math
        """,
        target=(2, 7)
    )
    transformer = Python2FutureTransformer()
    module = transformer.visit(module)
    assert transformer.tree_changed is True
    assert source(module) == """
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        import os
        import sys
        import math
        """

# Generated at 2022-06-18 00:10:51.613773
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'

# Generated at 2022-06-18 00:11:00.763741
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals


    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True

# Generated at 2022-06-18 00:11:08.296050
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__')

# Generated at 2022-06-18 00:11:11.991359
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.ast_helper import compare_ast
    from ..utils.ast_helper import get_ast


# Generated at 2022-06-18 00:11:22.741857
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals


    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True

# Generated at 2022-06-18 00:11:30.608260
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source
    from ..utils.ast import get_ast, ast_equal
    from ..utils.future import future_imports

    source_code = source(
        """
        def foo():
            pass
        """
    )
    expected_ast = get_ast(
        """
        def foo():
            pass
        """
    )
    expected_ast.body = future_imports.get_body(future='__future__') + expected_ast.body  # type: ignore
    assert ast_equal(Python2FutureTransformer().visit(get_ast(source_code)), expected_ast)

# Generated at 2022-06-18 00:11:41.088903
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import assert_source


# Generated at 2022-06-18 00:11:53.086227
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_builder import build_ast
    from ..utils.source_snippets import source_snippets
    from ..utils.source_snippets import source_snippets_from_ast
    from ..utils.source_snippets import source_snippets_from_tree
    from ..utils.source_snippets import source_snippets_from_node
    from ..utils.source_snippets import source_snippets_from_visit
    from ..utils.source_snippets import source_snippets_from_generic_visit
    from ..utils.source_snippets import source_snippets_from_visit_children
    from ..utils.source_snippets import source_snippets_from_visit_child
   

# Generated at 2022-06-18 00:12:03.219549
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source
    from ..utils.ast import dump_ast, dump_source
    from ..utils.visitor import dump_visitor_tree
    from ..utils.compare import compare_source

    # Test constructor
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)

    # Test visit_Module
    source_ast = source.parse_ast(source.get_source(imports))
    source_ast = transformer.visit(source_ast)
    source_ast = transformer.visit(source_ast)
    source_ast = transformer.visit(source_ast)
    assert transformer._tree_changed is True
    assert transformer._changed is False
    assert transformer._visited_count == 1
    assert transformer._visited_changed_count == 1
    assert transformer._visited

# Generated at 2022-06-18 00:12:13.436726
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.source import source
    from ..utils.ast_factory import ast_factory
    from ..utils.source_factory import source_factory
    from ..utils.snippet import snippet
    from ..utils.visitor import NodeVisitor
    from ..utils.visitor import visit_nodes
    from ..utils.visitor import visit_node
    from ..utils.visitor import visit_children
    from ..utils.visitor import visit_child
    from ..utils.visitor import visit_field
    from ..utils.visitor import visit_fields
    from ..utils.visitor import visit_iterable
    from ..utils.visitor import visit_optional
    from ..utils.visitor import visit_optional_node
    from ..utils.visitor import visit_optional_field


# Generated at 2022-06-18 00:12:24.168758
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    import astor
    from typed_ast import ast3 as ast

    node = ast.parse('print("Hello World")')
    node = Python2FutureTransformer().visit(node)
    assert astor.to_source(node) == '''\
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

print("Hello World")'''

# Generated at 2022-06-18 00:12:31.199374
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer.target == (2, 7)
    assert Python2FutureTransformer.__doc__ == """Prepends module with:
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
            
    """


# Generated at 2022-06-18 00:12:36.468770
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source2ast
    from ..utils.source import ast2source
    from ..utils.source import source2source
    from ..utils.source import source2source_transformer
    from ..utils.source import source2source_transformer_visitor
    from ..utils.source import source2source_visitor
    from ..utils.source import source2source_visitor_transformer


# Generated at 2022-06-18 00:12:40.663834
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)
    assert transformer.visit_Module.__name__ == 'visit_Module'
    assert transformer.visit_Module.__qualname__ == 'Python2FutureTransformer.visit_Module'


# Generated at 2022-06-18 00:12:50.793936
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True

# Generated at 2022-06-18 00:12:58.318951
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from .python2_future import Python2FutureTransformer
    from .python2_future import imports
    from .python2_future import test_Python2FutureTransformer_visit_Module
    from .python2_future import test_Python2FutureTransformer_visit_Module_1
    from .python2_future import test_Python2FutureTransformer_visit_Module_2
    from .python2_future import test_Python2FutureTransformer_visit_Module_3
    from .python2_future import test_Python2FutureTransformer_visit_Module_4
    from .python2_future import test_Python2FutureTransformer_visit_Module_5

# Generated at 2022-06-18 00:13:10.041952
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_test_module
    from ..utils.visitor import dump_ast

    module = make_test_module(
        """
        def foo():
            pass
        """)
    transformer = Python2FutureTransformer()
    transformer.visit(module)

# Generated at 2022-06-18 00:13:16.070206
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import assert_source

    source = """
    def foo():
        pass
    """
    expected = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    def foo():
        pass
    """
    assert_source(Python2FutureTransformer, source, expected)

# Generated at 2022-06-18 00:13:18.287071
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source

    class_ = Python2FutureTransformer
    source_ = source(class_)
    assert source_ == source(class_)

# Generated at 2022-06-18 00:13:28.541074
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.source import source
    from ..utils.ast_source import ast_source
    from ..utils.ast_compare import compare_ast
    from ..utils.ast_compare import compare_source
    from ..utils.ast_compare import compare_source_with_ast
    from ..utils.ast_compare import compare_source_with_source
    from ..utils.ast_compare import compare_source_with_source_with_ast
    from ..utils.ast_compare import compare_source_with_source_with_source
    from ..utils.ast_compare import compare_source_with_source_with_source_with_ast
    from ..utils.ast_compare import compare_source_with_source_with_source_with_source

# Generated at 2022-06-18 00:13:50.138709
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    @snippet
    def module():
        a = 1
        b = 2
        c = 3

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)


# Generated at 2022-06-18 00:13:58.967003
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__')

# Generated at 2022-06-18 00:14:09.460048
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__')

# Generated at 2022-06-18 00:14:20.237842
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals


    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True

# Generated at 2022-06-18 00:14:25.889976
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.test_utils import assert_source
    from ..utils.test_utils import get_node
    from ..utils.test_utils import get_source
    from ..utils.test_utils import run_transformer
    source = get_source(Python2FutureTransformer)
    node = get_node(source)
    node = run_transformer(Python2FutureTransformer, node)
    assert_source(node, source)

# Generated at 2022-06-18 00:14:31.163082
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from .python2future import Python2FutureTransformer
    from .python3future import Python3FutureTransformer
    from .python2unicode import Python2UnicodeTransformer
    from .python3unicode import Python3UnicodeTransformer
    from .python2division import Python2DivisionTransformer
    from .python3division import Python3DivisionTransformer
    from .python2print import Python2PrintTransformer
    from .python3print import Python3PrintTransformer
    from .python2absolute import Python2AbsoluteImportTransformer
    from .python3absolute import Python3AbsoluteImportTransformer
    from .python2relative import Python2RelativeImportTransformer
    from .python3relative import Python3Rel

# Generated at 2022-06-18 00:14:42.037093
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_test_module
    from ..utils.visitor import NodeVisitor
    from ..utils.source import source

    class Visitor(NodeVisitor):
        def visit_ImportFrom(self, node: ast.ImportFrom) -> None:
            if node.module == '__future__':
                assert node.names[0].name == 'absolute_import'
                assert node.names[1].name == 'division'
                assert node.names[2].name == 'print_function'
                assert node.names[3].name == 'unicode_literals'

    module = make_test_module('', target=(2, 7))
    module = Python2FutureTransformer().visit(module)
    Visitor().visit(module)

# Generated at 2022-06-18 00:14:51.750369
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
           

# Generated at 2022-06-18 00:14:57.525940
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.test_utils import assert_source

    source = '''
        def foo():
            pass
    '''
    expected = '''
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        def foo():
            pass
    '''
    tree = ast.parse(source)
    Python2FutureTransformer().visit(tree)
    assert_source(tree, expected)

# Generated at 2022-06-18 00:15:08.564003
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.source import source_to_ast
    from ..utils.snippet import snippet
    from ..utils.source import source_to_ast
    from ..utils.source import ast_to_source
    from ..utils.source import source_to_ast
    from ..utils.source import ast_to_source
    from ..utils.source import source_to_ast
    from ..utils.source import ast_to_source
    from ..utils.source import source_to_ast
    from ..utils.source import ast_to_source
    from ..utils.source import source_to_ast
    from ..utils.source import ast_to_source
    from ..utils.source import source_to_ast
    from ..utils.source import ast_to_source
    from ..utils.source import source

# Generated at 2022-06-18 00:15:44.471836
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_source_equal
    from ..utils.test_utils import parse_ast_tree

    tree = parse_ast_tree('''
        def foo():
            pass
    ''')
    transformer = Python2FutureTransformer()
    new_tree = transformer.visit(tree)
    assert_source_equal('''
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        def foo():
            pass
    ''', new_tree)

# Generated at 2022-06-18 00:15:46.802895
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'

# Generated at 2022-06-18 00:15:47.744165
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    Python2FutureTransformer()

# Generated at 2022-06-18 00:15:56.541343
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import assert_source

    source = """
    #!/usr/bin/env python
    # -*- coding: utf-8 -*-

    def foo():
        pass
    """
    expected = """
    #!/usr/bin/env python
    # -*- coding: utf-8 -*-
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals


    def foo():
        pass
    """
    tree = ast.parse(source)
    Python2FutureTransformer().visit(tree)
    assert_source(tree, expected)

# Generated at 2022-06-18 00:15:58.878025
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer.target == (2, 7)


# Generated at 2022-06-18 00:16:05.188100
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_source_equal
    from ..utils.test_utils import get_visitor
    from ..utils.test_utils import load_example_snippet

    snippet_name = 'Python2FutureTransformer_visit_Module'
    snippet_path = load_example_snippet(snippet_name)
    snippet_ast = ast.parse(snippet_path.read_text())
    visitor = get_visitor(Python2FutureTransformer, snippet_ast)
    visitor.visit(snippet_ast)
    assert_source_equal(snippet_ast, snippet_name)

# Generated at 2022-06-18 00:16:07.924797
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    t = Python2FutureTransformer()
    assert t.target == (2, 7)


# Generated at 2022-06-18 00:16:13.873693
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer.target == (2, 7)
    assert Python2FutureTransformer.__doc__ == """Prepends module with:
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
            
    """


# Generated at 2022-06-18 00:16:18.908608
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import assert_source

    source = """
    def foo():
        pass
    """
    expected = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    def foo():
        pass
    """
    tree = ast.parse(source)
    Python2FutureTransformer().visit(tree)
    assert_source(tree, expected)

# Generated at 2022-06-18 00:16:27.867637
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
           

# Generated at 2022-06-18 00:17:50.812734
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_code
    from ..utils.source import source_to_tokens
    from ..utils.source import source_to_token_names
    from ..utils.source import source_to_token_values
    from ..utils.source import source_to_token_offsets
    from ..utils.source import source_to_token_end_offsets
    from ..utils.source import source_to_token_line_numbers
    from ..utils.source import source_to_token_column_numbers
    from ..utils.source import source_to_token_line_offsets
    from ..utils.source import source_to_token_end_line_offsets
    from ..utils.source import source_to_token_column_offsets

# Generated at 2022-06-18 00:17:59.843551
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source
    from ..utils.compare_ast import compare_ast
    from ..utils.visitor import dump_tree
    from ..utils.visitor import dump_code
    from ..utils.visitor import dump_source
    from ..utils.visitor import dump_tokens
    from ..utils.visitor import dump_grammar

    source_ast = source.get_ast(source.get_source('python2'))
    source_code = source.get_code(source.get_source('python2'))
    source_tokens = source.get_tokens(source.get_source('python2'))
    source_grammar = source.get_grammar(source.get_source('python2'))

    print('\n--- source_ast ---')

# Generated at 2022-06-18 00:18:10.034986
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source
    from ..utils.ast import get_ast, compare_asts
