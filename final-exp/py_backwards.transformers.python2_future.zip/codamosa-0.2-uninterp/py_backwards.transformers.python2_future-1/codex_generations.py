

# Generated at 2022-06-18 00:08:18.355998
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import transform, compare_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import get_ast_node
    from ..utils.test_utils import get_ast_node_name

    source = """
    def foo():
        pass
    """
    expected = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    def foo():
        pass
    """
    tree = parse_ast(source)
    node = get_ast_node(tree, 'Module')
    new_node = Python2FutureTransformer().visit(node)  # type: ignore
    assert compare_ast(new_node, expected)



# Generated at 2022-06-18 00:08:24.768450
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_test_module
    from ..utils.visitor import dump_ast
    from ..utils.source import dedent
    from ..utils.source import source_to_ast

    source = dedent("""
    def foo():
        pass
    """)
    expected = dedent("""
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    def foo():
        pass
    """)
    module = make_test_module(source)
    module.ast = source_to_ast(source)
    transformer = Python2FutureTransformer()
    transformer.visit(module)
    assert dump_ast(module.ast) == dump_ast(source_to_ast(expected))

# Generated at 2022-06-18 00:08:33.480536
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Module, Name, Load, Str, ImportFrom
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed

# Generated at 2022-06-18 00:08:44.312259
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.ast_helper import compare_ast
    from ..utils.ast_helper import parse_ast
    from ..utils.ast_helper import parse_snippet
    from ..utils.ast_helper import run_transformer
    from .base import BaseNodeTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__') + node.body  # type: ignore
            return self.generic_visit(node)  # type: ignore

    # Test with empty module
    module = parse_snippet('pass')

# Generated at 2022-06-18 00:08:53.769393
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_module
    from ..utils.source import source_to_code
    from ..utils.source import source_to_tokens
    from ..utils.source import source_to_token_names
    from ..utils.source import source_to_comments
    from ..utils.source import source_to_node_linenos
    from ..utils.source import source_to_node_col_offsets
    from ..utils.source import source_to_node_end_lineno
    from ..utils.source import source_to_node_end_col_offset
    from ..utils.source import source_to_node_depth
    from ..utils.source import source_to_node_parent
    from ..utils.source import source_to_node_parents
   

# Generated at 2022-06-18 00:09:00.393635
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import transform_and_compare
    transform_and_compare(Python2FutureTransformer, '''
    def foo():
        pass
    ''', '''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    def foo():
        pass
    ''')

# Generated at 2022-06-18 00:09:08.351639
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_module
    from ..utils.source import source_to_code
    from ..utils.source import source_to_tokens
    from ..utils.source import source_to_token_list
    from ..utils.source import source_to_token_generator
    from ..utils.source import source_to_token_stream
    from ..utils.source import source_to_token_iterator
    from ..utils.source import source_to_token_iter
    from ..utils.source import source_to_token_enumerate
    from ..utils.source import source_to_token_enumerator
    from ..utils.source import source_to_token_enum
    from ..utils.source import source_to_token_zip

# Generated at 2022-06-18 00:09:15.477387
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import assert_ast_equal
    from ..utils.ast_helper import parse_ast
    from ..utils.ast_helper import get_ast_node_name
    from ..utils.ast_helper import get_ast_node_lineno
    from ..utils.ast_helper import get_ast_node_col_offset
    from ..utils.ast_helper import get_ast_node_end_lineno
    from ..utils.ast_helper import get_ast_node_end_col_offset
    from ..utils.ast_helper import get_ast_node_fields
    from ..utils.ast_helper import get_ast_node_field_value
    from ..utils.ast_helper import get_ast_node_field_values


# Generated at 2022-06-18 00:09:23.196773
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    @snippet
    def module():
        pass

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)


# Generated at 2022-06-18 00:09:34.269429
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
           

# Generated at 2022-06-18 00:09:42.838288
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import assert_source

    source = """
    import os
    import sys
    import re
    import math
    """
    expected = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    import os
    import sys
    import re
    import math
    """
    tree = ast.parse(source)
    Python2FutureTransformer().visit(tree)
    assert_source(tree, expected)

# Generated at 2022-06-18 00:09:51.093892
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_node
    from ..utils.source import source_to_tokens
    from ..utils.source import source_to_token_values
    from ..utils.source import source_to_token_types
    from ..utils.source import source_to_token_names
    from ..utils.source import source_to_token_offsets
    from ..utils.source import source_to_token_linenos
    from ..utils.source import source_to_token_end_linenos
    from ..utils.source import source_to_token_columns
    from ..utils.source import source_to_token_end_columns
    from ..utils.source import source_to_token_line_offsets


# Generated at 2022-06-18 00:09:59.818469
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True

# Generated at 2022-06-18 00:10:05.818739
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
           

# Generated at 2022-06-18 00:10:15.327515
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_builder import AstBuilder
    from ..utils.source_code import SourceCode
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def code():
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals
        import sys
        import os
        import re

    @snippet
    def expected():
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        import sys
        import os
        import re

    source_code = SourceCode(code.get_source())

# Generated at 2022-06-18 00:10:22.837917
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source
    from ..utils.ast import get_ast, compare_asts

    source = source('''
        import os
        import sys
    ''')
    expected_ast = get_ast('''
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        
        import os
        import sys
    ''')

    tree = get_ast(source)
    new_tree = Python2FutureTransformer().visit(tree)

    assert compare_asts(expected_ast, new_tree)

# Generated at 2022-06-18 00:10:30.713099
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__')

# Generated at 2022-06-18 00:10:35.794988
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    import astor
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet

    @snippet
    def code():
        print('Hello world')

    tree = ast.parse(code.get_source())
    transformer = Python2FutureTransformer()
    transformer.visit(tree)
    assert astor.to_source(tree) == imports.get_source(future='__future__') + code.get_source()

# Generated at 2022-06-18 00:10:46.509159
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import transform, compare_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import parse_snippet
    from ..utils.test_utils import get_ast_node
    from ..utils.test_utils import get_ast_nodes
    from ..utils.test_utils import get_ast_node_names
    from ..utils.test_utils import get_ast_node_name
    from ..utils.test_utils import get_ast_node_type
    from ..utils.test_utils import get_ast_node_types
    from ..utils.test_utils import get_ast_node_attr
    from ..utils.test_utils import get_ast_node_attrs
    from ..utils.test_utils import get_ast_node_attr_names

# Generated at 2022-06-18 00:10:52.573790
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import get_ast
    from ..utils.test_utils import get_source
    from ..utils.test_utils import get_target_ast

    source = get_source(__file__, 'test_Python2FutureTransformer_visit_Module.py')
    target = get_target_ast(__file__, 'test_Python2FutureTransformer_visit_Module.py')
    tree = get_ast(source)
    transformer = Python2FutureTransformer()
    new_tree = transformer.visit(tree)
    assert_equal_ast(new_tree, target)

# Generated at 2022-06-18 00:11:02.891312
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.test_utils import assert_source

    source = '''
    def foo():
        pass
    '''
    expected = '''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    
    def foo():
        pass
    '''
    tree = ast.parse(source)
    Python2FutureTransformer().visit(tree)
    assert_source(tree, expected)

# Generated at 2022-06-18 00:11:08.877983
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source
    from ..utils.ast import get_ast, compare_asts

    source = source('''
    def foo():
        pass
    ''')
    expected = source('''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    def foo():
        pass
    ''')

    module = get_ast(source)
    expected = get_ast(expected)

    transformer = Python2FutureTransformer()
    new_module = transformer.visit(module)

    assert compare_asts(expected, new_module)

# Generated at 2022-06-18 00:11:19.193567
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__')

# Generated at 2022-06-18 00:11:30.341103
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.ast_helper import parse_ast_tree
    from ..utils.ast_helper import compare_ast
    from ..utils.ast_helper import get_ast_node_at_line_number
    from ..utils.ast_helper import get_ast_node_at_line_number_and_offset
    from ..utils.ast_helper import get_ast_node_at_line_number_and_offset_range
    from ..utils.ast_helper import get_ast_node_at_line_number_range
    from ..utils.ast_helper import get_ast_node_at_offset
    from ..utils.ast_helper import get_ast_node_at_offset_range


# Generated at 2022-06-18 00:11:41.055197
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    @snippet
    def module():
        print('hello')

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)


# Generated at 2022-06-18 00:11:53.050824
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source
    from ..utils.ast import get_ast, compare_asts
    from ..utils.visitor import dump_ast

    source_1 = """
    print('Hello, world!')
    """
    expected_1 = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    print('Hello, world!')
    """
    source_2 = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    print('Hello, world!')
    """

# Generated at 2022-06-18 00:12:02.242599
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.fixtures import make_dummy_tree
    from ..utils.source import source
    from ..utils.visitor import dump_tree
    from ..utils.visitor import validate_tree
    from ..utils.visitor import visit_tree
    from ..utils.visitor import visit_tree_with_transformer

    tree = make_dummy_tree()
    print(source(tree))
    print(dump_tree(tree))
    validate_tree(tree)
    visit_tree(tree)
    visit_tree_with_transformer(tree, Python2FutureTransformer)
    print(source(tree))
    print(dump_tree(tree))
    validate_tree(tree)
    visit_tree(tree)

# Generated at 2022-06-18 00:12:06.479509
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import transform_and_compare
    transform_and_compare(Python2FutureTransformer,
                          'def foo():\n    pass',
                          'from __future__ import absolute_import\nfrom __future__ import division\nfrom __future__ import print_function\nfrom __future__ import unicode_literals\n\ndef foo():\n    pass')

# Generated at 2022-06-18 00:12:17.141085
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source_to_ast
    from ..utils.source import source_to_module
    from ..utils.source import source_to_code
    from ..utils.source import source_to_tokens
    from ..utils.source import source_to_token_names
    from ..utils.source import source_to_comments
    from ..utils.source import source_to_node_linenos
    from ..utils.source import source_to_node_col_offsets
    from ..utils.source import source_to_node_end_lineno
    from ..utils.source import source_to_node_end_col_offset
    from ..utils.source import source_to_node_depth
    from ..utils.source import source_to_node_parent_indices
    from ..utils.source import source_to_node_

# Generated at 2022-06-18 00:12:22.120029
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import assert_source

    source = """
    def foo():
        pass
    """
    expected = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    def foo():
        pass
    """
    tree = ast.parse(source)
    Python2FutureTransformer().visit(tree)
    assert_source(tree, expected)

# Generated at 2022-06-18 00:12:31.294159
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'

# Generated at 2022-06-18 00:12:41.182992
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source
    from ..utils.visitor import print_python_source
    from ..utils.visitor import visit_ast
    from ..utils.visitor import visit_ast_tree
    from ..utils.visitor import visit_ast_tree_recursive
    from ..utils.visitor import visit_ast_tree_recursive_iter
    from ..utils.visitor import visit_ast_tree_recursive_iter_with_parent
    from ..utils.visitor import visit_ast_tree_recursive_with_parent
    from ..utils.visitor import visit_ast_tree_with_parent
    from ..utils.visitor import visit_ast_with_parent
    from ..utils.visitor import visit_ast_with_parent_iter
    from ..utils.visitor import visit_ast_with_parent_iter_

# Generated at 2022-06-18 00:12:42.526657
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'

# Generated at 2022-06-18 00:12:45.701552
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    """Test for constructor of class Python2FutureTransformer"""
    # pylint: disable=unused-variable
    transformer = Python2FutureTransformer()


# Generated at 2022-06-18 00:12:54.809950
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source
    from ..utils.ast import get_ast, compare_asts, parse_ast

    source_1 = """
    import os
    import sys
    import math
    import numpy as np
    import pandas as pd
    import matplotlib.pyplot as plt
    """
    source_2 = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    import os
    import sys
    import math
    import numpy as np
    import pandas as pd
    import matplotlib.pyplot as plt
    """
    tree_1 = get_ast(source_1)
    tree_2 = get_ast(source_2)
    node_transformer

# Generated at 2022-06-18 00:13:05.779486
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from ..utils.ast_helper import ast_to_source
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    @snippet
    def code():
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        import math
        print(math.pi)


# Generated at 2022-06-18 00:13:14.271390
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.test_utils import assert_node_equal
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet

    @snippet
    def code_before():
        import os
        import sys
        import math
        import random

    @snippet
    def code_after():
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals
        import os
        import sys
        import math
        import random

    tree_before = ast.parse(code_before.get_source())
    tree_after = ast.parse(code_after.get_source())
    transformer = Python2FutureTransformer()
    tree_transformed = transformer.visit(tree_before)

# Generated at 2022-06-18 00:13:23.186527
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__')

# Generated at 2022-06-18 00:13:32.090625
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.snippet import snippet
    from ..utils.test_utils import assert_ast_equal

    @snippet
    def module():
        pass

    @snippet
    def expected():
        from __future__ import absolute_import
        from __future__ import division
        from __future__ import print_function
        from __future__ import unicode_literals

        pass

    module_node = module.get_ast()
    expected_node = expected.get_ast()
    transformer = Python2FutureTransformer()
    actual_node = transformer.visit(module_node)
    assert_ast_equal(expected_node, actual_node)

# Generated at 2022-06-18 00:13:41.656101
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import transform, compare_ast
    from ..utils.test_utils import parse_ast
    from ..utils.test_utils import get_ast_node
    from ..utils.test_utils import get_ast_node_name
    from ..utils.test_utils import get_ast_node_type
    from ..utils.test_utils import get_ast_node_lineno
    from ..utils.test_utils import get_ast_node_col_offset
    from ..utils.test_utils import get_ast_node_end_lineno
    from ..utils.test_utils import get_ast_node_end_col_offset
    from ..utils.test_utils import get_ast_node_value
    from ..utils.test_utils import get_ast_node_ctx
    from ..utils.test_utils import get

# Generated at 2022-06-18 00:14:03.912370
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_source_equal
    from ..utils.test_utils import get_ast

    source = """
    import os
    import sys
    """
    expected = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals
    import os
    import sys
    """
    tree = get_ast(source)
    transformer = Python2FutureTransformer()
    new_tree = transformer.visit(tree)  # type: ignore
    assert_source_equal(expected, new_tree)

# Generated at 2022-06-18 00:14:09.731794
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.fixtures import make_dummy_tree
    from ..utils.source import source
    from ..utils.visitor import dump_tree
    from ..utils.visitor import visit_and_replace_node
    from ..utils.visitor import visit_and_replace_tree

    tree = make_dummy_tree()

# Generated at 2022-06-18 00:14:20.572191
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.source import source_to_ast
    from ..utils.ast_helpers import dump_ast
    from ..utils.ast_helpers import get_first_class_or_function_node
    from ..utils.ast_helpers import get_first_import_node
    from ..utils.ast_helpers import get_first_import_from_node
    from ..utils.ast_helpers import get_first_import_from_node_names
    from ..utils.ast_helpers import get_first_import_from_node_module
    from ..utils.ast_helpers import get_first_import_from_node_names_as_str
    from ..utils.ast_helpers import get_first_import_from_node_module_as_str
    from ..utils.ast_helpers import get_first_import_

# Generated at 2022-06-18 00:14:30.257117
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source
    from ..utils.ast import ast_equal, dump
    from ..utils.future import future_absolute_import, future_division, future_print_function, future_unicode_literals
    from ..utils.compat import PYTHON_VERSION
    from ..utils.visitor import dump_visitor

    source_ast = source.parse('print("Hello, World!")')
    expected_ast = source.parse('''
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

print("Hello, World!")
''')

# Generated at 2022-06-18 00:14:41.001960
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_test_module
    from ..utils.visitor import dump_ast

    module = make_test_module()
    module = Python2FutureTransformer().visit(module)

# Generated at 2022-06-18 00:14:43.712513
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import assert_source

    source = """
    def foo():
        pass
    """
    expected = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    def foo():
        pass
    """
    tree = ast.parse(source)
    Python2FutureTransformer().visit(tree)
    assert_source(tree, expected)

# Generated at 2022-06-18 00:14:48.478761
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import assert_source_equal
    from ..utils.test_utils import get_node
    from ..utils.test_utils import get_source

    source = '''
    import os
    import sys
    '''
    expected = '''
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    import os
    import sys
    '''
    node = get_node(source, ast.Module)
    transformer = Python2FutureTransformer()
    new_node = transformer.visit(node)
    assert transformer._tree_changed
    assert_source_equal(get_source(new_node), expected)

# Generated at 2022-06-18 00:14:57.892141
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
           

# Generated at 2022-06-18 00:15:08.758622
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'
    assert Python2FutureTransformer.target == (2, 7)
    assert Python2FutureTransformer.__doc__ is not None
    assert Python2FutureTransformer.visit_Module.__doc__ is not None
    assert Python2FutureTransformer.visit_Module.__annotations__ == {'node': ast.Module, 'return': ast.Module}
    assert Python2FutureTransformer.visit_Module.__module__ == __name__
    assert Python2FutureTransformer.visit_Module.__name__ == 'visit_Module'
    assert Python2FutureTransformer.visit_Module.__qualname__ == 'Python2FutureTransformer.visit_Module'

# Generated at 2022-06-18 00:15:15.534475
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.fixtures import make_test_module
    from ..utils.visitor import dump_ast
    from ..utils.visitor import dump_source
    from ..utils.visitor import dump_tokens
    from ..utils.visitor import dump_types
    from ..utils.visitor import dump_symbols
    from ..utils.visitor import dump_symbols_table
    from ..utils.visitor import dump_symbols_table_summary
    from ..utils.visitor import dump_symbols_table_details
    from ..utils.visitor import dump_symbols_table_details_summary
    from ..utils.visitor import dump_symbols_table_details_summary_by_type
    from ..utils.visitor import dump_symbols_table_details_summary_by_type_and

# Generated at 2022-06-18 00:15:53.417802
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.source import source
    from ..utils.ast import dump
    from ..utils.ast import parse
    from ..utils.ast import equal

    source_ = source(imports)
    tree = parse(source_)
    transformer = Python2FutureTransformer()
    new_tree = transformer.visit(tree)
    expected_tree = parse(source_)
    assert equal(dump(new_tree), dump(expected_tree))

# Generated at 2022-06-18 00:16:02.048869
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body = imports.get_body(future='__future__')

# Generated at 2022-06-18 00:16:13.834143
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals


    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True

# Generated at 2022-06-18 00:16:14.991355
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    assert Python2FutureTransformer.__name__ == 'Python2FutureTransformer'

# Generated at 2022-06-18 00:16:17.903464
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)
    assert transformer.visit_Module(ast.parse("")) == ast.parse(imports.get_source(future='__future__'))

# Generated at 2022-06-18 00:16:27.411767
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from typed_ast import ast3 as ast
    from ..utils.snippet import snippet
    from .base import BaseNodeTransformer
    from .python2future import Python2FutureTransformer

    @snippet
    def imports(future):
        from future import absolute_import
        from future import division
        from future import print_function
        from future import unicode_literals

    class Python2FutureTransformer(BaseNodeTransformer):
        """Prepends module with:
            from __future__ import absolute_import
            from __future__ import division
            from __future__ import print_function
            from __future__ import unicode_literals
                
        """
        target = (2, 7)

        def visit_Module(self, node: ast.Module) -> ast.Module:
            self._tree_changed = True
            node.body

# Generated at 2022-06-18 00:16:30.566606
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    transformer = Python2FutureTransformer()
    assert transformer.target == (2, 7)
    assert transformer.visit_Module is not None


# Generated at 2022-06-18 00:16:36.443385
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.test_utils import assert_ast_equal
    from ..utils.test_utils import assert_source_equal
    from ..utils.test_utils import get_ast
    from ..utils.test_utils import get_source

    source = get_source(Python2FutureTransformer)
    expected_ast = get_ast(Python2FutureTransformer)
    actual_ast = Python2FutureTransformer().visit(get_ast(Python2FutureTransformer))
    assert_ast_equal(expected_ast, actual_ast)
    assert_source_equal(source, Python2FutureTransformer().visit(get_ast(Python2FutureTransformer)))

# Generated at 2022-06-18 00:16:41.401058
# Unit test for method visit_Module of class Python2FutureTransformer
def test_Python2FutureTransformer_visit_Module():
    from ..utils.test_utils import assert_source_equal
    from ..utils.test_utils import get_node

    source = """
    def foo():
        pass
    """
    expected = """
    from __future__ import absolute_import
    from __future__ import division
    from __future__ import print_function
    from __future__ import unicode_literals

    def foo():
        pass
    """
    node = get_node(source, ast.Module)
    transformer = Python2FutureTransformer()
    new_node = transformer.visit(node)
    assert_source_equal(expected, new_node)

# Generated at 2022-06-18 00:16:48.652152
# Unit test for constructor of class Python2FutureTransformer
def test_Python2FutureTransformer():
    from ..utils.test_utils import assert_equal_ast
    from ..utils.test_utils import assert_equal_code
    from ..utils.test_utils import assert_tree_changed
    from ..utils.test_utils import assert_tree_not_changed
    from ..utils.test_utils import assert_tree_unchanged

    # Test that the transformer works as expected
    assert_equal_ast(Python2FutureTransformer().visit(imports.get_ast(future='__future__')),
                     imports.get_ast(future='__future__'))
    assert_equal_code(Python2FutureTransformer().visit(imports.get_ast(future='__future__')),
                      imports.get_code(future='__future__'))